<!-- STABLE_PORT -->
## 2026-11-01 정식판 이식

모드 버전 **1.1.6**, 대상 게임 **2026-11-01**, WML **0.9.5**입니다. MCP 0.6.2로 연결을 검사합니다. 새 게임을 기준으로 하며 pre7 및 기존 저장 이전은 지원 범위에 포함하지 않습니다.

배포 파일: `construction-tool-compatible-brothel-1.1.6-20261101.zip`. 압축의 폴더 이름과 설치 ID는 `construction-tool-compatible-brothel`이며 `wml/mods/construction-tool-compatible-brothel/mod.js`로 설치합니다. WML 모드 관리자에서 ZIP 설치도 가능합니다. 아래의 pre7 버전·ZIP 안내는 이전 변경 기록입니다.
<!-- /STABLE_PORT -->

> **호환성 패치 기준:** construction-tool 1.2.10 / brothel 3.10.0
> 이번 개정의 기준 버전입니다. 버전 번호로 실행을 차단하지 않으며, 필수 모드와 실제 연결 기능은 필요합니다. 최신 구성에 맞춰 유지합니다.

# 건축 툴 · Brothel 지하 시설 연결 1.1.5

## [pre7 배포 · 버전 분리]

현재 모드 버전: 1.1.5. 대상 게임: 2026-10-24-pre7. 이전 모드 버전: 1.1.4-pre7.2.
배포 파일: construction-tool-compatible-brothel-1.1.5-pre7.zip
압축 내부 최상위 폴더와 로딩 ID는 항상 `construction-tool-compatible-brothel`이며 버전·pre 표기를 붙이지 않습니다. 폴더 복사 설치 경로는 `wml/mods/construction-tool-compatible-brothel/mod.js`입니다. ZIP 설치는 WML 모드 관리자를 사용하세요. 모드의 version은 숫자 버전, game은 대상 게임 식별자로 분리했습니다. 업데이트 인식을 위해 모드 버전의 마지막 숫자를 올렸으며 게임 동작은 이번 변경에서 수정하지 않았습니다. 이전 ZIP과 과거 변경 기록은 보존합니다.


필수: `construction-tool` 1.2.3 이상(2 미만), `brothel` 3.9.0 이상(4 미만).
`construction-tool-compatible-brothel-1.1.3.zip`을 본체들과 함께 설치하고 새로고침해 주세요.

지하의 세 시설은 각각 2×1칸을 예약해요.

- 지하방1: 1행 1~2열 / `brothel_cellar_1`
- 지하방2: 2행 1~2열 / `brothel_cellar_2`
- 휴게실: 3행 1~2열 / `brothel_break_room`

미건설 상태는 `(모드) 예약 자리`로 표시해요. 오른쪽 위 2×2 목욕탕과 겹치지 않아요.
본관 설계도에서 선택해 원래 비용과 30분 공사로 건설하고, 사용 중이 아닐 때 같은 층의 빈 공간으로 옮길 수 있어요.
시설이 2칸이므로 예전 한 칸짜리 자리 교환 대신 실제 면적의 겹침을 검사해요.

기존 방 ID·예약·직원 업무·유지비는 Brothel이 계속 소유해요. 이 모드는 Brothel 원본 파일을 수정하지 않아요.
가게의 중복 ‘아래층’ 줄을 숨기고 건축 툴의 지하 위치창에서 시설과 직원을 표시해요.
본체의 지하 확장 공사를 하면 이 시설을 배치할 수 있는 공간도 함께 넓어져요.
영업 준비 중 홀의 테이블을 변경하면 홀에 있던 Brothel 종업원을 휴게실로 보내고,
휴게실이 아직 없으면 건축 툴이 정한 뒷방·주방 등의 대체 장소로 이동시켜요.


## 2026-10-24-pre7 이식

- 배포 버전: `1.1.4-pre7.1` · WML 0.9.4 · 구 게임용 배포와 구분합니다.
- 원제작자·원문 출처 표기는 기존 머리말과 문서에 보존했습니다. 이 배포의 호환 수정: HL 작업본.
- 모드 내부 ID와 폴더 이름을 `construction-tool-compatible-brothel`로 통일했습니다. 이 폴더만 덮어쓸 수 있는 개별 ZIP을 함께 제공합니다.
- 구 게임의 압축 함수 이름과 탐색 규칙을 pre7에 맞췄습니다. 변경·검증의 전체 범위와 한계는 작업 폴더 `version_up_ready/PORT_RESULT.md`를 참고하세요.


## 1.1.4-pre7.2 · 2026-10-27 MCP 후속 보완

- MCP 0.6.1 기준의 고정 태그를 모드 자체에 선언했습니다. 제작자/원문 출처 및 기존 pack은 보존합니다.
