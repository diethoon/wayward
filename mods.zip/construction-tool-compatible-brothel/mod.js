// 호환성 패치 기준: construction-tool 1.2.10 / brothel 3.10.0 (개정 기준, 버전 번호에 따른 실행 제한 없음)
WML.define({
  tags: ["content"],
  id: 'construction-tool-compatible-brothel',
  author: "Hina_Lover",
  name: '건축 툴 · Brothel 지하 시설 연결',
  version: "1.1.6", game: "2026-11-01", lang: 'ko',
  description: '기존 지하방·휴게실을 건축 툴의 지하층에서 건설·배치하고 위치창에 통합해요.',
  requires: ['construction-tool', 'brothel'],
  /* requiresVersion: { 'construction-tool': '>=1.2.3 <2', brothel: '>=3.9.0 <4' }, */
  setup(api) {
    const building = api.use('construction-tool'), brothel = globalThis.__waywardBrothelPublic;
    if (!brothel?.purchaseCellar || !brothel?.purchaseBreakRoom) throw Error('Brothel 시설 API가 필요해요.');
    const rooms = [
      { id: 'brothel_cellar_1', field: 'hasBrothelCellar1', label: '지하방1', cost: 400, cells: [0,1] },
      { id: 'brothel_cellar_2', field: 'hasBrothelCellar2', label: '지하방2', cost: 400, cells: [4,5] },
      { id: 'brothel_break_room', field: 'hasBrothelBreakRoom', label: '휴게실', cost: 200, cells: [8,9] }
    ];
    rooms.forEach(room => building.registerExistingRoom({
      id: room.id, label: room.label, slot: `basement:${room.cells[0]}`, cells: room.cells,
      isBuilt: state => state.tavern?.[room.field] === true,
      isOccupied: () => brothel.atRoom(room.id).length > 0,
      occupantNames: () => brothel.atRoom(room.id).map(worker => worker.name),
      canBuild(state) {
        if (room.id === 'brothel_cellar_1' && !state.tavern?.backRoomReady) return '뒷방을 먼저 건설해 주세요.';
        if (room.id === 'brothel_cellar_2' && !state.tavern?.hasBrothelCellar1) return '지하방1을 먼저 건설해 주세요.';
        return state.economy.gold < room.cost ? `${room.cost}골드가 필요해요.` : null;
      },
      buildLabel: `${room.label} 건설 · ${room.cost}골드 · 30분`,
      description: '기존 Brothel의 공사 비용·소요 시간·유지비·방 기능을 사용해요. 배치는 지하층 안에서 변경해요.',
      build: () => room.id === 'brothel_break_room' ? brothel.purchaseBreakRoom() : brothel.purchaseCellar(room.id)
    }));

    // Brothel 종업원은 게임 state.locations가 아니라 자체 런타임에 있으므로
    // 건축 툴이 영업 준비 중 홀을 비울 때 호환 모드가 직접 위치를 옮겨요.
    building.registerHallEvacuator({
      id: 'construction-tool-compatible-brothel',
      evacuate(state, { roomId, fallbackRoom }) {
        const runtime = brothel.getRuntime();
        const destination = state.tavern?.hasBrothelBreakRoom ? 'brothel_break_room' : fallbackRoom;
        if (!destination || destination === roomId) return state;
        for (const worker of brothel.atRoom(roomId)) {
          const current = runtime.get(worker.id);
          if (current) runtime.set(worker.id, { ...current, location: destination });
        }
        return state;
      }
    });
    // Brothel still owns its facilities. Hide only its duplicate legacy row;
    // construction-tool renders the same rooms in the saved basement slots.
    const style = document.createElement('style');
    style.dataset.constructionBrothel = '';
    style.textContent = '[data-brothel-floor="below"]{display:none!important}';
    document.head.append(style);
  }
});
