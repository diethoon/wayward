const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const source = fs.readFileSync(require('node:path').join(__dirname, 'source/settings-panels.js'), 'utf8');
const start = source.indexOf('    let scenePromptEditorId =');
const end = source.indexOf('    const DRAFT_OUTFIT_PREVIEW_ID', start);
assert.ok(start >= 0 && end > start);

let saved = {};
let currentKey = 'wife__scene-patron_chatting__v-0';
let currentId = 'scene-patron_chatting';
let externalId = '';
let tableAvailable = true;
let refreshes = 0;
const table = { kissing: ['kiss'], patron_chatting: ['talk', 'smile'], patron_bold: ['touch'], bath_solo: ['bath'] };
const h = (tag, props, ...children) => ({ tag, props: props || {}, children: children.flat().filter(Boolean) });
const win = { refresh() {} };
const context = {
  latestScenePrompt: { characterId: 'wife', result: { key: currentKey, prompt: 'actual positive', negativePrompt: 'actual negative' } },
  latestPromptArgs: [{}], promptModPreview: { result: null, scope: 'global' }, activeSettingsTab: 'scene-prompts',
  activePortraitImageKey: () => currentKey,
  positionSituationId: () => currentId,
  basePositionSituationId: id => id.split('|')[0],
  positionSituationLabel: id => id,
  currentPositionStatePrompts: () => structuredClone(saved),
  scenePromptCatalog: () => {
    const ids = ['scene-patron_chatting', 'scene-patron_bold', ...(tableAvailable ? ['scene-bath_solo'] : []), 'task-idle', 'task-sleeping', ...Object.keys(saved), currentId];
    return [...new Set(ids)].map(id => ({ id, label: id, category: /^(scene|task|look)-/.exec(id)?.[1] || 'other' }));
  },
  currentPositionStatePrompt: id => saved[id] || (id === externalId ? { positivePrompt: 'external' } : null)
    || (!id.includes('|sleep-') ? saved[id.split('|')[0]] : null) || null,
  effectiveExternalTarget: (kind, id, value) => id === externalId ? { ...value, positivePrompt: 'external' } : value,
  api: { has: () => tableAvailable, fn: () => table, store: { game: () => ({ primaryCharacterId: 'wife' }) }, settings: { set: value => { saved = value.positionStatePrompts; } },
    ui: { button: (label, action) => h('button', { label, action }) } },
  nativeScenePromptCandidates: id => {
    if (!tableAvailable) return [];
    if (id === 'scene-patron_chatting') return [
      { source: 'scene', label: '게임 기본 후보 1', text: 'talk' },
      { source: 'scene', label: '게임 기본 후보 2', text: 'smile' },
      { source: 'bed', label: '침대 기본 후보', text: 'talk in bed' },
    ];
    if (id.startsWith('scene-patron_bold')) return [{ source: 'scene', label: '게임 기본 후보', text: 'touch' }];
    if (id === 'task-clean') return [{ source: 'task', label: '작업 기본 후보', text: 'cleaning' }];
    if (id === 'look-her|reaction-shy') return [{ source: 'look', label: '시선 기본 후보', text: 'looking' },
      { source: 'reaction', label: '반응 기본 후보', text: 'shy' }];
    return [];
  },
  renderSceneImagePreview: (make, win, id, active) => make('div', { 'data-scene-image-preview-test': id, active }),
  renderSceneBaseOverride: () => [],
  renderSceneCandidateEditor: () => null,
  renderCurrentStateEditor: (make, win, id, active) => make('div', { 'data-current-state-editor-test': id, active }),
  positionRandomChoices: { clear() {} },
  refreshPortraitImage: () => { refreshes += 1; },
  translatedPromptText: value => value,
  promptTagPreview: () => null,
  updatePromptTagPreview: () => {},
  activeTagTarget: null,
};
const render = vm.runInNewContext(`${source.slice(start, end)}; renderScenePrompts`, context);
const nodes = value => Array.isArray(value) ? value.flatMap(nodes) : value && typeof value === 'object'
  ? [value, ...nodes(value.children || [])] : [];
const find = (tree, attr) => nodes(tree).find(node => Object.hasOwn(node.props, attr));
const textOf = value => typeof value === 'string' ? value : (value?.children || []).map(textOf).join('');
let tree = render(h, win);
assert.ok(nodes(tree).indexOf(find(tree, 'data-scene-prompt-field')) < nodes(tree).indexOf(find(tree, 'data-scene-native-prompts')), 'editable additions precede long native candidates');
assert.ok(nodes(tree).indexOf(find(tree, 'data-current-state-editor-test')) < nodes(tree).indexOf(find(tree, 'data-scene-image-preview-test')), 'state edits precede image preview');
assert.deepEqual(saved, {}, 'displaying game prompts must not write user settings');
assert.ok(nodes(tree).some(node => node.tag === 'option' && node.props.value === 'scene-bath_solo'));
assert.equal(find(tree, 'data-scene-prompt-select').props.value, 'scene-patron_chatting');
assert.match(find(tree, 'data-scene-prompt-edit-guide').children.join(''), /기본 문구.*추가 문구/);
assert.equal(find(tree, 'data-scene-prompt-category').props.value, 'scene');
find(tree, 'data-scene-prompt-category').props.onchange({ currentTarget: { value: 'task' } });
tree = render(h, win);
assert.equal(find(tree, 'data-scene-prompt-select').props.value, 'task-idle');
assert.ok(nodes(tree).some(node => node.tag === 'option' && node.props.value === 'task-sleeping'), 'sleep is selectable while another situation is active');
find(tree, 'data-scene-prompt-select').props.onchange({ currentTarget: { value: 'scene-patron_chatting' } });
tree = render(h, win);
assert.match(find(tree, 'data-scene-native-prompts').children[0].children.join(''), /읽기 전용/);
assert.deepEqual(Array.from(nodes(tree).filter(node => Object.hasOwn(node.props, 'data-scene-native-variant')), textOf),
  ['게임 기본 후보 1 · talk', '게임 기본 후보 2 · smile', '침대 기본 후보 · talk in bed'], 'all original scene variants and sources are visible without being described as active');
assert.equal(find(tree, 'data-scene-prompt-id').tag, 'code', 'technical ID stays untranslated');
assert.ok(nodes(tree).filter(node => Object.hasOwn(node.props, 'data-scene-native-variant'))
  .every(node => node.children.some(child => child?.tag === 'code')), 'original candidates stay untranslated');
assert.equal(find(tree, 'data-scene-image-preview-test').props['data-scene-image-preview-test'], 'scene-patron_chatting');
assert.equal(find(tree, 'data-scene-image-preview-test').props.active, true);
assert.match(find(tree, 'data-scene-native-prompts').children.map(node => node.children?.join('') || '').join(' '), /Negative가 없어요/);
const actualFields = nodes(tree).filter(node => Object.hasOwn(node.props, 'data-scene-current-prompt'));
assert.deepEqual(Array.from(actualFields, node => node.props.value), ['actual positive', 'actual negative']);
assert.ok(actualFields.every(node => node.props.readOnly), 'calculated prompt is display-only');
let fields = nodes(tree).filter(node => node.props['data-scene-prompt-field']);
fields[0].props.oninput({ currentTarget: { value: 'talking, smiling' } });
fields[1].props.onchange({ currentTarget: { value: 'closed mouth' } });
assert.equal(saved['scene-patron_chatting'].positivePrompt, 'talking, smiling');
assert.equal(saved['scene-patron_chatting'].negativePrompt, 'closed mouth');
assert.equal(refreshes, 1);
find(tree, 'data-scene-prompt-select').props.onchange({ currentTarget: { value: 'scene-patron_bold' } });
tree = render(h, win);
assert.equal(find(tree, 'data-scene-prompt-select').props.value, 'scene-patron_bold');
assert.equal(nodes(tree).filter(node => Object.hasOwn(node.props, 'data-scene-current-prompt')).length, 0,
  'a different selected scene must not display a stale actual prompt');
assert.deepEqual(Array.from(nodes(tree).filter(node => Object.hasOwn(node.props, 'data-scene-native-variant')), textOf), ['게임 기본 후보 · touch']);
fields = nodes(tree).filter(node => node.props['data-scene-prompt-field']);
fields[0].props.onchange({ currentTarget: { value: 'holding her waist' } });
assert.equal(saved['scene-patron_bold'].positivePrompt, 'holding her waist');
assert.equal(refreshes, 1, 'editing another scene must not refresh current portrait');
currentKey = 'wife__scene-patron_bold__v-0';
currentId = 'scene-patron_bold';
tree = render(h, win);
assert.equal(nodes(tree).filter(node => Object.hasOwn(node.props, 'data-scene-current-prompt')).length, 0,
  'a stale image key must not be described as current');
context.latestScenePrompt = { characterId: 'other', result: { key: currentKey, prompt: 'wrong person', negativePrompt: '' } };
tree = render(h, win);
assert.equal(nodes(tree).filter(node => Object.hasOwn(node.props, 'data-scene-current-prompt')).length, 0,
  'a different character must not be described as current');
context.latestScenePrompt = { characterId: 'wife', result: { key: currentKey, prompt: 'current bold', negativePrompt: 'no violence' } };
tree = render(h, win);
assert.deepEqual(Array.from(nodes(tree).filter(node => Object.hasOwn(node.props, 'data-scene-current-prompt')), node => node.props.value), ['current bold', 'no violence']);
assert.equal(find(tree, 'data-scene-prompt-select').props.value, 'scene-patron_bold');
assert.match(find(tree, 'data-scene-prompt-active').children.join(''), /선택한 상황/);
assert.ok(nodes(tree).some(node => node.tag === 'button' && node.props.label === '다른 모드 프롬프트 수정'));
currentId = 'scene-patron_bold|abed-1';
tree = render(h, win);
assert.match(find(tree, 'data-scene-prompt-active').children.join(''), /선택한 상황/, 'base entry is inherited');
saved[currentId] = { positivePrompt: 'specific', negativePrompt: '', onlyState: false };
tree = render(h, win);
assert.match(find(tree, 'data-scene-prompt-active').children.join(''), /다른 상황/, 'specific entry takes priority');
delete saved[currentId];
externalId = currentId;
tree = render(h, win);
assert.match(find(tree, 'data-scene-prompt-active').children.join(''), /다른 상황/, 'specific external entry takes priority');
externalId = '';
currentId = 'scene-patron_bold|sleep-asleep';
tree = render(h, win);
assert.match(find(tree, 'data-scene-prompt-active').children.join(''), /다른 상황/, 'sleep does not inherit base entry');
saved['task-clean'] = { positivePrompt: 'old', negativePrompt: '', onlyState: false };
saved['look-her|reaction-shy'] = { positivePrompt: 'old', negativePrompt: '', onlyState: false };
find(tree, 'data-scene-prompt-select').props.onchange({ currentTarget: { value: 'task-clean' } });
tree = render(h, win);
assert.equal(find(tree, 'data-scene-native-variant').props['data-scene-native-source'], 'task');
find(tree, 'data-scene-prompt-select').props.onchange({ currentTarget: { value: 'look-her|reaction-shy' } });
tree = render(h, win);
assert.deepEqual(Array.from(nodes(tree).filter(node => Object.hasOwn(node.props, 'data-scene-native-source')), node => node.props['data-scene-native-source']), ['look', 'reaction']);
tableAvailable = false;
tree = render(h, win);
assert.ok(find(tree, 'data-scene-prompt-partial'));
assert.match(find(tree, 'data-scene-native-prompts').children.map(node => node.children?.join('') || '').join(' '), /확인할 수 없어요/);
assert.ok(nodes(tree).some(node => node.tag === 'option' && node.props.value === 'look-her|reaction-shy'), 'saved entry remains available when the native table is unavailable');
console.log('scene prompt UI: ok');
