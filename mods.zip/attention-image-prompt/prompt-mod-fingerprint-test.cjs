const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, 'source/prompt-mod-rules.js'), 'utf8');
const start = source.indexOf('    function promptTokens(');
const end = source.indexOf('    function deduplicatePrompt(', start);
assert(start >= 0 && end > start);
let saved = { promptModRules: [] }, setupFinished, settingsListener = null, settingsReads = 0, statusCalls = 0;
let loaded = ['mod-one'], booted = false;
const wml = { status: () => { statusCalls++; return { loaded, booted }; } };
const api = { id: 'attention-image-prompt',
  settings: { get: defaults => { settingsReads++; return { ...defaults, ...saved }; },
    set: next => { settingsListener?.(next); saved = { ...saved, ...next }; } },
  afterEachSetup: callback => { setupFinished = callback; },
};
const make = new Function('api', 'globalThis', 'shortHash', 'positionSituationId', 'deduplicatePrompt', 'promptGenParams',
  `${source.slice(start, end)}\nreturn { reloadPromptModRules, currentPromptModRules, savePromptModRule,
    deletePromptModRule, effectivePromptModRules, promptModRulesFingerprint, applyPromptModRules };`);
const feature = make(api, { WML: wml }, value => require('node:crypto').createHash('sha256').update(value).digest('hex').slice(0, 12),
  key => String(key || '').split('__').find(part => /^(?:scene|task|look)-/.test(part)) || '',
  value => value, prompt => ({ prompt }));
const scene = 'scene-test';
for (let i = 0; i < 100; i++) assert.equal(feature.promptModRulesFingerprint(scene), '');
assert.equal(statusCalls, 0, 'without configured rules there is no WML status call');
assert.equal(settingsReads, 1, 'without configured rules settings are read only at setup');

feature.savePromptModRule(api.id, 'positive', 'add', 'bright light', scene, { enabled: true });
const first = feature.promptModRulesFingerprint(scene);
assert.ok(first);
assert.equal(feature.promptModRulesFingerprint('scene-other'), '');
assert.equal(statusCalls, 1);
const reads = settingsReads;
for (let i = 0; i < 100; i++) feature.promptModRulesFingerprint(scene);
assert.equal(statusCalls, 1, 'boot-time repeated image lookups reuse one loaded-mod snapshot');
assert.equal(settingsReads, reads, 'image-key calculation does not reread settings');
const input = { key: 'wife__scene-test__v-0', prompt: '1girl', negativePrompt: 'bad', parts: [] };
assert.match(feature.applyPromptModRules(input).prompt, /bright light/);
feature.savePromptModRule('mod-disabled', 'negative', 'add', 'extra', scene, { enabled: true });
assert.equal(feature.promptModRulesFingerprint(scene), first, 'disabled mods do not alter automatic keys');
assert.equal(feature.applyPromptModRules(input).negativePrompt, 'bad');
loaded = ['mod-one', 'mod-disabled']; setupFinished('mod-disabled');
const enabled = feature.promptModRulesFingerprint(scene);
assert.notEqual(enabled, first);
assert.match(feature.applyPromptModRules(input).negativePrompt, /extra/);
assert.equal(statusCalls, 2, 'newly completed setup refreshes the loaded snapshot once');
for (let i = 0; i < 100; i++) feature.promptModRulesFingerprint(scene);
assert.equal(statusCalls, 2);
booted = true; setupFinished('last-mod');
assert.equal(feature.promptModRulesFingerprint(scene), enabled);
assert.equal(statusCalls, 3, 'first lookup after setup completion refreshes once');
for (let i = 0; i < 100; i++) feature.promptModRulesFingerprint(scene);
assert.equal(statusCalls, 3, 'idle post-boot lookups do not repeat WML.status');

feature.savePromptModRule(api.id, 'positive', 'add', 'bright light', scene, { enabled: true, korean: '풀이만 변경' });
assert.equal(feature.promptModRulesFingerprint(scene), enabled, 'translation-only edits preserve image keys');
feature.savePromptModRule(api.id, 'positive', 'add', 'bright light', scene, { enabled: true, replacement: 'warm light' });
const replaced = feature.promptModRulesFingerprint(scene);
assert.notEqual(replaced, enabled);
assert.match(feature.applyPromptModRules(input).prompt, /warm light/);
feature.deletePromptModRule(api.id, 'positive', 'add', 'bright light', scene);
assert.notEqual(feature.promptModRulesFingerprint(scene), replaced);
feature.deletePromptModRule('mod-disabled', 'negative', 'add', 'extra', scene);
assert.equal(feature.promptModRulesFingerprint(scene), '');

feature.savePromptModRule(api.id, 'positive', 'current', '1girl', '', { enabled: false });
assert.ok(feature.promptModRulesFingerprint('scene-other'));
feature.savePromptModRule(api.id, 'positive', 'current', '1girl', scene, { enabled: true });
assert.equal(feature.promptModRulesFingerprint(scene), '', 'a scene-specific no-op suppresses the global removal');
assert.equal(feature.applyPromptModRules(input).prompt, '1girl');
assert.equal(feature.applyPromptModRules({ ...input, key: 'wife__scene-other__v-0' }).prompt, '');
saved.promptModRules = [];
feature.reloadPromptModRules();
assert.equal(feature.promptModRulesFingerprint('scene-other'), '', 'import and reset refresh cached rules');
assert.equal(feature.applyPromptModRules(input).prompt, '1girl');
let observed;
settingsListener = () => { observed = { fingerprint: feature.promptModRulesFingerprint(scene),
  prompt: feature.applyPromptModRules(input).prompt }; };
feature.savePromptModRule(api.id, 'positive', 'add', 'atomic light', scene, { enabled: true });
assert.ok(observed.fingerprint, 'a synchronous settings listener observes the new key before save returns');
assert.match(observed.prompt, /atomic light/, 'a synchronous settings listener observes the new prompt');
const stable = feature.promptModRulesFingerprint(scene);
assert.equal(observed.fingerprint, stable);
settingsListener = () => {
  observed = { fingerprint: feature.promptModRulesFingerprint(scene), prompt: feature.applyPromptModRules(input).prompt };
  throw new Error('settings write failed');
};
assert.throws(() => feature.deletePromptModRule(api.id, 'positive', 'add', 'atomic light', scene), /settings write failed/);
assert.equal(observed.fingerprint, '', 'the listener sees the staged deletion');
assert.equal(observed.prompt, '1girl');
assert.equal(feature.promptModRulesFingerprint(scene), stable, 'a failed delete restores the previous key');
assert.match(feature.applyPromptModRules(input).prompt, /atomic light/);
assert.equal(saved.promptModRules.length, 1, 'a failed write keeps the persisted rule');
assert.throws(() => feature.savePromptModRule(api.id, 'positive', 'add', 'atomic light', scene,
  { enabled: true, replacement: 'other light' }), /settings write failed/);
assert.notEqual(observed.fingerprint, stable, 'a listener sees the staged replacement');
assert.match(observed.prompt, /other light/);
assert.equal(feature.promptModRulesFingerprint(scene), stable, 'a failed save restores the previous key');
assert.match(feature.applyPromptModRules(input).prompt, /atomic light/);
settingsListener = null;
feature.deletePromptModRule(api.id, 'positive', 'add', 'atomic light', scene);
assert.equal(feature.promptModRulesFingerprint(scene), '');
console.log('prompt mod fingerprint: ok');
