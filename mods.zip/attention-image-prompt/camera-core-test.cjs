const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

let settings = {}, draw = 0, currentKey = 'wife__scene-hug__v-0', cached = null, hangLookup = false, lookupGate = null;
let styleLoaded = false, styleNoPov = false, statusCalls = 0, onSetup;
const imageRequestTraceSymbol = Symbol('trace');
const nativeFreshVariantKeys = new Set();
const context = {
  api: { settings: { get: defaults => ({ ...defaults, ...settings }), set: patch => { settings = { ...settings, ...patch }; } }, afterEachSetup: fn => { onSetup = fn; },
    store: { game: () => ({ primaryCharacterId: 'wife' }) } },
  CAMERA_PRESET_GROUPS: vm.runInNewContext(fs.readFileSync(require('node:path').join(__dirname, 'source/camera-presets.js'), 'utf8') + '\nCAMERA_PRESET_GROUPS'), CAMERA_REMOVE_DEFAULTS: ['pov', 'from above'],
  CAMERA_NEGATIVE_DEFAULTS: vm.runInNewContext(fs.readFileSync(require('node:path').join(__dirname, 'source/camera-presets.js'), 'utf8') + '\nCAMERA_NEGATIVE_DEFAULTS'),
  splitFinalPrompt: value => ({ tokens: String(value).split(','), separators: [] }),
  globalPromptExclusionIdentity: token => { const value = String(token || '').trim().toLowerCase().replace(/^\((.*?)(?::[0-9.]+)?\)$/, '$1').replaceAll('_', ' '); return value ? `tag:${value}` : ''; },
  deduplicateFinalPrompt: text => [...new Set(String(text).split(',').map(item => item.trim()).filter(Boolean))].join(', '),
  shortHash: text => [...text].reduce((sum, char) => (sum * 33 + char.charCodeAt(0)) >>> 0, 5381).toString(36),
  activePortraitImageKey: () => currentKey,
  positionSituationId: key => (String(key).split('__').find(item => /^(scene|task|look)-/.test(item)) || ''),
  baseSituationImageKey: key => String(key).split('__').filter(item => !/^aip(?:k)?-/.test(item)).join('__'),
  compactGenerationKey: key => key,
  similarImageSituationKey: key => String(key).replace(/__v-\d+$/, ''),
  nativeFreshVariantKeys, imageRequestTraceSymbol, imagePlanDepth: 0,
  imageLookup: async () => lookupGate || (hangLookup ? new Promise(() => {}) : cached), imageEntryExists: async () => true,
  legacyDetailImageKeys: new Map(), statusCacheAliases: new Map(), latestScenePrompt: null,
  notifyExternalPromptChange() {}, promptGenParams: () => ({ steps: 8 }),
  removeGlobalPromptExclusions: value => value,
  applyGlobalPromptExclusions: request => request,
  WML: { status: () => { statusCalls++; return { loaded: styleLoaded ? ['style-lock'] : [] }; } },
  localStorage: { getItem: () => JSON.stringify({ noPov: styleNoPov }) },
  Math: { floor: Math.floor, ceil: Math.ceil, max: Math.max, random: () => draw }, Date, console, setTimeout, clearTimeout,
};
vm.runInNewContext(fs.readFileSync(require('node:path').join(__dirname, 'source/camera-core.js'), 'utf8')
  + '\n;globalThis.testCamera = { cameraController, cameraSettingsFingerprint, cameraApplyPromptResult, cameraGenerationAround, reloadCameraSettings };', context);
const { cameraController: camera, cameraSettingsFingerprint: fingerprint, cameraApplyPromptResult: apply, cameraGenerationAround: generate, reloadCameraSettings: reload } = context.testCamera;

(async () => {
  const originalCatalog = context.CAMERA_PRESET_GROUPS;
  context.CAMERA_PRESET_GROUPS = vm.runInNewContext(fs.readFileSync(require('node:path').join(__dirname, 'source/camera-presets.js'), 'utf8') + '\nCAMERA_PRESET_GROUPS');
  const oldFront = '(frontal camera view:1.3)';
  const comboId = 'camera-front-none-above-none-none-none';
  const oldCombo = '(frontal camera view:1.3), (high-angle camera view:1.3)';
  const migratedFixture = {
    'scene-hug': { shots: [
      { id: 'front', name: '사용자 이름', positive: oldFront, negative: 'custom-negative', future: 'keep' },
      { id: comboId, name: '조합', positive: oldCombo, negative: '' },
      { id: 'side', name: '사용자 편집', positive: '(side camera view:1.2)', negative: 'personal' },
      { id: 'above', name: '무가중 기본', positive: 'high-angle camera view', negative: '' },
      { id: 'custom', name: '자유 입력', positive: oldFront, negative: '' },
    ], selected: ['front', comboId], removeTags: 'user-remove', futureScene: 'keep' },
  };
  const metadata = { 'wife__scene-hug__v-4': { id: 'front', name: 'old', positive: oldFront, negative: '' } };
  settings = { cameraSceneSettings: JSON.parse(JSON.stringify(migratedFixture)), cameraImageMetadata: metadata };
  const oldToken = context.shortHash(JSON.stringify(['camera-layout-v4', [
    [comboId, oldCombo, ''], ['front', oldFront, 'custom-negative'],
  ].sort((a, b) => a[0].localeCompare(b[0])), ['tag:user-remove']]));
  reload();
  assert.equal(settings.cameraPresetRevision, 2, 'migration writes its revision together with settings');
  const after = camera.get('scene-hug');
  assert.equal(after.shots.find(shot => shot.id === 'front').positive, '(front view:1.3), (straight-on:1.3)');
  assert.equal(after.shots.find(shot => shot.id === comboId).positive, '(front view:1.3), (straight-on:1.3), (top view:1.3), (from_above:1.3)');
  assert.equal(after.shots.find(shot => shot.id === 'above').positive, '(top view:1.3), (from_above:1.3)', 'exact 1.74 unweighted default migrates');
  assert.equal(after.shots.find(shot => shot.id === 'side').positive, '(side camera view:1.2)', 'custom weighting is preserved');
  assert.equal(after.shots.find(shot => shot.id === 'custom').positive, oldFront, 'custom IDs are never inferred as built-ins');
  assert.equal(after.shots.find(shot => shot.id === 'front').name, '사용자 이름');
  assert.equal(after.shots.find(shot => shot.id === 'front').negative, 'custom-negative');
  assert.deepEqual(Array.from(after.selected), ['front', comboId]);
  assert.equal(settings.cameraSceneSettings['scene-hug'].futureScene, 'keep', 'unknown saved scene fields are not discarded');
  assert.equal(settings.cameraSceneSettings['scene-hug'].shots[0].future, 'keep', 'unknown saved shot fields are not discarded');
  assert.deepEqual(settings.cameraImageMetadata, metadata, 'existing image metadata remains unchanged');
  assert.notEqual(fingerprint('scene-hug'), oldToken, 'a migrated selected prompt changes the image key');
  camera.set('scene-hug', { ...after, shots: after.shots.map(shot => shot.id === 'front' ? { ...shot, positive: oldFront } : shot) });
  reload();
  assert.equal(camera.get('scene-hug').shots.find(shot => shot.id === 'front').positive, oldFront,
    'after revision is set, explicitly saved old text survives reload');
  const writeSettings = context.api.settings.set;
  settings = { cameraSceneSettings: JSON.parse(JSON.stringify(migratedFixture)), cameraImageMetadata: metadata };
  const beforeFailure = JSON.stringify(settings);
  const previousConsole = context.console, warnings = [];
  context.console = { ...console, warn: (...args) => warnings.push(args.join(' ')) };
  context.api.settings.set = () => {};
  reload();
  assert.equal(JSON.stringify(settings), beforeFailure, 'a swallowed storage failure leaves the old settings intact');
  assert.match(warnings.join(' '), /migration was not saved/, 'a failed migration is reported');
  assert.equal(camera.get('scene-hug').shots.find(shot => shot.id === 'front').positive, oldFront, 'failed migration does not expose an unpersisted value');
  context.api.settings.set = writeSettings;
  context.console = previousConsole;
  reload();
  assert.equal(camera.get('scene-hug').shots.find(shot => shot.id === 'front').positive, '(front view:1.3), (straight-on:1.3)', 'migration retries after storage recovers');
  const sideOld = '(from_side:1.3)';
  const sideView = '(side view:1.3), (from_side:1.3)';
  const revisionOne = { 'scene-hug': { shots: [
    { id: 'side', name: '사용자 이름', positive: sideOld, negative: 'keep-negative', extra: 'keep' },
    { id: comboId, name: '조합', positive: '(straight-on:1.3), (from_above:1.3)', negative: '' },
    { id: 'front', name: '변경됨', positive: '(straight-on:1.2)', negative: 'custom' },
    { id: 'rear', name: '직접 쓴 옛 문구', positive: '(rear camera view:1.3)', negative: '' },
  ], selected: ['side', comboId], removeTags: 'preserve' } };
  settings = { cameraSceneSettings: JSON.parse(JSON.stringify(revisionOne)), cameraImageMetadata: metadata, cameraPresetRevision: 1 };
  reload();
  const revisionTwo = camera.get('scene-hug');
  assert.equal(settings.cameraPresetRevision, 2);
  assert.equal(revisionTwo.shots.find(shot => shot.id === 'side').positive, sideView, 'revision 1 default migrates');
  assert.equal(revisionTwo.shots.find(shot => shot.id === comboId).positive, '(front view:1.3), (straight-on:1.3), (top view:1.3), (from_above:1.3)', 'revision 1 composite migrates');
  assert.equal(revisionTwo.shots.find(shot => shot.id === 'front').positive, '(straight-on:1.2)', 'custom weighting is retained');
  assert.equal(revisionTwo.shots.find(shot => shot.id === 'rear').positive, '(rear camera view:1.3)', 'revision 1 old text intentionally entered by a user is retained');
  assert.equal(settings.cameraSceneSettings['scene-hug'].shots[0].extra, 'keep');
  assert.equal(revisionTwo.shots[0].name, '사용자 이름');
  assert.equal(revisionTwo.shots[0].negative, 'keep-negative');
  assert.deepEqual(settings.cameraImageMetadata, metadata);
  camera.set('scene-hug', { ...revisionTwo, shots: revisionTwo.shots.map(shot => shot.id === 'side' ? { ...shot, positive: sideOld } : shot) });
  reload();
  assert.equal(camera.get('scene-hug').shots.find(shot => shot.id === 'side').positive, sideOld, 'revision 2 protects a later intentional old value');
  const legacyTags = {
    pov: 'pov', third_person: 'third-person perspective', pov_hands: 'pov, pov_hands',
    pov_above: 'pov, from_above', pov_below: 'pov, from_below',
    front: 'straight-on', three_quarter: 'from_side', side: 'from_side', rear: 'from_behind',
    above: 'from_above', ceiling_near: 'from_above, cowboy_shot', below: 'from_below', high_up: 'high_up, from_above',
    portrait: 'portrait', face_close: 'portrait, close-up', close_up: 'close-up', upper_body: 'upper_body',
    cowboy_shot: 'cowboy_shot', lower_body: 'lower_body', full_body: 'full_body', wide_shot: 'wide_shot',
    very_wide_shot: 'very_wide_shot', between_legs: 'from_below, thighs',
    dutch: 'dutch_angle', sideways: 'sideways', upside_down: 'upside-down', fisheye: 'fisheye',
  };
  const catalogue = context.CAMERA_PRESET_GROUPS.flatMap(group => group.items);
  assert.equal(catalogue.length, Object.keys(legacyTags).length, 'each old preset has a migration test');
  settings = { cameraPresetRevision: 1, cameraImageMetadata: metadata, cameraSceneSettings: { 'scene-hug': {
    shots: Object.entries(legacyTags).map(([id, value]) => ({ id, name: `saved-${id}`,
      positive: value.split(', ').map(term => `(${term}:1.3)`).join(', '), negative: 'keep-negative' })),
    selected: ['side', 'front'], removeTags: 'preserve',
  } } };
  reload();
  for (const preset of catalogue) {
    const migrated = camera.get('scene-hug').shots.find(shot => shot.id === preset.id);
    assert.equal(migrated.positive, preset.positive, `revision 1 default for ${preset.id} is updated`);
    assert.equal(migrated.name, `saved-${preset.id}`);
    assert.equal(migrated.negative, 'keep-negative');
  }
  assert.deepEqual(settings.cameraImageMetadata, metadata);
  assert.deepEqual(Array.from(camera.get('scene-hug').selected), ['side', 'front']);
  settings = { cameraSceneSettings: JSON.parse(JSON.stringify(revisionOne)), cameraImageMetadata: metadata };
  reload();
  assert.equal(camera.get('scene-hug').shots.find(shot => shot.id === 'side').positive, sideView, 'markerless revision 1 default migrates');
  assert.equal(camera.get('scene-hug').shots.find(shot => shot.id === 'rear').positive, '(back view:1.3), (from_behind:1.3)', 'markerless older photography default migrates');
  settings = {};
  context.CAMERA_PRESET_GROUPS = originalCatalog;
  reload();
  assert.equal(fingerprint('scene-hug'), '');
  const a = { id: 'a', name: '앞', positive: 'front view, custom_a', negative: 'bad view' };
  const b = { id: 'b', name: '위', positive: 'from above, custom_b', negative: '' };
  assert.equal(camera.set('scene-hug', { shots: [a, b], selected: [], removeTags: '' }).ok, true);
  assert.equal(fingerprint('scene-hug'), '', 'disabled draft never changes image keys');
  assert.equal(camera.set('scene-hug', { shots: [a, b], selected: ['a'], removeTags: 'wide shot' }).ok, true);
  const signature = fingerprint('scene-hug');
  const oldSignature = context.shortHash(JSON.stringify(['camera-layout-v2', [['a', a.positive, a.negative]], ['tag:wide shot']]));
  assert.notEqual(signature, oldSignature, 'automatic negative changes the camera image key');
  const previousSignature = context.shortHash(JSON.stringify(['camera-layout-v3', [['a', a.positive, a.negative]], ['tag:wide shot']]));
  assert.notEqual(signature, previousSignature, 'enhanced camera negatives invalidate earlier camera keys');
  assert.equal(camera.get('scene-hug|abed-1').active, true, 'detail inherits base settings');
  assert.equal(camera.reset('scene-hug|abed-1').ok, true);
  assert.equal(camera.get('scene-hug|abed-1').active, false, 'reset blocks inherited camera on this detail only');
  assert.equal(camera.get('scene-hug').active, true, 'detail reset preserves the shared base');
  assert.equal(fingerprint('scene-hug|abed-1'), '', 'explicit detail reset restores its old image key');
  assert.equal(camera.set('scene-hug', { shots: [{ ...a, name: '바뀐 이름' }, b], selected: ['a'], removeTags: 'wide shot' }).ok, true);
  assert.equal(fingerprint('scene-hug'), signature, 'display names never change image keys');
  const fixed = apply({ key: currentKey, prompt: '1girl, pov, wide_shot', negativePrompt: 'front view', parts: [{ label: '장면', tags: 'pov, wide_shot' }] });
  assert.match(fixed.prompt, /custom_a/);
  assert.doesNotMatch(fixed.prompt, /pov|wide_shot/);
  assert.doesNotMatch(fixed.negativePrompt, /front view/);
  assert.match(fixed.negativePrompt, /camera in frame/);
  assert.match(fixed.negativePrompt, /viewfinder overlay/);
  assert.match(fixed.negativePrompt, /DSLR camera/);
  assert.match(fixed.negativePrompt, /camera held in hands/);
  assert.match(fixed.negativePrompt, /bad view/, 'saved custom negative remains applied');
  assert.equal(camera.get('scene-hug').shots.find(shot => shot.id === 'a').negative, a.negative, 'automatic defaults never overwrite stored negative');
  assert.equal(camera.list().negativeDefaults, context.CAMERA_NEGATIVE_DEFAULTS);
  const userCamera = camera.preview('scene-hug', '1girl, (visible camera:1.25)', '');
  assert.doesNotMatch(userCamera.negativePrompt, /visible camera/, 'an explicit positive overrides the matching automatic negative');
  assert.match(userCamera.negativePrompt, /camera device/, 'unrelated automatic negatives remain');
  const userEquipment = camera.preview('scene-hug', '1girl, (DSLR camera:1.1), fisheye lens', '');
  assert.doesNotMatch(userEquipment.negativePrompt, /DSLR camera/, 'explicit positive equipment takes precedence');
  assert.match(userEquipment.prompt, /fisheye lens/, 'equipment negatives do not remove angle or lens prompts');
  const parts = [{ label: '품질', tags: 'masterpiece, best quality' },
    { label: '기본', tags: '1girl, (character name:1.2)' }, { label: '의상', tags: 'red dress' }];
  const ordered = apply({ key: currentKey, prompt: 'masterpiece, best quality, 1girl, (character name:1.2), red dress', negativePrompt: '', parts });
  assert.equal(ordered.prompt, 'masterpiece, best quality, 1girl, (character name:1.2), front view, custom_a, red dress');
  assert.deepEqual(Array.from(ordered.parts, part => part.label), ['품질', '기본', 'AIP 카메라 구도', '의상']);
  const expected = camera.preview('scene-hug', 'masterpiece, best quality, 1girl, (character name:1.2), red dress', '', { parts });
  assert.equal(expected.placement, 'after-base');
  assert.equal(expected.prompt, ordered.prompt, 'preview and imagePrompt share the same base insertion');
  assert.equal(expected.negativePrompt, ordered.negativePrompt, 'preview and imagePrompt use the same automatic negatives');
  assert.equal(camera.preview('scene-hug', 'unknown structure, red dress', '').placement, 'fallback');
  context.latestScenePrompt = { result: { key: currentKey, parts } };
  await generate(async request => { assert.equal(request.prompt, ordered.prompt, 'actual generation uses the same insertion');
    assert.equal(request.negativePrompt, ordered.negativePrompt, 'actual generation uses the same automatic negatives'); return {}; },
    { imageKey: currentKey, prompt: 'masterpiece, best quality, 1girl, (character name:1.2), red dress', negativePrompt: '', debug: { stats: {} } });
  context.latestScenePrompt = null;
  const observer = { id: 'camera-none-third_person-none-none-none-none', name: '3인칭', positive: 'from_side', negative: '' };
  camera.apply('scene-hug', { shots: [observer], selected: [observer.id], removeTags: '' });
  const observerPreview = camera.preview('scene-hug', '1girl, (pov_hands:1.2), hand on another\'s hips', '');
  assert.doesNotMatch(observerPreview.prompt, /pov_hands/);
  assert.match(observerPreview.prompt, /hand on another's hips/, 'physical action is retained');
  assert.match(observerPreview.negativePrompt, /pov_hands/);
  camera.apply('scene-hug', { shots: [{ ...observer, positive: 'from_side, pov_hands' }], selected: [observer.id], removeTags: '' });
  assert.doesNotMatch(camera.preview('scene-hug', '1girl', '').negativePrompt, /pov_hands/,
    'explicit user positive overrides the automatic third-person negative');
  camera.set('scene-hug', { shots: [a, b], selected: ['a'], removeTags: 'wide shot' });
  assert.equal(camera.set('scene-hug', { shots: [a, b], selected: ['a', 'b'], removeTags: '' }).ok, true);
  assert.equal(camera.preview('scene-hug', '1girl', '').shotId, null, 'random preview is unresolved until an actual draw');
  assert.equal(camera.cacheToken('scene-hug'), '', 'random cache token requires a resolved shot');
  draw = 0.99;
  const drawn = camera.preview('scene-hug', '1girl', '', { draw: true });
  draw = 0;
  assert.equal(camera.preview('scene-hug', '1girl', '', { shotId: drawn.shotId }).prompt, drawn.prompt,
    'explicit shotId reproduces an earlier random preview');
  assert.ok(camera.cacheToken('scene-hug', drawn.shotId));
  assert.equal(camera.cacheToken('scene-hug', 'not-selected'), '');
  const priorParts = [...parts, { label: 'AIP 카메라 구도', tags: 'front view, custom_a, shared_other' },
    { label: '다른 모드', tags: 'shared_other' }];
  const alternate = camera.preview('scene-hug', 'masterpiece, best quality, 1girl, (character name:1.2), red dress, front view, custom_a, shared_other', '',
    { shotId: 'b', parts: priorParts });
  assert.doesNotMatch(alternate.prompt, /custom_a/, 'random preview removes only the previously chosen camera text');
  assert.match(alternate.prompt, /shared_other/, 'random preview retains text also contributed by another mode');
  assert.match(alternate.prompt, /custom_b/);
  const make = key => ({ imageKey: key, prompt: '1girl, pov', negativePrompt: '', debug: { stats: {} } });
  let sent = [];
  draw = 0;
  let response = await generate(async request => { sent.push(request.prompt); return { imageMatchingMissing: true }; }, make(currentKey));
  assert.equal(response.imageMatchingMissing, true);
  draw = 0.99;
  await generate(async request => { sent.push(request.prompt); return { url: 'a.webp', fresh: true }; }, make(currentKey));
  assert.match(sent[0], /custom_a/);
  assert.match(sent[1], /custom_a/, 'retry keeps the original draw');
  assert.equal(camera.get('scene-hug').resolvedShotId, 'a');
  reload();
  assert.equal(camera.get('scene-hug').resolvedShotId, 'a', 'successful draw survives reload');
  currentKey = 'wife__scene-hug__v-1';
  nativeFreshVariantKeys.add(currentKey);
  sent = [];
  await generate(async request => { sent.push(request.prompt); return { url: 'b.webp', fresh: true }; }, make(currentKey));
  assert.match(sent[0], /custom_b/, 'a fresh variant draws again');
  assert.equal(camera.get('scene-hug').resolvedShotId, 'b');
  styleLoaded = true; styleNoPov = true; onSetup('style-lock');
  const callsAfterSetup = statusCalls;
  const styleShot = { id: 'p', name: '시점', positive: 'pov, pov from above', negative: '' };
  assert.equal(camera.set('scene-hug', { shots: [styleShot], selected: ['p'], removeTags: '' }).ok, true);
  const stylePreview = camera.preview('scene-hug', '1girl', '');
  assert.doesNotMatch(stylePreview.prompt, /pov/);
  assert.match(stylePreview.prompt, /from above/);
  assert.ok(camera.get('scene-hug').warnings.length);
  const photoShot = { id: 'q', name: '위 시점', positive: '(first-person camera view from above:1.2), first-person camera view with hands in the foreground', negative: '' };
  camera.set('scene-hug', { shots: [photoShot], selected: ['q'], removeTags: '' });
  const photoPreview = camera.preview('scene-hug', '1girl', '');
  assert.doesNotMatch(photoPreview.prompt, /first.person/i, 'noPov removes the new first-person photography phrases');
  assert.match(photoPreview.prompt, /\(high-angle camera view:1\.2\)/, 'noPov preserves the camera height and weight');
  assert.equal(statusCalls, callsAfterSetup, 'camera preview does not repeatedly copy WML status');
  styleNoPov = false;
  assert.match(camera.preview('scene-hug', '1girl', '').prompt, /first.person/i, 'style setting changes apply without a restart');
  assert.equal(camera.set('scene-hug', { shots: [a, b], selected: ['a', 'b'], removeTags: '' }).ok, true);
  nativeFreshVariantKeys.delete(currentKey);
  cached = { talentName: currentKey };
  const previous = settings.cameraImageMetadata[currentKey].id;
  await generate(async request => { assert.equal(request.prompt, '1girl, pov'); return { url: 'cached.webp', fresh: false }; }, make(currentKey));
  assert.equal(settings.cameraImageMetadata[currentKey].id, previous, 'cache hits do not draw or replace metadata');
  cached = null; hangLookup = true;
  let forwarded = false;
  const start = Date.now();
  await generate(async () => { forwarded = true; return { url: 'new.webp', fresh: true }; }, make(currentKey));
  assert.equal(forwarded, true, 'an unfinished optional cache lookup cannot block generation indefinitely');
  assert.ok(Date.now() - start < 2500, 'stalled lookup has a bounded delay');
  hangLookup = false;
  let resolveLookup;
  lookupGate = new Promise(resolve => { resolveLookup = resolve; });
  const oldRequest = make(currentKey);
  let racedRequest;
  const waiting = generate(async request => { racedRequest = request; return {}; }, oldRequest);
  await Promise.resolve();
  camera.apply('scene-hug', { shots: [b], selected: ['b'], removeTags: '' });
  resolveLookup(null);
  await waiting;
  assert.equal(racedRequest, undefined, 'selection changed during lookup must cancel the obsolete generation');
  lookupGate = null; reload();
  lookupGate = new Promise(resolve => { resolveLookup = resolve; });
  let disabledForwarded = false;
  const disabledWaiting = generate(async () => { disabledForwarded = true; return {}; }, make(currentKey));
  await Promise.resolve();
  camera.apply('scene-hug', { shots: [], selected: [], removeTags: '' });
  resolveLookup(null);
  assert.equal(await disabledWaiting, null, 'disabling camera settles the obsolete request');
  assert.equal(disabledForwarded, false);
  lookupGate = null; reload();
  lookupGate = new Promise(resolve => { resolveLookup = resolve; });
  let sceneForwarded = false;
  const sceneWaiting = generate(async () => { sceneForwarded = true; return {}; }, make(currentKey));
  await Promise.resolve();
  currentKey = 'wife__scene-kissing__v-0';
  resolveLookup(null);
  assert.equal(await sceneWaiting, null, 'scene change settles the obsolete request');
  assert.equal(sceneForwarded, false);
  currentKey = 'wife__scene-hug__v-1'; lookupGate = null;
  lookupGate = new Promise(resolve => { resolveLookup = resolve; });
  let initializedForwarded = false;
  const initialWaiting = generate(async () => { initializedForwarded = true; return {}; }, make(currentKey));
  await Promise.resolve();
  currentKey = 'wife__scene-hug__aip-state-distressed__v-1';
  resolveLookup(null);
  await initialWaiting;
  assert.equal(initializedForwarded, true, 'initial status code changes alone do not cancel the first portrait');
  currentKey = 'wife__scene-hug__v-1'; lookupGate = null;
  const saved = JSON.stringify(settings.cameraSceneSettings), savedSignature = fingerprint('scene-hug');
  assert.equal(camera.apply('scene-hug', { shots: [b], selected: ['b'], removeTags: '' }).reason, 'applied');
  assert.equal(camera.get('scene-hug').dirty, true, 'temporary choice is visibly unsaved');
  assert.notEqual(fingerprint('scene-hug'), savedSignature, 'temporary prompt affects image keys immediately');
  assert.equal(JSON.stringify(settings.cameraSceneSettings), saved, 'temporary choice does not persist settings');
  assert.equal(camera.preview('scene-hug', '1girl', '').shotId, 'b');
  reload();
  assert.equal(camera.get('scene-hug').dirty, false, 'reload discards only the temporary choice');
  assert.equal(fingerprint('scene-hug'), savedSignature, 'reload restores the saved image key');
  assert.equal(camera.apply('scene-hug', { shots: [b], selected: ['b'], removeTags: '' }).ok, true);
  assert.equal(camera.set('scene-hug', camera.get('scene-hug')).ok, true);
  assert.equal(camera.get('scene-hug').dirty, false, 'explicit save clears the draft');
  reload();
  assert.equal(camera.get('scene-hug').selected[0], 'b', 'explicit save survives reload');
  assert.equal(camera.reset('scene-hug').ok, true);
  assert.equal(fingerprint('scene-hug'), '');
  assert.equal(camera.preview('scene-hug', '1girl', 'original negative').negativePrompt, 'original negative', 'disabled camera leaves negative unchanged');
  console.log('camera core: ok');
})().catch(error => { console.error(error); process.exitCode = 1; });
