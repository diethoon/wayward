const assert = require('node:assert/strict');
const fs = require('node:fs');

class Element {
  constructor(classes = []) { this.nodeType = 1; this.classes = classes; this.attrs = {}; this.children = []; this.style = {}; }
  setAttribute(key, value) { this.attrs[key] = value; }
  hasAttribute(key) { return Object.hasOwn(this.attrs, key); }
  addEventListener() {}
  matches(selector) {
    return selector.includes('data-aip-position-console-panel')
      ? this.hasAttribute('data-aip-position-console-panel') || this.hasAttribute('data-aip-position-console-body')
      : selector === 'div.flex-1.min-h-0.overflow-y-auto' && ['flex-1', 'min-h-0', 'overflow-y-auto'].every(x => this.classes.includes(x));
  }
  closest(selector) { return this.matches(selector) ? this : this.parentNode?.closest?.(selector) || null; }
  querySelector(selector) { return this.children.find(node => node.matches(selector) || node.querySelector(selector)) || null; }
  querySelectorAll() { return []; }
  insertBefore(node, before) {
    node.remove(); node.parentNode = this;
    const at = this.children.indexOf(before);
    this.children.splice(at < 0 ? this.children.length : at, 0, node);
  }
  append(...nodes) { for (const node of nodes) this.insertBefore(node, null); }
  appendChild(node) { this.insertBefore(node, null); return node; }
  remove() { if (!this.parentNode) return; const i = this.parentNode.children.indexOf(this); if (i >= 0) this.parentNode.children.splice(i, 1); this.parentNode = null; }
  replaceChildren(...nodes) { this.children = nodes; }
  get classList() { return { contains: value => this.classes.includes(value) }; }
  get firstChild() { return this.children[0] || null; }
  get nextSibling() { return this.parentNode?.children[this.parentNode.children.indexOf(this) + 1] || null; }
}

const root = new Element();
const pane = new Element(['flex-1', 'min-h-0', 'overflow-y-auto', 'p-2', 'xl:p-3']);
const native = new Element();
const grid = new Element(['grid', 'grid-cols-1', 'gap-2']);
native.append(grid); pane.append(native); root.append(pane);
let observer, subscriber, launcher, scans = 0, lists = 0, windowLists = 0, windowCreates = 0, windowCloses = 0;
const tasks = [];
const state = { enabled: false, sceneToken: 'sex', sceneLabel: '당신', reason: 'disabled' };
const controller = { getState: () => state, list() { lists++; return []; } };
const windowController = { getState: () => ({ ...state, enabled: true, reason: '' }), list() { windowLists++; return []; } };
const api = { store: { game: () => ({ activeScene: { sex: {} }, pendingEvent: { type: 'sex_scene', choices: [] } }),
  subscribe(fn) { subscriber = fn; } }, ui: { h: () => new Element(),
    addButton(options) { launcher = options.onClick; return { remove() {} }; },
    window(options) {
      windowCreates++;
      const body = new Element();
      const win = { refresh() { options.render(body, win); }, close() { windowCloses++; options.onClose(); } };
      options.render(body, win);
      return win;
    } } };
const document = { getElementById: () => root, body: root, activeElement: root,
  createElement: () => new Element(), querySelectorAll() { scans++; return [pane]; } };
const window = { requestAnimationFrame(fn) { tasks.push(fn); } };
class Observer { constructor(fn) { observer = fn; } observe() {} }
const source = fs.readFileSync(`${__dirname}/source/position-controller-ui.js`, 'utf8');
new Function('api', 'document', 'window', 'MutationObserver', 'positionControllerApi', 'positionControllerWindowApi',
  'positionControllerState', 'positionControllerList', source)
  (api, document, window, Observer, controller, windowController, () => controller.getState(),
    allowWindow => allowWindow ? windowController.list() : controller.list());
assert.equal(lists, 0, 'disabled console must not build the action list');
const initialScans = scans;
const unrelated = new Element(); root.append(unrelated);
for (let i = 0; i < 5000; i++) observer([{ target: unrelated, addedNodes: [new Element()], removedNodes: [] }]);
assert.equal(tasks.length, 0, 'unrelated UI changes must not schedule a console scan');
assert.equal(scans, initialScans, 'unrelated mutations do not scan the document');
for (let frame = 0; frame < 120; frame++) {
  observer([{ target: unrelated, addedNodes: [new Element()], removedNodes: [] }]);
  while (tasks.length) tasks.shift()();
}
assert.equal(scans, initialScans, 'unrelated changes across animation frames stay cheap');
subscriber(); subscriber();
assert.equal(tasks.length, 1, 'store notifications are coalesced');
tasks.shift()();
assert.equal(lists, 0, 'disabled console stays cheap after game changes');
state.enabled = true; state.reason = '';
subscriber(); tasks.shift()();
assert.equal(lists, 1, 'the enabled scan and render share one action list');
const header = pane.children.find(node => node.hasAttribute('data-aip-position-console-panel'));
const body = pane.children.find(node => node.hasAttribute('data-aip-position-console-body'));
assert.ok(header && body);
assert.deepEqual(pane.children, [native, header, body], 'the console follows the game action UI');
observer([{ target: pane, addedNodes: [header, body], removedNodes: [] }]);
assert.equal(tasks.length, 0, 'moving the console itself does not cause a scan loop');
observer([{ target: grid, addedNodes: [new Element()], removedNodes: [] }]);
assert.equal(tasks.length, 1, 'real action panel changes still trigger a scan');
tasks.shift()();
header.remove(); body.remove();
observer([{ target: pane, addedNodes: [], removedNodes: [header, body] }]);
assert.equal(tasks.length, 1, 'a game redraw removing the console triggers restoration');
tasks.shift()();
assert.ok(header.parentNode && body.parentNode, 'the console is restored after redraw');
state.enabled = false; state.reason = 'disabled';
subscriber(); tasks.shift()();
const inlineLists = lists;
assert.equal(body.hidden, true, 'the inline console can be disabled');
assert.ok(launcher, 'the separate window has its own launcher');
launcher();
assert.equal(windowCreates, 1);
assert.equal(windowLists, 1, 'the window uses its own controller');
assert.equal(lists, inlineLists, 'opening the separate window does not build the disabled inline list');
assert.equal(state.enabled, false, 'opening the window does not enable the inline console');
assert.equal(windowCloses, 0);
observer([{ target: grid, addedNodes: [new Element()], removedNodes: [] }]);
assert.equal(tasks.length, 1, 'game panel changes schedule an inline scan');
tasks.shift()();
assert.equal(windowLists, 1, 'a DOM-only scan does not redraw the unrelated floating window');
subscriber(); subscriber();
assert.equal(tasks.length, 1, 'floating and inline updates share the same queued scan');
tasks.shift()();
assert.equal(windowLists, 2, 'store changes refresh the floating window once');
observer([{ target: grid, addedNodes: [new Element()], removedNodes: [] }]);
subscriber();
assert.equal(tasks.length, 1, 'a later store update joins an already queued DOM scan');
tasks.shift()();
assert.equal(windowLists, 3, 'a store update is not lost when a DOM scan was queued first');
console.log('position console mutation performance: ok');
