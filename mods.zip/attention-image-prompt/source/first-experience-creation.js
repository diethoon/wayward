    const firstExperienceEditedPanels = new WeakSet();
    if (typeof document !== 'undefined') {
      const rememberFirstExperienceEdit = event => {
        const control = event.target?.closest?.('button,input,select,textarea');
        const panel = control?.closest?.('[data-virginity-creation]');
        if (panel) firstExperienceEditedPanels.add(panel);
      };
      for (const type of ['click', 'input', 'change']) document.addEventListener(type, rememberFirstExperienceEdit, true);
    }

    function firstExperienceCreationStatusLoaded() {
      try { return globalThis.WML?.status?.().loaded?.includes('virginity-status') === true; }
      catch { return false; }
    }

    function firstExperienceCreationChoice(options) {
      const setting = options?.generatedArchetype?.__attentionFirstExperience;
      if (!setting || !['random', 'none', 'player', 'other'].includes(setting.mode)) return null;
      const panel = typeof document !== 'undefined' ? document.querySelector('[data-virginity-creation]') : null;
      if (panel && firstExperienceEditedPanels.has(panel)) return null;
      const mode = setting.mode === 'random' ? ['none', 'player', 'other'][Math.floor(Math.random() * 3)] : setting.mode;
      return { mode, partnerName: mode === 'other' ? String(setting.partnerName || '').trim().slice(0, 64) || '이름 미상' : '' };
    }

    function firstExperienceCreationDraft(choice) {
      return { virgin: choice.mode === 'none', firstNightWithPlayer: choice.mode === 'player',
        formerBoyfriendExperience: choice.mode === 'other', formerBoyfriendName: choice.partnerName,
        experienceLevel: choice.mode === 'none' ? 0 : 20 };
    }

    if (typeof api.has !== 'function' || api.has('newGameState')) api.hook('newGameState', {
      before(args) {
        const [options] = args;
        if (!options?.picks || typeof options.picks !== 'object' || Array.isArray(options.picks)) return;
        const choice = firstExperienceCreationChoice(options);
        if (!choice) return;
        const updated = { ...options, __attentionFirstExperienceResolved: choice };
        if (firstExperienceCreationStatusLoaded()) updated.picks = {
          ...options.picks, __virginityStatus: firstExperienceCreationDraft(choice),
        };
        return [updated, ...args.slice(1)];
      },
      after(result, [options]) {
        const choice = options?.__attentionFirstExperienceResolved;
        if (!choice || firstExperienceCreationStatusLoaded()) return result;
        const id = result?.primaryCharacterId, character = result?.characters?.[id];
        if (!id || !character || character.intimateTally || character.intimateHistory?.length) return result;
        const player = choice.mode === 'player', virgin = choice.mode === 'none';
        const partnerName = player ? '당신' : choice.partnerName;
        const virginity = { schema: 1, virgin, firstNightWithPlayer: player,
          firstPartnerName: virgin ? null : partnerName, firstPartnerId: player ? 'player' : null,
          firstPartnerOrigin: virgin ? null : player ? 'player' : 'creation_ex', experienceLevel: virgin ? 0 : 20 };
        const history = virgin ? [] : [{ actId: 'sex', partner: partnerName,
          partnerType: player ? 'player' : 'patron', day: 0, slot: 0 }];
        return { ...result, characters: { ...result.characters, [id]: { ...character, virginity, intimateHistory: history } } };
      },
    });
