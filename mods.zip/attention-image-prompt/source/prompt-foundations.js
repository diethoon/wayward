    function cleanPrompt(value) {
      return typeof value === 'string' ? value.trim() : '';
    }

    function parseMap(value) {
      const result = {};
      for (const line of String(value || '').split(/\r?\n/)) {
        const separator = line.indexOf('=');
        if (separator < 1) continue;
        const key = line.slice(0, separator).trim();
        const prompt = line.slice(separator + 1).trim();
        if (key && prompt) result[key] = prompt;
      }
      return result;
    }

    function band(value) {
      const number = Math.max(0, Math.min(100, Number(value) || 0));
      if (number < 20) return 0;
      if (number < 40) return 1;
      if (number < 60) return 2;
      if (number < 80) return 3;
      return 4;
    }

    function externalFluidTier(count) {
      if (count >= 10) return 4;
      if (count >= 6) return 3;
      if (count >= 3) return 2;
      if (count >= 1) return 1;
      return 0;
    }

    function fluidTier(part, count) {
      if (part === 'uterus') return Math.max(0, Math.min(4, Math.floor(Number(count) || 0)));
      if (part === 'thighs') return count >= 6 ? 2 : count >= 1 ? 1 : 0;
      return externalFluidTier(count);
    }

    function vulvaTier(character, drives) {
      const arousal = Math.max(0, Math.min(100, Number(character?.stats?.arousal) || 0));
      const desire = Math.max(0, Math.min(100, Number(drives?.desire) || 0));
      return band(arousal * 0.7 + desire * 0.3);
    }

    function characterIdOf(state, character) {
      for (const [id, candidate] of Object.entries(state.characters || {})) {
        if (candidate === character) return id;
        if (character?.id && candidate?.id === character.id) return id;
        if (character?.shortname && candidate?.shortname === character.shortname) return id;
      }
      return null;
    }

    function currentAccessoryCharacter(state, character, characterId) {
      if (imagePlanDepth) return character;
      const current = state.characters?.[characterId];
      if (current && characterId === state.primaryCharacterId && toyPreviewType !== null) return { ...character, situationStats: {
        ...current.situationStats, jewelryState: {
          ...current.situationStats?.jewelryState,
          vibe: { ...current.situationStats?.jewelryState?.vibe, type: toyPreviewType, suspension: null },
        },
      } };
      if (!current || current === character
        || current.situationStats?.jewelryState === character.situationStats?.jewelryState
          && current.situationStats?.hypnosis === character.situationStats?.hypnosis
          && current.situationStats?.crest === character.situationStats?.crest) return character;
      return { ...character, situationStats: {
        ...character.situationStats, jewelryState: current.situationStats?.jewelryState,
        hypnosis: current.situationStats?.hypnosis, crest: current.situationStats?.crest,
      } };
    }

    function currentAccessoryArgs(args) {
      const state = api.store.game();
      const character = args[0];
      const characterId = state && character && characterIdOf(state, character);
      if (!characterId) return undefined;
      const current = currentAccessoryCharacter(state, character, characterId);
      return current === character ? undefined : [current, ...args.slice(1)];
    }

    function wakingSceneArgs(args) {
      const state = api.store.game();
      const character = args[0];
      const characterId = state && character && characterIdOf(state, character);
      const sleep = state?.activeScene?.sex?.__hs?.sleep;
      if (imagePlanDepth || !currentFeaturePrompts().sleep || characterId !== state?.primaryCharacterId
        || sleep?.stage !== 'tussle' || sleep.how !== 'big') return undefined;
      return [{ ...character, sceneOverride: 'rubbing' }, ...args.slice(1)];
    }

    function addPrompt(target, code, value, codeOnly = false) {
      const prompt = cleanPrompt(value);
      if (value === null || (!prompt && !codeOnly) || target.codes.includes(code)) return;
      target.codes.push(code);
      if (!codeOnly && prompt) target.tags.push(prompt);
    }

    function activePregnancyField(state, characterId) {
      if (!state || characterId !== state.primaryCharacterId) return null;
      const mode = globalThis.__wc2PregnancyBirth265;
      if (typeof mode?.getData !== 'function') return null;
      try {
        if (mode.getOptions?.().enabled === false) return null;
        const conceptionDay = mode.getData()?.pregnancy?.conceptionDay;
        if (!Number.isFinite(conceptionDay)) return null;
        const age = Math.max(0, (Number(state.day) || 1) - conceptionDay);
        return PREGNANCY_FIELDS[age <= 1 ? 0 : age === 2 ? 1 : 2];
      } catch { return null; }
    }

    function pregnancyPromptState(state, characterId, prompts, codeOnly = false) {
      const field = activePregnancyField(state, characterId);
      if (!field) return null;
      const result = { codes: [], tags: [] };
      addPrompt(result, field.key.replace('.', '-'), prompts[field.key], codeOnly);
      return (codeOnly ? result.codes : result.tags).length ? result : null;
    }

    function cyclePromptState(state, characterId, prompts, codeOnly, imageKey) {
      if (characterId !== state.primaryCharacterId) return null;
      const patron = state.activeScene?.patron;
      const sex = state.activeScene?.sex;
      const patronContact = patron && /(?:^|__)scene-patron_/.test(imageKey)
        && ['sex_patron', 'rubbing_patron', 'intimate'].includes(patron.stage);
      const spouseContact = sex && /(?:^|__)scene-(?!patron_)/.test(imageKey)
        && ['sex', 'sex_rough', 'anal', 'riding', 'standing_sex', 'fingering',
          'cunnilingus', 'face_sitting', 'sixty_nine', 'rubbing', 'grinding'].includes(sex.type);
      if (!patronContact && !spouseContact) return null;
      const mode = globalThis.__wc2PregnancyBirth265;
      if (!cyclePreviewPhase && typeof mode?.getCycleInfo !== 'function') return null;
      try {
        if (!cyclePreviewPhase && (mode.getOptions?.().enabled === false || mode.getData?.()?.pregnancy)) return null;
        const field = CYCLE_FIELDS.find(item => item.key === `cycle.vulva.${cyclePreviewPhase || mode.getCycleInfo(state.day)?.id}`);
        if (!field) return null;
        if (!cleanPrompt(prompts[field.key])) return null;
        const result = { codes: [], tags: [] };
        addPrompt(result, field.key.replaceAll('.', '-'), prompts[field.key], codeOnly);
        return (codeOnly ? result.codes : result.tags).length ? result : null;
      } catch { return null; }
    }

    let firstExperienceVirginityLoaded;
    function firstExperienceHasVirginityMod() {
      if (firstExperienceVirginityLoaded !== undefined) return firstExperienceVirginityLoaded;
      const status = globalThis.WML?.status?.();
      const loaded = status?.loaded?.includes('virginity-status') === true;
      if (status?.booted === true && Array.isArray(status.loaded)) firstExperienceVirginityLoaded = loaded;
      return loaded;
    }

    function firstExperienceScene(state, characterId, imageKey, preview = false) {
      const character = state?.characters?.[characterId];
      const scene = String(character?.sceneOverride || '');
      if (!state || characterId !== state.primaryCharacterId
        || !['sex', 'sex_rough', 'riding', 'doggy_style', 'spooning', 'standing_sex']
          .includes(scene.replace(/^patron_/, ''))
        || !/(?:^|__)scene-(?:(?:patron_)?(?:sex|sex_rough|riding|doggy_style|spooning|standing_sex)|patron_intimate)(?:__|$)/.test(imageKey)) return false;
      if (preview) return true;
      const status = state.mods?.['virginity-status'];
      const marker = status?.prompt;
      if (firstExperienceHasVirginityMod())
        return marker?.schema === 1 && marker.characterId === characterId
          && marker.scene === scene && marker.pending === true;
      if (status?.promptDone?.[characterId] || status?.characters?.[characterId]?.virgin === false
        || character?.virginity?.virgin === false || Number(character?.creationHistory?.counts?.sex) > 0) return false;
      const active = scene.startsWith('patron_') ? state.activeScene?.patron : state.activeScene?.sex;
      if (!active) return false;
      const records = [...(Array.isArray(character.intimateHistory) ? character.intimateHistory : [])
        .filter(record => ['sex', 'sex_vaginal', 'sex_rough', 'sex_public', 'riding', 'doggy_style', 'spooning', 'standing_sex', 'sex_patron']
          .includes(String(record?.actId || '').replace(/_patron$/, ''))), character?.diary?.firsts?.sex].filter(Boolean);
      if (!records.length) return true;
      const startedAt = Number(active.startedAtSlot);
      return Number.isFinite(startedAt) && records.every(record => Number(record.day) === Number(state.day)
        && Number(record.slot) >= startedAt);
    }

    function firstExperiencePromptState(state, characterId, prompts, codeOnly, imageKey) {
      if (!firstExperienceScene(state, characterId, imageKey, firstExperiencePreviewing)) return null;
      const field = FIRST_EXPERIENCE_FIELDS[0];
      const value = prompts[field.key];
      if (!cleanPrompt(value)) return null;
      const result = { codes: [], tags: [] };
      addPrompt(result, field.key.replace('.', '-'), value, codeOnly);
      return (codeOnly ? result.codes : result.tags).length ? result : null;
    }

    function sleepPromptField(state, characterId, imageKey) {
      if (characterId !== state.primaryCharacterId || !/(?:^|__)scene-(?!patron_)/.test(imageKey)) return null;
      const sleep = state.activeScene?.sex?.__hs?.sleep;
      if (sleep?.stage === 'tussle' && sleep.how === 'big')
        return SLEEP_FIELDS.find(field => field.key === 'sleep.waking-rub');
      if (sleep?.stage !== 'asleep') return null;
      const depth = Number(sleep.depth);
      const maximum = Number(sleep.max) || 100;
      const ratio = Number.isFinite(depth) ? depth / maximum : 1;
      const level = sleep.sand || ratio >= 0.67 ? 'deep' : ratio >= 0.34 ? 'middle' : 'light';
      return SLEEP_FIELDS.find(field => field.key === `sleep.${level}`);
    }

    function sleepPromptState(state, characterId, prompts, codeOnly, imageKey) {
      const field = sleepPromptField(state, characterId, imageKey);
      if (!field) return null;
      const result = { codes: [], tags: [] };
      addPrompt(result, field.key.replace('.', '-'), prompts[field.key], codeOnly);
      return (codeOnly ? result.codes : result.tags).length ? result : null;
    }

    function alignSleepScenePrompt(result, state, characterId) {
      if (imagePlanDepth || !state || !result || !Array.isArray(result.parts) || !currentFeaturePrompts().sleep) return result;
      const field = sleepPromptField(state, characterId, baseSituationImageKey(result.key));
      if (!field) return result;
      const wakingRub = field.key === 'sleep.waking-rub';
      const awakeGaze = /^(?:open eyes|eyes open|wide eyes|half[- ]?closed eyes|half[- ]?lidded eyes|eye contact|looking\b|averting eyes|downcast eyes)/i;
      const uprightPose = /^(?:(?:woman|girl) (?:standing|sitting|kneeling|on all fours|bent over)|(?:standing|sitting|kneeling) (?:woman|girl)|standing(?: sex)?|sitting|kneeling|on all fours|all fours|cowgirl(?: position)?|reverse cowgirl(?: position)?|girl on top|against wall|suspended congress|upright posture|seated)$/i;
      const staleAction = /^(?:fingering|anal fingering|handjob|blowjob|fellatio|deepthroat|irrumatio|cunnilingus|paizuri|titfuck|breast sex|thigh sex|(?:mutual )?oral sex|fingers? in (?:pussy|ass)|hand on (?:another's )?(?:pussy|crotch)|(?:one )?penis in (?:mouth|hand)|penis rubbing between her thighs|(?:man|woman|male|female) (?:receiving |giving |performing )?(?:fingering|handjob|fellatio|paizuri)|(?:man's|woman's) fingers|pussy focus|oral focus|hand focus|breast focus|solo focus|pov hands|grabbing from behind|head back|open mouth|closed eyes|relaxed|relaxed expression|peaceful expression|pov)\b/i;
      const align = value => promptTokens(value).filter(tag => {
        const name = promptTagIdentity(tag).spaced;
        return !(!wakingRub && awakeGaze.test(name)) && !uprightPose.test(name)
          && !(wakingRub && staleAction.test(name));
      }).join(', ');
      const prompt = align(result.prompt);
      const parts = result.parts.map(part => ({ ...part, tags: align(part.tags) }));
      const negativePrompt = wakingRub
        ? withoutPromptTags(result.negativePrompt, 'bottomless, no panties, bare legs, revealing clothing')
        : result.negativePrompt;
      if (prompt === result.prompt && negativePrompt === result.negativePrompt
        && parts.every((part, index) => part.tags === result.parts[index].tags)) return result;
      return { ...result, prompt, parts, negativePrompt,
        ...(prompt !== result.prompt ? { genParams: promptGenParams(prompt) } : {}) };
    }

    function visibleAttentionRows(state) {
      const proximity = settingsStore?.getState?.().proximityMode === true;
      // The Korean game can emit a "spent" row for a healthy wife with negative urgency.
      return attentionSituations(state, { proximity, limit: 4 })
        .filter(row => row.kind !== 'spent' || Number(row.urgency) > 0);
    }

    function restraintVisible(state) {
      const restraint = state.mods?.badguest?.restraint
        ?? state.mods?.['bad-guest']?.restraint
        ?? state.modData?.BadGuest?.restraint;
      return Boolean(restraint && (restraint.active
        || (restraint.afterUntilSlot != null && state.slot < restraint.afterUntilSlot)));
    }

    function attentionPromptState(state, characterId, prompts, promptField, codeOnly = false) {
      const result = { codes: [], tags: [] };
      for (const row of visibleAttentionRows(state)) {
        if (row.characterId !== characterId) continue;
        addPrompt(result, row.kind, prompts[`attention.${row.kind}`], codeOnly);
      }

      if (characterId === state.primaryCharacterId && restraintVisible(state)) {
        const hasHStatusChoker = Number(state.characters?.[characterId]?.situationStats?.jewelryState?.breasts?.stage) === 3;
        const prompt = !codeOnly && promptField === 'negativePrompt' && hasHStatusChoker
          ? withoutChokerTags(prompts['restraint.handcuffed'])
          : prompts['restraint.handcuffed'];
        addPrompt(result, 'handcuffed', prompt, codeOnly);
      }
      return (codeOnly ? result.codes : result.tags).length ? result : null;
    }

    function detailPromptState(state, character, characterId, prompts, drives, codeOnly = false) {
      if (characterId !== state.primaryCharacterId) return null;
      const result = { codes: [], tags: [] };
      const stats = effectiveHeroineStats(state);
      const relationship = relationshipPanelStatus(state);
      const wellbeing = 100 - (Number(wellbeingSignals(state)?.total) || 0);
      const intoxication = intoxicationBand(character?.intoxication?.level || 0);
      const feelings = topFeelings(character, 2);
      const distressed = stats.mood < 40 || wellbeing < 40 || Number(relationship.latitude?.raw) < 0 || feelings.some(feeling =>
        Number(feeling.intensity) >= 80 && /^(?:anger|contempt|disgust|sadness|shame|guilt|regret|humiliation|fear)$/.test(feeling.emotion));

      for (const [name, value] of [['energy', stats.energy], ['mood', stats.mood], ['arousal', stats.arousal], ['wellbeing', wellbeing]]) {
        const tier = band(value);
        addPrompt(result, `${name}-${tier}`, prompts[`status.${name}.${tier}`], codeOnly);
      }
      if (!distressed && Number(allureScore(character)) >= 60) addPrompt(result, 'allure-high', prompts['status.allure.high'], codeOnly);
      if (Number(relationship.trust) < 30) addPrompt(result, 'trust-low', prompts['status.trust.low'], codeOnly);
      if (!distressed && Number(relationship.desire) >= 60) addPrompt(result, 'desire-high', prompts['status.desire.high'], codeOnly);
      if (Number(relationship.resentment) >= 60) addPrompt(result, 'resentment-high', prompts['status.resentment.high'], codeOnly);
      else if (Number(relationship.resentment) >= 35) addPrompt(result, 'resentment-medium', prompts['status.resentment.medium'], codeOnly);
      if (Number(relationship.drift?.raw) >= 35) addPrompt(result, 'drift-high', prompts['status.drift.high'], codeOnly);
      if (Number(relationship.latitude?.raw) < 0) addPrompt(result, 'latitude-negative', prompts['status.latitude.negative'], codeOnly);
      if (intoxication !== 'sober') addPrompt(result, `intoxication-${intoxication}`, prompts[`status.intoxication.${intoxication}`], codeOnly);

      const feelingPrompts = parseMap(prompts['status.feelings.map']);
      for (const feeling of prompts['status.feelings.map'] === null ? [] : feelings) {
        if (distressed && /^(?:tenderness|longing|desire|arousal_buzz)$/.test(feeling.emotion)) continue;
        if (Number(feeling.intensity) > 15) addPrompt(result, `feeling-${feeling.emotion}`, feelingPrompts[feeling.emotion], codeOnly);
      }
      const drivePrompts = parseMap(prompts['status.drives.map']);
      const strongestDrive = Object.entries(drives || {}).sort((left, right) => Number(right[1]) - Number(left[1]))[0];
      if (prompts['status.drives.map'] !== null && strongestDrive && Number(strongestDrive[1]) > 35
        && (!distressed || !/^(?:desire|longing|approval|pride)$/.test(strongestDrive[0]))) {
        addPrompt(result, `drive-${strongestDrive[0]}`, drivePrompts[strongestDrive[0]], codeOnly);
      }
      return (codeOnly ? result.codes : result.tags).length ? result : null;
    }

    function fluidPromptStates(character, prompts, drives, codeOnly = false) {
      const hStatus = character?.situationStats;
      const hasFluid = hStatus && typeof hStatus.fluidState === 'object';
      const hasJewelry = hStatus && typeof hStatus.jewelryState === 'object';
      const vibe = hasJewelry ? hStatus.jewelryState?.vibe : null;
      const toyType = !vibe?.suspension && ['egg', 'penis'].includes(vibe?.type) ? vibe.type : '';
      if (!hasFluid && !hasJewelry && !toyType) return [];
      const groups = [];
      for (const { part, label } of FLUID_PARTS) {
        const result = { codes: [], tags: [] };
        if (hasFluid) {
          const tier = part === 'vulva'
            ? vulvaTier(character, drives)
            : fluidTier(part, hStatus.fluidState?.[part]);
          if (!codeOnly || tier > 0) addPrompt(result, `${part}-${tier}`, prompts[`fluid.${part}.${tier}`], codeOnly);
        }
        if (hasJewelry && part === 'breasts') {
          const stage = Math.max(0, Math.min(3, Math.floor(Number(hStatus.jewelryState?.breasts?.stage) || 0)));
          if (!codeOnly || stage > 0) addPrompt(result, `jewelry-breasts-${stage}`, prompts[`jewelry.breasts.${stage}`], codeOnly);
        }
        if (hasJewelry && part === 'vulva') {
          const stage = Math.max(0, Math.min(1, Math.floor(Number(hStatus.jewelryState?.vulva?.stage) || 0)));
          if (!codeOnly || stage > 0) addPrompt(result, `jewelry-vulva-${stage}`, prompts[`jewelry.vulva.${stage}`], codeOnly);
        }
        if ((codeOnly ? result.codes : result.tags).length) groups.push({ id: `body-${part}`, label: api.t({ ko: `부위별 상태 · ${label}`, en: `Body status · ${part}` }), value: result });
      }
      if (toyType) {
        const result = { codes: [], tags: [] };
        addPrompt(result, `toy-vibe-${toyType}`, prompts[`toy.vulva.${toyType}`], codeOnly);
        if ((codeOnly ? result.codes : result.tags).length) groups.push({ id: 'body-toy', label: api.t({ ko: 'H Status · 토이', en: 'H Status · toy' }), value: result });
      }
      return groups;
    }

    function hStatusFantasyPromptState(character, kind, prompts, codeOnly = false) {
      const value = hStatusFantasyPreview?.kind === kind
        ? hStatusFantasyPreview.stage * 20 : character?.situationStats?.[kind];
      if (value === undefined || value === null) return null;
      const stage = Math.min(5, Math.ceil(Math.max(0, Math.min(100, Number(value) || 0)) / 20));
      const prompt = cleanPrompt(prompts[`hstatus.${kind}.${stage}`]);
      if (!prompt) return null;
      const result = { codes: [], tags: [] };
      addPrompt(result, `hstatus-${kind}-${stage}-${shortHash(prompt)}`, prompt, codeOnly);
      return result;
    }

    function currentErostatFits(state, characterId, imageKey) {
      if (!state || characterId !== state.primaryCharacterId) return [];
      const scene = imageKey ? basePositionSituationId(positionSituationId(imageKey))
        : state.activeScene?.patron ? 'scene-patron_sex' : state.activeScene?.sex ? 'scene-sex' : '';
      if (!scene.startsWith('scene-')) return [];
      const partnerType = scene.startsWith('scene-patron_') ? 'patron' : 'player';
      const erostat = globalThis.__waywardErostatPlus;
      if (!globalThis.__waywardSituationEventMod || typeof erostat?.insertions !== 'function'
        || typeof erostat.fit !== 'function') return [];
      const selected = {};
      try {
        const active = erostat.insertions();
        for (const insertion of Array.isArray(active) ? active : []) {
          if (insertion?.who?.type !== partnerType) continue;
          const fit = erostat.fit(insertion.who, insertion.hole, characterId);
          if (EROSTAT_FIT_BANDS.indexOf(fit?.band) > EROSTAT_FIT_BANDS.indexOf(selected[insertion.hole]?.band))
            selected[insertion.hole] = { ...fit, hole: insertion.hole };
        }
      } catch { return []; }
      return Object.values(selected);
    }

    function currentErostatFit(state, characterId, imageKey, hole) {
      const fits = currentErostatFits(state, characterId, imageKey);
      return hole ? fits.find(fit => fit.hole === hole) || null
        : fits.sort((left, right) => EROSTAT_FIT_BANDS.indexOf(right.band) - EROSTAT_FIT_BANDS.indexOf(left.band))[0] || null;
    }

    function erostatFitPromptState(state, characterId, imageKey, prompts, codeOnly = false) {
      const result = { codes: [], tags: [] };
      for (const fit of currentErostatFits(state, characterId, imageKey)) {
        const key = fit.hole === 'anal' ? `erostat.anal.${fit.band}` : `erostat.fit.${fit.band}`;
        const prompt = prompts[key];
        if (fit.hole === 'oral' && prompt === DEFAULT_PROMPTS[key]) continue;
        if (!cleanPrompt(prompt)) continue;
        addPrompt(result, `erostat-${fit.hole}-${fit.band}-${shortHash(prompt)}`, prompt, codeOnly);
      }
      return (codeOnly ? result.codes : result.tags).length ? result : null;
    }

    function dialogueText(value) {
      return String(value || '').replace(/\s+/g, ' ').trim().toLocaleLowerCase();
    }

    function dialogueLogs(state) {
      const logs = Array.isArray(state.log) ? state.log.slice(-200) : [];
      return settingsStore?.getState?.().proximityMode === true
        ? logs.filter(entry => entry?.coLocated !== false)
        : logs;
    }

    function patronActionPromptState(state, characterId, imageKey, promptField, codeOnly = false) {
      const patron = state.activeScene?.patron;
      if (characterId !== state.primaryCharacterId || !patron || patron.afterglow
        || !basePositionSituationId(positionSituationId(imageKey)).startsWith('scene-patron_')) return null;
      const now = Number(state.slot);
      const recent = minute => Number.isFinite(minute) && now - minute >= 0 && now - minute <= 1;
      const actions = new Set();
      try {
        const strike = globalThis.__waywardActExpansion?.strike?.state?.();
        if (strike?.customerId === patron.customerId) {
          for (const hit of strike.log || []) if (recent(hit.minute)) actions.add(hit.part);
          if (recent(strike.lastScream?.minute)) actions.add(strike.lastScream.trigger);
        }
      } catch {}
      const patronName = String(patron.customerName || state.customers?.find(customer =>
        customer.id === patron.customerId)?.name || '').trim();
      const wifeName = String(state.characters?.[characterId]?.name || '').trim();
      for (const entry of dialogueLogs(state).slice(-30)) {
        if (!recent(entry?.slot) || entry.epilogue || !entry.extraLine
          || Number.isFinite(patron.startedAtSlot) && entry.slot < patron.startedAtSlot - 1
          || entry.imageKey && sceneFamilyKey(entry.imageKey) !== sceneFamilyKey(imageKey)
          || entry.patronId && entry.patronId !== patron.customerId) continue;
        const group = String(entry.groupKey || '');
        if (!group.startsWith(`interaction:${patron.customerId}:`) && !group.startsWith('extra:')) continue;
        const narration = String(entry.text || '').replace(/『[^』]*』|"[^"]*"/g, '');
        for (const clause of narration.split(/[.!?。！？\n]/)) {
          const described = wifeName ? clause.replaceAll(`${wifeName}의 `, '그녀의 ')
            .replaceAll(`${wifeName} `, '그녀 ') : clause;
          if (!/(?:그의|남자의|손님의)\s*(?:머리채|머리칼)/.test(clause)
            && !(patronName && ['머리채', '머리칼'].some(part => clause.includes(`${patronName}의 ${part}`)))
            && /(?:머리채|머리칼)(?:를|을)?[^.!?]{0,24}(?:잡|쥐|움켜|당기|끌어|휘감|붙잡|감아)/.test(clause)) actions.add('hair');
          if (/(?:그녀|아내)(?:의)?\s*목을\s*(?:조|졸|움켜|틀어)/.test(described)) actions.add('choke');
          if (/(?:그녀|아내)(?:의)?\s*(?:두\s*)?손목을\s*[^.!?]{0,16}(?:잡|쥐|붙잡|묶|누르|짓누르)/.test(described)) actions.add('wrist');
        }
      }
      if (!actions.size) return null;
      const labels = { slap: '뺨', breast: '가슴', butt: '엉덩이', sex: '음부', belly: '배', hair: '머리채', choke: '목' };
      const available = availablePositionModules();
      const result = { codes: [], tags: [] };
      for (const action of actions) {
        const group = action === 'wrist' ? '오른손' : '폭력성';
        const label = action === 'wrist' ? '손목' : labels[action];
        if (!label) continue;
        const module = available.find(item => item.controllerScope === 'patron'
          && item.controllerGroup === group && item.controllerLabel === label);
        const tags = module?.[promptField] || (!module && promptField === 'positivePrompt'
          ? controllerButtonDefaultTags({ group, label }) : '');
        if (tags) addPrompt(result, `action.${action}`, tags, codeOnly);
      }
      return (codeOnly ? result.codes : result.tags).length ? result : null;
    }

    function outfitIdFor(character, imageKey) {
      const keyOutfit = typeof imageKey === 'string'
        ? imageKey.match(/(?:^|__)outfit-(.+?)(?=__|$)/)?.[1]
        : '';
      return String(keyOutfit || character?.outfit || '').trim().toLocaleLowerCase();
    }

    const NUDE_OUTFITS = new Set(['nude', 'naked', 'slave_collar', 'ribbon_only', 'sx_naked', 'sx_chains']);
    const SKIRTLESS_OUTFITS = new Set(['his_shirt', 'lingerie', 'panties_only']);
    const PARTIAL_OUTFITS = new Set([
      'bath_linen_wrap', 'bath_shift', 'bath_towel', 'bath_bindings', 'bath_sheer_chemise',
      'linen_shift', 'barmaid_corset', 'wench_bodice', 'his_shirt', 'crop_blouse_skirt',
      'breast_band_skirt', 'strapless_thigh_boots', 'silk_robe', 'lingerie', 'pink_babydoll',
      'auburn_babydoll', 'satin_babydoll', 'sheer_chemise', 'sheer_nightgown', 'panties_only',
      'naked_apron',
    ]);

    function outfitStateOf(outfitId) {
      if (NUDE_OUTFITS.has(outfitId) || outfitId.endsWith('+nude')) return 'nude';
      return PARTIAL_OUTFITS.has(outfitId) ? 'partial' : 'clothed';
    }

    function exposureFlags(imageKey, character) {
      const bits = String(imageKey || '').match(/(?:^|__)exp-([01]{7})(?=__|$)/)?.[1] || '';
      const exposure = character?.exposure || {};
      return {
        topPulledDown: bits[1] === '1' || exposure.topPulledDown === true,
        topRemoved: bits[2] === '1' || exposure.topRemoved === true,
        skirtUp: bits[3] === '1' || exposure.skirtUp === true,
        skirtRemoved: bits[4] === '1' || exposure.skirtRemoved === true,
        pantiesAside: bits[5] === '1' || exposure.pantiesAside === true,
        pantiesRemoved: bits[6] === '1' || exposure.pantiesRemoved === true,
      };
    }

    function promptPart(key) {
      if (String(key || '').startsWith('cycle.vulva.')) return 'vulva';
      return String(key || '').match(/^(?:fluid|jewelry|toy)\.([^.]+)/)?.[1] || '';
    }

    function partIsExposed(key, outfitId, imageKey, character) {
      const part = promptPart(key);
      if (!part) return false;
      if (part === 'mouth') return true;
      if (outfitStateOf(outfitId) === 'nude') return true;
      const exposed = exposureFlags(imageKey, character);
      if (part === 'breasts') return exposed.topPulledDown || exposed.topRemoved || outfitId === 'panties_only';
      if (part === 'thighs') return exposed.skirtUp || exposed.skirtRemoved
        || ['crop_blouse_skirt', 'breast_band_skirt', 'strapless_thigh_boots', 'lingerie', 'pink_babydoll', 'auburn_babydoll', 'satin_babydoll', 'panties_only'].includes(outfitId);
      if (part === 'uterus') return exposed.skirtUp || exposed.skirtRemoved
        || SKIRTLESS_OUTFITS.has(outfitId);
      return exposed.pantiesAside || exposed.pantiesRemoved;
    }

    function outfitAllows(states, outfitId, key = '', imageKey = '', character = null) {
      states = normalizeOutfitStates(states);
      if (ALL_OUTFIT_STATES.every(state => states.includes(state))) return true;
      return (!!outfitId && states.includes(outfitStateOf(outfitId)))
        || (states.includes(EXPOSED_OUTFIT_STATE[0]) && partIsExposed(key, outfitId, imageKey, character));
    }

    function promptsForOutfit(prompts, outfitStates, outfitId, imageKey, character) {
      return Object.fromEntries(Object.entries(prompts).map(([key, value]) => [
        key,
        outfitAllows(outfitStates[key], outfitId, key, imageKey, character) ? value : '',
      ]));
    }

    function sceneFamilyKey(imageKey) {
      if (typeof imageKey !== 'string') return '';
      return imageKey.split('__').filter((part, index) => index === 0
        || /^(?:scene|task|room|grp|gslot|focus)-/.test(part)).join('__');
    }

    function logImageKeyAt(logs, index) {
      for (let cursor = index; cursor >= 0; cursor -= 1) {
        if (typeof logs[cursor]?.imageKey === 'string') return logs[cursor].imageKey;
      }
      return '';
    }

    function dialoguePromptState(state, rules, imageKey, promptField, outfitId, codeOnly = false) {
      const logs = dialogueLogs(state);
      const currentScene = sceneFamilyKey(imageKey);
      const result = { codes: [], tags: [] };
      for (const rule of rules) {
        if (!outfitAllows(rule.outfitStates, outfitId)) continue;
        const wanted = dialogueText(rule.text);
        if (!wanted) continue;
        let matchIndex = -1;
        for (let index = logs.length - 1; index >= 0; index -= 1) {
          if (dialogueText(logs[index]?.text).includes(wanted)) {
            matchIndex = index;
            break;
          }
        }
        if (matchIndex < 0) continue;
        const entry = logs[matchIndex];
        const active = rule.duration === 'minutes'
          ? Number(state.slot) - Number(entry.slot) >= 0 && Number(state.slot) - Number(entry.slot) < rule.minutes
          : sceneFamilyKey(logImageKeyAt(logs, matchIndex)) === currentScene
            || (!logImageKeyAt(logs, matchIndex) && Number(entry.slot) === Number(state.slot));
        if (active) addPrompt(result, `dialogue-${rule.id}`, rule[promptField], codeOnly);
      }
      return (codeOnly ? result.codes : result.tags).length ? result : null;
    }

    function shortHash(value) {
      let hash = 2166136261;
      for (let index = 0; index < value.length; index += 1) {
        hash ^= value.charCodeAt(index);
        hash = Math.imul(hash, 16777619);
      }
      return (hash >>> 0).toString(36);
    }

    function compactGenerationOwner(owner) {
      return owner.length <= 50 ? owner : `${owner.slice(0, 40)}-${shortHash(owner)}`;
    }

    function compactGenerationKey(imageKey, includeLateTags = false) {
      const previouslyCompacted = imageKey.includes('__aipk-');
      if (!/__(?:scene|task|look)-/.test(imageKey)
        || (previouslyCompacted && (!includeLateTags
          || new TextEncoder().encode(`${imageKey}_portrait_00001_.png`).length <= 200))
        || (!previouslyCompacted && imageKey.length <= 120
          && (!includeLateTags || new TextEncoder().encode(`${imageKey}_portrait_00001_.png`).length <= 200))) return imageKey;
      const parts = imageKey.split('__');
      const owner = compactGenerationOwner(parts[0]);
      const situation = parts.find(part => /^(?:scene|task|look)-/.test(part)).slice(0, 42);
      const variant = (imageKey.match(/__v-\d+/)?.[0] || '').slice(0, 20);
      const hash = `${shortHash(imageKey)}${shortHash([...imageKey].reverse().join(''))}`;
      const compact = `${owner}__${situation}__aipk-${hash}${variant}`;
      return includeLateTags && new TextEncoder().encode(`${compact}_portrait_00001_.png`).length > 200
        ? `aip-${shortHash(parts[0])}__scene-${shortHash(situation)}__aipk-${hash}${variant}` : compact;
    }

    function compactSituationKey(fullKey) {
      if (fullKey.length <= 220) return fullKey;
      const parts = fullKey.split('__');
      const index = parts.findIndex(part => part.startsWith('aip-'));
      const accessories = index < 0 ? [] : parts[index].slice(4).split('_').filter(part => /^(?:jewel|toy|att-external)-/.test(part));
      const external = accessories.find(part => part.startsWith('att-external-')) || '';
      const accessoryCode = accessories.join('_');
      const hash = `${shortHash(fullKey)}${shortHash([...fullKey].reverse().join(''))}`;
      if (index >= 0) {
        parts[index] = `aipk-${hash}`;
        if (accessoryCode) parts.splice(index, 0, `aip-${accessoryCode}`);
      }
      let compact = parts.join('__');
      if (compact.length > 220) {
        const fields = fullKey.split('__').slice(1).filter(part =>
          /^(?:scene|task|look|outfit|room|mood|exp|grp|gslot|abed|fin|bd|position)-/.test(part));
        const variant = (fullKey.match(/__v-\d+/)?.[0] || '').slice(0, 20);
        const accessory = accessorySituationCode(fullKey);
        const shortFields = () => `${compactGenerationOwner(fullKey.split('__')[0])}__${fields.join('__')}${external ? `__aip-${external}` : ''}__aipk-${hash}${accessory ? `__acc-${shortHash(accessory)}` : ''}${variant}`;
        while (shortFields().length > 220 && fields.length > 3) fields.pop();
        compact = shortFields().length <= 220 ? shortFields() : compactGenerationKey(fullKey);
        if (external && !compact.includes(`aip-${external}`)) compact = compact.replace('__aipk-', `__aip-${external}__aipk-`);
      }
      if (compact !== fullKey) compactSituationAliases.set(compact, fullKey);
      if (compactSituationAliases.size > 200) compactSituationAliases.delete(compactSituationAliases.keys().next().value);
      return compact;
    }

    function statusContentKey(item) {
      const imageKey = item?.imageKey || item?.talentId;
      const variant = typeof imageKey === 'string' ? imageKey.match(/__v-(\d+)(?:__toy-[a-z0-9-]+(?:_[a-z0-9-]+)*)?$/) : null;
      if (!variant || Number(variant[1]) >= USER_VARIANT_START || !item.prompt
        || !/__(?:state|dialogue|position)-/.test(imageKey)
        || imageKey.startsWith('situation_') || /__(?:aip|character-(?:reuse|regenerate)|content)-/.test(imageKey)
        || (imageKey.includes('__position-') && !autoPositionPresets())) return null;
      const parts = imageKey.split('__');
      if (!parts.some(part => /^(?:mood|state)-/.test(part))) return null;
      const base = parts.filter(part => !/^(?:mood|state)-/.test(part)).join('__');
      const signature = JSON.stringify([
        item.prompt, item.negativePrompt || '', item.workflow || 'illustrious', item.imageType || 'portrait',
        item.width ?? null, item.height ?? null, item.steps ?? null, item.cfg ?? null,
        item.loraStrength ?? null, item.checkpoint ?? null, item.denoise ?? null, item.referenceHash ?? null,
      ]);
      let forward = 2166136261;
      let backward = 0x9e3779b9;
      for (let index = 0; index < signature.length; index += 1) {
        forward = Math.imul(forward ^ signature.charCodeAt(index), 16777619);
        backward = Math.imul(backward ^ signature.charCodeAt(signature.length - index - 1), 16777619);
      }
      const hash = `${(forward >>> 0).toString(16).padStart(8, '0')}${(backward >>> 0).toString(16).padStart(8, '0')}`;
      return { key: base.replace(/__v-\d+(?:__toy-[a-z0-9-]+(?:_[a-z0-9-]+)*)?$/, `__content-${hash}$&`), signature };
    }
