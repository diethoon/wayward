    function syncNativeStudioCharacters() {
      if (api.game !== '2026-11-01') return;
      const bridge = globalThis.WW_ImageStudioBridge;
      const presets = api.engine?.kr;
      const order = api.engine?.Gi;
      if (!bridge || !Array.isArray(presets) || !Array.isArray(order) || bridge.__attentionNativeWives) return;

      const separateAdapter = () => globalThis.WML?.status?.().loaded?.includes('imagestudio-native-packs');
      function studioScope(original, receiver, args, copyWives = false) {
        if (separateAdapter()) return original.apply(receiver, args);
        const sources = preGenerateWifeSources();
        if (!sources.length) return original.apply(receiver, args);
        const oldPresets = presets.slice();
        const oldOrder = order.slice();
        const native = sources.flatMap(source => {
          const id = String(source.id || '').trim();
          const shortname = String(source.archetype?.shortname || id).trim();
          if (!id || !/^[a-z0-9][a-z0-9_-]{0,99}$/.test(shortname)) return [];
          const collision = oldPresets.some(item => item?.shortname === shortname
            && item.id !== id && item.id !== `attentionwife_${shortname}`);
          return collision ? [] : [{ ...source.archetype, id, shortname }];
        });
        if (!native.length) return original.apply(receiver, args);
        const ids = new Set(native.map(item => item.id));
        const names = new Set(native.map(item => item.shortname));
        try {
          presets.splice(0, presets.length, ...oldPresets.filter(item => !ids.has(item?.id)
            && !(names.has(item?.shortname) && item?.id === `attentionwife_${item.shortname}`)), ...native);
          order.splice(0, order.length, ...new Set([...oldOrder, ...names]));
          const result = original.apply(receiver, args);
          return copyWives && Array.isArray(result) ? result.slice() : result;
        } finally {
          presets.splice(0, presets.length, ...oldPresets);
          order.splice(0, order.length, ...oldOrder);
        }
      }
      for (const name of ['characters', 'wives', 'axes', 'collectPromptDefaults', 'fromKey',
        'list', 'randomSpace', 'selectionConflicts', 'optionLimits']) {
        const original = bridge[name];
        if (typeof original !== 'function') continue;
        bridge[name] = function (...args) { return studioScope(original, this, args, name === 'wives'); };
      }
      if (typeof bridge.currentWife === 'function') {
        const original = bridge.currentWife;
        bridge.currentWife = function (...args) {
          if (separateAdapter()) return original.apply(this, args);
          const state = api.store.game();
          const character = state?.characters?.[state.primaryCharacterId];
          const generated = character?.generatedArchetype;
          const source = preGenerateWifeSource(generated?.attentionCustomWifeId || generated?.shortname || character?.archetypeId);
          return source?.archetype?.shortname || original.apply(this, args);
        };
      }
      Object.defineProperty(bridge, '__attentionNativeWives', { value: true });
    }

    syncNativeStudioCharacters();
