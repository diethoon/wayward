    // Search is explicit and read-only; a configured candidate need not be active in the game.
    function searchPromptTag(input) {
      const query = typeof input === 'string' ? input.trim().slice(0, 200) : '';
      const matches = [], warnings = [];
      if (!query) return { query, matches, warnings };
      const warning = text => { if (!warnings.includes(text)) warnings.push(text); };
      const normalize = text => globalPromptExclusionIdentity(text).replace(/^(?:tag|literal):/, '')
        .replaceAll('_', ' ').replace(/\s+/g, ' ').trim();
      const needle = normalize(query);
      const customTags = currentCustomTags();
      let limited = false, malformed = false;
      const add = (scope, source, location, polarity, field, value) => {
        if (limited || typeof value !== 'string' || !value.trim()) return;
        const parsed = splitFinalPrompt(value);
        if (!parsed) { malformed = true; return; }
        const found = parsed.tokens.map(token => token.trim()).filter(token => {
          if (!token) return false;
          const normalized = normalize(token);
          const korean = normalize(translatedPromptTag(token, customTags));
          return normalized.includes(needle) || korean.includes(needle);
        });
        if (!found.length) return;
        if (matches.length >= 500) { limited = true; return; }
        matches.push({ scope, source, location: String(location || ''), polarity,
          field: String(field || ''), prompt: value, matchedTags: [...new Set(found)] });
      };
      const collect = (name, fn) => {
        try { fn(); } catch { warning(`${name}을(를) 확인하지 못했어요.`); }
      };
      const pair = (source, location, field, value) => {
        if (!value || typeof value !== 'object') return;
        add('candidate', source, location, 'positive', field, value.positivePrompt);
        add('candidate', source, location, 'negative', field, value.negativePrompt);
      };
      collect('현재 초상화', () => {
        const state = api.store.game(), scene = latestScenePrompt, result = scene?.result;
        if (!result?.key || !state?.primaryCharacterId || scene.characterId !== state.primaryCharacterId
          || activePortraitImageKey('', state) !== result.key) return;
        const label = positionSituationLabel(scene.situationId) || scene.situationId;
        add('current', '현재 초상화의 마지막 계산', label, 'positive', '계산 Positive', result.prompt);
        add('current', '현재 초상화의 마지막 계산', label, 'negative', '최종 Negative', result.negativePrompt);
      });
      collect('게임 공통 설정', () => {
        const saved = currentGameDefaultPrompts();
        pair('게임 공통 설정', '모든 장면', '게임 공통', {
          positivePrompt: saved.positivePrompt ?? GAME_PROMPT_QUALITY,
          negativePrompt: saved.negativePrompt ?? GAME_PROMPT_NEGATIVE,
        });
      });
      const labels = new Map(FIELD_GROUPS.flatMap(group => group.fields.map(field =>
        [field.key, `${group.title} · ${field.label}`])));
      collect('상태 프롬프트', () => {
        const presets = [{ name: '기본 프리셋', prompts: currentPrompts(), negativePrompts: currentNegativePrompts(),
          dialogueRules: currentDialogueRules() },
          ...currentSituationPresets()];
        for (const preset of presets) {
          for (const [section, polarity] of [['prompts', 'positive'], ['negativePrompts', 'negative']])
            for (const [id, text] of Object.entries(preset[section] || {}))
              add('candidate', 'AIP 상태 설정', `${preset.name} · ${labels.get(id) || id}`, polarity, id, text);
          for (const rule of preset.dialogueRules || []) pair('대화 감지 설정', `${preset.name} · ${rule.name || rule.label || rule.id}`, rule.id, rule);
        }
      });
      collect('장면 프롬프트', () => {
        for (const scene of scenePromptCatalog('')) {
          const id = scene.id, label = `${scene.label} (${id})`;
          for (const candidate of nativeScenePromptCandidates(id))
            add('candidate', '게임 기본 장면 후보', label, 'positive', candidate.label, candidate.text);
        }
        for (const [id, value] of Object.entries(currentPositionStatePrompts()))
          pair('AIP 장면 추가 문구', `${positionSituationLabel(id)} (${id})`, id, value);
        for (const [id, value] of Object.entries(sceneBaseOverrides))
          add('candidate', '장면 기본 문구 수정', `${positionSituationLabel(id)} (${id})`, 'positive', id, value.positivePrompt);
        for (const [id, fields] of Object.entries(sceneStatePromptOverrides))
          for (const [key, value] of Object.entries(fields)) pair('장면별 상태 설정',
            `${positionSituationLabel(id)} · ${labels.get(key) || key}`, key, value);
        for (const [id, pool] of Object.entries(currentSceneCandidatePools())) {
          for (const entry of [...(pool.edits || []), ...(pool.additions || [])])
            add('candidate', '장면 프롬프트 후보', `${positionSituationLabel(id)} (${id})`, 'positive', entry.name || entry.id || entry.source, entry.prompt);
        }
      });
      collect('선택지 프롬프트', () => {
        for (const rule of buttonPromptRules) {
          if (rule.mode !== 'after') continue;
          const name = rule.label || rule.choiceId;
          pair('선택 후 공통 설정', `${name} · ${rule.scene}`, rule.choiceId, rule);
          for (const outcome of rule.outcomes || []) {
            const location = `${name} · ${positionSituationLabel(outcome.situationId)}${outcome.response ? ` · ${outcome.response}` : ''}`;
            pair('선택지 반응 설정', location, outcome.situationId, outcome);
            for (const candidate of outcome.candidates || []) pair('선택지 반응 후보', location, candidate.name || candidate.id, candidate);
          }
        }
      });
      collect('의상 프롬프트', () => {
        const saved = currentOutfitPrompts();
        for (const source of outfitPromptSources()) {
          const entry = outfitPromptValues(source, saved);
          pair('의상 설정', source.name, source.id, entry);
          add('candidate', '의상 상의', source.name, 'positive', source.id, entry.topPrompt);
          add('candidate', '의상 하의', source.name, 'positive', source.id, entry.skirtPrompt);
        }
        for (const entry of currentCustomOutfits()) {
          pair('추가 의상', entry.name || entry.id, entry.id, entry);
          add('candidate', '추가 의상 상의', entry.name || entry.id, 'positive', entry.id, entry.topPrompt);
          add('candidate', '추가 의상 하의', entry.name || entry.id, 'positive', entry.id, entry.skirtPrompt);
        }
      });
      collect('체위 프롬프트', () => {
        for (const entry of availablePositionModules()) pair('체위 모듈', entry.name || entry.id, entry.id, entry);
        for (const id of Object.keys(POSITION_PRESETS))
          add('candidate', '체위 프리셋', POSITION_PRESETS[id].name || id, 'positive', id, positionPresetById(id)?.prompt);
        for (const id of Object.keys(GROUP_SLOT_BY_ID))
          add('candidate', '체위 그룹', GROUP_SLOT_BY_ID[id].name || id, 'positive', id, positionGroupPromptById(id));
      });
      collect('카메라 구도', () => {
        for (const [id, config] of Object.entries({ ...cameraSceneSettings, ...cameraDrafts }))
          for (const shot of config.shots || []) {
            const location = `${positionSituationLabel(id)} · ${shot.name || shot.id}`;
            add('candidate', '장면별 카메라 구도', location, 'positive', shot.id, shot.positive);
            add('candidate', '장면별 카메라 구도', location, 'negative', shot.id, shot.negative);
          }
      });
      collect('다른 모드의 등록 문구', () => {
        for (const menu of externalPromptMenus()) for (const entry of menu.entries)
          pair(`다른 모드 · ${menu.title}`, entry.label, `${menu.id}/${entry.id}`, entry);
      });
      collect('캐릭터와 흔적 설정', () => {
        pair('현재 캐릭터 설정', currentWifePromptContext().name || '현재 아내', '캐릭터', currentWifeCharacterPrompt());
        for (const [id, value] of Object.entries(currentResiduePrompts())) pair('흔적 이미지 설정', id, id, value);
      });
      warning('게임 기본 후보와 저장된 설정은 조건에 따라 적용돼요. 전역 제거 등 다른 설정으로 최종 결과에서 빠질 수도 있어요.');
      warning('다른 모드의 독립 프롬프트나 서버에서 추가하는 태그는 확인할 수 없어요. 현재 값은 마지막 계산 기록이며 이후 변경될 수 있어요.');
      if (malformed) warning('구분할 수 없는 프롬프트가 있어 일부 결과를 제외했어요.');
      if (limited) warning('결과가 많아 앞의 500개만 표시해요. 검색어를 더 구체적으로 입력해 주세요.');
      return { query, matches, warnings };
    }
