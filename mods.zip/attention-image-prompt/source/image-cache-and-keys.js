    async function legacyCacheEntries() {
      if (!api.loadScript) return {};
      if (!legacyCachePromise) legacyCachePromise = api.loadScript('legacy-cache.js').then(() => {
        const data = globalThis.__attentionImageLegacyCache;
        delete globalThis.__attentionImageLegacyCache;
        return data?.version === 1 && data.entries && typeof data.entries === 'object' ? data.entries : {};
      }).catch(() => ({}));
      return legacyCachePromise;
    }

    async function legacyStatusEntry(contentKey, manifest) {
      if (!contentKey || !manifest?.entries) return null;
      const [name, path] = (await legacyCacheEntries())[contentKey] || [];
      const entry = manifest.entries[name];
      // shortcut: reuse only manifest-visible old art; older hidden renders need a separate file check.
      return name && path && entry?.talentName === name && entry.imagePath === path
        && await imageEntryExists(entry) ? entry : null;
    }

    function detailVisualBucket(codes) {
      const active = new Set(codes || []);
      const hasAny = values => values.some(value => active.has(value));
      if (active.has('intoxication-blacked_out')) return 'unconscious';
      if (hasAny(['energy-0', 'wellbeing-0', 'intoxication-sloppy'])) return 'exhausted';
      if ([...active].some(code => code.startsWith('intoxication-'))) return 'intoxicated';
      if (hasAny([
        'energy-1', 'mood-0', 'mood-1', 'wellbeing-1', 'wellbeing-2', 'trust-low',
        'resentment-medium', 'resentment-high', 'drift-high', 'latitude-negative',
        'feeling-anger', 'feeling-contempt', 'feeling-disgust', 'feeling-sadness',
        'feeling-shame', 'feeling-guilt', 'feeling-regret', 'feeling-humiliation',
        'drive-financial', 'drive-security', 'drive-social',
      ])) return 'distressed';
      if ([...active].some(code => /^arousal-[1-4]$/.test(code)) || hasAny([
        'allure-high', 'desire-high', 'feeling-tenderness', 'feeling-longing',
        'feeling-desire', 'feeling-arousal_buzz', 'drive-approval', 'drive-desire',
        'drive-pride', 'drive-longing',
      ])) return 'aroused';
      return 'other';
    }

    function hasNegativeOralState(characterId) {
      const state = api.store.game();
      const character = state?.characters?.[characterId];
      const detail = state && character
        ? detailPromptState(state, character, characterId, {}, heroineDriveCalc(state), true)
        : null;
      const codes = detail?.codes || [];
      return !codes.includes('intoxication-blacked_out')
        && ['exhausted', 'distressed'].includes(detailVisualBucket(codes.filter(code => !code.startsWith('intoxication-'))));
    }

    function detailImageSignature(value, prompts) {
      const promptConfig = DETAIL_FIELDS.map(field => `${field.key}:${cleanPrompt(prompts[field.key])}`).join('|');
      return `detail-${detailVisualBucket(value.codes)}-${shortHash(promptConfig)}`;
    }

    function markPromptState(state, characterId, prompts, codeOnly, visibleBody, visibleGenitals) {
      if (characterId !== state.primaryCharacterId) return null;
      let saved = [];
      try { saved = globalThis.__waywardMarks?.of?.(state)?.list || []; } catch {}
      if (!saved.length && (!state.waywardMarks?.id || state.waywardMarks.id === characterId))
        saved = Array.isArray(state.waywardMarks?.list) ? state.waywardMarks.list : [];
      const sceneStrikes = state.activeScene?.patron?.__actStrikes || [];
      const liveSexStrike = Array.isArray(sceneStrikes)
        && sceneStrikes.some(mark => mark?.part === 'sex' && Number(mark.degree) > 0);
      const degrees = new Map();
      for (const mark of [...saved, ...(Array.isArray(sceneStrikes) ? sceneStrikes : [])]) {
        if (!['slap', 'breast', 'butt', 'sex', 'belly'].includes(mark?.part)
          || mark.part === 'sex' && !visibleGenitals && !liveSexStrike
          || mark.part !== 'slap' && mark.part !== 'sex' && !visibleBody
          || Number(mark.degree) <= 0) continue;
        const degree = Math.max(1, Math.min(3, Math.round(Number(mark.degree) || 1)));
        degrees.set(mark.part, Math.max(degrees.get(mark.part) || 0, degree));
      }
      const codes = [...degrees].map(([part, degree]) => `mark.${part}.${degree}`)
        .filter(code => prompts[code] !== null);
      if (!codes.length) return null;
      return { codes, tags: codeOnly ? [] : promptTokens(codes.map(code => prompts[code]).join(', ')) };
    }

    function promptGroups(state, character, characterId, prompts, outfitStates, dialogueRules, imageKey, promptField, codeOnly = false) {
      const drives = heroineDriveCalc(state);
      const outfitId = outfitIdFor(character, imageKey);
      prompts = externalPromptsForField(prompts, promptField);
      prompts = effectiveSceneStatePrompts(prompts, positionSituationId(imageKey), promptField);
      const scopedPrompts = codeOnly
        ? Object.fromEntries(Object.keys(prompts).map(key => [key,
          outfitAllows(outfitStates[key], outfitId, key, imageKey, character)
            ? (key.startsWith('cycle.vulva.') || key.startsWith('firstExperience.') || key.startsWith('erostat.fit.') || key.startsWith('erostat.anal.') || key.startsWith('hstatus.') ? prompts[key] : '') : null]))
        : promptsForOutfit(prompts, outfitStates, outfitId, imageKey, character);
      const detail = detailPromptState(state, character, characterId, scopedPrompts, drives, codeOnly);
      const visibleBody = Boolean(['sex_patron', 'rubbing_patron'].includes(state.activeScene?.patron?.stage)
        || state.activeScene?.sex
        || /(?:nude|naked|undressed|bare)/i.test(outfitId));
      const exposure = exposureFlags(imageKey, character);
      const visibleGenitals = visibleBody || exposure.pantiesAside || exposure.pantiesRemoved;
      const visibleLowerAbdomen = outfitStateOf(outfitId) === 'nude' || outfitId === 'panties_only'
        || exposure.skirtUp || exposure.skirtRemoved;
      const features = currentFeaturePrompts();
      return [
        { id: 'attention', label: api.t({ ko: '대응 필요 상황', en: 'Attention needed' }), value: attentionPromptState(state, characterId, scopedPrompts, promptField, codeOnly) },
        { id: 'detail', label: api.t({ ko: '상세 상태', en: 'Detailed status' }), value: detail && !codeOnly ? { ...detail, imageSignature: detailImageSignature(detail, scopedPrompts) } : detail },
        { id: 'pregnancy', label: api.t({ ko: '임신 상태', en: 'Pregnancy status' }), value: features.pregnancy ? pregnancyPromptState(state, characterId, scopedPrompts, codeOnly) : null },
        { id: 'cycle', label: api.t({ ko: '생리 상태', en: 'Menstrual cycle' }),
          value: features.cycle || cyclePreviewPhase ? cyclePromptState(state, characterId, scopedPrompts, codeOnly, imageKey) : null },
        { id: 'firstExperience', label: api.t({ ko: '첫경험 상태', en: 'First experience' }),
          value: features.firstExperience || firstExperiencePreviewing
            ? firstExperiencePromptState(state, characterId, scopedPrompts, codeOnly, imageKey) : null },
        { id: 'sleep', label: api.t({ ko: '수면 상태', en: 'Sleep state' }),
          value: features.sleep ? sleepPromptState(state, characterId, scopedPrompts, codeOnly, imageKey) : null },
        { id: 'marks', label: api.t({ ko: '손찌검 흔적', en: 'Strike marks' }), value: features.marks ? markPromptState(state, characterId, scopedPrompts, codeOnly, visibleBody, visibleGenitals) : null },
        { id: 'erostat', label: api.t({ ko: '에로스테 크기', en: 'Erostat size' }),
          value: features.erostat ? erostatFitPromptState(state, characterId, imageKey, scopedPrompts, codeOnly) : null },
        { id: 'hypnosis', label: api.t({ ko: '최면 상태', en: 'Hypnosis status' }),
          value: characterId === state.primaryCharacterId ? hStatusFantasyPromptState(character, 'hypnosis', scopedPrompts, codeOnly) : null },
        { id: 'crest', label: api.t({ ko: '음문 상태', en: 'Crest status' }),
          value: characterId === state.primaryCharacterId && visibleLowerAbdomen
            ? hStatusFantasyPromptState(character, 'crest', scopedPrompts, codeOnly) : null },
        ...fluidPromptStates(character, scopedPrompts, drives, codeOnly),
        { id: 'sceneAction', label: api.t({ ko: '장면 동작', en: 'Scene action' }),
          value: patronActionPromptState(state, characterId, imageKey, promptField, codeOnly) },
        { id: 'dialogue', label: api.t({ ko: '대화 감지', en: 'Dialogue match' }), value: dialoguePromptState(state, dialogueRules, imageKey, promptField, outfitId, codeOnly) },
      ].filter(group => group.value);
    }

    function characterPromptGroup(state, character, characterId, promptField) {
      if (characterId !== state.primaryCharacterId) return null;
      const registered = character?.generatedArchetype?.attentionImagePrompt;
      const override = characterPromptOverride(currentWifePromptContext(state, characterId, character));
      const characterPrompt = override || (registered ? {
        ...normalizeCharacterPrompt(registered),
        negativePrompt: normalizedWifeNegative(registered.negativePrompt),
      } : null);
      if (!characterPrompt) return null;
      const tags = promptTokens(characterPrompt[promptField]);
      const clearsBaseNegative = promptField === 'negativePrompt' && characterPrompt.mode === 'replace' && Boolean(registered);
      if (!tags.length && !clearsBaseNegative) return null;
      return {
        id: 'character',
        label: api.t({ ko: '아내 캐릭터', en: 'Wife character' }),
        mode: characterPrompt.mode,
        imagePolicy: characterPrompt.imagePolicy,
        value: { codes: [`character.${characterPrompt.mode}`], tags },
      };
    }

    function outfitPromptGroup(character, imageKey, promptField) {
      const rawId = outfitIdFor(character, imageKey);
      const canonicalId = String(outfitById(rawId)?.id || rawId || '').trim();
      const prompts = currentOutfitPrompts();
      const override = prompts[canonicalId] || prompts[rawId];
      if (!override) return null;
      return {
        id: 'outfit',
        label: api.t({ ko: '의상 프롬프트', en: 'Outfit prompt' }),
        mode: 'replace',
        value: { codes: [`outfit.${canonicalId || rawId}`], tags: promptTokens(override[promptField]) },
      };
    }

    function nativeCharacterNegative(character) {
      const archetype = character?.generatedArchetype
        ?? (character?.archetypeId ? wifeArchetypeById(character.archetypeId) : null);
      return String(archetype?.imageNegative || '').trim();
    }

    function promptContext(state, character, characterId, imageKey, genericPlan = false) {
      const situationConfig = genericPlan ? null : situationConfigForCharacter(character, characterId);
      const characterPositive = characterPromptGroup(state, character, characterId, 'positivePrompt');
      const characterNegative = characterPromptGroup(state, character, characterId, 'negativePrompt');
      const outfitPositive = outfitPromptGroup(character, imageKey, 'positivePrompt');
      const outfitNegative = outfitPromptGroup(character, imageKey, 'negativePrompt');
      const positiveGroups = [characterPositive, outfitPositive, ...(situationConfig ? promptGroups(state, character, characterId, situationConfig.prompts, situationConfig.outfitStates, situationConfig.dialogueRules, imageKey, 'positivePrompt') : [])].filter(Boolean);
      const negativeGroups = [characterNegative, outfitNegative, ...(situationConfig ? promptGroups(state, character, characterId, situationConfig.negativePrompts, situationConfig.outfitStates, situationConfig.dialogueRules, imageKey, 'negativePrompt') : [])].filter(Boolean);
      const buttonGroups = buttonPromptGroups(state, characterId, imageKey, genericPlan);
      positiveGroups.push(...buttonGroups.positive);
      negativeGroups.push(...buttonGroups.negative);
      return {
        positiveGroups,
        negativeGroups,
        dialogue: [...positiveGroups, ...negativeGroups].some(group => group.id === 'dialogue' || group.id === 'sceneAction'),
        situational: [...positiveGroups, ...negativeGroups].some(group => group.id !== 'character'),
        characterPolicy: imageStudioOwnsSelection() ? null : (characterPositive || characterNegative)?.imagePolicy || null,
      };
    }

    function stateSignature(groups, exactDetail = false) {
      return groups.flatMap(group => group.id === 'detail' && !exactDetail
        ? [group.value.imageSignature]
        : [...group.value.codes, ...group.value.tags]).join('|');
    }

    function combinedStateSignature(positiveGroups, negativeGroups, exactDetail = false) {
      const exact = exactDetail || !groupSimilarDetailStates();
      const positive = stateSignature(positiveGroups, exact);
      const negative = stateSignature(negativeGroups, exact);
      return negative ? `positive:${positive}|negative:${negative}` : positive;
    }

    function baseSituationImageKey(key) {
      return String(compactSituationAliases.get(String(key)) || key || '').split('__').filter(part => !/^(?:aip-.+|aipk-.+|acc-[a-z0-9]+|state-[a-z0-9]+|dialogue-[a-z0-9]+|character-(?:reuse|regenerate)-[a-z0-9]+|position-.+|content-[0-9a-f]+)$/.test(part)).join('__');
    }

    function sleepSituationImageKey(key, state, characterId) {
      const clean = String(key || '').split('__').filter(part => !['sleep-asleep', 'sleep-rubbing', 'sleep-thigh-rubbing', 'sleep-entrance-contact'].includes(part)).join('__');
      const sleep = state.activeScene?.sex?.__hs?.sleep;
      const situation = sleep?.stage === 'asleep' ? 'asleep'
        : sleep?.stage === 'tussle' && sleep.how === 'big' ? 'entrance-contact' : '';
      if (characterId !== state.primaryCharacterId || !situation
        || !/(?:^|__)scene-(?!patron_)/.test(clean)) return clean;
      const variant = clean.match(/__v-\d+$/)?.[0] || '';
      return `${variant ? clean.slice(0, -variant.length) : clean}__sleep-${situation}${variant}`;
    }

    function situationCode(value) {
      const raw = String(value || '');
      if (/^[a-z0-9-]{1,60}$/.test(raw)) return raw;
      const readable = raw.toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40);
      return `${readable || 'id'}-${shortHash(raw)}`;
    }

    function positionDetailCode(value, count) {
      // Keep option indexes stable for fixed-rule choice signatures.
      const details = normalizePositionDetails(value, count);
      const optionCode = (options, selected) => options.findIndex(([id]) => id === selected).toString(36);
      const personCode = person => POSITION_DETAIL_FIELDS.map(field => optionCode(field.options, person[field.id])).join('');
      return `${optionCode(FEMALE_POSE_OPTIONS, details.female.pose)}${personCode(details.main)}${details.extras.map(personCode).join('')}`;
    }

    function customOutfitSituationCode(character, imageKey) {
      const customOutfit = customOutfitFor(character, imageKey);
      return customOutfit ? `custom-outfit-${shortHash(JSON.stringify([
        promptTokens(customOutfit.positivePrompt).sort(), promptTokens(customOutfit.negativePrompt).sort(),
        promptTokens(customOutfit.topPrompt).sort(), promptTokens(customOutfit.skirtPrompt).sort(),
        customOutfit.wear || 'floor', customOutfit.boldnessScore ?? 30, 'native-outfit-v1',
      ]))}` : '';
    }

    function customOutfitImageKey(imageKey, character) {
      if (typeof imageKey !== 'string' || !/(?:^|__)outfit-[^_]+/.test(imageKey)
        || /(?:^|__)aipk?-/.test(imageKey)) return imageKey;
      const code = customOutfitSituationCode(character, imageKey);
      if (!code) return imageKey;
      const variant = imageKey.match(/__v-\d+$/)?.[0] || '';
      const root = variant ? imageKey.slice(0, -variant.length) : imageKey;
      return compactSituationKey(`${root}__aip-att-${situationCode(code)}${variant}`);
    }

    function externalPlanImageKey(imageKey, character) {
      let key = customOutfitImageKey(imageKey, character);
      const globalSignature = globalPromptExclusionsFingerprint();
      if (typeof key === 'string' && globalSignature) {
        const parts = String(compactSituationAliases.get(key) || key).split('__');
        const index = parts.findIndex(part => part.startsWith('aip-'));
        if (index >= 0) {
          const codes = parts[index].slice(4).split('_').filter(code => !code.startsWith('state-global-remove-'));
          parts[index] = `aip-${[...codes, `state-global-remove-${globalSignature}`].sort().join('_')}`;
        } else {
          const variantIndex = parts.findIndex(part => /^v-\d+$/.test(part));
          parts.splice(variantIndex < 0 ? parts.length : variantIndex, 0, `aip-state-global-remove-${globalSignature}`);
        }
        key = compactSituationKey(parts.join('__'));
      }
      if (typeof key !== 'string' || !externalPromptRegistry.size) return key;
      const state = api.store.game();
      const current = state?.characters?.[state.primaryCharacterId];
      const archetypeIds = value => [value?.generatedArchetype?.id, value?.generatedArchetype?.shortname,
        value?.wifeArchetypeId, value?.archetypeId].filter(id => typeof id === 'string' && id && !['wife', 'elena'].includes(id));
      const plannedIds = archetypeIds(character);
      const currentMatches = current && archetypeIds(current).some(id => plannedIds.includes(id));
      const target = currentMatches ? current : character;
      const config = target ? situationConfigForCharacter(target, currentMatches ? state.primaryCharacterId : '') : legacySituationConfig();
      const signature = externalFieldCacheSignature(config);
      if (!signature) return key;
      const full = String(compactSituationAliases.get(key) || key);
      const parts = full.split('__');
      const index = parts.findIndex(part => part.startsWith('aip-'));
      if (index >= 0) {
        const codes = parts[index].slice(4).split('_').filter(code => !code.startsWith('att-external-'));
        parts[index] = `aip-${[...codes, `att-external-${signature}`].sort().join('_')}`;
      } else {
        const variantIndex = parts.findIndex(part => /^v-\d+$/.test(part));
        parts.splice(variantIndex < 0 ? parts.length : variantIndex, 0, `aip-att-external-${signature}`);
      }
      return compactSituationKey(parts.join('__'));
    }

    function externalSignatureFromImageKey(imageKey) {
      return String(compactSituationAliases.get(imageKey) || imageKey || '')
        .match(/(?:^|[-_])att-external-([a-z0-9]+)/)?.[1] || '';
    }

    function singleAnalAnatomyScene(key, characterId) {
      const situation = positionSituationId(key);
      const scene = basePositionSituationId(situation);
      if (!['scene-anal', 'scene-patron_anal'].includes(scene) || positionGroupCount(situation)
        || positionStateOnly(currentPositionStatePrompt(situation))) return false;
      const state = api.store.game(), sex = state?.activeScene?.sex, patron = state?.activeScene?.patron;
      if (!characterId || characterId !== state?.primaryCharacterId) return false;
      if (sex && patron) return false;
      if (scene === 'scene-anal') return Boolean(sex?.type === 'anal' && !sex.finish
        && (!sex.characterId || sex.characterId === state.primaryCharacterId));
      return Boolean(patron?.stage === 'sex_patron' && patron.primarySlot === 'inside_anal'
        && !patron.afterglow && !patron.playerEngaged && !patron.lateralAct
        && !multiplePatronActions(situation)
        && (!patron.characterId || patron.characterId === state.primaryCharacterId));
    }

    function analAnatomyConflictingPrompt(value) {
      const text = String(value || '').replaceAll('_', ' ').toLowerCase();
      return /\b(?:[2-9]\s*boys?|multiple boys|multiple men|two men|threesome|double penetration|vaginal(?!\s+opening\b)|penis in (?:pussy|vagina)|fingers? in pussy|fingering|fellatio|deepthroat|irrumatio)\b/.test(text);
    }

    function situationImageKey(key, state, character, characterId, choice) {
      const base = baseSituationImageKey(key);
      const codes = Object.fromEntries(['att', 'state', 'fluid', 'jewel', 'toy', 'talk'].map(kind => [kind, new Set()]));
      const add = (kind, value) => codes[kind].add(situationCode(value));
      const cameraSignature = cameraSettingsFingerprint(positionSituationId(base));
      if (cameraSignature) add('state', `camera-${cameraSignature}`);
      const outfitCode = customOutfitSituationCode(character, base);
      if (outfitCode) add('att', outfitCode);
      const globalSignature = globalPromptExclusionsFingerprint();
      if (globalSignature) add('state', `global-remove-${globalSignature}`);
      const sceneBaseSignature = sceneBaseOverrideFingerprint(positionSituationId(base));
      if (sceneBaseSignature) add('state', `scene-base-${sceneBaseSignature}`);
      const sceneStateSignature = sceneStatePromptFingerprint(positionSituationId(base));
      if (sceneStateSignature) add('state', `scene-state-${sceneStateSignature}`);
      const modRuleSignature = promptModRulesFingerprint(positionSituationId(base));
      if (modRuleSignature) add('state', `mod-rules-${modRuleSignature}`);
      const scenePrompt = currentPositionStatePrompt(positionSituationId(base));
      if (scenePrompt?.positivePrompt || scenePrompt?.negativePrompt) add('state', `scene-prompt-${shortHash(JSON.stringify([
        scenePrompt.positivePrompt || '', scenePrompt.negativePrompt || '', positionStateOnly(scenePrompt),
      ]))}`);
      const buttonGroups = buttonPromptGroups(state, characterId, base);
      if (buttonGroups.positive.length || buttonGroups.negative.length) add('state', `choice-prompt-${shortHash(JSON.stringify([
        buttonGroups.positive.map(group => [group.value.codes, group.value.tags]),
        buttonGroups.negative.map(group => [group.value.codes, group.value.tags]),
      ]))}`);
      const config = situationConfigForCharacter(character, characterId);
      const externalSignature = externalFieldCacheSignature(config);
      if (externalSignature) add('att', `external-${externalSignature}`);
      const groups = config ? promptGroups(state, character, characterId,
        config.prompts, config.outfitStates, config.dialogueRules, base, 'positivePrompt', true) : [];
      for (const group of groups) {
        if (group.id === 'attention') group.value.codes.forEach(code => add('att', code));
        else if (group.id === 'detail') {
          if (groupSimilarDetailStates()) {
            const bucket = detailVisualBucket(group.value.codes);
            if (bucket !== 'other') add('state', bucket);
          } else group.value.codes.forEach(code => add('state', code));
        } else if (['pregnancy', 'cycle', 'firstExperience', 'sleep', 'erostat', 'hypnosis', 'crest'].includes(group.id)) group.value.codes.forEach(code => add('state', code));
        else if (group.id === 'dialogue') group.value.codes.forEach(code => add('talk', code.slice('dialogue-'.length)));
        else if (group.id === 'sceneAction') group.value.codes.forEach(code => add('talk', code));
        else for (const code of group.value.codes) {
          if (code.startsWith('jewelry-')) add('jewel', code.slice('jewelry-'.length));
          else if (code.startsWith('toy-')) add('toy', code.slice('toy-'.length));
          else add('fluid', code);
        }
      }
      const negativeState = config && promptGroups(state, character, characterId,
        config.negativePrompts, config.outfitStates, config.dialogueRules, base, 'negativePrompt', true)
        .filter(group => ['cycle', 'firstExperience', 'erostat', 'hypnosis', 'crest'].includes(group.id));
      for (const group of negativeState || []) group.value.codes.forEach(code => add('state', code));
      for (const code of config ? patronActionPromptState(state, characterId, base, 'negativePrompt', true)?.codes || [] : [])
        add('talk', code);
      const breastStage = Number(character?.situationStats?.jewelryState?.breasts?.stage) || 0;
      if (character?.situationStats?.jewelryState) {
        const outfitId = outfitIdFor(character, base);
        const outfitTags = `${outfitById(outfitId)?.imageTags || ''}, ${currentOutfitPrompts()[outfitId]?.positivePrompt || ''}`;
        if (/choker/i.test(outfitTags)) add('jewel', breastStage === 3 ? 'choker-only-v3' : 'choker-suppressed-v2');
      }
      if ((breastStage === 1 || breastStage === 2) && !codes.jewel.has(`breasts-${breastStage}`)) {
        add('jewel', `breasts-${breastStage}-covered`);
      }
      if (breastStage === 3 && !codes.jewel.has('breasts-3')) {
        add('jewel', 'choker');
      }
      const vibe = character?.situationStats?.jewelryState?.vibe;
      if (!vibe?.suspension && ['egg', 'penis'].includes(vibe?.type)) add('toy', `vibe-${vibe.type}`);
      if (analFinishSceneKey(base)) add('att', 'anal-finish-v3');
      if (singleAnalAnatomyScene(base, characterId) && !choice?.conflictingNativeAct) {
        const analChoiceTags = [choice?.personPrompt, choice?.details?.main?.action,
          ...(choice?.details?.extras || []).map(person => person.action),
          ...(choice?.modules || []).map(module => module.positivePrompt)].filter(Boolean).join(', ');
        if (!analAnatomyConflictingPrompt(analChoiceTags)) add('att', 'anal-anatomy-v1');
      }
      if (characterId === state.primaryCharacterId && !positionStateOnly(scenePrompt)
        && (/^(?:scene-(?:patron_)?handjob(?:_finish)?)$/.test(basePositionSituationId(positionSituationId(base)))
        || String(choice?.groupSlots || positionGroupSlots(base)).includes('h')
        || choice?.details?.main?.action === MALE_ACTIONS.handjob
        || choice?.details?.extras?.some(person => person.action === MALE_ACTIONS.handjob)
        || choice?.modules?.some(module => /\bhandjob\b/i.test(module.positivePrompt || '')))) add('att', 'handjob-anatomy-v1');
      if (/(?:^|__)scene-patron_/.test(base) && hasSevereNegativeFeeling(character)) add('state', 'patron-distressed');
      const activeContext = promptContext(state, character, characterId, base);
      if (config && stateEditorHasGlobalChanges(config)) {
        const activeGroups = [...activeContext.positiveGroups, ...activeContext.negativeGroups];
        for (const field of ['positivePrompt', 'negativePrompt']) {
          const probe = stateEditorGlobalProbePrompts(config, field);
          if (probe) activeGroups.push(...promptGroups(state, character, characterId, probe,
            config.outfitStates, config.dialogueRules, base, field));
        }
        const signature = stateEditorGlobalFingerprint(config, activeGroups, positionSituationId(base));
        if (signature) add('state', `state-edit-${signature}`);
      }
      if (hasDistressedExpression(character, activeContext.positiveGroups)) {
        add('state', 'expression-v2');
      }
      const tags = Object.entries(codes).flatMap(([kind, values]) => [...values].sort().map(value => `${kind}-${value}`));
      const toySuffix = base.match(/__toy-[a-z0-9-]+(?:_[a-z0-9-]+)*$/)?.[0] || '';
      const legacyVariant = toySuffix && choice?.imageKey?.endsWith(toySuffix)
        ? choice.imageKey.slice(0, -toySuffix.length).match(/__v-\d+$/)?.[0] : '';
      const currentBase = legacyVariant
        ? `${base.slice(0, -toySuffix.length).replace(/__v-\d+$/, legacyVariant)}${toySuffix}` : base;
      const selectedVariant = choice?.imageKey?.match(/__v-\d+$/)?.[0];
      const variant = selectedVariant || currentBase.match(/__v-\d+$/)?.[0] || '';
      const root = currentBase.replace(/__v-\d+$/, '');
      const nextKey = `${root}${tags.length ? `__aip-${tags.join('_')}` : ''}${variant}`;
      const previousExternal = externalSignatureFromImageKey(choice?.imageKey);
      const choiceKey = String(choice?.imageKey || '');
      const expandedChoiceKey = compactSituationAliases.get(choiceKey) || choiceKey;
      const knownChoiceKey = !/(?:^|__)aipk-/.test(choiceKey) || compactSituationAliases.has(choiceKey);
      const previousGlobal = expandedChoiceKey.match(/(?:^|[-_])state-global-remove-([a-z0-9]+)/)?.[1] || '';
      const matchingGlobal = typeof choice?.globalExclusionSignature === 'string'
        ? choice.globalExclusionSignature === globalSignature
        : knownChoiceKey ? previousGlobal === globalSignature : !globalSignature;
      const previousCamera = expandedChoiceKey.match(/(?:^|[-_])state-camera-([a-z0-9]+)/)?.[1] || '';
      const matchingCamera = typeof choice?.cameraSignature === 'string'
        ? choice.cameraSignature === cameraSignature
        : knownChoiceKey ? previousCamera === cameraSignature : !cameraSignature;
      const fullKey = choice?.generatedKeys?.includes(choice.imageKey)
        && matchingGlobal && matchingCamera
        && previousExternal === externalSignature
        && positionSituationId(choice.imageKey) === positionSituationId(nextKey)
        && similarImageSituationKey(choice.imageKey) !== similarImageSituationKey(nextKey)
        && accessorySituationCode(choice.imageKey) === accessorySituationCode(nextKey)
        ? choice.imageKey : keyWithPosition(nextKey, matchingGlobal && matchingCamera || !choice ? choice
          : { ...choice, imageKey: '', pendingPreviousKey: '' });
      return compactSituationKey(fullKey);
    }

    function keyWithState(key, signature, dialogue = false, characterPolicy = null, situational = false) {
      const kind = dialogue ? 'dialogue' : situational ? 'state' : characterPolicy ? `character-${characterPolicy}` : 'state';
      const suffix = `__${kind}-${shortHash(signature)}`;
      if (key.includes(suffix)) return key;
      const variant = key.match(/__v-\d+$/)?.[0] || '';
      return `${variant ? key.slice(0, -variant.length) : key}${suffix}${variant}`;
    }

    function stripPositionKey(value) {
      return String(value || '').split('__').filter(part => !part.startsWith('position-')).join('__');
    }

    function activePortraitImageKey(fallback, state = api.store.game()) {
      if (!api.has('currentPortraitImageKey') || !state) return fallback;
      try {
        const imageKey = api.fn('currentPortraitImageKey')(state);
        return typeof imageKey === 'string' && imageKey ? imageKey : fallback;
      } catch (error) {
        console.warn('[attention-image-prompt] current portrait key', error);
        return fallback;
      }
    }

    function positionSituationId(value) {
      const parts = stripPositionKey(value).split('__');
      const base = parts.find(part => /^(?:scene|task|look)-/.test(part)) || '';
      if (!base) return '';
      const detailPrefixes = base.startsWith('scene-')
        ? ['sleep-', 'grp-', 'gslot-', 'abed-', 'fin-']
        : base.startsWith('look-') ? ['reaction-'] : [];
      return [base, ...detailPrefixes.map(prefix => parts.find(part => part.startsWith(prefix))).filter(Boolean)].join('|');
    }

    function basePositionSituationId(value) {
      return String(value || '').split('|')[0];
    }

    function matchingPositionRuleId(situationId, rules) {
      if (rules[situationId]?.length) return situationId;
      if (situationId.includes('|sleep-')) return '';
      const base = basePositionSituationId(situationId);
      return rules[base]?.length ? base : '';
    }

    function positionSituationLabel(value) {
      const [base, ...details] = String(value || '').split('|');
      if (!base) return '상황 정보 없음';
      const detailLabels = details.map(detail => {
        if (detail === 'sleep-asleep') return '수면 중';
        if (detail === 'sleep-entrance-contact') return '잠에서 깬 뒤 측위 입구 맞댐';
        if (detail.startsWith('grp-')) return `추가 남성 ${detail.slice(4)}명`;
        if (detail.startsWith('gslot-')) return `배치 ${positionPlacementLabel(detail.slice(6))}`;
        if (detail === 'abed-1') return '함께 침대에 있음';
        if (detail.startsWith('fin-')) return `마무리 ${detail.slice(4).replaceAll('_', ' ')}`;
        if (detail.startsWith('reaction-')) return `반응 ${detail.slice(9).replaceAll('_', ' ')}`;
        return detail.replaceAll('_', ' ');
      });
      const baseLabel = base === 'scene-groped_ass' ? '엉덩이를 만짐' : base.replace(/^(?:scene|task|look)-/, '').replaceAll('_', ' ');
      return [baseLabel, ...detailLabels].join(' · ');
    }

    function positionPlacementLabel(groupSlots) {
      return [...String(groupSlots || '')].map((slot, index) => `${index + 1}: ${GROUP_SLOT_BY_ID[slot]?.name || slot}`).join(' / ');
    }

    function positionDetailPrompt(value) {
      const detail = normalizePositionDetail(value);
      return [detail.placement, detail.pose, CONCISE_MALE_ACTIONS.get(detail.action) || detail.action, detail.target]
        .filter(Boolean).join(', ');
    }

    function positionFemaleDetailPrompt(value) {
      const pose = normalizeFemalePositionDetail(value?.female).pose;
      return pose ? `(woman pose:1.1), ${pose}` : '';
    }

    function positionPrimaryManPrompt(value, extraTags = '', grouped = false, actionPrompt = '') {
      const main = normalizePositionDetail(value?.main);
      const prompt = [positionDetailPrompt(main), main.action ? '' : actionPrompt, extraTags].filter(Boolean).join(', ');
      return grouped ? `(primary man in foreground:1.3), (male torso visible:1.2), ${prompt || 'man beside woman'}`
        : prompt ? `(primary man:1.05), ${prompt}` : '';
    }

    function positionPlacementPrompt(groupSlots, details, presetPrompt = '', slotPrompt = positionGroupPromptById, personPrompts = null) {
      const ordinals = ['first', 'second', 'third', 'fourth', 'fifth'];
      const normalizedDetails = normalizePositionDetails(details, String(groupSlots || '').length);
      const oralPattern = /\b(?:fellatio|deepthroat|penis[_ ]in[_ ]mouth|69(?:[_ ]position)?)\b/i;
      let mouthOccupied = oralPattern.test(`${normalizedDetails.main.action}, ${presetPrompt}`);
      const people = [...String(groupSlots || '')].flatMap((slot, index) => {
        const detail = normalizedDetails.extras[index];
        const prompt = [positionDetailPrompt(detail) || slotPrompt(slot), personPrompts?.extras?.[index]]
          .filter(Boolean).join(', ');
        if (oralPattern.test(prompt)) {
          if (mouthOccupied) return [`(${ordinals[index]} supporting man:1.0), watching nearby`];
          mouthOccupied = true;
        }
        return prompt ? [`(${ordinals[index]} supporting man:1.0), ${prompt}`] : [];
      });
      return people.length
        ? ['separate male bodies', ...people].join(', ')
        : '';
    }

    function selectedPositionGroupSlots(scene = latestScenePrompt) {
      if (!scene) return '';
      const count = positionGroupCount(scene.situationId);
      if (!count) return '';
      const nativeSlots = positionGroupSlots(scene.result.key);
      const selected = positionSelection.situationId === scene.situationId ? positionSelection.groupSlots : '';
      const draft = positionPlacementDrafts.get(scene.situationId);
      return String(draft || selected || nativeSlots).padEnd(count, 'w').slice(0, count);
    }

    function positionChoiceForImageKey(imageKey, characterId) {
      const situationId = positionSituationId(imageKey);
      const count = positionGroupCount(situationId);
      const nativeSlots = positionGroupSlots(imageKey);
      const override = positionOverride(situationId);
      const wakingContact = situationId.includes('|sleep-entrance-contact') && currentFeaturePrompts().sleep;
      const statePrompt = currentPositionStatePrompt(situationId);
      if (positionStateOnly(statePrompt)) {
        return override?.stateOnlySignature
          ? { ...override, preset: null, details: null, personPrompt: null, groupSlots: '' } : null;
      }
      if (positionMode() === 'modules') {
        if (wakingContact && !currentPositionModuleSelections()[situationId]?.length && !override?.manual) {
          const preset = POSITION_PRESETS['waking-contact'];
          return { presetId: preset.id, preset, groupSlots: nativeSlots,
            details: effectivePositionDetails(preset, null, count) };
        }
        const choice = positionModuleChoice(situationId, characterId, imageKey);
        return choice && override?.moduleSignature === choice.moduleSignature && override.imageKey
          ? { ...override, ...choice } : choice;
      }
      const overridePreset = positionPresetById(override?.presetId);
      const overrideDetails = effectivePositionDetails(overridePreset, override?.details, count);
      const rules = currentPositionRules();
      const ruleId = matchingPositionRuleId(situationId, rules);
      const choices = rules[ruleId] || [];
      const defaultAutoPresetId = wakingContact ? 'waking-contact' : situationId.includes('|sleep-')
        ? '' : AUTO_POSITION_PRESETS[basePositionSituationId(situationId)];
      const autoPresetId = !choices.length && (autoPositionPresets() || wakingContact)
        ? (defaultAutoPresetId === 'kneeling-fellatio' && hasNegativeOralState(characterId)
          ? 'rough-fellatio' : defaultAutoPresetId)
        : '';
      // shortcut: old saves omit selection origin; a plain default preset counts as automatic until legacy overrides expire.
      const oldAutomatic = override && (override.presetId === defaultAutoPresetId
        || (defaultAutoPresetId === 'kneeling-fellatio' && override.presetId === 'rough-fellatio'))
        && !override.manual && !override.personPrompt
        && positionDetailsSignature(overrideDetails, count)
          === positionDetailsSignature(effectivePositionDetails(overridePreset, null, count), count);
      if (override && !override.stateOnlySignature && override.imageKey
        && !(!override.manual && (override.automatic || oldAutomatic)
          && override.presetId !== autoPresetId)) {
        return { ...override, groupSlots: override.groupSlots || nativeSlots, details: overrideDetails, preset: overridePreset };
      }
      if (!choices.length) {
        const preset = positionPresetById(autoPresetId);
        return preset ? { presetId: autoPresetId, preset, groupSlots: nativeSlots, details: effectivePositionDetails(preset, null, count) } : null;
      }
      const includeDefault = currentPositionRuleDefaults(rules)[ruleId] === true;
      const candidateCount = choices.length + (includeDefault ? 1 : 0);
      const cleanKey = stripPositionKey(imageKey);
      const signature = `${JSON.stringify(choices.map(choice => [choice.presetId, choice.groupSlots,
        positionDetailCode(choice.details, count)]))}|default:${includeDefault}`;
      const cached = positionRandomChoices.get(cleanKey);
      const index = cached?.signature === signature
        ? cached.index % candidateCount
        : Math.floor(Math.random() * candidateCount);
      positionRandomChoices.set(cleanKey, { signature, index });
      if (includeDefault && index === choices.length) return null;
      const choice = choices[index];
      const preset = positionPresetById(choice.presetId);
      return {
        ...choice,
        groupSlots: choice.groupSlots || nativeSlots,
        details: effectivePositionDetails(preset, choice.details, count),
        preset,
      };
    }

    function positionBothHandPrompts(modules, situationId) {
      const targets = {
        '가슴': 'on her breasts', '젖꼭지': 'on her nipples', '클리': 'on her clitoris',
        '엉덩이': 'on her buttocks', '머리채': 'holding her hair', '손목': 'holding her wrist',
        '허리': 'on her waist', '다리': 'on her leg', '옷 위': 'on the same part of her clothed body',
        '속옷 위': 'on the same part of her body over her underwear',
      };
      return ['you', 'patron'].flatMap(scope => {
        const candidates = ['왼손', '오른손'].map(group => modules.filter(module => module.controller
          && module.controllerScope === scope && module.controllerGroup === group));
        if (candidates.some(hand => hand.length !== 1)) return [];
        const hands = candidates.map(hand => hand[0]);
        if (!hands[0].positivePrompt || !hands[1].positivePrompt || hands[0].controllerLabel !== hands[1].controllerLabel
          || !targets[hands[0].controllerLabel]) return [];
        const unchanged = hands.every(module => module.positivePrompt === controllerButtonDefaultTags({
          scope, group: module.controllerGroup, label: module.controllerLabel,
        }));
        if (!unchanged || scope === 'patron' && multiplePatronActions(situationId)) return [];
        return [`(both of ${scope === 'you' ? "her partner's" : "the customer's"} hands ${targets[hands[0].controllerLabel]}:1.25)`];
      });
    }

    function keyWithPosition(imageKey, choice) {
      const cleanKey = stripPositionKey(imageKey);
      const situationId = positionSituationId(cleanKey);
      const count = positionGroupCount(situationId);
      const statePrompt = currentPositionStatePrompt(situationId);
      const onlyState = positionStateOnly(statePrompt);
      if (Boolean(choice?.stateOnlySignature) !== onlyState) choice = null;
      const preset = choice?.preset || null;
      const details = effectivePositionDetails(preset, choice?.details, count);
      const statePositive = statePrompt?.positivePrompt || '';
      const stateNegative = statePrompt?.negativePrompt || '';
      const personPrompt = typeof choice?.personPrompt === 'string' ? choice.personPrompt : null;
      const modules = Array.isArray(choice?.modules) ? choice.modules : [];
      if (choice?.pendingPreviousKey && choice.imageKey
        && externalSignatureFromImageKey(choice.imageKey) === externalSignatureFromImageKey(cleanKey)) return choice.imageKey;
      if (!preset && !details && personPrompt === null && !modules.length && !(choice?.moduleSignature && choice?.groupSlots)) {
        return choice?.imageKey && (choice.stateKey === cleanKey || choice.sourceKey === cleanKey) ? choice.imageKey : cleanKey;
      }
      const cleanVariant = cleanKey.match(/__v-\d+$/)?.[0] || '';
      const root = cleanVariant ? cleanKey.slice(0, -cleanVariant.length) : cleanKey;
      const variant = choice?.pendingPreviousKey
        ? String(choice.imageKey || '').match(/__v-\d+$/)?.[0] || cleanVariant
        : cleanVariant;
      const keyPresetPrompt = POSITION_PRESETS[preset?.id]?.prompt || '';
      const placement = positionPlacementPrompt(choice?.groupSlots, details, keyPresetPrompt,
        slot => GROUP_SLOT_BY_ID[slot]?.prompt || '', choice?.personPrompts);
      const femaleDetail = positionFemaleDetailPrompt(details);
      const primaryMan = positionPrimaryManPrompt(details, choice?.personPrompts?.main);
      const id = choice?.moduleSignature ? 'modules' : preset?.id || (details ? 'custom' : personPrompt !== null ? 'person-custom' : 'state-custom');
      const slots = choice?.groupSlots ? `-slots-${choice.groupSlots}` : '';
      const stateSignature = onlyState ? '|only-state' : '';
      const positionNegative = [effectivePositionPresetPrompt(preset)?.negativePrompt || '',
        ...[...new Set(String(choice?.groupSlots || ''))].map(slot => effectivePositionGroupPrompt(slot, Boolean(choice?.moduleSignature)).negativePrompt)]
        .filter(Boolean).join(', ');
      const bothHands = positionBothHandPrompts(modules, situationId);
      const signature = choice?.moduleSignature ? `${id}|${choice.moduleSignature}|${statePositive}|${stateNegative}${stateSignature}${bothHands.length ? `|both-hands-v1:${bothHands.join('|')}` : ''}`
        : personPrompt === null
          ? `${id}|${keyPresetPrompt}|${femaleDetail}|${primaryMan}|${placement}|${stateSignature}`
          : `${id}|${keyPresetPrompt}|person:custom|${stateSignature}`;
      const stateContent = !choice?.moduleSignature && (statePositive || stateNegative)
        ? `|state-prompt:${JSON.stringify([statePositive, stateNegative])}` : '';
      const positionedKey = `${root}__position-${id}${slots}-${shortHash(`${signature}${stateContent}${positionNegative ? `|${positionNegative}` : ''}`)}${variant}`;
      const sameGeneratedPrompt = String(choice?.imageKey || '').replace(/__v-\d+$/, '') === positionedKey.replace(/__v-\d+$/, '');
      if (choice?.moduleSignature && (bothHands.length || choice.conflictingNativeAct)
        && !sameGeneratedPrompt && !choice.manual && !choice.pendingPreviousKey) return positionedKey;
      const cleanRoot = cleanKey.replace(/__v-\d+$/, '');
      const isNativeVariant = String(choice?.sourceKey || '').replace(/__v-\d+$/, '') === cleanRoot
        && String(choice?.imageKey || '').replace(/__v-\d+$/, '') === cleanRoot;
      return isNativeVariant || choice?.stateKey === cleanKey || (choice?.sourceKey === cleanKey && sameGeneratedPrompt)
        ? choice.imageKey
        : positionedKey;
    }

    function applyPositionPreset(result, choice, characterId) {
      if (!result || !Array.isArray(result.parts)) return result;
      const situationId = positionSituationId(result.key);
      const statePrompt = currentPositionStatePrompt(situationId);
      if (Boolean(choice?.stateOnlySignature) !== positionStateOnly(statePrompt)) choice = null;
      const presetPrompt = effectivePositionPresetPrompt(choice?.preset);
      const preset = choice?.preset && presetPrompt
        ? { ...choice.preset, prompt: presetPrompt.positivePrompt } : choice?.preset;
      const details = effectivePositionDetails(preset, choice?.details, positionGroupCount(situationId));
      const femaleDetail = positionFemaleDetailPrompt(details);
      const modules = Array.isArray(choice?.modules) ? choice.modules : [];
      const hasGroupLayout = Boolean(choice?.moduleSignature && choice?.groupSlots && positionGroupCount(situationId));
      const mainScope = basePositionSituationId(situationId).startsWith('scene-patron_') ? 'patron' : 'you';
      const mainAction = hasGroupLayout ? modules.find(module => module.kind === 'action'
        && module.controllerScope === mainScope)?.positivePrompt
        || modules.find(module => module.kind === 'action' && !module.controllerScope)?.positivePrompt || '' : '';
      const primaryMan = positionPrimaryManPrompt(details, choice?.personPrompts?.main, hasGroupLayout, mainAction);
      const placement = positionPlacementPrompt(choice?.groupSlots, details,
        [mainAction, ...modules.filter(module => module.kind === 'action' && !module.controller && !module.controllerScope)
          .map(module => module.positivePrompt)].filter(Boolean).join(', '),
        slot => effectivePositionGroupPrompt(slot, Boolean(choice?.moduleSignature)).positivePrompt,
        choice?.personPrompts);
      const personPrompt = typeof choice?.personPrompt === 'string' ? choice.personPrompt : null;
      const moduleNegative = modules.map(module => module.negativePrompt).filter(Boolean).join(', ');
      const defaultPreset = POSITION_PRESETS[preset?.id];
      const defaultDetails = defaultPreset?.template
        ? positionPresetTemplateDetails(defaultPreset, positionGroupCount(situationId)) : null;
      const presetNegative = preset && preset.prompt === defaultPreset?.prompt
        && positionFemaleDetailPrompt(details) === positionFemaleDetailPrompt(defaultDetails)
        && positionPrimaryManPrompt(details) === positionPrimaryManPrompt(defaultDetails)
        ? COUPLE_POSITION_NEGATIVES[preset.id] || '' : '';
      const targetNegative = [presetPrompt?.negativePrompt || '',
        ...[...new Set(String(choice?.groupSlots || ''))].map(slot => effectivePositionGroupPrompt(slot, Boolean(choice?.moduleSignature)).negativePrompt)]
        .filter(Boolean).join(', ');
      const statePositive = statePrompt?.positivePrompt || '';
      const stateNegative = statePrompt?.negativePrompt || '';
      const replacesPosition = Boolean(preset || (details && !choice?.moduleSignature) || personPrompt !== null
        || modules.some(module => ['pose', 'position', 'action'].includes(module.kind)));
      const moduleReplaces = label => modules.some(module => ['pose', 'position'].includes(module.kind) && ['자세', 'Pose'].includes(label)
        || module.kind === 'action' && ['장면', 'Scene', '작업', 'Action'].includes(label));
      const state = api.store.game();
      const handjob = /^scene-(?:patron_)?handjob(?:_finish)?$/.test(basePositionSituationId(situationId))
        || (personPrompt === null && (details?.main.action === MALE_ACTIONS.handjob
          || details?.extras.some(person => person.action === MALE_ACTIONS.handjob)))
        || String(choice?.groupSlots || positionGroupSlots(result.key)).includes('h')
        || modules.some(module => /\bhandjob\b/i.test(module.positivePrompt || ''));
      const handjobAnatomy = state && characterId === state.primaryCharacterId && !positionStateOnly(statePrompt) && handjob
        ? '(man beside woman:1.25), (his lower torso and groin visible beside her hip:1.25), (his penis rooted at his own groin:1.4)'
        : '';
      const cuffedHandjob = state && characterId === state.primaryCharacterId && !positionStateOnly(statePrompt)
        && restraintVisible(state) && handjob
        ? '(handcuffed woman giving handjob:1.3), (female cuffed wrists held together in front of her body:1.25), (her cuffed hands holding the man\'s penis beside his groin:1.3), short chain visible between her cuffs'
        : '';
      const oralPattern = /\b(?:fellatio|deepthroat|blowjob|penis[_ ]in[_ ]mouth|69(?:[_ ]position)?)\b/i;
      const nativeOral = !positionStateOnly(statePrompt) && oralPattern.test(result.prompt);
      const paizuriPattern = /\b(?:paizuri|titfuck|breast[_ ]sex)\b/i;
      const paizuriScene = basePositionSituationId(situationId) === 'scene-titfuck';
      const nativePaizuri = !positionStateOnly(statePrompt) && (paizuriScene || paizuriPattern.test(result.prompt));
      const removed = result.parts.filter(part => (modules.length ? moduleReplaces(part.label) : replacesPosition && POSITION_PART_LABELS.has(part.label))
        || String(part.label || '').startsWith('체위 프리셋 ·')
        || String(part.label || '').startsWith('체위 세부 설정 ·')
        || String(part.label || '').startsWith('인물별 설정 ·')
        || String(part.label || '').startsWith('추가 인원 배치 ·')
        || String(part.label || '').startsWith('체위 모듈 ·')
        || String(part.label || '') === '사람별 수정 프롬프트'
        || String(part.label || '') === '상태 추가 프롬프트'
        || String(part.label || '') === '수갑 남성 손 자극'
        || String(part.label || '') === '손 자극 해부 구분'
        || String(part.label || '') === '파이즈리 해부·구도'
        || String(part.label || '') === '구강 인원 제한'
         || ((hasGroupLayout || (replacesPosition && (!modules.length || modules.some(module => module.kind === 'action' && !module.controller))))
          && ['그룹', 'Group'].includes(part.label)));
      const nativePoseTags = modules.some(module => ['pose', 'position'].includes(module.kind))
        ? result.parts.filter(part => ['장면', 'Scene'].includes(part.label))
          .flatMap(part => promptTokens(part.tags))
          .filter(tag => MODULE_NATIVE_POSE_TAGS.has(promptTagIdentity(tag).spaced)).join(', ')
        : '';
      const expectedMenTag = hasGroupLayout ? `${positionGroupCount(situationId) + 1}boys` : '';
      const wrongCountTags = hasGroupLayout ? promptTokens(result.prompt).filter(tag => {
        const name = promptTagIdentity(tag).spaced;
        return /^\d+\s*boys?$/.test(name) && name !== expectedMenTag;
      }).join(', ') : '';
      if (!replacesPosition && !hasGroupLayout && !modules.length && !statePositive && !stateNegative && !handjobAnatomy && !cuffedHandjob && !nativeOral && !nativePaizuri && !removed.length
        && !choice?.pendingPreviousKey
        && result.positionStateNegativeBase === undefined) return result;
      const kept = result.parts.filter(part => !removed.includes(part)).map(part => {
        const isScene = ['장면', 'Scene'].includes(part.label);
        const nativeActTags = isScene && choice?.conflictingNativeAct
          ? conflictingNativeActTags(choice.conflictingNativeAct) : '';
        const tags = withoutPromptTags(nativeActTags ? withoutPromptTags(
          nativePoseTags && isScene ? withoutPromptTags(part.tags, nativePoseTags) : part.tags, nativeActTags)
          : nativePoseTags && isScene ? withoutPromptTags(part.tags, nativePoseTags) : part.tags, wrongCountTags);
        return tags === part.tags ? part : { ...part, tags };
      });
      const keptTags = new Set(promptTokens(kept.map(part => part.tags).join(', ')).map(tag => promptTagIdentity(tag).spaced));
      const nativeActSet = new Set(promptTokens(choice?.conflictingNativeAct
        ? conflictingNativeActTags(choice.conflictingNativeAct) : '').map(tag => promptTagIdentity(tag).spaced));
      const removedNativeAct = result.parts.filter(part => ['장면', 'Scene'].includes(part.label))
        .flatMap(part => promptTokens(part.tags)).filter(tag => nativeActSet.has(promptTagIdentity(tag).spaced)).join(', ');
      const removedOnly = promptTokens(`${removed.map(part => part.tags).join(', ')}, ${nativePoseTags}, ${removedNativeAct}`)
        .filter(tag => !keptTags.has(promptTagIdentity(tag).spaced))
        .join(', ');
      const participantTags = (!replacesPosition && !hasGroupLayout) || kept.some(part => ['성별', 'Gender'].includes(part.label)) ? [] : promptTokens(withoutPromptTags(removedOnly, wrongCountTags)).filter(tag =>
        /^(?:\d+\s*(?:boys?|girls?)|solo(?: focus)?|multiple (?:boys|girls)|(?:mmf|mff) threesome|threesome|group sex|gangbang)$/.test(promptTagIdentity(tag).spaced));
      if (hasGroupLayout && !keptTags.has(expectedMenTag)) participantTags.push(expectedMenTag);
      const leadingLabels = new Set(['품질', 'Quality', '기본', 'Base', '성별', 'Gender']);
      const leadingParts = kept.filter(part => leadingLabels.has(part.label));
      const remainingParts = kept.filter(part => !leadingLabels.has(part.label));
      const positionParts = [
        ...modules.filter(module => module.positivePrompt).map(module => ({
          label: `체위 모듈 · ${module.name} (${positionModuleDirection(module)})`, tags: module.positivePrompt })),
        ...positionBothHandPrompts(modules, situationId).map(tags => ({ label: '체위 모듈 · 양손 동작', tags })),
        ...(preset ? [{ label: `체위 프리셋 · ${preset.name}`, tags: preset.prompt }] : []),
        ...(personPrompt !== null ? [{ label: '사람별 수정 프롬프트', tags: personPrompt }] : [
          ...(femaleDetail ? [{ label: '체위 세부 설정 · 여성', tags: femaleDetail }] : []),
          ...(primaryMan ? [{ label: '인물별 설정 · 주 상대 남성', tags: primaryMan }] : []),
          ...(placement ? [{ label: `추가 인원 배치 · ${positionPlacementLabel(choice?.groupSlots)}`, tags: placement }] : []),
        ]),
      ];
      const leadingPrompt = leadingParts.map(part => part.tags).join(', ');
      const retainedPrompt = withoutPromptTags(result.prompt, `${removedOnly}, ${wrongCountTags}`);
      const remainingPrompt = retainedPrompt;
      const combinedPrompt = joinPrompt(`${leadingPrompt}, ${participantTags.join(', ')}, ${positionParts.map(part => part.tags).join(', ')}, ${remainingPrompt}, ${statePositive}, ${handjobAnatomy}, ${cuffedHandjob}`);
      const analHandNegative = modules.some(module => /(?:^|, )anal_fingering(?:,|$)/.test(module.positivePrompt))
        && !promptTokens(combinedPrompt).some(tag => ['anal', 'penis on ass', 'imminent anal'].includes(promptTagIdentity(tag).spaced))
        ? 'penis_on_ass' : '';
      const fingerNegative = combinedPrompt.includes("man fingering woman's vagina")
        ? `female_masturbation, hand_on_own_crotch${/\banal_fingering\b/.test(combinedPrompt) ? '' : ', anal_fingering, fingers_in_ass'}` : '';
      const oralGuard = !positionStateOnly(statePrompt) && oralPattern.test(combinedPrompt) ? '(one penis in mouth:1.25)' : '';
      const paizuri = !positionStateOnly(statePrompt) && (paizuriScene || paizuriPattern.test(combinedPrompt));
      const supinePaizuri = paizuri && details?.female.pose === FEMALE_POSES.back;
      const paizuriGuard = paizuri
        ? `${supinePaizuri ? '(man above woman:1.2), ' : ''}male torso visible, penis attached to man's groin`
        : '';
      const parts = [
        ...leadingParts,
        ...(participantTags.length ? [{ label: '성별·인원 유지', tags: participantTags.join(', ') }] : []),
        ...positionParts,
        ...remainingParts,
        ...(statePositive ? [{ label: '상태 추가 프롬프트', tags: statePositive }] : []),
        ...(handjobAnatomy ? [{ label: '손 자극 해부 구분', tags: handjobAnatomy }] : []),
        ...(cuffedHandjob ? [{ label: '수갑 남성 손 자극', tags: cuffedHandjob }] : []),
        ...(oralGuard ? [{ label: '구강 인원 제한', tags: oralGuard }] : []),
        ...(paizuriGuard ? [{ label: '파이즈리 해부·구도', tags: paizuriGuard }] : []),
      ];
      const coercionConflicts = modules.some(module => module.id === 'bridge-mood-coerced')
        ? 'smile, smiling, happy, seductive_smile' : '';
      const prompt = deduplicatePrompt(withoutPromptTags(
        joinPrompt(`${combinedPrompt}, ${oralGuard}, ${paizuriGuard}`), coercionConflicts));
      const negativeBase = result.positionStateNegativeBase ?? result.negativePrompt ?? '';
      const oralNegative = oralGuard ? 'two penises in mouth, multiple penises in mouth, extra penis in mouth' : '';
      const roughOral = preset?.id === 'rough-fellatio'
        || (personPrompt === null && (details?.main.action === MALE_ACTIONS.roughFellatio
          || details?.extras.some(person => person.action === MALE_ACTIONS.roughFellatio)));
      const roughOralNegative = roughOral
        ? 'smile, closed mouth, both eyes closed, shallow fellatio'
        : '';
      const paizuriNegative = paizuri
        ? `detached penis, penis growing from breasts, penis emerging from nipple${supinePaizuri ? ', woman on top' : ''}`
        : '';
      const handjobNegative = handjobAnatomy
        ? 'futanari, girl with penis, penis attached to woman, penis emerging from female crotch, detached penis, penis between woman\'s thighs'
        : '';
      const groupPrimaryNegative = hasGroupLayout
        ? 'female solo, missing foreground man, disembodied penis, floating penis' : '';
      return {
        ...result,
        key: keyWithPosition(result.key, choice),
        prompt,
        negativePrompt: deduplicatePrompt(joinPrompt(`${negativeBase}, ${presetNegative}, ${targetNegative}, ${moduleNegative}, ${stateNegative}, ${oralNegative}, ${roughOralNegative}, ${paizuriNegative}, ${handjobNegative}, ${analHandNegative}, ${fingerNegative}, ${groupPrimaryNegative}`)),
        ...(presetNegative || targetNegative || moduleNegative || stateNegative || oralGuard || paizuriGuard || handjobNegative || analHandNegative || fingerNegative || result.positionStateNegativeBase !== undefined ? { positionStateNegativeBase: negativeBase } : {}),
        parts: coercionConflicts ? parts.map(part => ({ ...part,
          tags: withoutPromptTags(part.tags, coercionConflicts) })) : parts,
        genParams: promptGenParams(prompt),
      };
    }

    function rememberLatestScenePrompt(result, state, character, characterId, promptArgs) {
      if (promptPreviewing) return result;
      if (characterId !== state.primaryCharacterId || !positionSituationId(result?.key)) return result;
      const situationId = positionSituationId(result.key);
      const activeSituationId = positionSituationId(activePortraitImageKey(result.key, state));
      if (activeSituationId && activeSituationId !== situationId) return result;
      latestPromptArgs = promptArgs.slice();
      if (latestScenePrompt?.situationId && latestScenePrompt.situationId !== situationId) {
        const previousOverride = positionOverride(latestScenePrompt.situationId);
        // Multi-person portraits can calculate another grp/gslot prompt before the queued key resolves.
        if (!previousOverride?.pendingPreviousKey) deletePositionOverride(latestScenePrompt.situationId);
      }
      const previousPrompt = latestScenePrompt?.result;
      latestScenePrompt = {
        result,
        situationId,
        characterId,
        characterName: String(character?.name || character?.shortname || '').trim(),
        controllerSceneIdentity: positionControllerSceneIdentity(state,
          basePositionSituationId(situationId).startsWith('scene-patron_') ? 'patron' : 'you'),
      };
      if (promptModPreview.result && (previousPrompt?.key !== result.key
        || previousPrompt.prompt !== result.prompt || previousPrompt.negativePrompt !== result.negativePrompt)) {
        promptModPreview.result = null;
        if (activeSettingsTab === 'prompt-mods') queueMicrotask(() => {
          if (settingsWindowHandle?.el?.isConnected !== false) settingsWindowHandle?.refresh();
        });
      }
      const choice = positionChoiceForImageKey(result.key, characterId);
      const groupSlots = choice?.groupSlots || positionGroupSlots(result.key);
      if (positionGroupCount(situationId) && !positionPlacementDrafts.has(situationId)) {
        positionPlacementDrafts.set(situationId, groupSlots);
      }
      if (positionSelection.situationId !== situationId || !positionSelection.manual) {
        positionSelection = {
          situationId,
          presetId: choice?.presetId || '',
          groupSlots: positionPlacementDrafts.get(situationId) || groupSlots,
          details: compactPositionDetails(choice?.details, positionGroupCount(situationId)),
          personPrompt: typeof choice?.personPrompt === 'string' ? choice.personPrompt : null,
          manual: Boolean(choice?.manual),
        };
      }
      return result;
    }
