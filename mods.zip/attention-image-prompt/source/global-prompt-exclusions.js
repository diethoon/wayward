    const globalPromptExclusions = { positive: '', negative: '' };
    const globalPromptExclusionSets = { positive: new Set(), negative: new Set() };
    let globalPromptExclusionHash = '';

    function globalPromptExclusionIdentity(value) {
      const text = String(value || '').trim();
      const wrapped = /^(\(+)\s*([\p{L}\p{N}_' -]+?)(?:\s*:\s*(-?(?:\d+(?:\.\d*)?|\.\d+)))?\s*(\)+)$/u.exec(text);
      const simple = wrapped && wrapped[1].length === wrapped[4].length ? wrapped[2]
        : /^[\p{L}\p{N}_' -]+$/u.test(text) ? text : '';
      return simple ? `tag:${simple.toLocaleLowerCase().replaceAll('_', ' ').replace(/\s+/g, ' ').trim()}`
        : text ? `literal:${text.toLocaleLowerCase()}` : '';
    }

    function setGlobalPromptExclusionCache(value, polarity) {
      if (!['positive', 'negative'].includes(polarity)) return false;
      const parsed = typeof value === 'string' && value.length <= 12000 ? splitFinalPrompt(value) : null;
      if (!parsed) return false;
      const identities = [...new Set(parsed.tokens.map(globalPromptExclusionIdentity).filter(Boolean))].sort();
      globalPromptExclusions[polarity] = value;
      globalPromptExclusionSets[polarity] = new Set(identities);
      const positive = [...globalPromptExclusionSets.positive], negative = [...globalPromptExclusionSets.negative];
      globalPromptExclusionHash = positive.length || negative.length ? shortHash(JSON.stringify([positive, negative])) : '';
      return true;
    }

    function currentGlobalPromptExclusions(polarity = 'positive') { return globalPromptExclusions[polarity] || ''; }
    function globalPromptExclusionsFingerprint() { return globalPromptExclusionHash; }
    function reloadGlobalPromptExclusions() {
      const saved = api.settings.get({ globalPromptExclusions: '', globalPromptExclusionsPositive: null, globalPromptExclusionsNegative: null });
      for (const polarity of ['positive', 'negative']) {
        const value = saved[polarity === 'positive' ? 'globalPromptExclusionsPositive' : 'globalPromptExclusionsNegative'];
        const legacy = typeof saved.globalPromptExclusions === 'string' ? saved.globalPromptExclusions : '';
        if (!setGlobalPromptExclusionCache(typeof value === 'string' ? value : legacy, polarity)) setGlobalPromptExclusionCache('', polarity);
      }
      legacyDetailImageKeys.clear();
      statusCacheAliases.clear();
    }
    function saveGlobalPromptExclusions(value, polarity = 'positive') {
      if (!['positive', 'negative'].includes(polarity) || typeof value !== 'string' || value.length > 12000 || !splitFinalPrompt(value)) return false;
      const key = polarity === 'positive' ? 'globalPromptExclusionsPositive' : 'globalPromptExclusionsNegative';
      try { api.settings.set({ [key]: value }); } catch { return false; }
      const previousHash = globalPromptExclusionHash;
      setGlobalPromptExclusionCache(value, polarity);
      if (previousHash !== globalPromptExclusionHash) {
        legacyDetailImageKeys.clear();
        statusCacheAliases.clear();
      }
      notifyExternalPromptChange();
      return true;
    }
    reloadGlobalPromptExclusions();

    function removeGlobalPromptExclusions(value, polarity = 'positive') {
      const blocked = globalPromptExclusionSets[polarity];
      if (!blocked || typeof value !== 'string' || !value || !blocked.size) return value;
      const parsed = splitFinalPrompt(value);
      if (!parsed) return value;
      const kept = parsed.tokens.map((token, index) => ({ token, index }))
        .filter(({ token }) => !blocked.has(globalPromptExclusionIdentity(token)));
      if (kept.length === parsed.tokens.length) return value;
      let output = '', previous = -1;
      for (const { token, index } of kept) {
        if (!token.trim()) continue;
        if (previous < 0) output = token.trimStart();
        else output += `${parsed.separators[previous] || ', '}${token}`;
        previous = index;
      }
      return output.trim();
    }

    function applyGlobalPromptExclusions(result) {
      if (!result || typeof result !== 'object' || !globalPromptExclusionHash) return result;
      const prompt = removeGlobalPromptExclusions(result.prompt, 'positive');
      const negativePrompt = removeGlobalPromptExclusions(result.negativePrompt, 'negative');
      const parts = Array.isArray(result.parts) ? result.parts.map(part => {
        if (!part || typeof part.tags !== 'string') return part;
        const tags = removeGlobalPromptExclusions(part.tags, 'positive');
        return tags === part.tags ? part : { ...part, tags };
      }) : result.parts;
      if (prompt === result.prompt && negativePrompt === result.negativePrompt
        && (!Array.isArray(parts) || parts.every((part, i) => part === result.parts[i]))) return result;
      return { ...result, ...(typeof result.prompt === 'string' ? { prompt } : {}),
        ...(typeof result.negativePrompt === 'string' ? { negativePrompt } : {}),
        ...(Array.isArray(parts) ? { parts } : {}) };
    }
