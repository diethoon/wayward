    function normalizeOutfitStates(value) {
      if (Array.isArray(value)) return [...new Set(value.filter(state => ALL_OUTFIT_STATES.includes(state) || state === EXPOSED_OUTFIT_STATE[0]))];
      if (value === 'nude') return ['nude'];
      if (value === 'clothed') return ['clothed', 'partial'];
      return [...ALL_OUTFIT_STATES];
    }

    function currentOutfitStates() {
      const saved = api.settings.get({ outfitStates: {}, outfitModes: {} });
      const states = {};
      for (const key of Object.keys(DEFAULT_OUTFIT_STATES)) {
        states[key] = Object.prototype.hasOwnProperty.call(saved.outfitStates || {}, key)
          ? normalizeOutfitStates(saved.outfitStates[key])
          : Object.prototype.hasOwnProperty.call(saved.outfitModes || {}, key)
            ? normalizeOutfitStates(saved.outfitModes[key])
            : [...DEFAULT_OUTFIT_STATES[key]];
      }
      return states;
    }

    function migrateExposedOutfitDefaults() {
      const saved = api.settings.get({ outfitStates: {}, outfitExposureDefaultsV1: false });
      if (saved.outfitExposureDefaultsV1) return;
      const outfitStates = { ...(saved.outfitStates || {}) };
      for (const key of Object.keys(DEFAULT_OUTFIT_STATES).filter(usesExposedDefault)) {
        if (!Object.prototype.hasOwnProperty.call(outfitStates, key)) outfitStates[key] = [...DEFAULT_OUTFIT_STATES[key]];
      }
      api.settings.set({ outfitStates, outfitExposureDefaultsV1: true });
    }
    migrateExposedOutfitDefaults();

    function migratedCrestNegativeDefaults(positiveSource, negativeSource, fillAbsent = true) {
      const positives = positiveSource && typeof positiveSource === 'object' && !Array.isArray(positiveSource) ? positiveSource : {};
      const negatives = negativeSource && typeof negativeSource === 'object' && !Array.isArray(negativeSource) ? negativeSource : {};
      const next = { ...negatives };
      for (let stage = 1; stage <= 5; stage++) {
        const key = `hstatus.crest.${stage}`;
        const previous = PREVIOUS_DEFAULT_PROMPTS[key];
        const knownDefaults = [DEFAULT_PROMPTS[key], ...(Array.isArray(previous) ? previous : [previous])];
        if ((fillAbsent || Object.prototype.hasOwnProperty.call(negatives, key))
          && (!Object.prototype.hasOwnProperty.call(positives, key) || knownDefaults.includes(positives[key]))
          && (!Object.prototype.hasOwnProperty.call(negatives, key) || negatives[key] === '')) {
          next[key] = DEFAULT_NEGATIVE_PROMPTS[key];
        }
      }
      return next;
    }

    function migrateCrestNegativeDefaults() {
      const saved = api.settings.get({ prompts: {}, negativePrompts: {}, situationPresets: [], crestNegativeDefaultsV1: false });
      if (saved.crestNegativeDefaultsV1) return;
      const situationPresets = Array.isArray(saved.situationPresets)
        ? saved.situationPresets.map(entry => entry && typeof entry === 'object' && !Array.isArray(entry)
          ? { ...entry, negativePrompts: migratedCrestNegativeDefaults(entry.prompts, entry.negativePrompts) } : entry)
        : saved.situationPresets;
      api.settings.set({
        negativePrompts: migratedCrestNegativeDefaults(saved.prompts, saved.negativePrompts),
        ...(Array.isArray(situationPresets) ? { situationPresets } : {}),
        crestNegativeDefaultsV1: true,
      });
    }
    migrateCrestNegativeDefaults();

    const FLUID_DECAY_PARTS = ['mouth', 'breasts', 'uterus'];
    const EXTERNAL_FLUID_TIER_VALUES = [0, 1, 3, 6, 10];

    function normalizeFluidDecaySettings(value) {
      return {
        enabled: value?.enabled !== false,
        intervalMinutes: Math.max(1, Math.min(1440, Math.floor(Number(value?.intervalMinutes) || DEFAULT_FLUID_DECAY.intervalMinutes))),
      };
    }

    function currentFluidDecaySettings() {
      return normalizeFluidDecaySettings(api.settings.get({ fluidDecay: DEFAULT_FLUID_DECAY }).fluidDecay);
    }

    function imageStudioResidueAvailable() {
      return typeof globalThis.WW_ImageStudioPrompt?.generate === 'function'
        && typeof globalThis.WW_ImageStudioPrompt?.open === 'function';
    }

    function savedResidueGenerationProvider() {
      return api.settings.get({ residueGenerationProvider: 'aip' }).residueGenerationProvider === 'imagestudio'
        ? 'imagestudio' : 'aip';
    }

    function currentResidueGenerationProvider() {
      return imageStudioResidueAvailable() ? savedResidueGenerationProvider() : 'aip';
    }

    function saveResidueGenerationProvider(provider) {
      if (!['aip', 'imagestudio'].includes(provider) || (provider === 'imagestudio' && !imageStudioResidueAvailable())) return;
      api.settings.set({ residueGenerationProvider: provider });
      scheduleUiScan();
    }

    function normalizeHStatusGenerationModes(value, legacyUterusEnabled = true) {
      const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
      return Object.fromEntries(FLUID_PARTS.map(({ part }) => {
        const fallback = part === 'uterus'
          ? legacyUterusEnabled === false ? 'text2img' : DEFAULT_H_STATUS_GENERATION_MODES.uterus
          : DEFAULT_H_STATUS_GENERATION_MODES[part];
        return [part, H_STATUS_GENERATION_MODE_VALUES.has(source[part]) ? source[part] : fallback];
      }));
    }

    function currentHStatusGenerationModes() {
      const settings = api.settings.get({ hStatusGenerationModes: {}, hStatusImg2Img: true });
      return normalizeHStatusGenerationModes(settings.hStatusGenerationModes, settings.hStatusImg2Img);
    }

    function saveHStatusGenerationMode(part, mode) {
      if (!FLUID_PARTS.some(entry => entry.part === part) || !H_STATUS_GENERATION_MODE_VALUES.has(mode)) return;
      const modes = { ...currentHStatusGenerationModes(), [part]: mode };
      api.settings.set({ hStatusGenerationModes: modes, hStatusImg2Img: modes.uterus === 'img2img' });
    }

    function hStatusImg2ImgEnabled(part) {
      return currentHStatusGenerationModes()[part] === 'img2img';
    }

    function relaxedFluidValue(part, value, steps) {
      if (part === 'uterus') return Math.max(0, value - steps);
      return EXTERNAL_FLUID_TIER_VALUES[Math.max(0, externalFluidTier(value) - steps)];
    }

    function applyFluidDecay(state, reset = false) {
      const settings = currentFluidDecaySettings();
      if (!state || !settings.enabled || !state.characters) return state;
      const now = Math.max(0, Math.floor(Number(state.slot) || 0));
      const modData = state.mods?.[api.id] || {};
      const savedTrackers = modData.fluidDecay?.characters || {};
      const trackers = { ...savedTrackers };
      let characters = state.characters;
      let changed = false;

      for (const [characterId, character] of Object.entries(state.characters)) {
        const stats = character?.situationStats;
        if (!stats?.fluidState || typeof stats.fluidState !== 'object') continue;
        const savedCharacterTrackers = savedTrackers[characterId] || {};
        const characterTrackers = { ...savedCharacterTrackers };
        let fluidState = stats.fluidState;
        let fluidChanged = false;

        for (const part of FLUID_DECAY_PARTS) {
          const value = Math.max(0, Math.floor(Number(fluidState[part]) || 0));
          const saved = savedCharacterTrackers[part];
          const lastUpdatedSlot = Number(saved?.lastUpdatedSlot);
          const trackedValue = Number(saved?.value);
          let nextValue = value;
          let nextSlot = now;

          if (!reset && Number.isFinite(lastUpdatedSlot) && trackedValue === value && now >= lastUpdatedSlot) {
            const steps = Math.floor((now - lastUpdatedSlot) / settings.intervalMinutes);
            nextValue = steps > 0 ? relaxedFluidValue(part, value, steps) : value;
            nextSlot = steps > 0 ? lastUpdatedSlot + steps * settings.intervalMinutes : lastUpdatedSlot;
          }

          if (nextValue !== value) {
            if (!fluidChanged) fluidState = { ...fluidState };
            fluidState[part] = nextValue;
            fluidChanged = true;
          }
          if (saved?.value !== nextValue || saved?.lastUpdatedSlot !== nextSlot) {
            characterTrackers[part] = { value: nextValue, lastUpdatedSlot: nextSlot };
            changed = true;
          }
        }

        if (fluidChanged) {
          if (characters === state.characters) characters = { ...state.characters };
          characters[characterId] = {
            ...character,
            situationStats: {
              ...stats,
              fluidState,
              dailyInternalEjaculationCount: fluidState.uterus,
            },
          };
          changed = true;
        }
        if (trackers[characterId] !== characterTrackers) trackers[characterId] = characterTrackers;
      }

      if (!changed) return state;
      return {
        ...state,
        characters,
        mods: {
          ...(state.mods || {}),
          [api.id]: { ...modData, fluidDecay: { characters: trackers } },
        },
      };
    }

    let syncingFluidDecay = false;
    function syncFluidDecay(reset = false) {
      if (syncingFluidDecay) return;
      const state = api.store.game();
      const next = applyFluidDecay(state, reset);
      if (!state || next === state) return;
      syncingFluidDecay = true;
      try {
        api.store.update(current => current === state ? next : applyFluidDecay(current, reset));
      } finally {
        syncingFluidDecay = false;
      }
    }
    api.store.subscribe(() => {
      syncFluidDecay();
      publishCurrentWifePromptProfile();
    });
    syncFluidDecay();
    publishCurrentWifePromptProfile();

    function normalizeDialogueRule(rule, index = 0) {
      if (!rule || typeof rule !== 'object') return null;
      const text = typeof rule.text === 'string' ? rule.text : '';
      const positivePrompt = typeof rule.positivePrompt === 'string' ? rule.positivePrompt : '';
      const negativePrompt = typeof rule.negativePrompt === 'string' ? rule.negativePrompt : '';
      return {
        id: typeof rule.id === 'string' && rule.id ? rule.id : `dialogue-import-${index + 1}-${shortHash(text)}`,
        text,
        positivePrompt,
        negativePrompt,
        duration: rule.duration === 'minutes' ? 'minutes' : 'scene',
        minutes: Math.max(1, Math.min(1440, Math.floor(Number(rule.minutes) || 10))),
        outfitStates: Object.prototype.hasOwnProperty.call(rule, 'outfitStates')
          ? normalizeOutfitStates(rule.outfitStates)
          : normalizeOutfitStates(rule.outfitMode),
      };
    }

    function currentDialogueRules() {
      const saved = api.settings.get({ dialogueRules: DEFAULT_DIALOGUE_RULES });
      return Array.isArray(saved.dialogueRules)
        ? saved.dialogueRules.map(normalizeDialogueRule).filter(Boolean)
        : DEFAULT_DIALOGUE_RULES.map(normalizeDialogueRule).filter(Boolean);
    }

    function normalizeSituationConfig(value) {
      const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
      return {
        prompts: { ...DEFAULT_PROMPTS, ...importedPrompts(source.prompts, DEFAULT_PROMPTS) },
        negativePrompts: { ...DEFAULT_NEGATIVE_PROMPTS, ...migratedBreathlessNegatives(source.prompts,
          importedPrompts(source.negativePrompts, DEFAULT_NEGATIVE_PROMPTS)) },
        outfitStates: { ...DEFAULT_OUTFIT_STATES, ...importedOutfitStates(source.outfitStates, source.outfitModes) },
        dialogueRules: Array.isArray(source.dialogueRules)
          ? source.dialogueRules.map(normalizeDialogueRule).filter(Boolean)
          : DEFAULT_DIALOGUE_RULES.map(normalizeDialogueRule).filter(Boolean),
      };
    }

    function normalizeSituationPresets(value) {
      if (!Array.isArray(value)) return [];
      const presets = [];
      const used = new Set([LEGACY_SITUATION_PRESET_ID]);
      for (const [index, entry] of value.slice(0, MAX_SITUATION_PRESETS).entries()) {
        if (!entry || typeof entry !== 'object' || Array.isArray(entry)) continue;
        let id = String(entry.id || '').trim();
        if (!/^[a-z0-9][a-z0-9_-]{0,79}$/i.test(id) || used.has(id)) id = `preset-${index + 1}-${shortHash(String(entry.name || index))}`;
        while (used.has(id)) id = `${id}-${presets.length + 1}`;
        used.add(id);
        presets.push({
          id,
          name: String(entry.name || '').trim().slice(0, 80) || `프리셋 ${presets.length + 1}`,
          ...normalizeSituationConfig(entry),
        });
      }
      return presets;
    }

    function currentSituationPresets() {
      return normalizeSituationPresets(api.settings.get({ situationPresets: [] }).situationPresets);
    }

    function currentFeaturePrompts() {
      const saved = api.settings.get({ featurePrompts: null }).featurePrompts;
      return { pregnancy: saved?.pregnancy === true, marks: saved?.marks === true,
        cycle: saved?.cycle === true, sleep: saved?.sleep === true,
        firstExperience: saved?.firstExperience !== false, erostat: saved?.erostat !== false };
    }

    function guestAppearanceEnabled() {
      return api.settings.get({ guestAppearance: true }).guestAppearance !== false;
    }

    function shortImageKeysEnabled() {
      return api.settings.get({ shortImageKeys: false }).shortImageKeys === true;
    }

    function saveShortImageKeys(enabled) {
      if (typeof enabled !== 'boolean') return false;
      try {
        api.settings.set({ shortImageKeys: enabled });
        return api.settings.get({ shortImageKeys: null }).shortImageKeys === enabled;
      } catch { return false; }
    }

    function legacySituationConfig() {
      return {
        id: LEGACY_SITUATION_PRESET_ID,
        name: '기본 프리셋',
        prompts: currentPrompts(),
        negativePrompts: currentNegativePrompts(),
        outfitStates: currentOutfitStates(),
        dialogueRules: currentDialogueRules(),
      };
    }

    function activeSituationConfig() {
      if (activeSituationPresetId === LEGACY_SITUATION_PRESET_ID) return legacySituationConfig();
      const preset = currentSituationPresets().find(entry => entry.id === activeSituationPresetId);
      if (preset) return preset;
      activeSituationPresetId = LEGACY_SITUATION_PRESET_ID;
      return legacySituationConfig();
    }

    function saveActiveSituationSection(section, value) {
      if (activeSituationPresetId === LEGACY_SITUATION_PRESET_ID) {
        api.settings.set({ [section]: value });
        return;
      }
      const presets = currentSituationPresets();
      if (!presets.some(entry => entry.id === activeSituationPresetId)) {
        activeSituationPresetId = LEGACY_SITUATION_PRESET_ID;
        api.settings.set({ [section]: value });
        return;
      }
      api.settings.set({
        situationPresets: presets.map(entry => entry.id === activeSituationPresetId ? { ...entry, [section]: value } : entry),
      });
    }

    function normalizeSituationPresetAssignments(value, presets = currentSituationPresets()) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      const presetIds = new Set([LEGACY_SITUATION_PRESET_ID, ...presets.map(entry => entry.id)]);
      return Object.fromEntries(Object.entries(value).flatMap(([characterId, presetId]) => {
        const id = String(characterId || '').trim();
        const selected = String(presetId ?? '');
        return id && id.length <= 120 && (selected === '' || presetIds.has(selected)) ? [[id, selected]] : [];
      }));
    }

    function currentSituationPresetAssignments(presets = currentSituationPresets()) {
      return normalizeSituationPresetAssignments(api.settings.get({ situationPresetAssignments: {} }).situationPresetAssignments, presets);
    }

    function situationPresetCharacterKeys(character, characterId) {
      const generated = character?.generatedArchetype;
      return [...new Set([
        generated?.id, generated?.shortname, character?.wifeArchetypeId, character?.archetypeId,
        character?.shortname, character?.id, characterId,
      ].map(value => String(value || '').trim()).filter(Boolean))];
    }

    function situationConfigForCharacter(character, characterId) {
      const presets = currentSituationPresets();
      const assignments = currentSituationPresetAssignments(presets);
      const assignedCharacter = situationPresetCharacterKeys(character, characterId)
        .find(id => Object.prototype.hasOwnProperty.call(assignments, id));
      const presetId = assignedCharacter ? assignments[assignedCharacter] : LEGACY_SITUATION_PRESET_ID;
      if (!presetId) return null;
      return presetId === LEGACY_SITUATION_PRESET_ID
        ? legacySituationConfig()
        : presets.find(entry => entry.id === presetId) || legacySituationConfig();
    }

    function isKnownBreathlessPrompt(key, value) {
      const erostatBand = /^erostat\.(?:fit|anal)\.(loose|snug|full|strain|limit)$/.exec(key)?.[1];
      if (!erostatBand) return false;
      if ([PREVIOUS_EROSTAT_BREATHLESS_PROMPTS[key], PREVIOUS_EROSTAT_BREATHLESS_PROMPTS_14193[key],
        PREVIOUS_EROSTAT_BREATHLESS_PROMPTS_14194[key]].includes(value)) return true;
      if (value === EROSTAT_BREATHLESS_PROMPTS[key]) return true;
      const previous = PREVIOUS_DEFAULT_PROMPTS[key];
      return erostatBand === 'strain' && Array.isArray(previous) && previous.slice(-2).some((base, index) =>
        value === `${base}, ${PREVIOUS_EROSTAT_BREATHLESS_STRAIN[index]}`);
    }

    function migratedPromptValue(key, value, defaults) {
      const previous = PREVIOUS_DEFAULT_PROMPTS[key];
      if (defaults === DEFAULT_PROMPTS && (Array.isArray(previous) ? previous.includes(value) : value === previous))
        return defaults[key];
      if (defaults === DEFAULT_PROMPTS && isKnownBreathlessPrompt(key, value)) return EROSTAT_BREATHLESS_PROMPTS[key];
      if (key === 'restraint.handcuffed') {
        if (defaults === DEFAULT_PROMPTS && [LEGACY_HANDCUFF_PROMPT, PREVIOUS_HANDCUFF_PROMPT].includes(value)) return DEFAULT_PROMPTS[key];
        if (defaults === DEFAULT_NEGATIVE_PROMPTS
          && [LEGACY_HANDCUFF_NEGATIVE_PROMPT, PREVIOUS_HANDCUFF_NEGATIVE_PROMPT].includes(value)) return DEFAULT_NEGATIVE_PROMPTS[key];
      }
      if (defaults === DEFAULT_NEGATIVE_PROMPTS && value === PREVIOUS_BREAST_JEWELRY_NEGATIVE_PROMPTS[key]) {
        return DEFAULT_NEGATIVE_PROMPTS[key];
      }
      const previousToyNegative = PREVIOUS_TOY_NEGATIVE_PROMPTS[key];
      if (defaults === DEFAULT_NEGATIVE_PROMPTS && (Array.isArray(previousToyNegative)
        ? previousToyNegative.includes(value) : value === previousToyNegative)) {
        return DEFAULT_NEGATIVE_PROMPTS[key];
      }
      if (defaults === DEFAULT_NEGATIVE_PROMPTS && key.startsWith('cycle.vulva.')
        && key !== 'cycle.vulva.menstrual' && value === 'menstrual blood, vaginal bleeding') return defaults[key];
      if (defaults === DEFAULT_NEGATIVE_PROMPTS && key === 'cycle.vulva.menstrual'
        && value === 'heavy bleeding, blood on legs, open wound') return defaults[key];
      if (defaults === DEFAULT_NEGATIVE_PROMPTS && key === 'sleep.waking-rub'
        && value === 'closed eyes, penetration, penis in pussy, fingering, fingers in pussy, handjob, fellatio, paizuri, red geometric mark on upper thigh, red painted symbol on hip, thigh tattoo') return defaults[key];
      return value;
    }

    function migratedBreathlessNegatives(positiveSource, negatives) {
      for (const key of Object.keys(PREVIOUS_EROSTAT_BREATHLESS_PROMPTS_14194)) {
        if ([PREVIOUS_EROSTAT_BREATHLESS_PROMPTS[key], PREVIOUS_EROSTAT_BREATHLESS_PROMPTS_14193[key],
          PREVIOUS_EROSTAT_BREATHLESS_PROMPTS_14194[key]].includes(positiveSource?.[key])
          && negatives[key] === EROSTAT_BREATHLESS_NEGATIVE)
          negatives[key] = DEFAULT_NEGATIVE_PROMPTS[key];
      }
      return negatives;
    }

    function importedPrompts(source, defaults) {
      const imported = {};
      if (!source || typeof source !== 'object' || Array.isArray(source)) return imported;
      for (const key of Object.keys(defaults)) {
        if (Object.prototype.hasOwnProperty.call(source, key) && typeof source[key] === 'string') {
          imported[key] = migratedPromptValue(key, source[key], defaults);
        }
      }
      return imported;
    }

    function importedOutfitStates(source, legacySource) {
      const imported = {};
      for (const key of Object.keys(DEFAULT_OUTFIT_STATES)) {
        if (source && typeof source === 'object' && !Array.isArray(source) && Object.prototype.hasOwnProperty.call(source, key)) {
          imported[key] = normalizeOutfitStates(source[key]);
        } else if (legacySource && typeof legacySource === 'object' && !Array.isArray(legacySource) && Object.prototype.hasOwnProperty.call(legacySource, key)) {
          imported[key] = normalizeOutfitStates(legacySource[key]);
        }
      }
      return imported;
    }

    function importPromptSettings(text) {
      const parsed = JSON.parse(text);
      const legacyCrestNegatives = !(Number(parsed?.version) >= 23);
      const positive = importedPrompts(parsed?.prompts ?? parsed, DEFAULT_PROMPTS);
      const importedNegative = importedPrompts(parsed?.negativePrompts, DEFAULT_NEGATIVE_PROMPTS);
      const negative = migratedBreathlessNegatives(parsed?.prompts ?? parsed,
        legacyCrestNegatives
          ? migratedCrestNegativeDefaults(parsed?.prompts ?? parsed, importedNegative, false)
          : importedNegative);
      const outfitStates = importedOutfitStates(parsed?.outfitStates, parsed?.outfitModes);
      const hasDialogueRules = Array.isArray(parsed?.dialogueRules);
      const hasFluidDecay = parsed?.fluidDecay && typeof parsed.fluidDecay === 'object' && !Array.isArray(parsed.fluidDecay);
      const hasResidueGenerationProvider = ['aip', 'imagestudio'].includes(parsed?.residueGenerationProvider);
      const hasHStatusImg2Img = typeof parsed?.hStatusImg2Img === 'boolean';
      const hasHStatusGenerationModes = parsed?.hStatusGenerationModes && typeof parsed.hStatusGenerationModes === 'object' && !Array.isArray(parsed.hStatusGenerationModes);
      const hasResiduePrompts = parsed?.residuePrompts && typeof parsed.residuePrompts === 'object' && !Array.isArray(parsed.residuePrompts);
      const hasResiduePartSources = parsed?.residuePartSources && typeof parsed.residuePartSources === 'object' && !Array.isArray(parsed.residuePartSources);
      const hasCustomTags = Array.isArray(parsed?.customTags);
      const hasPromptPresets = Array.isArray(parsed?.promptPresets);
      const hasErostatPromptPresets = Array.isArray(parsed?.erostatPromptPresets);
      const hasErostatPromptBundles = Array.isArray(parsed?.erostatPromptBundles);
      const hasGameDefaultPrompts = parsed?.gameDefaultPrompts !== undefined;
      const hasCameraSceneSettings = parsed?.cameraSceneSettings && typeof parsed.cameraSceneSettings === 'object' && !Array.isArray(parsed.cameraSceneSettings);
      const hasCameraImageMetadata = parsed?.cameraImageMetadata && typeof parsed.cameraImageMetadata === 'object' && !Array.isArray(parsed.cameraImageMetadata);
      if (hasCameraSceneSettings && Object.hasOwn(parsed, 'cameraPresetRevision')
        && (!Number.isSafeInteger(parsed.cameraPresetRevision) || parsed.cameraPresetRevision < 0))
        throw new Error('카메라 구도 기본값 버전이 올바르지 않습니다.');
      const hasGlobalPromptExclusions = ['globalPromptExclusions', 'globalPromptExclusionsPositive', 'globalPromptExclusionsNegative']
        .some(key => Object.hasOwn(parsed || {}, key));
      for (const key of ['globalPromptExclusions', 'globalPromptExclusionsPositive', 'globalPromptExclusionsNegative']) {
        if (Object.hasOwn(parsed || {}, key) && (typeof parsed[key] !== 'string'
          || parsed[key].length > 12000 || !splitFinalPrompt(parsed[key])))
          throw new Error('전역 제거 프롬프트가 올바르지 않습니다.');
      }
      const hasCharacterPrompt = parsed?.characterPrompt && typeof parsed.characterPrompt === 'object' && !Array.isArray(parsed.characterPrompt);
      const hasOutfitPrompts = parsed?.outfitPrompts && typeof parsed.outfitPrompts === 'object' && !Array.isArray(parsed.outfitPrompts);
      const hasCustomOutfits = Array.isArray(parsed?.customOutfits);
      const hasPositionPresetPrompts = parsed?.positionPresetPrompts && typeof parsed.positionPresetPrompts === 'object' && !Array.isArray(parsed.positionPresetPrompts);
      const hasPositionGroupPrompts = parsed?.positionGroupPrompts && typeof parsed.positionGroupPrompts === 'object' && !Array.isArray(parsed.positionGroupPrompts);
      const hasPositionStatePrompts = parsed?.positionStatePrompts && typeof parsed.positionStatePrompts === 'object' && !Array.isArray(parsed.positionStatePrompts);
      const hasButtonPromptRules = Array.isArray(parsed?.buttonPromptRules);
      const hasSceneBaseOverrides = parsed?.sceneBaseOverrides && typeof parsed.sceneBaseOverrides === 'object' && !Array.isArray(parsed.sceneBaseOverrides);
      const hasSceneCandidatePools = parsed?.sceneCandidatePools && typeof parsed.sceneCandidatePools === 'object' && !Array.isArray(parsed.sceneCandidatePools);
      const hasSceneStatePromptOverrides = parsed?.sceneStatePromptOverrides && typeof parsed.sceneStatePromptOverrides === 'object' && !Array.isArray(parsed.sceneStatePromptOverrides);
      const hasStateEditorGlobalChanges = parsed?.stateEditorGlobalChanges && typeof parsed.stateEditorGlobalChanges === 'object' && !Array.isArray(parsed.stateEditorGlobalChanges);
      const hasPositionTargetNegatives = parsed?.positionTargetNegativePrompts && typeof parsed.positionTargetNegativePrompts === 'object' && !Array.isArray(parsed.positionTargetNegativePrompts);
      const positionTargetSections = Array.isArray(parsed?.positionTargetNegativeSections)
        ? parsed.positionTargetNegativeSections.filter(kind => ['position-preset', 'position-group'].includes(kind))
        : ['position-preset', 'position-group'];
      const positionTargetNegatives = hasPositionTargetNegatives ? Object.fromEntries(
        Object.entries(parsed.positionTargetNegativePrompts).flatMap(([key, value]) => {
          const separator = key.indexOf(':');
          const kind = key.slice(0, separator), id = key.slice(separator + 1);
          const valid = kind === 'position-preset' ? Object.hasOwn(POSITION_PRESETS, id)
            : kind === 'position-group' && Object.hasOwn(GROUP_SLOT_BY_ID, id);
          return valid && positionTargetSections.includes(kind) && typeof value === 'string' ? [[key, value.slice(0, 12000)]] : [];
        })) : {};
      const hasPositionRules = parsed?.positionRules && typeof parsed.positionRules === 'object' && !Array.isArray(parsed.positionRules);
      const hasPositionMode = parsed?.positionMode === 'legacy' || parsed?.positionMode === 'modules';
      const hasGuestAppearance = typeof parsed?.guestAppearance === 'boolean';
      const hasPositionModules = Array.isArray(parsed?.positionModules);
      const hasPositionModuleSelections = parsed?.positionModuleSelections && typeof parsed.positionModuleSelections === 'object' && !Array.isArray(parsed.positionModuleSelections);
      const hasPositionModuleGroupLayouts = parsed?.positionModuleGroupLayouts && typeof parsed.positionModuleGroupLayouts === 'object' && !Array.isArray(parsed.positionModuleGroupLayouts);
      const hasPositionModulePoseAssignments = parsed?.positionModulePoseAssignments && typeof parsed.positionModulePoseAssignments === 'object' && !Array.isArray(parsed.positionModulePoseAssignments);
      const hasPositionModulePrompts = parsed?.positionModulePrompts && typeof parsed.positionModulePrompts === 'object' && !Array.isArray(parsed.positionModulePrompts);
      const hasControllerButtonCatalog = Array.isArray(parsed?.controllerButtonCatalog);
      const hasPositionDanbooruTags = Array.isArray(parsed?.positionDanbooruTags);
      const hasPromptModRules = Array.isArray(parsed?.promptModRules);
      const hasExternalPromptData = Array.isArray(parsed?.externalPromptData);
      const hasExternalPromptPresets = Array.isArray(parsed?.externalPromptPresets);
      const featurePrompts = parsed?.featurePrompts && typeof parsed.featurePrompts === 'object'
        && !Array.isArray(parsed.featurePrompts)
        ? Object.fromEntries(['pregnancy', 'marks', 'cycle', 'sleep', 'firstExperience', 'erostat']
          .filter(key => typeof parsed.featurePrompts[key] === 'boolean')
          .map(key => [key, parsed.featurePrompts[key]])) : {};
      const hasFeaturePrompts = Object.keys(featurePrompts).length > 0;
      const hasPositionRuleDefaults = parsed?.positionRuleDefaults && typeof parsed.positionRuleDefaults === 'object' && !Array.isArray(parsed.positionRuleDefaults);
      const hasAutoPositionPresets = typeof parsed?.autoPositionPresets === 'boolean';
      const hasSituationPresets = Array.isArray(parsed?.situationPresets);
      const hasSituationPresetAssignments = parsed?.situationPresetAssignments && typeof parsed.situationPresetAssignments === 'object' && !Array.isArray(parsed.situationPresetAssignments);
      const hasDetailGrouping = typeof parsed?.groupSimilarDetailStates === 'boolean';
      const hasShortImageKeys = typeof parsed?.shortImageKeys === 'boolean';
      const hasGenerationWeightEnabled = typeof parsed?.generationWeightEnabled === 'boolean';
      const hasGenerationWeightPercent = typeof parsed?.generationWeightPercent === 'number' && Number.isFinite(parsed.generationWeightPercent);
      const generationWeightKeys = ['generationWeightStepsPercent', 'generationWeightCfgPercent', 'generationWeightLoraPercent'];
      const importedGenerationWeights = Object.fromEntries(generationWeightKeys.flatMap(key => {
        const value = parsed?.[key];
        const valid = typeof value === 'number' && Number.isFinite(value);
        if (!valid && !hasGenerationWeightPercent) return [];
        return [[key, Math.max(0, Math.min(200, Math.round(valid ? value : parsed.generationWeightPercent)))]];
      }));
      const situationPresets = hasSituationPresets ? normalizeSituationPresets(legacyCrestNegatives
        ? parsed.situationPresets.map(entry => entry && typeof entry === 'object' && !Array.isArray(entry)
          ? { ...entry, negativePrompts: migratedCrestNegativeDefaults(entry.prompts, entry.negativePrompts, false) } : entry)
        : parsed.situationPresets) : currentSituationPresets();
      const hasDefaultPromptSection = ['prompts', 'negativePrompts'].some(key =>
        parsed?.[key] && typeof parsed[key] === 'object' && !Array.isArray(parsed[key]));
      const importedStateChanges = hasStateEditorGlobalChanges
        ? normalizeStateEditorGlobalChanges(parsed.stateEditorGlobalChanges) : {};
      let mergedStateChanges = importedStateChanges;
      if (hasStateEditorGlobalChanges && (hasDefaultPromptSection || hasSituationPresets)) {
        mergedStateChanges = { ...currentStateEditorGlobalChanges() };
        if (hasSituationPresets) {
          for (const preset of situationPresets) {
            delete mergedStateChanges[preset.id];
            if (importedStateChanges[preset.id]) mergedStateChanges[preset.id] = importedStateChanges[preset.id];
          }
        }
        if (hasDefaultPromptSection && importedStateChanges[LEGACY_SITUATION_PRESET_ID]) {
          mergedStateChanges[LEGACY_SITUATION_PRESET_ID] = [...new Set([
            ...(mergedStateChanges[LEGACY_SITUATION_PRESET_ID] || []),
            ...importedStateChanges[LEGACY_SITUATION_PRESET_ID],
          ])];
        }
        mergedStateChanges = normalizeStateEditorGlobalChanges(mergedStateChanges);
      }
      const positionRules = hasPositionRules ? normalizePositionRules(parsed.positionRules) : currentPositionRules();
      const importedPositionModules = [...BUILTIN_POSITION_MODULES,
        ...(hasPositionModules ? normalizePositionModules(parsed.positionModules) : currentPositionModules()),
        ...normalizeControllerButtonCatalog([...CONTROLLER_SEED_CATALOG,
          ...(hasControllerButtonCatalog ? normalizeControllerButtonCatalog(parsed.controllerButtonCatalog) : currentControllerButtonCatalog())])
          .map(entry => ({ id: entry.id, kind: controllerButtonKind(entry),
            controllerScope: entry.scope, controllerGroup: entry.group, controllerLabel: entry.label }))];
      const wives = Array.isArray(parsed?.wives) ? parsed.wives.filter(entry =>
        entry && typeof entry === 'object'
        && typeof entry.id === 'string' && entry.id.trim()
        && entry.inputs && typeof entry.inputs === 'object' && !Array.isArray(entry.inputs)) : [];
        if (!Object.keys(positive).length && !Object.keys(negative).length && !Object.keys(outfitStates).length && !hasDialogueRules && !hasFluidDecay && !hasHStatusImg2Img && !hasHStatusGenerationModes && !hasResiduePrompts && !hasResiduePartSources && !hasCustomTags && !hasPromptPresets && !hasErostatPromptPresets && !hasGameDefaultPrompts && !hasCameraSceneSettings && !hasCameraImageMetadata && !hasGlobalPromptExclusions && !hasCharacterPrompt && !hasOutfitPrompts && !hasCustomOutfits && !hasPositionPresetPrompts && !hasPositionGroupPrompts && !hasPositionStatePrompts && !hasButtonPromptRules && !hasPositionRules && !hasPositionMode && !hasGuestAppearance && !hasPositionModules && !hasPositionModuleSelections && !hasPositionModuleGroupLayouts && !hasPositionModulePoseAssignments && !hasPositionModulePrompts && !hasControllerButtonCatalog && !hasPositionDanbooruTags && !hasPromptModRules && !hasExternalPromptData && !hasExternalPromptPresets && !hasFeaturePrompts && !hasPositionRuleDefaults && !hasAutoPositionPresets && !hasSituationPresets && !hasSituationPresetAssignments && !hasDetailGrouping && !hasShortImageKeys && !hasGenerationWeightEnabled && !hasGenerationWeightPercent && !Object.keys(importedGenerationWeights).length && !wives.length && !hasSceneBaseOverrides && !hasSceneCandidatePools && !hasSceneStatePromptOverrides && !hasStateEditorGlobalChanges) throw new Error('가져올 수 있는 설정 항목이 없습니다.');
      for (const entry of wives) {
        customWifeStore.getState().save({
          id: entry.id.trim(),
          inputs: { ...entry.inputs },
          ...(typeof entry.portraitKey === 'string' ? { portraitKey: entry.portraitKey } : {}),
          ...(typeof entry.portraitUrl === 'string' ? { portraitUrl: entry.portraitUrl } : {}),
        });
      }
      const hStatusGenerationModes = hasHStatusGenerationModes
        ? normalizeHStatusGenerationModes(parsed.hStatusGenerationModes, hasHStatusImg2Img ? parsed.hStatusImg2Img : true)
        : hasHStatusImg2Img ? normalizeHStatusGenerationModes({}, parsed.hStatusImg2Img) : currentHStatusGenerationModes();
      if (hasCustomOutfits && parsed.customOutfits.length > 100)
        throw new Error('사용자 의상은 최대 100개까지 가져올 수 있습니다.');
      const customOutfits = [...new Map([...currentCustomOutfits(),
        ...(hasCustomOutfits ? normalizeCustomOutfits(parsed.customOutfits) : [])].map(entry => [entry.id, entry])).values()];
      if (customOutfits.length > 100) throw new Error('사용자 의상은 최대 100개까지 가져올 수 있습니다.');
      return {
        groupSimilarDetailStates: hasDetailGrouping ? parsed.groupSimilarDetailStates : groupSimilarDetailStates(),
        ...(hasShortImageKeys ? { shortImageKeys: parsed.shortImageKeys } : {}),
        ...(hasGenerationWeightEnabled ? { generationWeightEnabled: parsed.generationWeightEnabled } : {}),
        ...(hasGenerationWeightPercent
          ? { generationWeightPercent: Math.max(0, Math.min(200, Math.round(parsed.generationWeightPercent))) } : {}),
        ...importedGenerationWeights,
        gameDefaultPrompts: hasGameDefaultPrompts ? normalizeGameDefaultPrompts(parsed.gameDefaultPrompts) : currentGameDefaultPrompts(),
        ...(hasCameraSceneSettings ? { cameraSceneSettings: normalizeCameraSettings(parsed.cameraSceneSettings),
          cameraPresetRevision: Object.hasOwn(parsed, 'cameraPresetRevision') ? parsed.cameraPresetRevision : 0 } : {}),
        ...(hasCameraImageMetadata ? { cameraImageMetadata: normalizeCameraImageMetadata(parsed.cameraImageMetadata) } : {}),
        ...((Object.hasOwn(parsed || {}, 'globalPromptExclusionsPositive') || Object.hasOwn(parsed || {}, 'globalPromptExclusions'))
          ? { globalPromptExclusionsPositive: parsed.globalPromptExclusionsPositive ?? parsed.globalPromptExclusions } : {}),
        ...((Object.hasOwn(parsed || {}, 'globalPromptExclusionsNegative') || Object.hasOwn(parsed || {}, 'globalPromptExclusions'))
          ? { globalPromptExclusionsNegative: parsed.globalPromptExclusionsNegative ?? parsed.globalPromptExclusions } : {}),
        characterPrompt: hasCharacterPrompt ? normalizeCharacterPrompt(parsed.characterPrompt) : currentCharacterPrompt(),
        outfitPrompts: hasOutfitPrompts ? normalizeOutfitPrompts(parsed.outfitPrompts) : currentOutfitPrompts(),
        customOutfits,
        situationPresets,
        situationPresetAssignments: hasSituationPresetAssignments
          ? normalizeSituationPresetAssignments(parsed.situationPresetAssignments, situationPresets)
          : currentSituationPresetAssignments(situationPresets),
        positionPresetPrompts: hasPositionPresetPrompts ? normalizePositionPresetPrompts(parsed.positionPresetPrompts) : currentPositionPresetPrompts(),
        positionGroupPrompts: hasPositionGroupPrompts ? normalizePositionGroupPrompts(parsed.positionGroupPrompts) : currentPositionGroupPrompts(),
        positionStatePrompts: hasPositionStatePrompts ? normalizePositionStatePrompts(parsed.positionStatePrompts) : currentPositionStatePrompts(),
        ...(hasButtonPromptRules ? { buttonPromptRules: normalizeButtonPromptRules(parsed.buttonPromptRules) } : {}),
        ...(hasSceneBaseOverrides ? { sceneBaseOverrides: normalizeSceneBaseOverrides(parsed.sceneBaseOverrides) } : {}),
        ...(hasSceneCandidatePools ? { sceneCandidatePools: normalizeSceneCandidatePools(parsed.sceneCandidatePools) } : {}),
        ...(hasSceneStatePromptOverrides ? { sceneStatePromptOverrides: normalizeSceneStatePromptOverrides(parsed.sceneStatePromptOverrides) } : {}),
        ...(hasStateEditorGlobalChanges ? { stateEditorGlobalChanges: mergedStateChanges } : {}),
        ...(hasPositionTargetNegatives ? { positionTargetNegativePrompts: {
          ...Object.fromEntries(Object.entries(currentPositionTargetNegativePrompts()).filter(([key]) =>
            !positionTargetSections.includes(key.split(':')[0]))), ...positionTargetNegatives,
        } } : {}),
        positionMode: hasPositionMode ? parsed.positionMode : positionMode(),
        ...(hasGuestAppearance ? { guestAppearance: parsed.guestAppearance } : {}),
        positionModules: hasPositionModules ? normalizePositionModules(parsed.positionModules) : currentPositionModules(),
        positionModulePrompts: hasPositionModulePrompts ? normalizePositionModulePrompts(parsed.positionModulePrompts) : currentPositionModulePrompts(),
        controllerButtonCatalog: hasControllerButtonCatalog ? normalizeControllerButtonCatalog(parsed.controllerButtonCatalog)
          : normalizeControllerButtonCatalog(api.settings.get({ controllerButtonCatalog: [] }).controllerButtonCatalog),
        positionDanbooruTags: hasPositionDanbooruTags ? normalizePositionDanbooruTags(parsed.positionDanbooruTags) : currentPositionDanbooruTags(),
        positionModuleSelections: hasPositionModuleSelections
          ? normalizePositionModuleSelections(parsed.positionModuleSelections, importedPositionModules)
          : currentPositionModuleSelections(),
        positionModuleGroupLayouts: hasPositionModuleGroupLayouts
          ? normalizePositionModuleGroupLayouts(parsed.positionModuleGroupLayouts)
          : currentPositionModuleGroupLayouts(),
        positionModulePoseAssignments: hasPositionModulePoseAssignments
          ? normalizePositionModulePoseAssignments(parsed.positionModulePoseAssignments, importedPositionModules)
          : currentPositionModulePoseAssignments(),
        positionRules,
        promptModRules: hasPromptModRules ? normalizePromptModRules(parsed.promptModRules) : currentPromptModRules(),
        externalPromptData: hasExternalPromptData ? normalizeExternalPromptData(parsed.externalPromptData) : currentExternalPromptData(),
        externalPromptPresets: hasExternalPromptPresets ? normalizeExternalPromptPresets(parsed.externalPromptPresets) : currentExternalPromptPresets(),
        ...(hasFeaturePrompts ? { featurePrompts: { ...currentFeaturePrompts(), ...featurePrompts } } : {}),
        positionRuleDefaults: hasPositionRuleDefaults
          ? normalizePositionRuleDefaults(parsed.positionRuleDefaults, positionRules)
          : currentPositionRuleDefaults(positionRules),
        autoPositionPresets: hasAutoPositionPresets ? parsed.autoPositionPresets : autoPositionPresets(),
        prompts: { ...currentPrompts(), ...positive },
        negativePrompts: { ...currentNegativePrompts(), ...negative },
        outfitStates: { ...currentOutfitStates(), ...outfitStates },
        dialogueRules: hasDialogueRules ? parsed.dialogueRules.map(normalizeDialogueRule).filter(Boolean) : currentDialogueRules(),
        fluidDecay: hasFluidDecay ? normalizeFluidDecaySettings(parsed.fluidDecay) : currentFluidDecaySettings(),
        residueGenerationProvider: hasResidueGenerationProvider ? parsed.residueGenerationProvider : savedResidueGenerationProvider(),
        hStatusGenerationModes,
        hStatusImg2Img: hStatusGenerationModes.uterus === 'img2img',
        residuePrompts: hasResiduePrompts ? normalizeResiduePrompts(parsed.residuePrompts) : currentResiduePrompts(),
        residuePartSources: hasResiduePartSources ? normalizeResiduePartSources(parsed.residuePartSources) : currentResiduePartSources(),
        customTags: hasCustomTags ? normalizeCustomTags(parsed.customTags) : currentCustomTags(),
        promptPresets: hasPromptPresets ? normalizePromptPresets(parsed.promptPresets) : currentPromptPresets(),
        erostatPromptPresets: hasErostatPromptPresets ? normalizeErostatPromptPresets(parsed.erostatPromptPresets) : currentErostatPromptPresets(),
        erostatPromptBundles: hasErostatPromptBundles ? normalizeErostatPromptBundles(parsed.erostatPromptBundles) : currentErostatPromptBundles(),
      };
    }

    function promptSettingsSnapshot(onlySections) {
      const selected = Array.isArray(onlySections)
        ? onlySections.filter(key => Object.prototype.hasOwnProperty.call(exportSections, key))
        : Object.keys(exportSections).filter(key => exportSections[key]);
      if (!selected.length) return false;
      const data = {
        format: 'wayward-state-image-prompts',
        version: 23,
      };
      if (selected.includes('wives')) data.wives = (customWifeStore.getState().wives || []).map(entry => ({
        id: entry.id,
        inputs: { ...entry.inputs },
        ...(typeof entry.portraitKey === 'string' ? { portraitKey: entry.portraitKey } : {}),
        ...(typeof entry.portraitUrl === 'string' ? { portraitUrl: entry.portraitUrl } : {}),
      }));
      if (selected.includes('gameDefaultPrompts')) {
        data.gameDefaultPrompts = currentGameDefaultPrompts();
        data.globalPromptExclusionsPositive = currentGlobalPromptExclusions('positive');
        data.globalPromptExclusionsNegative = currentGlobalPromptExclusions('negative');
      }
      if (selected.includes('cameraSettings')) {
        data.cameraSceneSettings = normalizeCameraSettings(cameraSceneSettings);
        data.cameraImageMetadata = normalizeCameraImageMetadata(cameraImageMetadata);
        data.cameraPresetRevision = api.settings.get({ cameraPresetRevision: 0 }).cameraPresetRevision;
      }
      if (selected.includes('characterPrompt')) data.characterPrompt = currentCharacterPrompt();
      if (selected.includes('outfitPrompts')) data.outfitPrompts = currentOutfitPrompts();
      if (selected.includes('customOutfits')) data.customOutfits = currentCustomOutfits();
      if (selected.includes('situationPresets')) {
        data.situationPresets = currentSituationPresets();
        data.situationPresetAssignments = currentSituationPresetAssignments(data.situationPresets);
      }
      if (selected.includes('positionPresetPrompts')) data.positionPresetPrompts = currentPositionPresetPrompts();
      if (selected.includes('positionGroupPrompts')) data.positionGroupPrompts = currentPositionGroupPrompts();
      if (selected.includes('positionStatePrompts')) data.positionStatePrompts = currentPositionStatePrompts();
      if (selected.includes('buttonPromptRules')) data.buttonPromptRules = buttonPromptRules;
      if (selected.includes('sceneBaseOverrides')) {
        data.sceneBaseOverrides = sceneBaseOverrides;
        data.sceneCandidatePools = currentSceneCandidatePools();
      }
      if (selected.includes('sceneStatePromptOverrides')) data.sceneStatePromptOverrides = currentSceneStatePromptOverrides();
      const exportedStateEdits = Object.fromEntries(Object.entries(currentStateEditorGlobalChanges()).filter(([id]) =>
        id === LEGACY_SITUATION_PRESET_ID ? selected.includes('prompts') || selected.includes('negativePrompts')
          : selected.includes('situationPresets')));
      if (Object.keys(exportedStateEdits).length) data.stateEditorGlobalChanges = exportedStateEdits;
      const positionTargetSections = [
        ...(selected.includes('positionPresetPrompts') ? ['position-preset'] : []),
        ...(selected.includes('positionGroupPrompts') ? ['position-group'] : []),
      ];
      if (positionTargetSections.length) {
        data.positionTargetNegativeSections = positionTargetSections;
        data.positionTargetNegativePrompts = Object.fromEntries(Object.entries(currentPositionTargetNegativePrompts())
          .filter(([key]) => positionTargetSections.includes(key.split(':')[0])));
      }
      if (selected.includes('positionModules')) {
        data.positionMode = positionMode();
        data.guestAppearance = guestAppearanceEnabled();
        data.positionModules = currentPositionModules();
        data.positionModulePrompts = currentPositionModulePrompts();
        data.controllerButtonCatalog = normalizeControllerButtonCatalog(api.settings.get({ controllerButtonCatalog: [] }).controllerButtonCatalog)
          .filter(entry => !CONTROLLER_SEED_CATALOG.some(seed => seed.key === entry.key));
        data.positionDanbooruTags = currentPositionDanbooruTags();
        data.positionModuleSelections = currentPositionModuleSelections();
        data.positionModuleGroupLayouts = currentPositionModuleGroupLayouts();
        data.positionModulePoseAssignments = currentPositionModulePoseAssignments();
      }
      if (selected.includes('positionRules')) {
        data.positionRules = currentPositionRules();
        data.positionRuleDefaults = currentPositionRuleDefaults(data.positionRules);
        data.autoPositionPresets = autoPositionPresets();
      }
      if (selected.includes('promptModRules')) data.promptModRules = currentPromptModRules();
      if (selected.includes('externalPrompts')) {
        data.externalPromptData = currentExternalPromptData();
        data.externalPromptPresets = currentExternalPromptPresets();
      }
      if (selected.includes('featurePrompts')) data.featurePrompts = currentFeaturePrompts();
      if (selected.includes('shortImageKeys')) data.shortImageKeys = shortImageKeysEnabled();
      if (selected.includes('generationWeight')) {
        const weights = generationWeightSettings();
        data.generationWeightEnabled = weights.enabled;
        data.generationWeightPercent = weights.percent;
        data.generationWeightStepsPercent = weights.stepsPercent;
        data.generationWeightCfgPercent = weights.cfgPercent;
        data.generationWeightLoraPercent = weights.loraPercent;
      }
      if (selected.includes('prompts')) {
        data.groupSimilarDetailStates = groupSimilarDetailStates();
        data.prompts = currentPrompts();
      }
      if (selected.includes('negativePrompts')) data.negativePrompts = currentNegativePrompts();
      if (selected.includes('outfitStates')) data.outfitStates = currentOutfitStates();
      if (selected.includes('dialogueRules')) data.dialogueRules = currentDialogueRules();
      if (selected.includes('fluidDecay')) data.fluidDecay = currentFluidDecaySettings();
      if (selected.includes('residueGenerationProvider')) data.residueGenerationProvider = savedResidueGenerationProvider();
      if (selected.includes('hStatusGenerationModes')) {
        data.hStatusGenerationModes = currentHStatusGenerationModes();
        data.hStatusImg2Img = data.hStatusGenerationModes.uterus === 'img2img';
      }
      if (selected.includes('residuePrompts')) data.residuePrompts = currentResiduePrompts();
      if (selected.includes('residuePartSources')) data.residuePartSources = currentResiduePartSources();
      if (selected.includes('customTags')) data.customTags = currentCustomTags();
      if (selected.includes('promptPresets')) data.promptPresets = currentPromptPresets();
      if (selected.includes('erostatPromptPresets')) data.erostatPromptPresets = currentErostatPromptPresets();
      if (selected.includes('erostatPromptBundles')) data.erostatPromptBundles = currentErostatPromptBundles();
      return data;
    }

    function exportPrompts(onlySections) {
      const selected = Array.isArray(onlySections) ? onlySections.filter(key => Object.hasOwn(exportSections, key))
        : Object.keys(exportSections).filter(key => exportSections[key]);
      const data = promptSettingsSnapshot(selected);
      if (!data) return false;
      const text = JSON.stringify(data, null, 2);
      const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
      const link = document.createElement('a');
      link.href = url;
      link.download = selected.length === 1 && selected[0] === 'wives'
        ? 'wayward-custom-wives.json'
        : selected.length === 1 && selected[0] === 'situationPresets'
          ? 'wayward-situation-prompt-presets.json'
        : selected.length === 1 && selected[0] === 'positionRules'
          ? 'wayward-position-presets.json'
        : selected.every(key => ['residueGenerationProvider', 'hStatusGenerationModes', 'residuePrompts', 'residuePartSources'].includes(key))
          ? 'wayward-residue-image-prompts.json'
          : 'wayward-state-image-prompts.json';
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      return true;
    }
