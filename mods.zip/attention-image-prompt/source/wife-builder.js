    function applySavedWifeMetadata(archetype, inputs, fullPrompt, fullNegative) {
      if (!archetype || !inputs) return archetype;
      const marker = inputs.__attentionImagePromptArchetype;
      const normalizedMarker = normalizeCharacterPrompt(marker);
      const englishName = String(inputs.__attentionImageEnglishName || '').trim();
      const shortname = wifeImageName(inputs.__attentionImageShortname || englishName);
      let result = shortname || englishName ? {
        ...archetype,
        ...(shortname ? { shortname } : {}),
        ...(englishName ? { englishName } : {}),
      } : archetype;
      const rawPositivePrompt = joinPrompt(`${String(fullPrompt || inputs.customAppearance || '').trim()
        || normalizedMarker.positivePrompt}, ${wifeOutfitColorPrompt(inputs)}`);
      const hasStoredNegative = Object.prototype.hasOwnProperty.call(inputs, '__attentionImageNegativePrompt');
      const hasMarkerNegative = typeof marker?.negativePrompt === 'string';
      const hasNegativeOverride = fullNegative !== undefined || hasStoredNegative || hasMarkerNegative;
      const negativePrompt = normalizedWifeNegative(fullNegative !== undefined
        ? fullNegative
        : hasStoredNegative
          ? inputs.__attentionImageNegativePrompt
          : normalizedMarker.negativePrompt);
      const positivePrompt = withoutPromptTags(rawPositivePrompt, negativePrompt);
      result = {
        ...result,
        attentionExtraLinesArchetypeId: wifeDialogueArchetypeId(inputs),
        attentionImageOutfitColors: wifeOutfitColors(inputs),
        ...(inputs.__attentionFirstExperience ? { __attentionFirstExperience: { ...inputs.__attentionFirstExperience } } : {}),
      };
      if (positivePrompt || hasNegativeOverride) {
        const appliedPrompt = {
          positivePrompt,
          negativePrompt,
          mode: 'replace',
          imagePolicy: 'reuse',
        };
        result = {
          ...result,
          imageBase: positivePrompt || result.imageBase,
          attentionImagePrompt: appliedPrompt,
          ...(hasNegativeOverride ? { attentionImageNegativeOverride: negativePrompt } : {}),
        };
      }
      publishWifePromptProfile(result);
      return result;
    }

    function publishWifePromptProfile(archetype) {
      if (!archetype || typeof archetype !== 'object') return;
      const shortname = wifeImageName(archetype.shortname || archetype.englishName || archetype.id);
      const archetypeId = String(archetype.attentionCustomWifeId || archetype.id || shortname).trim();
      if (!shortname || !archetypeId) return;
      const positive = String(archetype.attentionImagePrompt?.positivePrompt || archetype.imageBase || '').trim()
        .replaceAll('\r\n', '\n');
      const negative = normalizedWifeNegative(archetype.attentionImageNegativeOverride
        ?? archetype.attentionImagePrompt?.negativePrompt
        ?? archetype.imageNegative
        ?? '');
      if (!positive && !negative) return;
      const parts = positive.split(/\n\s*\n/);
      const profile = {
        format: 1,
        profileVersion: 'attention-image-prompt-v1',
        archetypeId,
        shortname,
        positiveTags: String(parts.shift() || '').trim(),
        naturalDescription: parts.join('\n\n').trim(),
        negativeTags: negative,
        attentionImagePromptOwner: api.id,
      };
      const profiles = globalThis.__WAYWARD_CHARACTER_PROMPT_PROFILES__
        || (globalThis.__WAYWARD_CHARACTER_PROMPT_PROFILES__ = []);
      const at = profiles.findIndex(entry => entry?.attentionImagePromptOwner === api.id
        && (entry.archetypeId === archetypeId || entry.shortname === shortname));
      if (at >= 0) profiles[at] = profile;
      else profiles.push(profile);
    }

    function publishCurrentWifePromptProfile(state = api.store.game()) {
      const context = currentWifePromptContext(state);
      if (!context.archetype) return;
      const override = characterPromptOverride(context);
      publishWifePromptProfile({
        ...context.archetype,
        ...(context.character?.shortname ? { shortname: context.character.shortname } : {}),
        ...(context.wifeKey ? { attentionCustomWifeId: context.wifeKey } : {}),
        ...(override ? {
          imageBase: override.positivePrompt,
          attentionImagePrompt: override,
          attentionImageNegativeOverride: override.negativePrompt,
        } : {}),
      });
    }

    function promptList(value) {
      return String(value || '').split(',').map(tag => tag.trim()).filter(Boolean);
    }

    function promptIdentity(value) {
      return String(value || '').trim().toLocaleLowerCase().replaceAll('_', ' ').replace(/\s+/g, ' ');
    }

    function appearancePromptFacet(value) {
      const tag = promptIdentity(value);
      if (/\b(?:brown|blue|green|grey|black|yellow|orange|red|purple|pink|aqua) eyes\b/.test(tag)) return 'eyes';
      if (/\b(?:(?:light )?(?:brown|black|blonde|red|orange|grey|white|pink|purple|blue|green) hair|(?:very )?(?:long|short) hair|medium hair|straight hair|wavy hair|curly hair|messy hair|ponytail|low ponytail|single braid|twin braids|braided ponytail|single hair bun|double bun|low twintails|half updo)\b/.test(tag)) return 'hair';
      if (/\b(?:pale skin|tan|dark-skinned female|very dark skin)\b/.test(tag)) return 'skin';
      if (/\b(?:petite|skinny|curvy|plump|muscular female|mature female)\b/.test(tag)) return 'build';
      if (/\b(?:(?:medium|small|large|huge) breasts|flat chest)\b/.test(tag)) return 'bust';
      if (/\b(?:waist|hips|thighs)\b/.test(tag)) return 'figure';
      if (/\b(?:freckles|mole|scar|eyebrows)\b/.test(tag)) return 'marks';
      return '';
    }

    function generatedWifeBasePrompt(imageBase, customAppearance) {
      const full = String(imageBase || '').trim();
      const custom = String(customAppearance || '').trim().replace(/\s*,\s*$/, '');
      if (!custom) return full;
      const suffix = `, ${custom}`;
      return full.endsWith(suffix) ? full.slice(0, -suffix.length).trim() : full;
    }

    function rebaseWifePrompt(fullPrompt, previousBase, nextBase) {
      const full = promptList(fullPrompt);
      const previous = promptList(previousBase);
      const next = promptList(nextBase);
      const previousIds = new Set(previous.map(promptIdentity));
      const nextIds = new Set(next.map(promptIdentity));
      const facets = new Set([...previous, ...next].map(appearancePromptFacet).filter(Boolean));
      const changedFacets = new Set([...facets].filter(facet => {
        const before = previous.filter(tag => appearancePromptFacet(tag) === facet).map(promptIdentity).sort().join('|');
        const after = next.filter(tag => appearancePromptFacet(tag) === facet).map(promptIdentity).sort().join('|');
        return before !== after;
      }));
      const removedExact = new Set(previous
        .filter(tag => !appearancePromptFacet(tag) && !nextIds.has(promptIdentity(tag)))
        .map(promptIdentity));
      const retained = full.filter(tag => {
        const facet = appearancePromptFacet(tag);
        return facet ? !changedFacets.has(facet) : !removedExact.has(promptIdentity(tag));
      });
      const additions = next.filter(tag => {
        const facet = appearancePromptFacet(tag);
        return facet ? changedFacets.has(facet) : !previousIds.has(promptIdentity(tag));
      });
      return [...retained, ...additions]
        .filter((tag, index, list) => list.findIndex(other => promptIdentity(other) === promptIdentity(tag)) === index)
        .join(', ');
    }

    function wifePromptCleanup(value) {
      const removedCategories = new Set(['quality', 'location', 'lighting', 'mood', 'action']);
      const kept = [];
      const removed = [];
      for (const tag of promptList(value)) {
        const identity = promptTagIdentity(tag);
        const category = promptTagCategory(tag);
        const removableStatus = category === 'status'
          && !/\b(?:piercing|pierced|choker|tattoo|scar|freckles|mole)\b/.test(identity.spaced);
        const removableComposition = category === 'other'
          && /^(?:solo|solo focus|2girls|multiple girls|[2-9]boys?|group)$/.test(identity.spaced);
        (removedCategories.has(category) || removableStatus || removableComposition ? removed : kept).push(tag);
      }
      return { positivePrompt: kept.join(', '), removed };
    }

    function gameElement(type, properties, ...children) {
      const nextProps = { ...(properties || {}) };
      const key = nextProps.key;
      delete nextProps.key;
      const childNodes = children.flat().filter(child => child != null && child !== false);
      if (childNodes.length) nextProps.children = childNodes.length === 1 ? childNodes[0] : childNodes;
      return childNodes.length > 1 ? jsx.jsxs(type, nextProps, key) : jsx.jsx(type, nextProps, key);
    }

    function wifePromptSources() {
      const builtIn = BUILTIN_WIFE_PROMPT_SOURCES.map(([id, fallbackName]) => {
        const archetype = wifeArchetypeById(id);
        return archetype ? { id, name: archetype.name || fallbackName, archetype } : null;
      }).filter(Boolean);
      let custom;
      readingWifePromptSources = true;
      try {
        custom = (customWifeStore.getState().wives || []).map(entry => {
          try {
            const archetype = applySavedWifeMetadata(buildWifeArchetype(entry.inputs, entry.id), entry.inputs);
            return archetype ? { id: entry.id, name: archetype.name || entry.inputs?.name || '사용자 아내', archetype, custom: true } : null;
          } catch { return null; }
        }).filter(Boolean);
      } finally {
        readingWifePromptSources = false;
      }
      return [...builtIn, ...custom];
    }

    globalThis.WW_CustomWifeBridge = {
      list: () => wifePromptSources().filter(source => source.custom).map(source => ({
        id: source.archetype.shortname || source.id,
        entryId: source.id,
        name: source.name,
        archetype: source.archetype,
      })),
    };

    const injectedPreGenerateWifeIds = new Set();

    function preGenerateWifeSources() {
      return wifePromptSources().filter(source => source.custom && source.id && source.archetype);
    }

    function preGenerateWifeSource(id) {
      return preGenerateWifeSources().find(source => source.id === id || source.archetype.shortname === id) || null;
    }

    function syncPreGenerateWives() {
      if (!Array.isArray(imagePreGenerateCharacters)) return [];
      for (let index = imagePreGenerateCharacters.length - 1; index >= 0; index -= 1) {
        if (injectedPreGenerateWifeIds.has(imagePreGenerateCharacters[index])) imagePreGenerateCharacters.splice(index, 1);
      }
      injectedPreGenerateWifeIds.clear();
      const sources = preGenerateWifeSources();
      for (const source of sources) {
        if (imagePreGenerateCharacters.includes(source.id)) continue;
        imagePreGenerateCharacters.push(source.id);
        injectedPreGenerateWifeIds.add(source.id);
      }
      return sources;
    }

    const imageStudioInjectedWifeIds = new Set();

    function beginImageStudioWifeNameInjection() {
      const originalEntries = Object.entries;
      const interceptedEntries = value => {
        if (value?.elena === '엘레나' && value?.mara === '마라' && value?.pippa === '피파') {
          for (const id of imageStudioInjectedWifeIds) delete value[id];
          imageStudioInjectedWifeIds.clear();
          for (const source of preGenerateWifeSources()) {
            const id = String(source.archetype.shortname || source.id || '').trim();
            if (!id || Object.prototype.hasOwnProperty.call(value, id)) continue;
            value[id] = source.name;
            imageStudioInjectedWifeIds.add(id);
          }
        }
        return originalEntries(value);
      };
      // shortcut: Image Studio has no wife-registration API, remove this interception when it exposes one.
      Object.entries = interceptedEntries;
      return () => { if (Object.entries === interceptedEntries) Object.entries = originalEntries; };
    }

    function syncImageStudioWives() {
      const studio = window.WW_ImageStudio;
      const bridge = window.WW_ImageStudioBridge || globalThis.WW_ImageStudioBridge;
      const launch = document.getElementById('wwis-launch');
      let patched = false;
      if (launch && !launch.__attentionCustomWives) {
        let restoreEntries = null;
        launch.addEventListener('click', () => {
          restoreEntries?.();
          restoreEntries = beginImageStudioWifeNameInjection();
        }, true);
        launch.addEventListener('click', () => {
          restoreEntries?.();
          restoreEntries = null;
        });
        Object.defineProperty(launch, '__attentionCustomWives', { value: true });
        patched = true;
      } else if (!launch && studio?.open && !studio.open.__attentionCustomWives) {
        const originalOpen = studio.open;
        const patchedOpen = function (...args) {
          const restoreEntries = beginImageStudioWifeNameInjection();
          try { return originalOpen.apply(this, args); }
          finally { restoreEntries(); }
        };
        Object.defineProperty(patchedOpen, '__attentionCustomWives', { value: true });
        studio.open = patchedOpen;
        patched = true;
      }
      if (bridge?.openRandom && !bridge.openRandom.__attentionCustomWives) {
        const originalOpenRandom = bridge.openRandom;
        const patchedOpenRandom = function (wife, ...args) {
          syncPreGenerateWives();
          const source = preGenerateWifeSource(wife);
          return originalOpenRandom.call(this, source?.id || wife, ...args);
        };
        Object.defineProperty(patchedOpenRandom, '__attentionCustomWives', { value: true });
        bridge.openRandom = patchedOpenRandom;
        patched = true;
      }
      return patched;
    }

    syncImageStudioWives();

    function labelPreGenerateWives(node, labels) {
      if (Array.isArray(node)) {
        const children = node.map(child => labelPreGenerateWives(child, labels));
        return children.some((child, index) => child !== node[index]) ? children : node;
      }
      if (!node || typeof node !== 'object' || !node.props) return node;
      const current = node.props.children;
      const label = (node.type === 'span' || node.tag === 'span') && typeof current === 'string'
        ? labels.get(current) : '';
      const children = label ? `${label} (생성한 아내)` : labelPreGenerateWives(current, labels);
      return children === current ? node : { ...node, props: { ...node.props, children } };
    }

    function wifePickerTools(props) {
      const h = gameElement;
      const sources = wifePromptSources();
      const customWives = sources.filter(source => source.custom);
      return h('div', {
        key: 'attention-image-prompt-wife-tools',
        'data-wml-ui': '',
        'data-attention-wife-tools': '',
        className: 'max-w-3xl mx-auto mt-4 mb-2 rounded-lg border border-stone-700 bg-stone-800/40 px-4 py-2 space-y-2',
        style: { width: 'calc(100% - 32px)', boxSizing: 'border-box' },
      },
      customWives.length ? h('div', { className: 'space-y-2' },
        h('div', { className: 'text-xs uppercase tracking-wide text-stone-400' }, '사용자 아내'),
        ...customWives.map(source => h('div', {
          key: source.id,
          className: 'rounded border border-stone-600 bg-stone-900/50 p-2 transition-colors',
          'data-custom-wife-card': source.id,
        },
        h('button', {
          type: 'button',
          'data-custom-wife-select': source.id,
          className: 'w-full rounded px-2 py-2 text-left hover:bg-amber-950/30 transition-colors',
          onClick: () => props.onSelect(source.id, 'spouse', source.archetype),
        },
          h('strong', { className: 'text-amber-300' }, source.name),
          h('span', { className: 'block text-xs text-stone-500 mt-1' }, source.archetype.tagline || '사용자가 만든 아내')),
        h('div', { className: 'flex justify-end gap-2 border-t border-stone-800 pt-2' },
          h('button', {
            type: 'button',
            'data-custom-wife-edit': source.id,
            className: 'rounded bg-stone-700 px-3 py-1 text-xs text-stone-200 hover:bg-stone-600',
            onClick: () => props.onOpenBuilder(source.id),
          }, '수정'),
          h('button', {
            type: 'button',
            'data-custom-wife-delete': source.id,
            className: 'rounded bg-rose-950 px-3 py-1 text-xs text-rose-200 hover:bg-rose-900',
            onClick: () => {
              if (!window.confirm(`“${source.name}” 아내를 삭제할까요? 이 작업은 되돌릴 수 없습니다.`)) return;
              customWifeStore.getState().remove(source.id);
            },
          }, '삭제')),
        ))) : null,
      h('details', { 'data-add-wife-details': '' },
      h('summary', { className: 'cursor-pointer text-sm font-medium text-amber-300 hover:text-amber-200' }, '＋ 아내 추가하기'),
      h('form', {
        className: 'mt-3 border-t border-stone-700 pt-3 grid gap-2',
        'data-add-wife-form': '',
        onSubmit: event => {
          event.preventDefault();
          const englishName = wifeBuilderEnglishName.trim();
          const shortname = wifeImageName(englishName);
          if (!shortname) return;
          pendingWifeBuilderTemplate = { englishName, shortname };
          wifeBuilderActivePromptSourceId = '';
          wifeBuilderContextId = null;
          props.onOpenBuilder();
        },
      },
        h('label', { className: 'grid gap-1 text-xs text-stone-400' }, '영문 이미지 이름',
          h('input', {
            type: 'text',
            required: true,
            pattern: '[A-Za-z][A-Za-z0-9 _-]*',
            defaultValue: wifeBuilderEnglishName,
            placeholder: '예: Alice Morgan',
            title: '영문자로 시작하고 영문, 숫자, 공백, 밑줄, 하이픈만 사용해 주세요.',
            'data-wife-english-name': '',
            className: 'w-full max-w-sm bg-stone-900 border border-stone-700 rounded px-3 py-2 text-sm text-stone-200',
            onChange: event => { wifeBuilderEnglishName = event.currentTarget.value; },
          }),
        ),
        h('p', { className: 'text-xs text-stone-500' }, '영문 이름은 이미지 키로 사용됩니다. 외모·프롬프트는 다음 창에서 수정할 수 있습니다.'),
        h('button', {
          type: 'submit',
          'data-add-wife-button': '',
          className: 'justify-self-start rounded bg-amber-800 hover:bg-amber-700 px-4 py-2 text-sm font-medium text-stone-100 transition-colors',
        }, '아내 추가하기'),
      )));
    }

    function customizeWifeBuilder(result, props) {
      if (!result) return result;
      const contextId = props?.editId || '__new-wife__';
      if (wifeBuilderContextId !== contextId) {
        wifeBuilderContextId = contextId;
        wifeBuilderActivePromptSourceId = '';
      }
      const sources = wifePromptSources();
      const nodes = [];
      const collect = node => {
        if (Array.isArray(node)) { for (const child of node) collect(child); return; }
        if (!node || typeof node !== 'object') return;
        nodes.push(node);
        collect(node.props?.children);
      };
      collect(result);
      const identitySection = nodes.find(node => node.props?.title === '인물 정보');
      const baseSection = nodes.find(node => node.props?.title === '외모 기준 캐릭터');
      const appearanceSection = nodes.find(node => node.props?.title === '외모');
      const promptTextarea = nodes.find(node => node.type === 'textarea'
        && String(node.props?.placeholder || '').includes('hair ribbon'));
      if (!baseSection || !appearanceSection || !promptTextarea) return result;
      const baseSelect = (() => {
        const found = [];
        const walk = node => {
          if (Array.isArray(node)) { for (const child of node) walk(child); return; }
          if (!node || typeof node !== 'object') return;
          if (node.type === 'select') found.push(node);
          walk(node.props?.children);
        };
        walk(baseSection.props.children);
        return found[0];
      })();
      if (!baseSelect) return result;

      const sourcePrefix = 'attention-wife:';
      const nativeValue = String(baseSelect.props.value || '');
      const promptState = currentWifeBuilderPromptState;
      const promptInputs = promptState?.inputs || {};
      if (!props?.editId && promptState?.inputs && !Object.prototype.hasOwnProperty.call(promptInputs, '__attentionFirstExperience'))
        promptInputs.__attentionFirstExperience = { mode: 'random' };
      const updateBuilderInputs = patch => {
        if (!promptState?.inputs) return;
        Object.assign(promptState.inputs, patch);
        const positive = String(promptState.full ?? promptTextarea.props.value ?? '');
        promptTextarea.props.onChange({ target: { value: positive }, currentTarget: { value: positive } });
      };
      if (nativeValue) wifeBuilderActivePromptSourceId = '';
      if (!wifeBuilderActivePromptSourceId && !nativeValue) {
        const currentPrompt = String(promptState?.full || promptTextarea.props.value || '').trim();
        wifeBuilderActivePromptSourceId = sources.find(source =>
          String(source.archetype.imageBase || '').trim() === currentPrompt)?.id || '';
      }
      if (!sources.some(source => source.id === wifeBuilderActivePromptSourceId)) wifeBuilderActivePromptSourceId = '';
      const selectedValue = wifeBuilderActivePromptSourceId
        ? `${sourcePrefix}${wifeBuilderActivePromptSourceId}`
        : nativeValue;
      const nativeOptions = (Array.isArray(baseSelect.props.children)
        ? baseSelect.props.children : [baseSelect.props.children])
        .filter(option => option?.props?.value !== '');
      const replacementSelect = {
        ...baseSelect,
        props: {
          ...baseSelect.props,
          value: selectedValue,
          'data-wife-builder-base': '',
          onChange: event => {
            const value = String(event.target.value || '');
            if (value.startsWith(sourcePrefix)) {
              const source = sources.find(entry => entry.id === value.slice(sourcePrefix.length));
              if (!source) return;
              wifeBuilderActivePromptSourceId = source.id;
              if (promptState) {
                promptState.full = String(source.archetype.imageBase || '').trim();
                const sourceNegative = source.archetype.attentionImageNegativeOverride
                  ?? source.archetype.attentionImagePrompt?.negativePrompt
                  ?? joinPrompt(`${DEFAULT_WIFE_CHARACTER_NEGATIVE}, ${source.archetype.imageNegative || ''}`);
                promptState.negative = String(sourceNegative).trim();
                if (promptState.inputs) promptState.inputs.__attentionImageNegativePrompt = promptState.negative;
                promptState.needsPersist = false;
                promptState.userEdited = false;
              }
              baseSelect.props.onChange({ target: { value: '' }, currentTarget: { value: '' } });
              promptTextarea.props.onChange({ target: { value: source.archetype.imageBase || '' }, currentTarget: { value: source.archetype.imageBase || '' } });
              return;
            }
            wifeBuilderActivePromptSourceId = '';
            baseSelect.props.onChange(event);
          },
          children: [
            gameElement('option', { key: 'attention-wife-none-placeholder', value: '', disabled: true, hidden: true }, '기준 캐릭터를 선택하세요'),
            ...nativeOptions,
            gameElement('option', { key: 'attention-wife-divider', value: '__attention-divider__', disabled: true }, '── 기본·저장 캐릭터 ──'),
            ...sources.map(source => gameElement('option', {
              key: `${sourcePrefix}${source.id}`,
              value: `${sourcePrefix}${source.id}`,
            }, `${source.custom ? '저장한 아내' : '기본 캐릭터'} · ${source.name}`)),
          ],
        },
      };
      const noBaseCheckbox = gameElement('label', {
        key: 'attention-wife-no-base',
        className: 'flex items-center gap-2 text-sm text-stone-300 pb-2',
        'data-wife-no-base': '',
      },
      gameElement('input', {
        type: 'checkbox',
        checked: !nativeValue && !wifeBuilderActivePromptSourceId,
        onChange: event => {
          wifeBuilderActivePromptSourceId = '';
          if (event.target.checked) {
            baseSelect.props.onChange({ target: { value: '' }, currentTarget: { value: '' } });
            return;
          }
          const first = nativeOptions.find(option => option?.props?.value);
          if (first) baseSelect.props.onChange({ target: { value: first.props.value }, currentTarget: { value: first.props.value } });
        },
      }),
      '기준 캐릭터 없음');
      const metadataSelect = (label, data, value, options, onChange) => gameElement('label', {
        className: 'grid gap-1 text-xs text-stone-400',
      }, label, gameElement('select', {
        value,
        ...data,
        onChange,
        className: 'w-full rounded border border-stone-700 bg-stone-950 px-3 py-2 text-sm text-stone-200',
      }, ...options.map(([id, optionLabel]) => gameElement('option', { key: id || '__none', value: id }, optionLabel))));
      const firstExperience = promptInputs.__attentionFirstExperience || {};
      const firstExperienceMode = ['random', 'none', 'player', 'other'].includes(firstExperience.mode)
        ? firstExperience.mode : 'random';
      const firstExperienceEditor = gameElement('div', {
        key: 'attention-wife-first-experience', className: 'mt-3 pt-3 border-t border-stone-700 space-y-2',
        'data-wife-first-experience': '',
      },
      metadataSelect('첫 경험 상대', { 'data-wife-first-experience-mode': '' }, firstExperienceMode,
        [['random', '운명에 맡김 (랜덤)'], ['none', '경험 없음'], ['player', '당신'], ['other', '다른 사람']],
        event => updateBuilderInputs({ __attentionFirstExperience: {
          ...firstExperience, mode: event.target.value,
        } })),
      firstExperienceMode === 'other' ? gameElement('label', { className: 'grid gap-1 text-xs text-stone-400' },
        '첫 상대 이름', gameElement('input', {
          type: 'text', maxLength: 64, value: String(firstExperience.partnerName || ''),
          'data-wife-first-experience-partner': '', placeholder: '이름을 입력하세요',
          className: 'w-full rounded border border-stone-700 bg-stone-950 px-3 py-2 text-sm text-stone-200',
          onChange: event => updateBuilderInputs({ __attentionFirstExperience: {
            ...firstExperience, mode: 'other', partnerName: event.target.value,
          } }),
        })) : null,
      gameElement('p', { className: 'text-xs text-stone-500' },
        props?.editId && !promptInputs.__attentionFirstExperience
          ? '기존 캐릭터는 선택을 바꾸기 전까지 원래 게임 설정을 유지해요.'
          : '새 게임을 시작할 때 적용해요. 운명에 맡기면 시작할 때 정해지고, 이름을 비우면 이름 미상으로 기록돼요. 이후 성경험 화면에서 직접 바꾸면 그 선택이 우선돼요.'));
      const imageNameEditor = api.game === '2026-11-01' ? gameElement('label', {
        key: 'attention-wife-image-name', className: 'grid gap-1 text-xs text-stone-400',
      }, '영문 이미지 이름', gameElement('input', {
        type: 'text', value: promptInputs.__attentionImageEnglishName || promptInputs.__attentionImageShortname || '',
        pattern: '[A-Za-z][A-Za-z0-9 _-]*', 'data-attention-wife-english-name': '',
        className: 'w-full rounded border border-stone-700 bg-stone-950 px-3 py-2 text-sm text-stone-200',
        placeholder: '예: Alice Morgan',
        onChange: event => {
          const value = event.target.value;
          if (value && !/^[A-Za-z][A-Za-z0-9 _-]*$/.test(value)) return;
          updateBuilderInputs({ __attentionImageEnglishName: value, __attentionImageShortname: wifeImageName(value) });
        },
      }), gameElement('span', { className: 'text-xs text-stone-500' },
        '영문자로 시작하며 영문, 숫자, 공백, 밑줄, 하이픈을 쓸 수 있습니다. 기존 이름을 바꾸면 이미지 연결이 달라질 수 있습니다.')) : null;
      const outfitColors = wifeOutfitColors(promptInputs);
      const wifeMetadataEditor = gameElement('div', {
        key: 'attention-wife-metadata-editor',
        className: 'mt-3 pt-3 border-t border-stone-700 space-y-3',
        'data-wml-ui': '',
        'data-wife-metadata-editor': '',
      },
      gameElement('div', { className: 'text-sm font-medium text-stone-200' }, '추가 대사·의상 색상'),
      metadataSelect('추가 대사 모드에서 사용할 대사', { 'data-wife-dialogue-source': '' },
        wifeDialogueArchetypeId(promptInputs), EXTRA_LINES_DIALOGUE_SOURCES,
        event => updateBuilderInputs({ __attentionExtraLinesArchetypeId: event.target.value })),
      gameElement('p', { className: 'text-xs text-stone-500' },
        '엘레나·마라·피파 중 말투를 선택합니다. 기존 JSON에 선택값이 없으면 이전 동작과 같은 엘레나 대사를 사용합니다.'),
      gameElement('div', { className: 'grid grid-cols-1 sm:grid-cols-3 gap-2' },
        ...[
          ['primary', '주요 색상'], ['secondary1', '보조 색상 1'], ['secondary2', '보조 색상 2'],
        ].map(([key, label]) => metadataSelect(label, { 'data-wife-outfit-color': key }, outfitColors[key], OUTFIT_COLOR_OPTIONS,
          event => updateBuilderInputs({
            __attentionImageOutfitColors: { ...wifeOutfitColors(promptState?.inputs), [key]: event.target.value },
          })))),
      wifeOutfitColorPrompt(promptInputs)
        ? gameElement('p', { className: 'text-xs text-amber-300', 'data-wife-outfit-color-prompt': '' },
          `적용 태그: ${wifeOutfitColorPrompt(promptInputs)}`)
        : gameElement('p', { className: 'text-xs text-stone-500' }, '선택한 색상은 미리보기와 인게임 의상 프롬프트에 함께 추가됩니다.'));
      const promptCleanup = wifePromptCleanup(promptState?.full || promptTextarea.props.value || '');
      const promptCleanupWarning = promptState?.userEdited && promptCleanup.removed.length
        ? gameElement('div', {
          key: 'attention-wife-prompt-cleanup',
          className: 'mt-3 rounded border border-amber-700/70 bg-amber-950/30 p-3 space-y-2',
          'data-wife-prompt-cleanup': '',
        },
        gameElement('p', { className: 'text-sm font-medium text-amber-200' },
          `외형 외 태그 ${promptCleanup.removed.length}개가 감지되었습니다.`),
        gameElement('p', { className: 'text-xs text-stone-400' },
          `장면·행동·기분을 고정할 수 있는 태그: ${promptCleanup.removed.slice(0, 8).map(tag => translatedPromptTag(tag)).join(', ')}`),
        gameElement('button', {
          type: 'button',
          className: 'rounded bg-amber-800 px-3 py-1.5 text-xs font-medium text-white hover:bg-amber-700',
          'data-wife-prompt-cleanup-action': '',
          onClick: () => {
            if (!promptState) return;
            promptState.full = promptCleanup.positivePrompt;
            promptState.userEdited = false;
            promptState.needsPersist = false;
            const value = promptCleanup.positivePrompt;
            promptTextarea.props.onChange({ target: { value }, currentTarget: { value } });
          },
        }, '외형·의상 태그만 남기기'))
        : null;
      const negativeEditor = gameElement('div', {
        key: 'attention-wife-negative-editor',
        className: 'mt-3 pt-3 border-t border-stone-700',
        'data-wml-ui': '',
        'data-wife-negative-editor': '',
      },
      gameElement('div', { className: 'mb-2 text-sm font-medium text-stone-200' },
        '공통 Negative 프롬프트 (미리보기·인게임 기존 프롬프트 교체)'),
      gameElement('textarea', {
        value: promptState?.negative ?? DEFAULT_WIFE_CHARACTER_NEGATIVE,
        rows: 7,
        className: 'w-full rounded border border-stone-700 bg-stone-950 px-3 py-2 text-sm text-stone-200',
        placeholder: '미리보기와 인게임 모두에서 제외할 공통 Negative 프롬프트를 입력하세요.',
        'data-wife-negative-prompt': '',
        onChange: event => {
          if (!promptState) return;
          const value = event.target.value;
          promptState.negative = value;
          if (currentWifeBuilderPromptState?.id === promptState.id) {
            currentWifeBuilderPromptState.negative = value;
          }
          if (promptState.inputs) promptState.inputs.__attentionImageNegativePrompt = value;
          const positive = String(promptState.full ?? promptTextarea.props.value ?? '');
          promptTextarea.props.onChange({ target: { value: positive }, currentTarget: { value: positive } });
        },
      }));

      const visit = node => {
        if (Array.isArray(node)) return node.map(visit);
        if (node === baseSelect) return replacementSelect;
        if (typeof node === 'string') return node === '추가 프롬프트 태그'
          ? '전체 외형 프롬프트 (기존 프롬프트 교체)' : node;
        if (!node || typeof node !== 'object' || !node.props) return node;
        const children = visit(node.props.children);
        const nextProps = { ...node.props, children };
        if (node === baseSection) {
          const list = Array.isArray(children) ? children : [children];
          nextProps.children = [noBaseCheckbox, ...list];
        }
        if (node === identitySection) {
          const list = Array.isArray(children) ? children : [children];
          nextProps.children = [...list, firstExperienceEditor];
        }
        if (node === appearanceSection) {
          const list = Array.isArray(children) ? children : [children];
          nextProps.children = [...list, promptCleanupWarning, imageNameEditor, wifeMetadataEditor, negativeEditor].filter(Boolean);
        }
        if (node === promptTextarea) {
          nextProps.rows = 7;
          nextProps.value = promptState?.full ?? promptTextarea.props.value ?? '';
          nextProps.placeholder = '선택한 캐릭터의 전체 프롬프트를 불러오거나 직접 입력하세요. 이 값이 기존 외형 프롬프트를 교체합니다.';
          nextProps['data-wife-full-prompt'] = '';
          nextProps.onChange = event => {
            if (promptState) {
              promptState.full = event.target.value;
              promptState.needsPersist = false;
              promptState.userEdited = true;
            }
            promptTextarea.props.onChange(event);
          };
        }
        return { ...node, props: nextProps };
      };
      if (promptState?.needsPersist && !promptState.persistScheduled) {
        promptState.persistScheduled = true;
        const value = promptState.full;
        queueMicrotask(() => promptTextarea.props.onChange({ target: { value }, currentTarget: { value } }));
      }
      return visit(result);
    }

    const wrappedWifePickerTypes = new WeakMap();
    function addWifePickerTools(result, props) {
      if (typeof result?.type === 'function' && String(result.type).includes('wife-image-counts')
        && String(result.type).includes('onOpenBuilder')) {
        let wrapped = wrappedWifePickerTypes.get(result.type);
        if (!wrapped) {
          const originalType = result.type;
          wrapped = nextProps => addWifePickerTools(originalType(nextProps), nextProps);
          wrappedWifePickerTypes.set(originalType, wrapped);
        }
        return { ...result, type: wrapped };
      }
      const hasWifeTools = node => {
        if (Array.isArray(node)) return node.some(hasWifeTools);
        if (!node || typeof node !== 'object' || !node.props) return false;
        return node.props['data-attention-wife-tools'] !== undefined
          || node.props['data-add-wife-button'] !== undefined
          || hasWifeTools(node.props.children);
      };
      if (hasWifeTools(result)) return result;
      let added = false;
      const visit = node => {
        if (Array.isArray(node)) return node.map(visit);
        if (!node || typeof node !== 'object' || !node.props) return node;
        const className = String(node.props.className || '');
        if (!added && className.includes('space-y-3') && className.includes('mb-6')) {
          added = true;
          const children = Array.isArray(node.props.children) ? node.props.children : [node.props.children];
          return { ...node, props: { ...node.props, children: [...children, wifePickerTools(props)] } };
        }
        if (node.props.children == null) return node;
        return { ...node, props: { ...node.props, children: visit(node.props.children) } };
      };
      const decorated = visit(result);
      // Opaque picker components can ignore children injected into their props.
      return added ? decorated : gameElement(jsx.Fragment, {}, wifePickerTools(props), decorated);
    }
