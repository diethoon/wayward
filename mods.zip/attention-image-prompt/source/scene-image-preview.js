    let sceneImagePreviewId = '';
    let sceneImagePreviewSerial = 0;
    let sceneImagePreviewBusy = false;
    let sceneImagePreviewResults = {};

    function scenePreviewPromptSignature(id) {
      const prompt = currentPositionStatePrompt(id);
      return JSON.stringify([prompt?.positivePrompt || '', prompt?.negativePrompt || '', !!prompt?.onlyState,
        sceneBaseOverrideFingerprint(id)]);
    }

    function scenePreviewConfigurationSignature(state, wife, id) {
      if (!state || !wife) return '';
      const situation = situationConfigForCharacter(wife, state.primaryCharacterId);
      return JSON.stringify([scenePreviewPromptSignature(id), sceneStatePromptFingerprint(id),
        situation?.prompts || null, situation?.negativePrompts || null, currentGameDefaultPrompts(),
        currentWifeCharacterPrompt(currentWifePromptContext(state, state.primaryCharacterId, wife)),
        currentOutfitPrompts()[wife.outfit] || null, currentPromptModRules()]);
    }

    function scenePreviewOpen(win, id) {
      return win?.el?.isConnected !== false && activeSettingsTab === 'scene-prompts' && scenePromptEditorId === id;
    }

    function scenePreviewPlanCharacter(wife, id) {
      if (id.includes('|') && !/^look-[^|]+\|reaction-[^|]+$/.test(id))
        throw new Error('수면·다인·침대·세부 상태가 포함된 장면은 기본 장면을 선택해 주세요.');
      const match = id.match(/^(scene|task|look)-([^|]+)(?:\|reaction-([^|]+))?$/);
      if (!match || (match[1] === 'look' && !match[3]))
        throw new Error('이 장면의 기본 동작을 확인할 수 없어요. 반응이 포함된 장면을 선택해 주세요.');
      if (!api.has('imagePlanCharacter') || (!wife.archetypeId && !wife.generatedArchetype))
        throw new Error('현재 아내의 기본 외형을 확인할 수 없어요.');
      const sample = api.fn('imagePlanCharacter')(wife.archetypeId, wife.generatedArchetype);
      if (!sample || typeof sample !== 'object') throw new Error('기본 상태의 아내를 만들지 못했어요.');
      const character = { ...sample, id: wife.id, shortname: wife.shortname, name: wife.name,
        archetypeId: wife.archetypeId, generatedArchetype: wife.generatedArchetype,
        outfit: wife.outfit, exposure: undefined, aftermathTags: [], onPatronLap: false,
        sceneOverride: match[1] === 'scene' ? match[2] : undefined,
        sceneVariant: 0, currentTask: match[1] === 'task' ? match[2] : 'idle',
        lookFocus: match[1] === 'look' ? match[2] : undefined,
        lookFocusReaction: match[1] === 'look' ? match[3] : undefined };
      const room = match[2].startsWith('bath_') ? 'bathhouse'
        : match[1] === 'task' && match[2] === 'sleeping' ? 'bedroom' : 'taproom';
      return { character, room, kind: match[1] };
    }

    function scenePreviewRequest(mode, id, active, state, wife) {
      const oldPreviewing = promptPreviewing;
      const oldPlanDepth = imagePlanDepth;
      const oldBasePreviewing = sceneBaseOverridePreviewing;
      let result;
      promptPreviewing = true;
      try {
        if (mode === 'current') {
          const key = activePortraitImageKey('', state);
          if (!active || !key)
            throw new Error('현재 장면의 프롬프트를 확인할 수 없어요. 초상화를 다시 열어 주세요.');
          const symbols = ['portraitSceneContext', 'portraitMoodContext', 'portraitFinishContext',
            'wifeLocation', 'imageRoom', 'playerSexScene', 'patronScene'];
          let currentWife, args;
          if (symbols.every(name => api.has(name))) {
            const scene = api.fn('portraitSceneContext')(state);
            if (!scene || typeof scene !== 'object') throw new Error('현재 장면 정보를 읽을 수 없어요.');
            currentWife = { ...wife, sceneOverride: scene.scene, sceneVariant: scene.sceneVariant };
            args = [api.fn('imageRoom')(api.fn('wifeLocation')(state)), api.fn('portraitMoodContext')(state),
              api.fn('playerSexScene')(state)?.ticksElapsed, api.fn('patronScene')(state), api.fn('portraitFinishContext')(state)];
          } else {
            if (!latestPromptArgs?.length || latestScenePrompt?.characterId !== state.primaryCharacterId
              || latestScenePrompt.result?.key !== key)
              throw new Error('현재 장면의 프롬프트를 확인할 수 없어요. 초상화를 다시 열어 주세요.');
            const captured = latestPromptArgs[0];
            currentWife = { ...wife, sceneOverride: captured?.sceneOverride, sceneVariant: captured?.sceneVariant };
            args = latestPromptArgs.slice(1);
            args[2] = state.activeScene?.sex?.ticksElapsed;
            args[3] = state.activeScene?.patron;
          }
          result = api.fn('imagePrompt')(currentWife, ...args);
          if (!result?.prompt || !Array.isArray(result.parts)
            || result.key !== key)
            throw new Error('현재 장면이나 인물이 바뀌었어요. 초상화를 다시 확인해 주세요.');
          result = applyPromptModRules(alignSleepScenePrompt(replaceNativeFirstExperience(result), state, state.primaryCharacterId));
        } else {
          imagePlanDepth += 1;
          sceneBaseOverridePreviewing = true;
          const plan = scenePreviewPlanCharacter(wife, id);
          result = api.fn('imagePrompt')(plan.character, plan.room);
          if (!result?.prompt || !Array.isArray(result.parts) || positionSituationId(result.key) !== id
            || (plan.kind === 'scene' && !result.parts.some(part => ['장면', 'Scene'].includes(part.label))))
            throw new Error('선택한 장면의 기본 프롬프트를 만들 수 없어요.');
          const extra = currentPositionStatePrompt(id);
          result = { ...result, prompt: joinPrompt(`${result.prompt}, ${extra?.positivePrompt || ''}`),
            negativePrompt: joinPrompt(`${result.negativePrompt || ''}, ${extra?.negativePrompt || ''}`) };
          result = applyPromptModRules(result);
        }
        const beforeCameraPrompt = result.prompt;
        const cameraPreviewResult = cameraPreview(id, result.prompt, result.negativePrompt || '', { draw: true, parts: result.parts });
        result = { ...result, prompt: cameraPreviewResult.prompt, negativePrompt: cameraPreviewResult.negativePrompt };
        const cleaned = applyGlobalPromptExclusions(deduplicateFinalRequest(result));
        const params = mode === 'scene' || cleaned.prompt !== beforeCameraPrompt
          ? promptGenParams(cleaned.prompt) : result.genParams || promptGenParams(cleaned.prompt);
        const request = { prompt: cleaned.prompt, negativePrompt: cleaned.negativePrompt || '',
          width: 1216, height: 832, steps: params?.steps, cfg: params?.cfg, loraStrength: params?.loraStrength,
          checkpoint: result.checkpoint, ...(result.look === undefined ? {} : { look: result.look }),
          bypassCache: true, debug: { source: 'attention-image-prompt-scene-preview' } };
        request.imageKey = `aip_scene_preview_${shortHash(JSON.stringify([mode, id, request.prompt,
          request.negativePrompt, request.checkpoint, params, request.look]))}`;
        if (cameraPreviewResult.shotId) Object.defineProperty(request, '__aipCameraPreviewShotId', { value: cameraPreviewResult.shotId });
        return request;
      } finally {
        promptPreviewing = oldPreviewing;
        imagePlanDepth = oldPlanDepth;
        sceneBaseOverridePreviewing = oldBasePreviewing;
      }
    }

    async function generateSceneImagePreview(mode, id, active, win) {
      if (sceneImagePreviewBusy || !scenePreviewOpen(win, id)) return;
      const state = api.store.game(), wife = state?.characters?.[state?.primaryCharacterId];
      let request;
      try {
        if (!wife || !api.has('imageGenerate')) throw new Error('현재 아내 또는 이미지 생성 기능을 확인할 수 없어요.');
        request = scenePreviewRequest(mode, id, active, state, wife);
      } catch (error) {
        sceneImagePreviewResults[mode] = { error: diagnosticText(error) };
        if (scenePreviewOpen(win, id)) win.refresh();
        return;
      }
      const serial = ++sceneImagePreviewSerial;
      const signature = scenePreviewConfigurationSignature(state, wife, id);
      const key = activePortraitImageKey('', state);
      sceneImagePreviewBusy = true;
      sceneImagePreviewResults[mode] = { loading: true, request, wife, signature, key, day: state.day, slot: state.slot };
      if (scenePreviewOpen(win, id)) win.refresh();
      try {
        const result = await api.fn('imageGenerate')(request);
        if (!result?.url) throw new Error('이미지 서버가 결과 주소를 반환하지 않았어요.');
        const current = api.store.game();
        if (serial !== sceneImagePreviewSerial || !scenePreviewOpen(win, id)
          || current?.primaryCharacterId !== state.primaryCharacterId || current?.characters?.[current.primaryCharacterId] !== wife
          || scenePreviewConfigurationSignature(current, wife, id) !== signature
          || (mode === 'current' && (current.day !== state.day || current.slot !== state.slot
            || activePortraitImageKey('', current) !== key))) return;
        sceneImagePreviewResults[mode] = { request, url: String(result.url), wife, signature, key, day: state.day, slot: state.slot };
      } catch (error) {
        const current = api.store.game();
        if (serial === sceneImagePreviewSerial && scenePreviewOpen(win, id)
          && current?.primaryCharacterId === state.primaryCharacterId
          && current?.characters?.[current.primaryCharacterId] === wife
          && scenePreviewConfigurationSignature(current, wife, id) === signature)
          sceneImagePreviewResults[mode] = { error: diagnosticText(error) };
      } finally {
        if (serial === sceneImagePreviewSerial) {
          if (sceneImagePreviewResults[mode]?.loading) delete sceneImagePreviewResults[mode];
          sceneImagePreviewBusy = false;
          if (scenePreviewOpen(win, id)) win.refresh();
        }
      }
    }

    function renderSceneImagePreview(h, win, id, active) {
      if (sceneImagePreviewId !== id) {
        sceneImagePreviewId = id;
        sceneImagePreviewSerial += 1;
        sceneImagePreviewBusy = false;
        sceneImagePreviewResults = {};
      }
      const state = api.store.game(), wife = state?.characters?.[state?.primaryCharacterId];
      const signature = Object.values(sceneImagePreviewResults).some(result => result?.request)
        ? scenePreviewConfigurationSignature(state, wife, id) : '';
      for (const mode of ['current', 'scene']) {
        const result = sceneImagePreviewResults[mode];
        if (result?.request && (result.signature !== signature || result.wife !== wife
          || (mode === 'current' && (result.day !== state?.day || result.slot !== state?.slot
            || result.key !== activePortraitImageKey('', state))))) delete sceneImagePreviewResults[mode];
      }
      const renderResult = mode => {
        const result = sceneImagePreviewResults[mode];
        if (!result) return null;
        const label = mode === 'current' ? '현재 상황' : '장면 전용';
        return h('div', { 'data-scene-preview-result': mode, style: 'display:grid;gap:6px;margin-top:10px;' },
          h('strong', {}, label), result.loading ? h('p', { role: 'status' }, '이미지 생성 중…') : null,
          result.error ? h('p', { class: 'wml-note', role: 'alert' }, `생성 실패: ${result.error}`) : null,
          result.url ? h('img', { src: result.url, alt: `${label} 이미지 미리보기`, style: 'max-width:100%;max-height:420px;object-fit:contain;' }) : null,
          ...(result.request ? [['Positive', result.request.prompt], ['Negative', result.request.negativePrompt]].map(([name, value]) =>
            h('label', { class: 'aip-prompt-field' }, h('strong', {}, name), h('textarea', {
              rows: 3, value, readOnly: true, 'data-scene-preview-prompt': `${mode}-${name.toLowerCase()}`,
              style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:65px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
            }))) : []));
      };
      return h('section', { 'data-scene-image-preview': '', style: 'margin-top:18px;' },
        h('h3', {}, '이미지 미리보기'),
        h('p', { class: 'wml-muted wml-small' }, '현재 상황은 현재 상태와 마지막 초상화 맥락의 예상값이에요. 장면 전용은 현재 외형·의상과 장면 추가 문구를 사용해 기본 상태로 생성해요. 다른 모드나 서버 전송 과정에서 결과가 달라질 수 있어요.'),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;' },
          api.ui.button('현재 상황 이미지 생성', () => void generateSceneImagePreview('current', id, active, win), { disabled: sceneImagePreviewBusy || !active }),
          api.ui.button('장면 전용 이미지 생성', () => void generateSceneImagePreview('scene', id, active, win), { disabled: sceneImagePreviewBusy })),
        h('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,260px),1fr));gap:12px;' },
          renderResult('current'), renderResult('scene')));
    }
