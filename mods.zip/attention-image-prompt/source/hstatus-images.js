    function residueCharacterKey(state, character, characterId) {
      const generated = character?.generatedArchetype;
      const rawValues = [generated?.shortname, generated?.id, character?.archetypeId, characterId]
        .map(value => String(value || '').toLowerCase());
      const registered = globalThis.__WAYWARD_WIFE_REGISTRY__?.list?.() || [];
      for (const wife of registered) {
        const key = String(wife?.code || wife?.shortname || '').toLowerCase();
        const archetypeId = String(wife?.archetypeId || '').toLowerCase();
        if (key && rawValues.some(raw => raw === key || raw === archetypeId || raw.includes(key))) return key;
      }
      const profiles = globalThis.__WAYWARD_CHARACTER_PROMPT_PROFILES__ || [];
      for (let index = profiles.length - 1; index >= 0; index -= 1) {
        const key = String(profiles[index]?.shortname || '').toLowerCase();
        const archetypeId = String(profiles[index]?.archetypeId || '').toLowerCase();
        if (key && rawValues.some(raw => raw === key || raw === archetypeId || raw.includes(key))) return key;
      }
      const raw = rawValues.join(' ');
      return ['elena', 'mara', 'pippa'].find(key => raw.includes(key)) || '';
    }

    function residueImageKey(part) {
      const state = api.store.game();
      publishCurrentWifePromptProfile(state);
      const characterId = state?.primaryCharacterId;
      const character = state?.characters?.[characterId];
      const characterKey = residueCharacterKey(state, character, characterId);
      if (!characterKey || !character) return '';
      const stats = character.situationStats || {};
      const fluidState = stats.fluidState || {};
      const jewelry = stats.jewelryState || {};
      const bridge = globalThis.__waywardSituationEventMod;
      const wetnessTier = bridge?.vulvaWetnessTier
        ? bridge.vulvaWetnessTier(character.stats?.arousal, heroineDriveCalc(state)?.desire)
        : vulvaTier(character, heroineDriveCalc(state));
      const tier = part === 'vulva' ? wetnessTier
        : bridge?.fluidTier ? bridge.fluidTier(part, fluidState[part]) : fluidTier(part, fluidState[part]);
      const vaginalSex = Number(stats.eventCounts?.vaginalSex) || 0;
      const widthTier = bridge?.vaginalWidthTier ? bridge.vaginalWidthTier(vaginalSex)
        : vaginalSex >= 20 ? 2 : vaginalSex >= 5 ? 1 : 0;
      const insideTier = bridge?.insideTier ? bridge.insideTier(fluidState.uterus)
        : fluidTier('uterus', fluidState.uterus);
      const vibe = jewelry.vibe || {};
      const vibeType = ['egg', 'penis'].includes(vibe.type) && !vibe.suspension ? vibe.type : '';
      if (part === 'uterus') {
        if (vibeType) return `situation_toy_info__${characterKey}__uterus__vibe-${vibeType}__width-${widthTier}__inside-${insideTier}`;
        return `situation_fluid__${characterKey}__uterus__width-${widthTier}__stage-${tier}`;
      }
      if (part === 'breasts' && Number(jewelry.breasts?.stage) > 0) {
        const stage = Math.max(0, Math.min(3, Math.floor(Number(jewelry.breasts.stage) || 0)));
        return `situation_fluid__${characterKey}__breasts__stage-${tier}__jewelry-piercing-stage-${stage}`;
      }
      if (part === 'vulva') {
        const stage = Math.max(0, Math.min(1, Math.floor(Number(jewelry.vulva?.stage) || 0)));
        if (vibeType) return `situation_toy_info__${characterKey}__vulva__vibe-${vibeType}__width-${widthTier}__inside-${insideTier}`;
        return `situation_vulva__${characterKey}__wetness-${wetnessTier}__jewelry-${stage}`;
      }
      return `situation_fluid__${characterKey}__${part}__stage-${tier}`;
    }

    function syncResiduePresetPack() {
      const packs = window.__WAYWARD_IMAGE_PACKS__;
      if (!Array.isArray(packs)) return false;
      const packId = 'wayward-situation-aip-residue-presets';
      const existingIndex = packs.findIndex(pack => pack?.packId === packId);
      const existing = packs[existingIndex];
      const entries = {};
      const state = api.store.game();
      const characterId = state?.primaryCharacterId;
      const character = state?.characters?.[characterId];
      const characterKey = residueCharacterKey(state, character, characterId);
      const sources = currentResiduePartSources();
      const findBuiltIn = (key, prefix) => {
        for (let index = packs.length - 1; index >= 0; index -= 1) {
          const pack = packs[index];
          if (!String(pack?.packId || '').startsWith(prefix)) continue;
          const entry = pack.entries?.[key];
          if (String(entry?.imagePath || '').startsWith('illustrious/situation/')) return entry;
        }
        return null;
      };
      if (characterKey) for (const { part } of FLUID_PARTS) {
        const source = sources[part];
        if (source === 'generate') continue;
        const imageKey = residueImageKey(part);
        const sourceKey = imageKey.replace(`__${characterKey}__`, `__${source}__`);
        const image = findBuiltIn(sourceKey, `wayward-situation-${source}-`);
        if (image) entries[imageKey] = { ...image, talentName: imageKey };
        const status = part === 'mouth' ? 'mouth-hypnosis' : part === 'vulva' ? 'vulva-crest' : '';
        if (!status) continue;
        const value = Number(character?.situationStats?.[part === 'mouth' ? 'hypnosis' : 'crest']) || 0;
        const tier = Math.min(5, Math.ceil(Math.max(0, Math.min(100, value)) / 20));
        if (!tier) continue;
        const overlayKey = `situation_status__${characterKey}__${status}__stage-${tier}`;
        const overlay = findBuiltIn(`situation_status__${source}__${status}__stage-${tier}`, 'wayward-situation-status-');
        if (overlay) entries[overlayKey] = { ...overlay, talentName: overlayKey };
      }
      const changed = JSON.stringify(existing?.entries || {}) !== JSON.stringify(entries);
      if (!Object.keys(entries).length) {
        if (existingIndex < 0) return false;
        packs.splice(existingIndex, 1);
      } else if (existingIndex < 0) {
        packs.push({ packFormat: 1, packId, entries });
      } else {
        existing.entries = entries;
        if (existingIndex !== packs.length - 1) packs.push(...packs.splice(existingIndex, 1));
      }
      return changed || existingIndex !== packs.length - 1;
    }

    async function residueBasePrompt(imageKey) {
      publishCurrentWifePromptProfile();
      const bridge = globalThis.__waywardSituationEventMod;
      const baseImageKey = residueBaseImageKey(imageKey);
      const referenceImageKey = residueReferencePromptKey(baseImageKey);
      const fallback = typeof bridge?.promptForImage === 'function' ? await bridge.promptForImage(baseImageKey) : null;
      if (typeof bridge?.promptForImage === 'function' && referenceImageKey !== baseImageKey) await bridge.promptForImage(referenceImageKey);
      const reference = residuePromptPackEntry(referenceImageKey) || residuePromptPackEntry(baseImageKey)
        || await loadResiduePromptPackEntry(referenceImageKey);
      const source = reference || fallback;
      if (!source) return null;
      return composeResidueReferencePrompt(source, reference ? referenceImageKey : baseImageKey, baseImageKey);
    }

    const AIP_RESIDUE_PROFILE = { ...SECRET_IMAGE_PROFILE,
      checkpoint: 'waiIllustriousSDXL_v170.safetensors', steps: 18, cfg: 2.5, loraStrength: 0.8 };
    const AIP_RESIDUE_STAGES = {
      mouth: [
        'clean lips and tongue',
        '(small semen trace on lower lip:1.4)',
        '(semen on tongue and lower lip:1.5)',
        '(semen pooled in mouth, one chin drip:1.6)',
        '(semen overflowing mouth, several chin drips:1.7)',
      ],
      breasts: [
        'clean bare breasts',
        '(small semen smear on one breast:1.4)',
        '(semen marks on both breasts:1.5)',
        '(semen across both breasts, one drip:1.6)',
        '(breasts covered in semen, several drips:1.7)',
      ],
      vulva: [
        'dry vulva',
        '(slight sheen on labia:1.4)',
        '(clear droplets on labia:1.5)',
        '(clear fluid dripping onto inner thighs:1.6)',
        '(clear fluid flowing down both inner thighs:1.7)',
      ],
      thighs: [
        'clean inner thighs',
        '(one semen streak on one inner thigh:1.5)',
        '(semen streaks and drips on both inner thighs:1.7)',
      ],
      inside: [
        'clean vaginal opening',
        '(tiny semen trace at vaginal opening:1.4)',
        '(small semen pool at vaginal opening:1.5)',
        '(semen pooled around vaginal opening:1.6)',
        '(semen leaking onto inner thighs:1.7)',
      ],
      uterus: [
        'empty uterus and vaginal canal, no semen',
        '(small semen trace low in vaginal canal:1.4), uterus empty',
        '(vaginal canal filled with semen, small pool in uterus:1.5)',
        '(vaginal canal full, uterus half filled with semen, slight leak:1.6)',
        '(uterus and vaginal canal full of semen, visible overflow:1.7)',
      ],
    };

    function aipResiduePrompt(imageKey) {
      const part = residuePartFromImageKey(imageKey);
      if (!part) return null;
      const wife = currentWifeCharacterPrompt();
      let identity = residueVisibleWifeTraits(wife.positivePrompt, imageKey);
      if (part === 'breasts' || part === 'vulva') identity = promptTokens(identity).filter(tag =>
        !/\b(?:pierc\w*|choker|necklace|collar)\b/.test(promptTagIdentity(tag).spaced)).join(', ');
      const anchor = promptTokens(wife.positivePrompt).find(tag =>
        (/[A-Z][a-z]+ [A-Z][a-z]+/.test(tag) || /^[a-z]+_[a-z]+$/.test(tag))
        && !/\b(?:hair|eyes?|skin|breasts?|body|dress|game|cg|anime|comic|style)\b/.test(promptTagIdentity(tag).spaced)) || '';
      const stage = Number(imageKey.match(/__stage-(\d+)/)?.[1]) || 0;
      const wetness = Number(imageKey.match(/__wetness-(\d+)/)?.[1]) || 0;
      const inside = Number(imageKey.match(/__inside-(\d+)/)?.[1]) || 0;
      const width = Number(imageKey.match(/__width-(\d+)/)?.[1]) || 0;
      const jewelry = Number(imageKey.match(/__jewelry-(?:[a-z0-9_-]+-stage-)?(\d+)/)?.[1]) || 0;
      const egg = imageKey.includes('__vibe-egg__');
      const penis = imageKey.includes('__vibe-penis__');
      const toy = egg || penis;
      const pick = (states, level) => states[Math.max(0, Math.min(states.length - 1, level))];
      const positive = ['1girl, masterpiece, best quality, adult woman', anchor, identity];
      const negative = ['worst quality, low quality, bad anatomy, bad hands, text, watermark, 3d, realistic, multiple girls, multiple views, split screen, child, loli, underage'];
      if (part === 'mouth') {
        positive.push('face, parted lips, visible tongue', pick(AIP_RESIDUE_STAGES.mouth, stage));
        if (!stage) negative.push('semen on lips, semen on tongue');
      } else if (part === 'breasts') {
        positive.push('breasts visible', pick(AIP_RESIDUE_STAGES.breasts, stage));
        if (!stage) negative.push('semen on breasts');
        if (jewelry === 1) positive.push(imageKey.includes('__jewelry-piercing-right-')
          ? 'small silver ring on her right nipple only' : 'small silver ring on her left nipple only');
        if (jewelry >= 2) positive.push('small silver rings on both nipples');
        if (jewelry >= 3) positive.push('black heart choker');
        if (!jewelry) negative.push('nipple piercing, choker');
      } else if (part === 'thighs') {
        positive.push('inner thighs visible', pick(AIP_RESIDUE_STAGES.thighs, stage));
        if (!stage) negative.push('semen on thighs');
      } else if (part === 'vulva') {
        positive.push('vulva visible', toy ? pick(AIP_RESIDUE_STAGES.inside, inside) : pick(AIP_RESIDUE_STAGES.vulva, wetness));
        if (toy) {
          positive.push(pick(['tight fit around toy', 'slightly relaxed around toy', 'wide opening around toy'], width));
          positive.push(egg
            ? 'purple egg_vibrator, vaginal_object_insertion, vibrator_cord, (egg vibrator fully inside her vagina:1.45), (only its cord visible at the vaginal opening:1.3)'
            : 'purple dildo, vibrator, vaginal_object_insertion, (dildo shaft fully inside her vagina:1.45), (only its base visible at the vaginal opening:1.3)');
          if (!inside) negative.push('semen at vaginal opening');
        } else if (!wetness) negative.push('wet vulva, dripping fluid');
        if (jewelry) positive.push('small silver clitoral piercing');
        else negative.push('clitoral piercing, genital piercing');
      } else if (part === 'uterus') {
        positive.push('lower abdomen and pelvis visible, x-ray view through intact skin, one pink uterus and vaginal canal',
          pick(AIP_RESIDUE_STAGES.uterus, toy ? inside : stage),
          pick(['narrow vaginal canal', 'slightly open vaginal canal', 'wide vaginal canal'], width));
        if (egg) positive.push('purple egg_vibrator, vaginal_object_insertion, (egg vibrator fully inside vaginal canal:1.45)');
        if (penis) positive.push('purple dildo, vibrator, vaginal_object_insertion, (dildo shaft fully inside vaginal canal:1.45)');
        negative.push('medical chart, detached organ, open abdomen, exposed organs, gore, extra uterus, inset panel');
        if (!(toy ? inside : stage)) negative.push('semen, cum');
      }
      if (egg) negative.push('dildo, multiple vibrators, holding_sex_toy, vibrator outside body');
      if (penis) negative.push('egg_vibrator, vibrator_cord, multiple vibrators, holding_sex_toy, dildo outside body');
      const visible = `${anchor}, ${identity}`.toLowerCase().replaceAll('_', ' ');
      const negativePrompt = promptTokens(`${negative.join(', ')}, ${residueVisibleWifeTraits(wife.negativePrompt, imageKey)}`)
        .filter(tag => !visible.includes(promptTagIdentity(tag).spaced)).join(', ');
      return { ...AIP_RESIDUE_PROFILE, prompt: deduplicatePrompt(positive.filter(Boolean).join(', ')),
        negativePrompt: deduplicatePrompt(negativePrompt), source: 'attention-image-prompt-secret-own' };
    }

    function residueEditableBasePrompt(imageKey) {
      return currentHStatusGenerationModes()[residuePartFromImageKey(imageKey)] === 'own'
        ? aipResiduePrompt(imageKey) : residueBasePrompt(imageKey);
    }

    function blobDataUrl(blob) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(reader.error || new Error('참조 이미지를 읽지 못했습니다.'));
        reader.readAsDataURL(blob);
      });
    }

    async function hStatusImg2Img(imageKey, requestKey, prompt) {
      const part = residuePartFromImageKey(imageKey);
      if (!part) return null;
      diagnostics.lastHStatusImg2ImgFallback = '';
      if (!hStatusImg2ImgEnabled(part)) return null;
      const fallback = reason => {
        diagnostics.lastHStatusImg2ImgFallback = reason;
        return null;
      };
      if (typeof globalThis.fetch !== 'function' || typeof globalThis.FileReader !== 'function') {
        return fallback('브라우저가 참조 이미지 전송 기능을 제공하지 않습니다.');
      }

      let backend = api.has('imageBackend') ? api.fn('imageBackend')() : null;
      if ((!backend?.baseUrl || backend.comfyui === false) && api.has('imageBackendProbe')) {
        const prefs = settingsStore?.getState?.() || {};
        if (prefs.imageBackendMode !== 'off') {
          try {
            const allowAutoProbe = api.has('imageAutoProbeAllowed') ? api.fn('imageAutoProbeAllowed')() : true;
            backend = await api.fn('imageBackendProbe')({
              mode: prefs.imageBackendMode,
              url: prefs.imageBackendUrl,
              allowAutoProbe,
            }, true);
          } catch (error) {
            console.warn('[attention-image-prompt] H-Status ImageStudio probe', error);
          }
        }
      }
      if (!backend?.baseUrl || backend.comfyui === false) return fallback('연결된 ImageStudio 또는 ComfyUI를 찾지 못했습니다.');
      const baseUrl = String(backend.baseUrl).replace(/\/+$/, '');
      const referenceKey = residueReferenceImageKey(imageKey);
      let reference;
      try {
        reference = await imageLookup(referenceKey);
      } catch (error) {
        console.warn('[attention-image-prompt] H-Status reference lookup', error);
        return fallback(`기준 이미지 조회 실패: ${diagnosticText(error)}`);
      }
      if (!reference || (reference.talentName && reference.talentName !== referenceKey)) {
        return fallback(`정확한 기준 이미지를 찾지 못했습니다: ${referenceKey}`);
      }
      const referenceUrl = imageEntryUrl(reference);
      if (!referenceUrl) return fallback(`기준 이미지 주소를 만들지 못했습니다: ${referenceKey}`);
      const sourceUrl = /^\/?images\//i.test(referenceUrl)
        ? `${baseUrl}/${referenceUrl.replace(/^\/+/, '')}`
        : referenceUrl;
      const img2imgPrompt = removeGlobalPromptExclusions(deduplicateFinalPrompt(`${prompt.prompt}, ${SECRET_IMAGE_PROMPTS.img2imgSkinGuard}${part === 'breasts' ? `, ${SECRET_IMAGE_PROMPTS.img2imgBreastSizeGuard}` : ''}`));
      const img2imgNegativePrompt = removeGlobalPromptExclusions(deduplicateFinalPrompt(`${prompt.negativePrompt || ''}, ${SECRET_IMAGE_PROMPTS.img2imgSkinNegative}`), 'negative');

      let imageData;
      try {
        const sourceResponse = await globalThis.fetch(sourceUrl, { credentials: 'omit' });
        if (!sourceResponse.ok) return fallback(`기준 이미지 HTTP ${sourceResponse.status || '오류'}: ${sourceUrl}`);
        imageData = await blobDataUrl(await sourceResponse.blob());
      } catch (error) {
        console.warn('[attention-image-prompt] H-Status reference image', error);
        return fallback(`기준 이미지 읽기 실패: ${diagnosticText(error)}`);
      }

      const readResponse = async response => {
        const body = await response.json().catch(() => ({}));
        if (!response.ok && response.status !== 202) {
          const error = new Error(body.error || `ImageStudio HTTP ${response.status}`);
          error.status = response.status;
          throw error;
        }
        if (body.status === 'error') throw new Error(body.error || 'ImageStudio img2img 생성에 실패했습니다.');
        return body;
      };

      let response = await globalThis.fetch(`${baseUrl}/api/image/hstatus-img2img`, {
        method: 'POST',
        credentials: 'omit',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          talentId: requestKey,
          imageType: 'portrait',
          prompt: img2imgPrompt,
          negativePrompt: img2imgNegativePrompt,
          denoise: part === 'breasts' ? 0.4 : 0.28,
          imageData,
          referenceKey,
          bypassCache: false,
          debug: { source: 'attention-image-prompt-residue' },
        }),
      });
      if (response.status === 404 || response.status === 501) {
        return fallback(`ImageStudio가 H-Status img2img를 지원하지 않습니다. (HTTP ${response.status})`);
      }
      let result = await readResponse(response);
      for (let count = 0; ['queued', 'processing'].includes(result.status) && count < 900; count += 1) {
        await new Promise(resolve => window.setTimeout(resolve, 1000));
        response = await globalThis.fetch(`${baseUrl}/api/image/status/${encodeURIComponent(result.promptId)}`, { credentials: 'omit' });
        result = await readResponse(response);
      }
      if (['queued', 'processing'].includes(result.status)) throw new Error('ImageStudio img2img 생성 제한 시간(15분)을 넘었습니다.');
      if (!result.imageUrl) throw new Error('ImageStudio img2img 결과 주소가 없습니다.');
      const imageUrl = String(result.imageUrl);
      return { ...result, url: /^(?:https?:|data:|blob:)/i.test(imageUrl)
        ? imageUrl : `${baseUrl}${imageUrl.startsWith('/') ? '' : '/'}${imageUrl}` };
    }

    async function regenerateResidueImage(imageKey, button = null) {
      const originalText = button?.textContent || '이미지 재생성';
      if (button) { button.disabled = true; button.textContent = '생성 중…'; }
      let requestKey = imageKey;
      try {
        diagnostics.lastHStatusImg2ImgFallback = '';
        const provider = currentResidueGenerationProvider();
        const partMode = currentHStatusGenerationModes()[residuePartFromImageKey(imageKey)];
        const useHStatusPrompt = provider === 'imagestudio' || partMode === 'hstatus';
        const ownPrompt = provider === 'aip' && partMode === 'own';
        const prompt = useHStatusPrompt
          ? await globalThis.__waywardSituationEventMod?.promptForImage?.(imageKey)
          : await residueEditableBasePrompt(imageKey);
        if (!prompt?.prompt) throw new Error('잔류 상태 기본 프롬프트를 불러오지 못했습니다.');
        const params = promptGenParams(prompt.prompt);
        residueVariantId = Math.max(Date.now(), residueVariantId + 1);
        requestKey = `${imageKey}__v-${residueVariantId}`;
        const startedAt = Date.now();
        const request = {
          imageKey: requestKey,
          prompt: prompt.prompt,
          negativePrompt: prompt.negativePrompt || '',
          workflow: prompt.workflow || 'illustrious',
          width: Number(prompt.width) || 1152,
          height: Number(prompt.height) || 896,
          dimensions: prompt.dimensions,
          steps: useHStatusPrompt || ownPrompt ? Number(prompt.steps) || params?.steps : params?.steps,
          cfg: useHStatusPrompt || ownPrompt ? Number(prompt.cfg) || params?.cfg : params?.cfg,
          loraStrength: ownPrompt ? prompt.loraStrength : params?.loraStrength,
          ...(ownPrompt ? { checkpoint: prompt.checkpoint } : {}),
          ...(prompt.look === undefined ? {} : { look: prompt.look }),
          bypassCache: false,
          debug: { source: useHStatusPrompt ? 'attention-image-prompt-residue-hstatus'
            : ownPrompt ? 'attention-image-prompt-residue-own' : 'attention-image-prompt-residue' },
        };
        if (provider === 'imagestudio') {
          const studio = globalThis.WW_ImageStudioPrompt;
          studio.open();
          const draft = await studio.generate(applyGlobalPromptExclusions(request));
          if (!draft?.draftId) throw new Error('ImageStudio 검수 이미지를 받지 못했습니다.');
          diagnostics.lastGeneration = { at: startedAt, key: requestKey, status: 'review', durationMs: Date.now() - startedAt, error: '', mode: 'imagestudio-review' };
          if (button) button.textContent = '검수창에서 저장';
          return true;
        }
        if (!api.has('imageGenerate')) throw new Error('이미지 생성 기능을 찾지 못했습니다.');
        const img2imgResult = partMode === 'img2img' ? await hStatusImg2Img(imageKey, requestKey, prompt) : null;
        const result = img2imgResult || await api.fn('imageGenerate')(request);
        if (!result?.url) throw new Error('이미지 서버에서 결과를 받지 못했습니다.');
        if (img2imgResult || useHStatusPrompt || ownPrompt) diagnostics.lastGeneration = {
          at: startedAt, key: requestKey, status: 'success', durationMs: Date.now() - startedAt, error: '',
          mode: img2imgResult ? 'hstatus-img2img' : useHStatusPrompt ? 'hstatus-default' : 'aip-own',
        };
        saveResidueImageChoice(imageKey, { key: requestKey, url: String(result.url), createdAt: Date.now() });
        window.dispatchEvent(new CustomEvent('wayward-image-connection297'));
        scheduleUiScan();
        if (button) button.textContent = '완료';
        return true;
      } catch (error) {
        console.warn('[attention-image-prompt] residue regeneration', error);
        if (diagnostics.lastGeneration?.key !== requestKey || diagnostics.lastGeneration.status === 'running') {
          diagnostics.lastGeneration = {
            at: Date.now(), key: requestKey, status: 'error', durationMs: 0, error: diagnosticText(error),
          };
        }
        if (button) button.textContent = '생성 실패';
        return false;
      } finally {
        if (button) setTimeout(() => { button.disabled = false; button.textContent = originalText; }, 1400);
      }
    }

    function residueStateLabel(imageKey) {
      const part = residuePartFromImageKey(imageKey);
      const label = FLUID_PARTS.find(entry => entry.part === part)?.label || part || '상태';
      const details = [];
      const vibe = /__vibe-(egg|penis)__/.exec(imageKey)?.[1];
      const width = /__width-(\d+)/.exec(imageKey)?.[1];
      const inside = /__inside-(\d+)/.exec(imageKey)?.[1];
      const wetness = /__wetness-(\d+)/.exec(imageKey)?.[1];
      const stage = /__stage-(\d+)/.exec(imageKey)?.[1];
      const jewelry = /__jewelry-([a-z0-9_-]+?)(?:-stage-(\d+))?$/.exec(imageKey);
      if (vibe) details.push(vibe === 'egg' ? '에그형 바이브' : '삽입형 바이브');
      if (width !== undefined) details.push(`너비 ${width}`);
      if (inside !== undefined) details.push(`내부 상태 ${inside}`);
      if (wetness !== undefined) details.push(`젖음 ${wetness}`);
      if (stage !== undefined) details.push(`단계 ${stage}`);
      if (jewelry) details.push(jewelry[1] === '0' ? '장신구 없음' : `장신구 ${jewelry[1].replaceAll('-', ' ')}${jewelry[2] ? ` ${jewelry[2]}단계` : ''}`);
      return `${label} · ${details.join(' · ') || '현재 상태'}`;
    }

    async function residueStateImageKeys(part) {
      const currentKey = residueImageKey(part);
      if (!currentKey) return [];
      const referenceKey = residueReferencePromptKey(currentKey);
      const referenceCharacter = residueCharacterFromImageKey(referenceKey);
      const targetCharacter = residueCharacterFromImageKey(currentKey);
      if (!referenceCharacter || !targetCharacter) return [currentKey];
      const regularKey = part === 'vulva'
        ? `situation_vulva__${referenceCharacter}__wetness-0__jewelry-0`
        : part === 'uterus'
          ? `situation_fluid__${referenceCharacter}__uterus__width-0__stage-0`
          : referenceKey;
      const loadKeys = [regularKey];
      if (part === 'vulva' || part === 'uterus') {
        loadKeys.push(`situation_toy_info__${referenceCharacter}__${part}__vibe-egg__width-0__inside-0`);
      }
      await Promise.all(loadKeys.map(loadResiduePromptPackEntry));
      const prefixes = [part === 'vulva'
        ? `situation_vulva__${referenceCharacter}__`
        : `situation_fluid__${referenceCharacter}__${part}__`];
      if (part === 'vulva' || part === 'uterus') prefixes.push(`situation_toy_info__${referenceCharacter}__${part}__`);
      const keys = new Set();
      for (const pack of globalThis.__WAYWARD_SITUATION_PROMPT_PACKS__ || []) {
        for (const key of Object.keys(pack?.entries || {})) {
          if (prefixes.some(prefix => key.startsWith(prefix))) keys.add(key.replace(`__${referenceCharacter}__`, `__${targetCharacter}__`));
        }
      }
      if (!keys.size) keys.add(currentKey);
      return [...keys].sort((left, right) => left.localeCompare(right, 'ko', { numeric: true }));
    }

    function openResidueBatchManager(initialPart = 'mouth') {
      let part = FLUID_PARTS.some(entry => entry.part === initialPart) ? initialPart : 'mouth';
      let count = 1;
      let keys = [];
      let loading = true;
      let running = false;
      let stopRequested = false;
      let message = '';
      let progress = '';
      let win;
      const loadKeys = async () => {
        loading = true;
        keys = [];
        win.refresh();
        keys = await residueStateImageKeys(part);
        loading = false;
        message = keys.length ? '' : '생성할 상태 프롬프트를 찾지 못했습니다.';
        win.refresh();
      };
      const generate = async () => {
        if (running || loading || !keys.length) return;
        running = true;
        stopRequested = false;
        let completed = 0;
        let failed = 0;
        const total = keys.length * count;
        for (const key of keys) {
          for (let index = 0; index < count; index += 1) {
            if (stopRequested) break;
            progress = `${completed + 1} / ${total} · ${residueStateLabel(key)}`;
            win.refresh();
            if (await regenerateResidueImage(key)) completed += 1;
            else { completed += 1; failed += 1; }
          }
          if (stopRequested) break;
        }
        running = false;
        progress = '';
        message = stopRequested
          ? `중지했습니다. ${completed}장 처리${failed ? ` · 실패 ${failed}장` : ''}`
          : `완료했습니다. ${completed}장 처리${failed ? ` · 실패 ${failed}장` : ''}`;
        win.refresh();
      };
      win = api.ui.window({
        id: 'residue-batch-manager', title: '비밀 탭 상태별 이미지 생성', width: 1080, height: 760,
        render(body) {
          const h = api.ui.h;
          const choices = currentResidueImageChoices();
          body.replaceChildren(h('div', { style: 'display:grid;gap:12px;' },
            h('p', { class: 'wml-note' }, '선택한 부위의 모든 H-Status 상태를 순서대로 생성합니다. 자궁·외음부는 일반 상태와 에그형·삽입형 바이브 상태를 모두 포함합니다. 상태별 장 수는 1~10장입니다. 생성된 이미지는 상태마다 따로 보존되며 아래의 이미지 선택에서 사용할 한 장을 정할 수 있습니다.'),
            h('div', { style: 'display:grid;grid-template-columns:minmax(180px,1fr) 150px auto;gap:8px;align-items:end;' },
              h('label', { style: 'display:grid;gap:4px;font-size:12px;' }, '부위',
                h('select', {
                  value: part, disabled: running, 'data-residue-batch-part': '',
                  onchange: event => { part = event.currentTarget.value; void loadKeys(); },
                  style: 'border:1px solid #57534e;border-radius:5px;background:#1c1917;color:#f5f5f4;padding:7px 8px;',
                }, ...FLUID_PARTS.map(entry => h('option', { value: entry.part, selected: entry.part === part }, entry.label)))),
              h('label', { style: 'display:grid;gap:4px;font-size:12px;' }, '상태별 장 수',
                h('input', {
                  type: 'number', min: 1, max: 10, value: count, disabled: running, 'data-residue-batch-count': '',
                  onchange: event => { count = Math.max(1, Math.min(10, Math.floor(Number(event.currentTarget.value) || 1))); win.refresh(); },
                  style: 'border:1px solid #57534e;border-radius:5px;background:#1c1917;color:#f5f5f4;padding:7px 8px;',
                })),
              running
                ? api.ui.button('중지 요청', () => { stopRequested = true; message = '현재 이미지가 끝나면 중지합니다.'; win.refresh(); })
                : api.ui.button('전체 상태 생성', () => { void generate(); }, { primary: true, disabled: loading || !keys.length }),
            ),
            h('p', { class: 'wml-small', 'data-residue-batch-summary': '' }, loading ? '상태 목록을 불러오는 중…' : `상태 ${keys.length}개 · 총 ${keys.length * count}장${progress ? ` · ${progress}` : ''}`),
            message ? h('p', { class: 'wml-note' }, message) : null,
            h('div', { style: 'display:grid;gap:7px;' }, ...keys.map(key => {
              const entry = choices[key] || { selected: '', items: [] };
              const label = residueStateLabel(key);
              return h('div', {
                'data-residue-batch-state': key,
                 style: 'display:grid;grid-template-columns:minmax(0,1fr) auto auto;gap:8px;align-items:center;border:1px solid #44403c;border-radius:7px;background:#1c1917;padding:8px;',
              },
              h('div', { style: 'min-width:0;' },
                h('div', { style: 'font-size:12px;color:#fafaf9;' }, label),
                h('div', { style: 'margin-top:3px;font-size:10px;color:#a8a29e;overflow-wrap:anywhere;' }, `${key} · ${entry.items.length}장 · ${entry.selected ? '선택 이미지 사용 중' : '자동 이미지 사용'}`)),
               api.ui.button('프롬프트 수정', () => openResiduePromptEditor(key, label), { 'data-residue-batch-prompt': key }),
               api.ui.button(`이미지 선택 (${entry.items.length})`, () => openResidueImagePicker(key, label)));
            })),
          ));
        },
      });
      win.refresh();
      void loadKeys();
    }

    async function openResiduePromptEditor(imageKey, label) {
      const ownMode = currentHStatusGenerationModes()[residuePartFromImageKey(imageKey)] === 'own';
      const base = await residueEditableBasePrompt(imageKey);
      const saved = residuePromptOverride(imageKey);
      let positivePrompt = saved?.positivePrompt ?? base?.prompt ?? '';
      let negativePrompt = saved?.negativePrompt ?? base?.negativePrompt ?? '';
      let message = base ? '' : '기본 프롬프트를 불러오지 못했습니다.';
      let libraryPolarity = 'positive';
      let libraryCategory = 'all';
      const win = api.ui.window({
        id: 'residue-prompt-editor', title: `잔류 상태 프롬프트 · ${label}`, width: 1180, height: 760,
        render(body, windowHandle) {
          const h = api.ui.h;
          const customTags = currentCustomTags();
          const tags = allPromptTags(customTags).map(tag => ({ tag, category: promptTagCategory(tag, customTags) }));
          const visibleTags = libraryCategory === 'all' ? tags : tags.filter(entry => entry.category === libraryCategory);
          const presets = [...MODEL_PROMPT_PRESETS, ...currentPromptPresets()];
          const inputStyle = 'width:100%;box-sizing:border-box;resize:vertical;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:8px;font:12px/1.5 ui-monospace,Consolas,monospace;';
          const append = (value, name) => {
            if (libraryPolarity === 'negative') negativePrompt = deduplicatePrompt(`${negativePrompt}, ${value}`);
            else positivePrompt = deduplicatePrompt(`${positivePrompt}, ${value}`);
            message = `${name}을(를) ${libraryPolarity === 'negative' ? 'Negative' : 'Positive'}에 추가했습니다.`;
            windowHandle.refresh();
          };
          const targetButton = (polarity, text) => h('button', {
            type: 'button', class: 'wml-btn', 'data-residue-prompt-target': polarity,
            'aria-pressed': libraryPolarity === polarity ? 'true' : 'false',
            style: libraryPolarity === polarity ? 'border-color:#d97706;color:#fef3c7;background:#451a03;' : '',
            onclick: () => { libraryPolarity = polarity; windowHandle.refresh(); },
          }, text);
          body.replaceChildren(h('div', {
            'data-residue-prompt-layout': '',
            style: 'display:grid;grid-template-columns:minmax(0,1fr) 340px;gap:12px;align-items:start;',
          },
            h('section', { style: 'min-width:0;' },
              h('p', { class: 'wml-muted wml-small', style: 'overflow-wrap:anywhere;' }, imageKey),
               h('p', { class: 'wml-note', style: 'margin:0 0 10px;' }, ownMode
                 ? 'AIP가 아내 외형과 이 상태의 부위·단계·장신구·토이 조건으로 만든 기본값입니다. 이 상태의 Positive·Negative를 직접 수정할 수 있습니다.'
                 : 'H-Status의 WAI Illustrious SDXL 품질·구도 프롬프트를 유지하고, 화면에 보이는 아내 특성만 기본값에 반영합니다.'),
              h('label', { style: 'display:grid;gap:5px;margin-bottom:4px;' },
                h('strong', { style: 'font-size:12px;' }, '전체 Positive 프롬프트'),
                h('textarea', {
                  rows: 12, value: positivePrompt, spellcheck: false, style: inputStyle,
                  'data-residue-prompt-input': 'positive',
                  onfocus: () => { libraryPolarity = 'positive'; },
                  oninput: event => {
                    positivePrompt = event.currentTarget.value;
                    const node = event.currentTarget.closest?.('section')?.querySelector('[data-residue-applied-tags="positive"]');
                    const chips = promptTagChips(h, positivePrompt, windowHandle);
                    node?.replaceChildren(...(chips ? [chips] : []));
                  },
                }),
              ),
              h('div', {
                'data-residue-applied-tags': 'positive',
                style: 'max-height:112px;overflow-y:auto;margin:0 0 10px;padding:6px;border:1px solid #44403c;border-radius:6px;background:#1c1917;',
              }, promptTagChips(h, positivePrompt, windowHandle)),
              h('label', { style: 'display:grid;gap:5px;margin-bottom:4px;' },
                h('strong', { style: 'font-size:12px;' }, '전체 Negative 프롬프트'),
                h('textarea', {
                  rows: 8, value: negativePrompt, spellcheck: false, style: inputStyle,
                  'data-residue-prompt-input': 'negative',
                  onfocus: () => { libraryPolarity = 'negative'; },
                  oninput: event => {
                    negativePrompt = event.currentTarget.value;
                    const node = event.currentTarget.closest?.('section')?.querySelector('[data-residue-applied-tags="negative"]');
                    const chips = promptTagChips(h, negativePrompt, windowHandle);
                    node?.replaceChildren(...(chips ? [chips] : []));
                  },
                }),
              ),
              h('div', {
                'data-residue-applied-tags': 'negative',
                style: 'max-height:112px;overflow-y:auto;margin:0 0 10px;padding:6px;border:1px solid #44403c;border-radius:6px;background:#1c1917;',
              }, promptTagChips(h, negativePrompt, windowHandle)),
              h('div', { style: 'display:flex;gap:6px;flex-wrap:wrap;' },
                api.ui.button('저장', () => {
                  if (!positivePrompt.trim()) { message = 'Positive 프롬프트는 비워 둘 수 없습니다.'; windowHandle.refresh(); return; }
                  api.settings.set({ residuePrompts: { ...currentResiduePrompts(), [imageKey]: { positivePrompt, negativePrompt } } });
                  message = '저장했습니다. 다음 재생성부터 적용됩니다.';
                  windowHandle.refresh();
                }, { primary: true }),
                api.ui.button('기본값으로 복원', () => {
                  const next = { ...currentResiduePrompts() };
                  delete next[imageKey];
                  api.settings.set({ residuePrompts: next });
                  positivePrompt = base?.prompt || '';
                  negativePrompt = base?.negativePrompt || '';
                  message = '이 카드의 프롬프트를 기본값으로 복원했습니다.';
                  windowHandle.refresh();
                }),
                api.ui.button('저장 후 재생성', async () => {
                  if (!positivePrompt.trim()) { message = 'Positive 프롬프트는 비워 둘 수 없습니다.'; windowHandle.refresh(); return; }
                  api.settings.set({ residuePrompts: { ...currentResiduePrompts(), [imageKey]: { positivePrompt, negativePrompt } } });
                  message = await regenerateResidueImage(imageKey) ? '저장한 프롬프트로 이미지를 다시 생성했습니다.' : '재생성에 실패했습니다. 이미지 서버 연결을 확인해 주세요.';
                  windowHandle.refresh();
                }),
              ),
              message ? h('p', { class: 'wml-note', style: 'margin-top:8px;' }, message) : null,
            ),
            h('aside', {
              'data-residue-prompt-library': '', class: 'wml-section',
              style: 'min-width:0;max-height:660px;overflow-y:auto;overscroll-behavior:contain;scrollbar-gutter:stable;position:sticky;top:0;',
            },
            h('h3', { style: 'margin:0 0 4px;' }, '태그·프리셋 라이브러리'),
            h('p', { class: 'wml-muted wml-small', style: 'margin:0 0 8px;' }, '버튼은 한글로 표시되며, 마우스를 올리면 한글·영문을 함께 볼 수 있습니다.'),
            h('div', { style: 'display:flex;gap:5px;margin-bottom:8px;' },
              targetButton('positive', 'Positive에 추가'), targetButton('negative', 'Negative에 추가')),
            h('button', {
              type: 'button', class: 'wml-btn', 'data-residue-prompt-deduplicate': '', style: 'width:100%;margin-bottom:8px;',
              onclick: () => {
                if (libraryPolarity === 'negative') negativePrompt = deduplicatePrompt(negativePrompt);
                else positivePrompt = deduplicatePrompt(positivePrompt);
                message = `${libraryPolarity === 'negative' ? 'Negative' : 'Positive'} 중복 태그를 정리했습니다.`;
                windowHandle.refresh();
              },
            }, '현재 칸 중복 정리'),
            h('div', { style: 'display:flex;flex-wrap:wrap;gap:5px;margin-bottom:8px;' },
              ...TAG_CATEGORIES.filter(([id]) => id === 'all' || tags.some(entry => entry.category === id)).map(([id, text]) => h('button', {
                type: 'button', class: 'wml-btn', 'data-residue-prompt-category': id,
                'aria-pressed': libraryCategory === id ? 'true' : 'false',
                style: libraryCategory === id ? 'border-color:#d97706;color:#fef3c7;background:#451a03;' : '',
                onclick: () => { libraryCategory = id; windowHandle.refresh(); },
              }, text))),
            h('strong', { style: 'display:block;font-size:12px;margin-bottom:6px;' }, `태그 · ${visibleTags.length}개`),
            h('div', { style: 'display:flex;flex-wrap:wrap;gap:5px;margin-bottom:12px;' },
              ...visibleTags.map(({ tag }) => {
                const korean = translatedPromptTag(tag, customTags);
                return h('button', {
                  type: 'button', 'data-residue-prompt-tag': tag,
                  title: `한글: ${korean}\n영문: ${tag}\n클릭하면 현재 선택 칸에 추가합니다.`,
                  style: 'border:1px solid #57534e;border-radius:999px;background:#292524;color:#f5f5f4;padding:5px 8px;font-size:11px;cursor:pointer;text-align:left;',
                  onclick: () => append(tag, korean),
                }, korean);
              })),
            h('strong', { style: 'display:block;font-size:12px;margin-bottom:6px;' }, '프롬프트 프리셋'),
            h('div', { style: 'display:flex;flex-wrap:wrap;gap:5px;' },
              ...presets.map(preset => {
                const english = deduplicatePrompt(preset.prompt);
                const korean = promptTokens(english).map(tag => translatedPromptTag(tag, customTags)).join(', ');
                return h('button', {
                  type: 'button', 'data-residue-prompt-preset': preset.id,
                  title: `한글: ${korean}\n영문: ${english}\n클릭하면 현재 선택 칸에 모두 추가합니다.`,
                  style: 'border:1px solid #92400e;border-radius:999px;background:#451a03;color:#fef3c7;padding:5px 8px;font-size:11px;cursor:pointer;text-align:left;',
                  onclick: () => append(english, preset.name),
                }, preset.name);
              })),
            ),
          ));
        },
      });
      win.refresh();
    }

    function openResidueImagePicker(imageKey, label) {
      let loading = api.has('imageManifest');
      let message = '';
      const win = api.ui.window({
        id: 'residue-image-picker', title: `잔류 상태 이미지 선택 · ${label}`, width: 900, height: 720,
        render(body, windowHandle) {
          const h = api.ui.h;
          const entry = currentResidueImageChoices()[imageKey] || { selected: '', items: [] };
          const choose = selected => {
            selectResidueImage(imageKey, selected);
            windowHandle.refresh();
          };
          body.replaceChildren(h('div', {},
            h('p', { class: 'wml-note' }, '자동 이미지는 현재 상태의 기본 이미지를 사용합니다. “목록에서 제거”는 이 선택 목록에서만 빼며 이미지 파일은 삭제하지 않습니다.'),
            h('div', { style: 'display:flex;align-items:center;gap:8px;margin:10px 0;' },
              api.ui.button('생성 이미지 다시 찾기', async () => {
                loading = true;
                message = '';
                windowHandle.refresh();
                try {
                  const count = await discoverResidueImageChoices(imageKey, true);
                  message = count ? `ImageStudio에서 이 상태의 생성 이미지 ${count}장을 확인했습니다.` : 'ImageStudio에서 이 상태의 생성 이미지를 찾지 못했습니다.';
                } catch (error) {
                  message = `생성 이미지 목록을 불러오지 못했습니다: ${diagnosticText(error)}`;
                } finally {
                  loading = false;
                  windowHandle.refresh();
                }
              }, { 'data-residue-image-refresh': '' }),
              loading ? h('span', { class: 'wml-muted wml-small' }, 'ImageStudio 목록 확인 중…') : null,
            ),
            message ? h('p', { class: 'wml-muted wml-small' }, message) : null,
            h('div', { style: 'margin:10px 0 14px;' },
              api.ui.button(entry.selected ? '자동 이미지 사용' : '자동 이미지 사용 중', () => choose(''), { primary: !entry.selected }),
            ),
            entry.items.length
              ? h('div', { style: 'display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:10px;' },
                ...entry.items.map(item => {
                  const selected = item.key === entry.selected;
                  return h('div', {
                    style: `display:grid;gap:6px;border:2px solid ${selected ? '#f59e0b' : '#57534e'};border-radius:8px;background:#1c1917;color:#e7e5e4;padding:7px;`,
                  },
                  h('button', {
                    type: 'button',
                    title: selected ? '현재 선택된 이미지' : '이 이미지 사용',
                    'data-residue-image-choice': item.key,
                    onclick: () => choose(item.key),
                    style: 'display:grid;gap:6px;padding:0;border:0;background:transparent;color:inherit;text-align:left;cursor:pointer;',
                  },
                  h('img', { src: item.url, alt: `${label} 재생성 이미지`, loading: 'lazy', style: 'width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:5px;background:#0c0a09;' }),
                  h('span', { style: 'font-size:11px;overflow-wrap:anywhere;' }, selected ? '선택됨' : new Date(item.createdAt).toLocaleString())),
                  h('button', {
                    type: 'button',
                    title: '이미지 파일은 유지하고 이 목록에서만 제거',
                    'aria-label': `${label} 이미지를 선택 목록에서 제거`,
                    'data-residue-image-remove': item.key,
                    onclick: () => { removeResidueImageChoice(imageKey, item.key); windowHandle.refresh(); },
                    style: 'border:1px solid #78716c;border-radius:5px;background:#292524;color:#d6d3d1;padding:5px 7px;font-size:11px;cursor:pointer;',
                  }, '목록에서 제거'));
                }))
              : h('p', { class: 'wml-muted wml-small' }, '아직 보존된 재생성 이미지가 없습니다.'),
          ));
        },
      });
      win.refresh();
      if (loading) void (async () => {
        try {
          const count = await discoverResidueImageChoices(imageKey, true);
          if (count) message = `ImageStudio에서 이 상태의 생성 이미지 ${count}장을 복원했습니다.`;
        } catch (error) {
          message = `생성 이미지 목록을 불러오지 못했습니다: ${diagnosticText(error)}`;
        } finally {
          loading = false;
          win.refresh();
        }
      })();
    }

    function decorateResidueCards() {
      if (syncResiduePresetPack()) window.dispatchEvent(new CustomEvent('wayward-image-connection297'));
      const secretRoot = document.querySelector('.ko-se-secret');
      const provider = currentResidueGenerationProvider();
      if (secretRoot && !secretRoot.querySelector('[data-attention-hstatus-generation-modes]')) {
        const toolbar = document.createElement('div');
        toolbar.dataset.attentionHstatusGenerationModes = '';
        toolbar.dataset.wmlUi = '';
        toolbar.style.cssText = 'display:flex;justify-content:flex-end;padding:0 8px 10px;';
        const modeButton = document.createElement('button');
        modeButton.type = 'button';
        modeButton.textContent = '부위별 이미지 생성 방식';
        modeButton.style.cssText = 'border:1px solid #b45309;border-radius:6px;background:#451a03;color:#fef3c7;padding:7px 10px;font-size:12px;cursor:pointer;';
        modeButton.addEventListener('click', event => {
          event.preventDefault();
          event.stopPropagation();
          openHStatusGenerationModeSettings();
        });
        toolbar.append(modeButton);
        secretRoot.prepend(toolbar);
      }
      const sections = document.querySelectorAll('.ko-se-secret .ko-se-fluid-section');
      sections.forEach(section => {
        const cards = section.querySelectorAll('.ko-se-fluid-grid > .ko-se-fluid-card');
        cards.forEach((card, index) => {
          const legacyControls = card.querySelector('[data-attention-residue-controls]');
          if (legacyControls) {
            legacyControls.hidden = true;
            legacyControls.style?.setProperty?.('display', 'none', 'important');
          }
          const atelierActions = card.querySelector(':scope > .ca-hstatus-actions');
          if (atelierActions) {
            const hideBase = provider === 'aip';
            for (const node of atelierActions.querySelectorAll('[data-ca-kind="base"],[data-ca-info="base"]')) {
              node.hidden = hideBase;
              if (hideBase) node.style.setProperty('display', 'none', 'important');
              else node.style.removeProperty('display');
            }
            const hideActions = hideBase && !atelierActions.querySelector('[data-ca-kind="status"]');
            atelierActions.hidden = hideActions;
            if (hideActions) atelierActions.style.setProperty('display', 'none', 'important');
            else atelierActions.style.removeProperty('display');
          }
          const partInfo = FLUID_PARTS[index];
          if (!partInfo) return;
          const imageKey = residueImageKey(partInfo.part);
          if (!imageKey) return;
          const previousKey = card.dataset.aipResidueKey;
          const previousProvider = card.dataset.aipResidueProvider;
          card.dataset.aipResidueKey = imageKey;
          card.dataset.aipResidueProvider = provider;
          const entry = currentResidueImageChoices()[imageKey] || { selected: '', items: [] };
          const source = currentResiduePartSources()[partInfo.part];
          const selected = source === 'generate' ? entry.items.find(item => item.key === entry.selected) || null : null;
          const image = card.querySelector('img.ko-se-fluid-image');
          if (image) {
            const currentSrc = image.getAttribute?.('src') || image.src;
            if (previousKey !== imageKey || (!image.dataset.attentionResidueSelected && (!selected || currentSrc !== selected.url))) {
              image.dataset.attentionResidueAutoSrc = currentSrc;
            }
            if (selected) {
              image.dataset.attentionResidueSelected = selected.key;
              if (currentSrc !== selected.url) image.src = selected.url;
              image.style.objectFit = 'cover';
            } else if (image.dataset.attentionResidueSelected) {
              const autoUrl = image.dataset.attentionResidueAutoSrc;
              delete image.dataset.attentionResidueSelected;
              if (autoUrl && currentSrc !== autoUrl) image.src = autoUrl;
              image.style.objectFit = '';
            }
          }
          const expand = card.querySelector('.ko-se-fluid-expand');
          if (expand && !expand.dataset.attentionResidueFullscreenSync) {
            expand.dataset.attentionResidueFullscreenSync = '';
            const syncFullscreenImage = () => window.setTimeout(() => {
              const visibleImage = card.querySelector('img.ko-se-fluid-image');
              const fullscreenImage = document.querySelector('.ko-se-fullscreen-image');
              const src = visibleImage?.currentSrc || visibleImage?.src;
              if (fullscreenImage && src) {
                fullscreenImage.src = src;
                fullscreenImage.style.objectFit = visibleImage.dataset.attentionResidueSelected ? 'cover' : '';
              }
              const visibleOverlay = card.querySelector('.ko-se-status-overlay');
              const fullscreenOverlay = document.querySelector('.ko-se-fullscreen-overlay');
              const overlaySrc = visibleOverlay?.currentSrc || visibleOverlay?.src;
              if (fullscreenOverlay && overlaySrc) fullscreenOverlay.src = overlaySrc;
            }, 0);
            expand.addEventListener('click', syncFullscreenImage);
            expand.addEventListener('keydown', event => {
              if (event.key === 'Enter' || event.key === ' ') syncFullscreenImage();
            });
          }
          const existingControls = card.querySelector('[data-aip-residue-controls]');
          if (existingControls && (previousKey !== imageKey || previousProvider !== provider)) existingControls.remove();
          const existingSource = card.querySelector('[data-aip-residue-controls] [data-attention-residue-source]');
          if (existingSource) existingSource.value = source;
          const existingRegenerate = card.querySelector('[data-aip-residue-controls] [data-attention-residue-regenerate]');
          if (existingRegenerate) {
            existingRegenerate.disabled = source !== 'generate';
            existingRegenerate.textContent = source !== 'generate' ? '프리셋 사용 중'
              : provider === 'imagestudio' ? 'ImageStudio 검수 생성' : '이미지 재생성';
          }
          const existingPicker = card.querySelector('[data-aip-residue-controls] [data-attention-residue-select]');
          if (existingPicker) {
            existingPicker.disabled = source !== 'generate';
            existingPicker.textContent = `이미지 선택 (${entry.items.length})`;
          }
          if (card.querySelector('[data-aip-residue-controls],[data-ko-se-residue-settings],[data-ko-se-residue-regenerate]')) return;
          const controls = document.createElement('div');
          controls.dataset.aipResidueControls = '';
          controls.dataset.wmlUi = '';
          controls.style.cssText = 'display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px;padding:0 8px 8px;background:#0c0a09;';
          const button = (text, action) => {
            const element = document.createElement('button');
            element.type = 'button';
            element.textContent = text;
            element.style.cssText = 'flex:1;border:1px solid #57534e;border-radius:5px;background:#292524;color:#e7e5e4;padding:6px 8px;font-size:11px;cursor:pointer;';
            element.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); action(element); });
            return element;
          };
          const pickerButton = button(`이미지 선택 (${entry.items.length})`, () => openResidueImagePicker(imageKey, partInfo.label));
          pickerButton.dataset.attentionResidueSelect = '';
          pickerButton.disabled = source !== 'generate';
          const regenerateButton = button(source !== 'generate' ? '프리셋 사용 중'
            : provider === 'imagestudio' ? 'ImageStudio 검수 생성' : '이미지 재생성', element => regenerateResidueImage(imageKey, element));
          regenerateButton.dataset.attentionResidueRegenerate = '';
          regenerateButton.disabled = source !== 'generate';
          const sourceSelect = document.createElement('select');
          sourceSelect.dataset.attentionResidueSource = partInfo.part;
          sourceSelect.setAttribute('aria-label', `${partInfo.label} 이미지 표시 방식`);
          sourceSelect.style.cssText = 'grid-column:1/-1;width:100%;box-sizing:border-box;border:1px solid #57534e;border-radius:5px;background:#1c1917;color:#f5f5f4;padding:6px 8px;font-size:11px;';
          RESIDUE_PART_SOURCE_OPTIONS.forEach(([value, text]) => {
            const option = document.createElement('option');
            option.value = value;
            option.textContent = text;
            sourceSelect.append(option);
          });
          sourceSelect.value = source;
          sourceSelect.onchange = event => saveResiduePartSource(partInfo.part, event.currentTarget.value);
          controls.append(
            sourceSelect,
            provider === 'imagestudio'
              ? button('ImageStudio 검수창', () => globalThis.WW_ImageStudioPrompt?.open?.())
              : button('프롬프트 수정', () => openResiduePromptEditor(imageKey, partInfo.label)),
            regenerateButton,
            pickerButton,
            ...(provider === 'imagestudio' ? [] : [button('상태별 생성', () => openResidueBatchManager(partInfo.part))]),
          );
          card.append(controls);
        });
      });
    }

    function ensureSecretTabCompatibility() {
      const portraitSelector = 'button[title*="초상화"],button[title*="Portrait"]';
      const modernBars = new Set([...document.querySelectorAll('#root button[title*="초상화"],#root button[title*="Portrait"]')].map(button => button.parentElement).filter(Boolean));
      const candidates = new Set([...modernBars, ...document.querySelectorAll('#root div.flex.flex-wrap.border-b')]);
      for (const bar of candidates) {
        const buttons = [...bar.children].filter(node => node.tagName === 'BUTTON');
        const portrait = bar.querySelector(portraitSelector);
        const status = modernBars.has(bar)
          ? buttons.find(node => node !== portrait && !node.hasAttribute('data-ko-se-secret-tab'))
          : buttons.find(node => /^(상태|Stats)$/.test(node.textContent.trim()));
        if (!status) continue;
        const secret = bar.querySelector('[data-ko-se-secret-tab]');
        if (secret && modernBars.has(bar)) {
          if (secret.previousElementSibling !== status) status.after(secret);
          secret.classList.add('flex-1', 'py-1.5', 'border-l', 'transition-colors');
          secret.classList.remove('px-2', 'desk:px-3', 'rounded-t', '-mb-px', 'border-b-2');
          secret.dataset.attentionSecretLayout = 'current';
          continue;
        }
        if (secret || bar.dataset.attentionSecretTabKick || !globalThis.__waywardSituationEventMod) continue;
        bar.dataset.attentionSecretTabKick = 'true';
        const originalClass = bar.className;
        const originalChildren = [...bar.children];
        bar.classList.add('flex-wrap', 'border-b');
        if (buttons[0] !== status) bar.insertBefore(status, buttons[0]);
        setTimeout(() => {
          if (!status.isConnected || status.parentElement !== bar) return;
          originalChildren.forEach(node => { if (node.parentElement === bar) bar.append(node); });
          const addedSecret = bar.querySelector('[data-ko-se-secret-tab]');
          if (addedSecret) bar.append(addedSecret);
          bar.className = originalClass;
          scheduleUiScan();
        }, 0);
      }
    }
