    const externalPresetSelections = new Map();
    const externalPresetNames = new Map();

    function renderExternalPrompts(h, win, menu) {
      const inputStyle = 'min-width:0;max-width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:inherit;';
      const allPresets = currentExternalPromptPresets();
      const presets = allPresets.filter(preset => preset && preset.modId === menu.id && Array.isArray(preset.entries));
      const selected = presets.find(preset => preset.id === externalPresetSelections.get(menu.id));
      const selectedProvider = entry => {
        const provider = entry.activeProvider;
        if (entry.aipField && provider) {
          const target = externalPromptMenus().find(item => item.id === provider.id)?.entries.find(item => item.id === provider.entryId);
          if (target) return { owner: provider.id, id: provider.entryId, source: 'mod', entry: target, title: provider.title };
        }
        return { owner: menu.id, id: entry.id, source: entry.aipField ? 'aip' : 'mod', entry, title: menu.title };
      };
      const savePreset = () => {
        const name = String(externalPresetNames.get(menu.id) || '').trim().slice(0, 80);
        if (!name) {
          settingsMessage = '프리셋 이름을 입력해 주세요.';
          win.refresh();
          return;
        }
        if (presets.length >= 50 || allPresets.length >= 200) {
          settingsMessage = presets.length >= 50 ? '이 모드의 프리셋은 최대 50개까지 저장할 수 있습니다.' : '다른 모드 프리셋은 총 200개까지 저장할 수 있습니다.';
          win.refresh();
          return;
        }
        promptPresetCounter += 1;
        const id = `external-${Date.now().toString(36)}-${promptPresetCounter}`;
        const currentMenu = externalPromptMenus().find(item => item.id === menu.id);
        const entries = (currentMenu?.entries || []).map(entry => {
          const provider = selectedProvider(entry);
          return { id: entry.id, source: provider.source, providerOwner: provider.owner, providerEntryId: provider.id,
            positivePrompt: provider.entry.positivePrompt, negativePrompt: provider.entry.negativePrompt,
            ...(entry.target?.kind === 'outfit' ? { topPrompt: provider.entry.topPrompt, skirtPrompt: provider.entry.skirtPrompt } : {}) };
        });
        api.settings.set({ externalPromptPresets: [...allPresets, { id, modId: menu.id, name, entries }] });
        externalPresetSelections.set(menu.id, id);
        externalPresetNames.delete(menu.id);
        settingsMessage = `${name} 프리셋을 저장했습니다.`;
        win.refresh();
      };
      const applyPreset = () => {
        if (!selected) return;
        let count = 0;
        for (const saved of selected.entries) {
          const entry = menu.entries.find(item => item.id === saved.id);
          if (!entry) continue;
          const source = saved.source === 'aip' && entry.aipField ? 'aip' : 'mod';
          if (source === 'aip' && entry.unavailable) continue;
          const owner = source === 'aip' ? menu.id : saved.providerOwner || menu.id;
          const id = source === 'aip' ? entry.id : saved.providerEntryId || entry.id;
          const provider = externalPromptMenus().find(item => item.id === owner)?.entries.find(item => item.id === id);
          if (!provider || (entry.aipField && provider.aipField !== entry.aipField) || (!entry.aipField && (owner !== menu.id || id !== entry.id))) continue;
          setExternalPromptSource(owner, id, source);
          saveExternalPrompt(owner, id, source, { positivePrompt: String(saved.positivePrompt ?? ''),
            negativePrompt: String(saved.negativePrompt ?? ''),
            ...(typeof saved.topPrompt === 'string' ? { topPrompt: saved.topPrompt } : {}),
            ...(typeof saved.skirtPrompt === 'string' ? { skirtPrompt: saved.skirtPrompt } : {}) });
          count += 1;
        }
        activeTagTarget = null;
        settingsMessage = `${selected.name} 프리셋의 ${count}개 항목을 적용했습니다.`;
        win.refresh();
      };
      return [
        h('div', { class: 'wml-note', 'data-external-presets': menu.id },
          h('strong', {}, '이 모드의 프롬프트 프리셋'),
          h('p', { class: 'wml-muted wml-small' }, '이 메뉴의 항목과 선택한 제공자를 함께 저장합니다. 같은 기능을 공유하는 메뉴에는 제공자 선택이 함께 반영됩니다.'),
          h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;' },
            h('input', { type: 'text', value: externalPresetNames.get(menu.id) || '', maxlength: 80,
              placeholder: '새 프리셋 이름', 'aria-label': '새 프리셋 이름', 'data-external-preset-name': menu.id, style: inputStyle,
              oninput: event => externalPresetNames.set(menu.id, event.currentTarget.value) }),
            api.ui.button('현재 설정 저장', savePreset),
            h('select', { 'aria-label': '저장된 프리셋', 'data-external-preset-select': menu.id,
              style: inputStyle, value: selected?.id || '', onchange: event => { externalPresetSelections.set(menu.id, event.currentTarget.value); win.refresh(); } },
            h('option', { value: '', selected: !selected }, '저장된 프리셋 선택'),
            ...presets.map(preset => h('option', { value: preset.id, selected: preset.id === selected?.id }, preset.name))),
            api.ui.button('선택 적용', applyPreset, { disabled: !selected }),
            api.ui.button('선택 삭제', () => {
              if (!selected) return;
              api.settings.set({ externalPromptPresets: allPresets.filter(preset => preset !== selected) });
              externalPresetSelections.delete(menu.id);
              settingsMessage = `${selected.name} 프리셋을 삭제했습니다.`;
              win.refresh();
            }, { disabled: !selected }))),
        ...menu.entries.map(entry => {
          const provider = selectedProvider(entry);
          const unavailable = entry.unavailable && provider.source === 'aip';
          const customOutfitOriginal = provider.source === 'aip' && entry.target?.kind === 'outfit'
            && String(entry.target.id).startsWith('aip-outfit-');
          const choices = entry.aipField ? externalPromptMenus().flatMap(item => item.entries
            .filter(candidate => candidate.aipField === entry.aipField)
            .map(candidate => ({ owner: item.id, id: candidate.id, title: item.title, label: candidate.label }))) : [];
          const save = (field, value, updateView = true) => {
            saveExternalPrompt(provider.owner, provider.id, provider.source, { [field]: value });
            if (updateView) win.refresh();
          };
          return h('div', { class: 'aip-state-row', 'data-external-prompt-entry': entry.id },
            h('div', { class: 'aip-state-row-head' }, h('strong', {}, entry.label),
              api.ui.button('선택한 제공자의 기본값으로 복원', () => {
                const reset = resetExternalPrompt(provider.owner, provider.id, provider.source);
                settingsMessage = reset ? `${entry.label}의 ${provider.source === 'aip' ? 'AIP' : provider.title} 기본값을 복원했습니다.`
                  : '이 항목에는 복원할 기본값이 없습니다.';
                win.refresh();
              }, { disabled: unavailable || customOutfitOriginal })),
            entry.hook ? h('p', { class: 'wml-muted wml-small' }, `연결: ${entry.hook}`) : null,
            entry.unavailable ? h('p', { class: 'wml-muted wml-small' }, '연결 대상이 현재 없어 AIP 원본을 편집할 수 없습니다. 대상이 다시 생기면 저장된 설정을 사용할 수 있습니다.') : null,
            customOutfitOriginal ? h('p', { class: 'wml-muted wml-small' }, '직접 만든 의상은 작성한 내용이 원본이므로 별도의 기본값이 없습니다.') : null,
            entry.aipField ? h('label', { style: 'display:grid;gap:4px;margin:8px 0;' },
              h('strong', {}, '사용할 프롬프트'),
              h('select', { value: provider.source === 'aip' ? 'aip' : `${provider.owner}/${provider.id}`, 'data-external-prompt-source': entry.id, style: inputStyle,
                onchange: event => {
                  const choice = event.currentTarget.value;
                  if (choice === 'aip') setExternalPromptSource(menu.id, entry.id, 'aip');
                  else {
                    const candidate = choices.find(item => `${item.owner}/${item.id}` === choice);
                    if (candidate) setExternalPromptSource(candidate.owner, candidate.id, 'mod');
                  }
                  activeTagTarget = null;
                  win.refresh();
                } },
              h('option', { value: 'aip', selected: provider.source === 'aip' }, 'AIP 프롬프트'),
              ...choices.map(item => h('option', { value: `${item.owner}/${item.id}`,
                selected: provider.source === 'mod' && provider.owner === item.owner && provider.id === item.id },
              `${item.title} · ${item.label}`))),
              h('span', { class: 'wml-muted wml-small' }, '선택한 제공자의 프롬프트를 아래에서 편집합니다. 전환해도 각각의 수정 내용은 유지됩니다.')) : null,
            h('div', { class: 'aip-prompt-pair' }, ...[
              ['positivePrompt', 'Positive · 넣을 표현'], ['negativePrompt', 'Negative · 피할 표현'],
              ...(entry.target?.kind === 'outfit' ? [['topPrompt', '상의 · 부분 탈의'], ['skirtPrompt', '하의 · 부분 탈의']] : []),
            ].map(([field, label]) => {
              const value = provider.entry[field] ?? '';
              let currentValue = value;
              const chips = h('div', {}, promptTagChips(h, value, win));
              return h('label', { class: 'aip-prompt-field' },
                h('strong', {}, label),
                h('textarea', { rows: 3, value, spellcheck: false, disabled: unavailable,
                  'data-external-prompt-field': `${entry.id}:${field}`,
                  style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:68px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
                  onfocus: () => { activeTagTarget = { kind: 'external-prompt', modId: provider.owner, entryId: provider.id,
                    tabModId: menu.id, source: provider.source, field, label: `${provider.source === 'aip' ? 'AIP' : provider.title} · ${entry.label} ${field === 'negativePrompt' ? 'Negative' : 'Positive'}` }; },
                  oninput: event => {
                    currentValue = event.currentTarget.value;
                    save(field, currentValue, false);
                    const updated = promptTagChips(h, currentValue, win);
                    chips.replaceChildren(...(updated ? [updated] : []));
                  },
                }),
                chips,
                unavailable ? null : promptTagAdder(h, () => currentValue, next => save(field, next), `external:${menu.id}:${entry.id}:${field}`));
            })));
        }),
      ];
    }

    function renderGenerationWeightSettings(h, win) {
      const settings = generationWeightSettings();
      const selectedWeights = { stepsPercent: settings.stepsPercent, cfgPercent: settings.cfgPercent, loraPercent: settings.loraPercent };
      const controls = [
        { key: 'stepsPercent', saved: 'generationWeightStepsPercent', id: 'steps', label: 'Steps', guide: '낮추면 장면마다 단계 수가 덜 달라져요. 높이면 긴 프롬프트에서 단계가 늘어나 생성 시간이 길어질 수 있어요.' },
        { key: 'cfgPercent', saved: 'generationWeightCfgPercent', id: 'cfg', label: 'CFG', guide: '낮추면 장면마다 프롬프트 반영 강도의 차이가 줄어요. 높이면 긴 프롬프트를 더 강하게 따르지만 그림 느낌이 달라질 수 있어요.' },
        { key: 'loraPercent', saved: 'generationWeightLoraPercent', id: 'lora', label: 'LoRA', guide: '낮추면 LoRA 강도를 기준값 1.0에 가깝게 유지해요. 높이면 긴 프롬프트에서 강도가 더 낮아져 LoRA의 화풍 영향이 줄 수 있어요.' },
      ];
      const examples = [['짧음 · 40개 이하', 40], ['중간 · 41~60개', 50], ['김 · 61개 이상', 81]];
      const previewNodes = examples.map(() => h('span', { style: 'font-variant-numeric:tabular-nums;' }));
      const currentHeading = h('strong', {});
      const currentPreview = h('div', { 'data-aip-generation-weight-current-values': '', style: 'font-variant-numeric:tabular-nums;' });
      const currentStatus = h('span', { class: 'wml-muted wml-small' });
      const describe = value => `Steps ${value.steps} · CFG ${value.cfg} · LoRA ${value.loraStrength}`;
      const updatePreview = () => {
        examples.forEach(([, count], index) => {
          const prompt = Array(count).fill('tag').join(', ');
          const original = generationWeightForPrompt(prompt, 100);
          const selected = generationWeightForPrompt(prompt, selectedWeights);
          previewNodes[index].textContent = `게임 기본 ${describe(original)} → 선택한 설정 ${describe(selected)}`;
        });
        const currentPrompt = generationWeightCurrentPortraitPrompt();
        const currentCount = typeof currentPrompt === 'string' && currentPrompt.trim()
          ? currentPrompt.split(',').filter(tag => tag.trim()).length : 0;
        currentHeading.textContent = currentCount ? `현재 초상화 · ${currentCount}개 항목` : '현재 초상화';
        const note = 'AIP가 마지막으로 계산한 현재 Positive 기준 예상값이에요. 이후 다른 모드나 생성 방식에 따라 실제 값은 달라질 수 있어요.';
        currentStatus.textContent = settings.enabled && !generationWeightStyleLockActive()
          ? note : `조절이 꺼져 있거나 다른 설정에 막힌 상태예요. ${note}`;
        currentPreview.textContent = currentCount
          ? `게임 기본 ${describe(generationWeightForPrompt(currentPrompt, 100))} → 선택한 설정 ${describe(generationWeightForPrompt(currentPrompt, selectedWeights))}`
          : '현재 프롬프트 없음 · 초상화가 표시된 뒤 다시 확인해 주세요.';
      };
      updatePreview();
      return h('section', { 'data-aip-generation-weight-settings': '', style: 'display:grid;gap:10px;margin-bottom:18px;' },
        h('h4', { style: 'margin:0;font-size:14px;' }, '프롬프트 길이별 생성 설정'),
        h('label', { style: 'display:flex;align-items:center;gap:8px;cursor:pointer;' },
          h('input', { type: 'checkbox', checked: settings.enabled, 'data-aip-generation-weight-enabled': '',
            onchange: event => { api.settings.set({ generationWeightEnabled: event.currentTarget.checked }); win.refresh(); } }),
          h('span', {}, '길이에 따른 생성 설정 변화폭 조절')),
        h('p', { class: 'wml-muted wml-small', style: 'margin:0;' },
          '기준값은 Steps 8 · CFG 1.5 · LoRA 1.0이에요. 0%는 기준값 고정, 100%는 게임 기본 변화폭, 200%는 그 두 배예요. 길어지면 LoRA 강도는 낮아질 수 있어요.'),
        ...controls.map(control => {
          const output = h('output', { [`data-aip-generation-weight-${control.id}-value`]: '', style: 'font-weight:700;font-variant-numeric:tabular-nums;' }, `${selectedWeights[control.key]}%`);
          return h('label', { style: 'display:grid;gap:5px;' },
            h('span', { style: 'display:flex;justify-content:space-between;gap:10px;' }, `${control.label} 변화폭`, output),
            h('input', { type: 'range', min: 0, max: 200, step: 5, value: selectedWeights[control.key],
              disabled: !settings.enabled, [`data-aip-generation-weight-${control.id}`]: '', 'aria-label': `${control.label} 변화폭`,
              'aria-valuetext': `${selectedWeights[control.key]}%`, style: 'width:100%;accent-color:#fbbf24;',
              oninput: event => {
                const percent = Math.max(0, Math.min(200, Number(event.currentTarget.value)));
                selectedWeights[control.key] = percent;
                api.settings.set({ [control.saved]: percent });
                output.textContent = `${percent}%`;
                event.currentTarget.setAttribute?.('aria-valuetext', `${percent}%`);
                updatePreview();
              } }),
            h('span', { class: 'wml-muted wml-small' }, control.guide));
        }),
        h('div', { 'data-aip-generation-weight-preview': '', style: 'display:grid;gap:5px;' },
          h('strong', { style: 'font-size:12px;' }, '게임 기본값과 선택한 변화폭 예상값'),
          ...examples.map(([label], index) => h('div', { style: 'display:flex;flex-wrap:wrap;justify-content:space-between;gap:4px 12px;font-size:12px;' },
            h('span', {}, label), previewNodes[index]))),
        h('div', { 'data-aip-generation-weight-current': '', style: 'display:grid;gap:4px;font-size:12px;' },
          currentHeading,
          currentPreview,
          currentStatus,
          api.ui.button('현재 초상화 다시 확인', () => win.refresh())),
        settings.enabled && generationWeightStyleLockActive() ? h('p', { class: 'wml-note', role: 'status', style: 'margin:0;' },
          '그림체 고정 모드의 “그림 설정 고정”이 켜져 있어 이 값이 적용되지 않아요. 그 설정만 꺼 주세요.') : null,
        h('p', { class: 'wml-muted wml-small', style: 'margin:0;' },
          '새 일반 이미지 생성에 적용돼요. 기존 이미지는 바뀌지 않으며, Anima·NovelAI와 다른 모드의 별도 설정은 다르게 적용될 수 있어요. 다른 모드의 설정은 변경하지 않아요.'),
        h('details', { 'data-aip-generation-weight-guide': '' },
          h('summary', { style: 'cursor:pointer;' }, '화풍을 비슷하게 유지하는 방법'),
          h('p', { class: 'wml-muted wml-small' },
            '변화폭을 낮추면 장면별 생성 설정 차이가 줄어들 수 있어요. 먼저 0~50%를 비교해 보세요. 비교할 때는 모델·LoRA·Negative와 시드를 같게 맞추는 게 좋아요. motion lines 같은 장면 태그도 그림 느낌에 영향을 줄 수 있어요. 기존 그림은 그대로이므로 초상화의 + 버튼으로 새 그림을 만들어 비교하세요.')));
    }

    function renderPromptTagSearch(h) {
      const input = h('input', { type: 'search', 'aria-label': '찾을 프롬프트 태그',
        'data-prompt-tag-search-input': '', placeholder: '예: side view 또는 side_view', maxLength: 200,
        style: 'flex:1;min-width:0;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;' });
      const status = h('p', { class: 'wml-muted wml-small', 'data-prompt-tag-search-status': '', 'aria-live': 'polite', style: 'margin:0;' },
        '검색 버튼을 누르면 현재 프롬프트와 저장된 후보를 확인해요.');
      const results = h('div', { 'data-prompt-tag-search-results': '', style: 'display:grid;gap:8px;' });
      const run = event => {
        event.preventDefault();
        const query = input.value.trim();
        results.replaceChildren();
        if (!query) { status.textContent = '찾을 태그를 입력해 주세요.'; return; }
        let response;
        try { response = searchPromptTag(query); }
        catch { status.textContent = '검색하지 못했어요. 다시 시도해 주세요.'; return; }
        const matches = Array.isArray(response?.matches) ? response.matches : [];
        const warnings = Array.isArray(response?.warnings) ? response.warnings : [];
        status.textContent = matches.length ? `검색 결과 ${matches.length}개 · 조회 시점 기준` : '일치하는 프롬프트가 없어요.';
        const warningNodes = warnings.map(warning => h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, String(warning)));
        const list = h('div', { style: 'display:grid;gap:8px;' });
        const more = h('button', { type: 'button', class: 'wml-btn', 'data-prompt-tag-search-more': '' }, '더 보기');
        let shown = 0;
        const showMore = () => {
          const next = matches.slice(shown, shown + 100);
          list.append(...next.map(match => h('div', { 'data-prompt-tag-search-match': '', style: 'border:1px solid #57534e;border-radius:6px;padding:8px;min-width:0;overflow-wrap:anywhere;' },
            h('strong', { style: 'font-size:12px;' }, `${match.scope === 'current' ? '현재 장면' : '설정·기본 후보'} · ${match.location || '위치 확인 불가'}`),
            h('div', { class: 'wml-muted wml-small', style: 'margin-top:4px;' }, `${match.source || '출처 확인 불가'} · ${match.polarity === 'negative' ? 'Negative' : 'Positive'}${match.field ? ` · ${match.field}` : ''}`),
            h('div', { style: 'margin-top:4px;white-space:pre-wrap;font:12px/1.45 ui-monospace,Consolas,monospace;' },
              Array.isArray(match.matchedTags) ? match.matchedTags.join(', ') : ''),
            h('details', { style: 'margin-top:4px;' }, h('summary', { style: 'cursor:pointer;font-size:12px;' }, '전체 문구 보기'),
              h('div', { style: 'white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.45 ui-monospace,Consolas,monospace;' }, String(match.prompt || ''))))));
          shown += next.length;
          more.hidden = shown >= matches.length;
        };
        more.addEventListener('click', showMore);
        showMore();
        results.replaceChildren(...warningNodes, list, more);
      };
      return h('section', { 'data-prompt-tag-search': '', style: 'display:grid;gap:8px;margin-top:20px;' },
        h('h4', { style: 'margin:0;font-size:14px;' }, '태그가 사용되는 상황 찾기'),
        h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '현재 장면과 확인 가능한 설정·게임 기본 후보에서 태그를 찾아요. 후보는 조건에 따라 적용되지 않을 수 있어요.'),
        h('form', { onsubmit: run, style: 'display:flex;flex-wrap:wrap;gap:8px;align-items:center;' }, input,
          h('button', { type: 'submit', class: 'wml-btn', 'data-prompt-tag-search-submit': '' }, '검색')),
        status, results);
    }

    function renderGameDefaultPrompt(h, win) {
      const saved = currentGameDefaultPrompts();
      return [renderGenerationWeightSettings(h, win), h('div', { class: 'aip-prompt-pair' }, ...[['positive', 'positivePrompt', '게임 공통 품질 Positive 프롬프트', GAME_PROMPT_QUALITY],
        ['negative', 'negativePrompt', '게임 공통 Negative 프롬프트', GAME_PROMPT_NEGATIVE]].map(([polarity, field, label, fallback]) => {
        const value = saved[field] ?? fallback;
        const save = (next, updateView = true) => {
          api.settings.set({ gameDefaultPrompts: { ...currentGameDefaultPrompts(), [field]: next } });
          if (updateView) win.refresh();
        };
        return h('label', { class: 'aip-prompt-field' },
          h('strong', {}, label),
          h('textarea', { rows: 5, value, spellcheck: false,
            'data-game-default-prompt': polarity,
            style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:100px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
            onfocus: () => { activeTagTarget = { kind: 'game-default', polarity, label: `게임 기본 ${polarity === 'negative' ? 'Negative' : 'Positive'}` }; },
            oninput: event => { save(event.currentTarget.value, false); updatePromptTagPreview(event, h, win); },
            onchange: event => save(event.currentTarget.value),
          }),
          promptTagPreview(h, value, win),
          promptTagAdder(h, value, save, `game-default:${polarity}`),
          api.ui.button(`${polarity === 'negative' ? 'Negative' : 'Positive'} 게임 원본으로 복원`, () => {
            const next = currentGameDefaultPrompts();
            delete next[field];
            api.settings.set({ gameDefaultPrompts: next });
            win.refresh();
          }),
          h('span', { class: 'wml-muted wml-small' }, polarity === 'negative'
            ? '비우면 게임 공통 Negative만 빠지고 장면·아내 Negative는 유지됩니다.'
            : '새로 생성하는 이미지에 적용됩니다. 기존 이미지는 자동으로 다시 만들지 않습니다.'));
      })),
        h('section', { 'data-global-prompt-exclusions-settings': '', style: 'display:grid;gap:8px;margin-top:20px;' },
          h('h4', { style: 'margin:0;font-size:14px;' }, '특정 프롬프트 전역 제거'),
          h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '모든 장면의 해당 영역에서 입력한 태그를 제거해요. 쉼표나 줄바꿈으로 구분하며, 일반 태그와 가중치가 붙은 같은 태그를 모두 제거해요.'),
          h('div', { class: 'aip-prompt-pair' }, ...[['positive', 'Positive에서 제거'], ['negative', 'Negative에서 제거']].map(([polarity, label]) => {
            const excluded = currentGlobalPromptExclusions(polarity);
            const status = h('span', { class: 'wml-muted wml-small', 'aria-live': 'polite' });
            const save = (value, refresh = true) => {
              const ok = saveGlobalPromptExclusions(value, polarity);
              status.textContent = ok ? '' : '저장하지 못했어요. 입력 내용을 확인하고 다시 시도해 주세요.';
              if (ok && refresh) { refreshPortraitImage(); win.refresh(); }
            };
            return h('label', { class: 'aip-prompt-field' }, h('strong', {}, label),
              h('textarea', { rows: 3, value: excluded, maxLength: 12000, spellcheck: false,
                placeholder: '예: motion lines, sweat', 'data-global-prompt-exclusions': polarity,
                style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:72px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
                onfocus: () => { activeTagTarget = { kind: 'global-exclusions', polarity, label: `전역 ${label}` }; },
                oninput: event => { save(event.currentTarget.value, false); updatePromptTagPreview(event, h, win); },
                onchange: event => save(event.currentTarget.value),
              }), promptTagPreview(h, excluded, win), status);
          })),
          h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '각 칸을 비우면 해당 영역에서 제거하지 않아요. 새 이미지에 적용되며 직접 선택한 기존 이미지는 그대로 보일 수 있어요.')),
        renderPromptTagSearch(h)];
    }

    function renderCharacterPrompt(h, win) {
      const context = currentWifePromptContext();
      if (pendingWifePromptEdit && pendingWifePromptEdit.wifeKey !== context.wifeKey) pendingWifePromptEdit = null;
      const override = characterPromptOverride(context);
      const characterPrompt = {
        ...currentWifeCharacterPrompt(context),
        ...(pendingWifePromptEdit?.wifeKey === context.wifeKey ? pendingWifePromptEdit.values : {}),
      };
      const sources = wifePromptSources();
      return [
        h('div', {
          'data-current-wife-character': context.wifeKey,
          class: 'wml-note',
          style: 'margin-bottom:10px;',
        }, `현재 아내 · ${context.name}${context.wifeKey ? ` (${context.wifeKey})` : ''}`),
        h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
          h('strong', { style: 'font-size:12px;' }, '외형 프롬프트 불러오기'),
          h('select', {
            value: override?.sourceId || '',
            'data-character-prompt-source': '',
            style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
            onchange: event => {
              const sourceId = event.currentTarget.value;
              const source = sources.find(entry => entry.id === sourceId);
              if (source) {
                const prompt = promptFromWifeArchetype(source.archetype);
                saveCurrentWifeCharacterPrompt({
                  positivePrompt: prompt.positivePrompt,
                  negativePrompt: prompt.negativePrompt,
                  sourceId,
                });
              } else {
                saveCurrentWifeCharacterPrompt({ sourceId: '' });
              }
              win.refresh();
            },
          },
          h('option', { value: '' }, '현재 적용 중인 외형 · 직접 수정'),
          ...sources.map(source => h('option', { value: source.id }, `${source.custom ? '사용자 아내' : '기본 캐릭터'} · ${source.name}`))),
          h('span', { class: 'wml-muted wml-small' }, '선택한 캐릭터의 외형 Positive·전용 Negative를 현재 아내에게 불러옵니다.'),
        ),
        h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
          h('strong', { style: 'font-size:12px;' }, '기존 장면 이미지 처리'),
          h('select', {
            value: characterPrompt.imagePolicy,
            'data-character-image-policy': '',
            style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
            onchange: event => {
              saveCurrentWifeCharacterPrompt({ imagePolicy: event.currentTarget.value === 'regenerate' ? 'regenerate' : 'reuse' });
              win.refresh();
            },
          },
          h('option', { value: 'reuse' }, '기존 이미지 우선 · 필요한 장면만 수동 생성'),
          h('option', { value: 'regenerate' }, '정확한 이미지가 없으면 장면별 자동 생성')),
          h('span', { class: 'wml-muted wml-small' }, '기존 이미지 우선은 대량 재생성을 막습니다. 초상화의 이미지 추가 버튼으로 만든 새 이미지에는 수정한 프롬프트가 적용됩니다.'),
        ),
        h('div', { class: 'aip-prompt-pair' }, ...[['positive', 'positivePrompt', '현재 적용 중인 전체 Positive 외형 프롬프트'],
          ['negative', 'negativePrompt', '아내 전용 Negative 프롬프트 · 게임 기본·장면 Negative 유지']]
          .map(([polarity, field, label]) => {
            const value = characterPrompt[field];
            const save = (next, updateView = true) => {
              saveCurrentWifeCharacterPrompt({ [field]: next, sourceId: '' });
              if (updateView) win.refresh();
            };
            return h('label', { class: 'aip-prompt-field' },
              h('strong', {}, label),
              h('textarea', { rows: 5, value, spellcheck: false,
                'data-character-prompt': polarity,
                style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:100px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
                onfocus: () => { activeTagTarget = { kind: 'character', polarity, label: `아내 캐릭터 ${polarity === 'negative' ? 'Negative' : 'Positive'}` }; },
                oninput: event => {
                  const values = pendingWifePromptEdit?.wifeKey === context.wifeKey ? pendingWifePromptEdit.values : {};
                  pendingWifePromptEdit = { wifeKey: context.wifeKey, values: { ...values, [field]: event.currentTarget.value } };
                  save(event.currentTarget.value, false);
                  updatePromptTagPreview(event, h, win);
                },
                onchange: event => save(event.currentTarget.value),
              }),
              promptTagPreview(h, value, win),
              promptTagAdder(h, value, save, `character:${polarity}`));
          })),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;' },
          api.ui.button('현재 아내 원본 외형으로 복원', () => {
            api.settings.set({ characterPrompt: { ...DEFAULT_CHARACTER_PROMPT } });
            pendingWifePromptEdit = null;
            publishCurrentWifePromptProfile();
            win.refresh();
          }),
          h('span', { class: 'wml-muted wml-small' }, '수정값은 추가되지 않고 현재 아내의 기본 외형 묶음을 교체합니다.'),
        ),
      ];
    }

    let scenePromptEditorId = '';
    const SCENE_PROMPT_EXAMPLES = [
      ['scene-patron_chatting', '손님과 대화'],
      ['scene-patron_flirting', '손님과 장난스러운 대화'],
      ['scene-patron_touching', '손님의 가벼운 스킨십'],
      ['scene-patron_bold', '손님의 대담한 스킨십'],
      ['scene-patron_groping', '손님의 애무'],
      ['scene-patron_intimate', '손님과 친밀한 접촉'],
    ];

    function renderScenePrompts(h, win) {
      const state = api.store.game();
      const currentKey = activePortraitImageKey('', state);
      const currentId = positionSituationId(currentKey);
      const saved = currentPositionStatePrompts();
      const catalog = scenePromptCatalog(currentId);
      const labels = new Map(catalog.map(entry => [entry.id, entry.label]));
      const table = api.has('gameScenePromptTable') ? api.fn('gameScenePromptTable') : null;
      const tableAvailable = table && typeof table === 'object' && !Array.isArray(table)
        && Array.isArray(table.kissing) && Array.isArray(table.patron_chatting);
      if (!scenePromptEditorId || !labels.has(scenePromptEditorId)) scenePromptEditorId = currentId || SCENE_PROMPT_EXAMPLES[0][0];
      const id = scenePromptEditorId;
      const categories = [['task', '일상 활동'], ['scene', '상호작용·장면'], ['look', '시선·반응'], ['other', '기타·모드']];
      const category = catalog.find(entry => entry.id === id)?.category || 'other';
      const categoryEntries = catalog.filter(entry => entry.category === category);
      const own = saved[id] || { positivePrompt: '', negativePrompt: '', onlyState: false };
      const effective = currentPositionStatePrompt(id);
      const direct = saved[currentId] || { positivePrompt: '', negativePrompt: '', onlyState: false };
      const inheritedByCurrent = currentId && currentId !== id && basePositionSituationId(currentId) === id
        && !currentId.includes('|sleep-') && !saved[currentId]
        && effectiveExternalTarget('position-state', currentId, direct) === direct;
      const active = currentId === id || inheritedByCurrent;
      const inherited = !saved[id] && effective;
      const overridden = saved[id] && effective && (effective.positivePrompt !== own.positivePrompt || effective.negativePrompt !== own.negativePrompt);
      const nativeVariants = nativeScenePromptCandidates(id);
      const lastPrompt = active && currentKey && state?.primaryCharacterId && latestScenePrompt?.characterId === state.primaryCharacterId
        && latestScenePrompt?.result?.key === currentKey ? latestScenePrompt.result : null;
      const update = (field, value, refresh) => {
        const next = currentPositionStatePrompts();
        const entry = { positivePrompt: '', negativePrompt: '', onlyState: false, ...next[id], [field]: value.trim() };
        if (entry.positivePrompt || entry.negativePrompt || entry.onlyState) next[id] = entry;
        else delete next[id];
        api.settings.set({ positionStatePrompts: next });
        positionRandomChoices.clear();
        if (refresh) {
          if (active) refreshPortraitImage();
          win.refresh();
        }
      };
      return [
        h('p', { class: 'wml-muted wml-small', 'data-scene-prompt-edit-guide': '' }, '상황을 선택해 기본 문구를 바꾸거나 추가 문구를 설정해요.'),
        !tableAvailable ? h('p', { class: 'wml-note', 'data-scene-prompt-partial': '' }, '기본 장면 전체 목록을 읽지 못해 일부 예시와 현재·저장한 장면만 표시해요.') : null,
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:8px 12px;align-items:end;margin:12px 0 6px;min-width:0;' },
          h('label', { style: 'display:grid;gap:4px;flex:1 1 130px;min-width:0;max-width:100%;' }, h('strong', {}, '상황 분류'),
            h('select', { value: category, style: 'width:100%;min-width:0;max-width:100%;', 'data-scene-prompt-category': '', onchange: event => {
              const first = catalog.find(entry => entry.category === event.currentTarget.value);
              if (first) { scenePromptEditorId = first.id; activeTagTarget = null; win.refresh(); }
            } }, ...categories.filter(([value]) => catalog.some(entry => entry.category === value)).map(([value, label]) =>
              h('option', { value, selected: value === category }, label)))),
          h('label', { style: 'display:grid;gap:4px;flex:2 1 220px;min-width:0;max-width:100%;' }, h('strong', {}, '편집할 상황'),
            h('select', { value: id, style: 'width:100%;min-width:0;max-width:100%;', 'data-scene-prompt-select': '', onchange: event => { scenePromptEditorId = event.currentTarget.value; activeTagTarget = null; win.refresh(); } },
              ...categoryEntries.map(entry => h('option', { value: entry.id, selected: entry.id === id }, entry.label)))),
          currentId ? api.ui.button('현재 장면 선택', () => { scenePromptEditorId = currentId; activeTagTarget = null; win.refresh(); }) : null),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:4px 14px;align-items:center;margin-bottom:16px;' },
          h('span', { class: 'wml-muted wml-small', 'data-scene-prompt-active': '' }, currentId
            ? `현재: ${positionSituationLabel(currentId)} · ${active ? '선택한 상황' : '다른 상황을 편집 중'}`
            : '현재 상황을 확인할 수 없어요. 목록에서 미리 설정할 수 있어요.'),
          h('span', { class: 'wml-muted wml-small' }, 'ID: ', h('code', { 'data-scene-prompt-id': '' }, id))),
        h('section', { style: 'border-top:1px solid #44403c;padding-top:4px;' }, ...renderSceneBaseOverride(h, win, id, currentKey)),
        renderSceneCandidateEditor(h, win, id, currentKey),
        h('h4', { style: 'margin:18px 0 6px;' }, '추가 프롬프트'),
        inherited ? h('p', { class: 'wml-note' }, '이 장면에는 기본 장면의 문구가 적용 중이에요. 여기에 입력하면 이 장면에 별도로 적용돼요.') : null,
        overridden ? h('p', { class: 'wml-note' }, '다른 모드의 프롬프트 설정이 이 장면의 저장값에 영향을 주고 있어요.') : null,
        own.onlyState ? h('p', { class: 'wml-note' }, '이 장면은 기존 체위 설정에서 상태 프롬프트만 적용하도록 설정되어 있어요.') : null,
        h('div', { class: 'aip-prompt-pair' }, ...[['추가 Positive · 표현할 내용', 'positivePrompt'], ['추가 Negative · 피할 내용', 'negativePrompt']].map(([label, field]) =>
          h('label', { class: 'aip-prompt-field' }, h('strong', {}, label), h('textarea', {
            rows: 4, value: own[field], spellcheck: false, 'data-scene-prompt-field': field,
            style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:80px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
            onfocus: () => { activeTagTarget = { kind: 'position-state', id, field, label: `장면 ${label}` }; },
            oninput: event => { update(field, event.currentTarget.value, false); updatePromptTagPreview(event, h, win); },
            onchange: event => update(field, event.currentTarget.value, true),
          }), promptTagPreview(h, own[field], win)))),
        renderCurrentStateEditor(h, win, id, active),
        h('div', { 'data-scene-native-prompts': '' },
          h('strong', {}, '게임 기본 상황 Positive · 읽기 전용'),
          nativeVariants.length
            ? h('p', { class: 'wml-muted wml-small' }, '게임 원본의 상황별 후보예요. 실제로 쓰이는 후보는 상황과 이미지 변형에 따라 달라질 수 있어요. 이 목록에는 별도 Negative가 없어요.')
            : h('p', { class: 'wml-muted wml-small' }, '이 상황은 게임 기본 프롬프트 표에서 확인할 수 없어요. 목록에는 별도 Negative가 없어요.'),
          ...nativeVariants.map((candidate, index) => h('p', { 'data-scene-native-variant': String(index), 'data-scene-native-source': candidate.source,
            style: 'white-space:pre-wrap;overflow-wrap:anywhere;margin:6px 0;font-size:12px;' }, `${candidate.label} · `,
            h('code', {}, candidate.text)))),
        renderSceneImagePreview(h, win, id, active),
        h('div', { 'data-scene-current-prompts': '' },
          h('strong', {}, '현재 초상화의 마지막 계산 프롬프트'),
          lastPrompt
            ? h('p', { class: 'wml-muted wml-small' }, '같은 이미지 키에서 마지막으로 계산한 값이에요. 이후 다른 모드나 생성 과정에서 달라질 수 있어요.')
            : h('p', { class: 'wml-muted wml-small' }, active
              ? '현재 이미지 키와 일치하는 계산 기록이 없어요. 초상화의 최종 프롬프트 검수에서 확인해 주세요.'
              : '현재 초상화와 다른 장면이에요. 해당 장면을 표시하면 계산 기록을 확인할 수 있어요.'),
          ...(lastPrompt ? [['Positive', lastPrompt.prompt], ['Negative', lastPrompt.negativePrompt]].map(([label, text]) =>
            h('label', { class: 'aip-prompt-field' }, h('strong', {}, label), h('textarea', {
              rows: 3, value: typeof text === 'string' ? text : '', readOnly: true,
              'data-scene-current-prompt': label.toLowerCase(),
              style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:65px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
            }))) : [])),
        api.ui.button('다른 모드 프롬프트 수정', () => {
          promptModPreview.result = null;
          promptModPreview.scope = 'scene';
          activeSettingsTab = 'prompt-mods';
          win.refresh();
        }, { disabled: !lastPrompt || !latestPromptArgs?.length }),
        h('p', { class: 'wml-muted wml-small' }, '모드별 비교에서 태그를 수정해요. 같은 태그가 여러 출처에 있으면 함께 바뀔 수 있어요.'),
        !lastPrompt || !latestPromptArgs?.length ? h('p', { class: 'wml-muted wml-small' }, '현재 장면의 프롬프트가 확인되면 모드별 태그를 비교하고 수정할 수 있어요.') : null,
      ];
    }

    const DRAFT_OUTFIT_PREVIEW_ID = 'aip-outfit-draft-preview';
    let newOutfitDraft = { name: '', description: '', positivePrompt: '', negativePrompt: '', topPrompt: '', skirtPrompt: '', wear: 'floor', manualPrice: '', boldnessScore: 30 };
    let newOutfitOpen = false;
    let outfitEditorMessage = '';
    let outfitPreview = null;
    let previewDraftOutfit = null;

    async function previewOutfitInShop(outfitId, win, draft = null) {
      const state = api.store.game();
      const wife = state?.characters?.[state.primaryCharacterId];
      const previewId = draft ? DRAFT_OUTFIT_PREVIEW_ID : outfitId;
      if (!wife) {
        outfitPreview = { outfitId: previewId, error: '현재 아내 정보를 찾지 못했습니다.' };
        win.refresh();
        return;
      }
      const previousPreviewing = promptPreviewing;
      const previousPlanDepth = imagePlanDepth;
      const previousDraft = previewDraftOutfit;
      let request;
      promptPreviewing = true;
      imagePlanDepth += 1;
      try {
        if (draft) {
          const positive = String(draft.positivePrompt || '').trim();
          const boldness = draft.boldnessScore === '' ? NaN : Number(draft.boldnessScore ?? 30);
          if (!positive || !Number.isInteger(boldness) || boldness < 0 || boldness > 100)
            throw new Error('Positive 프롬프트와 노출도(0~100)를 입력해 주세요.');
          previewDraftOutfit = {
            id: previewId, name: String(draft.name || '').trim() || '작성 중 의상',
            imageTags: positive, negativeImageTags: String(draft.negativePrompt || ''),
            boldnessScore: boldness, price: outfitPriceFromPrompt(positive), wear: draft.wear || 'floor',
            halves: customOutfitHalves({ ...draft, positivePrompt: positive }),
          };
        }
        const shopWife = { ...wife, outfit: previewId, exposure: undefined,
          sceneOverride: undefined, sceneVariant: 0, lookFocus: undefined,
          lookFocusReaction: undefined, currentTask: 'idle', aftermathTags: [], onPatronLap: false };
        const result = api.fn('imagePrompt')(shopWife, 'taproom');
        if (!result?.prompt || !Array.isArray(result.parts) || outfitIdFor(shopWife, result.key) !== previewId)
          throw new Error('의상 가게 시착 프롬프트를 만들지 못했습니다.');
        const applied = applyPromptModRules(result);
        const params = applied.genParams || promptGenParams(applied.prompt);
        request = {
          imageKey: `aip_outfit_preview_${shortHash(JSON.stringify([
            previewId, applied.prompt, applied.negativePrompt, applied.checkpoint, params,
          ]))}`,
          prompt: applied.prompt, negativePrompt: applied.negativePrompt || '',
          width: 1216, height: 832, steps: params?.steps, cfg: params?.cfg,
          loraStrength: params?.loraStrength, checkpoint: applied.checkpoint,
          ...(applied.look === undefined ? {} : { look: applied.look }),
          bypassCache: true, debug: { source: 'attention-image-prompt-outfit-preview' },
        };
      } catch (error) {
        outfitPreview = { outfitId: previewId, error: diagnosticText(error) };
        win.refresh();
        return;
      } finally {
        promptPreviewing = previousPreviewing;
        imagePlanDepth = previousPlanDepth;
        previewDraftOutfit = previousDraft;
      }
      outfitPreview = { outfitId: previewId, imageKey: request.imageKey, loading: true,
        name: draft ? previewDraftOutfit?.name || String(draft.name || '').trim() || '작성 중 의상'
          : outfitPromptSources().find(entry => entry.id === outfitId)?.name || outfitId };
      win.refresh();
      try {
        if (!api.has('imageGenerate')) throw new Error('이미지 생성 기능을 찾지 못했습니다.');
        const result = await api.fn('imageGenerate')(request);
        if (!result?.url) throw new Error('이미지 서버가 결과 주소를 반환하지 않았습니다.');
        if (outfitPreview?.imageKey === request.imageKey) outfitPreview = { ...outfitPreview, loading: false, url: String(result.url) };
      } catch (error) {
        if (outfitPreview?.imageKey === request.imageKey) outfitPreview = { ...outfitPreview, loading: false, error: diagnosticText(error) };
      }
      win.refresh();
    }

    function renderOutfitPrompt(h, win) {
      if (activeTagTarget?.kind === 'outfit-draft' && activeTagTarget.windowEl !== win.el)
        activeTagTarget = null;
      const sources = outfitPromptSources();
      const inputStyle = 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;';
      const createPanel = h('details', { open: newOutfitOpen, 'data-aip-custom-outfit-create': '',
        class: 'wml-section', style: 'margin-bottom:12px;',
        ontoggle: event => {
          newOutfitOpen = event.currentTarget.open;
          if (!newOutfitOpen && activeTagTarget?.kind === 'outfit-draft') activeTagTarget = null;
        } },
      h('summary', { style: 'cursor:pointer;font-weight:700;' }, '새 의상 추가 · 의상 가게에 등록'),
      h('div', { style: 'display:grid;gap:9px;margin-top:12px;' },
        h('label', { class: 'aip-prompt-field' }, h('strong', {}, '의상 이름'),
          h('input', { type: 'text', value: newOutfitDraft.name, maxlength: 60,
            'data-aip-custom-outfit-name': '', style: inputStyle,
            oninput: event => { newOutfitDraft.name = event.currentTarget.value; } })),
        h('label', { class: 'aip-prompt-field' }, h('strong', {}, '가게 설명'),
          h('input', { type: 'text', value: newOutfitDraft.description, maxlength: 300,
            'data-aip-custom-outfit-description': '', style: inputStyle,
            oninput: event => { newOutfitDraft.description = event.currentTarget.value; } })),
        h('div', { class: 'aip-prompt-pair' },
          ...[['positivePrompt', 'Positive · 의상 외형'], ['negativePrompt', 'Negative · 피할 표현']].map(([field, label]) =>
            h('label', { class: 'aip-prompt-field' }, h('strong', {}, label),
              h('textarea', { rows: 4, value: newOutfitDraft[field], spellcheck: false,
                'data-aip-custom-outfit-prompt': field, style: `${inputStyle}resize:vertical;min-height:88px;font:12px/1.45 ui-monospace,Consolas,monospace;`,
                onfocus: () => { activeTagTarget = { kind: 'outfit-draft', field, windowEl: win.el, label: `작성 중 의상 ${label}` }; },
                oninput: event => {
                  newOutfitDraft[field] = event.currentTarget.value;
                   updatePromptTagPreview(event, h, win);
                  if (field === 'positivePrompt') {
                    const price = event.currentTarget.closest('[data-aip-custom-outfit-create]')?.querySelector('[data-aip-custom-outfit-auto-price]');
                    if (price) price.textContent = `자동 가격 ${outfitPriceFromPrompt(newOutfitDraft.positivePrompt)}G`;
                  }
                } }), promptTagPreview(h, newOutfitDraft[field], win)))),
        h('div', { class: 'aip-prompt-pair' },
          ...[['topPrompt', '상의 프롬프트 · 하의를 벗었을 때'], ['skirtPrompt', '하의 프롬프트 · 상의를 벗었을 때']].map(([field, label]) =>
            h('label', { class: 'aip-prompt-field' }, h('strong', {}, label),
              h('textarea', { rows: 3, value: newOutfitDraft[field], spellcheck: false,
                'data-aip-custom-outfit-half': field, style: `${inputStyle}resize:vertical;min-height:76px;font:12px/1.45 ui-monospace,Consolas,monospace;`,
                onfocus: () => { activeTagTarget = { kind: 'outfit-draft', field, windowEl: win.el, label: `작성 중 의상 ${label}` }; },
                oninput: event => { newOutfitDraft[field] = event.currentTarget.value; updatePromptTagPreview(event, h, win); } }),
              promptTagPreview(h, newOutfitDraft[field], win)))),
        h('p', { class: 'wml-muted wml-small' }, '부분 탈의 때 남아 있는 옷만 적어 주세요. 비우면 전체 의상 프롬프트에서 게임 방식으로 추정합니다.'),
        h('div', { style: 'display:flex;flex-wrap:wrap;align-items:end;gap:10px;' },
          h('label', { class: 'aip-prompt-field', style: 'min-width:150px;flex:0 1 190px;' },
            h('strong', {}, '의상 종류'),
            h('select', { value: newOutfitDraft.wear, 'data-aip-custom-outfit-wear': '', style: inputStyle,
              onchange: event => { newOutfitDraft.wear = event.currentTarget.value; } },
              ...[['floor', '일반 영업복'], ['sleep', '잠옷'], ['bath', '목욕복']].map(([value, label]) =>
                h('option', { value, selected: newOutfitDraft.wear === value }, label)))),
          h('label', { class: 'aip-prompt-field', style: 'min-width:170px;flex:0 1 210px;' },
            h('strong', {}, '직접 가격 · 비우면 자동'),
            h('input', { type: 'number', min: 1, max: 9999, step: 1, value: newOutfitDraft.manualPrice,
              'data-aip-custom-outfit-price': '', style: inputStyle,
              oninput: event => { newOutfitDraft.manualPrice = event.currentTarget.value; } })),
          h('label', { class: 'aip-prompt-field', style: 'min-width:135px;flex:0 1 150px;' },
            h('strong', {}, '노출도 · 0~100'),
            h('input', { type: 'number', min: 0, max: 100, step: 1, value: newOutfitDraft.boldnessScore,
              'data-aip-custom-outfit-boldness': '', style: inputStyle,
              oninput: event => { newOutfitDraft.boldnessScore = event.currentTarget.value; } })),
          h('span', { 'data-aip-custom-outfit-auto-price': '', class: 'wml-muted wml-small' },
            `자동 가격 ${outfitPriceFromPrompt(newOutfitDraft.positivePrompt)}G`),
          h('button', { type: 'button', class: 'wml-btn', 'data-aip-custom-outfit-draft-preview': '',
            disabled: outfitPreview?.outfitId === DRAFT_OUTFIT_PREVIEW_ID && !!outfitPreview.loading,
            onclick: () => previewOutfitInShop(DRAFT_OUTFIT_PREVIEW_ID, win, { ...newOutfitDraft }) },
          outfitPreview?.outfitId === DRAFT_OUTFIT_PREVIEW_ID && outfitPreview.loading ? '생성 중…' : '작성 중 의상 시착'),
          api.ui.button('의상 추가', () => {
            try {
              const added = saveCustomOutfit({ ...newOutfitDraft,
                manualPrice: newOutfitDraft.manualPrice === '' ? null : Number(newOutfitDraft.manualPrice) });
              activeOutfitPromptId = added.id;
              newOutfitDraft = { name: '', description: '', positivePrompt: '', negativePrompt: '', topPrompt: '', skirtPrompt: '', wear: 'floor', manualPrice: '', boldnessScore: 30 };
              newOutfitOpen = false;
              if (activeTagTarget?.kind === 'outfit-draft') activeTagTarget = null;
              outfitPreview = null;
              outfitEditorMessage = `${added.name} 의상을 가게에 등록했습니다.`;
            } catch (error) { outfitEditorMessage = diagnosticText(error); }
            win.refresh();
          })),
        h('p', { class: 'wml-muted wml-small' }, '자동 가격은 Positive 10자당 5G, 최소 20G입니다.'),
        h('p', { class: 'wml-muted wml-small' }, '기본 의상 비교: 0 수수한 작업복 · 30 목욕용 속옷 · 55 목욕 수건 · 80 비치는 잠옷 · 100 나체. 일부 게임 판정은 40 이상을 과감한 의상, 65 이상을 매우 노출된 의상으로 봅니다. 수치는 반응·매력 계산에 쓰이며 실제 신체 노출 상태나 옷 모양을 바꾸지 않아요. 옷 모양은 프롬프트로 적어 주세요.'),
      ));
      if (!sources.length) return [createPanel, h('p', { class: 'wml-note' }, '게임에 등록된 의상 정의를 찾지 못했습니다.')];
      const currentRawId = String(currentWifePromptContext().character?.outfit || '').trim();
      const currentId = String(outfitById(currentRawId)?.id || currentRawId);
      const source = sources.find(entry => entry.id === activeOutfitPromptId)
        || sources.find(entry => entry.id === currentId)
        || sources[0];
      activeOutfitPromptId = source.id;
      const prompts = currentOutfitPrompts();
      const overridden = Object.prototype.hasOwnProperty.call(prompts, source.id);
      const values = outfitPromptValues(source, prompts);
      const custom = currentCustomOutfits().find(entry => entry.id === source.id);
      const preview = [source.id, DRAFT_OUTFIT_PREVIEW_ID].includes(outfitPreview?.outfitId)
        ? outfitPreview : null;
      const saveCustomMeta = (patch, updateView = true) => {
        try {
          const latest = currentCustomOutfits().find(entry => entry.id === source.id);
          if (!latest) throw new Error('수정할 사용자 의상을 찾지 못했습니다.');
          saveCustomOutfit({ ...latest, ...patch });
          outfitPreview = null;
          outfitEditorMessage = '의상 정보와 가격을 저장했습니다.';
        } catch (error) { outfitEditorMessage = diagnosticText(error); }
        if (updateView) win.refresh();
      };
      return [h('div', { class: 'aip-outfit-layout', 'data-aip-outfit-layout': '' },
        h('div', { class: 'aip-outfit-editor' },
        createPanel,
        outfitEditorMessage ? h('p', { class: 'wml-note', role: 'status' }, outfitEditorMessage) : null,
        h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
          h('strong', { style: 'font-size:12px;' }, `등록된 의상 ${sources.length}개`),
          h('select', {
            value: source.id,
            'data-outfit-prompt-source': '',
            style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
            onchange: event => {
              activeOutfitPromptId = event.currentTarget.value;
              activeTagTarget = null;
              outfitPreview = null;
              win.refresh();
            },
          }, ...sources.map(entry => h('option', { value: entry.id, selected: entry.id === source.id }, `${entry.name} (${entry.id})`))),
          h('span', { class: 'wml-muted wml-small' }, `현재 아내 착용: ${currentId || '확인되지 않음'} · ${overridden ? '수정값 적용 중' : '등록 원본 표시 중'}`),
        ),
        custom ? h('div', { class: 'wml-section', 'data-aip-custom-outfit-edit': source.id,
          style: 'display:grid;gap:9px;margin-bottom:12px;' },
          h('div', { class: 'aip-prompt-pair' },
            h('label', { class: 'aip-prompt-field' }, h('strong', {}, '의상 이름'),
              h('input', { type: 'text', value: custom.name, maxlength: 60, style: inputStyle,
                'data-aip-custom-outfit-edit-name': '',
                onchange: event => saveCustomMeta({ name: event.currentTarget.value }) })),
            h('label', { class: 'aip-prompt-field' }, h('strong', {}, '가게 설명'),
              h('input', { type: 'text', value: custom.description, maxlength: 300, style: inputStyle,
                'data-aip-custom-outfit-edit-description': '',
                onchange: event => saveCustomMeta({ description: event.currentTarget.value }) }))),
          h('div', { style: 'display:flex;flex-wrap:wrap;gap:10px;align-items:end;' },
            h('label', { class: 'aip-prompt-field', style: 'min-width:150px;flex:0 1 190px;' },
              h('strong', {}, '의상 종류'),
              h('select', { value: custom.wear, 'data-aip-custom-outfit-edit-wear': '', style: inputStyle,
                onchange: event => saveCustomMeta({ wear: event.currentTarget.value }) },
                ...[['floor', '일반 영업복'], ['sleep', '잠옷'], ['bath', '목욕복']].map(([value, label]) =>
                  h('option', { value, selected: custom.wear === value }, label)))),
            h('label', { class: 'aip-prompt-field', style: 'min-width:170px;flex:0 1 210px;' },
              h('strong', {}, '직접 가격 · 비우면 자동'),
              h('input', { type: 'number', min: 1, max: 9999, step: 1,
                value: custom.manualPrice ?? '', style: inputStyle,
                'data-aip-custom-outfit-edit-price': '',
                onchange: event => saveCustomMeta({ manualPrice: event.currentTarget.value === ''
                  ? null : Number(event.currentTarget.value) }) })),
            h('label', { class: 'aip-prompt-field', style: 'min-width:135px;flex:0 1 150px;' },
              h('strong', {}, '노출도 · 0~100'),
              h('input', { type: 'number', min: 0, max: 100, step: 1,
                value: custom.boldnessScore, style: inputStyle,
                'data-aip-custom-outfit-edit-boldness': '',
                onchange: event => saveCustomMeta({ boldnessScore: event.currentTarget.value }) })),
            h('span', { class: 'wml-muted wml-small' },
              `자동 ${outfitPriceFromPrompt(values.positivePrompt)}G · 가게 ${custom.manualPrice ?? outfitPriceFromPrompt(values.positivePrompt)}G`)),
          h('span', { class: 'wml-muted wml-small' }, '기본 의상 비교: 0 수수한 작업복 · 30 목욕용 속옷 · 55 목욕 수건 · 80 비치는 잠옷 · 100 나체. 일부 판정은 40 이상을 과감한 의상, 65 이상을 매우 노출된 의상으로 봅니다. 수치는 게임 반응·매력 계산에 쓰이며 실제 신체 노출 상태나 옷 모양을 바꾸지 않아요.'),
        ) : source.description ? h('p', { class: 'wml-note', style: 'margin-bottom:10px;' }, source.description) : null,
        h('div', { class: 'aip-prompt-pair' }, ...[['positive', 'positivePrompt'], ['negative', 'negativePrompt']]
          .map(([polarity, field]) => {
            const value = values[field];
            const save = (next, updateView = true) => {
              saveOutfitPromptField(source.id, field, next);
              outfitPreview = null;
              if (updateView) win.refresh();
            };
            return h('label', { class: 'aip-prompt-field' },
              h('strong', {}, `의상 전체 ${polarity === 'negative' ? 'Negative' : 'Positive'} 프롬프트`),
              h('textarea', { rows: 5, value, spellcheck: false,
                'data-outfit-prompt': polarity,
                style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:100px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
                onfocus: () => { activeTagTarget = { kind: 'outfit', id: source.id, polarity,
                  label: `${source.name} ${polarity === 'negative' ? 'Negative' : 'Positive'}` }; },
                oninput: event => { save(event.currentTarget.value, false); updatePromptTagPreview(event, h, win); },
                onchange: event => save(event.currentTarget.value, false),
              }),
              promptTagPreview(h, value, win),
              promptTagAdder(h, value, save, `outfit:${source.id}:${polarity}`));
          })),
        h('div', { class: 'aip-prompt-pair' },
          ...[['topPrompt', '상의 프롬프트 · 하의를 벗었을 때'], ['skirtPrompt', '하의 프롬프트 · 상의를 벗었을 때']].map(([field, label]) => {
            const value = custom ? custom[field] : values[field];
            const save = (next, updateView = true) => {
              if (custom) saveCustomMeta({ [field]: next }, updateView);
              else {
                saveOutfitPromptField(source.id, field, next);
                outfitPreview = null;
                if (updateView) win.refresh();
              }
            };
            return h('label', { class: 'aip-prompt-field' }, h('strong', {}, label),
              h('textarea', { rows: 3, value, spellcheck: false,
                'data-aip-custom-outfit-edit-half': field, style: `${inputStyle}resize:vertical;min-height:76px;font:12px/1.45 ui-monospace,Consolas,monospace;`,
                onfocus: () => { activeTagTarget = { kind: 'outfit', id: source.id, polarity: field, label: `${source.name} ${label}` }; },
                oninput: event => { save(event.currentTarget.value, false); updatePromptTagPreview(event, h, win); }, onchange: event => save(event.currentTarget.value, false),
              }),
              promptTagPreview(h, value, win), promptTagAdder(h, value, save, `outfit:${source.id}:${field}`));
          }),
          h('span', { class: 'wml-muted wml-small' }, custom
            ? '비워 두면 전체 의상에서 게임 방식으로 추정합니다.'
            : '원본 상하의가 표시됩니다. 전체 Positive만 수정했다면 이전 상하의는 적용하지 않으며, 상하의를 수정하면 표시된 값이 적용됩니다.')),
        custom ? null : h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;' },
          api.ui.button('이 의상 원본 프롬프트로 복원', () => {
            const next = { ...currentOutfitPrompts() };
            delete next[source.id];
            api.settings.set({ outfitPrompts: next });
            win.refresh();
          }),
          h('span', { class: 'wml-muted wml-small' }, '기본 게임과 다른 모드 파일은 수정하지 않고 이 모드의 교체값만 저장합니다.'),
        ),
        ),
        h('aside', { class: 'aip-outfit-preview wml-section',
          'data-aip-outfit-preview': preview?.outfitId || source.id,
          style: 'display:grid;gap:8px;' },
          h('strong', {}, '의상 가게 시착 미리보기'),
          h('span', { class: 'wml-muted wml-small' }, '가게의 기본 대기 장면으로 생성합니다. 실제 착용·구매 상태는 바뀌지 않습니다.'),
          h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;' },
            api.ui.button(preview?.loading ? '생성 중…' : '시착 이미지 생성',
              () => previewOutfitInShop(source.id, win), { disabled: !!preview?.loading }),
            preview?.url ? api.ui.button('크게 보기', () =>
              openSimilarImagePreview({}, preview.imageKey, preview.url)) : null),
          preview?.outfitId === DRAFT_OUTFIT_PREVIEW_ID
            ? h('span', { class: 'wml-muted wml-small' }, '작성 중 의상 시착 결과 · 수정 후 왼쪽에서 다시 시착할 수 있습니다.') : null,
          preview?.error ? h('p', { class: 'wml-note', role: 'alert' }, preview.error) : null,
          preview?.url ? h('img', { src: preview.url, alt: `${preview.name || source.name} 시착 미리보기`,
            'data-aip-outfit-preview-image': preview.outfitId,
            style: 'display:block;width:100%;max-height:360px;object-fit:contain;background:#0c0a09;cursor:zoom-in;',
            onclick: () => openSimilarImagePreview({}, preview.imageKey, preview.url) }) : null),
      )];
    }

    function renderTagLibrary(h, win, compact = false) {
      if (activeTagTarget?.kind === 'outfit-draft' && (activeSettingsTab !== 'outfit-prompts'
        || !newOutfitOpen || activeTagTarget.windowEl !== win.el || activeTagTarget.windowEl?.isConnected === false))
        activeTagTarget = null;
      const customTags = currentCustomTags();
      const tags = allPromptTags(customTags);
      const translate = tag => translatedPromptTag(tag, customTags);
      const categorizedTags = tags.map(tag => ({ tag, category: promptTagCategory(tag, customTags) }));
      const visibleTags = activeTagCategory === 'all'
        ? categorizedTags
        : categorizedTags.filter(entry => entry.category === activeTagCategory);
      const search = tagLibrarySearch.trim().toLocaleLowerCase();
      const matchesSearch = tag => `${tag} ${translate(tag)}`.toLocaleLowerCase().includes(search);
      const matchCount = search ? visibleTags.filter(entry => matchesSearch(entry.tag)).length : visibleTags.length;
      const categoryCount = id => id === 'all' ? categorizedTags.length : categorizedTags.filter(entry => entry.category === id).length;
      let pendingLabel = '';
      let pendingTag = '';
      const add = () => saveCustomTag(pendingLabel, pendingTag, win);
      return h('aside', {
        'data-tag-library': '',
        class: 'wml-section',
        style: compact
          ? 'flex:1 1 100%;min-width:0;max-width:none;height:min(36vh,300px);overflow-y:auto;overscroll-behavior:contain;scrollbar-gutter:stable;'
          : 'flex:1 1 235px;max-width:290px;min-width:220px;align-self:flex-start;position:sticky;top:0;height:calc(100vh - 160px);max-height:720px;overflow-y:auto;overscroll-behavior:contain;scrollbar-gutter:stable;',
        onscroll: event => { tagLibraryScrollTop = event.currentTarget.scrollTop; },
      },
      h('h3', { style: 'margin:0 0 4px;' }, '전체 태그 라이브러리'),
      h('p', { class: 'wml-muted wml-small', style: 'margin:0 0 8px;' },
        activeTagTarget ? `현재 입력 대상 · ${activeTagTarget.label}` : '프롬프트 입력칸을 먼저 누르면 태그가 바로 추가됩니다.'),
      h('button', {
        type: 'button', class: 'wml-btn', 'data-prompt-deduplicate': '',
        style: 'width:100%;margin-bottom:8px;', onclick: () => deduplicateActivePrompt(win),
      }, '현재 입력 중복 정리'),
      h('details', { style: 'padding:8px;margin-bottom:8px;border:1px solid #57534e;border-radius:6px;background:#1c1917;' },
        h('summary', { style: 'cursor:pointer;font-size:12px;font-weight:600;' }, `내 태그 추가·관리${customTags.length ? ` · ${customTags.length}개` : ''}`),
        h('div', { style: 'display:grid;gap:6px;margin-top:8px;' },
        h('input', {
          type: 'text',
          placeholder: '한글 표시명',
          'aria-label': '사용자 태그 한글 표시명',
          'data-custom-tag-label': '',
          style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:6px 8px;',
          oninput: event => { pendingLabel = event.currentTarget.value; },
        }),
        h('input', {
          type: 'text',
          placeholder: '영문 프롬프트 태그',
          'aria-label': '사용자 태그 영문 프롬프트',
          'data-custom-tag-english': '',
          style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:6px 8px;font-family:ui-monospace,Consolas,monospace;',
          oninput: event => { pendingTag = event.currentTarget.value; },
          onkeydown: event => { if (event.key === 'Enter') { event.preventDefault(); add(); } },
        }),
        h('button', { type: 'button', class: 'wml-btn', 'data-custom-tag-add': '', onclick: add }, '라이브러리에 추가'),
        ...customTags.map(entry => h('div', { style: 'display:flex;align-items:center;gap:5px;font-size:11px;' },
          h('span', { style: 'min-width:0;flex:1;overflow-wrap:anywhere;' }, `${entry.label} · ${entry.tag}`),
          h('button', {
            type: 'button', class: 'wml-btn', title: '사용자 태그 삭제',
            'data-custom-tag-remove': entry.tag,
            onclick: () => removeCustomTag(entry.tag, win),
          }, '삭제'),
        )),
        ),
      ),
      h('input', {
        type: 'search',
        value: tagLibrarySearch,
        placeholder: '한글 또는 영문 태그 검색',
        'aria-label': '태그 라이브러리 검색',
        style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;margin-bottom:8px;',
        oninput: event => {
          tagLibrarySearch = event.currentTarget.value;
          const query = tagLibrarySearch.trim().toLocaleLowerCase();
          const library = event.currentTarget.closest('[data-tag-library]');
          let found = 0;
          for (const button of library.querySelectorAll('[data-library-tag]')) {
            button.hidden = query && !button.getAttribute('data-tag-search').includes(query);
            if (!button.hidden) found++;
          }
          const count = library.querySelector('[data-tag-match-count]');
          if (count) count.textContent = `${TAG_CATEGORIES.find(([id]) => id === activeTagCategory)?.[1] || '전체'} 태그 · ${found}개${query ? ' 검색됨' : ''}`;
        },
      }),
      h('div', { 'data-tag-category-tabs': '', style: 'display:flex;flex-wrap:wrap;gap:5px;margin-bottom:8px;' },
        ...TAG_CATEGORIES.filter(([id]) => id === 'all' || categoryCount(id) > 0).map(([id, label]) => h('button', {
          type: 'button',
          class: 'wml-btn',
          'data-tag-category-option': id,
          'aria-pressed': activeTagCategory === id ? 'true' : 'false',
          style: activeTagCategory === id ? 'border-color:#d97706;color:#fef3c7;background:#451a03;' : '',
          onclick: () => { activeTagCategory = id; win.refresh(); },
        }, `${label} ${categoryCount(id)}`)),
      ),
      h('div', { class: 'wml-muted wml-small', style: 'margin:0 0 6px;',
        'data-active-tag-category': activeTagCategory, 'data-tag-match-count': '' },
        `${TAG_CATEGORIES.find(([id]) => id === activeTagCategory)?.[1] || '전체'} 태그 · ${matchCount}개${search ? ' 검색됨' : ''}`),
      h('div', { style: 'display:flex;flex-wrap:wrap;gap:5px;' },
        ...visibleTags.map(({ tag, category }) => h('button', {
          type: 'button',
          'data-library-tag': tag,
          'data-library-category': category,
          'data-tag-search': `${tag} ${translate(tag)}`.toLocaleLowerCase(),
          hidden: Boolean(search && !matchesSearch(tag)),
          title: `${tag} · 클릭하면 복사${activeTagTarget ? ' 및 현재 항목에 추가' : ''}`,
          style: 'border:1px solid #57534e;border-radius:999px;background:#292524;color:#f5f5f4;padding:5px 8px;font-size:11px;cursor:pointer;text-align:left;',
          onclick: () => useLibraryTag(tag, win),
        }, translate(tag))),
      ));
    }

    function renderPromptPresetLibrary(h, win) {
      const customTags = currentCustomTags();
      const promptPresets = currentPromptPresets();
      let pendingPresetName = '';
      let pendingPresetPrompt = '';
      const savePreset = () => savePromptPreset(pendingPresetName, pendingPresetPrompt, win);
      const presetButton = preset => {
        const english = deduplicatePrompt(preset.prompt);
        const korean = promptTokens(english).map(tag => translatedPromptTag(tag, customTags)).join(', ');
        return h('button', {
          type: 'button',
          'data-prompt-preset-use': preset.id,
          title: `한글: ${korean}\n영문: ${english}\n클릭하면 현재 입력 대상에 모두 적용합니다.`,
          style: 'border:1px solid #92400e;border-radius:999px;background:#451a03;color:#fef3c7;padding:5px 8px;font-size:11px;cursor:pointer;text-align:left;',
          onclick: () => usePromptPreset(preset, win),
        }, preset.name);
      };
      return h('aside', {
        'data-prompt-preset-library': '',
        class: 'wml-section',
        style: 'flex:1 1 220px;max-width:270px;min-width:210px;align-self:flex-start;position:sticky;top:0;height:calc(100vh - 160px);max-height:720px;overflow-y:auto;overscroll-behavior:contain;scrollbar-gutter:stable;',
        onscroll: event => { promptPresetLibraryScrollTop = event.currentTarget.scrollTop; },
      },
      h('h3', { style: 'margin:0 0 4px;' }, '프롬프트 프리셋'),
      h('p', { class: 'wml-muted wml-small', style: 'margin:0 0 8px;' }, '제목에 마우스를 올리면 한글·영문 프롬프트를 함께 확인할 수 있습니다.'),
      h('div', { style: 'display:grid;gap:6px;padding:8px;margin-bottom:8px;border:1px solid #92400e;border-radius:6px;background:#1c1917;' },
        h('strong', { style: 'font-size:12px;' }, '현재 모델 프리셋'),
        h('span', { class: 'wml-muted wml-small' }, 'WAI Illustrious SDXL v17'),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:5px;' }, ...MODEL_PROMPT_PRESETS.map(presetButton)),
      ),
      h('div', { style: 'display:grid;gap:6px;padding:8px;border:1px solid #57534e;border-radius:6px;background:#1c1917;' },
        h('strong', { style: 'font-size:12px;' }, '사용자 프리셋'),
        h('input', {
          type: 'text', placeholder: '프리셋 이름', 'data-prompt-preset-name': '',
          style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:6px 8px;',
          oninput: event => { pendingPresetName = event.currentTarget.value; },
        }),
        h('textarea', {
          rows: 3, placeholder: '영문 프롬프트 · 쉼표로 여러 개 입력', 'data-prompt-preset-prompt': '', spellcheck: false,
          style: 'width:100%;box-sizing:border-box;resize:vertical;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:6px 8px;font:12px/1.4 ui-monospace,Consolas,monospace;',
          oninput: event => { pendingPresetPrompt = event.currentTarget.value; updatePromptTagPreview(event, h, win); },
        }),
        promptTagPreview(h, pendingPresetPrompt, win),
        h('button', { type: 'button', class: 'wml-btn', 'data-prompt-preset-save': '', onclick: savePreset }, '프롬프트 프리셋 저장'),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:5px;' },
          ...promptPresets.map(preset => h('span', {
            'data-prompt-preset': preset.id,
            style: 'display:inline-flex;align-items:center;gap:3px;',
          },
          presetButton(preset),
          h('button', {
            type: 'button', class: 'wml-btn', 'data-prompt-preset-remove': preset.id,
            title: `${preset.name} 삭제`, 'aria-label': `${preset.name} 삭제`, onclick: () => removePromptPreset(preset.id, win),
          }, '×'))),
        ),
      ));
    }
