    let cameraSceneSettings = {};
    let cameraDrafts = {};
    let cameraImageMetadata = {};
    const cameraPending = new Map();
    let cameraSettingsFingerprints = new Map();
    let cameraStyleLockLoaded = false;
    function refreshCameraStyleLockLoaded() {
      try { cameraStyleLockLoaded = globalThis.WML?.status?.().loaded?.includes('style-lock') === true; }
      catch { cameraStyleLockLoaded = false; }
    }
    refreshCameraStyleLockLoaded();
    api.afterEachSetup?.(id => { if (id === 'style-lock') refreshCameraStyleLockLoaded(); });

    function normalizeCameraSettings(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      const output = {};
      for (const [id, entry] of Object.entries(value).slice(0, 1000)) {
        if (!/^(?:scene|task|look)-[^_]/.test(id) || id.length > 200 || id.includes('__') || !entry || typeof entry !== 'object') continue;
        const seen = new Set();
        const shots = (Array.isArray(entry.shots) ? entry.shots : []).slice(0, 64).filter(shot => {
          if (!shot || typeof shot.id !== 'string' || !/^[a-z0-9_-]{1,160}$/i.test(shot.id) || seen.has(shot.id)
            || typeof shot.positive !== 'string' || shot.positive.length > 4000 || !splitFinalPrompt(shot.positive)
            || typeof shot.negative !== 'string' || shot.negative.length > 4000 || !splitFinalPrompt(shot.negative)) return false;
          seen.add(shot.id); return true;
        }).map(shot => ({ id: shot.id, name: String(shot.name || '').slice(0, 120), positive: shot.positive, negative: shot.negative }));
        const selected = [...new Set(Array.isArray(entry.selected) ? entry.selected : [])].filter(item => seen.has(item)).slice(0, 64);
        const removeTags = typeof entry.removeTags === 'string' && entry.removeTags.length <= 12000 && splitFinalPrompt(entry.removeTags) ? entry.removeTags : '';
        if (shots.length || removeTags || entry.disabled === true) output[id] = { shots, selected, removeTags,
          ...(entry.disabled === true ? { disabled: true } : {}) };
      }
      return output;
    }

    function normalizeCameraImageMetadata(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).slice(-1000).filter(([key, entry]) =>
        key.length <= 1000 && entry && typeof entry.id === 'string' && /^[a-z0-9_-]{1,160}$/i.test(entry.id)
        && typeof entry.positive === 'string' && entry.positive.length <= 4000 && splitFinalPrompt(entry.positive)
        && typeof entry.negative === 'string' && entry.negative.length <= 4000 && splitFinalPrompt(entry.negative))
        .map(([key, entry]) => [key, { id: entry.id, name: String(entry.name || '').slice(0, 120), positive: entry.positive, negative: entry.negative }]));
    }

    const CAMERA_PRESET_REVISION = 2;
    const CAMERA_OLD_DEFAULT_POSITIVE = {
      pov: 'first-person camera view', third_person: 'third-person camera view',
      pov_hands: 'first-person camera view with hands in the foreground',
      pov_above: 'first-person camera view from above', pov_below: 'first-person camera view from below',
      front: 'frontal camera view', three_quarter: 'three-quarter camera view', side: 'side camera view', rear: 'rear camera view',
      above: 'high-angle camera view', ceiling_near: 'overhead camera view, medium shot',
      below: 'low-angle camera view', high_up: 'camera view from a high vantage point',
      portrait: 'head-and-shoulders portrait shot', face_close: 'close-up shot of the face', close_up: 'close-up shot',
      upper_body: 'medium shot of the upper body', cowboy_shot: 'medium-long shot framed from head to mid-thigh',
      lower_body: 'shot framed on the lower body', full_body: 'full-body shot', wide_shot: 'wide shot',
      very_wide_shot: 'extreme wide shot', between_legs: "camera positioned between the subject's legs",
      dutch: 'dutch angle', sideways: 'camera rotated 90 degrees', upside_down: 'camera rotated 180 degrees',
      fisheye: 'fisheye lens',
    };
    const CAMERA_REV1_DEFAULT_POSITIVE = {
      pov: 'pov', third_person: 'third-person perspective', pov_hands: 'pov, pov_hands',
      pov_above: 'pov, from_above', pov_below: 'pov, from_below',
      front: 'straight-on', three_quarter: 'from_side', side: 'from_side', rear: 'from_behind',
      above: 'from_above', ceiling_near: 'from_above, cowboy_shot', below: 'from_below', high_up: 'high_up, from_above',
      portrait: 'portrait', face_close: 'portrait, close-up', close_up: 'close-up', upper_body: 'upper_body',
      cowboy_shot: 'cowboy_shot', lower_body: 'lower_body', full_body: 'full_body', wide_shot: 'wide_shot',
      very_wide_shot: 'very_wide_shot', between_legs: 'from_below, thighs',
      dutch: 'dutch_angle', sideways: 'sideways', upside_down: 'upside-down', fisheye: 'fisheye',
    };
    const CAMERA_PRESET_LOOKUP = new Map(CAMERA_PRESET_GROUPS.flatMap(group =>
      group.items.map(item => [item.id, { group: group.id, item }])));
    function cameraUpgradeDefaultShot(shot, revision) {
      if (!shot || typeof shot.id !== 'string' || typeof shot.positive !== 'string') return shot;
      const axes = ['direction', 'viewpoint', 'elevation', 'framing', 'tilt', 'lens'];
      const parts = shot.id.split('-');
      let items;
      if (parts[0] === 'camera' && parts.length === axes.length + 1) {
        items = parts.slice(1).flatMap((id, index) => {
          if (id === 'none') return [];
          const preset = CAMERA_PRESET_LOOKUP.get(id);
          return [preset?.group === axes[index] ? preset.item : null];
        });
      } else {
        const item = CAMERA_PRESET_LOOKUP.get(shot.id)?.item;
        items = item ? [item] : [];
      }
      if (!items.length || items.some(item => !item || !Object.hasOwn(CAMERA_OLD_DEFAULT_POSITIVE, item.id)
        || !Object.hasOwn(CAMERA_REV1_DEFAULT_POSITIVE, item.id))) return shot;
      const previous = deduplicateFinalPrompt(items.map(item => CAMERA_REV1_DEFAULT_POSITIVE[item.id]
        .split(', ').map(term => `(${term}:1.3)`).join(', ')).join(', '));
      if (shot.positive !== previous) {
        if (revision >= 1) return shot;
        const old = deduplicateFinalPrompt(items.map(item => CAMERA_OLD_DEFAULT_POSITIVE[item.id]
          .split(', ').map(term => `(${term}:1.3)`).join(', ')).join(', '));
        const oldUnweighted = deduplicateFinalPrompt(items.map(item => CAMERA_OLD_DEFAULT_POSITIVE[item.id]).join(', '));
        if (shot.positive !== old && shot.positive !== oldUnweighted) return shot;
      }
      return { ...shot, positive: deduplicateFinalPrompt(items.map(item => item.positive).filter(Boolean).join(', ')) };
    }
    function cameraUpgradeDefaults(value, revision) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return value;
      return Object.fromEntries(Object.entries(value).map(([id, entry], index) => [id,
        index < 1000 && entry && typeof entry === 'object' && !Array.isArray(entry) && Array.isArray(entry.shots)
          ? { ...entry, shots: entry.shots.map((shot, n) => n < 64 ? cameraUpgradeDefaultShot(shot, revision) : shot) } : entry]));
    }

    function reloadCameraSettings() {
      const saved = api.settings.get({ cameraSceneSettings: {}, cameraImageMetadata: {}, cameraPresetRevision: 0 });
      let scenes = saved.cameraSceneSettings;
      if (!Number.isSafeInteger(saved.cameraPresetRevision) || saved.cameraPresetRevision < CAMERA_PRESET_REVISION) {
        const upgraded = cameraUpgradeDefaults(scenes, Number.isSafeInteger(saved.cameraPresetRevision) ? saved.cameraPresetRevision : 0);
        try {
          api.settings.set({ cameraSceneSettings: upgraded, cameraPresetRevision: CAMERA_PRESET_REVISION });
          const check = api.settings.get({ cameraSceneSettings: null, cameraPresetRevision: 0 });
          if (check.cameraPresetRevision === CAMERA_PRESET_REVISION
            && JSON.stringify(check.cameraSceneSettings) === JSON.stringify(upgraded)) scenes = check.cameraSceneSettings;
          else console.warn('[attention-image-prompt] camera preset migration was not saved; retry on reload');
        } catch (error) { console.warn('[attention-image-prompt] camera preset migration', error); }
      }
      cameraSceneSettings = normalizeCameraSettings(scenes);
      cameraDrafts = {};
      cameraImageMetadata = normalizeCameraImageMetadata(saved.cameraImageMetadata);
      cameraSettingsFingerprints = new Map();
      cameraPending.clear();
    }
    reloadCameraSettings();

    function cameraSettingSource(id) {
      if (Object.hasOwn(cameraDrafts, id)) return { id, value: cameraDrafts[id], draft: true };
      if (Object.hasOwn(cameraSceneSettings, id)) return { id, value: cameraSceneSettings[id] };
      if (typeof id !== 'string' || id.includes('|sleep-')) return null;
      const base = id.split('|')[0];
      if (base !== id && Object.hasOwn(cameraDrafts, base)) return { id: base, value: cameraDrafts[base], draft: true };
      return base !== id && Object.hasOwn(cameraSceneSettings, base) ? { id: base, value: cameraSceneSettings[base] } : null;
    }
    function cameraSettingsFingerprint(id) {
      const source = cameraSettingSource(id), value = source?.value;
      if (!value?.selected.length) return '';
      const cached = cameraSettingsFingerprints.get(source.id);
      if (cached !== undefined) return cached;
      const shots = value.shots.filter(shot => value.selected.includes(shot.id))
        .map(shot => [shot.id, shot.positive, shot.negative]).sort((a, b) => a[0].localeCompare(b[0]));
      const removed = (splitFinalPrompt(value.removeTags)?.tokens || []).map(globalPromptExclusionIdentity).filter(Boolean).sort();
      const fingerprint = shortHash(JSON.stringify(['camera-layout-v4', shots, removed]));
      cameraSettingsFingerprints.set(source.id, fingerprint);
      return fingerprint;
    }

    function cameraKeyAliases(key) {
      if (typeof key !== 'string' || !key) return [];
      const aliases = [key];
      try { aliases.push(compactGenerationKey(key), compactGenerationKey(key, true)); } catch { /* optional game key */ }
      return [...new Set(aliases)];
    }
    function cameraMetadataForKey(key) {
      for (const alias of cameraKeyAliases(key)) if (cameraImageMetadata[alias]) return cameraImageMetadata[alias];
      return null;
    }
    function cameraIdentity(token) { return globalPromptExclusionIdentity(token); }
    function cameraRewriteText(value, excluded) {
      if (typeof value !== 'string' || !value || !excluded.size) return { value, removed: [] };
      const parsed = splitFinalPrompt(value);
      if (!parsed) return { value, removed: [] };
      const kept = [], removed = [];
      parsed.tokens.forEach(token => (excluded.has(cameraIdentity(token)) ? removed : kept).push(token.trim()));
      return { value: removed.length ? kept.filter(Boolean).join(', ') : value, removed };
    }
    function cameraThirdPerson(shot) {
      return shot?.id === 'third_person' || /^camera-[^-]+-third_person-/.test(shot?.id || '');
    }
    function cameraBlocked(shot, removeTags, previousTags = []) {
      const blocked = new Set([...CAMERA_REMOVE_DEFAULTS, ...(splitFinalPrompt(removeTags || '')?.tokens || [])]
        .map(cameraIdentity).filter(Boolean));
      if (cameraThirdPerson(shot)) for (const value of ['pov hands', 'pov crotch', 'pov feet']) blocked.add(cameraIdentity(value));
      for (const tag of previousTags) blocked.add(tag);
      return blocked;
    }
    // Anchor to the observed quality + character parts only when their tokens
    // can be matched in order near the start of the final prompt. An unknown
    // composition falls back to the beginning rather than guessing a scene tag.
    function cameraInsertAfterBase(prompt, positive, parts) {
      if (!positive) return { prompt, placement: 'none' };
      const parsed = splitFinalPrompt(prompt);
      if (!parsed) return { prompt: [positive, prompt].filter(Boolean).join(', '), placement: 'fallback' };
      const base = (Array.isArray(parts) ? parts : [])
        .filter(part => ['품질', 'Quality', '기본', 'Base'].includes(part?.label) && typeof part.tags === 'string')
        .flatMap(part => splitFinalPrompt(part.tags)?.tokens || []).map(cameraIdentity).filter(Boolean);
      const tokens = parsed.tokens.map(cameraIdentity);
      let index = -1, first = -1, count = 0;
      for (const identity of base) {
        const found = tokens.indexOf(identity, index + 1);
        if (found < 0) continue;
        if (first < 0) first = found;
        index = found; count++;
      }
      if (base.length < 2 || count < Math.max(2, Math.ceil(base.length * 0.8)) || first > 1 || index > base.length + 2)
        return { prompt: [positive, prompt].filter(Boolean).join(', '), placement: 'fallback' };
      let before = '', after = '';
      for (let i = 0; i < parsed.tokens.length; i++) {
        if (i <= index) before += (i ? parsed.separators[i - 1] || ',' : '') + parsed.tokens[i];
        else after += (i === index + 1 ? '' : parsed.separators[i - 1] || ',') + parsed.tokens[i];
      }
      return { prompt: `${before}, ${positive}${after.trim() ? `,${after}` : ''}`, placement: 'after-base' };
    }
    function cameraApplyShot(prompt, negativePrompt, shot, removeTags, previousTags = [], parts = null) {
      if (!shot) return { prompt, negativePrompt, removed: [], added: [], shotId: null };
      const blocked = cameraBlocked(shot, removeTags, previousTags);
      const filtered = cameraRewriteText(prompt, blocked);
      const shotTokens = (splitFinalPrompt(shot.positive)?.tokens || []).map(cameraIdentity).filter(Boolean);
      const negative = cameraRewriteText(negativePrompt, new Set(shotTokens));
      const inserted = cameraInsertAfterBase(filtered.value, shot.positive, parts);
      const positiveTokens = new Set([...(splitFinalPrompt(filtered.value)?.tokens || []).map(cameraIdentity), ...shotTokens]);
      const defaultNegative = cameraRewriteText(CAMERA_NEGATIVE_DEFAULTS, positiveTokens).value;
      const thirdPersonNegative = cameraThirdPerson(shot)
        ? ['pov', 'pov_hands'].filter(tag => !shotTokens.includes(cameraIdentity(tag))).join(', ') : '';
      return { prompt: deduplicateFinalPrompt(inserted.prompt), placement: inserted.placement,
        negativePrompt: deduplicateFinalPrompt([negative.value, shot.negative, thirdPersonNegative, defaultNegative].filter(Boolean).join(', ')),
        removed: [...filtered.removed, ...negative.removed], added: [shot.positive, shot.negative, thirdPersonNegative, defaultNegative].filter(Boolean), shotId: shot.id };
    }
    function cameraExclusiveTagsFromParts(parts) {
      if (!Array.isArray(parts)) return [];
      const cameraParts = parts.filter(part => part?.label === 'AIP 카메라 구도' && typeof part.tags === 'string');
      if (!cameraParts.length) return [];
      const protectedTags = new Set(parts.filter(part => part?.label !== 'AIP 카메라 구도' && typeof part?.tags === 'string')
        .flatMap(part => (splitFinalPrompt(part.tags)?.tokens || []).map(cameraIdentity)).filter(Boolean));
      return cameraParts.flatMap(part => (splitFinalPrompt(part.tags)?.tokens || []).map(cameraIdentity))
        .filter(tag => tag && !protectedTags.has(tag));
    }
    function cameraPreviousExclusiveTags(key) {
      const latest = latestScenePrompt?.result;
      if (!latest || typeof latest.key !== 'string'
        || similarImageSituationKey(latest.key) !== similarImageSituationKey(key)) return [];
      return cameraExclusiveTagsFromParts(latest.parts);
    }
    function cameraCurrentSituation() {
      try { return positionSituationId(activePortraitImageKey('', api.store.game())); } catch { return ''; }
    }
    function cameraStyleLockNoPov() {
      if (!cameraStyleLockLoaded) return false;
      try {
        const raw = localStorage.getItem('wml.mod.style-lock');
        const settings = raw && JSON.parse(raw);
        return settings?.noPov === true;
      } catch { /* another mod may not expose its settings */ }
      return false;
    }
    function cameraStyleLockShot(shot) {
      if (!shot || !cameraStyleLockNoPov()) return shot;
      const parsed = splitFinalPrompt(shot.positive);
      if (!parsed) return shot;
      const drop = /^(?:pov|taker pov|giver pov|pov hands|pov crotch|pov feet|first[- ]person view|first[- ]person perspective|first[- ]person camera view(?: with hands in the foreground)?|point of view)$/i;
      const angle = /^pov (from (?:below|above|behind(?: her)?|side|front))$/i;
      const cameraAngle = /^first[- ]person camera view from (above|below)$/i;
      const positive = parsed.tokens.flatMap(token => {
        const text = token.trim(), match = /^\((.+?)(:[\d.]+)?\)$/.exec(text);
        const inner = (match ? match[1] : text).trim();
        const normalized = inner.replaceAll('_', ' ');
        if (drop.test(normalized)) return [];
        const cameraFound = cameraAngle.exec(normalized);
        if (cameraFound) {
          const replacement = cameraFound[1].toLowerCase() === 'above' ? 'high-angle camera view' : 'low-angle camera view';
          return [match ? `(${replacement}${match[2] || ''})` : replacement];
        }
        const found = angle.exec(normalized);
        if (!found) return [text];
        const replacement = found[1].replace(/ her$/i, '');
        return [match ? `(${replacement}${match[2] || ''})` : replacement];
      }).filter(Boolean).join(', ');
      return { ...shot, positive };
    }
    function cameraWarnings(value) {
      const warnings = [];
      if (cameraStyleLockNoPov()) warnings.push('그림체 고정 모드의 POV 제거 설정이 켜져 있어 POV가 빠질 수 있어요.');
      for (const shot of value?.shots || []) if (value.selected?.includes(shot.id)
        && (removeGlobalPromptExclusions(shot.positive, 'positive') !== shot.positive
          || removeGlobalPromptExclusions(shot.negative, 'negative') !== shot.negative)) {
        warnings.push('전역 제거 설정과 선택한 카메라 태그가 겹쳐 해당 태그가 빠질 수 있어요.');
        break;
      }
      return warnings;
    }
    function cameraGet(id = '') {
      const situationId = id || cameraCurrentSituation();
      if (!/^(?:scene|task|look)-[^_]/.test(situationId) || situationId.length > 200 || situationId.includes('__')) return null;
      const source = cameraSettingSource(situationId), value = source?.value || { shots: [], selected: [], removeTags: '' };
      const key = cameraCurrentSituation() === situationId ? activePortraitImageKey('', api.store.game()) : '';
      const chosen = cameraMetadataForKey(key);
      const resolvedShotId = value.selected.length === 1 ? value.selected[0]
        : chosen && value.selected.includes(chosen.id) ? chosen.id : null;
      return { situationId, sourceId: source?.id || situationId, shots: value.shots.map(shot => ({ ...shot })),
        selected: [...value.selected], removeTags: value.removeTags, active: value.selected.length > 0,
        dirty: source?.draft === true, resolvedShotId, warnings: cameraWarnings(value) };
    }
    function cameraApply(id, value) {
      if (typeof id !== 'string' || !/^(?:scene|task|look)-[^_]/.test(id) || id.length > 200 || id.includes('__')
        || !value || typeof value !== 'object' || Array.isArray(value)) return { ok: false, reason: 'invalid' };
      const normalized = normalizeCameraSettings({ [id]: value });
      if (!Object.hasOwn(normalized, id) && (value.shots?.length || value.removeTags)) return { ok: false, reason: 'invalid' };
      if (!Object.hasOwn(cameraDrafts, id) && Object.keys(cameraDrafts).length >= 1000) return { ok: false, reason: 'limit' };
      cameraDrafts[id] = normalized[id] || { shots: [], selected: [], removeTags: '', disabled: true };
      cameraSettingsFingerprints.clear(); cameraPending.clear();
      legacyDetailImageKeys.clear(); statusCacheAliases.clear(); notifyExternalPromptChange();
      return { ok: true, reason: 'applied' };
    }
    function cameraSet(id, value) {
      if (typeof id !== 'string' || !value || typeof value !== 'object' || Array.isArray(value)) return { ok: false, reason: 'invalid' };
      const normalized = normalizeCameraSettings({ [id]: value });
      if (!Object.hasOwn(normalized, id) && (value?.shots?.length || value?.removeTags)) return { ok: false, reason: 'invalid' };
      if (!/^(?:scene|task|look)-[^_]/.test(id) || id.length > 200 || id.includes('__')) return { ok: false, reason: 'invalid' };
      const next = { ...cameraSceneSettings };
      if (normalized[id]) next[id] = normalized[id];
      else if (id.includes('|') && !id.includes('|sleep-') && cameraSettingSource(id.split('|')[0])?.value?.selected?.length)
        next[id] = { shots: [], selected: [], removeTags: '', disabled: true };
      else delete next[id];
      if (Object.keys(next).length > 1000) return { ok: false, reason: 'limit' };
      try { api.settings.set({ cameraSceneSettings: next }); } catch { return { ok: false, reason: 'storage' }; }
      cameraSceneSettings = next; delete cameraDrafts[id]; cameraSettingsFingerprints.clear(); cameraPending.clear();
      legacyDetailImageKeys.clear(); statusCacheAliases.clear(); notifyExternalPromptChange();
      return { ok: true, reason: 'saved' };
    }
    function cameraReset(id) {
      if (typeof id !== 'string' || !/^(?:scene|task|look)-[^_]/.test(id) || id.length > 200 || id.includes('__')) return { ok: false, reason: 'invalid' };
      const next = { ...cameraSceneSettings }; delete next[id];
      const base = id.split('|')[0];
      if (base !== id && !id.includes('|sleep-') && next[base]?.selected?.length)
        next[id] = { shots: [], selected: [], removeTags: '', disabled: true };
      try { api.settings.set({ cameraSceneSettings: next }); } catch { return { ok: false, reason: 'storage' }; }
      cameraSceneSettings = next; delete cameraDrafts[id]; cameraSettingsFingerprints.clear(); cameraPending.clear();
      legacyDetailImageKeys.clear(); statusCacheAliases.clear(); notifyExternalPromptChange();
      return { ok: true, reason: 'reset' };
    }
    function cameraPreview(id, prompt, negativePrompt, options = {}) {
      const snapshot = cameraGet(id);
      if (!snapshot?.active) return { prompt, negativePrompt, removed: [], added: [], shotId: null };
      const selected = snapshot.selected.map(key => snapshot.shots.find(shot => shot.id === key)).filter(Boolean);
      const choice = typeof options.shotId === 'string' ? selected.find(shot => shot.id === options.shotId)
        : options.draw === true ? selected[Math.floor(Math.random() * selected.length)]
          : selected.find(shot => shot.id === snapshot.resolvedShotId);
      const result = cameraApplyShot(prompt, negativePrompt, cameraStyleLockShot(choice), snapshot.removeTags,
        cameraExclusiveTagsFromParts(options.parts), options.parts);
      return result.shotId ? { ...result, prompt: cameraStyleLockShot({ positive: result.prompt }).positive } : result;
    }
    function cameraCacheToken(id, shotId = '') {
      if (typeof id !== 'string' || typeof shotId !== 'string') return '';
      const value = cameraSettingSource(id)?.value;
      if (!value?.selected.length) return '';
      const resolved = shotId || (value.selected.length === 1 ? value.selected[0] : '');
      if (!value.selected.includes(resolved) || !value.shots.some(shot => shot.id === resolved)) return '';
      return shortHash(JSON.stringify([cameraSettingsFingerprint(id), resolved]));
    }

    function cameraShotForImage(situationId, key) {
      const value = cameraSettingSource(situationId)?.value;
      if (!value?.selected.length) return null;
      if (value.selected.length === 1) return value.shots.find(shot => shot.id === value.selected[0]) || null;
      const metadata = cameraMetadataForKey(key);
      return metadata && value.selected.includes(metadata.id) ? metadata : null;
    }

    function cameraApplyPromptResult(result) {
      if (!result || typeof result.prompt !== 'string' || typeof result.key !== 'string') return result;
      const situationId = positionSituationId(result.key), value = cameraSettingSource(situationId)?.value;
      const shot = value && cameraShotForImage(situationId, result.key);
      if (!shot) return result;
      const changed = cameraApplyShot(result.prompt, result.negativePrompt || '', shot, value.removeTags, [], result.parts);
      const blocked = cameraBlocked(shot, value.removeTags);
      const parts = Array.isArray(result.parts) ? result.parts.map(part => part && typeof part.tags === 'string'
        ? { ...part, tags: cameraRewriteText(part.tags, blocked).value } : part) : [];
      const baseIndex = changed.placement === 'after-base' ? parts.reduce((last, part, index) =>
        ['품질', 'Quality', '기본', 'Base'].includes(part?.label) ? index : last, -1) : -1;
      parts.splice(baseIndex + 1, 0, { label: 'AIP 카메라 구도', tags: shot.positive });
      return { ...result, prompt: changed.prompt, negativePrompt: changed.negativePrompt,
        parts,
        genParams: promptGenParams(changed.prompt) };
    }

    function cameraGenerationOriginalKey(request) {
      const actual = request?.imageKey;
      if (typeof actual !== 'string' || !actual) return '';
      const traced = request?.[imageRequestTraceSymbol]?.aipBefore?.imageKey;
      if (typeof traced !== 'string' || !traced) return actual;
      const actualVariant = actual.match(/__v-\d+$/)?.[0] || '';
      const originalVariant = traced.match(/__v-\d+$/)?.[0] || '';
      const original = actualVariant && actualVariant !== originalVariant
        ? traced.replace(/__v-\d+$/, '') + actualVariant : traced;
      return cameraKeyAliases(original).includes(actual) ? original : actual;
    }

    // This is an optional cache probe before the game's normal generation
    // path, not a reason to hold the portrait indefinitely if an image pack,
    // remote server or another mod never finishes its lookup.
    async function cameraHasCachedImage(key) {
      if (typeof imageLookup !== 'function') return false;
      let timeout;
      try {
        return await Promise.race([
          Promise.resolve().then(async () => {
            const cached = await imageLookup(key);
            return !!(cached && cameraKeyAliases(key).includes(cached.talentName) && await imageEntryExists(cached));
          }).catch(() => false),
          new Promise(resolve => { timeout = setTimeout(() => resolve(false), 1200); }),
        ]);
      } finally { clearTimeout(timeout); }
    }

    async function cameraGenerationAround(next, request, ...args) {
      if (!request || typeof request.prompt !== 'string' || typeof request.imageKey !== 'string'
        || !request.debug?.stats || request.bulk === true || request.debug?.source || imagePlanDepth) return next(request, ...args);
      const original = cameraGenerationOriginalKey(request), situationId = positionSituationId(original);
      const value = cameraSettingSource(situationId)?.value;
      if (!value?.selected.length) return next(request, ...args);
      const state = api.store?.game?.(), portraitKey = activePortraitImageKey('', state);
      if (!state?.primaryCharacterId || !portraitKey
        || similarImageSituationKey(portraitKey) !== similarImageSituationKey(original)) return next(request, ...args);
      const selected = value.selected.map(id => value.shots.find(shot => shot.id === id)).filter(Boolean);
      if (!selected.length) return next(request, ...args);
      const signature = cameraSettingsFingerprint(situationId);
      const sameFresh = nativeFreshVariantKeys.has(request.imageKey) || nativeFreshVariantKeys.has(original);
      const bypass = request.bypassCache === true || sameFresh;
      const cached = !bypass && await cameraHasCachedImage(original);
      // The user may switch scenes or change the camera while the probe waits.
      // Ignore normal status/variant changes while the first portrait settles.
      const currentPortrait = activePortraitImageKey('', api.store.game());
      if (signature !== cameraSettingsFingerprint(situationId) || (currentPortrait
        && similarImageSituationKey(baseSituationImageKey(currentPortrait)) !== similarImageSituationKey(baseSituationImageKey(portraitKey))))
        return null;
      if (cached) return next(request, ...args);
      const pendingKey = request.imageKey;
      const now = Date.now();
      let pending = cameraPending.get(pendingKey);
      if (!pending || pending.expires < now || pending.signature !== cameraSettingsFingerprint(situationId)
        || (bypass && !sameFresh && !pending.running)) {
        const shot = selected.length === 1 ? selected[0] : selected[Math.floor(Math.random() * selected.length)];
        pending = { shot: { ...shot }, signature: cameraSettingsFingerprint(situationId), expires: now + 30000, running: 0 };
        cameraPending.set(pendingKey, pending);
        if (cameraPending.size > 200) for (const [key, item] of cameraPending) {
          if (!item.running && (item.expires < now || cameraPending.size > 200)) cameraPending.delete(key);
        }
      }
      const latestKey = latestScenePrompt?.result?.key;
      const matchingParts = typeof latestKey === 'string'
        && similarImageSituationKey(latestKey) === similarImageSituationKey(portraitKey) ? latestScenePrompt.result.parts : null;
      const changed = cameraApplyShot(request.prompt, request.negativePrompt || '', cameraStyleLockShot(pending.shot), value.removeTags,
        cameraPreviousExclusiveTags(portraitKey), matchingParts);
      changed.prompt = cameraStyleLockShot({ positive: changed.prompt }).positive;
      pending.running++;
      let result;
      try { result = await next(applyGlobalPromptExclusions({ ...request, prompt: changed.prompt, negativePrompt: changed.negativePrompt }), ...args); }
      finally { pending.running--; }
      if (result?.url && result.fresh !== false && pending.signature === cameraSettingsFingerprint(situationId)) {
        const nextMetadata = { ...cameraImageMetadata };
        for (const key of cameraKeyAliases(original)) nextMetadata[key] = pending.shot;
        for (const key of cameraKeyAliases(request.imageKey)) nextMetadata[key] = pending.shot;
        const normalized = normalizeCameraImageMetadata(nextMetadata);
        try { api.settings.set({ cameraImageMetadata: normalized }); cameraImageMetadata = normalized; }
        catch (error) { console.warn('[attention-image-prompt] camera metadata', error); }
        cameraPending.delete(pendingKey);
      }
      return result;
    }
    const cameraController = Object.freeze({
      list: () => ({ groups: CAMERA_PRESET_GROUPS.map(group => ({ ...group, items: group.items.map(item => ({ ...item })) })), removeDefaults: [...CAMERA_REMOVE_DEFAULTS], negativeDefaults: CAMERA_NEGATIVE_DEFAULTS }),
      get: cameraGet, apply: cameraApply, set: cameraSet, reset: cameraReset, preview: cameraPreview, cacheToken: cameraCacheToken,
    });
