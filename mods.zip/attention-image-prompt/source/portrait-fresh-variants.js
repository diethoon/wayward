    const portraitFreshReservations = new Set();

    function studioAutomaticGenerationBusy() {
      try {
        return globalThis.WW_ImageStudio?.isBusy?.() === true
          || globalThis.WW_ImageStudioPrompt?.isBusy?.() === true;
      } catch { return false; }
    }

    function studioAutomaticGenerationOff() {
      if (globalThis.__WW_STUDIO_OFFLINE_ONLY__ === true) return true;
      try { return settingsStore?.getState?.().imageBackendMode === 'off'; }
      catch { return false; }
    }

    let studioBackendProbePending = null;
    function studioBackendPreferences() {
      if (typeof settingsStore === 'undefined') return null;
      try {
        const settings = settingsStore?.getState?.();
        if (!settings || !['auto', 'custom', 'off'].includes(settings.imageBackendMode)) return null;
        return { mode: settings.imageBackendMode, url: settings.imageBackendUrl || '',
          allowAutoProbe: api.has('imageAutoProbeAllowed') ? api.fn('imageAutoProbeAllowed')() : true };
      } catch { return null; }
    }
    function sameStudioBackendPreferences(a, b) {
      return !!a && !!b && a.mode === b.mode && a.url === b.url && a.allowAutoProbe === b.allowAutoProbe;
    }
    function canRecheckStudioBackend(settings) {
      return !!settings && (settings.mode === 'auto' && settings.allowAutoProbe === true
        || settings.mode === 'custom' && typeof settings.url === 'string' && !!settings.url.trim());
    }
    function recheckStudioBackend() {
      if (studioBackendProbePending) return studioBackendProbePending;
      if (!api.has('imageBackendProbe')) return null;
      const initial = studioBackendPreferences();
      if (!canRecheckStudioBackend(initial)) return null;
      const run = async () => {
        if (studioAutomaticGenerationOff() || !sameStudioBackendPreferences(initial, studioBackendPreferences())) return;
        let current = initial;
        for (let count = 0; count < 3; count++) {
          let error;
          try { await api.fn('imageBackendProbe')(current, true); } catch (cause) { error = cause; }
          const latest = studioBackendPreferences();
          if (!latest || sameStudioBackendPreferences(current, latest)) {
            if (error) throw error;
            return;
          }
          current = latest;
        }
        // The game probe commits globally; discard a stale result if settings never settled.
        if (api.has('imageBackendForget')) api.fn('imageBackendForget')();
      };
      const pending = Promise.resolve().then(run).finally(() => {
        if (studioBackendProbePending === pending) studioBackendProbePending = null;
      });
      studioBackendProbePending = pending;
      return pending;
    }

    if (api.has('imageGenerate')) api.hook('imageGenerate', {
      priority: -3000001,
      async around(next, request, ...args) {
        if (!request || typeof request.imageKey !== 'string' || nativeFreshVariantKeys.has(request.imageKey) || request.bypassCache === true
          || request.bulk === true || request.debug?.source || studioAutomaticGenerationOff()
          || !studioAutomaticGenerationBusy()) return next(request, ...args);
        if (typeof imageLookup !== 'function' || !api.has('imageGenerationInFlight')
          || !api.has('currentPortraitImageKey')) return next(request, ...args);
        let cached;
        try { cached = await imageLookup(request.imageKey); }
        catch { return next(request, ...args); }
        if (cached) return next(request, ...args);
        let queue, owner, portraitKey, portraitKeyOf;
        try {
          queue = api.fn('imageGenerationInFlight');
          owner = queue?.get?.(request.imageKey);
          portraitKeyOf = api.fn('currentPortraitImageKey');
          portraitKey = portraitKeyOf(api.store.game());
        } catch { return next(request, ...args); }
        if (!owner || typeof portraitKey !== 'string' || !portraitKey) return next(request, ...args);
        const canceled = () => {
          if (owner.cancelRequested === true || queue.get(request.imageKey) !== owner) return true;
          try {
            const current = portraitKeyOf(api.store.game());
            return typeof current === 'string' && !!current && current !== portraitKey;
          } catch { return false; }
        };
        const deadline = Date.now() + 30000;
        while (studioAutomaticGenerationBusy() && !studioAutomaticGenerationOff() && Date.now() < deadline) {
          if (canceled()) return null;
          await new Promise(resolve => setTimeout(resolve, 250));
        }
        if (canceled()) return null;
        return next(request, ...args);
      },
    });

    // ImageStudio can return a placeholder before its server/batch status recovers.
    const pendingStudioPortraitRetries = new Map();
    if (api.has('imageGenerate')) api.hook('imageGenerate', {
      priority: -3000002,
      around(next, request, ...args) {
        if (request?.bypassCache === true && typeof request.imageKey === 'string') {
          const previous = pendingStudioPortraitRetries.get(request.imageKey);
          if (previous) previous.canceled = true;
        }
        if (!request?.debug?.stats || request.debug.source || request.bypassCache === true || request.bulk === true
          || typeof request.imageKey !== 'string' || !api.has('currentPortraitImageKey')) return next(request, ...args);
        const key = request.imageKey;
        const pending = pendingStudioPortraitRetries.get(key);
        if (pending) return pending.task;
        const retryState = { canceled: false, task: null };
        pendingStudioPortraitRetries.set(key, retryState);
        const run = async () => {
          const result = await next(request, ...args);
          if (retryState.canceled) return null;
          const bridge = globalThis.WW_ImageStudioBridge;
          if (!result?.imageMatchingMissing || studioAutomaticGenerationOff()
            || typeof bridge?.generationUnavailable !== 'function' || typeof bridge?.connection !== 'function') return result;
          let initial;
          try {
            const state = api.store.game();
            const portrait = api.fn('currentPortraitImageKey')(state);
            if (!state?.primaryCharacterId || !portrait
              || similarImageSituationKey(portrait) !== similarImageSituationKey(key)) return result;
            initial = { portrait, character: state.primaryCharacterId };
          } catch { return result; }
          const deadline = Date.now() + 30000;
          let attempts = 0, recheckedBackend = false;
          while (Date.now() < deadline && attempts < 3) {
            await new Promise(resolve => setTimeout(resolve, 1000));
            if (retryState.canceled) return null;
            if (studioAutomaticGenerationOff()) return result;
            try {
              const state = api.store.game();
              if (state?.primaryCharacterId !== initial.character
                || api.fn('currentPortraitImageKey')(state) !== initial.portrait) return null;
              let connection = bridge.connection();
              if ((!connection?.baseUrl || connection.comfyui === false) && !recheckedBackend && !studioAutomaticGenerationBusy()) {
                recheckedBackend = true;
                const settings = studioBackendPreferences();
                const probe = recheckStudioBackend();
                if (probe) {
                  await probe;
                  if (retryState.canceled) return null;
                  if (studioAutomaticGenerationOff() || !sameStudioBackendPreferences(settings, studioBackendPreferences())) return result;
                  const now = api.store.game();
                  if (now?.primaryCharacterId !== initial.character || api.fn('currentPortraitImageKey')(now) !== initial.portrait) return null;
                }
                connection = bridge.connection();
              }
              if (!connection?.baseUrl || connection.comfyui !== true) continue;
              if (await bridge.generationUnavailable()) continue;
              const current = api.store.game();
              if (retryState.canceled) return null;
              if (studioAutomaticGenerationOff() || Date.now() >= deadline) return result;
              if (current?.primaryCharacterId !== initial.character
                || api.fn('currentPortraitImageKey')(current) !== initial.portrait) return null;
              const currentConnection = bridge.connection();
              if (!currentConnection?.baseUrl || currentConnection.comfyui !== true) continue;
              attempts++;
              const retry = await next(request, ...args);
              if (retryState.canceled) return null;
              if (!retry?.imageMatchingMissing) return retry;
            } catch { return result; }
          }
          return result;
        };
        retryState.task = Promise.resolve().then(run).finally(() => {
          if (pendingStudioPortraitRetries.get(key) === retryState) pendingStudioPortraitRetries.delete(key);
        });
        return retryState.task;
      },
    });

    async function portraitFreshVariantKey(imageKey, rejected) {
      const base = similarImageSituationKey(imageKey);
      const choice = similarImageChoice(imageKey);
      const used = new Set([...(portraitImageVariants(imageKey).variants || []).filter(key => key !== imageKey),
        ...(unusedPortraitImages()[base] || []), ...(choice?.autoVariants || []),
        ...Object.keys(choice?.manualVariants || {}), ...portraitFreshReservations, ...rejected]);
      if (api.has('imageManifestReset')) api.fn('imageManifestReset')();
      const manifest = api.has('imageManifest') ? await api.fn('imageManifest')() : null;
      const local = await localGeneratedEntries(true);
      let number = Math.max(USER_VARIANT_START, Number(imageKey.match(/__v-(\d+)$/)?.[1]) || USER_VARIANT_START);
      if (!manifest?.entries) number = Math.max(number, Date.now() * 1000 + Math.floor(Math.random() * 1000));
      for (;;) {
        const candidate = `${base}__v-${number}`;
        const aliases = [candidate, compactGenerationKey(candidate), compactGenerationKey(candidate, true)];
        if (!aliases.some(key => used.has(key) || manifest?.entries?.[key] || local?.[key]
          || portraitFreshReservations.has(key))) { portraitFreshReservations.add(candidate); return candidate; }
        number += 1;
      }
    }

    async function portraitExactVariant(imageKey) {
      const variant = Number(String(imageKey || '').match(/__v-(\d+)$/)?.[1]);
      const variants = portraitImageVariants(imageKey).variants;
      const added = Number.isFinite(variant) && variant >= USER_VARIANT_START;
      if (!variants.includes(imageKey) || (!added && !variants.some(key =>
        Number(String(key).match(/__v-(\d+)$/)?.[1]) >= USER_VARIANT_START))
        || similarImageLookupOverride(imageKey)) return { handled: false };
      try {
        const manifest = api.has('imageManifest') ? await api.fn('imageManifest')() : null;
        const local = await localGeneratedEntries();
        for (const key of new Set([imageKey, compactGenerationKey(imageKey), compactGenerationKey(imageKey, true)])) {
          const entry = manifest?.entries?.[key] || local?.[key];
          if (entry && await imageEntryExists(entry)) return { handled: true, entry: { ...entry, talentName: imageKey } };
        }
      } catch (error) { console.warn('[attention-image-prompt] portrait variant lookup', error); }
      return { handled: added };
    }

    api.hook('imageGenerate', {
      // ImageStudio can return a similar image before the ordinary AIP hook runs.
      priority: -2000001,
      async around(next, request, ...args) {
        const original = request?.imageKey;
        if (!nativeFreshVariantKeys.has(original)) {
          if (request?.bypassCache === true || request?.bulk === true || request?.debug?.source) return next(request, ...args);
          const exact = typeof original === 'string' ? await portraitExactVariant(original) : null;
          const url = exact?.entry && imageEntryUrl(exact.entry);
          if (url) return { url, fresh: false, key: original };
          return exact?.handled ? null : next(request, ...args);
        }
        let key;
        const rejected = new Set();
        try {
          for (let attempt = 0; attempt < 8; attempt++) {
            key = await portraitFreshVariantKey(original, rejected);
            nativeFreshVariantKeys.add(key);
            const result = await next({ ...request, imageKey: key, bypassCache: true }, ...args);
            if (!result?.url) return result;
            if (result.fresh === true) {
              nativeFreshVariantKeys.delete(original);
              return { ...result, key };
            }
            if (result.fresh !== false) throw new Error('새 이미지가 생성됐는지 확인할 수 없습니다.');
            rejected.add(key);
            portraitFreshReservations.delete(key);
            if (key !== original) nativeFreshVariantKeys.delete(key);
          }
          throw new Error('사용하지 않은 이미지 번호를 찾지 못했습니다.');
        } catch (error) {
          console.warn('[attention-image-prompt] portrait variant generation', error);
          window.alert(`이미지 추가 생성을 시작하지 못했습니다: ${error.message || error}`);
          return null;
        } finally {
          if (key) { portraitFreshReservations.delete(key); if (key !== original) nativeFreshVariantKeys.delete(key); }
        }
      },
    });

    api.hook('imageLookup', {
      priority: -2000001,
      async around(next, imageKey, ...args) {
        if (nativeFreshVariantKeys.has(imageKey)) return null;
        const exact = await portraitExactVariant(imageKey);
        return exact.entry || (exact.handled ? null : next(imageKey, ...args));
      },
    });
