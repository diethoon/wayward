﻿# 실행: powershell -NoProfile -ExecutionPolicy Bypass -File wml/mods/attention-image-prompt/source/package.ps1
# Version is numeric; game target is 2026-11-01; ZIP contains the stable mod ID folder.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$releaseRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$releaseSource = Get-Content -LiteralPath (Join-Path $releaseRoot 'mod.js') -Raw -Encoding UTF8
$releaseDefinition = $releaseSource.Substring($releaseSource.IndexOf('WML.define'))
$releaseId = [regex]::Match($releaseDefinition, 'id\s*:\s*[\x27\x22]([^\x27\x22]+)').Groups[1].Value
$releaseVersion = [regex]::Match($releaseDefinition, 'version\s*:\s*[\x27\x22]([^\x27\x22]+)').Groups[1].Value
if ($releaseId -ne (Split-Path $releaseRoot -Leaf) -or $releaseVersion -notmatch '^\d+\.\d+\.\d+$') { throw 'ID/folder or numeric version mismatch' }
$releaseZip = Join-Path $releaseRoot ($releaseId + '-' + $releaseVersion + '-20261101.zip')
$releaseFiles = @('IMAGE_SERVER_README.md', 'README.md', 'README_USER.md', 'anal-anatomy-test.cjs', 'button-prompts-test.cjs', 'camera-all-angles-test.cjs', 'camera-core-test.cjs', 'camera-presets-test.cjs', 'camera-ui-test.cjs', 'check.cjs', 'current-state-editor-test.cjs', 'external-api-test.cjs', 'first-experience-creation-test.cjs', 'generation-weight-test.cjs', 'global-exclusion-test.cjs', 'manual-action-priority-test.cjs', 'mod.js', 'modder-api/AIP_FIELDS.md', 'modder-api/AIP_HOOKS.md', 'modder-api/MODDER_API.md', 'modder-api/modder-example.js', 'portrait-display-test.cjs', 'portrait-fresh-variants-test.cjs', 'portrait-offline-button-test.cjs', 'position-auto-default-test.cjs', 'position-console-panel-test.cjs', 'position-console-performance-test.cjs', 'position-controller-test.cjs', 'position-portrait-performance-test.cjs', 'prompt-dedup-test.cjs', 'prompt-mod-fingerprint-test.cjs', 'prompt-review-diff-test.cjs', 'prompt-tag-search-test.cjs', 'request-trace-test.cjs', 'scene-base-overrides-test.cjs', 'scene-candidate-pool-test.cjs', 'scene-image-preview-test.cjs', 'scene-native-prompts-test.cjs', 'scene-prompt-key-test.cjs', 'scene-prompt-ui-test.cjs', 'scene-prompts-api-test.cjs', 'short-image-keys-test.cjs', 'similar-preview-offline-test.cjs', 'source/build.mjs', 'source/button-prompts.js', 'source/camera-core.js', 'source/camera-presets.js', 'source/camera-ui.js', 'source/current-state-editor.js', 'source/diagnostics-and-image-pack.js', 'source/external-position-targets.js', 'source/external-targets.js', 'source/first-experience-creation.js', 'source/generation-weight.js', 'source/global-prompt-exclusions.js', 'source/hstatus-images.js', 'source/image-browser.js', 'source/image-cache-and-keys.js', 'source/image-state.js', 'source/mod.wml.js', 'source/native-pack-compat.js', 'source/native-studio-characters.js', 'source/offline-cache.js', 'source/package.ps1', 'source/portrait-fresh-variants.js', 'source/position-controller-core.js', 'source/position-controller-ui.js', 'source/position-generation.js', 'source/prompt-foundations.js', 'source/prompt-mod-rules.js', 'source/prompt-tag-search.js', 'source/scene-base-overrides.js', 'source/scene-candidate-pool.js', 'source/scene-image-preview.js', 'source/scene-native-prompts.js', 'source/scene-prompts-api.js', 'source/settings-controls.js', 'source/settings-data.js', 'source/tab-json.js', 'source/settings-panels.js', 'source/wife-builder.js', 'studio-busy-generation-test.cjs', 'studio-portrait-retry-test.cjs', 'tag-search-ui-test.cjs', 'two-hands-prompt-test.cjs')
if (Test-Path -LiteralPath $releaseZip) { throw 'Existing release is preserved. Bump mod version before packaging.' }
foreach ($releaseName in $releaseFiles) {
  if (!(Test-Path -LiteralPath (Join-Path $releaseRoot $releaseName) -PathType Leaf)) { throw ('Release file missing: ' + $releaseName) }
}
$releaseArchive = [IO.Compression.ZipFile]::Open($releaseZip, [IO.Compression.ZipArchiveMode]::Create, [Text.Encoding]::UTF8)
try { foreach ($releaseName in $releaseFiles) {
  $releasePath = [IO.Path]::GetFullPath((Join-Path $releaseRoot $releaseName))
  if (!$releasePath.StartsWith($releaseRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Path outside mod folder' }
  [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($releaseArchive, $releasePath, ($releaseId + '/' + $releaseName), [IO.Compression.CompressionLevel]::Optimal) | Out-Null
}} finally { $releaseArchive.Dispose() }
$releaseArchive = [IO.Compression.ZipFile]::OpenRead($releaseZip)
try {
 if ($releaseArchive.Entries.Count -ne $releaseFiles.Count) { throw 'ZIP count mismatch' }
 foreach ($releaseName in $releaseFiles) {
  $releaseEntry = $releaseArchive.GetEntry($releaseId + '/' + $releaseName)
  if (!$releaseEntry) { throw ('ZIP missing: ' + $releaseName) }
  $releaseInput = $releaseEntry.Open(); $releaseHash = [Security.Cryptography.SHA256]::Create()
  try { $releaseActual = ([BitConverter]::ToString($releaseHash.ComputeHash($releaseInput))).Replace('-', '') } finally { $releaseInput.Dispose(); $releaseHash.Dispose() }
  if ($releaseActual -ne (Get-FileHash -LiteralPath (Join-Path $releaseRoot $releaseName) -Algorithm SHA256).Hash) { throw ('ZIP differs: ' + $releaseName) }
 }
} finally { $releaseArchive.Dispose() }
Write-Output ('VERIFIED ' + $releaseZip)
