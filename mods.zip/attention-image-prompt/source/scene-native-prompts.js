    let nativeInlinePoseFn = null, nativeInlinePoseCache = null;
    function nativeInlinePoseCandidates() {
      let fn;
      try { fn = api.fn('imagePrompt'); } catch { return {}; }
      const original = typeof fn?.__wmlOriginal === 'function' ? fn.__wmlOriginal : fn;
      if (typeof original !== 'function') return {};
      if (original === nativeInlinePoseFn) return nativeInlinePoseCache;
      nativeInlinePoseFn = original;
      nativeInlinePoseCache = {};
      // The game stores these two task poses inline, not in the task prompt table.
      // Read only unambiguous literal branches; changed or wrapped game code remains unverified.
      let text;
      try { text = Function.prototype.toString.call(original); } catch { return nativeInlinePoseCache; }
      const sleep = [...text.matchAll(/\.currentTask\s*===\s*["']sleeping["'][\s\S]{0,350}?\{\s*label\s*:\s*["'](?:자세|Pose)["']\s*,\s*tags\s*:\s*(["'])([^"'\\\r\n]+)\1\s*\}/g)];
      if (sleep.length === 1) nativeInlinePoseCache.sleeping = [sleep[0][2]];
      const passed = [...text.matchAll(/\.currentTask\s*===\s*["']passed_out["'][\s\S]{0,500}?\{\s*label\s*:\s*["'](?:자세|Pose)["']\s*,\s*tags\s*:\s*\w+\s*\?\s*(["'])([^"'\\\r\n]+)\1\s*:\s*(["'])([^"'\\\r\n]+)\3\s*\}/g)];
      if (passed.length === 1) nativeInlinePoseCache.passed_out = [passed[0][2], passed[0][4]];
      return nativeInlinePoseCache;
    }

    function nativeScenePromptCandidates(situationId) {
      if (typeof situationId !== 'string' || !situationId) return [];
      const [base, ...details] = situationId.split('|');
      const read = name => {
        try {
          if (!api.has(name)) return null;
          return api.fn(name);
        } catch { return null; }
      };
      const readTable = name => {
        const value = read(name);
        return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
      };
      const out = [];
      const add = (source, label, values) => {
        const list = (Array.isArray(values) ? values : [values]).slice(0, 100);
        const valid = list.filter(value => typeof value === 'string' && value.trim());
        valid.forEach((text, index) => out.push({ source,
          label: valid.length > 1 ? `${label} ${index + 1}` : label, text: text.slice(0, 12000) }));
      };
      if (base.startsWith('scene-')) {
        const id = base.slice(6);
        add('scene', '게임 기본 후보', readTable('gameScenePromptTable')?.[id]);
        if (id === 'patron_groping' || id === 'patron_intimate')
          add('scene', '무릎 위 기본 후보', readTable('gameScenePromptTable')?.[`${id}_lap`]);
        add('bed', '침대 기본 후보', readTable('gameBedScenePromptTable')?.[id]);
        if (id === 'sex' || id === 'sex_rough') {
          const table = read(id === 'sex' ? 'gameSexPromptTable' : 'gameRoughSexPromptTable');
          if (Array.isArray(table)) add('scene', '관계 기본 후보', table.slice(0, 100).map(entry => entry?.tags));
        }
      } else if (base.startsWith('task-')) {
        const id = base.slice(5), table = readTable('gameTaskPromptTable');
        if (id === 'sleeping' || id === 'passed_out') {
          add('pose', id === 'sleeping' ? '수면 자세 기본 후보' : '기절 자세 기본 후보', nativeInlinePoseCandidates()[id]);
          return out;
        }
        if (table) {
          const own = Object.hasOwn(table, id) && typeof table[id] === 'string';
          add('task', own ? '작업 기본 후보' : '작업 공통 기본 후보', own ? table[id] : table.idle);
          if (id !== 'idle_bedroom') add('bedroom', '침실 작업 공통 후보', table.idle_bedroom);
        }
      } else if (base.startsWith('look-')) {
        const id = base.slice(5);
        const reaction = details.find(value => value.startsWith('reaction-'))?.slice(9);
        add('look', '시선 기본 후보', readTable('gameLookPromptTable')?.[id]);
        if (reaction) add('reaction', '반응 기본 후보', readTable('gameLookReactionPromptTable')?.[reaction]);
      }
      return out;
    }
