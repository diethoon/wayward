    let nativeInstalledPacks = [];
    if (api.game === '2026-11-01' && api.has('nativeInstalledImagePacks')
      && api.has('nativeInstalledPackEntries')) {
      const readNativePacks = api.fn('nativeInstalledImagePacks');
      const convertNativePacks = api.fn('nativeInstalledPackEntries');
      if (typeof readNativePacks === 'function' && typeof convertNativePacks === 'function') {
        let nativePackGeneration = 0, nativePacksLoaded = -1, nativePackPending = null;
        let nativePackDisposed = false, nativePackTimer = null, nativePackBridgeCleanup = null;
        let nativePackMarker = { packId: 'aip:native-packs:pending', entries: {} };
        async function ensureNativePacks() {
          while (!nativePackDisposed && nativePacksLoaded !== nativePackGeneration) {
            const requested = nativePackGeneration;
            if (!nativePackPending) {
              nativePackPending = (async () => {
                try {
                  const records = await readNativePacks();
                  if (!Array.isArray(records)) throw new Error('설치 팩 목록 형식이 다릅니다.');
                  const packs = convertNativePacks(records);
                  if (!Array.isArray(packs)) throw new Error('설치 팩 변환 결과가 다릅니다.');
                  if (!nativePackDisposed && requested === nativePackGeneration) {
                    nativeInstalledPacks = packs;
                    nativePacksLoaded = requested;
                    globalThis.WW_ImageStudioMatching?.refresh?.();
                  }
                  return true;
                } catch (error) {
                  if (!nativePackDisposed && requested === nativePackGeneration)
                    api.warn?.(`원본 이미지팩을 읽지 못했습니다: ${String(error?.message || error)}`);
                  return false;
                }
              })().finally(() => { nativePackPending = null; });
            }
            const success = await nativePackPending;
            if (!success && requested === nativePackGeneration) return false;
          }
          return !nativePackDisposed;
        }
        function resetNativePacks() {
          nativePackGeneration++;
          nativeInstalledPacks = [];
          nativePackMarker = { packId: 'aip:native-packs:pending', entries: {} };
          void ensureNativePacks();
        }
        const stopNativePackReset = api.has('imagePackReset')
          ? api.hook('imagePackReset', { before: resetNativePacks }) : null;
        function connectNativePackBridge() {
          if (nativePackDisposed) return;
          const status = globalThis.WML?.status?.();
          if (!status?.booted) {
            nativePackTimer = setTimeout(connectNativePackBridge, 250);
            return;
          }
          if (status.loaded?.includes('imagestudio-native-packs')) return;
          const bridge = globalThis.WW_ImageStudioBridge;
          if (typeof bridge?.packs !== 'function' || typeof bridge?.ready !== 'function') return;
          const originalPacks = bridge.packs, originalReady = bridge.ready;
          const wrappedPacks = function (...args) {
            const base = originalPacks.apply(this, args) || [];
            const ids = new Set(base.map(pack => pack?.packId).filter(Boolean));
            return [...base, ...nativeInstalledPacks.filter(pack => !ids.has(pack?.packId)), nativePackMarker];
          };
          const wrappedReady = async function (...args) {
            const result = await originalReady.apply(this, args);
            await ensureNativePacks();
            return result;
          };
          bridge.packs = wrappedPacks;
          bridge.ready = wrappedReady;
          nativePackBridgeCleanup = () => {
            if (bridge.packs === wrappedPacks) bridge.packs = originalPacks;
            if (bridge.ready === wrappedReady) bridge.ready = originalReady;
          };
          globalThis.WW_ImageStudioMatching?.refresh?.();
        }
        void ensureNativePacks();
        if (typeof globalThis.WML?.status === 'function') nativePackTimer = setTimeout(connectNativePackBridge, 0);
        window.addEventListener('pagehide', event => {
          if (event.persisted) return;
          nativePackDisposed = true;
          clearTimeout(nativePackTimer);
          stopNativePackReset?.();
          nativePackBridgeCleanup?.();
        });
      }
    }
