    const externalTargetAdapters = new Map();

    function registerExternalTargetAdapter(kind, adapter) {
      if (!externalIdValid(kind) || !adapter || typeof adapter.read !== 'function'
        || typeof adapter.save !== 'function' || typeof adapter.reset !== 'function' || typeof adapter.list !== 'function')
        throw new TypeError('Invalid AIP target adapter');
      externalTargetAdapters.set(kind, adapter);
    }

    function externalTargetBinding(target) {
      return target && externalTargetAdapters.has(target.kind) && typeof target.id === 'string'
        && target.id.length > 0 && target.id.length <= 160 && !/[\r\n\x00-\x1f]/.test(target.id)
        ? `@${target.kind}:${target.id}` : '';
    }

    function externalValidBinding(value, fieldKeys) {
      if (fieldKeys.has(value)) return true;
      if (typeof value !== 'string' || !value.startsWith('@')) return false;
      const separator = value.indexOf(':');
      if (separator < 2) return false;
      return externalTargetBinding({ kind: value.slice(1, separator), id: value.slice(separator + 1) }) === value;
    }

    function externalTargetSnapshot() {
      const data = currentExternalPromptData();
      return { data, providers: externalFieldProviders(data) };
    }

    function effectiveExternalTarget(kind, id, base, snapshot) {
      const binding = externalTargetBinding({ kind, id });
      if (!binding) return base;
      const provider = (snapshot?.providers || externalFieldProviders()).get(binding);
      if (!provider) return base;
      const prompt = resolveExternalPrompt(provider.id, provider.entryId, 'mod', snapshot?.data);
      if (!prompt) return base;
      return { ...base, positivePrompt: prompt.positivePrompt, negativePrompt: prompt.negativePrompt,
        ...(kind === 'outfit' ? { topPrompt: prompt.topPrompt, skirtPrompt: prompt.skirtPrompt } : {}) };
    }

    function externalTargetChanged(entry) {
      if (entry?.target) externalTargetAdapters.get(entry.target.kind)?.changed?.(entry.target.id);
    }

    registerExternalTargetAdapter('outfit', {
      list() {
        return (Array.isArray(outfitList) ? outfitList : []).filter(outfit => typeof outfit?.id === 'string')
          .map(outfit => ({ id: outfit.id, label: String(outfit.name || outfit.id) }));
      },
      read(id) {
        const custom = currentCustomOutfits().find(outfit => outfit.id === id);
        if (custom) return { positivePrompt: custom.positivePrompt, negativePrompt: custom.negativePrompt,
          topPrompt: custom.topPrompt, skirtPrompt: custom.skirtPrompt };
        const outfit = Array.isArray(outfitList) && outfitList.find(entry => entry?.id === id);
        if (!outfit) return null;
        const saved = normalizeOutfitPrompts(api.settings.get({ outfitPrompts: {} }).outfitPrompts)[id];
        return { positivePrompt: saved?.positivePrompt ?? String(outfit.imageTags || ''),
          negativePrompt: saved?.negativePrompt ?? String(outfit.negativeImageTags || ''),
          topPrompt: saved?.topPrompt ?? String(outfit.halves?.top || ''), skirtPrompt: saved?.skirtPrompt ?? String(outfit.halves?.skirt || '') };
      },
      save(id, changes) {
        const custom = currentCustomOutfits().find(outfit => outfit.id === id);
        if (custom) { saveCustomOutfit({ ...custom, ...changes }); return true; }
        const current = this.read(id);
        if (!current) return false;
        const positivePrompt = typeof changes.positivePrompt === 'string' ? changes.positivePrompt : current.positivePrompt;
        const negativePrompt = typeof changes.negativePrompt === 'string' ? changes.negativePrompt : current.negativePrompt;
        const previous = currentOutfitPrompts()[id] || {};
        const halves = Object.fromEntries(['topPrompt', 'skirtPrompt'].flatMap(field => typeof changes[field] === 'string'
          ? [[field, changes[field].slice(0, 8000)]] : typeof previous[field] === 'string' ? [[field, previous[field]]] : []));
        api.settings.set({ outfitPrompts: { ...currentOutfitPrompts(), [id]: { positivePrompt, negativePrompt, ...halves } } });
        return true;
      },
      reset(id) {
        const custom = currentCustomOutfits().find(outfit => outfit.id === id);
        if (custom) return false;
        const prompts = currentOutfitPrompts();
        if (!this.read(id)) return false;
        delete prompts[id];
        api.settings.set({ outfitPrompts: prompts });
        return true;
      },
      changed() { syncCustomOutfits(); },
    });
