    let latestServerImageRequest = null;
    const imageRequestTraceSymbol = Symbol('aip-image-request-trace');
    const pendingImageRequestTraces = new Map();
    const imageRequestWindows = new Set();
    let untrackedImageRequests = 0;

    function registerImageRequestWindow(win) {
      for (const item of imageRequestWindows) if (item.el?.isConnected === false) imageRequestWindows.delete(item);
      if (typeof win?.refresh === 'function') imageRequestWindows.add(win);
    }

    function imageRequestSnapshot(request) {
      return { imageKey: typeof request?.imageKey === 'string' ? request.imageKey : '',
        prompt: typeof request?.prompt === 'string' ? request.prompt : '',
        negativePrompt: typeof request?.negativePrompt === 'string' ? request.negativePrompt : '' };
    }

    function beginImageRequestTrace(request) {
      const trace = request?.[imageRequestTraceSymbol];
      const key = typeof request?.imageKey === 'string' ? request.imageKey : '';
      if (!trace || !key) {
        untrackedImageRequests += 1;
        let active = true;
        return () => { if (active) { active = false; untrackedImageRequests -= 1; } };
      }
      const now = Date.now();
      let count = 0;
      for (const [pendingKey, candidates] of pendingImageRequestTraces) {
        for (const candidate of candidates) if (now - candidate.at > 300000) {
          candidates.delete(candidate);
          candidate.untracked = true;
          untrackedImageRequests += 1;
        }
        if (!candidates.size) pendingImageRequestTraces.delete(pendingKey);
        else count += candidates.size;
      }
      if (count >= 64) {
        untrackedImageRequests += 1;
        let active = true;
        return () => { if (active) { active = false; untrackedImageRequests -= 1; } };
      }
      trace.aipAfter = imageRequestSnapshot(request);
      const pending = pendingImageRequestTraces.get(key) || new Set();
      const candidate = { trace, at: now, used: false };
      pending.add(candidate);
      pendingImageRequestTraces.set(key, pending);
      return () => {
        if (candidate.untracked) { candidate.untracked = false; untrackedImageRequests -= 1; }
        pending.delete(candidate);
        if (!pending.size && pendingImageRequestTraces.get(key) === pending) pendingImageRequestTraces.delete(key);
      };
    }

    function imageRequestComparison(imageKey, stack) {
      if (untrackedImageRequests) return null;
      const candidates = pendingImageRequestTraces.get(imageKey);
      if (!candidates || candidates.size !== 1) return null;
      const candidate = [...candidates][0];
      if (candidate.used || Date.now() - candidate.at > 300000) return null;
      let raw = '';
      try { raw = typeof api.sym === 'function' ? String(api.sym('imageGenerate') || '') : ''; } catch (_) {}
      // shortcut: stack names are only a conservative filter, not proof of request identity.
      const escaped = raw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const gameFrame = escaped && new RegExp(`\\bat\\s+(?:async\\s+)?(?:[\\w$.]+\\.)?${escaped}(?:\\s|\\()`);
      const frames = String(stack || '').split('\n');
      const observerFrame = frames.findIndex(line => /\bat\s+(?:[\w$.]+\.)?observedFetch(?:\s|\()/.test(line));
      if (!gameFrame || observerFrame < 0 || !gameFrame.test(frames[observerFrame + 1] || '')) return null;
      candidate.used = true;
      return { confidence: 'key-match', baseline: candidate.trace.baseline,
        aipBefore: candidate.trace.aipBefore || null, aipAfter: candidate.trace.aipAfter || null };
    }
    const imageRequestObserverKey = Symbol.for('wml.attention-image-prompt.request-observer');
    let imageRequestObserver = globalThis[imageRequestObserverKey];
    if (!imageRequestObserver && typeof globalThis.fetch === 'function') {
      const originalFetch = globalThis.fetch;
      imageRequestObserver = { capture: null, sequence: 0, keyTransfers: new Map(), transferSequence: 0,
        recentRegenerations: new Map() };
      const observer = imageRequestObserver;
      const observedFetch = function (...args) {
        let body = null;
        let bodyRequest = null;
        let sequence = 0;
        const capturedAt = Date.now();
        let stack = '';
        try {
          const input = args[0];
          const options = args[1];
          const url = typeof input === 'string' ? input : input?.url || input?.href || '';
          const method = String(options?.method || input?.method || 'GET').toUpperCase();
          if (method === 'POST' && /^(?:https?:\/\/[^/?#]+)?\/api\/review\/mark(?:[?#].*)?$/i.test(url)
            && typeof options?.body === 'string' && globalThis.WW_PromptManager?.version === '0.3.0') {
            const review = JSON.parse(options.body);
            if (review?.rating === 'regen' && typeof review.talentName === 'string' && review.talentName) {
              observer.recentRegenerations.set(review.talentName, Date.now());
              if (observer.recentRegenerations.size > 64)
                observer.recentRegenerations.delete(observer.recentRegenerations.keys().next().value);
            }
          }
          if (method === 'POST' && /^(?:https?:\/\/[^/?#]+)?\/api\/image\/generate(?:[?#].*)?$/i.test(url)) {
            sequence = ++observer.sequence;
            try { stack = String(new Error().stack || ''); } catch (_) {}
            if (typeof options?.body === 'string') body = options.body;
            else if (options?.body == null && typeof input?.clone === 'function') bodyRequest = input.clone();
            if (body !== null && observer.keyTransfers.size) {
              const value = JSON.parse(body);
              const marker = value?.debug?.__aipKeyTransfer;
              const transfer = observer.keyTransfers.get(marker);
              if (transfer && value.talentId === transfer.original && value.bypassCache === true) {
                observer.keyTransfers.delete(marker);
                const debug = { ...value.debug };
                delete debug.__aipKeyTransfer;
                if (!Object.keys(debug).length && transfer.originalDebug == null) {
                  if (transfer.originalDebug === null) value.debug = null;
                  else delete value.debug;
                } else value.debug = debug;
                value.talentId = transfer.compact;
                body = JSON.stringify(value);
                args[1] = { ...options, body };
              }
            }
          }
        } catch (_) {}
        const result = Reflect.apply(originalFetch, this, args);
        const record = text => {
          try {
            const value = JSON.parse(text);
            if (typeof value?.prompt === 'string'
              && (value.negativePrompt == null || typeof value.negativePrompt === 'string')) {
              const imageKey = typeof value.talentId === 'string' ? value.talentId
                : typeof value.talentName === 'string' ? value.talentName : '';
              observer.capture?.({ imageKey, prompt: value.prompt,
                negativePrompt: value.negativePrompt || '', capturedAt,
                comparison: imageRequestComparison(imageKey, stack) }, sequence);
            }
          } catch (_) {}
        };
        if (body !== null) record(body);
        else if (bodyRequest) {
          try { Promise.resolve(bodyRequest.text()).then(record, () => {}); } catch (_) {}
        }
        return result;
      };
      try {
        Object.defineProperty(globalThis, imageRequestObserverKey, { value: imageRequestObserver, configurable: true });
        globalThis.fetch = observedFetch;
        if (globalThis.fetch !== observedFetch) throw new Error('fetch is not writable');
      } catch (_) {
        try { delete globalThis[imageRequestObserverKey]; } catch (_) {}
        imageRequestObserver = null;
      }
    }
    if (imageRequestObserver) {
      let latestObservedSequence = imageRequestObserver.sequence;
      let imageRequestRefreshPending = false;
      let imageRequestBlurElement = null;
      const refreshObservedImageRequest = () => {
        if (activeSettingsTab !== 'prompt-mods' || !imageRequestWindows.size || imageRequestRefreshPending) return;
        imageRequestRefreshPending = true;
        queueMicrotask(() => {
          imageRequestRefreshPending = false;
          if (activeSettingsTab !== 'prompt-mods') return;
          const focused = globalThis.document?.activeElement;
          for (const win of imageRequestWindows) {
            if (win.el?.isConnected === false) { imageRequestWindows.delete(win); continue; }
            if (/^(?:INPUT|TEXTAREA|SELECT)$/.test(focused?.tagName || '')
              && win.el?.contains?.(focused) && typeof focused.addEventListener === 'function') {
              if (imageRequestBlurElement !== focused) {
                imageRequestBlurElement = focused;
                focused.addEventListener('blur', () => {
                  if (imageRequestBlurElement === focused) imageRequestBlurElement = null;
                  setTimeout(refreshObservedImageRequest, 0);
                }, { once: true });
              }
              continue;
            }
            try { win.refresh(); } catch (_) {}
          }
        });
      };
      imageRequestObserver.capture = (request, sequence) => {
        if (sequence <= latestObservedSequence) return;
        latestObservedSequence = sequence;
        latestServerImageRequest = request;
        refreshObservedImageRequest();
      };
    }

    function groupSimilarDetailStates() {
      return api.settings.get({ groupSimilarDetailStates: true }).groupSimilarDetailStates !== false;
    }

    function similarImageSituationKey(value) {
      return String(value || '').split('__').filter(part => !/^v-\d+$/.test(part)).join('__');
    }

    function accessorySituationCode(value) {
      const parts = String(value || '').split('__');
      const aip = (parts.find(part => part.startsWith('aip-')) || '').slice(4);
      return [...aip.split('_').filter(part => /^(?:jewel|toy)-/.test(part)),
        ...parts.filter(part => part.startsWith('acc-')),
        ...parts.filter(part => part.startsWith('toy-'))].join('_');
    }

    function currentSimilarImageChoices() {
      if (imageStudioOwnsSelection()) return {};
      const saved = api.settings.get({ similarImageChoices: {} }).similarImageChoices;
      if (!saved || typeof saved !== 'object' || Array.isArray(saved)) return {};
      const choices = [];
      for (const [target, value] of Object.entries(saved)) {
        if (typeof target !== 'string' || !target || target.length > 1000) continue;
        const rawKeys = typeof value === 'string' ? [value] : Array.isArray(value?.keys) ? value.keys : [value?.key];
        const keys = [...new Set(rawKeys.filter(key => typeof key === 'string' && key && key.length <= 1000))].slice(0, 50);
        const mode = ['auto', 'selected', 'both'].includes(value?.mode) ? value.mode : 'selected';
        const manualVariantKey = typeof value?.manualVariantKey === 'string' && value.manualVariantKey.length <= 1000 ? value.manualVariantKey : '';
        const manualVariants = Object.fromEntries(Object.entries(value?.manualVariants || {}).filter(([variant, source]) =>
          typeof variant === 'string' && variant && variant.length <= 1000
          && typeof source === 'string' && source && source.length <= 1000).slice(-100));
        if (manualVariantKey && keys[0]) manualVariants[manualVariantKey] = keys[0];
        const autoKey = typeof value?.autoKey === 'string' && value.autoKey.length <= 1000 ? value.autoKey : '';
        const autoVariants = [...new Set((Array.isArray(value?.autoVariants) ? value.autoVariants : [autoKey])
          .filter(key => typeof key === 'string' && key && key.length <= 1000))].slice(0, 50);
        if (!keys.length && !Object.keys(manualVariants).length) continue;
        choices.push([target, {
          key: keys[0] || '', keys, mode: keys.length ? mode : 'auto', manualVariants,
          autoKey: autoKey || autoVariants[0] || '', autoVariants,
        }]);
      }
      return Object.fromEntries(choices.slice(-200));
    }

    function similarImageChoice(imageKey) {
      return currentSimilarImageChoices()[similarImageSituationKey(imageKey)] || null;
    }

    function similarImageLookupOverride(imageKey) {
      const choice = similarImageChoice(imageKey);
      if (!choice) return null;
      const mappedSource = choice.manualVariants[imageKey];
      if (mappedSource && choice.keys.includes(mappedSource) && choice.mode !== 'auto') {
        return { key: mappedSource, fallbackKey: choice.autoKey, source: choice.mode === 'both' ? 'manual-both' : 'manual-selected-variant' };
      }
      if (mappedSource && choice.autoKey) return { key: choice.autoKey, source: 'manual-auto-cleanup' };
      if (isSavedPositionImageKey(imageKey) || positionGeneratedResults.has(imageKey)) return null;
      if (Number(imageKey.match(/__v-(\d+)$/)?.[1]) >= USER_VARIANT_START) return null;
      if (choice.mode === 'selected' && choice.keys[0]) {
        return { key: choice.keys[0], fallbackKey: choice.autoKey, source: 'manual-selected' };
      }
      return null;
    }

    function setSimilarImageChoice(imageKey, choice) {
      const target = similarImageSituationKey(imageKey);
      if (!target) return;
      const choices = currentSimilarImageChoices();
      delete choices[target];
      if (choice?.keys?.length || Object.keys(choice?.manualVariants || {}).length) choices[target] = choice;
      api.settings.set({ similarImageChoices: Object.fromEntries(Object.entries(choices).slice(-200)) });
    }

    function currentPrompts() {
      const saved = api.settings.get({ prompts: {} });
      const prompts = { ...DEFAULT_PROMPTS, ...(saved.prompts || {}) };
      for (const key of ['restraint.handcuffed', ...Object.keys(PREVIOUS_DEFAULT_PROMPTS), 'erostat.fit.loose', 'erostat.anal.loose']) {
        prompts[key] = migratedPromptValue(key, prompts[key], DEFAULT_PROMPTS);
      }
      return prompts;
    }

    function currentNegativePrompts() {
      const saved = api.settings.get({ negativePrompts: {} });
      const prompts = { ...DEFAULT_NEGATIVE_PROMPTS, ...(saved.negativePrompts || {}) };
      for (const key of ['restraint.handcuffed', ...Object.keys(PREVIOUS_BREAST_JEWELRY_NEGATIVE_PROMPTS), ...Object.keys(PREVIOUS_TOY_NEGATIVE_PROMPTS),
        'cycle.vulva.menstrual', 'cycle.vulva.follicular', 'cycle.vulva.ovulation', 'cycle.vulva.luteal', 'sleep.waking-rub']) {
        prompts[key] = migratedPromptValue(key, prompts[key], DEFAULT_NEGATIVE_PROMPTS);
      }
      return migratedBreathlessNegatives(api.settings.get({ prompts: {} }).prompts, prompts);
    }

    function normalizeCustomTags(value) {
      if (!Array.isArray(value)) return [];
      const tags = new Map();
      for (const entry of value) {
        const tag = String(entry?.tag || '').trim();
        const label = String(entry?.label || '').trim();
        if (tag && label) tags.set(tag.toLocaleLowerCase(), { tag, label });
      }
      return [...tags.values()];
    }

    function currentCustomTags() {
      return normalizeCustomTags(api.settings.get({ customTags: [] }).customTags);
    }

    function normalizePromptPresets(value) {
      if (!Array.isArray(value)) return [];
      const presets = new Map();
      for (const entry of value.slice(0, 50)) {
        const id = String(entry?.id || '').trim().slice(0, 100);
        const name = String(entry?.name || '').trim().slice(0, 80);
        const prompt = deduplicatePrompt(String(entry?.prompt || '').slice(0, 8000));
        if (id && name && prompt) presets.set(id, { id, name, prompt });
      }
      return [...presets.values()];
    }

    function currentPromptPresets() {
      return normalizePromptPresets(api.settings.get({ promptPresets: [] }).promptPresets);
    }

    function normalizeErostatPromptPresets(value) {
      if (!Array.isArray(value)) return [];
      const presets = new Map();
      for (const entry of value.slice(0, 50)) {
        const id = typeof entry?.id === 'string' && /^fit-[a-z0-9-]{1,96}$/.test(entry.id) ? entry.id : '';
        const name = typeof entry?.name === 'string' ? entry.name.trim().slice(0, 80) : '';
        const positivePrompt = typeof entry?.positivePrompt === 'string' ? entry.positivePrompt.slice(0, 8000) : '';
        const negativePrompt = typeof entry?.negativePrompt === 'string' ? entry.negativePrompt.slice(0, 8000) : '';
        if (id && name && (positivePrompt.trim() || negativePrompt.trim()))
          presets.set(id, { id, name, positivePrompt, negativePrompt });
      }
      return [...presets.values()];
    }

    function currentErostatPromptPresets() {
      return normalizeErostatPromptPresets(api.settings.get({ erostatPromptPresets: [] }).erostatPromptPresets);
    }

    function normalizeErostatPromptBundles(value) {
      if (!Array.isArray(value)) return [];
      const bundles = new Map();
      const fields = [...EROSTAT_FIT_FIELDS, ...EROSTAT_ANAL_FIELDS];
      for (const entry of value.slice(0, 50)) {
        const id = typeof entry?.id === 'string' && /^bundle-[a-z0-9-]{1,96}$/.test(entry.id) ? entry.id : '';
        const name = typeof entry?.name === 'string' ? entry.name.trim().slice(0, 80) : '';
        if (!id || !name) continue;
        const prompts = Object.fromEntries(fields.map(field => [field.key,
          typeof entry.prompts?.[field.key] === 'string' ? entry.prompts[field.key].slice(0, 8000) : DEFAULT_PROMPTS[field.key]]));
        const negativePrompts = Object.fromEntries(fields.map(field => [field.key,
          typeof entry.negativePrompts?.[field.key] === 'string' ? entry.negativePrompts[field.key].slice(0, 8000) : DEFAULT_NEGATIVE_PROMPTS[field.key]]));
        bundles.set(id, { id, name, prompts, negativePrompts });
      }
      return [...bundles.values()];
    }

    function currentErostatPromptBundles() {
      return normalizeErostatPromptBundles(api.settings.get({ erostatPromptBundles: [] }).erostatPromptBundles);
    }

    function normalizeCharacterPrompt(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return { ...DEFAULT_CHARACTER_PROMPT };
      const wifeKey = typeof value.wifeKey === 'string' ? value.wifeKey.trim() : '';
      const sourceId = typeof value.sourceId === 'string' ? value.sourceId.trim() : '';
      return {
        positivePrompt: typeof value.positivePrompt === 'string' ? value.positivePrompt : '',
        negativePrompt: typeof value.negativePrompt === 'string' ? value.negativePrompt : '',
        mode: 'replace',
        imagePolicy: value.imagePolicy === 'regenerate' ? 'regenerate' : 'reuse',
        ...(wifeKey ? { wifeKey } : {}),
        ...(sourceId ? { sourceId } : {}),
      };
    }

    function currentCharacterPrompt() {
      return normalizeCharacterPrompt(api.settings.get({ characterPrompt: DEFAULT_CHARACTER_PROMPT }).characterPrompt);
    }

    function normalizeGameDefaultPrompts(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(['positivePrompt', 'negativePrompt']
        .filter(key => typeof value[key] === 'string').map(key => [key, value[key]]));
    }

    function currentGameDefaultPrompts() {
      return normalizeGameDefaultPrompts(api.settings.get({ gameDefaultPrompts: {} }).gameDefaultPrompts);
    }

    function currentWifePromptContext(state = api.store.game(), characterId = state?.primaryCharacterId, character = state?.characters?.[characterId]) {
      const generated = character?.generatedArchetype;
      const archetype = generated ?? (character?.archetypeId ? wifeArchetypeById(character.archetypeId) : null);
      const wifeKey = String(generated?.attentionCustomWifeId || generated?.shortname || generated?.id
        || character?.archetypeId || characterId || '').trim();
      return {
        character,
        archetype,
        wifeKey,
        name: String(character?.name || archetype?.name || character?.shortname || characterId || '현재 아내').trim(),
      };
    }

    function promptFromWifeArchetype(archetype) {
      const registered = archetype?.attentionImagePrompt;
      const registeredNegative = registered && Object.prototype.hasOwnProperty.call(registered, 'negativePrompt');
      return normalizeCharacterPrompt({
        positivePrompt: String(registered?.positivePrompt || archetype?.imageBase || '').trim(),
        negativePrompt: normalizedWifeNegative(registeredNegative
          ? registered.negativePrompt
          : archetype?.attentionImageNegativeOverride ?? archetype?.imageNegative ?? ''),
        imagePolicy: registered?.imagePolicy,
      });
    }

    function characterPromptOverride(context = currentWifePromptContext()) {
      const saved = currentCharacterPrompt();
      if (saved.wifeKey) return saved.wifeKey === context.wifeKey ? saved : null;
      return saved.positivePrompt.trim() || saved.negativePrompt.trim() ? saved : null;
    }

    function currentWifeCharacterPrompt(context = currentWifePromptContext()) {
      return characterPromptOverride(context) || promptFromWifeArchetype(context.archetype);
    }

    function saveCurrentWifeCharacterPrompt(patch) {
      const context = currentWifePromptContext();
      const characterPrompt = normalizeCharacterPrompt({
        ...currentWifeCharacterPrompt(context),
        ...patch,
        wifeKey: context.wifeKey,
      });
      api.settings.set({ characterPrompt });
      if (pendingWifePromptEdit?.wifeKey === context.wifeKey) {
        const persisted = currentCharacterPrompt();
        for (const field of Object.keys(patch)) {
          if (persisted[field] === characterPrompt[field]) delete pendingWifePromptEdit.values[field];
        }
        if (!Object.keys(pendingWifePromptEdit.values).length) pendingWifePromptEdit = null;
      }
      publishCurrentWifePromptProfile();
      return characterPrompt;
    }

    function flushCurrentWifePromptEdit(state = api.store.game()) {
      const draft = pendingWifePromptEdit;
      if (draft?.wifeKey !== currentWifePromptContext(state).wifeKey) return;
      const values = { ...draft.values };
      saveCurrentWifeCharacterPrompt({ ...values, sourceId: '' });
      const saved = currentCharacterPrompt();
      if (Object.entries(values).some(([field, value]) => saved[field] !== value)) {
        throw new Error('현재 아내 프롬프트를 저장하지 못했습니다. 저장 공간을 확인해 주세요.');
      }
    }

    function normalizeOutfitPrompts(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).flatMap(([rawId, prompt]) => {
        const id = String(rawId || '').trim();
        if (!id || id.length > 120 || ['__proto__', 'prototype', 'constructor'].includes(id)
          || !prompt || typeof prompt !== 'object' || Array.isArray(prompt)
          || typeof prompt.positivePrompt !== 'string' || typeof prompt.negativePrompt !== 'string') return [];
        return [[id, { positivePrompt: prompt.positivePrompt, negativePrompt: prompt.negativePrompt,
          ...(typeof prompt.topPrompt === 'string' ? { topPrompt: prompt.topPrompt.slice(0, 8000) } : {}),
          ...(typeof prompt.skirtPrompt === 'string' ? { skirtPrompt: prompt.skirtPrompt.slice(0, 8000) } : {}) }]];
      }));
    }

    function currentOutfitPrompts() {
      const prompts = normalizeOutfitPrompts(api.settings.get({ outfitPrompts: {} }).outfitPrompts);
      for (const outfit of currentCustomOutfits()) delete prompts[outfit.id];
      return prompts;
    }

    const registeredCustomOutfits = new Map();

    function outfitPriceFromPrompt(prompt) {
      return Math.max(20, Math.min(9999, Math.ceil(String(prompt || '').trim().length / 10) * 5));
    }

    function normalizeCustomOutfits(value) {
      if (!Array.isArray(value)) return [];
      const outfits = new Map();
      for (const entry of value.slice(0, 100)) {
        if (!entry || typeof entry !== 'object' || Array.isArray(entry)) continue;
        const id = String(entry.id || '').trim();
        const name = String(entry.name || '').trim();
        const description = String(entry.description || '').trim();
        const positivePrompt = entry.positivePrompt;
        const negativePrompt = entry.negativePrompt;
        const topPrompt = entry.topPrompt ?? '';
        const skirtPrompt = entry.skirtPrompt ?? '';
        const wear = ['floor', 'sleep', 'bath'].includes(entry.wear) ? entry.wear : 'floor';
        const manualPrice = entry.manualPrice == null || entry.manualPrice === '' ? null : Number(entry.manualPrice);
        const boldnessScore = entry.boldnessScore == null ? 30 : Number(entry.boldnessScore);
        if (!/^aip-outfit-[a-z0-9-]{1,80}$/.test(id) || !name || name.length > 80
          || description.length > 300 || typeof positivePrompt !== 'string' || positivePrompt.length > 8000
          || typeof negativePrompt !== 'string' || negativePrompt.length > 8000
          || typeof topPrompt !== 'string' || topPrompt.length > 8000
          || typeof skirtPrompt !== 'string' || skirtPrompt.length > 8000
          || entry.boldnessScore === '' || !Number.isInteger(boldnessScore) || boldnessScore < 0 || boldnessScore > 100
          || (manualPrice !== null && (!Number.isInteger(manualPrice) || manualPrice < 1 || manualPrice > 9999))) continue;
        outfits.set(id, { id, name, description, positivePrompt, negativePrompt, topPrompt, skirtPrompt, wear, manualPrice, boldnessScore });
      }
      return [...outfits.values()];
    }

    function currentCustomOutfits() {
      return normalizeCustomOutfits(api.settings.get({ customOutfits: [] }).customOutfits);
    }

    function customOutfitFor(character, imageKey) {
      const id = outfitIdFor(character, imageKey);
      const outfit = currentCustomOutfits().find(entry => entry.id === id);
      return outfit ? effectiveExternalTarget('outfit', id, outfit) : outfit;
    }

    function customOutfitHalves(outfit) {
      if (!outfit.topPrompt && !outfit.skirtPrompt && api.game !== '2026-11-01') return undefined;
      const modest = ['fully covered', 'conservative', 'high collar', 'long sleeves', 'buttoned up', 'high neckline', 'thick fabric', 'modest neckline'];
      const top = ['blouse', 'shirt', 'bodice', 'corset', 'bra', 'cup', 'cups', 'chemise', 'smock', 'sundress', 'dress', 'robe', 'babydoll', 'negligee', 'nightgown', 'nightshift', 'nightie', 'tunic', 'wrap', 'shift', 'neckline', 'off-shoulder', 'off shoulder', 'collar', 'sleeve', 'sleeves', 'cleavage', 'bust', 'apron', 'strap', 'straps', 'ribbon', 'push-up', 'sweetheart', 'lacing', 'laced', 'unlaced', 'top ', 'through the fabric', 'nipples visible'];
      const skirt = ['skirt', 'dress', 'gown', 'garter', 'stocking', 'stockings', 'loincloth', 'hem', 'low-rise', 'underskirt', 'waistband', 'robe', 'babydoll', 'negligee', 'chemise', 'shift', 'smock', 'nightshift', 'nightgown', 'nightie', 'sundress', 'wrap', 'flared', 'pleated'];
      // shortcut: missing half prompts use the current games' keyword fallback; upgrade if their rules change.
      const fallback = removed => String(outfit.positivePrompt || '').split(',').map(tag => tag.trim()).filter(Boolean).filter(tag => {
        const text = tag.toLowerCase();
        return !modest.some(word => text.includes(word)) && !/panties|panty|underwear/.test(text)
          && (text.startsWith('bare ') || text.startsWith('exposed ') || !removed.some(word => text.includes(word)));
      }).join(', ');
      return { top: outfit.topPrompt || fallback(skirt), skirt: outfit.skirtPrompt || fallback(top) };
    }

    function syncCustomOutfitPlan(outfit) {
      const floor = api.has('imageFloorOutfits') ? api.fn('imageFloorOutfits') : null;
      const bath = api.has('imageBathOutfits') ? api.fn('imageBathOutfits') : null;
      const target = outfit.wear === 'bath' ? bath : floor;
      const other = outfit.wear === 'bath' ? floor : bath;
      if (!Array.isArray(target)) return;
      if (Array.isArray(other)) for (let index = other.length - 1; index >= 0; index -= 1) if (other[index] === outfit.id) other.splice(index, 1);
      if (!target.includes(outfit.id)) {
        const sentinel = target.indexOf(outfit.wear === 'bath' ? 'nude' : 'naked');
        target.splice(sentinel < 0 ? target.length : sentinel, 0, outfit.id);
      }
    }

    function syncCustomOutfits() {
      if (!Array.isArray(outfitList)) return false;
      for (const original of currentCustomOutfits()) {
        const outfit = effectiveExternalTarget('outfit', original.id, original);
        const matches = outfitList.filter(entry => entry?.id === outfit.id);
        const registered = registeredCustomOutfits.get(outfit.id);
        if (matches.some(entry => entry !== registered)) {
          console.warn('[attention-image-prompt] custom outfit id already registered', outfit.id);
          continue;
        }
        const definition = {
          id: outfit.id,
          name: outfit.name,
          description: outfit.description,
          price: original.manualPrice ?? outfitPriceFromPrompt(original.positivePrompt),
          imageTags: outfit.positivePrompt,
          negativeImageTags: outfit.negativePrompt,
          boldnessScore: outfit.boldnessScore,
          wear: outfit.wear,
          halves: customOutfitHalves(outfit),
        };
        if (matches.length) Object.assign(registered, definition);
        else {
          outfitList.push(definition);
          registeredCustomOutfits.set(outfit.id, definition);
        }
        syncCustomOutfitPlan(outfit);
      }
      return true;
    }

    function saveCustomOutfit(input) {
      if (!Array.isArray(outfitList)) throw new Error('게임 의상 목록을 찾지 못했습니다.');
      if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('의상 정보가 올바르지 않습니다.');
      const outfits = currentCustomOutfits();
      const requestedId = String(input.id || '').trim();
      const previous = outfits.find(entry => entry.id === requestedId);
      if (requestedId && !previous) throw new Error('수정할 사용자 의상을 찾지 못했습니다.');
      if (!previous && outfits.length >= 100) throw new Error('사용자 의상은 최대 100개까지 등록할 수 있습니다.');
      const name = String(input.name ?? previous?.name ?? '').trim();
      const description = String(input.description ?? previous?.description ?? '').trim();
      const positivePrompt = input.positivePrompt ?? previous?.positivePrompt ?? '';
      const negativePrompt = input.negativePrompt ?? previous?.negativePrompt ?? '';
      const topPrompt = input.topPrompt ?? previous?.topPrompt ?? '';
      const skirtPrompt = input.skirtPrompt ?? previous?.skirtPrompt ?? '';
      const wear = input.wear ?? previous?.wear ?? 'floor';
      const priceInput = Object.prototype.hasOwnProperty.call(input, 'manualPrice') ? input.manualPrice : previous?.manualPrice;
      const manualPrice = priceInput == null || priceInput === '' ? null : Number(priceInput);
      const boldnessInput = input.boldnessScore ?? previous?.boldnessScore ?? 30;
      const boldnessScore = boldnessInput === '' ? NaN : Number(boldnessInput);
      if (!name || name.length > 80 || description.length > 300
        || typeof positivePrompt !== 'string' || positivePrompt.length > 8000 || (!previous && !positivePrompt.trim())
        || typeof negativePrompt !== 'string' || negativePrompt.length > 8000
        || typeof topPrompt !== 'string' || topPrompt.length > 8000
        || typeof skirtPrompt !== 'string' || skirtPrompt.length > 8000 || !['floor', 'sleep', 'bath'].includes(wear)
        || !Number.isInteger(boldnessScore) || boldnessScore < 0 || boldnessScore > 100
        || (manualPrice !== null && (!Number.isInteger(manualPrice) || manualPrice < 1 || manualPrice > 9999)))
        throw new Error('이름(1~80자), 프롬프트(최대 8000자), 가격(1~9999골드), 노출도(0~100)를 확인해 주세요.');
      let id = requestedId;
      if (!id) {
        const prefix = `aip-outfit-${Date.now().toString(36)}`;
        id = prefix;
        for (let index = 2; outfitList.some(entry => entry?.id === id) || outfits.some(entry => entry.id === id); index += 1)
          id = `${prefix}-${index}`;
      } else if (outfitList.some(entry => entry?.id === id && entry !== registeredCustomOutfits.get(id))) {
        throw new Error('같은 ID의 다른 의상이 이미 등록되어 있습니다.');
      }
      const saved = { id, name, description, positivePrompt, negativePrompt, topPrompt, skirtPrompt, wear, manualPrice, boldnessScore };
      api.settings.set({ customOutfits: previous
        ? outfits.map(entry => entry.id === id ? saved : entry) : [...outfits, saved] });
      syncCustomOutfits();
      return saved;
    }

    function outfitPromptSources() {
      const definitions = [];
      if (Array.isArray(outfitList)) definitions.push(...outfitList);
      try {
        const addonOutfits = globalThis.__WAYWARD_ADDON_API__?.outfits;
        if (Array.isArray(addonOutfits)) definitions.push(...addonOutfits);
        const registered = globalThis.__waywardOutfits?.list?.();
        if (Array.isArray(registered)) definitions.push(...registered);
      } catch { /* an optional outfit bridge must not block the settings window */ }
      const currentOutfitId = String(currentWifePromptContext().character?.outfit || '').trim();
      const currentOutfit = currentOutfitId ? outfitById(currentOutfitId) : null;
      if (currentOutfit && !definitions.some(outfit => outfit?.id === currentOutfit.id)) definitions.push(currentOutfit);
      const unique = new Map();
      for (const outfit of definitions) {
        const id = String(outfit?.id || '').trim();
        if (!id) continue;
        unique.set(id, {
          id,
          name: String(outfit.name || id),
          description: String(outfit.description || ''),
          positivePrompt: String(outfit.imageTags || ''),
          negativePrompt: String(outfit.negativeImageTags || ''),
          topPrompt: String(outfit.halves?.top || ''),
          skirtPrompt: String(outfit.halves?.skirt || ''),
        });
      }
      return [...unique.values()].sort((left, right) => left.name.localeCompare(right.name, 'ko'));
    }

    function outfitPromptValues(source, prompts = currentOutfitPrompts()) {
      return { positivePrompt: source.positivePrompt, negativePrompt: source.negativePrompt,
        topPrompt: source.topPrompt, skirtPrompt: source.skirtPrompt, ...prompts[source.id] };
    }

    function saveOutfitPromptField(outfitId, field, value) {
      const source = outfitPromptSources().find(entry => entry.id === outfitId);
      if (!source || !['positivePrompt', 'negativePrompt', 'topPrompt', 'skirtPrompt'].includes(field)) return;
      const custom = currentCustomOutfits().find(entry => entry.id === outfitId);
      if (custom) {
        saveCustomOutfit({ ...custom, [field]: String(value ?? '') });
        return;
      }
      const prompts = currentOutfitPrompts();
      api.settings.set({
        outfitPrompts: {
          ...prompts,
          [outfitId]: { ...(prompts[outfitId] || { positivePrompt: source.positivePrompt, negativePrompt: source.negativePrompt }),
            [field]: String(value ?? '') },
        },
      });
    }

    function positionGroupCount(value) {
      return Math.max(0, Math.min(5, Number(String(value || '').match(/(?:^|__|\|)grp-(\d+)/)?.[1]) || 0));
    }

    function positionGroupSlots(value) {
      const count = positionGroupCount(value);
      const slots = String(value || '').match(/(?:^|__|\|)gslot-([mhbcfxriaw]+)/)?.[1] || '';
      return count && slots.length === count ? slots : '';
    }

    function normalizePositionPresetPrompts(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).flatMap(([presetId, prompt]) =>
        POSITION_PRESETS[presetId] && typeof prompt === 'string' ? [[presetId, prompt]] : []));
    }

    function currentPositionPresetPrompts() {
      return normalizePositionPresetPrompts(api.settings.get({ positionPresetPrompts: {} }).positionPresetPrompts);
    }

    function positionPresetById(presetId) {
      const preset = POSITION_PRESETS[presetId];
      if (!preset) return null;
      const prompts = currentPositionPresetPrompts();
      return Object.prototype.hasOwnProperty.call(prompts, presetId)
        ? { ...preset, prompt: [PREVIOUS_POSITION_PRESET_PROMPTS[presetId]].flat().includes(prompts[presetId]) ? preset.prompt : prompts[presetId] }
        : preset;
    }

    function normalizePositionGroupPrompts(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).flatMap(([slotId, prompt]) =>
        GROUP_SLOT_BY_ID[slotId] && typeof prompt === 'string' ? [[slotId, prompt]] : []));
    }

    function currentPositionGroupPrompts() {
      return normalizePositionGroupPrompts(api.settings.get({ positionGroupPrompts: {} }).positionGroupPrompts);
    }

    function positionGroupPromptById(slotId) {
      const option = GROUP_SLOT_BY_ID[slotId];
      if (!option) return '';
      const prompts = currentPositionGroupPrompts();
      const saved = prompts[slotId];
      if (slotId === 'b' && PREVIOUS_PAIZURI_GROUP_PROMPTS.includes(saved)) return option.prompt;
      return Object.prototype.hasOwnProperty.call(prompts, slotId) ? saved : option.prompt;
    }

    function normalizeFemalePositionDetail(value) {
      const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
      const selected = String(source.pose || '');
      const pose = FEMALE_POSE_MIGRATIONS[selected] || selected;
      return { pose: FEMALE_POSE_VALUES.has(pose) ? pose : '' };
    }

    function normalizePositionDetail(value) {
      const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
      return Object.fromEntries(POSITION_DETAIL_FIELDS.map(field => {
        const raw = String(source[field.id] || '');
        const selected = POSITION_DETAIL_MIGRATIONS[field.id]?.[raw] || raw;
        return [field.id, POSITION_DETAIL_VALUES[field.id].has(selected) ? selected : ''];
      }));
    }

    function positionDetailSignature(value) {
      const detail = normalizePositionDetail(value);
      return POSITION_DETAIL_FIELDS.map(field => detail[field.id]).join('~');
    }

    function normalizePositionDetails(value, groupCount = 0) {
      const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
      const extras = Array.isArray(source.extras) ? source.extras : [];
      const hasFemale = source.female && typeof source.female === 'object' && !Array.isArray(source.female);
      const legacyMain = source.main && typeof source.main === 'object' && !Array.isArray(source.main) ? source.main : {};
      return {
        female: normalizeFemalePositionDetail(hasFemale ? source.female : { pose: legacyMain.pose }),
        main: normalizePositionDetail(hasFemale ? source.main : { ...legacyMain, pose: '' }),
        extras: Array.from({ length: groupCount }, (_, index) => normalizePositionDetail(extras[index])),
      };
    }

    function positionDetailsSignature(value, groupCount = 0) {
      const details = normalizePositionDetails(value, groupCount);
      return [details.female.pose, positionDetailSignature(details.main), ...details.extras.map(positionDetailSignature)].join('|');
    }

    function hasPositionDetails(value, groupCount = 0) {
      return positionDetailsSignature(value, groupCount).replace(/[~|]/g, '').length > 0;
    }

    function compactPositionDetails(value, groupCount = 0) {
      const details = normalizePositionDetails(value, groupCount);
      return hasPositionDetails(details, groupCount) ? details : null;
    }

    function normalizeSavedPositionOverride(situationId, value) {
      if (typeof situationId !== 'string' || !situationId || situationId.length > 1000
        || !value || typeof value !== 'object' || Array.isArray(value)) return null;
      const savedKey = key => typeof value[key] === 'string' && value[key] && value[key].length <= 1000 ? value[key] : '';
      const sourceKey = savedKey('sourceKey');
      const stateKey = savedKey('stateKey');
      const imageKey = savedKey('imageKey');
      if (!sourceKey || !stateKey || !imageKey) return null;
      const generatedKeys = [...new Set([...(Array.isArray(value.generatedKeys) ? value.generatedKeys : []), imageKey]
        .filter(key => typeof key === 'string' && key && key.length <= 1000))].slice(-50);
      const count = positionGroupCount(situationId);
      const groupSlots = typeof value.groupSlots === 'string' && value.groupSlots.length === count
        && [...value.groupSlots].every(slot => GROUP_SLOT_BY_ID[slot]) ? value.groupSlots : '';
      const presetId = typeof value.presetId === 'string' && POSITION_PRESETS[value.presetId] ? value.presetId : '';
      const details = compactPositionDetails(value.details, count);
      const personPrompt = typeof value.personPrompt === 'string' && value.personPrompt.length <= 2000 ? value.personPrompt : null;
      const pendingPreviousKey = savedKey('pendingPreviousKey');
      const stateOnlySignature = typeof value.stateOnlySignature === 'string' && /^[a-z0-9]{1,20}$/.test(value.stateOnlySignature)
        ? value.stateOnlySignature : '';
      const moduleSignature = typeof value.moduleSignature === 'string' && /^[a-z0-9]{1,20}$/.test(value.moduleSignature)
        ? value.moduleSignature : '';
      const globalExclusionSignature = typeof value.globalExclusionSignature === 'string'
        && /^(?:[a-z0-9]{1,20})?$/.test(value.globalExclusionSignature) ? value.globalExclusionSignature : null;
      const cameraSignature = typeof value.cameraSignature === 'string'
        && /^(?:[a-z0-9]{1,20})?$/.test(value.cameraSignature) ? value.cameraSignature : null;
      return {
        presetId,
        groupSlots,
        ...(details ? { details } : {}),
        ...(personPrompt !== null ? { personPrompt } : {}),
        sourceKey,
        stateKey,
        imageKey,
        generatedKeys,
        ...(globalExclusionSignature !== null ? { globalExclusionSignature } : {}),
        ...(cameraSignature !== null ? { cameraSignature } : {}),
        ...(pendingPreviousKey ? { pendingPreviousKey } : {}),
        ...(stateOnlySignature ? { stateOnlySignature } : {}),
        ...(moduleSignature ? { moduleSignature } : {}),
        ...(value.manual === true ? { manual: true } : {}),
        ...(value.automatic === true ? { automatic: true } : {}),
      };
    }

    function currentPositionOverrides() {
      const saved = api.data.get()?.[positionMode() === 'modules' ? 'positionModuleOverrides' : 'positionOverrides'];
      if (!saved || typeof saved !== 'object' || Array.isArray(saved)) return {};
      return Object.fromEntries(Object.entries(saved).slice(-200).flatMap(([situationId, value]) => {
        const override = normalizeSavedPositionOverride(situationId, value);
        return override ? [[situationId, override]] : [];
      }));
    }

    function writePositionOverrides(overrides) {
      const key = positionMode() === 'modules' ? 'positionModuleOverrides' : 'positionOverrides';
      api.data.set(current => {
        const data = current && typeof current === 'object' && !Array.isArray(current) ? current : {};
        if (Object.keys(overrides).length) return { ...data, [key]: overrides };
        const next = { ...data };
        delete next[key];
        return next;
      });
    }

    function positionOverride(situationId) {
      return currentPositionOverrides()[situationId] || null;
    }

    function setPositionOverride(situationId, value) {
      const override = normalizeSavedPositionOverride(situationId, value);
      if (!override) return;
      writePositionOverrides(Object.fromEntries(Object.entries({ ...currentPositionOverrides(), [situationId]: override }).slice(-200)));
    }

    function deletePositionOverride(situationId) {
      const overrides = currentPositionOverrides();
      if (!Object.prototype.hasOwnProperty.call(overrides, situationId)) return;
      delete overrides[situationId];
      writePositionOverrides(overrides);
    }

    function clearPositionOverrides() {
      api.data.set(current => {
        const data = current && typeof current === 'object' && !Array.isArray(current) ? current : {};
        const { positionOverrides, positionModuleOverrides, ...rest } = data;
        return rest;
      });
    }

    function positionMode() {
      return api.settings.get({ positionMode: 'legacy' }).positionMode === 'modules' ? 'modules' : 'legacy';
    }

    function normalizePositionModules(value) {
      if (!Array.isArray(value)) return [];
      const seen = new Set();
      return value.slice(0, 50).flatMap(entry => {
        if (!entry || typeof entry !== 'object' || Array.isArray(entry)
          || typeof entry.id !== 'string' || !/^custom-[a-z0-9-]{1,60}$/.test(entry.id) || seen.has(entry.id)) return [];
        seen.add(entry.id);
        return [{
          id: entry.id,
          kind: ['pose', 'position', 'action', 'mood', 'other'].includes(entry.kind) ? entry.kind : 'other',
          name: typeof entry.name === 'string' ? entry.name.trim().slice(0, 80) : '',
          positivePrompt: typeof entry.positivePrompt === 'string' ? entry.positivePrompt.slice(0, 2000) : '',
          negativePrompt: typeof entry.negativePrompt === 'string' ? entry.negativePrompt.slice(0, 2000) : '',
        }];
      });
    }

    function currentPositionModules() {
      return normalizePositionModules(api.settings.get({ positionModules: [] }).positionModules);
    }

    function climaxModuleThreshold(module) {
      const match = /^(?:climax-([123])|custom-climax-([4-9]|[1-9]\d))$/.exec(module?.id || '');
      return match ? Number(match[1] || match[2]) : 0;
    }

    function danbooruModuleTags(value, allowSpaces = false) {
      const pattern = allowSpaces ? /^[a-z0-9][a-z0-9_+./' -]{0,79}$/ : /^[a-z0-9][a-z0-9_+./'-]{0,79}$/;
      return [...new Set(String(value || '').split(',').map(tag => tag.trim().toLowerCase())
        .filter(tag => pattern.test(tag)))].join(', ');
    }

    // shortcut: free-form custom tags need new category words when the provider adds unseen style or scene terms.
    const GUEST_NON_APPEARANCE_TAGS = [
      /(?:^|_)(?:anime|manga|comic|cartoon|illustration|drawing|painting|watercolor|sketch|lineart|shading|photorealistic|realistic|photo|photograph|cinematic|cgi|render|pixel_art|style|artstyle|masterpiece|quality|highres|hires|resolution|monochrome|greyscale|sepia|2d|3d)(?:_|$)/,
      /(?:^|_)(?:background|scenery|landscape|environment|interior|exterior|indoors|outdoors|lighting|candlelight|firelight|sunlight|moonlight|backlight|bokeh|depth_of_field|camera|lens|composition|framing|perspective|portrait|close_up|upper_body|full_body|cowboy_shot|wide_shot|film_grain|lens_flare)(?:_|$)/,
      /(?:^|_)(?:tavern|bedroom|kitchen|hallway|corridor|forest|city|castle|street|sky|sunset|room|studio|garden|beach|mountain|alley)(?:_(?:scene|setting|background|interior|exterior))?$/,
    ];
    function guestAppearanceTags(value) {
      return danbooruModuleTags(value).split(', ').filter(tag => tag
        && !GUEST_NON_APPEARANCE_TAGS.some(pattern => pattern.test(tag))).join(', ');
    }

    function normalizePositionDanbooruTags(value) {
      return Array.isArray(value) ? [...new Set(value.slice(0, 300).map(tag => danbooruModuleTags(tag, true))
        .filter(tag => tag && !tag.includes(',')))].slice(0, 300) : [];
    }

    function currentPositionDanbooruTags() {
      return normalizePositionDanbooruTags(api.settings.get({ positionDanbooruTags: [] }).positionDanbooruTags);
    }

    function normalizePositionModulePrompts(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).slice(-500).flatMap(([id, entry]) => {
        if (!/^(?:pose-\d+|action-\d+|climax-[123]|controller-[a-z0-9-]+)$/.test(id)
          || !entry || typeof entry !== 'object' || Array.isArray(entry)) return [];
        return [[id, {
          positivePrompt: typeof entry.positivePrompt === 'string' ? entry.positivePrompt.slice(0, 2000) : '',
          negativePrompt: typeof entry.negativePrompt === 'string' ? entry.negativePrompt.slice(0, 2000) : '',
        }]];
      }));
    }

    function currentPositionModulePrompts() {
      return normalizePositionModulePrompts(api.settings.get({ positionModulePrompts: {} }).positionModulePrompts);
    }

    function savePositionModulePrompt(id, field, value) {
      if (!['positivePrompt', 'negativePrompt'].includes(field) || typeof value !== 'string') return false;
      const prompt = value.slice(0, 2000);
      if (id.startsWith('custom-')) {
        const modules = currentPositionModules();
        if (!modules.some(module => module.id === id)) return false;
        api.settings.set({ positionModules: modules.map(module => module.id === id ? { ...module, [field]: prompt } : module) });
      } else {
        const module = availablePositionModules().find(entry => entry.id === id);
        if (!module) return false;
        api.settings.set({ positionModulePrompts: normalizePositionModulePrompts({
          ...currentPositionModulePrompts(), [id]: {
            positivePrompt: module.positivePrompt, negativePrompt: module.negativePrompt, [field]: prompt,
          },
        }) });
      }
      return true;
    }

    function normalizeControllerButtonCatalog(value) {
      if (!Array.isArray(value)) return [];
      const seen = new Set();
      return value.slice(0, 500).flatMap(entry => {
        if (!entry || typeof entry !== 'object' || typeof entry.key !== 'string'
          || entry.key.length > 220 || !/^(?:you|patron)\|/.test(entry.key) || seen.has(entry.key)) return [];
        seen.add(entry.key);
        return [{ id: `controller-${shortHash(entry.key)}`, key: entry.key,
          scope: entry.key.startsWith('you|') ? 'you' : 'patron',
          group: String(entry.group || '').slice(0, 80), label: String(entry.label || '').slice(0, 80) }];
      });
    }

    // patron-control 2026-10-25의 버튼 표. 제어판이 꺼져 있거나 접혀 있어도 편집할 수 있어야 한다.
    const CONTROLLER_POSE_ROWS = {
      patron: [['누워서', '정상위|측위|프레스(굴곡위)'], ['엎드려', '후배위|복와위'],
        ['그녀가 위', '기승위|역기승위'], ['선 채로', '입위|벽에 기대서|벽에 밀쳐서|벽에서 한발만 들림|들려서|발이 땅에 닿지 않게'],
        ['입·손·가슴', '무릎 구강성교|69|여성 손 자극|파이즈리|앉아서 남성 손 자극|커닐링구스']],
      you: [['앞·뒤', '정상위|후배위|측위|프레스(굴곡위)|복와위'],
        ['누워서', '정상위|후배위|측위|프레스(굴곡위)|복와위|목조르기 섹스|손목 눌러 붙잡고|교배 프레스|머리채 후배위|짓눌린 복와위|다리 들어 올린 측위|누워서 맞이한다|엎드려 엉덩이를 내민다|옆으로 누워 등을 붙인다|다리를 높이 들어 올린다|배를 깔고 엎드린다'],
        ['위', '기승위|역기승위|밑에서 쳐올리기|끌어내리기|위에 올라탄다|등을 돌려 올라탄다'],
        ['선 채로', '입위|벽에 기대서|벽에 밀쳐서|벽에서 한발만 들림|들려서|발이 땅에 닿지 않게'],
        ['입·가슴', '무릎 구강성교|69|파이즈리|이라마치오|가슴 움켜쥐고|머리 눌러 깊이|무릎 꿇고 입으로|거꾸로 엎드려 입으로|가슴으로 감싼다']],
    };
    const CONTROLLER_CARESS_ROWS = [['기본', '키스|가슴 주무르기|젖꼭지 빨기|목덜미·귀|클리|엉덩이 쥐기|머리채'],
      ['거칠게', '엉덩이 때리기|젖꼭지 비틀기|목덜미 깨물기'],
      ['입·손가락', '혀 얽기|손가락 빨리기|애널 손가락'],
      ['시키기', '목 끌어안게|다리로 허리 감게|그의 젖꼭지 핥게']];
    const CONTROLLER_STAGE_LABELS = '대화|추파|가벼운 접촉|대담한 접촉|더듬기|깊은 애무|손으로 애무받기|입으로 애무받기|몸 비비기|성관계'.split('|');
    const CONTROLLER_BUTTON_ROWS = [
      ['patron', '기타', '뒷방 막기|자율 행동|요청|강행|디버그|상호작용 시작|받아들이기|거절하기'],
      ['patron', '속도', '계속|빠르게|천천히|음란한 말|거칠게'],
      ['patron', '사정 위치', '항문 안에|질 안에|입 안에|빼서 밖에|밖에|얼굴에|입에|가슴에|게임대로'],
      ['patron', '삽입', '삽입 준비|앞으로|뒤로|자지 빼내기|기회 삽입'],
      ['patron', '옷', '벗기기|완전 탈의'],
      ['patron', '폭력성', '뺨|가슴|엉덩이|음부|배|머리채|목'],
      ['patron', '행위', [...CONTROLLER_STAGE_LABELS, ...CONTROLLER_STAGE_LABELS.map(label => `${label} ⤴`),
        '그녀를 입으로 애무하기', '그녀 앞에서 자기 몸 만지기', '항문 시도', '현 단계 유지', '구멍 위치 바꾸기'].join('|')],
      ['patron', '장면 이벤트', '칭찬하기|두둑한 팁 주기|무례한 말 하기|술 한잔 권하기|지난 방문 이야기하기|그녀에게 추파 던지기|그녀에게 다가가기|취해서 손대기|돈을 걸고 제안하기|다른 손님에게 자랑하기'],
      ['patron', '협박하기', '신체|남편|가게|아무거나|본보기 보이기|취소'],
      ['patron', '굴복도', '따름|망설임|반항|원래대로'],
      ['patron', '실랑이', '그녀가 이김|팽팽함|그가 이김|원래대로'],
      ['patron', '제압 길', '완력|꾀|원래대로'],
      ['patron', '꾀의 수', '가슴: 뒤집기|가슴: 발목 들어 올리기|가슴: 다리 걸기|가슴: 헛손질|가슴: 뒤에서 감싸 안기|가슴: 블라우스 묶기|다리: 뒤집기|다리: 발목 들어 올리기|다리: 다리 걸기|다리: 헛손질|다리: 뒤에서 감싸 안기|다리: 블라우스 묶기|원래대로'],
      ['patron', '가림 흐름 · 그의 숨', '가슴 가림 흐름|다리 가림 흐름|터지는 말'],
      ['patron', '가림 · 굴복도', '가림 강제 모두 풀기'],
      ['patron', '비명 단계', '반항|버팀|굴복|원래대로|상한 새로'],
      ['patron', '부위 (정도 2)', '뺨|가슴|엉덩이|음부|배|이 장면 손찌검 → 흔적'],
      ['patron', '고백 · 막는다', '표시한 손님 지금 들이기|묵인 선택지 지금|이 손님에 「막는다」 표시|대응 지금 (이 손님)'],
      ['patron', '힘으로 쫓아내기 결과', '주사위|이김|짐'],
      ['patron', '나쁜 손님', '뒷방으로 속이기|수갑 풀기|수갑 채우기|뒷방 문 열기|뒷방 문 잠그기|미약 없애기|미약 타기'],
      ['patron', '자리', '손|가슴|뒤에 붙음|입|몸 비비기|앞 (질)|뒤 (항문)|그녀가 위 (앞)'],
      ['you', '속도', '계속하기|속도 높이기|속도 늦추기|음란한 말 하기|아무것도 안 하기|거친 성관계|애태우기'],
      ['you', '사정 위치', '엉덩이 안에|안에|입 안에|얼굴에|빼서 몸에|손에|가슴에|그대로|게임대로'],
      ['you', '그녀의 바람', '항문|애널'],
      ['you', '행위', '성관계|거친 성관계|항문|애널|기승위|선 채로|입|펠라치오|깊게 입|이라마치오|손|파이즈리|허벅지|허벅지 사이|몸 비비기|비비기|무릎 위|손가락|손가락 애무|뒤 손가락|서로 애무|가슴 애무|커닐링구스|얼굴 위|얼굴 위에|69|자지 빼내기|키스|벗기기'],
      ['you', '삽입', '삽입 준비|뒤로 삽입 준비|입구에 맞댐|입구에 맞댐 (뒤)|삽입 준비 풀기|넣은 채|빼기'],
      ['you', '삽입 위치', '앞 (보지)|뒤 (애널)'],
      ['you', '벗기기', '비껴 내기|모두 벗기기|속옷 벗기기|상의 끈 풀기|상의 내리기|상의 벗기기|치마 걷어 올리기|치마 벗기기|속옷 비껴 내기'],
      ['you', '옷', '스스로 속옷을 비껴 낸다'],
      ['you', '움직임', '허리를 움직인다|입과 손으로 해 준다|몸을 비빈다|더 빠르게|천천히'],
      ['you', '해 달라고', '안에|입 안에|얼굴에|밖에'],
      ['you', '그 밖', '게임대로|자지 빼내기|키스|벗기기'],
    ];
    const CONTROLLER_SEED_CATALOG = normalizeControllerButtonCatalog([
      ...CONTROLLER_BUTTON_ROWS, ...Object.entries(CONTROLLER_POSE_ROWS).flatMap(([scope, rows]) => rows.map(([group, labels]) => [scope, group, labels])),
      ...['patron', 'you'].flatMap(scope => CONTROLLER_CARESS_ROWS.map(([group, labels]) => [scope, group, labels])),
      ...['patron', 'you'].flatMap(scope => [
        [scope, '옷 상태', '상의 끈 풀림|가슴 드러남|치마 걷힘|속옷 젖혀짐|상의 벗음|치마 벗음|속옷 벗음|완전 나체'],
        ...['오른손', '왼손'].map(group => [scope, group, '가슴|젖꼭지|클리|엉덩이|머리채|손목|허리|다리|옷 위|속옷 위|떼기']),
      ]),
      ['you', '기본', '옷 위로 만지기|속옷 위로 문지르기|팬티 위로 핥기'],
      ['you', '입·손가락', '손가락 넣기'],
      ['you', '선 채로', '선 채로 몰아붙이기|벽에 짓눌러서|벽에 처박듯이|한 다리 걸쳐 들고 거칠게|들어 올린 채 거칠게|마주 서서 안긴다|벽에 등을 기댄다|벽을 짚고 선다|한쪽 다리를 허리에 감는다|목에 매달린다|온몸을 맡기고 안긴다'],
      ...['가슴', '다리'].map((part, index) => ['patron', `${part} 가림`,
        `${(index ? '열림|힘이 빠져 벌어짐|허벅지를 붙임|무릎을 꼭 모음' : '내보임|손이 자꾸 올라옴|한 손으로 가림|두 팔로 감쌈')
          .split('|').map((label, level) => `${level} ${label}`).join('|')}|풀기`]),
    ].flatMap(([scope, group, labels]) => labels.split('|').map(label => ({
      key: `${scope}|${group}|${label}`, group, label,
    }))));
    const CONTROLLER_POSE_GROUPS = new Set(Object.values(CONTROLLER_POSE_ROWS).flatMap(rows => rows.map(([group]) => group)));
    function controllerScopesForSituation(situationId, characterId) {
      const state = api.store.game();
      if (!state) return ['patron', 'you'];
      const active = [state.activeScene?.patron && 'patron', state.activeScene?.sex && 'you'].filter(Boolean);
      if (!situationId) return active.length ? active : ['patron', 'you'];
      if (characterId !== state.primaryCharacterId || !basePositionSituationId(situationId).startsWith('scene-')) return [];
      const patron = Boolean(state.activeScene?.patron);
      const you = Boolean(state.activeScene?.sex);
      if (patron && you) return active;
      if (patron && basePositionSituationId(situationId).startsWith('scene-patron_')) return ['patron'];
      if (you && !basePositionSituationId(situationId).startsWith('scene-patron_')) return ['you'];
      return [];
    }
    function multiplePatronActions(situationId) {
      const scene = api.store.game()?.activeScene?.patron;
      return positionGroupCount(situationId) > 0 || Boolean(scene?.joinedPatronIds?.length || scene?.crowdPatronIds?.length);
    }
    function currentControllerButtonCatalog() {
      const saved = normalizeControllerButtonCatalog(api.settings.get({ controllerButtonCatalog: [] }).controllerButtonCatalog);
      const builtIn = new Set(CONTROLLER_SEED_CATALOG.map(entry => entry.key));
      return normalizeControllerButtonCatalog([...CONTROLLER_SEED_CATALOG, ...saved.filter(entry => !builtIn.has(entry.key))]);
    }

    function controllerButtonDescriptor(button) {
      const panel = button?.closest?.('.wpc-ctl, .wpc-dock, .hlc-dock');
      if (!panel || panel.hidden || panel.closest?.('[hidden]')) return null;
      const state = api.store.game();
      const scope = button.classList?.contains('hlc-chip') || state?.activeScene?.sex ? 'you'
        : state?.activeScene?.patron ? 'patron' : '';
      if (!scope) return null;
      const label = String(button.textContent || '').trim().replace(/(?:\s*[○△✕♥🔓↻✓×])+$/u, '')
        .replace(/^넣기\s*·\s*/u, '').replace(/\s*·\s*부탁$/u, '')
        .replace(/\s*✓\s*(?=\(뒤\)$)/u, ' ')
        .replace(/\s*\((?:기\s*\d+|\d+|손|입)\)$/u, '').slice(0, 80);
      if (!label) return null;
      const row = button.closest?.('.wpc-ctl-row, .hlc-row');
      const rowTitle = row?.querySelector?.(':scope > .wpc-ctl-sub, :scope > .hlc-sub')?.textContent;
      const foldTitle = button.closest?.('.wpc-ctl-grid')?.previousElementSibling?.textContent
        || button.closest?.('.wpc-ctl-stack')?.previousElementSibling?.textContent
        || button.closest?.('.hlc-fold')?.querySelector?.(':scope > summary')?.textContent || '';
      const knownFold = ['가림 · 굴복도', '손찌검 · 비명', '고백 · 막는다', '장면 이벤트', '협박하기', '나쁜 손님', '행위', '자리']
        .find(title => foldTitle.startsWith(`▾ ${title}`) || foldTitle.startsWith(`▸ ${title}`));
      const group = String(rowTitle || knownFold || (foldTitle.startsWith('행위') ? '행위' : '기타'))
        .trim().replace(/\s*·\s*임박$/u, '').slice(0, 80);
      const key = `${scope}|${group}|${label}`;
      const target = panel.querySelector?.('.wpc-select')?.value;
      const actorId = scope === 'patron' ? target && target !== 'main' ? target
        : state?.activeScene?.patron?.customerId : state?.primaryCharacterId;
      return { id: `controller-${shortHash(key)}`, key, scope, group, label, actorId };
    }

    function visibleControllerButtons() {
      if (typeof document?.querySelectorAll !== 'function') return [];
      return [...document.querySelectorAll('button.wpc-ctl-cmd, button.hlc-chip')].flatMap(button => {
        const module = controllerButtonDescriptor(button);
        return module ? [{ ...module, active: button.classList?.contains('wpc-active') === true
          || button.classList?.contains('on') === true }] : [];
      });
    }

    function discoverControllerButtons(buttons = visibleControllerButtons()) {
      const catalog = currentControllerButtonCatalog();
      const saved = normalizeControllerButtonCatalog(api.settings.get({ controllerButtonCatalog: [] }).controllerButtonCatalog);
      const known = new Set(catalog.map(entry => entry.key));
      const added = buttons.filter(entry => !known.has(entry.key));
      if (!added.length) return catalog;
      for (const entry of added) known.add(entry.key);
      const next = normalizeControllerButtonCatalog([...saved, ...added]);
      api.settings.set({ controllerButtonCatalog: next });
      return currentControllerButtonCatalog();
    }

    let exploringControllerFolds = false;
    let controllerFoldSnapshot = null;
    function discoverFoldedControllerButtons() {
      if (exploringControllerFolds || typeof document?.querySelectorAll !== 'function') return currentControllerButtonCatalog();
      const state = api.store.game();
      const sceneRef = state?.activeScene?.patron || state?.activeScene?.sex;
      let pose = '';
      try { pose = globalThis.__waywardActExpansion?.pose?.now?.()?.pose || ''; } catch {}
      const token = `${state?.slot}|${state?.activeScene?.patron?.customerId || ''}|${state?.activeScene?.patron?.stage || ''}|${state?.activeScene?.sex?.type || ''}|${pose}`;
      const panels = [...document.querySelectorAll('.wpc-ctl, .wpc-dock, .hlc-dock')];
      if (!panels.length) { controllerFoldSnapshot = null; return currentControllerButtonCatalog(); }
      if (controllerFoldSnapshot?.token === token && controllerFoldSnapshot.sceneRef === sceneRef
        && controllerFoldSnapshot.panelCount === panels.length) return currentControllerButtonCatalog();
      exploringControllerFolds = true;
      try {
        const buttons = visibleControllerButtons();
        for (const panel of panels) {
          if (panel.hidden || panel.closest?.('[hidden]')) continue;
          const folds = [...panel.querySelectorAll('button.wpc-ctl-fold')];
          for (let index = 0; index < folds.length; index += 1) {
            const fold = panel.querySelectorAll('button.wpc-ctl-fold')[index];
            if (!fold?.textContent?.startsWith('▸')) continue;
            fold.click();
            buttons.push(...visibleControllerButtons());
            const opened = panel.querySelectorAll('button.wpc-ctl-fold')[index];
            if (opened?.textContent?.startsWith('▾')) opened.click();
          }
          for (const fold of panel.querySelectorAll('details.hlc-fold')) {
            if (fold.open) continue;
            fold.open = true;
            buttons.push(...visibleControllerButtons());
            fold.open = false;
          }
        }
        const catalog = discoverControllerButtons(buttons);
        controllerFoldSnapshot = { token, sceneRef, panelCount: panels.length,
          activeIds: new Set(buttons.filter(button => button.active).map(button => button.id)) };
        return catalog;
      } finally {
        exploringControllerFolds = false;
      }
    }

    const NECK_GRAB_PROMPT = "neck_grab, (man's hand gripping the woman's neck:1.4), (hand_on_another's_neck:1.3)";
    const CONTROLLER_POSE_MODULE_TAGS = Object.freeze({
        '정상위': COUPLE_POSITION_TAGS.missionary, '측위': COUPLE_POSITION_TAGS.spooning,
        '프레스(굴곡위)': COUPLE_POSITION_TAGS.press,
        '후배위': COUPLE_POSITION_TAGS.doggystyle, '복와위': 'hetero, prone_bone', '기승위': 'hetero, cowgirl_position, girl_on_top',
        '역기승위': 'hetero, reverse_cowgirl_position, girl_on_top', '입위': 'hetero, standing_sex',
        '벽에 기대서': 'against_wall, leaning_forward', '벽에 밀쳐서': 'against_wall',
        '벽에서 한발만 들림': 'against_wall, leg_up', '들려서': 'suspended_congress',
        '발이 땅에 닿지 않게': 'suspended_congress', '무릎 구강성교': `kneeling, ${MODULE_ACT_TAGS.womanOralMan}`,
        '69': MODULE_ACT_TAGS.mutualOral, '여성 손 자극': MODULE_ACT_TAGS.manFingerWoman, '파이즈리': MODULE_ACT_TAGS.womanPaizuriMan,
        '앉아서 남성 손 자극': `sitting, ${MODULE_ACT_TAGS.womanHandjobMan}`, '커닐링구스': MODULE_ACT_TAGS.manOralWoman,
        '목조르기 섹스': `${COUPLE_POSITION_TAGS.missionary}, rough_sex, ${NECK_GRAB_PROMPT}`,
        '손목 눌러 붙잡고': `${COUPLE_POSITION_TAGS.missionary}, holding_another's_wrist`,
        '교배 프레스': `${COUPLE_POSITION_TAGS.press}, rough_sex`, '머리채 후배위': `${COUPLE_POSITION_TAGS.doggystyle}, rough_sex`,
        '짓눌린 복와위': 'prone_bone, rough_sex', '다리 들어 올린 측위': `${COUPLE_POSITION_TAGS.spooning}, legs_up`,
        '밑에서 쳐올리기': 'hetero, cowgirl_position, girl_on_top, rough_sex',
        '끌어내리기': 'hetero, reverse_cowgirl_position, girl_on_top, rough_sex',
        '선 채로 몰아붙이기': 'standing_sex, rough_sex', '벽에 짓눌러서': 'against_wall, rough_sex',
        '벽에 처박듯이': 'against_wall, rough_sex', '한 다리 걸쳐 들고 거칠게': 'against_wall, leg_up, rough_sex',
        '들어 올린 채 거칠게': 'suspended_congress, rough_sex', '이라마치오': MODULE_ACT_TAGS.manIrrumatioWoman,
        '가슴 움켜쥐고': `${MODULE_ACT_TAGS.womanPaizuriMan}, grabbing_another's_breast`,
        '머리 눌러 깊이': `${MODULE_ACT_TAGS.manIrrumatioWoman}, 69`,
        '누워서 맞이한다': 'on_back, lying', '엎드려 엉덩이를 내민다': COUPLE_POSITION_TAGS.doggystyle,
        '옆으로 누워 등을 붙인다': COUPLE_POSITION_TAGS.spooning, '다리를 높이 들어 올린다': 'on_back, legs_up',
        '배를 깔고 엎드린다': 'hetero, prone_bone',
        '위에 올라탄다': 'hetero, cowgirl_position, girl_on_top',
        '등을 돌려 올라탄다': 'hetero, reverse_cowgirl_position, girl_on_top',
        '마주 서서 안긴다': 'hetero, standing_sex',
        '벽에 등을 기댄다': 'against_wall', '벽을 짚고 선다': 'against_wall',
        '한쪽 다리를 허리에 감는다': 'against_wall, leg_up', '목에 매달린다': 'suspended_congress',
        '온몸을 맡기고 안긴다': 'suspended_congress', '무릎 꿇고 입으로': `kneeling, ${MODULE_ACT_TAGS.womanOralMan}`,
        '거꾸로 엎드려 입으로': MODULE_ACT_TAGS.mutualOral, '가슴으로 감싼다': MODULE_ACT_TAGS.womanPaizuriMan,
    });
    const PREVIOUS_CONTROLLER_POSE_TAGS = Object.freeze({
      '정상위': 'hetero, missionary, boy_on_top',
      '후배위': 'hetero, doggystyle',
      '머리채 후배위': 'doggystyle, rough_sex',
      '엎드려 엉덩이를 내민다': 'hetero, doggystyle',
      '측위': ['hetero, on_side', 'hetero, spooning, on_side, lying'],
      '프레스(굴곡위)': 'hetero, mating_press, boy_on_top',
      '목조르기 섹스': ['hetero, missionary, boy_on_top, rough_sex, neck_grab',
        `${COUPLE_POSITION_TAGS.missionary}, rough_sex, neck_grab`],
      '손목 눌러 붙잡고': "hetero, missionary, boy_on_top, holding_another's_wrist",
      '교배 프레스': 'mating_press, rough_sex',
      '다리 들어 올린 측위': ['on_side, legs_up', 'hetero, spooning, on_side, lying, legs_up'],
      '누워서 맞이한다': 'hetero, missionary, boy_on_top',
      '옆으로 누워 등을 붙인다': ['on_side', 'hetero, spooning, on_side, lying'],
      '다리를 높이 들어 올린다': 'mating_press',
    });

    const OVER_CLOTHES_TOUCH_PROMPT = "hetero, groping, (man's hand touching woman's breast through her clothes:1.25), covered_breasts";
    const CONTROLLER_ACTION_MODULE_TAGS = Object.freeze({
      '대화': 'talking', '추파': 'blush', '가벼운 접촉': "hetero, hand_on_another's_arm",
      '대담한 접촉': MODULE_ACT_TAGS.manFondleWoman,
      '더듬기': MODULE_ACT_TAGS.manFondleWoman, '깊은 애무': MODULE_ACT_TAGS.manFondleWoman,
      '손으로 애무받기': MODULE_ACT_TAGS.womanHandjobMan,
      '입으로 애무받기': MODULE_ACT_TAGS.womanOralMan,
      '몸 비비기': MODULE_ACT_TAGS.mutualRubbing, '성관계': MODULE_ACT_TAGS.manVaginalWoman,
      '그녀를 입으로 애무하기': MODULE_ACT_TAGS.manOralWoman,
      '그녀 앞에서 자기 몸 만지기': 'male_masturbation',
      '항문 시도': 'hetero, imminent_anal, penis_on_ass',
      '거친 성관계': `${MODULE_ACT_TAGS.manVaginalWoman}, rough_sex`,
      '항문': MODULE_ACT_TAGS.manAnalWoman, '애널': MODULE_ACT_TAGS.manAnalWoman,
      '기승위': `${MODULE_ACT_TAGS.manVaginalWoman}, cowgirl_position, girl_on_top`,
      '선 채로': `${MODULE_ACT_TAGS.manVaginalWoman}, standing_sex`,
      '입': MODULE_ACT_TAGS.womanOralMan, '펠라치오': MODULE_ACT_TAGS.womanOralMan,
      '깊게 입': MODULE_ACT_TAGS.manIrrumatioWoman,
      '이라마치오': MODULE_ACT_TAGS.manIrrumatioWoman,
      '손': MODULE_ACT_TAGS.womanHandjobMan, '파이즈리': MODULE_ACT_TAGS.womanPaizuriMan,
      '허벅지': 'hetero, thigh_sex', '허벅지 사이': 'hetero, thigh_sex',
      '무릎 위': 'hetero, sitting_on_lap', '손가락': MODULE_ACT_TAGS.manFingerWoman,
      '뒤 손가락': MODULE_ACT_TAGS.manAnalFingerWoman, '서로 애무': 'hetero, mutual_masturbation',
      '가슴 애무': MODULE_ACT_TAGS.manFondleWoman,
      '커닐링구스': MODULE_ACT_TAGS.manOralWoman,
       '얼굴 위': `sitting_on_face, girl_on_top, ${MODULE_ACT_TAGS.manOralWoman}`,
       '얼굴 위에': `sitting_on_face, girl_on_top, ${MODULE_ACT_TAGS.manOralWoman}`,
      '비비기': MODULE_ACT_TAGS.mutualRubbing,
      '손가락 애무': MODULE_ACT_TAGS.manFingerWoman,
      '69': MODULE_ACT_TAGS.mutualOral, '키스': MODULE_ACT_TAGS.mutualKiss,
      '벗기기': 'hetero, undressing',
    });
    const PREVIOUS_PENETRATION_MODULE_TAGS = Object.freeze({
      'hetero, vaginal': MODULE_ACT_TAGS.manVaginalWoman,
      'hetero, anal': MODULE_ACT_TAGS.manAnalWoman,
      "hetero, fingering, hand_on_another's_crotch, clitoral_stimulation": MODULE_ACT_TAGS.manFingerWoman,
      "hetero, groping, grabbing_another's_breast": OVER_CLOTHES_TOUCH_PROMPT,
      'hetero, cowgirl_position, girl_on_top': CONTROLLER_ACTION_MODULE_TAGS['기승위'],
      'hetero, standing_sex': CONTROLLER_ACTION_MODULE_TAGS['선 채로'],
    });
    const CONTROLLER_CARESS_MODULE_TAGS = Object.freeze({
      '키스': MODULE_ACT_TAGS.mutualKiss,
      '가슴 주무르기': MODULE_ACT_TAGS.manFondleWoman,
      '젖꼭지 빨기': 'hetero, breast_sucking, face_to_breasts',
      '목덜미·귀': 'hetero, kissing_neck, kissing_ear',
      '클리': "hetero, hand_on_another's_crotch, clitoral_stimulation, clitoris, clitoris_tweak",
      '엉덩이 쥐기': "hetero, grabbing_another's_ass",
      '머리채': "hetero, grabbing_another's_hair",
      '엉덩이 때리기': 'hetero, spanking', '젖꼭지 비틀기': 'hetero, nipple_tweak',
      '목덜미 깨물기': 'hetero, biting_neck', '혀 얽기': 'hetero, kiss, french_kiss',
      '손가락 빨리기': "hetero, finger_sucking, finger_in_another's_mouth",
      '애널 손가락': MODULE_ACT_TAGS.manAnalFingerWoman, '목 끌어안게': 'hetero, hug',
       '다리로 허리 감게': 'hetero, leg_lock', '그의 젖꼭지 핥게': 'hetero, licking_nipple, sucking_male_nipple',
       '옷 위로 만지기': OVER_CLOTHES_TOUCH_PROMPT,
      '속옷 위로 문지르기': MODULE_ACT_TAGS.mutualRubbing,
      '팬티 위로 핥기': 'hetero, licking_panties, panties',
      '손가락 넣기': MODULE_ACT_TAGS.manFingerWoman,
    });
    const CONTROLLER_CONTACT_PROMPTS = Object.freeze({
      front: { positivePrompt: 'hetero, erection, penis, pussy, imminent_vaginal, penis_on_pussy',
        negativePrompt: 'solo, disembodied_penis' },
      back: { positivePrompt: 'hetero, erection, penis, anus, imminent_anal, penis_on_ass',
        negativePrompt: 'solo, disembodied_penis' },
    });
    function activeContactType(state, scope) {
      if (scope === 'patron') {
        const patron = state?.activeScene?.patron;
        if (patron?.stage !== 'rubbing_patron' || !patron.__actPrep) return null;
        return /anal|back/.test(String(patron.__actPrep.into || patron.__actPrep.slot || patron.__actPrep.hole || ''))
          ? 'back' : 'front';
      }
      if (scope === 'you') {
        const sex = state?.activeScene?.sex;
        const prep = String(sex?.__hs?.her?.prep || '');
        if (sex?.finish || !prep.startsWith('ready:')) return null;
        return prep.slice(6) === 'anal' ? 'back'
          : ['sex', 'vaginal'].includes(prep.slice(6)) ? 'front' : null;
      }
      return null;
    }
    function controllerContactType(entry) {
      if (entry.group !== '삽입') return null;
      const label = entry.label.replace(/ ⤴$/u, '');
      if (label === '삽입 준비') return activeContactType(api.store.game(), entry.scope) || 'front';
      if (label === '뒤로 삽입 준비' || label === '입구에 맞댐 (뒤)') return 'back';
      return label === '입구에 맞댐' ? 'front' : null;
    }
    function controllerButtonKind(entry) {
      if (entry.group === '체위' || CONTROLLER_POSE_GROUPS.has(entry.group)) return 'position';
      if (entry.group === '행위' || entry.group === '그녀의 바람' || controllerContactType(entry)) return 'action';
      return 'other';
    }
    function positionModuleDirection(module) {
      if (climaxModuleThreshold(module)) return '절정 대상: 아내';
      if (module.kind === 'pose') return '아내 자세';
      if (module.id.startsWith('custom-')) return '대상·가하는 사람: 태그로 직접 지정';
      const activeScene = api.store.game()?.activeScene;
      const actor = module.controllerScope === 'patron' ? '손님'
        : module.controllerScope === 'you' ? '당신'
          : activeScene?.patron && !activeScene?.sex ? '손님'
            : activeScene?.sex && !activeScene?.patron ? '당신' : '상대 남성';
      if (/^action-\d+$/.test(module.id)) {
        const action = Number(module.id.slice(7));
        return [0, 10, 12].includes(action) ? `아내 ↔ ${actor}`
          : [4, 6, 7].includes(action) ? `아내 → ${actor}` : `${actor} → 아내`;
      }
      const label = module.controllerLabel || module.name;
      const group = module.controllerGroup;
      if (group === '그녀의 바람') return '아내의 바람 · 현재 행위 아님';
      if (['옷 상태', '가슴 가림', '다리 가림', '굴복도', '실랑이', '비명 단계'].includes(group)) return '상태 대상: 아내';
      if (module.kind === 'position' || group === '자리' && /그녀가 위|무릎 위/.test(label)
        || group === '행위' && /기승위|무릎 위|선 채로/.test(label)) return /기승위|그녀가 위|남성 위에|올라탄다|쳐올리기|무릎 위/.test(label)
        ? `아내 위 · ${actor} 아래` : `아내 + ${actor} · 체위`;
      if (!module.controllerScope && module.kind !== 'action') return '대상·가하는 사람: 태그로 직접 지정';
      if (/스스로/.test(label)) return '아내 → 자신';
      if (/자기 몸 만지기/.test(label)) return `${actor} → 자신`;
      if (group === '삽입 위치') return `${actor} → 아내 · 부위 선택`;
      if (group === '자리' && /앞 \(질\)|뒤 \(항문\)/.test(label)) return `${actor} → 아내 · 삽입 전`;
      if (group === '오른손' || group === '왼손') return `${actor} → 아내 · 손 위치`;
      if (module.kind === 'action' && /\b69\b/.test(module.positivePrompt)) return `아내 ↔ ${actor}`;
      if (/\birrumatio\b/.test(module.positivePrompt) || /이라마치오|깊게 입/.test(label)) return `${actor} → 아내`;
      if (/손으로 애무받기|입으로 애무받기|펠라치오|파이즈리|남성 손 자극|가슴으로 감싼다|그의 젖꼭지|손가락 빨리기|목 끌어안게|다리로 허리 감게/.test(label)
        || /\b(?:fellatio|handjob|paizuri|sucking_male_nipple)\b/.test(module.positivePrompt)) return `아내 → ${actor}`;
      if (/키스|혀 얽기|69|비비기|서로 애무|성기 마찰/.test(label)
        || /\b(?:69|mutual_masturbation|frottage)\b/.test(module.positivePrompt)) return `아내 ↔ ${actor}`;
      if (group === '사정 위치' || group === '해 달라고') return `${actor} → 아내 · 사정 목표`;
      if (group === '삽입' && /준비|맞댐|기회/.test(label)) return `${actor} → 아내 · 삽입 전`;
      if (module.kind === 'action' || module.positivePrompt) return `${actor} → 아내`;
      return '시각 태그 없음';
    }
    function controllerButtonDefaultTags(entry) {
      const { group } = entry;
      const label = entry.label.replace(/ ⤴$/u, '');
      if (controllerButtonKind(entry) === 'position') return CONTROLLER_POSE_MODULE_TAGS[label] || '';
      const contact = controllerContactType(entry);
      if (contact) return CONTROLLER_CONTACT_PROMPTS[contact].positivePrompt;
      if (group === '그녀의 바람') return '';
      if (group === '행위') return CONTROLLER_ACTION_MODULE_TAGS[label] || '';
      if (['기본', '거칠게', '입·손가락', '시키기'].includes(group)) return CONTROLLER_CARESS_MODULE_TAGS[label] || '';
      if (group === '옷 상태') return label === '완전 나체' ? 'nude'
        : label === '가슴 드러남' ? 'breasts_out, partially_undressed'
          : label === '속옷 젖혀짐' ? 'partially_undressed, panties_aside'
            : label === '치마 걷힘' ? 'partially_undressed, skirt_lift' : 'partially_undressed';
      if (group === '오른손' || group === '왼손') return ({ '가슴': MODULE_ACT_TAGS.manFondleWoman, '젖꼭지': 'hetero, nipple_tweak',
        '클리': "hetero, hand_on_another's_crotch, clitoral_stimulation, clitoris, clitoris_tweak",
        '엉덩이': "hetero, grabbing_another's_ass",
        '머리채': "hetero, grabbing_another's_hair", '손목': "hetero, holding_another's_wrist",
        '허리': "hetero, hand_on_another's_waist", '다리': "hetero, hand_on_another's_leg",
        '옷 위': MODULE_ACT_TAGS.manFondleWoman, '속옷 위': MODULE_ACT_TAGS.mutualRubbing })[label] || '';
      if (group === '사정 위치' || group === '해 달라고') return ({ '항문 안에': 'hetero, cum_in_ass', '엉덩이 안에': 'hetero, cum_in_ass',
        '질 안에': 'cum_in_pussy', '안에': 'cum_in_pussy', '입 안에': 'cum_in_mouth',
        '얼굴에': 'facial', '입에': 'cum_in_mouth', '가슴에': 'cum_on_breasts',
        '손에': 'cum_on_hands', '빼서 몸에': 'cum_on_body', '밖에': 'cum_on_body' })[label] || '';
      if (group === '폭력성') return ({ '뺨': '(hand striking her left cheek:1.2)', '가슴': '(hand striking her left breast:1.2)',
        '엉덩이': '(hand striking her left buttock:1.2)', '음부': '(hand striking her vulva:1.2)', '배': '(hand striking her lower abdomen:1.2)',
        '머리채': "grabbing_another's_hair", '목': NECK_GRAB_PROMPT })[label] || '';
      if (group === '자리') return ({ '손': MODULE_ACT_TAGS.womanHandjobMan, '가슴': MODULE_ACT_TAGS.womanPaizuriMan,
        '뒤에 붙음': 'hetero, doggystyle', '입': MODULE_ACT_TAGS.womanOralMan,
        '몸 비비기': MODULE_ACT_TAGS.mutualRubbing, '앞 (질)': 'hetero, penis_on_pussy',
        '뒤 (항문)': 'hetero, penis_on_ass', '그녀가 위 (앞)': 'hetero, cowgirl_position, girl_on_top' })[label] || '';
      if (group === '삽입') return ({ '앞으로': MODULE_ACT_TAGS.manVaginalWoman,
        '뒤로': MODULE_ACT_TAGS.manAnalWoman,
        '자지 빼내기': MODULE_ACT_TAGS.mutualRubbing,
        '기회 삽입': 'hetero, imminent_vaginal, penis_on_pussy',
        '넣은 채': 'hetero', '빼기': MODULE_ACT_TAGS.mutualRubbing })[label] || '';
      if (group === '삽입 위치') return label === '뒤 (애널)' ? 'hetero, penis_on_ass'
        : label === '앞 (보지)' ? 'hetero, penis_on_pussy' : '';
      if (group === '벗기기' || group === '옷') return /벗기|탈의|비껴|내리|걷어|끈 풀/.test(label) ? 'undressing' : '';
      if (group === '움직임') return /움직|비빈|빠르게/.test(label) ? 'motion_blur' : /입과 손/.test(label) ? 'groping' : '';
      if (group === '가슴 가림') return /^0 /.test(label) ? 'breasts' : label === '풀기' ? '' : 'covering_breasts';
      if (group === '다리 가림') return /^0 |^1 /.test(label) ? 'spread_legs' : label === '풀기' ? '' : 'legs_together';
      if (group === '꾀의 수') return /발목|다리 걸기/.test(label) ? 'legs_up' : /뒤에서/.test(label) ? 'hug' : '';
      if (group === '비명 단계') return label === '원래대로' || label === '상한 새로' ? '' : 'open_mouth, crying';
      if (group === '장면 이벤트') return ({ '칭찬하기': 'smile', '무례한 말 하기': 'angry',
        '술 한잔 권하기': 'drinking', '지난 방문 이야기하기': 'talking',
        '그녀에게 추파 던지기': 'blush', '그녀에게 다가가기': 'standing',
        '취해서 손대기': 'groping', '돈을 걸고 제안하기': 'money',
        '다른 손님에게 자랑하기': 'talking' })[label] || '';
      if (group === '나쁜 손님') return ({ '뒷방으로 속이기': 'door',
        '수갑 채우기': 'handcuffs, bound_wrists', '수갑 풀기': 'handcuffs',
        '뒷방 문 잠그기': 'door', '미약 타기': 'blush, dazed' })[label] || '';
      if (group === '부위 (정도 2)') return '';
      if (group === '고백 · 막는다' || group === '힘으로 쫓아내기 결과'
        || group === '가림 · 굴복도' || group === '협박하기') return '';
      if (/거친 성관계|거칠게/.test(label)) return 'rough_sex';
      if (/애태우기/.test(label)) return 'blush';
      if (/음란한 말|말하기/.test(label)) return 'talking';
      if (/빠르게/.test(label)) return 'motion_blur';
      if (/벗기기|탈의/.test(label)) return 'undressing';
      if (/수갑 채우기/.test(label)) return 'handcuffs';
      if (/미약 타기/.test(label)) return 'blush, dazed';
      if (/문 잠그기/.test(label)) return 'door';
      if (/가슴 가림 흐름/.test(label)) return 'covering_breasts';
      if (/다리 가림 흐름/.test(label)) return 'legs_together';
      if (label === '항문' || /항문|뒤로/.test(label) && /삽입|뒤로/.test(label)) return 'anal';
      if (/앞으로/.test(label)) return 'sex';
      if (/키스/.test(label)) return MODULE_ACT_TAGS.mutualKiss;
      if (/가슴.*애무|가슴.*주무|가슴.*쥐/.test(label)) return MODULE_ACT_TAGS.manFondleWoman;
      if (/애무|만지기/.test(label)) return MODULE_ACT_TAGS.manFondleWoman;
      if (entry.group === '폭력성' && label === '엉덩이') return 'spanking';
      if (/입안/.test(label)) return 'cum_in_mouth';
      if (/얼굴/.test(label) && /사정|싸/.test(entry.group + label)) return 'facial';
      if (/가슴/.test(label) && /사정|싸/.test(entry.group + label)) return 'cum_on_breasts';
      if (/안에|질내/.test(label) && /사정|싸/.test(entry.group + label)) return 'cum_in_pussy';
      return '';
    }
    function controllerButtonDefaultNegative(entry) {
      if (entry.group === '입·손가락' && entry.label === '혀 얽기') return 'tongue_out';
      const tags = controllerButtonDefaultTags(entry);
      if (controllerButtonKind(entry) === 'position') {
        if (tags.includes('mating_press')) return COUPLE_POSITION_NEGATIVES['mating-press'];
        if (tags.includes('doggystyle')) return COUPLE_POSITION_NEGATIVES.doggystyle;
        if (tags.includes('missionary')) return COUPLE_POSITION_NEGATIVES.missionary;
        if (tags.includes('spooning')) return COUPLE_POSITION_NEGATIVES.spooning;
      }
      const maleHand = ['오른손', '왼손'].includes(entry.group)
        || /\b(?:fingering|anal_fingering|groping)\b/.test(tags)
        || /grabbing_another's_(?:breast|ass)/.test(tags);
      if (!tags || !maleHand) return '';
      return /\b(?:fingering|clitoral_stimulation)\b/.test(tags)
        ? 'female_masturbation, hand_on_own_crotch, spread_pussy' : 'female_masturbation';
    }

    function availablePositionModules() {
      const overrides = currentPositionModulePrompts();
      const builtins = BUILTIN_POSITION_MODULES.map(module => {
        const saved = overrides[module.id] || {};
        return { ...module, ...saved,
          ...(PREVIOUS_PENETRATION_MODULE_TAGS[saved.positivePrompt] === module.positivePrompt
            || module.id === 'climax-1' && saved.positivePrompt === 'female_orgasm, moaning, blush, heavy_breathing'
            ? { positivePrompt: module.positivePrompt } : {}) };
      });
      const controller = currentControllerButtonCatalog().map(entry => {
        const contact = controllerContactType(entry);
        const positivePrompt = controllerButtonDefaultTags(entry);
        const negativePrompt = contact ? CONTROLLER_CONTACT_PROMPTS[contact].negativePrompt
          : controllerButtonDefaultNegative(entry);
        const saved = overrides[entry.id] || {};
        const previousDefault = PREVIOUS_CONTROLLER_POSE_TAGS[entry.label];
        const savedDefault = (Array.isArray(previousDefault) ? previousDefault : [previousDefault])
          .includes(saved.positivePrompt) || entry.group === '폭력성' && entry.label === '목'
          && saved.positivePrompt === 'neck_grab';
        return {
          id: entry.id, kind: controllerButtonKind(entry),
          name: `${entry.scope === 'you' ? '당신' : '손님'} · ${entry.group} · ${entry.label}`,
          positivePrompt, negativePrompt,
          controller: true,
          controllerScope: entry.scope, controllerGroup: entry.group, controllerLabel: entry.label,
          ...saved,
          ...(savedDefault ? { positivePrompt,
            ...(!saved.negativePrompt || positivePrompt.includes('spooning')
              && saved.negativePrompt === 'standing_sex' ? { negativePrompt } : {}) } : {}),
          ...(PREVIOUS_PENETRATION_MODULE_TAGS[saved.positivePrompt] === positivePrompt
            ? { positivePrompt } : {}),
        };
      });
      return [...builtins, ...currentPositionModules(), ...controller];
    }

    function normalizePositionModuleSelections(value, modules = availablePositionModules()) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      const available = new Map(modules.map(module => [module.id, module]));
      return Object.fromEntries(Object.entries(value).slice(-200).flatMap(([situationId, ids]) => {
        if (typeof situationId !== 'string' || situationId.length > 160
          || !/^(?:scene|task|look)-./.test(situationId) || situationId.includes('__') || !Array.isArray(ids)) return [];
        const selected = [...new Set(ids.filter(id => typeof id === 'string' && available.has(id)))].slice(0, 100);
        for (const kind of ['pose', 'position', 'action']) {
          const sameKind = selected.filter(id => available.get(id).kind === kind);
          if (kind === 'pose' || kind === 'position') {
            for (const id of sameKind.slice(0, -1)) selected.splice(selected.indexOf(id), 1);
            continue;
          }
          for (const role of ['patron', 'you', 'generic']) {
            const idsForRole = sameKind.filter(id => (available.get(id).controllerScope || 'generic') === role);
            if (role === 'patron' && multiplePatronActions(situationId)) continue;
            for (const id of idsForRole.slice(0, -1)) selected.splice(selected.indexOf(id), 1);
          }
        }
        for (const role of ['patron', 'you']) for (const group of ['오른손', '왼손']) {
          const handIds = selected.filter(id => available.get(id).controllerScope === role
            && available.get(id).controllerGroup === group);
          for (const id of handIds.slice(0, -1)) selected.splice(selected.indexOf(id), 1);
        }
        for (const role of ['patron', 'you']) {
          const clothes = selected.filter(id => available.get(id).controllerScope === role
            && available.get(id).controllerGroup === '옷 상태');
          const last = available.get(clothes.at(-1));
          for (const id of clothes) if (last?.controllerLabel === '완전 나체'
            ? id !== clothes.at(-1) : available.get(id).controllerLabel === '완전 나체')
            selected.splice(selected.indexOf(id), 1);
        }
        return selected.length ? [[situationId, selected]] : [];
      }));
    }

    function currentPositionModuleSelections() {
      return normalizePositionModuleSelections(api.settings.get({ positionModuleSelections: {} }).positionModuleSelections);
    }

    function normalizePositionModuleGroupLayouts(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).slice(-200).flatMap(([situationId, raw]) => {
        const count = positionGroupCount(situationId);
        if (!count || situationId.length > 160 || !/^(?:scene|task|look)-/.test(situationId)
          || situationId.includes('__') || !raw || typeof raw !== 'object' || Array.isArray(raw)) return [];
        const groupSlots = typeof raw.groupSlots === 'string' && raw.groupSlots.length === count
          && [...raw.groupSlots].every(slot => GROUP_SLOT_BY_ID[slot]) ? raw.groupSlots : '';
        const details = compactPositionDetails({ main: raw.details?.main, extras: raw.details?.extras,
          female: {} }, count);
        const personPrompts = {
          main: String(raw.personPrompts?.main || '').slice(0, 2000),
          extras: Array.from({ length: count }, (_, index) =>
            String(raw.personPrompts?.extras?.[index] || '').slice(0, 2000)),
        };
        if (!groupSlots && !details && !personPrompts.main && !personPrompts.extras.some(Boolean)) return [];
        return [[situationId, { groupSlots, ...(details ? { details } : {}), personPrompts }]];
      }));
    }

    function currentPositionModuleGroupLayouts() {
      return normalizePositionModuleGroupLayouts(api.settings.get({ positionModuleGroupLayouts: {} }).positionModuleGroupLayouts);
    }
    function normalizePositionModulePoseAssignments(value, modules = availablePositionModules()) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      const available = new Map(modules.map(module => [module.id, module]));
      return Object.fromEntries(Object.entries(value).slice(-100).filter(([poseId, positionId]) =>
        available.get(poseId)?.kind === 'pose' && available.get(positionId)?.kind === 'position'));
    }
    function currentPositionModulePoseAssignments() {
      return normalizePositionModulePoseAssignments(api.settings.get({ positionModulePoseAssignments: {} }).positionModulePoseAssignments);
    }

    const SCENE_POSE_PRESET_IDS = Object.freeze({
      missionary: 'missionary', doggystyle: 'doggystyle', spooning: 'spooning',
      standing: 'standing-sex', against_wall_pinned: 'wall-pinned', against_wall: 'wall-leaning',
      against_wall_leg_up: 'wall-one-leg-raised', carried: 'lifted-standing',
      lifted: 'wall-lifted-feet-off-ground', mating_press: 'mating-press', prone_bone: 'prone-bone',
      cowgirl: 'cowgirl', reverse_cowgirl: 'reverse-cowgirl', fellatio_kneeling: 'kneeling-fellatio',
      sixty_nine: 'sixty-nine', handjob: 'seated-handjob', fingering: 'female-hand-stimulation',
      cunnilingus: 'cunnilingus', paizuri: 'paizuri', thigh_sex: 'thigh-sex',
    });
    const SCENE_POSE_MOOD_PROMPTS = Object.freeze({
      coerced: ['struggling, resisting, tears, frown, averting_eyes', 'smile, happy, seductive_smile'],
      revulsion: ['disgust, grimace, averting_eyes', 'smile, seductive_smile'],
      tense: ['nervous, trembling, sweat', 'smile'],
      tears: ['tears, crying', 'smile'],
      pain: ['pain, grimace, clenched_teeth', 'smile'],
      pinned: ['restrained, struggling', 'arms_at_sides'],
      aroused: ['blush, heavy_breathing', ''],
      climax: ['female_orgasm, trembling, open_mouth', 'expressionless'],
      clinging: ['hug, blush', ''],
      drugged: ['dazed, half-closed_eyes, drooling', ''],
      loving: ['looking_at_another, smile', 'crying, rape, forced'],
      rough: ['rough_sex, motion_blur', ''],
    });
    const SCENE_POSE_LOOK_PROMPTS = Object.freeze({
      'charmer/adventurer': 'leather_armor, cape',
      'charmer/journeyman_artisan': 'apron, chisel, crystal_ball',
      'charmer/young_bachelor': 'mature_male, short_hair',
      'charmer/traveling_bard': 'mandolin, cloak',
      'charmer/clergy_off_duty': 'priest, stole, vial',
      'charmer/married_man_alone': 'carpenter, apron, wedding_ring',
      'charmer/traveling_merchant': 'merchant, ornate_clothes, pearl_earrings',
      'charmer/recently_widowed': 'old_man, grey_hair, beard',
      'drunk_bold/adventurer': 'armor, drunk',
      'drunk_bold/clergy_off_duty': 'priest, cassock, drunk',
      'drunk_bold/ex_soldier': 'old_man, armor, drunk',
      'drunk_bold/local_farmer': 'farmer, apron, drunk',
      'drunk_bold/traveling_merchant': 'merchant, backpack, drunk',
      'drunk_bold/town_drunk': 'drunk, messy_hair, red_nose',
      'drunk_bold/recently_widowed': 'old_man, drunk, formal_clothes',
      'nobleman/adventurer': 'knight, armor, shield, sword',
      'nobleman/clergy_off_duty': 'priest, stole, ornate_clothes',
      'nobleman/traveling_merchant': 'formal_clothes, ornate_clothes, perfume_bottle',
      'nobleman/noble_slumming': 'formal_clothes, white_gloves, mask, ring',
      'nobleman/recently_widowed': 'old_man, beard, ring, key',
      'regular/adventurer': 'old_man, rope, lantern',
      'regular/journeyman_artisan': 'carpenter, apron, wood_carving_tool',
      'regular/young_bachelor': 'mature_male, letter',
      'regular/clergy_off_duty': 'monk, rosary, torn_clothes',
      'regular/local_farmer': 'farmer, basket, apple',
      'regular/married_man_alone': 'vest, wedding_ring, whip, reins',
      'regular/traveling_merchant': 'merchant, tan, scales',
      'regular/recently_widowed': 'old_man, flour, apron',
      'rogue/adventurer': 'thief, magnifying_glass, lockpick',
      'rogue/young_bachelor': 'mature_male, scar, toothpick, knife',
      'rogue/clergy_off_duty': 'priest, cassock, rosary',
      'rogue/ex_soldier': 'soldier, scar, sword, crossbow',
      'rogue/traveling_merchant': 'merchant, bag, bottle',
      'rogue/recently_widowed': 'butcher, apron, hook',
      'wealthy_pervert/adventurer': 'old_man, fat_man, ring',
      'wealthy_pervert/clergy_off_duty': 'priest, fat_man, mitre',
      'wealthy_pervert/married_man_alone': 'merchant, formal_clothes, book',
      'wealthy_pervert/traveling_merchant': 'merchant, ornate_clothes, tape_measure',
      'wealthy_pervert/noble_slumming': 'mature_male, formal_clothes, crystal_ball',
      'wealthy_pervert/recently_widowed': 'old_man, formal_clothes, ring',
    });
    const SCENE_POSE_FILTH_PROMPTS = Object.freeze({
      drunk_bold: 'drunk, sweat, dirty, stubble', rogue: 'dirty, sweat, stubble',
      wealthy_pervert: 'sweat, dirty', regular: 'sweat', nobleman: 'sweat',
      'drunk_bold/adventurer': 'sweat, dirty, blood_stain, dirty_hands',
      'drunk_bold/clergy_off_duty': 'stained_clothes, bad_teeth, dirty',
      'drunk_bold/town_drunk': 'vomit, stained_clothes, bad_teeth, dirty',
      'nobleman/adventurer': 'sweat, rust, messy_hair',
      'nobleman/clergy_off_duty': 'sweat',
      'nobleman/noble_slumming': 'messy_hair, stained_clothes, dirty',
      'nobleman/recently_widowed': 'grey_beard, liver_spots',
    });
    const SCENE_POSE_ROUGH_PROMPTS = Object.freeze({
      '이라마치오': 'irrumatio, deepthroat', '목조르기 섹스': NECK_GRAB_PROMPT,
      '손목 눌러 붙잡고': "holding_another's_wrist, restrained",
      '교배 프레스': 'rough_sex', '머리채 후배위': "grabbing_another's_hair",
      '짓눌린 복와위': 'restrained', '다리 들어 올린 측위': 'leg_up',
      '밑에서 쳐올리기': 'rough_sex', '끌어내리기': 'rough_sex',
      '선 채로 몰아붙이기': 'rough_sex', '벽에 짓눌러서': 'rough_sex',
      '벽에 처박듯이': 'rough_sex', '한 다리 걸쳐 들고 거칠게': 'leg_up, rough_sex',
      '들어 올린 채 거칠게': 'rough_sex',
      '가슴 움켜쥐고': "grabbing_another's_breast", '머리 눌러 깊이': 'head_grab, deepthroat',
    });

    function controllerPositionModules(situationId, characterId) {
      const state = api.store.game();
      const scene = basePositionSituationId(situationId);
      if (!state || characterId !== state.primaryCharacterId || !scene.startsWith('scene-')) return null;
      const patronScene = scene.startsWith('scene-patron_');
      let poseName;
      let action;
      let bridge = null;
      let coerced = false;
      let aipPoseActive = false;
      try {
        const provided = globalThis.__waywardScenePose?.now?.();
        if (provided?.scene === scene.slice(6) && provided.source === (patronScene ? 'patron' : 'husband')) bridge = provided;
        if (patronScene) {
          const patron = state.activeScene?.patron;
          const now = globalThis.__waywardActExpansion?.pose?.now?.();
          if (!patron || patron.afterglow || patron.playerEngaged) return null;
          if (bridge?.customerId !== patron.customerId) bridge = null;
          let sceneState = null;
          try { sceneState = globalThis.__waywardActExpansion?.scene?.(); } catch {}
          const matchingScene = sceneState && (!sceneState.customer?.id
            || sceneState.customer.id === patron.customerId);
          coerced = Number.isFinite(patron.coercedSinceSlot)
            && state.slot >= patron.coercedSinceSlot && state.slot - patron.coercedSinceSlot <= 15
            || !!(matchingScene && (sceneState.coerced || sceneState.forcedIn
              || sceneState.pressured && sceneState.comfort < 40));
          const matchingPose = now?.customerId === patron.customerId;
          if (!matchingPose && !bridge && !coerced && !(patron.stage === 'sex_patron'
            && ['scene-patron_sex', 'scene-patron_anal'].includes(scene))) return null;
          poseName = bridge?.pose || (matchingPose ? now.pose : undefined);
          action = patron.lateralAct?.kind === 'cunnilingus' ? 'cunnilingus'
            : patron.stage === 'sex_patron' ? patron.primarySlot === 'inside_anal' ? 'anal' : 'vaginal'
              : ({ blowjob_patron: 'fellatio', handjob_patron: 'handjob', rubbing_patron: 'rubbing', intimate: 'fingering' })[patron.stage];
          if ((bridge?.group || now?.group) === 'rub') {
            if (poseName === '파이즈리') action = 'paizuri';
            if (poseName === '스마타') action = 'thighSex';
          }
        } else {
          const sex = state.activeScene?.sex;
          if (!sex || sex.finish) return null;
          const husband = globalThis.__waywardHusbandLife;
          const husbandOwns = !!husband?.owns?.(state);
          const controller = husbandOwns ? husband.compat : globalThis.__waywardActExpansion;
          const aipPose = sex.__aipPose;
          aipPoseActive = !husbandOwns && scene === `scene-${sex.type}`
            && aipPose?.version === 1 && typeof aipPose.label === 'string'
            && aipPose.actType === sex.type
            && (sex.characterId || state.primaryCharacterId) === characterId
            && aipPose.characterId === (sex.characterId || state.primaryCharacterId)
            && Number.isFinite(state.day) && aipPose.day === state.day
            && Number.isFinite(sex.startedAtSlot) && aipPose.startedAtSlot === sex.startedAtSlot
            && Object.values(POSITION_PRESETS).some(item => item.name === aipPose.label && item.template);
          poseName = aipPoseActive ? aipPose.label : bridge?.pose || controller?.husPoseOf?.(sex);
          action = ({ sex: 'vaginal', sex_rough: 'vaginal', standing_sex: 'vaginal', riding: 'vaginal',
            anal: 'anal', blowjob: 'fellatio', deepthroat: 'roughFellatio', titfuck: 'paizuri',
            sixty_nine: 'sixtyNine', handjob: 'handjob', fingering: 'fingering', anal_fingering: 'analFingering',
            cunnilingus: 'cunnilingus', thigh_job: 'rubbing', grinding: 'rubbing' })[sex.type];
        }
      } catch { return null; }
      const asleep = !aipPoseActive && !patronScene && state.activeScene?.sex?.__hs?.sleep?.stage === 'asleep';
      if (asleep && !['측위', '복와위'].includes(poseName))
        poseName = state.activeScene.sex.type === 'anal' ? '복와위' : '측위';
      const poseBridge = aipPoseActive ? null : bridge;
      const preset = POSITION_PRESETS[asleep ? '' : SCENE_POSE_PRESET_IDS[poseBridge?.poseId]]
        || Object.values(POSITION_PRESETS).find(item => item.name === poseName && item.template);
      const poseTags = {
        missionary: COUPLE_POSITION_TAGS.missionary, cowgirl: 'hetero, cowgirl_position, girl_on_top',
        'reverse-cowgirl': 'hetero, reverse_cowgirl_position, girl_on_top', doggystyle: COUPLE_POSITION_TAGS.doggystyle,
        'anal-doggystyle': 'hetero, doggystyle, anal', spooning: COUPLE_POSITION_TAGS.spooning,
        'standing-sex': 'standing_sex', 'wall-pinned': 'against_wall',
        'wall-leaning': 'against_wall, leaning_forward',
        'wall-one-leg-raised': 'against_wall, leg_up',
        'lifted-standing': 'suspended_congress', 'wall-lifted-feet-off-ground': 'suspended_congress, against_wall',
        'mating-press': COUPLE_POSITION_TAGS.press, 'prone-bone': 'prone_bone',
        'kneeling-fellatio': `kneeling, ${MODULE_ACT_TAGS.womanOralMan}`,
        'rough-fellatio': MODULE_ACT_TAGS.manIrrumatioWoman,
        cunnilingus: MODULE_ACT_TAGS.manOralWoman,
        'female-hand-stimulation': MODULE_ACT_TAGS.manFingerWoman,
        'sixty-nine': MODULE_ACT_TAGS.mutualOral,
        'seated-handjob': `sitting, ${MODULE_ACT_TAGS.womanHandjobMan}`,
        paizuri: MODULE_ACT_TAGS.womanPaizuriMan, 'thigh-sex': 'hetero, thigh_sex, penis, thighs',
      };
      const poseId = preset?.id || SCENE_POSE_PRESET_IDS[poseBridge?.poseId];
      const posePrompt = poseName === '여성 손 자극' || poseName === '앉아서 남성 손 자극'
        ? 'sitting' : poseTags[poseId] || danbooruModuleTags(poseBridge?.poseTags);
      const contactPosePrompt = activeContactType(state, patronScene ? 'patron' : 'you')
        ? danbooruModuleTags(posePrompt).split(', ').filter(tag => ![
          'anal', 'vaginal', 'fellatio', 'deepthroat', 'irrumatio', 'cunnilingus', 'handjob',
          'paizuri', 'thigh_sex', '69', 'fingering', 'licking_penis', "grabbing_another's_penis",
          'breast_press', 'rough_sex',
        ].includes(tag)).join(', ')
        : posePrompt;
      const actionTags = { kissing: MODULE_ACT_TAGS.mutualKiss,
        fondling: MODULE_ACT_TAGS.manFondleWoman, fingering: MODULE_ACT_TAGS.manFingerWoman,
        cunnilingus: MODULE_ACT_TAGS.manOralWoman, fellatio: MODULE_ACT_TAGS.womanOralMan,
        roughFellatio: MODULE_ACT_TAGS.manIrrumatioWoman,
        handjob: MODULE_ACT_TAGS.womanHandjobMan, paizuri: MODULE_ACT_TAGS.womanPaizuriMan,
        thighSex: 'hetero, thigh_sex, penis, thighs',
        vaginal: MODULE_ACT_TAGS.manVaginalWoman, anal: MODULE_ACT_TAGS.manAnalWoman,
        analFingering: MODULE_ACT_TAGS.manAnalFingerWoman,
        rubbing: MODULE_ACT_TAGS.mutualRubbing, watching: MODULE_ACT_TAGS.manWatchingWoman,
        sixtyNine: MODULE_ACT_TAGS.mutualOral };
      const extras = [];
      const climaxCount = femaleClimaxCount(situationId, characterId, state);
      const moodIds = new Set();
      if (bridge) {
        for (const mood of Array.isArray(bridge.mood) ? bridge.mood.slice(0, 12) : []) {
          const id = mood?.id;
          if (typeof id !== 'string' || moodIds.has(id) || id === 'coerced' && !coerced
            || id === 'climax' && !climaxCount) continue;
          const defaults = SCENE_POSE_MOOD_PROMPTS[id] || ['', ''];
          const positivePrompt = danbooruModuleTags(`${defaults[0]}, ${mood.tags || ''}`);
          const negativePrompt = danbooruModuleTags(defaults[1]);
          if (!positivePrompt && !negativePrompt) continue;
          moodIds.add(id);
          extras.push({ id: `bridge-mood-${id}`, kind: 'mood',
            name: `확장 분위기 · ${String(mood.label || id).slice(0, 80)}`,
            positivePrompt, negativePrompt });
        }
        if (guestAppearanceEnabled()) {
          const filthKey = bridge.him?.key || '';
          const filthPrompt = bridge.him?.filth
            ? SCENE_POSE_FILTH_PROMPTS[filthKey] || SCENE_POSE_FILTH_PROMPTS[filthKey.split('/')[0]] : '';
          const himTags = guestAppearanceTags([bridge.him && 'faceless_male',
            SCENE_POSE_LOOK_PROMPTS[bridge.him?.key], filthPrompt, bridge.him?.tags, bridge.him?.filth]
            .filter(value => typeof value === 'string' && value).join(', '));
          if (himTags) extras.push({ id: 'bridge-him', kind: 'other', name: '확장 손님 외형',
            positivePrompt: himTags, negativePrompt: '' });
        }
        const hostileMood = Array.isArray(bridge.mood) && bridge.mood.some(mood =>
          ['revulsion', 'tears', 'pain'].includes(mood?.id));
        const staleHostile = !coerced && !hostileMood
          ? 'smile, smiling, happy, content, heart-shaped pupils, ahegao, peace sign, looking at viewer seductively' : '';
        const staleClimax = !climaxCount && Array.isArray(bridge.mood)
          && bridge.mood.some(mood => mood?.id === 'climax') ? 'bored, expressionless' : '';
        const negative = typeof bridge.negative === 'string'
          ? danbooruModuleTags(withoutPromptTags(bridge.negative,
            `${bridge.poseNegative || ''}, ${staleHostile}, ${staleClimax}, ${climaxCount ? 'ahegao' : ''}`)) : '';
        if (negative) extras.push({ id: 'bridge-negative', kind: 'other', name: '확장 Negative',
          positivePrompt: '', negativePrompt: negative });
        const roughPrompt = SCENE_POSE_ROUGH_PROMPTS[poseBridge?.roughPose];
        if (roughPrompt) extras.push({ id: 'bridge-rough-pose', kind: 'mood',
          name: `확장 거친 자세 · ${bridge.roughPose}`, positivePrompt: roughPrompt, negativePrompt: '' });
      }
      if (coerced && !moodIds.has('coerced')) extras.push({
        id: 'bridge-mood-coerced', kind: 'mood', name: '현재 강압 · 아내 표정',
        positivePrompt: SCENE_POSE_MOOD_PROMPTS.coerced[0],
        negativePrompt: SCENE_POSE_MOOD_PROMPTS.coerced[1],
      });
      return {
        pose: contactPosePrompt ? { id: `controller-pose-${poseId || 'sumata'}`, kind: 'position', name: `현재 체위 · ${poseName}`,
          positivePrompt: contactPosePrompt,
          negativePrompt: COUPLE_POSITION_NEGATIVES[poseId] || (poseId === 'thigh-sex' ? 'vaginal, anal' : ''), controller: true,
          controllerScope: patronScene ? 'patron' : 'you' } : null,
        action: actionTags[action] ? { id: `controller-action-${action}`, kind: 'action', name: '게임 행위',
          positivePrompt: actionTags[action], negativePrompt: '', controller: true,
          controllerScope: patronScene ? 'patron' : 'you' } : null,
        poseNegative: danbooruModuleTags(poseBridge?.poseNegative),
        source: aipPoseActive ? 'aip' : 'external',
        extras,
      };
    }

    function femaleClimaxCount(situationId, characterId, state) {
      const character = state?.characters?.[characterId];
      if (!state || characterId !== state.primaryCharacterId || !Number.isFinite(character?.lastOrgasmSlot)) return 0;
      const situation = basePositionSituationId(situationId);
      const patron = situation.startsWith('scene-patron_') ? state.activeScene?.patron : null;
      const sex = situation.startsWith('scene-') && !situation.startsWith('scene-patron_')
        ? state.activeScene?.sex : null;
      const scene = patron || sex;
      if (!scene || (scene.characterId && scene.characterId !== characterId)
        || (Number.isFinite(scene.startedAtSlot) && character.lastOrgasmSlot < scene.startedAtSlot)) return 0;
      const event = latestHeroineOrgasm?.targetId === characterId && latestHeroineOrgasm.slot <= state.slot
        && (patron ? latestHeroineOrgasm.patronId === patron.customerId
          && latestHeroineOrgasm.patronStartedAtSlot === patron.startedAtSlot
          : latestHeroineOrgasm.sexType === sex.type
            && latestHeroineOrgasm.sexStartedAtSlot === sex.startedAtSlot)
        ? latestHeroineOrgasm : null;
      if (patron) return patron.elenaClimaxedDuringInteraction
        ? Math.max(0, Number(patron.elenaInteractionClimaxCount) || 0, event?.patronCount || 0) : 0;
      if (!sex.elenaClimaxedDuringScene && !sex.finish?.elenaAlsoOrgasmed) return 0;
      const count = Math.max(0, Number(sex.elenaClimaxCount) || 0);
      return Math.max(count, sex.finish?.elenaAlsoOrgasmed
        ? Math.max(1, count + (sex.elenaMoaning >= 70 ? 1 : 0)) : 0, event?.sexCount || 0);
    }

    function positionActClass(value) {
      const tags = String(value || '').toLowerCase();
      // Compound acts deliberately remain untouched; they may describe more than one participant.
      if (/\b(?:69|sixty[_ -]?nine)\b/.test(tags)) return '';
      const found = [
        ['oral', /\b(?:irrumatio|deepthroat|fellatio|blowjob)\b/],
        ['cunnilingus', /\bcunnilingus\b/], ['handjob', /\bhandjob\b/],
        ['paizuri', /\b(?:paizuri|titfuck|breast[_ ]sex)\b/],
        ['anal', /\banal\b/], ['vaginal', /\bvaginal\b/],
        ['fingering', /\b(?:fingering|anal_fingering)\b/], ['rubbing', /\b(?:frottage|thigh_sex)\b/],
      ].filter(([, pattern]) => pattern.test(tags)).map(([kind]) => kind);
      return found.length === 1 ? found[0] : '';
    }

    function positionExplicitActClass(module) {
      return module?.controller && module.kind === 'position' && module.controllerScope
        ? positionActClass(module.positivePrompt) : '';
    }

    function conflictingNativeActTags(kind) {
      return ({ vaginal: 'sex, rough_sex, vaginal, vaginal_sex, vaginal_penetration',
        anal: 'sex, rough_sex, anal, anal_sex, anal_penetration',
        oral: 'fellatio, blowjob, deepthroat, irrumatio', cunnilingus: 'cunnilingus',
        handjob: 'handjob', paizuri: 'paizuri, titfuck, breast_sex',
        fingering: 'fingering, anal_fingering', rubbing: 'frottage, thigh_sex' })[kind] || '';
    }

    function positionCurrentAct(scope, state, situationId) {
      const scene = basePositionSituationId(situationId);
      if (scope === 'you') {
        const sex = state?.activeScene?.sex, type = sex?.type;
        if (!type || sex.finish || sex.characterId != null && sex.characterId !== state.primaryCharacterId
          || scene !== `scene-${type}`) return '';
        return ({ sex: 'vaginal', sex_rough: 'vaginal', riding: 'vaginal', standing_sex: 'vaginal',
          anal: 'anal', blowjob: 'oral', deepthroat: 'oral', handjob: 'handjob', titfuck: 'paizuri',
          cunnilingus: 'cunnilingus', fingering: 'fingering', anal_fingering: 'fingering',
          grinding: 'rubbing', thigh_job: 'rubbing' })[type] || '';
      }
      const patron = state?.activeScene?.patron;
      if (scope !== 'patron' || !patron?.customerId || patron.afterglow || patron.playerEngaged
        || patron.characterId != null && patron.characterId !== state.primaryCharacterId
        || patron.lateralAct || multiplePatronActions(situationId)) return '';
      if (patron.stage === 'sex_patron') {
        const slot = patron.primarySlot;
        if (slot === 'inside_anal') return scene === 'scene-patron_anal' ? 'anal' : '';
        if (slot === 'astride') return scene === 'scene-patron_riding' ? 'vaginal' : '';
        if (slot == null || slot === 'inside') return scene === 'scene-patron_sex' ? 'vaginal' : '';
        return '';
      }
      const entry = ({ blowjob_patron: ['scene-patron_blowjob', 'oral'],
        handjob_patron: ['scene-patron_handjob', 'handjob'], rubbing_patron: ['scene-patron_rubbing', 'rubbing'],
        intimate: ['scene-patron_intimate', 'fingering'] })[patron.stage];
      return entry?.[0] === scene ? entry[1] : '';
    }

    function positionModuleChoice(situationId, characterId = api.store.game()?.primaryCharacterId, imageKey = '') {
      const state = api.store.game();
      const scopes = controllerScopesForSituation(situationId, characterId);
      const automaticScopes = scopes.length === 2 && !positionGroupCount(situationId)
        ? [basePositionSituationId(situationId).startsWith('scene-patron_') ? 'patron' : 'you'] : scopes;
      if (scopes.length) discoverFoldedControllerButtons();
      const buttons = automaticScopes.length ? visibleControllerButtons().filter(button => automaticScopes.includes(button.scope)) : [];
      if (buttons.length) discoverControllerButtons(buttons);
      const ids = currentPositionModuleSelections()[situationId] || [];
      const externalTargets = externalTargetSnapshot();
      const available = availablePositionModules().map(module => {
        const prompt = effectiveExternalTarget('position-module', module.id, module, externalTargets);
        return prompt === module ? module : { ...module, ...prompt };
      });
      const modules = available.filter(module => ids.includes(module.id)
        && (!module.controllerScope || scopes.includes(module.controllerScope))
        && (module.positivePrompt || module.negativePrompt));
      const singleScope = !positionGroupCount(situationId) && scopes.length === 1 && automaticScopes.length === 1
        ? automaticScopes[0] : '';
      const selectedActions = singleScope ? modules.filter(module => module.kind === 'action'
        && (!module.controllerScope || module.controllerScope === singleScope)) : [];
      const selectedExplicitPose = singleScope && !selectedActions.length
        ? modules.find(module => module.controllerScope === singleScope && positionExplicitActClass(module)) : null;
      const selectedAct = selectedActions.length === 1 ? positionActClass(selectedActions[0].positivePrompt)
        : !selectedActions.length ? positionExplicitActClass(selectedExplicitPose) : '';
      const currentAct = positionCurrentAct(singleScope, state, situationId);
      const conflictingAct = selectedAct && currentAct && selectedAct !== currentAct ? currentAct : '';
      const pose = modules.find(module => module.kind === 'pose');
      if (pose && !modules.some(module => module.kind === 'position')) {
        const assignedId = currentPositionModulePoseAssignments()[pose.id];
        const assigned = available.find(module => module.id === assignedId && module.kind === 'position'
          && (!module.controllerScope || scopes.includes(module.controllerScope))
          && (module.positivePrompt || module.negativePrompt));
        if (assigned) modules.push(assigned);
      }
      const activeIds = new Set(buttons.filter(button => button.active).map(button => button.id));
      for (const id of controllerFoldSnapshot?.activeIds || []) activeIds.add(id);
      const patronScene = state?.activeScene?.patron;
      const patronIds = new Set([patronScene?.customerId, ...(patronScene?.joinedPatronIds || []),
        ...(patronScene?.crowdPatronIds || [])]);
      const patronCaressApi = globalThis.__waywardActExpansion;
      const yourCaressApi = globalThis.__waywardHusbandLife?.owns?.(state)
        ? globalThis.__waywardHusbandLife.compat : patronCaressApi;
      const observedCaressIds = new Set();
      for (const scope of automaticScopes) {
        const caressApi = scope === 'you' ? yourCaressApi : patronCaressApi;
        let keys;
        try { keys = scope === 'patron' ? caressApi?.caressKeys?.(patronScene)
          : caressApi?.husCaressKeys?.(state?.activeScene?.sex); } catch { continue; }
        if (!Array.isArray(keys)) continue;
        const enabled = new Set(keys);
        for (const [set, group, members] of caressApi?.CARESS_SETS || []) {
          for (const [key, caress] of Object.entries(caressApi?.CARESS || {})) {
            if ((caress.set !== set && !members?.includes(key)) || !caress.label) continue;
            const id = `controller-${shortHash(`${scope}|${group}|${caress.label}`)}`;
            observedCaressIds.add(id);
            if (enabled.has(key)) activeIds.add(id);
            else activeIds.delete(id);
          }
        }
      }
      for (const recent of recentControllerButtons) {
        if (!automaticScopes.includes(recent.scope) || Number(state?.slot) < recent.slot
          || Number(state?.slot) > recent.slot + 1
          || recent.sceneType !== (recent.scope === 'patron' ? patronScene?.stage : state?.activeScene?.sex?.type)
          || observedCaressIds.has(recent.id)) continue;
        if (recent.scope === 'patron' && recent.actorId && !patronIds.has(recent.actorId)) continue;
        activeIds.add(recent.id);
      }
      for (const id of activeIds) {
        const module = available.find(entry => entry.id === id);
        if (module && controllerContactType({ group: module.controllerGroup, label: module.controllerLabel,
          scope: module.controllerScope })
          && !activeContactType(state, module.controllerScope)
          && (module.controllerScope === 'patron' ? patronScene?.stage === 'sex_patron'
            : ['sex', 'sex_rough', 'riding', 'standing_sex', 'anal'].includes(state?.activeScene?.sex?.type)))
          activeIds.delete(id);
      }
      for (const role of automaticScopes) {
        const contact = activeContactType(state, role);
        const activeButton = available.find(module => module.controllerScope === role
          && module.controllerGroup === '삽입' && controllerContactType({ group: '삽입',
            label: module.controllerLabel, scope: role }) && activeIds.has(module.id));
        if ((!contact && !activeButton) || modules.some(module => module.kind === 'action'
          && module.controllerScope === role) && !(role === 'patron' && multiplePatronActions(situationId))) continue;
        const label = role === 'patron' ? '삽입 준비'
          : contact === 'back' ? '입구에 맞댐 (뒤)' : '입구에 맞댐';
        const current = contact && available.find(module => module.controllerScope === role
          && module.controllerGroup === '삽입' && module.controllerLabel === label);
        const module = current || activeButton;
        if (module && !modules.some(selected => selected.id === module.id)) modules.push(module);
      }
      const controller = controllerPositionModules(situationId, characterId);
      for (const module of available) if (module.controller && automaticScopes.includes(module.controllerScope) && activeIds.has(module.id)
        && !(controller?.source === 'aip' && module.controllerScope === 'you' && ['pose', 'position'].includes(module.kind))
        && !(conflictingAct && module.controllerScope === singleScope && module.kind === 'action'
          && positionActClass(module.positivePrompt) === conflictingAct)
        && !['사정 위치', '해 달라고', '삽입 위치', '그녀의 바람'].includes(module.controllerGroup)
        && !modules.some(selected => selected.id === module.id)
        && !(module.kind === 'position' && modules.some(selected => ['pose', 'position'].includes(selected.kind)))
        && !(module.kind === 'action' && !(module.controllerScope === 'patron' && multiplePatronActions(situationId))
          && modules.some(selected => selected.kind === 'action' && (selected.controllerScope === module.controllerScope
            || singleScope && module.controllerScope === singleScope && !selected.controllerScope)))) modules.push(module);
      if (controller?.pose && !modules.some(module => ['pose', 'position'].includes(module.kind))) modules.unshift(
        modules.some(module => module.kind === 'action')
          ? controller.pose : { ...controller.pose,
            negativePrompt: danbooruModuleTags(`${controller.pose.negativePrompt}, ${controller.poseNegative}`) });
      if (!conflictingAct && controller?.action && modules.some(module => ['pose', 'position'].includes(module.kind))
        && !modules.some(module => module.kind === 'action')) modules.push(controller.action);
      if (automaticScopes.length === 2) {
        const sex = state.activeScene.sex;
        const patron = state.activeScene.patron;
        const youAction = ({ sex: MODULE_ACT_TAGS.manVaginalWoman,
          sex_rough: `${MODULE_ACT_TAGS.manVaginalWoman}, rough_sex`, anal: MODULE_ACT_TAGS.manAnalWoman,
          riding: MODULE_ACT_TAGS.manVaginalWoman, standing_sex: MODULE_ACT_TAGS.manVaginalWoman,
          blowjob: MODULE_ACT_TAGS.womanOralMan, deepthroat: MODULE_ACT_TAGS.manIrrumatioWoman,
          handjob: MODULE_ACT_TAGS.womanHandjobMan, titfuck: MODULE_ACT_TAGS.womanPaizuriMan,
          thigh_job: 'hetero, thigh_sex', grinding: MODULE_ACT_TAGS.mutualRubbing,
          lap_dance: 'hetero, sitting_on_lap', fingering: MODULE_ACT_TAGS.manFingerWoman,
          anal_fingering: MODULE_ACT_TAGS.manAnalFingerWoman, mutual_touching: 'hetero, mutual_masturbation',
          breast_worship: MODULE_ACT_TAGS.manFondleWoman, cunnilingus: MODULE_ACT_TAGS.manOralWoman,
          face_sitting: 'hetero, sitting_on_face, girl_on_top', sixty_nine: MODULE_ACT_TAGS.mutualOral })[sex?.type];
        const patronAction = patron?.lateralAct?.kind === 'cunnilingus' ? MODULE_ACT_TAGS.manOralWoman
          : ({ chatting: 'talking', flirting: 'blush', light_touch: "hetero, hand_on_another's_arm",
            bold_touch: MODULE_ACT_TAGS.manFondleWoman, groping: MODULE_ACT_TAGS.manFondleWoman,
            intimate: MODULE_ACT_TAGS.manFingerWoman,
            handjob_patron: MODULE_ACT_TAGS.womanHandjobMan,
            blowjob_patron: MODULE_ACT_TAGS.womanOralMan,
            rubbing_patron: MODULE_ACT_TAGS.mutualRubbing,
            sex_patron: patron?.primarySlot === 'inside_anal'
              ? MODULE_ACT_TAGS.manAnalWoman : MODULE_ACT_TAGS.manVaginalWoman })[patron?.stage];
        for (const [role, tags] of [['patron', patronAction], ['you', youAction]]) {
          if (tags && !modules.some(module => module.kind === 'action' && module.controllerScope === role))
            modules.push({ id: `controller-current-${role}`, kind: 'action', name: `${role === 'patron' ? '손님' : '당신'} · 현재 행위`,
              positivePrompt: tags, negativePrompt: '', controller: true, controllerScope: role });
        }
      }
      if (controller?.extras.length) modules.push(...controller.extras.map(module =>
        conflictingAct && module.id === 'bridge-rough-pose'
          ? { ...module, positivePrompt: withoutPromptTags(module.positivePrompt, conflictingNativeActTags(conflictingAct)) }
          : module));
      const climaxCount = femaleClimaxCount(situationId, characterId, state);
      for (const module of available) if (climaxModuleThreshold(module) > 0
        && climaxModuleThreshold(module) <= climaxCount
        && !modules.some(selected => selected.id === module.id)) modules.push(module);
      const tagged = modules.map(module => {
        const prompt = effectiveExternalTarget('position-module', module.id, module, externalTargets);
        return prompt === module ? module : { ...module, ...prompt };
      }).filter(module => module.positivePrompt || module.negativePrompt);
      const groupCount = positionGroupCount(situationId);
      const layout = groupCount ? currentPositionModuleGroupLayouts()[situationId] : null;
      const groupSlots = groupCount
        ? String(layout?.groupSlots || positionGroupSlots(imageKey || situationId)).padEnd(groupCount, 'w').slice(0, groupCount)
        : '';
      const details = layout?.details || null;
      const personPrompts = layout?.personPrompts || null;
      const signature = groupCount ? [tagged, groupSlots, details, personPrompts]
        : conflictingAct ? [tagged, 'manual-action-priority-v1', conflictingAct] : tagged;
      return tagged.length || groupSlots ? { modules: tagged, groupSlots, details, personPrompts,
        ...(conflictingAct ? { conflictingNativeAct: conflictingAct } : {}),
        moduleSignature: shortHash(JSON.stringify(signature)) } : null;
    }

    function positionPresetTemplateDetails(preset, groupCount = 0, current = null) {
      const details = normalizePositionDetails(current, groupCount);
      if (!preset?.template) return details;
      details.female = normalizeFemalePositionDetail({ pose: preset.template.femalePose });
      details.main = normalizePositionDetail(preset.template.main);
      return details;
    }

    function effectivePositionDetails(preset, value, groupCount = 0) {
      return compactPositionDetails(value, groupCount)
        || (preset?.template ? compactPositionDetails(positionPresetTemplateDetails(preset, groupCount), groupCount) : null);
    }

    function normalizePositionStatePrompts(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).flatMap(([situationId, prompt]) => {
        const id = String(situationId || '').trim();
        const positivePrompt = (typeof prompt === 'string' ? prompt : typeof prompt?.positivePrompt === 'string' ? prompt.positivePrompt : '').trim();
        const negativePrompt = (typeof prompt?.negativePrompt === 'string' ? prompt.negativePrompt : '').trim();
        const onlyState = prompt?.onlyState === true;
        return id.length <= 160 && /^(?:scene|task|look)-./.test(id) && !id.includes('__')
          && (positivePrompt || negativePrompt || onlyState)
          ? [[id, { positivePrompt, negativePrompt, onlyState }]] : [];
      }));
    }

    function currentPositionStatePrompts() {
      return normalizePositionStatePrompts(api.settings.get({ positionStatePrompts: {} }).positionStatePrompts);
    }

    function currentPositionStatePrompt(situationId) {
      const prompts = currentPositionStatePrompts();
      const base = prompts[situationId] || { positivePrompt: '', negativePrompt: '', onlyState: false };
      const effective = effectiveExternalTarget('position-state', situationId, base);
      if (effective !== base || prompts[situationId]) return effective;
      if (situationId.includes('|sleep-')) return null;
      const fallbackId = basePositionSituationId(situationId);
      if (fallbackId === situationId) return null;
      const fallback = prompts[fallbackId] || { positivePrompt: '', negativePrompt: '', onlyState: false };
      const inherited = effectiveExternalTarget('position-state', fallbackId, fallback);
      return inherited !== fallback || prompts[fallbackId] ? inherited : null;
    }

    function positionStateOnly(state) {
      return Boolean(state?.onlyState && (state.positivePrompt || state.negativePrompt));
    }

    function positionStateOnlySignature(state) {
      return shortHash(`${state?.positivePrompt || ''}|negative:${state?.negativePrompt || ''}`);
    }

    function normalizePositionRuleChoices(value, situationId) {
      const count = positionGroupCount(situationId);
      const choices = Array.isArray(value) ? value : [value];
      const unique = new Map();
      for (const entry of choices) {
        const requestedPresetId = typeof entry === 'string' ? entry : String(entry?.presetId || '');
        const details = compactPositionDetails(entry?.details, count);
        const presetId = !details && POSITION_PRESETS[requestedPresetId] ? requestedPresetId : '';
        const personPrompt = typeof entry?.personPrompt === 'string' && entry.personPrompt.length <= 2000 ? entry.personPrompt : null;
        if (!presetId && !details && personPrompt === null) continue;
        const rawSlots = typeof entry === 'object' && entry ? String(entry.groupSlots || '') : '';
        const groupSlots = count && rawSlots.length === count && /^[mhbcfxriaw]+$/.test(rawSlots) ? rawSlots : '';
        const signature = positionDetailsSignature(details, count);
        unique.set(JSON.stringify([presetId, groupSlots, signature, personPrompt]),
          { presetId, groupSlots, ...(details ? { details } : {}), ...(personPrompt !== null ? { personPrompt } : {}) });
      }
      return [...unique.values()];
    }

    function normalizePositionRules(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).flatMap(([situationId, rule]) => {
        const id = String(situationId || '').trim();
        if (id.length > 160 || !/^(?:scene|task|look)-./.test(id) || id.includes('__')) return [];
        const choices = normalizePositionRuleChoices(rule, id);
        return choices.length ? [[id, choices]] : [];
      }));
    }

    function currentPositionRules() {
      return normalizePositionRules(api.settings.get({ positionRules: {} }).positionRules);
    }

    function autoPositionPresets() {
      return api.settings.get({ autoPositionPresets: false }).autoPositionPresets === true;
    }

    function normalizePositionRuleDefaults(value, rules = currentPositionRules()) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).filter(([situationId, included]) =>
        included === true && rules[situationId]?.length));
    }

    function currentPositionRuleDefaults(rules = currentPositionRules()) {
      return normalizePositionRuleDefaults(api.settings.get({ positionRuleDefaults: {} }).positionRuleDefaults, rules);
    }

    function normalizeResiduePrompts(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).flatMap(([key, entry]) =>
        /^situation_(?:fluid|vulva|toy_info)__/.test(key) && entry && typeof entry === 'object'
          && typeof entry.positivePrompt === 'string' && typeof entry.negativePrompt === 'string'
          ? [[key, { positivePrompt: entry.positivePrompt, negativePrompt: entry.negativePrompt }]]
          : []));
    }

    function currentResiduePrompts() {
      return normalizeResiduePrompts(api.settings.get({ residuePrompts: {} }).residuePrompts);
    }

    function residuePromptOverride(imageKey) {
      const prompts = currentResiduePrompts();
      return prompts[imageKey] || prompts[String(imageKey || '').replace(/__vibe-(?:egg|penis)$/, '')];
    }

    function isResidueImageKey(value) {
      return /^situation_(?:fluid|vulva|toy_info)__/.test(String(value || ''));
    }

    function residueBaseImageKey(value) {
      const key = String(value || '');
      const match = key.match(/^(situation_(?:fluid|vulva|toy_info)__.+)__v-(\d+)$/);
      return match && Number(match[2]) >= USER_VARIANT_START ? match[1] : key;
    }

    function residueCharacterFromImageKey(value) {
      return /^situation_(?:fluid|vulva|toy_info)__([a-z][a-z0-9_-]{1,31}?)__/.exec(residueBaseImageKey(value))?.[1] || '';
    }

    function isCustomResidueImageKey(value) {
      const character = residueCharacterFromImageKey(value);
      return Boolean(character) && !['elena', 'mara', 'pippa'].includes(character);
    }

    function residuePartFromImageKey(value) {
      const imageKey = residueBaseImageKey(value);
      if (imageKey.startsWith('situation_vulva__')) return 'vulva';
      return FLUID_PARTS.find(({ part }) => imageKey.includes(`__${part}__`))?.part || '';
    }

    function normalizeResiduePartSources(value) {
      const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
      return Object.fromEntries(FLUID_PARTS.map(({ part }) => [
        part, RESIDUE_PART_SOURCE_VALUES.has(source[part]) ? source[part] : 'generate',
      ]));
    }

    function currentResiduePartSources() {
      return normalizeResiduePartSources(api.settings.get({ residuePartSources: {} }).residuePartSources);
    }

    function saveResiduePartSource(part, source) {
      if (!FLUID_PARTS.some(entry => entry.part === part) || !RESIDUE_PART_SOURCE_VALUES.has(source)) return;
      api.settings.set({ residuePartSources: { ...currentResiduePartSources(), [part]: source } });
      syncResiduePresetPack();
      window.dispatchEvent(new CustomEvent('wayward-image-connection297'));
      scheduleUiScan();
    }

    function residuePresetImageKey(value) {
      const imageKey = residueBaseImageKey(value);
      const source = currentResiduePartSources()[residuePartFromImageKey(imageKey)];
      const character = residueCharacterFromImageKey(imageKey);
      return source && source !== 'generate' && character
        ? imageKey.replace(`__${character}__`, `__${source}__`)
        : String(value || '');
    }

    function residueReferenceImageKey(value, context = currentWifePromptContext()) {
      const imageKey = residueBaseImageKey(value);
      const character = residueCharacterFromImageKey(imageKey);
      if (!character || ['elena', 'mara', 'pippa'].includes(character)) return imageKey;
      const sources = [context.archetype?.basedOn, context.character?.generatedArchetype?.basedOn,
        context.character?.archetypeId, context.archetype?.id];
      const reference = sources.map(source => String(source || '').toLocaleLowerCase()
        .match(/(?:^|_)(elena|mara|pippa)(?:_|$)/)?.[1]).find(Boolean) || 'pippa';
      return imageKey.replace(`__${character}__`, `__${reference}__`);
    }

    function residueExpressionImageKey(value) {
      return residueBaseImageKey(value).replace(/^(situation_fluid__.+?__mouth__stage-\d+)__vibe-(?:egg|penis)$/, '$1');
    }

    function residueReferencePromptKey(value, context = currentWifePromptContext()) {
      return residueReferenceImageKey(residueBaseImageKey(value).replace(/__vibe-(?:egg|penis)$/, ''), context);
    }

    function residuePromptPackEntry(imageKey) {
      const packs = globalThis.__WAYWARD_SITUATION_PROMPT_PACKS__ || [];
      for (let index = packs.length - 1; index >= 0; index -= 1) {
        const entry = packs[index]?.entries?.[imageKey];
        if (entry && typeof entry.prompt === 'string' && entry.prompt) return entry;
      }
      return null;
    }

    async function loadResiduePromptPackEntry(imageKey) {
      const existing = residuePromptPackEntry(imageKey);
      if (existing) return existing;
      const character = residueCharacterFromImageKey(imageKey);
      const file = imageKey.startsWith('situation_toy_info__')
        ? 'prompts-situation-toys.js'
        : ['elena', 'mara', 'pippa'].includes(character) ? `prompts-situation-${character}-info.js` : '';
      if (!file || typeof document === 'undefined' || !document.head) return null;
      if (!residuePromptPackLoads.has(file)) {
        residuePromptPackLoads.set(file, new Promise((resolve, reject) => {
          const script = document.createElement('script');
          script.src = new URL(`wml/mods/h-status/${file}`, document.baseURI).href;
          script.onload = () => { script.remove(); resolve(); };
          script.onerror = () => { script.remove(); reject(new Error(`H-Status 프롬프트 팩을 불러오지 못했습니다: ${file}`)); };
          document.head.append(script);
        }));
      }
      try {
        await residuePromptPackLoads.get(file);
      } catch (error) {
        residuePromptPackLoads.delete(file);
        console.warn('[attention-image-prompt] H-Status prompt pack', error);
      }
      return residuePromptPackEntry(imageKey);
    }

    function specializeResiduePrompt(prompt, negativePrompt, imageKey, rebuildUterus = false) {
      const part = residuePartFromImageKey(imageKey);
      const uterus = imageKey.includes('__uterus__');
      const vulva = imageKey.startsWith('situation_vulva__') || imageKey.includes('__vulva__');
      const breasts = imageKey.includes('__breasts__');
      const thighs = imageKey.includes('__thighs__');
      const eggToy = imageKey.startsWith('situation_toy_info__') && imageKey.includes('__vibe-egg__');
      const penisToy = imageKey.startsWith('situation_toy_info__') && imageKey.includes('__vibe-penis__');
      if (part && part !== 'mouth') {
        prompt = promptTokens(prompt).filter(tag => {
          const trait = promptTagIdentity(tag).spaced;
          if (/\b(?:face|head) out of frame\b/.test(trait) || /\b(?:pubic|body|chest) hair\b/.test(trait)) return true;
          return !/\b(?:hair|eyes?|faces?|facial|freckles?|makeup|lips?|mouth|nose|cheeks?|ears?|eyebrows?|eyelashes?|horns?|elf|fangs?|glasses|heterochromia|ribbons?|headwear|hats?)\b/.test(trait);
        }).join(', ');
      }
      if (breasts) {
        prompt = `${withoutPromptTags(prompt, 'three-quarter view, extreme close-up, breast focus')}, ${SECRET_IMAGE_PROMPTS.breastsFrame}`;
        negativePrompt = `${negativePrompt}, ${SECRET_IMAGE_PROMPTS.breastsFrameNegative}`;
        const jewelryStage = Math.max(0, Math.min(3, Number(imageKey.match(/__jewelry-[a-z0-9_-]+-stage-(\d+)/)?.[1]) || 0));
        if (jewelryStage === 3) {
          prompt = `${prompt}, ${SECRET_IMAGE_PROMPTS.breastChoker}`;
          negativePrompt = withoutChokerTags(negativePrompt);
        } else {
          prompt = withoutChokerTags(prompt);
          negativePrompt = `${negativePrompt}, ${SECRET_IMAGE_PROMPTS.chokerNegative}`;
        }
      }
      if (thighs) {
        prompt = withoutPromptTags(prompt, 'three-quarter view, extreme close-up');
        prompt = `${prompt}, ${SECRET_IMAGE_PROMPTS.thighsFrame}`;
        negativePrompt = `${negativePrompt}, ${SECRET_IMAGE_PROMPTS.closeupNegative}`;
      }
      if (vulva) {
        prompt = withoutPromptTags(prompt, 'full body, portrait, upper body, standing, standing pose, fixed frontal camera');
        prompt = `${prompt}, ${SECRET_IMAGE_PROMPTS.vulvaCloseup}`;
        negativePrompt = `${negativePrompt}, ${SECRET_IMAGE_PROMPTS.closeupNegative}, ${SECRET_IMAGE_PROMPTS.statusCameraNegative}`;
      } else if (uterus) {
        const width = imageKey.match(/__width-(\d+)/)?.[1];
        const widthPrompt = width === '0' ? '(one short closed central pink line below the chamber:1.5)'
          : width === '1' ? '(one short narrow central pink gap below the chamber:1.5)'
            : width === '2' ? '(one short moderately open central pink gap below the chamber:1.5)' : '';
        const stage = Math.max(0, Math.min(4, Number(imageKey.match(/__(?:stage|inside)-(\d+)/)?.[1]) || 0));
        const stagePrompt = SECRET_IMAGE_PROMPTS[`uterusStage${stage}`];
        const toyPrompt = eggToy ? SECRET_IMAGE_PROMPTS.eggUterus : penisToy ? SECRET_IMAGE_PROMPTS.penisUterus : '';
        if (rebuildUterus) {
          const identity = residueVisibleWifeTraits(currentWifeCharacterPrompt().positivePrompt, imageKey);
          prompt = [
            'masterpiece, best quality, score_7, absurdres, game cg, anime coloring, exactly one adult woman',
            identity,
            SECRET_IMAGE_PROMPTS.uterusCutaway,
            widthPrompt,
            stagePrompt,
            toyPrompt,
            SECRET_IMAGE_PROMPTS.identityConsistency,
          ].filter(Boolean).join(', ');
        } else {
          prompt = withoutPromptTags(prompt, `full body, portrait, upper body, standing, standing pose, fixed frontal camera, ${SECRET_IMAGE_PROMPTS.uterusUnsafePositive}`);
          prompt = `${prompt}, ${SECRET_IMAGE_PROMPTS.uterusCutaway}${widthPrompt ? `, ${widthPrompt}` : ''}${toyPrompt ? `, ${toyPrompt}` : ''}`;
        }
        negativePrompt = `${negativePrompt}, ${SECRET_IMAGE_PROMPTS.closeupNegative}, ${SECRET_IMAGE_PROMPTS.statusCameraNegative}, ${SECRET_IMAGE_PROMPTS.uterusNegative}`;
        if (!eggToy && !penisToy) negativePrompt = `${negativePrompt}, vibrator, dildo, sex toy, retrieval cord`;
        if (eggToy) negativePrompt = `${negativePrompt}, penis-shaped vibrator, long shaft, flared base`;
        if (penisToy) negativePrompt = `${negativePrompt}, ${SECRET_IMAGE_PROMPTS.penisNegative}`;
      }
      if (vulva || uterus) {
        prompt = `${prompt}, ${SECRET_IMAGE_PROMPTS.naturalSkinToneGuard}`;
        negativePrompt = `${negativePrompt}, ${SECRET_IMAGE_PROMPTS.skinColorNegative}`;
      }
      if (vulva) {
        prompt = `${prompt}, ${SECRET_IMAGE_PROMPTS.vulvaVisibilityGuard}`;
        negativePrompt = `${negativePrompt}, ${SECRET_IMAGE_PROMPTS.vulvaVisibilityNegative}`;
      }
      if (penisToy && (vulva || uterus)) {
        prompt = `${prompt}, ${SECRET_IMAGE_PROMPTS.penisToyColorGuard}`;
      }
      if (penisToy && vulva) {
        prompt = withoutPromptTags(prompt, 'two thirds of the device hidden inside, only the lower third and flared base visible, lower shaft and flared base visible');
        prompt = `${prompt}, ${SECRET_IMAGE_PROMPTS.penisToyVulvaContact}`;
        negativePrompt = `${negativePrompt}, ${SECRET_IMAGE_PROMPTS.penisToyVulvaNegative}`;
      }
      return { prompt: deduplicatePrompt(prompt), negativePrompt: deduplicatePrompt(negativePrompt) };
    }

    function residueVisibleWifeTraits(value, imageKey) {
      const part = residuePartFromImageKey(imageKey);
      const face = /\b(?:hair|eyes?|faces?|facial|skin|complexion|freckles?|moles?|birthmarks?|scars?|makeup|lips?|mouth|nose|cheeks?|ears?|eyebrows?|eyelashes?|horns?|elf|fangs?|glasses|heterochromia|ribbons?|headwear|hats?|tan|pale)\b/;
      const chest = /\b(?:skin|complexion|breasts?|bust|chest|nipples?|areolas?|torso|cleavage|body|build|figure|curv\w*|slim|slender|skinny|petite|athletic|muscular|tan|pale|chokers?|necklaces?)\b/;
      const lower = /\b(?:skin|complexion|waist|hips?|thighs?|legs?|pubic|vulva|pussy|labia|clitoris|genitals?|abdomen|stomach|navel|body|build|figure|curv\w*|slim|slender|skinny|petite|athletic|muscular|tan|pale|tails?|wings?)\b/;
      return promptTokens(value).filter(tag => {
        const trait = promptTagIdentity(tag).spaced;
        if (part === 'mouth') return face.test(trait);
        if (part === 'breasts') return chest.test(trait)
          || (/\b(?:tattoos?|scars?|moles?|birthmarks?|pierc\w*)\b/.test(trait) && /\b(?:breasts?|bust|chest|nipples?|areolas?|torso|cleavage)\b/.test(trait));
        return lower.test(trait)
          || (/\b(?:tattoos?|scars?|moles?|birthmarks?|pierc\w*)\b/.test(trait) && /\b(?:waist|hips?|thighs?|legs?|pubic|vulva|labia|genitals?|abdomen|stomach|navel)\b/.test(trait));
      }).join(', ');
    }

    function withoutReferenceAppearanceTraits(value) {
      const appearance = /\b(?:hair|eyes?|faces?|facial|skin|complexion|freckles?|moles?|birthmarks?|scars?|tattoos?|pierc\w*|makeup|lips?|nose|cheeks?|ears?|eyebrows?|eyelashes?|horns?|elf|fangs?|glasses|heterochromia|ribbons?|headwear|hats?|tails?|wings?|chokers?|necklaces?|waist|hips?|thighs?|legs?|pubic|vulva|pussy|labia|clitoris|genitals?|abdomen|stomach|navel|breasts?|bust|chest|nipples?|areolas?|torso|cleavage|body|build|figure|curv\w*|slim|slender|skinny|petite|athletic|muscular|tan|pale|tall)\b/;
      const defect = /\b(?:bad|extra|multiple|missing|fused|duplicate|deformed|malformed|misaligned|exaggerated|child|chibi|bodybuilder)\b/;
      const statusPlacement = /\b(?:hidden|covered|uncovered|out of frame|left|right|single|two|both|missing|unpierced|pierced|jewelry|stud|barbell)\b/;
      const statusPart = /\b(?:vulva|pussy|labia|clitoris|nipples?|breasts?)\b/;
      return promptTokens(value).filter(tag => {
        const trait = promptTagIdentity(tag).spaced;
        if (/^(?:tattoo|piercing|body jewelry)$/.test(trait)) return true;
        if (statusPlacement.test(trait) && statusPart.test(trait)) return true;
        return defect.test(trait) || !appearance.test(trait);
      }).join(', ');
    }

    function composeResidueReferencePrompt(entry, referenceImageKey, imageKey = referenceImageKey) {
      const wife = currentWifeCharacterPrompt();
      const identity = residueVisibleWifeTraits(wife.positivePrompt, imageKey);
      let prompt = withoutPromptTags(String(entry?.prompt || ''), '768 by 576 landscape composition');
      if (identity) {
        prompt = prompt.includes('{{character_prompt}}')
          ? prompt.replaceAll('{{character_prompt}}', identity)
          : `${prompt}, ${identity}`;
      }
      prompt = `${prompt}, ${SECRET_IMAGE_PROMPTS.identityConsistency}${residuePartFromImageKey(imageKey) === 'mouth' ? `, ${SECRET_IMAGE_PROMPTS.faceIdentityConsistency}` : ''}`;
      let negativePrompt = withoutReferenceAppearanceTraits(entry?.negativePrompt || '');
      if (/\btattoo\b/.test(identity)) negativePrompt = withoutPromptTags(negativePrompt, 'tattoo');
      if (/\bpierc/.test(identity)) negativePrompt = withoutPromptTags(negativePrompt, 'piercing');
      const specialized = specializeResiduePrompt(prompt.replaceAll('{{character_prompt}}', ''), negativePrompt, imageKey, true);
      return {
        ...entry,
        ...SECRET_IMAGE_PROFILE,
        prompt: specialized.prompt,
        negativePrompt: deduplicatePrompt(`${specialized.negativePrompt}, ${residueVisibleWifeTraits(wife.negativePrompt, imageKey)}`),
        source: 'attention-image-prompt-secret-reference',
        referenceImageKey,
      };
    }

    function normalizeResidueImageChoices(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      const normalized = {};
      for (const [rawKey, entry] of Object.entries(value)) {
        const imageKey = residueBaseImageKey(rawKey);
        if (!isResidueImageKey(imageKey) || !entry || typeof entry !== 'object') continue;
        const seen = new Set();
        const items = (Array.isArray(entry.items) ? entry.items : []).flatMap(item => {
          const key = String(item?.key || '');
          const url = String(item?.url || '').trim();
          if (!url || residueBaseImageKey(key) !== imageKey || key === imageKey || seen.has(key)) return [];
          seen.add(key);
          return [{ key, url, createdAt: Math.max(0, Number(item.createdAt) || Number(key.match(/__v-(\d+)$/)?.[1]) || 0) }];
        });
        const selected = items.some(item => item.key === entry.selected) ? entry.selected : '';
        if (items.length) normalized[imageKey] = { selected, items };
      }
      return normalized;
    }

    function normalizeHiddenResidueImages(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).flatMap(([rawKey, items]) => {
        const imageKey = residueBaseImageKey(rawKey);
        if (!isResidueImageKey(imageKey) || !Array.isArray(items)) return [];
        const hidden = [...new Set(items.map(String).filter(key => residueBaseImageKey(key) === imageKey))].slice(-100);
        return hidden.length ? [[imageKey, hidden]] : [];
      }));
    }

    function currentHiddenResidueImages() {
      const hidden = normalizeHiddenResidueImages(api.settings.get({ residueImageHidden: {} }).residueImageHidden);
      for (const itemKey of runtimeHiddenResidueImages) {
        const imageKey = residueBaseImageKey(itemKey);
        hidden[imageKey] = [...new Set([...(hidden[imageKey] || []), itemKey])].slice(-100);
      }
      return hidden;
    }

    function currentResidueImageChoices() {
      if (imageStudioOwnsSelection()) return {};
      const choices = normalizeResidueImageChoices(api.settings.get({ residueImageChoices: {} }).residueImageChoices);
      const runtime = normalizeResidueImageChoices(runtimeResidueImageChoices);
      const hidden = currentHiddenResidueImages();
      for (const [imageKey, entry] of Object.entries(runtime)) {
        const current = choices[imageKey] || { selected: '', items: [] };
        const items = [...entry.items, ...current.items].filter((item, index, all) =>
          !hidden[imageKey]?.includes(item.key) && all.findIndex(candidate => candidate.key === item.key) === index);
        if (items.length) choices[imageKey] = {
          selected: items.some(item => item.key === entry.selected) ? entry.selected : '',
          items,
        };
      }
      for (const [imageKey, entry] of Object.entries(choices)) {
        entry.items = entry.items.filter(item => !hidden[imageKey]?.includes(item.key));
        if (!entry.items.some(item => item.key === entry.selected)) entry.selected = '';
        if (!entry.items.length) delete choices[imageKey];
      }
      return choices;
    }

    function compactResidueImageChoices(choices) {
      return Object.fromEntries(Object.entries(normalizeResidueImageChoices(choices)).flatMap(([imageKey, entry]) => {
        const selected = entry.items.find(item => item.key === entry.selected);
        return selected ? [[imageKey, { selected: selected.key, items: [selected] }]] : [];
      }));
    }

    function persistResidueImageChoices(choices) {
      api.settings.set({ residueImageChoices: compactResidueImageChoices(choices) });
    }

    function saveResidueImageChoice(imageKey, item) {
      const choices = currentResidueImageChoices();
      const current = choices[imageKey] || { selected: '', items: [] };
      const next = {
        ...choices,
        [imageKey]: {
          selected: item.key,
          items: [item, ...current.items.filter(entry => entry.key !== item.key)],
        },
      };
      runtimeResidueImageChoices = next;
      persistResidueImageChoices(next);
    }

    function selectResidueImage(imageKey, selected) {
      const choices = currentResidueImageChoices();
      const current = choices[imageKey];
      if (!current) return;
      const next = {
        ...choices,
        [imageKey]: { ...current, selected: current.items.some(item => item.key === selected) ? selected : '' },
      };
      runtimeResidueImageChoices = next;
      persistResidueImageChoices(next);
      scheduleUiScan();
    }

    function removeResidueImageChoice(imageKey, itemKey) {
      const choices = currentResidueImageChoices();
      const current = choices[imageKey];
      if (!current) return;
      const items = current.items.filter(item => item.key !== itemKey);
      if (items.length === current.items.length) return;
      runtimeHiddenResidueImages.add(itemKey);
      const next = { ...choices };
      if (items.length) next[imageKey] = { selected: current.selected === itemKey ? '' : current.selected, items };
      else delete next[imageKey];
      runtimeResidueImageChoices = next;
      api.settings.set({
        residueImageChoices: compactResidueImageChoices(next),
        residueImageHidden: currentHiddenResidueImages(),
      });
      scheduleUiScan();
    }

    async function discoverResidueImageChoices(imageKey, reset = false) {
      if (!api.has('imageManifest')) return 0;
      if (reset && api.has('imageManifestReset')) api.fn('imageManifestReset')();
      const hidden = new Set(currentHiddenResidueImages()[imageKey] || []);
      const discovered = manifestImageEntries(await api.fn('imageManifest')()).flatMap(entry => {
        const key = String(entry?.talentName || '');
        const variant = Number(key.match(/__v-(\d+)$/)?.[1]);
        const url = imageEntryUrl(entry);
        return key !== imageKey && variant >= USER_VARIANT_START && residueBaseImageKey(key) === imageKey && url && !hidden.has(key)
          ? [{ key, url, createdAt: Number(entry.createdAt) || variant }]
          : [];
      }).sort((left, right) => right.createdAt - left.createdAt);
      if (!discovered.length) return 0;
      const current = currentResidueImageChoices()[imageKey] || { selected: '', items: [] };
      runtimeResidueImageChoices = {
        ...runtimeResidueImageChoices,
        [imageKey]: {
          selected: current.selected,
          items: [...discovered, ...current.items].filter((item, index, all) =>
            all.findIndex(candidate => candidate.key === item.key) === index),
        },
      };
      return discovered.length;
    }

    const savedResidueImageChoices = normalizeResidueImageChoices(api.settings.get({ residueImageChoices: {} }).residueImageChoices);
    const compactedResidueImageChoices = compactResidueImageChoices(savedResidueImageChoices);
    if (JSON.stringify(savedResidueImageChoices) !== JSON.stringify(compactedResidueImageChoices)) {
      api.settings.set({ residueImageChoices: compactedResidueImageChoices });
    }

    function wifeImageName(value) {
      const name = String(value || '').trim().toLocaleLowerCase()
        .replace(/['’]/g, '')
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '');
      return /[a-z]/.test(name) ? name : '';
    }

    function wifeDialogueArchetypeId(inputs) {
      if (!Object.prototype.hasOwnProperty.call(inputs || {}, '__attentionExtraLinesArchetypeId')) return EXTRA_LINES_DIALOGUE_SOURCES[0][0];
      const value = String(inputs.__attentionExtraLinesArchetypeId || '');
      return EXTRA_LINES_DIALOGUE_SOURCES.some(([id]) => id === value) ? value : '';
    }

    function wifeOutfitColors(inputs) {
      const saved = inputs?.__attentionImageOutfitColors;
      const valid = value => {
        const color = String(value || '');
        return OUTFIT_COLOR_OPTIONS.some(([id]) => id === color) ? color : '';
      };
      return {
        primary: valid(saved?.primary),
        secondary1: valid(saved?.secondary1),
        secondary2: valid(saved?.secondary2),
      };
    }

    function wifeOutfitColorPrompt(inputs) {
      const colors = wifeOutfitColors(inputs);
      const used = new Set();
      return [
        ['primary', 'clothing'], ['secondary1', 'trim'], ['secondary2', 'accents'],
      ].flatMap(([key, suffix]) => {
        const color = colors[key];
        if (!color || used.has(color)) return [];
        used.add(color);
        return [`${color} ${suffix}`];
      }).join(', ');
    }
