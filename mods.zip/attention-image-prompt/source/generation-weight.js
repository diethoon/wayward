    function generationWeightSettings() {
      let saved;
      try { saved = api.settings.get({ generationWeightEnabled: false, generationWeightPercent: 100,
        generationWeightStepsPercent: null, generationWeightCfgPercent: null, generationWeightLoraPercent: null }); }
      catch { saved = {}; }
      const value = saved?.generationWeightPercent;
      const percent = typeof value === 'number' && Number.isFinite(value)
        ? Math.max(0, Math.min(200, Math.round(value))) : 100;
      const individual = value => typeof value === 'number' && Number.isFinite(value)
        ? Math.max(0, Math.min(200, Math.round(value))) : percent;
      return { enabled: saved?.generationWeightEnabled === true, percent,
        stepsPercent: individual(saved?.generationWeightStepsPercent), cfgPercent: individual(saved?.generationWeightCfgPercent),
        loraPercent: individual(saved?.generationWeightLoraPercent) };
    }

    function generationWeightForPrompt(prompt, percent = 100) {
      if (typeof prompt !== 'string' || !prompt.trim()) return null;
      const count = prompt.split(',').map(tag => tag.trim()).filter(Boolean).length;
      const original = count <= 40 ? { steps: 8, cfg: 1.5, loraStrength: 1 }
        : count <= 60 ? { steps: 12, cfg: 2, loraStrength: 0.9 }
          : { steps: 18, cfg: 2.5, loraStrength: 0.8 };
      const scale = value => typeof value === 'number' && Number.isFinite(value)
        ? Math.max(0, Math.min(200, Math.round(value))) / 100 : 1;
      const values = typeof percent === 'object' && percent ? percent :
        { stepsPercent: percent, cfgPercent: percent, loraPercent: percent };
      const decimal = value => Math.round((value + Number.EPSILON) * 100) / 100;
      return { steps: Math.round(8 + (original.steps - 8) * scale(values.stepsPercent)),
        cfg: decimal(1.5 + (original.cfg - 1.5) * scale(values.cfgPercent)),
        loraStrength: decimal(1 + (original.loraStrength - 1) * scale(values.loraPercent)) };
    }

    function generationWeightStyleLockActive() {
      let loaded;
      try { loaded = globalThis.WML?.status?.()?.loaded; }
      catch { return true; }
      if (!Array.isArray(loaded) || !loaded.includes('style-lock')) return false;
      try {
        const stored = globalThis.localStorage?.getItem('wml.mod.style-lock');
        return !stored || JSON.parse(stored)?.lockParams !== false;
      } catch { return true; }
    }

    function generationWeightCurrentPortraitPrompt() {
      const state = api.store.game();
      const snapshot = latestScenePrompt;
      if (!state || !snapshot?.result?.prompt || snapshot.characterId !== state.primaryCharacterId) return null;
      const current = activePortraitImageKey('', state);
      if (!current || similarImageSituationKey(current) !== similarImageSituationKey(snapshot.result.key)) return null;
      return snapshot.result.prompt;
    }

    function generationWeightAdjustRequest(request) {
      const settings = generationWeightSettings();
      if (!settings.enabled || generationWeightStyleLockActive() || !request || typeof request !== 'object'
        || typeof request.imageKey !== 'string' || !request.imageKey || typeof request.prompt !== 'string' || !request.prompt.trim()
        || request.bulk === true || (request.imageType && request.imageType !== 'portrait')
        || request.imageData || request.referenceKey || request.referenceImage || request.initImage
        || request.mask || request.denoise !== undefined) return request;
      const source = request.debug?.source;
      if (source && source !== 'attention-image-prompt-position') return request;
      if (!source && !request.debug?.stats) {
        // Native redraw requests lack debug stats; restrict them to the current portrait.
        let current = '';
        try { current = activePortraitImageKey('', api.store.game()); } catch { return request; }
        if (!current || similarImageSituationKey(current) !== similarImageSituationKey(request.imageKey)) return request;
      }
      return { ...request, ...generationWeightForPrompt(request.prompt, settings) };
    }
