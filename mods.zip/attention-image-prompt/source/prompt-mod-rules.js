    const externalPromptRegistry = new Map();
    const externalIdValid = value => typeof value === 'string' && /^[a-z0-9._-]{1,80}$/i.test(value);
    const externalText = value => typeof value === 'string' ? value.slice(0, 12000) : '';

    function normalizeExternalPromptData(value) {
      if (!Array.isArray(value)) return [];
      const entries = new Map();
      const fieldKeys = new Set(externalFields().map(field => field.key));
      for (const item of value.slice(0, 1000)) {
        if (!externalIdValid(item?.owner) || !externalIdValid(item?.id)) continue;
        const next = { owner: item.owner, id: item.id, source: item.source === 'mod' ? 'mod' : 'aip' };
        if (typeof item.aipField === 'string' && externalValidBinding(item.aipField, fieldKeys)) next.aipField = item.aipField;
        if (typeof item.positivePrompt === 'string') next.positivePrompt = externalText(item.positivePrompt);
        if (typeof item.negativePrompt === 'string') next.negativePrompt = externalText(item.negativePrompt);
        if (typeof item.topPrompt === 'string') next.topPrompt = externalText(item.topPrompt);
        if (typeof item.skirtPrompt === 'string') next.skirtPrompt = externalText(item.skirtPrompt);
        entries.set(`${item.owner}/${item.id}`, next);
      }
      return [...entries.values()];
    }

    function currentExternalPromptData() {
      return normalizeExternalPromptData(api.settings.get({ externalPromptData: [] }).externalPromptData);
    }

    function normalizeExternalPromptPresets(value) {
      if (!Array.isArray(value)) return [];
      return value.slice(0, 200).flatMap(preset => {
        if (!externalIdValid(preset?.id) || !externalIdValid(preset?.modId) || typeof preset.name !== 'string'
          || !preset.name.trim() || !Array.isArray(preset.entries)) return [];
        const entries = preset.entries.slice(0, 300).flatMap(entry => externalIdValid(entry?.id) ? [{
          id: entry.id, source: entry.source === 'mod' ? 'mod' : 'aip',
          positivePrompt: externalText(entry.positivePrompt), negativePrompt: externalText(entry.negativePrompt),
          ...(typeof entry.topPrompt === 'string' ? { topPrompt: externalText(entry.topPrompt) } : {}),
          ...(typeof entry.skirtPrompt === 'string' ? { skirtPrompt: externalText(entry.skirtPrompt) } : {}),
          ...(externalIdValid(entry.providerOwner) && externalIdValid(entry.providerEntryId)
            ? { providerOwner: entry.providerOwner, providerEntryId: entry.providerEntryId } : {}),
        }] : []);
        return [{ id: preset.id, modId: preset.modId, name: preset.name.trim().slice(0, 120), entries }];
      });
    }

    function currentExternalPromptPresets() {
      return normalizeExternalPromptPresets(api.settings.get({ externalPromptPresets: [] }).externalPromptPresets);
    }

    function externalFields() {
      return FIELD_GROUPS.flatMap(group => group.fields.map(field => ({ key: field.key, label: field.label, group: group.title })));
    }

    function notifyExternalPromptChange() {
      if (typeof globalThis.dispatchEvent === 'function' && typeof CustomEvent === 'function')
        globalThis.dispatchEvent(new CustomEvent('attention-image-prompt:change'));
    }

    function registerExternalPromptMenu(definition) {
      if (!externalIdValid(definition?.id) || typeof definition.title !== 'string' || !definition.title.trim()
        || !Array.isArray(definition.entries) || !definition.entries.length || definition.entries.length > 300)
        throw new TypeError('Invalid AIP prompt registration');
      const fields = new Set(externalFields().map(field => field.key));
      const seen = new Set();
      const entries = definition.entries.map(entry => {
        const binding = entry?.target ? externalTargetBinding(entry.target) : '';
        if (!externalIdValid(entry?.id) || seen.has(entry.id) || typeof entry.label !== 'string' || !entry.label.trim()
          || (entry.aipField && !fields.has(entry.aipField)) || (entry.target && (!binding || entry.aipField)))
          throw new TypeError('Invalid AIP prompt entry');
        seen.add(entry.id);
        return { id: entry.id, label: entry.label.trim().slice(0, 120), hook: String(entry.hook || '').slice(0, 120),
          aipField: binding || entry.aipField || '', ...(binding ? { target: { kind: entry.target.kind, id: entry.target.id } } : {}),
          positivePrompt: externalText(entry.positivePrompt), negativePrompt: externalText(entry.negativePrompt),
          ...(entry.target?.kind === 'outfit' ? { topPrompt: externalText(entry.topPrompt), skirtPrompt: externalText(entry.skirtPrompt) } : {}) };
      });
      const previousEntries = externalPromptRegistry.get(definition.id)?.entries || [];
      externalPromptRegistry.set(definition.id, { id: definition.id, title: definition.title.trim().slice(0, 120),
        note: String(definition.note || '').slice(0, 500), entries });
      previousEntries.forEach(externalTargetChanged);
      entries.forEach(externalTargetChanged);
      notifyExternalPromptChange();
      settingsWindowHandle?.refresh?.();
      return () => { if (externalPromptRegistry.get(definition.id)?.entries === entries) {
        externalPromptRegistry.delete(definition.id); entries.forEach(externalTargetChanged); notifyExternalPromptChange(); settingsWindowHandle?.refresh?.();
      } };
    }

    function externalEntry(owner, id) {
      return externalPromptRegistry.get(owner)?.entries.find(entry => entry.id === id) || null;
    }

    function externalFieldProviders(data = currentExternalPromptData()) {
      const selected = new Set(data.filter(item => item.source === 'mod').map(item => `${item.owner}/${item.id}`));
      const providers = new Map();
      for (const menu of externalPromptRegistry.values()) for (const item of menu.entries) {
        const key = `${menu.id}/${item.id}`;
        if (!item.aipField || !selected.has(key)) continue;
        const previous = providers.get(item.aipField);
        if (!previous || key < previous.key) providers.set(item.aipField, { key, id: menu.id, title: menu.title, entryId: item.id });
      }
      return providers;
    }

    function externalEffectiveSource(owner, id, data = currentExternalPromptData(), providers = externalFieldProviders(data)) {
      const entry = externalEntry(owner, id);
      if (!entry) return null;
      if (!entry.aipField) return 'mod';
      return providers.get(entry.aipField)?.key === `${owner}/${id}` ? 'mod' : 'aip';
    }

    function resolveExternalPrompt(owner, id, source, data) {
      const entry = externalEntry(owner, id);
      if (!entry) return null;
      const saved = (data || currentExternalPromptData()).find(item => item.owner === owner && item.id === id);
      const selected = entry.aipField && (source || externalEffectiveSource(owner, id)) === 'aip' ? 'aip' : 'mod';
      const target = selected === 'aip' && entry.target ? externalTargetAdapters.get(entry.target.kind)?.read(entry.target.id) : null;
      const active = selected === 'aip' && !entry.target ? activeSituationConfig() : null;
      return { source: selected,
        positivePrompt: selected === 'aip' ? entry.target ? target?.positivePrompt ?? '' : active.prompts[entry.aipField] ?? '' : saved?.positivePrompt ?? entry.positivePrompt,
        negativePrompt: selected === 'aip' ? entry.target ? target?.negativePrompt ?? '' : active.negativePrompts[entry.aipField] ?? '' : saved?.negativePrompt ?? entry.negativePrompt,
        ...(entry.target ? { unavailable: !externalTargetAdapters.get(entry.target.kind)?.read(entry.target.id) } : {}),
        ...(entry.target?.kind === 'outfit' ? {
          topPrompt: selected === 'aip' ? target?.topPrompt ?? '' : saved?.topPrompt ?? entry.topPrompt,
          skirtPrompt: selected === 'aip' ? target?.skirtPrompt ?? '' : saved?.skirtPrompt ?? entry.skirtPrompt,
        } : {}) };
    }

    function externalPromptMenus() {
      const providers = externalFieldProviders();
      return [...externalPromptRegistry.values()].map(menu => ({ ...menu, entries: menu.entries.map(entry => ({
        ...entry, ...resolveExternalPrompt(menu.id, entry.id),
        activeProvider: entry.aipField ? providers.get(entry.aipField) || null : null,
        defaultPositivePrompt: entry.positivePrompt, defaultNegativePrompt: entry.negativePrompt,
      })) }));
    }

    function setExternalPromptSource(owner, id, source) {
      const entry = externalEntry(owner, id);
      if (!entry || !entry.aipField || !['aip', 'mod'].includes(source)) return false;
      let data = currentExternalPromptData();
      data = data.map(item => {
        const other = externalEntry(item.owner, item.id);
        return (other?.aipField || item.aipField) === entry.aipField && (item.owner !== owner || item.id !== id)
          ? { ...item, source: 'aip' } : item;
      });
      const previous = data.find(item => item.owner === owner && item.id === id) || { owner, id };
      api.settings.set({ externalPromptData: [...data.filter(item => item !== previous), { ...previous, source, aipField: entry.aipField }] });
      externalTargetChanged(entry);
      notifyExternalPromptChange();
      return true;
    }

    function saveExternalPrompt(owner, id, source, changes) {
      const entry = externalEntry(owner, id);
      if (!entry || !['aip', 'mod'].includes(source) || source === 'aip' && !entry.aipField) return false;
      if (source === 'aip') {
        if (entry.target) {
          if (!externalTargetAdapters.get(entry.target.kind)?.save(entry.target.id, changes)) return false;
        } else for (const [field, section] of [['positivePrompt', 'prompts'], ['negativePrompt', 'negativePrompts']]) {
          if (typeof changes?.[field] === 'string') saveActiveSituationSection(section,
            { ...activeSituationConfig()[section], [entry.aipField]: externalText(changes[field]) });
        }
      } else {
        const data = currentExternalPromptData();
        const previous = data.find(item => item.owner === owner && item.id === id) || { owner, id, source: entry.aipField ? 'aip' : 'mod' };
        const next = { ...previous };
        for (const field of ['positivePrompt', 'negativePrompt', ...(entry.target?.kind === 'outfit' ? ['topPrompt', 'skirtPrompt'] : [])])
          if (typeof changes?.[field] === 'string') next[field] = externalText(changes[field]);
        api.settings.set({ externalPromptData: [...data.filter(item => item !== previous), next] });
      }
      externalTargetChanged(entry); notifyExternalPromptChange();
      return true;
    }

    function resetExternalPrompt(owner, id, source) {
      const entry = externalEntry(owner, id);
      if (!entry) return false;
      if (source === 'aip' && entry.target) {
        const reset = externalTargetAdapters.get(entry.target.kind)?.reset(entry.target.id);
        if (reset) { externalTargetChanged(entry); notifyExternalPromptChange(); }
        return !!reset;
      }
      if (source === 'aip' && entry.aipField) return saveExternalPrompt(owner, id, source, {
        positivePrompt: DEFAULT_PROMPTS[entry.aipField] ?? '', negativePrompt: DEFAULT_NEGATIVE_PROMPTS[entry.aipField] ?? '',
      });
      if (source !== 'mod') return false;
      const data = currentExternalPromptData();
      api.settings.set({ externalPromptData: data.map(item => item.owner === owner && item.id === id
        ? { owner, id, source: item.source, ...(item.aipField ? { aipField: item.aipField } : {}) } : item) });
      externalTargetChanged(entry); notifyExternalPromptChange();
      return true;
    }

    function externalPromptsForField(prompts, promptField) {
      let result = prompts;
      const data = currentExternalPromptData();
      const providers = externalFieldProviders(data);
      for (const menu of externalPromptRegistry.values()) for (const entry of menu.entries) {
        if (!entry.aipField || entry.target) continue;
        const saved = data.find(item => item.owner === menu.id && item.id === entry.id);
        if (externalEffectiveSource(menu.id, entry.id, data, providers) !== 'mod' || prompts[entry.aipField] === null) continue;
        if (result === prompts) result = { ...prompts };
        result[entry.aipField] = saved?.[promptField] ?? entry[promptField];
      }
      return result;
    }

    function externalFieldCacheSignature(config) {
      const values = [];
      const data = currentExternalPromptData();
      const providers = externalFieldProviders(data);
      for (const menu of externalPromptRegistry.values()) for (const entry of menu.entries) {
        if (!entry.aipField || !entry.target && !config) continue;
        const source = externalEffectiveSource(menu.id, entry.id, data, providers);
        const saved = data.find(item => item.owner === menu.id && item.id === entry.id);
        const target = entry.target && externalTargetAdapters.get(entry.target.kind)?.read(entry.target.id);
        values.push([menu.id, entry.id, entry.aipField, source,
          source === 'mod' ? saved?.positivePrompt ?? entry.positivePrompt : entry.target ? target?.positivePrompt ?? '' : config.prompts[entry.aipField] ?? '',
          source === 'mod' ? saved?.negativePrompt ?? entry.negativePrompt : entry.target ? target?.negativePrompt ?? '' : config.negativePrompts[entry.aipField] ?? '',
          ...(entry.target?.kind === 'outfit' ? [source === 'mod' ? saved?.topPrompt ?? entry.topPrompt : target?.topPrompt ?? '',
            source === 'mod' ? saved?.skirtPrompt ?? entry.skirtPrompt : target?.skirtPrompt ?? ''] : [])]);
      }
      values.sort((a, b) => `${a[0]}/${a[1]}`.localeCompare(`${b[0]}/${b[1]}`));
      // shortcut: all linked fields share a cache signature; narrow it when every state exposes field provenance.
      return values.length ? shortHash(JSON.stringify(values)) : '';
    }

    function promptTokens(value) {
      return [...new Set(String(value || '').split(/\r?\n/).flatMap(line => {
        const prompt = line.includes('=') ? line.slice(line.indexOf('=') + 1) : line;
        return prompt.split(',');
      }).map(tag => tag.trim()).filter(Boolean))];
    }

    function normalizePromptModRules(value) {
      if (!Array.isArray(value)) return [];
      const rules = new Map();
      for (const entry of value.slice(0, 400)) {
        const owner = String(entry?.owner || '').trim();
        const tag = String(entry?.tag || '').trim();
        const polarity = entry?.polarity;
        const source = entry?.source;
        const scope = String(entry?.scope || '').trim();
        if (!/^[a-z0-9_-]{1,80}$/i.test(owner) || !tag || tag.length > 300 || /[\r\n]/.test(tag)
          || !['positive', 'negative'].includes(polarity) || !['current', 'without', 'add'].includes(source)
          || (scope && (scope.length > 120 || !/^[\p{L}\p{N}_ -]+(?:\|[\p{L}\p{N}_ -]+)*$/u.test(scope)))) continue;
        const replacement = String(entry.replacement || '').trim().slice(0, 300);
        if (/[\r\n]/.test(replacement)) continue;
        rules.set(JSON.stringify([owner, polarity, source, tag, scope]), {
          owner, polarity, source, tag, scope,
          enabled: source === 'current' ? entry.enabled !== false : entry.enabled === true,
          replacement,
          korean: String(entry.korean || '').trim().slice(0, 100),
        });
      }
      return [...rules.values()];
    }

    let promptModRulesCache = normalizePromptModRules(api.settings.get({ promptModRules: [] }).promptModRules);
    let promptModOwnersCache = null;
    const promptModFingerprintCache = new Map();

    function reloadPromptModRules() {
      promptModRulesCache = normalizePromptModRules(api.settings.get({ promptModRules: [] }).promptModRules);
      promptModFingerprintCache.clear();
    }

    function currentPromptModRules() {
      return promptModRulesCache;
    }

    function writePromptModRules(rules) {
      const previous = promptModRulesCache;
      promptModRulesCache = normalizePromptModRules(rules);
      promptModFingerprintCache.clear();
      try { api.settings.set({ promptModRules: promptModRulesCache }); }
      catch (error) {
        promptModRulesCache = previous;
        promptModFingerprintCache.clear();
        throw error;
      }
    }

    function loadedPromptModOwners() {
      const status = globalThis.WML?.status;
      if (promptModOwnersCache && promptModOwnersCache.status === status) return promptModOwnersCache.loaded;
      let loaded = [];
      try {
        const current = typeof status === 'function' ? status.call(globalThis.WML) : null;
        if (Array.isArray(current?.loaded)) loaded = current.loaded;
      } catch { /* ignore unavailable WML status */ }
      promptModOwnersCache = { status, loaded: new Set(loaded) };
      promptModFingerprintCache.clear();
      return promptModOwnersCache.loaded;
    }

    if (typeof api.afterEachSetup === 'function') api.afterEachSetup(() => {
      promptModOwnersCache = null;
      promptModFingerprintCache.clear();
    });

    function effectivePromptModRules(scene) {
      if (!promptModRulesCache.length) return [];
      const loaded = loadedPromptModOwners(), selected = new Map();
      for (const rule of promptModRulesCache) {
        if (!(rule.owner === api.id || loaded.has(rule.owner)) || (rule.scope && rule.scope !== scene)) continue;
        const key = JSON.stringify([rule.owner, rule.polarity, rule.source, rule.tag]);
        if (rule.scope || !selected.has(key)) selected.set(key, rule);
      }
      return [...selected.values()].sort((a, b) => (a.source === 'add') - (b.source === 'add'));
    }

    function promptModRulesFingerprint(situationId) {
      if (!promptModRulesCache.length) return '';
      const scene = typeof situationId === 'string' ? situationId : '';
      loadedPromptModOwners();
      if (promptModFingerprintCache.has(scene)) return promptModFingerprintCache.get(scene);
      const effective = effectivePromptModRules(scene).filter(rule => rule.source === 'current'
        ? !rule.enabled || rule.replacement : rule.enabled);
      const signature = ['positive', 'negative'].map(polarity => effective.filter(rule => rule.polarity === polarity)
        .map(rule => [rule.owner, rule.source, rule.tag, rule.enabled, rule.replacement]));
      const fingerprint = effective.length ? shortHash(JSON.stringify(signature)) : '';
      if (promptModFingerprintCache.size >= 512) promptModFingerprintCache.clear();
      promptModFingerprintCache.set(scene, fingerprint);
      return fingerprint;
    }

    function savePromptModRule(owner, polarity, source, tag, scope, changes) {
      const current = currentPromptModRules();
      const rules = current.filter(rule => !(rule.owner === owner && rule.polarity === polarity
        && rule.source === source && rule.tag === tag && rule.scope === scope));
      const old = current.find(rule => rule.owner === owner && rule.polarity === polarity
        && rule.source === source && rule.tag === tag && rule.scope === scope);
      const next = normalizePromptModRules([{ owner, polarity, source, tag, scope,
        enabled: source === 'current', replacement: '', korean: '', ...old, ...changes }])[0];
      const globalRule = scope && current.some(rule => rule.owner === owner && rule.polarity === polarity
        && rule.source === source && rule.tag === tag && !rule.scope);
      if (next && (globalRule || next.enabled !== (source === 'current') || next.replacement || next.korean)) rules.push(next);
      writePromptModRules(rules);
    }

    function deletePromptModRule(owner, polarity, source, tag, scope) {
      writePromptModRules(currentPromptModRules().filter(rule => !(rule.owner === owner
        && rule.polarity === polarity && rule.source === source && rule.tag === tag && rule.scope === scope)));
    }

    function rewritePromptModTags(value, rules, includeMissing = true) {
      const tags = promptTokens(value);
      let changed = false;
      for (const rule of rules) {
        if (rule.source === 'add') {
          if (rule.enabled && includeMissing) for (const tag of promptTokens(rule.replacement || rule.tag)) {
            if (!tags.includes(tag)) { tags.push(tag); changed = true; }
          }
          continue;
        }
        const index = tags.indexOf(rule.tag);
        const replacement = promptTokens(rule.replacement).slice(0, 8);
        if (rule.source === 'current' && index < 0) continue;
        if (!rule.enabled) {
          if (rule.source === 'current' && index >= 0) { tags.splice(index, 1); changed = true; }
          continue;
        }
        if (index >= 0 && replacement.length) {
          tags.splice(index, 1, ...replacement);
          changed = true;
        } else if (index < 0 && includeMissing && rule.source === 'without') {
          tags.push(...(replacement.length ? replacement : [rule.tag]));
          changed = true;
        }
      }
      return changed ? deduplicatePrompt(tags.join(', ')) : String(value || '');
    }

    function applyPromptModRules(result) {
      // shortcut: identical tags from active mods share one token; use per-tag provenance when WML exposes it.
      const scene = positionSituationId(result?.key);
      const rules = effectivePromptModRules(scene);
      if (!result || !rules.length) return result;
      const positive = rules.filter(rule => rule.polarity === 'positive');
      const negative = rules.filter(rule => rule.polarity === 'negative');
      const prompt = rewritePromptModTags(result.prompt, positive);
      const negativePrompt = rewritePromptModTags(result.negativePrompt, negative);
      if (prompt === result.prompt && negativePrompt === result.negativePrompt) return result;
      const parts = Array.isArray(result.parts) ? result.parts.map(part => ({
        ...part, tags: rewritePromptModTags(part.tags, positive, false),
      })) : result.parts;
      const restored = positive.filter(rule => ['without', 'add'].includes(rule.source) && rule.enabled
        && !promptTokens(result.prompt).includes(rule.tag))
        .flatMap(rule => promptTokens(rule.replacement || rule.tag));
      if (restored.length && Array.isArray(parts)) parts.push({ label: '모드 영향 · 다시 반영', tags: restored.join(', ') });
      return { ...result, prompt, negativePrompt, parts,
        ...(prompt !== result.prompt ? { genParams: promptGenParams(prompt) } : {}) };
    }

    function deduplicatePrompt(value) {
      return deduplicateFinalPrompt(String(value || ''));
    }

    function splitFinalPrompt(value) {
      const tokens = [], separators = [], stack = [];
      const pairs = { ')': '(', ']': '[', '}': '{', '>': '<' };
      let start = 0, escaped = false, quoted = false;
      for (let i = 0; i < value.length; i += 1) {
        const char = value[i];
        if (escaped) { escaped = false; continue; }
        if (char === '\\') { escaped = true; continue; }
        if (char === '"') { quoted = !quoted; continue; }
        if (quoted) continue;
        if ('([{<'.includes(char)) stack.push(char);
        else if (')]}>' .includes(char)) {
          if (stack.pop() !== pairs[char]) return null;
        } else if (!stack.length && (char === ',' || char === '\n' || char === '\r')) {
          tokens.push(value.slice(start, i));
          if (char === '\r' && value[i + 1] === '\n') { separators.push('\r\n'); i += 1; }
          else separators.push(char);
          start = i + 1;
        }
      }
      if (stack.length || quoted || escaped) return null;
      tokens.push(value.slice(start));
      return { tokens, separators };
    }

    function deduplicateFinalPrompt(value) {
      if (typeof value !== 'string' || !value) return value;
      const parsed = splitFinalPrompt(value);
      if (!parsed) return value;
      const { tokens, separators } = parsed;
      const known = new Map(), keep = tokens.map(() => true);
      let changed = false;
      for (const [index, token] of tokens.entries()) {
        const text = token.trim();
        if (!text) continue;
        const wrapped = /^(\(+)\s*([\p{L}\p{N}_' -]+?)(?:\s*:\s*(-?(?:\d+(?:\.\d*)?|\.\d+)))?\s*(\)+)$/u.exec(text);
        const weighted = wrapped && wrapped[1].length === wrapped[4].length ? wrapped : null;
        const simple = weighted?.[2] || (/^[\p{L}\p{N}_' -]+$/u.test(text) ? text : '');
        const key = simple ? `tag:${simple.toLocaleLowerCase().replaceAll('_', ' ').replace(/\s+/g, ' ').trim()}`
          : `literal:${text}`;
        const previous = known.get(key);
        if (!previous) { known.set(key, { index, weighted: Boolean(weighted) }); continue; }
        changed = true;
        if (weighted && !previous.weighted) {
          const prior = tokens[previous.index];
          tokens[previous.index] = `${prior.match(/^\s*/)?.[0] || ''}${text}${prior.match(/\s*$/)?.[0] || ''}`;
          known.set(key, { index: previous.index, weighted: true });
        }
        keep[index] = false;
      }
      if (!changed) return value;
      let output = '', previous = -1;
      for (let i = 0; i < tokens.length; i += 1) if (keep[i]) {
        if (previous < 0) output = `${value.match(/^\s*/)?.[0] || ''}${tokens[i].trimStart()}`;
        else output += `${separators[previous] || ', '}${tokens[i]}`;
        previous = i;
      }
      return output;
    }

    function deduplicateFinalRequest(request) {
      if (!request || typeof request !== 'object') return request;
      const prompt = deduplicateFinalPrompt(request.prompt);
      const negativePrompt = deduplicateFinalPrompt(request.negativePrompt);
      if (prompt === request.prompt && negativePrompt === request.negativePrompt) return request;
      return { ...request, ...(typeof request.prompt === 'string' ? { prompt } : {}),
        ...(typeof request.negativePrompt === 'string' ? { negativePrompt } : {}) };
    }

    function joinPromptWithPriority(next, value, ...args) {
      return next(typeof value === 'string' ? deduplicateFinalPrompt(value) : value, ...args);
    }

    function withoutPromptTags(value, excluded) {
      const blocked = new Set(promptTokens(excluded).map(tag => promptTagIdentity(tag).spaced));
      if (!blocked.size) return String(value || '').trim();
      return promptTokens(value)
        .filter(tag => !blocked.has(promptTagIdentity(tag).spaced))
        .join(', ');
    }

    function withoutUnfinishedPatronAftermath(result, state, character) {
      const scene = state?.activeScene?.patron;
      if (!scene || scene.afterglow || !Number.isFinite(scene.startedAtSlot)
        || !basePositionSituationId(positionSituationId(result?.key)).startsWith('scene-patron_')
        || character?.aftermathTags?.length) return result;
      const ids = new Set([scene.customerId, ...(scene.joinedPatronIds || []),
        ...(scene.crowdPatronIds || [])].filter(Boolean));
      if ((state.customers || []).some(customer => ids.has(customer.id)
        && customer.climaxSlots?.some(slot => slot >= scene.startedAtSlot && slot <= state.slot))) return result;
      const removed = result.parts.filter(part => ['정사 후 정황', 'Aftermath'].includes(part?.label));
      if (!removed.length) return result;
      const parts = result.parts.filter(part => !removed.includes(part));
      const retained = new Set(promptTokens(parts.map(part => part.tags).join(', '))
        .map(tag => promptTagIdentity(tag).spaced));
      const removedOnly = promptTokens(removed.map(part => part.tags).join(', '))
        .filter(tag => !retained.has(promptTagIdentity(tag).spaced)).join(', ');
      const prompt = withoutPromptTags(result.prompt, removedOnly);
      // shortcut: earlier oral residue has no verified source; preserve only a current climax or game aftermath record.
      return { ...result, parts, prompt,
        ...(prompt !== result.prompt ? { genParams: promptGenParams(prompt) } : {}) };
    }

    function withoutConflictingAppearanceNegatives(prompt, negativePrompt) {
      const positive = promptTokens(prompt).map(tag => ` ${promptTagIdentity(tag).spaced} `);
      const pantiesAside = positive.some(value => value.includes(' panties aside '));
      return promptTokens(negativePrompt).filter(tag => {
        const trait = promptTagIdentity(tag).spaced;
        if (pantiesAside && /^(?:underwear|panties)$/.test(trait)) return false;
        return !/\b(?:hair|eyes?|breasts?|shoulders?|skin|tattoo|piercing|dress|skirt|blouse|corset|boots|choker|nipple|panties|underwear|freckles)\b/.test(trait)
          || !positive.some(value => value.includes(` ${trait} `));
      }).join(', ');
    }

    function hasSevereNegativeFeeling(character) {
      return topFeelings(character, 2).some(feeling => Number(feeling.intensity) >= 80
        && /^(?:anger|contempt|disgust|sadness|shame|guilt|regret|humiliation|fear)$/.test(feeling.emotion));
    }

    function hasDistressedExpression(character, groups) {
      return hasSevereNegativeFeeling(character)
        || groups.some(group => group.id === 'attention'
          && group.value.codes.some(code => ['spent', 'trouble', 'escalation'].includes(code)))
        || groups.some(group => group.id === 'detail'
          && group.value.codes.some(code => /^(?:energy-[01]|mood-[01]|wellbeing-[01]|latitude-negative|intoxication-(?:blacked_out|sloppy))$/.test(code)))
        || groups.some(group => group.id === 'erostat'
          && group.value.codes.some(code => /^erostat-(?:vaginal|anal)-(?:full|strain|limit)-/.test(code)))
        || groups.some(group => group.id === 'firstExperience');
    }

    function alignDistressedExpression(result) {
      const cheerful = new Set(['smile', 'gentle smile', 'bright smile', 'playful smile', 'content', 'cheerful', 'energetic', 'pleasure']);
      const removed = [];
      const parts = result.parts.map(part => {
        if (!['장면', 'Scene', '작업', 'Task', '기분', 'Mood'].includes(part.label)) return part;
        const tags = promptTokens(part.tags);
        const kept = tags.filter(tag => {
          if (!cheerful.has(promptTagIdentity(tag).spaced)) return true;
          removed.push(tag);
          return false;
        });
        return kept.length === tags.length ? part : { ...part, tags: kept.join(', ') };
      });
      if (!removed.length) return result;
      const kept = new Set(promptTokens(parts.map(part => part.tags).join(', ')).map(tag => promptTagIdentity(tag).spaced));
      const prompt = withoutPromptTags(result.prompt, removed.filter(tag => !kept.has(promptTagIdentity(tag).spaced)).join(', '));
      return { ...result, prompt, parts, genParams: promptGenParams(prompt) };
    }

    function replaceNativeFirstExperience(result) {
      if (!result?.parts?.length || !globalThis.WML?.status?.().loaded?.includes('virginity-status')) return result;
      const sourceParts = result.parts.filter(part => part.label === '첫 삽입'
        && promptTokens(part.tags).includes(NATIVE_FIRST_EXPERIENCE_TAG));
      if (!sourceParts.length) return result;
      const parts = result.parts.filter(part => !sourceParts.includes(part));
      const keepTag = parts.some(part => promptTokens(part.tags).includes(NATIVE_FIRST_EXPERIENCE_TAG));
      const prompt = keepTag ? result.prompt : promptTokens(result.prompt)
        .filter(tag => tag !== NATIVE_FIRST_EXPERIENCE_TAG).join(', ');
      const key = currentFeaturePrompts().firstExperience ? result.key
        : result.key?.replace(/__virgin_blood(?=__|$)/, '');
      return { ...result, key, prompt, parts, genParams: promptGenParams(prompt) };
    }

    function withoutChokerTags(value, keepHeart = false) {
      return promptTokens(value).filter(tag => {
        const trait = promptTagIdentity(tag).spaced;
        if (keepHeart && /\bheart(?:-shaped)?\b/.test(trait) && /\bchokers?\b/.test(trait)) return true;
        return !/\bchokers?\b/.test(trait)
          && !/\bslave collars?\b|\bneck (?:collars?|restraints?|shackles?)\b/.test(trait)
          && !(/\bcollars?\b/.test(trait) && /\bneck\b/.test(trait))
          && !/\bchains? around (?:her )?neck\b/.test(trait);
      }).join(', ');
    }

    function alignHStatusBreastJewelry(result, character) {
      const stage = Math.max(0, Math.min(3, Math.floor(Number(character?.situationStats?.jewelryState?.breasts?.stage) || 0)));
      if (!stage || !result || !Array.isArray(result.parts)) return result;
      const exposed = partIsExposed('jewelry.breasts.1', outfitIdFor(character, result.key), result.key, character);
      const removeJewelry = stage === 1 || !exposed;
      const removeChoker = stage !== 3;
      if (!removeJewelry && !removeChoker) return result;
      const excluded = [
        removeJewelry && H_STATUS_PORTRAIT_BREAST_JEWELRY_PROMPT,
        removeChoker && H_STATUS_PORTRAIT_CHOKER_PROMPT,
      ].filter(Boolean).join(', ');
      const prompt = withoutPromptTags(result.prompt, excluded);
      return {
        ...result,
        prompt,
        negativePrompt: removeChoker
          ? joinPrompt(`${result.negativePrompt || ''}, ${H_STATUS_PORTRAIT_CHOKER_PROMPT}`)
          : result.negativePrompt,
        parts: result.parts.map(part => ({
          ...part,
          tags: withoutPromptTags(part.tags, excluded),
        })),
        genParams: promptGenParams(prompt),
      };
    }

    function alignPortraitAccessories(result, character) {
      if (!result || !Array.isArray(result.parts) || isResidueImageKey(result.key)) return result;
      result = alignHStatusBreastJewelry(result, character);
      const vibe = character?.situationStats?.jewelryState?.vibe;
      if ((!vibe || vibe.suspension || !['egg', 'penis'].includes(vibe.type))
        && result.parts.some(part => part.label === 'H Status · 토이')) {
        const parts = result.parts.filter(part => part.label !== 'H Status · 토이');
        const prompt = deduplicatePrompt(joinPrompt(parts.map(part => part.tags).join(', ')));
        result = { ...result, parts, prompt, genParams: promptGenParams(prompt) };
      }
      const stage = Math.max(0, Math.min(3, Math.floor(Number(character?.situationStats?.jewelryState?.breasts?.stage) || 0)));
      if (character?.situationStats?.jewelryState) {
        const prompt = withoutChokerTags(result.prompt, stage === 3);
        if (prompt !== result.prompt) result = {
          ...result,
          prompt,
          parts: result.parts.map(part => ({ ...part, tags: withoutChokerTags(part.tags, stage === 3) })),
          genParams: promptGenParams(prompt),
        };
      }
      const statusIndex = result.parts.findIndex(part => part.label === '상태'
        && String(part.tags || '').includes(H_STATUS_PORTRAIT_STATUS_GUARD));
      if (statusIndex >= 0) {
        const externalTags = new Set(promptTokens([
          H_STATUS_PORTRAIT_BREAST_JEWELRY_PROMPT,
          'one small clitoral jewelry ornament, anatomically placed',
          ...H_STATUS_PORTRAIT_TOY_PROMPTS,
          ...TOY_FIELDS.map(field => field.value),
          H_STATUS_PORTRAIT_STATUS_GUARD,
        ].join(', ')).map(tag => promptTagIdentity(tag).spaced));
        const otherChoker = result.parts.some((part, index) => index !== statusIndex
          && /\bchoker\b/i.test(String(part.tags || '').replaceAll('_', ' ')));
        const tags = promptTokens(result.parts[statusIndex].tags).filter(tag => {
          const identity = promptTagIdentity(tag).spaced;
          return !externalTags.has(identity)
            && (identity !== H_STATUS_PORTRAIT_CHOKER_PROMPT || (stage === 3 && !otherChoker));
        });
        const parts = result.parts.map((part, index) => index === statusIndex
          ? { ...part, tags: tags.join(', ') } : part).filter(part => part.tags);
        const prompt = deduplicatePrompt(joinPrompt(parts.map(part => part.tags).join(', ')));
        result = { ...result, parts, prompt, genParams: promptGenParams(prompt) };
      }
      const malePresent = /\b(?:[1-9]boys?|men|man|male)\b/i.test(result.prompt);
      const hasChoker = /\bchoker\b/i.test(result.prompt.replaceAll('_', ' '));
      const hasToy = /\b(?:egg[_ ]vibrator|vibrator|dildo)\b/i.test(result.prompt);
      const negativePrompt = withoutConflictingAppearanceNegatives(result.prompt, deduplicatePrompt(joinPrompt([
        malePresent ? 'male nipple piercings, nipple rings on men' : '',
        hasChoker ? '' : String(result.negativePrompt || '').includes(H_STATUS_PORTRAIT_CHOKER_PROMPT)
          ? H_STATUS_PORTRAIT_CHOKER_PROMPT : 'choker, heart-shaped choker',
        hasToy ? '' : 'vibrator, dildo',
        result.negativePrompt,
      ].filter(Boolean).join(', '))));
      return negativePrompt === result.negativePrompt ? result : { ...result, negativePrompt };
    }

    function alignAnalInsertion(result, characterId) {
      if (imagePlanDepth || !result || !Array.isArray(result.parts) || !singleAnalAnatomyScene(result.key, characterId)
        || result.parts.some(part => part.label === '항문 삽입 구분')) return result;
      const text = String(result.prompt || '').replaceAll('_', ' ').toLowerCase();
      if (!/\b(?:anal|penis in ass|penis in anus)\b/.test(text)
        || analAnatomyConflictingPrompt(text)
        || result.parts.some(part => String(part.label || '').startsWith('추가 인원 배치 ·'))) return result;
      const tags = '(anal penetration:1.3), (penis inserted into her anus:1.4), (vagina unpenetrated:1.2)';
      const prompt = deduplicatePrompt(joinPrompt(`${result.prompt}, ${tags}`));
      return { ...result, prompt,
        negativePrompt: deduplicatePrompt(joinPrompt(`${result.negativePrompt || ''}, vaginal penetration, penis in vagina, penis in pussy`)),
        parts: [...result.parts, { label: '항문 삽입 구분', tags }], genParams: promptGenParams(prompt) };
    }

    function alignAnalFinish(result, characterId) {
      result = alignAnalInsertion(result, characterId);
      if (!result || !Array.isArray(result.parts) || !analFinishSceneKey(result.key)
        || result.parts.some(part => part.label === '항문 마무리 구도')
        || /\b(?:fellatio|deepthroat|blowjob|penis[_ ]in[_ ]mouth)\b/i.test(result.prompt)) return result;
      const tags = '(anal ejaculation:1.3), (penis in anus:1.2)';
      const prompt = deduplicatePrompt(joinPrompt(`${result.prompt}, ${tags}`));
      return {
        ...result,
        prompt,
        negativePrompt: deduplicatePrompt(joinPrompt(`fellatio, deepthroat, penis in mouth, ${result.negativePrompt || ''}`)),
        parts: [...result.parts, { label: '항문 마무리 구도', tags }],
        genParams: promptGenParams(prompt),
      };
    }

    function promptTagIdentity(tag) {
      const raw = String(tag || '').trim();
      const weighted = raw.match(/^\((.+?):\s*([\d.]+)\)$/);
      const core = (weighted?.[1] || raw).trim();
      const normalized = core.toLocaleLowerCase();
      return { raw, core, normalized, spaced: normalized.replaceAll('_', ' ').replace(/\s+/g, ' '), weight: weighted?.[2] || '' };
    }

    function translatedPromptTag(tag, customTags = currentCustomTags()) {
      const identity = promptTagIdentity(tag);
      const custom = customTags.find(entry => promptTagIdentity(entry.tag).normalized === identity.normalized)?.label;
      const exact = custom
        || PROMPT_TAG_KO[identity.normalized]
        || PROMPT_TAG_KO[identity.spaced]
        || window.WML_I18N_DISPLAY?.[identity.normalized]
        || window.WML_I18N_DISPLAY?.[identity.spaced];
      const translated = exact || identity.spaced.split(' ').map(word => PROMPT_WORD_KO[word] || word).join(' ');
      return identity.weight ? `${translated} · 강조 ${identity.weight}` : translated;
    }

    function promptTagCategory(tag, customTags = currentCustomTags()) {
      const identity = promptTagIdentity(tag);
      if (customTags.some(entry => promptTagIdentity(entry.tag).normalized === identity.normalized)) return 'custom';
      const value = identity.spaced;
      if (/\b(?:quality|masterpiece|blurry|anatomy|limbs|deformed|watermark|signature|duplicate|mutilated|photorealistic|realistic|3d)\b/.test(value)) return 'quality';
      if (/\b(?:tavern|bedroom|bed|kitchen|hearth|bathhouse|hallway|corridor|indoors|entrance|room|table|tables|background)\b/.test(value)) return 'location';
      if (/\b(?:light|lighting|candlelight|firelight|sconce|portrait|upper body|full body|close-up|cropped|view|focus)\b/.test(value)) return 'lighting';
      if (/\b(?:dress|blouse|skirt|apron|corset|lingerie|stockings|garter|sleeves|neckline|bodice|clothes|clothing|nude|naked|bare skin|bare shoulders|bare legs|cleavage|panties|see-through|disheveled)\b/.test(value)) return 'outfit';
      if (/\b(?:smile|expression|cheerful|content|calm|worried|weary|tired|shy|blush|scared|tense|angry|gentle|playful|flustered|surprised|seductive|pleasure|nervous|confident|afterglow|satisfied|gaze|eyes|tears|moaning|panting|aroused|arousal|longing|resentment|uneasy|guilty|humiliated|lonely|proud)\b/.test(value)) return 'mood';
      if (/\b(?:handcuff|handcuffed|handcuffs|shackle|shackles|chain|chains|bound|unable|struggling|piercing|pierced|choker|cum|pussy juice|wet pussy|drunk|unconscious|exhausted|slumped|limp|wasted|intoxicated)\b/.test(value)) return 'status';
      if (/\b(?:girl|boy|woman|man|female|male|hair|eye|breast|waist|build|figure|bust|chest|hips|thighs|tall|short|petite|slim|slender|curvy|athletic|muscular|beard|face|freckles)\b/.test(value)) return 'character';
      if (/\b(?:standing|sitting|lying|kneeling|sleeping|looking|carrying|wiping|cleaning|stirring|holding|gripping|rolling|touching|kissing|riding|straddling|handjob|fellatio|sex|anal|dancing|gesture|posture|pose)\b/.test(value)) return 'action';
      return 'other';
    }

    function portraitTagLanguage() {
      return api.settings.get({ portraitTagLanguage: 'en' }).portraitTagLanguage === 'ko' ? 'ko' : 'en';
    }

    function portraitStateSummary() {
      const scene = latestScenePrompt;
      const state = api.store.game();
      const character = state?.characters?.[scene?.characterId];
      if (!scene || !state || !character) return '현재 장면 상태를 불러올 수 없습니다.';
      const config = situationConfigForCharacter(character, scene.characterId);
      if (!config) return '현재 캐릭터에 적용된 상황 프리셋이 없습니다.';
      const groups = promptGroups(state, character, scene.characterId, config.prompts, config.outfitStates,
        config.dialogueRules, scene.result.key, 'positivePrompt', true);
      const fields = new Map(FIELD_GROUPS.flatMap(group => group.fields).map(field => [field.key, field.label]));
      const names = {
        anger: '분노', contempt: '경멸', disgust: '혐오', sadness: '슬픔', shame: '수치심', guilt: '죄책감',
        regret: '후회', humiliation: '굴욕', tenderness: '다정함', longing: '그리움', desire: '욕망',
        arousal_buzz: '흥분', financial: '돈', approval: '인정', security: '안정', social: '교류', pride: '자부심',
      };
      const label = (group, code) => {
        if (code.startsWith('feeling-')) return `감정 · ${names[code.slice(8)] || code.slice(8)}`;
        if (code.startsWith('drive-')) return `욕구 · ${names[code.slice(6)] || code.slice(6)}`;
        if (code.startsWith('dialogue-')) {
          const rule = config.dialogueRules.find(entry => entry.id === code.slice(9));
          return rule?.text ? `“${rule.text}” 감지` : '대화 규칙 감지';
        }
        const key = group.id === 'attention' ? code === 'handcuffed' ? 'restraint.handcuffed' : `attention.${code}`
          : group.id === 'detail' ? `status.${code.replace('-', '.')}`
            : group.id === 'pregnancy' ? code.replace('-', '.')
              : group.id === 'marks' ? code
                : code.startsWith('jewelry-') ? `jewelry.${code.slice(8).replace('-', '.')}`
                  : code.startsWith('toy-vibe-') ? `toy.vulva.${code.slice(9)}`
                    : `fluid.${code.replace('-', '.')}`;
        return fields.get(key)?.replace(/^대응 필요 · /, '') || code;
      };
      const count = positionGroupCount(scene.situationId);
      const lines = count ? [`장면: 다대일 · 상대 ${count}명`] : [];
      for (const group of groups) {
        const title = { attention: '대응 필요', detail: '상세 상태', pregnancy: '임신', marks: '손찌검', dialogue: '대화' }[group.id] || group.label;
        lines.push(`${title}: ${group.value.codes.map(code => label(group, code)).join(', ')}`);
      }
      return lines.join('\n') || '현재 적용된 상황 상태가 없습니다.';
    }

    function translatedPromptText(value, customTags = currentCustomTags()) {
      return String(value || '').split(',').map(tag => {
        const trimmed = tag.trim();
        return trimmed ? translatedPromptTag(trimmed, customTags) : '';
      }).filter(Boolean).join(', ');
    }

    function updatePortraitTagNode(node, language, customTags) {
      const attribute = 'data-attention-image-prompt-original';
      const rendered = 'data-attention-image-prompt-rendered';
      if (!node.hasAttribute(attribute) || node.hasAttribute(rendered)
        && node.textContent !== node.getAttribute(rendered)) node.setAttribute(attribute, node.textContent || '');
      const original = node.getAttribute(attribute) || '';
      const display = language === 'ko' ? translatedPromptText(original, customTags) : original;
      if (node.textContent !== display) node.textContent = display;
      if (node.getAttribute(rendered) !== display) node.setAttribute(rendered, display);
      node.title = language === 'ko' ? `영문: ${original}` : '한글 표시로 전환할 수 있습니다.';
    }

    function updateCompatiblePortraitTagNode(node, language, legacyToggle, customTags) {
      const nativeText = node.textContent || '';
      const previousNative = node.getAttribute('data-aip-portrait-observed');
      const storedOriginal = node.getAttribute('data-aip-portrait-original');
      const legacyOriginal = node.getAttribute('data-attention-image-prompt-original');
      let original = storedOriginal ?? legacyOriginal ?? nativeText;
      if (previousNative !== null && nativeText !== previousNative) {
        let legacyText = legacyOriginal;
        if (legacyOriginal && legacyToggle?.textContent.includes('한글')) {
          let custom = [];
          try { custom = normalizeCustomTags(JSON.parse(localStorage.getItem('wml.mod.imagestudio-compatible-attention-image-prompt') || '{}').customTags); } catch { /* legacy settings unavailable */ }
          legacyText = translatedPromptText(legacyOriginal, custom);
        }
        if (nativeText !== legacyOriginal && nativeText !== legacyText) {
          original = nativeText;
          node.setAttribute('data-attention-image-prompt-original', original);
        } else original = legacyOriginal ?? original;
      }
      if (storedOriginal !== original) node.setAttribute('data-aip-portrait-original', original);
      if (previousNative !== nativeText) node.setAttribute('data-aip-portrait-observed', nativeText);
      let display = node.nextElementSibling;
      if (!display?.hasAttribute('data-aip-portrait-tag')) {
        display = document.createElement('code');
        display.setAttribute('data-aip-portrait-tag', '');
        display.setAttribute('data-i18n-skip', '');
        display.style.font = 'inherit';
        node.insertAdjacentElement('afterend', display);
      }
      node.style.display = 'none';
      if (display.className !== node.className) display.className = node.className;
      const text = language === 'ko' ? translatedPromptText(original, customTags) : original;
      if (display.textContent !== text) display.textContent = text;
      display.title = language === 'ko' ? `영문: ${original}` : '한글 표시로 전환할 수 있습니다.';
    }

    function decoratePortraitPromptTags() {
      const headings = [...document.querySelectorAll('span.text-stone-500.font-bold')].filter(node =>
        ['원본 자동 태그 (+)', 'Original auto tags (+)', 'Original automatic tags (+)'].includes((node.textContent || '').trim()));
      if (!headings.length) return;
      const language = portraitTagLanguage();
      const compatibleEditor = loadedPromptModOwners().has('imagestudio-compatible-attention-image-prompt');
      const customTags = language === 'ko' ? currentCustomTags() : undefined;

      for (const heading of headings) {
        const partsRoot = heading.parentElement;
        const overlay = partsRoot?.parentElement;
        if (!partsRoot || !overlay) continue;

        const toggleAttribute = compatibleEditor ? 'data-aip-portrait-language' : 'data-attention-image-prompt-language';
        let toggle = overlay.querySelector(`[${toggleAttribute}]`);
        if (!toggle) {
          toggle = document.createElement('button');
          toggle.type = 'button';
          toggle.className = 'ml-2 rounded border border-stone-600 bg-stone-800 px-2 py-0.5 text-[11px] text-stone-300 hover:bg-stone-700 hover:text-white';
          toggle.setAttribute(toggleAttribute, '');
          toggle.setAttribute('data-wml-ui', '');
          toggle.setAttribute('data-i18n-skip', '');
          toggle.addEventListener('click', event => {
            event.preventDefault();
            event.stopPropagation();
            api.settings.set({ portraitTagLanguage: portraitTagLanguage() === 'ko' ? 'en' : 'ko' });
            decoratePortraitPromptTags();
          });
          heading.insertAdjacentElement('afterend', toggle);
        }
        const otherToggle = compatibleEditor ? overlay.querySelector('[data-attention-image-prompt-language]') : null;
        if (compatibleEditor) {
          if (otherToggle && otherToggle !== toggle) otherToggle.style.display = 'none';
        }

        const toggleText = `태그 표시: ${language === 'ko' ? '한글' : '영문'}`;
        if (toggle.textContent !== toggleText) toggle.textContent = toggleText;
        toggle.title = language === 'ko' ? '영문 태그로 전환' : '한글 태그로 전환';
        let summary = overlay.querySelector('[data-attention-image-prompt-summary]');
        if (!summary) {
          summary = document.createElement('div');
          summary.className = 'mt-2 whitespace-pre-line rounded border border-stone-600 bg-stone-900 p-2 text-xs text-stone-200';
          summary.setAttribute('data-attention-image-prompt-summary', '');
          summary.setAttribute('data-wml-ui', '');
          summary.setAttribute('data-i18n-skip', '');
          toggle.insertAdjacentElement('afterend', summary);
        }
        const summaryText = portraitStateSummary();
        if (summary.textContent !== summaryText) summary.textContent = summaryText;
        const tagNodes = [
          ...partsRoot.querySelectorAll('div > span.text-stone-300'),
          ...overlay.querySelectorAll('div > span.text-stone-500.ml-3'),
        ];
        for (const node of new Set(tagNodes)) {
          if (compatibleEditor) updateCompatiblePortraitTagNode(node, language, otherToggle, customTags);
          else updatePortraitTagNode(node, language, customTags);
        }
      }
    }

    function openPositionQuickWindow() {
      activeTagTarget = null;
      quickTagLibraryOpen = false;
      const win = api.ui.window({
        id: 'position-quick', title: '현재 체위 변경', width: 1120, height: 760,
        render(body, windowHandle) {
          prepareAipEditorWindow(windowHandle, 'position', 1120, 760);
          const h = api.ui.h;
          const compact = window.innerWidth < 760;
          const editor = h('main', {},
            ...renderPositionSettings(h, windowHandle));
          const library = renderTagLibrary(h, windowHandle, compact);
          body.replaceChildren(h('style', { 'data-aip-editor-style': '' }, AIP_EDITOR_CSS),
            h('div', { 'data-aip-position': '', 'data-aip-mobile-open': quickTagLibraryOpen ? 'true' : 'false' },
              h('button', { type: 'button', class: 'wml-btn aip-mobile-tools',
                'data-aip-quick-tools': '', 'aria-expanded': quickTagLibraryOpen ? 'true' : 'false',
                onclick: () => { quickTagLibraryOpen = !quickTagLibraryOpen; windowHandle.refresh(); },
              }, quickTagLibraryOpen ? '태그 라이브러리 접기' : '태그 라이브러리 열기'),
              editor, library));
          queueMicrotask(() => {
            const panel = body.querySelector?.('[data-tag-library]');
            if (panel) panel.scrollTop = tagLibraryScrollTop;
          });
        },
      });
      win.refresh();
    }

    function similarImageProfile(imageKey) {
      const parts = String(imageKey || '').split('__').filter(Boolean);
      const residue = parts[0]?.startsWith('situation_');
      return {
        parts,
        kind: residue ? parts[0] : 'portrait',
        character: residue ? parts[1] : parts[0],
        situation: residue
          ? `${parts[0] || ''}__${parts[2] || ''}`
          : parts.find(part => /^(?:scene|task|look)-/.test(part)) || '',
      };
    }

    function similarImageScore(target, candidate) {
      if (!target.character || target.character !== candidate.character || target.kind !== candidate.kind) return -1;
      if (target.situation && target.situation !== candidate.situation) return -1;
      const candidateParts = new Set(candidate.parts);
      return target.parts.reduce((score, part) => {
        if (!candidateParts.has(part) || /^(?:v-\d+|state-[a-z0-9]+|dialogue-[a-z0-9]+|character-(?:reuse|regenerate)-[a-z0-9]+)$/.test(part)) return score;
        if (/^(?:room|outfit|position)-/.test(part)) return score + 5;
        if (/^(?:grp|gslot|focus|exp)-/.test(part)) return score + 3;
        if (/^(?:mood|fin|abed|reaction)-/.test(part)) return score + 2;
        return score + 1;
      }, candidate.parts.join('__') === target.parts.join('__') ? 1000 : 0);
    }

    function isCharacterImage(imageKey, character) {
      return similarImageProfile(imageKey).character === character
        || String(imageKey).startsWith(`wife_preview_${character}_`);
    }
