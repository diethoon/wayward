    function scenePromptCatalog(currentSituationId) {
      const entries = new Map();
      const add = (id, label) => {
        if (typeof id !== 'string' || !id || entries.has(id)) return;
        const category = /^(scene|task|look)-/.exec(id)?.[1] || 'other';
        entries.set(id, { id, label: label || positionSituationLabel(id), category });
      };
      for (const [id, label] of SCENE_PROMPT_EXAMPLES) add(id, label);
      const table = name => {
        try { return api.has(name) ? api.fn(name) : null; } catch { return null; }
      };
      const scenes = table('gameScenePromptTable');
      if (scenes && typeof scenes === 'object' && !Array.isArray(scenes))
        for (const [id, prompts] of Object.entries(scenes))
          if (/^[a-z0-9_]+$/i.test(id) && Array.isArray(prompts)) add(`scene-${id}`);
      const taskLabels = { idle: '대기 중', sleeping: '수면 중', passed_out: '의식불명',
        greeting: '손님 맞이', taking_order: '주문 받기', serving: '서빙', cleaning: '청소', cooking: '요리',
        composing: '작곡', away: '외출', bathing: '목욕', resting: '휴식', at_market: '시장에 있음' };
      for (const [id, label] of Object.entries(taskLabels)) add(`task-${id}`, label);
      const tasks = table('gameTaskPromptTable');
      if (tasks && typeof tasks === 'object' && !Array.isArray(tasks))
        for (const [id, prompt] of Object.entries(tasks))
          if (id !== 'idle_bedroom' && /^[a-z0-9_]+$/i.test(id) && typeof prompt === 'string') add(`task-${id}`);
      const looks = table('gameLookPromptTable');
      if (looks && typeof looks === 'object' && !Array.isArray(looks))
        for (const [id, prompts] of Object.entries(looks))
          if (/^[a-z0-9_]+$/i.test(id) && Array.isArray(prompts)) add(`look-${id}`);
      for (const menu of externalPromptRegistry.values()) for (const entry of menu.entries)
        if (entry.target?.kind === 'position-state') add(entry.target.id, entry.label);
      const currentId = typeof currentSituationId === 'string' ? currentSituationId
        : positionSituationId(activePortraitImageKey('', api.store?.game?.()));
      for (const id of [...Object.keys(currentPositionStatePrompts()), ...Object.keys(sceneBaseOverrides),
        ...Object.keys(sceneStatePromptOverrides), currentId, scenePromptEditorId]) add(id);
      return [...entries.values()];
    }

    function scenePromptsApiSnapshot(situationId) {
      if (typeof situationId !== 'string' || situationId.length > 160
        || !/^(?:scene|task|look)-./.test(situationId) || situationId.includes('__')) return null;
      const positive = sceneBaseOverrideSource(situationId);
      const entries = Object.hasOwn(sceneStatePromptOverrides, situationId)
        ? sceneStatePromptOverrides[situationId] : {};
      const states = Object.fromEntries(Object.entries(entries || {}).map(([key, value]) => [key, { ...value }]));
      return {
        situationId,
        basePositive: positive ? { sourceId: positive.id, prompt: positive.entry.positivePrompt } : null,
        states,
      };
    }

    function scenePromptsApiCacheToken(situationId) {
      const snapshot = scenePromptsApiSnapshot(situationId);
      if (!snapshot) return '';
      const states = Object.entries(snapshot.states).sort(([a], [b]) => a.localeCompare(b))
        .map(([key, value]) => [key, value.positivePrompt ?? null, value.negativePrompt ?? null]);
      const candidateToken = snapshot.basePositive ? '' : sceneCandidateFingerprint(situationId);
      if (!snapshot.basePositive && !states.length && !candidateToken) return '';
      return shortHash(JSON.stringify([situationId, snapshot.basePositive, states, candidateToken]));
    }
