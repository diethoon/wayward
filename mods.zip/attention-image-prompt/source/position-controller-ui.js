    let positionControllerButton = null;
    let positionControllerWindow = null;
    let positionControllerMessage = '';
    let positionControllerBusy = false;
    const positionConsolePanels = new Map();
    let positionConsoleScanQueued = false;
    let positionControllerWindowNeedsRefresh = false;

    function positionControllerReason(reason) {
      return ({
        disabled: 'AIP 체위 콘솔이 꺼져 있습니다.',
        module_mode_required: '체위 설정에서 모듈 방식을 먼저 선택해 주세요.',
        invalid_enabled: '켜기 또는 끄기만 선택할 수 있습니다.',
        invalid_action: '지원하지 않는 체위입니다.',
        no_scene: '진행 중인 관계 장면이 없습니다.',
        unsupported_scene: '현재 장면에서는 체위를 바꿀 수 없습니다.',
        unsupported_slot_check: '다른 손님의 자리를 확인할 수 없어 변경하지 않았습니다.',
        stale_scene: '장면이 바뀌었습니다. 현재 장면을 다시 확인해 주세요.',
        occupied: '다른 손님이 해당 자리를 사용 중입니다.',
        already_selected: '이미 선택된 체위입니다.',
        pending_event: '선택지가 열려 있습니다. 먼저 처리해 주세요.',
        controller_unavailable: '해당 행동을 지원하는 모드가 켜져 있지 않습니다.',
        unsupported_action: '현재 장면에서는 이 행동을 사용할 수 없습니다.',
        busy: '이전 요청을 처리 중입니다.',
        provider_unavailable: '세부 체위 제공 모드의 행동 엔진을 사용할 수 없어요. 모드 설정과 관계 상태를 확인해 주세요.',
        pending_request: '이미 처리 중인 요청이 있습니다.',
        plan_conflict: '손님 컨트롤러에 지정된 행동이 있어 변경하지 않았습니다.',
        controller_unverifiable: '손님 컨트롤러의 대기 요청을 확인할 수 없어 손님 행동을 변경할 수 없어요. 손님 컨트롤러를 사용해 주세요.',
        sequence_in_progress: '첫 경험 장면이 진행 중이에요. 끝난 뒤에 다시 시도해 주세요.',
        image_only: '이 모듈은 이미지 프롬프트 전용입니다.',
        image_context_unavailable: '현재 이미지 상황을 확인할 수 없습니다. 장면 이미지를 불러온 뒤 다시 시도해 주세요.',
        request_rejected: '현재 장면에서 요청을 받아들이지 않았습니다.',
        dispatch_failed_pending: '행동 요청은 등록됐지만 게임 시간을 보내지 못했습니다.',
        transition_unconfirmed: '선택한 행동으로 바로 바뀌었는지 확인하지 못했어요. 전희나 다른 반응이 시작됐을 수 있으니 게임 화면을 확인해 주세요.',
        actor_conflict: '손님과 당신의 관계 장면이 동시에 감지되어 대상을 안전하게 정할 수 없어요.',
        dual_action_conflict: '손님 장면이 함께 진행 중이라 다른 행동으로의 전환은 손님 상태를 바꿀 수 있어 제한해요. 현재 행동 안의 일부 자세는 조건에 따라 선택할 수 있어요.',
        image_override_conflict: '직접 지정한 이미지 체위·행동 또는 배치와 겹칩니다. 이미지 설정을 확인해 주세요.',
        update_failed: '장면이 바뀌어 체위를 적용하지 못했습니다.',
      })[reason] || (reason ? '체위를 변경하지 못했습니다.' : '');
    }

    function positionConsoleUniqueEntries(entries) {
      const seen = new Set();
      return entries.filter(entry => {
        if (!['you', 'patron'].includes(entry.scope) || entry.effect !== 'game'
          || ![undefined, 'aip'].includes(entry.provider) || typeof entry.label !== 'string') return true;
        // These pose providers dispatch by label; descriptions and catalog groups do not alter the action.
        const key = JSON.stringify([entry.scope, entry.provider || 'native-pose', entry.label,
          entry.actionId || '', entry.change || '', !!entry.available, !!entry.active,
          entry.reason || '', !!entry.proposal]);
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
    }

    function renderPositionController(body, win, snapshot = null) {
      const h = api.ui.h;
      const focused = typeof document !== 'undefined' && body.contains?.(document.activeElement)
        ? document.activeElement?.getAttribute?.('data-aip-position-controller-action') : '';
      if (focused) win.__aipFocusAction = focused;
      else if (typeof document !== 'undefined' && document.activeElement !== document.body) win.__aipFocusAction = '';
      const controller = win.__aipInline ? positionControllerApi : positionControllerWindowApi;
      const state = snapshot?.state || controller.getState();
      const entries = positionConsoleUniqueEntries(snapshot?.entries
        || positionControllerList(!win.__aipInline, { game: api.store.game(), state }));
      const offEntries = new Map(entries.filter(entry => entry.provider === 'husband-caress' && entry.caressMode === 'off' && entry.available)
        .map(entry => [`${entry.scope}:${entry.caressKey}`, entry]));
      const rows = entries.filter(entry => !(entry.provider === 'husband-caress' && entry.caressMode === 'off'));
      const visibleEntries = rows.filter(entry => entry.available || (entry.active && offEntries.has(`${entry.scope}:${entry.caressKey}`)));
      const canChoose = entries.some(entry => entry.available && (!entry.active || ['husband-caress', 'aip-prompt'].includes(entry.provider)));
      const actionButton = (entry, isOff = false, mainId = '') => {
        const why = positionControllerReason(entry.reason);
        const detail = typeof entry.detail === 'string' ? entry.detail.trim() : '';
        return h('button', {
            type: 'button', class: 'wml-btn',
            'data-aip-position-controller-action': entry.id,
            'aria-pressed': entry.active ? 'true' : 'false',
            'aria-label': [entry.label, entry.effect === 'image_only' ? '이미지 전용' : '실제 행동',
              entry.active ? '선택됨' : '', !entry.available ? why : '', !entry.available ? detail : ''].filter(Boolean).join(', '),
            disabled: positionControllerBusy || !entry.available, title: [why, detail].filter(Boolean).join(' ') || entry.label,
            style: isOff
              ? 'position:absolute;right:0;top:0;width:24px;min-height:32px;padding:0;font-size:15px;'
              : `width:100%;min-height:32px;padding:3px ${entry.provider === 'husband-caress' ? '27px' : '5px'} 3px 5px;font-size:12px;white-space:normal;word-break:keep-all;${entry.active ? 'border-color:#f59e0b;color:#fde68a;' : ''}`,
            onclick: () => {
              if (positionControllerBusy) return;
              if (isOff) win.__aipFocusFallback = mainId;
              positionControllerBusy = true;
              schedulePositionConsoleScan(true);
              Promise.resolve().then(() => controller.execute(entry.id, state.sceneToken))
                .then(result => { positionControllerMessage = result?.ok
                  ? result.effect === 'image_only' ? `${entry.label} 이미지 전용 선택을 ${entry.active ? '해제' : '적용'}했어요. 게임 상태는 바뀌지 않아요.`
                    : result.reason === 'proposal_sent' ? '제안을 요청했어요. 게임의 반응을 확인해 주세요.'
                    : result.pending ? `${entry.label} 요청을 보냈어요. 아직 적용 확인을 기다리고 있어요.` : `${entry.label} 적용을 확인했어요.`
                  : result?.actionApplied ? '게임 행동은 바뀌었지만 세부 자세를 확인하지 못했어요. 현재 장면을 확인해 주세요.'
                  : positionControllerReason(result?.reason || 'update_failed'); })
                .catch(() => { positionControllerMessage = positionControllerReason('update_failed'); })
                .finally(() => { positionControllerBusy = false; schedulePositionConsoleScan(true); });
            },
          }, isOff ? '×' : `${entry.label}${entry.effect === 'image_only' && !/^이미지(?:\s|·)/.test(entry.group || '') ? ' · 이미지' : ''}`);
      };
      const card = entry => {
        const off = entry.provider === 'husband-caress' ? offEntries.get(`${entry.scope}:${entry.caressKey}`) : null;
        return h('div', { style: 'position:relative;min-width:0;' }, actionButton(entry),
          off ? actionButton(off, true, entry.id) : null);
      };
      const renderGroups = items => {
        const groups = new Map();
        for (const entry of items) {
          const scope = entry.scope === 'patron' ? '손님' : entry.scope === 'you' ? '당신' : '';
          const group = [scope, entry.group || '체위'].filter(Boolean).join(' · ');
          if (!groups.has(group)) groups.set(group, []);
          groups.get(group).push(entry);
        }
        return [...groups].map(([group, groupItems]) => h('section', { style: 'display:grid;gap:3px;min-width:0;' },
          h('div', { style: 'font-weight:700;font-size:12px;' }, group),
          h('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,64px),1fr));gap:4px;align-items:start;' }, ...groupItems.map(card))));
      };
      body.replaceChildren(h('div', { 'data-aip-position-controller': '', style: 'display:grid;gap:6px;min-width:0;' },
        h('p', { class: 'wml-note', style: 'margin:0;font-size:11px;' }, '실제 행동은 시간·수치가 바뀔 수 있어요. ‘이미지’는 그림만 바꿔요.'),
        h('div', { 'data-aip-position-controller-scene': '', style: 'font-weight:700;' }, state.sceneLabel || '현재 장면 없음'),
        state.reason ? h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, positionControllerReason(state.reason)) : null,
        ...renderGroups(visibleEntries),
        state.imageWarning ? h('p', { class: 'wml-note', style: 'margin:0;' },
          state.imageWarning === 'image_override_conflict'
            ? '이미지에 직접 지정한 체위·행동이 있어, 실제 행동을 바꿔도 이미지와 다를 수 있어요.'
            : '현재 이미지와 실제 행동이 다를 수 있어요. 이미지 설정을 확인해 주세요.') : null,
        entries.some(entry => entry.reason === 'dual_action_conflict')
          ? h('p', { class: 'wml-note', style: 'margin:0;' }, positionControllerReason('dual_action_conflict')) : null,
        positionControllerMessage ? h('p', { role: 'status', class: 'wml-note', style: 'margin:0;' }, positionControllerMessage) : null,
        !canChoose ? h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '지금 선택할 수 있는 다른 행동이 없어요.') : null));
      if (!positionControllerBusy && win.__aipFocusAction) {
        const buttons = [...(body.querySelectorAll?.('[data-aip-position-controller-action]') || [])];
        const target = buttons.find(button => button.getAttribute('data-aip-position-controller-action') === win.__aipFocusAction && !button.disabled)
          || buttons.find(button => button.getAttribute('data-aip-position-controller-action') === win.__aipFocusFallback && !button.disabled);
        if (target) { try { target.focus({ preventScroll: true }); } catch { target.focus(); } }
        win.__aipFocusAction = '';
        win.__aipFocusFallback = '';
      }
    }

    function openPositionControllerWindow() {
      if (positionControllerWindow) { positionControllerWindow.refresh(); return; }
      positionControllerWindow = api.ui.window({
        id: 'position-controller', title: 'AIP 체위 콘솔', width: 520, height: 340,
        render: renderPositionController,
        onClose() { positionControllerWindow = null; positionControllerMessage = ''; },
      });
    }

    function restorePositionConsoleChoices(panel, wanted = new Set()) {
      for (const [node, display] of panel.hidden) {
        if (wanted.has(node)) continue;
        if (node.style.display === 'none') node.style.display = display;
        panel.hidden.delete(node);
      }
      for (const node of wanted) {
        if (panel.hidden.has(node)) continue;
        panel.hidden.set(node, node.style.display);
        node.style.display = 'none';
      }
    }

    function closePositionConsolePanel(panel) {
      restorePositionConsoleChoices(panel);
      panel.header.remove();
      panel.body.remove();
    }

    function positionConsoleChoiceNodes(pane, state, entries) {
      const choices = state?.pendingEvent?.choices;
      if (!Array.isArray(choices)) return new Set();
      const native = [...pane.children].find(child => !child.hasAttribute('data-aip-position-console-panel')
        && !child.hasAttribute('data-aip-position-console-body'));
      const grid = [...(native?.children || [])].find(child => child.classList?.contains('grid')
        && child.classList.contains('grid-cols-1') && child.classList.contains('gap-2'));
      const supported = new Set(entries.filter(entry => entry.available && entry.actionId).map(entry => entry.actionId));
      const wanted = new Set(choices.flatMap((choice, index) => {
        const node = grid?.children[index];
        return supported.has(choice?.id) && typeof choice.label === 'string' && choice.label
          && node?.tagName === 'BUTTON' && node.textContent.includes(choice.label) ? [node] : [];
      }));
      const husband = globalThis.__waywardHusbandLife;
      try {
        if (!husband?.owns?.(state)) return wanted;
        for (const entry of entries) if (entry.available && entry.scope === 'you' && entry.effect === 'game'
          && !entry.provider && husband.ui?.POSE_TYPE?.[entry.label]) supported.add(`act_pose:${entry.label}`);
        // shortcut: only the player's fixed dock has matching semantics; her-view controls change the lead.
        for (const button of pane.querySelectorAll?.('.hlc-dock.hlc-dock-fixed button[data-choice-id]') || []) {
          const id = button.getAttribute('data-choice-id');
          if (!supported.has(id) || button.getAttribute('aria-disabled') === 'true') continue;
          const caress = /^(?:act_toggle|act_caress):(.+)$/.exec(id);
          if (caress && button.querySelector('.hlc-x') && !supported.has(`act_off:${caress[1]}`)) continue;
          wanted.add(button);
        }
      } catch { /* Keep the other mod's controls if its scene cannot be verified. */ }
      return wanted;
    }

    function syncPositionConsolePanels() {
      if (typeof document === 'undefined' || typeof document.querySelectorAll !== 'function') return false;
      const game = api.store.game();
      const eventType = game?.pendingEvent?.type;
      const inScene = (eventType === 'sex_scene' && game?.activeScene?.sex)
        || (eventType === 'patron_interaction' && game?.activeScene?.patron);
      const panes = inScene ? [...document.querySelectorAll('div.flex-1.min-h-0.overflow-y-auto')].filter(pane =>
        pane.classList.contains('xl:p-3') && pane.classList.contains('p-2')
        || pane.classList.contains('py-1') && pane.classList.contains('text-[0.72rem]')) : [];
      for (const [pane, panel] of positionConsolePanels) if (!panes.includes(pane)) {
        closePositionConsolePanel(panel);
        positionConsolePanels.delete(pane);
      }
      if (!panes.length) return false;
      const state = positionControllerState(game), entries = state.enabled
        ? positionControllerList(false, { game, state }) : [];
      for (const pane of panes) {
        let panel = positionConsolePanels.get(pane);
        if (!panel) {
          const header = document.createElement('label');
          header.setAttribute('data-aip-position-console-panel', '');
          header.setAttribute('data-wml-ui', '');
          header.style.cssText = 'display:flex;align-items:center;gap:8px;margin:0 0 10px;padding:7px;border:1px solid #57534e;border-radius:6px;color:#fde68a;';
          const toggle = document.createElement('input');
          toggle.type = 'checkbox';
          toggle.setAttribute('data-aip-position-console-toggle', '');
          toggle.setAttribute('aria-label', 'AIP 체위 콘솔 켜기');
          const title = document.createElement('span');
          title.textContent = 'AIP 체위 콘솔';
          header.append(toggle, title);
          const body = document.createElement('div');
          body.setAttribute('data-aip-position-console-body', '');
          body.setAttribute('data-wml-ui', '');
          body.style.cssText = 'margin-top:10px;min-width:0;';
          panel = { header, toggle, body, hidden: new Map(), signature: '', win: null };
          panel.win = { __aipInline: true, refresh() {
            if (!panel.body.parentNode) return;
            schedulePositionConsoleScan();
          } };
          toggle.addEventListener('change', () => {
            positionControllerApi.setEnabled(toggle.checked);
          });
          positionConsolePanels.set(pane, panel);
        }
        if (panel.header.parentNode !== pane || panel.body.parentNode !== pane
          || panel.header.nextSibling !== panel.body || panel.body.nextSibling !== null) {
          pane.appendChild(panel.header);
          pane.appendChild(panel.body);
        }
        panel.toggle.checked = state.enabled;
        panel.body.hidden = !state.enabled;
        restorePositionConsoleChoices(panel, state.enabled && !state.reason
          ? positionConsoleChoiceNodes(pane, game, entries) : new Set());
        if (state.enabled) {
          const signature = JSON.stringify([state.sceneToken, state.reason, state.imageWarning,
            positionControllerMessage, positionControllerBusy, entries]);
          if (panel.signature !== signature) {
            renderPositionController(panel.body, panel.win, { state, entries });
            panel.signature = signature;
          }
        } else panel.signature = '';
      }
      return true;
    }

    function schedulePositionConsoleScan(refreshWindow = false) {
      if (refreshWindow) positionControllerWindowNeedsRefresh = true;
      if (positionConsoleScanQueued) return;
      positionConsoleScanQueued = true;
      const scan = () => {
        positionConsoleScanQueued = false;
        const refresh = positionControllerWindowNeedsRefresh;
        positionControllerWindowNeedsRefresh = false;
        syncPositionControllerButton(refresh);
      };
      if (typeof window !== 'undefined' && typeof window.requestAnimationFrame === 'function') window.requestAnimationFrame(scan);
      else queueMicrotask(scan);
    }

    function syncPositionControllerButton(refreshWindow = true) {
      syncPositionConsolePanels();
      if (!positionControllerButton && typeof api.ui.addButton === 'function') {
        positionControllerButton = api.ui.addButton({
          label: 'AIP 체위 콘솔', title: 'AIP 체위 콘솔 열기', onClick: openPositionControllerWindow,
        });
      }
      if (refreshWindow && positionControllerWindow) positionControllerWindow.refresh();
    }

    api.store.subscribe?.(() => schedulePositionConsoleScan(true));
    if (typeof MutationObserver !== 'undefined' && typeof document !== 'undefined') {
      const root = document.getElementById('root') || document.body;
      if (root) new MutationObserver(records => {
        const consoleSelector = '[data-aip-position-console-panel], [data-aip-position-console-body]';
        const paneSelector = 'div.flex-1.min-h-0.overflow-y-auto';
        const relevant = records.some(record => {
          if (record.target?.closest?.(consoleSelector)) return false;
          const nodes = [...(record.addedNodes || []), ...(record.removedNodes || [])]
            .filter(node => node.nodeType === 1);
          if (nodes.length && nodes.every(node => node.matches?.(consoleSelector))) {
            return [...positionConsolePanels.values()].some(panel => !panel.header.parentNode || !panel.body.parentNode);
          }
          if (record.target?.closest?.(paneSelector)) return true;
          return nodes.some(node => node.matches?.(paneSelector) || node.querySelector?.(paneSelector));
        });
        if (relevant) schedulePositionConsoleScan();
      }).observe(root, { childList: true, subtree: true });
    }
    syncPositionControllerButton();
