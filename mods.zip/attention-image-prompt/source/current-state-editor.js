    const stateEditorFields = new Map(FIELD_GROUPS.flatMap(group => group.fields.map(field => [field.key, field])));
    let sceneStatePromptOverrides = {};
    let stateEditorGlobalChanges = {};
    let sceneStateEditScope = 'global';
    let sceneStateIgnoreOverrides = false;

    function normalizeSceneStatePromptOverrides(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).slice(0, 200).flatMap(([id, entries]) => {
        if (id.length > 160 || !/^(?:scene|task|look)-./.test(id) || id.includes('__')
          || !entries || typeof entries !== 'object' || Array.isArray(entries)) return [];
        const fields = Object.fromEntries(Object.entries(entries).slice(0, 256).flatMap(([key, entry]) => {
          if (!stateEditorFields.has(key) || !entry || typeof entry !== 'object' || Array.isArray(entry)) return [];
          const prompts = {};
          for (const field of ['positivePrompt', 'negativePrompt'])
            if (typeof entry[field] === 'string' && entry[field].length <= 12000) prompts[field] = entry[field];
          return Object.keys(prompts).length ? [[key, prompts]] : [];
        }));
        return Object.keys(fields).length ? [[id, fields]] : [];
      }));
    }

    function currentSceneStatePromptOverrides() {
      return normalizeSceneStatePromptOverrides(sceneStatePromptOverrides);
    }

    function reloadSceneStatePromptOverrides() {
      sceneStatePromptOverrides = normalizeSceneStatePromptOverrides(api.settings.get({ sceneStatePromptOverrides: {} }).sceneStatePromptOverrides);
    }

    function normalizeStateEditorGlobalChanges(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).slice(0, 100).flatMap(([presetId, fields]) => {
        if (!/^[a-z0-9][a-z0-9_-]{0,79}$/i.test(presetId) || !Array.isArray(fields)) return [];
        const valid = [...new Set(fields.slice(0, 256).filter(key => typeof key === 'string' && stateEditorFields.has(key)))].sort();
        return valid.length ? [[presetId, valid]] : [];
      }));
    }

    function currentStateEditorGlobalChanges() {
      return normalizeStateEditorGlobalChanges(stateEditorGlobalChanges);
    }

    function reloadStateEditorGlobalChanges() {
      stateEditorGlobalChanges = normalizeStateEditorGlobalChanges(api.settings.get({ stateEditorGlobalChanges: {} }).stateEditorGlobalChanges);
    }

    function stateEditorHasGlobalChanges(config) {
      return Boolean(config?.id && stateEditorGlobalChanges[config.id]?.length);
    }

    function stateEditorGlobalProbePrompts(config, promptField) {
      const marked = config?.id && stateEditorGlobalChanges[config.id];
      if (!marked?.length || !['positivePrompt', 'negativePrompt'].includes(promptField)) return null;
      const section = promptField === 'positivePrompt' ? 'prompts' : 'negativePrompts';
      const prompts = config[section];
      if (!prompts || typeof prompts !== 'object') return null;
      const result = { ...prompts };
      let changed = false;
      for (const key of marked) if (typeof result[key] !== 'string' || !result[key].trim()) {
        result[key] = 'aip_state_probe'; changed = true;
      }
      return changed ? result : null;
    }

    function stateEditorGlobalFingerprint(config, groups, situationId = '') {
      const marked = config?.id && stateEditorGlobalChanges[config.id];
      if (!marked?.length) return '';
      const active = new Set();
      const list = Array.isArray(groups) ? groups : [...(groups?.positiveGroups || []), ...(groups?.negativeGroups || [])];
      for (const group of list) for (const code of group.value?.codes || []) {
        const key = stateEditorFieldKey(group.id, code);
        if (key) active.add(key);
      }
      const providers = externalFieldProviders(), scoped = sceneStatePromptOverrides[situationId] || {};
      const data = marked.filter(key => active.has(key) && !providers.has(key)).flatMap(key => {
        const positive = Object.hasOwn(scoped[key] || {}, 'positivePrompt') ? null : config.prompts?.[key] ?? '';
        const negative = Object.hasOwn(scoped[key] || {}, 'negativePrompt') ? null : config.negativePrompts?.[key] ?? '';
        return positive === null && negative === null ? [] : [[key, positive, negative]];
      });
      return data.length ? shortHash(JSON.stringify(data)) : '';
    }

    function effectiveSceneStatePrompts(prompts, situationId, promptField) {
      const entries = !sceneStateIgnoreOverrides && sceneStatePromptOverrides[situationId];
      if (!entries || !['positivePrompt', 'negativePrompt'].includes(promptField)) return prompts;
      let result = prompts;
      for (const [key, entry] of Object.entries(entries)) {
        if (!Object.hasOwn(entry, promptField)) continue;
        if (result === prompts) result = { ...prompts };
        result[key] = entry[promptField];
      }
      return result;
    }

    function sceneStatePromptFingerprint(situationId) {
      const entries = sceneStatePromptOverrides[situationId];
      if (!entries || sceneStateIgnoreOverrides) return '';
      const data = Object.entries(entries).sort(([a], [b]) => a.localeCompare(b))
        .map(([key, value]) => [key, value.positivePrompt ?? null, value.negativePrompt ?? null]);
      return data.length ? shortHash(JSON.stringify(data)) : '';
    }

    function stateEditorFieldKey(group, code) {
      let key = '';
      if (group === 'attention') key = code === 'handcuffed' ? 'restraint.handcuffed' : `attention.${code}`;
      else if (group === 'detail') {
        const match = /^(energy|mood|arousal|wellbeing|allure|trust|desire|resentment|drift|latitude|intoxication)-(.+)$/.exec(code);
        if (match) key = `status.${match[1]}.${match[2]}`;
      } else if (group === 'marks') key = code;
      else if (['pregnancy', 'firstExperience', 'sleep'].includes(group))
        key = [...stateEditorFields.keys()].find(value => value.startsWith(`${group}.`) && value.replace('.', '-') === code) || '';
      else if (group === 'cycle')
        key = [...stateEditorFields.keys()].find(value => value.startsWith('cycle.') && value.replaceAll('.', '-') === code) || '';
      else if (group === 'hypnosis' || group === 'crest') {
        const match = /^hstatus-(hypnosis|crest)-(\d+)-/.exec(code);
        if (match) key = `hstatus.${match[1]}.${match[2]}`;
      } else if (group === 'erostat') {
        const match = /^erostat-(vaginal|anal|oral)-([a-z]+)-/.exec(code);
        if (match) key = `erostat.${match[1] === 'anal' ? 'anal' : 'fit'}.${match[2]}`;
      } else if (group.startsWith('body-')) {
        let match = /^jewelry-(breasts|vulva)-(\d+)$/.exec(code);
        if (match) key = `jewelry.${match[1]}.${match[2]}`;
        else if ((match = /^toy-vibe-(egg|penis)$/.exec(code))) key = `toy.vulva.${match[1]}`;
        else if ((match = /^([a-z]+)-(\d+)$/.exec(code))) key = `fluid.${match[1]}.${match[2]}`;
      }
      return stateEditorFields.has(key) ? key : '';
    }

    function stateEditorContext(situationId) {
      const state = api.store.game(), characterId = state?.primaryCharacterId;
      const character = characterId && state.characters?.[characterId];
      const imageKey = state && activePortraitImageKey('', state);
      if (!character || !imageKey || positionSituationId(imageKey) !== situationId) return null;
      const config = situationConfigForCharacter(character, characterId);
      if (!config) return { state, characterId, imageKey, config: null, fields: [], unsupported: [] };
      const baseKey = baseSituationImageKey(imageKey);
      const contexts = [promptContext(state, character, characterId, baseKey)];
      if (sceneStatePromptOverrides[situationId]) {
        sceneStateIgnoreOverrides = true;
        try { contexts.push(promptContext(state, character, characterId, baseKey)); }
        finally { sceneStateIgnoreOverrides = false; }
      }
      const fields = new Set(), unsupported = new Set();
      for (const context of contexts) for (const group of [...context.positiveGroups, ...context.negativeGroups]) {
        if (['character', 'outfit', 'buttonChoice', 'dialogue', 'sceneAction'].includes(group.id)) continue;
        for (const code of group.value?.codes || []) {
          const key = stateEditorFieldKey(group.id, code);
          if (key) fields.add(key); else unsupported.add(group.label || group.id);
        }
      }
      const missing = new Set([...Object.keys(sceneStatePromptOverrides[situationId] || {}),
        ...(stateEditorGlobalChanges[config.id] || [])].filter(key => !fields.has(key)));
      if (missing.size) {
        sceneStateIgnoreOverrides = true;
        try {
          for (const [section, polarity] of [['prompts', 'positivePrompt'], ['negativePrompts', 'negativePrompt']]) {
            const probe = { ...config[section] };
            for (const key of missing) if (!cleanPrompt(probe[key])) probe[key] = 'aip_state_probe';
            for (const group of promptGroups(state, character, characterId, probe, config.outfitStates,
              config.dialogueRules, baseKey, polarity, false)) for (const code of group.value?.codes || []) {
              const key = stateEditorFieldKey(group.id, code);
              if (missing.has(key)) fields.add(key);
            }
          }
        } finally { sceneStateIgnoreOverrides = false; }
      }
      return { state, characterId, imageKey, config, fields: [...fields], unsupported: [...unsupported], providers: externalFieldProviders() };
    }

    function saveCurrentStateEditorPrompt(snapshot, situationId, fieldKey, promptField, text, scope) {
      if (!snapshot?.config || !stateEditorFields.has(fieldKey) || !['positivePrompt', 'negativePrompt'].includes(promptField)
        || typeof text !== 'string' || text.length > 12000 || !['global', 'scene'].includes(scope)) return false;
      const state = api.store.game();
      if (state !== snapshot.state || state?.primaryCharacterId !== snapshot.characterId
        || positionSituationId(activePortraitImageKey('', state)) !== situationId) return false;
      const character = state.characters?.[snapshot.characterId];
      const config = character && situationConfigForCharacter(character, snapshot.characterId);
      if (!config || config.id !== snapshot.config.id) return false;
      const provider = externalFieldProviders().get(fieldKey), expected = snapshot.providers?.get(fieldKey);
      if ((provider?.key || '') !== (expected?.key || '')) return false;
      if (scope === 'scene') {
        const entries = { ...(sceneStatePromptOverrides[situationId] || {}) };
        entries[fieldKey] = { ...entries[fieldKey], [promptField]: text };
        const next = normalizeSceneStatePromptOverrides({ ...sceneStatePromptOverrides, [situationId]: entries });
        if (next[situationId]?.[fieldKey]?.[promptField] !== text) return false;
        const previous = sceneStatePromptOverrides;
        sceneStatePromptOverrides = next;
        try { api.settings.set({ sceneStatePromptOverrides }); } catch (error) { sceneStatePromptOverrides = previous; throw error; }
      } else {
        const section = promptField === 'positivePrompt' ? 'prompts' : 'negativePrompts';
        if (provider) {
          if (externalPromptsForField(config[section], promptField)[fieldKey] === text) return true;
          return saveExternalPrompt(provider.id, provider.entryId, 'mod', { [promptField]: text });
        }
        if (config[section]?.[fieldKey] === text) return true;
        const values = { ...config[section], [fieldKey]: text };
        const marked = [...new Set([...(stateEditorGlobalChanges[config.id] || []), fieldKey])];
        const globalChanges = normalizeStateEditorGlobalChanges({ ...stateEditorGlobalChanges, [config.id]: marked });
        if (!globalChanges[config.id]?.includes(fieldKey)) return false;
        let patch;
        if (config.id === LEGACY_SITUATION_PRESET_ID) patch = { [section]: values, stateEditorGlobalChanges: globalChanges };
        else {
          const presets = currentSituationPresets();
          if (!presets.some(preset => preset.id === config.id)) return false;
          patch = { situationPresets: presets.map(preset => preset.id === config.id ? { ...preset, [section]: values } : preset),
            stateEditorGlobalChanges: globalChanges };
        }
        const previousChanges = stateEditorGlobalChanges;
        stateEditorGlobalChanges = globalChanges;
        try { api.settings.set(patch); } catch (error) { stateEditorGlobalChanges = previousChanges; throw error; }
      }
      return true;
    }

    function resetCurrentSceneStatePrompt(snapshot, situationId, fieldKey) {
      const state = api.store.game(), character = state?.characters?.[snapshot?.characterId];
      const config = character && situationConfigForCharacter(character, snapshot.characterId);
      if (state !== snapshot?.state || state?.primaryCharacterId !== snapshot.characterId || !config
        || config.id !== snapshot.config?.id || positionSituationId(activePortraitImageKey('', state)) !== situationId
        || (externalFieldProviders().get(fieldKey)?.key || '') !== (snapshot.providers?.get(fieldKey)?.key || '')
        || !sceneStatePromptOverrides[situationId]?.[fieldKey]) return false;
      const entries = { ...sceneStatePromptOverrides[situationId] };
      delete entries[fieldKey];
      const previous = sceneStatePromptOverrides;
      sceneStatePromptOverrides = normalizeSceneStatePromptOverrides({ ...sceneStatePromptOverrides, [situationId]: entries });
      try { api.settings.set({ sceneStatePromptOverrides }); } catch (error) { sceneStatePromptOverrides = previous; throw error; }
      return true;
    }

    function renderCurrentStateEditor(h, win, situationId, active) {
      const snapshot = active ? stateEditorContext(situationId) : null;
      const providers = snapshot?.providers || new Map();
      const globalPositive = snapshot?.config ? externalPromptsForField(snapshot.config.prompts, 'positivePrompt') : {};
      const globalNegative = snapshot?.config ? externalPromptsForField(snapshot.config.negativePrompts, 'negativePrompt') : {};
      const sceneEntries = sceneStatePromptOverrides[situationId] || {};
      const valueFor = (key, polarity) => sceneStateEditScope === 'scene' && Object.hasOwn(sceneEntries[key] || {}, polarity)
        ? sceneEntries[key][polarity] : (polarity === 'positivePrompt' ? globalPositive[key] : globalNegative[key]) || '';
      return h('section', { 'data-current-state-editor': '' },
        h('h3', {}, '현재 적용 중인 상태 프롬프트'),
        !snapshot ? h('p', { class: 'wml-muted wml-small' }, '현재 초상화와 같은 상세 장면을 선택해 주세요.') : !snapshot.config
          ? h('p', { class: 'wml-muted wml-small' }, '현재 아내에는 상황 프리셋이 적용되지 않아 상태 프롬프트가 없어요.')
          : h('p', { class: 'wml-muted wml-small' }, `현재 아내의 적용 프리셋: ${snapshot.config.name || snapshot.config.id}. 원본 상태나 다른 모드의 상태 값은 바꾸지 않아요.`),
        snapshot?.config ? h('label', {}, '수정 범위 ', h('select', { value: sceneStateEditScope,
          'data-current-state-scope': '', onchange: event => { sceneStateEditScope = event.currentTarget.value === 'scene' ? 'scene' : 'global'; win.refresh(); } },
          h('option', { value: 'global', selected: sceneStateEditScope === 'global' }, '해당 상태 전체'),
          h('option', { value: 'scene', selected: sceneStateEditScope === 'scene' }, '현재 장면만'))) : null,
        snapshot?.config ? h('p', { class: 'wml-muted wml-small' }, 'AIP 상태 제공자로 연결되지 않은 다른 모드 프롬프트는 초상화의 최종 프롬프트 검수에서 확인해 주세요.') : null,
        snapshot?.config && sceneStateEditScope === 'global' && Object.keys(sceneEntries).length
          ? h('p', { class: 'wml-note' }, '이 장면에 별도 수정값이 있으면 해당 상태의 전체 설정보다 우선해요.') : null,
        snapshot?.config && !snapshot.fields.length ? h('p', { class: 'wml-muted wml-small' }, '직접 수정할 수 있는 현재 상태가 없어요.') : null,
        ...(snapshot?.fields || []).map(key => {
          const provider = providers.get(key);
          const save = (field, text, refresh) => {
            try {
              if (!saveCurrentStateEditorPrompt(snapshot, situationId, key, field, text, sceneStateEditScope)) {
                settingsMessage = '장면이나 프리셋 또는 제공자가 바뀌었어요. 현재 상태를 다시 확인해 주세요.';
              } else if (refresh) { if (!provider || sceneStateEditScope === 'scene') notifyExternalPromptChange(); refreshPortraitImage(); }
            } catch { settingsMessage = '상태 프롬프트를 저장하지 못했어요. 설정 저장 공간을 확인해 주세요.'; }
            if (refresh) win.refresh();
          };
          return h('div', { 'data-current-state-field': key }, h('strong', {}, stateEditorFields.get(key).label),
            provider ? h('p', { class: 'wml-note' }, `다른 모드 제공: ${provider.title}. 전체 수정은 이 제공자를 쓰는 모든 캐릭터와 상황에 적용돼요. 수정값은 AIP에 저장하며 다른 모드의 파일과 설정은 바꾸지 않아요. 장면 수정값은 이 장면에서 우선해요.`) : null,
            h('div', { class: 'aip-prompt-pair' }, ...[['positivePrompt', 'Positive'], ['negativePrompt', 'Negative']].map(([field, label]) =>
              h('label', { class: 'aip-prompt-field' }, h('span', {}, label), h('textarea', { rows: 2, value: valueFor(key, field),
                maxLength: 12000, 'data-current-state-prompt': field,
                style: 'width:100%;box-sizing:border-box;resize:vertical;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
                oninput: event => { save(field, event.currentTarget.value, false); updatePromptTagPreview(event, h, win); },
                onchange: event => save(field, event.currentTarget.value, true) }),
                promptTagPreview(h, valueFor(key, field), win)))),
            sceneStateEditScope === 'scene' && sceneEntries[key] ? api.ui.button('이 상태의 장면 수정 해제', () => {
              try {
                if (resetCurrentSceneStatePrompt(snapshot, situationId, key)) { notifyExternalPromptChange(); refreshPortraitImage(); }
                else settingsMessage = '장면이나 프리셋 또는 제공자가 바뀌었어요. 현재 상태를 다시 확인해 주세요.';
              } catch { settingsMessage = '장면 수정값을 해제하지 못했어요. 설정 저장 공간을 확인해 주세요.'; }
              win.refresh();
            }) : null);
        }),
        snapshot?.unsupported?.length ? h('p', { class: 'wml-note' }, `자동으로 연결할 수 없는 상태: ${snapshot.unsupported.join(', ')}. 해당 상태의 기존 설정 또는 모드 제공자에서 수정해 주세요.`) : null);
    }

    reloadSceneStatePromptOverrides();
    reloadStateEditorGlobalChanges();
