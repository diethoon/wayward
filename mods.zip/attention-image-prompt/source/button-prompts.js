    // Choice prompts are keyed by game identifiers, not translated button labels.
    let buttonPromptRules = [];
    let buttonPromptRuleMap = new Map();
    let buttonPromptSelection = '';
    let buttonOutcomeSelection = '';
    let buttonOutcomeEvent = '';
    let buttonOutcomeResponse = '';
    let buttonOutcomeCandidateId = '';
    let buttonPromptCandidate = null;
    let buttonPromptAfter = null;
    let buttonPortraitDepth = 0;

    function buttonPromptId(context) {
      return JSON.stringify([context.scene, context.eventType, context.eventKind, context.choiceId]);
    }

    function validButtonPromptRule(rule) {
      return rule && typeof rule.scene === 'string' && !!rule.scene && rule.scene.length <= 200
        && typeof rule.eventType === 'string' && !!rule.eventType && rule.eventType.length <= 200
        && typeof rule.eventKind === 'string' && rule.eventKind.length <= 200
        && typeof rule.choiceId === 'string' && !!rule.choiceId && rule.choiceId.length <= 200
        && ['shown', 'after'].includes(rule.mode)
        && typeof rule.positivePrompt === 'string' && rule.positivePrompt.length <= 4000
        && typeof rule.negativePrompt === 'string' && rule.negativePrompt.length <= 4000;
    }

    function normalizeButtonPromptRules(saved) {
      if (!Array.isArray(saved)) return [];
      const entries = new Map();
      for (const rule of saved.slice(0, 256)) if (validButtonPromptRule(rule)) {
        const entry = { scene: rule.scene, eventType: rule.eventType, eventKind: rule.eventKind,
          choiceId: rule.choiceId, label: typeof rule.label === 'string' ? rule.label.slice(0, 200) : '',
          mode: rule.mode, positivePrompt: rule.positivePrompt, negativePrompt: rule.negativePrompt };
        if (rule.legacyShownPrompt && typeof rule.legacyShownPrompt.positivePrompt === 'string'
          && typeof rule.legacyShownPrompt.negativePrompt === 'string') entry.legacyShownPrompt = {
          positivePrompt: rule.legacyShownPrompt.positivePrompt.slice(0, 4000),
          negativePrompt: rule.legacyShownPrompt.negativePrompt.slice(0, 4000) };
        const outcomes = normalizeButtonPromptOutcomes(rule.outcomes);
        if (outcomes.length) entry.outcomes = outcomes;
        entries.set(buttonPromptId(entry), entry);
      }
      return [...entries.values()];
    }

    function normalizeButtonPromptOutcomes(outcomes) {
      const entries = new Map();
      if (!Array.isArray(outcomes)) return [];
      for (const entry of outcomes.slice(0, 128)) {
        if (!entry || typeof entry.situationId !== 'string' || !/^(?:scene|task|look)-[^_]/.test(entry.situationId)
          || entry.situationId.length > 200 || entry.situationId.includes('__')
          || typeof entry.positivePrompt !== 'string' || entry.positivePrompt.length > 4000
          || typeof entry.negativePrompt !== 'string' || entry.negativePrompt.length > 4000) continue;
        const eventType = typeof entry.eventType === 'string' ? entry.eventType : '';
        const eventKind = typeof entry.eventKind === 'string' ? entry.eventKind : '';
        if (eventType.length > 200 || eventKind.length > 200 || (!eventType && eventKind)) continue;
        const response = typeof entry.response === 'string' ? entry.response : '';
        if (!['', 'accept', 'eager', 'hesitant', 'refuse', 'angry', 'neutral'].includes(response)) continue;
        const candidates = normalizeButtonOutcomeCandidates(entry.candidates);
        const candidateSelection = candidates.some(candidate => candidate.id === entry.candidateSelection)
          ? entry.candidateSelection : candidates[0]?.id || '';
        const value = { situationId: entry.situationId, positivePrompt: entry.positivePrompt, negativePrompt: entry.negativePrompt,
          ...(candidates.length ? { candidates } : {}),
          ...(candidateSelection ? { candidateSelection } : {}),
          ...(eventType ? { eventType, eventKind } : {}), ...(response ? { response } : {}) };
        entries.set(JSON.stringify([entry.situationId, eventType, eventKind, response]), value);
      }
      return [...entries.values()];
    }

    function normalizeButtonOutcomeCandidates(value) {
      if (!Array.isArray(value)) return [];
      const candidates = new Map();
      for (const entry of value.slice(0, 64)) {
        if (!entry || typeof entry.id !== 'string' || !/^[a-z0-9_-]{1,80}$/i.test(entry.id)
          || typeof entry.positivePrompt !== 'string' || entry.positivePrompt.length > 4000
          || typeof entry.negativePrompt !== 'string' || entry.negativePrompt.length > 4000) continue;
        const name = typeof entry.name === 'string' ? entry.name.trim().slice(0, 120) : '';
        candidates.set(entry.id, { id: entry.id, ...(name ? { name } : {}), positivePrompt: entry.positivePrompt, negativePrompt: entry.negativePrompt });
      }
      return [...candidates.values()];
    }

    function buttonOutcomeCandidate(outcome) {
      return (outcome?.candidates || []).find(candidate => candidate.id === outcome.candidateSelection
        && (candidate.positivePrompt.trim() || candidate.negativePrompt.trim())) || null;
    }

    function buttonPromptAfterRule(rule) {
      if (rule.mode !== 'shown') return { ...rule, mode: 'after' };
      return { ...rule, mode: 'after', positivePrompt: '', negativePrompt: '',
        legacyShownPrompt: { positivePrompt: rule.positivePrompt, negativePrompt: rule.negativePrompt } };
    }

    function reloadButtonPromptSettings(notify = true) {
      const saved = api.settings.get({ buttonPromptRules: [] }).buttonPromptRules;
      buttonPromptRules = normalizeButtonPromptRules(saved);
      buttonPromptRuleMap = new Map(buttonPromptRules.map(rule => [buttonPromptId(rule), rule]));
      buttonPromptAfter = null;
      buttonPromptCandidate = null;
      if (notify) notifyExternalPromptChange();
    }

    function saveButtonPromptRule(rule) {
      const id = buttonPromptId(rule);
      if (!validButtonPromptRule(rule) || (buttonPromptRules.length >= 256 && !buttonPromptRuleMap.has(id))) return;
      const normalized = normalizeButtonPromptRules([rule])[0];
      if (!normalized) return;
      buttonPromptRules = buttonPromptRules.filter(entry => buttonPromptId(entry) !== id);
      buttonPromptRules.push(normalized);
      buttonPromptRuleMap = new Map(buttonPromptRules.map(entry => [buttonPromptId(entry), entry]));
      api.settings.set({ buttonPromptRules });
      notifyExternalPromptChange();
    }

    function getButtonPromptRule(context, mode) {
      if (!context || mode !== 'after'
        || !validButtonPromptRule({ ...context, mode, positivePrompt: '', negativePrompt: '' })) return null;
      const rule = buttonPromptRuleMap.get(buttonPromptId(context));
      if (!rule || rule.mode !== mode || (!rule.positivePrompt.trim() && !rule.negativePrompt.trim())) return null;
      return { mode: rule.mode, positivePrompt: rule.positivePrompt, negativePrompt: rule.negativePrompt };
    }

    function buttonPromptRuleToken(context, mode) {
      const rule = getButtonPromptRule(context, mode);
      return rule ? shortHash(JSON.stringify([buttonPromptId(context), rule])) : '';
    }

    function buttonEventIdentity(event) {
      const type = typeof event?.type === 'string' && event.type.length <= 200 ? event.type : '';
      const kind = event?.alert?.kind || event?.kind || '';
      return type && typeof kind === 'string' && kind.length <= 200 ? { type, kind } : null;
    }

    function nativeChoiceSceneCandidates(choice) {
      if (!choice || choice.eventType !== 'wife_conversation' || !api.has('gamePressTopicTable')) return [];
      let table;
      try { table = api.fn('gamePressTopicTable'); } catch { return []; }
      const match = /^press_(.+)_\d+$/.exec(choice.choiceId);
      const entry = table?.[match ? match[1] : choice.choiceId];
      const scene = entry?.scene || entry?.startScene;
      if (typeof scene !== 'string' || !/^[a-z0-9_]+$/i.test(scene)) return [];
      const id = `scene-${scene}`;
      return nativeScenePromptCandidates(id).map(candidate => ({ ...candidate, situationId: id }));
    }

    function getButtonPromptOutcome(context, situationId, event = null, response = '') {
      if (!context || typeof situationId !== 'string' || !situationId || situationId.length > 200
        || situationId.includes('__') || !validButtonPromptRule({ ...context, mode: 'after', positivePrompt: '', negativePrompt: '' })) return null;
      const rule = buttonPromptRuleMap.get(buttonPromptId(context));
      if (rule?.mode !== 'after') return null;
      const outcomes = rule.outcomes || [];
      const identity = buttonEventIdentity(event);
      const scenes = [situationId, situationId.split('|')[0]];
      const responses = response ? [response, ''] : [''];
      const entry = scenes.flatMap(scene => responses.flatMap(value => [
        identity && outcomes.find(item => item.situationId === scene && item.response === (value || undefined)
          && item.eventType === identity.type && (item.eventKind || '') === identity.kind),
        outcomes.find(item => item.situationId === scene && item.response === (value || undefined) && !item.eventType),
      ])).find(Boolean);
      return entry ? { ...entry, ...(entry.candidates ? { candidates: entry.candidates.map(candidate => ({ ...candidate })) } : {}) } : null;
    }

    function buttonPromptOutcomeToken(context, situationId, event = null, response = '') {
      const outcome = getButtonPromptOutcome(context, situationId, event, response);
      if (!outcome || !(outcome.positivePrompt.trim() || outcome.negativePrompt.trim()
        || outcome.candidates?.some(candidate => candidate.positivePrompt.trim() || candidate.negativePrompt.trim()))) return '';
      const { candidates, ...rest } = outcome;
      return shortHash(JSON.stringify([buttonPromptId(context), { ...rest,
        ...(candidates ? { candidates: candidates.map(({ id, positivePrompt, negativePrompt }) => ({ id, positivePrompt, negativePrompt })) } : {}) }]));
    }

    function buttonEventContext(state, scene) {
      const event = state?.pendingEvent;
      const kind = event?.alert?.kind || event?.kind || '';
      if (!scene || scene.length > 200 || !event || typeof event.type !== 'string' || !event.type
        || event.type.length > 200 || typeof kind !== 'string' || kind.length > 200
        || !Array.isArray(event.choices) || event.choices.length > 256) return [];
      const counts = new Map();
      for (const choice of event.choices) if (typeof choice?.id === 'string' && choice.id)
        counts.set(choice.id, (counts.get(choice.id) || 0) + 1);
      return event.choices.filter(choice => typeof choice?.id === 'string' && choice.id && choice.id.length <= 200
        && counts.get(choice.id) === 1 && !choice.disabled).map(choice => ({
          scene, eventType: event.type, eventKind: kind,
          choiceId: choice.id, label: String(choice.label || choice.text || choice.id).slice(0, 200),
        }));
    }

    function buttonSceneIdentity(state, scene) {
      const id = state?.primaryCharacterId;
      const character = id && state.characters?.[id];
      const patron = state?.activeScene?.patron, sex = state?.activeScene?.sex;
      const situation = state?.activeScene?.situation;
      if (!character || !scene || (patron && sex)) return '';
      const active = patron || sex;
      if (active?.characterId != null && active.characterId !== id) return '';
      if ((active?.crowdPatronIds?.length || 0) || (active?.joinedPatronIds?.length || 0)
        || (situation?.patronIds?.length || 0) > 1) return '';
      const started = active?.startedAtSlot ?? situation?.startedAtSlot ?? null;
      if (!Number.isFinite(state.day) || (active && !Number.isFinite(started))) return '';
      if (patron && (patron.customerId == null || !patron.stage)) return '';
      // shortcut: a save restored with the same scene identifiers cannot be distinguished, until the game exposes load identity.
      return JSON.stringify([id, state.day, scene, patron ? 'patron' : sex ? 'you' : 'other',
        patron?.customerId ?? situation?.patronIds?.[0] ?? '', patron?.stage ?? sex?.type ?? '',
        situation?.situationId ?? '', started]);
    }

    function buttonActionChoiceId(event, action) {
      if (event?.type === 'sex_scene' && action?.type === 'scene_action') return action.actionId;
      if (event?.type === 'patron_interaction' && action?.type === 'patron_interaction_choice') return action.choiceId;
      if (event?.type === 'wife_conversation' && action?.type === 'wife_topic') return action.topicId;
      if (!['sex_scene', 'patron_interaction', 'wife_conversation'].includes(event?.type)
        && action?.type === 'resolve_event') return action.choiceId;
      return null;
    }

    function buttonSameStateContext(before, current) {
      if (!before || !current || !before.primaryCharacterId || before.primaryCharacterId !== current.primaryCharacterId)
        return false;
      const id = before.primaryCharacterId;
      return before.pendingEvent === current.pendingEvent
        && before.activeScene === current.activeScene && before.characters?.[id] != null
        && before.characters[id] === current.characters?.[id]
        && before.day === current.day && before.slot === current.slot;
    }

    function buttonSameInputContext(before, current) {
      return before?.pendingEvent != null && buttonSameStateContext(before, current);
    }

    function buttonSameResultContext(result, current) {
      if (!result || !current || !result.primaryCharacterId || result.primaryCharacterId !== current.primaryCharacterId
        || result.pendingEvent !== current.pendingEvent || result.activeScene !== current.activeScene
        || result.day !== current.day || result.slot !== current.slot || result.locations !== current.locations) return false;
      const a = result.characters?.[result.primaryCharacterId], b = current.characters?.[current.primaryCharacterId];
      if (!a || !b) return false;
      if (!result.activeScene && !result.pendingEvent && (!result.customers || result.customers !== current.customers)) return false;
      return ['id', 'archetypeId', 'generatedArchetype', 'sceneOverride', 'sceneVariant', 'currentTask',
        'lookFocus', 'lookFocusReaction', 'outfit', 'exposure', 'aftermathTags', 'stats', 'location']
        .every(field => a[field] === b[field]);
    }

    function buttonFreshWifeResponse(before, result, action) {
      if (before?.pendingEvent?.type !== 'wife_conversation' || action?.type !== 'wife_topic'
        || before.primaryCharacterId !== result?.primaryCharacterId) return '';
      const oldWife = before.characters?.[before.primaryCharacterId], wife = result.characters?.[result.primaryCharacterId];
      if (!oldWife || !wife || typeof wife.lastResponse !== 'string' || !wife.lastResponse
        || !['accept', 'eager', 'hesitant', 'refuse', 'angry', 'neutral'].includes(wife.lastResponseType)
        || !Number.isFinite(wife.lastResponseSlot) || !Number.isFinite(before.slot) || !Number.isFinite(result.slot)
        || wife.lastResponseSlot < before.slot || wife.lastResponseSlot > result.slot
        || (wife.lastResponse === oldWife.lastResponse && wife.lastResponseSlot === oldWife.lastResponseSlot
          && wife.lastResponseType === oldWife.lastResponseType)) return '';
      return wife.lastResponseType;
    }

    function buttonPromptGroups(state, characterId, imageKey, planning = false) {
      if (!buttonPromptRules.length || planning || !state || !characterId || characterId !== state.primaryCharacterId
        || (state.activeScene?.sex && state.activeScene?.patron)
        || /(?:^|__)(?:grp|gslot)-/.test(String(imageKey))) return { positive: [], negative: [] };
      const active = state.activeScene?.patron || state.activeScene?.sex;
      if ((active?.characterId != null && active.characterId !== characterId)
        || (active?.crowdPatronIds?.length || 0) || (active?.joinedPatronIds?.length || 0))
        return { positive: [], negative: [] };
      const scene = positionSituationId(imageKey).split('|')[0];
      const rules = [];
      // The store can notify its subscribers before WML's action observer runs.
      let after = buttonSameResultContext(buttonPromptCandidate?.result, state) && api.store.game() === state
        ? buttonPromptCandidate : buttonPromptAfter;
      if (after?.followup && JSON.stringify(buttonEventIdentity(state.pendingEvent)) !== JSON.stringify(after.followup)) {
        if (api.store.game() === state) {
          if (buttonPromptAfter === after) buttonPromptAfter = null;
          if (buttonPromptCandidate === after) buttonPromptCandidate = null;
        }
        after = null;
      }
      if (after?.scene && after.scene !== scene && buttonPortraitDepth && api.store.game() === state) {
        if (buttonPromptAfter === after) buttonPromptAfter = null;
        if (buttonPromptCandidate === after) buttonPromptCandidate = null;
      }
      if (after && !after.scene && buttonPortraitDepth && buttonSameResultContext(after.result, state) && (scene !== after.beforeScene || after.followup || after.response)
        && String(imageKey).split('__')[0] === after.portraitOwner) {
        const identity = buttonSceneIdentity(state, scene);
        if (identity) { after.scene = scene; after.identity = identity; }
      }
      if (after && after.identity && after.identity === buttonSceneIdentity(state, scene) && after.scene === scene) {
        const rule = buttonPromptRuleMap.get(after.id);
        if (rule?.mode === 'after') {
          rules.push(rule);
          const outcome = getButtonPromptOutcome(rule, positionSituationId(imageKey), state.pendingEvent, after.response);
          if (outcome) {
            const label = `${rule.label || rule.choiceId} · 결과 ${positionSituationLabel(outcome.situationId)}`;
            rules.push({ ...rule, ...outcome, label });
            const candidate = buttonOutcomeCandidate(outcome);
            if (candidate) rules.push({ ...rule, ...candidate, label: `${label} · 후보` });
          }
        }
      }
      const makeGroups = field => rules.filter(rule => rule[field].trim()).map(rule => ({
        id: 'buttonChoice', label: `선택지: ${rule.label || rule.choiceId}`,
        value: { codes: [`choice-${rule.eventType}-${rule.choiceId}`], tags: [rule[field].trim()] },
      }));
      return { positive: makeGroups('positivePrompt'), negative: makeGroups('negativePrompt') };
    }

    function installButtonPromptObserver() {
      if (!api.has('reduceGameAction') || !api.actions?.observe) return;
      if (api.has('currentPortraitImageKey')) api.hook('currentPortraitImageKey', { around(next, ...args) {
        buttonPortraitDepth++;
        try { return next(...args); } finally { buttonPortraitDepth--; }
      } });
      api.hook('reduceGameAction', { priority: Number.MIN_SAFE_INTEGER, before([, action]) {
        buttonPromptCandidate = null;
        if (/^(?:load|new|reset)/i.test(action?.type || '')) {
          buttonPromptAfter = null;
          buttonPromptCandidate = null;
        }
      }, after(result, [before, action]) {
        if (!buttonPromptRules.length) return result;
        const choiceId = buttonActionChoiceId(before?.pendingEvent, action);
        if (typeof choiceId !== 'string' || !result || result === before) return result;
        if (!api.has('currentPortraitImageKey') || !buttonSameInputContext(before, api.store.game())
          || !buttonPromptRules.some(rule => rule.mode === 'after' && rule.eventType === before.pendingEvent.type && rule.choiceId === choiceId)) return result;
        let beforeKey = '';
        try { beforeKey = activePortraitImageKey('', before); } catch { return result; }
        const beforeScene = positionSituationId(beforeKey).split('|')[0];
        const context = buttonEventContext(before, beforeScene).find(entry => entry.choiceId === choiceId);
        const rule = context && buttonPromptRuleMap.get(buttonPromptId(context));
        if (rule?.mode === 'after' && result.primaryCharacterId === before.primaryCharacterId
          && buttonSceneIdentity(result, 'pending') && beforeScene && String(beforeKey).split('__')[0]) {
          const beforeEvent = buttonEventIdentity(before.pendingEvent), resultEvent = buttonEventIdentity(result.pendingEvent);
          const followup = resultEvent && JSON.stringify(resultEvent) !== JSON.stringify(beforeEvent) ? resultEvent : null;
          const response = buttonFreshWifeResponse(before, result, action);
          buttonPromptCandidate = { action, result, scene: '', identity: '', beforeScene, followup, response,
            portraitOwner: String(beforeKey).split('__')[0], id: buttonPromptId(context) };
        }
        return result;
      } });
      api.actions.observe(({ type, action }) => {
        const candidate = buttonPromptCandidate;
        buttonPromptCandidate = null;
        if (!candidate && !buttonPromptAfter) return;
        const state = api.store.game();
        if (/^(?:load|new|reset)/i.test(type)) buttonPromptAfter = null;
        else if (candidate && candidate.action === action && buttonSameResultContext(candidate.result, state)) buttonPromptAfter = candidate;
        else if (buttonPromptAfter?.response && action !== buttonPromptAfter.action) buttonPromptAfter = null;
        else if (buttonPromptAfter?.identity && (buttonPromptAfter.identity !== buttonSceneIdentity(state, buttonPromptAfter.scene)
          || buttonPromptAfter.followup && JSON.stringify(buttonEventIdentity(state.pendingEvent)) !== JSON.stringify(buttonPromptAfter.followup))) buttonPromptAfter = null;
      });
    }

    function renderButtonPrompts(h, win) {
      const state = api.store.game();
      const currentKey = activePortraitImageKey('', state);
      const scene = positionSituationId(currentKey).split('|')[0];
      const current = state?.primaryCharacterId ? buttonEventContext(state, scene) : [];
      const currentIds = new Set(current.map(buttonPromptId));
      const options = new Map(buttonPromptRules.map(rule => [buttonPromptId(rule), rule]));
      for (const choice of current) if (!options.has(buttonPromptId(choice))) options.set(buttonPromptId(choice), choice);
      if (api.has('gamePressTopicTable')) {
        let table;
        try { table = api.fn('gamePressTopicTable'); } catch { table = null; }
        for (const choice of [...current, ...buttonPromptRules]) {
          if (choice.eventType !== 'wife_conversation') continue;
          const base = /^press_(.+)_\d+$/.exec(choice.choiceId)?.[1] || choice.choiceId;
          if (!table?.[base]) continue;
          for (const stage of [1, 2]) {
            const entry = { scene: choice.scene, eventType: choice.eventType, eventKind: choice.eventKind, choiceId: `press_${base}_${stage}`,
              label: `${base} · ${stage === 1 ? '거절 후 밀어붙이기' : '다시 강하게 밀어붙이기'}` };
            const id = buttonPromptId(entry);
            if (!options.has(id)) options.set(id, entry);
          }
        }
      }
      const selected = options.get(buttonPromptSelection) || current[0] || buttonPromptRules[0];
      if (selected) buttonPromptSelection = buttonPromptId(selected);
      const storedRule = selected && buttonPromptRuleMap.get(buttonPromptSelection);
      const rule = selected && buttonPromptAfterRule(storedRule || {
        ...selected, mode: 'after', positivePrompt: '', negativePrompt: '',
      });
      const choiceNativeVariants = nativeChoiceSceneCandidates(selected);
      const outcomeOptions = new Map();
      if (rule?.mode === 'after') {
        for (const item of scenePromptCatalog()) outcomeOptions.set(item.id, item.label);
        for (const item of rule.outcomes || []) if (!outcomeOptions.has(item.situationId))
          outcomeOptions.set(item.situationId, positionSituationLabel(item.situationId));
        if (buttonPromptAfter?.id === buttonPromptSelection && buttonPromptAfter.identity === buttonSceneIdentity(state, scene)) {
          const observed = positionSituationId(currentKey);
          if (observed && !outcomeOptions.has(observed)) outcomeOptions.set(observed, positionSituationLabel(observed));
        }
        if (!outcomeOptions.has(buttonOutcomeSelection)) buttonOutcomeSelection = rule.outcomes?.[0]?.situationId
          || choiceNativeVariants[0]?.situationId || (outcomeOptions.has(selected.scene) ? selected.scene : outcomeOptions.keys().next().value) || '';
      }
      const canSave = buttonPromptRuleMap.has(buttonPromptSelection) || buttonPromptRules.length < 256;
      const save = (patch, updateView = false) => {
        saveButtonPromptRule({ ...buttonPromptAfterRule(buttonPromptRuleMap.get(buttonPromptSelection) || rule), ...patch });
        if (updateView) { refreshPortraitImage(); win.refresh(); }
      };
      return h('div', { 'data-button-prompt-editor': '' },
        h('p', { class: 'wml-muted wml-small' }, '선택 후 확인된 반응·결과별로 프롬프트 후보를 설정해요. 밀어붙이기 항목은 게임이 허용할 때 나타나요.'),
        storedRule?.mode === 'shown' || storedRule?.legacyShownPrompt ? h('p', { class: 'wml-note' }, '이전의 표시 중 문구는 보관하지만 적용하지 않아요. 결과별로 다시 작성해 주세요.') : null,
        !canSave ? h('p', { class: 'wml-note' }, '선택지 설정은 최대 256개예요. 저장한 항목을 삭제한 뒤 추가해 주세요.') : null,
        options.size ? h('label', { style: 'display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:10px 0;' }, '편집할 선택지', h('select', { value: buttonPromptSelection, 'data-button-prompt-select': '', style: 'max-width:100%;',
          onchange: event => { buttonPromptSelection = event.currentTarget.value; buttonOutcomeSelection = ''; buttonOutcomeEvent = ''; buttonOutcomeResponse = ''; win.refresh(); } },
          ...[...options.entries()].map(([id, entry]) => h('option', { value: id, selected: id === buttonPromptSelection },
            `${entry.label || entry.choiceId} · ${currentIds.has(id) ? '현재 표시 중' : '저장됨'}`))))
          : h('p', {}, '현재 편집할 선택지가 없어요. 선택지가 보이는 장면에서 다시 열어 주세요.'),
        selected ? h('p', { class: 'wml-muted wml-small', 'data-button-prompt-identity': '', style: 'overflow-wrap:anywhere;' },
          `장면: ${positionSituationLabel(selected.scene)} · 이벤트 ID: `,
          h('code', {}, `${selected.eventType}${selected.eventKind ? `/${selected.eventKind}` : ''}`),
          ' · 선택지 ID: ', h('code', {}, selected.choiceId)) : null,
        rule ? h('div', {},
          rule.mode === 'after' ? (() => {
            const events = new Map([['', '모든 후속 이벤트']]);
            for (const item of rule.outcomes || []) if (item.situationId === buttonOutcomeSelection && item.eventType)
              events.set(JSON.stringify([item.eventType, item.eventKind || '']), `${item.eventType}${item.eventKind ? ` / ${item.eventKind}` : ''}`);
            if (buttonPromptAfter?.id === buttonPromptSelection && buttonPromptAfter.scene === buttonOutcomeSelection && buttonPromptAfter.followup) {
              const { type, kind } = buttonPromptAfter.followup;
              events.set(JSON.stringify([type, kind]), `${type}${kind ? ` / ${kind}` : ''} · 현재 확인됨`);
            }
            if (!events.has(buttonOutcomeEvent)) buttonOutcomeEvent = '';
            const [eventType, eventKind] = buttonOutcomeEvent ? JSON.parse(buttonOutcomeEvent) : ['', ''];
            const matchesOutcome = item => item.situationId === buttonOutcomeSelection
              && (item.eventType || '') === eventType && (item.eventKind || '') === eventKind
              && (item.response || '') === buttonOutcomeResponse;
            const outcome = (rule.outcomes || []).find(matchesOutcome);
            const updateOutcome = (patch, updateView = false) => {
              const currentRule = buttonPromptAfterRule(buttonPromptRuleMap.get(buttonPromptSelection) || rule);
              const next = (currentRule.outcomes || []).filter(item => !matchesOutcome(item));
              const previous = (currentRule.outcomes || []).find(matchesOutcome);
              next.push({ situationId: buttonOutcomeSelection, positivePrompt: '', negativePrompt: '',
                ...(eventType ? { eventType, eventKind } : {}), ...(buttonOutcomeResponse ? { response: buttonOutcomeResponse } : {}), ...previous, ...patch });
              saveButtonPromptRule({ ...currentRule, outcomes: next });
              if (updateView) { refreshPortraitImage(); win.refresh(); }
            };
            const candidates = outcome?.candidates || [];
            buttonOutcomeCandidateId = outcome?.candidateSelection || candidates[0]?.id || '';
            const chosen = candidates.find(candidate => candidate.id === buttonOutcomeCandidateId);
            const changeCandidate = (id, patch, updateView = false) => {
              const currentRule = buttonPromptAfterRule(buttonPromptRuleMap.get(buttonPromptSelection) || rule);
              const currentOutcome = (currentRule.outcomes || []).find(matchesOutcome);
              const next = (currentOutcome?.candidates || []).map(candidate => candidate.id === id ? { ...candidate, ...patch } : candidate);
              updateOutcome({ candidates: next }, updateView);
            };
            const linked = choiceNativeVariants.some(candidate => candidate.situationId === buttonOutcomeSelection.split('|')[0])
              && ['', 'accept', 'eager'].includes(buttonOutcomeResponse);
            return h('section', { 'data-choice-outcomes': '', style: 'display:grid;gap:8px;margin:16px 0;' },
              h('strong', {}, '선택 후 결과 장면별 프롬프트'),
              h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '확인된 결과와 일치할 때 공통 문구에 추가돼요. 아내 대화의 새 반응만 반응별로 구분하며, 확인할 수 없는 반응에는 적용하지 않아요.'),
              h('label', {}, '결과 장면 ', h('select', { value: buttonOutcomeSelection, 'data-choice-outcome-select': '',
                onchange: event => { buttonOutcomeSelection = event.currentTarget.value; buttonOutcomeEvent = ''; win.refresh(); } },
                ...[...outcomeOptions.entries()].map(([id, label]) => h('option', { value: id, selected: id === buttonOutcomeSelection }, label)))),
              h('label', {}, '후속 이벤트 ', h('select', { value: buttonOutcomeEvent, 'data-choice-outcome-event': '',
                onchange: event => { buttonOutcomeEvent = event.currentTarget.value; win.refresh(); } },
                ...[...events.entries()].map(([value, label]) => h('option', { value, selected: value === buttonOutcomeEvent }, label)))),
              h('label', {}, '아내 반응 ', h('select', { value: buttonOutcomeResponse, 'data-choice-outcome-response': '',
                onchange: event => { buttonOutcomeResponse = event.currentTarget.value; win.refresh(); } },
                ...[['', '모든 반응'], ['accept', '수락'], ['eager', '적극적 수락'], ['hesitant', '망설임'], ['refuse', '거절'], ['angry', '분노'], ['neutral', '중립']]
                  .map(([value, label]) => h('option', { value, selected: value === buttonOutcomeResponse }, label)))),
              linked && typeof renderSceneCandidateEditor === 'function' ? h('div', { 'data-choice-shared-scene-candidates': '' },
                h('p', { class: 'wml-note' }, `이 결과의 게임 후보는 장면 프롬프트의 ${positionSituationLabel(buttonOutcomeSelection)} 기본 장면 부분과 공유돼요. 여기서 수정하면 그 장면에서도 바뀌어요.`),
                renderSceneCandidateEditor(h, win, buttonOutcomeSelection, currentKey)) : null,
              outcome ? h('div', { class: 'aip-prompt-pair' }, ...[['positivePrompt', 'Positive · 결과에 추가'], ['negativePrompt', 'Negative · 결과에서 피할 내용']].map(([field, label]) =>
                h('label', { class: 'aip-prompt-field' }, h('strong', {}, label), h('textarea', { rows: 3, value: outcome[field], spellcheck: false, maxLength: 4000,
                  'data-choice-outcome-field': field,
                  style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:80px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
                  onfocus: () => { activeTagTarget = { kind: 'button-outcome', id: buttonPromptSelection, situationId: buttonOutcomeSelection, eventType, eventKind, response: buttonOutcomeResponse, field, label: `선택지 결과 ${label}` }; },
                  oninput: event => { updateOutcome({ [field]: event.currentTarget.value }); updatePromptTagPreview(event, h, win); },
                  onchange: event => updateOutcome({ [field]: event.currentTarget.value }, true),
                }), promptTagPreview(h, outcome[field], win)))) : h('button', { type: 'button', class: 'wml-btn', 'data-choice-add-outcome': '',
                  disabled: !buttonOutcomeSelection || (rule.outcomes || []).length >= 128,
                  onclick: () => updateOutcome({ candidates: [{ id: 'candidate-1', positivePrompt: '', negativePrompt: '' }], candidateSelection: 'candidate-1' }, true) }, '이 반응의 후보 추가'),
              outcome ? h('div', { 'data-choice-branch-candidates': '', style: 'display:grid;gap:6px;' },
                h('strong', {}, '이 반응만의 프롬프트 후보'),
                h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '이 반응에 추가할 후보 하나를 선택해요. 장면 공통 후보는 위에서 수정해요.'),
                candidates.length ? h('label', {}, '후보 ', h('select', { 'data-choice-candidate-select': '', value: buttonOutcomeCandidateId,
                  onchange: event => { buttonOutcomeCandidateId = event.currentTarget.value; updateOutcome({ candidateSelection: buttonOutcomeCandidateId }, true); } },
                  ...candidates.map((candidate, index) => h('option', { value: candidate.id, selected: candidate.id === buttonOutcomeCandidateId }, `${candidate.name || `후보 ${index + 1}`}${candidate.id === outcome.candidateSelection ? ' · 적용 중' : ''}`)))) : null,
                chosen ? h('label', { class: 'aip-prompt-field' }, h('strong', {}, '후보 이름'), h('input', {
                  type: 'text', value: chosen.name || '', maxLength: 120, placeholder: '이름을 입력하세요', 'data-choice-candidate-name': '',
                  onfocus: () => { activeTagTarget = null; },
                  oninput: event => changeCandidate(chosen.id, { name: event.currentTarget.value }),
                  onchange: event => { changeCandidate(chosen.id, { name: event.currentTarget.value }); win.refresh(); },
                })) : null,
                chosen ? h('div', { class: 'aip-prompt-pair' }, ...[['positivePrompt', 'Positive · 후보 문구'], ['negativePrompt', 'Negative · 후보 문구']].map(([field, label]) =>
                  h('label', { class: 'aip-prompt-field' }, h('strong', {}, label), h('textarea', { rows: 3, value: chosen[field], spellcheck: false, maxLength: 4000,
                    'data-choice-candidate-field': field,
                    style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:80px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
                    onfocus: () => { activeTagTarget = { kind: 'button-outcome-candidate', id: buttonPromptSelection, situationId: buttonOutcomeSelection, eventType, eventKind, response: buttonOutcomeResponse, candidateId: chosen.id, field, label: `선택지 후보 ${label}` }; },
                    oninput: event => { changeCandidate(chosen.id, { [field]: event.currentTarget.value }); updatePromptTagPreview(event, h, win); },
                    onchange: event => changeCandidate(chosen.id, { [field]: event.currentTarget.value }, true),
                  }), promptTagPreview(h, chosen[field], win)))) : null,
                h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;' },
                  api.ui.button('후보 추가', () => {
                    let index = 1;
                    while (candidates.some(candidate => candidate.id === `candidate-${index}`)) index++;
                    buttonOutcomeCandidateId = `candidate-${index}`;
                    updateOutcome({ candidates: [...candidates, { id: buttonOutcomeCandidateId, positivePrompt: '', negativePrompt: '' }], candidateSelection: buttonOutcomeCandidateId }, true);
                  }, { disabled: candidates.length >= 64 }),
                  chosen ? api.ui.button('이 후보 삭제', () => {
                    buttonOutcomeCandidateId = '';
                    const remaining = candidates.filter(candidate => candidate.id !== chosen.id);
                    updateOutcome({ candidates: remaining, candidateSelection: remaining[0]?.id || '' }, true);
                  }) : null)) : null,
              outcome ? api.ui.button('이 결과 설정 삭제', () => { save({ outcomes: (rule.outcomes || []).filter(item => !matchesOutcome(item)) }, true); }) : null);
          })() : null,
          h('strong', {}, '선택 후 공통 추가 문구'),
          h('div', { class: 'aip-prompt-pair' }, ...[['positivePrompt', 'Positive · 표현할 내용'], ['negativePrompt', 'Negative · 피할 내용']].map(([field, label]) =>
            h('label', { class: 'aip-prompt-field' }, h('strong', {}, label), h('textarea', { rows: 3, value: rule[field], spellcheck: false, maxLength: 4000, disabled: !canSave, 'data-button-prompt-field': field,
              style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:80px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
              onfocus: () => { activeTagTarget = { kind: 'button-prompt', id: buttonPromptSelection, rule, field, label: `선택지 ${label}` }; },
              oninput: event => { save({ [field]: event.currentTarget.value }); updatePromptTagPreview(event, h, win); },
              onchange: event => save({ [field]: event.currentTarget.value }, true) }),
              promptTagPreview(h, rule[field], win)))),
          api.ui.button('선택지 설정 삭제', () => {
            buttonPromptRules = buttonPromptRules.filter(entry => buttonPromptId(entry) !== buttonPromptId(rule));
            buttonPromptRuleMap = new Map(buttonPromptRules.map(entry => [buttonPromptId(entry), entry]));
            api.settings.set({ buttonPromptRules }); notifyExternalPromptChange();
            buttonPromptSelection = ''; buttonOutcomeSelection = ''; buttonOutcomeEvent = ''; buttonOutcomeResponse = ''; refreshPortraitImage(); win.refresh();
          })) : null);
    }

    reloadButtonPromptSettings(false);
