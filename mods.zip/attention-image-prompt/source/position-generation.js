    function selectedPositionChoice() {
      if (positionSelection.situationId !== latestScenePrompt?.situationId) return null;
      const preset = positionPresetById(positionSelection.presetId);
      const count = positionGroupCount(latestScenePrompt.situationId);
      const details = effectivePositionDetails(preset, positionSelection.details, count);
      if (!preset && !details && typeof positionSelection.personPrompt !== 'string') return null;
      return { presetId: preset?.id || '', preset, groupSlots: selectedPositionGroupSlots(), details,
        ...(typeof positionSelection.personPrompt === 'string' ? { personPrompt: positionSelection.personPrompt } : {}) };
    }

    function nextPositionVariant(baseKey) {
      if (api.has('imageVariantState')) {
        try {
          const choice = similarImageChoice(baseKey);
          const used = new Set([...(api.fn('imageVariantState')(baseKey)?.variants || []),
            ...(unusedPortraitImages()[similarImageSituationKey(baseKey)] || []),
            ...(choice?.autoVariants || []), ...Object.keys(choice?.manualVariants || {})]
            .map(key => Number(String(key).match(/__v-(\d+)$/)?.[1]))
            .filter(Number.isFinite));
          let next = USER_VARIANT_START;
          while (used.has(next)) next += 1;
          return next;
        } catch (error) {
          console.warn('[attention-image-prompt] image variant lookup', error);
        }
      }
      positionVariantId = Math.max(Date.now(), positionVariantId + 1);
      return positionVariantId;
    }

    function currentImageVariant(imageKey) {
      if (!api.has('imageVariantState')) return imageKey;
      try {
        const current = api.fn('imageVariantState')(imageKey);
        return current?.variants?.[current.currentIdx] || imageKey;
      } catch (error) {
        console.warn('[attention-image-prompt] image variant lookup', error);
        return imageKey;
      }
    }

    function addPositionVariant(baseKey, variantKey, previousKey) {
      if (!api.has('imageVariantState') || !api.has('saveImageVariantState')) return false;
      try {
        const current = api.fn('imageVariantState')(baseKey) || { variants: [], currentIdx: 0 };
        const variants = [...new Set([...(current.variants?.length ? current.variants : previousKey ? [previousKey] : []), variantKey])];
        api.fn('saveImageVariantState')(baseKey, { variants, currentIdx: variants.indexOf(variantKey) });
        return true;
      } catch (error) {
        console.warn('[attention-image-prompt] image variant save', error);
        return false;
      }
    }

    function isSavedPositionImageKey(imageKey) {
      const data = api.data.get() || {};
      return [data.positionOverrides, data.positionModuleOverrides].some(saved => saved && typeof saved === 'object'
        && Object.entries(saved).slice(-200).some(([situationId, value]) =>
          normalizeSavedPositionOverride(situationId, value)?.generatedKeys.includes(imageKey)));
    }

    function positionPortraitImage() {
      if (!latestScenePrompt?.characterName) return null;
      return [...document.querySelectorAll('img')]
        .find(node => String(node.alt || '').startsWith(`${latestScenePrompt.characterName} -`)) || null;
    }

    let portraitImageRefresh = 0;
    function showGeneratedPositionImage(url, regenerated = false) {
      if (!url) return;
      const image = positionPortraitImage();
      if (!image) return;
      const previous = image.getAttribute?.('src') || image.src;
      const displayed = regenerated && /^(?:https?:|\/|images\/)/i.test(url)
        ? `${url}${url.includes('?') ? '&' : '?'}aip_refresh=${Date.now()}_${++portraitImageRefresh}` : url;
      // shortcut: the game keeps this URL in React-local state; use its setter until a supported one exists.
      const fiberName = Object.keys(image).find(name => name.startsWith('__reactFiber'));
      for (let fiber = image[fiberName], depth = 0; fiber && depth < 5; fiber = fiber.return, depth += 1) {
        for (let hook = fiber.memoizedState, index = 0; hook && index < 80; hook = hook.next, index += 1) {
          if (hook.memoizedState !== previous && hook.memoizedState !== image.src) continue;
          if (typeof hook.queue?.dispatch !== 'function') continue;
          hook.queue.dispatch(displayed);
          return;
        }
      }
      image.src = displayed;
    }

    async function generatePositionImage(addVariant, win) {
      const activeKey = latestScenePrompt ? activePortraitImageKey(latestScenePrompt.result.key) : '';
      const activeSituationId = positionSituationId(activeKey) || latestScenePrompt?.situationId || '';
      const statePrompt = currentPositionStatePrompt(activeSituationId);
      const onlyState = positionStateOnly(statePrompt);
      const choice = onlyState ? null : positionMode() === 'modules'
        ? positionModuleChoice(activeSituationId, latestScenePrompt?.characterId, latestScenePrompt?.result.key) : selectedPositionChoice();
      const preset = choice?.preset;
      if (!latestScenePrompt || (!addVariant && !choice && !statePrompt?.positivePrompt && !statePrompt?.negativePrompt)) {
        positionGeneration.message = '체위 프리셋·모듈 조합 또는 상태 추가 프롬프트를 먼저 지정해 주세요.';
        win.refresh();
        return;
      }
      if (!api.has('imageGenerate')) {
        positionGeneration.message = '이미지 생성 기능을 찾지 못했습니다.';
        win.refresh();
        return;
      }
      positionGeneration.running = true;
      positionGeneration.message = '이미지 생성 중…';
      win.refresh();
      const scene = latestScenePrompt;
      const gameState = api.store.game();
      const sceneCharacter = gameState?.characters?.[scene.characterId];
      if (!sceneCharacter) {
        positionGeneration.running = false;
        positionGeneration.message = '현재 인물 정보를 찾지 못했습니다.';
        win.refresh();
        return;
      }
      let currentResult;
      try {
        if (!latestPromptArgs?.length) throw new Error('현재 장면의 프롬프트 기록이 없습니다. 초상화를 다시 열어 주세요.');
        flushCurrentWifePromptEdit(gameState);
        const [capturedCharacter, ...promptArgs] = latestPromptArgs;
        currentResult = api.fn('imagePrompt')(sceneCharacter, ...promptArgs);
        if (positionSituationId(currentResult?.key) !== activeSituationId
          && characterIdOf(gameState, capturedCharacter) === scene.characterId) {
          // The visible portrait can lag a scene transition; retry its captured character.
          const capturedResult = api.fn('imagePrompt')(capturedCharacter, ...promptArgs);
          if (positionSituationId(capturedResult?.key) === activeSituationId) currentResult = capturedResult;
        }
        if (!Array.isArray(currentResult?.parts) || positionSituationId(currentResult.key) !== activeSituationId) {
          throw new Error('현재 장면의 프롬프트를 다시 읽지 못했습니다. 초상화를 다시 열어 주세요.');
        }
        if (String(currentResult.key).split('__')[0] !== String(scene.result.key).split('__')[0]) {
          throw new Error('현재 아내가 바뀌었습니다. 초상화를 다시 열어 주세요.');
        }
      } catch (error) {
        positionGeneration.running = false;
        positionGeneration.message = `생성 취소: ${error.message || error}`;
        win.refresh();
        return;
      }
      const currentOverride = positionOverride(activeSituationId);
      const matchingOverride = currentOverride && (onlyState
        ? Boolean(currentOverride.stateOnlySignature)
        : !currentOverride.stateOnlySignature) ? currentOverride : null;
      const targetKey = situationImageKey(activeKey, gameState, sceneCharacter, scene.characterId,
        onlyState ? matchingOverride : choice);
      const continuesCurrentVariant = matchingOverride?.imageKey === activeKey
        && similarImageSituationKey(activeKey) === similarImageSituationKey(targetKey);
      const sourceKey = continuesCurrentVariant && /__aipk?-/.test(matchingOverride.sourceKey)
        ? matchingOverride.sourceKey : targetKey;
      const stateKey = continuesCurrentVariant ? matchingOverride.stateKey || sourceKey : sourceKey;
      const sameSituation = similarImageSituationKey(sourceKey) === similarImageSituationKey(activeKey);
      const previousKey = sameSituation ? currentImageVariant(sourceKey) : '';
      const portrait = positionPortraitImage();
      const previousUrl = String(portrait?.currentSrc || portrait?.src || '');
      const positioned = applyPromptModRules(applyPositionPreset({ ...currentResult, key: activeKey }, choice, scene.characterId));
      const variant = addVariant ? nextPositionVariant(sourceKey) : null;
      const imageKey = addVariant
        ? /__v-\d+$/.test(sourceKey) ? sourceKey.replace(/__v-\d+$/, `__v-${variant}`) : `${sourceKey}__v-${variant}`
        : continuesCurrentVariant
          ? matchingOverride.imageKey
          : targetKey;
      try {
        const override = {
          presetId: preset?.id || '',
          groupSlots: choice?.groupSlots || '',
          ...(choice?.details ? { details: choice.details } : {}),
          ...(typeof choice?.personPrompt === 'string' ? { personPrompt: choice.personPrompt } : {}),
          ...(choice?.moduleSignature ? { moduleSignature: choice.moduleSignature } : {}),
          sourceKey,
          stateKey,
          imageKey,
          globalExclusionSignature: globalPromptExclusionsFingerprint(),
          cameraSignature: cameraSettingsFingerprint(scene.situationId),
          generatedKeys: [...(currentOverride?.generatedKeys || []), imageKey],
          ...(addVariant ? { pendingPreviousKey: previousKey } : {}),
          ...(onlyState ? { stateOnlySignature: positionStateOnlySignature(statePrompt) } : {}),
          ...(!onlyState && positionMode() === 'modules' ? { manual: true } : {}),
          ...(!onlyState && positionMode() === 'legacy' && positionSelection.manual ? { manual: true } : {}),
          ...(!onlyState && positionMode() === 'legacy' && !positionSelection.manual && autoPositionPresets()
            && !matchingPositionRuleId(scene.situationId, currentPositionRules()) ? { automatic: true } : {}),
        };
        const params = positioned.genParams || promptGenParams(positioned.prompt);
        const result = await api.fn('imageGenerate')({
          imageKey,
          prompt: positioned.prompt,
          negativePrompt: positioned.negativePrompt || '',
          width: 1216,
          height: 832,
          steps: params?.steps,
          cfg: params?.cfg,
          loraStrength: params?.loraStrength,
          checkpoint: positioned.checkpoint,
          ...(positioned.look === undefined ? {} : { look: positioned.look }),
          bypassCache: !addVariant,
          debug: { source: 'attention-image-prompt-position' },
        });
        if (!result?.url) throw new Error('이미지 서버에서 결과를 받지 못했습니다.');
        positionGeneratedResults.set(imageKey, result);
        let variantSaved = true;
        if (addVariant) {
          if (sameSituation && previousUrl && previousKey !== imageKey) {
            positionGeneratedResults.set(previousKey, { ...positionGeneratedResults.get(previousKey), url: previousUrl });
          }
          variantSaved = addPositionVariant(sourceKey, imageKey, previousKey);
        }
        setPositionOverride(activeSituationId, override);
        showGeneratedPositionImage(String(result.url), !addVariant);
        const label = choice?.modules?.length ? '모듈 조합' : preset?.name || (typeof choice?.personPrompt === 'string' ? '사람별 프롬프트' : choice ? '세부 설정' : '상태 추가 프롬프트');
        positionGeneration.message = addVariant
          ? variantSaved
            ? `${label} 이미지를 생성하고 기존 초상화 목록에 추가했습니다.`
            : `${label} 이미지는 생성됐지만 목록 저장에 실패했습니다. 브라우저 저장 공간을 확인해 주세요.`
          : `${label} 이미지로 재생성했습니다.`;
      } catch (error) {
        console.warn('[attention-image-prompt] position generation', error);
        positionGeneration.message = `생성 실패: ${error.message || error}`;
      } finally {
        positionGeneration.running = false;
        win.refresh();
      }
    }

    function renderPositionStatePromptSettings(h, win, scene, statePrompt) {
      const update = (patch, updateView = true) => {
        if (!scene) return;
        const next = { ...currentPositionStatePrompts() };
        const updated = { positivePrompt: '', negativePrompt: '', onlyState: false,
          ...(next[scene.situationId] || statePrompt), ...patch };
        if (updated.positivePrompt || updated.negativePrompt || updated.onlyState) next[scene.situationId] = updated;
        else delete next[scene.situationId];
        api.settings.set({ positionStatePrompts: next });
        positionRandomChoices.clear();
        positionGeneration.message = '현재 상태 추가 프롬프트 설정을 저장했습니다.';
        if (updateView) { refreshPortraitImage(); win.refresh(); }
      };
      return h('div', { style: 'border:1px solid #44403c;border-radius:7px;padding:9px 10px;margin-bottom:10px;' },
        h('strong', { style: 'font-size:12px;' }, '현재 상태 추가 프롬프트 · 체위와 별도 적용'),
        ...[['Positive', 'positivePrompt', 'data-position-state-prompt', '예: restrained wrists, embarrassed expression, dim candlelight'],
          ['Negative', 'negativePrompt', 'data-position-state-negative-prompt', '예: extra limbs, wrong clothing']]
          .map(([label, field, attribute, placeholder]) => h('label', { style: 'display:block;margin-top:7px;font-size:11px;' },
            h('span', {}, label), h('textarea', {
              rows: 3, value: statePrompt?.[field] || '', spellcheck: false, disabled: !scene,
              [attribute]: '', placeholder,
              style: 'width:100%;box-sizing:border-box;resize:vertical;margin-top:4px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
              onfocus: () => { activeTagTarget = { kind: 'position-state', id: scene.situationId, field,
                label: `현재 상태 ${label}` }; },
              oninput: event => {
                update({ [field]: event.currentTarget.value.trim() }, false);
                const note = event.currentTarget.closest?.('label')?.querySelector('[data-position-state-translation]');
                if (note) note.textContent = translatedPromptText(event.currentTarget.value);
              },
              onchange: event => update({ [field]: event.currentTarget.value.trim() }),
            }), h('span', { class: 'wml-muted wml-small', 'data-position-state-translation': field },
              translatedPromptText(statePrompt?.[field] || '')))),
        h('label', { style: 'display:flex;align-items:center;gap:7px;margin-top:8px;font-size:11px;cursor:pointer;' },
          h('input', { type: 'checkbox', checked: Boolean(statePrompt?.onlyState), disabled: !scene, 'data-position-state-only': '',
            onchange: event => update({ onlyState: event.currentTarget.checked }) }),
          h('span', {}, '상태 프롬프트만 적용 · 체위/모듈 설정 제외')));
    }

    const expandedPositionPresetGroups = new Set();
    function renderLegacyPositionSettings(h, win) {
      const scene = latestScenePrompt;
      const selectedChoice = selectedPositionChoice();
      const selected = selectedChoice?.preset || null;
      const rules = currentPositionRules();
      const fixedRuleId = scene ? matchingPositionRuleId(scene.situationId, rules) : '';
      const fixedChoices = rules[fixedRuleId] || [];
      const ruleDefaults = currentPositionRuleDefaults(rules);
      const includesDefaultPosition = ruleDefaults[fixedRuleId] === true;
      const appliedChoice = scene ? positionChoiceForImageKey(scene.result.key, scene.characterId) : null;
      const groupCount = scene ? positionGroupCount(scene.situationId) : 0;
      const nativeSlots = scene ? positionGroupSlots(scene.result.key) : '';
      const selectedSlots = selectedPositionGroupSlots(scene);
      const selectedDetails = normalizePositionDetails(selectedChoice?.details || positionSelection.details, groupCount);
      const statePrompt = scene ? currentPositionStatePrompt(scene.situationId) : null;
      const onlyState = positionStateOnly(statePrompt);
      const canGenerate = Boolean(scene && ((selectedChoice && !onlyState) || statePrompt?.positivePrompt || statePrompt?.negativePrompt));
      const personPromptPreview = joinPrompt(`${positionFemaleDetailPrompt(selectedDetails)}, ${positionPrimaryManPrompt(selectedDetails)}, ${positionPlacementPrompt(selectedSlots, selectedDetails, selected?.prompt)}`);
      const editedPersonPrompt = positionSelection.situationId === scene?.situationId && typeof positionSelection.personPrompt === 'string'
        ? positionSelection.personPrompt : null;
      const updateDefaultPositionSetting = (situationId, included) => {
        const next = { ...currentPositionRuleDefaults(rules) };
        if (included) next[situationId] = true;
        else delete next[situationId];
        api.settings.set({ positionRuleDefaults: next });
        positionRandomChoices.clear();
        positionGeneration.message = included
          ? `${positionSituationLabel(situationId)}에서 고정 체위와 게임 기본 상태를 함께 랜덤 후보로 사용합니다.`
          : `${positionSituationLabel(situationId)}에서 고정 체위만 랜덤 후보로 사용합니다.`;
        win.refresh();
      };
      const updateFemalePose = value => {
        if (!scene) return;
        const details = normalizePositionDetails(selectedDetails, groupCount);
        details.female = normalizeFemalePositionDetail({ pose: value });
        positionSelection = { ...positionSelection, situationId: scene.situationId, presetId: '', details, personPrompt: null, manual: true };
        positionGeneration.message = '여성 자세를 변경하고 충돌할 수 있는 장면 프리셋을 해제했습니다.';
        win.refresh();
      };
      const updatePositionDetail = (scope, index, fieldId, value) => {
        if (!scene) return;
        const details = normalizePositionDetails(selectedDetails, groupCount);
        if (scope === 'main') details.main = { ...details.main, [fieldId]: value };
        else details.extras[index] = { ...details.extras[index], [fieldId]: value };
        positionSelection = { ...positionSelection, situationId: scene.situationId, presetId: '', details, personPrompt: null, manual: true };
        const field = POSITION_DETAIL_FIELDS.find(item => item.id === fieldId);
        positionGeneration.message = `${scope === 'main' ? '주 상대 남성' : `추가 남성 ${index + 1}`}의 ${field?.name || '세부 설정'}을 변경했습니다.`;
        win.refresh();
      };
      const updateGroupSlot = (index, value) => {
        if (!scene) return;
        const slots = [...selectedSlots];
        slots[index] = value;
        const groupSlots = slots.join('');
        positionPlacementDrafts.set(scene.situationId, groupSlots);
        positionSelection = { ...positionSelection, situationId: scene.situationId, groupSlots, personPrompt: null, manual: true };
        positionGeneration.message = `추가 남성 ${index + 1}의 빠른 역할을 변경했습니다.`;
        win.refresh();
      };
      const applyPersonPreset = (scope, index, preset) => {
        if (!scene || !preset) return;
        const details = normalizePositionDetails(selectedDetails, groupCount);
        if (scope === 'main') details.main = normalizePositionDetail(preset.detail);
        else details.extras[index] = normalizePositionDetail(preset.detail);
        let groupSlots = selectedSlots || nativeSlots;
        if (scope === 'extra' && preset.slot) {
          const slots = [...groupSlots.padEnd(groupCount, 'w')];
          slots[index] = preset.slot;
          groupSlots = slots.join('');
          positionPlacementDrafts.set(scene.situationId, groupSlots);
        }
        positionSelection = { ...positionSelection, situationId: scene.situationId, presetId: '', groupSlots, details, personPrompt: null, manual: true };
        positionGeneration.message = `${scope === 'main' ? '주 상대 남성' : `추가 남성 ${index + 1}`}에 ${preset.name} 프리셋을 적용했습니다.`;
        win.refresh();
      };
      const detailEditor = (scope, index, label) => {
        const values = scope === 'main' ? selectedDetails.main : selectedDetails.extras[index];
        const personPreset = MALE_PERSON_PRESETS.find(preset => positionDetailSignature(preset.detail) === positionDetailSignature(values));
        return h('div', { style: 'border:1px solid #292524;border-radius:6px;padding:8px;' },
          h('strong', { style: 'display:block;font-size:12px;margin-bottom:6px;' }, label),
          h('div', { style: 'display:grid;grid-template-columns:120px minmax(0,1fr);align-items:center;gap:7px;margin-bottom:7px;font-size:11px;' },
            h('span', {}, '이 남성의 프리셋'),
            h('select', {
              value: personPreset?.id || '',
              'data-position-person-preset': scope === 'main' ? 'main' : String(index),
              style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:6px 8px;',
              onchange: event => applyPersonPreset(scope, index, MALE_PERSON_PRESETS.find(preset => preset.id === event.currentTarget.value)),
            }, h('option', { value: '', selected: !personPreset }, '직접 설정'),
            ...MALE_PERSON_PRESETS.map(preset => h('option', { value: preset.id, selected: personPreset?.id === preset.id }, preset.name))),
          ),
          scope === 'extra' ? h('div', { style: 'display:grid;grid-template-columns:120px minmax(0,1fr);align-items:center;gap:7px;margin-bottom:7px;font-size:11px;' },
            h('span', {}, '추가 인원 빠른 역할'),
            h('select', {
              value: selectedSlots[index],
              'data-position-group-slot': String(index),
              style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:6px 8px;',
              onchange: event => updateGroupSlot(index, event.currentTarget.value),
            }, ...GROUP_SLOT_OPTIONS.map(option => h('option', { value: option.id, selected: selectedSlots[index] === option.id }, option.name))),
          ) : null,
          h('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:7px;' }, ...POSITION_DETAIL_FIELDS.map(field => h('label', { style: 'display:grid;gap:4px;font-size:11px;' },
            h('span', {}, field.name),
            h('select', {
              value: values[field.id],
              [scope === 'main' ? 'data-position-detail-main' : 'data-position-detail-extra']: scope === 'main' ? field.id : `${index}:${field.id}`,
              style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:6px 8px;',
              onchange: event => updatePositionDetail(scope, index, field.id, event.currentTarget.value),
            }, ...field.options.map(([value, optionLabel]) => h('option', { value, selected: values[field.id] === value }, optionLabel))),
          ))),
        );
      };
      const femaleEditor = h('div', { 'data-position-female-settings': '', style: 'border:1px solid #292524;border-radius:6px;padding:8px;' },
        h('strong', { style: 'display:block;font-size:12px;margin-bottom:6px;' }, '여성 전용 설정'),
        h('label', { style: 'display:grid;grid-template-columns:120px minmax(0,1fr);align-items:center;gap:7px;font-size:11px;' },
          h('span', {}, '여성 자세 프리셋'),
          h('select', {
            value: selectedDetails.female.pose,
            'data-position-female-pose': '',
            style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:6px 8px;',
            onchange: event => updateFemalePose(event.currentTarget.value),
          }, ...FEMALE_POSE_OPTIONS.map(([value, optionLabel]) => h('option', { value, selected: selectedDetails.female.pose === value }, optionLabel))),
        ),
        h('p', { class: 'wml-muted wml-small', style: 'margin:6px 0 0;' }, '남성 설정과 분리해 여성에게만 적용합니다. 엎드리기는 prone·chest down·back up 태그를 함께 사용합니다.'),
      );
      return [
        h('div', { 'data-position-current': '', style: 'border:1px solid #57534e;border-radius:7px;padding:9px 10px;margin-bottom:10px;background:#1c1917;' },
          h('strong', { style: 'font-size:12px;' }, scene ? `현재 상황 · ${positionSituationLabel(scene.situationId)}` : '현재 상황을 확인할 수 없음'),
          h('p', { class: 'wml-muted wml-small', style: 'margin:4px 0 0;' }, scene
            ? `적용 중: ${onlyState ? '상태 추가 프롬프트만' : appliedChoice?.preset?.name || (appliedChoice?.details ? '세부 설정' : '게임 자동 체위')}${appliedChoice?.groupSlots ? ` · 추가 인원 ${positionPlacementLabel(appliedChoice.groupSlots)}` : ''}${statePrompt?.positivePrompt || statePrompt?.negativePrompt ? ' · 상태 프롬프트 사용' : ''}${!onlyState && fixedChoices.length ? ` · 고정 조합 ${fixedChoices.length}개${includesDefaultPosition ? ' + 기본 상태' : ''} 중 랜덤` : ''}`
            : '게임을 시작하고 초상화가 한 번 표시된 뒤 다시 열어 주세요.'),
        ),
        h('label', { style: 'display:flex;align-items:flex-start;gap:8px;margin-bottom:10px;font-size:12px;cursor:pointer;' },
          h('input', {
            type: 'checkbox', checked: autoPositionPresets(), 'data-position-auto-presets': '',
            onchange: event => {
              api.settings.set({ autoPositionPresets: event.currentTarget.checked });
              if (scene) {
                const choice = positionChoiceForImageKey(scene.result.key, scene.characterId);
                positionSelection = { situationId: scene.situationId, presetId: choice?.presetId || '',
                  groupSlots: choice?.groupSlots || nativeSlots, details: compactPositionDetails(choice?.details, groupCount), manual: false };
              }
              positionGeneration.message = event.currentTarget.checked
                ? '알아볼 수 있는 장면에 맞는 프리셋을 자동 적용합니다.' : '자동 프리셋을 껐습니다.';
              refreshPortraitImage();
              win.refresh();
            },
          }),
          h('span', {}, '장면에 맞는 체위 프리셋 자동 적용',
            h('span', { class: 'wml-muted wml-small', style: 'display:block;margin-top:3px;' },
              '지원하는 성행위 장면에 적용합니다. 일반 성교는 정상위를 기본으로 쓰며, 현재 체위 변경과 상황별 고정 목록이 우선합니다.')),
        ),
        renderPositionStatePromptSettings(h, win, scene, statePrompt),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px;' },
          api.ui.button('세부 설정만 사용', () => {
            if (!scene) return;
            activeTagTarget = null;
            positionSelection = { situationId: scene.situationId, presetId: '', groupSlots: selectedSlots || nativeSlots, details: selectedDetails, manual: true };
            positionGeneration.message = '프리셋을 끄고 아래 세부 설정만 사용합니다.';
            win.refresh();
          }, { primary: Boolean(selectedChoice && !selected), disabled: !scene }),
        ),
        ...POSITION_PRESET_GROUPS.filter(group => !group.hidden).map(group => h('details', {
          open: expandedPositionPresetGroups.has(group.title), 'data-position-preset-group': group.title,
          ontoggle: event => { event.currentTarget.open ? expandedPositionPresetGroups.add(group.title) : expandedPositionPresetGroups.delete(group.title); },
          style: 'border:1px solid #44403c;border-radius:7px;padding:8px 10px;margin-bottom:12px;' },
          h('summary', { style: 'cursor:pointer;font-size:12px;font-weight:700;' },
            `${group.title} · ${group.presets.length}개${group.presets.some(preset => preset.id === selected?.id) ? ` · ${selected.name} 선택 중` : ''}`),
          h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;' },
            ...group.presets.map(basePreset => {
              const preset = positionPresetById(basePreset.id);
              return api.ui.button(preset.name, () => {
              if (!scene) return;
              activeTagTarget = null;
              const details = positionPresetTemplateDetails(preset, groupCount, selectedDetails);
               positionSelection = { situationId: scene.situationId, presetId: preset.id, groupSlots: selectedSlots || nativeSlots, details, manual: true };
              positionGeneration.message = `${preset.name} 프리셋을 선택했습니다.`;
              win.refresh();
              }, { primary: selected?.id === preset.id, disabled: !scene });
            }),
          ),
        )),
        h('details', { open: true, 'data-position-details': '', style: 'border:1px solid #44403c;border-radius:7px;padding:8px 10px;margin-bottom:10px;' },
          h('summary', { style: 'cursor:pointer;font-size:12px;font-weight:700;' }, '여성 설정 · 사람별 남성 설정'),
          h('p', { class: 'wml-muted wml-small', style: 'margin:7px 0;' }, '여성 자세는 독립 적용합니다. 각 남성은 자기 프리셋을 고른 뒤 배치·자세·행동·대상 부위를 따로 조정할 수 있습니다.'),
          h('div', { style: 'display:grid;gap:7px;' },
            femaleEditor,
            detailEditor('main', 0, '남성 설정 · 주 상대'),
            ...Array.from({ length: groupCount }, (_, index) => detailEditor('extra', index, `남성 설정 · 추가 남성 ${index + 1}`)),
          ),
          scene ? h('label', { style: 'display:grid;gap:5px;margin-top:8px;font-size:11px;' },
            h('strong', {}, '현재 사람별 적용 프롬프트'),
            h('textarea', {
              rows: 5,
              value: editedPersonPrompt === null ? personPromptPreview : editedPersonPrompt,
              maxLength: 2000,
              spellcheck: false,
              'data-position-person-prompt-preview': '',
              placeholder: '여성·상대 남성의 자세와 행동을 영어 태그로 입력',
              style: 'width:100%;box-sizing:border-box;resize:vertical;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:11px/1.45 ui-monospace,Consolas,monospace;',
              onfocus: () => { activeTagTarget = null; },
              oninput: event => {
                const prompt = event.currentTarget.value.trim();
                if (prompt.length <= 2000) positionSelection = { ...positionSelection, situationId: scene.situationId,
                  personPrompt: prompt === personPromptPreview ? null : prompt, manual: true };
                updatePromptTagPreview(event, h, win);
              },
              onchange: event => {
                if (!scene) return;
                const prompt = event.currentTarget.value.trim();
                if (prompt.length > 2000) {
                  positionGeneration.message = '사람별 프롬프트는 2000자까지 입력할 수 있습니다.';
                  win.refresh();
                  return;
                }
                positionSelection = { ...positionSelection, situationId: scene.situationId,
                  personPrompt: prompt === personPromptPreview ? null : prompt, manual: true };
                positionGeneration.message = '수정한 사람별 프롬프트를 다음 이미지 생성에 적용합니다.';
                win.refresh();
              },
            }), promptTagPreview(h, editedPersonPrompt === null ? personPromptPreview : editedPersonPrompt, win),
            h('span', { class: 'wml-muted wml-small' }, '입력칸을 벗어나면 적용됩니다. 생성한 체위 이미지와 함께 현재 세이브에 저장됩니다.'),
          ) : null,
          h('div', { style: 'margin-top:7px;' }, api.ui.button('세부 설정 초기화', () => {
            if (!scene) return;
            positionSelection = { ...positionSelection, situationId: scene.situationId, details: null, personPrompt: null };
            positionGeneration.message = '여성 자세와 사람별 남성 설정을 초기화했습니다.';
            win.refresh();
          }, { disabled: !hasPositionDetails(selectedDetails, groupCount) })),
        ),
        h('details', { 'data-position-group-prompts': '', style: 'border:1px solid #44403c;border-radius:7px;padding:8px 10px;margin-bottom:10px;' },
          h('summary', { style: 'cursor:pointer;font-size:12px;font-weight:700;' }, '추가 인원 배치 프롬프트 편집 (SDXL)'),
          h('p', { class: 'wml-muted wml-small', style: 'margin:7px 0;' }, '기본 프롬프트는 원래 인물을 주 피사체로 유지하면서 추가 인원도 식별 가능한 보조 역할로 표현합니다.'),
          h('div', { style: 'display:grid;gap:8px;' }, ...GROUP_SLOT_OPTIONS.map(option => {
            const prompt = positionGroupPromptById(option.id);
            const customized = Object.prototype.hasOwnProperty.call(currentPositionGroupPrompts(), option.id);
            return h('label', { style: 'display:grid;gap:5px;font-size:12px;' },
              h('strong', {}, `${option.name} (${option.id})`),
              h('textarea', {
                rows: 3,
                value: prompt,
                spellcheck: false,
                'data-position-group-prompt': option.id,
                style: 'width:100%;box-sizing:border-box;resize:vertical;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
                onfocus: () => { activeTagTarget = { kind: 'position-group', id: option.id,
                  label: `${option.name} 배치 프롬프트` }; },
                oninput: event => {
                  api.settings.set({ positionGroupPrompts: { ...currentPositionGroupPrompts(), [option.id]: event.currentTarget.value } });
                  positionRandomChoices.clear();
                  updatePromptTagPreview(event, h, win);
                },
                onchange: event => {
                  api.settings.set({ positionGroupPrompts: { ...currentPositionGroupPrompts(), [option.id]: event.currentTarget.value } });
                  positionRandomChoices.clear();
                  positionGeneration.message = `${option.name} 배치 프롬프트를 수정했습니다.`;
                  win.refresh();
                },
              }),
              promptTagPreview(h, prompt, win), api.ui.button('기본값으로 복원', () => {
                const next = { ...currentPositionGroupPrompts() };
                delete next[option.id];
                api.settings.set({ positionGroupPrompts: next });
                positionRandomChoices.clear();
                positionGeneration.message = `${option.name} 배치 프롬프트를 기본값으로 복원했습니다.`;
                win.refresh();
              }, { disabled: !customized }),
            );
          })),
        ),
        selected ? h('div', { 'data-position-prompt': selected.id, style: 'border:1px solid #44403c;border-radius:7px;padding:9px 10px;margin-bottom:10px;' },
          h('strong', { style: 'font-size:12px;' }, `${selected.name} · 적용할 영문 프롬프트`),
          h('textarea', {
            rows: 4,
            value: selected.prompt,
            spellcheck: false,
            'data-position-preset-prompt': selected.id,
            style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:88px;margin-top:6px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
            onfocus: () => { activeTagTarget = { kind: 'position-preset', id: selected.id,
              label: `${selected.name} 체위 프롬프트` }; },
            oninput: event => {
              const prompt = event.currentTarget.value;
              api.settings.set({ positionPresetPrompts: { ...currentPositionPresetPrompts(), [selected.id]: prompt } });
              positionRandomChoices.clear();
              const status = event.currentTarget.parentElement?.querySelector('[data-position-prompt-save-status]');
              if (status) status.textContent = currentPositionPresetPrompts()[selected.id] === prompt
                ? '저장됨' : '저장 실패 · 브라우저 저장 공간을 확인해 주세요.';
              const chips = promptTagChips(h, prompt, win);
              event.currentTarget.parentElement?.querySelector('[data-position-prompt-chips]')?.replaceChildren(...(chips ? [chips] : []));
            },
            onchange: event => {
              const prompt = event.currentTarget.value;
              api.settings.set({ positionPresetPrompts: { ...currentPositionPresetPrompts(), [selected.id]: prompt } });
              const saved = currentPositionPresetPrompts()[selected.id] === prompt;
              if (saved) positionRandomChoices.clear();
              positionGeneration.message = saved
                ? `${selected.name} 프롬프트를 수정했습니다.`
                : '프롬프트 저장에 실패했습니다. 브라우저 저장 공간을 확인해 주세요.';
              const status = event.currentTarget.parentElement?.querySelector('[data-position-prompt-save-status]');
              if (status) status.textContent = saved ? '저장됨' : '저장 실패 · 브라우저 저장 공간을 확인해 주세요.';
            },
          }),
          h('span', { 'data-position-prompt-save-status': '', 'aria-live': 'polite', class: 'wml-muted wml-small' }, '입력칸을 벗어나면 저장됩니다.'),
          h('div', { 'data-position-prompt-chips': '', style: 'margin-top:6px;' }, promptTagChips(h, selected.prompt, win)),
          selectedChoice?.groupSlots ? h('div', { style: 'margin-top:6px;' }, promptTagChips(h, positionPlacementPrompt(selectedChoice.groupSlots, selectedChoice.details), win)) : null,
          api.ui.button('이 체위 기본 프롬프트로 복원', () => {
            const next = { ...currentPositionPresetPrompts() };
            delete next[selected.id];
            api.settings.set({ positionPresetPrompts: next });
            positionRandomChoices.clear();
            positionGeneration.message = `${selected.name} 프롬프트를 기본값으로 복원했습니다.`;
            win.refresh();
          }),
        ) : h('p', { class: 'wml-note' }, '체위명을 클릭하면 교체할 프롬프트 묶음을 확인할 수 있습니다.'),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;' },
          api.ui.button(positionGeneration.running ? '생성 중…' : '현재 이미지 재생성', () => {
            void generatePositionImage(false, win);
          }, { primary: true, disabled: !canGenerate || positionGeneration.running }),
          api.ui.button('이미지 추가 생성', () => {
            void generatePositionImage(true, win);
          }, { disabled: !scene || positionGeneration.running }),
          api.ui.button('이 상황에 고정 추가', () => {
            if (!scene || !selectedChoice) return;
            const current = rules[scene.situationId] || [];
            const details = compactPositionDetails(selectedChoice.details, groupCount);
            const presetDetails = effectivePositionDetails(selectedChoice.preset, null, groupCount);
            const storedDetails = presetDetails && positionDetailsSignature(presetDetails, groupCount) === positionDetailsSignature(details, groupCount)
              ? null : details;
            const stored = { presetId: selectedChoice.presetId, groupSlots: selectedChoice.groupSlots,
              ...(storedDetails ? { details: storedDetails } : {}),
              ...(typeof selectedChoice.personPrompt === 'string' ? { personPrompt: selectedChoice.personPrompt } : {}) };
            const storedSignature = positionDetailsSignature(effectivePositionDetails(selectedChoice.preset, stored.details, groupCount), groupCount);
            if (current.some(choice => {
              const choicePreset = positionPresetById(choice.presetId);
              return choice.presetId === stored.presetId && choice.groupSlots === stored.groupSlots
                && positionDetailsSignature(effectivePositionDetails(choicePreset, choice.details, groupCount), groupCount) === storedSignature
                && (choice.personPrompt ?? null) === (stored.personPrompt ?? null);
            })) {
              positionGeneration.message = '같은 체위·추가 인원·세부 설정 조합이 이미 고정 목록에 있습니다.';
              win.refresh();
              return;
            }
            api.settings.set({ positionRules: { ...rules, [scene.situationId]: [...current, stored] } });
            positionRandomChoices.clear();
            const override = positionOverride(scene.situationId);
            const overridePreset = positionPresetById(override?.presetId);
            if (override && (override.presetId !== stored.presetId || override.groupSlots !== stored.groupSlots
              || positionDetailsSignature(effectivePositionDetails(overridePreset, override.details, groupCount), groupCount) !== storedSignature
              || (override.personPrompt ?? null) !== (stored.personPrompt ?? null))) {
              deletePositionOverride(scene.situationId);
            }
            positionGeneration.message = `${selected?.name || '세부 설정'}${stored.groupSlots ? ` · ${positionPlacementLabel(stored.groupSlots)}` : ''} 조합을 고정 목록에 추가했습니다.`;
            win.refresh();
          }, { disabled: !scene || !selectedChoice }),
          api.ui.button('현재 상황 고정 전체 해제', () => {
            if (!fixedRuleId) return;
            const next = { ...rules };
            delete next[fixedRuleId];
            const nextDefaults = { ...currentPositionRuleDefaults(rules) };
            delete nextDefaults[fixedRuleId];
            api.settings.set({ positionRules: next, positionRuleDefaults: nextDefaults });
            positionRandomChoices.clear();
            positionGeneration.message = '현재 상황 종류의 체위 고정을 모두 해제했습니다.';
            win.refresh();
          }, { disabled: !fixedChoices.length }),
          api.ui.button('현재 체위 변경 취소', () => {
            if (!scene) return;
            deletePositionOverride(scene.situationId);
            const applied = positionChoiceForImageKey(scene.result.key, scene.characterId);
            const groupSlots = applied?.groupSlots || nativeSlots;
            positionPlacementDrafts.set(scene.situationId, groupSlots);
            positionSelection = {
              situationId: scene.situationId,
              presetId: applied?.presetId || '',
              groupSlots,
              details: compactPositionDetails(applied?.details, groupCount),
              personPrompt: typeof applied?.personPrompt === 'string' ? applied.personPrompt : null,
              manual: false,
            };
            positionGeneration.message = '현재 상황의 임시 체위 변경을 취소했습니다.';
            win.refresh();
          }, { disabled: !scene || !positionOverride(scene?.situationId) }),
        ),
        h('label', { style: 'display:flex;align-items:center;gap:6px;margin-top:8px;font-size:12px;' },
          h('input', {
            type: 'checkbox', checked: includesDefaultPosition, disabled: !fixedRuleId || !fixedChoices.length,
            'data-position-include-default': fixedRuleId || '',
            onchange: event => {
              if (!fixedRuleId) return;
              updateDefaultPositionSetting(fixedRuleId, event.currentTarget.checked);
            },
          }),
          '현재 상황에서 기본 상태도 포함',
          h('span', { class: 'wml-muted wml-small' }, '· 고정 목록과 기존 게임 체위 중에서 함께 랜덤 선택'),
        ),
        positionGeneration.message ? h('p', { class: 'wml-note', style: 'margin-top:8px;' }, positionGeneration.message) : null,
        h('div', { style: 'margin-top:14px;' },
          h('strong', { style: 'font-size:12px;' }, '상황별 고정 목록'),
          Object.keys(rules).length
            ? h('div', { style: 'display:grid;gap:8px;margin-top:7px;' }, ...Object.entries(rules).map(([situationId, choices]) => h('div', {
              'data-position-rule-group': situationId,
              style: 'display:grid;gap:6px;border:1px solid #44403c;border-radius:7px;padding:8px;',
            },
            h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;' },
              h('strong', { class: 'wml-small' }, positionSituationLabel(situationId)),
              h('label', { style: 'display:flex;align-items:center;gap:5px;font-size:11px;' },
                h('input', {
                  type: 'checkbox', checked: ruleDefaults[situationId] === true,
                  'data-position-rule-default': situationId,
                  onchange: event => updateDefaultPositionSetting(situationId, event.currentTarget.checked),
                }),
                '기본 상태도 랜덤 포함',
              ),
            ),
            ...choices.map((choice, index) => h('div', {
              'data-position-rule': situationId,
              style: 'display:flex;align-items:center;justify-content:space-between;gap:8px;border-top:1px solid #292524;padding-top:6px;',
            },
            h('span', { class: 'wml-small' }, `${positionSituationLabel(situationId)} → ${positionPresetById(choice.presetId)?.name || (typeof choice.personPrompt === 'string' && !choice.details ? '사람별 프롬프트' : '세부 설정')}${choice.groupSlots ? ` · ${positionPlacementLabel(choice.groupSlots)}` : ''}${choice.details ? ' · 세부 조합' : ''}${typeof choice.personPrompt === 'string' ? ' · 문구 수정' : ''}`),
            api.ui.button('삭제', () => {
              const next = { ...currentPositionRules() };
              const remaining = next[situationId].filter((_, choiceIndex) => choiceIndex !== index);
              if (remaining.length) next[situationId] = remaining;
              else delete next[situationId];
              const nextDefaults = { ...currentPositionRuleDefaults() };
              if (!remaining.length) delete nextDefaults[situationId];
              api.settings.set({ positionRules: next, positionRuleDefaults: nextDefaults });
              positionRandomChoices.clear();
              win.refresh();
            }))))))
            : h('p', { class: 'wml-muted wml-small', style: 'margin:6px 0 0;' }, '고정된 상황이 없습니다.'),
        ),
      ];
    }

    function positionModuleSection(module) {
      if (climaxModuleThreshold(module)) return 'climax';
      if (module.kind === 'pose') return 'posture';
      if (module.kind === 'position') return 'position';
      if (module.kind === 'action' || ['삽입', '삽입 위치', '사정 위치', '해 달라고', '자리', '속도', '움직임'].includes(module.controllerGroup)) return 'action';
      if (['기본', '거칠게', '입·손가락', '시키기', '폭력성', '부위 (정도 2)'].includes(module.controllerGroup)) return 'body';
      if (['옷', '옷 상태', '벗기기', '가슴 가림', '다리 가림'].includes(module.controllerGroup)) return 'clothes';
      if (['오른손', '왼손'].includes(module.controllerGroup)) return 'hands';
      return 'other';
    }

    function positionModuleGroup(module, section) {
      const label = module.controllerLabel || module.name;
      if (section === 'position' && !module.controllerGroup) return /마주 앉|등지고/.test(label) ? '기승'
        : /벽/.test(label) ? '벽' : /들려/.test(label) ? '들림' : '기타 체위';
      if (section === 'posture') return /벽|들려/.test(label) ? '벽·들림'
        : /눕|누워|누운|엎|네발|숙/.test(label) ? '눕기·엎드리기' : '서기·앉기';
      if (section === 'body') return /가슴|젖|유두/.test(label) ? '가슴·유두'
        : /항문|애널|엉덩이/.test(label) ? '항문·엉덩이'
          : /클리|보지|음부|질|팬티 위로 핥기|손가락 넣기|손가락 애무/.test(label) ? '음부·클리'
            : /입|키스|혀|목덜미|귀|빨리기/.test(label) ? '입·목'
              : /손목|손/.test(label) ? '손·손목'
                : /다리|허리|발목/.test(label) ? '다리·허리'
                  : /뺨|머리|얼굴/.test(label) ? '얼굴·머리' : '전신·기타';
      if (section === 'action' && (!module.controllerGroup || module.controllerGroup === '행위')) {
        const area = /입|구강|펠라|이라마|커닐|69|mouth/.test(label) ? '입'
          : /항문|애널|뒤 손가락|anal/.test(label) ? '항문'
            : /가슴|파이즈리/.test(label) ? '가슴'
              : /손|finger|handjob/.test(label) ? '손'
                : /성관계|기승|삽입|질|vaginal/.test(label) ? '성교' : '접촉·기타';
        return `행위 · ${area}`;
      }
      if (section === 'climax') return '아내의 절정 횟수';
      return module.controllerGroup || '직접 추가';
    }

    function renderModuleGroupLayout(h, win, scene) {
      const count = scene ? positionGroupCount(scene.situationId) : 0;
      if (!count) return null;
      const layouts = currentPositionModuleGroupLayouts();
      const layout = layouts[scene.situationId] || {};
      const groupSlots = String(layout.groupSlots || positionGroupSlots(scene.result.key))
        .padEnd(count, 'w').slice(0, count);
      const details = normalizePositionDetails(layout.details, count);
      const personPrompts = layout.personPrompts || { main: '', extras: Array(count).fill('') };
      const inputStyle = 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;';
      const save = (patch, updateView = true) => {
        const next = { ...currentPositionModuleGroupLayouts() };
        const normalized = normalizePositionModuleGroupLayouts({ [scene.situationId]: { ...layout, ...patch } });
        if (normalized[scene.situationId]) next[scene.situationId] = normalized[scene.situationId];
        else delete next[scene.situationId];
        api.settings.set({ positionModuleGroupLayouts: next });
        positionGeneration.message = '다대일 인원별 배치를 저장했습니다.';
        if (updateView) { refreshPortraitImage(); win.refresh(); }
      };
      const updateField = (scope, index, field, value) => {
        const next = normalizePositionDetails(details, count);
        if (scope === 'main') next.main[field] = value;
        else {
          const current = next.extras[index];
          const rolePreset = MALE_PERSON_PRESETS.find(preset => preset.slot === groupSlots[index]);
          const base = positionDetailPrompt(current) ? current : normalizePositionDetail(rolePreset?.detail);
          next.extras[index] = { ...base, [field]: value };
        }
        save({ details: next });
      };
      const updatePreset = (scope, index, presetId) => {
        const preset = MALE_PERSON_PRESETS.find(entry => entry.id === presetId);
        const next = normalizePositionDetails(details, count);
        if (scope === 'main') next.main = normalizePositionDetail(preset?.detail);
        else next.extras[index] = normalizePositionDetail(preset?.detail);
        const slots = [...groupSlots];
        if (scope === 'extra' && preset?.slot) slots[index] = preset.slot;
        save({ details: next, groupSlots: slots.join('') });
      };
      const person = (scope, index, label) => {
        const value = scope === 'main' ? details.main : details.extras[index];
        const selectedPreset = MALE_PERSON_PRESETS.find(preset =>
          positionDetailSignature(preset.detail) === positionDetailSignature(value));
        const extraTags = scope === 'main' ? personPrompts.main : personPrompts.extras?.[index] || '';
        return h('div', { style: 'border-top:1px solid #44403c;padding-top:10px;display:grid;gap:8px;' },
          h('strong', {}, label),
          scope === 'extra' ? h('label', { style: 'display:grid;gap:4px;' }, '빠른 역할',
            h('select', { value: groupSlots[index], 'data-position-module-group-slot': String(index),
              style: inputStyle,
              onchange: event => {
                const slots = [...groupSlots];
                slots[index] = event.currentTarget.value;
                const next = normalizePositionDetails(details, count);
                next.extras[index] = normalizePositionDetail(MALE_PERSON_PRESETS.find(preset =>
                  preset.slot === slots[index])?.detail);
                save({ groupSlots: slots.join(''), details: next });
              },
            }, ...GROUP_SLOT_OPTIONS.map(option => h('option', {
              value: option.id, selected: groupSlots[index] === option.id,
            }, option.name)))) : null,
          h('label', { style: 'display:grid;gap:4px;' }, '사람별 프리셋',
            h('select', { value: selectedPreset?.id || '',
              'data-position-module-person-preset': scope === 'main' ? 'main' : String(index),
              style: inputStyle, onchange: event => updatePreset(scope, index, event.currentTarget.value),
            }, h('option', { value: '', selected: !selectedPreset }, '직접 설정'),
            ...MALE_PERSON_PRESETS.map(preset => h('option', {
              value: preset.id, selected: selectedPreset?.id === preset.id,
            }, preset.name)))),
          h('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:7px;' },
            ...POSITION_DETAIL_FIELDS.map(field => h('label', { style: 'display:grid;gap:4px;' }, field.name,
              h('select', { value: value[field.id],
                'data-position-module-person-detail': `${scope === 'main' ? 'main' : index}:${field.id}`,
                style: inputStyle,
                onchange: event => updateField(scope, index, field.id, event.currentTarget.value),
              }, ...field.options.map(([id, name]) => h('option', {
                value: id, selected: value[field.id] === id,
              }, name)))))),
          h('label', { style: 'display:grid;gap:4px;' }, '추가 프롬프트',
            h('textarea', { rows: 2, value: extraTags, maxLength: 2000, spellcheck: false,
              'data-position-module-person-tags': scope === 'main' ? 'main' : String(index),
              style: `${inputStyle}resize:vertical;font:12px/1.5 ui-monospace,Consolas,monospace;`,
              oninput: event => {
                const next = { main: personPrompts.main || '', extras: [...(personPrompts.extras || Array(count).fill(''))] };
                if (scope === 'main') next.main = event.currentTarget.value;
                else next.extras[index] = event.currentTarget.value;
                save({ personPrompts: next }, false);
                updatePromptTagPreview(event, h, win);
              },
              onchange: event => {
                const next = { main: personPrompts.main || '', extras: [...(personPrompts.extras || Array(count).fill(''))] };
                if (scope === 'main') next.main = event.currentTarget.value;
                else next.extras[index] = event.currentTarget.value;
                save({ personPrompts: next });
              },
            }), promptTagPreview(h, extraTags, win)));
      };
      const choice = scene && positionModuleChoice(scene.situationId, scene.characterId, scene.result.key);
      const mainScope = basePositionSituationId(scene?.situationId).startsWith('scene-patron_') ? 'patron' : 'you';
      const mainAction = choice?.modules?.find(module => module.kind === 'action'
        && module.controllerScope === mainScope)?.positivePrompt
        || choice?.modules?.find(module => module.kind === 'action' && !module.controllerScope)?.positivePrompt || '';
      const preview = [positionPrimaryManPrompt(details, personPrompts.main, true, mainAction),
        positionPlacementPrompt(groupSlots, details, '', slot => GROUP_SLOT_BY_ID[slot]?.prompt || '', personPrompts)]
        .filter(Boolean).join(', ');
      return h('details', { open: true, 'data-position-module-group-layout': scene.situationId,
        style: 'border:1px solid #44403c;border-radius:8px;padding:10px 12px;margin-bottom:12px;' },
        h('summary', { style: 'cursor:pointer;font-weight:700;' }, `다대일 인원별 배치 · 추가 남성 ${count}명`),
        h('p', { class: 'wml-muted wml-small', style: 'margin:7px 0 10px;' },
          '주 상대와 추가 남성을 각각 설정합니다. 역할·자세·행동은 생성 프롬프트에 반영되며 게임 행동은 바꾸지 않습니다.'),
        person('main', 0, '주 상대 남성'),
        ...Array.from({ length: count }, (_, index) => person('extra', index, `추가 남성 ${index + 1}`)),
        h('p', { class: 'wml-small', 'data-position-module-group-preview': '',
          style: 'overflow-wrap:anywhere;margin:12px 0 8px;' }, `인원별 프롬프트: ${preview}`),
        api.ui.button('이 장면 인원 배치 초기화', () => {
          const next = { ...currentPositionModuleGroupLayouts() };
          delete next[scene.situationId];
          api.settings.set({ positionModuleGroupLayouts: next });
          positionGeneration.message = '이 장면의 인원별 배치를 게임 기본값으로 되돌렸습니다.';
          refreshPortraitImage();
          win.refresh();
        }, { disabled: !layout.groupSlots && !layout.details && !layout.personPrompts }));
    }

    function renderPositionModuleSettings(h, win, onlyClimax = false) {
      const scene = latestScenePrompt;
      discoverFoldedControllerButtons();
      const modules = availablePositionModules();
      const controllerScopes = controllerScopesForSituation(scene?.situationId, scene?.characterId);
      const patronScene = api.store.game()?.activeScene?.patron;
      const patronCount = new Set([patronScene?.customerId, ...(patronScene?.joinedPatronIds || []),
        ...(patronScene?.crowdPatronIds || [])].filter(Boolean)).size;
      const visibleModules = modules.filter(module => !module.controllerScope || controllerScopes.includes(module.controllerScope));
      const selections = currentPositionModuleSelections();
      const selectedIds = selections[scene?.situationId] || [];
      const selected = visibleModules.filter(module => selectedIds.includes(module.id));
      const selectedPose = selected.find(module => module.kind === 'pose');
      const selectedPosition = selected.find(module => module.kind === 'position');
      const linkedPosition = visibleModules.find(module => module.id === currentPositionModulePoseAssignments()[selectedPose?.id]);
      const sections = [['position', '체위'], ['posture', '여성 자세'], ['action', '행동'], ['climax', '절정'],
        ['body', '부위별 애무'], ['clothes', '옷'], ['hands', '손 위치'], ['other', '그 밖']]
        .filter(([id]) => (!onlyClimax || id === 'climax')
          && visibleModules.some(module => positionModuleSection(module) === id));
      const sectionId = sections.some(([id]) => id === activePositionModuleSection)
        ? activePositionModuleSection : sections[0]?.[0];
      const sectionModules = visibleModules.filter(module => positionModuleSection(module) === sectionId);
      if (sectionId === 'climax') sectionModules.sort((left, right) => climaxModuleThreshold(left) - climaxModuleThreshold(right));
      const scopeChoices = controllerScopes.filter(scope => sectionModules.some(module => module.controllerScope === scope));
      const scope = scopeChoices.includes(activePositionModuleScope) ? activePositionModuleScope : scopeChoices[0];
      const scopedModules = sectionModules.filter(module => !module.controllerScope || module.controllerScope === scope);
      const groups = [...new Set(scopedModules.map(module => positionModuleGroup(module, sectionId)))];
      const activeGroup = groups.includes(activePositionModuleGroup) ? activePositionModuleGroup
        : groups.find(group => scopedModules.some(module => selectedIds.includes(module.id)
          && positionModuleGroup(module, sectionId) === group)) || groups[0];
      const shownModules = scopedModules.filter(module => positionModuleGroup(module, sectionId) === activeGroup);
      const choice = scene ? positionModuleChoice(scene.situationId, scene.characterId, scene.result.key) : null;
      const controller = scene ? controllerPositionModules(scene.situationId, scene.characterId) : null;
      const statePrompt = scene ? currentPositionStatePrompt(scene.situationId) : null;
      const onlyState = positionStateOnly(statePrompt);
      const editorModule = shownModules.find(module => module.id === activePositionModuleEditorId);
      let nextClimaxTier = 4;
      while (modules.some(module => climaxModuleThreshold(module) === nextClimaxTier)) nextClimaxTier++;
      const inputStyle = 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:6px 8px;';
      const chipStyle = active => `min-height:34px;padding:7px 10px;border:1px solid ${active ? '#f59e0b' : '#57534e'};border-radius:6px;background:${active ? '#78350f' : '#292524'};color:${active ? '#fef3c7' : '#e7e5e4'};cursor:pointer;font-size:12px;line-height:1.3;`;
      const saveSelection = ids => {
        if (!scene) return;
        const next = { ...currentPositionModuleSelections() };
        if (ids.length) next[scene.situationId] = ids;
        else delete next[scene.situationId];
        api.settings.set({ positionModuleSelections: next });
        positionGeneration.message = '현재 상황의 모듈 조합을 저장했습니다.';
        refreshPortraitImage();
        win.refresh();
      };
      const selectOne = (kind, id) => saveSelection([
        ...selectedIds.filter(selectedId => modules.find(module => module.id === selectedId)?.kind !== kind),
        ...(id ? [id] : []),
      ]);
      const selectControllerModule = module => {
        if (selectedIds.includes(module.id)) return saveSelection(selectedIds.filter(id => id !== module.id));
        if (module.kind === 'pose' || module.kind === 'position') return selectOne(module.kind, module.id);
        if (module.kind === 'action') {
          if (module.controllerScope === 'patron' && multiplePatronActions(scene.situationId))
            return saveSelection([...selectedIds, module.id]);
          const role = module.controllerScope || 'generic';
          return saveSelection([...selectedIds.filter(id => {
            const current = modules.find(item => item.id === id);
            return current?.kind !== 'action' || (current.controllerScope || 'generic') !== role;
          }), module.id]);
        }
        if (['오른손', '왼손'].includes(module.controllerGroup)) return saveSelection([
          ...selectedIds.filter(id => {
            const current = modules.find(item => item.id === id);
            return current?.controllerScope !== module.controllerScope || current.controllerGroup !== module.controllerGroup;
          }), module.id,
        ]);
        if (module.controllerGroup === '옷 상태' && module.controllerLabel === '완전 나체') return saveSelection([
          ...selectedIds.filter(id => {
            const current = modules.find(item => item.id === id);
            return current?.controllerScope !== module.controllerScope || current.controllerGroup !== '옷 상태';
          }), module.id,
        ]);
        if (module.controllerGroup === '옷 상태') return saveSelection([
          ...selectedIds.filter(id => {
            const current = modules.find(item => item.id === id);
            return current?.controllerScope !== module.controllerScope || current.controllerLabel !== '완전 나체';
          }), module.id,
        ]);
        return saveSelection([...selectedIds, module.id]);
      };
      const tagCandidates = value => {
        const query = String(value || '').trim();
        if (!/[가-힣]/.test(query)) return [];
        return allPromptTags().filter(tag => /^[a-z0-9][a-z0-9_+./' -]{0,79}$/.test(tag)
          && translatedPromptTag(tag).includes(query));
      };
      const translatedTags = value => promptTokens(value).map(tag => translatedPromptTag(tag)).join(' · ')
        || '프롬프트를 입력하면 한글 풀이가 표시됩니다.';
      const saveModule = (id, patch, updateView = true) => {
        const promptField = ['positivePrompt', 'negativePrompt'].find(field => field in patch);
        if (promptField) {
          if (!savePositionModulePrompt(id, promptField, patch[promptField])) {
            positionGeneration.message = '모듈 프롬프트를 저장하지 못했습니다.';
            return false;
          }
        } else if (id.startsWith('custom-')) {
          const next = currentPositionModules().map(module => module.id === id ? { ...module, ...patch } : module);
          api.settings.set({ positionModules: normalizePositionModules(next) });
        }
        positionGeneration.message = '모듈 프롬프트를 저장했습니다.';
        if (updateView) { refreshPortraitImage(); win.refresh(); }
        return true;
      };
      const removeCustomModule = id => {
        const remaining = currentPositionModules().filter(module => module.id !== id);
        const available = modules.filter(module => module.id !== id);
        api.settings.set({ positionModules: remaining,
          positionModuleSelections: normalizePositionModuleSelections(currentPositionModuleSelections(), available),
          positionModulePoseAssignments: normalizePositionModulePoseAssignments(currentPositionModulePoseAssignments(), available) });
        if (activePositionModuleEditorId === id) activePositionModuleEditorId = '';
        if (activeTagTarget?.kind === 'position-module' && activeTagTarget.id === id) activeTagTarget = null;
        refreshPortraitImage();
        win.refresh();
      };
      const targetModulePrompt = (module, field) => {
        activeTagTarget = { kind: 'position-module', id: module.id, field,
          label: `${module.name} ${field === 'negativePrompt' ? 'Negative' : 'Positive'}` };
      };
      const resetKind = ({ position: 'position', posture: 'pose', action: 'action' })[sectionId];
      const moduleButton = module => h('div', { style: 'display:flex;gap:5px;min-width:0;' },
        h('button', { type: 'button', disabled: !scene,
          'data-position-module-kind': module.kind, 'data-position-module-id': module.id,
          ...(module.controllerGroup ? { 'data-controller-module-select': module.id }
            : { 'data-position-module-select': module.id }),
          'aria-label': module.name, 'aria-pressed': selectedIds.includes(module.id) ? 'true' : 'false',
          title: `${positionModuleDirection(module)} · Positive: ${module.positivePrompt || '없음'}${module.negativePrompt ? ` · Negative: ${module.negativePrompt}` : ''}`,
          style: `${chipStyle(selectedIds.includes(module.id))}flex:1;min-width:0;text-align:left;`,
          onclick: () => selectControllerModule(module),
        }, h('span', { style: 'display:block;' }, module.controllerLabel || module.name),
          h('small', { style: 'display:block;color:#d6d3d1;font-size:10px;margin-top:2px;' }, positionModuleDirection(module))),
        h('button', { type: 'button', 'data-controller-module-edit': module.id,
          'aria-label': `${module.name} 태그 수정`, 'aria-pressed': activePositionModuleEditorId === module.id ? 'true' : 'false',
          style: `${chipStyle(activePositionModuleEditorId === module.id)}flex:none;`,
          onclick: () => { activePositionModuleEditorId = module.id; targetModulePrompt(module, 'positivePrompt'); win.refresh(); },
        }, '수정'));
      return [
        onlyClimax ? null : h('div', { 'data-position-module-current': '', style: 'border:1px solid #57534e;border-radius:8px;padding:10px 12px;margin-bottom:12px;background:#1c1917;' },
          h('strong', { style: 'font-size:12px;' }, scene ? `현재 상황 · ${positionSituationLabel(scene.situationId)}` : '현재 상황을 확인할 수 없음'),
          h('p', { class: 'wml-muted wml-small', style: 'margin:5px 0 0;' }, scene
             ? onlyState ? '상태 프롬프트만 적용 중' : selected.length ? `직접 선택 ${selected.length}개` : '게임·제어판 상태 따라가기'
            : '게임을 시작하고 초상화가 한 번 표시된 뒤 다시 열어 주세요.'),
          selected.length ? h('div', { style: 'display:flex;flex-wrap:wrap;gap:5px;margin-top:8px;' },
            ...selected.map(module => h('button', { type: 'button', disabled: !scene,
              'data-position-module-remove': module.id, 'aria-label': `${module.name} 선택 해제`,
              style: `${chipStyle(true)}min-height:30px;padding:5px 8px;`,
              onclick: () => saveSelection(selectedIds.filter(id => id !== module.id)),
            }, `${module.name} · 해제`))) : null,
          !selected.length && controller?.pose ? h('p', { class: 'wml-muted wml-small', style: 'margin:5px 0 0;' },
            `${controller.pose.name} 자동 반영`) : null,
          !onlyState && choice?.modules?.some(module => climaxModuleThreshold(module))
            && femaleClimaxCount(scene.situationId, scene.characterId, api.store.game()) > 0
            ? h('p', { class: 'wml-muted wml-small', 'data-position-climax-auto': '', style: 'margin:5px 0 0;' },
              `현재 장면 아내 절정 ${femaleClimaxCount(scene.situationId, scene.characterId, api.store.game())}회 · 절정 태그 자동 반영 중`)
            : null,
          selectedPose ? h('div', { 'data-position-pose-link': selectedPose.id,
             style: 'border-top:1px solid #44403c;margin-top:9px;padding-top:9px;display:grid;gap:6px;' },
             h('strong', { style: 'font-size:12px;' }, `자세별 체위 · ${selectedPose.name}`),
             h('span', { class: 'wml-small' }, linkedPosition
               ? `연결됨: ${linkedPosition.name} · 직접 고른 체위가 우선해요.`
               : selectedPosition ? `선택한 체위: ${selectedPosition.name}` : '체위 탭에서 모듈을 고르면 이 자세에 연결할 수 있어요.'),
             h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;' },
               h('button', { type: 'button', disabled: !scene || !selectedPosition,
                 'data-position-pose-link-save': selectedPose.id,
                 style: chipStyle(Boolean(selectedPosition)),
                 onclick: () => {
                   if (!scene || !selectedPosition) return;
                   const nextSelections = { ...selections };
                   const remaining = selectedIds.filter(id => id !== selectedPosition.id);
                   if (remaining.length) nextSelections[scene.situationId] = remaining;
                   else delete nextSelections[scene.situationId];
                   api.settings.set({ positionModulePoseAssignments: {
                     ...currentPositionModulePoseAssignments(), [selectedPose.id]: selectedPosition.id,
                   }, positionModuleSelections: nextSelections });
                   positionGeneration.message = `${selectedPose.name}에서는 ${selectedPosition.name} 체위를 사용합니다.`;
                   refreshPortraitImage();
                   win.refresh();
                 },
               }, '이 자세에서 선택한 체위 사용'),
               linkedPosition ? h('button', { type: 'button', 'data-position-pose-link-remove': selectedPose.id,
                 style: chipStyle(false), onclick: () => {
                   const next = { ...currentPositionModulePoseAssignments() };
                   delete next[selectedPose.id];
                   api.settings.set({ positionModulePoseAssignments: next });
                   positionGeneration.message = `${selectedPose.name}의 체위 연결을 해제했습니다.`;
                   refreshPortraitImage();
                   win.refresh();
                 },
                }, '연결 해제') : null),
          ) : null,
        ),
        h('div', { style: 'border:1px solid #44403c;border-radius:8px;padding:10px 12px;margin-bottom:12px;' },
          h('strong', { style: 'font-size:12px;' }, onlyClimax ? '절정 횟수별 모듈' : '모듈 선택'),
          onlyClimax ? null : h('p', { class: 'wml-muted wml-small', style: 'margin:5px 0 10px;' },
            '종류 → 부위·동작 → 버튼 순서로 고르세요. 선택한 버튼은 조합에 더해집니다.'),
          onlyClimax ? null : h('div', { role: 'group', 'aria-label': '모듈 종류', style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(95px,1fr));gap:5px;margin-bottom:10px;' },
            ...sections.map(([id, label]) => h('button', { type: 'button', 'data-position-module-section': id,
              'aria-pressed': sectionId === id ? 'true' : 'false', style: chipStyle(sectionId === id),
              onclick: () => { activePositionModuleSection = id; activePositionModuleGroup = ''; activeTagTarget = null; win.refresh(); },
            }, label))),
          scopeChoices.length > 1 ? h('div', { role: 'group', 'aria-label': '장면 주체', style: 'display:flex;gap:5px;margin-bottom:10px;' },
            ...scopeChoices.map(id => h('button', { type: 'button', 'data-position-module-scope': id,
              'aria-pressed': scope === id ? 'true' : 'false', style: chipStyle(scope === id),
              onclick: () => { activePositionModuleScope = id; activePositionModuleGroup = ''; activeTagTarget = null; win.refresh(); },
            }, id === 'patron' ? `손님${patronCount > 1 ? ` ${patronCount}명` : ''}` : '당신'))) : null,
          patronCount > 1 && scope === 'patron' ? h('p', { class: 'wml-muted wml-small', style: 'margin:0 0 8px;' },
            '손님 방향은 손님 그룹 기준입니다. 단부루 태그만으로 손님 한 명을 지정할 수는 없습니다.') : null,
          groups.length > 1 ? h('div', { role: 'group', 'aria-label': '부위와 동작', style: 'display:flex;flex-wrap:wrap;gap:5px;margin-bottom:10px;' },
            ...groups.map(group => h('button', { type: 'button', 'data-position-module-group': group,
              'aria-pressed': activeGroup === group ? 'true' : 'false', style: chipStyle(activeGroup === group),
              onclick: () => { activePositionModuleGroup = group; activeTagTarget = null; win.refresh(); },
            }, group))) : null,
          resetKind ? h('button', { type: 'button', disabled: !scene,
            'data-position-module-kind': resetKind, 'data-position-module-id': '',
            'aria-pressed': selected.some(module => module.kind === resetKind) ? 'false' : 'true',
            style: `${chipStyle(!selected.some(module => module.kind === resetKind))}margin-bottom:8px;`,
            onclick: () => selectOne(resetKind, ''),
          }, sectionId === 'posture' ? '게임 자세 사용' : sectionId === 'position' ? '제어판 체위 따라가기' : '게임 행동 사용') : null,
          h('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:6px;' },
            ...shownModules.map(moduleButton)),
          sectionId === 'climax' ? h('button', { type: 'button', 'data-climax-tier-add': String(nextClimaxTier),
            disabled: nextClimaxTier > 99 || currentPositionModules().length >= 50,
            style: `${chipStyle(false)}margin-top:9px;`,
            onclick: () => {
              const id = `custom-climax-${nextClimaxTier}`;
              const module = { id, kind: 'other', name: `아내 절정 · ${nextClimaxTier}회 이상`,
                positivePrompt: '', negativePrompt: '' };
              api.settings.set({ positionModules: [...currentPositionModules(), module] });
              activePositionModuleEditorId = id;
              targetModulePrompt(module, 'positivePrompt');
              win.refresh();
            },
          }, `${nextClimaxTier}회 이상 단계 추가`) : null,
          editorModule ? h('div', { 'data-position-module-edit': editorModule.id,
            style: 'border-top:1px solid #57534e;margin-top:12px;padding-top:12px;display:grid;gap:8px;' },
             h('strong', { style: 'font-size:12px;' }, `${editorModule.name} · 프롬프트`),
             h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, `기본 방향: ${positionModuleDirection(editorModule)}`),
            h('p', { class: 'wml-muted wml-small', style: 'margin:0;' },
              '자유롭게 입력하고 가중치도 사용할 수 있어요. 단부루 라이브러리는 작성할 때 참고하거나 클릭해 추가하세요.'),
            ...[['Positive', 'positivePrompt'], ['Negative', 'negativePrompt']].map(([label, field]) => h('label', {
              style: 'display:grid;gap:4px;font-size:11px;',
            }, h('span', {}, label), h('textarea', {
              value: editorModule[field], rows: 2, maxLength: 2000, spellcheck: false,
              'data-position-module-prompt': `${editorModule.id}:${field}`,
              style: `${inputStyle}resize:vertical;font:12px/1.45 ui-monospace,Consolas,monospace;`,
              onfocus: () => targetModulePrompt(editorModule, field),
              oninput: event => {
                const input = event.currentTarget;
                saveModule(editorModule.id, { [field]: input.value }, false);
                updatePromptTagPreview(event, h, win);
                const note = input.closest?.('label')?.querySelector('[data-position-module-translation]');
                const pending = input.value.split(',').at(-1).trim();
                const candidates = tagCandidates(pending).slice(0, 5);
                if (note) note.textContent = candidates.length
                  ? `입력 후보: ${candidates.map(tag => `${translatedPromptTag(tag)} → ${tag}`).join(' · ')}`
                  : translatedTags(input.value);
              },
              onchange: event => {
                const input = event.currentTarget;
                if (!saveModule(editorModule.id, { [field]: input.value })) {
                  const note = input.closest?.('label')?.querySelector('[data-position-module-translation]');
                  if (note) note.textContent = '모듈 프롬프트를 저장하지 못했습니다.';
                  return;
                }
              },
            }), promptTagPreview(h, editorModule[field], win),
              h('span', { class: 'wml-muted wml-small', 'data-position-module-translation': `${editorModule.id}:${field}` }, ''))),
            climaxModuleThreshold(editorModule) > 3 ? h('button', { type: 'button',
              'data-climax-tier-remove': editorModule.id, style: chipStyle(false),
              onclick: () => removeCustomModule(editorModule.id),
            }, `${climaxModuleThreshold(editorModule)}회 이상 단계 삭제`) : null,
            !editorModule.id.startsWith('custom-') ? api.ui.button('기본 태그 복원', () => {
              const next = { ...currentPositionModulePrompts() };
              delete next[editorModule.id];
              api.settings.set({ positionModulePrompts: next });
              refreshPortraitImage();
              win.refresh();
            }, { disabled: !currentPositionModulePrompts()[editorModule.id] }) : null,
          ) : null,
        ),
        onlyClimax ? null : renderModuleGroupLayout(h, win, scene),
        onlyClimax ? null : renderPositionStatePromptSettings(h, win, scene, statePrompt),
        onlyClimax ? null : h('div', { style: 'border:1px solid #44403c;border-radius:7px;padding:9px 10px;margin-bottom:10px;' },
          h('strong', { style: 'font-size:12px;' }, '현재 조합 미리보기'),
          h('p', { class: 'wml-small', 'data-position-module-positive': '', style: 'white-space:pre-wrap;overflow-wrap:anywhere;' },
            `Positive: ${choice?.modules.map(module => module.positivePrompt).filter(Boolean).join(', ') || '(없음)'}`),
          h('p', { class: 'wml-small', 'data-position-module-negative': '', style: 'white-space:pre-wrap;overflow-wrap:anywhere;' },
            `Negative: ${choice?.modules.map(module => module.negativePrompt).filter(Boolean).join(', ') || '(없음)'}`),
        ),
        onlyClimax ? null : h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px;' },
          api.ui.button(positionGeneration.running ? '생성 중…' : '현재 이미지 재생성', () => {
            void generatePositionImage(false, win);
          }, { primary: true, disabled: !scene || (!choice && !statePrompt?.positivePrompt && !statePrompt?.negativePrompt) || positionGeneration.running }),
          api.ui.button('이미지 추가 생성', () => { void generatePositionImage(true, win); },
            { disabled: !scene || positionGeneration.running }),
          api.ui.button('현재 조합 해제', () => saveSelection([]), { disabled: !selectedIds.length }),
        ),
        positionGeneration.message ? h('p', { class: 'wml-note', style: 'margin-bottom:10px;' }, positionGeneration.message) : null,
        onlyClimax ? null : h('details', { style: 'border:1px solid #44403c;border-radius:7px;padding:9px 10px;' },
          h('summary', { style: 'font-size:12px;cursor:pointer;' }, `내 모듈 관리 · ${currentPositionModules().length}개`),
          ...currentPositionModules().filter(module => !climaxModuleThreshold(module)).map(module => h('div', {
            style: 'border-top:1px solid #292524;padding:9px 0;display:grid;gap:6px;' },
            h('div', { style: 'display:grid;grid-template-columns:minmax(0,1fr) 120px auto;gap:6px;' },
              h('input', { value: module.name, maxLength: 80, 'data-position-module-name': module.id,
                style: inputStyle, onchange: event => saveModule(module.id, { name: event.currentTarget.value }) }),
              h('select', { value: module.kind, 'data-position-module-type': module.id, style: inputStyle,
                onchange: event => {
                  saveModule(module.id, { kind: event.currentTarget.value });
                  activePositionModuleSection = positionModuleSection({ kind: event.currentTarget.value });
                  activePositionModuleGroup = '';
                  win.refresh();
                } },
               ...[['pose', '여성 자세'], ['position', '체위'], ['action', '행동'], ['mood', '분위기'], ['other', '기타']]
                .map(([value, label]) => h('option', { value, selected: module.kind === value }, label))),
              api.ui.button('삭제', () => removeCustomModule(module.id))),
          )),
          api.ui.button('새 모듈 추가', () => {
            const id = `custom-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
            api.settings.set({ positionModules: [...currentPositionModules(),
              { id, kind: 'mood', name: '새 모듈', positivePrompt: '', negativePrompt: '' }] });
            activePositionModuleEditorId = id;
            activePositionModuleSection = 'other';
            activePositionModuleGroup = '직접 추가';
            win.refresh();
          }, { disabled: currentPositionModules().length >= 50 }),
        ),
      ];
    }

    function renderPositionSettings(h, win) {
      const mode = positionMode();
      const chooseMode = nextMode => {
        api.settings.set({ positionMode: nextMode });
        activeTagTarget = null;
        positionGeneration.message = '체위 변경 방식을 전환했습니다. 두 방식의 설정은 각각 유지됩니다.';
        refreshPortraitImage();
        win.refresh();
      };
      return [
        h('div', { style: 'display:grid;gap:6px;margin-bottom:12px;font-size:12px;' },
          h('strong', {}, '체위 변경 방식'),
          h('div', { style: 'display:flex;flex-wrap:wrap;gap:5px;' },
            ...[['legacy', '기존 체위 변경'], ['modules', '모듈 조합']].map(([value, label]) => h('button', {
              type: 'button', 'data-position-mode': value, 'aria-pressed': mode === value ? 'true' : 'false',
              style: `padding:8px 12px;border:1px solid ${mode === value ? '#f59e0b' : '#57534e'};border-radius:6px;background:${mode === value ? '#78350f' : '#292524'};color:#fef3c7;cursor:pointer;`,
              onclick: () => chooseMode(value),
            }, label))),
          h('label', { style: 'display:flex;align-items:center;gap:6px;' },
            h('input', { type: 'checkbox', 'data-aip-position-controller-enabled': '',
              checked: positionControllerApi.getState().enabled,
              onchange: event => {
                positionControllerApi.setEnabled(event.currentTarget.checked);
                syncPositionControllerButton();
                win.refresh();
              } }),
            'AIP 체위 콘솔 사용'),
          h('span', { class: 'wml-muted wml-small' },
            '모듈 조합에서 사용할 수 있습니다. 실제 게임 행동을 실행하며 게임의 시간과 상태가 바뀔 수 있습니다.')),
        ...(mode === 'modules' ? renderPositionModuleSettings(h, win) : renderLegacyPositionSettings(h, win)),
      ];
    }
