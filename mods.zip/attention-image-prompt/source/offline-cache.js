    // shortcut: directory permission may expire after restart; reconnect from a user gesture when prompted.
    const offlineCache = (() => {
      const dbName = 'wml.mod.attention-image-prompt.offline-images';
      const dbStore = 'folders';
      const indexPattern = /^\.image-cache(?:_[a-z0-9][a-z0-9_-]{0,99})?\.json$/i;
      let directory = null, entries = new Map(), loadedAt = 0, pending = null, generation = 0;
      let status = 'unconfigured', message = '', saved = false, writes = Promise.resolve();
      const urls = new Map(), retiredUrls = [];

      function releaseUrls() {
        for (const value of urls.values()) URL.revokeObjectURL(value.url);
        for (const value of retiredUrls) URL.revokeObjectURL(value);
        urls.clear();
        retiredUrls.length = 0;
      }
      function retireUrl(url) {
        retiredUrls.push(url);
        if (retiredUrls.length > 128) URL.revokeObjectURL(retiredUrls.shift());
      }
      async function database() {
        if (!globalThis.indexedDB) throw new Error('indexeddb_unavailable');
        return await new Promise((resolve, reject) => {
          const request = indexedDB.open(dbName, 1);
          request.onupgradeneeded = () => request.result.createObjectStore(dbStore);
          request.onsuccess = () => resolve(request.result);
          request.onerror = () => reject(request.error || new Error('indexeddb_open_failed'));
          request.onblocked = () => reject(new Error('indexeddb_blocked'));
        });
      }
      async function stored(mode, value) {
        const db = await database();
        try {
          return await new Promise((resolve, reject) => {
            const transaction = db.transaction(dbStore, mode === 'get' ? 'readonly' : 'readwrite');
            const store = transaction.objectStore(dbStore);
            const request = mode === 'get' ? store.get('images') : mode === 'delete' ? store.delete('images') : store.put(value, 'images');
            request.onerror = () => reject(request.error || new Error('indexeddb_request_failed'));
            transaction.oncomplete = () => resolve(mode === 'get' ? request.result : undefined);
            transaction.onerror = () => reject(transaction.error || new Error('indexeddb_transaction_failed'));
            transaction.onabort = () => reject(transaction.error || new Error('indexeddb_transaction_aborted'));
          });
        } finally { db.close(); }
      }
      function normalizeEntry(key, entry) {
        const name = String(entry?.talentName || key || '');
        const path = typeof entry?.imagePath === 'string' ? entry.imagePath.replaceAll('\\', '/') : '';
        const parts = path.split('/');
        if (!name || name.length > 2048 || /[\/\\\x00-\x1f]/.test(name)
          || !path || path.length > 2048 || path.startsWith('/') || /^[a-z]+:/i.test(path)
          || parts.some(part => !part || part === '.' || part === '..' || /[\x00-\x1f:]/.test(part))
          || !/\.(?:webp|png|jpe?g)$/i.test(path)) return null;
        return { talentName: name, imagePath: path, imageType: entry.imageType || 'portrait',
          createdAt: Number(entry.createdAt) || 0, source: 'attention-image-prompt-offline' };
      }
      function cacheCharacter(entry) {
        const name = entry.talentName.toLowerCase();
        const path = entry.imagePath.toLowerCase();
        if (/^situation_(?:fluid|vulva|status|observation|event)__[a-z][a-z0-9_-]{0,99}__/i.test(name)) return 'h-status_cache';
        const folder = path.match(/(?:^|\/)characters\/([^/]+)\//)?.[1];
        if (folder && /^[a-z0-9][a-z0-9_-]{0,99}$/.test(folder)) return folder;
        const structured = name.startsWith('situation_') ? name.split('__')[1] : name.split('__')[0];
        return structured && /^[a-z0-9][a-z0-9_-]{0,99}$/.test(structured)
          && (name.includes('__') || /^[a-z][a-z0-9]*$/.test(name)) ? structured : 'shared';
      }
      async function indexFolder(handle) {
        const fresh = new Map(), files = [], groups = new Map(), migrations = [], validShards = new Set();
        let found = 0, valid = 0, oversized = 0;
        for await (const [name, file] of handle.entries()) {
          if (!indexPattern.test(name) || file.kind !== 'file') continue;
          files.push([name, file]); found += 1;
        }
        const shards = new Set(files.filter(([name]) => name.toLowerCase() !== '.image-cache.json')
          .map(([name]) => name.slice('.image-cache_'.length, -'.json'.length).toLowerCase()));
        for (const [name, file] of files) {
          try {
            const blob = await file.getFile();
            if (blob.size > 64 * 1024 * 1024) { oversized += 1; continue; }
            const index = JSON.parse(await blob.text());
            if (index?.version !== 1 || !index.entries || typeof index.entries !== 'object' || Array.isArray(index.entries)) continue;
            valid += 1;
            const shard = name.toLowerCase() === '.image-cache.json' ? null
              : name.slice('.image-cache_'.length, -'.json'.length).toLowerCase();
            if (shard !== null) validShards.add(shard);
            for (const [key, raw] of Object.entries(index.entries)) {
              const entry = normalizeEntry(key, raw);
              if (!entry) continue;
              const owner = cacheCharacter(entry);
              if (shard === null && shards.has(owner)) continue;
              if (shard !== null && shard !== owner) {
                if (owner === 'h-status_cache') migrations.push([owner, key, entry]);
                continue;
              }
              if (!groups.has(owner)) groups.set(owner, new Map());
              groups.get(owner).set(key, entry);
            }
          } catch { /* Ignore damaged indexes; do not touch their files. */ }
        }
        if (!valid) throw new Error(oversized ? 'image_index_too_large' : found ? 'invalid_image_index' : 'missing_image_index');
        for (const [owner, key, entry] of migrations) {
          if (shards.has(owner) && !validShards.has(owner)) continue;
          if (!groups.has(owner)) groups.set(owner, new Map());
          if (!groups.get(owner).has(key)) groups.get(owner).set(key, entry);
        }
        for (const group of groups.values()) for (const entry of group.values()) {
          if (!fresh.has(entry.talentName)) fresh.set(entry.talentName, []);
          fresh.get(entry.talentName).push(entry);
        }
        for (const choices of fresh.values()) choices.sort((a, b) => b.createdAt - a.createdAt);
        return { entries: fresh, warning: valid < found ? '일부 이미지 목록을 읽지 못했어요. 파일 형식과 크기를 확인해 주세요.' : '' };
      }
      async function load(handle, epoch) {
        const fresh = await indexFolder(handle);
        if (directory !== handle || generation !== epoch) return;
        entries = fresh.entries;
        loadedAt = Date.now();
        status = 'ready';
        message = fresh.warning;
      }
      async function refresh(force = false) {
        if (!directory || status !== 'ready' || !force && Date.now() - loadedAt < 15000) return;
        if (!pending) {
          const current = directory, epoch = generation;
          pending = load(current, epoch).catch(() => { if (directory === current && generation === epoch) { status = 'unavailable'; message = '이미지 목록을 읽을 수 없어요. 폴더 권한을 확인해 주세요.'; } })
            .finally(() => { pending = null; });
        }
        await pending;
      }
      async function activate(handle, persist, epoch = ++generation) {
        const nextEntries = await indexFolder(handle);
        if (epoch !== generation) return false;
        releaseUrls();
        directory = handle;
        entries = nextEntries.entries;
        loadedAt = Date.now();
        status = 'ready';
        message = nextEntries.warning;
        if (persist) {
          try {
            writes = writes.catch(() => {}).then(() => epoch === generation ? stored('put', handle) : undefined);
            await writes;
            if (epoch === generation) saved = true;
          } catch { if (epoch === generation) { saved = false; message = '이 브라우저에서는 폴더 선택을 저장하지 못해 다음 실행 때 다시 선택해야 해요.'; } }
        }
        return epoch === generation;
      }
      async function choose() {
        if (typeof globalThis.showDirectoryPicker !== 'function') {
          status = 'unsupported'; message = '이 브라우저에서는 폴더 연결을 지원하지 않아요.'; return false;
        }
        const epoch = ++generation;
        try {
          const handle = await globalThis.showDirectoryPicker({ mode: 'read' });
          return await activate(handle, true, epoch);
        } catch (error) {
          if (epoch === generation && error?.name !== 'AbortError') message = error?.message === 'missing_image_index'
            ? '이미지 목록이 없어요. 이미지 서버의 images 폴더를 선택해 주세요.'
            : error?.message === 'image_index_too_large' ? '이미지 목록이 64MiB를 넘어 읽을 수 없어요.'
            : error?.message === 'invalid_image_index' ? '이미지 목록을 읽을 수 없어요. 올바른 images 폴더인지 확인해 주세요.'
              : '폴더에 접근하지 못했어요. 읽기 권한을 확인해 주세요.';
          return false;
        }
      }
      async function restore() {
        const epoch = generation;
        try {
          const handle = await stored('get');
          if (epoch !== generation) return false;
          if (!handle) return false;
          saved = true;
          directory = handle;
          const permission = await handle.queryPermission({ mode: 'read' });
          if (epoch !== generation) return false;
          if (permission !== 'granted') { status = 'permission'; return false; }
          return await activate(handle, false, epoch);
        } catch { if (epoch === generation) status = directory ? 'unavailable' : 'unconfigured'; return false; }
      }
      async function reconnect() {
        if (!directory) return choose();
        const current = directory, epoch = ++generation;
        try {
          const permission = await current.requestPermission({ mode: 'read' });
          if (epoch !== generation) return false;
          if (permission !== 'granted') { status = 'permission'; return false; }
          return await activate(current, false, epoch);
        } catch { if (epoch === generation) { status = 'unavailable'; message = '폴더에 접근하지 못했어요. 다시 선택해 주세요.'; } return false; }
      }
      async function disconnect() {
        generation += 1;
        releaseUrls(); directory = null; entries = new Map(); loadedAt = 0;
        status = 'unconfigured'; message = ''; saved = false;
        try { writes = writes.catch(() => {}).then(() => stored('delete')); await writes; }
        catch { message = '저장된 연결 정보를 지우지 못했어요. 브라우저 사이트 데이터를 확인해 주세요.'; }
      }
      async function resolve(keys) {
        if (!directory || status !== 'ready') return null;
        const current = directory, epoch = generation;
        try {
          const permission = await current.queryPermission({ mode: 'read' });
          if (directory !== current || generation !== epoch) return null;
          if (permission !== 'granted') { status = 'permission'; return null; }
          await refresh();
          if (status !== 'ready' || directory !== current || generation !== epoch) return null;
          for (const key of new Set(Array.isArray(keys) ? keys : [keys])) {
            for (const entry of entries.get(key) || []) try {
              const parts = entry.imagePath.split('/');
              let parent = directory;
              for (const part of parts.slice(0, -1)) parent = await parent.getDirectoryHandle(part);
              const file = await parent.getFileHandle(parts.at(-1));
              const image = await file.getFile();
              if (directory !== current || generation !== epoch) return null;
              if (!image.size || image.type && !/^image\/(?:webp|png|jpeg)$/i.test(image.type)) continue;
              const fingerprint = `${image.size}:${image.lastModified || 0}:${image.type || ''}`;
              let cached = urls.get(entry.imagePath);
              if (!cached || cached.fingerprint !== fingerprint) {
                if (cached) retireUrl(cached.url);
                cached = { url: URL.createObjectURL(image), fingerprint };
                urls.set(entry.imagePath, cached);
                if (urls.size > 512) { const oldest = urls.keys().next().value; retireUrl(urls.get(oldest).url); urls.delete(oldest); }
              }
              if (directory !== current || generation !== epoch) return null;
              return { ...entry, offlineUrl: cached.url };
            } catch { /* Removed or inaccessible files are not valid cache hits. */ }
          }
        } catch { if (directory === current && generation === epoch) status = 'unavailable'; }
        return null;
      }
      function getState() { return { status, message, saved, count: entries.size, folderName: directory?.name || '' }; }
      function ownsUrl(entry) { return entry?.source === 'attention-image-prompt-offline'
        && typeof entry.offlineUrl === 'string' && (urls.get(entry.imagePath)?.url === entry.offlineUrl || retiredUrls.includes(entry.offlineUrl)); }
      globalThis.addEventListener?.('unload', releaseUrls, { once: true });
      void restore().then(ready => { if (ready) offlineImageRefreshView(); });
      return { choose, reconnect, disconnect, resolve, getState, refresh, ownsUrl };
    })();

    function offlineImageCandidates(key) {
      if (typeof key !== 'string' || !key) return [];
      const previous = compactSituationAliases.get(key), alias = statusCacheAliases.get(key);
      return [...new Set([key, previous, previous && compactGenerationKey(previous),
        previous && compactGenerationKey(previous, true), alias, alias && compactGenerationKey(alias),
        alias && compactGenerationKey(alias, true), compactGenerationKey(key), compactGenerationKey(key, true)].filter(Boolean))];
    }

    function offlineManualCandidate(key) {
      if (typeof key !== 'string' || /__(?:content|aipk)-/.test(key)) return '';
      try {
        const choice = similarImageLookupOverride(key);
        return choice?.source?.startsWith('manual-') && choice.source !== 'manual-auto-cleanup' ? choice.key : '';
      } catch { return ''; }
    }

    async function offlineServerUnavailable() {
      if (globalThis.__WW_STUDIO_OFFLINE_ONLY__ === true) return true;
      try { if (settingsStore?.getState?.().imageBackendMode === 'off') return true; } catch {}
      let unavailable = false;
      try {
        const url = imageServerUrl('/api/image/health');
        if (!url) unavailable = true;
        else {
          const options = { credentials: 'omit', cache: 'no-store' };
          if (globalThis.AbortSignal?.timeout) options.signal = AbortSignal.timeout(1500);
          await fetch(url, options);
        }
      } catch (error) { unavailable = error?.name === 'TypeError'; }
      return unavailable;
    }

    function offlineImageRefreshView() {
      try { if (api.has('imageManifestReset')) api.fn('imageManifestReset')(); } catch {}
      try { globalThis.WW_ImageStudioMatching?.refresh?.(); } catch {}
      try { refreshPortraitImage(); } catch {}
    }

    api.hook('imageLookup', {
      priority: -3000000,
      async around(next, key, ...args) {
        let result, error;
        try { result = await next(key, ...args); } catch (cause) { error = cause; }
        if (offlineCache.getState().status === 'ready') {
          const candidates = offlineImageCandidates(key), manual = offlineManualCandidate(key);
          const keys = manual ? [...offlineImageCandidates(manual), ...candidates] : candidates;
          const valid = !!result && (result.source !== 'server' || await imageEntryExists(result));
          const localPack = valid && result.source !== 'server' && result.source !== 'attention-image-prompt-offline'
            && (!manual || result.talentName !== manual);
          const local = (!valid || localPack) && await offlineServerUnavailable() ? await offlineCache.resolve(keys) : null;
          if (local) return local;
        }
        if (error) throw error;
        return result;
      },
    });
    if (api.has('imageGenerate')) api.hook('imageGenerate', {
      priority: -3000000,
      async around(next, request, ...args) {
        if (!request || request.bypassCache === true || request.bulk || offlineCache.getState().status !== 'ready')
          return next(request, ...args);
        let result, error;
        try { result = await next(request, ...args); } catch (cause) { error = cause; }
        const manual = offlineManualCandidate(request.imageKey);
        const missing = !result?.url || result.imageMatchingMissing === true
          || result.fresh === false && !await imageEntryExists({ url: result.url });
        const sameKeyPack = result?.url && result.fresh === false && result.key === request.imageKey && !manual;
        if ((missing || sameKeyPack) && await offlineServerUnavailable()) {
          const keys = offlineImageCandidates(request.imageKey);
          const local = await offlineCache.resolve(manual ? [...offlineImageCandidates(manual), ...keys] : keys);
          if (local) return { url: local.offlineUrl, key: request.imageKey, fresh: false };
        }
        if (error) throw error;
        return result;
      },
    });

    function renderOfflineImageFolder(h, win) {
      const state = offlineCache.getState();
      const status = state.status === 'ready' ? `연결됨: ${state.folderName} · 이미지 ${state.count.toLocaleString()}개`
        : state.status === 'permission' ? '브라우저가 폴더 읽기 재허용을 기다리고 있어요.'
          : state.status === 'unsupported' ? '이 브라우저에서는 폴더 연결을 지원하지 않아요.'
            : state.status === 'unavailable' ? '연결된 폴더를 읽을 수 없어요.' : '연결된 폴더가 없어요.';
      const run = action => { void action().then(() => {
        offlineImageRefreshView();
        win.refresh();
      }); };
      return [
        h('p', { class: 'wml-note' }, '이미지 서버를 끈 뒤 기존 그림을 보려면 서버가 저장한 images 폴더를 읽기 전용으로 연결해 주세요. 실제 파일을 복사하거나 변경하지 않습니다.'),
        h('p', { class: 'wml-small', role: 'status', 'data-aip-offline-status': '' }, `${status}${state.message ? ` · ${state.message}` : ''}`),
        api.ui.button('기존 이미지 폴더 연결', () => run(() => offlineCache.choose())),
        state.status === 'permission' || state.status === 'unavailable'
          ? api.ui.button('폴더 읽기 권한 다시 허용', () => run(() => offlineCache.reconnect())) : null,
        state.status !== 'unconfigured' && state.status !== 'unsupported'
          ? api.ui.button('연결 해제', () => run(() => offlineCache.disconnect())) : null,
      ];
    }
