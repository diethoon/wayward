    // Use view tags without naming a physical camera.
    const CAMERA_PRESET_GROUPS = [
      { id: 'viewpoint', label: '시점', items: [
        { id: 'pov', name: '1인칭 시점', positive: 'first-person view, pov', negative: '' },
        { id: 'third_person', name: '3인칭 관찰', positive: 'third-person view', negative: '' },
        { id: 'pov_hands', name: '1인칭 · 손 보임', positive: 'first-person view, pov, pov_hands', negative: '' },
        { id: 'pov_above', name: '1인칭 · 위에서', positive: 'first-person view, pov, top view, from_above', negative: '' },
        { id: 'pov_below', name: '1인칭 · 아래에서', positive: 'first-person view, pov, low-angle view, from_below', negative: '' },
      ] },
      { id: 'direction', label: '방향', items: [
        { id: 'front', name: '정면', positive: 'front view, straight-on', negative: '' },
        { id: 'three_quarter', name: '사선', positive: 'three-quarter view', negative: '' },
        { id: 'side', name: '측면', positive: 'side view, from_side', negative: '' },
        { id: 'rear', name: '뒤쪽에서', positive: 'back view, from_behind', negative: '' },
      ] },
      { id: 'elevation', label: '높이', items: [
        { id: 'above', name: '위에서 내려다보기', positive: 'top view, from_above', negative: '' },
        { id: 'ceiling_near', name: '천장 시점 · 가까운 거리', positive: 'top view, from_above, cowboy_shot', negative: '' },
        { id: 'below', name: '아래에서 올려다보기 · 로우앵글', positive: 'low-angle view, from_below', negative: '' },
        { id: 'high_up', name: '높은 곳에서', positive: 'high-angle view, high_up, from_above', negative: '' },
      ] },
      { id: 'framing', label: '화면 범위', items: [
        { id: 'portrait', name: '얼굴 · 어깨', positive: 'portrait', negative: '' },
        { id: 'face_close', name: '얼굴 확대', positive: 'portrait, close-up', negative: '' },
        { id: 'close_up', name: '가까이', positive: 'close-up', negative: '' },
        { id: 'upper_body', name: '상반신', positive: 'upper_body', negative: '' },
        { id: 'cowboy_shot', name: '허벅지 위까지', positive: 'cowboy_shot', negative: '' },
        { id: 'lower_body', name: '하반신', positive: 'lower_body', negative: '' },
        { id: 'full_body', name: '전신', positive: 'full_body', negative: '' },
        { id: 'wide_shot', name: '먼 전신', positive: 'wide_shot', negative: '' },
        { id: 'very_wide_shot', name: '더 먼 전신', positive: 'very_wide_shot', negative: '' },
        { id: 'between_legs', name: '다리 사이', positive: 'low-angle view, from_below, thighs', negative: '' },
      ] },
      { id: 'tilt', label: '화면 기울기', items: [
        { id: 'dutch', name: '기울어진 화면', positive: 'dutch_angle', negative: '' },
        { id: 'sideways', name: '옆으로 회전', positive: 'sideways', negative: '' },
        { id: 'upside_down', name: '거꾸로 회전', positive: 'upside-down', negative: '' },
      ] },
      { id: 'lens', label: '원근', items: [
        { id: 'fisheye', name: '어안 렌즈', positive: 'fisheye', negative: '' },
      ] },
    ].map(group => ({ ...group, items: group.items.map(item => ({ ...item,
      positive: item.positive.split(', ').map(term => `(${term}:1.3)`).join(', '),
    })) }));

    const CAMERA_NEGATIVE_DEFAULTS = 'camera in frame, visible camera, camera device, camera body, camera lens in frame, camera held in hands, DSLR camera, video camera, camcorder, tripod, photography equipment, viewfinder overlay, camera screen overlay, recording overlay, REC icon, battery icon, shutter button, on-screen camera interface';

    // Exclude ambiguous physical action and gaze tags such as 'from behind' or 'looking at viewer'.
    const CAMERA_REMOVE_DEFAULTS = [
      'pov', 'taker pov', 'giver pov', 'first-person view', 'first-person perspective', 'third-person view', 'third-person perspective', 'point of view',
      'pov from above', 'pov from below', 'pov from behind', 'pov from behind her', 'pov from side', 'pov from front',
      'from above', 'from below', 'from side', 'straight-on', 'head-on', 'front view', 'side view', 'rear view', 'back view',
      'three-quarter view', 'high angle', 'low angle', 'high-angle view', 'low-angle view', 'top view', 'overhead view',
      'dutch angle', 'sideways', 'upside-down', 'fisheye', 'high up', 'view between legs',
      'close-up', 'extreme close-up', 'portrait', 'upper body', 'lower body', 'cowboy shot', 'full body', 'wide shot', 'very wide shot',
      'first-person camera view', 'third-person camera view', 'first-person camera view with hands in the foreground',
      'first-person camera view from above', 'first-person camera view from below', 'frontal camera view', 'three-quarter camera view',
      'side camera view', 'rear camera view', 'high-angle camera view', 'overhead camera view', 'medium shot',
      'low-angle camera view', 'camera view from a high vantage point', 'head-and-shoulders portrait shot',
      'close-up shot of the face', 'close-up shot', 'medium shot of the upper body', 'medium-long shot framed from head to mid-thigh',
      'shot framed on the lower body', 'full-body shot', 'extreme wide shot', "camera positioned between the subject's legs",
      'camera rotated 90 degrees', 'camera rotated 180 degrees', 'fisheye lens',
    ];
