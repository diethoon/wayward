    // The controller only requests moves through the owning mod's public API.
    let positionControllerExecuting = false;
    const positionControllerPoseTypes = Object.freeze({
      '정상위': 'sex', '후배위': 'sex', '측위': 'sex', '프레스(굴곡위)': 'sex', '복와위': 'sex',
      '기승위': 'riding', '역기승위': 'riding', '입위': 'standing_sex', '벽에 기대서': 'standing_sex',
      '벽에 밀쳐서': 'standing_sex', '벽에서 한발만 들림': 'standing_sex', '들려서': 'standing_sex',
      '발이 땅에 닿지 않게': 'standing_sex', '무릎 구강성교': 'blowjob', '69': 'sixty_nine', '파이즈리': 'titfuck',
    });
    const positionControllerRepresentative = Object.freeze({ sex: '정상위', sex_rough: '프레스(굴곡위)',
      anal: '후배위', riding: '기승위', standing_sex: '입위', blowjob: '무릎 구강성교',
      deepthroat: '무릎 구강성교', sixty_nine: '69', titfuck: '파이즈리' });
    function positionControllerPoseFits(type, label) {
      const target = positionControllerPoseTypes[label];
      return !!target && (target === type || type === 'sex_rough' && target === 'sex'
        || type === 'anal' && ['sex', 'riding', 'standing_sex'].includes(target)
        || type === 'deepthroat' && target === 'blowjob');
    }
    function positionControllerScope(state) {
      const patron = state?.activeScene?.patron;
      const sex = state?.activeScene?.sex;
      if (patron && sex) return state?.pendingEvent?.type === 'sex_scene' ? 'you' : '';
      return patron ? 'patron' : sex ? 'you' : '';
    }
    function positionControllerHusbandOwner(state) {
      const hl = globalThis.__waywardHusbandLife;
      if (!hl) return { hl, owned: false, error: false };
      if (typeof hl.owns !== 'function') return { hl, owned: false, error: true };
      try { return { hl, owned: !!hl.owns(state), error: false }; }
      catch { return { hl, owned: false, error: true }; }
    }
    function positionControllerPose(state = api.store.game()) {
      const sex = state?.activeScene?.sex;
      if (!sex || sex.finish || !state.primaryCharacterId || !Number.isFinite(state.day) || !Number.isFinite(sex.startedAtSlot)
        || sex.characterId != null && sex.characterId !== state.primaryCharacterId
        || positionControllerScope(state) !== 'you') return null;
      const owner = positionControllerHusbandOwner(state);
      if (owner.error) return null;
      if (owner.owned) {
        try {
          const label = owner.hl?.ui?.poseOf?.(sex);
          return label && positionControllerPoseFits(sex.type, label)
            ? { label, provider: 'husband-life', actType: sex.type } : null;
        } catch { return null; }
      }
      const pose = sex.__aipPose;
      return pose?.version === 1 && pose.day === state.day && pose.actType === sex.type && pose.characterId === state.primaryCharacterId
        && pose.startedAtSlot === sex.startedAtSlot && positionControllerPoseFits(sex.type, pose.label)
        ? { label: pose.label, provider: 'aip', actType: sex.type } : null;
    }
    function positionControllerSceneIdentity(state, scope) {
      const scene = scope === 'patron' ? state?.activeScene?.patron
        : scope === 'you' ? state?.activeScene?.sex : null;
      if (!scene || state.day == null || state.primaryCharacterId == null || state.primaryCharacterId === ''
        || scene.startedAtSlot == null || (scope === 'patron' && (scene.customerId == null || scene.customerId === '')))
        return null;
      return JSON.stringify([scope, state.day, scene.startedAtSlot, scene.id ?? null, state.primaryCharacterId,
        scene.customerId ?? null, scene.characterId ?? null, scene.partnerId ?? null]);
    }
    function positionControllerEnabled() {
      return api.settings.get({ positionControllerEnabled: false }).positionControllerEnabled === true;
    }
    function positionControllerState(state = api.store.game(), allowWindow = false) {
      const enabled = positionControllerEnabled();
      const patron = state?.activeScene?.patron;
      const sex = state?.activeScene?.sex;
      const scope = positionControllerScope(state);
      const scene = scope === 'patron' ? patron : scope === 'you' ? sex : null;
      const event = state?.pendingEvent;
      const token = scene ? JSON.stringify([scope, state.day, state.slot, scene.id ?? null,
        scene.startedAtSlot ?? null, state.primaryCharacterId ?? null, scene.characterId ?? null,
        scene.partnerId ?? null, scene.customerId ?? null, scene.stage ?? null, scene.type ?? null,
        scene.playerEngaged ?? null, event?.id ?? null, event?.type ?? null,
        Array.isArray(event?.choices) ? event.choices.map(choice => choice?.id ?? null) : null,
        patron ? [patron.id ?? null, patron.customerId ?? null, patron.characterId ?? null,
          patron.startedAtSlot ?? null, patron.stage ?? null] : null]) : null;
      let reason = !enabled && !allowWindow ? 'disabled' : patron && sex && !scope ? 'actor_conflict' : !scene ? 'no_scene' : '';
      if (!reason && scope === 'you' && sex.characterId != null && sex.characterId !== state.primaryCharacterId)
        reason = 'actor_conflict';
      if (!reason && scope === 'you' && positionControllerHusbandOwner(state).error) reason = 'provider_unavailable';
      if (!reason && positionMode() !== 'modules') reason = 'module_mode_required';
      return { enabled, sceneToken: token, sceneLabel: scope === 'patron'
        ? `손님 · ${scene.customerName || scene.customerId || ''}` : scope === 'you' ? '당신' : '', reason,
        imageWarning: !reason && scope === 'you' ? positionControllerImageConflict(state) : '' };
    }

    function positionControllerImageConflict(state) {
      const scene = typeof latestScenePrompt === 'undefined' ? null : latestScenePrompt;
      if (!scene?.situationId || (scene.characterId && state.primaryCharacterId
        && scene.characterId !== state.primaryCharacterId)) return 'image_context_unavailable';
      const scope = positionControllerScope(state);
      const identity = positionControllerSceneIdentity(state, scope);
      if (!identity || scene.controllerSceneIdentity !== identity) return 'image_context_unavailable';
      const id = scene.situationId;
      const base = basePositionSituationId(id);
      if (!base.startsWith('scene-') || (base.startsWith('scene-patron_') !== (scope === 'patron')))
        return 'image_context_unavailable';
      const currentId = positionSituationId(activePortraitImageKey(scene.result?.key || '', state));
      if (!currentId || currentId !== id) return 'image_context_unavailable';
      if (positionOverride(id) || positionStateOnly(currentPositionStatePrompt(id))) return 'image_override_conflict';
      const selections = currentPositionModuleSelections()[id] || [];
      const modules = availablePositionModules();
      if (modules.some(module => selections.includes(module.id) && ['pose', 'position', 'action'].includes(module.kind)))
        return 'image_override_conflict';
      const layouts = currentPositionModuleGroupLayouts()[id];
      if (layouts && Object.keys(layouts).length) return 'image_override_conflict';
      return '';
    }

    function positionControllerPlan(scene) {
      const provider = globalThis.__waywardPatronControl;
      if (!provider) return { provider: null, plan: null };
      if (typeof provider.plans !== 'function') return { provider, error: 'provider_unavailable' };
      try {
        const plans = provider.plans();
        if (!plans || typeof plans !== 'object') return { provider, error: 'provider_unavailable' };
        return { provider, plan: plans[scene.customerId] || null };
      } catch { return { provider, error: 'provider_unavailable' }; }
    }

    function positionControllerCaressRows(state, hl, sharedReason, dualScene) {
      const sex = state?.activeScene?.sex, ui = hl?.ui;
      if (!sex || !Array.isArray(ui?.CARESS_SETS) || !ui.CARESS
        || typeof ui.caressAllowed !== 'function' || typeof ui.caressPlaced !== 'function'
        || typeof ui.caressKeys !== 'function' || typeof ui.INSIDE?.has !== 'function') return [];
      try {
        const allowed = new Set(ui.caressAllowed(sex, state));
        const placed = new Set(ui.caressPlaced(sex));
        const active = new Set(ui.caressKeys(sex));
        const inside = ui.INSIDE.has(sex.type);
        const dress = typeof ui.dress === 'function' ? ui.dress(state) : null;
        const guarded = dualScene && (state.pendingEvent?.sleepActions != null
          || typeof structuredClone !== 'function' || typeof api.has !== 'function' || !api.has('playerSexChoose'));
        const rows = [];
        for (const set of ui.CARESS_SETS) {
          const [, group, keys] = set;
          if (!Array.isArray(keys)) continue;
          for (const key of keys) {
            if (typeof key !== 'string' || !/^[a-zA-Z0-9_]+$/.test(key) || !ui.CARESS[key]) continue;
            const info = ui.CARESS[key], on = active.has(key);
            const instant = inside && !on;
            const conflict = dualScene && (!instant || guarded);
            const canUse = allowed.has(key) && !sex.finish && sex.__hs?.sleep?.stage !== 'tussle';
            const why = !allowed.has(key) && placed.has(key) && dress && typeof ui.clothWhy === 'function' ? ui.clothWhy(key, dress) : '';
            rows.push({ id: `hl:caress:${key}`, provider: 'husband-caress', actionId: `${inside ? 'act_toggle' : 'act_caress'}:${key}`,
              caressKey: key, caressMode: on ? 'focus' : 'on', label: info.label || key,
              group: `손·입 애무 · ${group || '기본'}`, scope: 'you', active: on,
              available: Boolean(canUse && !sharedReason && !conflict),
              reason: sharedReason || (conflict ? 'dual_action_conflict' : canUse ? '' : 'unsupported_action'),
              detail: why || (!canUse ? '현재 자세·옷·상태에서 사용할 수 없어요.'
                : on ? '다시 누르면 1분 동안 집중합니다.' : inside ? '켜 두면 매분 함께합니다.' : '켜고 1분 애무합니다.'), effect: 'game' });
            if (on) rows.push({ id: `hl:caress-off:${key}`, provider: 'husband-caress', actionId: `act_off:${key}`,
              caressKey: key, caressMode: 'off', label: `${info.label || key} 끄기`, group: `손·입 애무 · ${group || '기본'}`,
              scope: 'you', active: false, available: !sharedReason && !sex.finish && !guarded && sex.__hs?.sleep?.stage !== 'tussle',
              reason: sharedReason || (guarded ? 'dual_action_conflict' : sex.finish || sex.__hs?.sleep?.stage === 'tussle' ? 'unsupported_action' : ''),
              detail: '켜진 애무를 끕니다.', effect: 'game' });
          }
        }
        return rows;
      } catch { return []; }
    }

    function positionControllerPromptSituation(state, imageConflict) {
      const scene = typeof latestScenePrompt === 'undefined' ? null : latestScenePrompt;
      if (scene) return (imageConflict === undefined ? positionControllerImageConflict(state) : imageConflict)
        !== 'image_context_unavailable' ? scene.situationId : '';
      if (positionControllerScope(state) !== 'you' || !state.primaryCharacterId
        || state.activeScene?.sex?.characterId != null && state.activeScene.sex.characterId !== state.primaryCharacterId) return '';
      const situationId = positionSituationId(activePortraitImageKey('', state));
      return basePositionSituationId(situationId) === `scene-${state.activeScene?.sex?.type}` ? situationId : '';
    }

    function positionControllerPromptCaressRows(state, sharedReason, imageConflict) {
      const situationId = positionControllerPromptSituation(state, imageConflict);
      const valid = !!situationId;
      const selections = valid ? currentPositionModuleSelections()[situationId] || [] : [];
      return availablePositionModules().filter(module => module.controller && module.controllerScope === 'you'
        && module.kind === 'other' && ['기본', '거칠게', '입·손가락', '시키기', '오른손', '왼손'].includes(module.controllerGroup)
        && module.controllerLabel !== '떼기' && (module.positivePrompt || module.negativePrompt)).map(module => {
        const active = selections.includes(module.id);
        const reason = sharedReason || (!valid ? 'image_context_unavailable' : '');
        return { id: module.id, provider: 'aip-prompt', label: module.controllerLabel || module.name || module.id,
          group: `이미지 · ${module.controllerGroup}`, scope: 'you', active, available: !reason, reason,
          detail: '이미지 프롬프트만 바꿉니다. 실제 게임 행동과 쾌감은 바뀌지 않아요.',
          effect: 'image_only' };
      });
    }

    function positionControllerList(allowWindow = false, display = null) {
      const state = display?.game || api.store.game();
      const snapshot = display?.state || positionControllerState(state, allowWindow);
      const patron = state?.activeScene?.patron;
      const sex = state?.activeScene?.sex;
      const scope = positionControllerScope(state);
      if (!scope) return [];
      const modules = availablePositionModules().filter(m => ['pose', 'position', 'action'].includes(m.kind)
        && (!m.controllerScope || m.controllerScope === scope));
      let sharedReason = snapshot.reason;
      if (!sharedReason && scope === 'patron') sharedReason = positionControllerImageConflict(state);
      const canDispatch = typeof api.store.dispatch === 'function'
        && typeof api.store.get === 'function' && typeof api.store.get()?.dispatch === 'function';
      if (!sharedReason && !canDispatch) sharedReason = 'provider_unavailable';
      if (scope === 'patron') {
        const planInfo = positionControllerPlan(patron);
        const expansion = globalThis.__waywardActExpansion;
        const pose = expansion?.pose;
        let expansionActive = false;
        try { expansionActive = expansion?.active?.() === true; } catch {}
        let now = null;
        try { now = typeof pose?.now === 'function' ? pose.now() : null; } catch {}
        if (!sharedReason && state.pendingEvent) sharedReason = 'pending_event';
        if (!sharedReason && typeof expansion?.pseqNow === 'function') {
          try { if (expansion.pseqNow(state)) sharedReason = 'sequence_in_progress'; }
          catch { sharedReason = 'provider_unavailable'; }
        }
        if (!sharedReason && planInfo.error) sharedReason = planInfo.error;
        if (!sharedReason && (planInfo.plan?.move || planInfo.plan?.repeat)) sharedReason = 'plan_conflict';
        // shortcut: block Patron Control until it exposes its private pending requests.
        if (!sharedReason && planInfo.provider) sharedReason = 'controller_unverifiable';
        if (!sharedReason && now?.asked) sharedReason = 'pending_request';
        const validPose = expansionActive && now && now.customerId === patron.customerId && Array.isArray(now.choices)
          && typeof pose?.ask === 'function';
        const rows = modules.map(module => {
          const label = module.controllerLabel || module.name || module.id;
          const isPose = module.controller && module.controllerScope === 'patron'
            && ['pose', 'position'].includes(module.kind);
          const available = Boolean(isPose && validPose && now.choices.includes(label) && !sharedReason);
          return { id: module.id, label, group: module.controllerGroup || module.kind, scope,
            active: Boolean(isPose && validPose && now.pose === label), available,
            reason: sharedReason || (isPose && !validPose ? 'provider_unavailable' : available ? '' : isPose ? 'unsupported_action' : 'image_only'),
            effect: isPose ? 'game' : 'image_only' };
        });
        return rows;
      }
      const dualScene = Boolean(patron && sex);
      const nativeReason = sharedReason || (state.pendingEvent?.type !== 'sex_scene' ? 'pending_event'
        : dualScene ? 'dual_action_conflict' : '');
      const seenNativeChoices = new Set();
      const nativeRows = (state.pendingEvent?.type === 'sex_scene' && Array.isArray(state.pendingEvent.choices)
        ? state.pendingEvent.choices : []).flatMap(choice => {
        const actionId = choice?.id;
        if (typeof actionId !== 'string' || !/^switch_to_[a-z0-9_]+$/.test(actionId)
          || seenNativeChoices.has(actionId)) return [];
        seenNativeChoices.add(actionId);
        const active = sex.type === actionId.slice('switch_to_'.length);
        const blocked = choice.disabled === true || choice.enabled === false;
        const reason = nativeReason || (blocked ? 'unsupported_action' : '');
        return [{ id: `native:${actionId}`, actionId, provider: 'game',
          label: typeof choice.label === 'string' && choice.label ? choice.label : actionId,
          group: '게임 행동', scope, active, available: !reason, reason,
          detail: typeof choice.description === 'string' ? choice.description : '', effect: 'game' }];
      });
      const owner = positionControllerHusbandOwner(state);
      const { hl, owned } = owner;
      if (!sharedReason && (owner.error || owned && typeof hl?.ui?.poseRoute !== 'function')) sharedReason = 'provider_unavailable';
      if (!sharedReason && state.pendingEvent?.type !== 'sex_scene') sharedReason = 'pending_event';
      const poseRows = modules.map(module => {
        const label = module.controllerLabel || module.name || module.id;
        if (!owned) {
          const isPose = module.controller && module.controllerScope === 'you'
            && Object.prototype.hasOwnProperty.call(positionControllerPoseTypes, label);
          const fits = isPose && positionControllerPoseFits(sex.type, label);
          const actionId = isPose && !fits ? `switch_to_${positionControllerPoseTypes[label]}` : '';
          const gameChoice = actionId && Array.isArray(state.pendingEvent?.choices)
            && state.pendingEvent.choices.find(choice => choice?.id === actionId
            && choice.disabled !== true && choice.enabled !== false);
          const dualConflict = dualScene && isPose && !fits;
          const available = Boolean(isPose && (fits || gameChoice) && !dualConflict && Number.isFinite(state.day) && Number.isFinite(sex.startedAtSlot)
            && !sex.finish && !sharedReason);
          const active = positionControllerPose(state)?.label === label;
          return { id: module.id, label, group: module.controllerGroup || module.kind, scope,
            provider: 'aip', actionId, change: fits ? 'pose' : 'action', active, available,
            reason: sharedReason || (dualConflict ? 'dual_action_conflict'
              : available ? '' : isPose ? 'unsupported_action' : 'image_only'),
            detail: isPose ? (fits ? '현재 행동 안의 자세를 기록합니다. 게임에 별도의 세부 자세 수용 판정은 없어요.'
              : '게임의 행동 전환을 먼저 진행하고 성공하면 자세를 기록합니다.') : '',
            effect: isPose ? 'game' : 'image_only' };
        }
        let route = null;
        if (owned && module.controller && module.controllerScope === 'you') {
          try { route = hl.ui.poseRoute(state, sex, label); } catch {}
        }
        const ui = hl?.ui;
        const isPose = module.controller && module.controllerScope === 'you' && !!ui?.POSE_TYPE?.[label];
        const inside = ui?.INSIDE?.has?.(sex.type);
        const targetInside = ui?.INSIDE?.has?.(ui?.POSE_TYPE?.[label]);
        const herLead = ui?.leadOf?.(sex) === 'her';
        const prepared = String(sex.__hs?.her?.prep ?? '').startsWith('ready:');
        const waitsForPreparation = targetInside && !inside && !herLead && !prepared && route?.mode !== 'unlock';
        const supported = route && ['fits', 'game', 'force', 'unlock'].includes(route.mode) && !waitsForPreparation;
        let active = false;
        try { active = isPose && hl.ui.poseOf(sex) === label; } catch {}
        const dualFits = dualScene && isPose && route?.mode === 'fits'
          && state.pendingEvent?.sleepActions == null && typeof structuredClone === 'function'
          && typeof api.has === 'function' && api.has('playerSexChoose');
        const dualConflict = dualScene && isPose && !dualFits;
        const available = Boolean(supported && !sharedReason && !dualConflict);
        return { id: module.id, label, group: module.controllerGroup || module.kind, scope, active,
          available, reason: sharedReason || (dualConflict ? 'dual_action_conflict'
            : available ? '' : isPose ? 'unsupported_action' : 'image_only'),
          detail: !sharedReason && isPose ? (sex.finish ? '관계 후 마무리 단계라 체위를 바꿀 수 없어요.'
            : waitsForPreparation ? '먼저 삽입 준비를 해 주세요.' : route?.why || '') : '',
          proposal: route?.mode === 'unlock', effect: isPose ? 'game' : 'image_only' };
      });
      const representative = positionControllerRepresentative[sex.type];
      const target = representative && poseRows.find(row => row.label === representative && row.effect === 'game');
      let sameAct = !owned && target?.change === 'pose';
      if (owned && target) {
        try { sameAct = hl.ui.poseRoute(state, sex, representative)?.mode === 'fits'; } catch { sameAct = false; }
      }
      const baseRow = { id: 'aip:representative-pose', provider: 'aip-representative', targetId: target?.id || '',
        label: representative ? `대표 체위 · ${representative}` : '대표 체위', group: '기본', scope,
        active: !!target?.active && sameAct, available: !!target?.available && sameAct,
        reason: target?.reason || (!sameAct ? sharedReason || 'unsupported_action' : ''),
        detail: target ? `현재 행동의 대표 자세로 바꿉니다. ${target.detail || ''}`
          : '현재 행동에 지정된 대표 체위가 없어요.', effect: 'game' };
      return [baseRow, ...nativeRows, ...(owned ? positionControllerCaressRows(state, hl, sharedReason, dualScene)
        : positionControllerPromptCaressRows(state, sharedReason, snapshot.reason ? undefined : snapshot.imageWarning)), ...poseRows];
    }

    function executePositionController(id, sceneToken, allowWindow = false) {
        if (positionControllerExecuting) return { ok: false, reason: 'busy' };
        if (typeof id !== 'string' || !id || typeof sceneToken !== 'string' || !sceneToken)
          return { ok: false, reason: 'invalid_action' };
        positionControllerExecuting = true;
        try {
          const snapshot = positionControllerState(api.store.game(), allowWindow);
          if (snapshot.reason) return { ok: false, reason: snapshot.reason };
          if (snapshot.sceneToken !== sceneToken) return { ok: false, reason: 'stale_scene' };
          let entry = positionControllerList(allowWindow).find(row => row.id === id);
          if (!entry) return { ok: false, reason: 'invalid_action' };
          if (!entry.available) return { ok: false, reason: entry.reason || 'image_only' };
          if (entry.active && !['husband-caress', 'aip-prompt'].includes(entry.provider)) return { ok: false, reason: 'already_selected' };
          if (entry.provider === 'aip-representative') {
            id = entry.targetId;
            const fresh = positionControllerList(allowWindow);
            const representative = fresh.find(row => row.id === 'aip:representative-pose');
            if (!representative?.available || representative.active || representative.targetId !== id)
              return { ok: false, reason: 'stale_scene' };
            entry = fresh.find(row => row.id === id);
            if (!entry?.available || entry.active) return { ok: false, reason: 'stale_scene' };
          }
          const state = api.store.game();
          if (positionControllerState(api.store.game(), allowWindow).sceneToken !== sceneToken) return { ok: false, reason: 'stale_scene' };
          if (entry.provider === 'aip-prompt') {
            const current = positionControllerList(allowWindow).find(row => row.id === id && row.provider === 'aip-prompt');
            if (!current?.available || current.active !== entry.active)
              return { ok: false, reason: 'stale_scene' };
            const situationId = positionControllerPromptSituation(state);
            if (!situationId || positionControllerState(api.store.game(), allowWindow).sceneToken !== sceneToken) return { ok: false, reason: 'stale_scene' };
            const selections = { ...currentPositionModuleSelections() }, prior = selections[situationId] || [];
            const selectedModule = availablePositionModules().find(module => module.id === id);
            const hand = selectedModule?.controllerScope === 'you' && selectedModule.kind === 'other'
              && ['오른손', '왼손'].includes(selectedModule.controllerGroup) ? selectedModule.controllerGroup : '';
            const sameHand = hand ? new Set(availablePositionModules().filter(module => module.controller
              && module.controllerScope === 'you' && module.kind === 'other' && module.controllerGroup === hand)
              .map(module => module.id)) : new Set();
            const next = entry.active ? prior.filter(value => value !== id)
              : [...prior.filter(value => !sameHand.has(value)), id];
            if (next.length) selections[situationId] = next; else delete selections[situationId];
            api.settings.set({ positionModuleSelections: selections });
            if ((currentPositionModuleSelections()[situationId] || []).includes(id) === entry.active)
              return { ok: false, reason: 'update_failed' };
            if (typeof refreshPortraitImage === 'function') refreshPortraitImage();
            return { ok: true, pending: false, reason: 'applied', effect: 'image_only' };
          }
          if (entry.provider === 'game') {
            const target = entry.actionId.slice('switch_to_'.length);
            if (state.pendingEvent?.type !== 'sex_scene'
              || !state.pendingEvent.choices?.some(choice => choice?.id === entry.actionId
                && choice.disabled !== true && choice.enabled !== false)) return { ok: false, reason: 'stale_scene' };
            try { api.store.dispatch({ type: 'scene_action', actionId: entry.actionId }); }
            catch { return { ok: false, pending: true, reason: 'transition_unconfirmed' }; }
            const after = api.store.game();
            if (after?.day === state.day && after?.primaryCharacterId === state.primaryCharacterId
              && after?.activeScene?.sex?.type === target)
              return { ok: true, pending: false, reason: 'applied' };
            return { ok: false, pending: false, reason: 'transition_unconfirmed' };
          }
          if (entry.provider === 'aip') {
            let expectedToken = sceneToken;
            let actionApplied = false;
            if (entry.actionId) {
              if (state.pendingEvent?.type !== 'sex_scene' || !Array.isArray(state.pendingEvent.choices)
                || !state.pendingEvent.choices.some(choice => choice?.id === entry.actionId
                  && choice.disabled !== true && choice.enabled !== false)) return { ok: false, reason: 'stale_scene' };
              try { api.store.dispatch({ type: 'scene_action', actionId: entry.actionId }); }
              catch { return { ok: false, pending: true, reason: 'transition_unconfirmed' }; }
              const next = api.store.game();
              const nextSex = next?.activeScene?.sex;
              const beforePatron = state.activeScene?.patron;
              const afterPatron = next?.activeScene?.patron;
              if (!nextSex || next.primaryCharacterId !== state.primaryCharacterId
                || nextSex.characterId != null && nextSex.characterId !== state.primaryCharacterId
                || nextSex.type !== entry.actionId.slice('switch_to_'.length))
                return { ok: false, pending: false, reason: 'transition_unconfirmed' };
              actionApplied = true;
              if (next.day !== state.day
                || !!beforePatron !== !!afterPatron
                || beforePatron && (beforePatron.customerId !== afterPatron.customerId
                  || beforePatron.characterId !== afterPatron.characterId || beforePatron.id !== afterPatron.id))
                return { ok: false, pending: false, actionApplied, reason: 'transition_unconfirmed' };
              const nextSnapshot = positionControllerState(next, allowWindow);
              if (nextSnapshot.reason || positionControllerHusbandOwner(next).owned)
                return { ok: false, pending: false, actionApplied, reason: 'transition_unconfirmed' };
              expectedToken = nextSnapshot.sceneToken;
            }
            let applied = false;
            api.store.update(current => {
              const sex = current?.activeScene?.sex;
              const owner = positionControllerHusbandOwner(current);
              if (!sex || owner.error || owner.owned || sex.finish || !Number.isFinite(current.day) || !Number.isFinite(sex.startedAtSlot)
                || current.pendingEvent?.type !== 'sex_scene' || positionControllerScope(current) !== 'you'
                || !current.primaryCharacterId || sex.characterId != null && sex.characterId !== current.primaryCharacterId
                || !positionControllerSceneIdentity(current, 'you')
                || !positionControllerPoseFits(sex.type, entry.label)
                || positionControllerState(current, allowWindow).reason || positionControllerState(current, allowWindow).sceneToken !== expectedToken) return current;
              applied = true;
              return { ...current, activeScene: { ...current.activeScene, sex: { ...sex,
                __aipPose: { version: 1, day: current.day, label: entry.label, actType: sex.type,
                  characterId: current.primaryCharacterId, startedAtSlot: sex.startedAtSlot } } } };
            });
            const pose = positionControllerPose(api.store.game());
            return applied && pose?.provider === 'aip' && pose.label === entry.label
              ? { ok: true, pending: false, reason: 'applied' }
              : { ok: false, pending: false, actionApplied, reason: 'transition_unconfirmed' };
          }
          if (entry.provider === 'husband-caress') {
            const before = positionControllerList(allowWindow).find(row => row.id === id);
            if (!before?.available || before.actionId !== entry.actionId || before.caressMode !== entry.caressMode)
              return { ok: false, reason: 'stale_scene' };
            const previousSlot = state.slot;
            if (state.activeScene?.patron && state.activeScene?.sex) {
              let applied = false;
              api.store.update(current => {
                const sex = current?.activeScene?.sex, owner = positionControllerHusbandOwner(current);
                const fresh = positionControllerList(allowWindow).find(row => row.id === id);
                if (!sex || !current.activeScene?.patron || owner.error || !owner.owned
                  || current.pendingEvent?.type !== 'sex_scene' || current.pendingEvent?.sleepActions != null
                  || positionControllerState(current, allowWindow).sceneToken !== sceneToken
                  || !fresh?.available || fresh.actionId !== entry.actionId || fresh.caressMode !== entry.caressMode
                  || entry.caressMode === 'focus' || !api.has('playerSexChoose') || typeof structuredClone !== 'function') return current;
                const protectedState = value => {
                  const { sex: _sex, ...otherScenes } = value.activeScene || {};
                  const { 'husband-life': _husband, ...otherMods } = value.mods || {};
                  const { [value.primaryCharacterId]: _wife, ...otherCharacters } = value.characters || {};
                  return JSON.stringify([otherScenes, value.customers, value.patronRecords, otherMods, value.modData, otherCharacters]);
                };
                try {
                  const protectedBefore = protectedState(current);
                  const changed = api.fn('playerSexChoose')(structuredClone(current), entry.actionId);
                  const afterSex = changed?.activeScene?.sex;
                  const keys = afterSex && owner.hl.ui.caressKeys(afterSex);
                  if (!changed || protectedState(changed) !== protectedBefore || changed.day !== current.day
                    || changed.slot !== current.slot || changed.primaryCharacterId !== current.primaryCharacterId
                    || changed.pendingEvent?.type !== 'sex_scene' || changed.pendingEvent?.sleepActions != null
                    || afterSex?.type !== sex.type || afterSex?.startedAtSlot !== sex.startedAtSlot
                    || !owner.hl.owns(changed) || !Array.isArray(keys)
                    || keys.includes(entry.caressKey) !== (entry.caressMode === 'on')) return current;
                  applied = true;
                  return changed;
                } catch { return current; }
              });
              return applied ? { ok: true, pending: false, reason: 'applied' }
                : { ok: false, pending: false, reason: 'transition_unconfirmed' };
            }
            try { api.store.dispatch({ type: 'scene_action', actionId: entry.actionId }); }
            catch { return { ok: false, pending: true, reason: 'transition_unconfirmed' }; }
            const after = api.store.game(), afterSex = after?.activeScene?.sex;
            const owner = positionControllerHusbandOwner(after);
            if (!owner.error && owner.owned && afterSex && typeof owner.hl.ui?.caressKeys === 'function') {
              const keys = owner.hl.ui.caressKeys(afterSex);
              if (Array.isArray(keys) && (entry.caressMode === 'focus' ? after.slot > previousSlot
                : keys.includes(entry.caressKey) === (entry.caressMode === 'on')))
                return { ok: true, pending: false, reason: 'applied' };
            }
            return { ok: false, pending: false, reason: 'transition_unconfirmed' };
          }
          if (entry.scope === 'patron') {
            const scene = state.activeScene.patron;
            const info = positionControllerPlan(scene);
            if (info.error || info.plan?.move || info.plan?.repeat) return { ok: false, reason: info.error || 'plan_conflict' };
            const pose = globalThis.__waywardActExpansion?.pose;
            const now = pose?.now?.();
            if (now?.asked) return { ok: false, reason: 'pending_request' };
            if (!now || now.customerId !== scene.customerId || !now.choices?.includes(entry.label)
              || typeof pose.ask !== 'function') return { ok: false, reason: 'request_rejected' };
            let accepted;
            try { accepted = pose.ask(entry.label); }
            catch { return { ok: false, pending: true, reason: 'transition_unconfirmed' }; }
            if (accepted !== true) return { ok: false, reason: 'request_rejected' };
            try { api.store.dispatch({ type: 'wait', minutes: 1 }); }
            catch { return { ok: false, pending: true, reason: 'dispatch_failed_pending' }; }
            let after;
            try { after = pose.now(); }
            catch { return { ok: false, pending: true, reason: 'transition_unconfirmed' }; }
            if (after?.customerId === scene.customerId && after.pose === entry.label)
              return { ok: true, pending: false, reason: 'applied' };
            if (after?.customerId === scene.customerId && after.asked === entry.label)
              return { ok: true, pending: true, reason: 'pending' };
            return { ok: false, pending: false, reason: 'transition_unconfirmed' };
          }
          if (state.activeScene?.patron && state.activeScene?.sex) {
            let applied = false;
            api.store.update(current => {
              const sex = current?.activeScene?.sex, owner = positionControllerHusbandOwner(current);
              if (!sex || !current.activeScene?.patron || owner.error || !owner.owned
                || current.pendingEvent?.type !== 'sex_scene' || current.pendingEvent?.sleepActions != null
                || positionControllerState(current, allowWindow).reason || positionControllerState(current, allowWindow).sceneToken !== sceneToken
                || owner.hl.ui.poseRoute(current, sex, entry.label)?.mode !== 'fits'
                || !api.has('playerSexChoose') || typeof structuredClone !== 'function') return current;
              const protectedState = value => {
                const { sex: _sex, ...otherScenes } = value.activeScene || {};
                const { 'husband-life': _husband, ...otherMods } = value.mods || {};
                const { [value.primaryCharacterId]: _wife, ...otherCharacters } = value.characters || {};
                return JSON.stringify([otherScenes, value.customers, value.patronRecords, otherMods, value.modData, otherCharacters]);
              };
              try {
                const before = protectedState(current);
                const changed = api.fn('playerSexChoose')(structuredClone(current), `act_pose:${entry.label}`);
                if (!changed || protectedState(changed) !== before || changed.day !== current.day
                  || changed.slot !== current.slot || changed.primaryCharacterId !== current.primaryCharacterId
                  || changed.pendingEvent?.type !== 'sex_scene' || changed.pendingEvent?.sleepActions != null
                  || changed.activeScene?.sex?.type !== sex.type
                  || changed.activeScene?.sex?.startedAtSlot !== sex.startedAtSlot
                  || !owner.hl.owns(changed) || owner.hl.ui.poseOf(changed.activeScene.sex) !== entry.label) return current;
                applied = true;
                return changed;
              } catch { return current; }
            });
            return applied && positionControllerPose(api.store.game())?.label === entry.label
              ? { ok: true, pending: false, reason: 'applied' }
              : { ok: false, pending: false, reason: 'transition_unconfirmed' };
          }
          try { api.store.dispatch({ type: 'scene_action', actionId: `act_pose:${entry.label}` }); }
          catch { return { ok: false, pending: true, reason: 'transition_unconfirmed' }; }
          const afterState = api.store.game();
          const hl = globalThis.__waywardHusbandLife;
          if (afterState?.activeScene?.sex && hl?.owns?.(afterState) && hl.ui.poseOf(afterState.activeScene.sex) === entry.label)
            return { ok: true, pending: false, reason: 'applied' };
          if (entry.proposal) return { ok: true, pending: false, reason: 'proposal_sent' };
          return { ok: false, pending: false, reason: 'transition_unconfirmed' };
        } catch { return { ok: false, reason: 'update_failed' }; }
        finally { positionControllerExecuting = false; }
    }
    const positionControllerApi = Object.freeze({
      getState: () => positionControllerState(),
      setEnabled(value) {
        if (typeof value !== 'boolean') return { ok: false, reason: 'invalid_enabled' };
        api.settings.set({ positionControllerEnabled: value });
        if (!value) { positionAutoPending = null; positionAutoPatronCancel(); }
        if (typeof syncPositionControllerButton === 'function') syncPositionControllerButton();
        return { ok: true, reason: '' };
      },
      list: () => positionControllerList(),
      getPose: () => positionControllerPose(),
      execute: (id, sceneToken) => executePositionController(id, sceneToken),
    });
    // Window access does not change the saved in-game panel setting or public API contract.
    const positionControllerWindowApi = Object.freeze({
      getState: () => positionControllerState(api.store.game(), true),
      list: () => positionControllerList(true),
      execute: (id, sceneToken) => executePositionController(id, sceneToken, true),
    });

    function positionControllerHasExplicitChoice(state) {
      const sex = state?.activeScene?.sex, owner = positionControllerHusbandOwner(state);
      if (!sex || owner.error || sex.__aipPose || sex.__actPose || sex.__hs?.pose) return true;
      try {
        if (owner.owned && (typeof owner.hl?.ui?.poseOf !== 'function' || owner.hl.ui.poseOf(sex))) return true;
        const bridge = globalThis.__waywardScenePose?.now?.();
        if (bridge?.source === 'husband' && bridge.scene === sex.type
          && (bridge.pose || bridge.poseId || bridge.poseTags)) return true;
        if (!owner.owned && globalThis.__waywardActExpansion?.compat?.husPoseOf?.(sex)) return true;
        const base = `scene-${sex.type}`;
        const portraitId = positionSituationId(activePortraitImageKey('', state));
        const current = basePositionSituationId(portraitId) === base ? portraitId : '';
        const selections = currentPositionModuleSelections();
        const layouts = currentPositionModuleGroupLayouts();
        const savedOverrides = typeof currentPositionOverrides === 'function' ? currentPositionOverrides() : {};
        const savedStatePrompts = typeof currentPositionStatePrompts === 'function' ? currentPositionStatePrompts() : {};
        const ids = current ? [current] : [...new Set([base, ...Object.keys({ ...selections, ...layouts,
          ...savedOverrides, ...savedStatePrompts }).filter(id => basePositionSituationId(id) === base)])];
        const modules = availablePositionModules();
        return ids.some(id => {
          const override = positionOverride(id);
          if (override?.manual || override?.pendingPreviousKey || positionStateOnly(currentPositionStatePrompt(id))) return true;
          const layout = layouts[id];
          if (layout && Object.keys(layout).length) return true;
          return (selections[id] || []).some(selected => modules.some(module => module.id === selected
            && ['pose', 'position', 'action'].includes(module.kind) && module.controllerScope !== 'patron'));
        });
      } catch { return true; }
    }

    // Observe only newly entered player scenes. Merely enabling the panel or loading an existing scene
    // must not apply an action. A prelude can reach a supported act later in the same scene.
    let positionAutoObserved = Boolean(api.store.game());
    let positionAutoIdentity = positionControllerSceneIdentity(api.store.game(), 'you');
    let positionAutoPreviousAct = api.store.game()?.activeScene?.sex?.type || '';
    let positionAutoPending = null, positionAutoQueued = false;
    api.store.subscribe?.(() => {
      const state = api.store.game();
      if (!state) { positionAutoObserved = false; positionAutoIdentity = null; positionAutoPreviousAct = ''; positionAutoPending = null; return; }
      const identity = positionControllerSceneIdentity(state, 'you');
      const actType = state.activeScene?.sex?.type || '';
      if (!positionAutoObserved) { positionAutoObserved = true; positionAutoIdentity = identity; positionAutoPreviousAct = actType; return; }
      if (identity !== positionAutoIdentity) {
        const previousIdentity = positionAutoIdentity, previousPending = positionAutoPending;
        positionAutoIdentity = identity;
        if (identity && previousIdentity && previousPending && !positionControllerRepresentative[positionAutoPreviousAct]
          && previousPending.day === state.day && previousPending.characterId === state.primaryCharacterId) {
          positionAutoPending = { ...previousPending, identity };
        } else positionAutoPending = identity && !previousIdentity && positionControllerEnabled() && positionMode() === 'modules'
          ? { identity, day: state.day, characterId: state.primaryCharacterId } : null;
      }
      positionAutoPreviousAct = actType;
      if (!identity || !positionAutoPending || positionAutoQueued) return;
      const pending = positionAutoPending;
      positionAutoQueued = true;
      queueMicrotask(() => {
        positionAutoQueued = false;
        if (positionAutoPending !== pending) return;
        const current = api.store.game(), sex = current?.activeScene?.sex;
        if (positionControllerSceneIdentity(current, 'you') !== pending.identity) { positionAutoPending = null; return; }
        const snapshot = positionControllerState(current);
        if (!snapshot.enabled || positionMode() !== 'modules') { positionAutoPending = null; return; }
        if (!sex || sex.finish) { positionAutoPending = null; return; }
        if (!positionControllerRepresentative[sex.type]) return;
        if (snapshot.reason || current.pendingEvent?.sleepActions != null) { positionAutoPending = null; return; }
        // A just-created action can briefly precede its event; do not retry a locked action indefinitely.
        if (pending.readyDeadline == null) pending.readyDeadline = Date.now() + 2000;
        if (Date.now() >= pending.readyDeadline) { positionAutoPending = null; return; }
        if (current.pendingEvent?.type !== 'sex_scene') return;
        if (positionControllerHasExplicitChoice(current)) { positionAutoPending = null; return; }
        const row = positionControllerList().find(item => item.id === 'aip:representative-pose');
        if (!row?.available || row.active) { positionAutoPending = null; return; }
        // Mark before dispatch: subscriptions from the owning game/mod must never dispatch a second time.
        positionAutoPending = null;
        executePositionController(row.id, snapshot.sceneToken);
      });
    });

    const positionPatronRepresentative = Object.freeze({ front: '정상위', back: '후배위', ride: '기승위',
      mouth: '무릎 구강성교', hand: '여성 손 자극', fingers: '앉아서 남성 손 자극', lick: '커닐링구스' });
    let positionAutoPatronObserved = Boolean(api.store.game());
    let positionAutoPatronIdentity = positionControllerSceneIdentity(api.store.game(), 'patron');
    let positionAutoPatronPending = null, positionAutoPatronQueued = false;
    function positionAutoPatronCancel() {
      if (positionAutoPatronPending?.timer != null) clearTimeout(positionAutoPatronPending.timer);
      positionAutoPatronPending = null;
    }
    function positionAutoPatronCheck() {
      if (!positionAutoPatronPending || positionAutoPatronQueued) return;
      const pending = positionAutoPatronPending;
      positionAutoPatronQueued = true;
      queueMicrotask(() => {
        positionAutoPatronQueued = false;
        if (positionAutoPatronPending !== pending) return;
        const state = api.store.game(), patron = state?.activeScene?.patron;
        if (!state || positionControllerSceneIdentity(state, 'patron') !== pending.identity
          || !positionControllerState(state).enabled || positionMode() !== 'modules'
          || state.activeScene?.sex || patron?.afterglow) { positionAutoPatronCancel(); return; }
        const expansion = globalThis.__waywardActExpansion, pose = expansion?.pose;
        let now;
        try {
          if (globalThis.__waywardPatronControl || expansion?.active?.() !== true || typeof pose?.now !== 'function') {
            positionAutoPatronCancel(); return;
          }
          now = pose.now();
        } catch { positionAutoPatronCancel(); return; }
        if (!now || now.customerId !== patron.customerId) return;
        if (now.pose || now.asked || now.group === 'rub') { positionAutoPatronCancel(); return; }
        const representative = positionPatronRepresentative[now.group];
        if (!representative || !Array.isArray(now.choices) || !now.choices.includes(representative)) return;
        const snapshot = positionControllerState(state);
        if (snapshot.reason || positionControllerScope(state) !== 'patron') return;
        const conflict = positionControllerImageConflict(state);
        if (conflict === 'image_context_unavailable') {
          // Store notifications do not consume retries or create additional timers.
          const remaining = pending.deadline - Date.now();
          if (remaining <= 0) positionAutoPatronCancel();
          else if (pending.timer == null) pending.timer = setTimeout(() => {
            pending.timer = null;
            if (positionAutoPatronPending === pending) positionAutoPatronCheck();
          }, Math.min(250, remaining));
          return;
        }
        if (conflict) { positionAutoPatronCancel(); return; }
        const row = positionControllerList().find(item => item.scope === 'patron'
          && item.label === representative && item.effect === 'game');
        if (!row?.available || row.active) {
          if (row?.reason !== 'pending_event') positionAutoPatronCancel();
          return;
        }
        // pose.ask reserves a request and wait advances one game minute; never repeat a failed dispatch.
        positionAutoPatronCancel();
        executePositionController(row.id, snapshot.sceneToken);
      });
    }
    api.store.subscribe?.(() => {
      const state = api.store.game();
      if (!state) { positionAutoPatronObserved = false; positionAutoPatronIdentity = null; positionAutoPatronCancel(); return; }
      const identity = positionControllerSceneIdentity(state, 'patron');
      if (!positionAutoPatronObserved) { positionAutoPatronObserved = true; positionAutoPatronIdentity = identity; return; }
      if (identity !== positionAutoPatronIdentity) {
        const previousIdentity = positionAutoPatronIdentity;
        positionAutoPatronIdentity = identity;
        positionAutoPatronCancel();
        positionAutoPatronPending = identity && !previousIdentity && !state.activeScene?.sex
          && positionControllerEnabled() && positionMode() === 'modules'
          ? { identity, deadline: Date.now() + 2000, timer: null } : null;
      }
      if (positionAutoPatronPending && (state.activeScene?.sex || !positionControllerEnabled() || positionMode() !== 'modules'))
        positionAutoPatronCancel();
      positionAutoPatronCheck();
    });
