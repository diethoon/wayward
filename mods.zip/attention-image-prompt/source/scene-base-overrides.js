    let sceneBaseOverrides = {};
    let sceneBaseOverrideCount = 0;
    let sceneBaseOverridePreviewing = false;
    let lastSceneBaseOverrideStatus = null;
    let sceneBaseEditor = { id: '', open: false, draft: null, candidate: '', error: '' };
    let sceneBaseNativeCurrent = null;

    function readCurrentNativeScenePart(situationId, key) {
      const state = api.store?.game?.(), wife = state?.characters?.[state.primaryCharacterId];
      const names = ['portraitSceneContext', 'portraitMoodContext', 'portraitFinishContext', 'wifeLocation', 'imageRoom', 'playerSexScene', 'patronScene'];
      if (!wife || !key || positionSituationId(key) !== situationId || !names.every(name => api.has(name))) return null;
      try {
        const dispatcher = api.fn('imagePrompt'), original = dispatcher?.__wmlOriginal;
        // Only use a verified game implementation, never an unknown mod wrapper.
        if (typeof original !== 'function' || !nativeInlinePoseCandidates().sleeping) return null;
        const scene = api.fn('portraitSceneContext')(state);
        if (!scene || typeof scene !== 'object') return null;
        const character = { ...wife, sceneOverride: scene.scene, sceneVariant: scene.sceneVariant };
        const result = original(character, api.fn('imageRoom')(api.fn('wifeLocation')(state)),
          api.fn('portraitMoodContext')(state), api.fn('playerSexScene')(state)?.ticksElapsed,
          api.fn('patronScene')(state), api.fn('portraitFinishContext')(state));
        if (!result || baseSituationImageKey(result.key) !== baseSituationImageKey(key)
          || positionSituationId(result.key) !== situationId || !Array.isArray(result.parts)) return null;
        const type = situationId.split('|')[0].split('-')[0];
        const labels = type === 'scene' ? ['장면', 'Scene'] : type === 'look' ? ['초점', 'Focus']
          : type === 'task' ? ['작업', 'Action', '자세', 'Pose'] : [];
        const parts = result.parts.filter(part => labels.includes(part?.label) && typeof part.tags === 'string' && part.tags.trim());
        if (parts.length !== 1) return null;
        return { id: situationId, key: baseSituationImageKey(key), characterId: state.primaryCharacterId,
          wife, day: state.day, slot: state.slot, sex: state.activeScene?.sex, patron: state.activeScene?.patron,
          label: parts[0].label, text: parts[0].tags };
      } catch { return null; }
    }

    function currentNativeScenePart(situationId, key) {
      const current = sceneBaseNativeCurrent, state = api.store?.game?.();
      return current && key && current.id === situationId && current.characterId === state?.primaryCharacterId
        && current.wife === state?.characters?.[state?.primaryCharacterId] && current.day === state.day && current.slot === state.slot
        && current.sex === state.activeScene?.sex && current.patron === state.activeScene?.patron
        && current.key === baseSituationImageKey(key) ? current : null;
    }

    function normalizeSceneBaseOverrides(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).slice(0, 1000).flatMap(([id, entry]) =>
        id.length <= 160 && /^(?:scene|task|look)-./.test(id) && !id.includes('__')
        && entry && typeof entry === 'object' && typeof entry.positivePrompt === 'string'
        && entry.positivePrompt.length <= 12000
          ? [[id, { positivePrompt: entry.positivePrompt.trim(),
            ...(entry.nativePart && typeof entry.nativePart.label === 'string'
              && ['장면', 'Scene', '작업', 'Action', '자세', 'Pose', '초점', 'Focus'].includes(entry.nativePart.label)
              && typeof entry.nativePart.text === 'string' && entry.nativePart.text.trim() && entry.nativePart.text.length <= 12000
              ? { nativePart: { label: entry.nativePart.label, text: entry.nativePart.text } } : {}) }]] : []));
    }

    function reloadSceneBaseOverrides(notify = true) {
      sceneBaseOverrides = normalizeSceneBaseOverrides(api.settings.get({ sceneBaseOverrides: {} }).sceneBaseOverrides);
      sceneBaseOverrideCount = Object.keys(sceneBaseOverrides).length;
      lastSceneBaseOverrideStatus = null;
      if (notify) notifyExternalPromptChange();
    }

    function sceneBaseOverrideSource(situationId) {
      if (Object.hasOwn(sceneBaseOverrides, situationId)) return { id: situationId, entry: sceneBaseOverrides[situationId] };
      if (typeof situationId !== 'string' || situationId.includes('|sleep-')) return null;
      const base = situationId.split('|')[0];
      return base !== situationId && Object.hasOwn(sceneBaseOverrides, base) ? { id: base, entry: sceneBaseOverrides[base] } : null;
    }

    function sceneBaseOverride(situationId) {
      return sceneBaseOverrideSource(situationId)?.entry || null;
    }

    function saveSceneBaseOverride(situationId, positivePrompt, nativePart) {
      const next = normalizeSceneBaseOverrides({ [situationId]: { positivePrompt, nativePart } });
      if (!Object.hasOwn(next, situationId) || (!Object.hasOwn(sceneBaseOverrides, situationId)
        && sceneBaseOverrideCount >= 1000)) return false;
      if (!Object.hasOwn(sceneBaseOverrides, situationId)) sceneBaseOverrideCount++;
      sceneBaseOverrides = { ...sceneBaseOverrides, [situationId]: next[situationId] };
      api.settings.set({ sceneBaseOverrides });
      lastSceneBaseOverrideStatus = null;
      notifyExternalPromptChange();
      return true;
    }

    function resetSceneBaseOverride(situationId) {
      if (!Object.hasOwn(sceneBaseOverrides, situationId)) return false;
      sceneBaseOverrides = { ...sceneBaseOverrides };
      delete sceneBaseOverrides[situationId];
      sceneBaseOverrideCount--;
      api.settings.set({ sceneBaseOverrides });
      lastSceneBaseOverrideStatus = null;
      notifyExternalPromptChange();
      return true;
    }

    function sceneBaseOverrideFingerprint(situationId) {
      const entry = sceneBaseOverride(situationId);
      if (entry) return shortHash(JSON.stringify([situationId, entry.positivePrompt, entry.nativePart || null]));
      return sceneCandidateFingerprint(situationId);
    }

    function sceneBaseParts(situationId) {
      const base = situationId.split('|')[0], type = base.split('-')[0];
      if (base === 'task-sleeping' || base === 'task-passed_out') return { sources: ['pose'], labels: ['자세', 'Pose'] };
      if (type === 'scene') return { sources: ['scene', 'bed'], labels: ['장면', 'Scene'] };
      if (type === 'task') return { sources: ['task', 'bedroom'], labels: ['작업', 'Action'] };
      if (type === 'look') return { sources: ['look'], labels: ['초점', 'Focus'] };
      return { sources: [], labels: [] };
    }

    function matchSceneBaseCandidate(situationId, partText, key) {
      if (typeof partText !== 'string' || !partText.trim()) return null;
      const current = currentNativeScenePart(situationId, key);
      if (current?.text === partText) return { source: 'observed', label: '현재 게임 원본', text: partText };
      const { sources } = sceneBaseParts(situationId);
      const candidates = [...new Map(nativeScenePromptCandidates(situationId)
        .filter(candidate => sources.includes(candidate.source) && typeof candidate.text === 'string')
        .map(candidate => [candidate.text, candidate])).values()];
      const exact = candidates.find(candidate => candidate.text === partText);
      if (exact) return exact;
      const part = splitFinalPrompt(partText);
      if (!part) return null;
      const wanted = part.tokens.map(token => token.trim()).filter(Boolean);
      if (!wanted.length) return null;
      const matches = candidates.filter(candidate => {
        const parsed = splitFinalPrompt(candidate.text);
        if (!parsed) return false;
        let index = 0;
        for (const token of parsed.tokens) if (token.trim() === wanted[index]) index++;
        return index === wanted.length;
      });
      return matches.length === 1 ? matches[0] : null;
    }

    function evaluateSceneBaseOverride(result, candidateEntry = null) {
      const situationId = positionSituationId(result?.key);
      const entry = sceneBaseOverride(situationId) || candidateEntry;
      const outcome = (reason, value = result) => ({ situationId, reason, result: value });
      if (!entry) return outcome('no_override');
      if (!result || typeof result.prompt !== 'string' || !Array.isArray(result.parts)) return outcome('missing_parts');
      const current = currentNativeScenePart(situationId, result.key);
      let savedNative = null;
      try {
        if (entry.nativePart && typeof api.fn('imagePrompt')?.__wmlOriginal === 'function'
          && nativeInlinePoseCandidates().sleeping) savedNative = entry.nativePart;
      } catch { /* A wrapped or unknown implementation is not trusted. */ }
      const { labels: baseLabels } = sceneBaseParts(situationId);
      const labels = [...new Set([...baseLabels, ...(current ? [current.label] : []), ...(savedNative ? [savedNative.label] : [])])];
      const matches = result.parts.filter(part => labels.includes(part?.label) && typeof part.tags === 'string');
      if (matches.length !== 1) return outcome(matches.length ? 'ambiguous_part' : 'missing_part');
      const part = matches[0];
      if (!(savedNative?.label === part.label && savedNative.text === part.tags)
        && !matchSceneBaseCandidate(situationId, part.tags, result.key))
        return outcome('unknown_source');
      const full = splitFinalPrompt(result.prompt), selected = splitFinalPrompt(part.tags);
      const replacement = splitFinalPrompt(entry.positivePrompt);
      if (!full || !selected || !replacement || full.separators.some(separator => separator !== ','))
        return outcome('ambiguous_prompt');
      const chosen = selected.tokens.map(token => token.trim()).filter(Boolean);
      if (!chosen.length || new Set(chosen.map(tag => promptTagIdentity(tag).spaced)).size !== chosen.length)
        return outcome('ambiguous_prompt');
      const otherTokens = [];
      for (const other of result.parts) {
        if (other === part || !other?.tags) continue;
        if (typeof other.tags !== 'string') return outcome('ambiguous_prompt');
        const parsed = splitFinalPrompt(other.tags);
        if (!parsed) return outcome('ambiguous_prompt');
        otherTokens.push(...parsed.tokens.map(token => promptTagIdentity(token).spaced));
      }
      const protectedTags = new Set(otherTokens);
      const fullTokens = full.tokens.map(token => token.trim());
      const removed = new Set();
      const positions = [];
      for (const tag of chosen) {
        const identity = promptTagIdentity(tag).spaced;
        const found = fullTokens.flatMap((token, index) => promptTagIdentity(token).spaced === identity ? [index] : []);
        if (!found.length || found.length > 1) return outcome('ambiguous_prompt');
        positions.push(found[0]);
        if (!protectedTags.has(identity)) {
          if (fullTokens[found[0]] !== tag) return outcome('ambiguous_prompt');
          removed.add(found[0]);
        }
      }
      const insertAt = Math.min(...positions);
      const output = [];
      for (let index = 0; index < fullTokens.length; index++) {
        if (index === insertAt) output.push(...replacement.tokens.map(token => token.trim()).filter(Boolean));
        if (!removed.has(index) && fullTokens[index]) output.push(fullTokens[index]);
      }
      const prompt = output.join(', ');
      return outcome('applied', { ...result, prompt,
        parts: result.parts.map(value => value === part ? { ...value, tags: entry.positivePrompt } : value),
        genParams: promptGenParams(prompt) });
    }

    function installSceneBaseOverrideHook() {
      // A high-priority around hook is inside ordinary WML around hooks, before other mods adjust the result.
      api.hook('imagePrompt', { priority: Number.MAX_SAFE_INTEGER, around(next, ...args) {
        const result = next(...args);
        if ((!sceneBaseOverrideCount && !sceneCandidatePoolCount) || (imagePlanDepth && !sceneBaseOverridePreviewing)) return result;
        const evaluated = evaluateSceneBaseOverride(result, sceneCandidateEntryForResult(result, args[0]));
        if (!promptPreviewing && !sceneBaseOverridePreviewing && evaluated.reason !== 'no_override') {
          const state = api.store?.game?.();
          const characterId = state && args[0] ? characterIdOf(state, args[0]) : '';
          lastSceneBaseOverrideStatus = { situationId: evaluated.situationId, reason: evaluated.reason,
            imageKey: result?.key || '', characterId };
        }
        return !sceneBaseOverride(positionSituationId(result?.key)) && evaluated.reason !== 'applied'
          ? appendSelectedSceneCandidate(result) : evaluated.result;
      } });
    }

    function renderSceneBaseOverride(h, win, situationId, currentKey) {
      if (!situationId) return [];
      if (sceneBaseEditor.id !== situationId)
        sceneBaseEditor = { id: situationId, open: false, draft: null, candidate: '', error: '' };
      const source = sceneBaseOverrideSource(situationId);
      const saved = source?.entry || null;
      const own = Object.hasOwn(sceneBaseOverrides, situationId);
      const inherited = Boolean(source && source.id !== situationId);
      const fallsBack = situationId.includes('|') && !situationId.includes('|sleep-')
        && Object.hasOwn(sceneBaseOverrides, situationId.split('|')[0]);
      const { sources, labels } = sceneBaseParts(situationId);
      const currentNative = currentNativeScenePart(situationId, currentKey);
      const candidates = nativeScenePromptCandidates(situationId).filter(candidate => sources.includes(candidate.source));
      if (currentNative && !candidates.some(candidate => candidate.text === currentNative.text))
        candidates.unshift({ source: 'observed', label: '현재 게임 원본', text: currentNative.text });
      const state = api.store?.game?.();
      const isCurrent = Boolean(currentKey && positionSituationId(currentKey) === situationId);
      const sameCurrent = isCurrent && state?.primaryCharacterId && latestScenePrompt?.characterId === state.primaryCharacterId
        && baseSituationImageKey(currentKey) === baseSituationImageKey(latestScenePrompt?.result?.key || '');
      const observedLabels = currentNative ? [...new Set([...labels, currentNative.label])] : labels;
      const observedParts = sameCurrent ? latestScenePrompt.result.parts?.filter(part => observedLabels.includes(part?.label)) : [];
      const observedCandidate = observedParts?.length === 1 ? matchSceneBaseCandidate(situationId, observedParts[0].tags, currentKey) : null;
      const observed = observedCandidate ? candidates.findIndex(candidate => candidate.text === observedCandidate.text) : -1;
      const status = isCurrent && saved && state?.primaryCharacterId === lastSceneBaseOverrideStatus?.characterId
        && lastSceneBaseOverrideStatus?.situationId === situationId
        && baseSituationImageKey(currentKey) === baseSituationImageKey(lastSceneBaseOverrideStatus?.imageKey || '')
        ? lastSceneBaseOverrideStatus.reason : '';
      const statusText = {
        applied: '현재 초상화의 원본 부분에 변경 문구를 적용했어요.',
        missing_parts: '현재 원본 프롬프트의 구성 정보를 확인할 수 없어 적용하지 않았어요.',
        missing_part: '현재 원본 프롬프트에 해당 장면 부분이 없어 적용하지 않았어요.',
        ambiguous_part: '장면 부분이 여러 개라 안전하게 구분할 수 없어 적용하지 않았어요.',
        unknown_source: '현재 장면 문구를 게임 기본 후보 하나와 안전하게 연결할 수 없어 적용하지 않았어요.',
        ambiguous_prompt: '현재 프롬프트의 태그 출처를 안전하게 구분할 수 없어 적용하지 않았어요.',
      };
      const begin = () => {
        sceneBaseNativeCurrent = readCurrentNativeScenePart(situationId, currentKey);
        sceneBaseEditor = { id: situationId, open: true, draft: saved?.positivePrompt ?? null,
          candidate: '', error: '' };
        if (!saved && observed >= 0) {
          sceneBaseEditor.candidate = String(observed);
          sceneBaseEditor.draft = observedParts[0].tags;
        }
        win.refresh();
      };
      const save = () => {
        const chosen = /^\d+$/.test(sceneBaseEditor.candidate) ? candidates[Number(sceneBaseEditor.candidate)] : null;
        const nativePart = chosen?.source === 'observed' && currentNative?.text === chosen.text
          ? { label: currentNative.label, text: currentNative.text }
          : chosen ? undefined : saved?.nativePart;
        if (sceneBaseEditor.draft === null) sceneBaseEditor.error = '먼저 기본 후보를 선택해 주세요.';
        else if (!splitFinalPrompt(sceneBaseEditor.draft)) sceneBaseEditor.error = '괄호와 따옴표를 확인해 주세요.';
        else if (!saveSceneBaseOverride(situationId, sceneBaseEditor.draft, nativePart)) sceneBaseEditor.error = '장면 설정을 저장할 수 없어요.';
        else {
          sceneBaseEditor = { id: situationId, open: false, draft: null, candidate: '', error: '' };
          if (isCurrent) refreshPortraitImage();
        }
        win.refresh();
      };
      return [
        h('h4', { style: 'margin:14px 0 4px;' }, '게임 기본 장면 문구 변경'),
        h('p', { class: 'wml-muted wml-small' }, '확인된 게임 기본 문구만 바꾸며 다른 문구와 Negative는 유지해요. 출처가 불명확하면 적용하지 않아요. 기본 장면 설정은 수면을 제외한 세부 장면에 상속돼요.'),
        h('p', { class: 'wml-muted wml-small' }, '다른 모드가 기본 태그를 제거한 경우에는 게임 기본 보정과 구분하지 못할 수 있어요.'),
        saved ? h('p', { class: 'wml-small', 'data-scene-base-saved': '' }, saved.positivePrompt
          ? h('code', {}, saved.positivePrompt) : '기본 장면 문구를 비우도록 저장됨') : null,
        inherited ? h('p', { class: 'wml-note', 'data-scene-base-inherited': '' }, `기본 장면 ${source.id}의 설정을 적용해요. 여기서 저장하면 선택한 세부 장면만 따로 바꿔요.`) : null,
        saved ? h('p', { class: 'wml-note', 'data-scene-base-status': '' }, statusText[status] || '현재 초상화에서 적용 여부를 아직 확인하지 못했어요.') : null,
        !sceneBaseEditor.open ? api.ui.button('이 장면 프롬프트 변경', begin, { disabled: !saved && !candidates.length && !isCurrent }) : null,
        !saved && !candidates.length ? h('p', { class: 'wml-note' }, isCurrent ? '편집을 열어 현재 게임 원본을 확인해요. 원본을 구분하지 못하면 변경할 수 없어요.' : '확인된 기본 후보가 없어요. 현재 장면으로 열면 게임 원본을 확인할 수 있어요.') : null,
        currentNative ? h('p', { class: 'wml-note' }, '현재 인물과 이미지 키에서 확인한 원본이에요. 동적 원본은 같은 문구일 때 적용되며 달라지면 다시 확인해야 해요.') : null,
        sceneBaseEditor.open ? h('div', { 'data-scene-base-editor': '', style: 'display:grid;gap:8px;margin:8px 0;' },
          candidates.length ? h('label', {}, '기본 후보로 시작', h('select', { 'data-scene-base-candidate': '', value: sceneBaseEditor.candidate,
            onchange: event => {
              const value = event.currentTarget.value;
              const selected = /^\d+$/.test(value) ? candidates[Number(value)] : null;
              if (selected) { sceneBaseEditor.candidate = value; sceneBaseEditor.draft = selected.text; sceneBaseEditor.error = ''; }
              win.refresh();
            } }, h('option', { value: '', selected: !sceneBaseEditor.candidate }, '기본 후보 선택'),
            ...candidates.map((candidate, index) => h('option', { value: String(index), selected: sceneBaseEditor.candidate === String(index) },
              candidate.label)))) : null,
          sceneBaseEditor.draft === null ? h('p', { class: 'wml-note' }, '현재 원본을 확인하지 못했어요. 사용할 기본 후보를 직접 선택해 주세요.') :
            h('label', { class: 'aip-prompt-field' }, h('strong', {}, '변경할 장면 Positive'), h('textarea', {
              'data-scene-base-draft': '', value: sceneBaseEditor.draft, rows: 4, maxLength: 12000, spellcheck: false,
              style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:80px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
              onfocus: () => { activeTagTarget = null; },
              oninput: event => { sceneBaseEditor.draft = event.currentTarget.value; sceneBaseEditor.error = ''; updatePromptTagPreview(event, h, win); },
            }), promptTagPreview(h, sceneBaseEditor.draft, win), h('span', { class: 'wml-muted wml-small' }, '비워서 저장하면 이 장면의 기본 문구를 제거해요.')),
          sceneBaseEditor.error ? h('p', { class: 'wml-note', role: 'status' }, sceneBaseEditor.error) : null,
          h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;' },
            api.ui.button('변경 저장', save, { disabled: sceneBaseEditor.draft === null }),
            api.ui.button('취소', () => { sceneBaseEditor = { id: situationId, open: false, draft: null, candidate: '', error: '' }; win.refresh(); }),
            own ? api.ui.button(fallsBack ? '세부 설정 삭제' : '원본 복원', () => {
              resetSceneBaseOverride(situationId);
              sceneBaseEditor = { id: situationId, open: false, draft: null, candidate: '', error: '' };
              if (isCurrent) refreshPortraitImage();
              win.refresh();
            }) : null)) : null,
      ];
    }

    reloadSceneBaseOverrides(false);
