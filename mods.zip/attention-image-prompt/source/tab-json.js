    // A tab owns only these sections. Imports are validated through the full importer,
    // then narrowed again so its default-filled result cannot affect unrelated settings.
    function tabJsonSections(tab) {
      if (tab.externalMenu) return ['externalPromptData', 'externalPromptPresets'];
      const sections = {
        'image-keys': ['shortImageKeys'],
        'game-default': ['gameDefaultPrompts', 'globalPromptExclusionsPositive', 'globalPromptExclusionsNegative',
          'generationWeightEnabled', 'generationWeightPercent', 'generationWeightStepsPercent', 'generationWeightCfgPercent', 'generationWeightLoraPercent'],
        character: ['wives', 'characterPrompt'], 'outfit-prompts': ['outfitPrompts', 'customOutfits'],
        'situation-presets': ['situationPresets', 'situationPresetAssignments'],
        'scene-prompts': ['positionStatePrompts', 'sceneBaseOverrides', 'sceneCandidatePools', 'sceneStatePromptOverrides',
          'stateEditorGlobalChanges', 'cameraSceneSettings', 'cameraImageMetadata', 'cameraPresetRevision'],
        'button-prompts': ['buttonPromptRules'],
        positions: ['positionPresetPrompts', 'positionGroupPrompts', 'positionTargetNegativePrompts', 'positionMode',
          'guestAppearance', 'positionModules', 'positionModulePrompts', 'controllerButtonCatalog', 'positionDanbooruTags',
          'positionModuleSelections', 'positionModuleGroupLayouts', 'positionModulePoseAssignments', 'positionRules', 'positionRuleDefaults', 'autoPositionPresets'],
        'climax-prompts': ['positionModules', 'positionModulePrompts'],
        dialogue: ['dialogueRules'], 'prompt-mods': ['promptModRules'],
      };
      if (tab.fields) return ['prompts', 'negativePrompts', 'outfitStates', 'featurePrompts',
        ...(tab.id === 'erostat' ? ['erostatPromptPresets', 'erostatPromptBundles'] : []),
        ...(tab.id === 'h-status' ? ['fluidDecay', 'residueGenerationProvider', 'hStatusGenerationModes', 'hStatusImg2Img', 'residuePrompts', 'residuePartSources'] : [])];
      return sections[tab.id] || [];
    }

    function tabJsonNarrow(data, tab) {
      const result = {};
      for (const section of tabJsonSections(tab)) if (Object.hasOwn(data, section)) result[section] = data[section];
      if (tab.fields) {
        const keys = new Set(tab.fields.map(field => field.key));
        for (const section of ['prompts', 'negativePrompts', 'outfitStates']) if (result[section])
          result[section] = Object.fromEntries(Object.entries(result[section]).filter(([key]) => keys.has(key)));
        if (result.featurePrompts) result.featurePrompts = Object.hasOwn(result.featurePrompts, tab.id)
          ? { [tab.id]: result.featurePrompts[tab.id] } : {};
      }
      if (tab.externalMenu) {
        if (Array.isArray(result.externalPromptData)) result.externalPromptData = result.externalPromptData.filter(row => row?.owner === tab.externalMenu.id);
        if (Array.isArray(result.externalPromptPresets)) result.externalPromptPresets = result.externalPromptPresets.filter(row => row?.modId === tab.externalMenu.id);
      }
      if (['positions', 'climax-prompts'].includes(tab.id)) {
        const belongs = id => /^climax-\d+$/.test(id) === (tab.id === 'climax-prompts');
        if (Array.isArray(result.positionModules)) result.positionModules = result.positionModules.filter(row => belongs(row?.id));
        for (const section of ['positionModulePrompts']) if (result[section])
          result[section] = Object.fromEntries(Object.entries(result[section]).filter(([key]) => belongs(key)));
      }
      return result;
    }

    function exportTabJson(tab) {
      const data = promptSettingsSnapshot(Object.keys(exportSections));
      const config = activeSituationConfig();
      if (tab.fields || tab.id === 'dialogue') for (const key of ['prompts', 'negativePrompts', 'outfitStates', 'dialogueRules']) data[key] = config[key];
      return { format: 'wayward-state-image-prompts', version: 23, scope: 'tab', tabId: tab.id,
        ...((tab.fields || tab.id === 'dialogue') ? { presetId: config.id } : {}), ...tabJsonNarrow(data, tab) };
    }

    function importTabJson(parsed, tab) {
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw Error('JSON 설정 객체가 필요합니다.');
      if (parsed.scope === 'tab' && parsed.tabId !== tab.id) throw Error('다른 탭의 JSON입니다. 해당 탭에서 불러오세요.');
      if (parsed.format && parsed.format !== 'wayward-state-image-prompts') throw Error('지원하지 않는 JSON 형식입니다.');
      const data = tabJsonNarrow(parsed, tab);
      if (!Object.keys(data).length) throw Error('이 탭에 해당하는 설정이 없습니다.');
      const arraySections = new Set(['wives', 'customOutfits', 'situationPresets', 'buttonPromptRules', 'positionModules',
        'controllerButtonCatalog', 'positionDanbooruTags', 'promptModRules', 'dialogueRules', 'erostatPromptPresets', 'erostatPromptBundles', 'externalPromptData', 'externalPromptPresets']);
      const booleanSections = new Set(['shortImageKeys', 'generationWeightEnabled', 'guestAppearance', 'autoPositionPresets', 'hStatusImg2Img']);
      const stringSections = new Set(['positionMode', 'residueGenerationProvider', 'globalPromptExclusionsPositive', 'globalPromptExclusionsNegative']);
      const numericSections = new Set(['cameraPresetRevision', 'generationWeightPercent', 'generationWeightStepsPercent', 'generationWeightCfgPercent', 'generationWeightLoraPercent']);
      for (const [key, value] of Object.entries(data)) {
        if (arraySections.has(key) && !Array.isArray(value)) throw Error(key + ' 목록이 올바르지 않습니다.');
        if (value === null && !['generationWeightStepsPercent', 'generationWeightCfgPercent', 'generationWeightLoraPercent'].includes(key)) throw Error(key + ' 값이 올바르지 않습니다.');
        if (booleanSections.has(key) && typeof value !== 'boolean') throw Error(key + ' 값은 체크 상태여야 합니다.');
        if (stringSections.has(key) && typeof value !== 'string') throw Error(key + ' 값은 문자열이어야 합니다.');
        if (numericSections.has(key) && value !== null && !Number.isFinite(value)) throw Error(key + ' 값은 숫자여야 합니다.');
        if (![arraySections, booleanSections, stringSections, numericSections].some(set => set.has(key))
          && (!value || typeof value !== 'object' || Array.isArray(value))) throw Error(key + ' 설정 객체가 필요합니다.');
      }
      for (const value of Object.values(data.featurePrompts || {})) if (typeof value !== 'boolean') throw Error('전체 적용 상태는 체크 상태여야 합니다.');
      for (const key of ['prompts', 'negativePrompts']) for (const value of Object.values(data[key] || {}))
        if (typeof value !== 'string') throw Error('프롬프트는 문자열이어야 합니다.');
      const normalized = importPromptSettings(JSON.stringify({ format: 'wayward-state-image-prompts', version: parsed.version || 23, ...data }));
      const patch = {};
      for (const key of Object.keys(data)) if (Object.hasOwn(normalized, key)) patch[key] = normalized[key];
      for (const key of ['generationWeightStepsPercent', 'generationWeightCfgPercent', 'generationWeightLoraPercent'])
        if (Object.hasOwn(data, key) && data[key] === null) patch[key] = null;
      // Preset-scoped rows update the preset being edited, never the preset ID from another PC.
      if (tab.fields || tab.id === 'dialogue') {
        const config = activeSituationConfig(), rows = {};
        const raw = api.settings.get(), originalConfig = config.id === LEGACY_SITUATION_PRESET_ID
          ? raw : (raw.situationPresets || []).find(preset => preset.id === config.id) || {};
        for (const section of ['prompts', 'negativePrompts', 'outfitStates', 'dialogueRules']) if (Object.hasOwn(data, section)) {
          rows[section] = section === 'dialogueRules' ? patch[section] : { ...originalConfig[section],
            ...Object.fromEntries(Object.keys(data[section]).map(key => [key, patch[section][key]])) };
          delete patch[section];
        }
        if (config.id === LEGACY_SITUATION_PRESET_ID) Object.assign(patch, rows);
        else patch.situationPresets = (api.settings.get().situationPresets || []).map(preset => preset.id === config.id ? { ...preset, ...rows } : preset);
        if (data.featurePrompts && Object.keys(data.featurePrompts).length) patch.featurePrompts = { ...raw.featurePrompts, ...data.featurePrompts };
        else delete patch.featurePrompts;
      }
      const saved = api.settings.get();
      if (tab.externalMenu) {
        if (patch.externalPromptData) patch.externalPromptData = [...currentExternalPromptData().filter(row => row.owner !== tab.externalMenu.id), ...patch.externalPromptData];
        if (patch.externalPromptPresets) patch.externalPromptPresets = [...currentExternalPromptPresets().filter(row => row.modId !== tab.externalMenu.id), ...patch.externalPromptPresets];
      }
      if (['positions', 'climax-prompts'].includes(tab.id)) {
        const belongs = id => /^climax-\d+$/.test(id) === (tab.id === 'climax-prompts');
        if (patch.positionModules) patch.positionModules = [...(saved.positionModules || []).filter(row => !belongs(row.id)), ...patch.positionModules];
        for (const section of ['positionModulePrompts']) if (patch[section])
          patch[section] = { ...Object.fromEntries(Object.entries(saved[section] || {}).filter(([key]) => !belongs(key))), ...patch[section] };
      }
      api.settings.set(patch);
      reloadButtonPromptSettings(); reloadPromptModRules(); reloadGlobalPromptExclusions(); reloadSceneBaseOverrides();
      reloadSceneCandidatePools(); reloadCameraSettings(); reloadSceneStatePromptOverrides(); reloadStateEditorGlobalChanges();
      syncCustomOutfits(); legacyDetailImageKeys.clear(); publishCurrentWifePromptProfile();
    }

    function renderTabJson(h, win, tab) {
      if (!tabJsonSections(tab).length) return null;
      const button = (label, action, click) => {
        const node = api.ui.button(label, click);
        node.setAttribute('data-aip-tab-json-' + action, tab.id);
        return node;
      };
      const input = h('input', { type: 'file', accept: '.json,application/json', hidden: true, 'data-aip-tab-json-input': tab.id,
        onchange: async event => {
          const node = event.currentTarget, file = node.files?.[0], preset = activeSituationPresetId;
          if (!file) return;
          try {
            const parsed = JSON.parse(await file.text());
            if (activeSettingsTab !== tab.id || activeSituationPresetId !== preset) throw Error('편집 대상이 바뀌었습니다. 해당 탭에서 다시 불러오세요.');
            importTabJson(parsed, tab); settingsMessage = tab.title + ' 탭 설정을 불러왔습니다.';
          } catch (error) { settingsMessage = '탭 JSON 불러오기 실패: ' + error.message; }
          node.value = ''; win.refresh();
        } });
      return h('section', { 'data-aip-tab-json': tab.id, 'aria-label': tab.title + ' JSON 저장·불러오기',
        style: 'display:grid;gap:8px;padding:10px;border:1px solid #a16207;border-radius:7px;background:#29210f;margin-bottom:12px;' },
        h('strong', {}, tab.title + ' · 이 탭 설정'),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;' },
        button(tab.title + ' JSON 저장', 'save', async () => {
          try { await api.saveFile('wayward-prompts-' + tab.id.replace(/[^a-zA-Z0-9_-]/g, '-') + '.json', JSON.stringify(exportTabJson(tab), null, 2), 'application/json');
            settingsMessage = tab.title + ' 탭 설정을 저장했습니다.';
          } catch (error) { settingsMessage = '탭 JSON 저장 실패: ' + error.message; }
          win.refresh();
        }), button(tab.title + ' JSON 불러오기', 'load', () => input.click())),
        h('small', {}, '현재 탭의 설정만 저장·불러옵니다. 전체 설정은 아래 JSON 백업·복원을 사용하세요.'), input);
    }
