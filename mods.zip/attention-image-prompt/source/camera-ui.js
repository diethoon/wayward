    let cameraWindow = null;
    let cameraButton = null;
    let cameraUiScene = '';
    let cameraUiCharacter = '';
    let cameraUiAxes = {};
    let cameraUiShot = '';
    let cameraUiMulti = false;
    let cameraUiMessage = '';
    let cameraUiPreview = null;
    let cameraUiPreviewSerial = 0;
    let cameraUiEditorOpen = false;
    let cameraUiMoreOpen = false;
    const cameraAxisOrder = ['direction', 'viewpoint', 'elevation', 'framing', 'tilt', 'lens'];

    function cameraUiCurrent() {
      const state = api.store.game();
      const key = state?.primaryCharacterId ? activePortraitImageKey('', state) : '';
      const id = positionSituationId(key);
      return { state, key, id, characterId: state?.primaryCharacterId || '' };
    }

    function cameraUiParseAxes(id) {
      const parts = typeof id === 'string' ? id.split('-') : [];
      if (parts.shift() !== 'camera' || parts.length !== cameraAxisOrder.length) return {};
      return Object.fromEntries(cameraAxisOrder.map((axis, index) => [axis, parts[index] === 'none' ? '' : parts[index]]));
    }

    function cameraUiShotFromAxes(catalog, axes = cameraUiAxes) {
      const items = cameraAxisOrder.flatMap(axis => {
        const item = catalog.groups.find(group => group.id === axis)?.items?.find(entry => entry.id === axes[axis]);
        return item ? [item] : [];
      });
      if (!items.length || items.length !== cameraAxisOrder.filter(axis => axes[axis]).length) return null;
      return { id: `camera-${cameraAxisOrder.map(axis => axes[axis] || 'none').join('-')}`, name: items.map(item => item.name || item.label || item.id).join(' · '),
        positive: deduplicateFinalPrompt(items.map(item => item.positive || '').filter(Boolean).join(', ')),
        negative: deduplicateFinalPrompt(items.map(item => item.negative || '').filter(Boolean).join(', ')) };
    }

    function cameraUiSavedShotIds(id) {
      const saved = cameraSceneSettings[id] || (!id.includes('|sleep-') ? cameraSceneSettings[id.split('|')[0]] : null);
      return new Set((saved?.shots || []).map(shot => shot.id));
    }

    function cameraUiChange(expected, patch) {
      const current = cameraUiCurrent();
      if (!expected.id || current.id !== expected.id || current.characterId !== expected.characterId) {
        cameraUiMessage = '장면이나 인물이 바뀌었어요. 현재 장면을 다시 확인해 주세요.';
        cameraWindow?.refresh();
        return false;
      }
      const snapshot = cameraController.get(current.id);
      if (!snapshot) { cameraUiMessage = '현재 장면을 확인할 수 없어요.'; cameraWindow?.refresh(); return false; }
      const result = cameraController.apply(current.id, { shots: snapshot.shots, selected: snapshot.selected,
        removeTags: snapshot.removeTags, ...patch });
      if (!result?.ok) { cameraUiMessage = '구도를 적용하지 못했어요. 현재 장면을 다시 확인해 주세요.'; cameraWindow?.refresh(); return false; }
      cameraUiPreviewSerial += 1;
      cameraUiPreview = null;
      cameraUiMessage = '';
      refreshPortraitImage();
      cameraWindow?.refresh();
      return true;
    }

    function cameraUiSave(expected) {
      const current = cameraUiCurrent();
      if (!expected.id || current.id !== expected.id || current.characterId !== expected.characterId) {
        cameraUiMessage = '장면이나 인물이 바뀌었어요. 현재 장면을 다시 확인해 주세요.'; cameraWindow?.refresh(); return;
      }
      const snapshot = cameraController.get(current.id);
      const saved = cameraUiSavedShotIds(current.id);
      const shots = snapshot?.shots.filter(shot => saved.has(shot.id) || snapshot.selected.includes(shot.id) || shot.id === cameraUiShot);
      const result = snapshot && cameraController.set(current.id, { shots, selected: snapshot.selected, removeTags: snapshot.removeTags });
      cameraUiMessage = result?.ok ? '이 장면의 구도를 저장했어요.' : '구도를 저장하지 못했어요. 다시 시도해 주세요.';
      cameraWindow?.refresh();
    }

    function cameraUiChooseAxis(expected, axis, value, catalog) {
      if (value && cameraUiAxes[axis] === value) value = '';
      cameraUiAxes = { ...cameraUiAxes, [axis]: value };
      let adjusted = false;
      if (axis === 'viewpoint' && ((value === 'pov_above' && cameraUiAxes.elevation === 'below')
        || (value === 'pov_below' && ['above', 'high_up'].includes(cameraUiAxes.elevation)))) {
        cameraUiAxes.elevation = ''; adjusted = true;
      } else if (axis === 'elevation' && ((value === 'below' && cameraUiAxes.viewpoint === 'pov_above')
        || (['above', 'high_up'].includes(value) && cameraUiAxes.viewpoint === 'pov_below'))) {
        cameraUiAxes.viewpoint = 'pov'; adjusted = true;
      }
      const shot = cameraUiShotFromAxes(catalog);
      if (!shot) {
        cameraUiShot = '';
        if (cameraUiMulti) cameraWindow?.refresh();
        else cameraUiChange(expected, { selected: [] });
        return;
      }
      const snapshot = cameraController.get(expected.id);
      if (!snapshot) return;
      const saved = cameraUiSavedShotIds(expected.id);
      const retained = snapshot.shots.filter(item => saved.has(item.id) || (cameraUiMulti && snapshot.selected.includes(item.id)));
      const existing = snapshot.shots.find(item => item.id === shot.id);
      if (!retained.some(item => item.id === shot.id) && retained.length >= 64) {
        cameraUiMessage = '구도는 장면마다 최대 64개까지 저장할 수 있어요. 사용하지 않는 구도를 삭제해 주세요.';
        cameraWindow?.refresh(); return;
      }
      const shots = retained.some(item => item.id === shot.id) ? retained : [...retained, existing || shot];
      cameraUiShot = shot.id;
      const selected = cameraUiMulti ? snapshot.selected : [shot.id];
      if (cameraUiChange(expected, { shots, selected }) && adjusted) {
        cameraUiMessage = '서로 반대인 높이 설정을 기본값으로 바꿨어요.';
        cameraWindow?.refresh();
      }
    }

    function cameraUiToggleShot(expected, id) {
      const snapshot = cameraController.get(expected.id);
      if (!snapshot) return;
      if (cameraUiMulti && (!cameraUiSavedShotIds(expected.id).has(id) || !snapshot.shots.some(shot => shot.id === id))) return;
      const deselect = !cameraUiMulti && snapshot.selected.includes(id);
      cameraUiShot = deselect ? '' : id;
      cameraUiAxes = deselect ? {} : cameraUiParseAxes(id);
      const selected = cameraUiMulti
        ? (snapshot.selected.includes(id) ? snapshot.selected.filter(item => item !== id) : [...snapshot.selected, id])
        : (deselect ? [] : [id]);
      cameraUiChange(expected, { selected });
    }

    function cameraUiDeleteShot(expected, id) {
      const snapshot = cameraController.get(expected.id);
      if (!snapshot?.shots.some(shot => shot.id === id)) return;
      const selected = snapshot.selected.filter(item => item !== id);
      if (!cameraUiChange(expected, { shots: snapshot.shots.filter(shot => shot.id !== id), selected })) return;
      if (cameraUiShot === id) {
        cameraUiShot = selected[0] || '';
        cameraUiAxes = cameraUiParseAxes(cameraUiShot);
      }
      cameraUiMessage = '구도를 삭제했어요. 구도 저장을 눌러 변경을 보관하세요.';
      cameraWindow?.refresh();
    }

    async function cameraUiGeneratePreview(expected) {
      if (!cameraWindow || cameraUiPreview?.loading) return;
      const now = cameraUiCurrent(), wife = now.state?.characters?.[now.characterId];
      if (!now.id || now.id !== expected.id || now.characterId !== expected.characterId || !wife || !api.has('imageGenerate')) {
        cameraUiMessage = '현재 장면과 이미지 생성 기능을 확인해 주세요.'; cameraWindow?.refresh(); return;
      }
      const serial = ++cameraUiPreviewSerial;
      const signature = JSON.stringify(cameraController.get(now.id));
      let request, previewShot = '';
      try {
        request = scenePreviewRequest('current', now.id, true, now.state, wife);
        previewShot = typeof request.__aipCameraPreviewShotId === 'string' ? request.__aipCameraPreviewShotId : '';
        request.imageKey = `aip_camera_preview_${shortHash(JSON.stringify([now.id, request.prompt, request.negativePrompt, request.checkpoint]))}`;
        request.debug = { source: 'attention-image-prompt-camera-preview' };
      } catch (error) {
        cameraUiMessage = `미리보기를 만들 수 없어요: ${diagnosticText(error)}`; cameraWindow?.refresh(); return;
      }
      cameraUiPreview = { loading: true, request, shotId: previewShot }; cameraUiMessage = ''; cameraWindow.refresh();
      try {
        const result = await api.fn('imageGenerate')(request);
        if (!result?.url || result.imageMatchingMissing) throw new Error('이미지 서버에서 미리보기 이미지를 만들지 못했어요.');
        const latest = cameraUiCurrent();
        if (serial !== cameraUiPreviewSerial || !cameraWindow || latest.id !== now.id || latest.characterId !== now.characterId
          || latest.key !== now.key || JSON.stringify(cameraController.get(now.id)) !== signature) return;
        cameraUiPreview = { url: String(result.url), request, shotId: previewShot };
      } catch (error) {
        if (serial === cameraUiPreviewSerial && cameraWindow) cameraUiPreview = { error: diagnosticText(error) };
      } finally { if (serial === cameraUiPreviewSerial) cameraWindow?.refresh(); }
    }

    function renderCameraWindow(body, win) {
      const h = api.ui.h, current = cameraUiCurrent();
      if (cameraUiScene !== current.id || cameraUiCharacter !== current.characterId) {
        cameraUiScene = current.id; cameraUiCharacter = current.characterId; cameraUiPreview = null;
        cameraUiPreviewSerial += 1; cameraUiAxes = {}; cameraUiShot = ''; cameraUiMessage = '';
        const state = current.id ? cameraController.get(current.id) : null;
        if (state?.selected?.length) { cameraUiShot = state.selected[0]; cameraUiAxes = cameraUiParseAxes(cameraUiShot); }
        cameraUiMulti = (state?.selected?.length || 0) > 1;
      }
      const snapshot = current.id ? cameraController.get(current.id) : null;
      const catalog = cameraController.list();
      const groups = Array.isArray(catalog?.groups) ? catalog.groups : [];
      const shots = snapshot?.shots || [], selected = snapshot?.selected || [];
      const savedIds = current.id ? cameraUiSavedShotIds(current.id) : new Set();
      const savedShots = shots.filter(shot => savedIds.has(shot.id));
      const wife = current.state?.characters?.[current.characterId];
      const title = wife?.name || wife?.shortname || current.characterId;
      const activeShot = shots.find(item => item.id === cameraUiShot) || shots.find(item => selected.includes(item.id));
      const defaultShot = activeShot && (groups.flatMap(group => group.items || []).find(item => item.id === activeShot.id)
        || cameraUiShotFromAxes(catalog, cameraUiParseAxes(activeShot.id)));
      const buttonStyle = active => `min-height:32px;padding:4px 7px;font-size:12px;white-space:normal;${active ? 'border-color:#f59e0b;color:#fde68a;background:#78350f;' : ''}`;
      const axisButton = (axis, item, label = '') => {
        const active = (cameraUiAxes[axis] || '') === item.id;
        return h('button', { type: 'button', class: 'wml-btn', 'data-aip-camera-axis': axis,
          'data-aip-camera-angle': item.id, 'aria-pressed': active ? 'true' : 'false',
          disabled: !snapshot, style: buttonStyle(active),
          onclick: () => cameraUiChooseAxis(current, axis, item.id, catalog) }, label || item.name || item.label || item.id);
      };
      const direction = groups.find(group => group.id === 'direction')?.items || [];
      const directionItem = id => direction.find(item => item.id === id);
      const mapButton = (id, label) => directionItem(id) ? axisButton('direction', directionItem(id), label) : h('span', {});
      const showGroup = group => h('section', { style: 'display:grid;gap:5px;' },
        h('strong', { style: 'font-size:12px;' }, group.label),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:5px;' },
          axisButton(group.id, { id: '', name: '기본' }),
          ...(group.items || []).map(item => axisButton(group.id, item))));
      const saveShotField = (field, value) => {
        const shot = shots.find(item => item.id === activeShot?.id);
        if (!shot) return;
        cameraUiChange(current, { shots: shots.map(item => item.id === shot.id ? { ...item, [field]: value } : item) });
      };
      const validatePromptInput = event => {
        const valid = !!splitFinalPrompt(event.currentTarget.value);
        const hint = event.currentTarget.parentElement?.querySelector?.('[data-aip-camera-field-error]');
        if (hint) hint.textContent = valid ? '' : '괄호와 따옴표를 확인해 주세요. 완성된 문구만 저장돼요.';
        return valid;
      };
      const resolvedName = shots.find(item => item.id === snapshot?.resolvedShotId)?.name;
      const status = snapshot?.active ? selected.length > 1
        ? `랜덤 후보 ${selected.length}개 · ${resolvedName ? `현재 그림: ${resolvedName}` : '새 이미지 생성 시 결정'}`
        : `적용 중: ${shots.find(item => item.id === selected[0])?.name || '선택한 구도'}` : '원본 구도';
      body.replaceChildren(h('div', { 'data-aip-camera-window': '', style: 'display:grid;gap:8px;min-width:0;' },
        h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;' },
          h('strong', { 'data-aip-camera-scene': '' }, current.id ? `${title} · ${positionSituationLabel(current.id)}` : '현재 장면을 확인할 수 없어요'),
          h('span', { class: 'wml-small', role: 'status' }, `${status}${snapshot?.dirty ? ' · 저장 안 됨' : ''}`)),
        h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '선택은 즉시 적용돼요. 목록과 장면 설정은 구도 저장을 눌러야 보관돼요.'),
        ...((snapshot?.warnings || []).map(warning => h('p', { class: 'wml-note', role: 'status' }, warning))),
        h('div', { style: 'display:flex;gap:6px;flex-wrap:wrap;' },
          h('button', { type: 'button', class: 'wml-btn', 'data-aip-camera-mode': 'single', 'aria-pressed': cameraUiMulti ? 'false' : 'true',
            style: buttonStyle(!cameraUiMulti), onclick: () => { cameraUiMulti = false; if (selected.length > 1) cameraUiChange(current, { selected: [cameraUiShot || selected[0]] }); else win.refresh(); } }, '한 구도'),
          h('button', { type: 'button', class: 'wml-btn', 'data-aip-camera-mode': 'random', 'aria-pressed': cameraUiMulti ? 'true' : 'false',
            style: buttonStyle(cameraUiMulti), onclick: () => {
              cameraUiMulti = true;
              const savedSelection = selected.filter(id => savedIds.has(id));
              if (savedSelection.length !== selected.length) cameraUiChange(current, { selected: savedSelection });
              else win.refresh();
            } }, '랜덤 후보 선택'),
          h('button', { type: 'button', class: 'wml-btn', 'data-aip-camera-save': '', disabled: !snapshot?.dirty,
            style: buttonStyle(!!snapshot?.dirty), onclick: () => cameraUiSave(current) }, '구도 저장'),
          h('button', { type: 'button', class: 'wml-btn', 'data-aip-camera-reset': '', disabled: !snapshot?.active,
            style: buttonStyle(false), onclick: () => {
              const latest = cameraUiCurrent();
              if (latest.id !== current.id || latest.characterId !== current.characterId) { cameraUiMessage = '장면이 바뀌었어요.'; win.refresh(); return; }
              cameraUiAxes = {}; cameraUiShot = ''; cameraUiMulti = false;
              cameraUiChange(current, { selected: [] });
            } }, '원본 구도로 복원')),
        h('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,210px),1fr));gap:12px;align-items:start;' },
        h('section', { style: 'display:grid;gap:6px;' }, h('strong', {}, '카메라 위치'),
          h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '좌우는 같은 구도로 적용돼요.'),
          h('div', { 'data-aip-camera-map': '', style: 'display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:5px;max-width:330px;text-align:center;align-items:stretch;' },
            h('span', {}), mapButton('rear', '뒤'), h('span', {}),
            mapButton('side', '측면'), h('span', { style: 'display:grid;place-items:center;min-height:44px;border:1px solid #78716c;border-radius:6px;font-size:12px;font-weight:700;' }, '인물'), mapButton('side', '측면'),
            mapButton('three_quarter', '사선'), mapButton('front', '앞'), mapButton('three_quarter', '사선'))),
        h('div', { style: 'display:grid;gap:8px;min-width:0;' },
          ...groups.filter(group => !['direction', 'tilt', 'lens'].includes(group.id)).map(showGroup),
          h('details', { open: cameraUiMoreOpen, ontoggle: event => { cameraUiMoreOpen = event.currentTarget.open; } },
            h('summary', {}, '화면 기울기 · 렌즈'), ...groups.filter(group => ['tilt', 'lens'].includes(group.id)).map(showGroup)))),
        (savedShots.length || cameraUiMulti) ? h('section', { style: 'display:grid;gap:6px;' },
          h('strong', {}, cameraUiMulti ? '랜덤으로 사용할 구도' : '저장한 구도'),
          h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, cameraUiMulti
            ? '저장된 구도에서 2개 이상 선택하면 새 이미지마다 하나를 고릅니다.' : '선택한 구도가 현재 장면에 적용돼요.'),
          cameraUiMulti && !savedShots.length ? h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '저장된 구도가 없어요. 구도를 만든 뒤 구도 저장을 눌러 주세요.') : null,
          cameraUiMulti && cameraUiShot && !savedIds.has(cameraUiShot) ? h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '현재 구도는 저장한 뒤 랜덤 후보로 선택할 수 있어요.') : null,
          cameraUiMulti && selected.some(id => !savedIds.has(id)) ? h('p', { class: 'wml-note', role: 'status' }, '기존 임시 후보가 있어요. 구도 저장으로 보관하거나 랜덤 후보 선택을 다시 눌러 제외하세요.') : null,
          h('div', { style: 'display:flex;flex-wrap:wrap;align-content:flex-start;gap:5px;max-height:110px;overflow-y:auto;' }, ...savedShots.map(shot =>
            h('div', { style: 'display:inline-flex;gap:2px;max-width:100%;' },
              h('button', { type: 'button', class: 'wml-btn', 'data-aip-camera-shot': shot.id,
                'aria-pressed': selected.includes(shot.id) ? 'true' : 'false', style: buttonStyle(selected.includes(shot.id)),
                onclick: () => cameraUiToggleShot(current, shot.id),
              }, shot.name || shot.id),
              h('button', { type: 'button', class: 'wml-btn', 'data-aip-camera-delete-saved': shot.id,
                'aria-label': `${shot.name || shot.id} 구도 삭제`, title: `${shot.name || shot.id} 구도 삭제`,
                style: buttonStyle(false), onclick: () => cameraUiDeleteShot(current, shot.id) }, '삭제'))))) : null,
        activeShot ? h('details', { open: cameraUiEditorOpen, ontoggle: event => { cameraUiEditorOpen = event.currentTarget.open; } },
          h('summary', {}, '선택 구도 프롬프트 수정'), h('section', { style: 'display:grid;gap:7px;padding-top:6px;' },
          h('label', { class: 'aip-prompt-field' }, h('span', {}, '구도 이름'), h('input', {
            type: 'text', value: activeShot.name || '', maxLength: 120, 'data-aip-camera-shot-name': '',
            style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
            onchange: event => saveShotField('name', event.currentTarget.value),
          })),
          ...[['positive', 'Positive · 적용할 태그'], ['negative', 'Negative · 피할 태그']].map(([field, label]) =>
            h('label', { class: 'aip-prompt-field' }, h('strong', {}, label), h('textarea', {
              rows: 2, value: activeShot[field], maxLength: 4000, spellcheck: false, 'data-aip-camera-prompt': field,
              style: 'width:100%;box-sizing:border-box;resize:vertical;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
              oninput: event => { validatePromptInput(event); updatePromptTagPreview(event, h, win); },
              onchange: event => { if (validatePromptInput(event)) saveShotField(field, event.currentTarget.value); },
            }), promptTagPreview(h, activeShot[field], win), h('span', { 'data-aip-camera-field-error': '', role: 'alert', class: 'wml-small' }, ''))),
          catalog.negativeDefaults ? h('div', { 'data-aip-camera-negative-defaults': '', class: 'wml-small' },
            h('strong', {}, '공통 장비 방지 Negative'),
            h('p', { class: 'wml-muted wml-small', style: 'margin:3px 0;' }, '구도 적용 시 함께 사용해요. 전역 Negative 제거에서 특정 문구를 제외할 수 있어요.'),
            h('div', {}, catalog.negativeDefaults), promptTagPreview(h, catalog.negativeDefaults, win)) : null,
          h('div', { style: 'display:flex;gap:6px;flex-wrap:wrap;' },
          h('button', { type: 'button', class: 'wml-btn', 'data-aip-camera-reset-prompt': '', disabled: !defaultShot, style: buttonStyle(false), onclick: () => {
            if (defaultShot) cameraUiChange(current, { shots: shots.map(item => item.id === activeShot.id
              ? { ...item, positive: defaultShot.positive, negative: defaultShot.negative } : item) });
          } }, '프롬프트 기본값으로 복원'),
          h('button', { type: 'button', class: 'wml-btn', 'data-aip-camera-delete-shot': '', style: buttonStyle(false),
            onclick: () => cameraUiDeleteShot(current, activeShot.id) }, '이 구도 삭제')))) : null,
        h('details', {}, h('summary', {}, '기존 카메라 태그 제거 설정'),
          h('p', { class: 'wml-muted wml-small' }, '구도 적용 시 아래 기본 태그와 직접 추가한 태그를 제거해요. 다른 인물의 행동이나 상태는 바꾸지 않아요.'),
          h('details', {}, h('summary', {}, '기본 제거 목록 보기'),
            h('p', { class: 'wml-muted wml-small' }, (catalog.removeDefaults || []).join(', ') || '없음')),
          h('label', { class: 'aip-prompt-field' }, h('strong', {}, '직접 추가할 제거 태그'), h('textarea', {
            rows: 2, value: snapshot?.removeTags || '', maxLength: 12000, spellcheck: false, 'data-aip-camera-remove': 'positive',
            style: 'width:100%;box-sizing:border-box;resize:vertical;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
            oninput: event => { validatePromptInput(event); updatePromptTagPreview(event, h, win); },
            onchange: event => { if (validatePromptInput(event)) cameraUiChange(current, { removeTags: event.currentTarget.value }); },
          }), promptTagPreview(h, snapshot?.removeTags || '', win), h('span', { 'data-aip-camera-field-error': '', role: 'alert', class: 'wml-small' }, ''))),
        h('section', { style: 'display:grid;gap:6px;' }, h('strong', {}, '구도 미리보기'),
          h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '현재 상황으로 새 이미지를 만들어요. 게임의 이미지 선택은 바뀌지 않아요.'),
          h('button', { type: 'button', class: 'wml-btn', 'data-aip-camera-preview': '', disabled: !snapshot || !!cameraUiPreview?.loading,
            style: buttonStyle(false), onclick: () => void cameraUiGeneratePreview(current) }, cameraUiPreview?.loading ? '이미지 생성 중…' : '이 구도로 이미지 생성'),
          cameraUiPreview?.error ? h('p', { class: 'wml-note', role: 'alert' }, `생성 실패: ${cameraUiPreview.error}`) : null,
          cameraUiPreview?.url ? h('img', { src: cameraUiPreview.url, alt: '카메라 구도 미리보기', style: 'max-width:100%;max-height:420px;object-fit:contain;' }) : null,
          cameraUiPreview?.shotId ? h('p', { class: 'wml-muted wml-small', style: 'margin:0;' },
            `미리보기 구도: ${shots.find(shot => shot.id === cameraUiPreview.shotId)?.name || cameraUiPreview.shotId}`) : null,
          cameraUiPreview?.request ? h('details', {}, h('summary', {}, '미리보기 요청 프롬프트'),
            ...[['prompt', 'Positive'], ['negativePrompt', 'Negative']].map(([field, label]) =>
              h('label', { class: 'aip-prompt-field' }, h('strong', {}, label),
                h('textarea', { rows: 3, value: cameraUiPreview.request[field] || '', readOnly: true,
                  style: 'width:100%;box-sizing:border-box;resize:vertical;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;' }),
                promptTagPreview(h, cameraUiPreview.request[field] || '', win)))) : null),
        h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '직접 선택한 기존 이미지는 구도가 바뀌어도 그대로 보일 수 있어요.'),
        cameraUiMessage ? h('p', { class: 'wml-note', role: 'status' }, cameraUiMessage) : null));
    }

    function clampCameraWindow(win) {
      const el = win?.el;
      if (!el?.isConnected || typeof el.getBoundingClientRect !== 'function'
        || typeof window === 'undefined' || !window.innerWidth || !window.innerHeight) return;
      let rect = el.getBoundingClientRect();
      const maxWidth = Math.max(1, window.innerWidth - 16), maxHeight = Math.max(1, window.innerHeight - 16);
      if (rect.width > maxWidth) el.style.setProperty('width', `${maxWidth}px`, 'important');
      if (rect.height > maxHeight) el.style.setProperty('height', `${maxHeight}px`, 'important');
      rect = el.getBoundingClientRect();
      if (rect.right > window.innerWidth - 8 || rect.left < 8)
        el.style.setProperty('left', `${Math.max(8, Math.min(rect.left, window.innerWidth - rect.width - 8))}px`);
      if (rect.bottom > window.innerHeight - 8 || rect.top < 8)
        el.style.setProperty('top', `${Math.max(8, Math.min(rect.top, window.innerHeight - rect.height - 8))}px`);
    }

    function openCameraWindow() {
      if (cameraWindow) { cameraWindow.refresh(); return; }
      cameraWindow = api.ui.window({ id: 'camera-controller', title: 'AIP 카메라 구도', width: 600, height: 720,
        render: renderCameraWindow, onClose() { cameraWindow = null; cameraUiPreviewSerial += 1; cameraUiPreview = null; } });
      clampCameraWindow(cameraWindow);
    }

    if (typeof api.ui.addButton === 'function') cameraButton = api.ui.addButton({
      label: '카메라 구도', title: '현재 장면의 카메라 구도', onClick: openCameraWindow,
    });

    if (typeof window !== 'undefined') window.addEventListener?.('resize', () => { if (cameraWindow) clampCameraWindow(cameraWindow); });

    let cameraUiRefreshQueued = false;
    api.store.subscribe?.(() => {
      if (!cameraWindow || cameraUiRefreshQueued) return;
      cameraUiRefreshQueued = true;
      queueMicrotask(() => {
        cameraUiRefreshQueued = false;
        if (!cameraWindow) return;
        const current = cameraUiCurrent();
        if (current.id !== cameraUiScene || current.characterId !== cameraUiCharacter) cameraWindow.refresh();
      });
    });
