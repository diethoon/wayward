    async function copyText(tag) {
      let copied = false;
      try {
        if (navigator.clipboard?.writeText) {
          await navigator.clipboard.writeText(tag);
          copied = true;
        }
      } catch { /* use the selection fallback below */ }
      if (!copied) {
        const input = document.createElement('textarea');
        input.value = tag;
        input.style.cssText = 'position:fixed;left:-9999px;top:-9999px;';
        document.body.appendChild(input);
        input.select();
        try { copied = document.execCommand('copy'); } catch { copied = false; }
        input.remove();
      }
      return copied;
    }

    async function copyPromptTag(tag, win) {
      const copied = await copyText(tag);
      settingsMessage = copied ? `영문 프롬프트를 복사했습니다: ${tag}` : '클립보드 복사가 차단되었습니다.';
      win.refresh();
    }

    function addTagToActiveTarget(tag) {
      if (!activeTagTarget) return '';
      if (activeTagTarget.kind === 'external-prompt') {
        const { modId, entryId, source, field } = activeTagTarget;
        const entry = externalPromptMenus().find(menu => menu.id === modId)?.entries.find(item => item.id === entryId);
        if (!entry || entry.source !== source || activeSettingsTab !== `external:${activeTagTarget.tabModId || modId}`) {
          activeTagTarget = null;
          return '';
        }
        saveExternalPrompt(modId, entryId, source, { [field]: appendPromptTags(entry[field], tag) });
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'outfit-draft') {
        const field = activeTagTarget.field;
        if (!newOutfitOpen || activeSettingsTab !== 'outfit-prompts'
          || activeTagTarget.windowEl?.isConnected === false
          || !['positivePrompt', 'negativePrompt', 'topPrompt', 'skirtPrompt'].includes(field)) {
          activeTagTarget = null;
          return '';
        }
        newOutfitDraft[field] = appendPromptTags(newOutfitDraft[field], tag);
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'game-default') {
        const field = activeTagTarget.polarity === 'negative' ? 'negativePrompt' : 'positivePrompt';
        const current = currentGameDefaultPrompts();
        api.settings.set({ gameDefaultPrompts: { ...current,
          [field]: appendPromptTags(current[field] ?? (field === 'negativePrompt' ? GAME_PROMPT_NEGATIVE : GAME_PROMPT_QUALITY), tag) } });
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'global-exclusions') {
        if (activeSettingsTab !== 'game-default') { activeTagTarget = null; return ''; }
        const polarity = activeTagTarget.polarity;
        if (!['positive', 'negative'].includes(polarity)) { activeTagTarget = null; return ''; }
        if (!saveGlobalPromptExclusions(appendPromptTags(currentGlobalPromptExclusions(polarity), tag), polarity)) return '';
        refreshPortraitImage();
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'character') {
        const characterPrompt = currentWifeCharacterPrompt();
        const field = activeTagTarget.polarity === 'negative' ? 'negativePrompt' : 'positivePrompt';
        saveCurrentWifeCharacterPrompt({ [field]: appendPromptTags(characterPrompt[field], tag), sourceId: '' });
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'outfit') {
        const source = outfitPromptSources().find(entry => entry.id === activeTagTarget.id);
        if (!source) return '';
        const field = ['topPrompt', 'skirtPrompt'].includes(activeTagTarget.polarity)
          ? activeTagTarget.polarity : activeTagTarget.polarity === 'negative' ? 'negativePrompt' : 'positivePrompt';
        const custom = currentCustomOutfits().find(entry => entry.id === source.id);
        const value = (field === 'topPrompt' || field === 'skirtPrompt') && custom ? custom[field] : outfitPromptValues(source)[field];
        saveOutfitPromptField(source.id, field, appendPromptTags(value || '', tag));
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'position-module') {
        const module = availablePositionModules().find(entry => entry.id === activeTagTarget.id);
        if (!module) return '';
        const field = activeTagTarget.field;
        const next = tag ? [module[field], tag].filter(Boolean).join(', ') : deduplicatePrompt(module[field]);
        if (!savePositionModulePrompt(module.id, field, next)) return '';
        refreshPortraitImage();
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'button-prompt') {
        if (activeSettingsTab !== 'button-prompts' || activeTagTarget.id !== buttonPromptSelection) {
          activeTagTarget = null;
          return '';
        }
        const saved = buttonPromptRuleMap.get(activeTagTarget.id) || activeTagTarget.rule;
        const entry = saved && buttonPromptAfterRule(saved);
        if (!entry) return '';
        const field = activeTagTarget.field;
        saveButtonPromptRule({ ...entry, [field]: appendPromptTags(entry[field], tag) });
        refreshPortraitImage();
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'button-outcome' || activeTagTarget.kind === 'button-outcome-candidate') {
        if (activeSettingsTab !== 'button-prompts' || activeTagTarget.id !== buttonPromptSelection
          || activeTagTarget.situationId !== buttonOutcomeSelection
          || (activeTagTarget.response || '') !== buttonOutcomeResponse
          || JSON.stringify([activeTagTarget.eventType, activeTagTarget.eventKind]) !== (buttonOutcomeEvent || JSON.stringify(['', '']))) { activeTagTarget = null; return ''; }
        const entry = buttonPromptRuleMap.get(activeTagTarget.id);
        const outcome = entry?.outcomes?.find(item => item.situationId === activeTagTarget.situationId
          && (item.eventType || '') === activeTagTarget.eventType && (item.eventKind || '') === activeTagTarget.eventKind
          && (item.response || '') === (activeTagTarget.response || ''));
        if (!outcome) return '';
        const field = activeTagTarget.field;
        if (activeTagTarget.kind === 'button-outcome-candidate') {
          if (activeTagTarget.candidateId !== buttonOutcomeCandidateId) { activeTagTarget = null; return ''; }
          const candidate = outcome.candidates?.find(item => item.id === activeTagTarget.candidateId);
          if (!candidate) return '';
          saveButtonPromptRule({ ...entry, outcomes: entry.outcomes.map(item => item === outcome
            ? { ...item, candidates: item.candidates.map(value => value === candidate
              ? { ...value, [field]: appendPromptTags(value[field], tag) } : value) } : item) });
          refreshPortraitImage();
          return activeTagTarget.label;
        }
        saveButtonPromptRule({ ...entry, outcomes: entry.outcomes.map(item => item === outcome
          ? { ...item, [field]: appendPromptTags(item[field], tag) } : item) });
        refreshPortraitImage();
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'position-state') {
        const current = currentPositionStatePrompts();
        const entry = current[activeTagTarget.id] || { positivePrompt: '', negativePrompt: '', onlyState: false };
        api.settings.set({ positionStatePrompts: { ...current, [activeTagTarget.id]: {
          ...entry, [activeTagTarget.field]: appendPromptTags(entry[activeTagTarget.field], tag),
        } } });
        positionRandomChoices.clear();
        refreshPortraitImage();
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'position-preset') {
        const preset = positionPresetById(activeTagTarget.id);
        if (!preset) return '';
        api.settings.set({ positionPresetPrompts: { ...currentPositionPresetPrompts(),
          [preset.id]: appendPromptTags(preset.prompt, tag) } });
        positionRandomChoices.clear();
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'position-group') {
        const current = currentPositionGroupPrompts();
        api.settings.set({ positionGroupPrompts: { ...current, [activeTagTarget.id]:
          appendPromptTags(positionGroupPromptById(activeTagTarget.id), tag) } });
        positionRandomChoices.clear();
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'field') {
        const setting = activeTagTarget.polarity === 'negative' ? 'negativePrompts' : 'prompts';
        const current = activeSituationConfig()[setting];
        saveActiveSituationSection(setting, { ...current, [activeTagTarget.key]: appendPromptTags(current[activeTagTarget.key], tag) });
        return activeTagTarget.label;
      }
      const field = activeTagTarget.polarity === 'negative' ? 'negativePrompt' : 'positivePrompt';
      saveActiveSituationSection('dialogueRules', activeSituationConfig().dialogueRules.map(rule => rule.id === activeTagTarget.id
        ? { ...rule, [field]: appendPromptTags(rule[field], tag) }
        : rule));
      return activeTagTarget.label;
    }

    async function useLibraryTag(tag, win) {
      const copied = await copyText(tag);
      const target = addTagToActiveTarget(tag);
      settingsMessage = target
        ? `${translatedPromptTag(tag)} 태그를 ${target}에 추가${copied ? '하고 영문을 복사' : ''}했습니다.`
        : copied ? `영문 프롬프트를 복사했습니다: ${tag}` : '클립보드 복사가 차단되었습니다.';
      win.refresh();
    }

    async function usePromptPreset(preset, win) {
      const prompt = deduplicatePrompt(preset?.prompt);
      if (!prompt) return;
      const copied = await copyText(prompt);
      const target = addTagToActiveTarget(prompt);
      settingsMessage = target
        ? `${preset.name} 묶음의 프롬프트를 ${target}에 모두 추가${copied ? '하고 복사' : ''}했습니다.`
        : copied ? `${preset.name} 묶음을 복사했습니다. 적용할 프롬프트 입력칸을 먼저 눌러 주세요.` : '프롬프트 입력칸을 먼저 눌러 주세요.';
      win.refresh();
    }

    function allPromptTags(customTags = currentCustomTags()) {
      const characterPrompt = currentWifeCharacterPrompt();
      const configured = [
        ...Object.values({ positivePrompt: GAME_PROMPT_QUALITY, negativePrompt: GAME_PROMPT_NEGATIVE, ...currentGameDefaultPrompts() }),
        characterPrompt.positivePrompt,
        characterPrompt.negativePrompt,
        ...Object.values(currentOutfitPrompts()).flatMap(prompt => [prompt.positivePrompt, prompt.negativePrompt]),
        ...Object.values(currentPrompts()),
        ...Object.values(currentNegativePrompts()),
        ...currentDialogueRules().flatMap(rule => [rule.positivePrompt, rule.negativePrompt]),
        ...availablePositionModules().flatMap(module => [module.positivePrompt, module.negativePrompt]),
        ...Object.values(SCENE_POSE_MOOD_PROMPTS).flat(),
        ...Object.values(SCENE_POSE_LOOK_PROMPTS),
        ...Object.values(SCENE_POSE_FILTH_PROMPTS),
        ...Object.values(SCENE_POSE_ROUGH_PROMPTS),
        'thigh_sex, thighs',
        ...MODEL_PROMPT_PRESETS.map(preset => preset.prompt),
        ...currentPromptPresets().map(preset => preset.prompt),
      ].flatMap(promptTokens);
      const unique = new Map();
      for (const tag of [...Object.keys(PROMPT_TAG_KO), ...Object.values(DANBOORU_TAG_LIBRARY).flat(),
        ...currentPositionDanbooruTags(), ...customTags.map(entry => entry.tag), ...configured]) {
        const key = promptTagIdentity(tag).spaced;
        if (!unique.has(key)) unique.set(key, tag);
      }
      return [...unique.values()].sort((left, right) =>
        translatedPromptTag(left, customTags).localeCompare(translatedPromptTag(right, customTags), 'ko'));
    }

    function saveCustomTag(label, tag, win) {
      label = String(label || '').trim();
      tag = String(tag || '').trim();
      if (!label || !tag) {
        settingsMessage = '한글 표시명과 영문 태그를 모두 입력해 주세요.';
        win.refresh();
        return;
      }
      const current = currentCustomTags().filter(entry => entry.tag.toLocaleLowerCase() !== tag.toLocaleLowerCase());
      api.settings.set({ customTags: [...current, { tag, label }] });
      settingsMessage = `사용자 태그를 저장했습니다: ${label} · ${tag}`;
      win.refresh();
    }

    function removeCustomTag(tag, win) {
      api.settings.set({ customTags: currentCustomTags().filter(entry => entry.tag.toLocaleLowerCase() !== tag.toLocaleLowerCase()) });
      settingsMessage = `사용자 태그를 삭제했습니다: ${tag}`;
      win.refresh();
    }

    function savePromptPreset(name, prompt, win) {
      name = String(name || '').trim().slice(0, 80);
      prompt = deduplicatePrompt(String(prompt || '').slice(0, 8000));
      if (!name || !prompt) {
        settingsMessage = '프리셋 이름과 영문 프롬프트를 모두 입력해 주세요.';
        win.refresh();
        return;
      }
      promptPresetCounter += 1;
      const id = `prompt-${Date.now().toString(36)}-${promptPresetCounter}`;
      api.settings.set({ promptPresets: [...currentPromptPresets(), { id, name, prompt }] });
      settingsMessage = `${name} 프롬프트 프리셋을 중복 정리 후 저장했습니다.`;
      win.refresh();
    }

    function removePromptPreset(id, win) {
      const preset = currentPromptPresets().find(entry => entry.id === id);
      api.settings.set({ promptPresets: currentPromptPresets().filter(entry => entry.id !== id) });
      settingsMessage = `${preset?.name || '사용자'} 프롬프트 프리셋을 삭제했습니다.`;
      win.refresh();
    }

    function deduplicateActivePrompt(win) {
      const target = addTagToActiveTarget('');
      settingsMessage = target ? `${target}의 중복 프롬프트를 하나로 정리했습니다.` : '정리할 프롬프트 입력칸을 먼저 눌러 주세요.';
      win.refresh();
    }

    function promptTagChips(h, value, win) {
      const tags = promptTokens(value);
      if (!tags.length) return null;
      const customTags = currentCustomTags();
      return h('div', { style: 'display:flex;flex-wrap:wrap;gap:5px;margin-top:2px;' },
        h('span', { class: 'wml-muted wml-small', style: 'width:100%;' }, '한글 태그 · 클릭하면 영문 복사'),
        ...tags.map(tag => {
          const korean = translatedPromptTag(tag, customTags);
          return h('button', {
            type: 'button',
            title: `한글: ${korean}\n영문: ${tag}\n클릭하면 영문을 복사합니다.`,
            'data-prompt-tag': tag,
            style: 'border:1px solid #57534e;border-radius:999px;background:#292524;color:#f5f5f4;padding:4px 8px;font-size:11px;cursor:pointer;',
            onclick: () => copyPromptTag(tag, win),
          }, korean);
        }),
      );
    }

    function promptTagPreview(h, value, win) {
      return h('div', { 'data-prompt-tag-preview': '' }, promptTagChips(h, value, win));
    }

    function updatePromptTagPreview(event, h, win) {
      const input = event.currentTarget;
      const node = input.parentElement?.querySelector?.('[data-prompt-tag-preview]');
      if (!node) return;
      const chips = promptTagChips(h, input.value, win);
      node.replaceChildren(...(chips ? [chips] : []));
    }

    function appendPromptTags(current, added) {
      return deduplicatePrompt([...promptTokens(current), ...promptTokens(added)].join(', '));
    }

    function promptTagAdder(h, value, onAdd, id) {
      let pending = '';
      const add = () => {
        const current = typeof value === 'function' ? value() : value;
        const next = appendPromptTags(current, pending);
        if (next !== current) onAdd(next);
      };
      const input = h('input', {
        type: 'text',
        placeholder: '영문 태그 · 쉼표로 여러 개 추가 가능',
        'data-prompt-tag-input': id,
        style: 'min-width:220px;flex:1;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:6px 8px;font:12px/1.4 ui-monospace,Consolas,monospace;',
        oninput: event => { pending = event.currentTarget.value; },
        onkeydown: event => {
          if (event.key !== 'Enter') return;
          event.preventDefault();
          add();
        },
      });
      return h('div', { style: 'display:flex;gap:6px;align-items:center;flex-wrap:wrap;' },
        input,
        h('button', {
          type: 'button',
          'data-prompt-tag-add': id,
          class: 'wml-btn',
          onclick: add,
        }, '태그 추가'),
      );
    }

    function outfitStateChecks(h, selected, onChange, id, allowExposed = false) {
      const options = allowExposed ? [...OUTFIT_STATE_OPTIONS, EXPOSED_OUTFIT_STATE] : OUTFIT_STATE_OPTIONS;
      return h('fieldset', { style: 'border:1px solid #57534e;border-radius:6px;padding:6px 8px;margin:0;' },
        h('legend', { class: 'wml-muted wml-small', style: 'padding:0 4px;' }, '적용할 옷 상태 · 복수 선택'),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px 12px;' },
          ...options.map(([value, label]) => h('label', { style: 'display:flex;align-items:center;gap:5px;font-size:12px;' },
            h('input', {
              type: 'checkbox',
              checked: selected.includes(value),
              'data-outfit-state': `${id}:${value}`,
              onchange: event => onChange(event.currentTarget.checked
                ? [...new Set([...selected, value])]
                : selected.filter(state => state !== value)),
            }),
            label,
          )),
        ),
      );
    }

    let expandedPresetAssignments = false;
    function renderSituationPresets(h, win) {
      const presets = currentSituationPresets();
      const active = activeSituationConfig();
      const assignments = currentSituationPresetAssignments(presets);
      const sources = wifePromptSources();
      const inputStyle = 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;';
      const options = [
        [LEGACY_SITUATION_PRESET_ID, '기본 프리셋'],
        ...presets.map(entry => [entry.id, entry.name]),
      ];
      const activeCustom = presets.find(entry => entry.id === active.id);
      const collapseAssignments = sources.length > 3;
      return [
        h('div', { class: 'wml-section', style: 'display:grid;gap:8px;margin-bottom:10px;' },
          h('label', { style: 'display:grid;gap:4px;' },
            h('strong', { style: 'font-size:12px;' }, '편집할 프리셋'),
            h('select', {
              value: active.id,
              'data-situation-preset-editor': '',
              style: inputStyle,
              onchange: event => {
                activeSituationPresetId = event.currentTarget.value;
                activeTagTarget = null;
                win.refresh();
              },
            }, ...options.map(([id, name]) => h('option', { value: id, selected: id === active.id }, name))),
          ),
          activeCustom ? h('label', { style: 'display:grid;gap:4px;' },
            h('span', { class: 'wml-muted wml-small' }, '프리셋 이름'),
            h('input', {
              type: 'text', maxlength: 80, value: activeCustom.name,
              'data-situation-preset-name': activeCustom.id,
              style: inputStyle,
              onchange: event => {
                const name = String(event.currentTarget.value || '').trim().slice(0, 80);
                if (name) api.settings.set({ situationPresets: presets.map(entry => entry.id === activeCustom.id ? { ...entry, name } : entry) });
                win.refresh();
              },
            }),
          ) : null,
          h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;' },
            api.ui.button('현재 설정을 복제해 새 프리셋 추가', () => {
              if (presets.length >= MAX_SITUATION_PRESETS) return;
              situationPresetCounter += 1;
              const used = new Set(presets.map(entry => entry.id));
              let id = `preset-${Date.now().toString(36)}-${situationPresetCounter}`;
              while (used.has(id)) id = `${id}-${situationPresetCounter += 1}`;
              const name = `${active.name} 복사 ${presets.length + 1}`;
              api.settings.set({ situationPresets: [...presets, { id, name, ...normalizeSituationConfig(active) }] });
              activeSituationPresetId = id;
              activeTagTarget = null;
              settingsMessage = `${name} 프리셋을 만들었습니다.`;
              win.refresh();
            }, { primary: true, disabled: presets.length >= MAX_SITUATION_PRESETS }),
            activeCustom ? api.ui.button('현재 프리셋 삭제', () => {
              if (!window.confirm(`“${activeCustom.name}” 프리셋을 삭제할까요?`)) return;
              const nextAssignments = Object.fromEntries(Object.entries(assignments)
                .map(([characterId, presetId]) => [characterId, presetId === activeCustom.id ? '' : presetId]));
              api.settings.set({
                situationPresets: presets.filter(entry => entry.id !== activeCustom.id),
                situationPresetAssignments: nextAssignments,
              });
              activeSituationPresetId = LEGACY_SITUATION_PRESET_ID;
              activeTagTarget = null;
              settingsMessage = `${activeCustom.name} 프리셋을 삭제했습니다.`;
              win.refresh();
            }) : null,
          ),
          h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '선택한 프리셋에서 바꾼 상황·상태·H Status·대화 설정은 모드 전용 저장소에 즉시 저장됩니다. 기본 프리셋은 기존 JSON 구조와 연결됩니다.'),
        ),
        h(collapseAssignments ? 'details' : 'div', { class: collapseAssignments ? 'aip-state-group' : 'wml-section',
          'data-aip-preset-assignments': '',
          ...(collapseAssignments ? { open: expandedPresetAssignments,
            ontoggle: event => { expandedPresetAssignments = event.currentTarget.open; } } : {}) },
          collapseAssignments ? h('summary', {}, `캐릭터별 적용 프리셋 · ${sources.length}명`)
            : h('strong', { style: 'font-size:12px;' }, '캐릭터별 적용 프리셋'),
          h('p', { class: 'wml-muted wml-small', style: 'margin:4px 0 8px;' }, '각 캐릭터는 미적용 또는 하나의 프리셋만 선택할 수 있습니다.'),
          h('div', { style: 'display:grid;gap:7px;' }, ...sources.map(source => {
            const selected = Object.prototype.hasOwnProperty.call(assignments, source.id)
              ? assignments[source.id]
              : LEGACY_SITUATION_PRESET_ID;
            return h('label', { style: 'display:grid;grid-template-columns:minmax(120px,1fr) minmax(180px,2fr);align-items:center;gap:8px;' },
              h('span', { class: 'wml-small' }, source.name),
              h('select', {
                value: selected,
                'data-situation-preset-character': source.id,
                style: inputStyle,
                onchange: event => {
                  const next = { ...currentSituationPresetAssignments() };
                  const presetId = event.currentTarget.value;
                  if (presetId === LEGACY_SITUATION_PRESET_ID) delete next[source.id];
                  else next[source.id] = presetId;
                  api.settings.set({ situationPresetAssignments: next });
                  win.refresh();
                },
              },
              h('option', { value: '', selected: selected === '' }, '미적용'),
              ...options.map(([id, name]) => h('option', { value: id, selected: selected === id }, name))),
            );
          })),
        ),
      ];
    }

    const expandedDialogueRules = new Set();
    function renderDialogueRules(h, win) {
      const rules = activeSituationConfig().dialogueRules;
      const inputStyle = 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;';
      const update = (id, patch, updateView = true) => {
        saveActiveSituationSection('dialogueRules', activeSituationConfig().dialogueRules.map(rule => rule.id === id ? { ...rule, ...patch } : rule));
        if (updateView) win.refresh();
      };
      const remove = id => {
        saveActiveSituationSection('dialogueRules', activeSituationConfig().dialogueRules.filter(rule => rule.id !== id));
        expandedDialogueRules.delete(id);
        win.refresh();
      };
      return [
        ...rules.map((rule, index) => {
          const defaultRule = DEFAULT_DIALOGUE_RULES.find(entry => entry.id === rule.id);
          return h('details', { class: 'aip-state-group', 'data-aip-dialogue-rule': rule.id,
            open: expandedDialogueRules.has(rule.id),
            ontoggle: event => { event.currentTarget.open ? expandedDialogueRules.add(rule.id) : expandedDialogueRules.delete(rule.id); },
            style: 'margin-bottom:10px;' },
          h('summary', {}, rule.text.trim() || `새 대화 규칙 ${index + 1}`),
          h('div', { style: 'display:flex;align-items:center;justify-content:flex-end;gap:8px;margin-bottom:8px;' },
            h('span', { style: 'display:flex;gap:6px;flex-wrap:wrap;' },
              defaultRule ? api.ui.button('이 규칙 기본값으로', () => update(rule.id, {
                ...defaultRule,
                outfitStates: [...defaultRule.outfitStates],
              })) : null,
              api.ui.button('삭제', () => remove(rule.id)),
            ),
          ),
          h('label', { style: 'display:grid;gap:4px;margin-bottom:8px;' },
            h('span', { class: 'wml-muted wml-small' }, '감지할 대화 문구 · 포함 일치'),
            h('input', { type: 'text', value: rule.text, placeholder: '예: 절대로 놓아주지 않겠어', style: inputStyle, onchange: event => update(rule.id, { text: event.currentTarget.value }) }),
          ),
          h('label', { style: 'display:grid;gap:4px;margin-bottom:8px;' },
            h('span', { class: 'wml-muted wml-small' }, '추가할 Positive 프롬프트'),
            h('textarea', { rows: 2, value: rule.positivePrompt, spellcheck: false, style: `${inputStyle}resize:vertical;min-height:52px;`,
              onfocus: () => { activeTagTarget = { kind: 'dialogue', id: rule.id, polarity: 'positive', label: `대화 규칙 ${index + 1} Positive` }; },
              oninput: event => { update(rule.id, { positivePrompt: event.currentTarget.value }, false); updatePromptTagPreview(event, h, win); },
              onchange: event => update(rule.id, { positivePrompt: event.currentTarget.value }) }),
            promptTagPreview(h, rule.positivePrompt, win),
            promptTagAdder(h, rule.positivePrompt, value => update(rule.id, { positivePrompt: value }), `${rule.id}:positive`),
          ),
          h('label', { style: 'display:grid;gap:4px;margin-bottom:8px;' },
            h('span', { class: 'wml-muted wml-small' }, '추가할 Negative 프롬프트'),
            h('textarea', { rows: 2, value: rule.negativePrompt, spellcheck: false, style: `${inputStyle}resize:vertical;min-height:52px;`,
              onfocus: () => { activeTagTarget = { kind: 'dialogue', id: rule.id, polarity: 'negative', label: `대화 규칙 ${index + 1} Negative` }; },
              oninput: event => { update(rule.id, { negativePrompt: event.currentTarget.value }, false); updatePromptTagPreview(event, h, win); },
              onchange: event => update(rule.id, { negativePrompt: event.currentTarget.value }) }),
            promptTagPreview(h, rule.negativePrompt, win),
            promptTagAdder(h, rule.negativePrompt, value => update(rule.id, { negativePrompt: value }), `${rule.id}:negative`),
          ),
          h('div', { style: 'display:flex;align-items:end;gap:8px;flex-wrap:wrap;' },
            h('label', { style: 'display:grid;gap:4px;min-width:160px;flex:1;' },
              h('span', { class: 'wml-muted wml-small' }, '적용 유지 범위'),
              h('select', { value: rule.duration, 'data-dialogue-duration': rule.id, style: inputStyle, onchange: event => update(rule.id, { duration: event.currentTarget.value }) },
                h('option', { value: 'scene', selected: rule.duration === 'scene' }, '상황이 끝날 때까지'),
                h('option', { value: 'minutes', selected: rule.duration === 'minutes' }, '지정한 시간 동안'),
              ),
            ),
            outfitStateChecks(h, rule.outfitStates, states => update(rule.id, { outfitStates: states }), rule.id),
            rule.duration === 'minutes' ? h('label', { style: 'display:grid;gap:4px;width:110px;' },
              h('span', { class: 'wml-muted wml-small' }, '유지 시간(분)'),
              h('input', { type: 'number', min: 1, max: 1440, value: rule.minutes, style: inputStyle, onchange: event => update(rule.id, { minutes: Math.max(1, Math.min(1440, Math.floor(Number(event.currentTarget.value) || 1))) }) }),
            ) : null,
          ),
        ); }),
        rules.length ? null : h('p', { class: 'wml-muted wml-small' }, '등록된 대화 규칙이 없습니다.'),
        api.ui.button('대화 규칙 추가', () => {
          dialogueRuleCounter += 1;
          const id = `dialogue-${Date.now().toString(36)}-${dialogueRuleCounter}`;
          expandedDialogueRules.add(id);
          saveActiveSituationSection('dialogueRules', [...activeSituationConfig().dialogueRules, {
            id,
            text: '',
            positivePrompt: '',
            negativePrompt: '',
            duration: 'scene',
            minutes: 10,
            outfitStates: [...ALL_OUTFIT_STATES],
          }]);
          win.refresh();
        }, { primary: true }),
      ];
    }

    function renderFluidDecaySettings(h, win) {
      const settings = currentFluidDecaySettings();
      const save = patch => {
        api.settings.set({ fluidDecay: { ...currentFluidDecaySettings(), ...patch } });
        syncFluidDecay(true);
        win.refresh();
      };
      return h('div', { class: 'wml-section', style: 'margin-bottom:10px;' },
        h('strong', { style: 'font-size:12px;' }, '정액 상태 자동 완화'),
        h('p', { class: 'wml-muted wml-small', style: 'margin:4px 0 8px;' }, '입·가슴·자궁의 정액 상태를 마지막 갱신부터 설정 시간마다 한 단계씩 낮추며, 실제 H-Status 값도 함께 갱신합니다.'),
        h('div', { style: 'display:flex;align-items:end;gap:12px;flex-wrap:wrap;' },
          h('label', { style: 'display:flex;align-items:center;gap:6px;font-size:12px;padding-bottom:7px;' },
            h('input', {
              type: 'checkbox',
              checked: settings.enabled,
              'data-fluid-decay-enabled': 'true',
              onchange: event => save({ enabled: event.currentTarget.checked }),
            }),
            '자동 완화 사용',
          ),
          h('label', { style: 'display:grid;gap:4px;width:150px;' },
            h('span', { class: 'wml-muted wml-small' }, '단계 완화 간격(분)'),
            h('input', {
              type: 'number', min: 1, max: 1440, value: settings.intervalMinutes,
              disabled: !settings.enabled,
              'data-fluid-decay-minutes': 'true',
              style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
              onchange: event => save({ intervalMinutes: Math.max(1, Math.min(1440, Math.floor(Number(event.currentTarget.value) || DEFAULT_FLUID_DECAY.intervalMinutes))) }),
            }),
          ),
        ),
      );
    }

    function renderHStatusImg2ImgSettings(h, win) {
      const modes = currentHStatusGenerationModes();
      const provider = currentResidueGenerationProvider();
      return h('div', { class: 'wml-section', style: 'margin-bottom:10px;' },
        imageStudioResidueAvailable() ? h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;font-size:12px;' },
          h('strong', {}, '비밀 탭 이미지 생성 제공자'),
          h('select', {
            value: provider, 'data-residue-generation-provider': '',
            style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
            onchange: event => { saveResidueGenerationProvider(event.currentTarget.value); win.refresh(); },
          },
          h('option', { value: 'aip', selected: provider === 'aip' }, 'AIP · 바로 생성하고 이미지 선택'),
          h('option', { value: 'imagestudio', selected: provider === 'imagestudio' }, 'ImageStudio · 검수 후 저장')),
          h('span', { class: 'wml-muted wml-small' }, 'ImageStudio 방식은 H-Status 기본 프롬프트로 검수 이미지를 만듭니다. 검수창에서 저장한 뒤 이미지 선택에서 생성 이미지를 다시 찾으세요.')) : null,
        h('strong', { style: 'font-size:12px;' }, '부위별 이미지 생성 방식'),
        h('p', { class: 'wml-muted wml-small', style: 'margin:4px 0 8px;' }, 'AIP 방식에서 적용합니다. AIP 자체 프롬프트는 아내 외형과 부위별 상태로 새로 구성하며 상태마다 직접 수정할 수 있습니다. H-Status 기본값은 원본 생성 설정을 사용합니다. 기준 이미지 img2img는 같은 상태의 기본 이미지를 참조합니다.'),
        h('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px;' },
          ...FLUID_PARTS.map(({ part, label }) => h('label', { style: 'display:grid;gap:4px;font-size:12px;' },
            h('span', { class: 'wml-muted wml-small' }, label),
            h('select', {
              value: modes[part],
              disabled: provider === 'imagestudio',
              'data-hstatus-generation-mode': part,
              style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
              onchange: event => {
                saveHStatusGenerationMode(part, event.currentTarget.value);
                win.refresh();
              },
            },
            h('option', { value: 'text2img', selected: modes[part] === 'text2img' }, '프롬프트 생성'),
            h('option', { value: 'img2img', selected: modes[part] === 'img2img' }, '기준 이미지 img2img'),
            h('option', { value: 'hstatus', selected: modes[part] === 'hstatus' }, 'H-Status 기본값'),
            h('option', { value: 'own', selected: modes[part] === 'own' }, 'AIP 자체 프롬프트')),
          )),
        ),
      );
    }

    function openHStatusGenerationModeSettings() {
      const win = api.ui.window({
        id: 'hstatus-generation-modes', title: '부위별 이미지 생성 방식', width: 760, height: 430,
        render(body, windowHandle) {
          const h = api.ui.h;
          body.replaceChildren(h('div', {},
            h('p', { class: 'wml-note' }, '비밀 탭 생성 제공자를 선택하고, AIP 방식일 때 부위별 생성 방법을 지정합니다.'),
            renderHStatusImg2ImgSettings(h, windowHandle)));
        },
      });
      win.refresh();
    }
