    function diagnosticText(value) {
      return String(value?.message || value || '').replace(/\s+/g, ' ').trim().slice(0, 240);
    }

    function diagnosticImageName(source) {
      try {
        const url = new URL(source, window.location.href);
        return decodeURIComponent(url.pathname.split('/').filter(Boolean).at(-1) || url.pathname).slice(0, 120);
      } catch {
        return String(source || '').split(/[/?#]/).filter(Boolean).at(-1)?.slice(0, 120) || '(주소 없음)';
      }
    }

    async function runDiagnostics(win, force = true) {
      if (diagnostics.running) return;
      diagnostics.running = true;
      diagnostics.checks = [];
      win?.refresh?.();
      const checks = [];
      const add = (status, title, detail, fix = '') => checks.push({ status, title, detail, fix });
      let backend = null;
      const previousGeneration = diagnostics.lastGeneration;
      let hStatusResidueTest = null;

      try {
        const wml = globalThis.WML?.status?.();
        if (!wml) {
          add('warn', 'WML 상태 정보 확인 불가', '현재 WML에서 모드 파일 상태를 읽을 수 없습니다.', 'WML 로더를 최신 버전으로 갱신한 뒤 새로고침하세요.');
        } else {
          const missing = Array.isArray(wml.missing) ? wml.missing : [];
          const failed = Array.isArray(wml.failed) ? wml.failed : [];
          if (missing.length) {
            const shown = missing.slice(0, 8).join(', ');
            add('warn', '등록된 모드 파일 누락', `${shown}${missing.length > 8 ? ` 외 ${missing.length - 8}개` : ''}`, '누락된 모드 폴더를 다시 설치하거나 모드목록_자동갱신.cmd로 목록을 갱신하세요.');
          } else {
            add('ok', 'WML 모드 파일', '등록된 모드에서 누락된 폴더가 발견되지 않았습니다.');
          }
          if (failed.length) {
            add('error', '모드 로드 오류', failed.slice(0, 5).map(entry => `${entry.id || '알 수 없음'}: ${diagnosticText(entry.error)}`).join(' / '), 'WML 모드 관리자에서 오류 표시를 확인하고 해당 모드를 다시 설치하거나 호환 버전을 사용하세요.');
          } else {
            add('ok', '모드 로드', 'WML이 기록한 모드 로드 오류가 없습니다.');
          }
          const related = ['h-status', 'badguest', 'imagestudio', 'image-ext', 'easygen'].filter(id => wml.loaded?.includes(id));
          add('info', '관련 모드', related.length ? `작동 중: ${related.join(', ')}` : '추가 연동 모드가 감지되지 않았습니다.', '`h-status`와 `badguest`는 해당 상태를 사용할 때만 필요합니다.');
        }

        const imageFunctions = ['imageKey', 'imagePrompt', 'imageLookup', 'imageGenerate'];
        const missingFunctions = imageFunctions.filter(name => !api.has(name));
        if (missingFunctions.length) {
          add('error', '이미지 기능 심볼 누락', missingFunctions.join(', '), '게임 버전과 WML 심볼 표를 맞춘 뒤 새로고침하세요.');
        } else {
          add('ok', '이미지 기능 연결', '이미지 키·프롬프트·조회·생성 함수를 모두 찾았습니다.');
        }

        const gameState = api.store.game();
        add(gameState ? 'ok' : 'warn', '게임 상태', gameState ? '현재 게임 상태를 읽을 수 있습니다.' : '아직 게임이 시작되지 않아 현재 장면을 확인할 수 없습니다.', gameState ? '' : '게임을 시작한 뒤 문제가 난 장면에서 다시 진단하세요.');

        const hStatusBridge = globalThis.__waywardSituationEventMod;
        const hStatusLoaded = globalThis.WML?.status?.()?.loaded?.includes('h-status');
        if (!hStatusBridge) {
          add(hStatusLoaded ? 'error' : 'info', 'H-Status 비밀 탭 연동', hStatusLoaded ? 'H-Status는 로드됐지만 연동 API를 찾지 못했습니다.' : 'H-Status가 활성화되지 않아 비밀 탭 검사를 생략합니다.', hStatusLoaded ? 'H-Status와 이 모드를 최신 버전으로 맞춘 뒤 새로고침하세요.' : '비밀 탭 기능을 사용할 때만 H-Status가 필요합니다.');
        } else {
          add('ok', 'H-Status 연동 API', hStatusBridge.version ? `연동 API ${hStatusBridge.version}` : '연동 API를 사용할 수 있습니다.');
          const secretTab = document.querySelector('#root [data-ko-se-secret-tab]');
          if (secretTab) {
            const currentLayout = secretTab.dataset.attentionSecretLayout === 'current'
              || !!secretTab.parentElement?.querySelector('button[title*="초상화"],button[title*="Portrait"]');
            add(currentLayout ? 'ok' : 'warn', 'H-Status 비밀 탭 위치', currentLayout ? '최신 아내 카드의 초상화·상태 탭 옆에 연결됐습니다.' : '구형 상세 상태 탭 위치에서 감지됐습니다.', currentLayout ? '' : '아내 카드가 표시된 상태에서 다시 진단하세요. 계속 구형 위치로 나오면 H-Status를 갱신하세요.');
          } else {
            add('error', 'H-Status 비밀 탭 없음', '현재 아내 카드에서 비밀 탭 버튼을 찾지 못했습니다.', '아내 카드가 보이는 게임 화면에서 다시 진단하고, H-Status와 이 모드를 최신 버전으로 맞추세요.');
          }
          const secretPanel = document.querySelector('.ko-se-secret');
          if (secretPanel) {
            const cards = [...secretPanel.querySelectorAll('.ko-se-fluid-section .ko-se-fluid-card')];
            const images = cards.map(card => card.querySelector('img.ko-se-fluid-image')).filter(Boolean);
            const ready = images.filter(image => image.complete && image.naturalWidth > 0).length;
            const broken = images.filter(image => image.complete && image.currentSrc && image.naturalWidth === 0).length;
            add(broken ? 'error' : cards.length >= FLUID_PARTS.length ? 'ok' : 'warn', 'H-Status 비밀 탭 잔류 카드', `카드 ${cards.length}개 · 표시 이미지 ${ready}개${broken ? ` · 로드 실패 ${broken}개` : ''}`, broken ? '이미지팩 파일과 이미지 서버의 저장 경로를 확인하세요.' : cards.length >= FLUID_PARTS.length ? '' : '비밀 탭을 다시 열고 카드가 모두 표시되는지 확인하세요.');
          } else {
            add('info', 'H-Status 비밀 탭 내용', '비밀 탭이 닫혀 있어 카드 DOM 검사는 생략했습니다.', '비밀 탭을 연 상태에서 다시 진단하면 카드와 이미지 로드 여부도 확인합니다.');
          }
          const imageKey = residueImageKey('mouth');
          if (!imageKey) {
            add('error', 'H-Status 잔류 이미지 키 생성 실패', '현재 아내의 이미지 이름 또는 상태값으로 잔류 이미지 키를 만들지 못했습니다.', '아내의 영문 이미지 이름과 H-Status 상태 데이터가 저장되어 있는지 확인하세요.');
          } else {
            try {
              const prompt = await residueEditableBasePrompt(imageKey);
              if (prompt?.prompt) {
                hStatusResidueTest = { imageKey, prompt };
                add('ok', 'H-Status 잔류 이미지 프롬프트', `${imageKey} · Positive/Negative 전달 준비 완료`);
              } else {
                add('error', 'H-Status 잔류 프롬프트 누락', imageKey, '사용자 아내는 영문 이미지 이름과 전체 외형 프롬프트를 확인하세요. 기본 아내라면 H-Status 프롬프트 팩 파일도 확인하세요.');
              }
            } catch (error) {
              add('error', 'H-Status 잔류 프롬프트 확인 실패', diagnosticText(error), 'H-Status 프롬프트 팩 파일과 브라우저 콘솔 오류를 확인하세요.');
            }
          }
        }

        const prefs = settingsStore?.getState?.() || {};
        if (prefs.imageBackendMode === 'off') {
          add('error', '이미지 서버 설정 꺼짐', '게임 설정에서 이미지 백엔드 모드가 꺼져 있습니다.', '게임 설정의 이미지 생성 항목에서 자동 또는 사용자 지정 서버를 선택하세요.');
        }
        const offlineOnly = globalThis.__WW_STUDIO_OFFLINE_ONLY__;
        if (offlineOnly === true) {
          add('error', '게임 중 이미지 생성 꺼짐', '이미지 생성 도구가 오프라인 이미지팩만 사용하도록 설정되어 있습니다.', '이미지 생성 도구에서 “게임 플레이 중 이미지 생성”을 자동 또는 켬으로 바꾸세요.');
        } else if (offlineOnly === false) {
          add('ok', '게임 중 이미지 생성', '이미지 서버에 항상 요청하도록 설정되어 있습니다.');
        } else if (offlineOnly === 'auto') {
          add('info', '게임 중 이미지 생성', '서버가 연결되고 생성 가능한 경우에만 자동 요청합니다.');
        }

        try {
          if (force && api.has('imageBackendProbe') && prefs.imageBackendMode !== 'off') {
            const allowAutoProbe = api.has('imageAutoProbeAllowed') ? api.fn('imageAutoProbeAllowed')() : true;
            backend = await api.fn('imageBackendProbe')({
              mode: prefs.imageBackendMode,
              url: prefs.imageBackendUrl,
              allowAutoProbe,
            }, true);
          } else if (api.has('imageBackend')) {
            backend = api.fn('imageBackend')();
          }
        } catch (error) {
          add('error', '이미지 서버 재검색 실패', diagnosticText(error), '서버 주소와 WML 버전을 확인한 뒤 다시 진단하세요.');
        }
        diagnostics.backend = backend || null;

        if (!backend?.baseUrl) {
          add('error', '이미지 생성기 미연결', backend?.error ? diagnosticText(backend.error) : '연결된 이미지 서버를 찾지 못했습니다.', '이미지 생성 서버를 실행하고 게임 설정에서 주소를 확인한 뒤 “다시 진단”을 누르세요.');
        } else if (backend.comfyui !== true) {
          add('error', '이미지 엔진 응답 없음', `서버 ${backend.baseUrl}에는 연결됐지만 생성 엔진이 준비되지 않았습니다.`, 'ComfyUI 또는 선택한 이미지 공급자를 실행하고 서버의 모델 설정을 확인하세요.');
        } else {
          add('ok', '이미지 생성기 연결', `${backend.baseUrl}${backend.version ? ` · 서버 ${backend.version}` : ''}`);
        }

        if (force && backend?.baseUrl && typeof globalThis.fetch === 'function') {
          try {
            const timeout = globalThis.AbortSignal?.timeout?.(5000);
            const response = await globalThis.fetch(`${String(backend.baseUrl).replace(/\/+$/, '')}/api/image/health`, {
              credentials: 'omit',
              ...(timeout ? { signal: timeout } : {}),
            });
            const health = await response.json().catch(() => ({}));
            if (!response.ok || (health.comfyui && health.comfyui !== 'connected')) {
              add('error', '이미지 서버 상태 오류', `HTTP ${response.status}${health.provider ? ` · ${health.provider}` : ''}${health.comfyui ? ` · 엔진 ${health.comfyui}` : ''}`, '이미지 서버 창의 오류 로그와 모델·공급자 설정을 확인하세요.');
            } else {
              add('ok', '이미지 서버 상태 확인', `${health.provider || 'provider'} · 저장 이미지 ${Number(health.images) || 0}개`);
              const img2imgReady = Array.isArray(health.capabilities) && health.capabilities.includes('hstatus-img2img-v1');
              add(img2imgReady ? 'ok' : 'warn', 'H-Status img2img', img2imgReady
                ? '부위별 설정에서 선택한 카드를 참조 이미지 기반 1216×832로 생성할 수 있습니다.'
                : '현재 ImageStudio는 전용 img2img 기능을 제공하지 않아 기존 생성 방식으로 대체됩니다.',
              img2imgReady ? '' : '배포본의 wayward-imagegen 폴더를 덮어쓰고 Start_ImageStudio.cmd를 다시 실행하세요.');
            }
            const queued = Number(health.jobs?.queued);
            if (Number.isFinite(queued)) {
              add(queued >= 60 ? 'warn' : 'info', '생성 대기열', `대기 ${queued}건`, queued >= 60 ? '대기열이 줄어든 뒤 다시 시도하거나 서버에서 불필요한 작업을 취소하세요.' : '');
            }
          } catch (error) {
            add('error', '이미지 서버 통신 실패', diagnosticText(error) || '상태 확인 요청에 응답하지 않았습니다.', '서버 실행 여부, 주소, 방화벽과 CORS 설정을 확인하세요.');
          }
        }

        if (force && api.has('imageGenerate') && backend?.baseUrl && backend.comfyui === true
          && prefs.imageBackendMode !== 'off' && offlineOnly !== true) {
          const imageKey = hStatusResidueTest?.imageKey || 'attention_image_prompt__diagnostic__v-1';
          const startedAt = Date.now();
          try {
            if (hStatusResidueTest) {
              if (await regenerateResidueImage(imageKey)) {
                if (diagnostics.lastGeneration?.status === 'review') {
                  add('info', 'ImageStudio 검수 대기', `${imageKey} · 검수창에서 저장한 뒤 비밀 탭의 이미지 선택에서 다시 찾으세요.`);
                } else {
                  add('ok', 'H-Status 비밀 탭 이미지 생성 성공', `${imageKey} · ${(Date.now() - startedAt).toLocaleString()}ms`);
                }
              } else {
                add('error', 'H-Status 비밀 탭 이미지 생성 실패', `${imageKey} · 이미지 서버가 결과 URL을 반환하지 않았습니다.`, '이미지 서버 로그에서 H-Status 프롬프트 팩·모델·워크플로·저장 경로 오류를 확인하세요.');
              }
            } else {
              const result = await api.fn('imageGenerate')({
                imageKey,
                prompt: 'single red apple on a plain white table, centered composition, studio lighting, best quality',
                negativePrompt: 'worst quality, low quality, blurry, text, watermark',
                workflow: 'illustrious',
                width: 512,
                height: 512,
                bypassCache: true,
                debug: { source: 'attention-image-prompt-diagnostics' },
              });
              if (result?.url) {
                add('ok', '테스트 이미지 생성 성공', `512×512 · ${(Date.now() - startedAt).toLocaleString()}ms`);
              } else {
                add('error', '테스트 이미지 생성 실패', '이미지 서버가 결과 URL을 반환하지 않았습니다.', '이미지 서버 로그에서 모델·워크플로·저장 경로 오류를 확인하세요.');
              }
            }
          } catch (error) {
            add('error', hStatusResidueTest ? 'H-Status 비밀 탭 이미지 생성 실패' : '테스트 이미지 생성 실패', diagnosticText(error), '이미지 서버 로그에서 모델·워크플로·저장 경로 오류를 확인하세요.');
          } finally {
            if (residueBaseImageKey(diagnostics.lastGeneration?.key) === imageKey) diagnostics.lastGeneration = previousGeneration;
          }
        } else if (force) {
          add('info', hStatusResidueTest ? 'H-Status 비밀 탭 이미지 생성 생략' : '테스트 이미지 생성 생략', '이미지 생성기 연결과 게임 중 생성 설정이 준비되지 않았습니다.', '위 연결 오류를 해결한 뒤 다시 진단하세요.');
        }

        if (api.has('imageManifest')) {
          try {
            const manifest = await api.fn('imageManifest')();
            const count = Object.keys(manifest?.entries || {}).length;
            add(count ? 'ok' : backend?.comfyui ? 'info' : 'warn', '사용 가능한 이미지 목록', `${count.toLocaleString()}개`, count || backend?.comfyui ? '' : '이미지팩을 다시 설치하거나 이미지 서버를 연결하세요.');
          } catch (error) {
            add('warn', '이미지 목록 확인 실패', diagnosticText(error), '이미지팩 파일과 서버의 /api/pack 응답을 확인하세요.');
          }
        }

        const brokenImages = [...document.images].filter(image => image.complete && image.currentSrc && image.naturalWidth === 0);
        if (brokenImages.length) {
          add('error', '현재 화면 이미지 파일 로드 실패', `${brokenImages.length}개 · ${brokenImages.slice(0, 4).map(image => diagnosticImageName(image.currentSrc)).join(', ')}`, '해당 이미지팩 파일이 실제로 있는지 확인하고, 서버 이미지라면 서버의 images 경로와 접근 권한을 확인하세요.');
        } else {
          add('ok', '현재 화면 이미지 파일', '브라우저가 로드에 실패한 이미지가 없습니다.');
        }

        const lookup = diagnostics.lastLookup;
        if (lookup) {
          const lookupDetail = `${lookup.key} · ${lookup.source}${lookup.resolvedKey ? ` → ${lookup.resolvedKey}` : ''}`;
          if (lookup.source === 'exact') add('ok', '최근 이미지 조회', `정확한 캐시 이미지를 찾았습니다: ${lookupDetail}`, '같은 이미지 키는 새로 생성하지 않습니다. 새 상태 프롬프트가 적용됐다면 키도 달라져야 합니다.');
          else if (lookup.source === 'base-fallback') add('info', '최근 이미지 조회', `기본 장면 이미지를 대신 사용했습니다: ${lookupDetail}`, '캐릭터 설정에서 기존 이미지 재사용을 선택한 경우 정상입니다.');
          else if (lookup.source === 'nearest-blocked') add('info', '최근 이미지 조회', `유사 이미지를 제외하고 새 생성을 요청했습니다: ${lookupDetail}`);
          else add('warn', '최근 이미지 조회', `사용 가능한 이미지를 찾지 못했습니다: ${lookupDetail}`, '아래 최근 생성 요청과 이미지 생성기 연결 결과를 함께 확인하세요.');
        } else {
          add('info', '최근 이미지 조회 기록 없음', '이 모드를 로드한 뒤 처리된 이미지 조회가 없습니다.', '문제가 난 장면이나 초상화를 한 번 표시한 뒤 다시 진단하세요.');
        }

        const generation = diagnostics.lastGeneration;
        if (!generation) {
          add('info', '최근 생성 요청 기록 없음', '이 모드를 통과한 이미지 생성 요청이 없습니다.', '문제를 재현한 뒤 다시 진단하세요. 조회 실패 후에도 기록이 없다면 게임 중 이미지 생성 설정이 꺼졌을 가능성이 큽니다.');
        } else if (generation.status === 'success') {
          add('ok', '최근 생성 요청 성공', `${generation.key} · ${generation.durationMs}ms · ${generation.mode === 'hstatus-img2img' ? 'H-Status img2img' : generation.mode === 'hstatus-default' ? 'H-Status 기본값' : generation.mode === 'aip-own' ? 'AIP 자체 프롬프트' : '일반 생성'}`);
          if (generation.mode !== 'hstatus-img2img' && diagnostics.lastHStatusImg2ImgFallback) {
            add('warn', 'H-Status img2img 미적용', diagnostics.lastHStatusImg2ImgFallback, '위 원인을 해결한 뒤 자궁 이미지를 다시 생성하세요.');
          }
        } else if (generation.status === 'running') {
          add('info', '이미지 생성 진행 중', generation.key);
        } else if (generation.status === 'review') {
          add('info', 'ImageStudio 검수 대기', `${generation.key} · 검수창에서 저장한 뒤 비밀 탭의 이미지 선택에서 다시 찾으세요.`);
        } else {
          add('error', '최근 생성 요청 실패', `${generation.key}${generation.error ? ` · ${generation.error}` : ' · 서버가 이미지 URL을 반환하지 않았습니다.'}`, '이미지 서버 상태·대기열·서버 로그를 확인한 뒤 다시 생성하세요.');
        }
      } catch (error) {
        add('error', '진단기 실행 오류', diagnosticText(error), '페이지를 새로고침한 뒤 다시 시도하고, 계속되면 이 문구를 제보해 주세요.');
      } finally {
        diagnostics.running = false;
        diagnostics.checkedAt = Date.now();
        diagnostics.checks = checks;
        win?.refresh?.();
      }
    }

    const IMAGE_DEBUG_FIELDS = {
      cycle: [...CYCLE_FIELDS.map(field => ({ id: field.key.split('.').at(-1), label: field.label })),
        { id: 'first-experience', label: '첫경험 · 현재 주기' }],
      hypnosis: H_STATUS_FANTASY_FIELDS.filter(field => field.key.startsWith('hstatus.hypnosis.'))
        .map((field, stage) => ({ id: `hypnosis-${stage}`, label: field.label })),
      crest: H_STATUS_FANTASY_FIELDS.filter(field => field.key.startsWith('hstatus.crest.'))
        .map((field, stage) => ({ id: `crest-${stage}`, label: field.label })),
      toy: [{ id: 'toy-none', label: '토이 · 없음' },
        { id: 'toy-egg', label: '토이 · 에그 바이브' },
        { id: 'toy-penis', label: '토이 · 자지형 바이브' }],
    };

    function captureCycleDebugPrompts(win) {
      if (cycleDebugger.running) return;
      const state = api.store.game();
      const scene = latestScenePrompt;
      const character = state?.characters?.[scene?.characterId];
      if (!scene || !latestPromptArgs?.length || !character || scene.characterId !== state.primaryCharacterId) {
        cycleDebugger.message = '현재 아내의 초상화 장면을 먼저 열어 주세요.';
        win.refresh();
        return;
      }
      const previousPreviewing = promptPreviewing;
      const previousPhase = cyclePreviewPhase;
      const previousFirstExperience = firstExperiencePreviewing;
      const previousFantasy = hStatusFantasyPreview;
      const previousToy = toyPreviewType;
      promptPreviewing = true;
      try {
        const resolve = () => {
          const result = api.fn('imagePrompt')(character, ...latestPromptArgs.slice(1));
          if (!result?.prompt || !Array.isArray(result.parts)
            || positionSituationId(result.key) !== scene.situationId) throw new Error('장면이 바뀌었습니다. 초상화를 다시 열어 주세요.');
          return applyPromptModRules(alignSleepScenePrompt(
            replaceNativeFirstExperience(result), state, scene.characterId));
        };
        cyclePreviewPhase = '';
        firstExperiencePreviewing = false;
        hStatusFantasyPreview = null;
        toyPreviewType = null;
        const current = resolve();
        const variants = {};
        for (const field of IMAGE_DEBUG_FIELDS[cycleDebugger.mode]) {
          const phase = field.id;
          cyclePreviewPhase = cycleDebugger.mode === 'cycle' && phase !== 'first-experience' ? phase : '';
          firstExperiencePreviewing = cycleDebugger.mode === 'cycle' && phase === 'first-experience';
          hStatusFantasyPreview = !['hypnosis', 'crest'].includes(cycleDebugger.mode) ? null
            : { kind: cycleDebugger.mode, stage: Number(phase.split('-').at(-1)) };
          toyPreviewType = cycleDebugger.mode === 'toy' ? phase === 'toy-none' ? '' : phase.slice('toy-'.length) : null;
          const result = resolve();
          const imageKey = `aip_${cycleDebugger.mode}_debug_${phase}_${shortHash(JSON.stringify([
            scene.result.key, result.prompt, result.negativePrompt, result.checkpoint, result.genParams,
            ...(result.look === undefined ? [] : [result.look]),
          ]))}`;
          const old = cycleDebugger.variants[phase];
          const partLabel = cycleDebugger.mode === 'cycle' ? firstExperiencePreviewing ? '첫경험 상태' : '생리 상태'
            : cycleDebugger.mode === 'hypnosis' ? '최면 상태'
              : cycleDebugger.mode === 'crest' ? '음문 상태' : 'H Status · 토이';
          const stateTags = result.parts.find(part => part.label === partLabel)?.tags || '';
          variants[phase] = {
            imageKey, prompt: result.prompt, negativePrompt: result.negativePrompt || '',
            checkpoint: result.checkpoint, params: result.genParams || promptGenParams(result.prompt),
            ...(result.look === undefined ? {} : { look: result.look }),
            stateTags, available: cycleDebugger.mode !== 'cycle' || !firstExperiencePreviewing || !!stateTags,
            sameAsCurrent: result.prompt === current.prompt && result.negativePrompt === current.negativePrompt,
            url: old?.imageKey === imageKey ? old.url : '',
            generatedAt: old?.imageKey === imageKey ? old.generatedAt : 0,
            error: '',
          };
        }
        cycleDebugger.sceneKey = scene.result.key;
        cycleDebugger.characterId = scene.characterId;
        cycleDebugger.slot = state.slot;
        cycleDebugger.day = state.day;
        cycleDebugger.variants = variants;
        cycleDebugger.message = `현재 장면의 ${cycleDebugger.mode === 'cycle' ? '주기 네 단계와 첫경험' : cycleDebugger.mode === 'hypnosis' ? '최면 0~5단계' : cycleDebugger.mode === 'crest' ? '음문 0~5단계' : '토이 없음·에그·자지형'} 프롬프트를 계산했습니다. 이미지 생성은 버튼을 눌렀을 때만 실행됩니다.`;
      } catch (error) {
        cycleDebugger.variants = {};
        cycleDebugger.message = `프롬프트 계산 실패: ${diagnosticText(error)}`;
      } finally {
        cyclePreviewPhase = previousPhase;
        firstExperiencePreviewing = previousFirstExperience;
        hStatusFantasyPreview = previousFantasy;
        toyPreviewType = previousToy;
        promptPreviewing = previousPreviewing;
        win.refresh();
      }
    }

    function cycleDebugSceneCurrent() {
      const state = api.store.game();
      const activeSituationId = positionSituationId(activePortraitImageKey('', state));
      return cycleDebugger.sceneKey && latestScenePrompt?.result?.key === cycleDebugger.sceneKey
        && latestScenePrompt.characterId === cycleDebugger.characterId
        && state?.slot === cycleDebugger.slot && state?.day === cycleDebugger.day
        && (!activeSituationId || activeSituationId === positionSituationId(cycleDebugger.sceneKey));
    }

    async function generateCycleDebugImages(phases, win) {
      if (cycleDebugger.running) return;
      if (!cycleDebugSceneCurrent()) {
        cycleDebugger.message = '장면이나 게임 시간이 바뀌었습니다. 현재 장면 프롬프트를 다시 계산해 주세요.';
        win.refresh();
        return;
      }
      if (!api.has('imageGenerate')) {
        cycleDebugger.message = '이미지 생성 기능을 찾지 못했습니다.';
        win.refresh();
        return;
      }
      if (phases.some(phase => !cycleDebugger.variants[phase]?.available)) {
        cycleDebugger.message = '첫경험 비교는 현재 초상화가 질 삽입 장면일 때 사용할 수 있습니다.';
        win.refresh();
        return;
      }
      cycleDebugger.running = phases.length > 1 ? 'all' : phases[0];
      const generatedThisRun = new Map();
      try {
        for (const phase of phases) {
          const variant = cycleDebugger.variants[phase];
          if (!variant) continue;
          const signature = JSON.stringify([variant.prompt, variant.negativePrompt, variant.checkpoint, variant.params,
            ...(variant.look === undefined ? [] : [variant.look])]);
          const shared = generatedThisRun.get(signature);
          if (shared) {
            variant.url = shared.url;
            variant.generatedAt = shared.generatedAt;
            variant.error = '';
            win.refresh();
            continue;
          }
          cycleDebugger.message = `${IMAGE_DEBUG_FIELDS[cycleDebugger.mode].find(field => field.id === phase)?.label || phase} 이미지 생성 중…`;
          win.refresh();
          try {
            const result = await api.fn('imageGenerate')({
              imageKey: variant.imageKey,
              prompt: variant.prompt,
              negativePrompt: variant.negativePrompt,
              width: 1216, height: 832,
              steps: variant.params?.steps, cfg: variant.params?.cfg,
              loraStrength: variant.params?.loraStrength,
              checkpoint: variant.checkpoint,
              ...(variant.look === undefined ? {} : { look: variant.look }),
              bypassCache: true,
              debug: { source: 'attention-image-prompt-cycle-debug' },
            });
            if (!result?.url) throw new Error('이미지 서버가 결과 URL을 반환하지 않았습니다.');
            variant.url = String(result.url);
            variant.generatedAt = Date.now();
            variant.error = '';
            generatedThisRun.set(signature, variant);
          } catch (error) {
            variant.error = diagnosticText(error);
            cycleDebugger.message = `이미지 생성 실패: ${variant.error}`;
            break;
          }
          win.refresh();
        }
        if (!Object.values(cycleDebugger.variants).some(variant => variant.error))
          cycleDebugger.message = '비교 이미지 생성이 끝났습니다. 동일한 프롬프트는 같은 이미지를 공유합니다.';
      } finally {
        cycleDebugger.running = '';
        win.refresh();
      }
    }

    function renderCycleDebugger(h, win) {
      const stale = Object.keys(cycleDebugger.variants).length > 0 && !cycleDebugSceneCurrent();
      const fields = IMAGE_DEBUG_FIELDS[cycleDebugger.mode];
      const phases = cycleDebugger.mode === 'cycle' ? CYCLE_FIELDS.map(field => field.key.split('.').at(-1)) : fields.map(field => field.id);
      const count = cycleDebugger.mode === 'cycle' ? 4 : cycleDebugger.mode === 'toy' ? 3 : 6;
      const countLabel = cycleDebugger.mode === 'toy' ? '토이 3종' : `${count}단계`;
      const promptStyle = 'width:100%;min-height:104px;background:#0c0a09;color:#e7e5e4;border:1px solid #57534e;border-radius:5px;padding:7px;box-sizing:border-box;resize:vertical;';
      return [
        h('p', { class: 'wml-note' }, '현재 초상화 장면에서 선택한 상태의 단계별 프롬프트를 가상으로 비교합니다. 첫경험은 질 삽입 장면에서만 적용됩니다. 세이브·설정·게임 시간과 초상화 이미지 목록은 바뀌지 않습니다. 생성한 비교 이미지는 이미지 서버에 저장됩니다.'),
        h('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;align-items:center;' },
          ...[['cycle', '생리·첫경험'], ['hypnosis', '최면 0~5단계'], ['crest', '음문 0~5단계'], ['toy', '토이 3종']].map(([mode, label]) =>
            api.ui.button(label, () => {
              if (cycleDebugger.running) return;
              cycleDebugger.mode = mode;
              cycleDebugger.variants = {};
              cycleDebugger.message = '';
              win.refresh();
            }, { primary: cycleDebugger.mode === mode, disabled: !!cycleDebugger.running })),
        ),
        h('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;align-items:center;' },
          api.ui.button(`현재 장면 ${countLabel} 계산`, () => captureCycleDebugPrompts(win), { primary: true, disabled: !!cycleDebugger.running }),
          api.ui.button(cycleDebugger.running === 'all' ? `${countLabel} 생성 중…` : `${countLabel} 비교 이미지 생성`,
            () => generateCycleDebugImages(phases, win),
            { disabled: !!cycleDebugger.running || stale || !Object.keys(cycleDebugger.variants).length }),
        ),
        cycleDebugger.message ? h('p', { class: 'wml-note', role: 'status', 'data-aip-cycle-debug-message': '' }, cycleDebugger.message) : null,
        stale ? h('p', { class: 'wml-note' }, '현재 장면이 달라졌습니다. 생성 전에 단계를 다시 계산해 주세요.') : null,
        h('div', { 'data-aip-cycle-debug-results': '', style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:10px;margin-top:10px;' },
          ...fields.map(field => {
            const phase = field.id;
            const variant = cycleDebugger.variants[phase];
            if (!variant) return null;
            const src = variant.url ? `${variant.url}${variant.url.includes('?') ? '&' : '?'}aip_debug=${variant.generatedAt}` : '';
            return h('article', { 'data-aip-cycle-variant': phase,
              style: 'min-width:0;border:1px solid #57534e;border-radius:7px;padding:10px;background:#1c1917;' },
              h('strong', {}, cycleDebugger.mode === 'cycle' ? field.label.split(' · ')[0] : field.label),
              h('p', { class: 'wml-muted wml-small' }, variant.stateTags
                ? `${cycleDebugger.mode === 'cycle' ? phase === 'first-experience' ? '첫경험' : '주기' : cycleDebugger.mode === 'hypnosis' ? '최면' : cycleDebugger.mode === 'crest' ? '음문' : '토이'} 태그: ${variant.stateTags}`
                : !variant.available ? '현재 장면은 질 삽입이 아니므로 첫경험을 적용할 수 없습니다.'
                  : variant.sameAsCurrent ? '현재 장면과 같은 프롬프트' : '이 단계의 Positive 태그 없음'),
              variant.url ? h('img', { src, alt: `${field.label} 비교 이미지`, 'data-aip-cycle-image': phase,
                style: 'width:100%;aspect-ratio:1216/832;object-fit:contain;background:#0c0a09;border-radius:5px;' })
                : h('div', { class: 'wml-muted wml-small', style: 'aspect-ratio:1216/832;display:grid;place-items:center;background:#0c0a09;border-radius:5px;' }, '아직 생성한 이미지 없음'),
              api.ui.button(variant.url ? '다시 생성' : '이미지 생성',
                () => generateCycleDebugImages([phase], win),
                { disabled: !!cycleDebugger.running || stale || !variant.available }),
              variant.error ? h('p', { class: 'wml-note', role: 'alert' }, variant.error) : null,
              h('details', {}, h('summary', { style: 'cursor:pointer;margin-top:8px;' }, '전체 프롬프트 보기'),
                h('label', { class: 'wml-small' }, 'Positive', h('textarea', { value: variant.prompt,
                  readOnly: true, 'data-aip-cycle-positive': phase, style: promptStyle })),
                h('label', { class: 'wml-small' }, 'Negative', h('textarea', { value: variant.negativePrompt,
                  readOnly: true, 'data-aip-cycle-negative': phase, style: promptStyle }))),
            );
          }),
        ),
      ];
    }

    function renderDiagnostics(h, win) {
      const colors = {
        ok: ['정상', '#86efac', '#052e16'],
        info: ['정보', '#93c5fd', '#172554'],
        warn: ['확인', '#fde68a', '#451a03'],
        error: ['오류', '#fca5a5', '#450a0a'],
      };
      return [
        h('p', { class: 'wml-muted wml-small', 'data-aip-runtime-versions': '' },
          `WML ${api.wml || globalThis.WML?.VERSION || '알 수 없음'} · 게임 ${api.game || '알 수 없음'}`),
        h('div', { style: 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:10px;' },
          api.ui.button(diagnostics.running ? '진단 중…' : diagnostics.checkedAt ? '다시 진단' : '진단 실행', () => {
            void runDiagnostics(win, true);
          }, { primary: true, disabled: diagnostics.running }),
          h('span', { class: 'wml-muted wml-small' }, diagnostics.checkedAt
            ? `마지막 확인: ${new Date(diagnostics.checkedAt).toLocaleTimeString()} · 연결 시 테스트 이미지 1장 생성`
            : '실행 시 테스트 이미지 1장을 생성하며, H-Status 연동 시 현재 비밀 탭 잔류 이미지를 검사합니다.'),
        ),
        diagnostics.checks.length
          ? h('div', { 'data-attention-diagnostics': '', style: 'display:grid;gap:8px;' },
            ...diagnostics.checks.map(check => {
              const [label, color, background] = colors[check.status] || colors.info;
              return h('article', {
                'data-diagnostic-status': check.status,
                style: `border:1px solid ${color}55;border-radius:7px;padding:9px 10px;background:${background};`,
              },
              h('div', { style: 'display:flex;align-items:center;gap:7px;margin-bottom:3px;' },
                h('strong', { style: `font-size:11px;color:${color};` }, label),
                h('strong', { style: 'font-size:12px;' }, check.title),
              ),
              h('div', { class: 'wml-small', style: 'overflow-wrap:anywhere;' }, check.detail),
              check.fix ? h('div', { class: 'wml-small', style: 'margin-top:5px;color:#d6d3d1;' }, `해결 방법: ${check.fix}`) : null);
            }),
          )
          : h('p', { class: 'wml-note', 'data-attention-diagnostics-empty': '' }, '진단 실행을 누르면 현재 연결 상태와 최근 이미지 처리 기록을 확인합니다.'),
      ];
    }

    async function buildImagePack(win, destination = null) {
      if (imagePackBuild.busy) return;
      imagePackBuild.busy = true;
      imagePackBuild.cancelled = false;
      imagePackBuild.message = '현재 아내의 이미지 목록을 확인하는 중…';
      win.refresh();
      try {
        const state = api.store.game();
        const characterId = state?.primaryCharacterId;
        const character = state?.characters?.[characterId];
        const wife = residueCharacterKey(state, character, characterId);
        if (!wife) throw new Error('현재 아내를 찾지 못했습니다.');
        if (!api.has('imageManifest') || !api.saveFile) throw new Error('WML 이미지 목록 또는 파일 저장 기능이 없습니다.');
        if (api.has('imageManifestReset')) api.fn('imageManifestReset')();
        const manifest = await api.fn('imageManifest')();
        const localEntries = await localGeneratedEntries(true);
        const entries = {};
        for (const [cacheKey, entry] of [...Object.entries(localEntries), ...Object.entries(manifest?.entries || {})]) {
          const name = String(entry?.talentName || cacheKey);
          const owner = name.split('__')[0];
          const path = String(entry?.imagePath || '').replaceAll('\\', '/');
          if ((owner !== wife && !(owner === compactGenerationOwner(wife) && name.includes('__aipk-')))
            || !/__(?:aip|aipk|position)-/.test(name)
            || !(path.includes(`/characters/${owner}/`)
              || (!['elena', 'mara', 'pippa'].includes(wife) && path.includes('/characters/unknown/')))
            || path.startsWith('/')
            || path.split('/').some(part => !part || part === '.' || part === '..' || /[<>:"|?*\x00-\x1f]/.test(part))
            || /^[a-z]+:/i.test(path)) continue;
          if (entries[name] && entry.source !== 'server') continue;
          if (!await localImageExists(path)) continue;
          entries[name] = { imagePath: path, talentName: name, imageType: entry.imageType || 'portrait', source: 'attention-image-prompt' };
        }
        const count = Object.keys(entries).length;
        if (!count) throw new Error('현재 아내의 상황별 프롬프트 이미지가 목록에 없습니다. 게임 폴더의 images/ 캐시와 실제 이미지 파일을 확인해 주세요.');
        const pack = {
          packFormat: 1,
          packId: `attention-image-prompt-${wife}-${new Date().toISOString().slice(0, 10)}`,
          generatedAt: new Date().toISOString().slice(0, 10),
          characters: [wife],
          entryCount: count,
          entries,
        };
        const script = `(function(){var p=window.__WAYWARD_IMAGE_PACKS__||(window.__WAYWARD_IMAGE_PACKS__=[]);p.push(${JSON.stringify(pack)});})();\n`;
        if (destination) {
          const folderName = `attention-image-prompt-${wife.replace(/[^a-z0-9_-]/gi, '-')}-${Date.now()}`;
          const folder = await destination.getDirectoryHandle(folderName, { create: true });
          const write = async (segments, data) => {
            let dir = folder;
            for (const segment of segments.slice(0, -1)) dir = await dir.getDirectoryHandle(segment, { create: true });
            const file = await dir.getFileHandle(segments.at(-1), { create: true });
            const stream = await file.createWritable();
            try { await stream.write(data); await stream.close(); }
            catch (error) { try { await stream.abort?.(); } catch {} throw error; }
          };
          const paths = [...new Set(Object.values(entries).map(entry => entry.imagePath))];
          for (let index = 0; index < paths.length; index++) {
            if (imagePackBuild.cancelled) throw new Error('사용자가 중지했습니다. 만들어진 폴더는 일부 파일만 담고 있습니다.');
            const path = paths[index];
            const response = await fetch(`./images/${path.split('/').map(encodeURIComponent).join('/')}`, { credentials: 'omit' });
            if (!response.ok) throw new Error(`이미지 파일을 읽지 못했습니다: ${path}`);
            await write(['images', ...path.split('/')], await response.blob());
            if ((index + 1) % 25 === 0 || index + 1 === paths.length) {
              imagePackBuild.message = `${wife} · 이미지 파일 ${index + 1}/${paths.length}개 저장 중…`;
              win.refresh();
            }
          }
          await write(['wml', 'mods', 'attention-image-prompt', 'image-pack.js'], new Blob([script], { type: 'text/javascript' }));
          imagePackBuild.message = `${wife} · 이미지 ${count.toLocaleString()}장과 목록을 ${folderName} 폴더에 저장했습니다. 이 폴더 안의 images/와 wml/을 별도 게임 복사본의 HTML 옆에 복사한 뒤 새로고침하세요.`;
        } else {
          await api.saveFile('image-pack.js', script, 'text/javascript');
          imagePackBuild.message = `${wife} · ${count.toLocaleString()}장 내보냈습니다. 받은 image-pack.js를 이 모드 폴더에 넣고 게임을 새로고침하세요. 그림 파일은 게임 HTML 옆의 images/ 경로에 유지해야 합니다.`;
        }
      } catch (error) {
        imagePackBuild.message = `${imagePackBuild.cancelled ? '이미지팩 내보내기 중지' : '이미지팩 제작 실패'}: ${error?.message || error}`;
      } finally {
        imagePackBuild.busy = false;
        win.refresh();
      }
    }

    function renderImagePack(h, win) {
      return [
        ...renderOfflineImageFolder(h, win),
        h('p', { class: 'wml-note' }, '현재 아내의 AIP·체위·단축 키 이미지만 모읍니다. 기존 이미지와 서버 캐시는 변경하지 않습니다. 목록 파일만 내려받거나, 지원 브라우저에서는 그림 파일까지 새 폴더에 저장할 수 있습니다.'),
        api.ui.button(imagePackBuild.busy ? '제작 중…' : '현재 아내 이미지팩 만들기', () => { void buildImagePack(win); }, { disabled: imagePackBuild.busy }),
        typeof window.showDirectoryPicker === 'function' ? api.ui.button('그림 포함 폴더로 저장', async () => {
          try { void buildImagePack(win, await window.showDirectoryPicker({ mode: 'readwrite' })); }
          catch (error) {
            if (error?.name !== 'AbortError') {
              imagePackBuild.message = `폴더를 열지 못했습니다: ${error?.message || error}`;
              win.refresh();
            }
          }
        }, { disabled: imagePackBuild.busy }) : null,
        imagePackBuild.busy ? api.ui.button('내보내기 중지', () => { imagePackBuild.cancelled = true; }) : null,
        h('p', { class: 'wml-small', role: 'status', 'data-attention-image-pack-result': '' }, imagePackBuild.message || '내보낸 image-pack.js는 이 모드 폴더의 같은 이름 파일과 교체하면 됩니다.'),
      ];
    }

    function promptHookInspector() {
      if (typeof api.hookOwners === 'function' && typeof api.previewHook === 'function') return {
        source: 'wml-api', hookOwners: name => api.hookOwners(name),
        previewHook: (name, args, without) => api.previewHook(name, args, without),
      };
      let hooks;
      try { hooks = globalThis.WML?.dev?.().hooks; } catch { return null; }
      if (!hooks?.get || !api.sym || !api.engine) return null;
      const entry = name => hooks.get(api.sym(name));
      return {
        source: 'wml-dev',
        hookOwners(name) {
          const item = entry(name);
          return [...new Set([
            ...(item?.before || []), ...(item?.around || []), ...(item?.after || []), item?.replace,
          ].filter(Boolean).map(hook => hook.owner))];
        },
        previewHook(name, args, without) {
          const item = entry(name);
          const target = api.engine[api.sym(name)];
          if (!item || typeof target !== 'function' || !Array.isArray(args)
            || !Array.isArray(item.before) || !Array.isArray(item.around) || !Array.isArray(item.after))
            throw new Error('프롬프트 훅을 찾지 못했습니다.');
          const original = [item.before, item.around, item.after, item.replace];
          try {
            if (without) {
              item.before = original[0].filter(hook => hook.owner !== without);
              item.around = original[1].filter(hook => hook.owner !== without);
              item.after = original[2].filter(hook => hook.owner !== without);
              if (item.replace?.owner === without) item.replace = null;
            }
            const result = target.apply(api.engine, args);
            if (result?.then) throw new Error('비동기 프롬프트 훅은 미리볼 수 없습니다.');
            return result;
          } finally {
            [item.before, item.around, item.after, item.replace] = original;
          }
        },
      };
    }

    function splitPromptReviewTags(value) {
      if (typeof value !== 'string') return null;
      const tags = [];
      const stack = [];
      const closing = { ')': '(', ']': '[', '}': '{' };
      let escaped = false;
      let start = 0;
      for (let index = 0; index < value.length; index += 1) {
        const char = value[index];
        if (escaped) { escaped = false; continue; }
        if (char === '\\') { escaped = true; continue; }
        if ('([{'.includes(char)) stack.push(char);
        else if (Object.prototype.hasOwnProperty.call(closing, char)) {
          if (stack.pop() !== closing[char]) return null;
        } else if (char === ',' && !stack.length) {
          const tag = value.slice(start, index).trim();
          if (tag) tags.push(tag);
          start = index + 1;
        }
      }
      if (stack.length || escaped) return null;
      const last = value.slice(start).trim();
      if (last) tags.push(last);
      return tags;
    }

    function diffPromptReviewTags(before, after) {
      const oldTags = splitPromptReviewTags(before);
      const newTags = splitPromptReviewTags(after);
      if (!oldTags || !newTags) return null;
      const count = tags => {
        const counts = new Map();
        for (const tag of tags) counts.set(tag, (counts.get(tag) || 0) + 1);
        return counts;
      };
      const oldCounts = count(oldTags);
      const newCounts = count(newTags);
      const delta = (values, other) => [...values].flatMap(([tag, amount]) => {
        const difference = amount - (other.get(tag) || 0);
        return difference > 0 ? [{ tag, count: difference }] : [];
      });
      return { added: delta(newCounts, oldCounts), removed: delta(oldCounts, newCounts) };
    }

    function renderServerPromptChanges(h, request, field) {
      const comparison = request?.comparison;
      const comparable = comparison && ['key-match', 'same-request'].includes(comparison.confidence);
      const baseline = comparable ? comparison.baseline?.[field] : undefined;
      const final = request?.[field];
      const diff = diffPromptReviewTags(baseline, final);
      if (!diff) return h('p', { class: 'wml-note', 'data-server-diff-unavailable': field },
        comparable && typeof baseline === 'string' && typeof final === 'string'
          ? '프롬프트의 괄호 또는 이스케이프가 완전하지 않아 태그 차이를 계산할 수 없어요.'
          : '이 요청과 비교할 생성 전 프롬프트를 확인하지 못했어요.');
      const observed = diffPromptReviewTags(comparison.aipBefore?.[field], comparison.aipAfter?.[field]);
      const renderList = (kind, title) => {
        const items = diff[kind];
        const observedTags = new Set((observed?.[kind] || []).map(item => item.tag));
        const added = kind === 'added';
        return h('section', { 'data-server-diff-kind': kind, style: 'margin-top:8px;' },
          h('strong', { style: 'font-size:12px;' }, `${title} · ${items.reduce((total, item) => total + item.count, 0)}개`),
          items.length ? h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;margin-top:5px;' },
            ...items.map(item => {
              const note = observedTags.has(item.tag)
                ? 'AIP 생성 요청 보정 과정에서 관찰됐어요. 다른 모드 프롬프트 훅도 포함될 수 있어 개별 모드는 확인할 수 없어요.'
                : '이 태그를 변경한 모드는 확인할 수 없어요.';
              return h('details', { 'data-server-diff-tag': item.tag,
                style: `max-width:100%;border:1px solid ${added ? '#4d7c0f' : '#b45309'};border-radius:6px;background:${added ? '#1a2e05' : '#451a03'};color:${added ? '#ecfccb' : '#fef3c7'};` },
              h('summary', { title: note, style: 'cursor:pointer;padding:5px 8px;overflow-wrap:anywhere;font:12px/1.45 ui-monospace,Consolas,monospace;' },
                `${added ? '추가' : '제거'} · ${item.tag}${item.count > 1 ? ` ×${item.count}` : ''}`),
              h('span', { class: 'wml-small', style: 'display:block;padding:0 8px 7px;max-width:320px;overflow-wrap:anywhere;' }, note));
            })) : h('p', { class: 'wml-muted wml-small', style: 'margin:3px 0;' }, '없음'));
      };
      return h('div', { 'data-server-prompt-diff': field, style: 'margin:8px 0 14px;' },
        renderList('added', '추가된 태그'), renderList('removed', '제거된 태그'));
    }

    function renderPromptMods(h, win) {
      const current = promptModPreview.result?.current || latestScenePrompt?.result;
      const scene = positionSituationId(current?.key);
      if (!scene && promptModPreview.scope === 'scene') promptModPreview.scope = 'global';
      const selectedScope = promptModPreview.scope === 'scene' ? scene : '';
      const ruleRow = (owner, polarity, source, tag, savedScope) => {
        const scope = savedScope === undefined ? selectedScope : savedScope;
        const rules = currentPromptModRules();
        const explicit = rules.find(rule => rule.owner === owner && rule.polarity === polarity
          && rule.source === source && rule.tag === tag && rule.scope === scope);
        const inherited = scope && rules.find(rule => rule.owner === owner && rule.polarity === polarity
          && rule.source === source && rule.tag === tag && !rule.scope);
        const saved = explicit || inherited;
        const save = changes => savePromptModRule(owner, polarity, source, tag, scope,
          { ...(!explicit && inherited ? { enabled: inherited.enabled, replacement: inherited.replacement, korean: inherited.korean } : {}), ...changes });
        const enabled = saved ? saved.enabled : source === 'current';
        const korean = saved?.korean || translatedPromptTag(tag);
        const untranslated = /[a-z]{2,}/i.test(korean);
        const key = JSON.stringify([owner, polarity, source, tag, scope]);
        const editing = promptModPreview.editKey === key;
        return h('div', {
          'data-prompt-mod-rule': '', 'data-prompt-mod-owner': owner,
          'data-prompt-mod-polarity': polarity, 'data-prompt-mod-source': source,
          'data-prompt-mod-tag': tag, 'data-prompt-mod-scope': scope,
          style: 'display:grid;gap:6px;align-content:start;min-width:0;flex:1 1 240px;max-width:420px;padding:10px;border:1px solid #57534e;border-radius:8px;background:#1c1917;',
        },
        h('div', { style: 'display:flex;gap:6px;align-items:center;min-width:0;flex-wrap:wrap;' },
          h('button', {
            type: 'button', 'data-prompt-mod-chip': tag, 'aria-pressed': enabled ? 'true' : 'false',
            'aria-label': `${tag} ${enabled ? '반영 중, 눌러 제외' : '제외 중, 눌러 반영'}`,
            title: `${untranslated ? '풀이 미등록' : korean} · ${scope ? `장면 ${scope}` : '전역'} · 클릭: 반영 전환 · Ctrl+클릭: 수정 · Alt+클릭: 원복`,
            style: `border:1px solid ${enabled ? '#b45309' : '#78716c'};border-radius:6px;padding:7px 9px;min-height:36px;max-width:100%;overflow-wrap:anywhere;text-align:left;cursor:pointer;background:${enabled ? '#451a03' : '#292524'};color:${enabled ? '#fef3c7' : '#e7e5e4'};font:12px ui-monospace,Consolas,monospace;`,
            onclick: event => {
              if (event.altKey) {
                deletePromptModRule(owner, polarity, source, tag, scope);
                promptModPreview.editKey = '';
              } else if (event.ctrlKey || event.metaKey) promptModPreview.editKey = editing ? '' : key;
              else save({ enabled: !enabled });
              win.refresh();
            },
          }, tag, h('span', { 'data-prompt-mod-state': '', class: 'wml-small', style: `display:block;margin-top:3px;color:${enabled ? '#fcd34d' : '#d6d3d1'};` },
            enabled ? '반영 중 · 눌러 제외' : '반영 안 함 · 눌러 반영'))),
        h('span', { 'data-prompt-mod-translation': '', class: 'wml-small', style: 'color:#d6d3d1;overflow-wrap:anywhere;' },
          untranslated ? '한글 풀이 없음' : korean),
        h('div', { style: 'display:flex;gap:6px;flex-wrap:wrap;' },
          h('button', { type: 'button', 'data-prompt-mod-edit': tag, 'aria-label': `${tag} 태그 수정`,
            title: '태그 수정', class: 'wml-btn', style: 'min-height:36px;padding:6px 10px;',
            onclick: () => { promptModPreview.editKey = editing ? '' : key; win.refresh(); },
          }, editing ? '수정 닫기' : '수정'),
          h('button', { type: 'button', 'data-prompt-mod-restore': tag, 'aria-label': `${tag} 기본값 복원`,
            class: 'wml-btn', disabled: !explicit, style: 'min-height:36px;padding:6px 10px;',
            onclick: () => { deletePromptModRule(owner, polarity, source, tag, scope); promptModPreview.editKey = ''; win.refresh(); },
          }, source === 'add' ? '삭제' : '복원')),
        savedScope !== undefined ? h('span', { class: 'wml-muted wml-small', style: 'overflow-wrap:anywhere;' },
          `${owner === api.id && source === 'add' ? '직접 추가' : owner} · ${polarity === 'positive' ? 'Positive' : 'Negative'} · ${scope ? `장면: ${scope}` : '전역'}`) : null,
        editing ? h('div', { style: 'display:grid;gap:5px;padding:8px;border:1px solid #57534e;border-radius:7px;background:#1c1917;' },
        h('span', { class: 'wml-small' }, `${owner} · ${polarity === 'positive' ? 'Positive' : 'Negative'} · ${scope ? `장면: ${scope}` : '전역'}${!explicit && inherited ? ' (전역 규칙 적용 중)' : ''}`),
        h('span', { class: 'wml-small', 'data-prompt-mod-korean': '' },
          `한글: ${untranslated ? '풀이 미등록' : korean}`),
        h('input', {
          type: 'text', value: saved?.korean || '',
          'data-prompt-mod-korean-input': '',
          'aria-label': `${tag} 한글 풀이`, placeholder: '한글 풀이 직접 입력 (선택)',
          style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:6px 8px;font-size:12px;',
          onchange: event => {
            save({ korean: event.currentTarget.value });
            win.refresh();
          },
        }),
        h('input', {
          type: 'text', value: saved?.replacement || '',
          'data-prompt-mod-replacement': '',
          'aria-label': `${owner} ${polarity === 'positive' ? 'Positive' : 'Negative'} ${tag} 대체 태그`,
          placeholder: '대신 적용할 영문 SDXL 태그 (비우면 원래 태그)',
          style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px ui-monospace,Consolas,monospace;',
          onchange: event => {
            const replacement = String(event.currentTarget.value || '').trim();
            save({ replacement, enabled: replacement ? true : enabled });
            win.refresh();
          },
        }),
        h('button', { type: 'button', 'data-prompt-mod-reset': tag,
          disabled: !explicit, style: 'justify-self:start;border:1px solid #57534e;border-radius:5px;background:#292524;color:#e7e5e4;padding:5px 8px;',
          onclick: () => {
            deletePromptModRule(owner, polarity, source, tag, scope);
            promptModPreview.editKey = '';
            win.refresh();
          },
        }, '기본값 복원'),
        saved && source === 'add' ? h('button', { type: 'button', 'data-prompt-mod-delete': tag,
          onclick: () => { deletePromptModRule(owner, polarity, source, tag, scope); promptModPreview.editKey = ''; win.refresh(); },
        }, '추가 규칙 삭제') : null) : null);
      };
      const common = [
        h('h4', { style: 'margin:16px 0 4px;font-size:15px;' }, '프롬프트 확인'),
        h('p', { class: 'wml-muted wml-small', style: 'margin:0 0 8px;' }, '최근 요청과 현재 장면의 예상 프롬프트를 따로 확인해요.'),
        h('details', { 'data-prompt-server-request': '',
          open: promptModPreview.serverRequestOpen ?? !!latestServerImageRequest,
          ontoggle: event => { promptModPreview.serverRequestOpen = event.currentTarget.open; },
          style: 'margin:8px 0;padding:10px 12px;border:1px solid #57534e;border-radius:8px;background:#1c1917;',
        },
          h('summary', { style: 'cursor:pointer;font-weight:700;' }, latestServerImageRequest ? '최근 서버 요청 · 기록 있음' : '최근 서버 요청 · 기록 없음'),
          latestServerImageRequest ? h('div', {},
            h('p', { class: 'wml-muted wml-small' }, 'AIP가 전송 시도 때 확인한 내용이에요. 서버 수신·생성 성공과 이후 다른 모드의 변경은 확인할 수 없어요.'),
            h('p', { class: 'wml-small', style: 'overflow-wrap:anywhere;' },
              `기록 시각: ${new Date(latestServerImageRequest.capturedAt).toLocaleString()} · 이미지 키: ${latestServerImageRequest.imageKey || '(없음)'}`),
            current?.key && current.key !== latestServerImageRequest.imageKey
              ? h('p', { class: 'wml-note' }, '현재 초상화와 요청의 키가 달라요. 다른 장면·변형이거나 축약된 키일 수 있어요.') : null,
            ['key-match', 'same-request'].includes(latestServerImageRequest.comparison?.confidence) ? h('p', { class: 'wml-note', 'data-server-diff-confidence': '' },
              latestServerImageRequest.comparison.confidence === 'key-match'
                ? '이미지 키 기준으로 생성 전 프롬프트와 비교했어요. 같은 요청인지는 확정할 수 없어요.'
                : '이 요청의 생성 전 프롬프트와 비교했어요.') : null,
            ...['prompt', 'negativePrompt'].flatMap((key, index) => [
              h('p', { class: 'wml-small' }, index ? 'Negative · 네거티브' : 'Positive · 포지티브'),
              h('code', { class: 'notranslate', translate: 'no', style: 'display:block;white-space:pre-wrap;overflow-wrap:anywhere;' }, latestServerImageRequest[key] || ''),
              renderServerPromptChanges(h, latestServerImageRequest, key),
            ])) : h('p', { class: 'wml-note' }, '아직 관찰된 서버 생성 요청이 없습니다. 기존 이미지를 재사용했거나 생성이 차단됐다면 요청이 발생하지 않을 수 있습니다.')),
        current ? h('details', { 'data-prompt-mod-current': '', style: 'margin:8px 0;padding:10px 12px;border:1px solid #57534e;border-radius:8px;background:#1c1917;' },
          h('summary', { style: 'cursor:pointer;font-weight:700;' }, '현재 초상화 · 생성 요청 전 예상'),
          h('p', { class: 'wml-small', style: 'overflow-wrap:anywhere;' }, `현재 이미지 키: ${current.key || ''}`),
          ...['prompt', 'negativePrompt'].flatMap((key, index) => [
            h('p', { class: 'wml-small' }, index ? 'Negative · 네거티브' : 'Positive · 포지티브'),
              h('code', { class: 'notranslate', translate: 'no', style: 'display:block;white-space:pre-wrap;overflow-wrap:anywhere;' }, deduplicateFinalRequest(applyPromptModRules(current))?.[key] || ''),
          ])) : h('p', { class: 'wml-note' }, '현재 아내의 초상화 장면을 먼저 열어 주세요.'),
      ];
      const scopeEditor = [
        h('h4', { style: 'margin:18px 0 4px;font-size:15px;' }, '변경 적용 범위'),
        h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '이 범위는 포지티브와 네거티브 태그의 수정·제외·추가에 모두 적용돼요.'),
        h('label', { style: 'display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:10px 0;' }, '새 태그 규칙 적용 범위',
          h('select', { 'data-prompt-mod-scope-select': '', value: promptModPreview.scope || 'global',
            onchange: event => { promptModPreview.scope = event.currentTarget.value; promptModPreview.editKey = ''; win.refresh(); } },
            h('option', { value: 'global', selected: promptModPreview.scope !== 'scene' }, '전역'),
            h('option', { value: 'scene', selected: promptModPreview.scope === 'scene', disabled: !scene }, scene ? `현재 장면: ${scene}` : '현재 장면 없음'))),
        h('p', { class: 'wml-muted wml-small' }, selectedScope ? '이 장면 계열과 인원·배치가 같은 경우에 적용돼요.' : '전역으로 선택되어 있어요. 해당 태그가 나오는 모든 장면에 적용돼요.'),
      ];
      const addEditor = [
        h('h4', { style: 'margin:22px 0 4px;font-size:15px;' }, '태그 직접 추가'),
        h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '포지티브에는 표현할 내용을, 네거티브에는 피할 내용을 넣어요.'),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:8px 0;' },
          h('span', { class: 'wml-small' }, '추가할 프롬프트'),
          h('select', { 'data-prompt-mod-add-polarity': '', 'aria-label': '추가할 프롬프트 종류', value: promptModPreview.addPolarity || 'positive',
            onchange: event => { promptModPreview.addPolarity = event.currentTarget.value; } },
            h('option', { value: 'positive', selected: promptModPreview.addPolarity !== 'negative' }, '포지티브 · 표현할 내용'),
            h('option', { value: 'negative', selected: promptModPreview.addPolarity === 'negative' }, '네거티브 · 피할 내용')),
          h('input', { type: 'text', 'data-prompt-mod-add-input': '', 'aria-label': '추가할 영문 태그',
            placeholder: '추가할 영문 태그', value: promptModPreview.addText || '', style: 'flex:1 1 180px;min-width:0;',
            oninput: event => { promptModPreview.addText = event.currentTarget.value; } }),
          api.ui.button('태그 추가', () => {
            const tags = promptTokens(promptModPreview.addText);
            if (!tags.length || tags.some(tag => tag.length > 300) || (promptModPreview.scope === 'scene' && !scene)) {
              promptModPreview.error = '추가할 태그(각 300자 이하)와 적용할 장면을 확인해 주세요.';
            } else {
              for (const tag of tags) savePromptModRule(api.id, promptModPreview.addPolarity || 'positive', 'add', tag, selectedScope, { enabled: true });
              promptModPreview.addText = '';
              promptModPreview.error = '';
            }
            win.refresh();
          })),
      ];
      const inspector = promptHookInspector();
      if (!inspector) {
        const status = globalThis.WML?.status?.() || {};
        const loaded = (Array.isArray(status.loaded) ? status.loaded : []).filter(id => id !== api.id);
        const tagged = loaded.filter(id => status.meta?.[id]?.prompt);
        return [
          ...common,
          h('h4', { style: 'margin:22px 0 4px;font-size:15px;' }, '모드별 태그 확인'),
          h('p', { class: 'wml-note' }, '모드별 차이를 보려면 WML 진단 모드를 켜 주세요. 이미지 생성은 실행하지 않아요.'),
          typeof globalThis.WML?.dev === 'function' && globalThis.localStorage?.setItem
            ? api.ui.button('WML 진단 모드 켜고 미리보기', () => {
              try { globalThis.localStorage.setItem('wml.dev', 'true'); promptModPreview.error = ''; }
              catch (error) { promptModPreview.error = `진단 모드를 켤 수 없습니다: ${error?.message || error}`; }
              win.refresh();
            }) : null,
          promptModPreview.error ? h('p', { class: 'wml-note', role: 'status' }, promptModPreview.error) : null,
          h('details', { 'data-prompt-mod-compat': '' },
            h('summary', {}, `${tagged.length ? '프롬프트 관련 활성 모드' : '활성 모드 전체'} (${(tagged.length ? tagged : loaded).length})`),
            h('p', { class: 'wml-small', style: 'overflow-wrap:anywhere;' }, (tagged.length ? tagged : loaded).join(', ') || '없음')),
          h('p', { class: 'wml-muted wml-small' }, '이후 생성 요청 단계에서 프롬프트가 달라질 수 있어요.'),
          ...scopeEditor,
          ...addEditor,
          currentPromptModRules().length ? h('details', { 'data-prompt-mod-saved': '' },
            h('summary', {}, `저장한 태그 반영 규칙 (${currentPromptModRules().length})`),
            h('p', { class: 'wml-muted wml-small' }, '태그 클릭: 반영 전환 · Ctrl+클릭 또는 ✎: 수정 · Alt+클릭: 기본값 복원'),
            h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;' },
              ...currentPromptModRules().map(rule => ruleRow(rule.owner, rule.polarity, rule.source, rule.tag, rule.scope)))) : null,
        ];
      }
      const loaded = new Set(globalThis.WML?.status?.().loaded || []);
      const owners = inspector.hookOwners('imagePrompt').filter(owner => loaded.has(owner) && owner !== api.id);
      const requestOwners = inspector.hookOwners('imageGenerate').filter(owner => loaded.has(owner) && owner !== api.id && !owners.includes(owner));
      const compare = owner => {
        promptModPreview.owner = owner;
        promptModPreview.error = '';
        promptModPreview.result = null;
        if (!latestPromptArgs?.length) {
          promptModPreview.error = '현재 아내의 초상화 장면을 먼저 열어 주세요.';
          win.refresh();
          return;
        }
        promptPreviewing = true;
        try {
          const current = inspector.previewHook('imagePrompt', latestPromptArgs);
          const without = inspector.previewHook('imagePrompt', latestPromptArgs, owner);
          const difference = key => {
            const now = promptTokens(current?.[key]);
            const then = promptTokens(without?.[key]);
            return { removed: now.filter(token => !then.includes(token)), added: then.filter(token => !now.includes(token)) };
          };
          promptModPreview.result = { current, positive: difference('prompt'), negative: difference('negativePrompt') };
        } catch (error) {
          promptModPreview.error = `미리보기 불가: ${error?.message || error}`;
        } finally {
          promptPreviewing = false;
          win.refresh();
        }
      };
      const rows = (label, polarity, source, tokens) => {
        const id = `${polarity}:${source}`;
        return h('details', { 'data-prompt-mod-section': id, open: promptModPreview.expanded[id] === true,
          style: 'margin:8px 0;padding:7px 9px;border:1px solid #57534e;border-radius:7px;background:#1c1917;',
          ontoggle: event => { promptModPreview.expanded[id] = event.currentTarget.open; },
        }, h('summary', { style: 'cursor:pointer;font-size:12px;font-weight:700;' }, `${label} (${tokens.length})`),
        h('div', { style: 'display:flex;flex-wrap:wrap;align-items:flex-start;gap:6px;margin-top:8px;' },
          ...(tokens.length ? tokens.map(tag => ruleRow(promptModPreview.owner, polarity, source, tag))
            : [h('span', { class: 'wml-muted wml-small' }, '없음')])));
      };
      return [
        ...common,
        h('h4', { style: 'margin:22px 0 4px;font-size:15px;' }, '모드별 태그 확인'),
        h('p', { class: 'wml-muted wml-small', style: 'margin:0 0 8px;' }, '모드를 선택하면 현재 장면에 추가하거나 숨긴 태그를 볼 수 있어요.'),
        owners.length
          ? h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;margin:8px 0;' }, ...owners.map(owner => api.ui.button(owner, () => compare(owner), { primary: owner === promptModPreview.owner })))
          : h('p', { class: 'wml-note' }, '현재 연결된 이미지 프롬프트 훅 모드가 없습니다.'),
        promptModPreview.error ? h('p', { class: 'wml-note', role: 'status' }, promptModPreview.error) : null,
        ...scopeEditor,
        promptModPreview.result ? h('div', { 'data-prompt-mod-preview': promptModPreview.owner, role: 'status' },
          h('p', { class: 'wml-small', style: 'margin:10px 0 4px;color:#fcd34d;' },
            `변경 적용 범위: ${selectedScope ? `현재 장면 (${selectedScope})` : '전역'}`),
          rows('이 모드가 넣은 Positive · 포지티브', 'positive', 'current', promptModPreview.result.positive.removed),
          rows('이 모드가 숨긴 Positive · 포지티브', 'positive', 'without', promptModPreview.result.positive.added),
          rows('이 모드가 넣은 Negative · 네거티브', 'negative', 'current', promptModPreview.result.negative.removed),
          rows('이 모드가 숨긴 Negative · 네거티브', 'negative', 'without', promptModPreview.result.negative.added),
          h('details', { 'data-prompt-mod-effective': '' },
            h('summary', {}, '태그 선택을 반영한 프롬프트 보기 (생성 요청 전)'),
            h('p', { class: 'wml-small' }, 'Positive'),
            h('code', { class: 'notranslate', translate: 'no', style: 'display:block;white-space:pre-wrap;overflow-wrap:anywhere;' },
              deduplicateFinalRequest(applyPromptModRules(promptModPreview.result.current))?.prompt || ''),
            h('p', { class: 'wml-small' }, 'Negative'),
            h('code', { class: 'notranslate', translate: 'no', style: 'display:block;white-space:pre-wrap;overflow-wrap:anywhere;' },
              deduplicateFinalRequest(applyPromptModRules(promptModPreview.result.current))?.negativePrompt || ''),
          ),
        ) : owners.length ? h('p', { class: 'wml-note' }, '확인할 모드를 위에서 선택해 주세요.') : null,
        ...addEditor,
        currentPromptModRules().length ? h('details', {
          'data-prompt-mod-saved': '', open: !promptModPreview.result,
        },
        h('summary', {}, `저장된 태그 규칙 (${currentPromptModRules().length})`),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;' },
          ...currentPromptModRules().map(rule => ruleRow(rule.owner, rule.polarity, rule.source, rule.tag, rule.scope)))) : null,
        h('details', { style: 'margin-top:18px;' },
          h('summary', { style: 'cursor:pointer;' }, '비교 방법과 확인할 점'),
          h('p', { class: 'wml-muted wml-small' }, inspector.source === 'wml-dev'
            ? '선택한 모드의 프롬프트 훅을 잠시 제외해 비교한 뒤 복원해요. 다른 모드 훅이 다시 실행되므로 그 훅에 부작용이 있으면 비교 중에도 발생할 수 있어요.'
            : '현재 초상화 장면 기준으로 비교하며 이미지를 생성하지 않아요.'),
          h('p', { class: 'wml-muted wml-small' }, '같은 태그를 여러 모드가 넣으면 출처를 구분할 수 없어 해당 태그 전체에 적용돼요. 훅 밖의 변경은 비교되지 않을 수 있어요.'),
          h('p', { class: 'wml-muted wml-small' }, '한글은 설명용이며 실제 생성에는 영문 태그만 들어가요. 기존 이미지는 자동으로 바뀌지 않아요.'),
          loaded.has('h-status') && !owners.includes('h-status')
            ? h('p', { class: 'wml-note' }, 'h-status는 WML 훅 밖에서 함수를 직접 변경하므로 끈 결과를 안전하게 미리 볼 수 없습니다.') : null,
          requestOwners.length ? h('p', { class: 'wml-note' }, `생성 요청 단계 모드: ${requestOwners.join(', ')} · 실제 생성을 호출할 수 있어 미리보기에서 제외합니다.`) : null,
          h('p', { class: 'wml-muted wml-small' }, 'AIP 자체는 여러 단계에서 바꾸므로 단일 훅 제외 결과로 표시하지 않아요.'),
          inspector.source === 'wml-dev' && globalThis.localStorage?.removeItem
            ? api.ui.button('WML 진단 모드 끄기', () => {
              globalThis.localStorage.removeItem('wml.dev');
              promptModPreview.result = null;
              win.refresh();
            }) : null),
      ];
    }

    const AIP_EDITOR_CSS = `
      .wml-win[data-aip-window] { color-scheme:dark; }
      [data-aip-settings], [data-aip-position] { color:#f5f5f4; font:13px/1.5 system-ui,sans-serif; scrollbar-color:#57534e #1c1917; }
      [data-aip-prompt-review] .wml-small { font-size:13px; line-height:1.5; }
      [data-aip-prompt-review] .wml-muted { color:#d6d3d1; }
      [data-aip-prompt-review] button { min-height:36px; }
      [data-aip-prompt-review] summary { min-height:32px; }
      [data-aip-prompt-review] :is(input,select) { background:#292524; color:#f5f5f4; border:1px solid #78716c; border-radius:6px; padding:8px; font-size:14px; }
      [data-aip-prompt-review] input::placeholder { color:#c5beb4; opacity:1; }
      [data-aip-prompt-review] code { max-height:240px; overflow:auto; font-size:12.5px; line-height:1.5; }
      @media (max-width:640px) { [data-aip-prompt-review] button, [data-aip-prompt-review] select, [data-aip-prompt-review] input { min-height:44px !important; font-size:16px; } }
      [data-aip-settings] :is(button,input,select,textarea):focus-visible,
      [data-aip-position] :is(button,input,select,textarea):focus-visible,
      [data-aip-settings] summary:focus-visible { outline:2px solid #fbbf24; outline-offset:2px; }
      [data-aip-settings] :is(input,select,textarea), [data-aip-position] :is(input,select,textarea) { min-width:0; }
      [data-aip-settings] :is(button,select), [data-aip-position] :is(button,select) { transition:background-color 150ms ease,border-color 150ms ease,color 150ms ease; }
      [data-aip-settings] button:disabled, [data-aip-position] button:disabled { opacity:.48; cursor:not-allowed !important; }
      .wml-win[data-aip-window="settings"] > .wml-win-body { min-height:0; overflow:hidden; }
      [data-aip-settings] { display:grid; grid-template-columns:174px minmax(0,1fr) 278px; grid-template-rows:minmax(0,1fr); gap:14px; height:100%; overflow:hidden; }
      [data-aip-settings][data-aip-has-tools="false"] .aip-editor { grid-column:2 / 4; }
      [data-aip-settings] .aip-nav { min-height:0; overflow-y:auto; overscroll-behavior:contain; padding:2px 10px 6px 0; border-right:1px solid #44403c; }
      [data-aip-settings] .aip-nav > strong { display:block; margin:2px 0 9px; font-size:12px; color:#d6d3d1; }
      [data-aip-settings] .aip-nav [data-aip-tab-list] { display:grid !important; gap:3px !important; margin:0 !important; }
      [data-aip-settings] .aip-nav [data-aip-tab-list] button { width:100%; min-height:34px; padding:6px 9px; text-align:left; border-color:transparent; background:transparent; color:#d6d3d1; }
      [data-aip-settings] .aip-nav [data-aip-tab-list] button:hover { background:#292524; color:#fff; }
      [data-aip-settings] .aip-nav [data-aip-tab-list] button.wml-primary { background:#78350f; border-color:#b45309; color:#fffbeb; }
      [data-aip-settings] .aip-mobile-top { display:none; }
      [data-aip-settings] .aip-nav details { margin-top:13px; border-top:1px solid #44403c; padding-top:11px; }
      [data-aip-settings] .aip-nav summary, [data-aip-settings] .aip-backup summary { cursor:pointer; color:#d6d3d1; font-weight:600; }
      [data-aip-settings] .aip-nav [data-detail-state-grouping] { margin:9px 0 0 !important; padding:8px; }
      [data-aip-settings] .aip-editor { min-width:0; min-height:0; overflow-y:auto; overscroll-behavior:contain; padding-right:6px; }
      [data-aip-settings] .aip-editor > .wml-note { margin:0 0 10px; }
      [data-aip-settings] .aip-editor > .wml-section { margin-top:10px; }
      [data-aip-settings] .aip-plus-offer { border:1px solid #b45309; border-radius:8px; background:#292017; padding:13px; }
      [data-aip-settings] .aip-plus-offer p { margin:7px 0 0; }
      [data-aip-settings] .aip-editor h3 { margin:0 0 5px; font-size:16px; line-height:1.3; }
      [data-aip-settings] .aip-editor textarea { line-height:1.55; }
      [data-aip-settings] .aip-prompt-pair { display:grid; gap:14px; margin:8px 0 14px; }
      [data-aip-settings] .aip-prompt-field { display:grid; gap:5px; min-width:0; font-size:12px; }
      [data-aip-settings] .aip-prompt-field > strong { color:#f5f5f4; font-size:12px; }
      [data-aip-settings] .aip-outfit-layout { display:grid; grid-template-columns:minmax(0,1fr) minmax(250px,36%); gap:14px; align-items:start; }
      [data-aip-settings] .aip-outfit-editor, [data-aip-settings] .aip-outfit-preview { min-width:0; }
      [data-aip-settings] .aip-outfit-preview { position:sticky; top:8px; }
      [data-aip-settings] .aip-state-group { border:1px solid #57534e; border-radius:8px; margin:14px 0; padding:0 12px; }
      [data-aip-settings] .aip-state-group > :is(h4,summary) { margin:0 -12px; padding:9px 12px; background:#292524; border-radius:7px 7px 0 0; font-size:13px; }
      [data-aip-settings] .aip-state-group > summary { cursor:pointer; list-style-position:inside; font-weight:700; }
      [data-aip-settings] .aip-state-row { border-top:1px solid #44403c; padding:14px 0 4px; }
      [data-aip-settings] .aip-state-row > summary { cursor:pointer; list-style-position:inside; padding:2px 0 8px; font-size:13px; font-weight:600; }
      [data-aip-settings] .aip-state-row-head { display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:7px; }
      [data-aip-settings] .aip-state-row-head > strong { font-size:13px; }
      [data-aip-settings] .aip-state-row .aip-prompt-pair { margin:10px 0; }
      [data-aip-settings] .aip-backup { margin-top:16px; border-top:1px solid #44403c; padding-top:11px; }
      [data-aip-settings] .aip-backup > .wml-section { margin-top:10px !important; }
      [data-aip-settings] .aip-rail { min-width:0; min-height:0; overflow-y:auto; overscroll-behavior:contain; }
      [data-aip-settings] .aip-rail-tabs { display:flex; gap:4px; margin-bottom:8px; }
      [data-aip-settings] .aip-rail-tabs button { flex:1; min-height:34px; }
      [data-aip-settings] .aip-rail [data-tag-library],
      [data-aip-settings] .aip-rail [data-prompt-preset-library] { width:100% !important; min-width:0 !important; max-width:none !important; position:relative !important; top:auto !important; height:min(65vh,640px) !important; box-sizing:border-box; }
      [data-aip-position] { display:grid !important; grid-template-columns:minmax(0,1fr) 280px; gap:14px !important; align-items:start; }
      [data-aip-position] > main { min-width:0; }
      [data-aip-position] > [data-tag-library] { width:100% !important; min-width:0 !important; max-width:none !important; position:sticky !important; top:0 !important; height:min(72vh,680px) !important; box-sizing:border-box; }
      [data-aip-position] .aip-mobile-tools { display:none; }
      @media(max-width:1100px) {
        [data-aip-settings] { grid-template-columns:160px minmax(0,1fr) minmax(180px,240px); }
        [data-aip-position] { grid-template-columns:minmax(0,1fr) 240px; }
      }
      @media(max-width:850px) {
        [data-aip-settings] .aip-outfit-layout { grid-template-columns:minmax(0,1fr); }
        [data-aip-settings] .aip-outfit-preview { position:static; }
      }
      @media(max-width:760px) {
        .wml-win[data-aip-window] { width:calc(100vw - 16px) !important; min-width:0 !important; height:calc(100dvh - 16px) !important; left:8px !important; top:8px !important; }
        .wml-win[data-aip-window="settings"] > .wml-win-body { overflow:auto; }
        [data-aip-settings], [data-aip-position] { display:flex !important; flex-direction:column; gap:10px !important; }
        [data-aip-settings] { height:auto; overflow:visible; }
        [data-aip-settings] .aip-nav { display:none; }
        [data-aip-settings] .aip-mobile-top { display:grid !important; gap:7px; width:100%; }
        [data-aip-settings] .aip-editor, [data-aip-settings] .aip-rail { width:100%; overflow:visible; }
        [data-aip-settings] .aip-rail { order:1; }
        [data-aip-settings] .aip-editor { order:2; }
        [data-aip-settings] .aip-rail[data-aip-mobile-open="false"] { display:none; }
        [data-aip-settings] .aip-rail [data-tag-library],
        [data-aip-settings] .aip-rail [data-prompt-preset-library] { height:min(38vh,320px) !important; }
        [data-aip-position] .aip-mobile-tools { display:block; width:100%; }
        [data-aip-position] > main { order:2; width:100%; }
        [data-aip-position] > [data-tag-library] { order:1; width:100%; height:min(38vh,320px) !important; position:relative !important; }
        [data-aip-position][data-aip-mobile-open="false"] > [data-tag-library] { display:none; }
      }
      @media(max-height:650px) { .wml-win[data-aip-window] { max-height:calc(100vh - 16px); } }
      @media(prefers-reduced-motion:reduce) { [data-aip-settings] :is(button,select),[data-aip-position] :is(button,select) { transition:none; } }
    `;

    function prepareAipEditorWindow(win, kind, preferredWidth, preferredHeight) {
      const el = win?.el;
      if (!el || el.__aipEditorPrepared) return;
      el.__aipEditorPrepared = true;
      el.setAttribute?.('data-aip-window', kind);
      const width = Math.max(280, Math.min(preferredWidth, window.innerWidth - 24));
      const height = Math.max(300, Math.min(preferredHeight, window.innerHeight - 24));
      el.style.setProperty('width', `${width}px`);
      el.style.setProperty('height', `${height}px`);
      el.style.setProperty('left', `${Math.max(8, (window.innerWidth - width) / 2)}px`);
      el.style.setProperty('top', `${Math.max(8, (window.innerHeight - height) / 2)}px`);
    }

    function imagePromptPlusStatus() {
      try {
        const wml = globalThis.WML;
        if (!wml?.status || !wml?.currentPreset || !wml?.applyPreset) return null;
        const status = wml.status();
        const id = 'image-prompt-plus';
        if (!status.meta?.[id]) return null;
        let options = {};
        try { options = JSON.parse(localStorage.getItem(`wml.mod.${id}`) || '{}') || {}; } catch {}
        const loaderEnabled = wml.currentPreset('현재 모드 조합').mods.some(mod => mod.id === id);
        const loaded = status.loaded?.includes(id) === true;
        return {
          active: loaderEnabled && loaded && options.enabled === true && options.bridge !== false,
          scheduled: loaderEnabled && options.enabled === true && options.bridge !== false,
        };
      } catch { return null; }
    }

    function renderImagePromptPlusOffer(h, win, dismiss) {
      const state = imagePromptPlusStatus();
      if (!state || state.active && !imagePromptPlusReloadPending) return null;
      return h('section', { class: 'wml-section aip-plus-offer', 'data-aip-image-prompt-plus-offer': '',
        style: 'border:1px solid #b45309;border-radius:8px;background:#292017;padding:13px;' },
        h('strong', {}, state.scheduled ? '이미지 프롬프트 확장 · 적용 대기' : '이미지 프롬프트 확장을 켤까요?'),
        h('p', { class: 'wml-muted wml-small' },
          '이 모드는 추가 대사의 현재 자세·분위기와 손님의 생김새를 AIP에 전달합니다. AIP는 그 정보를 모듈 조합 프롬프트에 반영합니다. 켜기를 선택하면 직접 프롬프트 덧붙이기는 자동으로 설정해 중복을 피합니다.'),
        state.scheduled ? h('p', { class: 'wml-note' }, '켜기로 저장했습니다. 게임을 새로고침하면 적용됩니다. 진행 중인 내용은 먼저 저장해 주세요.') : null,
        imagePromptPlusMessage ? h('p', { class: 'wml-note' }, imagePromptPlusMessage) : null,
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:8px;margin-top:10px;' },
          state.scheduled
            ? api.ui.button('저장 후 새로고침', () => window.location.reload(), { primary: true })
            : api.ui.button('확장 모드 켜기', () => {
              try {
                // shortcut: WML에는 다른 모드 설정 쓰기 API가 없어 저장 형식을 사용한다. 공개 API가 생기면 교체한다.
                const key = 'wml.mod.image-prompt-plus';
                const saved = JSON.parse(localStorage.getItem(key) || '{}');
                if (!saved || typeof saved !== 'object' || Array.isArray(saved)) throw new Error('확장 모드 설정 형식이 올바르지 않습니다.');
                localStorage.setItem(key, JSON.stringify({ ...saved, enabled: true, bridge: true, inject: 'auto' }));
                const preset = globalThis.WML.currentPreset('현재 모드 조합');
                if (!preset.mods.some(mod => mod.id === 'image-prompt-plus')) {
                  globalThis.WML.applyPreset({ ...preset, mods: [...preset.mods, { id: 'image-prompt-plus' }] });
                }
                const updated = imagePromptPlusStatus();
                if (!updated?.scheduled) throw new Error('확장 모드 켜기 상태를 저장하지 못했습니다.');
                imagePromptPlusReloadPending = true;
                imagePromptPlusMessage = '';
              } catch (error) {
                imagePromptPlusMessage = `켜기 실패: ${error.message || error}`;
              }
              win.refresh();
            }, { primary: true }),
          dismiss ? api.ui.button(state.scheduled ? '나중에 새로고침' : '지금은 안 켜기', () => win.close()) : null,
        ));
    }

    function renderErostatPresets(h, win) {
      const key = `erostat.${activeErostatPart === 'anal' ? 'anal' : 'fit'}.${activeErostatBand}`;
      const current = activeSituationConfig();
      const presets = currentErostatPromptPresets();
      const bundleFields = [...EROSTAT_FIT_FIELDS, ...EROSTAT_ANAL_FIELDS];
      const defaultBundle = { id: 'default-erostat', name: '상황별 이미지 프롬프트 기본 · 질·애널 10단계',
        prompts: Object.fromEntries(bundleFields.map(field => [field.key, DEFAULT_PROMPTS[field.key]])),
        negativePrompts: Object.fromEntries(bundleFields.map(field => [field.key, DEFAULT_NEGATIVE_PROMPTS[field.key]])) };
      const breathlessBundle = { id: 'default-erostat-breathless', name: '숨이 막히는 듯 · 질·애널 10단계',
        prompts: Object.fromEntries(bundleFields.map(field => [field.key, EROSTAT_BREATHLESS_PROMPTS[field.key]])),
        negativePrompts: defaultBundle.negativePrompts };
      const savedBundles = currentErostatPromptBundles();
      const bundles = [defaultBundle, breathlessBundle, ...savedBundles];
      const matchesBundle = bundle => bundleFields.every(field => bundle.prompts[field.key] === (current.prompts[field.key] || '')
        && bundle.negativePrompts[field.key] === (current.negativePrompts[field.key] || ''));
      const appliedBundle = bundles.find(bundle => bundle.id === selectedErostatBundleId && matchesBundle(bundle))
        || bundles.find(matchesBundle);
      const selectedBundle = bundles.find(bundle => bundle.id === selectedErostatBundleId) || appliedBundle;
      const bundleStage = appliedBundle && appliedBundle.id !== defaultBundle.id ? {
        id: `${appliedBundle.id}-stage-${key}`,
        name: `${appliedBundle.name} · ${bundleFields.find(field => field.key === key)?.label}`,
        positivePrompt: appliedBundle.prompts[key], negativePrompt: appliedBundle.negativePrompts[key],
      } : null;
      const available = [...(bundleStage ? [bundleStage] : []), ...EROSTAT_DEFAULT_PRESETS, ...presets];
      const matchesStage = preset => preset.positivePrompt === (current.prompts[key] || '')
        && preset.negativePrompt === (current.negativePrompts[key] || '');
      const appliedPreset = available.find(preset => preset.id === selectedErostatPresetId && matchesStage(preset))
        || available.find(matchesStage);
      const selected = available.find(preset => preset.id === selectedErostatPresetId) || appliedPreset;
      const applyBundle = (bundle, label) => {
        const current = activeSituationConfig();
        saveActiveSituationSection('prompts', { ...current.prompts, ...bundle.prompts });
        saveActiveSituationSection('negativePrompts', { ...current.negativePrompts, ...bundle.negativePrompts });
        selectedErostatBundleId = bundle.id;
        selectedErostatPresetId = '';
        settingsMessage = `${label}의 질·애널 10단계 문구를 적용했습니다.`;
        refreshPortraitImage();
        win.refresh();
      };
      const state = api.store.game();
      const fit = currentErostatFit(state, state?.primaryCharacterId, null, activeErostatPart);
      let playerSize = null;
      try { playerSize = globalThis.__waywardSituationEventMod?.playerPenis?.(); } catch {}
      const inputStyle = 'background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;';
      return h('div', { class: 'wml-section', 'data-erostat-preset-tools': '', style: 'display:grid;gap:8px;margin-bottom:12px;' },
        h('p', { class: 'wml-note', 'data-erostat-fit-current': '' }, fit
          ? `현재 ${activeErostatPart === 'anal' ? '애널' : '질'} 삽입 · ${fit.label} · 길이 ${fit.size?.lengthCm ?? '?'}cm / 둘레 ${fit.size?.girthCm ?? '?'}cm`
          : playerSize ? `H-Status 남성기 설정 · 길이 ${playerSize.lengthCm}cm / 둘레 ${playerSize.girthCm}cm · 현재 삽입 판정 없음`
            : '현재 삽입 판정이 없거나 H-Status·에로스테 확장이 꺼져 있습니다.'),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:8px;align-items:center;' },
          h('label', { style: 'display:grid;gap:4px;font-size:12px;' }, '삽입 부위',
            h('select', { value: activeErostatPart, 'data-erostat-preset-part': '', style: inputStyle,
              onchange: event => {
                if (['vaginal', 'anal'].includes(event.currentTarget.value)) activeErostatPart = event.currentTarget.value;
                selectedErostatPresetId = '';
                win.refresh();
              } },
            h('option', { value: 'vaginal', selected: activeErostatPart === 'vaginal' }, '질'),
            h('option', { value: 'anal', selected: activeErostatPart === 'anal' }, '애널'))),
          h('label', { style: 'display:grid;gap:4px;font-size:12px;' }, '편집할 단계',
            h('select', { value: activeErostatBand, 'data-erostat-preset-band': '', style: inputStyle,
              onchange: event => {
                if (EROSTAT_FIT_BANDS.includes(event.currentTarget.value)) activeErostatBand = event.currentTarget.value;
                selectedErostatPresetId = '';
                win.refresh();
              } },
            ...EROSTAT_FIT_FIELDS.map(field => h('option', {
              value: field.key.split('.').at(-1), selected: field.key.endsWith(`.${activeErostatBand}`),
            }, field.label)))),
          h('label', { style: 'display:grid;gap:4px;font-size:12px;' }, '새 프리셋 이름',
            h('input', { type: 'text', value: pendingErostatPresetName, maxLength: 80,
              'data-erostat-preset-name': '', style: inputStyle,
              oninput: event => { pendingErostatPresetName = event.currentTarget.value; } })),
          api.ui.button('현재 단계 문구를 프리셋으로 저장', () => {
            const name = pendingErostatPresetName.trim().slice(0, 80);
            const current = activeSituationConfig();
            const positivePrompt = current.prompts[key] || '';
            const negativePrompt = current.negativePrompts[key] || '';
            if (!name || !positivePrompt.trim() && !negativePrompt.trim() || presets.length >= 50) {
              settingsMessage = presets.length >= 50 ? '프리셋은 최대 50개까지 저장할 수 있습니다.'
                : '프리셋 이름과 Positive 또는 Negative 문구를 입력해 주세요.';
            } else {
              promptPresetCounter += 1;
              selectedErostatPresetId = `fit-${Date.now().toString(36)}-${promptPresetCounter}`;
              api.settings.set({ erostatPromptPresets: [...presets, {
                id: selectedErostatPresetId, name: `${activeErostatPart === 'anal' ? '애널' : '질'} · ${name}`, positivePrompt, negativePrompt,
              }] });
              pendingErostatPresetName = '';
              settingsMessage = `${name} 프리셋을 저장했습니다.`;
            }
            win.refresh();
          })),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:8px;align-items:end;' },
          h('p', { class: 'wml-note', 'data-erostat-preset-applied': '', style: 'flex-basis:100%;margin:0;' },
            `현재 단계 문구: ${appliedPreset?.name || (appliedBundle ? `${appliedBundle.name}에서 적용` : '직접 수정한 문구')}`),
          h('label', { style: 'display:grid;gap:4px;font-size:12px;' }, '기본·사용자 프리셋',
            h('select', { value: selected?.id || '', 'data-erostat-preset-select': '', style: inputStyle,
              onchange: event => { selectedErostatPresetId = event.currentTarget.value; win.refresh(); } },
            h('option', { value: '', selected: !selected }, '단계 프리셋 선택'),
            ...available.map(preset => h('option', { value: preset.id, selected: selected?.id === preset.id }, preset.name)))),
          api.ui.button('선택한 단계에 불러오기', () => {
            if (!selected) return;
            const current = activeSituationConfig();
            saveActiveSituationSection('prompts', { ...current.prompts, [key]: selected.positivePrompt });
            saveActiveSituationSection('negativePrompts', { ...current.negativePrompts, [key]: selected.negativePrompt });
            selectedErostatBundleId = '';
            settingsMessage = `${selected.name} 프리셋을 ${[...EROSTAT_FIT_FIELDS, ...EROSTAT_ANAL_FIELDS].find(field => field.key === key)?.label} 단계에 불러왔습니다.`;
            refreshPortraitImage();
            win.refresh();
          }, { disabled: !selected }),
          api.ui.button('프리셋 삭제', () => {
            if (!selected?.id.startsWith('fit-')) return;
            api.settings.set({ erostatPromptPresets: presets.filter(preset => preset.id !== selected.id) });
            selectedErostatPresetId = '';
            settingsMessage = `${selected.name} 프리셋을 삭제했습니다.`;
            win.refresh();
          }, { disabled: !selected?.id.startsWith('fit-') })),
        h('div', { style: 'display:grid;gap:8px;padding-top:12px;border-top:1px solid #44403c;' },
          h('p', { class: 'wml-note' }, '질·애널 10단계의 Positive와 Negative를 한 묶음으로 저장하거나 불러옵니다.'),
          h('div', { style: 'display:flex;flex-wrap:wrap;gap:8px;align-items:end;' },
            h('label', { style: 'display:grid;gap:4px;font-size:12px;' }, '묶음 이름',
              h('input', { type: 'text', value: pendingErostatBundleName, maxLength: 80,
                'data-erostat-bundle-name': '', style: inputStyle,
                oninput: event => { pendingErostatBundleName = event.currentTarget.value; } })),
            api.ui.button('현재 10단계 묶음 저장', () => {
              const name = pendingErostatBundleName.trim().slice(0, 80);
              if (!name || savedBundles.length >= 50) {
                settingsMessage = savedBundles.length >= 50 ? '묶음 프리셋은 최대 50개까지 저장할 수 있습니다.' : '묶음 이름을 입력해 주세요.';
              } else {
                const current = activeSituationConfig();
                promptPresetCounter += 1;
                selectedErostatBundleId = `bundle-${Date.now().toString(36)}-${promptPresetCounter}`;
                selectedErostatPresetId = '';
                api.settings.set({ erostatPromptBundles: [...savedBundles, { id: selectedErostatBundleId, name,
                  prompts: Object.fromEntries(bundleFields.map(field => [field.key, current.prompts[field.key] || ''])),
                  negativePrompts: Object.fromEntries(bundleFields.map(field => [field.key, current.negativePrompts[field.key] || ''])),
                }] });
                pendingErostatBundleName = '';
                settingsMessage = `${name} 묶음을 저장했습니다.`;
              }
              win.refresh();
            })),
          h('div', { style: 'display:flex;flex-wrap:wrap;gap:8px;align-items:end;' },
            h('p', { class: 'wml-note', 'data-erostat-bundle-applied': '', style: 'flex-basis:100%;margin:0;' },
              `현재 10단계 묶음: ${appliedBundle?.name || '단계별 변경 또는 직접 수정'}`),
            h('label', { style: 'display:grid;gap:4px;font-size:12px;' }, '기본·저장된 묶음',
              h('select', { value: selectedBundle?.id || '', 'data-erostat-bundle-select': '', style: inputStyle,
                onchange: event => { selectedErostatBundleId = event.currentTarget.value; win.refresh(); } },
              h('option', { value: '', selected: !selectedBundle }, '묶음 프리셋 선택'),
              ...bundles.map(bundle => h('option', { value: bundle.id, selected: selectedBundle?.id === bundle.id }, bundle.name)))),
            api.ui.button('선택한 묶음 불러오기', () => {
              if (selectedBundle) applyBundle(selectedBundle, selectedBundle.name);
            }, { disabled: !selectedBundle }),
            api.ui.button('묶음 삭제', () => {
              if (!selectedBundle) return;
              if (selectedBundle.id.startsWith('default-')) return;
              api.settings.set({ erostatPromptBundles: savedBundles.filter(bundle => bundle.id !== selectedBundle.id) });
              selectedErostatBundleId = '';
              settingsMessage = `${selectedBundle.name} 묶음을 삭제했습니다.`;
              win.refresh();
            }, { disabled: !selectedBundle || selectedBundle.id.startsWith('default-') }))),
      );
    }

    const expandedStateSections = new Set();
    let settingsNavScrollTop = 0;
    let settingsEditorScrollTop = 0;
    let settingsRailScrollTop = 0;

    function renderSettings(body, win) {
      registerImageRequestWindow(win);
      prepareAipEditorWindow(win, 'settings', 1320, 840);
      const h = api.ui.h;
      const field = (definition, outfitStates) => {
        const save = (polarity, value, updateView = true) => {
          const setting = polarity === 'negative' ? 'negativePrompts' : 'prompts';
          const current = activeSituationConfig()[setting];
          saveActiveSituationSection(setting, { ...current, [definition.key]: value });
          if (definition.key.startsWith('erostat.')) {
            selectedErostatPresetId = '';
            selectedErostatBundleId = '';
          }
          if (updateView) win.refresh();
        };
        const reset = () => {
          const current = activeSituationConfig();
          saveActiveSituationSection('prompts', { ...current.prompts, [definition.key]: DEFAULT_PROMPTS[definition.key] });
          saveActiveSituationSection('negativePrompts', { ...current.negativePrompts, [definition.key]: DEFAULT_NEGATIVE_PROMPTS[definition.key] });
          saveActiveSituationSection('outfitStates', { ...current.outfitStates, [definition.key]: [...DEFAULT_OUTFIT_STATES[definition.key]] });
          if (definition.key.startsWith('erostat.')) {
            selectedErostatPresetId = '';
            selectedErostatBundleId = '';
          }
          activeTagTarget = null;
          settingsMessage = `${definition.label} 항목을 기본값으로 되돌렸습니다.`;
          win.refresh();
        };
        const promptInput = polarity => {
          const setting = polarity === 'negative' ? 'negativePrompts' : 'prompts';
          const value = situationConfig[setting][definition.key] || '';
          return h('label', { class: 'aip-prompt-field' },
            h('strong', {}, polarity === 'negative' ? 'Negative · 피할 표현' : 'Positive · 넣을 표현'),
            h('textarea', {
              rows: definition.rows || 2, value, spellcheck: false,
              'data-aip-field-prompt': `${definition.key}:${polarity}`,
              style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:52px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
              onfocus: () => { activeTagTarget = definition.key.endsWith('.map') ? null : {
                kind: 'field', key: definition.key, polarity, label: `${definition.label} ${polarity === 'negative' ? 'Negative' : 'Positive'}`,
              }; },
              oninput: event => { save(polarity, event.currentTarget.value, false); updatePromptTagPreview(event, h, win); },
              onchange: event => save(polarity, event.currentTarget.value),
            }),
            promptTagPreview(h, value, win),
            definition.key.endsWith('.map') ? null : promptTagAdder(h, value,
              next => save(polarity, next), polarity === 'negative' ? `${definition.key}:negative` : definition.key));
        };
        const collapsible = (activeGroup.fields?.length || 0) > 3;
        const rowId = `${activeGroup.id}:${definition.key}`;
        return h(collapsible ? 'details' : 'div', { class: 'aip-state-row', 'data-aip-state-row': definition.key,
          ...(collapsible ? { open: expandedStateSections.has(rowId),
            ontoggle: event => { event.currentTarget.open ? expandedStateSections.add(rowId) : expandedStateSections.delete(rowId); } } : {}),
        },
          collapsible ? h('summary', {}, definition.label) : h('div', { class: 'aip-state-row-head' }, h('strong', {}, definition.label),
            api.ui.button('이 항목 전체 기본값으로', reset)),
          collapsible ? h('div', { class: 'aip-state-row-head' }, api.ui.button('이 항목 전체 기본값으로', reset)) : null,
          definition.hint ? h('p', { class: 'wml-muted wml-small' }, definition.hint) : null,
          outfitStateChecks(h, outfitStates[definition.key], states => {
            saveActiveSituationSection('outfitStates', { ...activeSituationConfig().outfitStates, [definition.key]: states });
            win.refresh();
          }, definition.key, /^(?:fluid|jewelry|toy|cycle)\./.test(definition.key)),
          h('div', { class: 'aip-prompt-pair' }, promptInput('positive'), promptInput('negative')),
        );
      };
      const groupedFields = () => {
        const fields = activeGroup.fields || [];
        if (!['detail', 'h-status', 'marks'].includes(activeGroup.id)) return fields.map(definition => field(definition, outfitStates));
        const groups = new Map();
        for (const definition of fields) {
          const parts = definition.key.split('.');
          const id = parts.slice(0, 2).join('.');
          if (!groups.has(id)) {
            const label = definition.label.split(' · ')[0].split(/\s+\d/)[0];
            const title = activeGroup.id === 'h-status'
              ? `${{ fluid: '부위별 흔적', jewelry: '장신구', toy: '삽입 토이' }[parts[0]] || parts[0]} · ${label}`
              : activeGroup.id === 'marks' ? `${label} 흔적` : label;
            groups.set(id, { title, fields: [] });
          }
          groups.get(id).fields.push(definition);
        }
        return [...groups].map(([id, group]) => h('details', { class: 'aip-state-group', 'data-aip-state-group': id,
          open: expandedStateSections.has(`${activeGroup.id}:${id}`),
          ontoggle: event => { const key = `${activeGroup.id}:${id}`; event.currentTarget.open ? expandedStateSections.add(key) : expandedStateSections.delete(key); },
        },
          h('summary', {}, `${group.title} · ${group.fields.length}개 상태`),
          ...group.fields.map(definition => field(definition, outfitStates))));
      };
      const situationConfig = activeSituationConfig();
      const outfitStates = situationConfig.outfitStates;
      const externalMenus = externalPromptMenus();
      const settingsTabs = [...SETTINGS_TABS, ...externalMenus.map(menu => ({
        id: `external:${menu.id}`, title: menu.title, note: menu.note, externalMenu: menu,
      }))];
      const activeGroup = settingsTabs.find(group => group.id === activeSettingsTab) || settingsTabs[0];
      const gameState = activeGroup.id === 'pregnancy' ? api.store.game() : null;
      const fileInput = h('input', {
        type: 'file',
        accept: '.json,application/json',
        style: 'display:none;',
        onchange: async event => {
          const input = event.currentTarget;
          const file = input.files?.[0];
          if (!file) return;
          try {
            const parsed = JSON.parse(await file.text());
            if (parsed.scope === 'tab') {
              if (activeSettingsTab !== activeGroup.id) throw Error('편집 탭이 바뀌었습니다. 다시 불러오세요.');
              importTabJson(parsed, activeGroup);
            } else api.settings.set(importPromptSettings(JSON.stringify(parsed)));
            reloadButtonPromptSettings();
            reloadPromptModRules();
            reloadGlobalPromptExclusions();
            reloadSceneBaseOverrides();
            reloadSceneCandidatePools();
            reloadCameraSettings();
            reloadSceneStatePromptOverrides();
            reloadStateEditorGlobalChanges();
            syncCustomOutfits();
            selectedErostatPresetId = '';
            selectedErostatBundleId = '';
            legacyDetailImageKeys.clear();
            publishCurrentWifePromptProfile();
            if (parsed.scope !== 'tab') syncFluidDecay(true);
            settingsMessage = `${file.name || '파일'}에서 설정을 가져왔습니다.`;
          } catch (error) {
            settingsMessage = `가져오기 실패: ${error.message || error}`;
          }
          input.value = '';
          win.refresh();
        },
      });
      const chooseTab = group => {
        activeSettingsTab = group.id;
        if (group.id === 'erostat') {
          selectedErostatPresetId = '';
          selectedErostatBundleId = '';
          const state = api.store.game();
          const fit = currentErostatFit(state, state?.primaryCharacterId);
          if (['vaginal', 'anal'].includes(fit?.hole)) activeErostatPart = fit.hole;
          activeErostatBand = fit?.band || activeErostatBand;
        }
        if (group.id === 'climax-prompts') {
          activePositionModuleSection = 'climax';
          activePositionModuleGroup = '';
          activePositionModuleEditorId = 'climax-1';
        }
        activeTagTarget = group.id === 'climax-prompts'
          ? { kind: 'position-module', id: 'climax-1', field: 'positivePrompt', label: '아내 절정 · 1회 이상 Positive' }
          : null;
        win.refresh();
        if (group.id === 'diagnostics' && !diagnostics.checkedAt) queueMicrotask(() => { void runDiagnostics(win, true); });
      };
      const content = [
        activeGroup.externalMenu || ['diagnostics', 'cycle-debug', 'image-pack', 'prompt-mods', 'scene-prompts', 'button-prompts', 'climax-prompts', 'image-keys'].includes(activeGroup.id) ? null : h('label', {
          'data-detail-state-grouping': '',
          class: 'wml-section',
          style: 'display:flex;align-items:flex-start;gap:8px;margin-bottom:10px;cursor:pointer;',
        },
        h('input', {
          type: 'checkbox',
          checked: groupSimilarDetailStates(),
          'data-detail-state-grouping-toggle': '',
          onchange: event => {
            api.settings.set({ groupSimilarDetailStates: event.currentTarget.checked });
            legacyDetailImageKeys.clear();
            settingsMessage = event.currentTarget.checked
              ? '비슷한 상세 상태를 대표 이미지 묶음으로 재사용합니다.'
              : '상세 상태 조합마다 별도 이미지를 사용합니다.';
            win.refresh();
          },
        }),
        h('span', {},
          h('strong', {}, '비슷한 상세 상태 이미지 묶기'),
          h('span', { class: 'wml-muted wml-small', style: 'display:block;margin-top:3px;' }, '기력·기분·감정·욕구 등의 상세 수치를 6가지 시각 상태로 묶습니다. 피어싱·토이·수갑·의상·체위는 계속 따로 구분합니다.'),
        )),
        activeGroup.externalMenu || ['situation-presets', 'scene-prompts', 'button-prompts', 'positions', 'climax-prompts', 'diagnostics', 'cycle-debug', 'image-pack', 'prompt-mods', 'image-keys'].includes(activeGroup.id) ? null : h('p', { class: 'wml-note' }, activeGroup.id === 'game-default'
          ? '생성 설정 변화폭과 모든 장면의 공통 Positive·Negative를 조절합니다. 아내·장면·의상별 태그는 따로 유지됩니다.'
          : activeGroup.id === 'character'
          ? '현재 아내의 전체 Positive·Negative 외형을 확인하고 교체합니다. 장면·의상·상태 프롬프트는 그대로 유지됩니다.'
          : activeGroup.id === 'outfit-prompts'
            ? '등록된 의상의 Positive·Negative를 확인하고 교체합니다. 수정된 의상은 기존 캐시와 다른 이미지 상황으로 생성됩니다.'
            : 'Positive와 Negative를 각각 설정할 수 있습니다. 빈 값은 해당 조건의 추가를 끕니다. 옷 상태 제한은 현재 이미지의 outfit 상태를 확인합니다.'),
        null,
        h('div', { 'data-aip-tab-list': '', style: 'display:flex;flex-wrap:wrap;gap:6px;margin:10px 0;' },
          ...settingsTabs.map(group => api.ui.button(group.id === 'image-keys'
            ? `이미지 파일명 · ${shortImageKeysEnabled() ? '켜짐' : '꺼짐'}` : group.title, () => chooseTab(group),
            { primary: group.id === activeGroup.id })),
        ),
        !activeGroup.externalMenu && !['game-default', 'character', 'outfit-prompts', 'situation-presets', 'scene-prompts', 'button-prompts', 'positions', 'climax-prompts', 'diagnostics', 'cycle-debug', 'image-pack', 'prompt-mods', 'image-keys'].includes(activeGroup.id)
          ? h('div', { 'data-active-situation-preset': situationConfig.id, class: 'wml-note', style: 'margin-bottom:10px;' }, `편집 중인 상황 프리셋 · ${situationConfig.name}`)
          : null,
        h('section', { class: 'wml-section' },
          h('h3', { style: 'margin:0 0 6px;' }, activeGroup.title),
          h('p', { class: 'wml-muted wml-small' }, activeGroup.note),
          ['pregnancy', 'marks', 'cycle', 'sleep', 'firstExperience', 'erostat'].includes(activeGroup.id) ? h('label', {
            class: 'wml-note', style: 'display:flex;align-items:center;gap:8px;cursor:pointer;',
          }, h('input', { type: 'checkbox', checked: currentFeaturePrompts()[activeGroup.id],
            'data-aip-feature-toggle': activeGroup.id,
            onchange: event => {
              api.settings.set({ featurePrompts: { ...currentFeaturePrompts(), [activeGroup.id]: event.currentTarget.checked } });
              refreshPortraitImage();
              win.refresh();
            },
          }), `${activeGroup.title} 프롬프트 전체 적용`) : null,
          activeGroup.id === 'pregnancy' ? h('p', { class: 'wml-note', 'data-pregnancy-state': '' },
            `현재 아내 · ${activePregnancyField(gameState, gameState?.primaryCharacterId)?.label.split(' · ')[0] || '미임신 또는 임신 모드 비활성'}`) : null,
          activeGroup.id === 'positions' ? h('label', { class: 'wml-note',
            style: 'display:flex;align-items:center;gap:8px;cursor:pointer;' },
          h('input', { type: 'checkbox', checked: guestAppearanceEnabled(), 'data-aip-guest-appearance': '',
            onchange: event => {
              api.settings.set({ guestAppearance: event.currentTarget.checked });
              refreshPortraitImage();
              win.refresh();
            },
          }), '추가대사 손님 외형 반영 · 화풍·배경 태그 제외') : null,
          activeGroup.id === 'image-keys' ? h('div', {},
            h('label', { class: 'wml-note', style: 'display:flex;align-items:center;gap:8px;cursor:pointer;' },
              h('input', { type: 'checkbox', checked: shortImageKeysEnabled(), 'data-aip-short-image-keys': '',
                onchange: event => {
                  const enabled = event.currentTarget.checked;
                  settingsMessage = saveShortImageKeys(enabled) ? '' : '파일명 축약 설정을 저장하지 못했어요. 브라우저의 저장 공간과 저장 허용 설정을 확인한 뒤 다시 시도해 주세요.';
                  win.refresh();
                },
              }), '다른 모드 태그까지 추가 축약'),
            h('p', { class: 'wml-note' }, '이점: 다른 모드의 태그가 뒤에 붙어 다시 길어진 최종 생성 키를 줄여 파일명 길이로 인한 실패를 줄입니다. AIP 자체의 기존 키 축약은 이 설정과 관계없이 유지됩니다. 실제 Positive·Negative 프롬프트와 이미지별 저장 정보는 유지합니다.'),
            h('p', { class: 'wml-note' }, '주의: 켠 뒤에도 기존 긴 키 이미지를 먼저 조회하고, 다시 꺼도 축약한 이미지를 조회해 재사용합니다. 새 이미지는 별도의 짧은 파일명으로 저장되므로 외부 도구·직접 만든 이미지팩의 파일명 연결은 달라질 수 있습니다. 끄더라도 이미 저장된 파일명은 되돌리지 않습니다.'),
            h('p', { class: 'wml-note' }, 'AIP가 처리하는 초상화·조건부 생성에만 적용됩니다. 이미지 스튜디오의 직접 일괄 요청에는 적용되지 않습니다.')) : null,
          activeGroup.id === 'climax-prompts' && positionMode() !== 'modules'
            ? h('p', { class: 'wml-note', 'data-climax-mode-note': '' }, '현재는 기존 체위 변경 방식입니다. 태그 수정은 저장되며 모듈 조합으로 전환하면 적용됩니다.') : null,
           ...(activeGroup.externalMenu
             ? renderExternalPrompts(h, win, activeGroup.externalMenu)
             : activeGroup.id === 'prompt-mods'
            ? [h('div', { 'data-aip-prompt-review': '' }, ...renderPromptMods(h, win))]
            : activeGroup.id === 'image-pack'
            ? renderImagePack(h, win)
            : activeGroup.id === 'cycle-debug'
            ? renderCycleDebugger(h, win)
            : activeGroup.id === 'image-keys'
            ? []
            : activeGroup.id === 'diagnostics'
            ? renderDiagnostics(h, win)
            : activeGroup.id === 'situation-presets'
              ? renderSituationPresets(h, win)
             : activeGroup.id === 'scene-prompts'
               ? renderScenePrompts(h, win)
             : activeGroup.id === 'button-prompts'
               ? [renderButtonPrompts(h, win)]
            : activeGroup.id === 'positions'
              ? renderPositionSettings(h, win)
            : activeGroup.id === 'climax-prompts'
              ? renderPositionModuleSettings(h, win, true)
            : activeGroup.id === 'dialogue'
              ? renderDialogueRules(h, win)
              : activeGroup.id === 'game-default'
                ? renderGameDefaultPrompt(h, win)
              : activeGroup.id === 'character'
                ? renderCharacterPrompt(h, win)
                : activeGroup.id === 'outfit-prompts'
                  ? renderOutfitPrompt(h, win)
                 : activeGroup.id === 'erostat'
                   ? [renderErostatPresets(h, win), field(activeGroup.fields.find(definition => definition.key === `erostat.${activeErostatPart === 'anal' ? 'anal' : 'fit'}.${activeErostatBand}`), outfitStates)]
                 : activeGroup.id === 'h-status'
                  ? [renderFluidDecaySettings(h, win), ...groupedFields()]
                  : groupedFields()),
        ),
        ['diagnostics', 'cycle-debug', 'image-pack', 'prompt-mods'].includes(activeGroup.id) ? null : h('div', { class: 'wml-section', style: 'margin-top:10px;' },
          h('strong', { style: 'font-size:12px;' }, 'JSON 내보내기 항목'),
          h('p', { class: 'wml-muted wml-small', style: 'margin:4px 0 8px;' }, '직접 추가한 태그는 Positive 또는 Negative 프롬프트에 포함됩니다.'),
          h('div', { style: 'display:flex;flex-wrap:wrap;gap:8px 14px;' },
            ...[
              ['wives', '사용자 생성 아내'],
              ['gameDefaultPrompts', '게임 기본 설정 프롬프트'],
              ['characterPrompt', '현재 아내 외형 프롬프트'],
              ['outfitPrompts', '의상별 프롬프트'],
              ['customOutfits', '사용자 의상'],
              ['situationPresets', '상황 프리셋·캐릭터 배정'],
              ['positionPresetPrompts', '체위 프롬프트 프리셋'],
              ['positionGroupPrompts', '추가 인원 배치 프롬프트'],
              ['positionStatePrompts', '상황별 상태 추가 프롬프트'],
              ['sceneBaseOverrides', '게임 기본 장면 프롬프트 수정'],
              ['cameraSettings', '장면별 카메라 구도와 이미지 기록'],
              ['sceneStatePromptOverrides', '장면별 상태 프롬프트 수정'],
              ['buttonPromptRules', '선택지 프롬프트'],
              ['positionModules', '모듈 조합·장면별 선택·다대일 배치'],
              ['positionRules', '상황별 체위 고정'],
              ['promptModRules', '모드 영향 태그 반영·수정'],
              ['externalPrompts', '다른 모드 프롬프트·프리셋'],
              ['featurePrompts', '임신·생리·수면·손찌검·첫경험·에로스테 프롬프트 전체 적용'],
              ['shortImageKeys', '최종 이미지 키 추가 축약'],
              ['generationWeight', '프롬프트 길이별 생성 설정'],
              ['prompts', 'Positive 프롬프트'],
              ['negativePrompts', 'Negative 프롬프트'],
              ['outfitStates', '옷 상태 제한'],
              ['dialogueRules', '대화 감지 규칙'],
              ['fluidDecay', 'H Status 정액 상태 완화'],
              ['residueGenerationProvider', '비밀 탭 이미지 생성 제공자'],
              ['hStatusGenerationModes', 'H Status 부위별 생성 방식'],
              ['residuePrompts', '잔류 상태 카드 프롬프트'],
              ['residuePartSources', '잔류 상태 부위별 이미지 방식'],
              ['customTags', '사용자 태그 라이브러리'],
              ['promptPresets', '사용자 프롬프트 프리셋'],
               ['erostatPromptPresets', '에로스테 크기 문구 프리셋'],
               ['erostatPromptBundles', '에로스테 10단계 묶음 프리셋'],
            ].map(([key, label]) => h('label', { style: 'display:flex;align-items:center;gap:5px;font-size:12px;' },
              h('input', {
                type: 'checkbox',
                checked: exportSections[key],
                'data-export-section': key,
                onchange: event => { exportSections[key] = event.currentTarget.checked; },
              }),
              label,
            )),
          ),
        ),
        ['diagnostics', 'cycle-debug', 'image-pack', 'prompt-mods'].includes(activeGroup.id) ? null : h('div', { class: 'wml-section', style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-top:10px;' },
          api.ui.button('JSON 내보내기', () => {
            settingsMessage = exportPrompts()
              ? '선택한 설정을 JSON 파일로 내보냈습니다.'
              : '내보낼 항목을 하나 이상 선택해 주세요.';
            win.refresh();
          }),
          api.ui.button('아내만 내보내기', () => {
            exportPrompts(['wives']);
            settingsMessage = '사용자 생성 아내를 JSON 파일로 내보냈습니다.';
            win.refresh();
          }),
          api.ui.button('상황 프리셋만 내보내기', () => {
            exportPrompts(['situationPresets']);
            settingsMessage = '상황 프롬프트 프리셋과 캐릭터 배정을 JSON 파일로 내보냈습니다.';
            win.refresh();
          }),
          api.ui.button('잔류 상태만 내보내기', () => {
            exportPrompts(['residueGenerationProvider', 'hStatusGenerationModes', 'residuePrompts', 'residuePartSources']);
            settingsMessage = '잔류 상태 카드 프롬프트와 생성·부위별 이미지 방식을 JSON 파일로 내보냈습니다.';
            win.refresh();
          }),
          api.ui.button('JSON 가져오기', () => fileInput.click()),
          api.ui.button('모든 프롬프트를 기본값으로 복원', () => {
            api.settings.set({
              characterPrompt: { ...DEFAULT_CHARACTER_PROMPT },
              globalPromptExclusions: '',
              globalPromptExclusionsPositive: '',
              globalPromptExclusionsNegative: '',
              outfitPrompts: {},
              situationPresets: [],
              situationPresetAssignments: {},
              positionPresetPrompts: {},
              positionGroupPrompts: {},
              positionStatePrompts: {},
              sceneBaseOverrides: {},
              sceneCandidatePools: {},
              cameraSceneSettings: {},
              cameraImageMetadata: {},
              sceneStatePromptOverrides: {},
              stateEditorGlobalChanges: {},
              buttonPromptRules: [],
              positionTargetNegativePrompts: {},
              positionMode: 'legacy',
              positionModules: [],
              positionModuleGroupLayouts: {},
              positionModuleSelections: {},
              positionModulePoseAssignments: {},
              positionRules: {},
              positionRuleDefaults: {},
              autoPositionPresets: false,
              prompts: { ...DEFAULT_PROMPTS },
              negativePrompts: { ...DEFAULT_NEGATIVE_PROMPTS },
              outfitStates: { ...DEFAULT_OUTFIT_STATES },
              dialogueRules: DEFAULT_DIALOGUE_RULES.map(rule => ({ ...rule, outfitStates: [...rule.outfitStates] })),
              fluidDecay: { ...DEFAULT_FLUID_DECAY },
              residueGenerationProvider: 'aip',
              hStatusGenerationModes: { ...DEFAULT_H_STATUS_GENERATION_MODES },
              hStatusImg2Img: true,
              residuePrompts: {},
              residuePartSources: normalizeResiduePartSources({}),
              customTags: [],
              promptPresets: [],
               externalPromptData: [],
               externalPromptPresets: [],
              groupSimilarDetailStates: true,
            });
            reloadButtonPromptSettings();
            reloadGlobalPromptExclusions();
            reloadSceneBaseOverrides();
            reloadSceneCandidatePools();
            reloadCameraSettings();
            reloadSceneStatePromptOverrides();
            reloadStateEditorGlobalChanges();
            publishCurrentWifePromptProfile();
            activeSituationPresetId = LEGACY_SITUATION_PRESET_ID;
            clearPositionOverrides();
            positionRandomChoices.clear();
            positionPlacementDrafts.clear();
            positionGeneratedResults.clear();
            legacyDetailImageKeys.clear();
            positionSelection = { situationId: latestScenePrompt?.situationId || '', presetId: '', groupSlots: '', details: null };
            syncFluidDecay(true);
            settingsMessage = '모든 프롬프트를 기본값으로 복원했습니다.';
            win.refresh();
          }),
          fileInput,
        ),
        !['diagnostics', 'cycle-debug'].includes(activeGroup.id) && settingsMessage ? h('p', { class: 'wml-note', style: 'margin-top:8px;' }, settingsMessage) : null,
      ];
      const showTagLibrary = !['situation-presets', 'diagnostics', 'cycle-debug', 'image-pack', 'prompt-mods'].includes(activeGroup.id);
      const showPromptPresets = showTagLibrary && !['positions', 'climax-prompts', 'button-prompts'].includes(activeGroup.id);
      const [groupingControl, introNote, polarityControl, tabList, presetNotice,
        settingsSection, exportOptions, exportActions, feedback] = content;
      const navigation = h('nav', { class: 'aip-nav', 'aria-label': '설정 항목',
        onscroll: event => { settingsNavScrollTop = event.currentTarget.scrollTop; } },
        h('strong', {}, '설정 항목'), tabList);
      const mobileNavigation = h('div', { class: 'aip-mobile-top' },
        h('label', { style: 'display:grid;gap:4px;' },
          h('strong', {}, '설정 항목'),
          h('select', { value: activeGroup.id, 'data-aip-mobile-tab': '',
            style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:8px;',
            onchange: event => chooseTab(settingsTabs.find(group => group.id === event.currentTarget.value) || settingsTabs[0]),
          }, ...settingsTabs.map(group => h('option', { value: group.id, selected: group.id === activeGroup.id }, group.title)))),
        showTagLibrary ? h('button', { type: 'button', class: 'wml-btn',
          'data-aip-mobile-tools': '', 'aria-expanded': mobileSettingsToolsOpen ? 'true' : 'false',
          onclick: () => { mobileSettingsToolsOpen = !mobileSettingsToolsOpen; win.refresh(); },
        }, mobileSettingsToolsOpen ? '태그 도구 접기' : '태그 도구 열기') : null);
      const plusOffer = renderImagePromptPlusOffer(h, win, false);
      const mainPanel = h('main', { class: 'aip-editor',
        onscroll: event => { settingsEditorScrollTop = event.currentTarget.scrollTop; } },
        activeGroup.id === 'prompt-mods' ? null : plusOffer,
        renderTabJson(h, win, activeGroup), introNote, polarityControl, presetNotice, feedback, settingsSection,
        activeGroup.id === 'prompt-mods' && plusOffer ? h('details', { class: 'aip-backup' },
          h('summary', {}, '이미지 프롬프트 확장 안내'), plusOffer) : null,
        groupingControl ? h('details', { class: 'aip-backup' },
          h('summary', {}, '이미지 상태 묶기'), groupingControl) : null,
        exportOptions || exportActions ? h('details', { class: 'aip-backup' },
          h('summary', {}, '설정 JSON 백업·복원'), exportOptions, exportActions) : null);
      const sidePanel = showTagLibrary ? h('aside', { class: 'aip-rail',
        'data-aip-mobile-open': mobileSettingsToolsOpen ? 'true' : 'false',
        onscroll: event => { settingsRailScrollTop = event.currentTarget.scrollTop; },
        'aria-label': '프롬프트 도구' },
        showPromptPresets ? h('div', { class: 'aip-rail-tabs', role: 'group', 'aria-label': '도구 종류' },
          ...[['tags', '태그'], ['presets', '프리셋']].map(([id, label]) => h('button', {
            type: 'button', class: `wml-btn${activeSettingsRail === id ? ' wml-primary' : ''}`,
            'data-aip-rail-tab': id, 'aria-pressed': activeSettingsRail === id ? 'true' : 'false',
            onclick: () => { activeSettingsRail = id; win.refresh(); },
          }, label))) : null,
        h('div', { 'data-aip-rail-panel': 'tags', hidden: showPromptPresets && activeSettingsRail === 'presets' },
          renderTagLibrary(h, win)),
        showPromptPresets ? h('div', { 'data-aip-rail-panel': 'presets', hidden: activeSettingsRail !== 'presets' },
          renderPromptPresetLibrary(h, win)) : null) : null;
      body.replaceChildren(h('style', { 'data-aip-editor-style': '' }, AIP_EDITOR_CSS),
        h('div', { 'data-aip-settings': '', 'data-aip-has-tools': showTagLibrary ? 'true' : 'false' },
          navigation, mobileNavigation, mainPanel, sidePanel));
      queueMicrotask(() => {
        const nav = body.querySelector?.('.aip-nav');
        const editor = body.querySelector?.('.aip-editor');
        const rail = body.querySelector?.('.aip-rail');
        if (nav) nav.scrollTop = settingsNavScrollTop;
        if (editor) editor.scrollTop = settingsEditorScrollTop;
        if (rail) rail.scrollTop = settingsRailScrollTop;
        const tagLibrary = body.querySelector?.('[data-tag-library]');
        const presetLibrary = body.querySelector?.('[data-prompt-preset-library]');
        if (tagLibrary) tagLibrary.scrollTop = tagLibraryScrollTop;
        if (presetLibrary) presetLibrary.scrollTop = promptPresetLibraryScrollTop;
      });
    }
