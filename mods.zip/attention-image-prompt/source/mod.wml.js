// 원제작자: aaajjaaaadsfa(papalae)
// 원글: https://kone.gg/s/somisoft/d7dNsfio5zS0D3neJOhkeb
// 수정자: HL — AIP 1.77.0 원본의 ImageStudio 통합 호환판.
WML.define({
  id: 'attention-image-prompt',
  name: '상황별 이미지 프롬프트',
  version: "1.79.2",
  game: "2026-11-01",
  description: '상태·대화·체위·아내 캐릭터·의상의 이미지 프롬프트와 사용자 아내 등록을 관리합니다.',
  loadAfter: ['addon-compat', 'outfit', 'badguest', 'h-status', 'pregnancy', 'image-look', 'virginity-status'],
  loadBefore: ['prompt-manager'],
  role: 'scene-prompt',
  author: 'aaajjaaaadsfa(papalae) · HL', tags: ['image', 'prompt'],

  symbols: {
    "playerSexChoose": {"raw":{"2026-11-01":"SOe"},"doc":"당신 장면 선택 처리","optional":true},
    "attentionSituations": {"raw":{"2026-11-01":"lV"},"doc":"대응이 필요한 상황 목록을 구조화된 상태로 계산"},
    "effectiveHeroineStats": {"raw":{"2026-11-01":"Yoe"},"doc":"상세 상태 영역에 표시하는 주인공의 유효 기력 기분 흥분도 계산"},
    "relationshipPanelStatus": {"raw":{"2026-11-01":"vv"},"doc":"상세 상태 영역에 표시하는 신뢰 욕망 원망 이탈 허용 상태 계산"},
    "topFeelings": {"raw":{"2026-11-01":"i_"},"doc":"인물의 강한 감정을 세기 순서로 조회"},
    "wellbeingSignals": {"raw":{"2026-11-01":"Pv"},"doc":"상세 상태 영역의 심신 상태 저하 신호 계산"},
    "intoxicationBand": {"raw":{"2026-11-01":"Sn"},"doc":"취기 수치를 화면 표시 단계로 변환"},
    "imageLookup": {"raw":{"2026-11-01":"vy"},"doc":"이미지 키에 맞는 팩 항목 또는 가장 가까운 대체 항목 조회"},
    "outfitList": {"raw":{"2026-11-01":"Oi"},"doc":"기본 게임과 다른 모드가 함께 등록하는 의상 정의 목록","optional":true},
    "customWifeStore": {"raw":{"2026-11-01":"sd"},"doc":"사용자 생성 아내 등록 저장소와 아내 프롬프트 구성"},
    "nativeInstalledImagePacks": {"raw":{"2026-11-01":"by"},"doc":"원본 IndexedDB 이미지팩 조회","optional":true},
    "nativeInstalledPackEntries": {"raw":{"2026-11-01":"Tot"},"doc":"원본 이미지팩 항목과 우선순위 변환","optional":true},
    "wifeBuilderDefaults": {"raw":{"2026-11-01":"Yq"},"doc":"사용자 생성 아내 등록 저장소와 아내 프롬프트 구성"},
    "buildWifeArchetype": {"raw":{"2026-11-01":"SE"},"doc":"사용자 생성 아내 등록 저장소와 아내 프롬프트 구성"},
    "wifeArchetypeById": {"raw":{"2026-11-01":"$m"},"doc":"아내 archetype id로 기본 외형과 배경 정보 조회"},
    "wifePicker": {"raw":{"2026-11-01":"qit"},"doc":"새 게임에서 기본·사용자 아내를 선택하고 사용자 아내 생성기를 여는 화면"},
    "wifeBuilder": {"raw":{"2026-11-01":"elt"},"doc":"사용자 아내의 정보와 전체 외형 프롬프트를 편집하는 화면"},
    "newGameState": {"raw":{"2026-11-01":"fc"},"optional":true,"doc":"새 게임 상태 생성"},
    "wifePreviewBundle": {"raw":{"2026-11-01":"WL"},"doc":"사용자 아내 미리보기의 Positive·Negative 프롬프트 구성"},
    "wifeCharacterFromArchetype": {"raw":{"2026-11-01":"RZe"},"doc":"선택한 아내 원형으로 실제 게임 캐릭터를 생성"},
    "pauseMenu": {"raw":{"2026-11-01":"fit"},"doc":"일시 정지 메뉴 화면","optional":true},
    "imageVariantState": {"raw":{"2026-11-01":"NB"},"doc":"이미지 키별 생성 변형 목록과 현재 선택 인덱스 조회","optional":true},
    "saveImageVariantState": {"raw":{"2026-11-01":"Ip"},"doc":"이미지 키별 생성 변형 목록과 현재 선택 인덱스 저장","optional":true},
    "currentPortraitImageKey": {"raw":{"2026-11-01":"bee"},"doc":"현재 주인공 초상화가 실제로 사용하는 이미지 키 계산","optional":true},
    "imageManifest": {"raw":{"2026-11-01":"bh"},"doc":"이미지팩과 이미지 서버의 사용 가능한 이미지 목록 읽기","optional":true},
    "imageManifestReset": {"raw":{"2026-11-01":"t_"},"doc":"사용 가능한 이미지 목록 캐시 초기화","optional":true},
    "imageUrl": {"raw":{"2026-11-01":"o_"},"doc":"이미지 목록 항목을 브라우저 표시 주소로 변환","optional":true},
    "imagePreGenerateCharacters": {"raw":{"2026-11-01":"Gi"},"doc":"설정의 이미지 미리 생성 창에 표시하는 인물 ID 목록"},
    "imageFloorOutfits": {"raw":{"2026-11-01":"ene"},"doc":"미리 생성할 일반·잠옷 의상 ID 목록","optional":true},
    "imageBathOutfits": {"raw":{"2026-11-01":"ene"},"doc":"미리 생성할 목욕 의상 ID 목록","optional":true},
    "imagePreGenerateDialog": {"raw":{"2026-11-01":"hM"},"doc":"설정의 이미지 미리 생성해두기 선택 창"},
    "imagePlanCharacter": {"raw":{"2026-11-01":"Fat"},"doc":"사전 생성 후보를 만들 때 인물 ID로 임시 아내 캐릭터 구성"},
    "imagePlanEntry": {"raw":{"2026-11-01":"mu"},"doc":"이미지 공방의 개별 사전 생성 후보와 프롬프트 구성"},
    "imagePlanList": {"raw":{"2026-11-01":"Uat"},"doc":"인물 하나의 사전 생성 이미지 후보 목록 구성"},
    "gamePromptQuality": {"raw":{"2026-11-01":"Mz"},"doc":"게임이 모든 초상화에 넣는 기본 품질 Positive"},
    "gamePromptNegative": {"raw":{"2026-11-01":"YMe"},"doc":"게임이 모든 초상화에 넣는 공통 Negative"},
    "gameScenePromptTable": {"doc":"게임의 기본 이미지 장면 프롬프트 목록","optional":true,"raw":{"2026-11-01":"Iz"}},
    "gamePressTopicTable": {"doc":"원본 대화 선택의 압박 행동 및 조건부 결과 장면","optional":true,"raw":{"2026-11-01":"Bg"}},
    "gameTaskPromptTable": {"doc":"게임의 기본 작업 프롬프트 후보","optional":true,"raw":{"2026-11-01":"DL"}},
    "gameLookPromptTable": {"doc":"게임의 기본 시선 프롬프트 후보","optional":true,"raw":{"2026-11-01":"YDe"}},
    "gameLookReactionPromptTable": {"doc":"게임의 기본 시선 반응 프롬프트 후보","optional":true,"raw":{"2026-11-01":"BDe"}},
    "gameBedScenePromptTable": {"doc":"게임의 침대 장면 프롬프트 후보","optional":true,"raw":{"2026-11-01":"LDe"}},
    "gameSexPromptTable": {"doc":"게임의 관계 장면 기본 후보","optional":true,"raw":{"2026-11-01":"zDe"}},
    "gameRoughSexPromptTable": {"doc":"게임의 거친 관계 장면 기본 후보","optional":true,"raw":{"2026-11-01":"JDe"}},
    "portraitSceneContext": {"doc":"현재 초상화 장면과 변형","optional":true,"raw":{"2026-11-01":"Wg"}},
    "portraitMoodContext": {"doc":"현재 초상화 분위기","optional":true,"raw":{"2026-11-01":"Gz"}},
    "portraitFinishContext": {"doc":"현재 초상화 마무리 상태","optional":true,"raw":{"2026-11-01":"GK"}},
    "imageGenerationInFlight": {"raw":{"2026-11-01":"xc"},"doc":"이미지 생성 요청과 취소 상태를 추적하는 진행 중 작업 Map","optional":true},
    "heroineOrgasm": {"raw":{"2026-11-01":"k_"},"doc":"게임의 캐릭터 절정 확정 및 절정 시각·횟수 기록"}
  },

  setup(api) {
    // HL integration: expose the existing editor instance; never initialize a second AIP.
    const initialEditorSettings = localStorage.getItem('wml.mod.attention-image-prompt');
    let imageStudioEditorHost = null;
    let imageStudioPlanState = null, imageStudioCompose = null;
    const originalEditorApi = api;
    // Selection belongs to Studio even when its optional matching system is off.
    function imageStudioOwnsSelection() {
      return globalThis.WML?.status?.().loaded?.includes('imagestudio') === true;
    }
    api = { ...api, store: { ...api.store, game: () => imageStudioPlanState || originalEditorApi.store.game() }, hook(name, spec) {
      if (name === 'imagePrompt' && spec.before === currentAccessoryArgs) imageStudioCompose = spec.after;
      if (['imageLookup', 'imageVariantState', 'saveImageVariantState', 'currentPortraitImageKey'].includes(name)) {
        const delegated = { ...spec };
        if (spec.before) delegated.before = (...args) => imageStudioOwnsSelection() ? undefined : spec.before(...args);
        if (spec.after) delegated.after = (result, ...args) => imageStudioOwnsSelection() ? result : spec.after(result, ...args);
        if (spec.around) delegated.around = (next, ...args) => imageStudioOwnsSelection() ? next(...args) : spec.around(next, ...args);
        return originalEditorApi.hook(name, delegated);
      }
      if (name === 'imageGenerate' && spec.around) {
        return originalEditorApi.hook(name, { ...spec, around: (next, ...args) =>
          imageStudioOwnsSelection() ? next(...args) : spec.around(next, ...args) });
      }
      return originalEditorApi.hook(name, spec);
    }, fn(name) {
      if (name === 'imageGenerate') return (...args) => imageStudioEditorHost?.generate
        ? imageStudioEditorHost.generate(...args) : originalEditorApi.fn(name)(...args);
      return originalEditorApi.fn(name);
    } };
    const attentionSituations = api.fn('attentionSituations');
    const effectiveHeroineStats = api.fn('effectiveHeroineStats');
    const relationshipPanelStatus = api.fn('relationshipPanelStatus');
    const topFeelings = api.fn('topFeelings');
    const wellbeingSignals = api.fn('wellbeingSignals');
    const intoxicationBand = api.fn('intoxicationBand');
    const heroineDriveCalc = api.fn('heroineDriveCalc');
    const allureScore = api.fn('allureScore');
    const gameJoinPrompt = api.fn('promptJoin');
    const joinPrompt = value => gameJoinPrompt(typeof value === 'string' ? deduplicateFinalPrompt(value) : value);
    api.hook('promptJoin', { priority: Number.MAX_SAFE_INTEGER, around: joinPromptWithPriority });
    const promptGenParams = api.fn('promptGenParams');
    const GAME_PROMPT_QUALITY = api.fn('gamePromptQuality');
    const GAME_PROMPT_NEGATIVE = api.fn('gamePromptNegative');
    const settingsStore = api.fn('settingsStore');
    const imageLookup = api.fn('imageLookup');
    const customWifeStore = api.fn('customWifeStore');
    const wifeBuilderDefaults = api.fn('wifeBuilderDefaults');
    const buildWifeArchetype = api.fn('buildWifeArchetype');
    const wifeArchetypeById = api.fn('wifeArchetypeById');
    const wifeCharacterFromArchetype = api.fn('wifeCharacterFromArchetype');
    const wifePreviewBundle = api.fn('wifePreviewBundle');
    const imagePreGenerateCharacters = api.fn('imagePreGenerateCharacters');
    const imageServerUrl = api.fn('imageServerUrl');
    const outfitById = api.fn('outfitById');
    const outfitList = api.has('outfitList') ? api.fn('outfitList') : null;
    const jsx = api.fn('jsx');
    let ownImagePackEntries = null;
    let mergedImagePackSource = null;
    let mergedImagePackManifest = null;
    let localImageCache = { at: 0, entries: {} };
    let localImageCachePending = null;
    let imagePlanDepth = 0;
    async function localGeneratedEntries(refresh = false) {
      if (!refresh && Date.now() - localImageCache.at < 15_000) return localImageCache.entries;
      if (localImageCachePending) return localImageCachePending;
      localImageCachePending = readLocalGeneratedEntries();
      try { return await localImageCachePending; }
      finally { localImageCachePending = null; }
    }
    async function readLocalGeneratedEntries() {
      const entries = {};
      try {
        const response = await fetch('./images/.image-cache.json', { credentials: 'omit', cache: 'no-store' });
        if (response.ok) {
          const index = await response.json();
          if (index?.version === 1 && index.entries && typeof index.entries === 'object') {
            for (const [cacheKey, entry] of Object.entries(index.entries)) {
              const name = String(entry?.talentName || cacheKey);
              const path = String(entry?.imagePath || '').replaceAll('\\', '/');
              const createdAt = Number(entry?.createdAt) || 0;
              if (!name || name.length > 2048 || /[\/\\\x00-\x1f]/.test(name)
                || !path.includes('/characters/') || !/\.(?:webp|png|jpe?g)$/i.test(path)
                || path.startsWith('/') || path.split('/').some(part => part === '.' || part === '..')
                || /^[a-z]+:/i.test(path)
                || entries[name]?.createdAt >= createdAt) continue;
              entries[name] = { talentName: name, imagePath: path, imageType: entry.imageType || 'portrait', createdAt,
                ...(typeof entry.prompt === 'string' ? { prompt: entry.prompt } : {}),
                ...(typeof entry.negativePrompt === 'string' ? { negativePrompt: entry.negativePrompt } : {}),
                source: 'attention-image-prompt' };
            }
          }
        }
      } catch { /* The image folder may not be served, especially from file://. */ }
      localImageCache = { at: Date.now(), entries };
      return entries;
    }
    async function localImageExists(path) {
      try {
        const url = `./images/${path.split('/').map(encodeURIComponent).join('/')}`;
        const response = await fetch(url, { method: 'HEAD', credentials: 'omit', cache: 'no-store' });
        return response.ok;
      } catch { return false; }
    }
    if (api.has('imageManifest')) api.hook('imageManifest', {
      around(next, ...args) {
        return Promise.resolve(next(...args)).then(manifest => {
          if (!ownImagePackEntries) return manifest;
          if (manifest === mergedImagePackSource && mergedImagePackManifest) return mergedImagePackManifest;
          const entries = { ...manifest?.entries };
          for (const [key, entry] of Object.entries(ownImagePackEntries)) {
            if (entries[key]?.source !== 'server') entries[key] = entry;
          }
          mergedImagePackSource = manifest;
          mergedImagePackManifest = { ...manifest, version: manifest?.version || 1, entries };
          return mergedImagePackManifest;
        });
      },
    });
    if (api.has('imageUrl')) api.hook('imageUrl', {
      after(url, [entry]) {
        if (entry?.source === 'attention-image-prompt-offline' && offlineCache.ownsUrl(entry)) return entry.offlineUrl;
        if (entry?.source !== 'attention-image-prompt') return url;
        const path = String(entry.imagePath || '').replaceAll('\\', '/');
        if (!path || path.startsWith('/') || path.split('/').includes('..') || /^[a-z]+:/i.test(path)) return '';
        return `images/${path.split('/').map(encodeURIComponent).join('/')}`;
      },
    });
    if (api.loadScript) {
      const before = globalThis.__WAYWARD_IMAGE_PACKS__?.length || 0;
      void api.loadScript('image-pack.js').then(() => {
        const ownPacks = (globalThis.__WAYWARD_IMAGE_PACKS__ || []).slice(before)
          .filter(pack => String(pack?.packId || '').startsWith('attention-image-prompt-'));
        if (!ownPacks.length) return;
        ownImagePackEntries = Object.fromEntries(ownPacks.flatMap(pack =>
          Object.entries(pack.entries || {}).map(([key, entry]) => [key, { ...entry, source: 'attention-image-prompt' }])));
        if (api.has('imagePackReset')) api.fn('imagePackReset')();
      }).catch(error => console.warn('[attention-image-prompt] optional image pack', error));
    }
    const DEFAULT_WIFE_PREVIEW_NEGATIVE = String(wifePreviewBundle({
      id: '__attention_preview__',
      shortname: '__attention_preview__',
      imageBase: '',
    })?.negativePrompt || '').trim();
    const WIFE_PREVIEW_ONLY_NEGATIVE = 'nude, naked, breasts_out, nipples, lingerie, heavy armor, cloak hiding body, cropped, close-up';
    const previewOnlySuffix = `, ${WIFE_PREVIEW_ONLY_NEGATIVE}`;
    const DEFAULT_WIFE_CHARACTER_NEGATIVE = DEFAULT_WIFE_PREVIEW_NEGATIVE.endsWith(previewOnlySuffix)
      ? DEFAULT_WIFE_PREVIEW_NEGATIVE.slice(0, -previewOnlySuffix.length).trim()
      : DEFAULT_WIFE_PREVIEW_NEGATIVE;

    function normalizedWifeNegative(value) {
      const negative = String(value ?? '').trim();
      return negative === DEFAULT_WIFE_PREVIEW_NEGATIVE ? DEFAULT_WIFE_CHARACTER_NEGATIVE : negative;
    }

    const LEGACY_HANDCUFF_PROMPT = 'hands_behind_back, wrists_bound_behind_back, handcuffed, metal_handcuffs, iron_chains, shackles, unable_to_move, struggling';
    const PREVIOUS_HANDCUFF_PROMPT = '(only female restrained:1.25), (handcuffed woman:1.3), (female wrists cuffed together:1.3), (female hands together:1.2), metal handcuffs, short chain between cuffs, struggling, (all males unrestrained:1.2), male hands free';
    const LEGACY_HANDCUFF_NEGATIVE_PROMPT = 'handcuffed boys, restrained boys, male handcuffs, male shackles, chains on male wrists, boys with bound hands, boys with hands tied, handcuffs on both genders, smile';
    const PREVIOUS_HANDCUFF_NEGATIVE_PROMPT = 'handcuffed man, restrained man, bound man, male bondage, male handcuffs, male wrists together, male hands together, female wrists apart, female hands separated, shared handcuffs';
    const CHOKER_NEGATIVE_PROMPT = 'choker, heart choker, heart-shaped choker, black leather choker, slave collar, neck restraint, neck shackle, chain around neck';
    const H_STATUS_PORTRAIT_CHOKER_PROMPT = 'a heart-shaped choker fitted around her neck';
    const H_STATUS_PORTRAIT_BREAST_JEWELRY_PROMPT = 'matching metal nipple jewelry on both breasts';
    const H_STATUS_PORTRAIT_TOY_PROMPTS = [
      'an inserted egg vibrator concealed inside her vagina with only a thin retrieval cord visible',
      'an inserted penis-shaped vibrator concealed inside her vagina with its base visible',
    ];
    const H_STATUS_PORTRAIT_STATUS_GUARD = 'exactly one of each described device, no duplicate jewelry, no extra vibrator';
    const GENERAL_FIELDS = [
      { key: 'attention.escalation', label: '대응 필요 · 긴급/고조', value: 'tense expression' },
      { key: 'attention.unwatched', label: '대응 필요 · 보이지 않는 상황', value: 'furtive expression' },
      { key: 'attention.trouble', label: '대응 필요 · 문제 발생', value: 'distressed expression' },
      { key: 'attention.spent', label: '대응 필요 · 기진맥진', value: 'exhausted' },
      {
        key: 'restraint.handcuffed',
        label: '수갑을 채웠음',
        value: '(only female restrained:1.25), handcuffed woman, wrists cuffed together, short chain, men unrestrained',
      },
    ];
    const PREGNANCY_FIELDS = [
      { key: 'pregnancy.early', label: '임신 초기 · 수태 후 0–1일',
        value: '',
        negative: '' },
      { key: 'pregnancy.middle', label: '임신 중기 · 수태 후 2일',
        value: '',
        negative: '' },
      { key: 'pregnancy.late', label: '임신 후기 · 수태 후 3일 이상',
        value: '',
        negative: '' },
    ];
    const CYCLE_FIELDS = [
      { key: 'cycle.vulva.menstrual', label: '월경기 · 음부',
        value: '(menstruation:1.1), (small visible trace of muted red menstrual blood at her vaginal opening:1.25), (subtle blood stain confined to her vulva:1.1)',
        negative: 'blood splatter, blood on legs, blood on buttocks, open wound' },
      { key: 'cycle.vulva.follicular', label: '난포기 · 음부',
        value: '', negative: '' },
      { key: 'cycle.vulva.ovulation', label: '배란기 · 음부',
        value: '', negative: '' },
      { key: 'cycle.vulva.luteal', label: '황체기 · 음부',
        value: '', negative: '' },
    ];
    const FIRST_EXPERIENCE_FIELDS = [
      { key: 'firstExperience.vaginal', label: '첫 질 삽입 · 표정과 혈흔',
        value: '(pained wince:1.3), (furrowed brow:1.2), (lips parted in a strained gasp:1.2), (slight whole-body trembling:1.25), (only a tiny pinpoint of blood at her vaginal opening:0.95), (one sharply defined thin red blood streak running down one inner thigh:1.25)',
        negative: 'heavy bleeding, pooled blood, large blood stains, blood splatter, multiple blood streaks, open wound, smile, relaxed expression' },
    ];
    const NATIVE_FIRST_EXPERIENCE_TAG = '(virgin blood:1.3)';
    const SLEEP_FIELDS = [
      { key: 'sleep.light', label: '얕은 잠 · 곧 깨어남',
        value: '(closed eyes:1.35), (woman lying down in bed:1.35), head on pillow, drowsy sleeping expression, slight stirring',
        negative: 'open eyes, wide eyes, looking at viewer, eye contact, standing woman, sitting woman, kneeling woman, cowgirl' },
      { key: 'sleep.middle', label: '보통 잠',
        value: '(closed eyes:1.45), (woman lying down in bed:1.35), head on pillow, asleep, relaxed sleeping face, slow breathing',
        negative: 'open eyes, wide eyes, looking at viewer, eye contact, standing woman, sitting woman, kneeling woman, cowgirl' },
      { key: 'sleep.deep', label: '깊은 잠',
        value: '(closed eyes:1.55), (woman lying down in bed:1.35), head on pillow, deep sleep, peaceful sleeping face, still posture',
        negative: 'open eyes, wide eyes, looking at viewer, eye contact, standing woman, sitting woman, kneeling woman, cowgirl' },
      { key: 'sleep.waking-rub', label: '삽입 직전 깨어남 · 측위 입구 맞댐',
        value: '(eyes wide open:1.2), startled expression, parted lips in surprise, ^^^, (woman lying on her side in bed:1.35), exposed pussy, (penis_on_pussy:1.3), (tip of penis touching her vaginal opening from outside:1.3)',
        negative: 'closed eyes, penetration, penis in pussy, fingering, fingers in pussy, handjob, fellatio, paizuri' },
    ];

    const DETAIL_FIELDS = [
      { key: 'status.energy.0', label: '기력 0–19', value: 'exhausted' },
      { key: 'status.energy.1', label: '기력 20–39', value: 'tired, low energy' },
      { key: 'status.energy.2', label: '기력 40–59', value: '' },
      { key: 'status.energy.3', label: '기력 60–79', value: '' },
      { key: 'status.energy.4', label: '기력 80–100', value: '' },
      { key: 'status.mood.0', label: '기분 0–19', value: 'depressed expression' },
      { key: 'status.mood.1', label: '기분 20–39', value: 'sad expression, subdued mood' },
      { key: 'status.mood.2', label: '기분 40–59', value: '' },
      { key: 'status.mood.3', label: '기분 60–79', value: '' },
      { key: 'status.mood.4', label: '기분 80–100', value: '' },
      { key: 'status.arousal.0', label: '흥분도 0–19', value: '' },
      { key: 'status.arousal.1', label: '흥분도 20–39', value: 'slightly flushed, subtle arousal' },
      { key: 'status.arousal.2', label: '흥분도 40–59', value: 'flushed face, aroused' },
      { key: 'status.arousal.3', label: '흥분도 60–79', value: 'heavy breathing, highly aroused' },
      { key: 'status.arousal.4', label: '흥분도 80–100', value: 'flushed, heavy breathing' },
      { key: 'status.wellbeing.0', label: '심신 상태 0–19', value: 'at the limit, physically and mentally exhausted' },
      { key: 'status.wellbeing.1', label: '심신 상태 20–39', value: 'distressed expression' },
      { key: 'status.wellbeing.2', label: '심신 상태 40–59', value: 'weary, strained expression' },
      { key: 'status.wellbeing.3', label: '심신 상태 60–79', value: '' },
      { key: 'status.wellbeing.4', label: '심신 상태 80–100', value: '' },
      { key: 'status.allure.high', label: '주목도 60 이상', value: 'alluring pose' },
      { key: 'status.trust.low', label: '신뢰 30 미만', value: 'guarded expression, emotionally distant' },
      { key: 'status.desire.high', label: '애정·욕망 60 이상', value: 'affectionate gaze' },
      { key: 'status.resentment.medium', label: '원망도 35–59', value: 'resentful expression' },
      { key: 'status.resentment.high', label: '원망도 60 이상', value: 'deep resentment, hostile expression' },
      { key: 'status.drift.high', label: '심적 이탈 35 이상', value: 'emotionally distant, averted gaze' },
      { key: 'status.latitude.negative', label: '허용 인식 0 미만', value: 'uneasy expression' },
      { key: 'status.intoxication.tipsy', label: '취기 · 살짝 취함', value: 'tipsy, faint blush' },
      { key: 'status.intoxication.drunk', label: '취기 · 취함', value: 'drunk, flushed face, unsteady posture' },
      { key: 'status.intoxication.wasted', label: '취기 · 만취', value: 'heavily drunk, dazed expression, unsteady posture' },
      { key: 'status.intoxication.sloppy', label: '취기 · 몸을 못 가눔', value: 'extremely drunk, unfocused eyes, unable to stand steadily' },
      { key: 'status.intoxication.blacked_out', label: '취기 · 의식 없음', value: 'unconscious, limp body' },
      {
        key: 'status.feelings.map',
        label: '강한 감정 매핑',
        rows: 9,
        hint: '한 줄에 상태키=프롬프트. 강도 15를 넘는 상위 감정 2개에 적용합니다.',
        value: [
          'anger=angry expression',
          'contempt=contemptuous expression',
          'disgust=disgusted expression',
          'sadness=sad expression',
          'shame=embarrassed, downcast eyes',
          'guilt=guilty expression',
          'regret=regretful expression',
          'humiliation=humiliated expression',
          'tenderness=tender expression',
          'longing=yearning gaze',
          'desire=desirous expression',
          'arousal_buzz=flushed face',
        ].join('\n'),
      },
      {
        key: 'status.drives.map',
        label: '가장 강한 욕구 매핑',
        rows: 7,
        hint: '한 줄에 상태키=프롬프트. 수치 35를 넘는 가장 강한 욕구에 적용합니다.',
        value: [
          'financial=worried expression',
          'approval=seeking approval',
          'desire=longing gaze',
          'security=anxious expression',
          'social=lonely expression',
          'pride=proud posture',
          'longing=yearning expression',
        ].join('\n'),
      },
    ];

    const FLUID_PARTS = [
      {
        part: 'mouth', label: '입', statuses: ['없음', '흔적이 남음', '묻어 있음', '많이 묻어 있음', '넘쳐남'],
        values: ['', 'cum_in_mouth', 'cum_in_mouth, cum_on_tongue', 'cum_in_mouth, cum_on_tongue, cum_dripping_from_mouth', 'cum_in_mouth, cum_on_tongue, cum_dripping_from_mouth, excessive_cum'],
      },
      {
        part: 'breasts', label: '가슴', statuses: ['없음', '흔적이 남음', '묻어 있음', '많이 묻어 있음', '넘쳐남'],
        values: ['', 'cum_on_breasts', 'cum_on_breasts, cum_on_chest', 'cum_on_breasts, cum_on_chest, excessive_cum', 'cum_on_breasts, cum_on_chest, excessive_cum, dripping_cum'],
      },
      {
        part: 'uterus', label: '자궁', statuses: ['없음', '질내 잔류', '자궁 내 일부', '가득참', '넘쳐남'],
        values: ['', 'creampie', 'creampie, cum_in_pussy', 'creampie, cum_in_pussy, excessive_cum', 'creampie, cum_in_pussy, overflowing_creampie'],
      },
      {
        part: 'vulva', label: '보지', statuses: ['건조함', '은은하게 젖음', '애액이 맺힘', '허벅지 안쪽까지 흐름', '애액이 허벅지를 타고 흐름'],
        values: ['', 'slightly_wet_pussy', 'wet_pussy, pussy_juice', 'wet_pussy, pussy_juice, pussy_juice_dripping', 'wet_pussy, excessive_pussy_juice, pussy_juice_dripping'],
      },
      {
        part: 'thighs', label: '허벅지', statuses: ['없음', '흔적이 남음', '묻어 있음'],
        values: ['', 'cum_on_thighs', 'cum_on_thighs, cum_dripping_thighs'],
      },
    ];
    const H_STATUS_GENERATION_MODE_VALUES = new Set(['text2img', 'img2img', 'hstatus', 'own']);
    const DEFAULT_H_STATUS_GENERATION_MODES = Object.freeze({
      mouth: 'text2img', breasts: 'text2img', uterus: 'img2img', vulva: 'text2img', thighs: 'text2img',
    });
    const FLUID_FIELDS = FLUID_PARTS.flatMap(({ part, label, statuses, values }) => statuses.map((status, tier) => ({
      key: `fluid.${part}.${tier}`,
      label: `${label} · ${status}`,
      value: values[tier],
    })));
    const H_STATUS_FANTASY_FIELDS = [
      ...['', '(ringed_eyes:0.85), (slightly unfocused gaze:1.06)',
        '(ringed_eyes:0.95), (unfocused gaze:1.1)',
        '(ringed_eyes:1.15), (dazed expression:1.15), (one small floating question mark beside her face:1.15)',
        '(ringed_eyes:1.25), (pink_eyes:1.05), (pale pink color confined to the woman\'s irises:1.15), (vacant gaze:1.2), (one small floating question mark beside her face:1.15)',
        '(ringed_eyes:1.35), (purple_eyes:1.1), (deep violet color confined to the woman\'s irises:1.2), (empty stare:1.25), (slack expression:1.15), (one small floating question mark beside her face:1.15)']
        .map((value, stage) => ({ key: `hstatus.hypnosis.${stage}`, label: `최면 · ${stage}단계`, value })),
      ...[['', ''], ['faint pale pink', ''], ['light pink', ''], ['clear magenta', ''],
        ['vivid magenta', '1.15'], ['deep crimson-magenta', '1.4']]
        .map(([color, glow], stage) => ({ key: `hstatus.crest.${stage}`, label: `음문 · ${stage}단계`,
          value: stage ? `(pubic_tattoo:1.1), (single ${color} crest on the woman's exposed lower abdomen between navel and pubic bone:1.25)${glow ? `, (glowing_tattoo:${glow})` : ''}` : '' })),
    ];
    const CREST_NEGATIVE_PROMPT = 'male tattoo, hand tattoo, duplicate crest';
    const JEWELRY_FIELDS = [
      { key: 'jewelry.breasts.0', label: '가슴 · 장신구 없음', value: '' },
      { key: 'jewelry.breasts.1', label: '가슴 · 좌측 유두 피어싱', value: 'nipple_piercing, single_nipple_piercing' },
      { key: 'jewelry.breasts.2', label: '가슴 · 양쪽 유두 피어싱', value: 'nipple_piercing, pierced_nipples' },
      { key: 'jewelry.breasts.3', label: '가슴 · 양쪽 유두 피어싱 · 하트 초커', value: 'nipple_piercing, pierced_nipples, heart_choker' },
      { key: 'jewelry.vulva.0', label: '보지 · 장신구 없음', value: '' },
      { key: 'jewelry.vulva.1', label: '보지 · 클리 피어싱', value: 'clitoris_piercing, genital_piercing' },
    ];
    const TOY_FIELDS = [
      { key: 'toy.vulva.egg', label: '보지 · 에그 바이브 장착', value: '(egg_vibrator:1.1), vaginal_object_insertion, vibrator_cord, (egg vibrator fully inside her vagina:1.45), (only its cord visible at the vaginal opening:1.3)' },
      { key: 'toy.vulva.penis', label: '보지 · 자지형 바이브 장착', value: '(dildo:1.1), vibrator, vaginal_object_insertion, (dildo shaft fully inside her vagina:1.45), (only its base visible at the vaginal opening:1.3)' },
    ];
    const FEMALE_POSES = Object.freeze({
      standing: '(woman standing:1.25), upright posture',
      sitting: '(woman sitting:1.25), seated',
      kneeling: '(woman kneeling:1.25), upright torso',
      back: '(woman lying on back:1.3), supine, face up',
      side: '(woman lying on side:1.3), side-lying',
      prone: '(woman lying face down:1.35), prone, chest down, back up',
      allFours: '(woman on all fours:1.35), on hands and knees, back horizontal',
      bent: '(woman bent over:1.3), torso forward',
      legsRaised: '(woman lying on back:1.3), legs up, spread legs',
      straddling: '(woman straddling man:1.3), woman on top, facing man',
      reverseStraddling: '(woman straddling man facing away:1.3), woman on top, reverse cowgirl position',
      wallPinned: '(woman standing with her back pressed against wall:1.35), woman upright',
      wallLeaning: '(woman leaning forward with both palms on wall:1.35), woman torso inclined, woman arms extended to wall',
      wallOneLeg: '(woman standing side-on against wall:1.35), woman shoulder and back against wall, (one leg raised:1.4), (other foot planted on floor:1.35), asymmetrical legs',
      lifted: '(suspended congress:1.35), woman pressed to male partner torso, legs locked around male partner waist, arms around male partner shoulders, (both feet hanging in midair:1.35)',
      wallLifted: '(suspended congress:1.35), (woman pressed against wall:1.3), woman back pressed against wall, legs locked around male partner waist, (both feet hanging in midair:1.4)',
    });
    const FEMALE_POSE_OPTIONS = [
      ['', '자동/장면 기본값'], [FEMALE_POSES.standing, '서 있기'], [FEMALE_POSES.sitting, '앉기'],
      [FEMALE_POSES.kneeling, '무릎 꿇기'], [FEMALE_POSES.back, '바로 눕기'], [FEMALE_POSES.side, '옆으로 눕기'],
      [FEMALE_POSES.prone, '엎드리기'], [FEMALE_POSES.allFours, '네발 자세'], [FEMALE_POSES.bent, '상체 숙이기'],
      [FEMALE_POSES.legsRaised, '바로 누워 다리 들기'], [FEMALE_POSES.straddling, '남성 위에 마주 앉기'],
      [FEMALE_POSES.reverseStraddling, '남성 위에 등지고 앉기'],
      [FEMALE_POSES.wallPinned, '벽에 등을 대고 서기'], [FEMALE_POSES.wallLeaning, '벽을 짚고 기대기'],
      [FEMALE_POSES.wallOneLeg, '벽에 기대 한쪽 다리 들기'],
      [FEMALE_POSES.lifted, '들려 있기'], [FEMALE_POSES.wallLifted, '벽에 들려 양발 띄우기'],
    ];
    const FEMALE_POSE_VALUES = new Set(FEMALE_POSE_OPTIONS.map(([value]) => value));
    const MAN_FINGER_WOMAN_PROMPT = "hetero, (fingering:1.15), (man fingering woman's vagina:1.3), (man's fingers at woman's vulva:1.25), (woman receiving fingering:1.2), hand_on_another's_crotch, fingers_in_pussy, pussy_focus";
    const MALE_ACTIONS = Object.freeze({
      kissing: 'man kissing woman, body contact',
      fondling: 'man fondling woman, groping',
      fingering: '(fingering:1.15), man fingering woman, hand on pussy, fingers in pussy, female focus',
      cunnilingus: '(cunnilingus:1.15), man performing cunnilingus on woman, oral focus',
      fellatio: '(fellatio:1.15), man receiving fellatio from woman, penis in mouth, oral focus',
      roughFellatio: '(rough fellatio:1.25), (deepthroat:1.25), man receiving fellatio from woman, penis in mouth, tears, trembling, one eye closed, wide-eyed, oral focus',
      handjob: '(handjob:1.15), man receiving handjob from woman, penis in hand, hand focus',
      paizuri: '(paizuri:1.15), man receiving paizuri from woman, breast sex, breast press, breast focus',
      vaginal: '(vaginal sex:1.2), man penetrating woman, penis in pussy, penetration',
      anal: '(anal sex:1.2), man penetrating woman, penis in ass, anal penetration',
      rubbing: '(penis rubbing:1.15), man rubbing against woman, grinding, body contact',
      watching: 'man watching woman, watching, voyeur',
      sixtyNine: '(69 position:1.2), mutual oral sex, mutual oral',
    });
    const CONCISE_MALE_ACTIONS = new Map([
      [MALE_ACTIONS.fingering, MAN_FINGER_WOMAN_PROMPT],
      [MALE_ACTIONS.cunnilingus, '(cunnilingus:1.15)'],
      [MALE_ACTIONS.fellatio, '(fellatio:1.15), penis in mouth'],
      [MALE_ACTIONS.roughFellatio, '(rough fellatio:1.25), deepthroat, penis in mouth, tears, trembling, one eye closed, other eye wide'],
      [MALE_ACTIONS.handjob, '(handjob:1.15), penis in hand'],
      [MALE_ACTIONS.paizuri, '(paizuri:1.25), penis between breasts'],
      [MALE_ACTIONS.vaginal, '(vaginal sex:1.25), (man\'s penis visibly inserted into woman\'s vagina:1.3)'],
      [MALE_ACTIONS.anal, '(anal sex:1.25), (man\'s penis visibly inserted into woman\'s anus:1.3)'],
      [MALE_ACTIONS.rubbing, 'penis rubbing against woman'],
      [MALE_ACTIONS.sixtyNine, '(69 position:1.2), mutual oral sex'],
    ]);
    const GROUP_SLOT_OPTIONS = [
      { id: 'm', name: '입', prompt: '(positioned at her mouth:1.0), (fellatio:1.1), penis_in_mouth, oral_focus' },
      { id: 'h', name: '남성 손 자극', prompt: '(positioned at her side:1.0), (female giving handjob:1.1), handjob, penis_in_hand, hand_focus' },
      { id: 'f', name: '여성 손 자극', prompt: `(positioned between her legs:1.0), ${MAN_FINGER_WOMAN_PROMPT}` },
      { id: 'c', name: '커닐링구스', prompt: '(positioned between her legs:1.0), (cunnilingus:1.1), oral_focus, pussy_focus' },
      { id: 'b', name: '파이즈리', prompt: '(supporting man at her chest:1.2), (paizuri:1.25), penis between breasts' },
      { id: 'x', name: '후방', prompt: '(positioned behind her:1.0), (sex_from_behind:1.1), doggystyle, rear_view' },
      { id: 'r', name: '마찰', prompt: '(pressed against her body:1.0), (penis_rubbing:1.1), grinding, body_contact' },
      { id: 'i', name: '질 삽입', prompt: '(positioned between her legs:1.0), (vaginal_sex:1.1), penis_in_pussy, penetration' },
      { id: 'a', name: '항문 삽입', prompt: '(positioned behind her:1.0), (anal_sex:1.1), penis_in_ass, anal_penetration' },
      { id: 'w', name: '관전', prompt: '(standing in background:0.95), (watching:1.05), voyeur, looking_at_sex' },
    ];
    const GROUP_SLOT_BY_ID = Object.fromEntries(GROUP_SLOT_OPTIONS.map(option => [option.id, option]));
    const POSITION_DETAIL_FIELDS = [
      { id: 'placement', name: '남성 배치', options: [
        ['', '자동/빠른 역할'], ['in front of woman', '여성 앞'], ['behind woman', '여성 뒤'], ['beside woman', '여성 옆'],
        ["between woman's legs", '여성 다리 사이'], ['above woman', '여성 위'], ['below woman', '여성 아래'],
        ["near woman's head", '여성 머리 쪽'], ["at woman's chest", '여성 가슴 쪽'], ['in background', '뒤쪽·배경'],
      ] },
      { id: 'pose', name: '남성 자세', options: [
        ['', '자동/프리셋'], ['male standing', '서 있기'], ['male sitting', '앉기'], ['male kneeling', '무릎 꿇기'],
        ['male crouching', '쪼그려 앉기'], ['male lying on back', '바로 눕기'], ['male lying on side', '옆으로 눕기'],
        ['male lying face down', '엎드리기'], ['male on all fours', '네발 자세'], ['male leaning over woman', '여성 위로 몸 숙이기'],
      ] },
      { id: 'action', name: '행동', options: [
        ['', '자동/프리셋'], [MALE_ACTIONS.kissing, '여성에게 키스'], [MALE_ACTIONS.fondling, '여성을 애무'],
        [MALE_ACTIONS.fingering, '여성 손 자극'], [MALE_ACTIONS.cunnilingus, '커닐링구스'],
        [MALE_ACTIONS.fellatio, '펠라치오 받기'], [MALE_ACTIONS.roughFellatio, '거친 구강성교 받기'], [MALE_ACTIONS.handjob, '남성 손 자극 받기'],
        [MALE_ACTIONS.paizuri, '파이즈리 받기'], [MALE_ACTIONS.vaginal, '질 삽입'], [MALE_ACTIONS.anal, '항문 삽입'],
        [MALE_ACTIONS.rubbing, '성기 마찰'], [MALE_ACTIONS.watching, '관전'], [MALE_ACTIONS.sixtyNine, '69 상호 구강성교'],
      ] },
      { id: 'target', name: '대상 부위', options: [
        ['', '자동/프리셋'], ['mouth focus', '입'], ['breast focus', '가슴'], ['pussy focus', '여성기'],
        ['ass focus', '항문·엉덩이'], ['hand focus', '손'], ['thigh focus', '허벅지'], ['full body', '전신'],
      ] },
    ];
    const POSITION_DETAIL_VALUES = Object.fromEntries(POSITION_DETAIL_FIELDS.map(field => [field.id, new Set(field.options.map(([value]) => value))]));
    const DANBOORU_POSE_TAGS = [
      'standing', 'sitting', 'kneeling', 'on_back', 'on_side', 'on_stomach', 'all_fours',
      'bent_over', 'on_back, legs_up', 'hetero, cowgirl_position, girl_on_top',
      'hetero, reverse_cowgirl_position, girl_on_top',
      'against_wall', 'against_wall, leaning_forward', 'against_wall, leg_up',
      'suspended_congress', 'suspended_congress, against_wall',
    ];
    const COUPLE_POSITION_TAGS = Object.freeze({
      missionary: 'hetero, missionary, on_back, boy_on_top',
      doggystyle: 'hetero, doggystyle, all_fours, (doggystyle:1.3), (woman on hands and knees:1.3), (man kneeling directly behind woman:1.25)',
      spooning: 'hetero, spooning, on_side, lying, (both partners lying on their sides:1.35), (woman lying on her side with her back against the man:1.3), (man lying on his side directly behind her:1.3), parallel horizontal bodies',
      press: 'hetero, mating_press, missionary, on_back, folded, boy_on_top',
    });
    const COUPLE_POSITION_NEGATIVES = Object.freeze({
      missionary: 'girl_on_top, cowgirl_position, reverse_cowgirl_position',
      doggystyle: 'missionary, on_back, girl_on_top, cowgirl_position, reverse_cowgirl_position',
      spooning: 'standing_sex, missionary, on_back, boy_on_top, face-to-face',
      'side-rubbing': 'fingering, penetration, penis in pussy, standing_sex',
      'waking-contact': 'fingering, penetration, penis in pussy, thigh sex, standing_sex',
      'mating-press': 'solo, girl_on_top, cowgirl_position, reverse_cowgirl_position',
    });
    const MODULE_ACT_TAGS = Object.freeze({
      mutualKiss: 'hetero, kiss',
      manFondleWoman: "hetero, groping, grabbing_another's_breast",
      manFingerWoman: MAN_FINGER_WOMAN_PROMPT,
      manAnalFingerWoman: "hetero, anal_fingering, fingering, hand_on_another's_ass",
      manOralWoman: 'hetero, cunnilingus, pussy',
      womanOralMan: 'hetero, fellatio, penis, open_mouth',
      manIrrumatioWoman: 'hetero, irrumatio, deepthroat, fellatio, penis, open_mouth',
      womanHandjobMan: "hetero, handjob, grabbing_another's_penis",
      womanPaizuriMan: 'hetero, paizuri, breast_press',
      manVaginalWoman: 'hetero, sex, vaginal, penis, pussy',
      manAnalWoman: 'hetero, sex, anal, penis, ass',
      mutualRubbing: 'hetero, frottage',
      manWatchingWoman: 'voyeurism, looking_at_another',
      mutualOral: 'hetero, 69, fellatio, cunnilingus',
    });
    const DANBOORU_ACTION_TAGS = [MODULE_ACT_TAGS.mutualKiss, MODULE_ACT_TAGS.manFondleWoman,
      MODULE_ACT_TAGS.manFingerWoman, MODULE_ACT_TAGS.manOralWoman, MODULE_ACT_TAGS.womanOralMan,
      MODULE_ACT_TAGS.manIrrumatioWoman, MODULE_ACT_TAGS.womanHandjobMan, MODULE_ACT_TAGS.womanPaizuriMan,
      MODULE_ACT_TAGS.manVaginalWoman, MODULE_ACT_TAGS.manAnalWoman, MODULE_ACT_TAGS.mutualRubbing,
      MODULE_ACT_TAGS.manWatchingWoman, MODULE_ACT_TAGS.mutualOral];
    const DANBOORU_TAG_LIBRARY = Object.freeze({
      '인물·구도': ['1girl', '1boy', '2boys', 'multiple_boys', 'full_body', 'upper_body'],
      '행위 주체·대상': ['hetero', 'girl_on_top', 'boy_on_top', "grabbing_another's_breast",
        "grabbing_another's_penis", "grabbing_another's_ass", "hand_on_another's_ass", 'clitoral_stimulation',
        'licking_penis', 'sucking_male_nipple', "finger_in_another's_mouth", 'face_to_breasts',
        'penis_on_pussy', 'penis_on_ass'],
      '여성 자세': ['standing', 'sitting', 'kneeling', 'lying', 'on_back', 'on_side', 'on_stomach', 'all_fours',
        'bent_over', 'folded', 'legs_up', 'leg_up', 'spread_legs', 'leaning_forward'],
      '체위': ['cowgirl_position', 'reverse_cowgirl_position', 'doggystyle', 'missionary',
        'spooning', 'mating_press', 'standing_sex', 'against_wall', 'suspended_congress'],
      '행위': ['kiss', 'french_kiss', 'kissing_neck', 'kissing_ear', 'biting_neck',
        'finger_sucking', 'breast_sucking', 'licking_nipple', 'licking_panties',
        'groping', 'fingering', 'anal_fingering', 'cunnilingus', 'fellatio', 'irrumatio', 'deepthroat',
        'handjob', 'paizuri', 'sex', 'vaginal', 'anal', 'frottage', 'voyeurism', '69', 'rough_sex', 'undressing'],
      '표정·동작': ['blush', 'tears', 'crying', 'sweat', 'open_mouth', 'tongue_out', 'looking_at_another',
        'dazed', 'struggling', 'resisting', 'spanking', 'motion_blur', 'female_orgasm', 'moaning',
        'heavy_breathing', 'trembling', 'ahegao', 'drooling'],
      '의상·소품': ['nude', 'partially_undressed', 'handcuffs', 'bound_wrists', 'rope', 'door'],
      '체액·신체': ['cum_in_pussy', 'facial', 'cum_on_breasts', 'cum_in_mouth', 'cum_on_body',
        'breasts', 'ass', 'pussy', 'penis'],
    });
    const MODULE_NATIVE_POSE_TAGS = new Set([
      ...DANBOORU_TAG_LIBRARY['여성 자세'], ...DANBOORU_TAG_LIBRARY['체위'],
      'sex from behind', 'standing sex', 'missionary position', 'girl_on_top', 'boy_on_top',
      'woman on top', 'man on top', 'face-to-face',
    ].map(tag => promptTagIdentity(tag).spaced));
    const BUILTIN_POSITION_MODULES = [
      ...FEMALE_POSE_OPTIONS.slice(1).map(([, name], index) => ({ id: `pose-${index}`,
        kind: index < 9 ? 'pose' : 'position', name,
        positivePrompt: DANBOORU_POSE_TAGS[index], negativePrompt: '' })),
      ...POSITION_DETAIL_FIELDS.find(field => field.id === 'action').options.slice(1)
        .map(([, name], index) => ({ id: `action-${index}`, kind: 'action', name,
          positivePrompt: DANBOORU_ACTION_TAGS[index],
          negativePrompt: index === 2 ? 'female_masturbation, hand_on_own_crotch, spread_pussy'
            : index === 1 ? 'female_masturbation' : '' })),
      { id: 'climax-1', kind: 'other', name: '아내 절정 · 1회 이상',
        positivePrompt: 'female_orgasm, moaning, blush, heavy_breathing, emphasis line', negativePrompt: '' },
      { id: 'climax-2', kind: 'other', name: '아내 절정 · 2회 이상',
        positivePrompt: 'trembling, sweat, open_mouth', negativePrompt: '' },
      { id: 'climax-3', kind: 'other', name: '아내 절정 · 3회 이상',
        positivePrompt: 'ahegao, drooling', negativePrompt: '' },
    ];
    const MALE_PERSON_PRESETS = [
      { id: 'kiss', name: '키스', detail: { placement: 'in front of woman', pose: '', action: MALE_ACTIONS.kissing, target: 'mouth focus' } },
      { id: 'fondling', name: '애무', detail: { placement: 'beside woman', pose: '', action: MALE_ACTIONS.fondling, target: 'full body' } },
      { id: 'female-hand-stimulation', name: '여성 손 자극', slot: 'f', detail: { placement: "between woman's legs", pose: '', action: MALE_ACTIONS.fingering, target: 'pussy focus' } },
      { id: 'cunnilingus', name: '커닐링구스', slot: 'c', detail: { placement: "between woman's legs", pose: 'male kneeling', action: MALE_ACTIONS.cunnilingus, target: 'pussy focus' } },
      { id: 'fellatio', name: '펠라치오 받기', slot: 'm', detail: { placement: 'in front of woman', pose: '', action: MALE_ACTIONS.fellatio, target: 'mouth focus' } },
      { id: 'handjob', name: '남성 손 자극 받기', slot: 'h', detail: { placement: 'beside woman', pose: '', action: MALE_ACTIONS.handjob, target: 'hand focus' } },
      { id: 'paizuri', name: '파이즈리 받기', slot: 'b', detail: { placement: "at woman's chest", pose: '', action: MALE_ACTIONS.paizuri, target: 'breast focus' } },
      { id: 'vaginal-front', name: '정면 질 삽입', slot: 'i', detail: { placement: "between woman's legs", pose: 'male leaning over woman', action: MALE_ACTIONS.vaginal, target: 'pussy focus' } },
      { id: 'vaginal-behind', name: '후방 질 삽입', slot: 'x', detail: { placement: 'behind woman', pose: 'male kneeling', action: MALE_ACTIONS.vaginal, target: 'pussy focus' } },
      { id: 'anal-behind', name: '후방 항문 삽입', slot: 'a', detail: { placement: 'behind woman', pose: 'male kneeling', action: MALE_ACTIONS.anal, target: 'ass focus' } },
      { id: 'rubbing', name: '성기 마찰', slot: 'r', detail: { placement: 'in front of woman', pose: '', action: MALE_ACTIONS.rubbing, target: 'full body' } },
      { id: 'watching', name: '관전', slot: 'w', detail: { placement: 'in background', pose: 'male standing', action: MALE_ACTIONS.watching, target: 'full body' } },
      { id: 'rough-fellatio', name: '거친 구강성교 받기', slot: 'm', detail: { placement: 'in front of woman', pose: '', action: MALE_ACTIONS.roughFellatio, target: 'mouth focus' } },
    ];
    const POSITION_PRESET_GROUPS = [
      {
        title: '여성 자세 빠른 프리셋', hidden: true, presets: [
          { id: 'standing', name: '서 있기', prompt: 'female focus', template: { femalePose: FEMALE_POSES.standing, main: {} } },
          { id: 'sitting', name: '앉기', prompt: 'female focus', template: { femalePose: FEMALE_POSES.sitting, main: {} } },
          { id: 'kneeling', name: '무릎 꿇기', prompt: 'female focus', template: { femalePose: FEMALE_POSES.kneeling, main: {} } },
          { id: 'lying-back', name: '바로 눕기', prompt: 'female focus', template: { femalePose: FEMALE_POSES.back, main: {} } },
          { id: 'all-fours', name: '네발 자세', prompt: 'female focus', template: { femalePose: FEMALE_POSES.allFours, main: {} } },
        ],
      },
      {
        title: '장면 조합 프리셋', presets: [
          { id: 'missionary', name: '정상위', prompt: '(missionary:1.35), (woman lying on her back:1.35), (man visibly on top of woman:1.3), face-to-face, male partner between her legs', template: { femalePose: FEMALE_POSES.back, main: MALE_PERSON_PRESETS[7].detail } },
          { id: 'cowgirl', name: '기승위', prompt: '(cowgirl position:1.2), woman on top', template: { femalePose: FEMALE_POSES.straddling, main: { placement: 'below woman', pose: 'male lying on back', action: MALE_ACTIONS.vaginal, target: 'pussy focus' } } },
          { id: 'reverse-cowgirl', name: '역기승위', prompt: '(reverse cowgirl position:1.2), woman on top', template: { femalePose: FEMALE_POSES.reverseStraddling, main: { placement: 'below woman', pose: 'male lying on back', action: MALE_ACTIONS.vaginal, target: 'pussy focus' } } },
          { id: 'doggystyle', name: '후배위', prompt: `${COUPLE_POSITION_TAGS.doggystyle}, sex from behind`, template: { femalePose: FEMALE_POSES.allFours, main: MALE_PERSON_PRESETS[8].detail } },
          { id: 'anal-doggystyle', name: '후방 항문위', prompt: '(anal sex from behind:1.2), doggystyle', template: { femalePose: FEMALE_POSES.allFours, main: MALE_PERSON_PRESETS[9].detail } },
          { id: 'spooning', name: '측위', prompt: '(spooning:1.35), (both partners lying on their sides:1.35), man lying behind woman, his chest against her back, horizontal bodies', template: { femalePose: FEMALE_POSES.side, main: { placement: 'behind woman', pose: 'male lying on side', action: MALE_ACTIONS.vaginal, target: 'pussy focus' } } },
          { id: 'side-rubbing', name: '측위 허벅지 비비기', prompt: '(both partners lying on their sides:1.3), (thigh sex:1.25), penis rubbing between her thighs', template: { femalePose: FEMALE_POSES.side, main: { placement: 'behind woman', pose: 'male lying on side', action: MALE_ACTIONS.rubbing, target: 'full body' } } },
          { id: 'waking-contact', name: '측위 입구 맞댐', prompt: '(both partners lying on their sides:1.3), (penis_on_pussy:1.3), penis tip touching her vaginal opening from outside', template: { femalePose: FEMALE_POSES.side, main: { placement: 'behind woman', pose: 'male lying on side', action: '', target: 'pussy focus' } } },
          { id: 'standing-sex', name: '입위', prompt: '(standing sex:1.2), face-to-face, upright bodies, one leg raised', template: { femalePose: FEMALE_POSES.standing, main: { placement: 'in front of woman', pose: 'male standing', action: MALE_ACTIONS.vaginal, target: 'pussy focus' } } },
          { id: 'wall-pinned', name: '벽에 밀쳐서', prompt: '(woman pinned against wall:1.3), woman back pressed against wall, face-to-face, standing sex, male partner standing in front of woman', template: { femalePose: FEMALE_POSES.wallPinned, main: { placement: 'in front of woman', pose: 'male standing', action: MALE_ACTIONS.vaginal, target: 'pussy focus' } } },
          { id: 'wall-leaning', name: '벽에 기대서', prompt: '(woman leaning against wall:1.3), woman bracing both hands on wall, woman torso leaning forward, sex from behind, male partner standing behind woman', template: { femalePose: FEMALE_POSES.wallLeaning, main: { placement: 'behind woman', pose: 'male standing', action: MALE_ACTIONS.vaginal, target: 'pussy focus' } } },
          { id: 'wall-one-leg-raised', name: '벽에서 한발만 들림', prompt: '(standing sex against wall:1.3), (side penetration:1.25), side-by-side bodies, male partner standing beside woman, man penetrating woman from the side, (only one leg raised:1.4), other leg straight, (one foot planted on floor:1.35), full body, floor visible', template: { femalePose: FEMALE_POSES.wallOneLeg, main: { placement: 'beside woman', pose: 'male standing', action: MALE_ACTIONS.vaginal, target: 'pussy focus' } } },
          { id: 'lifted-standing', name: '들려서', prompt: '(suspended congress:1.4), face-to-face, male partner supporting woman under both thighs, legs locked around male partner waist, (both feet hanging in midair:1.4), (clear gap between feet and floor:1.35), full body, floor visible', template: { femalePose: FEMALE_POSES.lifted, main: { placement: 'in front of woman', pose: 'male standing', action: MALE_ACTIONS.vaginal, target: 'pussy focus' } } },
          { id: 'wall-lifted-feet-off-ground', name: '발이 땅에 닿지 않게', prompt: '(suspended congress:1.4), (woman pressed against wall:1.3), male partner supporting woman under both thighs, woman back pressed against wall, legs locked around male partner waist, (both feet hanging in midair:1.4), (clear gap between feet and floor:1.4), full body, floor visible beneath both feet', template: { femalePose: FEMALE_POSES.wallLifted, main: { placement: 'in front of woman', pose: 'male standing', action: MALE_ACTIONS.vaginal, target: 'pussy focus' } } },
          { id: 'mating-press', name: '프레스(굴곡위)', prompt: '(mating press:1.35), face-to-face, (woman lying on back:1.35), (man visibly on top of woman:1.35), (male head and torso visible:1.3), (knees pressed beside shoulders:1.35), (thighs folded tightly against torso:1.3), (male torso lowered far over woman:1.35), male chest over her folded legs, man pressing her knees down with his body weight, (deep penetration:1.2), (forceful thrusting:1.2), dynamic pose', template: { femalePose: FEMALE_POSES.legsRaised, main: MALE_PERSON_PRESETS[7].detail } },
          { id: 'prone-bone', name: '복와위', prompt: '(prone bone:1.2), sex from behind', template: { femalePose: FEMALE_POSES.prone, main: { placement: 'above woman', pose: 'male leaning over woman', action: MALE_ACTIONS.vaginal, target: 'pussy focus' } } },
        ],
      },
      {
        title: '구강·손 장면 프리셋', presets: [
          { id: 'kneeling-fellatio', name: '무릎 구강성교', prompt: '(fellatio:1.15)', template: { femalePose: FEMALE_POSES.kneeling, main: { ...MALE_PERSON_PRESETS[4].detail, pose: 'male standing' } } },
          { id: 'rough-fellatio', name: '거친 구강성교', prompt: '(rough fellatio:1.25), deepthroat, tears, trembling, one eye closed, other eye wide', template: { femalePose: FEMALE_POSES.back, main: { ...MALE_PERSON_PRESETS[4].detail, placement: 'above woman', pose: 'male kneeling', action: MALE_ACTIONS.roughFellatio } } },
          { id: 'cunnilingus', name: '커닐링구스', prompt: '(cunnilingus:1.15)', template: { femalePose: FEMALE_POSES.back, main: MALE_PERSON_PRESETS[3].detail } },
          { id: 'female-hand-stimulation', name: '여성 손 자극', prompt: '(fingering:1.15)', template: { femalePose: FEMALE_POSES.back, main: MALE_PERSON_PRESETS[2].detail } },
          { id: 'sixty-nine', name: '69', prompt: '(69 position:1.2), mutual oral sex, opposite-facing bodies', template: { femalePose: FEMALE_POSES.side, main: { placement: 'beside woman', pose: 'male lying on side', action: MALE_ACTIONS.sixtyNine, target: 'mouth focus' } } },
          { id: 'seated-handjob', name: '앉아서 남성 손 자극', prompt: '(handjob:1.15)', template: { femalePose: FEMALE_POSES.sitting, main: MALE_PERSON_PRESETS[5].detail } },
          { id: 'paizuri', name: '파이즈리', prompt: '(paizuri:1.15)', template: { femalePose: FEMALE_POSES.back, main: { ...MALE_PERSON_PRESETS[6].detail, placement: 'above woman', pose: 'male leaning over woman' } } },
        ],
      },
    ];
    const POSITION_PRESETS = Object.fromEntries(POSITION_PRESET_GROUPS.flatMap(group => group.presets).map(preset => [preset.id, preset]));
    const PREVIOUS_POSITION_PRESET_PROMPTS = {
      doggystyle: ['(doggystyle:1.2), sex from behind'],
      missionary: ['(missionary position:1.2), face-to-face'],
      spooning: ['(spooning position:1.2), sex from behind'],
      'side-rubbing': ['(both partners lying on their sides:1.3), (genital rubbing:1.25), frottage'],
      'mating-press': ['(mating press:1.35), face-to-face, (knees pressed beside shoulders:1.35), (thighs folded tightly against torso:1.3), (male torso lowered far over woman:1.35), male chest over her folded legs, man pressing her knees down with his body weight, (deep penetration:1.2), (forceful thrusting:1.2), dynamic pose'],
      'rough-fellatio': ['(rough fellatio:1.25), (deepthroat:1.25), tears, trembling, one eye closed, wide-eyed'],
      paizuri: [
        '(paizuri:1.3), woman holding both breasts together around man\'s penis',
        '(paizuri:1.3), (penis extending from man\'s groin over woman\'s cleavage:1.3), penis visibly outside breast skin, woman pressing both breasts against its sides',
      ],
    };
    const PREVIOUS_PAIZURI_GROUP_PROMPTS = [
      '(positioned at her chest:1.0), (paizuri:1.1), breast_sex, breast_focus',
      '(positioned at her chest:1.0), (paizuri:1.1), breast_sex, breast_focus',
      '(positioned at her chest:1.0), (paizuri:1.25), (penis between breasts:1.3), woman holding breasts together, breast_focus',
      '(supporting man facing her chest:1.1), (paizuri:1.25), (penis extending from supporting man\'s groin across her cleavage:1.3), (penis resting on breast skin outside her body:1.2), breasts pressed against both sides of his penis, separate bodies, breast_focus',
      '(man beside her chest:1.1), (paizuri:1.2), separate bodies',
    ];
    const AUTO_POSITION_PRESETS = {
      'scene-sex': 'missionary',
      'scene-sex_rough': 'mating-press',
      'scene-patron_sex': 'missionary',
      'scene-patron_riding': 'cowgirl',
      'scene-anal': 'anal-doggystyle',
      'scene-patron_anal': 'anal-doggystyle',
      'scene-blowjob': 'kneeling-fellatio',
      'scene-patron_blowjob': 'kneeling-fellatio',
      'scene-cunnilingus': 'cunnilingus',
      'scene-patron_cunnilingus': 'cunnilingus',
      'scene-fingered': 'female-hand-stimulation',
      'scene-sixty_nine': 'sixty-nine',
      'scene-titfuck': 'paizuri',
    };
    const FEMALE_POSE_MIGRATIONS = {
      standing: FEMALE_POSES.standing, sitting: FEMALE_POSES.sitting, kneeling: FEMALE_POSES.kneeling,
      'lying on back': FEMALE_POSES.back, 'lying on side': FEMALE_POSES.side,
      'lying face down': FEMALE_POSES.prone, 'on all fours': FEMALE_POSES.allFours,
    };
    const POSITION_DETAIL_MIGRATIONS = {
      placement: {
        'positioned in front of her': 'in front of woman', 'positioned behind her': 'behind woman',
        'positioned at her side': 'beside woman', 'positioned between her legs': "between woman's legs",
        'positioned above her': 'above woman', 'positioned below her': 'below woman', 'standing in background': 'in background',
      },
      pose: {
        standing: 'male standing', sitting: 'male sitting', kneeling: 'male kneeling',
        'lying on back': 'male lying on back', 'lying on side': 'male lying on side',
        'lying face down': 'male lying face down', 'on all fours': 'male on all fours',
      },
      action: {
        'kissing, body contact': MALE_ACTIONS.kissing, 'fondling, groping': MALE_ACTIONS.fondling,
        'fingering, female receiving hand stimulation, hand_on_pussy, fingers_in_pussy': MALE_ACTIONS.fingering,
        cunnilingus: MALE_ACTIONS.cunnilingus, fellatio: MALE_ACTIONS.fellatio,
        'female giving handjob, handjob, penis_in_hand': MALE_ACTIONS.handjob,
        'handjob, penis_in_hand': MALE_ACTIONS.handjob,
        '(paizuri:1.15), man receiving paizuri from woman, breast sex, breast press, breast focus': MALE_ACTIONS.paizuri,
        '(paizuri:1.25), man receiving paizuri from woman, (penis between breasts:1.3), (woman squeezing breasts together around penis:1.25), breast focus': MALE_ACTIONS.paizuri,
        '(paizuri:1.25), man receiving paizuri from woman, (penis extending from man\'s groin between woman\'s breasts:1.3), penis resting on breast skin outside her body, woman pressing breasts against both sides of his penis, breast focus': MALE_ACTIONS.paizuri,
        'paizuri, breast press, breast sex': MALE_ACTIONS.paizuri,
        'vaginal sex, penis_in_pussy': MALE_ACTIONS.vaginal, 'anal sex, penis_in_ass': MALE_ACTIONS.anal,
        'grinding, rubbing': MALE_ACTIONS.rubbing, 'watching, voyeur': MALE_ACTIONS.watching,
      },
      target: {
        mouth_focus: 'mouth focus', breast_focus: 'breast focus', pussy_focus: 'pussy focus',
        ass_focus: 'ass focus', thigh_focus: 'thigh focus',
      },
    };
    const POSITION_PART_LABELS = new Set(['장면', '자세', '작업', 'Scene', 'Pose', 'Action']);
    const MARK_FIELDS = [
      ['slap', '뺨', [
        '(bruise_on_face:1.1), (slightly reddened left cheek:1.2)',
        '(bruise_on_face:1.2), (red swollen left cheek:1.3)',
        '(bruise_on_face:1.3), (visibly swollen left cheek:1.4), irritated skin',
      ]],
      ['breast', '가슴', [
        '(red palm print on her left breast:1.2)',
        '(red handprint on her left breast:1.3), (red swollen left breast:1.3)',
        '(dark bruise on her left breast:1.3), (visibly swollen left breast:1.4)',
      ]],
      ['butt', '엉덩이', [
        '(red palm print on her left buttock:1.2)',
        '(red handprint on her left buttock:1.3), (red swollen left buttock:1.3)',
        '(dark bruise on her left buttock:1.3), (visibly swollen left buttock:1.4)',
      ]],
      ['sex', '음부', [
        '(red slap mark on her vulva:1.2)',
        '(red palm-shaped mark on her vulva:1.3), (red swollen vulva:1.3)',
        '(dark bruise on her vulva:1.3), (visibly swollen vulva:1.4)',
      ]],
      ['belly', '배', [
        '(red palm print on her lower abdomen:1.2)',
        '(red handprint on her lower abdomen:1.3), (red swollen lower abdomen:1.3)',
        '(dark bruise on her lower abdomen:1.3), (visibly swollen lower abdomen:1.4)',
      ]],
    ].flatMap(([part, label, values]) => values.map((value, index) => ({
      key: `mark.${part}.${index + 1}`, label: `${label} · 흔적 ${index + 1}단계`, value,
    })));
    const EROSTAT_FIT_BANDS = ['loose', 'snug', 'full', 'strain', 'limit'];
    const EROSTAT_FIT_FIELDS = [
      ['loose', '여유', '(size fits without visible physical strain:1.05)'],
      ['snug', '꼭 맞음', '(tense expression:1.1), (slight physical tension from the size:1.08), faint involuntary shiver'],
      ['full', '꽉 참', '(strained expression:1.25), (furrowed brow:1.15), parted lips, (uneven breathing from the size:1.12), (slight body trembling:1.12), (small shallow penis-shaped bulge visible low on her abdomen from vaginal insertion:1.08)'],
      ['strain', '버거움', '(glazed eyes:1.3), (unfocused upward gaze:1.25), (half-lidded eyes:1.2), (dazed expression:1.2), (lips parted in a breathless gasp:1.2), (visibly struggling to accommodate the size:1.2), (body trembling:1.25), (localized shallow penis-shaped bulge visible low on her abdomen from vaginal insertion:1.15)'],
      ['limit', '한계', '(overwhelmed expression:1.35), (furrowed brow:1.3), (open_mouth:1.3), (rounded lips in a breathless gasp:1.2), (at her physical limit from the size:1.3), (whole body shaking:1.35), (distinct small penis-shaped bulge visible low on her abdomen from vaginal insertion:1.2)'],
    ].map(([band, label, value]) => ({ key: `erostat.fit.${band}`, label: `크기 · ${label}`, value }));
    const EROSTAT_ANAL_FIELDS = [
      ['loose', '여유', '(anal penetration without visible physical strain:1.05)'],
      ['snug', '꼭 맞음', '(tense expression:1.1), (slight tension in her hips from anal penetration:1.08), faint involuntary shiver'],
      ['full', '꽉 참', '(strained expression:1.25), (furrowed brow:1.15), parted lips, (hips tensing around anal penetration:1.15), (slight body trembling:1.15)'],
      ['strain', '버거움', '(glazed eyes:1.3), (unfocused upward gaze:1.25), (half-lidded eyes:1.2), (dazed expression:1.2), (lips parted in a breathless gasp:1.2), (visibly struggling with anal penetration:1.2), (tense hips:1.2), (body trembling:1.25)'],
      ['limit', '한계', '(overwhelmed expression:1.35), (furrowed brow:1.3), (open_mouth:1.3), (rounded lips in a breathless gasp:1.2), (at her physical limit from anal penetration:1.3), (whole body shaking:1.35), (tense hips:1.3)'],
    ].map(([band, label, value]) => ({ key: `erostat.anal.${band}`, label: `크기 · ${label}`, value }));
    const EROSTAT_DEFAULT_PRESETS = [...EROSTAT_FIT_FIELDS, ...EROSTAT_ANAL_FIELDS].map(field => ({
      id: `default-${field.key.split('.').slice(-2).join('-')}`,
      name: `기본 · ${field.key.startsWith('erostat.anal.') ? '애널' : '질'} · ${field.label.split(' · ')[1]}`,
      positivePrompt: field.value, negativePrompt: '',
    }));
    const PREVIOUS_EROSTAT_BREATHLESS_PROMPTS = {
      'erostat.fit.loose': '(lips slightly parted:1.1), (breath briefly catching:1.1), (size fits comfortably:1.05)',
      'erostat.fit.snug': '(slightly unfocused gaze:1.15), (lips parted for a shallow breath:1.15), (breath catching:1.15), (slight physical tension from the size:1.08), faint involuntary shiver',
      'erostat.fit.full': '(glazed unfocused eyes:1.25), (mouth open in a quiet gasp:1.2), (short uneven breaths:1.25), (slight body trembling:1.15), (small shallow penis-shaped bulge visible low on her abdomen from vaginal insertion:1.08)',
      'erostat.fit.strain': '(vacant glassy eyes:1.35), (half-lidded eyes:1.25), (eyes almost rolled upward:1.2), (pupils still visible:1.15), (mouth open in a breathless gasp:1.3), (struggling to draw a full breath:1.3), (body trembling:1.25), (localized shallow penis-shaped bulge visible low on her abdomen from vaginal insertion:1.15)',
      'erostat.fit.limit': '(vacant unfocused eyes:1.4), (eyes nearly rolled upward:1.3), (pupils still visible:1.15), (mouth held open in a silent gasp:1.35), (rapid shallow breaths:1.35), (whole body shaking:1.35), (distinct small penis-shaped bulge visible low on her abdomen from vaginal insertion:1.2)',
      'erostat.anal.loose': '(lips slightly parted:1.1), (breath briefly catching:1.1), (anal penetration without visible physical strain:1.05)',
      'erostat.anal.snug': '(slightly unfocused gaze:1.15), (lips parted for a shallow breath:1.15), (breath catching:1.15), (slight tension in her hips from anal penetration:1.08), faint involuntary shiver',
      'erostat.anal.full': '(glazed unfocused eyes:1.25), (mouth open in a quiet gasp:1.2), (short uneven breaths:1.25), (hips tensing around anal penetration:1.15), (slight body trembling:1.15)',
      'erostat.anal.strain': '(vacant glassy eyes:1.35), (half-lidded eyes:1.25), (eyes almost rolled upward:1.2), (pupils still visible:1.15), (mouth open in a breathless gasp:1.3), (struggling to draw a full breath:1.3), (tense hips:1.2), (body trembling:1.25)',
      'erostat.anal.limit': '(vacant unfocused eyes:1.4), (eyes nearly rolled upward:1.3), (pupils still visible:1.15), (mouth held open in a silent gasp:1.35), (rapid shallow breaths:1.35), (whole body shaking:1.35), (tense hips:1.3)',
    };
    const PREVIOUS_EROSTAT_BREATHLESS_PROMPTS_14193 = {
      'erostat.fit.loose': '(lips softly parted as she exhales:1.1), (gentle breath leaving her mouth:1.1), (size fits comfortably:1.05)',
      'erostat.fit.snug': '(slightly bewildered gaze:1.15), (lips parted in a shaky exhale:1.15), (breath leaving her mouth unevenly:1.15), (slight physical tension from the size:1.08), faint involuntary shiver',
      'erostat.fit.full': '(confused unsteady gaze:1.25), (lips open as she exhales sharply:1.2), (unsteady breath escaping her lips:1.25), (slight body trembling:1.15), (small shallow penis-shaped bulge visible low on her abdomen from vaginal insertion:1.08)',
      'erostat.fit.strain': '(bewildered unsteady eyes:1.35), (gaze wavering upward:1.18), (pupils clearly visible:1.15), (lips open in a ragged exhale:1.3), (breath forced out in short bursts:1.3), (body trembling:1.25), (localized shallow penis-shaped bulge visible low on her abdomen from vaginal insertion:1.15)',
      'erostat.fit.limit': '(confused overwhelmed gaze:1.4), (eyes wavering upward:1.25), (pupils clearly visible:1.15), (mouth open as she forcefully exhales:1.35), (ragged breath spilling from her lips:1.35), (whole body shaking:1.35), (distinct small penis-shaped bulge visible low on her abdomen from vaginal insertion:1.2)',
      'erostat.anal.loose': '(lips softly parted as she exhales:1.1), (gentle breath leaving her mouth:1.1), (anal penetration without visible physical strain:1.05)',
      'erostat.anal.snug': '(slightly bewildered gaze:1.15), (lips parted in a shaky exhale:1.15), (breath leaving her mouth unevenly:1.15), (slight tension in her hips from anal penetration:1.08), faint involuntary shiver',
      'erostat.anal.full': '(confused unsteady gaze:1.25), (lips open as she exhales sharply:1.2), (unsteady breath escaping her lips:1.25), (hips tensing around anal penetration:1.15), (slight body trembling:1.15)',
      'erostat.anal.strain': '(bewildered unsteady eyes:1.35), (gaze wavering upward:1.18), (pupils clearly visible:1.15), (lips open in a ragged exhale:1.3), (breath forced out in short bursts:1.3), (tense hips:1.2), (body trembling:1.25)',
      'erostat.anal.limit': '(confused overwhelmed gaze:1.4), (eyes wavering upward:1.25), (pupils clearly visible:1.15), (mouth open as she forcefully exhales:1.35), (ragged breath spilling from her lips:1.35), (whole body shaking:1.35), (tense hips:1.3)',
    };
    const PREVIOUS_EROSTAT_BREATHLESS_PROMPTS_14194 = {
      'erostat.fit.loose': '(lips slightly parted:1.1), (breath briefly catching:1.1), (size fits comfortably:1.05)',
      'erostat.fit.snug': '(slightly hollow tired eyes:1.15), (slightly furrowed brows:1.08), (lips parting in a small stifled gasp:1.15), (breath catching then slipping out:1.15), (slight physical tension from the size:1.08), faint involuntary shiver',
      'erostat.fit.full': '(slightly hollow dazed eyes:1.25), (heavy-lidded eyes:1.15), (slightly furrowed brows:1.1), (small breathless gasp escaping parted lips:1.2), (short broken breaths:1.25), (slight body trembling:1.15), (small shallow penis-shaped bulge visible low on her abdomen from vaginal insertion:1.08)',
      'erostat.fit.strain': '(slightly hollow dazed eyes with visible pupils:1.3), (gaze drifting slightly upward:1.18), (slightly furrowed brows:1.12), (lips parted in a strained stifled gasp:1.3), (breath hitching into short broken gasps:1.3), (body trembling:1.25), (localized shallow penis-shaped bulge visible low on her abdomen from vaginal insertion:1.15)',
      'erostat.fit.limit': '(slightly hollow dazed eyes with visible pupils:1.35), (gaze drifting upward slightly:1.25), (slightly furrowed brows:1.15), (lips forming a small rounded gasp:1.35), (breath catching repeatedly in short broken gasps:1.35), (whole body shaking:1.35), (distinct small penis-shaped bulge visible low on her abdomen from vaginal insertion:1.2)',
      'erostat.anal.loose': '(lips slightly parted:1.1), (breath briefly catching:1.1), (anal penetration without visible physical strain:1.05)',
      'erostat.anal.snug': '(slightly hollow tired eyes:1.15), (slightly furrowed brows:1.08), (lips parting in a small stifled gasp:1.15), (breath catching then slipping out:1.15), (slight tension in her hips from anal penetration:1.08), faint involuntary shiver',
      'erostat.anal.full': '(slightly hollow dazed eyes:1.25), (heavy-lidded eyes:1.15), (slightly furrowed brows:1.1), (small breathless gasp escaping parted lips:1.2), (short broken breaths:1.25), (hips tensing around anal penetration:1.15), (slight body trembling:1.15)',
      'erostat.anal.strain': '(slightly hollow dazed eyes with visible pupils:1.3), (gaze drifting slightly upward:1.18), (slightly furrowed brows:1.12), (lips parted in a strained stifled gasp:1.3), (breath hitching into short broken gasps:1.3), (tense hips:1.2), (body trembling:1.25)',
      'erostat.anal.limit': '(slightly hollow dazed eyes with visible pupils:1.35), (gaze drifting upward slightly:1.25), (slightly furrowed brows:1.15), (lips forming a small rounded gasp:1.35), (breath catching repeatedly in short broken gasps:1.35), (whole body shaking:1.35), (tense hips:1.3)',
    };
    const EROSTAT_BREATHLESS_NEGATIVE = 'metal gag, metal mouthpiece, metal bar in mouth, biting metal';
    const PREVIOUS_EROSTAT_BREATHLESS_REACTIONS = {
      loose: '(breath briefly catching:1.1), (lips slightly parted:1.1)',
      snug: '(breath catching:1.15), (short shallow breaths:1.15), (lips parted:1.15)',
      full: '(visibly breathless expression:1.25), (short uneven breaths:1.25), (mouth open in a gasp:1.2)',
      strain: '(eyes almost rolled upward:1.2), (pupils still visible:1.15), (struggling to draw a full breath:1.3), (gasping with mouth open:1.3), (trembling shoulders:1.2)',
      limit: '(barely able to catch her breath:1.35), (mouth held open in a breathless gasp:1.35), (rapid shallow breaths:1.3)',
    };
    const EROSTAT_BREATHLESS_PROMPTS = Object.fromEntries([...EROSTAT_FIT_FIELDS, ...EROSTAT_ANAL_FIELDS]
      .map(field => [field.key, `${field.value}, ${PREVIOUS_EROSTAT_BREATHLESS_REACTIONS[field.key.split('.').at(-1)]}`]));
    const PREVIOUS_EROSTAT_BREATHLESS_STRAIN = [
      '(struggling to draw a full breath:1.3), (gasping with mouth open:1.3), (trembling shoulders:1.2)',
      '(half-lidded unfocused upward gaze:1.2), (struggling to draw a full breath:1.3), (gasping with mouth open:1.3), (trembling shoulders:1.2)',
    ];
    const FIELD_GROUPS = [
      { id: 'general', title: '기본 상황', note: '대응 필요 목록과 “수갑을 채웠음” 상태에 붙일 태그입니다.', fields: GENERAL_FIELDS },
      { id: 'detail', title: '상세 상태', note: '상태 묶음을 펼친 뒤 필요한 항목만 수정할 수 있습니다.', fields: DETAIL_FIELDS },
      { id: 'pregnancy', title: '임신 상태', note: '임신 / 출산 모드의 현재 아내 임신 단계에 적용합니다. image-look 없이도 작동하며, 함께 켜져 있으면 임신 태그를 이 설정으로 교체합니다.', fields: PREGNANCY_FIELDS },
      { id: 'cycle', title: '생리 상태', note: '임신 / 출산 모드의 월경기 출혈만 기본 프롬프트에 넣습니다. 난포·배란·황체기는 기본 문구가 비어 있으며 직접 수정할 수 있습니다. 관계·성기 접촉 장면에서 음부가 보일 때만 적용하고, 임신 중에는 적용하지 않습니다.', fields: CYCLE_FIELDS },
      { id: 'firstExperience', title: '첫경험', note: '현재 상태 모드·비밀 일기·게임의 친밀 기록을 읽고 첫 질 삽입 장면에 표정·떨림·소량 혈흔을 적용합니다. 첫 경험 모드 없이도 동작하며, 함께 켜져 있으면 그 모드의 피 태그를 이 설정으로 대체합니다.', fields: FIRST_EXPERIENCE_FIELDS },
      { id: 'sleep', title: '수면 중 관계', note: '당신과 그녀의 일상 모드의 수면 단계·깊이를 읽습니다. 잠든 장면은 일반 관계와 이미지·체위 설정을 분리하고 누운 자세와 감은 눈을 적용합니다.', fields: SLEEP_FIELDS },
      { id: 'erostat', title: '에로스테 크기', note: 'H-Status의 남성기 크기를 에로스테 확장의 현재 수용 정도 5단계로 판정합니다. 질·애널은 별도 문구를 적용하며, 기본 아랫배 돌출 문구는 질 삽입에만 사용합니다. 여러 상대가 있으면 부위별로 가장 부담이 큰 단계를 사용합니다.', fields: [...EROSTAT_FIT_FIELDS, ...EROSTAT_ANAL_FIELDS] },
      { id: 'marks', title: '손찌검 흔적', note: '손님 확장의 현재 장면 손찌검과 아내에게 남은 흔적을 부위·정도별로 읽습니다. 뺨은 항상, 몸의 흔적은 성적 장면이나 노출 의상에서 적용합니다. 음부는 속옷을 젖히거나 벗었을 때도 적용합니다.', fields: MARK_FIELDS },
      { id: 'h-status', title: 'H Status', note: '부위·장신구·토이와 실제 초상화의 최면·음문 0~5단계입니다. 음문은 아랫배가 드러난 초상화에만 적용됩니다. H Status가 없어도 이 모드는 정상 작동합니다.', fields: [...FLUID_FIELDS, ...JEWELRY_FIELDS, ...TOY_FIELDS, ...H_STATUS_FANTASY_FIELDS] },
    ];
    const DIALOGUE_TAB = { id: 'dialogue', title: '대화 감지', note: 'text-sm 대화 영역에 원하는 문구가 포함되면 설정한 프롬프트를 추가합니다.' };
    const GAME_DEFAULT_TAB = { id: 'game-default', title: '게임 기본 설정', note: '공통 Positive·Negative와 프롬프트 길이에 따른 생성 설정 변화폭을 조절합니다.' };
    const CHARACTER_TAB = { id: 'character', title: '아내 캐릭터', note: '현재 아내에게 적용 중인 전체 외형 프롬프트를 불러오거나 직접 수정해 기본 외형 묶음을 교체합니다.' };
    const OUTFIT_TAB = { id: 'outfit-prompts', title: '의상 프롬프트', note: '의상을 등록하고 가격·노출도·프롬프트를 수정합니다. 작성 중이거나 등록된 의상을 가게 기본 장면으로 시착할 수 있습니다.' };
    const SITUATION_PRESET_TAB = { id: 'situation-presets', title: '상황 프리셋', note: '상황·상태·H Status·대화 프롬프트 묶음을 여러 개 저장하고 캐릭터별로 하나만 적용합니다.' };
    const SCENE_PROMPT_TAB = { id: 'scene-prompts', title: '장면 프롬프트', note: '게임과 다른 모드의 이미지 장면에 추가할 프롬프트를 설정합니다.' };
    const BUTTON_PROMPT_TAB = { id: 'button-prompts', title: '선택지 프롬프트', note: '현재 사건의 선택지와 저장한 선택지의 이미지 프롬프트를 설정합니다.' };
    const POSITION_TAB = { id: 'positions', title: '체위 설정', note: '이미지의 체위 설정과 모듈 조합을 선택합니다. AIP 체위 콘솔에서 실제 게임 행동과 이미지 전용 항목을 사용할 수 있습니다.' };
    const CLIMAX_TAB = { id: 'climax-prompts', title: '절정 프롬프트', note: '아내의 장면별 절정 횟수에 붙일 프롬프트를 수정하고 4회 이상 단계도 추가할 수 있습니다. 자동 적용은 모듈 조합 방식에서만 작동합니다.' };
    const IMAGE_PACK_TAB = { id: 'image-pack', title: '이미지팩 제작', note: '현재 아내의 이 모드 상황·체위 이미지를 게임용 이미지팩으로 내보냅니다.' };
    const PROMPT_MOD_TAB = { id: 'prompt-mods', title: '모드 영향', note: '모드별 태그를 한글로 확인하고, 반영 여부와 실제 적용할 영문 태그를 수정합니다.' };
    const CYCLE_DEBUG_TAB = { id: 'cycle-debug', title: '이미지 디버거', note: '현재 초상화 장면을 유지한 채 생리 주기·첫경험, 최면·음문 단계 또는 토이 상태를 비교합니다. 게임 상태와 초상화 목록은 바뀌지 않습니다.' };
    const DIAGNOSTICS_TAB = { id: 'diagnostics', title: '동작 진단', note: '모드 파일·이미지팩·이미지 생성기 연결과 최근 이미지 처리 기록을 확인합니다.' };
    const IMAGE_KEY_TAB = { id: 'image-keys', title: '이미지 파일명', note: '다른 모드의 태그가 뒤에 붙어 다시 길어진 최종 이미지 키를 생성 요청 전에 추가로 줄입니다.' };
    const SETTINGS_TABS = [IMAGE_KEY_TAB, GAME_DEFAULT_TAB, CHARACTER_TAB, OUTFIT_TAB, SITUATION_PRESET_TAB, SCENE_PROMPT_TAB, BUTTON_PROMPT_TAB, POSITION_TAB, CLIMAX_TAB, ...FIELD_GROUPS, DIALOGUE_TAB, CYCLE_DEBUG_TAB, IMAGE_PACK_TAB, PROMPT_MOD_TAB, DIAGNOSTICS_TAB];
    const LEGACY_SITUATION_PRESET_ID = 'default';
    const MAX_SITUATION_PRESETS = 50;
    const DEFAULT_PROMPTS = Object.fromEntries(FIELD_GROUPS.flatMap(group => group.fields).map(field => [field.key, field.value]));
    const PREVIOUS_DEFAULT_PROMPTS = {
      'hstatus.hypnosis.1': ['(slightly distant gaze:1.08)', '(slightly distant gaze:1.08), (one small pale pink question mark beside her head:1.2)', '(ringed_eyes:1.2), (dazed gaze:1.1), (one pale pink question mark beside her head:1.2)'],
      'hstatus.hypnosis.2': ['(soft unfocused gaze:1.12), slow blinking', '(soft unfocused gaze:1.12), (two small pink question marks beside her head:1.25)', '(ringed_eyes:1.3), (unfocused gaze:1.2), (two pink question marks beside her head:1.25)'],
      'hstatus.hypnosis.3': ['(glassy unfocused eyes:1.2), (dazed expression:1.15)', '(glassy unfocused eyes:1.2), (three pink question marks and small hearts beside her head:1.3)', '(ringed_eyes:1.35), (faint pink glow confined to her irises:1.2), (dazed expression:1.2), (pink question marks and hearts beside her head:1.3)', '(ringed_eyes:1.15), (dazed expression:1.15)'],
      'hstatus.hypnosis.4': ['(vacant gaze:1.28), (half-lidded eyes:1.18), (dazed expression:1.2)', '(vacant gaze:1.28), (several vivid pink question marks and hearts close to her head:1.35)', '(ringed_eyes:1.4), (glowing_eyes:1.2), (pink glow confined to her irises:1.25), (vacant expression:1.2), (vivid pink question marks and hearts beside her head:1.35)', '(ringed_eyes:1.25), (vacant gaze:1.2)'],
      'hstatus.hypnosis.5': ['(empty unresponsive gaze:1.35), (glassy eyes:1.25), (slack expression:1.22)', '(empty unresponsive gaze:1.35), (bright pink question marks and hearts close to her head:1.4)', '(ringed_eyes:1.45), (glowing_eyes:1.3), (bright pink glow confined to her irises:1.35), (empty stare:1.25), (bright pink question marks and hearts beside her head:1.4)', '(ringed_eyes:1.35), (empty stare:1.25), (slack expression:1.15)'],
      'hstatus.crest.1': ['(faint small pink sigil on her lower abdomen:1.15)', '(pubic_tattoo:1.15), (faint small pink sigil centered on exposed lower abdomen between navel and pubic bone:1.2)'],
      'hstatus.crest.2': ['(small pink magical crest on her lower abdomen:1.2)', '(pubic_tattoo:1.2), (small pink magical crest centered on exposed lower abdomen between navel and pubic bone:1.25)'],
      'hstatus.crest.3': ['(clear magenta magical crest on her lower abdomen:1.25)', '(pubic_tattoo:1.25), (clear magenta magical crest centered on exposed lower abdomen between navel and pubic bone:1.3)'],
      'hstatus.crest.4': ['(vivid magenta sigil on her lower abdomen:1.3), subtle local glow', '(pubic_tattoo:1.3), (vivid magenta sigil centered on exposed lower abdomen between navel and pubic bone:1.35), subtle local glow', '(pubic_tattoo:1.15), (single vivid magenta crest printed flat on the woman\'s exposed lower abdomen:1.35), (directly below her navel and above her pubic bone:1.3)', '(pubic_tattoo:1.1), (single vivid magenta crest on the woman\'s exposed lower abdomen between navel and pubic bone:1.25), (faint glow confined to the crest:1.1)'],
      'hstatus.crest.5': ['(intense crimson-magenta sigil on her lower abdomen:1.4), bright glow confined to the sigil', '(pubic_tattoo:1.35), (intense crimson-magenta sigil centered on exposed lower abdomen between navel and pubic bone:1.4), bright glow confined to the sigil', '(pubic_tattoo:1.2), (single deep crimson-magenta crest printed flat on the woman\'s exposed lower abdomen:1.4), (directly below her navel and above her pubic bone:1.35)', '(pubic_tattoo:1.1), (single deep crimson-magenta crest on the woman\'s exposed lower abdomen between navel and pubic bone:1.25), (visible glow confined to the crest:1.1)'],
      'toy.vulva.egg': [H_STATUS_PORTRAIT_TOY_PROMPTS[0], '(egg_vibrator:1.25), vaginal_object_insertion, vibrator_cord, only the cord visible', '(egg_vibrator:1.1), vaginal_object_insertion, vibrator_cord, (exactly one vibrator:1.35), (egg vibrator fully inside her vagina:1.45), (only its cord visible at the vaginal opening:1.3)'],
      'toy.vulva.penis': [H_STATUS_PORTRAIT_TOY_PROMPTS[1], '(dildo:1.2), vibrator, vaginal_object_insertion, vibrator base visible', 'vaginal_object_insertion, (exactly one dildo vibrator:1.35), (dildo shaft fully inside her vagina:1.45), (only its base visible at the vaginal opening:1.3)'],
      'cycle.vulva.menstrual': ['(light menstrual staining confined to her vulva:1.15)',
        '(menstruation:1.2), (visible dark red menstrual blood at her vaginal opening:1.35), (small blood stain confined to her vulva:1.2)'],
      'firstExperience.vaginal': '(pained wince:1.3), (furrowed brow:1.2), (lips parted in a strained gasp:1.2), (slight whole-body trembling:1.25), (only a pinpoint of faint blood at her vaginal opening:1.1), (a single thin faint red blood streak running down one inner thigh:1.15)',
      'erostat.fit.snug': '(slight physical tension from the size:1.08), faint involuntary shiver',
      'erostat.fit.full': ['(uneven breathing from the size:1.12), (slight body trembling:1.12), (subtle penis-shaped bulge in her lower abdomen from the insertion:1.12)',
        '(strained expression:1.25), (furrowed brow:1.15), parted lips, (uneven breathing from the size:1.12), (slight body trembling:1.12)'],
      'erostat.fit.strain': ['(visibly struggling to accommodate the size:1.2), (body trembling:1.25), (clear penis-shaped bulge pushing out her lower abdomen from within:1.25)',
        '(strained expression:1.3), (furrowed brow:1.25), grimace, (visibly struggling to accommodate the size:1.2), (body trembling:1.25), (very slight penis-shaped rise low on her abdomen from vaginal insertion:0.8)',
        '(strained expression:1.3), (furrowed brow:1.25), (lips parted in a pained gasp:1.2), (visibly struggling to accommodate the size:1.2), (body trembling:1.25), (localized shallow penis-shaped bulge visible low on her abdomen from vaginal insertion:1.15)',
        '(dazed vacant gaze:1.25), (slightly glassy eyes:1.15), (unfocused eyes drifting subtly upward:1.12), (lips parted in a breathless gasp:1.2), (visibly struggling to accommodate the size:1.2), (body trembling:1.25), (localized shallow penis-shaped bulge visible low on her abdomen from vaginal insertion:1.15)'],
      'erostat.fit.limit': ['(at her physical limit from the size:1.3), (whole body shaking:1.35), (pronounced penis-shaped bulge pushing out her lower abdomen from within:1.35)',
        '(grimace:1.35), (furrowed brow:1.3), (clenched_teeth:1.2), (at her physical limit from the size:1.3), (whole body shaking:1.35), (small localized penis-shaped rise low on her abdomen from vaginal insertion:0.9)'],
      'erostat.anal.snug': '(slight tension in her hips from anal penetration:1.08), faint involuntary shiver',
      'erostat.anal.full': '(hips tensing around anal penetration:1.15), (slight body trembling:1.15)',
      'erostat.anal.strain': ['(visibly struggling with anal penetration:1.2), (tense hips:1.2), (body trembling:1.25)',
        '(strained expression:1.3), (furrowed brow:1.25), grimace, (visibly struggling with anal penetration:1.2), (tense hips:1.2), (body trembling:1.25)',
        '(strained expression:1.3), (furrowed brow:1.25), (lips parted in a pained gasp:1.2), (visibly struggling with anal penetration:1.2), (tense hips:1.2), (body trembling:1.25)',
        '(dazed vacant gaze:1.25), (slightly glassy eyes:1.15), (unfocused eyes drifting subtly upward:1.12), (lips parted in a breathless gasp:1.2), (visibly struggling with anal penetration:1.2), (tense hips:1.2), (body trembling:1.25)'],
      'erostat.anal.limit': ['(at her physical limit from anal penetration:1.3), (whole body shaking:1.35), (tense hips:1.3)',
        '(grimace:1.35), (furrowed brow:1.3), (clenched_teeth:1.2), (at her physical limit from anal penetration:1.3), (whole body shaking:1.35), (tense hips:1.3)'],
      'cycle.vulva.follicular': '(natural vulva with little visible moisture:1.1)',
      'cycle.vulva.ovulation': '(clear natural moisture at her vulva:1.15)',
      'cycle.vulva.luteal': '(subtle natural moisture at her vulva:1.1)',
      'sleep.waking-rub': [
        '(open eyes:1.2), startled expression, (woman lying on her side in bed:1.35), (genital rubbing:1.25), frottage, penis rubbing against her body',
        '(eyes wide open:1.2), startled expression, parted lips in surprise, (woman lying on her side in bed:1.35), (thigh sex:1.25), penis rubbing between her thighs',
        '(eyes wide open:1.2), startled expression, parted lips in surprise, (woman lying on her side in bed:1.35), exposed pussy, (penis_on_pussy:1.3), (tip of penis touching her vaginal opening from outside:1.3)',
        '(eyes wide open:1.2), startled expression, parted lips in surprise, (small white comic-style shock symbol with three jagged rays beside her head:1.25), (woman lying on her side in bed:1.35), exposed pussy, (penis_on_pussy:1.3), (tip of penis touching her vaginal opening from outside:1.3)',
        '(eyes wide open:1.2), startled expression, parted lips in surprise, (small white three-point surprise mark beside her head:1.15), (woman lying on her side in bed:1.35), exposed pussy, (penis_on_pussy:1.3), (tip of penis touching her vaginal opening from outside:1.3)',
        '(eyes wide open:1.2), startled expression, parted lips in surprise, ^^^, (small white three-point surprise mark beside her head:1.15), (woman lying on her side in bed:1.35), exposed pussy, (penis_on_pussy:1.3), (tip of penis touching her vaginal opening from outside:1.3)',
      ],
      'attention.escalation': 'tense atmosphere, urgent situation, alert expression',
      'attention.unwatched': 'secret encounter, furtive atmosphere, cautious expression',
      'attention.trouble': 'tense confrontation, defensive posture, distressed expression',
      'attention.spent': 'exhausted, weary expression, slumped posture',
      'status.energy.0': 'exhausted, weak posture, heavy eyelids',
      'status.mood.0': 'gloomy expression, deeply depressed',
      'status.arousal.4': 'deeply flushed, intense arousal, heavy breathing',
      'status.wellbeing.1': 'unstable, visibly distressed',
      'status.allure.high': 'alluring pose, captivating presence',
      'status.desire.high': 'longing gaze, affectionate expression',
      'status.latitude.negative': 'uneasy expression, conflicted',
      'mark.slap.1': ['red mark on cheek', '(bruise_on_face:1.1), (slightly reddened left cheek:1.2)',
        '(slap_mark_on_face:1.05), (faint red mark on her left cheek:1.2)',
        '(faint red handprint confined to her left cheek:1.2)',
        '(faint red handprint only on her left cheek:1.25)',
        '(faint uneven pinkness confined to her left cheek:1.15)',
        '(faint red handprint only on her left cheek:1.1)'],
      'mark.slap.2': ['red handprint on cheek', '(bruise_on_face:1.2), (red swollen left cheek:1.3)',
        '(slap_mark_on_face:1.1), (red swollen left cheek:1.3)',
        '(clear red handprint confined to her left cheek:1.3), (mild swelling of her left cheek:1.15)',
        '(clear red handprint only on her left cheek:1.35), (left cheek slightly swollen:1.2)',
        '(soft diffuse redness confined to her left cheek:1.25), (slight swelling of her left cheek:1.1)',
        '(red handprint only on her left cheek:1.15), (left cheek slightly swollen:1.05)'],
      'mark.slap.3': ['bruised cheek, red handprint on cheek',
        '(bruise_on_face:1.3), (visibly swollen left cheek:1.4), irritated skin',
        '(slap_mark_on_face:1.1), (single dark bruise on her left cheek:1.3), (visibly swollen left cheek:1.35)',
        '(one dark purple-red handprint confined to her left cheek:1.35), (visible swelling of her left cheek:1.25)',
        '(intense crimson handprint only on her left cheek:1.45), (left cheek visibly swollen:1.3)',
        '(uneven muted red discoloration confined to her left cheek:1.3), (visible swelling of her left cheek:1.2)',
        '(red handprint only on her left cheek:1.2), (left cheek visibly swollen:1.1)'],
      'mark.breast.1': ['red mark on breast', '(faint red palm print confined to her left breast:1.2)', '(red palm print on her left breast:1.2)',
        '(faint red palm print confined to her left breast:1.25)',
        '(faint uneven pinkness confined to her left breast:1.15)',
        '(faint red palm print confined to her left breast:1.1)'],
      'mark.breast.2': ['red handprint on breast', '(clear red palm print confined to her left breast:1.3)', '(red handprint on her left breast:1.3), (red swollen left breast:1.3)',
        '(clear red handprint confined to her left breast:1.35), (localized redness on her left breast:1.2)',
        '(soft diffuse redness confined to her left breast:1.25), (mild irritation on her left breast:1.1)',
        '(red handprint confined to her left breast:1.15), (localized redness on her left breast:1.05)'],
      'mark.breast.3': ['bruised breast, red handprint on breast',
        '(dark purple-red palm print confined to her left breast:1.35), (localized swelling of her left breast:1.2)',
        '(dark bruise on her left breast:1.3), (visibly swollen left breast:1.4)',
        '(deep crimson handprint confined to her left breast:1.45), (localized swelling of her left breast:1.3)',
        '(uneven muted red discoloration confined to her left breast:1.3), (localized swelling of her left breast:1.2)',
        '(red handprint confined to her left breast:1.2), (localized swelling of her left breast:1.1)'],
      'mark.butt.1': ['red mark on buttock', '(faint red palm print confined to her left buttock:1.2)', '(red palm print on her left buttock:1.2)',
        '(faint red palm print confined to her left buttock:1.25)',
        '(faint uneven pinkness confined to her left buttock:1.15)',
        '(faint red palm print confined to her left buttock:1.1)'],
      'mark.butt.2': ['red handprint on buttock', '(clear red palm print confined to her left buttock:1.3)', '(red handprint on her left buttock:1.3), (red swollen left buttock:1.3)',
        '(clear red handprint confined to her left buttock:1.35), (localized redness on her left buttock:1.2)',
        '(soft diffuse redness confined to her left buttock:1.25), (mild irritation on her left buttock:1.1)',
        '(red handprint confined to her left buttock:1.15), (localized redness on her left buttock:1.05)'],
      'mark.butt.3': ['bruised buttocks, red handprint on buttock',
        '(dark purple-red palm print confined to her left buttock:1.35), (localized swelling of her left buttock:1.2)',
        '(dark bruise on her left buttock:1.3), (visibly swollen left buttock:1.4)',
        '(deep crimson handprint confined to her left buttock:1.45), (localized swelling of her left buttock:1.3)',
        '(uneven muted red discoloration confined to her left buttock:1.3), (localized swelling of her left buttock:1.2)',
        '(red handprint confined to her left buttock:1.2), (localized swelling of her left buttock:1.1)'],
      'mark.sex.1': ['red mark on vulva', '(faint redness confined to her vulva:1.2)', '(red slap mark on her vulva:1.2)',
        '(red palm-shaped slap mark across her vulva and pubic mound:1.3)',
        '(faint diffuse pinkness on her vulva and pubic mound:1.2)',
        '(red palm-shaped slap mark across her vulva and pubic mound:1.15)'],
      'mark.sex.2': ['red handprint on vulva', '(clear red palm-shaped mark confined to her vulva:1.3)', '(red palm-shaped mark on her vulva:1.3), (red swollen vulva:1.3)',
        '(clear red handprint across her vulva and pubic mound:1.4), (localized swelling of her vulva:1.2)',
        '(uneven soft redness on her vulva and pubic mound:1.3), (mild localized swelling of her vulva:1.15)',
        '(red handprint across her vulva and pubic mound:1.2), (localized swelling of her vulva:1.1)'],
      'mark.sex.3': ['bruised vulva, red handprint on vulva',
        '(dark purple-red palm-shaped mark confined to her vulva:1.35), (localized swelling of her vulva:1.2)',
        '(dark bruise on her vulva:1.3), (visibly swollen vulva:1.4)',
        '(deep crimson palm-shaped mark across her vulva and pubic mound:1.5), (visibly swollen vulva:1.3)',
        '(noticeable muted red discoloration on her vulva and pubic mound:1.35), (localized swelling of her vulva:1.25)',
        '(red palm-shaped mark across her vulva and pubic mound:1.25), (visibly swollen vulva:1.15)'],
      'mark.belly.1': ['red mark on abdomen', '(faint red palm print confined to her lower abdomen:1.2)', '(red palm print on her lower abdomen:1.2)',
        '(faint red palm print confined to her lower abdomen:1.25)',
        '(faint uneven pinkness confined to her lower abdomen:1.15)',
        '(faint red palm print confined to her lower abdomen:1.1)'],
      'mark.belly.2': ['red handprint on abdomen', '(clear red palm print confined to her lower abdomen:1.3)', '(red handprint on her lower abdomen:1.3), (red swollen lower abdomen:1.3)',
        '(clear red handprint confined to her lower abdomen:1.35), (localized redness on her lower abdomen:1.2)',
        '(soft diffuse redness confined to her lower abdomen:1.25), (mild irritation on her lower abdomen:1.1)',
        '(red handprint confined to her lower abdomen:1.15), (localized redness on her lower abdomen:1.05)'],
      'mark.belly.3': ['bruised abdomen, red handprint on abdomen',
        '(dark purple-red palm print confined to her lower abdomen:1.35), (localized swelling of her lower abdomen:1.2)',
        '(dark bruise on her lower abdomen:1.3), (visibly swollen lower abdomen:1.4)',
        '(deep crimson handprint confined to her lower abdomen:1.45), (localized swelling of her lower abdomen:1.3)',
        '(uneven muted red discoloration confined to her lower abdomen:1.3), (localized swelling of her lower abdomen:1.2)',
        '(red handprint confined to her lower abdomen:1.2), (localized swelling of her lower abdomen:1.1)'],
    };
    const PREVIOUS_BREAST_JEWELRY_NEGATIVE_PROMPTS = Object.freeze({
      'jewelry.breasts.1': `right nipple piercing, two nipple piercings, ${CHOKER_NEGATIVE_PROMPT}`,
      'jewelry.breasts.2': `single nipple piercing, missing nipple piercing, ${CHOKER_NEGATIVE_PROMPT}`,
    });
    const PREVIOUS_TOY_NEGATIVE_PROMPTS = Object.freeze({
      'toy.vulva.egg': ['penis-shaped vibrator, dildo, multiple vibrators, detached vibrator, vibrator outside body', 'dildo, (multiple vibrators:1.5), (extra vibrator:1.5), (vibrator outside body:1.5), holding_sex_toy'],
      'toy.vulva.penis': ['egg vibrator, vibrator cord, multiple vibrators, detached vibrator, vibrator outside body', 'egg_vibrator, vibrator_cord, (multiple vibrators:1.5), (extra dildo:1.5), (dildo outside body:1.5), holding_sex_toy'],
    });
    const DEFAULT_NEGATIVE_PROMPTS = {
      ...Object.fromEntries(Object.keys(DEFAULT_PROMPTS).map(key => [key, ''])),
      ...Object.fromEntries([1, 2, 3, 4, 5].map(stage => [`hstatus.crest.${stage}`, CREST_NEGATIVE_PROMPT])),
      ...Object.fromEntries(PREGNANCY_FIELDS.map(field => [field.key, field.negative])),
      ...Object.fromEntries([...CYCLE_FIELDS, ...FIRST_EXPERIENCE_FIELDS, ...SLEEP_FIELDS].map(field => [field.key, field.negative])),
      'restraint.handcuffed': 'handcuffed man, male wrists bound, shared handcuffs',
      'toy.vulva.egg': 'dildo, multiple vibrators, detached vibrator, (vibrator outside body:1.4), holding_sex_toy',
      'toy.vulva.penis': 'egg_vibrator, vibrator_cord, multiple vibrators, detached vibrator, (dildo outside body:1.4), holding_sex_toy',
    };
    const OUTFIT_STATE_OPTIONS = [
      ['clothed', '일반 착의'],
      ['partial', '부분 착의·속옷'],
      ['nude', '나체·장신구만'],
    ];
    const EXPOSED_OUTFIT_STATE = ['exposed', '해당 부위가 노출된 경우'];
    const ALL_OUTFIT_STATES = OUTFIT_STATE_OPTIONS.map(([value]) => value);
    const EXPOSED_DEFAULT_PARTS = new Set(['breasts', 'thighs', 'vulva']);
    const usesExposedDefault = key => key.startsWith('cycle.vulva.')
      || EXPOSED_DEFAULT_PARTS.has(String(key).match(/^(?:fluid|jewelry|toy)\.([^.]+)/)?.[1]);
    const DEFAULT_OUTFIT_STATE_OVERRIDES = {
      'attention.trouble': ['partial', 'nude'],
      'status.energy.3': ['partial', 'nude'],
      'fluid.uterus.0': ['nude', 'partial', 'clothed'],
      'fluid.uterus.1': [EXPOSED_OUTFIT_STATE[0]],
      'fluid.uterus.2': [EXPOSED_OUTFIT_STATE[0]],
      'fluid.uterus.3': [EXPOSED_OUTFIT_STATE[0]],
      'fluid.uterus.4': [EXPOSED_OUTFIT_STATE[0]],
      'toy.vulva.egg': [EXPOSED_OUTFIT_STATE[0], 'nude', 'partial'],
      'toy.vulva.penis': [EXPOSED_OUTFIT_STATE[0], 'nude', 'partial'],
    };
    const DEFAULT_OUTFIT_STATES = Object.fromEntries(Object.keys(DEFAULT_PROMPTS).map(key => [
      key,
      DEFAULT_OUTFIT_STATE_OVERRIDES[key]
        || (usesExposedDefault(key) ? [EXPOSED_OUTFIT_STATE[0]] : [...ALL_OUTFIT_STATES]),
    ]));
    const DEFAULT_DIALOGUE_RULES = [
      {
        id: 'dialogue-muzqz0av-1',
        text: '잠시 뒤 목덜미와 가슴 안쪽부터 설명하기 어려운 열기가 천천히 번지기 시작합니다',
        positivePrompt: 'blush, dazed expression', negativePrompt: '', duration: 'minutes', minutes: 120,
        outfitStates: [...ALL_OUTFIT_STATES],
      },
      {
        id: 'dialogue-muzxq0xh-2',
        text: '끝내 압박을 떨쳐내지 못하고 마십니다',
        positivePrompt: 'blush, dazed expression', negativePrompt: '', duration: 'minutes', minutes: 120,
        outfitStates: [...ALL_OUTFIT_STATES],
      },
      {
        id: 'dialogue-muzyywtf-3',
        text: '저항을 눌러 버리고',
        positivePrompt: 'tears, scared, humiliated expression', negativePrompt: '', duration: 'scene', minutes: 10,
        outfitStates: [...ALL_OUTFIT_STATES],
      },
    ];
    const DEFAULT_FLUID_DECAY = { enabled: true, intervalMinutes: 120 };
    const DEFAULT_CHARACTER_PROMPT = { positivePrompt: '', negativePrompt: '', mode: 'replace', imagePolicy: 'reuse' };
    const BUILTIN_WIFE_PROMPT_SOURCES = [
      ['elena_farmgirl', '엘레나'], ['mara_citygirl', '마라'], ['pippa_waif', '피파'],
    ];
    const EXTRA_LINES_DIALOGUE_SOURCES = [
      ['elena_farmgirl', '엘레나 대사'], ['mara_citygirl', '마라 대사'], ['pippa_waif', '피파 대사'], ['', '추가 대사 사용 안 함'],
    ];
    const OUTFIT_COLOR_OPTIONS = [
      ['', '선택 안 함'], ['black', '검정'], ['white', '흰색'], ['gray', '회색'], ['silver', '은색'],
      ['beige', '베이지'], ['cream', '크림색'], ['brown', '갈색'], ['red', '빨강'], ['burgundy', '버건디'],
      ['orange', '주황'], ['yellow', '노랑'], ['green', '초록'], ['blue', '파랑'], ['navy', '남색'],
      ['purple', '보라'], ['pink', '분홍'], ['gold', '금색'],
    ];
    const PROMPT_TAG_KO = {
      masterpiece: '최고 수준 작품', 'best quality': '최고 품질', 'amazing quality': '뛰어난 품질', portrait: '인물화', 'upper body': '상반신', 'full body': '전신',
      'bad quality': '나쁜 품질', 'worst quality': '최저 품질', 'worst detail': '나쁜 세부 표현', 'low quality': '낮은 품질', sketch: '스케치', censor: '검열 표시', blurry: '흐릿함', 'bad anatomy': '잘못된 인체 구조',
      'bad hands': '잘못된 손', '5 fingers': '손가락 5개', highres: '고해상도',
      'extra limbs': '팔다리 추가', deformed: '기형', text: '문자', watermark: '워터마크', signature: '서명', ugly: '추함',
      duplicate: '중복 인물', morbid: '병적인 표현', mutilated: '훼손된 신체', '3d': '3D', realistic: '실사풍', photorealistic: '사진 같은 실사풍',
      '1girl': '여성 1명', '2girls': '여성 2명', 'multiple girls': '여성 여러 명', solo: '단독 인물', solo_focus: '한 인물에 초점',
      multiple_boys: '남성 여러 명', hetero: '이성 간 행위', girl_on_top: '여성이 위', boy_on_top: '남성이 위',
      "grabbing_another's_breast": '상대의 가슴을 움켜쥠', "grabbing_another's_penis": '상대의 남성기를 움켜쥠',
      "grabbing_another's_ass": '상대의 엉덩이를 움켜쥠', "hand_on_another's_ass": '상대의 엉덩이에 손을 얹음',
      clitoral_stimulation: '클리토리스 자극', licking_penis: '남성기를 핥음', sucking_male_nipple: '남성 유두를 빪',
      "finger_in_another's_mouth": '상대의 입에 손가락을 넣음', face_to_breasts: '얼굴을 가슴에 댐',
      penis_on_pussy: '남성기를 여성기 입구에 맞댐', penis_on_ass: '남성기를 엉덩이에 맞댐',
      kneeling: '무릎 꿇기', lying: '눕기', on_back: '등을 대고 눕기', on_side: '옆으로 눕기',
      on_stomach: '엎드리기', all_fours: '네발 자세', bent_over: '몸을 숙임', folded: '몸을 접음',
      legs_up: '양다리 들기', leg_up: '한쪽 다리 들기', spread_legs: '다리 벌리기', leaning_forward: '앞으로 기울기',
      cowgirl_position: '기승위', reverse_cowgirl_position: '역기승위', doggystyle: '후배위',
      missionary: '정상위', spooning: '측위', mating_press: '프레스 체위', standing_sex: '서서 성교',
      against_wall: '벽에 기대기', suspended_congress: '안긴 채 서서 성교',
      kiss: '입맞춤', french_kiss: '혀를 섞는 키스', kissing_neck: '목에 키스', kissing_ear: '귀에 키스',
      biting_neck: '목을 깨묾', finger_sucking: '손가락 빨기', breast_sucking: '가슴 빨기',
      licking_nipple: '유두 핥기', licking_panties: '팬티 핥기', groping: '몸을 더듬음', fingering: '손가락 삽입',
      anal_fingering: '항문에 손가락 삽입', cunnilingus: '여성기 구강 애무', fellatio: '남성기 구강 애무',
      irrumatio: '남성이 구강 삽입', deepthroat: '깊은 구강 삽입', handjob: '손으로 남성기 애무',
      paizuri: '가슴 사이로 남성기 애무', sex: '성교', vaginal: '질 성교', anal: '항문 성교',
      frottage: '성기 비비기', voyeurism: '관음', '69': '69 자세', rough_sex: '거친 성교', undressing: '옷 벗기기',
      crying: '울음', sweat: '땀', tongue_out: '혀를 내밈', dazed: '멍한 표정', resisting: '저항함',
      spanking: '엉덩이 때리기', motion_blur: '움직임 잔상', 'emphasis line': '강조선', female_orgasm: '여성 절정',
      '^^^': '머리 옆 뾰족한 놀람 표시',
      'small white three-point surprise mark beside her head': '머리 옆의 작은 흰 놀람 표시',
      heavy_breathing: '거친 호흡', trembling: '몸 떨림', ahegao: '절정에 풀린 표정',
      partially_undressed: '옷 일부 벗음', handcuffs: '수갑', bound_wrists: '손목 묶임', rope: '밧줄', door: '문',
      facial: '얼굴에 사정', cum_on_body: '몸에 묻은 정액', breasts: '가슴', penis: '남성기',
      kisaragi_chihaya: '치하야',
      '1boy': '남성 1명', '2boys': '남성 2명', '3boys': '남성 3명', '4boys': '남성 4명', '5boys': '남성 5명',
      'long dark hair': '긴 짙은 머리', 'black hair': '검은 머리', 'brown hair': '갈색 머리', 'blonde hair': '금발', 'very long hair': '매우 긴 머리',
      'medium hair': '중간 길이 머리', 'straight hair': '생머리', 'shoulder-length brown hair': '어깨 길이 갈색 머리', 'side part': '옆가르마',
      'hair behind ear': '귀 뒤로 넘긴 머리', 'swept bangs': '옆으로 넘긴 앞머리', sidelocks: '옆머리', bangs: '앞머리',
      'brown eyes': '갈색 눈', 'hazel eyes': '헤이즐 눈', 'green eyes': '초록색 눈', 'pale skin': '창백한 피부', 'fair skin': '밝은 피부',
      'medium breasts': '중간 크기 가슴', 'large breasts': '큰 가슴', 'slim waist': '잘록한 허리', 'narrow waist': '잘록한 허리', 'athletic build': '탄탄한 체형',
      'sharper features': '뚜렷한 이목구비', 'distinctive jawline': '뚜렷한 턱선', 'makeup heavy': '진한 화장', 'heavy makeup': '진한 화장',
      'silver hair': '은빛 머리', 'detailed eyes': '세밀한 눈', 'expressive face': '표정이 잘 드러나는 얼굴', 'sharp focus': '선명한 초점', 'looking at viewer': '정면을 바라봄', 'looking at another': '다른 사람을 바라봄',
      faceless_male: '얼굴이 보이지 않는 남성', 'bright eyes': '생기 있는 눈', 'tired eyes': '피곤한 눈', 'soft eyes': '부드러운 눈빛',
      'white blouse': '흰 블라우스', 'buttoned up': '단추를 끝까지 잠금', 'high neckline': '목까지 올라오는 옷깃', 'long sleeves': '긴소매',
      'full-length skirt': '발목 길이 치마', apron: '앞치마', 'top button undone': '윗단추를 풀어 둠', 'collarbone visible': '쇄골이 보임',
      'fitted bodice': '몸에 맞는 보디스', 'knee-length skirt': '무릎 길이 치마', 'low neckline blouse': '깊게 파인 블라우스',
      cleavage: '가슴골', corset: '코르셋', 'skirt above knee': '무릎 위 치마', 'very low-cut top': '매우 깊게 파인 상의',
      'tight corset': '꽉 조인 코르셋', 'very short skirt': '매우 짧은 치마', 'bare shoulders': '드러난 어깨', 'bare legs': '맨다리',
      'lace lingerie': '레이스 란제리', 'see-through': '비치는 옷', stockings: '스타킹', 'garter belt': '가터벨트',
      nude: '나체', naked: '알몸', 'bare skin': '맨살', disheveled: '헝클어진 옷차림', 'pulled down': '아래로 내려간 옷',
      'exposed breasts': '드러난 가슴', 'skirt hiked up': '걷어 올린 치마', 'clothes pulled aside': '옆으로 젖힌 옷',
      'plain linen shift': '수수한 린넨 슈미즈', 'sleeves rolled up': '걷어 올린 소매', hair_up: '올림머리', nightshift: '잠옷',
      'bright smile': '환한 미소', cheerful: '쾌활함', energetic: '활기참', 'gentle smile': '부드러운 미소', content: '만족스러움',
      'calm expression': '차분한 표정', 'relaxed expression': '편안한 표정', focused: '집중함', 'weary expression': '지친 표정', 'worried expression': '걱정스러운 표정',
      tense: '긴장함', 'tense expression': '긴장한 표정', 'furrowed brow': '찌푸린 눈썹', glaring: '노려봄', smile: '미소', interested: '관심을 보임', blush: '홍조',
      'playful smile': '장난스러운 미소', shy: '수줍음', flustered: '당황함', 'looking away': '시선을 돌림', surprised: '놀람',
      seductive: '유혹적인 분위기', 'half-lidded eyes': '게슴츠레한 눈', pleasure: '쾌감', 'closed eyes': '눈을 감음', closed_eyes: '눈을 감음',
      'lost in it': '쾌감에 몰입함', 'parted lips': '살짝 벌어진 입술', 'looking up': '올려다봄', tears: '눈물', drooling: '침 흘림',
      moaning: '신음함', panting: '헐떡임', nervous: '긴장함', gripping: '꽉 붙잡음', confident: '자신감 있음',
      'rolling hips': '허리를 움직임', sweating: '땀 흘림', intense: '격렬함', overwhelmed: '압도됨', messy: '흐트러짐',
      afterglow: '여운에 잠김', satisfied: '만족한 표정', scared: '두려워함', 'wide eyes': '눈을 크게 뜸', troubled: '심란함', downcast: '고개를 숙임',
      'tavern interior': '선술집 내부', 'wooden tables': '나무 탁자', candlelight: '촛불', 'medieval tavern background': '중세 선술집 배경',
      'wooden wall': '나무 벽', 'wooden floor': '나무 바닥', lantern: '등불', barrel: '나무통', mug: '잔',
      'warm candlelight': '따뜻한 촛불', 'upstairs hall': '위층 복도', 'narrow wood corridor': '좁은 나무 복도', 'single sconce': '벽등 하나',
      'low light': '어두운 조명', hallway: '복도', indoors: '실내', bedroom: '침실', bed: '침대', 'single candle': '촛불 하나',
      'intimate lighting': '은은하고 사적인 조명', private: '사적인 공간', kitchen: '부엌', hearth: '화덕', steam: '수증기', firelight: '불빛',
      'warm lighting': '따뜻한 조명', 'soft morning light': '부드러운 아침 햇빛', 'dim bedroom light': '어두운 침실 조명',
      '1girl in bathtub': '욕조 안 여성 1명', ass: '엉덩이', breasts_out: '가슴 노출', crossdressing: '이성 복장',
      'girl bathing': '목욕 중인 여성', 'girl in tub': '욕조 안 여성', nipples: '유두', 'otoko no ko': '여장 남성', pussy: '여성기',
      'round porcelain basin': '둥근 도자기 욕조', 'toilet bowl': '변기', toilet: '화장실 설비', '1girl only': '여성 1명만', '3girls': '여성 3명',
      'bad proportions': '잘못된 신체 비율', bald: '대머리', 'bare forearms': '드러난 팔뚝', beard: '수염', biting_own_lip: '자기 입술을 깨묾',
      'booming presence': '압도적인 존재감', bottomless: '하의 없음', 'boyish face': '소년 같은 얼굴', 'breath uneven': '고르지 않은 숨',
      'breathing hard': '거칠게 숨 쉼', 'broad shoulders': '넓은 어깨', 'bushy beard': '덥수룩한 수염', 'clean-shaven': '면도한 얼굴',
      'cloak hiding body': '몸을 가리는 망토', 'close-up': '클로즈업', 'crooked nose': '휘어진 코', cropped: '잘린 구도', crowd: '군중',
      'cum on clothes': '옷에 묻은 정액', 'cum on dress': '드레스에 묻은 정액', 'cum on floor': '바닥에 묻은 정액',
      'cum on furniture': '가구에 묻은 정액', 'cum on table': '탁자에 묻은 정액', 'curly brown hair': '곱슬 갈색 머리',
      'dark beard': '짙은 수염', 'deep-set eyes': '깊게 들어간 눈', dignified: '품위 있음', 'distracted expression': '집중이 흐트러진 표정',
      'eager expression': '적극적인 표정', 'exposed ass': '드러난 엉덩이', freckles: '주근깨', gangbang: '다인 성행위', 'gaunt face': '수척한 얼굴',
      'girl in water': '물속의 여성', 'girl partially submerged': '몸 일부를 물에 담근 여성', 'group sex': '집단 성행위',
      'half-closed eyes': '반쯤 감긴 눈', 'half-closed_eyes': '반쯤 감긴 눈', head_back: '고개를 뒤로 젖힘', 'heavy armor': '중갑',
      'heavyset man': '덩치 큰 남성', intimidating: '위압적임', 'jolly expression': '유쾌한 표정', 'kind eyes': '인자한 눈빛',
      'lean man': '마른 남성', 'legs trembling': '다리가 떨림', 'long beard': '긴 수염', 'male in dress': '드레스를 입은 남성',
      'male in lingerie': '란제리를 입은 남성', 'male wearing skirt': '치마를 입은 남성', 'man in sheer clothing': '비치는 옷을 입은 남성',
      'matching outfits': '맞춰 입은 옷', 'merchant clothes': '상인 복장', 'messy hair': '헝클어진 머리', mmf_threesome: '남성 2명과 여성 1명',
      'modest cleavage': '살짝 보이는 가슴골', moustache: '콧수염', 'multiple views': '여러 시점', 'narrow eyes': '가늘게 뜬 눈',
      'neutral expression': '중립적인 표정', nightgown: '잠옷 드레스', 'no panties': '팬티 없음', 'panties aside': '팬티를 옆으로 젖힘',
      'practical boots': '실용적인 부츠', 'revealing clothing': '노출이 많은 옷', 'rough face': '거친 얼굴', 'rough hands': '거친 손',
      'round face': '둥근 얼굴', 'sandy hair': '모래빛 머리', 'scars on face': '얼굴 흉터', 'self-pleasure': '자위',
      'sharp features': '날카로운 이목구비', 'simple medieval tavern dress': '수수한 중세 선술집 드레스', 'sitting in basin': '욕조 안에 앉음',
      skirt_lift: '치마를 들어 올림', 'slight flush': '옅은 홍조', 'split screen': '분할 화면', 'square jaw': '각진 턱',
      'staring at cum': '정액을 바라봄', 'stocky man': '다부진 남성', stubble: '짧은 수염', 'sturdy build': '튼튼한 체격',
      'tall thin man': '키 크고 마른 남성', 'thighs pressed together': '허벅지를 붙임', 'thin frame': '마른 체격', threesome: '3인 성행위',
      'tight expression': '긴장으로 굳은 표정', 'top pulled down': '상의가 아래로 내려감', 'traveler clothes': '여행자 복장',
      'troubled expression': '심란한 표정', 'weathered face': '풍파를 겪은 얼굴', 'white porcelain tub': '흰 도자기 욕조',
      'working class': '노동자 계층', wrinkled: '주름진',
      standing: '서 있음', relaxed: '편안함', sitting: '앉아 있음', on_bed: '침대 위', 'welcoming gesture': '반기는 손짓',
      'arms at sides': '팔을 옆으로 둠', 'looking to the side': '옆을 바라봄', 'cowboy shot': '허벅지 위까지 보이는 구도',
      'friendly smile': '친근한 미소', 'tavern entrance': '선술집 입구', 'listening attentively': '주의 깊게 들음', 'notepad in hand': '손에 주문장을 듦',
      'carrying tray': '쟁반을 나름', alcohol: '술', 'busy tavern': '붐비는 선술집', 'wiping table': '탁자를 닦음', cleaning: '청소 중',
      'stirring pot': '냄비를 저음', 'sleeping peacefully': '평온하게 잠듦', 'lying in bed': '침대에 누움', 'head on pillow': '베개에 머리를 댐',
      'blanket pulled up': '이불을 끌어올림', 'passed out': '의식을 잃음', 'drunk and sleeping': '취해 잠듦', 'mouth slightly open': '입을 살짝 벌림',
      'slack body': '축 늘어진 몸', 'limp limbs': '힘없이 늘어진 팔다리', 'unconscious at the bar': '술집에서 의식을 잃음', open_mouth: '입을 벌림',
      'flushed cheeks': '붉어진 볼', 'pink cheeks': '분홍빛 볼', 'slight smile': '옅은 미소', 'glassy eyes': '풀린 눈', unsteady: '비틀거림',
      'very drunk': '매우 취함', 'unfocused gaze': '초점 없는 시선', leaning: '기댐', 'slack mouth': '힘없이 벌어진 입', 'half-conscious': '반쯤 의식이 없음',
      slumped: '축 처짐', 'drooping eyelids': '감기는 눈꺼풀', 'head down on table': '탁자에 고개를 떨굼', limp: '축 늘어짐',
      'tense atmosphere': '긴장된 분위기', 'urgent situation': '긴급한 상황', 'alert expression': '경계하는 표정',
      'secret encounter': '비밀스러운 만남', 'furtive atmosphere': '은밀한 분위기', 'cautious expression': '조심스러운 표정',
      'tense confrontation': '긴장된 대치', 'defensive posture': '방어적인 자세', 'distressed expression': '괴로운 표정',
      exhausted: '기진맥진', 'weary expression': '지친 표정', 'slumped posture': '축 처진 자세',
      hands_behind_back: '양손을 등 뒤로', wrists_bound_behind_back: '손목을 등 뒤로 묶음', handcuffed: '수갑을 참',
      'only female restrained': '여성만 구속됨', 'handcuffed woman': '수갑을 찬 여성', 'female wrists cuffed together': '여성의 두 손목을 함께 수갑으로 묶음',
      'female hands together': '여성의 두 손을 모음', 'metal handcuffs': '금속 수갑', 'short chain between cuffs': '수갑 사이의 짧은 사슬',
      'all males unrestrained': '모든 남성은 구속되지 않음', 'male hands free': '남성들의 손은 자유로움',
      'handcuffed man': '수갑을 찬 남성', 'restrained man': '구속된 남성', 'bound man': '묶인 남성', 'male bondage': '남성 구속',
      'male handcuffs': '남성의 수갑', 'male wrists together': '남성의 두 손목을 모음', 'male hands together': '남성의 두 손을 모음',
      'female wrists apart': '여성의 두 손목이 떨어짐', 'female hands separated': '여성의 두 손이 떨어짐', 'shared handcuffs': '남녀가 수갑을 함께 참',
      metal_handcuffs: '금속 수갑', iron_chains: '쇠사슬', shackles: '족쇄', unable_to_move: '움직일 수 없음', struggling: '몸부림침',
      'weak posture': '힘없는 자세', 'heavy eyelids': '무거운 눈꺼풀', tired: '피곤함', 'low energy': '기력 저하',
      'gloomy expression': '우울한 표정', 'deeply depressed': '심하게 침울함', 'sad expression': '슬픈 표정', 'subdued mood': '가라앉은 분위기',
      'slightly flushed': '살짝 붉어진 얼굴', 'subtle arousal': '은은한 흥분', 'flushed face': '붉어진 얼굴', aroused: '흥분함',
      'heavy breathing': '거친 숨', 'highly aroused': '매우 흥분함', 'deeply flushed': '짙게 붉어진 얼굴', 'intense arousal': '강한 흥분',
      'at the limit': '한계 상태', 'physically and mentally exhausted': '심신이 지침', unstable: '불안정함',
      'visibly distressed': '눈에 띄게 괴로워함', weary: '지침', 'strained expression': '힘겨운 표정',
      'size fits without visible physical strain': '크기를 무리 없이 받아들임', 'slight physical tension from the size': '크기로 인한 가벼운 긴장',
      'faint involuntary shiver': '몸이 미세하게 떨림', 'uneven breathing from the size': '크기 때문에 호흡이 고르지 않음',
      'slight body trembling': '몸이 조금 떨림', 'visibly struggling to accommodate the size': '크기를 받아들이기 버거워함',
      'body trembling': '몸을 떨림', 'at her physical limit from the size': '크기로 인해 신체적 한계에 이름',
      'whole body shaking': '온몸을 떨림', 'subtle penis-shaped bulge in her lower abdomen from the insertion': '삽입으로 아랫배에 희미한 남성기 모양 돌출',
      'clear penis-shaped bulge pushing out her lower abdomen from within': '안쪽에서 밀려 나온 선명한 남성기 모양 아랫배 돌출',
      'pronounced penis-shaped bulge pushing out her lower abdomen from within': '안쪽에서 밀려 나온 뚜렷한 남성기 모양 아랫배 돌출',
      'very slight penis-shaped rise low on her abdomen from vaginal insertion': '질 삽입으로 아랫배 아래쪽에 아주 약한 남성기 형태의 굴곡',
      'small localized penis-shaped rise low on her abdomen from vaginal insertion': '질 삽입으로 아랫배 아래쪽에 작고 국소적인 남성기 형태의 굴곡',
      'localized shallow penis-shaped bulge visible low on her abdomen from vaginal insertion': '질 삽입으로 아랫배 아래쪽에 보이는 얕고 국소적인 남성기 형태의 돌출',
      'distinct small penis-shaped bulge visible low on her abdomen from vaginal insertion': '질 삽입으로 아랫배 아래쪽에 보이는 작고 분명한 남성기 형태의 돌출',
      'small shallow penis-shaped bulge visible low on her abdomen from vaginal insertion': '질 삽입으로 아랫배 아래쪽에 보이는 작고 얕은 남성기 형태의 돌출',
      'lips parted in a pained gasp': '버거워 입술을 벌리고 숨을 들이킴',
      'overwhelmed expression': '압도되어 버거운 표정',
      'rounded lips in a breathless gasp': '숨을 삼키며 둥글게 벌어진 입술',
      'anal penetration without visible physical strain': '애널 삽입을 무리 없이 받아들임',
      'slight tension in her hips from anal penetration': '애널 삽입으로 엉덩이에 가벼운 긴장',
      'hips tensing around anal penetration': '애널 삽입에 엉덩이가 긴장함',
      'visibly struggling with anal penetration': '애널 삽입을 버거워함', 'tense hips': '긴장한 엉덩이',
      'at her physical limit from anal penetration': '애널 삽입으로 신체적 한계에 이름',
      'alluring pose': '매혹적인 자세', 'captivating presence': '시선을 끄는 분위기', 'guarded expression': '경계하는 표정',
      'emotionally distant': '정서적으로 멀어짐', 'longing gaze': '갈망하는 눈빛', 'affectionate expression': '애정 어린 표정',
      'resentful expression': '원망하는 표정', 'deep resentment': '깊은 원망', 'hostile expression': '적대적인 표정',
      'averted gaze': '시선을 피함', 'uneasy expression': '불편한 표정', conflicted: '갈등함', tipsy: '살짝 취함',
      'faint blush': '옅은 홍조', drunk: '취함', 'unsteady posture': '비틀거리는 자세', 'heavily drunk': '만취함',
      'dazed expression': '멍한 표정', 'extremely drunk': '몸을 못 가눌 정도로 취함', 'unfocused eyes': '초점 없는 눈',
      'unable to stand steadily': '제대로 서지 못함', unconscious: '의식 없음', 'limp body': '축 늘어진 몸',
      'angry expression': '화난 표정', 'contemptuous expression': '경멸하는 표정', 'disgusted expression': '혐오하는 표정',
      averting_eyes: '시선을 피함', frown: '미간을 찌푸림', grimace: '괴로운 표정', hug: '껴안기',
      clenched_teeth: '이를 악묾', disgust: '혐오감', pain: '고통', restrained: '제압당함',
      expressionless: '표정 없음', seductive_smile: '유혹적인 미소', forced: '강압', rape: '강간', happy: '행복한 표정',
      armor: '갑옷', leather_armor: '가죽 갑옷', cape: '망토', cloak: '여행용 망토',
      apron: '앞치마', chisel: '끌', crystal_ball: '수정구', mandolin: '만돌린',
      mature_male: '성인 남성', old_man: '나이 든 남성', grey_hair: '회색 머리', short_hair: '짧은 머리',
      priest: '성직자', stole: '성직자 영대', cassock: '사제복', monk: '수도사', rosary: '묵주', mitre: '주교관',
      carpenter: '목수', farmer: '농부', merchant: '상인', butcher: '백정', thief: '도둑', knight: '기사', soldier: '군인',
      formal_clothes: '격식 있는 옷', ornate_clothes: '화려한 옷', torn_clothes: '낡은 옷',
      wedding_ring: '결혼반지', pearl_earrings: '진주 귀걸이', perfume_bottle: '향수병',
      ring: '반지', key: '열쇠', bottle: '병', vial: '작은 약병', book: '책', letter: '편지',
      basket: '바구니', apple: '사과', flour: '밀가루', backpack: '배낭', bag: '가방',
      sword: '검', shield: '방패', crossbow: '석궁', knife: '칼', whip: '채찍', reins: '고삐',
      lockpick: '자물쇠 따개', magnifying_glass: '돋보기', wood_carving_tool: '나무 조각 도구',
      tape_measure: '줄자', scales: '저울', hook: '갈고리', toothpick: '이쑤시개',
      white_gloves: '흰 장갑', vest: '조끼', mask: '가면', scar: '흉터',
      fat_man: '체격이 큰 남성', tan: '햇볕에 그을림', red_nose: '붉은 코',
      thigh_sex: '허벅지 사이 성교', thighs: '허벅지',
      dirty: '더러움', stubble: '턱수염 자국', blood_stain: '핏자국', dirty_hands: '더러운 손',
      stained_clothes: '얼룩진 옷', bad_teeth: '상한 치아', vomit: '토사물', rust: '녹',
      messy_hair: '헝클어진 머리', grey_beard: '회색 수염', liver_spots: '검버섯',
      "hand_on_another's_neck": '상대의 목에 손을 댐', neck_grab: '상대의 목을 움켜쥠',
      "holding_another's_wrist": '상대의 손목을 붙잡음', "grabbing_another's_hair": '상대의 머리채를 잡음',
      head_grab: '상대의 머리를 붙잡음',
      embarrassed: '당황함', 'downcast eyes': '눈을 내리깜', 'guilty expression': '죄책감 어린 표정',
      'regretful expression': '후회하는 표정', 'humiliated expression': '굴욕적인 표정', 'tender expression': '다정한 표정',
      'yearning gaze': '그리워하는 눈빛', 'desirous expression': '욕망하는 표정', 'worried expression': '걱정스러운 표정',
      'seeking approval': '인정을 바람', 'anxious expression': '불안한 표정', 'lonely expression': '외로운 표정',
      'proud posture': '자부심 있는 자세', 'yearning expression': '갈망하는 표정',
      cum_in_mouth: '입 안에 정액', cum_on_tongue: '혀 위에 정액', cum_dripping_from_mouth: '입에서 정액이 흐름', excessive_cum: '많은 정액',
      cum_on_breasts: '가슴에 정액', cum_on_chest: '가슴팍에 정액', dripping_cum: '정액이 흘러내림',
      creampie: '질내 사정', cum_in_pussy: '질 안에 정액', overflowing_creampie: '질내 정액이 넘쳐흐름',
      slightly_wet_pussy: '살짝 젖은 보지', wet_pussy: '젖은 보지', pussy_juice: '애액', pussy_juice_dripping: '애액이 흘러내림',
      excessive_pussy_juice: '많은 애액', cum_on_thighs: '허벅지에 정액', cum_dripping_thighs: '허벅지로 정액이 흐름',
      nipple_piercing: '유두 피어싱', single_nipple_piercing: '한쪽 유두 피어싱', pierced_nipples: '양쪽 유두 피어싱',
      heart_choker: '하트 초커', clitoris_piercing: '클리토리스 피어싱', genital_piercing: '성기 피어싱',
      'subtle involuntary pleasure reaction': '은은한 무의식적 쾌감 반응', 'soft blush': '은은한 홍조',
      'gently trembling eyelids': '살며시 떨리는 눈꺼풀', 'lightly tensed eyebrows': '살짝 긴장된 눈썹',
      'intense internal pressure pleasure expression': '강한 내부 압박 쾌감 표정', 'trembling eyelids': '떨리는 눈꺼풀',
      'knitted inner eyebrows': '안쪽으로 모인 눈썹', 'involuntary shiver': '무의식적인 떨림',
      'consistent character identity': '인게임과 같은 캐릭터 정체성', 'consistent hair color': '같은 머리색 유지',
      'consistent eye color': '같은 눈색 유지', 'consistent skin tone': '같은 피부색 유지', 'consistent body proportions': '같은 체형 비율 유지',
      'consistent facial features': '같은 얼굴 특징 유지',
      'fixed h-status composition': 'H-Status 고정 구도', 'same camera angle and crop across every status level': '모든 상태 단계에서 같은 카메라 각도와 크롭 유지',
      'consistent game cg anime coloring': '일관된 게임 CG 애니 채색', 'consistent warm candlelight color grading': '일관된 따뜻한 촛불 색감',
      'character-accurate natural skin tone': '현재 아내와 일치하는 자연스러운 피부색', 'uniform natural skin tone across visible body': '보이는 신체 전체의 자연스러운 피부색 통일',
      '1216 by 832 landscape composition': '1216×832 가로 구도',
      'tight frontal crop from waist to upper thighs': '허리부터 허벅지 위쪽까지 정면 확대', 'vulva centered in frame': '외음부를 화면 중앙에 배치',
      'face out of frame': '얼굴은 화면 밖', 'chest out of frame': '가슴은 화면 밖', 'single panel': '단일 화면', 'single uninterrupted image': '나뉘지 않은 단일 이미지', 'one view': '한 시점',
      'extreme crotch close-up': '가랑이 초근접 확대', 'extreme bare crotch close-up': '맨살 가랑이 초근접 확대', 'tight frontal crop from lower abdomen to upper thighs': '하복부부터 허벅지 위쪽까지 정면 확대',
      'continuous bare skin across the lower abdomen and groin': '하복부와 사타구니가 천 없이 이어진 맨살', 'fully exposed bare vulva': '옷에 가리지 않고 완전히 드러난 외음부',
      'fully uncovered bare vulva': '천에 가리지 않고 완전히 드러난 외음부', 'vulva centered and fills the frame': '외음부가 화면 중앙을 가득 채움',
      'completely nude from waist down': '허리 아래 완전 나체', 'naked hips': '맨살 골반', 'bare inner thighs': '맨살 허벅지 안쪽', 'genitals unobstructed': '성기가 가려지지 않음',
      'surrounding vulva skin matches the inner thighs': '외음부 주변 피부색을 허벅지 안쪽과 일치', 'natural skin-colored mons pubis': '자연스러운 피부색의 치구',
      'subtle healthy pink limited to the inner labia': '안쪽 음순에만 은은하고 건강한 분홍색',
      'integrated lower-abdomen anatomical cutaway': '하복부에 직접 통합된 해부 단면', 'opaque natural skin around the cutaway': '단면 주변은 불투명한 자연 피부',
      'one centered stylized uterus with one cervix and one straight vertical vaginal canal': '중앙에 자궁 하나·자궁경부 하나·곧은 수직 질관 하나 표시',
      'seamless borderless cutaway drawn directly inside the lower abdomen': '하복부 안에 테두리 없이 바로 이어지는 단면',
      'crop from lower abdomen to upper thighs': '하복부부터 허벅지 위쪽까지 자름',
      'tight close-up showing only lower abdomen and upper thighs': '하복부와 허벅지 위쪽만 보이는 근접 구도',
      'flat stylized anatomical overlay without open body cavity': '열린 신체 구멍이 아닌 평면형 해부 오버레이',
      'stylized 2d anime h-status illustration': '2D 애니풍 H-Status 상태 그림',
      'fixed frontal crop from navel to upper thighs': '배꼽부터 허벅지 위쪽까지 정면 고정 구도',
      'one continuous adult female lower torso': '끊기지 않은 성인 여성 하반신 하나', 'one centered pelvis': '중앙에 골반 하나',
      'smooth intact opaque natural skin': '매끈하고 온전한 불투명 자연 피부',
      'one clean simple pink uterus status graphic integrated into the lower abdomen': '하복부에 자연스럽게 통합된 단순한 분홍색 자궁 상태 그림 하나',
      'one pear shaped uterine cavity and one short vertical canal': '배 모양 자궁강 하나와 짧은 수직 질관 하나',
      'simple rounded shapes': '단순하고 둥근 형태', 'fixed identical frontal viewpoint and crop': '같은 정면 시점과 구도를 고정',
      'symbolic vaginal canal drawn as a narrow closed line': '좁게 닫힌 선으로 표시한 상징적 질관',
      'symbolic vaginal canal drawn as a slightly open narrow line': '살짝 열린 좁은 선으로 표시한 상징적 질관',
      'symbolic vaginal canal drawn as a moderately open line': '적당히 열린 선으로 표시한 상징적 질관',
      'internal tissue close-up': '내부 조직 확대', 'realistic internal tissue': '사실적인 내부 조직', 'wet mucosa': '젖은 점막',
      'fleshy tunnel': '살점 터널', 'fleshy walls': '살점 벽', 'body made of flesh': '살점으로 변한 신체',
      'skin texture filling background': '배경을 채운 피부 질감', 'tiled skin': '타일처럼 반복된 피부', 'stacked torsos': '위아래로 겹친 몸통',
      'duplicated pelvis': '중복된 골반', 'multiple vulvas': '여러 외음부', 'portrait orientation': '세로 구도', 'vertical composition': '세로형 구성',
      'solid white shaft': '하얀 막대 형태', 'white dildo': '하얀 딜도', 'phallic semen': '남성기처럼 뭉친 정액',
      'lower abdomen bare vulva and upper thighs only': '하복부·맨 외음부·허벅지 위쪽만 표시',
      'fixed frontal chest status card': '정면 고정 가슴 상태 카드', 'crop from shoulders to upper waist': '어깨부터 허리 위쪽까지 자름',
      'both breasts fully visible and centered': '양쪽 가슴 전체를 중앙에 표시',
      'breasts proportional to character body type': '캐릭터 체형에 비례한 가슴', 'natural breast volume': '자연스러운 가슴 부피',
      'medium chest shot': '가슴 중간 확대 구도', 'visible collarbones': '쇄골이 보임', 'visible ribcage and upper waist': '흉곽과 상복부가 보임',
      'space around both sides of torso': '몸통 양옆에 여백', 'breast size follows the character prompt exactly': '캐릭터 프롬프트의 가슴 크기를 정확히 유지',
      'matte cel-shaded skin': '무광 셀 채색 피부', 'soft diffuse skin highlights': '부드럽고 퍼진 피부 하이라이트',
      'clean even skin surface': '깨끗하고 균일한 피부 표면', 'breast volume follows the current wife size tags': '현재 아내 크기 태그에 맞는 가슴 볼륨',
      'natural breast separation': '자연스럽게 떨어진 가슴',
      'fixed frontal chest crop': '정면 고정 가슴 구도', 'both breasts inside frame': '양쪽 가슴이 화면 안에 표시됨',
      'fixed frontal crop from waist to upper thighs': '허리부터 허벅지 위쪽까지 정면 고정 구도',
      'fixed frontal lower-torso crop': '하복부 정면 고정 구도', 'lower abdomen and upper thighs inside frame': '하복부와 허벅지 위쪽이 화면 안에 표시됨',
      'fixed frontal lower-body crop': '정면 고정 하체 구도', 'both inner thighs inside frame': '양쪽 허벅지 안쪽이 화면 안에 표시됨',
      'fixed frontal lower-body status card': '정면 고정 하체 상태 카드', 'crop from lower abdomen to just above the knees': '하복부부터 무릎 바로 위까지 자름',
      'complete unobstructed vulva visible at the upper center': '화면 위쪽 중앙에 가려지지 않은 외음부 전체 표시', 'both inner thighs fully visible': '양쪽 허벅지 안쪽 전체 표시',
      'complete unobstructed natural vulva visible at the upper center': '화면 위쪽 중앙에 가려지지 않은 자연스러운 외음부 전체 표시',
      "one silver ring on the character's anatomical left nipple only": '캐릭터 기준 왼쪽 유두에만 은색 링 하나',
      "character's anatomical right nipple completely bare and unpierced": '캐릭터 기준 오른쪽 유두는 장신구 없이 완전히 미착용',
      "one silver ring on the character's anatomical right nipple only": '캐릭터 기준 오른쪽 유두에만 은색 링 하나',
      "character's anatomical left nipple completely bare and unpierced": '캐릭터 기준 왼쪽 유두는 장신구 없이 완전히 미착용',
      'one matching silver ring on each nipple': '양쪽 유두에 같은 은색 링을 하나씩 착용',
      "exactly one small silver captive bead ring pierced through the center of the character's anatomical left nipple (viewer right) only": '캐릭터 기준 왼쪽 유두 중앙(화면 오른쪽)에 작은 은색 캡티브 비드 링 하나만',
      "character's anatomical right nipple (viewer left) completely bare and unpierced": '캐릭터 기준 오른쪽 유두(화면 왼쪽)는 완전히 미착용',
      "exactly one small silver captive bead ring pierced through the center of the character's anatomical right nipple (viewer left) only": '캐릭터 기준 오른쪽 유두 중앙(화면 왼쪽)에 작은 은색 캡티브 비드 링 하나만',
      "character's anatomical left nipple (viewer right) completely bare and unpierced": '캐릭터 기준 왼쪽 유두(화면 오른쪽)는 완전히 미착용',
      'exactly one small silver captive bead ring pierced through the center of each nipple': '양쪽 유두 중앙에 작은 은색 캡티브 비드 링을 하나씩',
      "only the character's anatomical left nipple (viewer right) has one tiny silver captive bead ring": '캐릭터 기준 왼쪽 유두(화면 오른쪽)에 아주 작은 은색 캡티브 비드 링 하나만',
      "only the character's anatomical right nipple (viewer left) has one tiny silver captive bead ring": '캐릭터 기준 오른쪽 유두(화면 왼쪽)에 아주 작은 은색 캡티브 비드 링 하나만',
      'each nipple has exactly one tiny silver captive bead ring through its center': '양쪽 유두 중앙에 아주 작은 은색 캡티브 비드 링을 하나씩',
      'one matching subtle flush ring on each nipple': '각 유두에 같은 작은 밀착형 링 하나', 'tiny subtle ring pierced through nipple center': '유두 중앙을 관통한 아주 작은 링',
      'black leather heart choker fitted snugly around her neck': '목에 꼭 맞게 착용한 검은 가죽 하트 초커',
      'small heart-shaped pendant centered at the front of her neck': '목 앞 중앙의 작은 하트 모양 펜던트',
      'base of neck visible at top of frame': '화면 위쪽에 목 아랫부분이 보임', 'one continuous fitted neck band': '끊김 없이 목에 밀착된 밴드 하나',
      'heart-shaped choker': '하트 모양 초커', 'black leather choker': '검은 가죽 초커', 'slave collar': '노예 목걸이',
      'neck restraint': '목 구속구', 'neck shackle': '목 족쇄', 'chain around neck': '목을 두른 체인',
      'jewelry flush against nipple': '유두에 밀착된 장식', 'no hanging section': '아래로 늘어진 부분 없음',
      'ring diameter much smaller than areola': '유륜보다 훨씬 작은 링', 'exactly one nipple piercing total': '유두 피어싱은 전체 한 개만',
      'exactly two nipple piercings total': '유두 피어싱은 전체 두 개만',
      'one matching snug ring on each nipple': '각 유두에 같은 밀착형 링 하나', 'ring snug against nipple': '유두에 밀착된 링',
      'ring diameter smaller than areola': '유륜보다 작은 링', 'modest natural bust': '자연스럽고 작은 가슴',
      'oversized nipple ring': '너무 큰 유두 링', 'dangling nipple jewelry': '늘어진 유두 장식', 'nipple chain': '유두 체인',
      'linked nipple rings': '서로 연결된 유두 링', 'hands holding nipple jewelry': '손으로 유두 장식을 잡음',
      'covered vulva': '가려진 외음부', 'fabric over crotch': '가랑이를 덮는 천', 'clothed lower body': '옷을 입은 하체',
      'anatomical cutaway': '해부 단면', 'x-ray': '엑스레이', xray: '엑스레이', 'x ray': '엑스레이',
      'transparent skin': '투명 피부', 'translucent skin': '반투명 피부', uterus: '자궁', bra: '브래지어', panties: '팬티', underwear: '속옷', dildo: '딜도',
      'transparent whole body': '전신 투명', 'translucent whole body': '전신 반투명', 'transparent torso': '몸통 투명', 'translucent torso': '몸통 반투명',
      'full-body x-ray': '전신 엑스레이', 'whole-body x-ray': '전신 엑스레이', 'visible ribcage': '드러난 흉곽',
      'localized x-ray cutaway overlay on opaque lower-abdomen skin': '불투명한 하복부 피부 위의 국소 X-ray 단면 오버레이',
      'visible lungs': '드러난 폐', 'visible heart': '드러난 심장', 'visible intestines': '드러난 장기', 'skeletal body': '골격이 드러난 몸',
      collage: '콜라주', 'multiple panels': '여러 패널', 'contact sheet': '모음 시트',
      'one clearly phallic penis-shaped vibrator silhouette': '남성기형 바이브 하나의 뚜렷한 윤곽',
      'artificial saturated-purple silicone dildo vibrator': '인공 진보라색 실리콘 남성기형 바이브', 'molded rounded glans ridge': '성형된 둥근 귀두 테두리',
      'continuous defined shaft': '끊김 없이 선명한 축', 'lower shaft and flared safety base remain visibly outside the vaginal opening': '아래쪽 축과 넓은 안전 받침이 질 입구 밖에 보임',
      'labia close around the shaft': '음순이 축 둘레를 감쌈', 'rounded toy tip stops below the cervix': '둥근 토이 끝이 자궁경부 아래에서 멈춤',
      'flared safety base remains visibly outside the vaginal opening': '넓은 안전 받침이 질 입구 밖에 보임',
      'one unmistakably artificial elongated silicone vibrator': '실제 신체가 아닌 길쭉한 인공 실리콘 바이브 하나',
      'saturated purple synthetic toy': '선명한 보라색 인공 토이', 'smooth seamless cylindrical toy body': '이음새 없이 매끈한 원통형 토이 몸체',
      'blunt rounded silicone tip': '뭉툭하고 둥근 실리콘 끝', 'rigid molded purple control-button base visibly outside the vaginal opening': '질 입구 밖에 보이는 단단한 보라색 버튼형 받침',
      'blunt rounded silicone tip positioned within the vaginal canal below the cervix': '자궁경부 아래 질관 안에 놓인 뭉툭하고 둥근 실리콘 끝',
      'uniform manufactured surface': '균일한 공산품 표면', 'simplified sex-toy geometry': '단순화된 성인용 토이 형태', 'labia around the toy': '토이 둘레의 음순',
      "the character's natural skin tone stays unchanged": '캐릭터의 자연스러운 피부색을 그대로 유지',
      'purple color confined to the vibrator': '보라색은 바이브에만 한정',
      'labia majora clearly visible on both sides': '양쪽 외음순이 선명하게 보임',
      'vaginal opening clearly visible': '질 입구가 선명하게 보임',
      'labia majora clearly visible on both sides of the inserted toy': '삽입된 토이 양쪽에 외음순이 선명하게 보임',
      'toy visibly enters the vaginal opening': '토이가 질 입구로 들어가는 지점이 보임',
      'purple skin': '보라색 피부', 'violet skin': '자주색 피부', 'lavender skin': '연보라색 피부', 'purple-tinted skin': '보랏빛 피부',
      'purple body': '보라색 신체', 'violet body': '자주색 신체', 'purple color cast on skin': '피부에 번진 보라색', 'toy color bleeding into skin': '토이 색이 피부로 번짐',
      'hidden labia majora': '가려진 외음순', 'missing labia majora': '사라진 외음순', 'toy covering the entire vulva': '토이가 외음부 전체를 가림',
      'toy floating in front of the vulva': '토이가 외음부 앞에 떠 있음', 'hands in frame': '화면 안의 손', 'fingers in frame': '화면 안의 손가락', 'hands covering vulva': '손이 외음부를 가림',
      'camera in frame': '화면 안의 카메라', 'camera device': '촬영 기기', 'viewfinder overlay': '뷰파인더 표시', 'recording overlay': '녹화 표시',
      'REC icon': 'REC 아이콘', 'battery icon': '배터리 아이콘', 'shutter button': '셔터 버튼', 'camera frame': '카메라 프레임', 'on-screen camera interface': '화면의 카메라 UI',
      'emotionless face': '감정 없는 얼굴', 'blank expression': '멍한 표정', 'egg-shaped vibrator': '에그형 바이브',
      'oval vibrator': '타원형 바이브', 'bullet vibrator': '불릿 바이브', 'retrieval cord': '회수용 줄',
      'human penis': '사람의 남성기', 'real penis': '실제 남성기', 'flesh-colored genital': '살색 성기', 'realistic male genital anatomy': '사실적인 남성 성기 구조',
      glans: '귀두', foreskin: '포피', urethra: '요도', 'penile veins': '남성기 혈관', testicles: '고환', scrotum: '음낭',
      'skin texture on device': '기기에 생체 피부 질감', 'organic flesh': '생체 살점', 'severed penis': '절단된 남성기', 'detached penis': '분리된 남성기',
      'male body': '남성 신체', 'attached male body': '연결된 남성 신체', 'real human penis attached to a person': '사람에게 연결된 실제 남성기',
      thong: '티팬티', 'g-string': '지스트링', 'crotch strap': '가랑이 끈', 'pelvic strap': '골반 끈', 'black strap': '검은 끈',
      'black fabric': '검은 천', 'fabric strip': '천 조각', 'cloth strip': '천 조각', 'genital covering': '성기 가림',
      inset: '삽입 화면', 'picture-in-picture': '화면 속 화면', 'diagram inset': '도해 삽입 화면', 'panel border': '패널 테두리',
      face: '얼굴', 'standing pose': '서 있는 자세', 'distant shot': '먼 거리 구도',
    };
    const PROMPT_WORD_KO = {
      best: '최고', quality: '품질', portrait: '인물화', upper: '상부', full: '전체', body: '몸', girl: '여성', girls: '여성들', boy: '남성', boys: '남성들',
      solo: '단독', multiple: '여러', long: '긴', short: '짧은', dark: '짙은', light: '밝은', hair: '머리', eyes: '눈', eye: '눈',
      black: '검은', brown: '갈색', blond: '금발', blonde: '금발', red: '붉은', white: '흰', grey: '회색', gray: '회색', silver: '은빛', green: '초록색', blue: '파란색',
      medium: '중간 크기', large: '큰', huge: '매우 큰', gigantic: '거대한', breasts: '가슴', breast: '가슴', slim: '날씬한', waist: '허리',
      tall: '키 큰', petite: '아담한', slender: '가녀린', curvy: '굴곡진', athletic: '탄탄한', muscular: '근육질', build: '체형', figure: '몸매',
      young: '젊은', old: '나이 든', 'middle-aged': '중년', elderly: '노년', woman: '여성', man: '남성', female: '여성', male: '남성',
      smile: '미소', expression: '표정', cheerful: '쾌활한', calm: '차분한', focused: '집중한', worried: '걱정스러운', weary: '지친', tired: '피곤한',
      shy: '수줍은', blush: '홍조', scared: '두려운', tense: '긴장한', angry: '화난', gentle: '부드러운', soft: '부드러운', bright: '환한',
      happy: '행복한', sad: '슬픈', playful: '장난스러운', nervous: '긴장한', proud: '자부심 있는', affectionate: '다정한', lonely: '외로운',
      looking: '바라봄', viewer: '정면', down: '아래', up: '위', away: '다른 곳', another: '다른 사람', gaze: '시선', mouth: '입', lips: '입술',
      closed: '감은', open: '벌린', parted: '살짝 벌린', flushed: '붉어진', cheeks: '볼', tears: '눈물', drooling: '침 흘림',
      tavern: '선술집', interior: '내부', medieval: '중세', background: '배경', wooden: '나무', tables: '탁자', table: '탁자', candlelight: '촛불',
      room: '방', bedroom: '침실', kitchen: '부엌', bathhouse: '목욕탕', hallway: '복도', corridor: '복도', upstairs: '위층', indoors: '실내', private: '사적인 공간',
      candle: '촛불', sconce: '벽등', lighting: '조명', morning: '아침', dim: '어두운', warm: '따뜻한', firelight: '불빛', steam: '수증기',
      standing: '서 있음', sitting: '앉아 있음', lying: '누워 있음', kneeling: '무릎 꿇음', sleeping: '잠듦', relaxed: '편안함',
      carrying: '나름', tray: '쟁반', wiping: '닦음', cleaning: '청소', stirring: '저음', pot: '냄비', holding: '들고 있음',
      dress: '드레스', blouse: '블라우스', skirt: '치마', apron: '앞치마', corset: '코르셋', lingerie: '란제리', stockings: '스타킹',
      sleeves: '소매', neckline: '옷깃', bodice: '보디스', clothes: '옷', clothing: '옷차림', nude: '나체', naked: '알몸', bare: '드러난', skin: '피부',
      exposed: '드러난', pulled: '당겨진', aside: '옆으로 젖힘', hiked: '걷어 올림', disheveled: '헝클어진', button: '단추', undone: '풀림',
      drunk: '취함', unconscious: '의식 없음', exhausted: '기진맥진', struggling: '몸부림침', unable: '불가능', move: '움직임',
      handcuffed: '수갑을 참', handcuffs: '수갑', chains: '쇠사슬', shackles: '족쇄', bound: '묶임', wrists: '손목', hands: '손',
      piercing: '피어싱', pierced: '피어싱한', choker: '초커', cum: '정액', wet: '젖은', dripping: '흐름', excessive: '많은',
      overlay: '겹쳐 표시', chamber: '상태 공간', opaque: '불투명', contained: '내부에 한정', rounded: '둥근', stem: '짧은 세로선', empty: '비어 있음',
      masterpiece: '최고 수준 작품', blurry: '흐릿함', deformed: '기형', anatomy: '인체 구조', limbs: '팔다리', watermark: '워터마크', signature: '서명', text: '문자',
    };
    const TAG_CATEGORIES = [
      ['all', '전체'], ['quality', '품질'], ['character', '인물·외형'], ['outfit', '의상·노출'], ['mood', '기분·표정'],
      ['action', '행동·자세'], ['location', '장소·배경'], ['lighting', '조명·구도'], ['status', '상태·장신구'], ['custom', '사용자'], ['other', '기타'],
    ];
    const SECRET_IMAGE_PROFILE = { workflow: 'illustrious', width: 1216, height: 832, dimensions: '1216 x 832 (1.46:1)' };
    const RESIDUE_PART_SOURCE_OPTIONS = [
      ['generate', '현재 아내로 생성'], ['pippa', '피파 기본 이미지'],
      ['mara', '마라 기본 이미지'], ['elena', '엘레나 기본 이미지'],
    ];
    const RESIDUE_PART_SOURCE_VALUES = new Set(RESIDUE_PART_SOURCE_OPTIONS.map(([value]) => value));
    const SECRET_IMAGE_PROMPTS = {
      identityConsistency: '(consistent character identity:1.25), (same camera angle and crop across every status level:1.3), 1216 by 832 landscape composition',
      faceIdentityConsistency: 'consistent hair color, consistent eye color, consistent facial features',
      eggExpression: '(subtle involuntary pleasure reaction:1.3), soft blush, gently trembling eyelids, lightly tensed eyebrows',
      penisExpression: '(intense internal pressure pleasure expression:1.45), flushed cheeks, trembling eyelids, knitted inner eyebrows, involuntary shiver',
      vulvaCloseup: 'single uninterrupted image, one view, (fixed frontal crop from waist to upper thighs:1.35), face out of frame, chest out of frame',
      uterusCutaway: 'single uninterrupted image, one view, extreme close-up, (frontal female lower torso only:1.7), (fixed crop from navel to upper thighs:1.8), navel at the top frame edge, both upper thighs at the bottom frame edge, head out of frame, upper torso out of frame, breasts out of frame, arms out of frame, hands out of frame, symmetrical centered pelvis, legs together, (smooth intact opaque natural skin:1.5), (one flat translucent pink H-Status overlay centered on the lower abdomen:1.8), (one simple stylized uterus icon:1.7), (one short rounded pink chamber:1.65), skin clearly visible around the overlay, clean 2D lineart, flat cel shading, restrained highlights, simple dark background',
      uterusStage0: '(empty pink status chamber:1.6), no white fill inside the chamber',
      uterusStage1: '(tiny opaque white status fill contained at the bottom of the pink chamber:1.6)',
      uterusStage2: '(small opaque white status fill contained in the lower third of the pink chamber:1.65)',
      uterusStage3: '(opaque white status fill contained in the lower half of the pink chamber:1.7)',
      uterusStage4: '(opaque white status fill contained inside most of the pink chamber:1.75), narrow pink rim remains visible, no overflow',
      uterusUnsafePositive: 'frontal lower-torso erotic game x-ray status illustration, translucent skin, transparent lower abdomen, transparent body, faint body silhouette, seamless anatomical transparency, direct see-through abdomen, uterus visible beneath intact skin, uterus visible through skin, uterus visible inside body, x-ray view, x-ray vision, ridged vaginal walls, rounded vaginal folds on both walls, rounded vaginal folds, interlocking ridged folds, opposing vaginal folds, softened vaginal folds, translucent pink uterus, soft pink glow, dark neutral x-ray field, radiographic glow, vaginal walls contact both sides, vaginal walls directly grip both sides of the egg, closed narrow vaginal opening and nearly closed empty canal, slightly relaxed narrow vaginal opening and a small continuous canal gap, clearly widened vaginal opening and relaxed canal walls, nearly closed vaginal canal, vaginal walls touching, hairline central slit, tiny opening, slightly open vagina, slightly separated vaginal walls, narrow continuous central gap, small opening, wide vaginal canal, clearly separated vaginal walls, broad continuous central opening, open vagina',
      breastsFrame: '(fixed frontal chest crop:1.35), (crop from shoulders to upper waist:1.35), both breasts inside frame, head out of frame, lower body out of frame',
      thighsFrame: '(fixed frontal lower-body crop:1.35), (crop from lower abdomen to just above the knees:1.35), both inner thighs inside frame, head out of frame, upper body out of frame',
      breastPiercingLeft: "(only the character's anatomical left nipple (viewer right) has one tiny silver captive bead ring:2.0), (character's anatomical right nipple (viewer left) completely bare and unpierced:2.0), tiny subtle ring pierced through nipple center, jewelry flush against nipple, no hanging section, ring diameter much smaller than areola, exactly one nipple piercing total",
      breastPiercingRight: "(only the character's anatomical right nipple (viewer left) has one tiny silver captive bead ring:2.0), (character's anatomical left nipple (viewer right) completely bare and unpierced:2.0), tiny subtle ring pierced through nipple center, jewelry flush against nipple, no hanging section, ring diameter much smaller than areola, exactly one nipple piercing total",
      breastPiercingBoth: '(each nipple has exactly one tiny silver captive bead ring through its center:2.0), one matching subtle flush ring on each nipple, no hanging section, ring diameter much smaller than areola, exactly two nipple piercings total',
      breastChoker: '(black leather heart choker fitted snugly around her neck:1.8), (small heart-shaped pendant centered at the front of her neck:1.6), base of neck visible at top of frame, one continuous fitted neck band',
      chokerNegative: CHOKER_NEGATIVE_PROMPT,
      breastSizeNegative: '(oversized breasts:1.8), exaggerated breast size, breasts larger than character design, breasts larger than head, gigantomastia, macromastia, hyper breasts, breast expansion, breast focus, extreme breast close-up, deep cleavage, breast press, squeezed breasts',
      breastPiercingNegative: '(oversized nipple ring:1.7), large nipple ring, dangling nipple jewelry, ornate nipple jewelry, nipple chain, linked nipple rings, multiple rings on one nipple, nipple clamp, pendant, charm, bell, handcuff, shackle, jewelry below nipple, jewelry beside nipple, jewelry attached to areola, floating jewelry, hands touching breasts, hands holding nipple jewelry',
      breastPiercingLeftNegative: '(right nipple piercing:2.0), jewelry on right nipple, two nipple piercings',
      breastPiercingRightNegative: '(left nipple piercing:2.0), jewelry on left nipple, two nipple piercings',
      breastPiercingBothNegative: 'single nipple piercing, missing nipple piercing',
      img2imgSkinGuard: '(matte cel-shaded skin:1.25), soft diffuse skin highlights, clean even skin surface, restrained highlights',
      img2imgSkinNegative: '(oily skin:1.35), (glossy skin:1.35), reflective skin, plastic skin, wet skin outside the stated body part, excessive specular highlights, scattered white highlights, white spots on skin, blown highlights, lens flare on skin',
      img2imgBreastSizeGuard: '(breast volume follows the current wife size tags:1.45), (breast size follows the character prompt exactly:1.4), natural breast volume',
      penisVulva: '(exactly one manufactured saturated-purple silicone dildo vibrator:1.85), (vibrator:1.5), (dildo shaft fully inside her vagina:1.5), (only its flared base visible at the vaginal opening:1.4), visible control button on the base, labia close around the base',
      eggUterus: '(exactly one small manufactured purple egg-shaped vibrator symbol:1.8), smooth oval device centered on the short pink stem, no shaft, no flared base, uniform silicone surface, device fully contained inside the overlay',
      penisUterus: '(exactly one small manufactured saturated-purple silicone dildo vibrator symbol:1.85), short straight shaft centered on the short pink stem, blunt rounded tip, small flared safety base, uniform manufactured surface, device fully contained inside the overlay',
      naturalSkinToneGuard: "(the character's natural skin tone stays unchanged:1.3)",
      penisToyColorGuard: 'purple color confined to the vibrator',
      vulvaVisibilityGuard: '(labia majora clearly visible on both sides:1.35), (vaginal opening clearly visible:1.3)',
      penisToyVulvaContact: '(dildo shaft already inside her vagina:1.45), (only its base visible at the vaginal opening:1.3)',
      expressionNegative: 'emotionless face, blank expression',
      penisNegative: '(human penis:1.8), (real penis:1.8), flesh-colored genital, realistic male genital anatomy, glans, foreskin, urethra, penile veins, testicles, scrotum, skin texture on device, organic flesh, severed penis, detached penis, male body, attached male body, (egg-shaped vibrator:1.5), oval vibrator, bullet vibrator, retrieval cord',
      skinColorNegative: '(purple skin:1.5), violet skin, lavender skin, purple-tinted skin, purple body, violet body, purple color cast on skin, toy color bleeding into skin',
      vulvaVisibilityNegative: 'hidden labia majora, missing labia majora, hands in frame, fingers in frame, hands covering vulva',
      penisToyVulvaNegative: 'toy covering the entire vulva, toy floating in front of the vulva, holding_sex_toy, dildo outside body',
      statusCameraNegative: 'camera in frame, camera device, viewfinder overlay, recording overlay, REC icon, battery icon, shutter button, camera frame, on-screen camera interface',
      closeupNegative: 'full body, face, portrait, standing pose, distant shot, upper body, collage, split screen, multiple views, multiple panels, contact sheet, inset, picture-in-picture, diagram inset, panel border',
      breastsFrameNegative: 'full body, lower body, distant shot, collage, split screen, multiple views, multiple panels, contact sheet, inset, picture-in-picture, panel border',
      skinToneNegative: 'washed-out skin, overexposed skin, gray skin, chalk-white skin, strong red color cast, uniformly bright-red skin, oversaturated skin colors',
      thighsNegative: 'vulva out of frame, hidden vulva, crotch hidden by thighs, closed legs, crossed legs, cropped crotch, clothes, underwear, panties, thong, fabric over crotch, cloth panel, beige patch, skin-colored fabric, censor patch, censorship bar, mosaic, sticker, bandage, adhesive tape, rectangular object over crotch, genital covering',
      vulvaNegative: 'clothes, underwear, panties, thong, g-string, bra, lingerie, bikini bottom, swimsuit, bodysuit, loincloth, harness, crotch strap, pelvic strap, waistband, side straps, garter straps, black strap, black fabric, fabric strip, cloth strip, ribbon, bow, cord, wire, cable, fabric over crotch, fabric across hips, fabric attached to vibrator, device fused to fabric, modesty cloth, censorship bar, adhesive tape, covered vulva, genital covering, clothed lower body, bright red vulva, crimson vulva, uniformly red genital area, inflamed labia, oversaturated pink skin, uterus, anatomical cutaway, x-ray, transparent skin, translucent skin',
      uterusNegative: 'transparent whole body, translucent whole body, transparent torso, translucent torso, full-body x-ray, whole-body x-ray, full figure, standing woman, head, face, breasts, cleavage, chest, shoulders, arms, hands, fingers, visible ribcage, visible lungs, visible heart, visible intestines, skeletal body, separate diagram, rectangular panel, bordered inset, side illustration, giant external vulva, vulva focus, extreme vulva close-up, external genital close-up, exposed vaginal interior, protruding vaginal canal, long vaginal canal, ridged vaginal walls, stacked vaginal folds, repeated fleshy folds, low-angle view, open abdomen, open abdominal hole, external body cavity, gaping body cavity, gore, internal tissue close-up, realistic internal tissue, wet mucosa, fleshy tunnel, fleshy walls, body made of flesh, skin texture filling background, tiled skin, repeated torso, stacked torsos, duplicated pelvis, multiple vulvas, portrait orientation, vertical composition, rotated composition, solid white shaft, white dildo, phallic semen, white fluid outside the pink chamber',
    };
    const MODEL_PROMPT_PRESETS = [
      { id: 'wai-quality', name: 'WAI 품질 기본', prompt: 'masterpiece, best quality, amazing quality' },
      { id: 'wai-negative', name: 'WAI Negative 기본', prompt: 'bad quality, worst quality, worst detail, sketch, censor' },
      { id: 'wai-portrait', name: 'WAI 상반신 초상화', prompt: 'portrait, upper body, looking at viewer, detailed eyes, expressive face' },
      { id: 'wai-full-body', name: 'WAI 전신 구도', prompt: 'full body, standing, looking at viewer' },
      { id: 'wai-clear-face', name: 'WAI 표정·초점', prompt: 'detailed eyes, expressive face, sharp focus' },
      { id: 'wai-expression-smile', name: '표정 · 부드러운 미소', prompt: 'gentle smile, relaxed expression, looking at viewer' },
      { id: 'wai-expression-shy', name: '표정 · 수줍은 홍조', prompt: 'shy, blush, averted gaze' },
      { id: 'wai-expression-scared', name: '표정 · 두려움', prompt: 'scared, wide eyes, tense expression' },
      { id: 'wai-expression-angry', name: '표정 · 분노', prompt: 'angry expression, furrowed brow, glaring' },
      { id: 'wai-expression-tired', name: '표정 · 피곤함', prompt: 'weary expression, heavy eyelids, tired' },
      { id: 'wai-expression-pleasure', name: '표정 · 쾌감', prompt: 'pleasure, flushed face, half-closed eyes, parted lips' },
      { id: 'secret-identity-consistency', name: '비밀 외형 · 캐릭터 일치', prompt: SECRET_IMAGE_PROMPTS.identityConsistency },
      { id: 'secret-face-identity', name: '비밀 외형 · 얼굴 일치', prompt: SECRET_IMAGE_PROMPTS.faceIdentityConsistency },
      { id: 'secret-expression-egg', name: '비밀 표정 · 에그 바이브', prompt: SECRET_IMAGE_PROMPTS.eggExpression },
      { id: 'secret-expression-penis', name: '비밀 표정 · 남성기형 바이브', prompt: SECRET_IMAGE_PROMPTS.penisExpression },
      { id: 'secret-vulva-closeup', name: '비밀 구도 · 외음부 확대', prompt: SECRET_IMAGE_PROMPTS.vulvaCloseup },
      { id: 'secret-uterus-cutaway', name: '비밀 구도 · 자궁 상태 오버레이', prompt: SECRET_IMAGE_PROMPTS.uterusCutaway },
      { id: 'secret-uterus-stage-0', name: '비밀 자궁 상태 · 비어 있음', prompt: SECRET_IMAGE_PROMPTS.uterusStage0 },
      { id: 'secret-uterus-stage-1', name: '비밀 자궁 상태 · 아주 적음', prompt: SECRET_IMAGE_PROMPTS.uterusStage1 },
      { id: 'secret-uterus-stage-2', name: '비밀 자궁 상태 · 적음', prompt: SECRET_IMAGE_PROMPTS.uterusStage2 },
      { id: 'secret-uterus-stage-3', name: '비밀 자궁 상태 · 중간', prompt: SECRET_IMAGE_PROMPTS.uterusStage3 },
      { id: 'secret-uterus-stage-4', name: '비밀 자궁 상태 · 많음', prompt: SECRET_IMAGE_PROMPTS.uterusStage4 },
      { id: 'secret-breasts-frame', name: '비밀 구도 · 가슴 고정', prompt: SECRET_IMAGE_PROMPTS.breastsFrame },
      { id: 'secret-thighs-frame', name: '비밀 구도 · 허벅지 고정', prompt: SECRET_IMAGE_PROMPTS.thighsFrame },
      { id: 'secret-piercing-left', name: '비밀 피어싱 · 왼쪽', prompt: SECRET_IMAGE_PROMPTS.breastPiercingLeft },
      { id: 'secret-piercing-right', name: '비밀 피어싱 · 오른쪽', prompt: SECRET_IMAGE_PROMPTS.breastPiercingRight },
      { id: 'secret-piercing-both', name: '비밀 피어싱 · 양쪽', prompt: SECRET_IMAGE_PROMPTS.breastPiercingBoth },
      { id: 'secret-breast-choker', name: '비밀 장신구 · 하트 초커', prompt: SECRET_IMAGE_PROMPTS.breastChoker },
      { id: 'secret-breast-size-negative', name: '비밀 Negative · 가슴 크기', prompt: SECRET_IMAGE_PROMPTS.breastSizeNegative },
      { id: 'secret-img2img-skin', name: '비밀 img2img · 피부 광택 억제', prompt: SECRET_IMAGE_PROMPTS.img2imgSkinGuard },
      { id: 'secret-img2img-breast-size', name: '비밀 img2img · 가슴 크기 반영', prompt: SECRET_IMAGE_PROMPTS.img2imgBreastSizeGuard },
      { id: 'secret-img2img-skin-negative', name: '비밀 img2img Negative · 흰 반점·유광 피부', prompt: SECRET_IMAGE_PROMPTS.img2imgSkinNegative },
      { id: 'secret-piercing-negative', name: '비밀 Negative · 유두 피어싱 형태', prompt: SECRET_IMAGE_PROMPTS.breastPiercingNegative },
      { id: 'secret-piercing-left-negative', name: '비밀 Negative · 왼쪽만 착용', prompt: SECRET_IMAGE_PROMPTS.breastPiercingLeftNegative },
      { id: 'secret-piercing-right-negative', name: '비밀 Negative · 오른쪽만 착용', prompt: SECRET_IMAGE_PROMPTS.breastPiercingRightNegative },
      { id: 'secret-piercing-both-negative', name: '비밀 Negative · 양쪽 착용', prompt: SECRET_IMAGE_PROMPTS.breastPiercingBothNegative },
      { id: 'secret-choker-negative', name: '비밀 Negative · 초커 없음', prompt: SECRET_IMAGE_PROMPTS.chokerNegative },
      { id: 'secret-penis-vulva', name: '비밀 토이 · 남성기형 외음부', prompt: SECRET_IMAGE_PROMPTS.penisVulva },
      { id: 'secret-egg-uterus', name: '비밀 토이 · 에그형 자궁', prompt: SECRET_IMAGE_PROMPTS.eggUterus },
      { id: 'secret-penis-uterus', name: '비밀 토이 · 남성기형 자궁', prompt: SECRET_IMAGE_PROMPTS.penisUterus },
      { id: 'secret-natural-skin-tone', name: '비밀 상태 · 피부색 유지', prompt: SECRET_IMAGE_PROMPTS.naturalSkinToneGuard },
      { id: 'secret-penis-toy-color', name: '비밀 토이 · 보라색 분리', prompt: SECRET_IMAGE_PROMPTS.penisToyColorGuard },
      { id: 'secret-vulva-visibility', name: '비밀 상태 · 외음순 노출', prompt: SECRET_IMAGE_PROMPTS.vulvaVisibilityGuard },
      { id: 'secret-penis-vulva-contact', name: '비밀 토이 · 외음순 접촉', prompt: SECRET_IMAGE_PROMPTS.penisToyVulvaContact },
      { id: 'secret-expression-negative', name: '비밀 Negative · 무표정 제외', prompt: SECRET_IMAGE_PROMPTS.expressionNegative },
      { id: 'secret-penis-negative', name: '비밀 Negative · 남성기형 구분', prompt: SECRET_IMAGE_PROMPTS.penisNegative },
      { id: 'secret-skin-color-negative', name: '비밀 Negative · 보라색 피부 번짐', prompt: SECRET_IMAGE_PROMPTS.skinColorNegative },
      { id: 'secret-vulva-visibility-negative', name: '비밀 Negative · 외음순·손 가림', prompt: SECRET_IMAGE_PROMPTS.vulvaVisibilityNegative },
      { id: 'secret-penis-vulva-contact-negative', name: '비밀 Negative · 외음순 가림', prompt: SECRET_IMAGE_PROMPTS.penisToyVulvaNegative },
      { id: 'secret-status-camera-negative', name: '비밀 Negative · 촬영 UI', prompt: SECRET_IMAGE_PROMPTS.statusCameraNegative },
      { id: 'secret-closeup-negative', name: '비밀 Negative · 확대 구도', prompt: SECRET_IMAGE_PROMPTS.closeupNegative },
      { id: 'secret-skin-tone-negative', name: '비밀 Negative · 피부 색감', prompt: SECRET_IMAGE_PROMPTS.skinToneNegative },
      { id: 'secret-thighs-negative', name: '비밀 Negative · 허벅지 구도', prompt: SECRET_IMAGE_PROMPTS.thighsNegative },
      { id: 'secret-vulva-negative', name: '비밀 Negative · 외음부 노출', prompt: SECRET_IMAGE_PROMPTS.vulvaNegative },
      { id: 'secret-uterus-negative', name: '비밀 Negative · 자궁 상태 오버레이', prompt: SECRET_IMAGE_PROMPTS.uterusNegative },
    ];
    const USER_VARIANT_START = 4;
    let activeSettingsTab = 'general';
    let activeOutfitPromptId = '';
    let activeSituationPresetId = LEGACY_SITUATION_PRESET_ID;
    let settingsMessage = '';
    let imagePromptPlusMessage = '';
    let imagePromptPlusReloadPending = false;
    const imagePackBuild = { busy: false, cancelled: false, message: '' };
    const promptModPreview = { owner: '', result: null, error: '', editKey: '', expanded: {} };
    let settingsWindowHandle = null;
    let promptPreviewing = false;
    let dialogueRuleCounter = 0;
    let situationPresetCounter = 0;
    let promptPresetCounter = 0;
    let tagLibraryScrollTop = 0;
    let promptPresetLibraryScrollTop = 0;
    let activeSettingsRail = 'tags';
    let mobileSettingsToolsOpen = false;
    let quickTagLibraryOpen = false;
    let activeTagTarget = null;
    let activeTagCategory = 'all';
    let tagLibrarySearch = '';
    let wifeBuilderEnglishName = '';
    let wifeBuilderActivePromptSourceId = '';
    let wifeBuilderContextId = null;
    let currentWifeBuilderPromptState = null;
    let readingWifePromptSources = false;
    let pendingWifeBuilderTemplate = null;
    let residueVariantId = 0;
    let runtimeResidueImageChoices = {};
    const runtimeHiddenResidueImages = new Set();
    let positionVariantId = 0;
    let recentControllerButtons = [];
    let activePositionModuleEditorId = '';
    let activePositionModuleSection = 'position';
    let activePositionModuleScope = 'patron';
    let activePositionModuleGroup = '';
    let latestScenePrompt = null;
    let latestPromptArgs = null;
    let cyclePreviewPhase = '';
    let firstExperiencePreviewing = false;
    let hStatusFantasyPreview = null;
    let toyPreviewType = null;
    const cycleDebugger = { mode: 'cycle', sceneKey: '', characterId: '', slot: null, day: null, variants: {}, running: '', message: '' };
    let pendingWifePromptEdit = null;
    let positionSelection = { situationId: '', presetId: '', groupSlots: '', details: null, personPrompt: null, manual: false };
    const positionRandomChoices = new Map();
    const positionPlacementDrafts = new Map();
    const positionGeneratedResults = new Map();
    const nativeFreshPrompts = new Map();
    const legacyDetailImageKeys = new Map();
    const compactSituationAliases = new Map();
    const regenerateCharacterImageKeys = new Set();
    const nativeFreshVariantKeys = new Set();
    const statusCacheAliases = new Map();
    let legacyCachePromise;
    const residuePromptPackLoads = new Map();
    const positionGeneration = { running: false, message: '' };
    let activeErostatBand = 'full';
    let activeErostatPart = 'vaginal';
    let selectedErostatPresetId = '';
    let pendingErostatPresetName = '';
    let selectedErostatBundleId = '';
    let pendingErostatBundleName = '';
    let skipUnrecordedPortraitKey = 0;
    let previousPortraitSnapshot = null;
    const exportSections = { wives: true, gameDefaultPrompts: true, characterPrompt: true, outfitPrompts: true, customOutfits: true, situationPresets: true, positionPresetPrompts: true, positionGroupPrompts: true, positionStatePrompts: true, sceneBaseOverrides: true, cameraSettings: true, sceneStatePromptOverrides: true, buttonPromptRules: true, positionRules: true, positionModules: true, promptModRules: true, externalPrompts: true, featurePrompts: true, shortImageKeys: true, generationWeight: true, prompts: true, negativePrompts: true, outfitStates: true, dialogueRules: true, fluidDecay: true, residueGenerationProvider: true, hStatusGenerationModes: true, residuePrompts: true, residuePartSources: true, customTags: true, promptPresets: true, erostatPromptPresets: true, erostatPromptBundles: true };
    const diagnostics = {
      running: false,
      checkedAt: 0,
      checks: [],
      backend: null,
      lastLookup: null,
      lastGeneration: null,
      lastHStatusImg2ImgFallback: '',
    };

    let latestHeroineOrgasm = null;
    /* AIP_SOURCE:image-state */
    /* AIP_SOURCE:wife-builder */
    /* AIP_SOURCE:first-experience-creation */
    /* AIP_SOURCE:native-studio-characters */
    /* AIP_SOURCE:settings-data */
    /* AIP_SOURCE:tab-json */
    /* AIP_SOURCE:generation-weight */
    /* AIP_SOURCE:prompt-foundations */
    /* AIP_SOURCE:image-cache-and-keys */
    /* AIP_SOURCE:scene-native-prompts */
    /* AIP_SOURCE:scene-base-overrides */
    /* AIP_SOURCE:scene-candidate-pool */
    /* AIP_SOURCE:scene-prompts-api */
    /* AIP_SOURCE:current-state-editor */
    /* AIP_SOURCE:scene-image-preview */
    /* AIP_SOURCE:button-prompts */
    /* AIP_SOURCE:prompt-mod-rules */
    /* AIP_SOURCE:global-prompt-exclusions */
    /* AIP_SOURCE:prompt-tag-search */
    /* AIP_SOURCE:camera-presets */
    /* AIP_SOURCE:camera-core */
    /* AIP_SOURCE:external-targets */
    /* AIP_SOURCE:external-position-targets */
    /* AIP_SOURCE:native-pack-compat */
    syncCustomOutfits();
    /* AIP_SOURCE:image-browser */
    /* AIP_SOURCE:offline-cache */
    /* AIP_SOURCE:settings-controls */
    /* AIP_SOURCE:hstatus-images */
    /* AIP_SOURCE:settings-panels */
    /* AIP_SOURCE:position-generation */
    /* AIP_SOURCE:portrait-fresh-variants */
    /* AIP_SOURCE:position-controller-core */
    /* AIP_SOURCE:position-controller-ui */
    /* AIP_SOURCE:camera-ui */
    /* AIP_SOURCE:diagnostics-and-image-pack */
    function openSettingsWindow() {
      selectedErostatPresetId = '';
      selectedErostatBundleId = '';
      const win = api.ui.window({
        id: 'settings',
        title: '상황별 이미지 프롬프트 설정',
        width: 1320,
        height: 840,
        render: renderSettings,
      });
      settingsWindowHandle = win;
      const width = Math.max(320, Math.min(1320, window.innerWidth - 24));
      const height = Math.max(320, Math.min(840, window.innerHeight - 24));
      win.el.style.setProperty('width', `${width}px`, 'important');
      win.el.style.setProperty('height', `${height}px`, 'important');
      win.el.style.setProperty('z-index', '2147483647', 'important');
      win.refresh();
    }

    window.addEventListener('resize', () => {
      const el = settingsWindowHandle?.el;
      if (!el?.isConnected || typeof el.getBoundingClientRect !== 'function') return;
      let rect = el.getBoundingClientRect();
      const maxWidth = Math.max(280, window.innerWidth - 16);
      const maxHeight = Math.max(300, window.innerHeight - 16);
      if (rect.width > maxWidth) el.style.setProperty('width', `${maxWidth}px`, 'important');
      if (rect.height > maxHeight) el.style.setProperty('height', `${maxHeight}px`, 'important');
      rect = el.getBoundingClientRect();
      if (rect.right > window.innerWidth - 8 || rect.left < 8)
        el.style.setProperty('left', `${Math.max(8, Math.min(rect.left, window.innerWidth - rect.width - 8))}px`);
      if (rect.bottom > window.innerHeight - 8 || rect.top < 8)
        el.style.setProperty('top', `${Math.max(8, Math.min(rect.top, window.innerHeight - rect.height - 8))}px`);
    });

    let uiScanQueued = false;
    function scheduleUiScan() {
      if (uiScanQueued) return;
      uiScanQueued = true;
      const scan = () => {
        uiScanQueued = false;
        decoratePortraitPromptTags();
        decoratePortraitPositionButton();
        ensureSecretTabCompatibility();
        decorateResidueCards();
      };
      if (typeof window.requestAnimationFrame === 'function') window.requestAnimationFrame(scan);
      else queueMicrotask(scan);
    }

    const accessoryUiSignature = () => {
      const state = api.store.game();
      const wife = state?.characters?.[state.primaryCharacterId];
      const jewelry = wife?.situationStats?.jewelryState;
      return [wife?.outfit, jewelry?.breasts?.stage, jewelry?.vulva?.stage,
        jewelry?.vibe?.type, jewelry?.vibe?.suspension?.reason, jewelry?.vibe?.suspension?.untilSlot].join('|');
    };
    let lastAccessoryUiSignature = accessoryUiSignature();
    api.store.subscribe?.(() => {
      const current = accessoryUiSignature();
      if (current === lastAccessoryUiSignature) return;
      lastAccessoryUiSignature = current;
      scheduleUiScan();
      window.setTimeout(scheduleUiScan, 250);
    });

    api.ui.settings(renderSettings);
    api.ui.pauseSettings?.({
      label: { ko: '상황별 이미지 프롬프트 설정', en: 'Situation Image Prompt settings' },
      onClick: openSettingsWindow,
      attributes: { 'data-attention-image-prompt-settings': '' },
    });
    const offerImagePromptPlus = () => {
      const wml = globalThis.WML;
      if (!wml?.readAll) return;
      void wml.readAll().then(() => {
        const state = imagePromptPlusStatus();
        if (!state || state.active || api.settings.get({ imagePromptPlusOfferAsked: false }).imagePromptPlusOfferAsked) return;
        api.settings.set({ imagePromptPlusOfferAsked: true });
        api.ui.window({
          id: 'image-prompt-plus-offer',
          title: '이미지 프롬프트 확장 연결',
          width: 510,
          height: 300,
          render: (body, win) => body.replaceChildren(renderImagePromptPlusOffer(api.ui.h, win, true)),
        });
      }).catch(() => {});
    };
    const offerShortImageKeys = () => {
      if (typeof api.settings.get({ shortImageKeys: null }).shortImageKeys === 'boolean') {
        offerImagePromptPlus();
        return;
      }
      let shortKeySaveError = '';
      api.ui.window({
        id: 'short-image-keys-first-start',
        title: '최종 이미지 파일명 추가 축약',
        width: 540,
        height: 360,
        render: (body, win) => {
          const h = api.ui.h;
          const choose = enabled => {
            if (!saveShortImageKeys(enabled)) {
              shortKeySaveError = '설정을 저장하지 못했어요. 브라우저의 저장 공간과 저장 허용 설정을 확인한 뒤 다시 시도해 주세요.';
              win.refresh();
              return;
            }
            win.close();
            offerImagePromptPlus();
          };
          body.replaceChildren(h('div', { class: 'wml-section' },
            h('p', {}, '사용 이점: 다른 모드가 태그를 더해 다시 길어진 이미지 요청 키를 추가로 줄여 파일명 길이 때문에 생성이 실패하는 일을 줄입니다. AIP 자체의 기존 키 축약은 이 설정과 관계없이 유지됩니다. Positive·Negative 프롬프트와 이미지별 저장 기록은 줄이지 않습니다.'),
            h('p', { class: 'wml-note' }, '기존 이미지: 축약을 켜도 이전 긴 키 이미지를 먼저 조회하고, 다시 꺼도 축약한 이미지를 조회해 재사용합니다. 새 이미지는 짧은 해시 키로 저장되므로 외부 도구나 직접 만든 이미지팩에서 파일명으로 이미지를 찾는 경우 연결을 수정해야 할 수 있습니다. 끄더라도 이미 저장된 파일 이름은 바뀌지 않습니다.'),
            h('p', { class: 'wml-note' }, '적용 범위: 이 모드가 처리하는 초상화·조건부 생성 요청에만 적용됩니다. 이미지 스튜디오가 별도로 직접 보내는 일괄 요청까지 보호하지는 않습니다.'),
            shortKeySaveError ? h('p', { class: 'wml-note', role: 'alert' }, shortKeySaveError) : null,
            h('div', { style: 'display:flex;gap:8px;margin-top:16px;' },
              api.ui.button('축약 켜기', () => choose(true), { primary: true }),
              api.ui.button('사용 안 함', () => choose(false)))));
        },
      });
    };
    window.setTimeout(() => {
      const configured = api.settings.get({ featurePrompts: null }).featurePrompts;
      if (['pregnancy', 'marks', 'cycle', 'sleep'].every(key => typeof configured?.[key] === 'boolean')) {
        offerShortImageKeys();
        return;
      }
      const selected = currentFeaturePrompts();
      api.ui.window({
        id: 'feature-prompts-first-start',
        title: '상태별 프롬프트 선택',
        width: 520,
        height: 390,
        render: (body, win) => {
          const h = api.ui.h;
          const save = () => {
            api.settings.set({ featurePrompts: { ...selected } });
            refreshPortraitImage();
            win.close();
            offerShortImageKeys();
          };
          body.replaceChildren(h('div', { class: 'wml-section' },
            h('p', { class: 'wml-note' }, '이미지 프롬프트에 추가할 상태를 선택하세요. 나중에 각 설정 탭에서 언제든 변경할 수 있습니다.'),
            ...[['pregnancy', '임신 상태'], ['marks', '손찌검 흔적'],
              ['cycle', '생리 상태'], ['sleep', '수면 중 관계'], ['firstExperience', '첫경험 장면']].map(([key, label]) => h('label', {
              style: 'display:flex;align-items:center;gap:8px;margin:12px 0;cursor:pointer;',
            }, h('input', { type: 'checkbox', checked: selected[key], 'data-feature-first-start': key,
              onchange: event => { selected[key] = event.currentTarget.checked; } }), label)),
            h('div', { style: 'display:flex;gap:8px;margin-top:16px;' },
              api.ui.button('선택 적용', save, { primary: true }),
              api.ui.button('모두 끄기', () => {
                for (const key of ['pregnancy', 'marks', 'cycle', 'sleep', 'firstExperience']) selected[key] = false;
                save();
              })),
          ));
        },
      });
    }, 500);
    decoratePortraitPromptTags();
    decoratePortraitPositionButton();
    ensureSecretTabCompatibility();
    decorateResidueCards();
    const uiObserverRoot = document.getElementById('root') || document.body;
    if (uiObserverRoot && typeof MutationObserver !== 'undefined') {
      const uiObserver = new MutationObserver(scheduleUiScan);
      uiObserver.observe(uiObserverRoot, { childList: true, attributes: true, attributeFilter: ['src'], subtree: true });
      window.addEventListener('pagehide', () => uiObserver.disconnect(), { once: true });
    }
    document.addEventListener?.('click', event => {
      const button = event.target?.closest?.('button.wpc-ctl-cmd, button.hlc-chip');
      if (button) {
        const entry = controllerButtonDescriptor(button);
        if (!entry) return;
        discoverControllerButtons([entry]);
        controllerFoldSnapshot = null;
        if (positionMode() === 'modules' && button.getAttribute('aria-disabled') !== 'true') {
          const wasActive = button.classList?.contains('wpc-active') === true
            || button.classList?.contains('on') === true;
          const state = api.store.game();
          const kind = controllerButtonKind(entry);
          const slot = Number(state?.slot) || 0;
          recentControllerButtons = recentControllerButtons.filter(previous => previous.slot >= slot - 1
            && !(previous.scope === entry.scope && previous.actorId === entry.actorId
              && (previous.id === entry.id || ['position', 'action'].includes(kind) && previous.kind === kind)));
          if (!wasActive) recentControllerButtons.push({ ...entry, kind, slot,
            sceneType: entry.scope === 'patron' ? state?.activeScene?.patron?.stage : state?.activeScene?.sex?.type });
          recentControllerButtons = recentControllerButtons.slice(-30);
          window.setTimeout(refreshPortraitImage, 0);
        }
      } else if (!exploringControllerFolds && event.target?.closest?.('.wpc-ctl-fold')) {
        controllerFoldSnapshot = null;
        window.setTimeout(() => {
          discoverControllerButtons();
          settingsWindowHandle?.refresh?.();
        }, 0);
      }
    }, true);

    api.hook('wifePicker', {
      after(result, [props]) {
        if (api.game === '2026-11-01') return result;
        return result && props?.onSelect && props?.onOpenBuilder ? addWifePickerTools(result, props) : result;
      },
    });

    api.hook('wifeBuilderDefaults', {
      after(result) {
        const template = pendingWifeBuilderTemplate;
        pendingWifeBuilderTemplate = null;
        if (!result || !template) return result;
        wifeBuilderActivePromptSourceId = '';
        wifeBuilderContextId = null;
        currentWifeBuilderPromptState = null;
        return {
          ...result,
          __attentionImageEnglishName: template.englishName,
          __attentionImageShortname: template.shortname,
          __attentionImageNegativePrompt: DEFAULT_WIFE_CHARACTER_NEGATIVE,
          __attentionExtraLinesArchetypeId: EXTRA_LINES_DIALOGUE_SOURCES[0][0],
          __attentionImageOutfitColors: { primary: '', secondary1: '', secondary2: '' },
        };
      },
    });

    api.hook('wifeBuilder', {
      after(result, [props]) {
        return customizeWifeBuilder(result, props);
      },
    });

    api.hook('imagePreGenerateDialog', {
      before() {
        syncPreGenerateWives();
      },
      after(result) {
        const labels = new Map(preGenerateWifeSources().map(source => [source.id, source.name]));
        return labels.size ? labelPreGenerateWives(result, labels) : result;
      },
    });

    api.hook('imagePlanEntry', {
      around(next, ...args) {
        imagePlanDepth += 1;
        try { return next(...args); }
        finally { imagePlanDepth -= 1; }
      },
    });

    api.hook('imagePlanCharacter', {
      around(next, id, ...args) {
        if (args[0]) return next(id, ...args);
        const source = preGenerateWifeSource(id);
        return source
          ? wifeCharacterFromArchetype(source.archetype, { id: 'wife', generatedArchetype: source.archetype })
          : next(id, ...args);
      },
    });

    api.hook('imagePlanList', {
      after(result, [options]) {
        if (!Array.isArray(result)) return result;
        const source = options?.generatedArchetype ? null : preGenerateWifeSource(options?.archetype);
        const checkpoint = String(source?.archetype.imageCheckpoint || '').trim();
        const planCharacter = externalPromptRegistry.size
          ? api.fn('imagePlanCharacter')(options?.archetype || 'elena_farmgirl', options?.generatedArchetype) : null;
        let changed = false;
        const entries = result.map(entry => {
          const talentId = typeof entry?.talentId === 'string'
            ? externalPlanImageKey(entry.talentId, planCharacter) : entry?.talentId;
          if (!source && talentId === entry?.talentId) return entry;
          changed = true;
          return { ...entry, ...(talentId !== entry?.talentId ? { talentId } : {}),
            ...(source ? { archetypeId: source.id, ...(checkpoint ? { checkpoint } : {}) } : {}) };
        });
        return changed ? entries : result;
      },
    });

    api.hook('imageQueue', {
      priority: Number.MAX_SAFE_INTEGER,
      around(next, entries, ...args) {
        return next(Array.isArray(entries) ? entries.map(entry => applyGlobalPromptExclusions(deduplicateFinalRequest(entry))) : entries, ...args);
      },
    });
    api.hook('imageQueue', {
      async around(next, entries) {
        if (!Array.isArray(entries)) return next(entries);
        const lastByKey = new Map(entries.map((entry, index) => [entry?.talentId, index]));
        const queued = [];
        let legacyReused = 0;
        const contents = entries.map(entry => globalPromptExclusionsFingerprint() ? null : statusContentKey(entry));
        const legacy = contents.some(Boolean) ? await legacyCacheEntries() : {};
        const shortenFinalKeys = shortImageKeysEnabled();
        const manifest = api.has('imageManifest') && (contents.some(content => legacy[content?.key])
          || entries.some(entry =>
            typeof entry?.talentId === 'string' && compactGenerationKey(entry.talentId, true) !== entry.talentId))
          ? await api.fn('imageManifest')() : null;
        for (const [index, entry] of entries.entries()) {
          if (entry?.talentId && lastByKey.get(entry.talentId) !== index) continue;
          const content = contents[index];
          if (!content) {
            queued.push(entry);
            continue;
          }
          if (!manifest?.entries?.[entry.talentId] && !manifest?.entries?.[content.key]
            && await legacyStatusEntry(content.key, manifest)) {
            legacyReused += 1;
            continue;
          }
          queued.push(entry);
        }
        const prepared = await Promise.all(queued.map(async entry => {
          if (typeof entry?.talentId !== 'string') return entry;
          const shortKey = compactGenerationKey(entry.talentId, true);
          if (shortKey === entry.talentId) return entry;
          const existing = manifest?.entries?.[entry.talentId] || await imageLookup(entry.talentId);
          if (existing?.talentName && await imageEntryExists(existing)) {
            if (existing.talentName === entry.talentId) return entry;
            if ([shortKey, compactGenerationKey(entry.talentId)].includes(existing.talentName)) return null;
          }
          return shortenFinalKeys ? { ...entry, talentId: shortKey } : entry;
        }));
        const submitted = prepared.filter(Boolean).map(entry => applyGlobalPromptExclusions(deduplicateFinalRequest(entry)));
        legacyReused += prepared.length - submitted.length;
        if (!submitted.some(entry => String(entry?.checkpoint || '').trim())) {
          const result = await next(submitted);
          return result && legacyReused ? { ...result, alreadyCached: (result.alreadyCached || 0) + legacyReused } : result;
        }
        const endpoint = imageServerUrl('/api/batch/enqueue');
        if (!endpoint) {
          const result = await next(submitted);
          return result && legacyReused ? { ...result, alreadyCached: (result.alreadyCached || 0) + legacyReused } : result;
        }
        let accepted = 0;
        let alreadyCached = legacyReused;
        let jobId = '';
        for (let offset = 0; offset < submitted.length; offset += 2000) {
          const items = submitted.slice(offset, offset + 2000).map(entry => ({
            talentId: entry.talentId,
            prompt: entry.prompt,
            negativePrompt: entry.negativePrompt,
            workflow: entry.workflow,
            steps: entry.steps,
            cfg: entry.cfg,
            loraStrength: entry.loraStrength,
            checkpoint: entry.checkpoint,
            look: entry.look,
            width: entry.width,
            height: entry.height,
            weight: entry.weight,
          }));
          const response = await globalThis.fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'omit',
            body: JSON.stringify({
              ...(jobId ? { jobId } : {}),
              start: offset + 2000 >= submitted.length,
              items,
            }),
          });
          if (!response.ok) throw new Error(`이미지 서버가 대기열 등록을 거부했습니다(${response.status})`);
          const body = await response.json();
          accepted += body.accepted;
          alreadyCached += body.alreadyCached;
          jobId = body.jobId;
        }
        return { accepted, alreadyCached, jobId };
      },
    });

    api.hook('buildWifeArchetype', {
      after(result, [inputs, id]) {
        if (!result || !inputs || readingWifePromptSources) return applySavedWifeMetadata(result, inputs);
        const customAppearance = String(inputs.customAppearance || '');
        const base = generatedWifeBasePrompt(result.imageBase, customAppearance);
        const previous = currentWifeBuilderPromptState?.id === id ? currentWifeBuilderPromptState : null;
        const full = previous && previous.base !== base
          ? rebaseWifePrompt(previous.full, previous.base, base)
          : previous?.userEdited ? customAppearance : customAppearance || previous?.full || base;
        const negative = previous ? String(previous.negative ?? '') : normalizedWifeNegative(Object.prototype.hasOwnProperty.call(inputs, '__attentionImageNegativePrompt')
          ? String(inputs.__attentionImageNegativePrompt || '')
          : DEFAULT_WIFE_CHARACTER_NEGATIVE);
        inputs.__attentionImageNegativePrompt = negative;
        currentWifeBuilderPromptState = {
          id,
          base,
          full,
          negative,
          inputs,
          needsPersist: Boolean(customAppearance && full !== customAppearance),
          persistScheduled: false,
          userEdited: previous?.userEdited || false,
        };
        return applySavedWifeMetadata(result, inputs, full, negative);
      },
    });

    api.hook('wifeCharacterFromArchetype', {
      after(result, [archetype]) {
        const dialogueArchetypeId = String(archetype?.attentionExtraLinesArchetypeId || '');
        if (!result || !EXTRA_LINES_DIALOGUE_SOURCES.some(([id]) => id && id === dialogueArchetypeId)) return result;
        const generatedArchetype = result.generatedArchetype ? {
          ...result.generatedArchetype,
          id: dialogueArchetypeId,
          attentionCustomWifeId: archetype.id,
        } : result.generatedArchetype;
        return { ...result, archetypeId: dialogueArchetypeId, generatedArchetype };
      },
    });

    api.hook('wifePreviewBundle', {
      after(result, [archetype]) {
        if (!result || !archetype
          || !Object.prototype.hasOwnProperty.call(archetype, 'attentionImageNegativeOverride')) return result;
        const sharedNegative = normalizedWifeNegative(archetype.attentionImageNegativeOverride);
        const prompt = withoutPromptTags(result.prompt, sharedNegative);
        const parts = Array.isArray(result.parts) ? result.parts.map(part => ({
          ...part,
          tags: withoutPromptTags(part.tags, sharedNegative),
        })) : result.parts;
        return {
          ...result,
          prompt,
          negativePrompt: joinPrompt(`${sharedNegative}, ${WIFE_PREVIEW_ONLY_NEGATIVE}`),
          parts,
          genParams: promptGenParams(prompt),
        };
      },
    });

    function compatibleImageResult(result, imageKey, reused = false) {
      if (api.game !== '2026-11-01' || !result?.url) return result;
      return { ...result, key: typeof result.key === 'string' && result.key ? result.key : imageKey,
        ...(reused ? { fresh: false } : {}) };
    }

    if (api.has('imageGenerate')) {
      api.hook('imageGenerate', {
        priority: Number.MAX_SAFE_INTEGER,
        around(next, request, ...args) {
          return cameraGenerationAround(next, applyGlobalPromptExclusions(deduplicateFinalRequest(request)), ...args);
        },
        before(args) {
          const request = args[0];
          if (!request || typeof request.imageKey !== 'string' || typeof request.prompt !== 'string') return;
          return [{ ...request, [imageRequestTraceSymbol]: { baseline: imageRequestSnapshot(request) } }, ...args.slice(1)];
        },
      });
      api.hook('imageGenerate', {
        priority: -20,
        after(result, [request]) {
          if (!result?.url || !currentFeaturePrompts().firstExperience
            || !globalThis.WML?.status?.().loaded?.includes('virginity-status')
            || !request?.imageKey?.includes('__virgin_blood')
            || request.prompt?.includes(NATIVE_FIRST_EXPERIENCE_TAG)) return result;
          const state = api.store.game();
          const marker = state?.mods?.['virginity-status']?.prompt;
          if (!marker?.pending || !firstExperienceScene(state, marker.characterId, request.imageKey)) return result;
          // The source mod consumes this marker only when its own blood tag is sent.
          queueMicrotask(() => api.store.update(current => {
            const root = current?.mods?.['virginity-status'];
            const pending = root?.prompt;
            if (!pending?.pending || pending.characterId !== marker.characterId
              || pending.scene !== marker.scene || pending.id !== marker.id) return current;
            return { ...current, mods: { ...current.mods, 'virginity-status': {
              ...root, prompt: { ...pending, pending: false },
              promptDone: { ...(root.promptDone || {}), [pending.characterId]: true },
            } } };
          }));
          return result;
        },
        before(args) {
          const request = args[0];
          if (!request || typeof request.imageKey !== 'string') return undefined;
          const rawImageKey = residueBaseImageKey(request.imageKey);
          const imageKey = residueExpressionImageKey(rawImageKey);
          const override = request.debug?.source === 'attention-image-prompt-residue-hstatus'
            ? null : residuePromptOverride(imageKey);
          const reuseExactCache = !imageStudioOwnsSelection() && isResidueImageKey(imageKey)
            && request.debug?.source === 'wayward-situation'
            && request.bypassCache === true;
          if (!override && !reuseExactCache && imageKey === rawImageKey) return undefined;
          return [{
            ...request,
            ...(imageKey !== rawImageKey ? { imageKey: request.imageKey.replace(rawImageKey, imageKey) } : {}),
            ...(reuseExactCache ? { bypassCache: false } : {}),
            ...(override ? {
              prompt: override.positivePrompt.trim() || request.prompt,
              negativePrompt: override.negativePrompt,
            } : {}),
          }, ...args.slice(1)];
        },
        async around(next, request, ...args) {
          if (!request || typeof request.imageKey !== 'string') return next(deduplicateFinalRequest(request), ...args);
          const requestTrace = request[imageRequestTraceSymbol];
          if (requestTrace) requestTrace.aipBefore = imageRequestSnapshot(request);
          const nativeFresh = nativeFreshVariantKeys.has(request.imageKey);
          const nativeFreshKey = request.imageKey;
          const forward = async forwarded => {
            forwarded = deduplicateFinalRequest(forwarded);
            const release = beginImageRequestTrace(forwarded);
            if (nativeFresh) nativeFreshVariantKeys.add(forwarded.imageKey);
            const debug = forwarded.debug;
            const reviewedAt = imageRequestObserver?.recentRegenerations?.get(trace.key);
            if (forwarded.bypassCache === true && reviewedAt != null) imageRequestObserver.recentRegenerations.delete(trace.key);
            const bridge = !nativeFresh && forwarded.bypassCache === true && forwarded.imageKey !== trace.key
              && globalThis.WW_PromptManager?.version === '0.3.0' && imageRequestObserver?.keyTransfers instanceof Map
              && Number.isFinite(reviewedAt) && Date.now() - reviewedAt < 15000
              && (debug == null || (typeof debug === 'object'
                && [Object.prototype, null].includes(Object.getPrototypeOf(debug))
                && !Object.prototype.hasOwnProperty.call(debug, '__aipKeyTransfer')));
            let marker = '';
            if (bridge) {
              marker = String(++imageRequestObserver.transferSequence);
              imageRequestObserver.keyTransfers.set(marker, { original: trace.key, compact: forwarded.imageKey, originalDebug: debug });
            }
            try {
              const request = bridge ? { ...forwarded, imageKey: trace.key, debug: { ...debug, __aipKeyTransfer: marker } }
                : nativeFresh ? { ...forwarded, bypassCache: false } : forwarded;
              const result = await next(request, ...args);
              if (bridge && result?.url && !imageRequestObserver.keyTransfers.has(marker) && api.has('imageManifestReset')) {
                try { api.fn('imageManifestReset')(); } catch (_) {}
              }
              return result;
            } finally {
              if (marker) imageRequestObserver.keyTransfers.delete(marker);
              if (nativeFresh && forwarded.imageKey !== nativeFreshKey) nativeFreshVariantKeys.delete(forwarded.imageKey);
              release();
            }
          };
          if (nativeFresh) request = { ...request, bypassCache: true };
          const state = api.store.game();
          const portraitKey = activePortraitImageKey('', state);
          let refreshedPortraitPrompt = null;
          // The game's portrait + button keeps its previous prompt until the scene key changes.
          if (request.debug?.stats && !request.debug.source && request.width === 1216 && request.height === 832
            && latestPromptArgs?.length && portraitKey
            && similarImageSituationKey(request.imageKey) === similarImageSituationKey(portraitKey)) {
            try { flushCurrentWifePromptEdit(state); }
            catch (error) {
              console.warn('[attention-image-prompt] native portrait prompt save', error);
              return null;
            }
            const character = state?.characters?.[state.primaryCharacterId];
            const current = character && api.fn('imagePrompt')(character, ...latestPromptArgs.slice(1));
            if (current?.prompt && positionSituationId(current.key) === positionSituationId(request.imageKey)
              && String(current.key).split('__')[0] === String(request.imageKey).split('__')[0]) {
              const params = current.genParams || promptGenParams(current.prompt);
              request = { ...request, prompt: current.prompt, negativePrompt: current.negativePrompt || '',
                steps: params?.steps, cfg: params?.cfg, loraStrength: params?.loraStrength,
                checkpoint: current.checkpoint,
                ...(Object.prototype.hasOwnProperty.call(current, 'look') ? { look: current.look } : {}) };
              refreshedPortraitPrompt = current;
            }
          }
          const rawResidueKey = residueBaseImageKey(request.imageKey);
          const residueKey = residueExpressionImageKey(rawResidueKey);
          if (residueKey !== rawResidueKey) request = { ...request, imageKey: request.imageKey.replace(rawResidueKey, residueKey) };
          const nativeHStatusPrompt = request.debug?.source === 'attention-image-prompt-residue-hstatus';
          const ownResidueMode = currentResidueGenerationProvider() === 'aip'
            && currentHStatusGenerationModes()[residuePartFromImageKey(residueKey)] === 'own'
            && ['wayward-situation', 'attention-image-prompt-residue-own'].includes(request.debug?.source);
          const customResidue = isCustomResidueImageKey(residueKey);
          const managedResidue = !nativeHStatusPrompt && !ownResidueMode && (customResidue
            || (isResidueImageKey(residueKey) && request.debug?.source === 'attention-image-prompt-residue'));
          const residueOverride = managedResidue || ownResidueMode ? residuePromptOverride(residueKey) : null;
          if (ownResidueMode) {
            const own = residueOverride
              ? { prompt: residueOverride.positivePrompt.trim() || request.prompt,
                negativePrompt: residueOverride.negativePrompt }
              : request.debug?.source === 'wayward-situation' ? aipResiduePrompt(residueKey) : null;
            request = { ...request, ...AIP_RESIDUE_PROFILE,
              ...(own ? { prompt: own.prompt, negativePrompt: own.negativePrompt } : {}),
              debug: { ...request.debug, source: 'attention-image-prompt-residue-own' } };
          }
          if (managedResidue) request = { ...request, ...SECRET_IMAGE_PROFILE };
          if (residueOverride && !ownResidueMode) {
            const specialized = specializeResiduePrompt(request.prompt, request.negativePrompt || '', residueKey);
            request = { ...request, prompt: specialized.prompt, negativePrompt: specialized.negativePrompt };
          }
          if (managedResidue && !residueOverride) {
            try {
              const reference = await residueBasePrompt(residueKey);
              if (reference?.prompt) request = {
                ...request,
                prompt: reference.prompt,
                negativePrompt: reference.negativePrompt || '',
                workflow: reference.workflow || request.workflow,
                width: Number(reference.width) || request.width,
                height: Number(reference.height) || request.height,
                dimensions: reference.dimensions || request.dimensions,
                steps: Number(reference.steps) || request.steps,
                cfg: Number(reference.cfg) || request.cfg,
              };
            } catch (error) {
              console.warn('[attention-image-prompt] secret reference prompt', error);
            }
          }
          request = generationWeightAdjustRequest(request);
          const generated = request.bypassCache !== true ? positionGeneratedResults.get(request.imageKey) : null;
          if (generated && await imageEntryExists(generated)) return compatibleImageResult(generated, request.imageKey, true);
          if (generated) positionGeneratedResults.delete(request.imageKey);
          if (request.bypassCache === true) statusCacheAliases.delete(request.imageKey);
          const startedAt = Date.now();
          const trace = { at: startedAt, key: request.imageKey, status: 'running', durationMs: 0, error: '' };
          diagnostics.lastGeneration = trace;
          try {
            const content = request.bypassCache === true || globalPromptExclusionsFingerprint() || cameraSettingsFingerprint(positionSituationId(request.imageKey)) || similarImageLookupOverride(request.imageKey)
              ? null : statusContentKey(request);
            if (content) {
              const manifest = api.has('imageManifest') ? await api.fn('imageManifest')() : null;
              const existing = manifest ? manifest.entries?.[request.imageKey] : await imageLookup(request.imageKey);
              if (existing?.imagePath && (!existing.talentName || existing.talentName === request.imageKey)) {
                statusCacheAliases.delete(request.imageKey);
              } else {
                const old = !manifest?.entries?.[content.key] && await legacyStatusEntry(content.key, manifest);
                const url = old && imageEntryUrl(old);
                const canceled = api.has('imageGenerationInFlight')
                  && api.fn('imageGenerationInFlight').get?.(request.imageKey)?.cancelRequested;
                if (url && !canceled) {
                  statusCacheAliases.set(request.imageKey, old.talentName);
                  diagnostics.lastGeneration = { ...trace, status: 'success', reusedFrom: 'legacy-cache', durationMs: Date.now() - startedAt };
                  return compatibleImageResult({ url }, old.talentName || request.imageKey, true);
                }
                if (canceled) return null;
                statusCacheAliases.set(request.imageKey, content.key);
              }
            }
            const compactKey = compactGenerationKey(request.imageKey, shortImageKeysEnabled());
            const compatibleKey = compactGenerationKey(request.imageKey, true);
            if (compactKey !== request.imageKey || compatibleKey !== request.imageKey) {
              const existing = request.bypassCache === true ? null : await imageLookup(request.imageKey);
              const exact = existing?.talentName === request.imageKey && await imageEntryExists(existing);
              if (existing && !exact && await imageEntryExists(existing)) {
                const knownAlias = [compatibleKey, compactGenerationKey(request.imageKey)].includes(existing.talentName);
                const url = knownAlias && imageEntryUrl(existing);
                if (url) {
                  diagnostics.lastGeneration = { ...trace, status: 'success', reusedFrom: 'short-key', durationMs: Date.now() - startedAt };
                  return compatibleImageResult({ url }, existing.talentName || request.imageKey, true);
                }
              }
              if (compactKey !== request.imageKey && !exact) request = { ...request, imageKey: compactKey };
            }
            const inFlight = request.imageKey !== trace.key && api.has('imageGenerationInFlight')
              ? api.fn('imageGenerationInFlight') : null;
            const own = inFlight?.get?.(trace.key);
            let result;
            if (own && request.imageKey !== trace.key) {
              const active = inFlight.get(request.imageKey);
              if (active && active !== own) {
                const shared = await active.promise;
                if (shared?.url || own.cancelRequested) result = own.cancelRequested ? null : shared;
              }
              if (result === undefined) {
                if (own.cancelRequested) result = null;
                else {
                  inFlight.set(request.imageKey, own);
                  try { result = await forward(request); }
                  finally { if (inFlight.get(request.imageKey) === own) inFlight.delete(request.imageKey); }
                }
              }
            } else result = await forward(request);
            if (result?.url && (trace.key.includes('__position-') || isSavedPositionImageKey(trace.key))) {
              positionGeneratedResults.set(trace.key, result);
            }
            diagnostics.lastGeneration = {
              ...trace,
              status: result?.url ? 'success' : 'empty',
              durationMs: Date.now() - startedAt,
            };
            if (result?.url && result.fresh === true) nativeFreshVariantKeys.delete(trace.key);
            if (result?.url && result.fresh && refreshedPortraitPrompt) {
              nativeFreshPrompts.set(trace.key, { ...refreshedPortraitPrompt, key: trace.key });
              if (nativeFreshPrompts.size > 20) nativeFreshPrompts.delete(nativeFreshPrompts.keys().next().value);
              window.setTimeout(scheduleUiScan, 150);
            }
            return compatibleImageResult(result, trace.key);
          } catch (error) {
            diagnostics.lastGeneration = {
              ...trace,
              status: 'error',
              durationMs: Date.now() - startedAt,
              error: diagnosticText(error),
            };
            throw error;
          }
        },
      });
    }

    api.hook('outfitById', {
      after(result, [requestedId]) {
        if (requestedId === previewDraftOutfit?.id) return previewDraftOutfit;
        if (!result) return result;
        const prompts = currentOutfitPrompts();
        const override = prompts[String(result.id || '')] || prompts[String(requestedId || '')];
        const outfitId = String(result.id || requestedId || '');
        const base = { positivePrompt: override?.positivePrompt ?? String(result.imageTags || ''),
          negativePrompt: override?.negativePrompt ?? String(result.negativeImageTags || ''),
          topPrompt: override?.topPrompt ?? String(result.halves?.top || ''),
          skirtPrompt: override?.skirtPrompt ?? String(result.halves?.skirt || '') };
        const selected = effectiveExternalTarget('outfit', outfitId, base);
        if (!override && selected === base) return result;
        const explicitHalves = typeof override?.topPrompt === 'string' || typeof override?.skirtPrompt === 'string';
        const keepOriginalHalves = !explicitHalves && selected === base && override?.positivePrompt === String(result.imageTags || '');
        const useHalves = selected !== base || explicitHalves;
        return {
          ...result,
          imageTags: selected.positivePrompt,
          negativeImageTags: selected.negativePrompt,
          // The original half-tags would reintroduce the old prompt during partial exposure.
          halves: keepOriginalHalves ? result.halves : useHalves
            ? (explicitHalves ? { top: selected.topPrompt, skirt: selected.skirtPrompt } : customOutfitHalves(selected))
            : api.game === '2026-11-01' ? customOutfitHalves({ ...selected, topPrompt: '', skirtPrompt: '' }) : undefined,
        };
      },
    });

    function analFinishSceneKey(value) {
      const scene = String(value || '').split('__').find(part => part.startsWith('scene-')) || '';
      return /^scene-(?:(?:patron_)?anal_finish|finish_on_back_anal_internal)$/.test(scene);
    }

    function analSceneKey(value) {
      const scene = String(value || '').split('__').find(part => part.startsWith('scene-')) || '';
      return /^scene-(?:(?:patron_)?anal(?:_finish)?|finish_on_back_anal_internal)$/.test(scene);
    }

    api.hook('imageLookup', {
      // Wrap image-pack optimizers so state-specific keys cannot return unrelated art.
      priority: -1,
      async around(next, imageKey, ...args) {
        if (typeof imageKey !== 'string') return next(imageKey, ...args);
        let missingRequestedImage = false;
        const lookup = async key => {
          const entry = await next(key, ...args);
          if (await imageEntryExists(entry)) return entry;
          if (key === imageKey && entry?.talentName === imageKey) missingRequestedImage = true;
          return null;
        };
        const presetKey = residuePresetImageKey(imageKey);
        if (presetKey !== imageKey) {
          const preset = await lookup(presetKey);
          const resolved = preset?.talentName === presetKey ? preset : null;
          diagnostics.lastLookup = {
            at: Date.now(), key: imageKey.slice(0, 240), source: resolved ? 'residue-preset' : 'residue-preset-missing',
            resolvedKey: resolved ? presetKey.slice(0, 240) : '',
          };
          return resolved;
        }
        if (isResidueImageKey(imageKey)) {
          const residueKey = residueBaseImageKey(imageKey);
          const choice = currentResidueImageChoices()[residueKey];
          const selectedKey = choice?.selected;
          if (selectedKey && selectedKey !== imageKey) {
            const selected = await lookup(selectedKey);
            if (selected?.talentName === selectedKey) {
              diagnostics.lastLookup = {
                at: Date.now(), key: imageKey.slice(0, 240), source: 'residue-selected',
                resolvedKey: selectedKey.slice(0, 240),
              };
              return selected;
            }
          }
        }
        const override = /__(?:content|aipk)-/.test(imageKey) ? null : similarImageLookupOverride(imageKey);
        if (override?.key && override.key !== imageKey) {
          const selected = await lookup(override.key);
          if (selected?.talentName === override.key || (override.source === 'manual-auto-cleanup' && selected)) {
            diagnostics.lastLookup = {
              at: Date.now(), key: imageKey.slice(0, 240), source: override.source,
              resolvedKey: String(selected.talentName || override.key).slice(0, 240),
            };
            return selected;
          }
          if (override.fallbackKey && override.fallbackKey !== imageKey) {
            const fallback = await lookup(override.fallbackKey);
            if (fallback) return fallback;
          }
        }
        const result = await lookup(imageKey);
        if (missingRequestedImage) {
          diagnostics.lastLookup = { at: Date.now(), key: imageKey.slice(0, 240), source: 'missing-file', resolvedKey: '' };
          return null;
        }
        const alias = statusCacheAliases.get(imageKey);
        const previousFullKey = compactSituationAliases.get(imageKey);
        if (result?.talentName !== imageKey) {
          const candidates = [...new Set([previousFullKey, previousFullKey && compactGenerationKey(previousFullKey),
            previousFullKey && compactGenerationKey(previousFullKey, true), alias,
            alias && compactGenerationKey(alias), alias && compactGenerationKey(alias, true),
            compactGenerationKey(imageKey), compactGenerationKey(imageKey, true)])]
            .filter(key => key && key !== imageKey);
          for (const key of candidates) {
            const shared = await lookup(key);
            const old = key !== alias || shared?.talentName === key || !api.has('imageManifest') ? null
              : await legacyStatusEntry(key, await api.fn('imageManifest')());
            const resolvedAlias = shared?.talentName === key ? shared : old;
            if (resolvedAlias && (!analSceneKey(imageKey) || analSceneKey(resolvedAlias.talentName))) {
              diagnostics.lastLookup = {
                at: Date.now(), key: imageKey.slice(0, 240),
                source: old ? 'legacy-cache' : key === previousFullKey ? 'previous-full-key'
                  : key === alias ? 'shared-content' : 'short-key',
                resolvedKey: String(resolvedAlias.talentName || key).slice(0, 240),
              };
              return resolvedAlias;
            }
          }
        }
        const variant = Number(imageKey.match(/__v-(\d+)$/)?.[1]);
        const exactOnly = isResidueImageKey(imageKey)
          || imageKey.includes('__aip-')
          || regenerateCharacterImageKeys.has(imageKey)
          || imageKey.includes('__state-')
          || imageKey.includes('__content-')
          || imageKey.includes('__aipk-')
          || (!!alias && imageKey.includes('__aip-'))
          || imageKey.includes('__dialogue-')
          || imageKey.includes('__position-')
          || imageKey.includes('__character-regenerate-')
          || isSavedPositionImageKey(imageKey)
          || variant >= USER_VARIANT_START;
        let resolved = result;
        let source = result?.talentName === imageKey ? 'exact' : result ? 'nearest' : 'missing';
        if (exactOnly && result?.talentName !== imageKey) {
          const legacyKey = legacyDetailImageKeys.get(imageKey);
          const legacy = legacyKey ? await lookup(legacyKey) : null;
          resolved = legacy?.talentName === legacyKey ? legacy : null;
          source = resolved ? 'legacy-detail' : result ? 'nearest-blocked' : 'missing';
        } else if (!exactOnly && !result) {
          const baseKey = imageKey.replace(/__(?:state|character-(?:reuse|regenerate))-[a-z0-9]+(?=__v-\d+$|$)/, '');
          if (baseKey !== imageKey) {
            resolved = await lookup(baseKey);
            source = resolved ? 'base-fallback' : 'missing';
          }
        }
        if (resolved?.talentName !== imageKey) {
          const entries = await localGeneratedEntries();
          for (const key of new Set([imageKey, previousFullKey,
            previousFullKey && compactGenerationKey(previousFullKey),
            previousFullKey && compactGenerationKey(previousFullKey, true), alias,
            alias && compactGenerationKey(alias), alias && compactGenerationKey(alias, true),
            compactGenerationKey(imageKey), compactGenerationKey(imageKey, true)])) {
            const local = entries[key];
            if (local && await localImageExists(local.imagePath)) {
              resolved = local;
              source = 'local-cache';
              break;
            }
          }
        }
        if (analSceneKey(imageKey) && resolved && !analSceneKey(resolved.talentName)) {
          resolved = null;
          source = 'wrong-scene-blocked';
        }
        if (resolved?.talentName && resolved.talentName !== compactGenerationKey(imageKey)
          && resolved.talentName !== compactGenerationKey(imageKey, true)
          && (!alias || resolved.talentName !== compactGenerationKey(alias))
          && (!alias || resolved.talentName !== compactGenerationKey(alias, true))
          && accessorySituationCode(imageKey) !== accessorySituationCode(resolved.talentName)) {
          resolved = null;
          source = 'accessory-mismatch-blocked';
        }
        diagnostics.lastLookup = {
          at: Date.now(),
          key: imageKey.slice(0, 240),
          source,
          resolvedKey: typeof resolved?.talentName === 'string' ? resolved.talentName.slice(0, 240) : '',
        };
        return resolved;
      },
    });

    function activePortraitVariantState(key, value) {
      const unused = unusedPortraitImages()[similarImageSituationKey(key)] || [];
      if (!unused.length || !Array.isArray(value?.variants)) return value;
      const variants = value.variants.filter(variant => !unused.includes(variant));
      if (!variants.length || variants.length === value.variants.length) return value;
      const current = value.variants[value.currentIdx];
      return { ...value, variants, currentIdx: Math.max(0, variants.indexOf(current)) };
    }
    if (api.has('imageVariantState')) api.hook('imageVariantState', {
      after(result, [key]) { return activePortraitVariantState(key, result); },
    });
    if (api.has('saveImageVariantState')) api.hook('saveImageVariantState', {
      around(next, key, value, ...args) {
        return next(key, restoringUnusedPortraitVariant ? value : activePortraitVariantState(key, value), ...args);
      },
    });

    if (api.has('currentPortraitImageKey')) api.hook('currentPortraitImageKey', {
      around(next, current, ...args) {
        const committed = api.store.game();
        const previous = previousPortraitSnapshot;
        const snapshot = { committed, logSeq: current?.logSeq, log: current?.log,
          lastLog: current?.log?.at(-1), away: current?.awayEvents,
          lastAway: current?.awayEvents?.at(-1) };
        const unchangedRecords = previous?.committed === committed
          && previous.logSeq === snapshot.logSeq
          && previous.log?.length === snapshot.log?.length
          && previous.away?.length === snapshot.away?.length
          && previous.lastLog === snapshot.lastLog && previous.lastAway === snapshot.lastAway;
        previousPortraitSnapshot = snapshot;
        // A provisional tick key is discarded when it has no new log or away event to attach to.
        const skip = current && current !== committed && current.slot !== committed?.slot && unchangedRecords;
        if (skip) skipUnrecordedPortraitKey += 1;
        try { return next(current, ...args); }
        finally { if (skip) skipUnrecordedPortraitKey -= 1; }
      },
      after(result) {
        if (typeof result !== 'string') return result;
        const unused = unusedPortraitImages()[similarImageSituationKey(result)] || [];
        if (!unused.includes(result)) return result;
        return portraitImageVariants(result).variants.find(key => !unused.includes(key)) || result;
      },
    });

    api.hook('imageKey', { priority: 3000000, before: wakingSceneArgs });
    api.hook('imagePrompt', { priority: 3000000, before: wakingSceneArgs });
    api.hook('imageKey', {
      before: currentAccessoryArgs,
      after(result, args) {
        if (imagePlanDepth) return typeof result === 'string' ? externalPlanImageKey(result, args?.[0]) : result;
        if (skipUnrecordedPortraitKey) return result;
        let [character] = args;
        const state = api.store.game();
        if (!state || !character || typeof result !== 'string') return result;
        if (isResidueImageKey(result)) return result;
        const characterId = characterIdOf(state, character);
        if (!characterId) return result;
        character = currentAccessoryCharacter(state, character, characterId);
        const baseKey = sleepSituationImageKey(baseSituationImageKey(result), state, characterId);
        const { positiveGroups, negativeGroups, dialogue, characterPolicy, situational } = promptContext(state, character, characterId, baseKey);
        const expressionSignature = hasDistressedExpression(character, positiveGroups) ? '|expression-distressed-v2' : '';
        const hasPrompts = positiveGroups.length || negativeGroups.length || expressionSignature;
        const stateKey = hasPrompts
          ? keyWithState(baseKey, `${combinedStateSignature(positiveGroups, negativeGroups)}${expressionSignature}`, dialogue, characterPolicy, situational)
          : baseKey;
        const exactStateKey = hasPrompts
          ? keyWithState(baseKey, `${combinedStateSignature(positiveGroups, negativeGroups, true)}${expressionSignature}`, dialogue, characterPolicy, situational)
          : baseKey;
        const positionChoice = positionChoiceForImageKey(baseKey, characterId);
        const imageKey = situationImageKey(baseKey, state, character, characterId, positionChoice);
        if (promptPreviewing) return imageKey;
        if (characterPolicy === 'regenerate') regenerateCharacterImageKeys.add(imageKey);
        else regenerateCharacterImageKeys.delete(imageKey);
        const legacyImageKey = keyWithPosition(exactStateKey, positionChoice);
        if (!globalPromptExclusionsFingerprint() && !cameraSettingsFingerprint(positionSituationId(baseKey)) && !customOutfitFor(character, baseKey) && legacyImageKey !== imageKey
          && accessorySituationCode(legacyImageKey) === accessorySituationCode(imageKey)) legacyDetailImageKeys.set(imageKey, legacyImageKey);
        else legacyDetailImageKeys.delete(imageKey);
        const situationId = positionSituationId(stateKey);
        const override = positionOverride(situationId);
        if (override?.pendingPreviousKey) {
          const { pendingPreviousKey, ...settled } = override;
          setPositionOverride(situationId, {
            ...settled,
            sourceKey: imageKey,
            stateKey: stripPositionKey(stateKey),
            imageKey,
          });
        }
        return imageKey;
      },
    });

    // ImageStudio's separate prompt editor can rebuild AIP's semantic key.
    // Reconstruct the active camera's key after that provider, preserving all
    // non-AIP key segments. Keep the pre-camera behavior when it is disabled.
    api.hook('imageKey', {
      priority: -3000000,
      after(result, args) {
        if (imagePlanDepth || skipUnrecordedPortraitKey || typeof result !== 'string'
          || !globalThis.WML?.use?.('imagestudio-compatible-attention-image-prompt')) return result;
        const state = api.store.game(), character = args?.[0];
        const characterId = state && character && characterIdOf(state, character);
        if (!characterId || isResidueImageKey(result)) return result;
        const choice = positionChoiceForImageKey(result, characterId);
        const cameraSignature = cameraSettingsFingerprint(positionSituationId(result));
        const restored = cameraSignature
          ? situationImageKey(result, state, currentAccessoryCharacter(state, character, characterId), characterId, choice)
          : result;
        if (!choice) return restored;
        const positioned = keyWithPosition(restored, choice);
        const position = positioned.match(/__position-[^_]+/);
        if (!position) return restored;
        const clean = stripPositionKey(restored);
        const variant = clean.match(/__v-\d+$/)?.[0] || '';
        return `${variant ? clean.slice(0, -variant.length) : clean}${position[0]}${variant}`;
      },
    });

    function recordStatusCacheAlias(result) {
      const params = result.genParams || {};
      const content = globalPromptExclusionsFingerprint() || cameraSettingsFingerprint(positionSituationId(result.key)) || similarImageLookupOverride(result.key) ? null : statusContentKey({
        imageKey: legacyDetailImageKeys.get(result.key) || result.key,
        prompt: result.prompt,
        negativePrompt: result.negativePrompt,
        width: 1216,
        height: 832,
        steps: params.steps,
        cfg: params.cfg,
        loraStrength: params.loraStrength,
        checkpoint: result.checkpoint,
      });
      if (content) statusCacheAliases.set(result.key, content.key);
      else statusCacheAliases.delete(result.key);
    }

    api.hook('heroineOrgasm', {
      after(result, [before, targetId = before?.primaryCharacterId, options = {}]) {
        const character = result?.characters?.[targetId];
        if (!result || targetId !== result.primaryCharacterId || character?.lastOrgasmSlot !== result.slot
          || (character.orgasmsToday ?? 0) <= (before?.characters?.[targetId]?.orgasmsToday ?? 0)) return result;
        const patron = result.activeScene?.patron;
        const sex = result.activeScene?.sex;
        latestHeroineOrgasm = {
          slot: result.slot, targetId,
          patronId: patron?.customerId, patronStartedAtSlot: patron?.startedAtSlot,
          patronCount: patron?.elenaInteractionClimaxCount || 0,
          sexType: sex?.type, sexStartedAtSlot: sex?.startedAtSlot,
          sexCount: (sex?.elenaClimaxCount || 0) + (sex?.finish?.elenaAlsoOrgasmed && options.repeatInScene ? 1 : 0),
        };
        return result;
      },
    });
    let outerHStatusPortrait = false;
    api.hook('imagePrompt', {
      before: currentAccessoryArgs,
      after(result, args) {
        let [character] = args;
        const state = api.store.game();
        if (!state || !character || !result || !Array.isArray(result.parts)) return result;
        if (isResidueImageKey(result.key)) return result;
        const characterId = characterIdOf(state, character);
        if (!characterId) return result;
        character = currentAccessoryCharacter(state, character, characterId);
        if (!imagePlanDepth && characterId === state.primaryCharacterId)
          result = withoutUnfinishedPatronAftermath(result, state, character);
        const pregnancyField = activePregnancyField(state, characterId);
        const pregnancyPromptEnabled = currentFeaturePrompts().pregnancy;
        const imageLookPregnancy = (!imagePlanDepth || !pregnancyPromptEnabled) && pregnancyField && globalThis.__WML_IMAGELOOK__
          && (situationConfigForCharacter(character, characterId) || !pregnancyPromptEnabled)
          && result.parts.find(part => ['임신', 'Pregnancy'].includes(part?.label));
        if (imageLookPregnancy) result = {
          ...result,
          prompt: withoutPromptTags(result.prompt, imageLookPregnancy.tags),
          negativePrompt: withoutPromptTags(result.negativePrompt, pregnancyField.negative),
          parts: result.parts.filter(part => part !== imageLookPregnancy),
        };
        const gameDefaults = currentGameDefaultPrompts();
        if (typeof gameDefaults.positivePrompt === 'string') {
          const quality = result.parts.find(part => part.label === '품질');
          const prompt = quality?.tags && result.prompt.includes(quality.tags)
            ? joinPrompt(result.prompt.replace(quality.tags, gameDefaults.positivePrompt))
            : joinPrompt(`${gameDefaults.positivePrompt}, ${withoutPromptTags(result.prompt, GAME_PROMPT_QUALITY)}`);
          result = { ...result, prompt, genParams: promptGenParams(prompt),
            parts: quality ? result.parts.map(part => part === quality ? { ...part, tags: gameDefaults.positivePrompt } : part)
              : [{ label: '품질', tags: gameDefaults.positivePrompt }, ...result.parts] };
        }
        if (typeof gameDefaults.negativePrompt === 'string') {
          const archetype = character.generatedArchetype
            ?? (character.archetypeId ? wifeArchetypeById(character.archetypeId) : null);
          const appearance = new Set(String(archetype?.imageBase || '').toLowerCase().split(',').map(tag => tag.trim()));
          const nativeBase = GAME_PROMPT_NEGATIVE.split(', ')
            .filter(tag => !appearance.has(tag.toLowerCase())).join(', ');
          const original = String(result.negativePrompt || '');
          const remaining = original.includes(nativeBase)
            ? original.replace(nativeBase, '')
            : withoutPromptTags(original, GAME_PROMPT_NEGATIVE);
          result = { ...result, negativePrompt: joinPrompt(`${gameDefaults.negativePrompt}, ${remaining}`) };
        }
        const originalBaseKey = baseSituationImageKey(result.key);
        const baseKey = imagePlanDepth ? originalBaseKey
          : sleepSituationImageKey(originalBaseKey, state, characterId);
        if (baseKey !== originalBaseKey) result = { ...result, key: baseKey };
        const { positiveGroups, negativeGroups } = promptContext(state, character, characterId, baseKey, !!imagePlanDepth);
        const expressionSignature = !imagePlanDepth && hasDistressedExpression(character, positiveGroups) ? '|expression-distressed-v2' : '';
        if (expressionSignature) result = alignDistressedExpression(result);
        const nativeNegative = nativeCharacterNegative(character);
        const originalNegative = joinPrompt(`${result.negativePrompt || ''}, ${nativeNegative}`);
        const previousAttention = result.parts.filter(part => ['대응 필요 상황', 'Attention needed'].includes(part.label));
        if (previousAttention.length) {
          const retainedParts = result.parts.filter(part => !previousAttention.includes(part));
          const usedTags = new Set([...retainedParts.flatMap(part => promptTokens(part.tags)),
            ...positiveGroups.flatMap(group => group.value.tags).flatMap(promptTokens)]
            .map(tag => promptTagIdentity(tag).spaced));
          const staleAttentionTags = previousAttention.flatMap(part => promptTokens(part.tags))
            .filter(tag => !usedTags.has(promptTagIdentity(tag).spaced));
          result = { ...result, parts: retainedParts,
            prompt: withoutPromptTags(result.prompt, staleAttentionTags.join(', ')) };
        }
        let augmented;
        if (!positiveGroups.length && !negativeGroups.length) {
          augmented = expressionSignature || originalNegative !== result.negativePrompt
            ? { ...result, key: baseKey, negativePrompt: originalNegative }
            : result;
        } else {
          const characterPositive = positiveGroups.find(group => group.id === 'character');
          const characterNegative = negativeGroups.find(group => group.id === 'character');
          const extraPositiveGroups = positiveGroups.filter(group => !['character', 'outfit'].includes(group.id));
          const extraNegativeGroups = negativeGroups.filter(group => !['character', 'outfit'].includes(group.id));
          const extraTags = extraPositiveGroups.flatMap(group => group.value.tags).join(', ');
          const extraNegativeTags = extraNegativeGroups.flatMap(group => group.id === 'cycle'
            && positiveGroups.some(item => item.id === 'firstExperience')
            ? group.value.tags.flatMap(promptTokens).filter(tag => promptTagIdentity(tag).spaced !== 'blood on legs')
            : group.value.tags).join(', ');
          let basePartFound = false;
          const baseParts = result.parts.map(part => {
            if (!characterPositive || !['기본', 'Base'].includes(part.label)) return part;
            basePartFound = true;
            const characterTags = characterPositive.value.tags.join(', ');
            return {
              ...part,
              tags: characterPositive.mode === 'replace' ? characterTags : joinPrompt(`${part.tags || ''}, ${characterTags}`),
            };
          });
          const positiveParts = [
            ...baseParts,
            ...(!characterPositive || basePartFound ? [] : [{ label: characterPositive.label, tags: characterPositive.value.tags.join(', ') }]),
            ...extraPositiveGroups.map(group => ({ label: group.label, tags: group.value.tags.join(', ') })),
          ];
          const characterNegativeTags = characterNegative?.value.tags.join(', ') || '';
          const separatedPositiveParts = characterNegativeTags ? positiveParts.map(part => ({
            ...part,
            tags: withoutPromptTags(part.tags, characterNegativeTags),
          })) : positiveParts;
          const prompt = characterPositive && basePartFound
            ? joinPrompt(separatedPositiveParts.map(part => part.tags).join(', '))
            : withoutPromptTags(
              joinPrompt(`${result.prompt}, ${characterPositive?.value.tags.join(', ') || ''}, ${extraTags}`),
              characterNegativeTags,
            );
          const negativeBase = characterNegative?.mode === 'replace'
            ? joinPrompt(`${withoutPromptTags(originalNegative, nativeNegative)}, ${gameDefaults.negativePrompt || ''}`)
            : originalNegative;
          const negativePrompt = joinPrompt(`${negativeBase}, ${characterNegativeTags}, ${extraNegativeTags}`);
          augmented = {
            ...result,
            key: baseKey,
            prompt,
            negativePrompt,
            parts: separatedPositiveParts,
            genParams: promptGenParams(prompt),
          };
        }
        const positionChoice = imagePlanDepth ? null : positionChoiceForImageKey(baseKey, characterId);
        const positioned = imagePlanDepth ? augmented : alignHStatusBreastJewelry(
          applyPositionPreset(augmented.key === baseKey ? augmented : { ...augmented, key: baseKey }, positionChoice, characterId), character);
        const situationKey = imagePlanDepth ? externalPlanImageKey(baseKey, character)
          : situationImageKey(baseKey, state, character, characterId, positionChoice);
        const alignedNegative = withoutConflictingAppearanceNegatives(positioned.prompt, positioned.negativePrompt);
        const aligned = alignedNegative === positioned.negativePrompt
          ? positioned : { ...positioned, negativePrompt: alignedNegative };
        const guarded = alignAnalFinish(outerHStatusPortrait ? aligned : alignPortraitAccessories(aligned, character), characterId);
        const prepared = alignSleepScenePrompt(guarded, state, characterId);
        const finalPrompt = imagePlanDepth ? (prepared.key === situationKey ? prepared : { ...prepared, key: situationKey }) : rememberLatestScenePrompt(
          prepared.key === situationKey ? prepared : { ...prepared, key: situationKey },
          state,
          character,
          characterId,
          args,
        );
        if (!promptPreviewing && !imagePlanDepth) recordStatusCacheAlias(finalPrompt);
        return finalPrompt;
      },
    });
    api.hook('imagePrompt', {
      priority: -1000000,
      after(result, args) {
        if (promptPreviewing || imagePlanDepth) return result;
        const state = api.store.game();
        const characterId = state && args?.[0] && characterIdOf(state, args[0]);
        const composed = applyPromptModRules(alignSleepScenePrompt(
          replaceNativeFirstExperience(result), state, characterId));
        const cleaned = applyGlobalPromptExclusions(deduplicateFinalRequest(cameraApplyPromptResult(composed)));
        const applied = cleaned?.prompt !== composed?.prompt
          ? { ...cleaned, genParams: promptGenParams(cleaned.prompt) } : cleaned;
        if (latestScenePrompt?.result?.key === applied.key?.replace(/__virgin_blood(?=__|$)/, '')) {
          latestScenePrompt = { ...latestScenePrompt, result: applied };
          recordStatusCacheAlias(applied);
        }
        return applied;
      },
    });
    if (api.engine && api.sym && globalThis.WML?.status?.().loaded?.includes('h-status')) {
      const raw = api.sym('imagePrompt');
      const original = api.engine[raw];
      if (typeof original === 'function' && !original.__wmlOriginal) {
        // shortcut: H Status wraps imagePrompt outside WML hooks; remove when it uses api.hook.
        api.engine[raw] = function (...args) {
          const result = original.apply(this, args);
          const state = api.store.game();
          const characterId = state && characterIdOf(state, args[0]);
          const character = characterId ? currentAccessoryCharacter(state, args[0], characterId) : args[0];
          const aligned = alignPortraitAccessories(result, character);
          if (aligned !== result) {
            if (!promptPreviewing && !imagePlanDepth) {
              if (latestScenePrompt?.result?.key === aligned.key) latestScenePrompt = { ...latestScenePrompt, result: aligned };
              recordStatusCacheAlias(aligned);
            }
          }
          return aligned;
        };
        outerHStatusPortrait = true;
      }
    }
    installButtonPromptObserver();
    installSceneBaseOverrideHook();
    const externalPromptApi = Object.freeze({
      version: 1,
      editor: Object.freeze({
        version: 2, modVersion: '1.79.2', initialSettings: initialEditorSettings,
        capabilities: Object.freeze({ tabJson: true, studioSelection: true }),
        render: (body, win) => renderSettings(body, win),
        connect: host => { imageStudioEditorHost = host; },
        reload() {
          reloadSceneBaseOverrides(false); reloadSceneCandidatePools(false);
          reloadSceneStatePromptOverrides(); reloadStateEditorGlobalChanges();
          reloadGlobalPromptExclusions(); reloadPromptModRules(); reloadCameraSettings();
        },
        composePlan(result, character, state, room) {
          const previousState = imageStudioPlanState, previousPreview = promptPreviewing;
          imageStudioPlanState = state; promptPreviewing = true; imagePlanDepth++;
          try { return externalPromptApi.editor.finishPlan(imageStudioCompose(result, [character, room]), character); }
          finally { imagePlanDepth--; promptPreviewing = previousPreview; imageStudioPlanState = previousState; }
        },
        finishPlan(result, character) {
          const evaluated = evaluateSceneBaseOverride(result, sceneCandidateEntryForResult(result, character));
          const scene = !sceneBaseOverride(positionSituationId(result?.key)) && evaluated.reason !== 'applied'
            ? appendSelectedSceneCandidate(result) : evaluated.result;
          const value = applyGlobalPromptExclusions(deduplicateFinalRequest(cameraApplyPromptResult(applyPromptModRules(scene))));
          // Studio's planner bypasses AIP's live state-key path. Fingerprint its actual output.
          const parts = value.key.split('__').filter(part => !part.startsWith('studio-'));
          const at = parts.findIndex(part => /^v-\d+$/.test(part));
          parts.splice(at < 0 ? parts.length : at, 0, 'studio-' + shortHash(JSON.stringify([value.prompt, value.negativePrompt])));
          return { ...value, key: parts.join('__') };
        },
      }),
      cameraController,
      promptTagSearch: Object.freeze({ search: searchPromptTag }),
      globalExclusions: Object.freeze({ get: () => ({ positive: currentGlobalPromptExclusions('positive'), negative: currentGlobalPromptExclusions('negative') }),
        apply: removeGlobalPromptExclusions, cacheToken: globalPromptExclusionsFingerprint }),
      positionController: positionControllerApi,
      register: registerExternalPromptMenu,
      resolve: resolveExternalPrompt,
      listFields: externalFields,
      choicePrompts: Object.freeze({
        get: context => getButtonPromptRule(context, context?.mode),
        cacheToken: context => buttonPromptRuleToken(context, context?.mode),
        nativeCandidates: nativeChoiceSceneCandidates,
        getOutcome: getButtonPromptOutcome,
        outcomeCacheToken: buttonPromptOutcomeToken,
      }),
      scenePrompts: Object.freeze({
        list: () => scenePromptCatalog(),
        candidates: sceneCandidateSnapshot,
        get: scenePromptsApiSnapshot,
        cacheToken: scenePromptsApiCacheToken,
      }),
      listTargets(kind) {
        return externalTargetAdapters.get(kind)?.list() || [];
      },
      cacheToken(owner, id) {
        const prompt = resolveExternalPrompt(owner, id);
        return prompt ? shortHash(JSON.stringify([owner, id, prompt])) : '';
      },
    });
    api.provide?.(externalPromptApi);
    globalThis.AttentionImagePrompt = externalPromptApi;
    if (typeof globalThis.dispatchEvent === 'function' && typeof CustomEvent === 'function')
      globalThis.dispatchEvent(new CustomEvent('attention-image-prompt:ready', { detail: externalPromptApi }));
  },
});
