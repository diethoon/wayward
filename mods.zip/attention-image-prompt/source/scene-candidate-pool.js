    let sceneCandidatePools = {};
    let sceneCandidatePoolCount = 0;
    let sceneCandidateEditor = { id: '', selected: '', draft: '', name: '', adding: false, error: '' };

    function normalizeSceneCandidatePools(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).slice(0, 1000).flatMap(([id, pool]) => {
        if (!/^(?:scene|task|look)-./.test(id) || id.length > 160 || id.includes('__') || !pool || typeof pool !== 'object') return [];
        const edits = (Array.isArray(pool.edits) ? pool.edits : []).slice(0, 100).filter(entry => entry
          && typeof entry.source === 'string' && entry.source.length <= 50 && typeof entry.original === 'string'
          && entry.original.trim() && entry.original.length <= 12000 && typeof entry.prompt === 'string' && entry.prompt.length <= 12000)
          .map(({ source, original, prompt, name }) => ({ source, original, prompt: prompt.trim(),
            ...(typeof name === 'string' && name.trim() ? { name: name.trim().slice(0, 200) } : {}) }));
        const seen = new Set();
        const additions = (Array.isArray(pool.additions) ? pool.additions : []).slice(0, 100).filter(entry => entry
          && typeof entry.id === 'string' && /^add-\d+$/.test(entry.id) && !seen.has(entry.id) && seen.add(entry.id)
          && typeof entry.prompt === 'string' && entry.prompt.trim() && entry.prompt.length <= 12000)
          .map(({ id: candidateId, prompt, name }) => ({ id: candidateId, prompt: prompt.trim(),
            ...(typeof name === 'string' && name.trim() ? { name: name.trim().slice(0, 200) } : {}) }));
        const selected = additions.some(entry => entry.id === pool.selected) ? pool.selected : '';
        return edits.length || additions.length ? [[id, { edits, additions, selected }]] : [];
      }));
    }

    function reloadSceneCandidatePools(notify = true) {
      sceneCandidatePools = normalizeSceneCandidatePools(api.settings.get({ sceneCandidatePools: {} }).sceneCandidatePools);
      sceneCandidatePoolCount = Object.keys(sceneCandidatePools).length;
      if (notify) notifyExternalPromptChange();
    }

    function currentSceneCandidatePools() { return normalizeSceneCandidatePools(sceneCandidatePools); }

    function sceneCandidatePoolSource(id) {
      if (Object.hasOwn(sceneCandidatePools, id)) return { id, pool: sceneCandidatePools[id] };
      if (typeof id !== 'string' || id.includes('|sleep-')) return null;
      const base = id.split('|')[0];
      return base !== id && Object.hasOwn(sceneCandidatePools, base) ? { id: base, pool: sceneCandidatePools[base] } : null;
    }

    function saveSceneCandidatePool(id, pool) {
      const normalized = normalizeSceneCandidatePools({ [id]: pool });
      if (!Object.hasOwn(normalized, id) && (pool.edits?.length || pool.additions?.length)) return false;
      if (!Object.hasOwn(sceneCandidatePools, id) && Object.keys(sceneCandidatePools).length >= 1000) return false;
      const next = { ...sceneCandidatePools };
      if (normalized[id]) next[id] = normalized[id]; else delete next[id];
      api.settings.set({ sceneCandidatePools: next });
      sceneCandidatePools = next;
      sceneCandidatePoolCount = Object.keys(next).length;
      notifyExternalPromptChange();
      return true;
    }

    function sceneCandidateFingerprint(id) {
      const source = sceneCandidatePoolSource(id);
      if (!source) return '';
      const edits = source.pool.edits.filter(entry => entry.prompt !== entry.original)
        .map(({ source: candidateSource, original, prompt }) => [candidateSource, original, prompt])
        .sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
      const selected = source.pool.additions.find(entry => entry.id === source.pool.selected);
      return edits.length || selected ? shortHash(JSON.stringify([id, source.id, edits, selected?.prompt ?? null])) : '';
    }

    function sceneCandidateEntryForResult(result) {
      const id = positionSituationId(result?.key), pool = sceneCandidatePoolSource(id)?.pool;
      if (!pool || !Array.isArray(result?.parts)) return null;
      const labels = sceneBaseParts(id).labels;
      const parts = result.parts.filter(part => labels.includes(part?.label) && typeof part.tags === 'string');
      if (parts.length !== 1) return null;
      const candidates = nativeScenePromptCandidates(id).filter(candidate => sceneBaseParts(id).sources.includes(candidate.source));
      const matched = matchSceneBaseCandidate(id, parts[0].tags, result.key);
      if (!matched || candidates.filter(candidate => candidate.text === matched.text).length !== 1) return null;
      const addition = pool.additions.find(candidate => candidate.id === pool.selected);
      const edit = pool.edits.find(candidate => candidate.source === matched.source && candidate.original === matched.text
        && candidate.prompt !== candidate.original);
      if (!addition && !edit) return null;
      return { positivePrompt: addition ? addition.prompt : edit.prompt };
    }

    function appendSelectedSceneCandidate(result) {
      const id = positionSituationId(result?.key), pool = sceneCandidatePoolSource(id)?.pool;
      const selected = pool?.additions.find(candidate => candidate.id === pool.selected);
      if (!selected || !result || typeof result.prompt !== 'string' || !Array.isArray(result.parts)
        || !splitFinalPrompt(result.prompt) || !splitFinalPrompt(selected.prompt)) return result;
      const prompt = joinPrompt(`${result.prompt}, ${selected.prompt}`);
      return { ...result, prompt, parts: [...result.parts, { label: 'AIP 추가 장면 후보', tags: selected.prompt }], genParams: promptGenParams(prompt) };
    }

    function sceneCandidateSnapshot(id) {
      if (typeof id !== 'string' || !/^(?:scene|task|look)-./.test(id) || id.includes('__') || id.length > 160) return null;
      const source = sceneCandidatePoolSource(id), pool = source?.pool || { edits: [], additions: [], selected: '' };
      const candidates = nativeScenePromptCandidates(id).filter(candidate => sceneBaseParts(id).sources.includes(candidate.source))
        .map(candidate => {
          const edit = pool.edits.find(entry => entry.source === candidate.source && entry.original === candidate.text);
          return { ...candidate, prompt: edit?.prompt ?? candidate.text, ...(edit?.name ? { name: edit.name } : {}) };
        });
      return { situationId: id, sourceId: source?.id || id, candidates, additions: pool.additions.map(entry => ({ ...entry })),
        selected: pool.selected, blockedByBaseOverride: !!sceneBaseOverride(id) };
    }

    function renderSceneCandidateEditor(h, win, id, currentKey) {
      if (!id) return null;
      if (sceneCandidateEditor.id !== id) sceneCandidateEditor = { id, selected: '', draft: '', name: '', adding: false, error: '' };
      const source = sceneCandidatePoolSource(id), pool = source?.pool || { edits: [], additions: [], selected: '' };
      const allowed = sceneBaseParts(id).sources;
      const candidates = nativeScenePromptCandidates(id).filter(candidate => allowed.includes(candidate.source));
      const options = [...candidates.map((candidate, index) => ({ ...candidate, id: `native-${index}`, native: true })),
        ...pool.additions.map((candidate, index) => ({ ...candidate, text: candidate.prompt, label: candidate.name || `추가 후보 ${index + 1}` }))];
      const selected = options.find(candidate => candidate.id === sceneCandidateEditor.selected);
      const ambiguous = !!selected?.native && candidates.filter(candidate => candidate.text === selected.text).length !== 1;
      const isCurrent = positionSituationId(currentKey) === id;
      const save = () => {
        if (!splitFinalPrompt(sceneCandidateEditor.draft)) { sceneCandidateEditor.error = '괄호와 따옴표를 확인해 주세요.'; win.refresh(); return; }
        const next = { edits: [...pool.edits], additions: [...pool.additions], selected: pool.selected };
        if (sceneCandidateEditor.adding) {
          if (!sceneCandidateEditor.draft.trim()) { sceneCandidateEditor.error = '새 후보 문구를 입력해 주세요.'; win.refresh(); return; }
          let n = 1; while (next.additions.some(entry => entry.id === `add-${n}`)) n++;
          sceneCandidateEditor.selected = `add-${n}`;
          next.additions.push({ id: sceneCandidateEditor.selected, prompt: sceneCandidateEditor.draft, name: sceneCandidateEditor.name });
        } else if (selected?.native) {
          next.edits = next.edits.filter(entry => entry.source !== selected.source || entry.original !== selected.text);
          if (sceneCandidateEditor.draft.trim() !== selected.text.trim() || sceneCandidateEditor.name.trim())
            next.edits.push({ source: selected.source, original: selected.text, prompt: sceneCandidateEditor.draft, name: sceneCandidateEditor.name });
        } else if (selected) next.additions = next.additions.map(entry => entry.id === selected.id
          ? { ...entry, prompt: sceneCandidateEditor.draft, name: sceneCandidateEditor.name } : entry);
        else return;
        if (!saveSceneCandidatePool(id, next)) sceneCandidateEditor.error = '후보를 저장할 수 없어요.';
        else { sceneCandidateEditor.adding = false; sceneCandidateEditor.error = ''; if (isCurrent) refreshPortraitImage(); }
        win.refresh();
      };
      return h('section', { 'data-scene-candidate-editor': id, style: 'display:grid;gap:7px;margin:16px 0;' },
        h('strong', {}, '장면 기본 후보 편집'),
        h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '이 후보는 장면 프롬프트의 게임 기본 Positive와 연결돼요. 여기서 수정하면 같은 장면을 사용하는 다른 선택지에도 적용돼요.'),
        sceneBaseOverride(id) ? h('p', { class: 'wml-note' }, '이 장면의 전체 기본 문구 변경이 우선 적용되고 있어요. 개별 후보를 쓰려면 기존 전체 변경을 복원해 주세요.') : null,
        source?.id !== id && source ? h('p', { class: 'wml-note' }, `기본 상황 ${source.id}의 후보를 사용 중이에요. 저장하면 현재 상황에 별도로 적용돼요.`) : null,
        options.length ? h('label', {}, '수정할 후보 ', h('select', { 'data-scene-candidate-select': '', value: sceneCandidateEditor.selected,
          onchange: event => { const candidate = options.find(entry => entry.id === event.currentTarget.value);
            sceneCandidateEditor.selected = candidate?.id || ''; sceneCandidateEditor.adding = false;
            const saved = candidate?.native && pool.edits.find(entry => entry.source === candidate.source && entry.original === candidate.text);
            sceneCandidateEditor.draft = saved ? saved.prompt : candidate?.text || '';
            sceneCandidateEditor.name = saved?.name || (!candidate?.native && candidate?.name) || '';
            sceneCandidateEditor.error = ''; win.refresh(); } },
          h('option', { value: '', selected: !sceneCandidateEditor.selected }, '후보 선택'),
          ...options.map(candidate => {
            const saved = candidate.native && pool.edits.find(entry => entry.source === candidate.source && entry.original === candidate.text);
            return h('option', { value: candidate.id, selected: candidate.id === sceneCandidateEditor.selected }, saved?.name || candidate.label);
          }))) :
          h('p', { class: 'wml-muted wml-small' }, '확인된 게임 기본 후보가 없어요. 새 후보를 추가할 수 있어요.'),
        ambiguous ? h('p', { class: 'wml-note' }, '같은 원본 문구가 여러 후보에 있어 어느 후보인지 구분할 수 없어요. 이 후보의 개별 수정은 적용하지 않아요.') : null,
        (selected || sceneCandidateEditor.adding) ? h('label', { class: 'aip-prompt-field' }, h('strong', {}, '후보 이름'),
          h('input', { type: 'text', value: sceneCandidateEditor.name, maxLength: 200, placeholder: '이름을 비우면 기본 이름을 사용해요',
            'data-scene-candidate-name': '', oninput: event => { sceneCandidateEditor.name = event.currentTarget.value; } })) : null,
        (selected || sceneCandidateEditor.adding) ? h('label', { class: 'aip-prompt-field' }, h('strong', {}, sceneCandidateEditor.adding ? '새 Positive 후보' : '후보 Positive'),
          h('textarea', { rows: 3, value: sceneCandidateEditor.draft, 'data-scene-candidate-prompt': '', spellcheck: false, maxLength: 12000,
            style: 'width:100%;box-sizing:border-box;resize:vertical;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
            onfocus: () => { activeTagTarget = null; }, oninput: event => { sceneCandidateEditor.draft = event.currentTarget.value; sceneCandidateEditor.error = ''; updatePromptTagPreview(event, h, win); } }),
          promptTagPreview(h, sceneCandidateEditor.draft, win)) : null,
        sceneCandidateEditor.error ? h('p', { class: 'wml-note', role: 'status' }, sceneCandidateEditor.error) : null,
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;' },
          (selected || sceneCandidateEditor.adding) ? api.ui.button('후보 저장', save, { disabled: ambiguous }) : null,
          selected && !sceneCandidateEditor.adding && (!selected.native || pool.edits.some(entry => entry.source === selected.source && entry.original === selected.text))
            ? api.ui.button(selected.native ? '이 후보 원본 복원' : '이 후보 삭제', () => {
              const next = { ...pool,
                edits: pool.edits.filter(entry => !selected.native || entry.source !== selected.source || entry.original !== selected.text),
                additions: pool.additions.filter(entry => selected.native || entry.id !== selected.id),
                selected: pool.selected === selected.id ? '' : pool.selected };
              if (saveSceneCandidatePool(id, next)) { sceneCandidateEditor.selected = ''; sceneCandidateEditor.draft = ''; if (isCurrent) refreshPortraitImage(); }
              win.refresh();
            }) : null,
          api.ui.button('후보 추가', () => { sceneCandidateEditor = { id, selected: '', draft: '', name: '', adding: true, error: '' }; win.refresh(); })),
        pool.additions.length ? h('label', {}, '적용할 후보 ', h('select', { 'data-scene-candidate-active': '', value: pool.selected,
          onchange: event => { saveSceneCandidatePool(id, { ...pool, selected: event.currentTarget.value }); if (isCurrent) refreshPortraitImage(); win.refresh(); } },
          h('option', { value: '', selected: !pool.selected }, '게임의 원본 후보 선택 유지'),
          ...pool.additions.map((candidate, index) => h('option', { value: candidate.id, selected: candidate.id === pool.selected }, candidate.name || `추가 후보 ${index + 1}`)))) : null,
        pool.additions.length ? h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '추가 후보는 직접 선택할 때 적용해요. 원본 부분을 확인하면 교체하고, 확인하지 못하면 기존 문구에 추가해요. 원본 선택 유지는 게임의 기존 후보 선택 방식을 따릅니다.') : null);
    }

    reloadSceneCandidatePools(false);
