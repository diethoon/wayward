    function currentPositionTargetNegativePrompts() {
      const value = api.settings.get({ positionTargetNegativePrompts: {} }).positionTargetNegativePrompts;
      return value && typeof value === 'object' && !Array.isArray(value) ? { ...value } : {};
    }

    function savePositionTargetNegative(kind, id, value) {
      const negative = currentPositionTargetNegativePrompts();
      const key = `${kind}:${id}`;
      if (value) negative[key] = String(value).slice(0, 12000);
      else delete negative[key];
      api.settings.set({ positionTargetNegativePrompts: negative });
    }

    function effectivePositionPresetPrompt(preset) {
      if (!preset) return null;
      const base = { positivePrompt: preset.prompt || '',
        negativePrompt: currentPositionTargetNegativePrompts()[`position-preset:${preset.id}`] || '' };
      return effectiveExternalTarget('position-preset', preset.id, base);
    }

    function effectivePositionGroupPrompt(slotId, moduleMode = false) {
      const base = { positivePrompt: moduleMode ? GROUP_SLOT_BY_ID[slotId]?.prompt || '' : positionGroupPromptById(slotId),
        negativePrompt: currentPositionTargetNegativePrompts()[`position-group:${slotId}`] || '' };
      return effectiveExternalTarget('position-group', slotId, base);
    }

    registerExternalTargetAdapter('position-module', {
      list: () => availablePositionModules().map(module => ({ id: module.id, label: module.name })),
      read: id => {
        const module = availablePositionModules().find(item => item.id === id);
        return module ? { positivePrompt: module.positivePrompt || '', negativePrompt: module.negativePrompt || '' } : null;
      },
      save: (id, changes) => {
        if (!availablePositionModules().some(module => module.id === id)) return false;
        for (const field of ['positivePrompt', 'negativePrompt']) {
          if (typeof changes[field] === 'string' && !savePositionModulePrompt(id, field, changes[field])) return false;
        }
        positionRandomChoices.clear();
        return true;
      },
      reset: id => {
        if (id.startsWith('custom-') || !availablePositionModules().some(module => module.id === id)) return false;
        const prompts = currentPositionModulePrompts();
        delete prompts[id];
        api.settings.set({ positionModulePrompts: prompts });
        positionRandomChoices.clear();
        return true;
      },
    });

    registerExternalTargetAdapter('position-preset', {
      list: () => Object.values(POSITION_PRESETS).map(preset => ({ id: preset.id, label: preset.name })),
      read: id => {
        const preset = positionPresetById(id);
        return preset ? { positivePrompt: preset.prompt || '', negativePrompt: currentPositionTargetNegativePrompts()[`position-preset:${id}`] || '' } : null;
      },
      save: (id, changes) => {
        if (!POSITION_PRESETS[id]) return false;
        if (typeof changes.positivePrompt === 'string') api.settings.set({ positionPresetPrompts: {
          ...currentPositionPresetPrompts(), [id]: changes.positivePrompt,
        } });
        if (typeof changes.negativePrompt === 'string') savePositionTargetNegative('position-preset', id, changes.negativePrompt);
        positionRandomChoices.clear();
        return true;
      },
      reset: id => {
        if (!POSITION_PRESETS[id]) return false;
        const prompts = currentPositionPresetPrompts();
        delete prompts[id];
        api.settings.set({ positionPresetPrompts: prompts });
        savePositionTargetNegative('position-preset', id, '');
        positionRandomChoices.clear();
        return true;
      },
    });

    registerExternalTargetAdapter('position-group', {
      list: () => GROUP_SLOT_OPTIONS.map(option => ({ id: option.id, label: option.name })),
      read: id => GROUP_SLOT_BY_ID[id] ? { positivePrompt: positionGroupPromptById(id),
        negativePrompt: currentPositionTargetNegativePrompts()[`position-group:${id}`] || '' } : null,
      save: (id, changes) => {
        if (!GROUP_SLOT_BY_ID[id]) return false;
        if (typeof changes.positivePrompt === 'string') api.settings.set({ positionGroupPrompts: {
          ...currentPositionGroupPrompts(), [id]: changes.positivePrompt,
        } });
        if (typeof changes.negativePrompt === 'string') savePositionTargetNegative('position-group', id, changes.negativePrompt);
        positionRandomChoices.clear();
        return true;
      },
      reset: id => {
        if (!GROUP_SLOT_BY_ID[id]) return false;
        const prompts = currentPositionGroupPrompts();
        delete prompts[id];
        api.settings.set({ positionGroupPrompts: prompts });
        savePositionTargetNegative('position-group', id, '');
        positionRandomChoices.clear();
        return true;
      },
    });

    const validExternalPositionStateId = id => typeof id === 'string' && id.length <= 160
      && /^(?:scene|task|look)-/.test(id) && !id.includes('__');
    registerExternalTargetAdapter('position-state', {
      list: () => [...new Set([...Object.keys(currentPositionStatePrompts()), latestScenePrompt?.situationId]
        .filter(validExternalPositionStateId))].map(id => ({ id, label: positionSituationLabel(id) })),
      read: id => {
        if (!validExternalPositionStateId(id)) return null;
        const prompt = currentPositionStatePrompts()[id];
        return { positivePrompt: prompt?.positivePrompt || '', negativePrompt: prompt?.negativePrompt || '' };
      },
      save: (id, changes) => {
        if (!validExternalPositionStateId(id)) return false;
        const prompts = currentPositionStatePrompts();
        const next = { positivePrompt: '', negativePrompt: '', onlyState: false, ...prompts[id] };
        for (const field of ['positivePrompt', 'negativePrompt']) if (typeof changes[field] === 'string') next[field] = changes[field];
        if (next.positivePrompt || next.negativePrompt || next.onlyState) prompts[id] = next;
        else delete prompts[id];
        api.settings.set({ positionStatePrompts: prompts });
        positionRandomChoices.clear();
        return true;
      },
      reset: id => {
        if (!validExternalPositionStateId(id)) return false;
        const prompts = currentPositionStatePrompts();
        if (prompts[id]?.onlyState) prompts[id] = { positivePrompt: '', negativePrompt: '', onlyState: true };
        else delete prompts[id];
        api.settings.set({ positionStatePrompts: prompts });
        positionRandomChoices.clear();
        return true;
      },
    });
