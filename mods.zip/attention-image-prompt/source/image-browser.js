    function imageEntryUrl(entry) {
      try {
        if (api.has('imageUrl')) {
          const url = api.fn('imageUrl')(entry);
          if (url) return String(url);
        }
      } catch (error) {
        console.warn('[attention-image-prompt] image URL', error);
      }
      const path = String(entry?.imagePath || '').replaceAll('\\', '/');
      if (!path || entry?.source === 'server' || path.startsWith('/')
        || path.split('/').includes('..') || /^[a-z]+:/i.test(path)) return '';
      return /^(?:https?:|data:|blob:)/i.test(path)
        ? path
        : `images/${path.split('/').map(encodeURIComponent).join('/')}`;
    }

    async function imageEntryExists(entry) {
      const url = (entry?.imagePath && imageEntryUrl(entry)) || entry?.url;
      if (!url) return true;
      if (/^(?:data:|blob:)/i.test(url)) return true;
      try {
        const response = await fetch(url, { method: 'HEAD', credentials: 'omit', cache: 'no-store' });
        if (response.status === 404 || response.status === 410) return false;
        if (response.ok && !/^text\/html/i.test(response.headers?.get?.('content-type') || '')) return true;
      } catch { /* file:// and some image hosts block HEAD even when img can load. */ }
      if (typeof Image !== 'function') return true;
      return new Promise(resolve => {
        const probe = new Image();
        const finish = exists => {
          clearTimeout(timeout);
          probe.onload = probe.onerror = null;
          resolve(exists);
        };
        const timeout = setTimeout(() => finish(true), 5000);
        probe.onload = () => finish(true);
        probe.onerror = () => finish(false);
        probe.src = `${url}${url.includes('?') ? '&' : '?'}aip_file_check=${Date.now()}`;
      });
    }

    let enlargedImagePreview = null;
    function openSimilarImagePreview(entry, requestedKey, directUrl = '') {
      const url = directUrl || imageEntryUrl(entry);
      if (!url) return;
      const storedKey = entry?.talentName && entry.talentName !== requestedKey ? entry.talentName : '';
      enlargedImagePreview = { url, requestedKey, storedKey };
      const win = api.ui.window({
        id: 'similar-image-preview', title: '이미지 크게 보기', width: 1180, height: 860,
        render(body) {
          const { url, requestedKey, storedKey } = enlargedImagePreview;
          body.replaceChildren(api.ui.h('div', { style: 'display:grid;gap:8px;min-width:0;' },
            api.ui.h('img', { src: url, alt: '확대 이미지', style: 'display:block;width:100%;max-height:75vh;object-fit:contain;background:#0c0a09;' }),
            api.ui.h('div', { class: 'wml-muted wml-small', style: 'overflow-wrap:anywhere;' }, requestedKey),
            storedKey ? api.ui.h('div', { class: 'wml-muted wml-small', style: 'overflow-wrap:anywhere;' },
              `저장된 이미지 키: ${storedKey}`) : null));
        },
      });
      win.refresh();
    }

    function manifestImageEntries(manifest, character = '') {
      const seenPaths = new Set();
      const entries = [];
      for (const [key, value] of Object.entries(manifest?.entries || {})) {
        if (!value?.imagePath) continue;
        const name = value.talentName || key;
        if (character && !isCharacterImage(name, character)) continue;
        if (seenPaths.has(value.imagePath)) continue;
        seenPaths.add(value.imagePath);
        entries.push({ ...value, talentName: name });
      }
      return entries;
    }

    function similarImageEntries(imageKey, entries) {
      const target = similarImageProfile(imageKey);
      const similar = [];
      for (const entry of entries) {
        const score = similarImageScore(target, similarImageProfile(entry.talentName));
        if (score >= 0) similar.push({ ...entry, score });
      }
      return similar.sort((left, right) => right.score - left.score
        || Number(right.createdAt || 0) - Number(left.createdAt || 0));
    }

    function searchedImageEntries(entries, query) {
      const wanted = String(query || '').trim().toLocaleLowerCase();
      if (!wanted) return entries;
      return entries.filter(entry => `${entry.talentName} ${entry.imagePath}`.toLocaleLowerCase().includes(wanted));
    }

    function similarImageLabel(imageKey) {
      const parts = String(imageKey || '').split('__').filter(part =>
        !/^(?:v-\d+|state-[a-z0-9]+|dialogue-[a-z0-9]+|character-(?:reuse|regenerate)-[a-z0-9]+)$/.test(part)
        && !/^(?:scene|task|look)-/.test(part));
      return [...new Set(parts.slice(1))].slice(0, 5).join(' · ') || '기본 이미지';
    }

    function refreshPortraitImage() {
      api.store.update(state => state ? { ...state } : state);
    }

    function unusedPortraitImages() {
      if (imageStudioOwnsSelection()) return {};
      const saved = api.settings.get({ unusedPortraitImages: {} }).unusedPortraitImages;
      if (!saved || typeof saved !== 'object' || Array.isArray(saved)) return {};
      return Object.fromEntries(Object.entries(saved).filter(([key, variants]) =>
        key && key.length <= 1000 && Array.isArray(variants)).map(([key, variants]) =>
        [key, [...new Set(variants.filter(value => typeof value === 'string' && value && value.length <= 1000))]]));
    }

    function unusedPortraitImageOrder() {
      if (imageStudioOwnsSelection()) return {};
      const saved = api.settings.get({ unusedPortraitImageOrder: {} }).unusedPortraitImageOrder;
      if (!saved || typeof saved !== 'object' || Array.isArray(saved)) return {};
      return Object.fromEntries(Object.entries(saved).filter(([key, variants]) =>
        key && key.length <= 1000 && Array.isArray(variants)).map(([key, variants]) =>
        [key, [...new Set(variants.filter(value => typeof value === 'string' && value && value.length <= 1000))]]));
    }

    function portraitOrderWithUnused(active, previousOrder, unused) {
      const order = [...active];
      for (const [index, key] of previousOrder.entries()) {
        if (!unused.includes(key) || order.includes(key)) continue;
        const next = previousOrder.slice(index + 1).find(candidate => order.includes(candidate));
        const previous = previousOrder.slice(0, index).reverse().find(candidate => order.includes(candidate));
        order.splice(next ? order.indexOf(next) : previous ? order.indexOf(previous) + 1 : order.length, 0, key);
      }
      return order;
    }

    function portraitImageVariants(targetKey) {
      if (!api.has('imageVariantState')) return { variants: [], currentIdx: 0 };
      try {
        const state = api.fn('imageVariantState')(targetKey);
        return { variants: [...new Set(state?.variants?.length ? state.variants : [targetKey])], currentIdx: state?.currentIdx || 0 };
      } catch (error) {
        console.warn('[attention-image-prompt] portrait image variants', error);
        return { variants: [], currentIdx: 0 };
      }
    }

    let restoringUnusedPortraitVariant = false;
    function setPortraitImageUse(targetKey, variantKey, use, portrait, viewHost) {
      if (!api.has('saveImageVariantState')) return false;
      const state = portraitImageVariants(targetKey);
      const previousCount = state.variants.length;
      const choice = similarImageChoice(targetKey);
      const manualSource = choice?.manualVariants?.[variantKey]
        || (choice?.mode === 'selected' && variantKey === choice.autoKey ? choice.keys[0] : '');
      if (!use && manualSource && choice.keys.includes(manualSource)) {
        return applySimilarImageChoice(targetKey, choice.keys.filter(key => key !== manualSource),
          choice.mode, portrait, viewHost);
      }
      if (use && choice?.mode === 'selected') return false;
      if (!use && choice?.mode === 'both' && choice.autoVariants.length === 1
        && choice.autoVariants[0] === variantKey) return false;
      const saved = unusedPortraitImages();
      const group = similarImageSituationKey(targetKey);
      const unused = saved[group] || [];
      if (use ? !unused.includes(variantKey) : !state.variants.includes(variantKey) || previousCount <= 1) return false;
      const savedOrder = unusedPortraitImageOrder();
      const order = portraitOrderWithUnused(state.variants, savedOrder[group] || [...state.variants, ...unused], unused);
      const nextUnused = use ? unused.filter(key => key !== variantKey) : [...unused, variantKey];
      const variants = use ? order.filter(key => !nextUnused.includes(key)) : state.variants.filter(key => key !== variantKey);
      const currentKey = state.variants[state.currentIdx];
      const currentIdx = Math.max(0, variants.indexOf(currentKey));
      if (nextUnused.length) {
        saved[group] = nextUnused;
        savedOrder[group] = order;
      } else {
        delete saved[group];
        delete savedOrder[group];
      }
      const patch = { unusedPortraitImages: saved, unusedPortraitImageOrder: savedOrder };
      if (choice) {
        const manualVariants = new Set(Object.keys(choice.manualVariants));
        const autoVariants = variants.filter(key => !manualVariants.has(key) && !nextUnused.includes(key));
        const choices = currentSimilarImageChoices();
        choices[group] = { ...choice, autoVariants, autoKey: autoVariants[0] || '' };
        patch.similarImageChoices = choices;
      }
      let nativeSaved = false;
      try {
        restoringUnusedPortraitVariant = use;
        try { api.fn('saveImageVariantState')(targetKey, { variants, currentIdx }); }
        finally { restoringUnusedPortraitVariant = false; }
        nativeSaved = true;
        api.settings.set(patch);
      } catch (error) {
        if (nativeSaved) {
          try { api.fn('saveImageVariantState')(targetKey, state); }
          catch (rollbackError) { console.warn('[attention-image-prompt] portrait image rollback', rollbackError); }
        }
        console.warn('[attention-image-prompt] portrait image use', error);
        return false;
      }
      try { syncMountedPortrait(portrait, viewHost, previousCount, variants.length, targetKey); }
      catch (error) { console.warn('[attention-image-prompt] native image variant sync', error); }
      refreshPortraitImage();
      return true;
    }

    function nativePortraitAddButton(portrait) {
      return [...(portrait?.querySelectorAll?.('button') || [])].find(button =>
        ['현재 상태의 다른 이미지 추가', '이 그림을 다른 버전으로 다시 그려요',
          'Add another variant of this state', 'Draw another version of this picture']
          .some(title => String(button.title || '').startsWith(title))) || null;
    }

    function guardUnusedPortraitVariantOnAdd(portrait) {
      const button = nativePortraitAddButton(portrait);
      if (!button || button.__attentionUnusedVariantGuard) return;
      button.__attentionUnusedVariantGuard = true;
      button.addEventListener('click', event => {
        if (imageStudioOwnsSelection()) return;
        const key = activePortraitImageKey(latestScenePrompt?.result?.key || '');
        if (!key || !api.has('saveImageVariantState')) return;
        const state = portraitImageVariants(key);
        const used = new Set(state.variants.map(value => Number(String(value).match(/__v-(\d+)$/)?.[1]))
          .filter(Number.isFinite));
        let nativeVariant = USER_VARIANT_START;
        while (used.has(nativeVariant)) nativeVariant += 1;
        const nativeKey = /__v-\d+$/.test(key)
          ? key.replace(/__v-\d+$/, `__v-${nativeVariant}`) : `${key}__v-${nativeVariant}`;
        const unused = unusedPortraitImages()[similarImageSituationKey(key)] || [];
        if (!unused.length) {
          nativeFreshVariantKeys.add(nativeKey);
          return;
        }
        const safeVariant = nextPositionVariant(key);
        if (nativeVariant === safeVariant) {
          nativeFreshVariantKeys.add(nativeKey);
          return;
        }
        const viewHost = portraitViewHost(portrait);
        if (!viewHost) return;
        event.preventDefault();
        event.stopImmediatePropagation?.();
        event.stopPropagation();
        const variantKey = /__v-\d+$/.test(key)
          ? key.replace(/__v-\d+$/, `__v-${safeVariant}`) : `${key}__v-${safeVariant}`;
        const active = state.variants.filter(value => !unused.includes(value));
        const anchor = active.indexOf(key);
        const variants = anchor < 0
          ? [...active, variantKey]
          : [...active.slice(0, anchor), variantKey, ...active.slice(anchor)];
        try {
          api.fn('saveImageVariantState')(key, { variants, currentIdx: variants.indexOf(variantKey) });
          nativeFreshVariantKeys.add(variantKey);
          const observer = new MutationObserver(() => {
            if (portrait.isConnected === true) return;
            const previous = [...(viewHost.querySelectorAll?.('button') || [])]
              .find(candidate => ['이전 이미지', '이전 버전', 'Previous variant', 'Previous version']
                .includes(candidate.title));
            if (!previous) return;
            observer.disconnect();
            previous.click();
          });
          observer.observe(viewHost, { childList: true, subtree: true });
          window.setTimeout(() => observer.disconnect(), 5000);
          syncMountedPortrait(portrait, viewHost, state.variants.length, variants.length, key);
        } catch (error) {
          console.warn('[attention-image-prompt] unused portrait variant add', error);
          window.alert(`이미지 추가 생성을 시작하지 못했습니다: ${error.message || error}`);
        }
      }, true);
    }

    function portraitViewHost(portrait) {
      for (let node = portrait, depth = 0; node && depth < 8; node = node.parentElement, depth += 1) {
        const titles = [...(node.querySelectorAll?.('button') || [])].map(button => String(button.title || ''));
        if (titles.includes('초상화 보기') && titles.includes('캐릭터 정보 카드 보기')) return node;
      }
      return null;
    }

    function syncNativePortraitVariants(portrait, key) {
      if (imageStudioOwnsSelection()) return false;
      if (!portrait || !key) return false;
      const wanted = portraitImageVariants(key);
      if (!wanted.variants.length) return false;
      const group = similarImageSituationKey(key);
      // shortcut: this game keeps portrait variants in React-local state; replace when it exposes a supported setter.
      const fiberName = Object.keys(portrait).find(name => name.startsWith('__reactFiber'));
      for (let fiber = portrait[fiberName], depth = 0; fiber && depth < 5; fiber = fiber.return, depth += 1) {
        for (let hook = fiber.memoizedState, index = 0; hook && index < 80; hook = hook.next, index += 1) {
          const current = hook.memoizedState;
          if (!Array.isArray(current?.variants) || !Number.isInteger(current.currentIdx)
            || typeof hook.queue?.dispatch !== 'function'
            || !current.variants.some(variant => similarImageSituationKey(variant) === group)) continue;
          if (current.currentIdx !== wanted.currentIdx || current.variants.length !== wanted.variants.length
            || current.variants.some((variant, position) => variant !== wanted.variants[position])) {
            hook.queue.dispatch(wanted);
          }
          return true;
        }
      }
      return false;
    }

    function portraitDisplayParts(parts) {
      if (!Array.isArray(parts)) return parts;
      const parsed = parts.map(part => typeof part?.tags === 'string' ? splitFinalPrompt(part.tags) : null);
      if (parsed.some(item => !item)) return parts;
      const joined = parts.map(part => part.tags).join(', ');
      const cleaned = deduplicateFinalPrompt(joined);
      if (cleaned === joined) return parts;
      const finalTokens = splitFinalPrompt(cleaned);
      if (!finalTokens) return parts;
      const remaining = new Map();
      for (const token of finalTokens.tokens) {
        const text = token.trim();
        if (text) remaining.set(text, (remaining.get(text) || 0) + 1);
      }
      return parts.map((part, index) => ({ ...part, tags: parsed[index].tokens.flatMap(token => {
        const text = token.trim();
        const count = remaining.get(text) || 0;
        if (!count) return [];
        remaining.set(text, count - 1);
        return [text];
      }).join(', ') }));
    }

    function syncNativePortraitPrompt(portrait) {
      // shortcut: this game's visible prompt is React-local; replace when it exposes a supported current-prompt setter.
      const fiberName = portrait && Object.keys(portrait).find(name => name.startsWith('__reactFiber'));
      for (let fiber = portrait?.[fiberName], depth = 0; fiber && depth < 5; fiber = fiber.return, depth += 1) {
        let shownHook = null;
        let current = null;
        let selectedKey = '';
        let loadedKey = '';
        for (let hook = fiber.memoizedState, index = 0; hook && index < 80; hook = hook.next, index += 1) {
          const value = hook.memoizedState;
          if (typeof value?.key === 'string' && typeof value.prompt === 'string'
            && typeof hook.queue?.dispatch === 'function') shownHook = hook;
          if (Array.isArray(value) && typeof value[0]?.key === 'string'
            && typeof value[0]?.prompt === 'string' && Array.isArray(value[0].parts)) current = value[0];
          if (Array.isArray(value?.variants) && Number.isInteger(value.currentIdx)) {
            selectedKey = value.variants[value.currentIdx] || '';
          }
          if (typeof value?.current === 'string' && value.current.includes('__')) loadedKey = value.current;
        }
        if (!shownHook || !current) continue;
        const shown = shownHook.memoizedState;
        const fresh = loadedKey === selectedKey ? nativeFreshPrompts.get(selectedKey) : null;
        const source = fresh || current;
        const expected = { ...deduplicateFinalRequest(source), parts: portraitDisplayParts(source.parts) };
        const accessoryTags = value => [
          /\bchoker\b/i.test(value), /\b(?:vibrator|dildo)\b/i.test(value),
        ].join(':');
        if (accessorySituationCode(shown.key) !== accessorySituationCode(expected.key)
          || accessoryTags(shown.prompt) !== accessoryTags(expected.prompt)
          || fresh && (shown.key !== expected.key || shown.prompt !== expected.prompt
            || shown.negativePrompt !== expected.negativePrompt)) {
          shownHook.queue.dispatch(expected);
        } else {
          const variant = { ...deduplicateFinalRequest(shown), parts: portraitDisplayParts(shown.parts) };
          if (variant.prompt !== shown.prompt || variant.negativePrompt !== shown.negativePrompt
            || JSON.stringify(variant.parts) !== JSON.stringify(shown.parts)) shownHook.queue.dispatch(variant);
        }
        const staleImage = loadedKey && selectedKey
          && accessorySituationCode(loadedKey) !== accessorySituationCode(selectedKey);
        const image = portrait.querySelector?.('img');
        const visualNodes = [image, ...(portrait.querySelectorAll?.('video, button[title="이미지 전체화면 보기"], button[title="이 이미지로 영상 만들기"]') || [])]
          .filter(Boolean);
        const veil = portrait.querySelector?.('[data-attention-stale-accessory-image]');
        if (staleImage && visualNodes.length) {
          for (const node of visualNodes) {
            if (!node.__attentionPreviousVisibility) node.__attentionPreviousVisibility = node.style.visibility || 'unset';
            node.style.visibility = 'hidden';
          }
          if (image && !image.__attentionImageLoadWatch) {
            image.__attentionImageLoadWatch = true;
            image.addEventListener('load', scheduleUiScan);
          }
          if (!veil) {
            const note = document.createElement('div');
            note.setAttribute('data-attention-stale-accessory-image', '');
            note.setAttribute('role', 'status');
            note.textContent = '이전 장착 상태 그림 숨김 · 현재 그림을 기다리는 중';
            note.style.cssText = 'position:absolute;inset:0;display:grid;place-items:center;padding:16px;background:#1c1917;color:#d6d3d1;font-size:12px;text-align:center;pointer-events:none;z-index:3;';
            portrait.appendChild(note);
          }
        } else {
          for (const node of visualNodes) {
            if (!node.__attentionPreviousVisibility) continue;
            node.style.visibility = node.__attentionPreviousVisibility === 'unset' ? '' : node.__attentionPreviousVisibility;
            delete node.__attentionPreviousVisibility;
          }
          veil?.remove();
        }
        return current.key;
      }
      return '';
    }

    function syncMountedPortrait(portrait, viewHost, previousCount, nextCount, key) {
      if (syncNativePortraitVariants(portrait, key)) return;
      const buttons = [...(viewHost?.querySelectorAll?.('button') || [])];
      const portraitButton = buttons.find(button => button.title === '초상화 보기');
      const statusButton = buttons.find(button => button.title === '캐릭터 정보 카드 보기');
      if (portraitButton && statusButton) {
        statusButton.click();
        window.requestAnimationFrame(() => portraitButton.click());
        return;
      }
      const addButton = nativePortraitAddButton(portrait);
      for (let index = previousCount; addButton && index < nextCount; index += 1) addButton.click();
    }

    function applySimilarImageChoice(targetKey, selectedKeys, mode, portrait, viewHost, focusSource = '') {
      const previous = similarImageChoice(targetKey);
      const keys = [...new Set((Array.isArray(selectedKeys) ? selectedKeys : [selectedKeys])
        .filter(key => typeof key === 'string' && key && key.length <= 1000))].slice(0, 50);
      if (!keys.length) mode = 'auto';
      const supportsVariants = api.has('imageVariantState') && api.has('saveImageVariantState');
      if ((mode === 'both' || (mode === 'selected' && keys.length > 1)) && !supportsVariants) return false;
      let manualVariants = { ...(previous?.manualVariants || {}) };
      let autoVariants = [...(previous?.autoVariants || [])];
      let autoKey = previous?.autoKey || '';
      let previousCount = 0;
      let variants = autoVariants.length ? [...autoVariants] : [autoKey || targetKey];
      let variantsSaved = false;
      if (supportsVariants) {
        try {
          const state = api.fn('imageVariantState')(targetKey) || { variants: [], currentIdx: 0 };
          const currentVariants = state.variants?.length ? state.variants : [targetKey];
          previousCount = currentVariants.length;
          const currentKey = currentVariants[state.currentIdx] || targetKey;
          const rememberedManual = new Set(Object.keys(manualVariants));
           const unused = new Set(unusedPortraitImages()[similarImageSituationKey(targetKey)] || []);
           const discoveredAuto = currentVariants.filter(key => !rememberedManual.has(key) && !unused.has(key));
           autoVariants = [...new Set([
             ...(previous?.mode === 'selected' ? autoVariants : []), ...discoveredAuto,
           ])].filter(key => !unused.has(key));
           if (!autoVariants.length) autoVariants = [currentKey];
           autoKey = autoVariants.includes(autoKey) ? autoKey : autoVariants[0];

          const neededSources = mode === 'both' ? keys : mode === 'selected' ? keys.slice(1) : [];
          const usedNumbers = new Set([...autoVariants, ...Object.keys(manualVariants)]
            .map(key => Number(String(key).match(/__v-(\d+)$/)?.[1])).filter(Number.isFinite));
          for (const source of neededSources) {
            if (Object.values(manualVariants).includes(source)) continue;
            const reusable = Object.entries(manualVariants).find(([, mapped]) => !keys.includes(mapped));
            if (reusable) {
              manualVariants[reusable[0]] = source;
              continue;
            }
            let variant = USER_VARIANT_START;
            while (usedNumbers.has(variant)) variant += 1;
            usedNumbers.add(variant);
            const variantKey = /__v-\d+$/.test(targetKey)
              ? targetKey.replace(/__v-\d+$/, `__v-${variant}`)
              : `${targetKey}__v-${variant}`;
            manualVariants[variantKey] = source;
          }

          const variantFor = source => Object.entries(manualVariants).find(([, mapped]) => mapped === source)?.[0] || '';
          variants = mode === 'both'
            ? [...new Set([...autoVariants, ...keys.map(variantFor).filter(Boolean)])]
            : mode === 'selected'
              ? [...new Set([autoKey, ...keys.slice(1).map(variantFor).filter(Boolean)])]
              : [...autoVariants];
          const focusedVariant = mode === 'selected' && focusSource === keys[0] ? autoKey : variantFor(focusSource);
          const wantedKey = focusedVariant || (mode === 'auto' && variants.includes(currentKey) ? currentKey : variants[0]);
          const currentIdx = Math.max(0, variants.indexOf(wantedKey));
          api.fn('saveImageVariantState')(targetKey, { variants, currentIdx });
          variantsSaved = true;
        } catch (error) {
          console.warn('[attention-image-prompt] similar image variants', error);
          if (mode === 'both' || (mode === 'selected' && keys.length > 1)) return false;
        }
      }
      manualVariants = Object.fromEntries(Object.entries(manualVariants).slice(-100));
      const choice = {
        key: keys[0] || '', keys, mode, manualVariants,
        autoKey: autoKey || targetKey, autoVariants: autoVariants.length ? autoVariants : [autoKey || targetKey],
      };
      setSimilarImageChoice(targetKey, choice);
      try {
        if (variantsSaved) syncMountedPortrait(portrait, viewHost, previousCount, variants.length, targetKey);
      } catch (error) {
        console.warn('[attention-image-prompt] native image variant sync', error);
      }
      refreshPortraitImage();
      return true;
    }

    async function loadSimilarImages(picker, win) {
      const serial = picker.loadSerial = (picker.loadSerial || 0) + 1;
      const current = () => !picker.closed && picker.loadSerial === serial;
      picker.loading = true;
      picker.message = '';
      picker.previewEntries = {};
      win.refresh();
      try {
        if (!api.has('imageManifest')) throw new Error('이미지 목록 기능을 찾지 못했습니다.');
        // The game caches an empty manifest while the image server is offline.
        if (api.has('imageManifestReset')) api.fn('imageManifestReset')();
        const character = similarImageProfile(picker.targetKey).character;
        const entries = manifestImageEntries(await api.fn('imageManifest')(), character);
        const seenKeys = new Set(entries.map(entry => entry.talentName));
        const seenPaths = new Set(entries.map(entry => entry.imagePath));
        for (const entry of Object.values(await localGeneratedEntries(true))) {
          if (!isCharacterImage(entry.talentName, character)
            || seenKeys.has(entry.talentName) || seenPaths.has(entry.imagePath)) continue;
          entries.push(entry);
          seenKeys.add(entry.talentName);
          seenPaths.add(entry.imagePath);
        }
        const choice = similarImageChoice(picker.targetKey);
        const variantKeys = portraitImageVariants(picker.targetKey).variants;
        const previewKeys = [...new Set([...variantKeys,
          ...(unusedPortraitImages()[similarImageSituationKey(picker.targetKey)] || []),
          ...(choice?.keys || []), ...Object.values(choice?.manualVariants || {})])];
        const previews = {};
        await Promise.all(previewKeys.filter(key => isCharacterImage(key, character) && !seenKeys.has(key))
          .map(async key => {
            try {
              const candidates = offlineImageCandidates(key);
              let entry = candidates.map(candidate => entries.find(item => item.talentName === candidate)).find(Boolean) || null;
              if (!entry) try { entry = await api.fn('imageLookup')(key); }
              catch (error) { console.warn('[attention-image-prompt] portrait preview lookup', error); }
              if (!entry?.imagePath || !candidates.includes(entry.talentName)) {
                const local = await offlineCache.resolve(candidates);
                if (local) entry = local;
              }
              if (entry?.imagePath && (!entry.talentName || isCharacterImage(entry.talentName, character))) {
                previews[key] = entry;
                if (!entry.talentName || entry.talentName === key) {
                  entries.push({ ...entry, talentName: key });
                  seenKeys.add(key);
                }
              }
            } catch (error) { console.warn('[attention-image-prompt] portrait preview lookup', error); }
          }));
        if (!current()) return;
        picker.previewEntries = previews;
        picker.allEntries = entries.sort((left, right) => Number(right.createdAt || 0) - Number(left.createdAt || 0)
            || String(left.talentName).localeCompare(String(right.talentName)));
        picker.similarEntries = similarImageEntries(picker.targetKey, picker.allEntries);
        picker.message = picker.similarEntries.length
          ? `현재 장면과 비슷한 기존 이미지 ${picker.similarEntries.length}개를 찾았습니다.`
          : '같은 인물·장면의 기존 이미지를 찾지 못했습니다.';
      } catch (error) {
        if (!current()) return;
        picker.allEntries = [];
        picker.similarEntries = [];
        picker.previewEntries = {};
        picker.message = `이미지 목록을 불러오지 못했습니다: ${diagnosticText(error)}`;
      } finally {
        if (current()) {
          picker.loading = false;
          win.refresh();
        }
      }
    }

    async function similarImageServerReachable(picker) {
      let url;
      try {
        if (globalThis.__WW_STUDIO_OFFLINE_ONLY__ === true || settingsStore?.getState?.().imageBackendMode === 'off') return null;
        url = imageServerUrl('/api/image/health');
      } catch { return null; }
      if (!url) return null;
      const controller = typeof AbortController === 'function' ? new AbortController() : null;
      const timeout = setTimeout(() => controller?.abort(), 1500);
      picker.healthController = controller;
      picker.healthTimeout = timeout;
      try {
        const response = await fetch(url, { credentials: 'omit', cache: 'no-store', ...(controller ? { signal: controller.signal } : {}) });
        return response.ok;
      } catch { return false; }
      finally {
        clearTimeout(timeout);
        if (picker.healthController === controller) picker.healthController = null;
        if (picker.healthTimeout === timeout) picker.healthTimeout = null;
      }
    }

    function monitorSimilarImageRecovery(picker, win) {
      if (picker.closed || picker.recoveryTimer) return;
      picker.recoveryTimer = setTimeout(async () => {
        picker.recoveryTimer = null;
        if (picker.closed) return;
        const reachable = await similarImageServerReachable(picker);
        if (picker.closed) return;
        if (picker.recoveryRecheck) {
          picker.recoveryRecheck = false;
          return armSimilarImageRecovery(picker, win, true);
        }
        if (reachable === null) return;
        if (!reachable || picker.loading) return monitorSimilarImageRecovery(picker, win);
        picker.recoveryRefreshOnHealthy = false;
        void loadSimilarImages(picker, win);
      }, 5000);
    }

    function stopSimilarImageRecovery(picker) {
      picker.closed = true;
      picker.loadSerial = (picker.loadSerial || 0) + 1;
      if (picker.recoveryTimer) clearTimeout(picker.recoveryTimer);
      picker.recoveryTimer = null;
      picker.healthController?.abort();
      if (picker.healthTimeout) clearTimeout(picker.healthTimeout);
      picker.healthTimeout = null;
    }

    function armSimilarImageRecovery(picker, win, force = false, refreshOnHealthy = false) {
      if (refreshOnHealthy) picker.recoveryRefreshOnHealthy = true;
      if (picker.closed || picker.recoveryTimer) return;
      if (picker.recoveryArming || picker.healthTimeout) {
        if (force) picker.recoveryRecheck = true;
        return;
      }
      if (!force && Date.now() - (picker.lastRecoveryProbeAt || 0) < 5000) return;
      picker.lastRecoveryProbeAt = Date.now();
      picker.recoveryArming = true;
      void similarImageServerReachable(picker).then(reachable => {
        if (reachable === false && !picker.closed) monitorSimilarImageRecovery(picker, win);
        else if (reachable === true && !picker.closed && !picker.recoveryRecheck && picker.recoveryRefreshOnHealthy) {
          picker.recoveryRefreshOnHealthy = false;
          void loadSimilarImages(picker, win);
        }
      }).catch(() => {}).finally(() => {
        picker.recoveryArming = false;
        if (picker.recoveryRecheck && !picker.closed && !picker.recoveryTimer) {
          picker.recoveryRecheck = false;
          armSimilarImageRecovery(picker, win, true);
        }
      });
    }

    function openSimilarImagePicker(portrait) {
      const fallbackKey = latestScenePrompt?.result?.key || '';
      const picker = {
        targetKey: currentImageVariant(activePortraitImageKey(fallbackKey)),
        portrait, viewHost: portraitViewHost(portrait), allEntries: [], similarEntries: [], previewEntries: {}, mode: 'similar', query: '', pendingQuery: '', visibleLimit: 48, loading: true, message: '', closed: false, recoveryTimer: null,
      };
      const win = api.ui.window({
        id: 'similar-image-picker', title: '현재 상황에 사용할 이미지 선택', width: 980, height: 760,
        onClose() {
          stopSimilarImageRecovery(picker);
          delete win.__aipSimilarPickerActive;
        },
        render(body, windowHandle) {
          const h = api.ui.h;
          if (!picker.targetKey) {
            body.replaceChildren(h('p', { class: 'wml-note' }, '현재 초상화 상황을 먼저 한 번 표시해 주세요.'));
            return;
          }
          const choice = similarImageChoice(picker.targetKey);
          const selectedKeys = choice?.keys || [];
          const variantState = portraitImageVariants(picker.targetKey);
          const unusedVariants = unusedPortraitImages()[similarImageSituationKey(picker.targetKey)] || [];
          const portraitVariants = variantState.variants;
          const setUse = (key, use) => {
            const changed = setPortraitImageUse(picker.targetKey, key, use, picker.portrait, picker.viewHost);
            picker.message = changed
              ? use ? '이미지를 초상화 목록에 다시 넣었습니다.' : '이미지를 초상화 목록에서 제외했습니다. 원본 파일은 유지됩니다.'
              : '마지막 자동 이미지이거나 초상화 목록을 저장하지 못해 변경하지 않았습니다. 선택 이미지만 모드에서는 자동 모드로 바꾼 뒤 복원해 주세요.';
            if (changed && !use) armSimilarImageRecovery(picker, windowHandle, true, true);
            windowHandle.refresh();
          };
          const useMode = mode => {
            if (!applySimilarImageChoice(picker.targetKey, selectedKeys, mode, picker.portrait, picker.viewHost)) {
              picker.message = mode === 'both' ? '현재 게임에서는 자동 이미지와 선택 이미지를 한 목록에 합칠 수 없습니다.' : '이미지 사용 방식을 바꾸지 못했습니다.';
            } else if (mode === 'both') {
              picker.message = `자동 이미지와 선택 이미지 ${selectedKeys.length}개를 함께 사용합니다. 초상화의 이전·다음 화살표로 전환할 수 있습니다.`;
            } else if (mode === 'selected') {
              picker.message = `선택한 이미지 ${selectedKeys.length}개만 현재 상황에 사용합니다.`;
            } else {
              picker.message = '현재 상황을 자동 이미지만 사용하도록 복원했습니다.';
            }
            windowHandle.refresh();
          };
          const sourceEntries = picker.query || picker.mode === 'all' ? picker.allEntries : picker.similarEntries;
          const matchedEntries = searchedImageEntries(sourceEntries, picker.query);
          const visibleEntries = matchedEntries.slice(0, picker.visibleLimit);
          const choose = entry => {
            const selected = selectedKeys.includes(entry.talentName);
            const keys = selected
              ? selectedKeys.filter(key => key !== entry.talentName)
              : [...selectedKeys, entry.talentName];
            const mode = !keys.length ? 'auto' : choice ? choice.mode : 'selected';
            applySimilarImageChoice(picker.targetKey, keys, mode, picker.portrait, picker.viewHost, selected ? '' : entry.talentName);
            if (!selected) showGeneratedPositionImage(imageEntryUrl(entry));
            picker.message = selected
              ? keys.length ? `선택을 해제했습니다. 현재 ${keys.length}개가 선택되어 있습니다.` : '선택을 모두 해제하고 자동 이미지로 복원했습니다.'
              : mode === 'both' ? `선택 이미지 ${keys.length}개를 자동 이미지와 함께 사용합니다.`
                : mode === 'auto' ? `이미지 ${keys.length}개를 저장했습니다. 적용하려면 ‘선택 이미지만’ 또는 ‘자동 + 선택 함께’를 누르세요.`
                  : `선택 이미지 ${keys.length}개를 현재 상황에 연결했습니다.`;
            windowHandle.refresh();
          };
          const portraitCard = key => {
            const active = variantState.variants.includes(key);
            const source = choice?.manualVariants?.[key]
              || (choice?.mode === 'selected' && key === choice.autoKey ? selectedKeys[0] : key);
            const entry = picker.allEntries.find(item => item.talentName === source) || picker.previewEntries[source];
            const previewUrl = entry ? imageEntryUrl(entry)
              : key === variantState.variants[variantState.currentIdx]
                ? picker.portrait?.querySelector('img')?.currentSrc || '' : '';
            return h('div', { style: 'border:1px solid #57534e;border-radius:8px;padding:7px;min-width:0;' },
              previewUrl ? h('img', { src: previewUrl, alt: '초상화 이미지 미리보기', loading: 'lazy', onerror: () => armSimilarImageRecovery(picker, windowHandle), style: 'width:100%;height:180px;object-fit:contain;background:#0c0a09;border-radius:5px;' })
                : h('div', { class: 'wml-muted wml-small', style: 'height:180px;display:grid;place-items:center;background:#0c0a09;border-radius:5px;' }, '미리보기 없음'),
              h('div', { class: 'wml-muted wml-small', style: 'overflow-wrap:anywhere;' }, similarImageLabel(source)),
              previewUrl ? h('button', { type: 'button', class: 'wml-btn',
                'data-portrait-image-preview': key,
                onclick: () => openSimilarImagePreview(entry || {}, source, previewUrl),
              }, '크게 보기') : null,
              h('button', { type: 'button', class: 'wml-btn',
                'data-portrait-image-use': key, 'aria-pressed': active ? 'true' : 'false',
                disabled: active ? variantState.variants.length <= 1
                  || (choice?.mode === 'both' && choice.autoVariants.length === 1 && choice.autoVariants[0] === key)
                  : choice?.mode === 'selected',
                title: active && choice?.mode === 'both' && choice.autoVariants.length === 1 && choice.autoVariants[0] === key
                  ? '자동 이미지를 모두 빼려면 선택 이미지만 모드로 바꾸세요.'
                  : !active && choice?.mode === 'selected' ? '자동 이미지 모드로 바꾼 뒤 복원할 수 있습니다.' : '',
                onclick: () => setUse(key, !active),
              }, active ? '사용 안 함' : '다시 사용'));
          };
          body.replaceChildren(h('div', {},
            h('p', { class: 'wml-note' }, '비슷한 탭은 같은 인물·장면을 우선합니다. 검색은 탭이나 더 보기와 관계없이 현재 인물의 전체 이미지를 찾습니다. 파일은 삭제하지 않습니다.'),
            h('p', { class: 'wml-muted wml-small', style: 'overflow-wrap:anywhere;' }, `현재 상황: ${picker.targetKey}`),
            portraitVariants.length ? h('div', { style: 'margin:10px 0 14px;' },
              h('strong', {}, '현재 초상화 이미지 목록'),
              h('p', { class: 'wml-muted wml-small' }, '사용하지 않을 이미지를 목록에서 제외할 수 있습니다. 마지막 한 장은 남겨 둡니다.'),
              h('div', { 'data-portrait-active-list': '', style: 'display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:8px;' },
                ...portraitVariants.map(portraitCard)),
            ) : null,
            unusedVariants.length ? h('details', { style: 'margin:0 0 14px;' },
              h('summary', { style: 'cursor:pointer;' }, `사용 안 함 · 복원 (${unusedVariants.length})`),
              h('div', { 'data-portrait-unused-list': '', style: 'display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:8px;margin-top:8px;' },
                ...unusedVariants.filter(key => !variantState.variants.includes(key)).map(portraitCard)),
            ) : null,
            h('div', { style: 'display:flex;gap:6px;flex-wrap:wrap;margin:10px 0 12px;' },
              h('button', {
                type: 'button', class: 'wml-btn', 'data-similar-image-use-mode': 'auto',
                'aria-pressed': !choice || choice.mode === 'auto' ? 'true' : 'false',
                style: !choice || choice.mode === 'auto' ? 'border-color:#d97706;color:#fef3c7;background:#451a03;' : '',
                onclick: () => useMode('auto'),
              }, '자동 이미지만'),
              h('button', {
                type: 'button', class: 'wml-btn', disabled: !selectedKeys.length,
                'data-similar-image-use-mode': 'selected',
                'aria-pressed': choice?.mode === 'selected' ? 'true' : 'false',
                style: choice?.mode === 'selected' ? 'border-color:#d97706;color:#fef3c7;background:#451a03;' : '',
                onclick: () => useMode('selected'),
              }, '선택 이미지만'),
              h('button', {
                type: 'button', class: 'wml-btn', disabled: !selectedKeys.length || !api.has('imageVariantState') || !api.has('saveImageVariantState'),
                'data-similar-image-use-mode': 'both',
                'aria-pressed': choice?.mode === 'both' ? 'true' : 'false',
                title: '자동 이미지와 선택 이미지를 초상화 변형 목록에 함께 넣습니다.',
                style: choice?.mode === 'both' ? 'border-color:#d97706;color:#fef3c7;background:#451a03;' : '',
                onclick: () => useMode('both'),
              }, '자동 + 선택 함께'),
              h('span', { class: 'wml-muted wml-small', 'data-similar-image-selected-count': '' }, `선택 이미지 ${selectedKeys.length}개`),
              h('button', {
                type: 'button', class: 'wml-btn', disabled: !selectedKeys.length, 'data-similar-image-clear': '',
                onclick: () => {
                  applySimilarImageChoice(picker.targetKey, [], 'auto', picker.portrait, picker.viewHost);
                  picker.message = '선택을 모두 해제하고 자동 이미지로 복원했습니다.';
                  windowHandle.refresh();
                },
              }, '선택 전체 해제'),
              api.ui.button('목록 새로고침', () => loadSimilarImages(picker, windowHandle, true), { 'data-similar-image-refresh': '' }),
            ),
            h('div', { style: 'display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px;' },
              h('button', {
                type: 'button', class: 'wml-btn', 'aria-pressed': picker.mode === 'similar' ? 'true' : 'false',
                'data-similar-image-mode': 'similar',
                style: picker.mode === 'similar' ? 'border-color:#d97706;color:#fef3c7;background:#451a03;' : '',
                onclick: () => { picker.mode = 'similar'; picker.visibleLimit = 48; windowHandle.refresh(); },
              }, `비슷한 이미지 ${picker.similarEntries.length}`),
              h('button', {
                type: 'button', class: 'wml-btn', 'aria-pressed': picker.mode === 'all' ? 'true' : 'false',
                'data-similar-image-mode': 'all',
                style: picker.mode === 'all' ? 'border-color:#d97706;color:#fef3c7;background:#451a03;' : '',
                onclick: () => { picker.mode = 'all'; picker.visibleLimit = 80; windowHandle.refresh(); },
              }, `현재 인물 전체 이미지 ${picker.allEntries.length}`),
            ),
            h('div', { style: 'display:flex;gap:6px;margin-bottom:10px;' },
              h('input', {
                type: 'search', value: picker.pendingQuery, placeholder: '현재 인물 전체 이미지 키 또는 파일명 검색',
                'data-similar-image-search': '',
                style: 'min-width:0;flex:1;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
                oninput: event => { picker.pendingQuery = event.currentTarget.value; },
                onkeydown: event => {
                  if (event.key !== 'Enter') return;
                  event.preventDefault();
                  picker.query = picker.pendingQuery;
                  picker.visibleLimit = picker.mode === 'all' ? 80 : 48;
                  windowHandle.refresh();
                },
              }),
              h('button', {
                type: 'button', class: 'wml-btn', 'data-similar-image-search-submit': '',
                onclick: () => { picker.query = picker.pendingQuery; picker.visibleLimit = picker.mode === 'all' ? 80 : 48; windowHandle.refresh(); },
              }, '검색'),
              picker.query ? h('button', {
                type: 'button', class: 'wml-btn', 'data-similar-image-search-clear': '',
                onclick: () => { picker.query = ''; picker.pendingQuery = ''; picker.visibleLimit = picker.mode === 'all' ? 80 : 48; windowHandle.refresh(); },
              }, '검색 초기화') : null,
            ),
            picker.message ? h('p', { class: 'wml-muted wml-small' }, picker.message) : null,
            picker.loading
              ? h('p', { class: 'wml-muted wml-small' }, '이미지 목록을 불러오는 중입니다…')
              : visibleEntries.length
                ? h('div', { style: 'display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:10px;' },
                  ...visibleEntries.map(entry => {
                    const selected = selectedKeys.includes(entry.talentName);
                    const url = imageEntryUrl(entry);
                    return h('div', { style: 'border:2px solid #57534e;border-radius:8px;background:#1c1917;padding:7px;min-width:0;' },
                    h('button', {
                      type: 'button', title: entry.talentName,
                      'data-similar-image-choice': entry.talentName,
                      'aria-pressed': selected ? 'true' : 'false',
                      onclick: () => choose(entry),
                      style: `display:grid;gap:6px;width:100%;text-align:left;border:${selected ? '2px solid #f59e0b' : '0'};border-radius:6px;background:transparent;color:#e7e5e4;padding:0;cursor:pointer;`,
                    },
                    h('img', { src: url, alt: `${similarImageLabel(entry.talentName)} 미리보기`, loading: 'lazy', onerror: () => armSimilarImageRecovery(picker, windowHandle), style: 'width:100%;height:210px;object-fit:contain;border-radius:5px;background:#0c0a09;' }),
                    h('strong', { style: 'font-size:11px;overflow-wrap:anywhere;' }, selected ? `선택됨 · 클릭하면 해제 · ${similarImageLabel(entry.talentName)}` : similarImageLabel(entry.talentName)),
                    h('span', { class: 'wml-muted', style: 'font-size:10px;overflow-wrap:anywhere;' }, entry.talentName)),
                    h('button', { type: 'button', class: 'wml-btn', 'data-similar-image-preview': entry.talentName,
                      onclick: () => openSimilarImagePreview(entry, entry.talentName),
                    }, '크게 보기'));
                  }))
                : h('p', { class: 'wml-muted wml-small' }, picker.query ? '검색 결과가 없습니다.' : '표시할 이미지가 없습니다.'),
            matchedEntries.length > visibleEntries.length
              ? h('button', { type: 'button', class: 'wml-btn', 'data-similar-image-more': '',
                onclick: () => { picker.visibleLimit += 80; windowHandle.refresh(); },
              }, `더 보기 (${visibleEntries.length}/${matchedEntries.length})`)
              : null,
          ));
        },
      });
      if (win.__aipSimilarPickerActive) { win.focus?.(); return; }
      win.__aipSimilarPickerActive = true;
      win.refresh();
      if (picker.targetKey) {
        armSimilarImageRecovery(picker, win, true);
        void loadSimilarImages(picker, win);
      }
    }

    function portraitImageMissing(portrait) {
      if (portrait.querySelector('[data-sfw-placeholder], video')) return false;
      const texts = [...portrait.querySelectorAll('div')].map(node => (node.textContent || '').trim());
      if (texts.some(text => ['생성 중...', '업데이트 중...', '생성 중…', '업데이트 중…', 'Generating...', 'Updating...', 'Generating…', 'Updating…'].includes(text))) return false;
      if (portrait.querySelector('[data-attention-stale-accessory-image]')) return true;
      const image = portrait.querySelector('img');
      if (!image) return texts.some(text => ['이미지 없음', 'No image', 'No image available'].includes(text));
      if (!image.__attentionOfflineImageWatch) {
        image.__attentionOfflineImageWatch = true;
        image.addEventListener('load', scheduleUiScan);
        image.addEventListener('error', scheduleUiScan);
      }
      if (!image.complete) return false;
      if (image.naturalWidth === 0) return true;
      const source = String(image.currentSrc || image.src || '');
      if (!/^data:image\/svg\+xml(?:;charset=utf-8)?,/i.test(source) || source.length > 8192) return false;
      try {
        const svg = decodeURIComponent(source.slice(source.indexOf(',') + 1));
        return /<svg\b/i.test(svg) && /<text\b[^>]*>\s*이미지 없음\s*<\/text>/i.test(svg)
          && /viewBox=["']0 0 832 1216["']/i.test(svg);
      } catch { return false; }
    }

    function offlinePortraitVariantKey(portrait) {
      const fiberName = portrait && Object.keys(portrait).find(name => name.startsWith('__reactFiber'));
      for (let fiber = portrait?.[fiberName], depth = 0; fiber && depth < 5; fiber = fiber.return, depth += 1) {
        for (let hook = fiber.memoizedState, index = 0; hook && index < 80; hook = hook.next, index += 1) {
          const value = hook.memoizedState;
          if (Array.isArray(value?.variants) && Number.isInteger(value.currentIdx)) return value.variants[value.currentIdx] || '';
        }
      }
      return '';
    }

    function refreshOfflinePortrait(portrait, key, variant) {
      offlineImageRefreshView();
      if (!key || portrait.isConnected === false || activePortraitImageKey(latestScenePrompt?.result?.key || '') !== key
        || variant && offlinePortraitVariantKey(portrait) !== variant) return false;
      const host = portraitViewHost(portrait);
      const buttons = [...(host?.querySelectorAll?.('button') || [])];
      const portraitButton = buttons.find(button => button.title === '초상화 보기');
      const statusButton = buttons.find(button => button.title === '캐릭터 정보 카드 보기');
      if (!portraitButton || !statusButton) return false;
      statusButton.click();
      window.requestAnimationFrame(() => {
        if (host.isConnected !== false && statusButton.isConnected !== false && portraitButton.isConnected !== false
          && (!statusButton.classList || statusButton.classList.contains('bg-amber-900/40'))
          && activePortraitImageKey(latestScenePrompt?.result?.key || '') === key)
          portraitButton.click();
      });
      return true;
    }

    function decorateOfflinePortraitFolder(portrait) {
      let area = portrait.querySelector('[data-attention-offline-area]');
      if (!portraitImageMissing(portrait)) { area?.remove(); return; }
      if (area) return;
      area = document.createElement('div');
      area.setAttribute('data-attention-offline-area', '');
      area.setAttribute('data-wml-ui', '');
      area.style.cssText = 'position:absolute;left:8px;right:8px;bottom:10px;z-index:9;display:grid;justify-items:center;gap:4px;';
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'bg-black/80 hover:bg-amber-700/90 text-white rounded px-2 py-1 text-xs';
      button.setAttribute('data-attention-offline-connect', '');
      button.setAttribute('data-i18n-skip', '');
      const status = document.createElement('span');
      status.setAttribute('role', 'status');
      status.style.cssText = 'color:white;background:rgba(0,0,0,.8);font-size:11px;text-align:center;';
      const updateLabel = () => { button.textContent = offlineCache.getState().status === 'permission'
        ? '폴더 읽기 권한 허용' : '기존 이미지 폴더 연결'; };
      updateLabel();
      button.addEventListener('click', event => {
        event.preventDefault();
        event.stopPropagation();
        if (button.disabled) return;
        button.disabled = true;
        status.textContent = '';
        const permission = offlineCache.getState().status === 'permission';
        const key = activePortraitImageKey(latestScenePrompt?.result?.key || '');
        const variant = offlinePortraitVariantKey(portrait);
        const action = permission ? offlineCache.reconnect() : offlineCache.choose();
        void Promise.resolve(action).then(ok => {
          if (ok) {
            if (!refreshOfflinePortrait(portrait, key, variant)) status.textContent = '폴더를 연결했어요. 초상화를 다시 열어 주세요.';
          } else {
            const state = offlineCache.getState();
            status.textContent = permission && state.status === 'permission' ? '폴더 읽기 권한을 허용해 주세요.' : state.message || '';
          }
        }).catch(() => { status.textContent = '폴더를 읽지 못했어요. 다시 시도해 주세요.'; }).finally(() => {
          button.disabled = false;
          updateLabel();
          scheduleUiScan();
        });
      });
      area.append(button, status);
      portrait.appendChild(area);
    }

    const choicePromptEntryButtons = new Set();
    let choicePromptEntryEvent = null;
    let choicePromptScanAt = 0, choicePromptRetry = null;
    window.addEventListener('resize', () => scheduleUiScan());
    function decorateCurrentChoicePromptButton() {
      const state = api.store.game();
      const choices = state?.pendingEvent?.choices;
      const sameEvent = state?.pendingEvent === choicePromptEntryEvent;
      if (sameEvent && choicePromptEntryButtons.size
        && [...choicePromptEntryButtons].every(button => button.isConnected && button.getClientRects().length && button.__attentionChoiceGrid?.isConnected
          && button.__attentionChoiceCount === choices?.length)) return;
      if (sameEvent && !choicePromptEntryButtons.size && Array.isArray(choices) && choices.length) {
        const delay = 300 - (Date.now() - choicePromptScanAt);
        if (delay > 0) {
          if (!choicePromptRetry) choicePromptRetry = window.setTimeout(() => {
            choicePromptRetry = null;
            if (api.store.game()?.pendingEvent === choicePromptEntryEvent) decorateCurrentChoicePromptButton();
          }, delay);
          return;
        }
      }
      choicePromptEntryEvent = state?.pendingEvent;
      choicePromptScanAt = Date.now();
      const panes = Array.isArray(choices) && choices.length
        ? [...document.querySelectorAll('div.flex-1.min-h-0.overflow-y-auto')]
        : [];
      const active = new Set();
      for (const pane of panes) {
        if (!pane.getClientRects().length) continue;
        const nativeButtons = [...pane.querySelectorAll('button')].filter(node => !node.closest('[data-wml-ui]'));
        const matched = choices.flatMap(choice => {
          const label = String(choice?.label || choice?.text || '').trim();
          const node = nativeButtons.find(candidate => choice?.id && candidate.getAttribute('data-choice-id') === choice.id
            || label && candidate.textContent.includes(label));
          return node ? [node] : [];
        });
        if (!matched.length) continue;
        const grid = matched[0].closest('.grid') || matched[0].parentElement;
        if (!grid || grid === pane || !pane.contains(grid)) continue;
        let button = pane.querySelector('[data-attention-choice-prompt-entry]');
        if (!button) {
          button = document.createElement('button');
          button.type = 'button';
          button.textContent = '현재 선택지 프롬프트 추가하기';
          button.className = 'mt-2 px-2 py-1 text-xs bg-stone-700 hover:bg-stone-600 rounded text-stone-200';
          button.setAttribute('data-attention-choice-prompt-entry', '');
          button.setAttribute('data-wml-ui', '');
          button.setAttribute('data-i18n-skip', '');
          button.addEventListener('click', event => {
            event.preventDefault();
            event.stopPropagation();
            const current = api.store.game();
            const id = positionSituationId(activePortraitImageKey('', current)).split('|')[0];
            const available = buttonEventContext(current, id);
            buttonPromptSelection = available.length ? buttonPromptId(available[0]) : '';
            buttonOutcomeSelection = '';
            buttonOutcomeEvent = '';
            buttonOutcomeResponse = '';
            activeTagTarget = null;
            activeSettingsTab = 'button-prompts';
            openSettingsWindow();
          });
        }
        if (grid.nextElementSibling !== button) grid.after(button);
        button.__attentionChoiceGrid = grid;
        button.__attentionChoiceCount = choices.length;
        active.add(button);
      }
      for (const button of choicePromptEntryButtons) if (!active.has(button)) button.remove();
      choicePromptEntryButtons.clear();
      for (const button of active) choicePromptEntryButtons.add(button);
    }

    function decoratePortraitPositionButton() {
      decorateCurrentChoicePromptButton();
      const headings = [...document.querySelectorAll('span.text-stone-500.font-bold')].filter(node =>
        ['원본 자동 태그 (+)', 'Original auto tags (+)', 'Original automatic tags (+)'].includes((node.textContent || '').trim()));
      for (const heading of headings) {
        const overlay = heading.parentElement?.parentElement;
        if (!overlay) continue;
        if (overlay.querySelector('[data-attention-prompt-review]')) continue;
        const review = document.createElement('button');
        review.type = 'button';
        review.textContent = '최종 프롬프트 검수';
        review.className = 'mt-2 ml-2 px-2 py-1 text-xs bg-stone-700 hover:bg-stone-600 rounded text-stone-200';
        review.setAttribute('data-attention-prompt-review', '');
        review.setAttribute('data-wml-ui', '');
        review.setAttribute('data-i18n-skip', '');
        review.addEventListener('click', event => {
          event.preventDefault();
          event.stopPropagation();
          activeSettingsTab = 'prompt-mods';
          openSettingsWindow();
        });
        overlay.appendChild(review);
      }
      const portraits = document.querySelectorAll('div.relative.overflow-hidden.bg-stone-800.cursor-pointer');
      if (!portraits.length) return;
      const unused = unusedPortraitImages();
      const hasUnused = Object.keys(unused).length > 0;
      portraits.forEach(portrait => {
        if (imageStudioOwnsSelection()) {
          portrait.querySelectorAll('[data-attention-position-quick],[data-attention-similar-images],[data-attention-scene-prompt-entry],[data-attention-camera-entry]')
            .forEach(button => button.remove());
          syncNativePortraitPrompt(portrait);
          return;
        }
        decorateOfflinePortraitFolder(portrait);
        const promptKey = syncNativePortraitPrompt(portrait);
        if (promptKey && portrait.__attentionPromptSyncKey !== promptKey) {
          portrait.__attentionPromptSyncKey = promptKey;
          window.setTimeout(() => {
            if (portrait.isConnected !== false) syncNativePortraitPrompt(portrait);
          }, 150);
        }
        const key = hasUnused ? activePortraitImageKey(latestScenePrompt?.result?.key || '') : '';
        if (key && unused[similarImageSituationKey(key)]?.length) {
          syncNativePortraitVariants(portrait, key);
          if (portrait.__attentionUnusedSyncKey !== key) {
            portrait.__attentionUnusedSyncKey = key;
            window.setTimeout(() => {
              if (portrait.isConnected !== false) syncNativePortraitVariants(portrait, key);
            }, 150);
          }
        }
        guardUnusedPortraitVariantOnAdd(portrait);
        if (!portrait.querySelector('[data-attention-scene-prompt-entry]')) {
          const scene = document.createElement('button');
          scene.type = 'button';
          scene.textContent = '장면 프롬프트';
          scene.className = 'bg-black/60 hover:bg-amber-700/90 text-white/80 hover:text-white rounded px-2 py-1 text-[11px] transition-colors';
          scene.style.cssText = 'position:absolute;top:8px;left:178px;z-index:8;display:inline-block!important;';
          scene.title = '이 장면 프롬프트 변경';
          scene.setAttribute('data-attention-scene-prompt-entry', '');
          scene.setAttribute('data-wml-ui', '');
          scene.setAttribute('data-i18n-skip', '');
          scene.addEventListener('click', event => {
            event.preventDefault();
            event.stopPropagation();
            scenePromptEditorId = positionSituationId(activePortraitImageKey('', api.store.game()));
            activeTagTarget = null;
            activeSettingsTab = 'scene-prompts';
            openSettingsWindow();
            const open = [...(settingsWindowHandle?.el?.querySelectorAll('button') || [])]
              .find(button => button.textContent.trim() === '이 장면 프롬프트 변경');
            if (open && !open.disabled) open.click();
          });
          portrait.prepend(scene);
        }
        if (!portrait.querySelector('[data-attention-camera-entry]')) {
          const camera = document.createElement('button');
          camera.type = 'button';
          camera.textContent = '🎥';
          camera.className = 'bg-black/60 hover:bg-amber-700/90 text-white/80 hover:text-white rounded px-2 py-1 text-[11px] transition-colors';
          camera.style.cssText = 'position:absolute;top:8px;left:270px;z-index:8;display:inline-block!important;';
          camera.title = '카메라 구도';
          camera.setAttribute('aria-label', '카메라 구도');
          camera.setAttribute('data-attention-camera-entry', '');
          camera.setAttribute('data-wml-ui', '');
          camera.setAttribute('data-i18n-skip', '');
          camera.addEventListener('click', event => {
            event.preventDefault();
            event.stopPropagation();
            openCameraWindow();
          });
          portrait.prepend(camera);
        }
        if (!portrait.querySelector('[data-attention-position-quick]')) {
          const button = document.createElement('button');
          button.type = 'button';
          button.textContent = '체위 변경';
          button.className = 'bg-black/60 hover:bg-violet-700/90 text-white/80 hover:text-white rounded px-2 py-1 text-[11px] transition-colors';
          // ImageStudio hides this attribute with a stylesheet !important rule.
          button.style.cssText = 'position:absolute;top:8px;left:8px;z-index:8;display:inline-block!important;';
          button.title = '현재 상황의 체위 프리셋 변경';
          button.setAttribute('data-attention-position-quick', '');
          button.setAttribute('data-wml-ui', '');
          button.setAttribute('data-i18n-skip', '');
          button.addEventListener('click', event => {
            event.preventDefault();
            event.stopPropagation();
            openPositionQuickWindow();
          });
          portrait.prepend(button);
        }
        if (portrait.querySelector('[data-attention-similar-images]')) return;
        const similar = document.createElement('button');
        similar.type = 'button';
        similar.textContent = '비슷한 이미지';
        similar.className = 'bg-black/60 hover:bg-amber-700/90 text-white/80 hover:text-white rounded px-2 py-1 text-[11px] transition-colors';
        similar.style.cssText = 'position:absolute;top:8px;left:78px;z-index:8;';
        similar.title = '현재와 비슷한 상황의 기존 이미지 선택';
        similar.setAttribute('data-attention-similar-images', '');
        similar.setAttribute('data-wml-ui', '');
        similar.setAttribute('data-i18n-skip', '');
        similar.addEventListener('click', event => {
          event.preventDefault();
          event.stopPropagation();
          openSimilarImagePicker(portrait);
        });
        portrait.prepend(similar);
      });
    }
