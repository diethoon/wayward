const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, 'source/first-experience-creation.js'), 'utf8');
function fixture({ status = false, random = 0 } = {}) {
  const panel = {}, listeners = {}, hooks = {};
  const document = {
    addEventListener(type, listener) { listeners[type] = listener; },
    querySelector(selector) { return selector === '[data-virginity-creation]' ? panel : null; },
  };
  const math = Object.create(Math);
  math.random = () => random;
  const api = { hook(name, spec) { hooks[name] = spec; } };
  const context = { api, document, Math: math, WML: { status: () => ({ loaded: status ? ['virginity-status'] : [] }) } };
  vm.runInNewContext(source, context, { filename: 'first-experience-creation.js' });
  const run = (setting, character = {}, extraOptions = {}) => {
    const archetype = setting === undefined ? {} : { __attentionFirstExperience: setting };
    const options = { generatedArchetype: archetype, picks: {}, ...extraOptions };
    const args = hooks.newGameState.before([options]) || [options];
    const state = { day: 1, primaryCharacterId: 'wife', characters: { wife: character }, mods: {} };
    const result = hooks.newGameState.after(state, args);
    return { options: args[0], state, result };
  };
  const editPanel = () => {
    const target = { closest(selector) { return selector === 'button,input,select,textarea' ? this : selector === '[data-virginity-creation]' ? panel : null; } };
    listeners.input({ target });
  };
  return { run, editPanel };
}
const plain = value => JSON.parse(JSON.stringify(value));

for (const status of [false, true]) {
  const { run } = fixture({ status });
  const untouched = run(undefined);
  assert.equal(untouched.result, untouched.state, 'older characters keep original behavior');
  assert.equal(untouched.options.__attentionFirstExperienceResolved, undefined);
  for (const [mode, name] of [['none', ''], ['player', ''], ['other', '도윤']]) {
    const { options, state, result } = run({ mode, partnerName: name });
    assert.equal(options.__attentionFirstExperienceResolved.mode, mode);
    if (status) {
      assert.equal(result, state, 'the owning mod writes its own record');
      assert.deepEqual(plain(options.picks.__virginityStatus), {
        virgin: mode === 'none', firstNightWithPlayer: mode === 'player',
        formerBoyfriendExperience: mode === 'other', formerBoyfriendName: name,
        experienceLevel: mode === 'none' ? 0 : 20,
      });
    } else {
      const wife = result.characters.wife;
      assert.equal(wife.virginity.virgin, mode === 'none');
      assert.equal(wife.virginity.firstNightWithPlayer, mode === 'player');
      assert.equal(wife.virginity.firstPartnerName, mode === 'none' ? null : mode === 'player' ? '당신' : name);
      assert.equal(wife.intimateHistory.length, mode === 'none' ? 0 : 1);
      if (mode !== 'none') {
        assert.equal(wife.intimateHistory[0].actId, 'sex');
        assert.equal(wife.intimateHistory[0].partnerType, mode === 'player' ? 'player' : 'patron');
      }
    }
  }
  const unknown = run({ mode: 'other', partnerName: '  ' });
  assert.equal(unknown.options.__attentionFirstExperienceResolved.partnerName, '이름 미상');
}

for (const status of [false, true]) for (const [random, expected] of [[0, 'none'], [0.4, 'player'], [0.9, 'other']]) {
  const result = fixture({ random, status }).run({ mode: 'random' });
  assert.equal(result.options.__attentionFirstExperienceResolved.mode, expected);
  if (expected === 'other') assert.equal(result.options.__attentionFirstExperienceResolved.partnerName, '이름 미상');
  if (status) assert.equal(result.options.picks.__virginityStatus.virgin, expected === 'none');
}

const withExisting = fixture().run({ mode: 'none' }, { intimateHistory: [{ actId: 'sex', partner: '다른 사람' }] });
assert.equal(withExisting.result, withExisting.state, 'existing history must not be overwritten');
const withTally = fixture().run({ mode: 'player' }, { intimateTally: { partners: {}, acts: {} } });
assert.equal(withTally.result, withTally.state, 'existing tally must not be overwritten');
const edited = fixture({ status: true });
edited.editPanel();
const afterEdit = edited.run({ mode: 'none' }, {}, { picks: { __virginityStatus: { experienceLevel: 43 } } });
assert.equal(afterEdit.result, afterEdit.state);
assert.equal(afterEdit.options.picks.__virginityStatus.experienceLevel, 43, 'manual status-panel edit takes precedence');
assert.equal(afterEdit.options.__attentionFirstExperienceResolved, undefined);
const preview = fixture().run({ mode: 'player' }, {}, { picks: undefined });
assert.equal(preview.result, preview.state, 'preview construction is not game creation');

console.log('first experience creation: ok');
