'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

// Reuse the camera test's isolated WML environment while exercising real presets.
const fixture = fs.readFileSync(path.join(__dirname, 'camera-core-test.cjs'), 'utf8');
const boundary = fixture.indexOf('\n(async () => {');
assert.ok(boundary > 0, 'camera test environment is available');
const { context, camera, generate } = new Function('require', '__dirname',
  `${fixture.slice(0, boundary)}\nreturn { context, camera, generate };`)(require, __dirname);
const presets = vm.runInNewContext(fs.readFileSync(path.join(__dirname, 'source/camera-presets.js'), 'utf8')
  + '\n({ groups: CAMERA_PRESET_GROUPS, remove: CAMERA_REMOVE_DEFAULTS, negative: CAMERA_NEGATIVE_DEFAULTS })');
context.CAMERA_PRESET_GROUPS = presets.groups;
context.CAMERA_REMOVE_DEFAULTS = presets.remove;

(async () => {
  const items = presets.groups.flatMap(group => Array.from(group.items));
  assert.equal(items.length, 27, 'check every built-in camera angle');
  const negativeTerms = presets.negative.split(', ').map(term => term.toLowerCase());
  for (const term of ['camera body', 'camera lens in frame', 'camera held in hands', 'dslr camera', 'video camera',
    'camcorder', 'tripod', 'photography equipment', 'camera screen overlay', 'shutter button', 'on-screen camera interface'])
    assert.ok(negativeTerms.includes(term), `equipment protection includes ${term}`);
  for (const broad of ['camera', 'photographer', 'cameraman', 'person', 'hands', 'lens'])
    assert.ok(!negativeTerms.includes(broad), `do not exclude unrelated ${broad}`);

  for (const item of items) {
    const selection = { shots: [item], selected: [item.id], removeTags: '' };
    assert.equal(camera.apply('scene-hug', selection).ok, true, item.id);
    const preview = camera.preview('scene-hug', '1girl, hand on another\'s hips', 'custom negative');
    assert.match(preview.prompt, /hand on another's hips/, `${item.id} preserves physical action`);
    for (const term of negativeTerms) assert.ok(preview.negativePrompt.toLowerCase().includes(term), `${item.id}: ${term}`);
    assert.match(preview.negativePrompt, /custom negative/, `${item.id} preserves user negative`);
    await generate(async request => {
      assert.equal(request.negativePrompt, preview.negativePrompt, `${item.id} generation matches preview`);
      return { imageMatchingMissing: true };
    }, { imageKey: 'wife__scene-hug__v-0', prompt: '1girl, hand on another\'s hips', negativePrompt: 'custom negative', debug: { stats: {} } });
  }
  camera.apply('scene-hug', { shots: [], selected: [], removeTags: '' });
  assert.equal(camera.preview('scene-hug', '1girl', 'custom negative').negativePrompt, 'custom negative', 'disabled camera does not add equipment negatives');
  console.log(`camera equipment negatives: ${items.length} angles ok`);
})().catch(error => { console.error(error); process.exitCode = 1; });
