const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const source = fs.readFileSync(require('node:path').join(__dirname, 'source/settings-data.js'), 'utf8');
const match = source.match(/function saveShortImageKeys\(enabled\) \{[\s\S]*?\n    \}/);
assert.ok(match, 'setting save helper exists');
let saved = { unrelated: 'preserved' }, mode = 'normal';
const api = { settings: {
  get(defaults) { if (mode === 'read-throws') throw Error('blocked'); return { ...defaults, ...saved }; },
  set(value) { if (mode === 'write-throws') throw Error('blocked'); if (mode !== 'silent-failure') saved = { ...saved, ...value }; },
} };
const save = vm.runInNewContext(`(${match[0]})`, { api });
assert.equal(save(true), true);
assert.equal(saved.shortImageKeys, true);
assert.equal(saved.unrelated, 'preserved');
mode = 'silent-failure';
assert.equal(save(false), false);
assert.equal(saved.shortImageKeys, true);
mode = 'normal';
assert.equal(save(false), true);
assert.equal(saved.shortImageKeys, false);
mode = 'write-throws';
assert.equal(save(true), false);
mode = 'read-throws';
assert.equal(save(true), false);
assert.equal(save('true'), false);

// Restart with the same serialized WML settings: an already chosen value must
// bypass the first-start offer in either direction, without overwriting it.
const mod = fs.readFileSync(require('node:path').join(__dirname, 'source/mod.wml.js'), 'utf8');
const offerMatch = mod.match(/const offerShortImageKeys = \(\) => \{[\s\S]*?\n    \};\n    window\.setTimeout/);
assert.ok(offerMatch, 'first-start implementation exists');
const offerSource = offerMatch[0].replace(/\n    window\.setTimeout$/, '') + '\nofferShortImageKeys();';
for (const value of [true, false]) {
  let persisted = JSON.stringify({ shortImageKeys: value, unrelated: 4 });
  let windows = 0, next = 0;
  const bootApi = { settings: {
    get(defaults) { return { ...defaults, ...JSON.parse(persisted) }; },
    set(value) { persisted = JSON.stringify({ ...JSON.parse(persisted), ...value }); },
  }, ui: { window() { windows++; } } };
  vm.runInNewContext(offerSource, { api: bootApi, offerImagePromptPlus() { next++; } });
  assert.equal(windows, 0, 'saved preference must not prompt again after restart');
  assert.equal(next, 1);
  assert.deepEqual(JSON.parse(persisted), { shortImageKeys: value, unrelated: 4 });
}
{
  let options, children, closed = false, next = 0;
  const uiApi = { settings: { get(defaults) { return { ...defaults }; }, set() {} }, ui: {
    h(tag, props, ...content) { return { tag, props, children: content }; },
    button(label, onclick) { return { tag: 'button', label, onclick }; },
    window(value) { options = value; },
  } };
  const helper = vm.runInNewContext(`(${match[0]})`, { api: uiApi });
  vm.runInNewContext(offerSource, { api: uiApi, saveShortImageKeys: helper, offerImagePromptPlus() { next++; } });
  const body = { replaceChildren(...content) { children = content; } };
  const win = { close() { closed = true; }, refresh() { options.render(body, win); } };
  options.render(body, win);
  const nodes = value => value && typeof value === 'object' ? [value, ...(value.children || []).flatMap(nodes)] : [];
  nodes(children[0]).find(node => node.label === '축약 켜기').onclick();
  assert.equal(closed, false, 'failed initial setting must keep the dialog open');
  assert.equal(next, 0);
  assert.ok(nodes(children[0]).some(node => node.props?.role === 'alert'), 'failed write must be visible');
}
console.log('short-image-keys-test passed');
