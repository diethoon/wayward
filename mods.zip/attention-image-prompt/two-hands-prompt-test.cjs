const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const crypto = require('node:crypto');

const source = fs.readFileSync(`${__dirname}/source/image-cache-and-keys.js`, 'utf8');
const start = source.indexOf('    function positionBothHandPrompts(');
const end = source.indexOf('    function rememberLatestScenePrompt(', start);
assert.ok(start >= 0 && end > start);
const tokens = value => String(value || '').split(',').map(x => x.trim()).filter(Boolean);
let multiplePatrons = false;
const context = {
  controllerButtonDefaultTags: ({ label }) => label === '가슴' ? 'hetero, groping' : 'hetero, grabbing',
  multiplePatronActions: situationId => multiplePatrons || /grp-[1-9]/.test(String(situationId || '')),
  stripPositionKey: key => key.split('__').filter(part => !part.startsWith('position-')).join('__'),
  positionSituationId: () => 'scene-sex', basePositionSituationId: id => id,
  positionGroupCount: () => 0, currentPositionStatePrompt: () => null, positionStateOnly: () => false,
  effectivePositionDetails: () => null, POSITION_PRESETS: {}, GROUP_SLOT_BY_ID: {},
  positionPlacementPrompt: () => '', positionFemaleDetailPrompt: () => '', positionPrimaryManPrompt: () => '',
  effectivePositionPresetPrompt: () => null, effectivePositionGroupPrompt: () => ({ positivePrompt: '', negativePrompt: '' }),
  shortHash: value => crypto.createHash('sha256').update(value).digest('hex').slice(0, 8),
  externalSignatureFromImageKey: () => '', positionGroupSlots: () => '',
  COUPLE_POSITION_NEGATIVES: {}, POSITION_PART_LABELS: new Set(), MODULE_NATIVE_POSE_TAGS: new Set(),
  api: { store: { game: () => ({ primaryCharacterId: 'pippa' }) } },
  MALE_ACTIONS: { handjob: 'handjob', roughFellatio: 'rough fellatio' },
  FEMALE_POSES: { back: 'back' }, restraintVisible: () => false,
  promptTokens: tokens, promptTagIdentity: tag => ({ spaced: tag.toLowerCase() }),
  withoutPromptTags: (value, removed) => tokens(value).filter(tag => !tokens(removed).includes(tag)).join(', '),
  joinPrompt: value => tokens(value).join(', '), deduplicatePrompt: value => [...new Set(tokens(value))].join(', '),
  positionModuleDirection: () => '배우자', positionPlacementLabel: () => '', promptGenParams: () => ({}),
};
vm.createContext(context);
vm.runInContext(`${source.slice(start, end)}\nthis.testBoth = positionBothHandPrompts; this.testKey = keyWithPosition; this.testApply = applyPositionPreset;`, context);
const hand = (group, label = '가슴', scope = 'you', prompt = 'hetero, groping') => ({
  controller: true, controllerScope: scope, controllerGroup: group, controllerLabel: label,
  kind: 'other', id: `${scope}-${group}-${label}`, name: `${group} ${label}`, positivePrompt: prompt, negativePrompt: '',
});
const left = hand('왼손');
const right = hand('오른손');
const sourceKey = 'pippa__scene-sex__v-0';
const choice = { moduleSignature: 'selected-hands', modules: [left, right] };
const result = { key: sourceKey, prompt: '1girl, best quality', negativePrompt: '', parts: [
  { label: '기본', tags: '1girl' }, { label: '품질', tags: 'best quality' },
] };
const output = context.testApply(result, choice, 'pippa');
assert.match(output.prompt, /both of her partner's hands on her breasts/);
assert.equal(tokens(output.prompt).filter(tag => tag === 'groping').length, 1, 'unrelated prompt dedup remains enabled');
assert.ok(output.parts.some(part => part.label === '체위 모듈 · 양손 동작'));
const oldSignature = 'modules|selected-hands||';
const oldKey = `pippa__scene-sex__position-modules-${context.shortHash(oldSignature)}__v-0`;
assert.notEqual(output.key, oldKey, 'both-hand composition must get a fresh cache key');
assert.match(output.key, /__v-0$/);
assert.equal(context.testKey(sourceKey, { ...choice, stateKey: sourceKey, imageKey: oldKey, generatedKeys: [oldKey] }), output.key,
  'an automatic stale generated override must not hide the new two-hand key');
assert.equal(context.testKey(sourceKey, { ...choice, sourceKey, stateKey: sourceKey, imageKey: oldKey, generatedKeys: [oldKey], manual: true }), oldKey,
  'an explicitly selected generated image must remain selected');
assert.equal(context.testKey(sourceKey, { ...choice, pendingPreviousKey: oldKey, imageKey: oldKey }), oldKey,
  'an in-progress explicitly selected previous image must remain visible');
context.externalSignatureFromImageKey = key => key === oldKey ? 'old-external' : 'new-external';
assert.equal(context.testKey(sourceKey, { ...choice, stateKey: sourceKey, pendingPreviousKey: oldKey, imageKey: oldKey }), oldKey,
  'pending selection must retain the previous state-key behavior when external tags differ');
context.externalSignatureFromImageKey = () => '';
const conflictingChoice = { moduleSignature: 'new-conflict', modules: [left], conflictingNativeAct: 'vaginal' };
const expectedConflicting = context.testKey(sourceKey, conflictingChoice);
assert.equal(context.testKey(sourceKey, { ...conflictingChoice, stateKey: sourceKey, imageKey: oldKey, generatedKeys: [oldKey] }), expectedConflicting,
  'a conflicting old automatic override must use its corrected key');
assert.equal(context.testKey(sourceKey, { ...conflictingChoice, stateKey: sourceKey, imageKey: oldKey, manual: true }), oldKey,
  'manual selection remains an explicit choice even after an act conflict');
const oneHand = context.testApply(result, { moduleSignature: 'selected-hands', modules: [left] }, 'pippa');
assert.equal(oneHand.key, oldKey, 'unrelated one-hand cache keys remain unchanged');
assert.doesNotMatch(oneHand.prompt, /both of/);
assert.equal(context.testBoth([left, hand('오른손', '손목')]).length, 0, 'different targets must not be combined');
assert.equal(context.testBoth([left, hand('오른손', '가슴', 'patron')]).length, 0, 'different actors must not be combined');
const patron = [hand('왼손', '가슴', 'patron'), hand('오른손', '가슴', 'patron')];
const bothActors = context.testBoth([left, right, ...patron]);
assert.equal(bothActors.length, 2, 'each actor needs their own two-hand expression');
assert.match(bothActors[1], /both of the customer's hands on her breasts/);
assert.equal(context.testKey(sourceKey, choice), context.testKey(sourceKey, { ...choice, modules: [right, left] }),
  'the same chosen hand modules must not change keys when their input order changes');
const custom = context.testApply(result, { moduleSignature: 'custom', modules: [
  { ...left, positivePrompt: 'custom hand pose' }, right,
] }, 'pippa');
assert.match(custom.prompt, /custom hand pose/);
assert.doesNotMatch(custom.prompt, /both of/, 'custom hand wording must not trigger an inferred target');
assert.equal(custom.key, `pippa__scene-sex__position-modules-${context.shortHash('modules|custom||')}__v-0`,
  'custom hand wording must not acquire a speculative key signature');
assert.equal(context.testBoth([{ ...left, id: 'another-left' }, left, right], 'scene-sex').length, 0,
  'two possible left hands make attribution ambiguous');
assert.equal(context.testBoth([left, right, { ...right, id: 'another-right' }], 'scene-sex').length, 0,
  'two possible right hands make attribution ambiguous');
assert.equal(context.testBoth(patron, 'scene-patron_sex|grp-2').length, 0,
  'group scenes must not assign two unknown hands to a single patron');
multiplePatrons = true;
assert.equal(context.testBoth(patron, 'scene-patron_sex').length, 0,
  'joined or crowd patrons must not receive a speculative two-hand prompt');
assert.equal(context.testBoth([left, right], 'scene-sex').length, 1,
  'known player hands still work when other patrons are present');
multiplePatrons = false;
console.log('two-hand prompt and key: ok');
