const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, 'source/image-state.js'), 'utf8');
const section = source.slice(source.indexOf('    const imageRequestTraceSymbol'), source.indexOf('    const imageRequestObserverKey'));
let now = 1000;
const api = { sym: () => 'LPe' };
const { prepare, beginImageRequestTrace: begin, imageRequestComparison: compare, pendingImageRequestTraces: pending } =
  new Function('api', 'Date', `${section}\nreturn { pendingImageRequestTraces, beginImageRequestTrace, imageRequestComparison,
    prepare: request => ({ ...request, [imageRequestTraceSymbol]: { baseline: imageRequestSnapshot(request), aipBefore: imageRequestSnapshot(request) } }) };`)(api, { now: () => now });

const original = { imageKey: 'same', prompt: 'before', negativePrompt: '', debug: { custom: 'kept' } };
const stack = 'Error\n    at observedFetch (aip.js:1:1)\n    at LPe (game.js:1:1)';
const request = prepare(original);
assert.deepEqual(JSON.parse(JSON.stringify(request)), original, 'the trace symbol must not affect the serialized request');
const release = begin({ ...request, prompt: 'after' });
assert.equal(compare('different', stack), null);
assert.equal(compare('same', 'Error\n    at observedFetch (aip.js:1:1)\n    at directFetch (game.js:1:1)'), null, 'direct fetch must not be matched');
assert.equal(compare('same', 'Error\n    at observedFetch (aip.js:1:1)\n    at unrelatedLPe (game.js:1:1)'), null, 'partial stack names must not be matched');
assert.equal(compare('same', 'Error\n    at observedFetch (aip.js:1:1)\n    at otherWrapper (mod.js:1:1)\n    at LPe (game.js:1:1)'), null,
  'a direct fetch inside another wrapper must not be mistaken for the game request');
const result = compare('same', stack);
assert.equal(result.confidence, 'key-match');
assert.equal(result.baseline.prompt, 'before');
assert.equal(result.aipAfter.prompt, 'after');
assert.equal(compare('same', stack), null, 'one candidate cannot be reused for another fetch');
release();
assert.equal(pending.size, 0);
api.sym = () => '$Q';
const dollar = begin(prepare(original));
assert.equal(compare('same', 'Error\n    at observedFetch (aip.js:1:1)\n    at $Q (game.js:1:1)')?.confidence,
  'key-match', 'minified function names containing $ must be escaped');
dollar();
api.sym = () => 'LPe';

const first = begin(prepare(original));
const untracked = begin(original);
assert.equal(compare('same', stack), null,
  'an untracked in-flight request must not be matched to a tracked one');
untracked();
const second = begin(prepare({ ...original, prompt: 'other' }));
assert.equal(compare('same', stack), null, 'simultaneous same-key requests are ambiguous');
first(); second();

const oldRelease = begin(prepare(original));
now += 300001;
const replacement = begin(prepare(original));
assert.equal(compare('same', stack), null,
  'an expired but still-running request must not be confused with a replacement');
oldRelease();
assert.equal(pending.get('same').size, 1, 'an expired request must not remove a replacement set');
replacement();
const releases = Array.from({ length: 65 }, (_, index) => begin(prepare({ ...original, imageKey: String(index) })));
assert.equal(pending.size, 64, 'pending trace storage must remain bounded');
assert.equal(compare('0', stack), null,
  'a capacity-excluded request makes active comparisons ambiguous');
releases.forEach(end => end());
assert.equal(pending.size, 0);
console.log('image request trace: ok');
