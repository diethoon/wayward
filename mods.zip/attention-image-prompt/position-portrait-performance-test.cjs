const assert = require('node:assert/strict');
const fs = require('node:fs');

const foundations = fs.readFileSync(`${__dirname}/source/prompt-foundations.js`, 'utf8');
const start = foundations.indexOf('    let firstExperienceVirginityLoaded;');
const end = foundations.indexOf('    function firstExperiencePromptState(', start);
assert.ok(start >= 0 && end > start);
const createSceneCheck = () => new Function(`${foundations.slice(start, end)}\nreturn firstExperienceScene;`)();
const state = { primaryCharacterId: 'pippa', day: 1, characters: { pippa: { sceneOverride: 'sex' } },
  activeScene: { sex: {} }, mods: { 'virginity-status': { prompt: { schema: 1, characterId: 'pippa', scene: 'sex', pending: true } } } };
const key = 'pippa__scene-sex__v-0';
const originalWML = globalThis.WML;
let status = { booted: false, loaded: [] }, calls = 0;
globalThis.WML = { status() { calls++; return status; } };
let scene = createSceneCheck();
assert.equal(scene(state, 'pippa', key), true);
status = { booted: false, loaded: ['virginity-status'] };
state.mods['virginity-status'].prompt.pending = false;
assert.equal(scene(state, 'pippa', key), false, 'booting must recheck a newly loaded mod');
status = { booted: true, loaded: ['virginity-status'] };
assert.equal(scene(state, 'pippa', key), false);
const bootedCalls = calls;
for (let i = 0; i < 1000; i++) assert.equal(scene(state, 'pippa', key), false);
assert.equal(calls, bootedCalls, 'completed loader status is read only once');
scene = createSceneCheck();
status = { loaded: [] };
assert.equal(scene(state, 'pippa', key), true);
status = { loaded: ['virginity-status'] };
assert.equal(scene(state, 'pippa', key), false, 'older loaders without a boot flag are not cached');
globalThis.WML = originalWML;

const browser = fs.readFileSync(`${__dirname}/source/image-browser.js`, 'utf8');
const decorateStart = browser.indexOf('    function decoratePortraitPositionButton()');
assert.ok(decorateStart >= 0);
let unused = {}, keyReads = 0, variantSyncs = 0;
const portrait = { querySelector: () => ({}), isConnected: true };
const document = { querySelectorAll(selector) { return selector.startsWith('span.') ? [] : [portrait]; } };
const names = ['document', 'decorateCurrentChoicePromptButton', 'decorateOfflinePortraitFolder', 'activePortraitImageKey', 'latestScenePrompt',
  'syncNativePortraitPrompt', 'window', 'unusedPortraitImages', 'similarImageSituationKey',
  'syncNativePortraitVariants', 'guardUnusedPortraitVariantOnAdd'];
const decorate = new Function(...names, `${browser.slice(decorateStart)}\nreturn decoratePortraitPositionButton;`)(
  document, () => {}, () => {}, () => { keyReads++; return key; }, null, () => '', { setTimeout() {} },
  () => unused, () => 'situation', () => { variantSyncs++; }, () => {});
for (let i = 0; i < 1000; i++) decorate();
assert.equal(keyReads, 0, 'no unused images means no expensive current-image-key read');
unused = { situation: ['old'] };
decorate();
assert.equal(keyReads, 1);
assert.equal(variantSyncs, 1, 'unused variants are still synchronized');
console.log('position portrait performance: ok');
