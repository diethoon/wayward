const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, 'source/diagnostics-and-image-pack.js'), 'utf8');
const begin = source.indexOf('    function splitPromptReviewTags(');
const end = source.indexOf('    function renderServerPromptChanges(', begin);
assert.ok(begin >= 0 && end > begin, '프롬프트 비교 함수를 찾지 못했습니다.');
const context = {};
vm.runInNewContext(source.slice(begin, end), context);
const { splitPromptReviewTags, diffPromptReviewTags } = context;
const equal = (actual, expected) => assert.equal(JSON.stringify(actual), JSON.stringify(expected));

equal(splitPromptReviewTags('plain, (weight, nested), [one, two], {x,y}, escaped\\,comma'),
  ['plain', '(weight, nested)', '[one, two]', '{x,y}', 'escaped\\,comma']);
equal(diffPromptReviewTags('alpha, beta, alpha', 'beta, alpha, alpha'), { added: [], removed: [] });
equal(diffPromptReviewTags('alpha, alpha, beta', 'alpha, beta, beta, beta'), {
  added: [{ tag: 'beta', count: 2 }], removed: [{ tag: 'alpha', count: 1 }],
});
equal(diffPromptReviewTags('', 'a, b'), { added: [{ tag: 'a', count: 1 }, { tag: 'b', count: 1 }], removed: [] });
equal(diffPromptReviewTags('a, b', ''), { added: [], removed: [{ tag: 'a', count: 1 }, { tag: 'b', count: 1 }] });
equal(diffPromptReviewTags('(a,b), x\\,y, [c,d]', '[c,d], x\\,y, (a,b)'), { added: [], removed: [] });
assert.equal(splitPromptReviewTags('(unterminated'), null);
assert.equal(splitPromptReviewTags('mismatched [tag)'), null);
assert.equal(splitPromptReviewTags('trailing\\'), null);
assert.equal(diffPromptReviewTags(undefined, 'tag'), null);
console.log('prompt-review-diff: ok');
