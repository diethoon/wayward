const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const source = fs.readFileSync(require('node:path').join(__dirname, 'source/image-cache-and-keys.js'), 'utf8');
const start = source.indexOf('    function keyWithPosition(');
const end = source.indexOf('    function applyPositionPreset(', start);
assert(start >= 0 && end > start);
const sceneStart = source.indexOf('    function situationImageKey(');
const sceneEnd = source.indexOf('    function keyWithState(', sceneStart);
assert(sceneStart >= 0 && sceneEnd > sceneStart);
const applyEnd = source.indexOf('    function rememberLatestScenePrompt(', end);
assert(applyEnd > end);
let prompt = null;
let buttonGroups = { positive: [], negative: [] };
let baseSignature = '', scopedStateSignature = '', globalStateSignature = '';
let exclusionSignature = '';
let cameraSignature = '';
const context = {
  globalPromptExclusionsFingerprint: () => exclusionSignature,
  cameraSettingsFingerprint: () => cameraSignature,
  compactSituationAliases: new Map(),
  stripPositionKey: key => key.replace(/__position-[^_]+/, ''),
  baseSituationImageKey: key => key.split('__').filter(part => !/^(aip-|position-)/.test(part)).join('__'),
  positionSituationId: key => key.split('__').find(part => /^(?:scene|task|look)-/.test(part)) || '',
  positionGroupCount: () => 0,
  currentPositionStatePrompt: () => prompt,
  sceneBaseOverrideFingerprint: () => baseSignature,
  sceneStatePromptFingerprint: () => scopedStateSignature,
  promptModRulesFingerprint: () => '',
  stateEditorGlobalProbePrompts: () => null,
  stateEditorGlobalFingerprint: () => globalStateSignature,
  buttonPromptGroups: () => buttonGroups,
  positionStateOnly: value => Boolean(value?.onlyState && (value.positivePrompt || value.negativePrompt)),
  effectivePositionDetails: () => null,
  externalSignatureFromImageKey: () => '',
  POSITION_PRESETS: {}, GROUP_SLOT_BY_ID: {},
  positionPlacementPrompt: () => '', positionFemaleDetailPrompt: () => '', positionPrimaryManPrompt: () => '',
  effectivePositionPresetPrompt: () => null, effectivePositionGroupPrompt: () => ({ negativePrompt: '' }),
  positionBothHandPrompts: () => [],
  shortHash: value => require('node:crypto').createHash('sha256').update(value).digest('hex').slice(0, 12),
  situationCode: value => value, customOutfitSituationCode: () => '',
  situationConfigForCharacter: () => null, externalFieldCacheSignature: () => '',
  outfitIdFor: () => '', outfitById: () => null, currentOutfitPrompts: () => ({}),
  analFinishSceneKey: () => false, singleAnalAnatomyScene: () => false,
  hasSevereNegativeFeeling: () => false, hasDistressedExpression: () => false,
  promptContext: () => ({ positiveGroups: [] }), compactSituationKey: key => key,
  similarImageSituationKey: key => key, accessorySituationCode: () => '',
  basePositionSituationId: value => value, positionGroupSlots: () => '',
  restraintVisible: () => false,
  api: { store: { game: () => ({ primaryCharacterId: 'wife' }) } },
  MALE_ACTIONS: {}, FEMALE_POSES: {}, COUPLE_POSITION_NEGATIVES: {}, POSITION_PART_LABELS: new Set(),
  promptTokens: value => String(value || '').split(',').map(tag => tag.trim()).filter(Boolean),
  promptTagIdentity: value => ({ spaced: value }), withoutPromptTags: value => value,
  joinPrompt: value => String(value || '').split(',').map(tag => tag.trim()).filter(Boolean).join(', '),
  deduplicatePrompt: value => value, promptGenParams: () => ({}),
};
vm.createContext(context);
vm.runInContext(`${source.slice(start, applyEnd)}\n${source.slice(sceneStart, sceneEnd)}\nthis.keyWithPosition = keyWithPosition; this.situationImageKey = situationImageKey; this.applyPositionPreset = applyPositionPreset;`, context);
const state = { activeScene: {}, primaryCharacterId: 'another' };
const character = {};
const sceneKey = (key, choice = null) => context.situationImageKey(key, state, character, 'wife', choice);

const originalKey = sceneKey('wife__task-idle__v-0');
exclusionSignature = 'excluded';
const excludedKey = sceneKey('wife__task-idle__v-0');
assert.notEqual(excludedKey, originalKey, 'global exclusions change the image key');
const previousChoice = { imageKey: originalKey, generatedKeys: [originalKey] };
assert.notEqual(sceneKey('wife__task-idle__v-0', previousChoice), originalKey,
  'an old automatically generated key cannot bypass active exclusions');
exclusionSignature = '';
assert.equal(sceneKey('wife__task-idle__v-0'), originalKey, 'clearing exclusions restores the previous key');
const oldCompact = 'wife__task-idle__aipk-old__v-0';
const oldCompactChoice = { imageKey: oldCompact, generatedKeys: [oldCompact], pendingPreviousKey: 'previous' };
assert.equal(sceneKey('wife__task-idle__v-0', oldCompactChoice), oldCompact,
  'pre-existing compressed position choices remain valid with exclusions off');
cameraSignature = 'cameraon';
assert.notEqual(sceneKey('wife__task-idle__v-0', oldCompactChoice), oldCompact,
  'old position keys cannot bypass an active camera configuration');
const cameraChoice = { imageKey: 'wife__task-idle__aipk-camera__v-0',
  generatedKeys: ['wife__task-idle__aipk-camera__v-0'], cameraSignature: 'cameraon' };
assert.equal(sceneKey('wife__task-idle__v-0', cameraChoice), cameraChoice.imageKey,
  'matching saved camera keys survive lost compressed aliases');
cameraSignature = '';
assert.notEqual(sceneKey('wife__task-idle__v-0', cameraChoice), cameraChoice.imageKey,
  'disabling the camera does not reuse an image generated with the camera');
exclusionSignature = 'excluded';
assert.notEqual(sceneKey('wife__task-idle__v-0', oldCompactChoice), oldCompact,
  'pending previous key cannot bypass active exclusions');
const filteredChoice = { imageKey: 'wife__task-idle__aipk-filtered__v-0',
  generatedKeys: ['wife__task-idle__aipk-filtered__v-0'], globalExclusionSignature: 'excluded' };
exclusionSignature = '';
assert.notEqual(sceneKey('wife__task-idle__v-0', filteredChoice), filteredChoice.imageKey,
  'turning exclusions off cannot reuse a compressed image saved with exclusions');
exclusionSignature = 'excluded';
assert.equal(sceneKey('wife__task-idle__v-0', filteredChoice), filteredChoice.imageKey,
  'a matching exclusion signature retains a compressed generated choice after alias loss on reload');
exclusionSignature = 'different';
assert.notEqual(sceneKey('wife__task-idle__v-0', filteredChoice), filteredChoice.imageKey,
  'changing exclusions cannot reuse the previous compressed generated image');
const manualChoice = { ...filteredChoice, manual: true, pendingPreviousKey: 'previous' };
const manualBefore = JSON.stringify(manualChoice);
assert.notEqual(sceneKey('wife__task-idle__v-0', manualChoice), manualChoice.imageKey,
  'a pending manually selected position cannot bypass changed exclusions');
assert.equal(JSON.stringify(manualChoice), manualBefore,
  'recomputing the image key must not mutate the saved manual choice');
exclusionSignature = '';

for (const kind of ['scene-patron_chatting', 'scene-patron_bold', 'task-cooking', 'look-happy']) {
  const key = `wife__${kind}__v-0`;
  prompt = null;
  assert.equal(sceneKey(key), key, `${kind}: unchanged prompts keep the original key`);
  prompt = { positivePrompt: 'talking', negativePrompt: '' };
  const positive = sceneKey(key);
  const result = context.applyPositionPreset({ key, prompt: '1girl', negativePrompt: 'watermark', parts: [{ label: '기본', tags: '1girl' }] }, null, 'wife');
  assert.match(result.prompt, /talking/, `${kind}: positive is applied`);
  assert.equal(sceneKey(result.key), positive, `${kind}: prompt and key agree`);
  assert.notEqual(positive, key);
  assert.match(positive, /__aip-state-scene-prompt-/);
  assert.doesNotMatch(positive, /__position-/);
  assert.equal(sceneKey(key), positive);
  prompt = { positivePrompt: 'talking gently', negativePrompt: '' };
  assert.notEqual(sceneKey(key), positive, `${kind}: positive edits change key`);
  prompt = { positivePrompt: 'talking', negativePrompt: 'text' };
  assert.notEqual(sceneKey(key), positive, `${kind}: negative edits change key`);
  const negative = context.applyPositionPreset({ key, prompt: '1girl', negativePrompt: 'watermark', parts: [{ label: '기본', tags: '1girl' }] }, null, 'wife');
  assert.match(negative.negativePrompt, /text/, `${kind}: negative is applied`);
  assert.equal(sceneKey(negative.key), sceneKey(key), `${kind}: negative prompt and key agree`);
  prompt = { positivePrompt: 'talking', negativePrompt: '', onlyState: true };
  assert.notEqual(sceneKey(key), positive, `${kind}: changing state-only behavior changes key`);
  prompt = null;
  assert.equal(sceneKey(key), key, `${kind}: clearing prompts restores the unmodified key`);
}

const key = 'wife__scene-patron_chatting__v-0';
prompt = { positivePrompt: 'talking', negativePrompt: '' };
const choice = { preset: { id: 'test' } };
const presetKey = sceneKey(key, choice);
assert.match(presetKey, /__aip-state-scene-prompt-/);
assert.match(presetKey, /__position-test-/);
const studioKey = presetKey.replace(/__position-[^_]+/, '__position-studio');
assert.match(studioKey, /__aip-state-scene-prompt-/, 'Studio position replacement preserves the scene signature');
prompt = { positivePrompt: 'talking gently', negativePrompt: '' };
assert.notEqual(sceneKey(key, choice), presetKey, 'preset mode includes scene text');
prompt = { positivePrompt: 'talking', negativePrompt: '' };
const moduleKey = sceneKey(key, { moduleSignature: 'abc', modules: [{ kind: 'pose' }] });
prompt = { positivePrompt: 'talking', negativePrompt: 'text' };
assert.notEqual(sceneKey(key, { moduleSignature: 'abc', modules: [{ kind: 'pose' }] }), moduleKey, 'module mode includes both polarities');
prompt = null;
assert.equal(context.keyWithPosition(key, { sourceKey: key, imageKey: key }), key, 'explicitly selected native image stays selected');
prompt = { positivePrompt: 'talking', negativePrompt: '' };
const selectedKey = 'wife__scene-patron_chatting__position-state-custom-old__v-1';
assert.equal(sceneKey(key, { imageKey: selectedKey, generatedKeys: [selectedKey] }), selectedKey,
  'an explicitly selected earlier image is retained');
prompt = null;
buttonGroups = { positive: [{ value: { codes: ['choice-x'], tags: ['talking'] } }], negative: [] };
const choiceKey = sceneKey(key);
assert.match(choiceKey, /state-choice-prompt-/);
buttonGroups = { positive: [{ value: { codes: ['choice-x'], tags: ['whispering'] } }], negative: [] };
assert.notEqual(sceneKey(key), choiceKey, 'editing choice Positive changes its key');
buttonGroups = { positive: [{ value: { codes: ['choice-x'], tags: ['talking'] } }], negative: [{ value: { codes: ['choice-x'], tags: ['text'] } }] };
assert.notEqual(sceneKey(key), choiceKey, 'editing choice Negative changes its key');
buttonGroups = { positive: [], negative: [] };
assert.equal(sceneKey(key), key, 'no choice prompt keeps original key');
baseSignature = 'base123';
assert.match(sceneKey(key), /state-scene-base-base123/, 'base scene edit participates in automatic key');
baseSignature = ''; scopedStateSignature = 'scoped123';
assert.match(sceneKey(key), /state-scene-state-scoped123/, 'scene state edit participates in automatic key');
scopedStateSignature = '';
console.log('scene prompt keys: ok');
