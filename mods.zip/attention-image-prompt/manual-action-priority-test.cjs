const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const crypto = require('node:crypto');
const source = fs.readFileSync(path.join(__dirname, 'source/image-state.js'), 'utf8');
const helpers = source.slice(source.indexOf('    function positionActClass('), source.indexOf('    function positionModuleChoice('));
const start = source.indexOf('    function positionModuleChoice(');
const end = source.indexOf('\n    function ', start + 8);
assert.ok(start > 0 && end > start);
let selected = ['oral'], groupCount = 0, poseScope = 'you', bridgeExtras = [], situation = 'scene-sex_rough';
let snapshots = 0, lastSnapshot;
const choices = [
  { id: 'oral', kind: 'position', controller: true, controllerScope: 'you', controllerGroup: '입·가슴',
    controllerLabel: '이라마치오', positivePrompt: 'hetero, irrumatio, deepthroat, fellatio' },
  { id: 'guest-oral', kind: 'position', controller: true, controllerScope: 'patron', controllerGroup: '입·손·가슴',
    controllerLabel: '무릎 구강성교', positivePrompt: 'hetero, fellatio, penis' },
  { id: 'compound', kind: 'position', controller: true, controllerScope: 'you',
    positivePrompt: '69, fellatio, cunnilingus' },
  { id: 'manual', kind: 'action', controller: true, controllerScope: 'you',
    positivePrompt: 'hetero, irrumatio, deepthroat' },
  { id: 'generic', kind: 'action', positivePrompt: 'hetero, irrumatio, deepthroat' },
  { id: 'game', kind: 'action', controller: true, controllerScope: 'you',
    positivePrompt: 'hetero, sex, vaginal, penis, pussy' },
  { id: 'guest-game', kind: 'action', controller: true, controllerScope: 'patron',
    positivePrompt: 'hetero, sex, vaginal, penis, pussy' },
  { id: 'guest', kind: 'action', controller: true, controllerScope: 'patron',
    positivePrompt: 'hetero, anal, penis' },
];
const game = { primaryCharacterId: 'wife', slot: 500,
  activeScene: { sex: { type: 'sex_rough' }, patron: { customerId: 'guest', stage: 'sex_patron', primarySlot: 'inside' } } };
const scope = {
  api: { store: { game: () => game } }, controllerFoldSnapshot: null, recentControllerButtons: [],
  controllerScopesForSituation: () => poseScope === 'both' ? ['you', 'patron'] : [poseScope],
  positionGroupCount: () => groupCount, basePositionSituationId: id => id,
  discoverFoldedControllerButtons: () => {}, discoverControllerButtons: () => {},
  visibleControllerButtons: () => [{ scope: poseScope === 'patron' ? 'patron' : 'you',
    id: poseScope === 'patron' ? 'guest-game' : 'game', active: true }],
  currentPositionModuleSelections: () => ({ [situation]: selected }),
  availablePositionModules: () => choices, externalTargetSnapshot: () => { snapshots++; return lastSnapshot = {}; },
  effectiveExternalTarget: (_kind, _id, value, snapshot) => { assert.equal(snapshot, lastSnapshot); return value; },
  currentPositionModulePoseAssignments: () => ({}), activeContactType: () => null,
  controllerContactType: () => null, multiplePatronActions: () => !!(groupCount
    || game.activeScene.patron?.joinedPatronIds?.length || game.activeScene.patron?.crowdPatronIds?.length),
  controllerPositionModules: () => ({ action: choices.find(x => x.id === (poseScope === 'patron' ? 'guest-game' : 'game')), extras: bridgeExtras }),
  femaleClimaxCount: () => 0, climaxModuleThreshold: () => 0,
  currentPositionModuleGroupLayouts: () => ({}), positionGroupSlots: () => '',
  shortHash: text => text,
  MODULE_ACT_TAGS: {}, globalThis: {}, withoutPromptTags: (value, removed) => String(value).split(', ')
    .filter(tag => !String(removed).split(', ').includes(tag)).join(', '),
};
const context = vm.createContext(scope);
vm.runInContext(helpers + source.slice(start, end) + '\nthis.choice = positionModuleChoice;', context);
const run = () => scope.choice(situation, 'wife', '');
let result = run();
assert.equal(snapshots, 1, 'each position calculation makes just one external target snapshot');
assert.equal(result.conflictingNativeAct, 'vaginal');
game.activeScene.sex.characterId = 'someone-else';
assert.equal(run().conflictingNativeAct, undefined, 'another actor must not reinterpret this portrait');
delete game.activeScene.sex.characterId;
assert.deepEqual(Array.from(result.modules, x => x.id), ['oral']);
assert.match(result.moduleSignature, /manual-action-priority-v1/);
assert.equal(scope.conflictingNativeActTags('vaginal'), 'sex, rough_sex, vaginal, vaginal_sex, vaginal_penetration');
const corrected = result;
bridgeExtras = [{ id: 'bridge-rough-pose', kind: 'mood', positivePrompt: 'rough_sex, grabbing_hair', negativePrompt: '' }];
result = run();
assert.equal(result.modules.find(module => module.id === 'bridge-rough-pose').positivePrompt, 'grabbing_hair');
bridgeExtras = [];
selected = ['manual']; bridgeExtras = [{ id: 'bridge-rough-pose', kind: 'mood', positivePrompt: 'rough_sex, grabbing_hair', negativePrompt: '' }];
result = run();
assert.equal(result.conflictingNativeAct, 'vaginal');
assert.equal(result.modules.find(module => module.id === 'bridge-rough-pose').positivePrompt, 'grabbing_hair');
bridgeExtras = []; result = run();
assert.deepEqual(Array.from(result.modules, x => x.id), ['manual']);
selected = ['generic']; result = run();
assert.deepEqual(Array.from(result.modules, x => x.id), ['generic'], 'generic explicit action wins in a single-role scene');
selected = ['compound']; result = run();
assert.equal(result.conflictingNativeAct, undefined, 'intentional compound poses must remain untouched');
selected = ['oral']; groupCount = 1; poseScope = 'both'; result = run();
assert.equal(result.conflictingNativeAct, undefined, 'group scenes must preserve independently assigned acts');
groupCount = 0; poseScope = 'you'; game.activeScene.sex.type = 'blowjob';
result = run();
assert.equal(result.conflictingNativeAct, undefined, 'a stale portrait is not reinterpreted using a new scene');
situation = 'scene-blowjob'; result = run();
assert.equal(result.conflictingNativeAct, undefined, 'same-class actions are not changed');
poseScope = 'patron'; situation = 'scene-patron_sex'; selected = ['guest-oral'];
result = run();
assert.equal(result.conflictingNativeAct, 'vaginal', 'single patron action yields to the chosen oral pose');
assert.ok(result.modules.some(module => module.id === 'guest-oral'));
assert.ok(!result.modules.some(module => module.id === 'guest-game'));
game.activeScene.patron.joinedPatronIds = ['second'];
assert.equal(run().conflictingNativeAct, undefined, 'multiple patrons keep their distinct actions');
delete game.activeScene.patron.joinedPatronIds;
game.activeScene.patron.lateralAct = { kind: 'cunnilingus' };
assert.equal(run().conflictingNativeAct, undefined, 'simultaneous patron acts stay intact');
delete game.activeScene.patron.lateralAct;
game.activeScene.patron.primarySlot = 'inside_anal';
assert.equal(run().conflictingNativeAct, undefined, 'a mismatched patron portrait is not reinterpreted');
situation = 'scene-patron_anal';
assert.equal(run().conflictingNativeAct, 'anal');

// Exercise the real prompt composer and key writer with an actual native scene part.
const cacheSource = fs.readFileSync(path.join(__dirname, 'source/image-cache-and-keys.js'), 'utf8');
const cacheStart = cacheSource.indexOf('    function positionBothHandPrompts(');
const cacheEnd = cacheSource.indexOf('    function rememberLatestScenePrompt(', cacheStart);
const tokens = text => String(text || '').split(',').map(value => value.trim()).filter(Boolean);
const identity = text => String(text).toLowerCase().replace(/^\(/, '').replace(/:[\d.]+\)$/, '').replace(/_/g, ' ');
const composer = {
  controllerButtonDefaultTags: () => '', stripPositionKey: key => key.split('__').filter(x => !x.startsWith('position-')).join('__'),
  positionSituationId: () => 'scene-sex_rough', basePositionSituationId: id => id, positionGroupCount: () => 0,
  currentPositionStatePrompt: () => null, positionStateOnly: () => false, effectivePositionDetails: () => null,
  POSITION_PRESETS: {}, GROUP_SLOT_BY_ID: {}, positionPlacementPrompt: () => '', positionFemaleDetailPrompt: () => '',
  positionPrimaryManPrompt: () => '', effectivePositionPresetPrompt: () => null,
  effectivePositionGroupPrompt: () => ({ positivePrompt: '', negativePrompt: '' }),
  shortHash: value => crypto.createHash('sha256').update(value).digest('hex').slice(0, 8),
  externalSignatureFromImageKey: key => key, positionGroupSlots: () => '', COUPLE_POSITION_NEGATIVES: {},
  POSITION_PART_LABELS: new Set(), MODULE_NATIVE_POSE_TAGS: new Set(), api: { store: { game: () => game } },
  MALE_ACTIONS: { handjob: 'handjob', roughFellatio: 'rough fellatio' }, FEMALE_POSES: { back: 'back' },
  restraintVisible: () => false, promptTokens: tokens, promptTagIdentity: tag => ({ spaced: identity(tag) }),
  withoutPromptTags: (value, removed) => { const ids = tokens(removed).map(identity);
    return tokens(value).filter(tag => !ids.includes(identity(tag))).join(', '); },
  joinPrompt: value => tokens(value).join(', '), deduplicatePrompt: value => [...new Set(tokens(value))].join(', '),
  positionModuleDirection: () => '당신', positionPlacementLabel: () => '', promptGenParams: () => ({}),
  conflictingNativeActTags: scope.conflictingNativeActTags,
};
vm.createContext(composer);
vm.runInContext(`${cacheSource.slice(cacheStart, cacheEnd)}\nthis.apply = applyPositionPreset;`, composer);
const base = { key: 'wife__scene-sex_rough__v-1', prompt: '1girl, (rough_sex:1.2), sex, (vaginal:1.3), (penis:1.3), bedroom, custom_style',
  negativePrompt: 'low quality', parts: [{ label: '기본', tags: '1girl' },
    { label: '장면', tags: '(rough_sex:1.2), sex, (vaginal:1.3), (penis:1.3), bedroom' },
    { label: '사용자 프롬프트', tags: 'custom_style' }] };
const output = composer.apply(base, corrected, 'wife');
assert.match(output.prompt, /irrumatio/);
assert.doesNotMatch(output.prompt, /\b(?:rough_sex|vaginal|sex)\b/);
assert.match(output.prompt, /bedroom/); assert.match(output.prompt, /custom_style/);
assert.match(output.negativePrompt, /low quality/);
const explicitCustom = { ...base, prompt: `${base.prompt}, vaginal`,
  parts: [...base.parts, { label: '사용자 추가', tags: 'vaginal' }] };
assert.match(composer.apply(explicitCustom, corrected, 'wife').prompt, /vaginal/,
  'a user-authored action tag survives even if it matches the suppressed native action');
const oldChoice = { ...corrected, conflictingNativeAct: undefined,
  moduleSignature: JSON.stringify(corrected.modules) };
assert.notEqual(output.key, composer.apply(base, oldChoice, 'wife').key, 'corrected images use a fresh key');
assert.match(output.key, /__v-1$/, 'variant remains intact');
console.log('manual action priority: ok');
