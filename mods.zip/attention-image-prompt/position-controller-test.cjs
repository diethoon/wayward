const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, 'source/position-controller-core.js'), 'utf8');
const snapshot = value => structuredClone(value);
const fixture = () => ({
  day: 7, slot: 431, primaryCharacterId: 'wife',
  characters: { wife: { id: 'wife', stats: { arousal: 42 }, relationship: { trust: 30 } } },
  customers: [{ id: 'guest-1', stamina: 40 }],
  activeScene: { patron: { customerId: 'guest-1', customerName: '손님', stage: 'sex_patron',
    primarySlot: 'inside', startedAtSlot: 420, patronPleasure: 67 } },
  pendingEvent: null, log: [{ text: 'before' }],
  mods: { other: { existing: true } },
});
const modules = [
  { id: 'guest-front', name: '정상위', controller: true, controllerScope: 'patron', kind: 'pose', controllerLabel: '정상위' },
  { id: 'guest-back', name: '후배위', controller: true, controllerScope: 'patron', kind: 'pose', controllerLabel: '후배위' },
  { id: 'you-front', name: '정상위', controller: true, controllerScope: 'you', kind: 'pose', controllerLabel: '정상위' },
  { id: 'you-front-alt', name: '정상위', controller: true, controllerScope: 'you', controllerGroup: '누워서', kind: 'pose', controllerLabel: '정상위' },
  { id: 'you-back', name: '후배위', controller: true, controllerScope: 'you', kind: 'pose', controllerLabel: '후배위' },
  { id: 'you-press', name: '프레스(굴곡위)', controller: true, controllerScope: 'you', kind: 'pose', controllerLabel: '프레스(굴곡위)' },
  { id: 'you-up', name: '기승위', controller: true, controllerScope: 'you', kind: 'pose', controllerLabel: '기승위' },
  { id: 'you-kiss', name: '키스', controller: true, controllerScope: 'you', controllerGroup: '기본', kind: 'other', controllerLabel: '키스', positivePrompt: 'kiss' },
  { id: 'you-hand', name: '가슴', controller: true, controllerScope: 'you', controllerGroup: '오른손', kind: 'other', controllerLabel: '가슴', positivePrompt: 'groping' },
  { id: 'you-hand-other', name: '허리', controller: true, controllerScope: 'you', controllerGroup: '오른손', kind: 'other', controllerLabel: '허리', positivePrompt: 'hand_on_waist' },
  { id: 'you-left', name: '어깨', controller: true, controllerScope: 'you', controllerGroup: '왼손', kind: 'other', controllerLabel: '어깨', positivePrompt: 'hand_on_shoulder' },
  { id: 'you-left-other', name: '팔', controller: true, controllerScope: 'you', controllerGroup: '왼손', kind: 'other', controllerLabel: '팔', positivePrompt: 'hand_on_arm' },
  { id: 'image-only', name: '이미지만', kind: 'action' },
];

function harness(game) {
  let state = fixture();
  let settings = {};
  let mode = 'modules', activeKey = null, activeKeyReads = 0;
  let override = null, stateOnly = false, selections = {}, layouts = {};
  let latestScenePrompt = { situationId: 'scene-patron_sex', characterId: 'wife', result: { key: 'scene-patron_sex' },
    controllerSceneIdentity: JSON.stringify(['patron', 7, 420, null, 'wife', 'guest-1', null, null]) };
  let refreshes = 0, calls = [], asks = [], queued = [], dispatchError = null, onDispatch = null, onUpdate = null, onChoose = null, chooseAvailable = true, chooseCalls = [];
  let poseNow = { customerId: 'guest-1', pose: '정상위', asked: null, choices: ['정상위', '후배위'] };
  let plan = { move: null, custom: 'keep' };
  let moves = [{ label: '몸 비비기', move: { kind: 'rung', target: 'rubbing_patron' } }];
  let poseProviderPresent = true, patronProviderPresent = false, husbandProviderPresent = true, husbandOwns = true, husbandThrows = false;
  let askResult = true, applyWait = true, applyAction = true, resetStart = false, expansionActive = true, routeMode = 'fits', routeWhy = '', sequence = false;

  function applyCaress(value, action) {
    const match = /^(act_toggle|act_caress|act_off):([a-zA-Z0-9_]+)$/.exec(action);
    if (!match) return false;
    const sex = value.activeScene.sex, keys = sex.testCaress || [];
    if (match[1] === 'act_off') sex.testCaress = keys.filter(key => key !== match[2]);
    else if (!keys.includes(match[2])) sex.testCaress = [...keys, match[2]];
    else value.slot += 1;
    if (match[1] === 'act_caress' && !keys.includes(match[2])) value.slot += 1;
    return true;
  }

  const api = { game, has: name => name === 'playerSexChoose' && chooseAvailable,
    fn: name => { assert.equal(name, 'playerSexChoose'); return (value, action) => {
      chooseCalls.push(action);
      if (onChoose) return onChoose(value, action);
      if (!applyCaress(value, action)) value.activeScene.sex.testPose = action.slice('act_pose:'.length);
      return value;
    }; }, settings: {
    get: defaults => ({ ...defaults, ...settings }),
    set: patch => { settings = { ...settings, ...patch }; if (patch.positionModuleSelections) selections = patch.positionModuleSelections; },
  }, store: {
    game: () => state,
    update: fn => { if (onUpdate) onUpdate(); state = fn(state); },
    get: () => ({ dispatch: () => {} }),
    dispatch: action => {
      calls.push(snapshot(action));
      if (onDispatch) onDispatch();
      if (dispatchError) throw dispatchError;
      if (action.type === 'wait' && applyWait) {
        state.slot += action.minutes;
        if (poseNow.asked) poseNow = { ...poseNow, pose: poseNow.asked, asked: null };
        if (plan.move) plan = { ...plan, move: null };
      }
      if (action.type === 'scene_action' && applyAction) {
        if (applyCaress(state, action.actionId)) { /* public HL action */ }
        else if (action.actionId.startsWith('switch_to_'))
          state.activeScene.sex = { ...state.activeScene.sex, type: action.actionId.slice('switch_to_'.length),
            ...(resetStart ? { startedAtSlot: state.slot } : {}) };
        else if (action.actionId.startsWith('act_pose:'))
          state.activeScene.sex = { ...state.activeScene.sex, testPose: action.actionId.slice('act_pose:'.length) };
      }
    },
  } };

  const fakeGlobals = {
    get __waywardActExpansion() {
      if (!poseProviderPresent) return undefined;
      return { active: () => expansionActive, pseqNow: () => sequence, pose: {
        now: () => snapshot(poseNow),
        ask: label => { asks.push(label); if (askResult) poseNow.asked = label; return askResult; },
      } };
    },
    get __waywardPatronControl() {
      if (!patronProviderPresent) return undefined;
      return {
        plans: () => ({ 'guest-1': snapshot(plan) }),
        shownMoves: () => snapshot(moves),
        queueMove: (actor, move) => { queued.push({ actor, move: snapshot(move) }); plan.move = snapshot(move); },
      };
    },
    get __waywardHusbandLife() {
      if (!husbandProviderPresent) return undefined;
      return { owns: current => { if (husbandThrows) throw new Error('owner unavailable'); return husbandOwns && !!current.activeScene?.sex; }, ui: {
        INSIDE: new Set(['inside']), POSE_TYPE: { '정상위': 'inside', '후배위': 'outside', '프레스(굴곡위)': 'inside' },
        CARESS: { kiss: { label: '키스', part: 'mouth' }, grope: { label: '가슴 주무르기', part: 'hand' } },
        CARESS_SETS: [['basic', '기본', ['kiss', 'grope']]],
        caressAllowed: (sex, state) => sex.blocked ? [] : state?.testBlocked ? ['kiss'] : ['kiss', 'grope'],
        caressPlaced: sex => sex?.unplaced ? [] : ['kiss', 'grope'], caressKeys: sex => sex?.testCaress || [],
        dress: () => ({}), clothWhy: () => '옷을 조정해 주세요.',
        leadOf: sex => sex.lead || 'you',
        poseRoute: (_state, _sex, label) => ['정상위', '후배위', '프레스(굴곡위)'].includes(label) ? { mode: routeMode, why: routeWhy } : null,
        poseOf: sex => sex && Object.prototype.hasOwnProperty.call(sex, 'testPose') ? sex.testPose : '정상위',
      } };
    },
  };
  const make = (both = false) => new Function('api', 'globalThis', 'positionMode', 'latestScenePrompt', 'positionOverride',
    'positionStateOnly', 'currentPositionStatePrompt', 'currentPositionModuleSelections',
    'availablePositionModules', 'currentPositionModuleGroupLayouts', 'syncPositionControllerButton',
    'basePositionSituationId', 'positionSituationId', 'activePortraitImageKey',
    `${source}\nreturn ${both ? `{ api: positionControllerApi, window: positionControllerWindowApi,
      display(allowWindow = false) { const game = api.store.game(), state = positionControllerState(game, allowWindow);
        return { state, entries: positionControllerList(allowWindow, { game, state }) }; } }` : 'positionControllerApi'};`)(api, fakeGlobals, () => mode, latestScenePrompt,
    () => override, () => stateOnly, () => ({}), () => selections, () => modules,
    () => layouts, () => { refreshes++; }, id => id, id => id, key => { activeKeyReads++; return activeKey ?? key; });
  return { make, api, get state() { return state; }, set state(value) { state = value; },
    get settings() { return settings; }, get calls() { return calls; }, get asks() { return asks; },
    get queued() { return queued; }, get poseNow() { return poseNow; }, set poseNow(value) { poseNow = value; },
    get plan() { return plan; }, set plan(value) { plan = value; }, get refreshes() { return refreshes; },
    get latest() { return latestScenePrompt; }, set latest(value) { latestScenePrompt = value; }, set mode(value) { mode = value; },
    get override() { return override; }, get selections() { return selections; }, get layouts() { return layouts; },
    set override(value) { override = value; }, set stateOnly(value) { stateOnly = value; },
    set selections(value) { selections = value; }, set layouts(value) { layouts = value; },
    set dispatchError(value) { dispatchError = value; }, set onDispatch(value) { onDispatch = value; },
    set onUpdate(value) { onUpdate = value; }, set onChoose(value) { onChoose = value; },
    set chooseAvailable(value) { chooseAvailable = value; }, get chooseCalls() { return chooseCalls; },
    set poseProviderPresent(value) { poseProviderPresent = value; },
    set patronProviderPresent(value) { patronProviderPresent = value; },
    set husbandProviderPresent(value) { husbandProviderPresent = value; },
    set husbandOwns(value) { husbandOwns = value; },
    set husbandThrows(value) { husbandThrows = value; },
    set askResult(value) { askResult = value; }, set applyWait(value) { applyWait = value; },
    set expansionActive(value) { expansionActive = value; }, set routeMode(value) { routeMode = value; }, set routeWhy(value) { routeWhy = value; },
    set sequence(value) { sequence = value; }, set activeKey(value) { activeKey = value; }, get activeKeyReads() { return activeKeyReads; },
    set applyAction(value) { applyAction = value; }, set resetStart(value) { resetStart = value; }, set moves(value) { moves = value; } };
}

for (const game of ['2026-10-04', '2026-10-24-pre7']) {
  const h = harness(game), controller = h.make();
  assert.ok(Object.isFrozen(controller));
  assert.equal(controller.getState().enabled, false, `${game}: disabled by default`);
  let before = snapshot(h.state), planBefore = snapshot(h.plan), poseBefore = snapshot(h.poseNow);
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'disabled');
  assert.deepEqual(h.state, before); assert.deepEqual(h.plan, planBefore); assert.deepEqual(h.poseNow, poseBefore);
  assert.equal(h.calls.length, 0); assert.equal(h.asks.length, 0);
  assert.equal(controller.setEnabled('true').reason, 'invalid_enabled');
  assert.equal(h.settings.positionControllerEnabled, undefined);
  assert.equal(controller.setEnabled(true).ok, true);
  assert.equal(h.settings.positionControllerEnabled, true);
  assert.equal(h.refreshes, 1);
  assert.equal(h.make().getState().enabled, true, 'on/off preference survives reload');
  const enabledSettings = snapshot(h.settings);
  const stateView = controller.getState(), listView = controller.list();
  assert.equal(stateView.reason, '');
  assert.ok(listView.find(item => item.id === 'guest-back').available);
  assert.equal(listView.find(item => item.id === 'guest-front').active, true);
  assert.equal(listView.find(item => item.id === 'image-only').reason, 'image_only');
  assert.equal(h.calls.length, 0); assert.equal(h.asks.length, 0);
  assert.deepEqual(h.state, before, 'reads do not mutate game state');
  assert.deepEqual(h.settings, enabledSettings, 'reads do not modify saved settings');
  assert.equal(h.refreshes, 1, 'reads do not update the controller UI');
  try { stateView.enabled = false; listView[0].label = 'tampered'; listView.push({ id: 'injected' }); } catch {}
  assert.equal(controller.getState().enabled, true);
  assert.ok(!controller.list().some(item => item.id === 'injected'), 'returned lists are detached');

  for (const id of ['', null, {}, 'missing', '__proto__']) {
    before = snapshot(h.state); planBefore = snapshot(h.plan); poseBefore = snapshot(h.poseNow);
    assert.equal(controller.execute(id, controller.getState().sceneToken).ok, false);
    assert.deepEqual(h.state, before); assert.deepEqual(h.plan, planBefore); assert.deepEqual(h.poseNow, poseBefore);
    assert.equal(h.calls.length, 0); assert.equal(h.asks.length, 0);
  }
  let token = controller.getState().sceneToken;
  assert.equal(controller.execute('guest-back', '').reason, 'invalid_action');
  assert.equal(controller.execute('guest-back', 'forged').reason, 'stale_scene');
  h.state.slot++;
  assert.equal(controller.execute('guest-back', token).reason, 'stale_scene');
  assert.equal(h.calls.length, 0); assert.equal(h.asks.length, 0);
  assert.equal(controller.execute('guest-front', controller.getState().sceneToken).reason, 'already_selected');

  const dispatch = h.api.store.dispatch;
  h.api.store.dispatch = undefined;
  before = snapshot(h.state); planBefore = snapshot(h.plan); poseBefore = snapshot(h.poseNow);
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'provider_unavailable');
  assert.deepEqual(h.state, before); assert.deepEqual(h.plan, planBefore); assert.deepEqual(h.poseNow, poseBefore);
  h.api.store.dispatch = dispatch;

  const patron = h.state.activeScene.patron;
  delete h.state.activeScene.patron;
  assert.equal(controller.getState().reason, 'no_scene');
  assert.deepEqual(controller.list(), []);
  assert.equal(controller.execute('guest-back', 'old-token').reason, 'no_scene');
  h.state.activeScene.patron = patron;

  h.mode = 'legacy';
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'module_mode_required');
  h.mode = 'modules';
  h.latest.situationId = '';
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'image_context_unavailable');
  h.latest.situationId = 'scene-patron_sex';
  h.latest.result.key = 'scene-other';
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'image_context_unavailable');
  h.latest.result.key = 'scene-patron_sex';
  h.latest.characterId = 'another-wife';
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'image_context_unavailable');
  h.latest.characterId = 'wife';
  const currentIdentity = h.latest.controllerSceneIdentity;
  h.latest.controllerSceneIdentity = 'previous-scene';
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'image_context_unavailable');
  h.latest.controllerSceneIdentity = currentIdentity;
  h.override = { presetId: 'custom' };
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'image_override_conflict');
  h.override = null; h.stateOnly = true;
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'image_override_conflict');
  h.stateOnly = false; h.selections = { 'scene-patron_sex': ['guest-back'] };
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'image_override_conflict');
  h.selections = {}; h.layouts = { 'scene-patron_sex': { groupSlots: 'm' } };
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'image_override_conflict');
  h.layouts = {};
  h.state.pendingEvent = { type: 'some-other-event' };
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'pending_event');
  h.state.pendingEvent = null;
  h.sequence = true;
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'sequence_in_progress');
  h.sequence = false;
  h.patronProviderPresent = true;
  h.plan = { move: { kind: 'rung', target: 'other' }, custom: 'keep' };
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'plan_conflict');
  h.plan = { move: null, repeat: true, custom: 'keep' };
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'plan_conflict');
  h.plan = { move: null, custom: 'keep' };
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'controller_unverifiable');
  const blockedMove = controller.list().find(item => item.id.startsWith('move:'));
  assert.equal(blockedMove, undefined, 'private controller moves must not be offered');
  assert.equal(h.queued.length, 0, 'coexisting controller must not have a move queued');
  h.patronProviderPresent = false;
  h.poseNow = { ...h.poseNow, asked: '후배위' };
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'pending_request');
  h.poseNow = { ...h.poseNow, asked: null };
  h.poseProviderPresent = false;
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'provider_unavailable');
  h.poseProviderPresent = true;
  h.expansionActive = false;
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'provider_unavailable');
  h.expansionActive = true;
  assert.equal(h.calls.length, 0); assert.equal(h.asks.length, 0);

  h.askResult = false;
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'request_rejected');
  assert.equal(h.calls.length, 0);
  h.askResult = true;
  before = snapshot(h.state);
  let reentrant;
  h.onDispatch = () => { reentrant = controller.execute('guest-back', controller.getState().sceneToken); };
  token = controller.getState().sceneToken;
  assert.deepEqual(controller.execute('guest-back', token), { ok: true, pending: false, reason: 'applied' });
  assert.equal(reentrant.reason, 'busy', 'reentrant action must not dispatch twice');
  assert.equal(h.asks.filter(value => value === '후배위').length, 2, 'one rejected request and one accepted request');
  assert.deepEqual(h.calls, [{ type: 'wait', minutes: 1 }]);
  assert.equal(h.poseNow.pose, '후배위');
  assert.equal(h.poseNow.asked, null);
  assert.deepEqual(h.state, { ...before, slot: before.slot + 1 },
    'the controller delegates time effects once to the owning game dispatch');
  assert.deepEqual(h.plan, { move: null, custom: 'keep' }, 'another controller plan must survive');
  h.onDispatch = null;

  h.state = fixture(); h.poseNow = { customerId: 'guest-1', pose: '정상위', asked: null, choices: ['정상위', '후배위'] };
  h.applyWait = false;
  const pendingCalls = h.calls.length;
  assert.deepEqual(controller.execute('guest-back', controller.getState().sceneToken),
    { ok: true, pending: true, reason: 'pending' });
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'pending_request');
  assert.equal(h.calls.length, pendingCalls + 1, 'pending requests must never dispatch again');
  h.applyWait = true;

  h.state = fixture(); h.poseNow = { customerId: 'guest-1', pose: '정상위', asked: null, choices: ['정상위', '후배위'] };
  h.dispatchError = new Error('disconnected');
  const callsBefore = h.calls.length;
  assert.deepEqual(controller.execute('guest-back', controller.getState().sceneToken),
    { ok: false, pending: true, reason: 'dispatch_failed_pending' });
  assert.equal(h.poseNow.asked, '후배위', 'a queued pose must be retained on dispatch failure');
  assert.equal(controller.execute('guest-back', controller.getState().sceneToken).reason, 'pending_request');
  assert.equal(h.calls.length, callsBefore + 1, 'failed requests must never be dispatched a second time');

  h.dispatchError = null;
  h.state = fixture(); delete h.state.activeScene.patron;
  h.state.activeScene.sex = { type: 'sex', startedAtSlot: 420, testPose: '정상위' };
  h.state.pendingEvent = { type: 'sex_scene', choices: [] };
  h.latest.situationId = 'scene-sex';
  h.latest.result.key = 'scene-sex';
  h.latest.controllerSceneIdentity = JSON.stringify(['you', 7, 420, null, 'wife', null, null, null]);
  const youToken = controller.getState().sceneToken;
  assert.ok(controller.list().find(item => item.id === 'you-back').available);
  const priorCalls = h.calls.length;
  assert.deepEqual(controller.execute('you-back', youToken), { ok: true, pending: false, reason: 'applied' });
  assert.equal(h.calls.length, priorCalls + 1);
  assert.deepEqual(h.calls.at(-1), { type: 'scene_action', actionId: 'act_pose:후배위' });
  assert.equal(h.state.activeScene.sex.testPose, '후배위');
  h.routeMode = 'game';
  h.state.activeScene.sex.__hs = { her: { prep: 'ready:inside' } };
  assert.deepEqual(controller.execute('you-front', controller.getState().sceneToken), { ok: true, pending: false, reason: 'applied' });
  assert.deepEqual(h.calls.at(-1), { type: 'scene_action', actionId: 'act_pose:정상위' });
  h.routeMode = 'force';
  assert.deepEqual(controller.execute('you-back', controller.getState().sceneToken), { ok: true, pending: false, reason: 'applied' });
  delete h.state.activeScene.sex.__hs;
  const forceCount = h.calls.length;
  assert.equal(controller.execute('you-front', controller.getState().sceneToken).reason, 'unsupported_action');
  assert.equal(h.calls.length, forceCount, 'force route must respect original preparation gating');
  h.state.activeScene.sex.lead = 'her';
  assert.deepEqual(controller.execute('you-front', controller.getState().sceneToken), { ok: true, pending: false, reason: 'applied' });
  h.state.pendingEvent = { type: 'unrelated' };
  assert.equal(controller.execute('you-back', controller.getState().sceneToken).reason, 'pending_event');
  h.state.pendingEvent = null; h.husbandProviderPresent = false;
  assert.equal(controller.execute('you-back', controller.getState().sceneToken).reason, 'pending_event');
  h.husbandProviderPresent = true;
  h.state.activeScene.patron = fixture().activeScene.patron;
  assert.equal(controller.getState().reason, 'actor_conflict');
  assert.deepEqual(controller.list(), []);
  assert.equal(controller.execute('you-front', controller.getState().sceneToken).ok, false);
  assert.equal(controller.setEnabled(false).ok, true);
  assert.equal(h.make().getState().enabled, false, 'disabled setting survives reload');

  // Image settings must survive an actual action even if the displayed portrait is pinned or unavailable.
  for (const imageCase of ['selection', 'override', 'state-only', 'layout', 'missing']) {
    const c = harness(game);
    delete c.state.activeScene.patron;
    c.state.activeScene.sex = { type: 'sex', startedAtSlot: 420, testPose: '정상위' };
    c.state.pendingEvent = { type: 'sex_scene', choices: [] };
    c.latest.situationId = 'scene-sex';
    c.latest.result.key = 'scene-sex';
    c.latest.controllerSceneIdentity = JSON.stringify(['you', 7, 420, null, 'wife', null, null, null]);
    if (imageCase === 'selection') c.selections = { 'scene-sex': ['you-front'] };
    if (imageCase === 'override') c.override = { presetId: 'custom' };
    if (imageCase === 'state-only') c.stateOnly = true;
    if (imageCase === 'layout') c.layouts = { 'scene-sex': { groupSlots: 'm' } };
    if (imageCase === 'missing') c.latest = null;
    c.api.settings.set({ imageSettings: { preset: 'keep' } });
    const control = c.make();
    control.setEnabled(true);
    const saved = snapshot(c.settings), selected = snapshot(c.selections), fixed = snapshot(c.override), layout = snapshot(c.layouts);
    assert.equal(control.getState().imageWarning, imageCase === 'missing' ? 'image_context_unavailable' : 'image_override_conflict', imageCase);
    assert.ok(control.list().find(item => item.id === 'you-back').available, imageCase);
    assert.deepEqual(control.execute('you-back', control.getState().sceneToken), { ok: true, pending: false, reason: 'applied' }, imageCase);
    assert.equal(c.state.activeScene.sex.testPose, '후배위', imageCase);
    assert.deepEqual(c.settings, saved, imageCase);
    assert.deepEqual(c.selections, selected, imageCase);
    assert.deepEqual(c.override, fixed, imageCase);
    assert.deepEqual(c.layouts, layout, imageCase);
  }

  const c = harness(game);
  delete c.state.activeScene.patron;
  c.state.activeScene.sex = { type: 'outside', startedAtSlot: 420, testPose: '정상위' };
  c.state.pendingEvent = { type: 'sex_scene', choices: [] };
  c.latest.situationId = 'scene-sex'; c.latest.result.key = 'scene-sex';
  c.latest.controllerSceneIdentity = JSON.stringify(['you', 7, 420, null, 'wife', null, null, null]);
  const control = c.make(); control.setEnabled(true);
  c.routeMode = 'force';
  let front = control.list().find(item => item.id === 'you-front');
  assert.equal(front.available, false);
  assert.equal(front.active, true, 'current pose stays visible even when its route is unavailable');
  assert.equal(front.detail, '먼저 삽입 준비를 해 주세요.');
  c.state.activeScene.sex.type = 'inside';
  c.routeMode = null; c.routeWhy = '게임이 지금 선택지를 내주지 않습니다.';
  front = control.list().find(item => item.id === 'you-front');
  assert.equal(front.active, true);
  assert.equal(front.detail, '게임이 지금 선택지를 내주지 않습니다.');
  c.state.activeScene.sex.type = 'outside';
  c.state.activeScene.sex.testPose = '후배위';
  c.routeMode = 'unlock'; c.routeWhy = '처음 해 보자고 제안합니다.';
  front = control.list().find(item => item.id === 'you-front');
  assert.equal(front.available, true, 'first-time proposal does not require completed insertion preparation');
  assert.equal(front.proposal, true);
  c.applyAction = false;
  assert.deepEqual(control.execute('you-front', control.getState().sceneToken), { ok: true, pending: false, reason: 'proposal_sent' });
  assert.equal(c.state.activeScene.sex.testPose, '후배위', 'proposal alone must not claim the pose changed');
  c.applyAction = true;
  assert.deepEqual(control.execute('you-front', control.getState().sceneToken), { ok: true, pending: false, reason: 'applied' });
  assert.equal(c.state.activeScene.sex.testPose, '정상위');
}

// Rough scenes offer native action choices independently of Husband Life ownership.
for (const game of ['2026-10-04', '2026-10-24-pre7']) for (const owner of ['missing', 'unowned', 'owned']) {
  const h = harness(game);
  delete h.state.activeScene.patron;
  h.state.primaryCharacterId = 'pippa';
  h.state.activeScene.sex = { type: 'sex_rough', startedAtSlot: 420, testPose: '정상위' };
  h.state.pendingEvent = { id: 'rough-event', type: 'sex_scene', choices: [
    { id: 'switch_to_riding', label: '기승위', description: '게임의 선택지' },
    { id: 'switch_to_anal', label: '뒤로', disabled: true },
    { id: 'switch_to_blowjob', label: '입으로', enabled: false },
    { id: 'finish', label: '마무리' },
    { id: 'switch_to_../evil', label: '잘못된 선택지' },
  ] };
  h.latest.situationId = 'scene-sex_rough';
  h.latest.result.key = 'scene-sex_rough';
  h.latest.characterId = 'pippa';
  h.latest.controllerSceneIdentity = JSON.stringify(['you', 7, 420, null, 'pippa', null, null, null]);
  h.selections = { 'scene-sex_rough': ['you-front'] };
  h.override = { presetId: 'custom' };
  h.layouts = { 'scene-sex_rough': { groupSlots: 'm' } };
  h.husbandProviderPresent = owner !== 'missing';
  h.husbandOwns = owner === 'owned';
  const controller = h.make();
  controller.setEnabled(true);
  const saved = snapshot(h.settings), selected = snapshot(h.selections), override = snapshot(h.override), layouts = snapshot(h.layouts);
  const rows = controller.list();
  const riding = rows.find(row => row.id === 'native:switch_to_riding');
  assert.ok(riding?.available, `${owner}: native rough-scene choice is available`);
  assert.equal(riding.effect, 'game');
  assert.equal(riding.actionId, 'switch_to_riding');
  assert.equal(riding.label, '기승위');
  assert.equal(rows.find(row => row.id === 'native:switch_to_anal')?.available, false, `${owner}: disabled choice`);
  assert.equal(rows.find(row => row.id === 'native:switch_to_blowjob')?.available, false, `${owner}: explicitly unavailable choice`);
  assert.equal(rows.some(row => row.id === 'native:finish' || row.id === 'native:switch_to_../evil'), false,
    `${owner}: unrelated and malformed actions are never exposed`);
  assert.equal(controller.execute('native:switch_to_anal', controller.getState().sceneToken).ok, false);
  assert.equal(controller.execute('native:switch_to_blowjob', controller.getState().sceneToken).ok, false);
  assert.equal(controller.execute('native:switch_to_missing', controller.getState().sceneToken).ok, false);
  let token = controller.getState().sceneToken;
  h.state.slot++;
  assert.equal(controller.execute(riding.id, token).reason, 'stale_scene', `${owner}: stale scene token rejected`);
  token = controller.getState().sceneToken;
  h.state.pendingEvent.choices[0].disabled = true;
  assert.equal(controller.execute(riding.id, token).ok, false, `${owner}: availability rechecked at execution`);
  h.state.pendingEvent.choices[0].disabled = false;
  h.state.activeScene.sex.finish = { resolved: true };
  assert.equal(controller.list().find(row => row.id === riding.id)?.available, true,
    `${owner}: currently offered game choices remain available after finish`);
  delete h.state.activeScene.sex.finish;
  token = controller.getState().sceneToken;
  h.state.pendingEvent.id = 'changed-event';
  assert.equal(controller.execute(riding.id, token).reason, 'stale_scene', `${owner}: changed event rejected`);
  assert.equal(h.calls.length, 0, `${owner}: rejected actions never dispatch`);
  h.resetStart = true;
  assert.deepEqual(controller.execute(riding.id, controller.getState().sceneToken),
    { ok: true, pending: false, reason: 'applied' }, `${owner}: native result confirmed`);
  assert.deepEqual(h.calls, [{ type: 'scene_action', actionId: 'switch_to_riding' }]);
  assert.equal(h.state.activeScene.sex.type, 'riding');
  assert.equal(h.state.activeScene.sex.startedAtSlot, h.state.slot, `${owner}: reset start slot is accepted`);
  assert.deepEqual(h.settings, saved, `${owner}: user settings unchanged`);
  assert.deepEqual(h.selections, selected, `${owner}: image module selection unchanged`);
  assert.deepEqual(h.override, override, `${owner}: image override unchanged`);
  assert.deepEqual(h.layouts, layouts, `${owner}: image layout unchanged`);
  assert.equal(h.queued.length, 0, `${owner}: no guest controller interaction`);
}

{
  const h = harness('2026-10-24-pre7');
  delete h.state.activeScene.patron;
  h.state.activeScene.sex = { type: 'sex_rough', startedAtSlot: 420 };
  h.state.pendingEvent = { type: 'sex_scene', choices: [{ id: 'switch_to_riding', label: '기승위' }] };
  h.husbandProviderPresent = false;
  const controller = h.make(); controller.setEnabled(true);
  h.applyAction = false;
  assert.deepEqual(controller.execute('native:switch_to_riding', controller.getState().sceneToken),
    { ok: false, pending: false, reason: 'transition_unconfirmed' }, 'a no-op cannot claim that the action succeeded');
  assert.equal(h.state.activeScene.sex.type, 'sex_rough');
  assert.deepEqual(h.calls, [{ type: 'scene_action', actionId: 'switch_to_riding' }]);
  h.state.pendingEvent = { type: 'other_event', choices: [{ id: 'switch_to_anal', label: '뒤로' }] };
  assert.equal(controller.list().some(row => row.id === 'native:switch_to_anal' && row.available), false,
    'native actions from a different event are not eligible');
}

// The independent provider changes only its own pose state, and delegates act changes to the game.
function standalone() {
  const h = harness('2026-10-24-pre7');
  delete h.state.activeScene.patron;
  h.state.activeScene.sex = { type: 'sex_rough', characterId: 'wife', startedAtSlot: 420,
    playerPleasure: 72, elenaMoaning: 22, __hs: { other: 'preserve' } };
  h.state.pendingEvent = { type: 'sex_scene', choices: [] };
  h.state.mods.badguest = { equipment: { restraint: { active: true, owner: 'player' } } };
  h.state.mods.other = { reserved: 'unchanged' };
  h.husbandProviderPresent = false;
  const controller = h.make(); controller.setEnabled(true);
  return { h, controller };
}

// The floating window can operate with the inline panel disabled, without changing public API behavior.
for (const dual of [false, true]) {
  const h = harness('2026-10-24-pre7');
  if (!dual) delete h.state.activeScene.patron;
  h.state.activeScene.sex = { type: 'sex_rough', characterId: 'wife', startedAtSlot: 420, pleasure: 42 };
  h.state.pendingEvent = { type: 'sex_scene', choices: [] };
  h.husbandProviderPresent = false; h.latest = null; h.activeKey = 'scene-sex_rough';
  const controls = h.make(true), pub = controls.api, win = controls.window;
  assert.equal(pub.getState().reason, 'disabled');
  assert.equal(win.getState().enabled, false);
  assert.equal(win.getState().reason, '');
  assert.equal(win.getState().sceneToken, pub.getState().sceneToken);
  assert.equal(pub.list().find(row => row.id === 'you-back').available, false);
  assert.equal(win.list().find(row => row.id === 'you-back').available, true);
  assert.equal(pub.execute('you-back', pub.getState().sceneToken, true).reason, 'disabled', 'public bypass arguments are ignored');
  let reentry;
  h.onUpdate = () => { reentry = win.execute('you-back', win.getState().sceneToken); };
  assert.equal(win.execute('you-back', win.getState().sceneToken).reason, 'applied');
  h.onUpdate = null;
  assert.equal(reentry.reason, 'busy', 'window and panel share the execution lock');
  assert.equal(pub.getPose().label, '후배위');
  assert.equal(h.settings.positionControllerEnabled, undefined, 'window never changes panel setting');
  const before = snapshot(h.state);
  assert.equal(win.execute('you-kiss', win.getState().sceneToken).effect, 'image_only');
  assert.deepEqual(h.state, before);
  assert.equal(win.list().find(row => row.id === 'you-kiss').active, true);
  pub.setEnabled(true);
  assert.equal(pub.list().find(row => row.id === 'you-kiss').active, true, 'both views share selected modules');
  pub.setEnabled(false);
  h.mode = 'presets';
  assert.equal(win.getState().reason, 'module_mode_required', 'window retains module mode guard');
  assert.equal(win.execute('you-back', win.getState().sceneToken).reason, 'module_mode_required');
}

{
  const h = harness('2026-10-24-pre7');
  h.state.activeScene.sex = { type: 'inside', characterId: 'wife', startedAtSlot: 420, testPose: '정상위' };
  h.state.pendingEvent = { type: 'sex_scene', choices: [] };
  const controls = h.make(true), win = controls.window;
  assert.equal(win.execute('hl:caress:kiss', win.getState().sceneToken).reason, 'applied');
  assert.deepEqual(h.state.activeScene.patron, fixture().activeScene.patron, 'window keeps dual-scene protection');
  assert.equal(win.execute('hl:caress:kiss', win.getState().sceneToken).reason, 'dual_action_conflict');
  const token = win.getState().sceneToken;
  h.state.slot++;
  assert.equal(win.execute('hl:caress:grope', token).reason, 'stale_scene');
}

// The representative pose follows the same owner-specific route as the matching pose row.
for (const owner of ['aip', 'husband-life']) for (const dual of [false, true]) {
  const h = harness('2026-10-24-pre7');
  if (!dual) delete h.state.activeScene.patron;
  h.state.activeScene.sex = { type: 'sex_rough', characterId: 'wife', startedAtSlot: 420,
    testPose: '후배위', pleasure: 55, __hs: { her: { prep: 'ready:inside' } } };
  h.state.pendingEvent = { type: 'sex_scene', choices: [] };
  h.husbandProviderPresent = owner === 'husband-life'; h.latest = null; h.activeKey = 'scene-sex_rough';
  h.selections = { 'scene-sex_rough': ['you-front', 'you-kiss'], 'scene-anal': ['you-front'] };
  const controller = h.make(); controller.setEnabled(true);
  const before = snapshot(h.state), selections = snapshot(h.selections);
  const row = controller.list().find(item => item.id === 'aip:representative-pose');
  assert.equal(row.targetId, 'you-press'); assert.equal(row.available, true);
  assert.equal(row.label, '대표 체위 · 프레스(굴곡위)');
  assert.deepEqual(controller.execute(row.id, controller.getState().sceneToken),
    { ok: true, pending: false, reason: 'applied' });
  if (owner === 'aip') delete h.state.activeScene.sex.__aipPose;
  else h.state.activeScene.sex.testPose = before.activeScene.sex.testPose;
  assert.deepEqual(h.state, before, 'representative route preserves other state in this fixture');
  assert.deepEqual(h.selections, selections, 'manual image choices remain untouched');
}

{
  const { h, controller } = standalone();
  for (const [type, expected] of [['sex', 'you-front'], ['sex_rough', 'you-press'], ['anal', 'you-back'], ['riding', 'you-up']]) {
    h.state.activeScene.sex.type = type;
    const row = controller.list().find(item => item.id === 'aip:representative-pose');
    assert.equal(row.targetId, expected, `${type}: representative stays in the current act`);
    assert.equal(row.available, true);
  }
  h.state.activeScene.sex.type = 'unknown';
  const row = controller.list().find(item => item.id === 'aip:representative-pose');
  assert.equal(row.available, false); assert.equal(row.reason, 'unsupported_action');
  assert.equal(controller.execute(row.id, controller.getState().sceneToken).reason, 'unsupported_action');
}

{
  const h = harness('2026-10-24-pre7');
  delete h.state.activeScene.patron;
  h.state.activeScene.sex = { type: 'sex', startedAtSlot: 420, testPose: '후배위' };
  h.state.pendingEvent = { type: 'sex_scene', choices: [] };
  h.routeMode = null;
  const controller = h.make(); controller.setEnabled(true);
  const row = controller.list().find(item => item.id === 'aip:representative-pose');
  assert.equal(row.reason, 'unsupported_action');
  assert.equal(controller.execute(row.id, controller.getState().sceneToken).ok, false);
  assert.deepEqual(h.calls, [], 'the representative must honor the owning mod route');
}

{
  const h = harness('2026-10-24-pre7');
  delete h.state.activeScene.patron;
  h.state.activeScene.sex = { type: 'sex_rough', characterId: 'wife', startedAtSlot: 420 };
  h.state.pendingEvent = { type: 'sex_scene', choices: [] };
  h.husbandProviderPresent = false;
  h.latest = null;
  h.activeKey = 'scene-sex_rough';
  h.selections = { 'scene-sex_rough': ['you-front'], 'scene-anal': ['you-hand'] };
  const controller = h.make(); controller.setEnabled(true);
  const before = snapshot(h.state);
  const row = controller.list().find(item => item.id === 'you-kiss');
  assert.equal(row.effect, 'image_only');
  assert.equal(row.provider, 'aip-prompt');
  assert.equal(row.available, true, 'the current situation can be derived when no portrait is visible');
  assert.deepEqual(controller.execute('you-kiss', controller.getState().sceneToken),
    { ok: true, pending: false, reason: 'applied', effect: 'image_only' });
  assert.deepEqual(h.state, before, 'image-only selections do not dispatch or mutate game state');
  assert.deepEqual(h.selections, { 'scene-sex_rough': ['you-front', 'you-kiss'], 'scene-anal': ['you-hand'] },
    'unrelated manual selections and other situations survive');
  assert.equal(controller.list().find(item => item.id === 'you-kiss').active, true);
  assert.equal(controller.execute('you-kiss', controller.getState().sceneToken).ok, true);
  assert.deepEqual(h.selections, { 'scene-sex_rough': ['you-front'], 'scene-anal': ['you-hand'] });
  assert.equal(h.calls.length, 0);
  assert.equal(controller.execute('you-hand', controller.getState().sceneToken).ok, true);
  assert.equal(controller.execute('you-left', controller.getState().sceneToken).ok, true);
  assert.equal(controller.list().find(item => item.id === 'you-hand-other').available, true);
  assert.equal(controller.execute('you-hand-other', controller.getState().sceneToken).ok, true);
  assert.deepEqual(h.selections['scene-sex_rough'], ['you-front', 'you-left', 'you-hand-other'],
    'selecting another right-hand prompt replaces only that hand');
  assert.equal(controller.execute('you-left-other', controller.getState().sceneToken).ok, true);
  assert.deepEqual(h.selections['scene-sex_rough'], ['you-front', 'you-hand-other', 'you-left-other'],
    'the left-hand replacement preserves the right hand');
  assert.equal(controller.execute('you-left-other', controller.getState().sceneToken).ok, true);
  assert.deepEqual(h.selections['scene-sex_rough'], ['you-front', 'you-hand-other'],
    'clicking the active image-only item still turns it off');
  assert.deepEqual(h.selections['scene-anal'], ['you-hand'], 'another situation is preserved');
  assert.deepEqual(h.state, before, 'same-hand switches change no game state');
  h.activeKey = 'scene-anal';
  assert.equal(controller.list().find(item => item.id === 'you-kiss').reason, 'image_context_unavailable',
    'a mismatched portrait context must not receive a scene-specific edit');
}

{
  const { h, controller } = standalone();
  const before = snapshot(h.state), saved = snapshot(h.settings);
  const back = controller.list().find(row => row.id === 'you-back');
  assert.equal(back.provider, 'aip');
  assert.equal(back.available, true, 'same-act pose remains available without husband-life');
  assert.equal(controller.getPose(), null);
  const oldToken = controller.getState().sceneToken;
  h.state.slot++;
  assert.equal(controller.execute('you-back', oldToken).reason, 'stale_scene');
  h.state.slot--;
  assert.deepEqual(controller.execute('you-back', controller.getState().sceneToken),
    { ok: true, pending: false, reason: 'applied' });
  assert.deepEqual(controller.getPose(), { label: '후배위', provider: 'aip', actType: 'sex_rough' });
  assert.equal(controller.list().find(row => row.id === 'you-back').active, true);
  const after = snapshot(h.state);
  assert.deepEqual(after.activeScene.sex.__aipPose,
    { version: 1, label: '후배위', actType: 'sex_rough', characterId: 'wife', startedAtSlot: 420, day: 7 });
  delete after.activeScene.sex.__aipPose;
  assert.deepEqual(after, before, 'pose change preserves cuffs, arousal, time, events, and other mods');
  assert.deepEqual(h.settings, saved);
  assert.deepEqual(h.calls, [], 'same-act pose does not dispatch an unrelated game action');
  assert.equal(controller.execute('you-back', controller.getState().sceneToken).reason, 'already_selected');
  h.state.activeScene.sex.startedAtSlot++;
  assert.equal(controller.getPose(), null, 'the pose cannot leak to a new scene');
  h.state.activeScene.sex.startedAtSlot--;
  h.state.day++;
  assert.equal(controller.getPose(), null, 'the pose cannot leak to another day');
  h.state.day--;
  h.state.activeScene.sex.type = 'riding';
  assert.equal(controller.getPose(), null, 'the pose cannot leak to a different act');
  h.state.activeScene.sex.type = 'sex_rough';
  h.state.activeScene.sex.characterId = 'another';
  assert.equal(controller.getPose(), null, 'the pose cannot leak to another character');
}

{
  const { h, controller } = standalone();
  h.state.mods.badguest.equipment.restraint.active = false;
  const up = controller.list().find(row => row.id === 'you-up');
  assert.equal(up.available, false, 'a different act cannot bypass the game acceptance choice');
  assert.equal(controller.execute('you-up', controller.getState().sceneToken).ok, false);
  assert.equal(h.calls.length, 0);
  h.state.pendingEvent.choices = [{ id: 'switch_to_riding', label: '기승위' }];
  assert.equal(controller.list().find(row => row.id === 'you-up').available, true);
  h.applyAction = false;
  assert.deepEqual(controller.execute('you-up', controller.getState().sceneToken),
    { ok: false, pending: false, reason: 'transition_unconfirmed' });
  assert.equal(h.state.activeScene.sex.__aipPose, undefined, 'a rejected game action cannot set the pose');
  h.applyAction = true; h.resetStart = true;
  assert.deepEqual(controller.execute('you-up', controller.getState().sceneToken),
    { ok: true, pending: false, reason: 'applied' });
  assert.equal(h.state.activeScene.sex.type, 'riding');
  assert.deepEqual(controller.getPose(), { label: '기승위', provider: 'aip', actType: 'riding' });
  assert.equal(h.state.activeScene.sex.__aipPose.startedAtSlot, h.state.slot);
  assert.deepEqual(h.state.mods.badguest.equipment.restraint, { active: false, owner: 'player' });
}

{
  const { h, controller } = standalone();
  h.state.activeScene.patron = fixture().activeScene.patron;
  h.state.pendingEvent.choices = [{ id: 'switch_to_riding', label: '기승위' }];
  const before = snapshot(h.state);
  assert.equal(controller.getState().reason, '', 'an explicit player sex_scene identifies the actor in a dual scene');
  for (const id of ['native:switch_to_riding', 'you-up']) {
    const row = controller.list().find(entry => entry.id === id);
    assert.equal(row.available, false, `${id}: cannot transition the shared scene`);
    assert.equal(row.reason, 'dual_action_conflict');
    assert.equal(controller.execute(id, controller.getState().sceneToken).reason, 'dual_action_conflict');
  }
  assert.deepEqual(h.state, before, 'blocked actions preserve both scenes and restraint state');
  assert.deepEqual(h.calls, [], 'blocked dual-scene actions never reach the game dispatcher');
  assert.equal(controller.list().find(row => row.id === 'you-back').available, true);
  assert.equal(controller.execute('you-back', controller.getState().sceneToken).reason, 'applied');
  const after = snapshot(h.state);
  delete after.activeScene.sex.__aipPose;
  assert.deepEqual(after, before, 'same-act pose preserves the patron, restraints, and all other state');
  h.state.pendingEvent = { type: 'patron_interaction', choices: [] };
  assert.equal(controller.getState().reason, 'actor_conflict', 'an ambiguous dual scene fails closed');
  assert.equal(controller.getPose(), null);
}

for (const shape of ['modern', 'legacy', 'modData']) {
  const { h, controller } = standalone();
  const restraint = { active: true, owner: 'someone-else' };
  if (shape === 'modern') h.state.mods.badguest = { equipment: { restraint } };
  if (shape === 'legacy') h.state.mods.badguest = { restraint };
  if (shape === 'modData') {
    delete h.state.mods.badguest;
    h.state.modData = { BadGuest: { equipment: { restraint } } };
  }
  h.state.pendingEvent.choices = [{ id: 'switch_to_riding', label: '기승위' }];
  for (const id of ['native:switch_to_riding', 'you-up']) {
    assert.equal(controller.list().find(row => row.id === id).available, true, `${shape}: restraints do not hide game actions`);
  }
  assert.equal(controller.execute('native:switch_to_riding', controller.getState().sceneToken).reason, 'applied');
  assert.deepEqual(h.calls.at(-1), { type: 'scene_action', actionId: 'switch_to_riding' });
  assert.deepEqual(restraint, { active: true, owner: 'someone-else' });
}

{
  const { h, controller } = standalone();
  h.husbandProviderPresent = true;
  assert.equal(controller.list().find(row => row.id === 'you-back').available, true);
  assert.equal(controller.execute('you-back', controller.getState().sceneToken).reason, 'applied');
  assert.equal(h.calls.at(-1).actionId, 'act_pose:후배위');
}

{
  const { h, controller } = standalone();
  h.state.pendingEvent.choices = [{ id: 'switch_to_riding', label: '기승위' }];
  h.state.mods.badguest.equipment.restraint.active = false;
  const token = controller.getState().sceneToken;
  assert.equal(controller.list().find(row => row.id === 'native:switch_to_riding').available, true);
  h.state.mods.badguest.equipment.restraint.active = true;
  assert.equal(controller.execute('native:switch_to_riding', token).reason, 'applied',
    'a newly applied restraint does not block a displayed action');
  assert.deepEqual(h.calls.at(-1), { type: 'scene_action', actionId: 'switch_to_riding' });
}

{
  const { h, controller } = standalone();
  h.state.activeScene.patron = fixture().activeScene.patron;
  h.state.activeScene.sex.type = 'inside';
  h.husbandProviderPresent = true;
  for (const mode of ['game', 'force', 'unlock']) {
    h.routeMode = mode;
    const before = snapshot(h.state);
    const row = controller.list().find(entry => entry.id === 'you-back');
    assert.equal(row.available, false, `${mode}: a dual scene cannot take an external transition route`);
    assert.equal(row.reason, 'dual_action_conflict');
    assert.equal(controller.execute('you-back', controller.getState().sceneToken).reason, 'dual_action_conflict');
    assert.deepEqual(h.state, before);
    assert.deepEqual(h.calls, []);
  }
  h.routeMode = 'fits';
  h.state.activeScene.sex.type = 'sex_rough';
  h.state.activeScene.sex.lead = 'her';
  const before = snapshot(h.state);
  assert.equal(controller.list().find(entry => entry.id === 'you-back').available, true);
  assert.equal(controller.execute('you-back', controller.getState().sceneToken).reason, 'applied');
  assert.deepEqual(h.chooseCalls, ['act_pose:후배위']);
  assert.deepEqual(h.calls, [], 'direct pose must not dispatch the outer reducer');
  assert.equal(h.state.activeScene.sex.testPose, '후배위');
  assert.deepEqual(h.state.activeScene.patron, before.activeScene.patron);
  assert.deepEqual(h.state.customers, before.customers);
  assert.deepEqual(h.state.mods, before.mods);
  h.state.activeScene.sex.testPose = '정상위';
  h.state.pendingEvent.sleepActions = {};
  assert.equal(controller.list().find(entry => entry.id === 'you-back').reason, 'dual_action_conflict');
  delete h.state.pendingEvent.sleepActions;
  h.chooseAvailable = false;
  assert.equal(controller.list().find(entry => entry.id === 'you-back').reason, 'dual_action_conflict');
  h.chooseAvailable = true;
  h.onChoose = value => { value.activeScene.patron.customerId = 'changed'; value.mods.other.existing = false; return value; };
  const protectedBefore = snapshot(h.state);
  assert.equal(controller.execute('you-back', controller.getState().sceneToken).reason, 'transition_unconfirmed');
  assert.deepEqual(h.state, protectedBefore, 'mutating external hooks cannot corrupt the original state');
}

{
  const { h, controller } = standalone();
  h.state.pendingEvent.choices = [{ id: 'switch_to_riding', label: '기승위' }];
  h.state.mods.badguest.equipment.restraint.active = false;
  const token = controller.getState().sceneToken;
  assert.equal(controller.list().find(row => row.id === 'native:switch_to_riding').available, true);
  h.state.activeScene.patron = fixture().activeScene.patron;
  const before = snapshot(h.state);
  assert.equal(controller.execute('native:switch_to_riding', token).reason, 'stale_scene',
    'a newly added patron invalidates an earlier single-scene action');
  assert.deepEqual(h.state, before);
  assert.deepEqual(h.calls, []);
}

{
  const { h, controller } = standalone();
  h.state.activeScene.sex.characterId = 'another';
  assert.equal(controller.getState().reason, 'actor_conflict');
  assert.equal(controller.execute('you-back', controller.getState().sceneToken).ok, false);
  h.state.activeScene.sex.characterId = 'wife';
  h.husbandProviderPresent = true; h.husbandThrows = true;
  assert.equal(controller.getState().reason, 'provider_unavailable', 'unknown external ownership fails closed');
  assert.equal(controller.execute('you-back', controller.getState().sceneToken).ok, false);
  assert.equal(h.state.activeScene.sex.__aipPose, undefined);
  h.husbandThrows = false;
  h.state.mods.badguest.equipment.restraint.active = false;
  assert.equal(controller.list().find(row => row.id === 'you-back').provider, undefined,
    'when husband-life owns the scene, its action route retains priority');
  assert.equal(controller.execute('you-back', controller.getState().sceneToken).reason, 'applied');
  assert.equal(h.state.activeScene.sex.__aipPose, undefined, 'the fallback must not overwrite the owning mod');
  assert.equal(h.calls.at(-1).actionId, 'act_pose:후배위');
}

{
  const { h, controller } = standalone();
  const oldState = snapshot(h.state);
  h.onUpdate = () => { h.state.slot++; };
  assert.deepEqual(controller.execute('you-back', controller.getState().sceneToken),
    { ok: false, pending: false, actionApplied: false, reason: 'transition_unconfirmed' },
    'a scene changing just before update must not receive a stale pose');
  assert.equal(h.state.activeScene.sex.__aipPose, undefined);
  h.state = oldState;
  h.onUpdate = () => { h.husbandProviderPresent = true; h.husbandOwns = true; };
  assert.equal(controller.execute('you-back', controller.getState().sceneToken).ok, false,
    'ownership changing just before update must not be overwritten');
  assert.equal(h.state.activeScene.sex.__aipPose, undefined);
}
{
  const { h, controller } = standalone();
  h.state.pendingEvent.choices = [
    { id: 'switch_to_handjob', label: '손으로' },
    { id: 'switch_to_blowjob', label: '입으로' },
    { id: 'switch_to_cunnilingus', label: '口', disabled: true },
    { id: 'switch_to_fingering', label: '손가락' },
  ];
  for (const id of ['handjob', 'blowjob', 'fingering'])
    assert.equal(controller.list().find(row => row.id === `native:switch_to_${id}`).available, true);
  assert.equal(controller.list().find(row => row.id === 'native:switch_to_cunnilingus').available, false);
  assert.equal(controller.execute('native:switch_to_blowjob', controller.getState().sceneToken).reason, 'applied');
  assert.equal(h.calls.at(-1).actionId, 'switch_to_blowjob', 'native actions retain game decision handling');
}

{
  const { h, controller } = standalone();
  h.husbandProviderPresent = true;
  h.state.activeScene.sex.type = 'inside';
  const before = snapshot(h.state);
  assert.ok(controller.list().find(row => row.id === 'hl:caress:kiss').available);
  assert.ok(controller.list().find(row => row.id === 'hl:caress:grope').available);
  assert.equal(controller.execute('hl:caress:kiss', controller.getState().sceneToken).reason, 'applied');
  assert.equal(h.calls.at(-1).actionId, 'act_toggle:kiss');
  assert.deepEqual(h.state.activeScene.sex.testCaress, ['kiss']);
  assert.equal(h.state.slot, before.slot, 'enabling an inside caress is instantaneous');
  assert.equal(controller.list().find(row => row.id === 'hl:caress:kiss').active, true);
  assert.equal(controller.execute('hl:caress:kiss', controller.getState().sceneToken).reason, 'applied');
  assert.equal(h.state.slot, before.slot + 1, 'clicking an active caress performs its normal focused minute');
  assert.equal(controller.execute('hl:caress-off:kiss', controller.getState().sceneToken).reason, 'applied');
  assert.deepEqual(h.state.activeScene.sex.testCaress, []);
  assert.equal(h.calls.at(-1).actionId, 'act_off:kiss');
  h.state.testBlocked = true;
  const caressOrder = controller.list().filter(row => row.id.startsWith('hl:caress:')).map(row => row.id);
  const blocked = controller.list().find(row => row.id === 'hl:caress:grope');
  assert.equal(blocked.available, false);
  assert.equal(blocked.detail, '옷을 조정해 주세요.');
  const count = h.calls.length;
  assert.equal(controller.execute(blocked.id, controller.getState().sceneToken).ok, false);
  assert.equal(h.calls.length, count, 'the owning mod clothing restriction must not be bypassed');
  h.state.activeScene.sex.blocked = true;
  h.state.activeScene.sex.unplaced = true;
  const unavailable = controller.list().find(row => row.id === 'hl:caress:grope');
  assert.ok(unavailable, 'HL rows remain present in the same order even when not placed');
  assert.deepEqual(controller.list().filter(row => row.id.startsWith('hl:caress:')).map(row => row.id), caressOrder);
  assert.equal(unavailable.available, false);
  assert.equal(unavailable.detail, '현재 자세·옷·상태에서 사용할 수 없어요.');
  assert.equal(controller.execute(unavailable.id, controller.getState().sceneToken).ok, false);
  delete h.state.activeScene.sex.blocked; delete h.state.activeScene.sex.unplaced;
  h.state.testBlocked = false;
  h.state.activeScene.sex.type = 'sex_rough';
  assert.equal(controller.execute('hl:caress:grope', controller.getState().sceneToken).reason, 'applied');
  assert.equal(h.calls.at(-1).actionId, 'act_caress:grope', 'foreplay uses the owning mod minute action');
}

{
  const { h, controller } = standalone();
  h.husbandProviderPresent = true;
  h.state.activeScene.sex.type = 'inside';
  h.state.activeScene.patron = fixture().activeScene.patron;
  const patron = snapshot(h.state.activeScene.patron), mods = snapshot(h.state.mods);
  assert.equal(controller.execute('hl:caress:kiss', controller.getState().sceneToken).reason, 'applied');
  assert.equal(h.chooseCalls.at(-1), 'act_toggle:kiss');
  assert.deepEqual(h.state.activeScene.patron, patron);
  assert.deepEqual(h.state.mods, mods);
  assert.equal(controller.list().find(row => row.id === 'hl:caress:kiss').reason, 'dual_action_conflict',
    'focused actions that advance time are not safe in overlapping scenes');
  assert.equal(controller.execute('hl:caress-off:kiss', controller.getState().sceneToken).reason, 'applied');
  assert.equal(h.chooseCalls.at(-1), 'act_off:kiss');
  assert.deepEqual(h.state.activeScene.patron, patron);
  h.onChoose = (state, action) => { state.activeScene.patron.playerEngaged = false; return state; };
  const before = snapshot(h.state);
  assert.equal(controller.execute('hl:caress:grope', controller.getState().sceneToken).reason, 'transition_unconfirmed');
  assert.deepEqual(h.state, before, 'a hook that mutates the patron must not commit');
}
{
  const h = harness('2026-10-24-pre7');
  h.state.activeScene = { sex: { type: 'sex', startedAtSlot: 420 } };
  h.state.pendingEvent = { type: 'sex_scene', choices: [] };
  h.latest.situationId = 'scene-sex'; h.latest.result.key = 'scene-sex';
  h.latest.controllerSceneIdentity = JSON.stringify(['you', 7, 420, null, 'wife', null, null, null]);
  h.husbandProviderPresent = false;
  h.api.settings.set({ positionControllerEnabled: true });
  const controls = h.make(true), before = h.activeKeyReads;
  let display = controls.display();
  assert.equal(h.activeKeyReads - before, 1, 'one display snapshot validates the portrait key only once');
  assert.equal(display.state.imageWarning, '');
  assert.equal(display.entries.find(row => row.id === 'you-kiss').available, true);
  h.activeKey = 'scene-other';
  display = controls.display();
  assert.equal(display.state.imageWarning, 'image_context_unavailable', 'a later changed portrait is rechecked');
  assert.equal(display.entries.find(row => row.id === 'you-kiss').reason, 'image_context_unavailable');
  h.activeKey = 'scene-sex'; h.override = { manual: true };
  display = controls.display();
  assert.equal(display.state.imageWarning, 'image_override_conflict', 'a later changed image override is rechecked');
  h.husbandProviderPresent = true; h.state.testBlocked = true;
  display = controls.display();
  assert.equal(display.entries.find(row => row.id === 'hl:caress:grope').available, false,
    'provider changes and its current restrictions are rechecked on the next display');
}
console.log('position controller API: ok');
module.exports = { harness };
