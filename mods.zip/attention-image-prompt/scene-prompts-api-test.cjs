const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, 'source/scene-prompts-api.js'), 'utf8');
const positive = { 'scene-chat': { positivePrompt: 'talking' } };
const states = { 'scene-chat|abed-1': { 'restraint.handcuffed': { positivePrompt: 'cuffs', negativePrompt: '' } } };
const resolve = entries => id => {
  if (Object.hasOwn(entries, id)) return { id, entry: entries[id] };
  if (id.includes('|sleep-')) return null;
  const base = id.split('|')[0];
  return Object.hasOwn(entries, base) ? { id: base, entry: entries[base] } : null;
};
let candidateToken = '';
const factory = new Function('sceneBaseOverrideSource', 'sceneStatePromptOverrides', 'shortHash', 'sceneCandidateFingerprint',
  'api', 'SCENE_PROMPT_EXAMPLES', 'positionSituationLabel', 'positionSituationId', 'activePortraitImageKey',
  'currentPositionStatePrompts', 'sceneBaseOverrides', 'scenePromptEditorId', 'externalPromptRegistry',
  `${source}\nreturn { get: scenePromptsApiSnapshot, cacheToken: scenePromptsApiCacheToken, list: scenePromptCatalog };`);
const api = factory(resolve(positive), states,
  value => require('node:crypto').createHash('sha256').update(value).digest('hex').slice(0, 12),
  () => candidateToken,
  { has: name => ['gameScenePromptTable', 'gameTaskPromptTable', 'gameLookPromptTable'].includes(name),
    fn: name => ({ gameScenePromptTable: { chat: ['talking'] }, gameTaskPromptTable: { idle: 'standing', idle_bedroom: 'bed', serving: 'serving' },
      gameLookPromptTable: { tits: ['focus'], ass: ['focus'], pussy: ['focus'] } })[name], store: { game: () => ({}) } },
  [['scene-chat', '대화']], id => id, key => key, () => 'task-idle',
  () => ({ 'scene-other|abed-1': {} }), positive, 'scene-other|fin-1',
  new Map([['extra', { entries: [{ label: '모드 장면', target: { kind: 'position-state', id: 'scene-mod-added' } }] }]]));
const catalog = api.list();
assert.ok(catalog.some(entry => entry.id === 'task-sleeping' && entry.category === 'task'));
assert.ok(catalog.some(entry => entry.id === 'task-passed_out' && entry.category === 'task'));
assert.ok(catalog.some(entry => entry.id === 'task-composing' && entry.category === 'task'));
assert.ok(catalog.some(entry => entry.id === 'task-idle' && entry.category === 'task'));
assert.ok(!catalog.some(entry => entry.id === 'task-idle_bedroom'));
assert.ok(catalog.some(entry => entry.id === 'look-tits' && entry.category === 'look'));
assert.ok(catalog.some(entry => entry.id === 'scene-other|abed-1'));
assert.ok(catalog.some(entry => entry.id === 'scene-other|fin-1'));
assert.ok(catalog.some(entry => entry.id === 'scene-mod-added' && entry.label === '모드 장면'));
assert.equal(catalog.filter(entry => entry.id === 'scene-chat').length, 1);
catalog.find(entry => entry.id === 'task-sleeping').label = 'external mutation';
assert.notEqual(api.list().find(entry => entry.id === 'task-sleeping').label, 'external mutation');
assert.equal(api.get('invalid'), null);
assert.equal(api.cacheToken('scene-absent'), '');
candidateToken = 'candidate-change';
assert.notEqual(api.cacheToken('scene-absent'), '');
candidateToken = '';
const id = 'scene-chat|abed-1';
const value = api.get(id);
assert.equal(Object.hasOwn(value, 'baseNegative'), false, 'scene API does not expose a game common Negative override');
assert.deepEqual(value, { situationId: id, basePositive: { sourceId: 'scene-chat', prompt: 'talking' },
  states: { 'restraint.handcuffed': { positivePrompt: 'cuffs', negativePrompt: '' } } });
const first = api.cacheToken(id);
assert.ok(first);
value.basePositive.prompt = 'changed externally';
value.states['restraint.handcuffed'].positivePrompt = 'changed externally';
assert.equal(api.get(id).basePositive.prompt, 'talking');
assert.equal(api.get(id).states['restraint.handcuffed'].positivePrompt, 'cuffs');
assert.equal(api.cacheToken(id), first);
states[id]['restraint.handcuffed'].negativePrompt = 'new negative';
assert.notEqual(api.cacheToken(id), first);
assert.equal(api.get('scene-chat|sleep-deep').basePositive, null);
assert.equal(api.get('scene-chat|sleep-deep').states['restraint.handcuffed'], undefined);
assert.equal(api.cacheToken('scene-chat|sleep-deep'), '');
console.log('scene prompts public API: ok');
