const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const source = fs.readFileSync(require('node:path').join(__dirname, 'source/scene-image-preview.js'), 'utf8');

async function main() {
  let wife = { id: 'wife', shortname: 'wife', name: 'Wife', archetypeId: 'wife-archetype', outfit: 'modest',
    stats: { mood: 10, arousal: 90 } };
  let state = { primaryCharacterId: 'wife', day: 1, slot: 100, characters: { wife },
    activeScene: { sex: { ticksElapsed: 9 }, patron: { stage: 'bold_touch' } } };
  let key = 'wife__scene-patron_chatting__v-0';
  let extra = { positivePrompt: 'custom_scene_positive', negativePrompt: 'custom_scene_negative' };
  let appearance = { positivePrompt: 'wife appearance' };
  let baseFingerprint = 'base-fingerprint';
  let stateFingerprint = 'state-fingerprint';
  let assignedSituation = { prompts: { arousal: 'normal' }, negativePrompts: {} };
  const calls = [], resolvers = [], planArguments = [];
  let feature, sourceThrows = false, imageThrows = false, derivedContext = false, refreshes = 0;
  const win = { el: { isConnected: true }, refresh() { refreshes++; } };
  const api = {
    store: { game: () => state },
    has: name => ['imageGenerate', 'imagePlanCharacter'].includes(name)
      || (derivedContext && ['portraitSceneContext', 'portraitMoodContext', 'portraitFinishContext', 'wifeLocation', 'imageRoom', 'playerSexScene', 'patronScene'].includes(name)),
    fn: name => {
      if (name === 'portraitSceneContext') return () => ({ scene: 'patron_chatting', sceneVariant: 2 });
      if (name === 'wifeLocation') return () => 'bedroom';
      if (name === 'imageRoom') return room => room;
      if (name === 'portraitMoodContext') return () => 'worried';
      if (name === 'portraitFinishContext') return () => 'hiked';
      if (name === 'playerSexScene') return state => state.activeScene.sex;
      if (name === 'patronScene') return state => state.activeScene.patron;
      if (name === 'imagePlanCharacter') return (id, generated) => {
        planArguments.push([id, generated, feature.flags()]);
        return { id: 'sample', shortname: 'sample', stats: { mood: 50, arousal: 0 }, outfit: 'plain', currentTask: 'work' };
      };
      if (name === 'imagePrompt') return (character, room, mood, ticks, patron, finish) => {
        if (sourceThrows) throw new Error('prompt unavailable');
        const flags = feature.flags();
        assert.equal(flags.previewing, true);
        const synthetic = flags.planDepth > 0;
        if (synthetic) {
          assert.equal(character.id, wife.id);
          assert.equal(character.outfit, wife.outfit);
          assert.equal(character.stats.arousal, 0, 'synthetic preview does not copy arousal');
          assert.equal(character.currentTask, 'idle', 'scene preview has a neutral task');
          assert.equal(character.exposure, undefined);
          assert.deepEqual(character.aftermathTags, []);
          assert.equal(room, 'taproom');
        } else {
          assert.equal(character.id, wife.id, 'current preview uses the actual wife');
          assert.equal(character.stats, wife.stats);
          assert.equal(character.sceneOverride, 'patron_chatting', 'captured portrait scene remains intact');
          assert.equal(ticks, 9, 'current scene tick replaces the captured tick');
          assert.equal(patron, state.activeScene.patron, 'current patron replaces the captured patron');
          if (derivedContext) {
            assert.equal(character.sceneVariant, 2);
            assert.equal(room, 'bedroom');
            assert.equal(mood, 'worried');
            assert.equal(finish, 'hiked');
          }
        }
        return { key: `wife__scene-${character.sceneOverride}__v-0`, prompt: synthetic ? 'native scene, wife appearance, outfit'
          : 'current native scene, current state, current mod', negativePrompt: synthetic ? 'native negative' : 'current negative',
          parts: [{ label: '장면', tags: 'native scene' }], genParams: { steps: 8, cfg: 1.5, loraStrength: 1 }, checkpoint: 'model' };
      };
      if (name === 'imageGenerate') return request => {
        calls.push(request);
        if (imageThrows) return Promise.reject(new Error('server offline'));
        return new Promise(resolve => resolvers.push(resolve));
      };
      throw new Error(`unexpected ${name}`);
    },
    ui: { button: (label, onClick, options = {}) => ({ label, onClick, options }) },
  };
  const latest = { characterId: 'wife', result: { key } };
  const factory = new Function('api', 'latestScenePrompt', 'latestPromptArgs', 'activePortraitImageKey',
    'currentPositionStatePrompt', 'sceneBaseOverrideFingerprint', 'sceneStatePromptFingerprint', 'situationConfigForCharacter',
    'currentGameDefaultPrompts', 'currentWifeCharacterPrompt',
    'currentWifePromptContext', 'currentOutfitPrompts', 'currentPromptModRules', 'positionSituationId', 'similarImageSituationKey', 'shortHash',
    'joinPrompt', 'deduplicateFinalRequest', 'applyGlobalPromptExclusions', 'applyPromptModRules', 'alignSleepScenePrompt',
    'replaceNativeFirstExperience', 'promptGenParams', 'diagnosticText', 'cameraPreview', `
      let promptPreviewing = false, imagePlanDepth = 0, sceneBaseOverridePreviewing = false, activeSettingsTab = 'scene-prompts';
      let scenePromptEditorId = 'scene-patron_chatting';
      ${source}
      return { renderSceneImagePreview, generateSceneImagePreview, scenePreviewRequest,
        setScene(value) { scenePromptEditorId = value; }, setTab(value) { activeSettingsTab = value; },
        setFlags(previewing, planDepth) { promptPreviewing = previewing; imagePlanDepth = planDepth; },
        flags() { return { previewing: promptPreviewing, planDepth: imagePlanDepth, basePreviewing: sceneBaseOverridePreviewing }; },
        results() { return sceneImagePreviewResults; } };
    `);
  feature = factory(api, latest, [{ ...wife, sceneOverride: 'patron_chatting', sceneVariant: 0 }, 'taproom', 'shy', 1, { stage: 'old' }], () => key, () => extra, () => baseFingerprint,
    () => stateFingerprint, () => assignedSituation, () => ({}), () => appearance, () => ({}), () => ({}), () => [],
    value => String(value || '').split('__').find(part => /^(scene|task|look)-/.test(part)) || '',
    value => String(value || '').replace(/__v-\d+$/, ''),
    value => crypto.createHash('sha256').update(value).digest('hex').slice(0, 12),
    value => String(value).split(',').map(tag => tag.trim()).filter(Boolean).join(', '),
    value => value, value => value, value => value, value => value, value => value,
    prompt => ({ steps: 8, cfg: 1.5, loraStrength: 1, prompt }), error => String(error.message || error),
    (id, prompt, negativePrompt) => ({ prompt, negativePrompt, shotId: null }));
  const h = (tag, props, ...children) => ({ tag, props, children });
  const initialState = JSON.stringify(state);
  feature.renderSceneImagePreview(h, win, 'scene-patron_chatting', true);
  assert.equal(calls.length, 0, 'rendering never generates an image');

  let pending = feature.generateSceneImagePreview('current', 'scene-patron_chatting', true, win);
  assert.equal(calls.length, 1);
  await feature.generateSceneImagePreview('scene', 'scene-patron_chatting', true, win);
  assert.equal(calls.length, 1, 'a second click while generating does not start another request');
  assert.match(calls[0].prompt, /current state/);
  assert.match(calls[0].prompt, /current mod/);
  assert.match(calls[0].negativePrompt, /current negative/);
  assert.match(calls[0].imageKey, /^aip_scene_preview_/);
  assert.equal(calls[0].bypassCache, true);
  assert.deepEqual(feature.flags(), { previewing: false, planDepth: 0, basePreviewing: false }, 'flags restore before awaiting the server');
  resolvers.shift()({ url: 'https://image/current.webp' }); await pending;
  assert.equal(feature.results().current.url, 'https://image/current.webp');
  assert.equal(JSON.stringify(state), initialState, 'current preview does not change game state');

  pending = feature.generateSceneImagePreview('scene', 'scene-patron_chatting', true, win);
  assert.equal(calls.length, 2);
  assert.match(calls[1].prompt, /native scene/);
  assert.match(calls[1].prompt, /wife appearance/);
  assert.match(calls[1].prompt, /outfit/);
  assert.match(calls[1].prompt, /custom_scene_positive/);
  assert.match(calls[1].negativePrompt, /custom_scene_negative/);
  assert.doesNotMatch(calls[1].prompt, /current state|current mod/);
  assert.notEqual(calls[0].imageKey, calls[1].imageKey);
  assert.equal(planArguments[0][0], 'wife-archetype');
  assert.equal(planArguments[0][2].planDepth, 1);
  assert.equal(planArguments[0][2].basePreviewing, true, 'scene base overrides apply in synthetic previews');
  resolvers.shift()({ url: 'https://image/scene.webp' }); await pending;
  assert.equal(feature.results().scene.url, 'https://image/scene.webp');
  assert.equal(feature.results().current.url, 'https://image/current.webp', 'both previews remain independently visible');
  assert.equal(JSON.stringify(state), initialState, 'synthetic preview does not change game state');

  derivedContext = true;
  latest.result.key = 'wife__scene-old__v-0';
  pending = feature.generateSceneImagePreview('current', 'scene-patron_chatting', true, win);
  assert.equal(calls.length, 3, 'native state-derived context works without a current captured prompt');
  resolvers.shift()({ url: 'https://image/current-derived.webp' }); await pending;
  assert.equal(feature.results().current.url, 'https://image/current-derived.webp');
  latest.result.key = key;
  derivedContext = false;
  key = 'wife__scene-other__v-0';
  await feature.generateSceneImagePreview('current', 'scene-patron_chatting', true, win);
  assert.equal(calls.length, 3, 'stale active key cannot generate current scene');
  assert.match(feature.results().current.error, /현재 장면/);
  key = 'wife__scene-patron_chatting__v-0';
  feature.setFlags(false, 0);
  assert.throws(() => feature.scenePreviewRequest('scene', 'scene-patron_chatting|sleep-asleep', true, state, wife), /기본 장면/);
  assert.throws(() => feature.scenePreviewRequest('scene', 'look-tits', true, state, wife), /반응/);
  assert.deepEqual(feature.flags(), { previewing: false, planDepth: 0, basePreviewing: false });
  sourceThrows = true;
  assert.throws(() => feature.scenePreviewRequest('scene', 'scene-patron_chatting', true, state, wife), /prompt unavailable/);
  assert.deepEqual(feature.flags(), { previewing: false, planDepth: 0, basePreviewing: false }, 'errors restore preview flags');
  feature.setFlags(true, 7);
  assert.throws(() => feature.scenePreviewRequest('scene', 'scene-patron_chatting', true, state, wife), /prompt unavailable/);
  assert.deepEqual(feature.flags(), { previewing: true, planDepth: 7, basePreviewing: false }, 'nested preview flags also restore');
  feature.setFlags(false, 0);
  sourceThrows = false;

  pending = feature.generateSceneImagePreview('scene', 'scene-patron_chatting', true, win);
  feature.setScene('scene-patron_bold');
  feature.renderSceneImagePreview(h, win, 'scene-patron_bold', false);
  resolvers.shift()({ url: 'https://image/old.webp' }); await pending;
  assert.equal(feature.results().scene, undefined, 'old request cannot overwrite the new scene');
  feature.setScene('scene-patron_chatting');
  feature.renderSceneImagePreview(h, win, 'scene-patron_chatting', true);
  pending = feature.generateSceneImagePreview('scene', 'scene-patron_chatting', true, win);
  appearance = { positivePrompt: 'edited appearance' };
  resolvers.shift()({ url: 'https://image/old-appearance.webp' }); await pending;
  assert.equal(feature.results().scene, undefined, 'an appearance edit invalidates an in-flight preview');
  pending = feature.generateSceneImagePreview('scene', 'scene-patron_chatting', true, win);
  baseFingerprint = 'edited-base';
  resolvers.shift()({ url: 'https://image/old-base.webp' }); await pending;
  assert.equal(feature.results().scene, undefined, 'a base prompt edit invalidates an in-flight preview');
  pending = feature.generateSceneImagePreview('scene', 'scene-patron_chatting', true, win);
  stateFingerprint = 'edited-state';
  resolvers.shift()({ url: 'https://image/old-state.webp' }); await pending;
  assert.equal(feature.results().scene, undefined, 'a scene-specific state edit invalidates an in-flight preview');
  pending = feature.generateSceneImagePreview('scene', 'scene-patron_chatting', true, win);
  assignedSituation = { prompts: { arousal: 'edited' }, negativePrompts: {} };
  resolvers.shift()({ url: 'https://image/old-preset.webp' }); await pending;
  assert.equal(feature.results().scene, undefined, 'an assigned character preset edit invalidates an in-flight preview');
  pending = feature.generateSceneImagePreview('scene', 'scene-patron_chatting', true, win);
  const priorRefreshes = refreshes;
  win.el.isConnected = false;
  resolvers.shift()({ url: 'https://image/closed.webp' }); await pending;
  assert.equal(refreshes, priorRefreshes, 'closed windows do not refresh');
  assert.equal(feature.results().scene, undefined, 'closed windows do not retain a loading result');
  win.el.isConnected = true;
  imageThrows = true;
  await feature.generateSceneImagePreview('scene', 'scene-patron_chatting', true, win);
  assert.match(feature.results().scene.error, /server offline/);
  console.log('scene image preview: ok');
}

main().catch(error => { console.error(error); process.exitCode = 1; });
