const assert = require('node:assert/strict');
const fs = require('node:fs');
const source = fs.readFileSync(require('node:path').join(__dirname, 'source/portrait-fresh-variants.js'), 'utf8');
const code = source.slice(0, source.indexOf('    async function portraitFreshVariantKey('));
const missing = { url: 'placeholder', imageMatchingMissing: true };

function fixture(options = {}) {
  const key = 'wife__task-idle__v-0';
  let now = 0, calls = 0, waits = 0, scene = key, character = 'wife', off = options.offline === true;
  let settings = { imageBackendMode: options.mode || 'auto', imageBackendUrl: options.url || '' };
  let connection = { baseUrl: options.noBase ? null : 'http://127.0.0.1:2700', comfyui: options.connected !== false };
  let releaseProbe, forgotten = 0;
  const probeGate = options.gated ? new Promise(resolve => { releaseProbe = resolve; }) : null;
  const probes = [], hooks = [], settingsStore = { getState: () => settings };
  const api = { has: name => ['imageGenerate', 'currentPortraitImageKey'].includes(name)
      || options.supportsProbe === true && ['imageBackendProbe', 'imageBackendForget', 'imageAutoProbeAllowed'].includes(name),
    fn: name => {
      if (name === 'currentPortraitImageKey') return () => scene;
      if (name === 'imageAutoProbeAllowed') return () => options.allowAuto !== false;
      if (name === 'imageBackendForget') return () => { forgotten++; connection = { baseUrl: null, comfyui: false }; };
      if (name === 'imageBackendProbe') return async (prefs, force) => {
        assert.equal(force, true); probes.push({ ...prefs });
        if (probeGate && probes.length === 1) await probeGate;
        if (options.onProbe) settings = options.onProbe({ ...settings }, probes.length);
        connection = prefs.mode === 'off' ? { baseUrl: null, comfyui: false }
          : { baseUrl: prefs.url || 'http://127.0.0.1:2700', comfyui: options.probeHealthy === true };
        return connection;
      };
      throw Error('unexpected API: ' + name);
    }, store: { game: () => ({ primaryCharacterId: character }) },
    hook: (name, spec) => hooks.push(spec) };
  const bridge = { connection: () => connection,
    generationUnavailable: async () => { if (options.changeDuringProbe) scene = 'wife__task-sleeping__v-0';
      if (options.offDuringProbe) global.__WW_STUDIO_OFFLINE_ONLY__ = true; return options.busyUntil > now; } };
  const global = { __WW_STUDIO_OFFLINE_ONLY__: off, WW_ImageStudioBridge: bridge, WW_ImageStudio: { isBusy: () => options.studioBusy === true } };
  const delay = callback => { now += 1000; waits++; if (options.changeAt <= now) scene = 'wife__task-sleeping__v-0';
    if (options.changeCharacterAt <= now) character = 'other'; if (options.offAt <= now) global.__WW_STUDIO_OFFLINE_ONLY__ = true; callback(); };
  const internals = new Function('api', 'globalThis', 'settingsStore', 'similarImageSituationKey', 'Date', 'setTimeout', code + '\nreturn { recheckStudioBackend };')(
    api, global, settingsStore, value => value.replace(/__v-\d+$/, ''), { now: () => now }, delay);
  const request = { imageKey: key, debug: { stats: {} } };
  const next = () => { calls++; return options.cached || (calls > 1 && !options.alwaysMissing) ? { url: 'image', key } : missing; };
  return { run: patch => hooks.at(-1).around(next, { ...request, ...patch }), recheck: internals.recheckStudioBackend, probes,
    release: () => releaseProbe?.(), setSettings: value => { settings = { ...settings, ...value }; },
    setScene: value => { scene = value; }, setCharacter: value => { character = value; }, setOffline: value => { off = value; global.__WW_STUDIO_OFFLINE_ONLY__ = value; },
    get calls() { return calls; }, get waits() { return waits; }, get connection() { return connection; }, get forgotten() { return forgotten; } };
}

async function waitForProbe(f) { for (let i = 0; !f.probes.length && i < 20; i++) await Promise.resolve(); assert.ok(f.probes.length); }

(async () => {
  const busy = fixture({ busyUntil: 3000 });
  assert.equal((await busy.run()).url, 'image'); assert.equal(busy.calls, 2); assert.equal(busy.waits, 3);
  const concurrent = fixture({ busyUntil: 2000 });
  const [a, b] = await Promise.all([concurrent.run(), concurrent.run()]);
  assert.equal(a.url, 'image'); assert.equal(b.url, 'image'); assert.equal(concurrent.calls, 2);
  const manual = fixture();
  const automatic = manual.run();
  await manual.run({ bypassCache: true });
  assert.equal(await automatic, null);
  for (const options of [{ changeAt: 1000 }, { changeCharacterAt: 1000 }, { changeDuringProbe: true }]) {
    const f = fixture(options); assert.equal(await f.run(), null); assert.equal(f.calls, 1);
  }
  for (const options of [{ offAt: 1000 }, { offDuringProbe: true }, { connected: false }, { busyUntil: Infinity }]) {
    const f = fixture(options); assert.equal((await f.run()).url, 'placeholder'); assert.equal(f.calls, 1);
  }
  const cached = fixture({ cached: true }); assert.equal((await cached.run()).url, 'image'); assert.equal(cached.waits, 0);
  const offline = fixture({ offline: true }); assert.equal((await offline.run()).url, 'placeholder'); assert.equal(offline.calls, 1); assert.equal(offline.waits, 0);
  const failed = fixture({ alwaysMissing: true }); assert.equal((await failed.run()).url, 'placeholder'); assert.equal(failed.calls, 4);
  const other = fixture(); assert.equal((await other.run({ debug: { source: 'other', stats: {} } })).url, 'placeholder'); assert.equal(other.waits, 0);
  const explicit = fixture(); assert.equal((await explicit.run({ bypassCache: true })).url, 'placeholder'); assert.equal(explicit.waits, 0);

  for (const options of [{ connected: false }, { noBase: true }, { connected: false, mode: 'custom', url: 'http://127.0.0.1:7777' }]) {
    const f = fixture({ ...options, supportsProbe: true, probeHealthy: true });
    assert.equal((await f.run()).url, 'image'); assert.equal(f.probes.length, 1); assert.equal(f.calls, 2);
    if (options.url) assert.equal(f.probes[0].url, options.url);
  }
  for (const options of [{ offline: true }, { mode: 'off' }, { allowAuto: false }, { mode: 'custom', url: '' }, { studioBusy: true }]) {
    const f = fixture({ ...options, connected: false, supportsProbe: true, probeHealthy: true });
    assert.equal((await f.run()).url, 'placeholder'); assert.equal(f.probes.length, 0);
  }
  const unhealthy = fixture({ connected: false, supportsProbe: true, probeHealthy: false });
  assert.equal((await unhealthy.run()).url, 'placeholder'); assert.equal(unhealthy.probes.length, 1);

  const shared = fixture({ supportsProbe: true, gated: true });
  const sharedOne = shared.recheck(), sharedTwo = shared.recheck();
  assert.equal(sharedOne, sharedTwo, 'concurrent requests share one backend probe');
  await waitForProbe(shared); shared.release(); await Promise.all([sharedOne, sharedTwo]); assert.equal(shared.probes.length, 1);

  for (const change of ['scene', 'character', 'offline']) {
    const f = fixture({ connected: false, supportsProbe: true, probeHealthy: true, gated: true });
    const task = f.run(); await waitForProbe(f);
    if (change === 'scene') f.setScene('wife__task-sleeping__v-0');
    if (change === 'character') f.setCharacter('other');
    if (change === 'offline') f.setOffline(true);
    f.release(); assert.equal(await task, change === 'offline' ? missing : null); assert.equal(f.calls, 1);
  }
  for (const nextSettings of [{ imageBackendMode: 'off' }, { imageBackendMode: 'custom', imageBackendUrl: 'http://127.0.0.1:9999' }]) {
    const f = fixture({ connected: false, supportsProbe: true, probeHealthy: true, gated: true });
    const task = f.run(); await waitForProbe(f); f.setSettings(nextSettings); f.release();
    assert.equal(await task, missing); assert.equal(f.calls, 1); assert.equal(f.probes.length, 2);
    assert.equal(f.probes[1].mode, nextSettings.imageBackendMode);
    if (nextSettings.imageBackendUrl) assert.equal(f.connection.baseUrl, nextSettings.imageBackendUrl);
    else assert.equal(f.connection.baseUrl, null);
  }
  const changing = fixture({ connected: false, supportsProbe: true, probeHealthy: true,
    onProbe: (settings, count) => ({ ...settings, imageBackendUrl: 'http://127.0.0.1:' + (3000 + count) }) });
  assert.equal(await changing.run(), missing); assert.equal(changing.probes.length, 3); assert.equal(changing.forgotten, 1);
  console.log('studio portrait placeholder retry: ok');
})().catch(error => { console.error(error); process.exitCode = 1; });
