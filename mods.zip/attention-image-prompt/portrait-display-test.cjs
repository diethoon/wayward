const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const mod = fs.readFileSync(`${__dirname}/source/prompt-mod-rules.js`, 'utf8');
const wml = fs.readFileSync(`${__dirname}/source/mod.wml.js`, 'utf8');
const browser = fs.readFileSync(`${__dirname}/source/image-browser.js`, 'utf8');
const dedup = mod.slice(mod.indexOf('    function deduplicatePrompt(value)'), mod.indexOf('    function withoutPromptTags'));
const display = browser.slice(browser.indexOf('    function portraitDisplayParts(parts)'), browser.indexOf('    function syncMountedPortrait('));
const tag = mod.slice(mod.indexOf('    function updatePortraitTagNode('), mod.indexOf('    function decoratePortraitPromptTags('));
assert.ok(dedup && display && tag);
const ctx = vm.createContext({ nativeFreshPrompts: new Map(), accessorySituationCode: key => key.replace(/__v-\d+$/, ''),
  translatedPromptText: text => `ko:${text}` });
vm.runInContext(`${dedup}\n${display}\n${tag}`, ctx);
const joinSource = wml.match(/const gameJoinPrompt = api\.fn\('promptJoin'\);\s*const joinPrompt = [^;]+;/);
assert.ok(joinSource, 'AIP must preserve weighted tags before the game prompt join');
ctx.api = { fn(name) { assert.equal(name, 'promptJoin'); return value => {
  const seen = new Set();
  return value.split(',').map(tag => tag.trim()).filter(Boolean).filter(tag => {
    const key = tag.toLowerCase().replace(/[()]/g, '').replace(/:[0-9.]+/g, '').trim();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).join(', ');
}; } };
vm.runInContext(`${joinSource[0]}\nglobalThis.testJoinPrompt = joinPrompt;`, ctx);
assert.equal(ctx.testJoinPrompt('hetero, (hetero:1.2), sex'), '(hetero:1.2), sex');
assert.equal(ctx.testJoinPrompt('probe_negative, (probe_negative:1.4)'), '(probe_negative:1.4)');
assert.equal(ctx.testJoinPrompt('hetero, (hetero:-0.5)'), '(hetero:-0.5)');
assert.equal(ctx.testJoinPrompt('style=anime, (red, blue:1.2)'), 'style=anime, (red, blue:1.2)');
assert.throws(() => ctx.testJoinPrompt(undefined));

const original = { key: 'pippa__scene-sex', prompt: 'hetero, sex, (hetero:1.2)',
  negativePrompt: 'bad, bad', parts: [{ label: '현재 체위', tags: 'hetero, sex' },
    { label: '게임 행위', tags: '(hetero:1.2), vaginal' }] };
let renders = 0;
const shown = { memoizedState: original, queue: { dispatch(value) { renders++; shown.memoizedState = value; } } };
const source = { memoizedState: [original], next: null };
shown.next = source;
const portrait = { __reactFiberTest: { memoizedState: shown }, querySelector: () => null,
  querySelectorAll: () => [] };
ctx.syncNativePortraitPrompt(portrait);
assert.equal(renders, 1);
assert.equal(shown.memoizedState.prompt, '(hetero:1.2), sex');
assert.equal(shown.memoizedState.negativePrompt, 'bad');
assert.equal(shown.memoizedState.parts[0].tags, 'sex');
assert.equal(shown.memoizedState.parts[1].tags, '(hetero:1.2), vaginal');
assert.equal(original.parts[0].tags, 'hetero, sex', 'display must not change source parts');
ctx.syncNativePortraitPrompt(portrait);
assert.equal(renders, 1, 'the same display must not dispatch repeatedly');
source.memoizedState = [{ ...original, prompt: 'new, new', parts: [{ label: '새 장면', tags: 'new, new' }] }];
shown.memoizedState = source.memoizedState[0];
ctx.syncNativePortraitPrompt(portrait);
assert.equal(renders, 2);
assert.equal(shown.memoizedState.parts[0].tags, 'new');
ctx.syncNativePortraitPrompt(portrait);
assert.equal(renders, 2, 'the refreshed scene must settle');
const savedVariant = { key: `${original.key}__v-2`, prompt: 'saved, hetero, (hetero:1.3)',
  negativePrompt: 'variant_bad, variant_bad', parts: [{ label: '변형 체위', tags: 'hetero, saved' },
    { label: '변형 행위', tags: '(hetero:1.3), variant' }] };
shown.memoizedState = savedVariant;
ctx.syncNativePortraitPrompt(portrait);
assert.equal(renders, 3);
assert.equal(shown.memoizedState.key, savedVariant.key, 'preserve the selected variant');
assert.equal(shown.memoizedState.prompt, 'saved, (hetero:1.3)');
assert.equal(shown.memoizedState.negativePrompt, 'variant_bad');
assert.equal(shown.memoizedState.parts[0].tags, 'saved');
assert.equal(shown.memoizedState.parts[1].tags, '(hetero:1.3), variant');
assert.equal(savedVariant.parts[0].tags, 'hetero, saved', 'do not mutate variant data');
ctx.syncNativePortraitPrompt(portrait);
assert.equal(renders, 3, 'the cleaned variant must settle');
const manualSameKey = { ...original, prompt: 'manual, manual', parts: [{ label: '수동', tags: 'manual, manual' }] };
shown.memoizedState = manualSameKey;
ctx.syncNativePortraitPrompt(portrait);
assert.equal(shown.memoizedState.prompt, 'manual', 'same-key manual prompt must not be replaced by the current scene');

const attributes = new Map();
const node = { textContent: 'hetero', title: '', hasAttribute: key => attributes.has(key),
  getAttribute: key => attributes.get(key) ?? null, setAttribute: (key, value) => attributes.set(key, value) };
ctx.updatePortraitTagNode(node, 'ko');
assert.equal(node.textContent, 'ko:hetero');
ctx.updatePortraitTagNode(node, 'en');
assert.equal(node.textContent, 'hetero');
node.textContent = 'new scene';
ctx.updatePortraitTagNode(node, 'ko');
assert.equal(node.textContent, 'ko:new scene', 'React-reused nodes must not restore the old scene');
ctx.updatePortraitTagNode(node, 'en');
assert.equal(node.textContent, 'new scene');

const compat = mod.slice(mod.indexOf('    function updateCompatiblePortraitTagNode('), mod.indexOf('    function decoratePortraitPromptTags('));
assert.ok(compat);
ctx.normalizeCustomTags = value => value || [];
ctx.localStorage = { getItem: () => '{}' };
ctx.document = { createElement: () => {
  const attrs = new Map();
  return { style: {}, className: '', textContent: '', title: '',
    setAttribute: (key, value) => attrs.set(key, value), hasAttribute: key => attrs.has(key) };
} };
vm.runInContext(compat, ctx);
const legacyAttrs = new Map([['data-attention-image-prompt-original', 'old tags']]);
const legacy = { textContent: 'old tags', className: 'text-stone-300', style: {}, nextElementSibling: null,
  getAttribute: key => legacyAttrs.get(key) ?? null, setAttribute: (key, value) => legacyAttrs.set(key, value),
  insertAdjacentElement: (_, value) => { legacy.nextElementSibling = value; } };
ctx.updateCompatiblePortraitTagNode(legacy, 'ko', { textContent: '태그 표시: 영문' });
assert.equal(legacy.nextElementSibling.textContent, 'ko:old tags');
assert.equal(legacy.style.display, 'none');
legacy.textContent = 'new tags';
ctx.updateCompatiblePortraitTagNode(legacy, 'ko', { textContent: '태그 표시: 영문' });
assert.equal(legacyAttrs.get('data-attention-image-prompt-original'), 'new tags', 'prevent the old editor restoring stale source');
assert.equal(legacy.nextElementSibling.textContent, 'ko:new tags');
legacy.textContent = 'ko:new tags';
ctx.updateCompatiblePortraitTagNode(legacy, 'en', { textContent: '태그 표시: 한글' });
assert.equal(legacy.nextElementSibling.textContent, 'new tags', 'the old editor translation is not mistaken for new source');

const decorate = mod.slice(mod.indexOf('    function decoratePortraitPromptTags('), mod.indexOf('    function openPositionQuickWindow('));
let customReads = 0, languageReads = 0, updated = 0;
const summaryNode = { textContent: 'summary' }, toggleNode = { textContent: '태그 표시: 한글' };
const overlay = { querySelector: selector => selector.includes('summary') ? summaryNode : toggleNode,
  querySelectorAll: () => [] };
const heading = { textContent: '원본 자동 태그 (+)', parentElement: { parentElement: overlay,
  querySelectorAll: () => Array.from({ length: 12 }, () => ({})) } };
const uiContext = vm.createContext({ document: { querySelectorAll: () => [] },
  portraitTagLanguage: () => { languageReads++; return 'ko'; },
  currentCustomTags: () => { customReads++; return []; }, loadedPromptModOwners: () => new Set(),
  portraitStateSummary: () => 'summary', updatePortraitTagNode: () => { updated++; } });
vm.runInContext(decorate, uiContext);
uiContext.decoratePortraitPromptTags();
assert.equal(languageReads, 0, 'unrelated screen changes do not read language settings');
uiContext.document.querySelectorAll = () => [heading];
uiContext.decoratePortraitPromptTags();
assert.equal(customReads, 1, 'custom tag settings are read once for the whole portrait');
assert.equal(updated, 12);
console.log('portrait prompt display: ok');
