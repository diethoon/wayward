const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const { execFileSync } = require('node:child_process');

execFileSync(process.execPath, [`${__dirname}/source/build.mjs`, '--check']);
execFileSync(process.execPath, [`${__dirname}/prompt-dedup-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/global-exclusion-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/prompt-tag-search-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/tag-search-ui-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/camera-presets-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/camera-core-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/camera-all-angles-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/camera-ui-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/short-image-keys-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/portrait-display-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/offline-cache-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/portrait-offline-button-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/position-console-panel-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/position-console-performance-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/position-portrait-performance-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/studio-busy-generation-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/studio-portrait-retry-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/two-hands-prompt-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/manual-action-priority-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/position-auto-default-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/anal-anatomy-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/scene-prompt-key-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/scene-prompt-ui-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/button-prompts-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/scene-native-prompts-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/scene-base-overrides-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/scene-candidate-pool-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/scene-prompts-api-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/scene-image-preview-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/current-state-editor-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/prompt-mod-fingerprint-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/similar-preview-offline-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/position-controller-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/first-experience-creation-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/portrait-fresh-variants-test.cjs`]);
execFileSync(process.execPath, [`${__dirname}/generation-weight-test.cjs`]);

let mod;
let exportedText = '';
let exportClicked = false;
let exportFilename = '';
let openedSettingsWindow;
const fixtureWindows = new Set();
let pauseEntry;
let pauseSettingsButton;
let pauseButtonInsertions = 0;
let pauseObserverCallback;
let copiedText = '';
let portraitLanguageButton;
let portraitReviewButton;
let portraitScenePromptButton;
let portraitCameraButton;
let portraitSummaryPanel;
let portraitPositionButton;
let portraitSimilarButton;
let portraitNativeAddClicks = 0;
let portraitButtonTextWrites = 0;
let animationFrameCallback;
let animationFrameRequests = 0;
let savedWives = [];
const preGenerateCharacters = ['elena', 'mara', 'pippa'];
let generatedRequests = [];
let storeUpdates = 0;
let storeListener;
let randomValue = 0;
let activePortraitKey = '';
let promptInputByContext = null;
let imageManifestEntries = {};
let imageLookupExtraEntries = {};
let localCacheFixture = { version: 1, entries: {} };
let savedImagePackFile;
const legacyCacheFixture = { version: 1, entries: {} };
const imageGenerationInFlight = new Map();
let imageManifestResets = 0;
let completeImagePackLoad;
let failVariantSave = false;
let dropCharacterPromptWrites = false;
let relativeImageUrls = false;
const fetchedUrls = [];
const serverRequestFetches = [];
const serverRequestResponse = { ok: true, status: 200 };
const serverRequestError = new Error('test fetch error');
const imageProbeUrls = [];
const batchRequests = [];
const hStatusImg2ImgRequests = [];
let secretSections = [];
let secretFullscreenImage = null;
let secretFullscreenOverlay = null;
let secretModeToolbar = null;
let imageStudioLaunch = null;
let controllerDomButtons = [];
let controllerPanels = [];
let documentClickListener;
const imageVariantStates = {};
const testMath = Object.create(Math);
testMath.random = () => randomValue;
class FakeBlob {
  constructor(parts, options) {
    this.parts = parts;
    this.options = options;
  }
}
class FakeFileReader {
  readAsDataURL() {
    this.result = 'data:image/webp;base64,dGVzdA==';
    this.onload?.();
  }
}
const gameSettingsButton = {
  className: 'game-settings-button',
  textContent: '설정',
  insertAdjacentElement(position, node) {
    assert.equal(position, 'afterend');
    pauseSettingsButton = node;
    pauseButtonInsertions += 1;
  },
};
const secretRoot = {
  querySelector(selector) {
    return selector === '[data-attention-hstatus-generation-modes]' ? secretModeToolbar : null;
  },
  prepend(node) { secretModeToolbar = node; },
};
const pauseRoot = {
  querySelector(selector) {
    return selector === '[data-attention-image-prompt-settings]' ? pauseSettingsButton : null;
  },
  querySelectorAll(selector) {
    return selector === 'button' ? [gameSettingsButton] : [];
  },
};
const pauseHeading = {
  textContent: '일시 정지',
  closest(selector) { return selector === '.fixed' ? pauseRoot : null; },
};
const portraitTagNode = value => ({
  textContent: value,
  title: '',
  attributes: {},
  hasAttribute(name) { return Object.prototype.hasOwnProperty.call(this.attributes, name); },
  getAttribute(name) { return this.attributes[name] ?? null; },
  setAttribute(name, value) { this.attributes[name] = value; },
});
const portraitBuiltInTag = portraitTagNode('hands_behind_back, handcuffed');
const portraitCustomTag = portraitTagNode('user_pose_tag');
const portraitSceneTag = portraitTagNode('(tavern interior:1.2), shy, warm candlelight, white blouse, standing');
const portraitNegativeTag = portraitTagNode('shackles');
const portraitOverlay = {
  querySelector(selector) {
    if (selector === '[data-attention-image-prompt-language]') return portraitLanguageButton;
    if (selector === '[data-attention-image-prompt-summary]') return portraitSummaryPanel;
    if (selector === '[data-attention-prompt-review]') return portraitReviewButton;
    if (selector === '[data-attention-scene-prompt-entry]') return portraitScenePromptButton;
    if (selector === '[data-attention-camera-entry]') return portraitCameraButton;
    return null;
  },
  appendChild(node) { portraitReviewButton = node; },
  prepend(node) { portraitScenePromptButton = node; },
  querySelectorAll(selector) {
    return selector === 'div > span.text-stone-500.ml-3' ? [portraitNegativeTag] : [];
  },
};
const portraitPartsRoot = {
  parentElement: portraitOverlay,
  querySelectorAll(selector) {
    return selector === 'div > span.text-stone-300' ? [portraitBuiltInTag, portraitCustomTag, portraitSceneTag] : [];
  },
};
const portraitHeading = {
  textContent: '원본 자동 태그 (+)',
  parentElement: portraitPartsRoot,
  insertAdjacentElement(position, node) {
    assert.equal(position, 'afterend');
    portraitLanguageButton = node;
  },
};
const portraitNativeAddListeners = [];
const portraitNativeAddButton = {
  title: '현재 상태의 다른 이미지 추가(현재 이미지는 유지하며, 화살표로 선택)',
  addEventListener(type, listener, capture) {
    if (type === 'click' && capture) portraitNativeAddListeners.push(listener);
  },
  click() {
    let stopped = false;
    const event = {
      preventDefault() {}, stopPropagation() { stopped = true; }, stopImmediatePropagation() { stopped = true; },
    };
    for (const listener of portraitNativeAddListeners) listener(event);
    if (!stopped) portraitNativeAddClicks += 1;
  },
};
const portraitActionBar = {
  querySelector(selector) {
    if (selector === '[data-attention-position-quick]') return portraitPositionButton;
    if (selector === '[data-attention-similar-images]') return portraitSimilarButton;
    if (selector === '[data-attention-scene-prompt-entry]') return portraitScenePromptButton;
    if (selector === '[data-attention-camera-entry]') return portraitCameraButton;
    return null;
  },
  querySelectorAll(selector) {
    return selector === 'button' ? [portraitNativeAddButton] : [];
  },
  prepend(node) {
    if (Object.prototype.hasOwnProperty.call(node.attributes, 'data-attention-similar-images')) portraitSimilarButton = node;
    else if (Object.prototype.hasOwnProperty.call(node.attributes, 'data-attention-scene-prompt-entry')) portraitScenePromptButton = node;
    else if (Object.prototype.hasOwnProperty.call(node.attributes, 'data-attention-camera-entry')) portraitCameraButton = node;
    else portraitPositionButton = node;
    node.parentElement = this;
  },
};
const portraitImage = {
  alt: 'elena - patron scene',
  src: 'https://example.test/original-visible-position.webp',
  currentSrc: '',
};
const vmContext = {
  WML: { define(value) { mod = value; } },
  Blob: FakeBlob,
  TextEncoder,
  FileReader: FakeFileReader,
  Image: class {
    set src(url) {
      imageProbeUrls.push(String(url));
      queueMicrotask(() => String(url).includes('/head-blocked-missing.webp') ? this.onerror?.() : this.onload?.());
    }
  },
  setTimeout,
  clearTimeout,
  fetch(url, options = {}) {
    const value = String(url?.url || url);
    if (value.includes('/api/image/generate')) {
      const recorded = { receiver: this, url, options };
      serverRequestFetches.push(recorded);
      if (options.testThrow) throw serverRequestError;
      return (recorded.promise = Promise.resolve(serverRequestResponse));
    }
    return (async () => {
    fetchedUrls.push(value);
    if (value.includes('/images/.image-cache.json')) return { ok: true, status: 200, async json() { return localCacheFixture; } };
    if (options.method === 'HEAD' && value.includes('/missing.webp')) return { ok: false, status: 404 };
    if (options.method === 'HEAD' && value.includes('/head-blocked-')) throw new TypeError('HEAD blocked');
    if (value.includes('/api/image/hstatus-img2img')) {
      hStatusImg2ImgRequests.push(JSON.parse(options.body));
      return { ok: true, status: 200, async json() { return { status: 'complete', imageUrl: `/images/hstatus-${hStatusImg2ImgRequests.length}.webp` }; } };
    }
    if (value.includes('/api/batch/enqueue')) {
      const body = JSON.parse(options.body);
      batchRequests.push(body);
      return { ok: true, status: 200, async json() { return { accepted: body.items.length, alreadyCached: 0, jobId: 'custom-wife-job' }; } };
    }
    if (value.includes('/images/')) {
      return { ok: true, status: 200, async blob() { return new FakeBlob(['test'], { type: 'image/webp' }); } };
    }
      throw new Error(`unexpected fetch: ${value}`);
    })();
  },
  CustomEvent: class { constructor(type) { this.type = type; } },
  Math: testMath,
  URL: class extends URL {
    static createObjectURL(blob) {
      exportedText = blob.parts.join('');
      return 'blob:test';
    }
    static revokeObjectURL() {}
  },
  Request,
  location: { href: 'https://game.example.test/index.html' },
  document: {
    addEventListener(type, listener) { if (type === 'click') documentClickListener = listener; },
    createElement(tag) {
      if (tag === 'button') {
        const listeners = {};
        let textContent = '';
        const button = {
          attributes: {},
          dataset: {},
          style: {},
          setAttribute(name, value) { this.attributes[name] = value; },
          addEventListener(name, listener) { listeners[name] = listener; },
          insertAdjacentElement(position, node) {
            assert.equal(position, 'afterend');
            portraitSummaryPanel = node;
          },
          click() {
            listeners.click?.({ preventDefault() {}, stopPropagation() {} });
          },
          keydown(key) { listeners.keydown?.({ key, preventDefault() {}, stopPropagation() {} }); },
        };
        Object.defineProperty(button, 'textContent', {
          get() { return textContent; },
          set(value) {
            if (Object.prototype.hasOwnProperty.call(button.attributes, 'data-attention-image-prompt-language')) portraitButtonTextWrites += 1;
            textContent = value;
          },
        });
        return button;
      }
      return {
        attributes: {}, dataset: {}, style: {}, children: [],
        setAttribute(name, value) { this.attributes[name] = value; },
        append(...children) { this.children.push(...children); },
        click() { exportClicked = true; exportFilename = this.download; },
        remove() {},
      };
    },
    body: { appendChild() {} },
    getElementById(id) {
      if (id === 'root') return {};
      if (id === 'wwis-launch') return imageStudioLaunch;
      return null;
    },
    querySelector(selector) {
      if (selector === '.ko-se-fullscreen-image') return secretFullscreenImage;
      if (selector === '.ko-se-fullscreen-overlay') return secretFullscreenOverlay;
      if (selector === '.ko-se-secret') return secretSections.length ? secretRoot : null;
      return null;
    },
    querySelectorAll(selector) {
      if (selector === 'button.wpc-ctl-cmd, button.hlc-chip') return controllerDomButtons;
      if (selector === '.wpc-ctl, .wpc-dock, .hlc-dock') return controllerPanels;
      if (selector === 'h2') return [pauseHeading];
      if (selector === 'span.text-stone-500.font-bold') return [portraitHeading];
      if (selector === 'div.relative.overflow-hidden.bg-stone-800.cursor-pointer') return [portraitActionBar];
      if (selector === 'img') return [portraitImage];
      if (selector === '.ko-se-secret .ko-se-fluid-section') return secretSections;
      return [];
    },
  },
  MutationObserver: class {
    constructor(callback) { pauseObserverCallback = callback; }
    observe() {}
    disconnect() {}
  },
  queueMicrotask(callback) { callback(); },
  navigator: { clipboard: { async writeText(value) { copiedText = value; } } },
  window: {
    innerWidth: 1440,
    innerHeight: 1000,
    confirm() { return true; },
    alert(message) { throw new Error(message); },
    addEventListener() {},
    dispatchEvent() {},
    requestAnimationFrame(callback) {
      animationFrameRequests += 1;
      animationFrameCallback = callback;
      return animationFrameRequests;
    },
    setTimeout(callback) { callback(); return 1; },
  },
};
vm.runInNewContext(`
  window.__imageStudioNames = { elena: '엘레나', mara: '마라', pippa: '피파' };
  window.__imageStudioEntries = [];
  window.__imageStudioRandomWife = '';
  window.__imageStudioOriginalEntries = Object.entries;
  window.__imageStudioLaunch = {
    listeners: { capture: [], bubble: [] },
    addEventListener(type, listener, options) {
      if (type === 'click') this.listeners[options === true ? 'capture' : 'bubble'].push(listener);
    },
    onclick() { window.__imageStudioEntries = Object.entries(window.__imageStudioNames); },
    click() {
      const event = { preventDefault() {}, stopPropagation() {} };
      for (const listener of this.listeners.capture) listener(event);
      this.onclick(event);
      for (const listener of this.listeners.bubble) listener(event);
    },
  };
  window.WW_ImageStudio = {
    open() { window.__imageStudioLaunch.click(); },
  };
  globalThis.WW_ImageStudioBridge = {
    openRandom(wife) { window.__imageStudioRandomWife = wife; },
    async list(wife) { window.__imageStudioListWife = wife; return []; },
  };
  window.WW_ImageStudioBridge = globalThis.WW_ImageStudioBridge;
`, vmContext);
imageStudioLaunch = vmContext.window.__imageStudioLaunch;
const modSource = fs.readFileSync(`${__dirname}/mod.js`, 'utf8');
vm.runInNewContext(modSource, vmContext);
vmContext.WML.status = () => ({ loaded: ['h-status'] });

const hooks = {};
let lastImagePromptInput = null;
let outerPortraitInput;
const outerEngine = { imagePrompt: () => outerPortraitInput };
let settingsRenderer;
let rows = [{ kind: 'spent', characterId: 'wife', urgency: 50 }];
let driveState = { financial: 0, approval: 0, desire: 0, security: 0, social: 0, pride: 0, longing: 0 };
let relationshipLatitude = 0;
let savedSettings = {};
let persistedFeaturePrompts;
let savedModData = {};
let dropResidueImageChoiceWrites = false;
let dropPositionPresetPromptWrites = false;
const fakeNode = (tag, props, ...children) => ({
  tag,
  props: props || {},
  children: children.flat().filter(child => child != null && child !== false),
});
const fakeJsxNode = (tag, props, key) => ({
  $$typeof: Symbol.for('react.element'),
  type: tag,
  tag,
  key,
  props: props || {},
});
const flattenNodes = roots => {
  const nodes = [];
  const visit = node => {
    if (Array.isArray(node)) { for (const child of node) visit(child); return; }
    if (!node || typeof node !== 'object') return;
    nodes.push(node);
    visit(node.children || node.props?.children || []);
  };
  visit(roots);
  return nodes;
};
const wifeArchetypes = {
  elena_farmgirl: { id: 'elena_farmgirl', name: '엘레나', tagline: '기본 소개', backstory: '기본 배경', imageBase: '1girl, brown_hair', imageNegative: 'tattoo, piercing' },
  mara_citygirl: { id: 'mara_citygirl', name: '마라', tagline: '도시 아가씨', backstory: '도시 배경', imageBase: '1girl, black_hair, blue_eyes', imageNegative: 'long hair, tattoo' },
  pippa_waif: { id: 'pippa_waif', name: '피파', tagline: '거리의 아이', backstory: '피파 배경', imageBase: '1girl, short_brown_hair, green_eyes, hair_ribbon, tired_eyes', imageNegative: 'child, loli, black hair' },
};
const outfitDefinitions = [
  {
    id: 'modest', name: '수수한 작업복', description: '기본 의상',
    imageTags: 'plain brown dress, white apron', negativeImageTags: 'cleavage, breasts_out',
    halves: { top: 'brown blouse', skirt: 'brown skirt' },
  },
  {
    id: 'maid_dress', name: '메이드복', description: '다른 모드가 등록한 의상',
    imageTags: 'black maid dress, white apron', negativeImageTags: 'casual clothes, long skirt',
    halves: { top: 'maid blouse', skirt: 'black skirt' },
  },
];
const preGenerateFloorOutfits = ['modest', 'maid_dress', 'naked'];
const preGenerateBathOutfits = ['base-bath-outfit', 'nude'];
let plannerOutfitSymbolsAvailable = true;
const wife = {
  id: 'wife',
  shortname: 'elena',
  archetypeId: 'elena_farmgirl',
  stats: { energy: 50, mood: 50, arousal: 0 },
  relationship: { trust: 50 },
  feelings: [],
  intoxication: { level: 0 },
};
const customWifeStore = selector => selector({
  wives: savedWives,
  save(entry) { savedWives = [...savedWives, entry]; return entry; },
  remove(id) { savedWives = savedWives.filter(entry => entry.id !== id); },
});
customWifeStore.getState = () => ({
  wives: savedWives,
  save(entry) { savedWives = [...savedWives, entry]; return entry; },
  remove(id) { savedWives = savedWives.filter(entry => entry.id !== id); },
});
const state = {
  slot: 100,
  log: [],
  primaryCharacterId: 'wife',
  characters: { wife },
  modData: {},
};
const api = {
  id: 'attention-image-prompt',
  engine: outerEngine,
  sym: name => name,
  async loadScript(file) {
    assert.ok(['legacy-cache.js', 'image-pack.js'].includes(file));
    if (file === 'legacy-cache.js') vmContext.__attentionImageLegacyCache = legacyCacheFixture;
    if (file === 'image-pack.js') return new Promise(resolve => {
      completeImagePackLoad = () => {
        vmContext.__WAYWARD_IMAGE_PACKS__ = [...(vmContext.__WAYWARD_IMAGE_PACKS__ || []), {
          packFormat: 1, packId: 'attention-image-prompt-elena-test', generatedAt: '2026-10-16',
          entries: { 'elena__aip-late-pack__v-0': {
            imagePath: 'illustrious/characters/elena/late.webp', talentName: 'elena__aip-late-pack__v-0', imageType: 'portrait',
          } },
        }];
        resolve();
      };
    });
  },
  async saveFile(name, data, type) { savedImagePackFile = { name, data, type }; },
  has(name) {
    if (['imageFloorOutfits', 'imageBathOutfits'].includes(name)) return plannerOutfitSymbolsAvailable;
    return ['pauseMenu', 'imageGenerate', 'imageGenerationInFlight', 'imageVariantState', 'saveImageVariantState', 'currentPortraitImageKey', 'outfitList', 'imageManifest', 'imageManifestReset', 'imageUrl', 'imageBackend'].includes(name);
  },
  fn(name) {
    return {
      attentionSituations(current, options) {
        assert.equal(current, state);
        assert.equal(options.proximity, true);
        assert.equal(options.limit, 4);
        return rows;
      },
      effectiveHeroineStats: () => ({ ...wife.stats }),
      relationshipPanelStatus: () => ({
        trust: wife.relationship.trust,
        desire: 0,
        resentment: 0,
        drift: { raw: 0 },
        latitude: { raw: relationshipLatitude },
      }),
      topFeelings: (character, limit) => [...(character.feelings || [])]
        .sort((left, right) => right.intensity - left.intensity)
        .slice(0, limit),
      wellbeingSignals: () => ({ total: 0, signals: [] }),
      intoxicationBand: level => level <= 0 ? 'sober' : level <= 25 ? 'tipsy' : 'drunk',
      heroineDriveCalc: () => ({ ...driveState }),
      allureScore: () => 0,
      gamePromptQuality: 'best quality',
      gamePromptNegative: 'base_negative',
      promptJoin: value => [...new Set(value.split(',').map(tag => tag.trim()).filter(Boolean))].join(', '),
      promptGenParams: prompt => ({ promptLength: prompt.length }),
      imageGenerate: async request => {
        generatedRequests.push(request);
        return { url: `https://example.test/${encodeURIComponent(request.imageKey)}.webp` };
      },
      imagePrompt: (...args) => {
        const fixture = promptInputByContext?.get(args[1]);
        const source = (typeof fixture === 'function' ? fixture(args[0]) : fixture) || lastImagePromptInput?.result;
        if (!source) return null;
        const base = hooks.imagePromptBase?.around ? hooks.imagePromptBase.around(() => ({ ...source }), ...args) : { ...source };
        return hooks.imagePromptTail.after(hooks.imagePrompt.after(base, args), args);
      },
      imageLookup: async key => imageManifestEntries[key] || imageLookupExtraEntries[key] || null,
      imageGenerationInFlight,
      imageBackend: () => ({ baseUrl: 'http://127.0.0.1:8189', comfyui: true, version: '0.2.0' }),
      imageVariantState: key => {
        const result = imageVariantStates[String(key).replace(/__v-\d+$/, '')] || { variants: [], currentIdx: 0 };
        return hooks.imageVariantState?.after ? hooks.imageVariantState.after(result, [key]) : result;
      },
      saveImageVariantState: (key, value) => {
        const write = (target, nextValue) => {
          if (failVariantSave) throw new Error('storage quota exceeded');
          imageVariantStates[String(target).replace(/__v-\d+$/, '')] = nextValue;
        };
        return hooks.saveImageVariantState?.around
          ? hooks.saveImageVariantState.around(write, key, value) : write(key, value);
      },
      currentPortraitImageKey: () => activePortraitKey,
      imageManifest: async () => ({ version: 1, entries: imageManifestEntries }),
      imageManifestReset: () => { imageManifestResets += 1; },
      imageUrl: entry => `${relativeImageUrls ? '' : 'https://example.test/'}images/${String(entry.imagePath).replaceAll('\\', '/')}`,
      settingsStore: { getState: () => ({ proximityMode: true }) },
      customWifeStore,
      wifeBuilderDefaults: () => ({
        name: '기본', age: 18, background: 'same_town', backstoryIndex: 0, taglineIndex: 0,
        characterBase: '', look: { marks: [] }, customAppearance: '', customTagline: '', customBackstory: '',
        openness: 'mid', confidence: 'mid', tendencies: [], imageCheckpoint: '',
      }),
      buildWifeArchetype: (inputs, id) => ({
        id, name: inputs.name, tagline: inputs.customTagline, backstory: inputs.customBackstory,
        imageBase: inputs.customAppearance || 'generated_base', imageCheckpoint: inputs.imageCheckpoint || undefined,
      }),
      wifeCharacterFromArchetype: (archetype, options = {}) => ({
        id: options.id || 'wife', archetypeId: archetype.id,
        generatedArchetype: options.generatedArchetype,
      }),
      wifePreviewBundle: archetype => ({
        key: `wife_preview_${archetype.shortname || archetype.id}`,
        prompt: archetype.imageBase,
        negativePrompt: `default_negative${archetype.imageNegative ? `, ${archetype.imageNegative}` : ''}, nude, naked, breasts_out, nipples, lingerie, heavy armor, cloak hiding body, cropped, close-up`,
        parts: [],
      }),
      wifeArchetypeById: id => wifeArchetypes[id],
      imagePreGenerateCharacters: preGenerateCharacters,
      imageFloorOutfits: preGenerateFloorOutfits,
      imageBathOutfits: preGenerateBathOutfits,
      imagePreGenerateDialog: () => null,
      imagePlanCharacter: id => ({ id: 'wife', archetypeId: id }),
      imagePlanList: options => [{ talentId: `${options.archetype}__task-idle__v-0`, prompt: 'planned' }],
      imageServerUrl: path => `http://127.0.0.1:8189${path}`,
      outfitById: id => outfitDefinitions.find(outfit => outfit.id === id),
      outfitList: outfitDefinitions,
      jsx: { jsx: fakeJsxNode, jsxs: fakeJsxNode, Fragment: Symbol.for('react.fragment') },
    }[name];
  },
  hook(name, spec) {
    if (['imageKey', 'imagePrompt'].includes(name) && spec.priority === 3000000) hooks[`${name}Wake`] = spec;
    else if (name === 'imageKey' && spec.priority === -3000000) hooks.imageKeyStudioTail = spec;
    else if (name === 'imagePrompt' && typeof spec.around === 'function') hooks.imagePromptBase = spec;
    else if (name === 'imagePrompt' && hooks[name]) hooks.imagePromptTail = spec;
    else if (name === 'imagePrompt') hooks[name] = { ...spec, after(result, args) {
      lastImagePromptInput = { result, args };
      return spec.after(result, args);
    } };
    else hooks[name] = spec;
  },
  hookOwners(name) { return name === 'imagePrompt' ? ['prompt-tags'] : name === 'imageGenerate' ? ['outfitqueue'] : []; },
  previewHook(name, args, without) {
    assert.equal(name, 'imagePrompt');
    assert.equal(args[0], wife);
    return without === 'prompt-tags'
      ? { key: 'elena__task-idle__v-0', prompt: 'base, recovered', negativePrompt: 'bad' }
      : { key: 'elena__task-idle__v-0', prompt: 'base, from mod, blush', negativePrompt: 'bad, from mod negative' };
  },
  store: {
    game: () => state,
    update(updater) { storeUpdates += 1; updater(state); },
    subscribe(listener) { storeListener = listener; return () => {}; },
  },
  settings: {
    get(defaults) { return { ...defaults, ...(persistedFeaturePrompts ? { featurePrompts: persistedFeaturePrompts } : {}), ...savedSettings }; },
    set(value) {
      const next = { ...value };
      if (dropResidueImageChoiceWrites) delete next.residueImageChoices;
      if (dropPositionPresetPromptWrites) delete next.positionPresetPrompts;
      if (dropCharacterPromptWrites) delete next.characterPrompt;
      savedSettings = { ...savedSettings, ...next };
    },
  },
  data: {
    get() { return savedModData; },
    set(value) {
      savedModData = typeof value === 'function' ? value(savedModData) : value;
      storeUpdates += 1;
    },
  },
  ui: {
    settings(render) { settingsRenderer = render; },
    pauseSettings(options) { pauseEntry = options; },
    window(options) {
      const body = {
        children: [],
        replaceChildren(...children) { this.children = children; },
        querySelector(selector) {
          const attribute = selector.match(/^\[([^\]]+)\]$/)?.[1];
          return attribute ? flattenNodes(this.children).find(node => Object.prototype.hasOwnProperty.call(node.props || {}, attribute)) : null;
        },
      };
      const styles = {};
      const listeners = {};
      const win = {
        el: {
          style: { setProperty(name, value, priority) { styles[name] = { value, priority }; } },
          addEventListener(name, listener) { (listeners[name] ||= []).push(listener); },
          dispatchEvent(event) { for (const listener of listeners[event.type] || []) listener(event); },
        },
        styles,
        refresh() { options.render(body, win); },
        close() {
          if (win.closed) return;
          win.closed = true;
          fixtureWindows.delete(win);
          options.onClose?.();
        },
      };
      fixtureWindows.add(win);
      options.render(body, win);
      openedSettingsWindow = { options, body, win };
      return win;
    },
    h: fakeNode,
    button(label, onclick, options) { return fakeNode('button', { onclick, options }, label); },
  },
  t: values => values.ko,
};

const compactedStartupKey = 'situation_fluid__elena__mouth__stage-1';
savedSettings = {
  prompts: { 'hstatus.crest.4': '(pubic_tattoo:1.15), (single vivid magenta crest printed flat on the woman\'s exposed lower abdomen:1.35), (directly below her navel and above her pubic bone:1.3)' },
  negativePrompts: { 'hstatus.crest.4': '', 'hstatus.crest.5': 'custom_crest_negative_kept' },
  situationPresets: [
    { id: 'crest-default-migrate', name: '기본 음문', prompts: { 'hstatus.crest.5': '(pubic_tattoo:1.2), (single deep crimson-magenta crest printed flat on the woman\'s exposed lower abdomen:1.4), (directly below her navel and above her pubic bone:1.35)' }, negativePrompts: { 'hstatus.crest.5': '' } },
    { id: 'crest-custom-preserve', name: '사용자 음문', prompts: { 'hstatus.crest.4': 'custom_crest_positive' }, negativePrompts: { 'hstatus.crest.4': '' } },
  ],
  residueImageChoices: {
    [compactedStartupKey]: {
      selected: `${compactedStartupKey}__v-1700000000002`,
      items: [
        { key: `${compactedStartupKey}__v-1700000000001`, url: 'https://example.test/old-1.webp', createdAt: 1 },
        { key: `${compactedStartupKey}__v-1700000000002`, url: 'https://example.test/old-2.webp', createdAt: 2 },
      ],
    },
  },
};
persistedFeaturePrompts = { pregnancy: true, marks: false };
mod.setup(api);
assert.equal(savedSettings.crestNegativeDefaultsV1, true);
assert.equal(savedSettings.negativePrompts['hstatus.crest.4'], 'male tattoo, hand tattoo, duplicate crest');
assert.equal(savedSettings.negativePrompts['hstatus.crest.5'], 'custom_crest_negative_kept');
assert.equal(savedSettings.situationPresets[0].negativePrompts['hstatus.crest.5'],
  'male tattoo, hand tattoo, duplicate crest');
assert.equal(savedSettings.situationPresets[1].negativePrompts['hstatus.crest.4'], '');
savedSettings = { ...savedSettings, prompts: {}, negativePrompts: {}, situationPresets: [] };
assert.equal(openedSettingsWindow?.options.id, 'feature-prompts-first-start',
  'upgrading an older setup should ask before enabling new status prompts');
assert.equal(savedSettings.featurePrompts, undefined);
const firstStartNodes = flattenNodes(openedSettingsWindow.body.children);
assert.equal(firstStartNodes.find(node => node.props?.['data-feature-first-start'] === 'pregnancy').props.checked, true);
assert.equal(firstStartNodes.find(node => node.props?.['data-feature-first-start'] === 'marks').props.checked, false);
assert.equal(firstStartNodes.find(node => node.props?.['data-feature-first-start'] === 'cycle').props.checked, false);
assert.equal(firstStartNodes.find(node => node.props?.['data-feature-first-start'] === 'sleep').props.checked, false);
assert.equal(firstStartNodes.find(node => node.props?.['data-feature-first-start'] === 'firstExperience').props.checked, true);
firstStartNodes.find(node => node.props?.['data-feature-first-start'] === 'pregnancy')
  .props.onchange({ currentTarget: { checked: true } });
firstStartNodes.find(node => node.props?.['data-feature-first-start'] === 'marks')
  .props.onchange({ currentTarget: { checked: true } });
firstStartNodes.find(node => node.props?.['data-feature-first-start'] === 'cycle')
  .props.onchange({ currentTarget: { checked: true } });
firstStartNodes.find(node => node.props?.['data-feature-first-start'] === 'sleep')
  .props.onchange({ currentTarget: { checked: true } });
firstStartNodes.find(node => node.props?.['data-feature-first-start'] === 'firstExperience')
  .props.onchange({ currentTarget: { checked: true } });
firstStartNodes.find(node => node.tag === 'button' && node.children[0] === '선택 적용').props.onclick();
assert.deepEqual({ ...savedSettings.featurePrompts }, { pregnancy: true, marks: true, cycle: true, sleep: true, firstExperience: true, erostat: true });
assert.equal(openedSettingsWindow.options.id, 'short-image-keys-first-start');
assert.equal(savedSettings.shortImageKeys, undefined, 'the optional filename change must stay off until chosen');
const shortKeyOffer = flattenNodes(openedSettingsWindow.body.children);
assert.match(shortKeyOffer.filter(node => node.tag === 'p').flatMap(node => node.children).join(' '), /기존 이미지.*외부 도구.*직접.*이미지 스튜디오/);
shortKeyOffer.find(node => node.tag === 'button' && node.children[0] === '사용 안 함').props.onclick();
assert.equal(savedSettings.shortImageKeys, false);
persistedFeaturePrompts = savedSettings.featurePrompts;
assert.equal(savedSettings.residueImageChoices[compactedStartupKey].items.length, 1,
  'startup migration should keep only the selected secret image in browser storage');
assert.equal(savedSettings.residueImageChoices[compactedStartupKey].items[0].key,
  `${compactedStartupKey}__v-1700000000002`);
savedSettings = { ...savedSettings, residueImageChoices: {} };
assert.equal(mod.name, '상황별 이미지 프롬프트');
assert.equal(mod.version, '1.77.0');
assert.ok(mod.loadAfter.includes('imagestudio'));
assert.match(modSource, /\/api\/image\/hstatus-img2img/);
assert.match(modSource, /hstatus-img2img-v1/);
assert.match(modSource, /generation\.mode === 'hstatus-img2img' \? 'H-Status img2img' : generation\.mode === 'hstatus-default' \? 'H-Status 기본값' : generation\.mode === 'aip-own' \? 'AIP 자체 프롬프트' : '일반 생성'/,
  'diagnostics should identify the actual generation path');
assert.doesNotMatch(modSource,
  /residuePartFromImageKey\(imageKey\) !== 'uterus'\s*\|\| !isCustomResidueImageKey\(imageKey\)/,
  'base-character uterus regeneration must use the same img2img path as custom wives');
assert.doesNotMatch(modSource, /residuePartFromImageKey\(imageKey\) !== 'uterus'/,
  'img2img must be available to every H-Status body part');
assert.doesNotMatch(modSource, /api\.has\('imageLookup'\)/,
  'the required mod-local image lookup must not be hidden behind the common-symbol availability check');
assert.match(modSource, /\^\\\/\?images\\\//,
  'relative game image paths must be fetched through ImageStudio when the game runs from file://');
assert.match(modSource, /dimensions: prompt\.dimensions,/,
  'manual secret-image regeneration should forward the supported landscape dimension preset');
const legacyHandcuffPrompt = 'hands_behind_back, wrists_bound_behind_back, handcuffed, metal_handcuffs, iron_chains, shackles, unable_to_move, struggling';
const legacyHandcuffNegativePrompt = 'handcuffed boys, restrained boys, male handcuffs, male shackles, chains on male wrists, boys with bound hands, boys with hands tied, handcuffs on both genders, smile';
assert.equal(savedSettings.outfitExposureDefaultsV1, true);
for (const key of ['fluid.breasts.1', 'fluid.thighs.1', 'fluid.vulva.1', 'jewelry.breasts.1', 'jewelry.vulva.1']) {
  assert.deepEqual([...savedSettings.outfitStates[key]], ['exposed'], `${key} should migrate to the exposed-only default`);
}
for (const key of ['toy.vulva.egg', 'toy.vulva.penis']) {
  assert.deepEqual([...savedSettings.outfitStates[key]], ['exposed', 'nude', 'partial'], `${key} should keep the current configured visibility default`);
}
assert.equal(typeof hooks.imageKey?.after, 'function');
assert.equal(typeof hooks.imagePrompt?.after, 'function');
const timeSkipKey = 'elena__task-idle__outfit-modest__room-bedroom__v-0';
const fullTimeSkipKey = hooks.imageKey.after(timeSkipKey, [wife]);
assert.notEqual(fullTimeSkipKey, timeSkipKey, 'the time-skip test must exercise an AIP-expanded image key');
const timeSkipTick = { ...state, slot: state.slot + 1, awayEvents: [] };
assert.equal(hooks.currentPortraitImageKey.around(() => hooks.imageKey.after(timeSkipKey, [wife]), timeSkipTick), fullTimeSkipKey);
assert.equal(hooks.currentPortraitImageKey.around(() => hooks.imageKey.after(timeSkipKey, [wife]), { ...timeSkipTick, slot: timeSkipTick.slot + 1 }), timeSkipKey,
  'an intermediate minute without a new image record should skip AIP key expansion');
assert.equal(hooks.currentPortraitImageKey.around(() => hooks.imageKey.after(timeSkipKey, [wife]), {
  ...timeSkipTick, slot: timeSkipTick.slot + 2, log: [{ seq: 1, text: 'new event' }],
}), fullTimeSkipKey, 'a new event must retain its own AIP image key');
assert.equal(hooks.currentPortraitImageKey.around(() => hooks.imageKey.after(timeSkipKey, [wife]), state), fullTimeSkipKey,
  'the final committed portrait must use the full AIP image key');
const pregnancyBaseKey = 'elena__task-idle__outfit-modest__room-bedroom__v-0';
const beforePregnancySettings = savedSettings;
const pregnancyBase = { key: pregnancyBaseKey, prompt: 'base_positive', negativePrompt: 'base_negative',
  parts: [{ label: '기본', tags: 'base_positive' }] };
assert.doesNotMatch(hooks.imageKey.after(pregnancyBaseKey, [wife]), /state-pregnancy-/,
  'AIP must keep working when the pregnancy mod is absent');
let pregnancyEnabled = true;
const pregnancyData = { pregnancy: { conceptionDay: 10 } };
vmContext.__wc2PregnancyBirth265 = {
  getOptions: () => ({ enabled: pregnancyEnabled }),
  getData: () => pregnancyData,
};
state.day = 10;
savedSettings.featurePrompts = { pregnancy: false, marks: true };
assert.doesNotMatch(hooks.imageKey.after(pregnancyBaseKey, [wife]), /state-pregnancy-/,
  'the pregnancy feature switch must also remove its image-key state');
assert.doesNotMatch(hooks.imagePrompt.after(pregnancyBase, [wife]).prompt, /soft lower belly/);
savedSettings.featurePrompts = { pregnancy: true, marks: true };
for (const [day, stage, positive, negative] of [
  [10, 'early', 'soft lower belly', 'big belly'],
  [11, 'early', 'soft lower belly', 'big belly'],
  [12, 'middle', 'small baby bump', 'huge belly'],
  [13, 'late', 'round pregnant belly', 'ready to pop'],
]) {
  state.day = day;
  assert.match(hooks.imageKey.after(pregnancyBaseKey, [wife]), new RegExp(`state-pregnancy-${stage}`));
  const prompt = hooks.imagePrompt.after(pregnancyBase, [wife]);
  assert.match(prompt.prompt, new RegExp(positive), `pregnancy ${stage} Positive should work without image-look`);
  assert.match(prompt.negativePrompt, new RegExp(negative), `pregnancy ${stage} Negative should work without image-look`);
  assert.equal(prompt.parts.filter(part => part.label === '임신 상태').length, 1);
}
pregnancyEnabled = false;
assert.doesNotMatch(hooks.imageKey.after(pregnancyBaseKey, [wife]), /state-pregnancy-/);
assert.doesNotMatch(hooks.imagePrompt.after(pregnancyBase, [wife]).prompt, /round pregnant belly/);
pregnancyEnabled = true;
state.day = 12;
savedSettings = { prompts: { 'pregnancy.middle': '' }, negativePrompts: { 'pregnancy.middle': 'custom_pregnancy_negative' } };
const negativeOnlyPregnancy = hooks.imagePrompt.after(pregnancyBase, [wife]);
assert.match(hooks.imageKey.after(pregnancyBaseKey, [wife]), /state-pregnancy-middle/);
assert.doesNotMatch(negativeOnlyPregnancy.prompt, /small baby bump/);
assert.match(negativeOnlyPregnancy.negativePrompt, /custom_pregnancy_negative/);
const nativeMiddlePositive = '(pregnant:0.8), small baby bump, (rounded belly:1.0), soft belly, (natural proportions:0.6)';
const nativeMiddleNegative = 'huge belly, big belly, ready to pop, inflation, belly expansion, stomach bulge, distended belly, obese, fat, abs, muscular abdomen';
vmContext.__WML_IMAGELOOK__ = { version: 1 };
savedSettings = { prompts: { 'pregnancy.middle': 'custom_pregnancy_positive' },
  negativePrompts: { 'pregnancy.middle': 'custom_pregnancy_negative' } };
const imageLookInput = {
  key: pregnancyBaseKey.replace('__v-0', '__preg-2b__v-0'),
  prompt: `base_positive, ${nativeMiddlePositive}`,
  negativePrompt: `base_negative, ${nativeMiddleNegative}`,
  parts: [...pregnancyBase.parts, { label: '임신', tags: nativeMiddlePositive }],
};
const imageLookPregnancy = hooks.imagePrompt.after(imageLookInput, [wife]);
assert.match(imageLookPregnancy.prompt, /custom_pregnancy_positive/);
assert.doesNotMatch(imageLookPregnancy.prompt, /small baby bump/);
assert.match(imageLookPregnancy.negativePrompt, /custom_pregnancy_negative/);
assert.doesNotMatch(imageLookPregnancy.negativePrompt, /huge belly/);
assert.equal(imageLookPregnancy.parts.filter(part => ['임신', '임신 상태'].includes(part.label)).length, 1,
  'AIP must replace image-look pregnancy tags instead of duplicating them');
savedSettings.featurePrompts = { pregnancy: false, marks: true };
const disabledPregnancy = hooks.imagePrompt.after(imageLookInput, [wife]);
assert.doesNotMatch(disabledPregnancy.prompt, /custom_pregnancy_positive|small baby bump/,
  'the global switch must suppress both AIP and image-look pregnancy tags');
assert.equal(disabledPregnancy.parts.some(part => ['임신', '임신 상태'].includes(part.label)), false);
savedSettings.featurePrompts = { pregnancy: true, marks: true };
const plannedPregnancy = hooks.imagePlanEntry.around(() => hooks.imagePrompt.after(imageLookInput, [wife]));
assert.equal(plannedPregnancy.parts.some(part => part.label === '임신'), true,
  'the generic image plan must keep image-look virtual pregnancy stages');
savedSettings = { situationPresetAssignments: { wife: '' } };
assert.equal(hooks.imagePrompt.after(imageLookInput, [wife]).parts.some(part => part.label === '임신'), true,
  'disabling AIP situation prompts must leave image-look pregnancy tags alone');
delete vmContext.__WML_IMAGELOOK__;
delete vmContext.__wc2PregnancyBirth265;
delete state.day;
savedSettings = beforePregnancySettings;

const beforeCycleSettings = savedSettings;
const beforeCycleScene = state.activeScene;
savedSettings = { ...savedSettings, featurePrompts: { ...savedSettings.featurePrompts, cycle: true, sleep: true } };
savedSettings = { ...savedSettings, prompts: { ...savedSettings.prompts },
  negativePrompts: { ...savedSettings.negativePrompts } };
const contactKey = 'elena__scene-fingered__outfit-modest__exp-1111111__v-0';
const contactBase = { key: contactKey, prompt: 'base_positive, looking_at_another, (wide eyes:1.2), woman sitting',
  negativePrompt: 'base_negative', parts: [{ label: '기본', tags: 'base_positive, looking_at_another, (wide eyes:1.2), woman sitting' }] };
state.activeScene = { sex: { type: 'fingering' } };
state.day = 10;
let cyclePhase = 'menstrual';
let cyclePregnant = false;
let cycleEnabled = true;
vmContext.__wc2PregnancyBirth265 = {
  getOptions: () => ({ enabled: cycleEnabled }),
  getData: () => ({ pregnancy: cyclePregnant ? { conceptionDay: 8 } : null }),
  getCycleInfo: () => ({ id: cyclePhase }),
};
assert.match(hooks.imageKey.after(contactKey, [wife]), /state-cycle-vulva-menstrual/);
for (const previous of ['(light menstrual staining confined to her vulva:1.15)',
  '(menstruation:1.2), (visible dark red menstrual blood at her vaginal opening:1.35), (small blood stain confined to her vulva:1.2)']) {
  savedSettings.prompts['cycle.vulva.menstrual'] = previous;
  savedSettings.negativePrompts['cycle.vulva.menstrual'] = 'heavy bleeding, blood on legs, open wound';
  const migratedMenstrual = hooks.imagePrompt.after(contactBase, [wife]);
  assert.match(migratedMenstrual.prompt, /small visible trace of muted red menstrual blood at her vaginal opening/,
    'earlier saved defaults must use the lighter menstrual prompt');
  assert.match(migratedMenstrual.negativePrompt, /blood splatter/);
  assert.doesNotMatch(migratedMenstrual.negativePrompt, /heavy bleeding/);
}
savedSettings.prompts['cycle.vulva.menstrual'] = 'custom_menstrual_positive';
savedSettings.negativePrompts['cycle.vulva.menstrual'] = 'custom_menstrual_negative';
const customMenstrual = hooks.imagePrompt.after(contactBase, [wife]);
assert.match(customMenstrual.prompt, /custom_menstrual_positive/);
assert.match(customMenstrual.negativePrompt, /custom_menstrual_negative/);
delete savedSettings.prompts['cycle.vulva.menstrual'];
delete savedSettings.negativePrompts['cycle.vulva.menstrual'];
for (const [phase, oldPositive] of [
  ['follicular', '(natural vulva with little visible moisture:1.1)'],
  ['ovulation', '(clear natural moisture at her vulva:1.15)'],
  ['luteal', '(subtle natural moisture at her vulva:1.1)'],
]) {
  cyclePhase = phase;
  savedSettings.prompts[`cycle.vulva.${phase}`] = oldPositive;
  savedSettings.negativePrompts[`cycle.vulva.${phase}`] = 'menstrual blood, vaginal bleeding';
  assert.doesNotMatch(hooks.imageKey.after(contactKey, [wife]), /state-cycle-vulva-/,
    'saved non-bleeding defaults must not split image keys');
  const prompt = hooks.imagePrompt.after(contactBase, [wife]);
  assert.equal(prompt.parts.some(part => part.label === '생리 상태'), false);
  assert.doesNotMatch(prompt.prompt, /menstrual blood|blood stain/);
  assert.doesNotMatch(prompt.prompt, /natural vulva|natural moisture/);
  assert.doesNotMatch(prompt.negativePrompt, /menstrual blood|vaginal bleeding/);
}
savedSettings.prompts['cycle.vulva.ovulation'] = 'custom_cycle_positive';
savedSettings.negativePrompts['cycle.vulva.ovulation'] = 'custom_cycle_negative';
cyclePhase = 'ovulation';
assert.match(hooks.imageKey.after(contactKey, [wife]), /state-cycle-vulva-ovulation/,
  'user-authored non-bleeding prompts remain editable');
assert.match(hooks.imagePrompt.after(contactBase, [wife]).prompt, /custom_cycle_positive/);
delete savedSettings.prompts['cycle.vulva.ovulation'];
delete savedSettings.negativePrompts['cycle.vulva.ovulation'];
savedSettings.negativePrompts['cycle.vulva.ovulation'] = 'custom_cycle_negative_only';
assert.match(hooks.imageKey.after(contactKey, [wife]), /state-cycle-vulva-ovulation/,
  'a custom negative-only phase must not reuse an earlier image');
assert.match(hooks.imagePrompt.after(contactBase, [wife]).negativePrompt, /custom_cycle_negative_only/);
delete savedSettings.negativePrompts['cycle.vulva.ovulation'];
cyclePhase = 'menstrual';
state.activeScene.sex.type = 'handjob';
assert.doesNotMatch(hooks.imageKey.after(contactKey, [wife]), /state-cycle-vulva-/,
  'a male handjob must not show the woman\'s genital cycle state');
state.activeScene = { patron: { stage: 'intimate' } };
assert.match(hooks.imageKey.after(contactKey.replace('scene-fingered', 'scene-patron_intimate'), [wife]),
  /state-cycle-vulva-menstrual/, 'an exposed patron-touch scene should read menstrual bleeding');
state.activeScene = { sex: { type: 'fingering' } };
cyclePregnant = true;
assert.doesNotMatch(hooks.imageKey.after(contactKey, [wife]), /state-cycle-vulva-/);
cyclePregnant = false;
cycleEnabled = false;
assert.doesNotMatch(hooks.imageKey.after(contactKey, [wife]), /state-cycle-vulva-/);
cycleEnabled = true;
savedSettings.featurePrompts = { ...savedSettings.featurePrompts, cycle: false };
assert.doesNotMatch(hooks.imageKey.after(contactKey, [wife]), /state-cycle-vulva-/);
const cycleOffPrompt = hooks.imagePrompt.after(contactBase, [wife]);
assert.equal(cycleOffPrompt.parts.some(part => part.label === '생리 상태'), false);
assert.doesNotMatch(cycleOffPrompt.prompt, /menstrual blood/);
assert.doesNotMatch(cycleOffPrompt.negativePrompt, /blood on legs/);
savedSettings.featurePrompts = { ...savedSettings.featurePrompts, cycle: true };
delete vmContext.__wc2PregnancyBirth265;

const beforeFirstExperienceSettings = savedSettings;
const beforeFirstExperienceMods = state.mods;
const beforeFirstExperienceScene = state.activeScene;
const beforeFirstExperienceOverride = wife.sceneOverride;
const beforeFirstExperienceHistory = wife.intimateHistory;
const beforeFirstExperienceDiary = wife.diary;
const beforeFirstExperienceVirginity = wife.virginity;
const beforeFirstExperienceDay = state.day;
const beforeFirstExperienceStatus = vmContext.WML.status;
const firstExperienceKey = 'elena__scene-sex__outfit-modest__exp-1111111__v-0';
const firstExperienceBase = { key: firstExperienceKey, prompt: 'base_positive, smile',
  negativePrompt: 'base_negative', parts: [{ label: '장면', tags: 'base_positive, smile' }] };
state.activeScene = { sex: { type: 'sex', startedAtSlot: 100 } };
state.day = 2;
wife.sceneOverride = 'sex';
wife.intimateHistory = [{ actId: 'anal', day: 1, slot: 20 }];
assert.match(hooks.imageKey.after(firstExperienceKey, [wife]), /state-firstexperience-vaginal/,
  'a first vaginal scene must work without the first-experience mod');
wife.intimateHistory.push({ actId: 'sex', day: 1, slot: 30 });
assert.doesNotMatch(hooks.imageKey.after(firstExperienceKey, [wife]), /state-firstexperience-vaginal/,
  'past vaginal history prevents a false first-experience image');
wife.intimateHistory = [{ actId: 'sex', day: 2, slot: 100 }];
assert.match(hooks.imageKey.after(firstExperienceKey, [wife]), /state-firstexperience-vaginal/,
  'the first record made during the current scene keeps that scene active');
wife.intimateHistory = [];
wife.diary = { firsts: { sex: { day: 1, slot: 30 } } };
assert.doesNotMatch(hooks.imageKey.after(firstExperienceKey, [wife]), /state-firstexperience-vaginal/,
  'the secret diary first-experience record must be honored');
delete wife.diary;
wife.virginity = { virgin: false };
assert.doesNotMatch(hooks.imageKey.after(firstExperienceKey, [wife]), /state-firstexperience-vaginal/,
  'an existing non-virgin status must be honored');
delete wife.virginity;
state.mods = { ...(state.mods || {}), 'virginity-status': { schema: 1,
  characters: { wife: { virgin: false } },
  prompt: { schema: 1, id: 'wife:100:sex', characterId: 'wife', scene: 'sex', pending: true } } };
vmContext.WML.status = () => ({ loaded: ['h-status', 'virginity-status'] });
savedSettings = { ...savedSettings, featurePrompts: { ...savedSettings.featurePrompts,
  cycle: false, firstExperience: true } };
const firstExperienceMarker = state.mods['virginity-status'].prompt;
state.mods['virginity-status'].prompt = null;
assert.doesNotMatch(hooks.imageKey.after(firstExperienceKey, [wife]), /state-firstexperience-vaginal/,
  'the status mod defaults to non-virgin, so an absent marker cannot be inferred as first experience');
state.mods['virginity-status'].prompt = firstExperienceMarker;
const previousFirstExperiencePrompt = '(pained wince:1.3), (furrowed brow:1.2), (lips parted in a strained gasp:1.2), (slight whole-body trembling:1.25), (only a pinpoint of faint blood at her vaginal opening:1.1), (a single thin faint red blood streak running down one inner thigh:1.15)';
savedSettings.prompts = { ...savedSettings.prompts, 'firstExperience.vaginal': previousFirstExperiencePrompt };
assert.match(hooks.imagePrompt.after(firstExperienceBase, [wife]).prompt, /one sharply defined thin red blood streak/,
  'the previous built-in prompt should migrate to the clearer thinner line');
savedSettings.prompts['firstExperience.vaginal'] = 'custom_first_experience_blood';
assert.match(hooks.imagePrompt.after(firstExperienceBase, [wife]).prompt, /custom_first_experience_blood/,
  'a user-edited first-experience prompt must remain unchanged');
delete savedSettings.prompts['firstExperience.vaginal'];
assert.match(hooks.imageKey.after(firstExperienceKey, [wife]), /state-firstexperience-vaginal/,
  'the first vaginal insertion needs its own portrait image key');
const firstExperiencePrompt = hooks.imagePrompt.after(firstExperienceBase, [wife]);
assert.match(firstExperiencePrompt.prompt, /pained wince.*whole-body trembling.*tiny pinpoint of blood.*one sharply defined thin red blood streak/);
assert.doesNotMatch(firstExperiencePrompt.prompt, /\bsmile\b/, 'first-insertion distress replaces a generic smile');
assert.match(firstExperiencePrompt.negativePrompt, /heavy bleeding.*multiple blood streaks/);
assert.equal(firstExperiencePrompt.parts.filter(part => part.label === '첫경험 상태').length, 1);
vmContext.__wc2PregnancyBirth265 = { getOptions: () => ({ enabled: true }),
  getData: () => ({ pregnancy: null }), getCycleInfo: () => ({ id: 'menstrual' }) };
savedSettings.featurePrompts = { ...savedSettings.featurePrompts, cycle: true };
const menstrualFirstExperience = hooks.imagePrompt.after(firstExperienceBase, [wife]);
assert.match(menstrualFirstExperience.prompt, /one sharply defined thin red blood streak/);
assert.doesNotMatch(menstrualFirstExperience.negativePrompt, /blood on legs/,
  'the menstrual Negative must not erase the first-experience thigh streak');
assert.match(menstrualFirstExperience.negativePrompt, /blood splatter/);
delete vmContext.__wc2PregnancyBirth265;
savedSettings.featurePrompts = { ...savedSettings.featurePrompts, cycle: false };
const withNativeFirstExperience = { ...firstExperiencePrompt,
  key: `${firstExperiencePrompt.key}__virgin_blood`,
  prompt: `${firstExperiencePrompt.prompt}, (virgin blood:1.3)`,
  parts: [...firstExperiencePrompt.parts, { label: '첫 삽입', tags: '(virgin blood:1.3)' }],
};
const nativeFirstExperience = hooks.imagePromptTail.after(withNativeFirstExperience, [wife]);
assert.match(nativeFirstExperience.key, /__virgin_blood/, 'the source mod key must survive until image generation');
assert.doesNotMatch(nativeFirstExperience.prompt, /\(virgin blood:1\.3\)/,
  'AIP replaces the source mod blood tag in the final prompt');
assert.match(nativeFirstExperience.prompt, /one sharply defined thin red blood streak/);
assert.ok(!nativeFirstExperience.parts.some(part => part.label === '첫 삽입'));
const originalFirstExperienceUpdate = api.store.update;
let consumedFirstExperience;
api.store.update = updater => { consumedFirstExperience = updater(state); };
hooks.imageGenerate.after({ url: 'first.webp' }, [{ imageKey: nativeFirstExperience.key,
  prompt: nativeFirstExperience.prompt }]);
api.store.update = originalFirstExperienceUpdate;
assert.equal(consumedFirstExperience.mods['virginity-status'].prompt.pending, false,
  'successful generation must consume the source mod marker even after replacing its tag');
assert.equal(consumedFirstExperience.mods['virginity-status'].promptDone.wife, true);
savedSettings.featurePrompts = { ...savedSettings.featurePrompts, firstExperience: false };
assert.doesNotMatch(hooks.imageKey.after(firstExperienceKey, [wife]), /state-firstexperience-vaginal/);
assert.doesNotMatch(hooks.imagePrompt.after(firstExperienceBase, [wife]).prompt, /pained wince/);
const disabledFirstExperience = hooks.imagePromptTail.after({ ...firstExperienceBase,
  key: `${firstExperienceKey}__virgin_blood`,
  prompt: `${firstExperienceBase.prompt}, (virgin blood:1.3)`,
  parts: [...firstExperienceBase.parts, { label: '첫 삽입', tags: '(virgin blood:1.3)' }],
}, [wife]);
assert.doesNotMatch(disabledFirstExperience.prompt, /virgin blood|one sharply defined thin red blood streak/,
  'disabling the feature also removes the other mod blood tag');
assert.doesNotMatch(disabledFirstExperience.key, /__virgin_blood/);
savedSettings.featurePrompts = { ...savedSettings.featurePrompts, firstExperience: true };
state.mods['virginity-status'].prompt.pending = false;
assert.doesNotMatch(hooks.imageKey.after(firstExperienceKey, [wife]), /state-firstexperience-vaginal/,
  'the first-experience prompt must end after the source mod consumes its marker');
state.mods['virginity-status'].prompt.pending = true;
assert.doesNotMatch(hooks.imageKey.after(firstExperienceKey.replace('scene-sex', 'scene-anal'), [wife]),
  /state-firstexperience-vaginal/, 'anal scenes must not receive vaginal first-experience tags');
savedSettings = beforeFirstExperienceSettings;
if (beforeFirstExperienceMods === undefined) delete state.mods;
else state.mods = beforeFirstExperienceMods;
state.activeScene = beforeFirstExperienceScene;
if (beforeFirstExperienceOverride === undefined) delete wife.sceneOverride;
else wife.sceneOverride = beforeFirstExperienceOverride;
if (beforeFirstExperienceHistory === undefined) delete wife.intimateHistory;
else wife.intimateHistory = beforeFirstExperienceHistory;
if (beforeFirstExperienceDiary === undefined) delete wife.diary;
else wife.diary = beforeFirstExperienceDiary;
if (beforeFirstExperienceVirginity === undefined) delete wife.virginity;
else wife.virginity = beforeFirstExperienceVirginity;
if (beforeFirstExperienceDay === undefined) delete state.day;
else state.day = beforeFirstExperienceDay;
vmContext.WML.status = beforeFirstExperienceStatus;

const ordinaryKeyBeforeSleep = hooks.imageKey.after(contactKey, [wife]);
state.activeScene = { sex: { type: 'fingering', __hs: { sleep: { stage: 'asleep', depth: 90, max: 100 } } } };
for (const [depth, level] of [[10, 'light'], [50, 'middle'], [90, 'deep']]) {
  state.activeScene.sex.__hs.sleep.depth = depth;
  const sleepKey = hooks.imageKey.after(contactKey, [wife]);
  assert.match(sleepKey, /__sleep-asleep(?:__|$)/, 'sleep must have a separate scene key');
  assert.match(sleepKey, new RegExp(`state-sleep-${level}`));
  const prompt = hooks.imagePrompt.after(contactBase, [wife]);
  assert.equal(prompt.key, sleepKey, 'a sleeping image must save its prompt under the generated key');
  assert.match(prompt.prompt, /closed eyes.*woman lying down in bed/);
  assert.doesNotMatch(prompt.prompt, /looking_at_another|wide eyes|woman sitting/);
  assert.doesNotMatch(prompt.parts.map(part => part.tags).join(', '), /looking_at_another|wide eyes|woman sitting/);
  assert.match(prompt.negativePrompt, /open eyes/);
  assert.equal(prompt.parts.filter(part => part.label === '수면 상태').length, 1);
}
const beforeSleepModuleSettings = savedSettings;
savedSettings = { ...savedSettings, positionMode: 'modules' };
vmContext.__waywardHusbandLife = { owns: () => true, compat: { husPoseOf: () => '무릎 구강성교' } };
const sleepModulePrompt = hooks.imagePrompt.after(contactBase, [wife]);
assert.match(sleepModulePrompt.prompt, /spooning|on_side/,
  'the live pose module should choose a lying pose while she sleeps');
assert.doesNotMatch(sleepModulePrompt.prompt, /kneeling|woman sitting/);
delete vmContext.__waywardHusbandLife;
savedSettings = beforeSleepModuleSettings;
const beforeSleepSettings = savedSettings;
savedSettings = { ...savedSettings, positionRules: { 'scene-fingered': ['seated-handjob'] },
  positionStatePrompts: { 'scene-fingered': { positivePrompt: 'generic_pose_tag', negativePrompt: '' } } };
const separateSleep = hooks.imagePrompt.after(contactBase, [wife]);
assert.doesNotMatch(separateSleep.prompt, /generic_pose_tag|woman sitting|handjob/,
  'ordinary pose rules and prompts must not enter the sleeping scene');
savedSettings = beforeSleepSettings;
state.activeScene.sex.__hs.sleep.stage = 'tussle';
assert.doesNotMatch(hooks.imageKey.after(contactKey, [wife]), /state-sleep-/,
  'waking must stop using a sleeping image');
assert.equal(hooks.imageKey.after(contactKey, [wife]), ordinaryKeyBeforeSleep,
  'waking should recover the exact existing ordinary image key');
assert.doesNotMatch(hooks.imagePrompt.after(contactBase, [wife]).prompt, /closed eyes/);
state.activeScene.sex.__hs.sleep.how = 'big';
const wakeCharacter = hooks.imagePromptWake.before([wife])[0];
assert.equal(wakeCharacter.sceneOverride, 'rubbing');
assert.equal(hooks.imageKeyWake.before([wife])[0].sceneOverride, 'rubbing');
assert.notEqual(wakeCharacter, wife, 'portrait routing must not change the game character');
const wakingSceneKey = contactKey.replace('scene-fingered', 'scene-rubbing');
const interruptedInput = { key: wakingSceneKey,
  prompt: 'base_positive, fingering, (fingering:1.15), (woman receiving fingering:1.2), woman kneeling',
  negativePrompt: 'base_negative', parts: [{ label: '기본', tags: 'base_positive, fingering' },
    { label: '장면', tags: '(fingering:1.15), (woman receiving fingering:1.2), woman kneeling' }] };
const interruptedKey = hooks.imageKey.after(wakingSceneKey, [wakeCharacter]);
const interruptedPrompt = hooks.imagePrompt.after(interruptedInput, [wife]);
assert.match(interruptedKey, /scene-rubbing.*__sleep-entrance-contact(?:__|$)/,
  'waking at the entrance should not reuse the preceding action image');
assert.equal(interruptedPrompt.key, interruptedKey);
assert.match(interruptedPrompt.prompt, /lying on (?:her |their )?side|lying on their sides/);
assert.match(interruptedPrompt.prompt, /penis_on_pussy|penis on pussy/);
assert.match(interruptedPrompt.prompt, /startled expression/);
assert.doesNotMatch(interruptedPrompt.prompt, /small white three-point surprise mark beside her head/);
assert.match(interruptedPrompt.prompt, /\^\^\^/);
assert.doesNotMatch(interruptedPrompt.prompt, /comic-style|comic panel/);
assert.doesNotMatch(interruptedPrompt.prompt, /fingering|woman kneeling/);
assert.doesNotMatch(interruptedPrompt.prompt, /thigh sex|rubbing between her thighs|missionary/);
assert.doesNotMatch(interruptedPrompt.prompt, /penis rubbing against woman/);
assert.match(interruptedPrompt.negativePrompt, /penetration/);
assert.doesNotMatch(interruptedPrompt.negativePrompt, /red geometric mark on upper thigh/);
const beforeWakeDefaults = savedSettings;
savedSettings = { ...savedSettings,
  prompts: { ...savedSettings.prompts, 'sleep.waking-rub': '(open eyes:1.2), startled expression, (woman lying on her side in bed:1.35), (genital rubbing:1.25), frottage, penis rubbing against her body' },
  positionPresetPrompts: { ...savedSettings.positionPresetPrompts,
    'side-rubbing': '(both partners lying on their sides:1.3), (genital rubbing:1.25), frottage' } };
const migratedWakePrompt = hooks.imagePrompt.after(interruptedInput, [wife]);
assert.match(migratedWakePrompt.prompt, /lying on (?:her |their )?side|lying on their sides/);
assert.match(migratedWakePrompt.prompt, /penis_on_pussy|penis on pussy/);
assert.doesNotMatch(migratedWakePrompt.prompt, /genital rubbing|frottage/);
assert.doesNotMatch(migratedWakePrompt.prompt, /small white three-point surprise mark beside her head/);
assert.match(migratedWakePrompt.prompt, /\^\^\^/);
savedSettings = { ...savedSettings, prompts: { ...savedSettings.prompts,
  'sleep.waking-rub': '(eyes wide open:1.2), startled expression, parted lips in surprise, (woman lying on her side in bed:1.35), exposed pussy, (penis_on_pussy:1.3), (tip of penis touching her vaginal opening from outside:1.3)' } };
assert.doesNotMatch(hooks.imagePrompt.after(interruptedInput, [wife]).prompt, /small white three-point surprise mark/,
  'older defaults must drop the misplaced surprise mark description');
savedSettings = { ...savedSettings, prompts: { ...savedSettings.prompts,
  'sleep.waking-rub': '(eyes wide open:1.2), startled expression, parted lips in surprise, (small white comic-style shock symbol with three jagged rays beside her head:1.25), (woman lying on her side in bed:1.35), exposed pussy, (penis_on_pussy:1.3), (tip of penis touching her vaginal opening from outside:1.3)' } };
const correctedWhiteMark = hooks.imagePrompt.after(interruptedInput, [wife]).prompt;
assert.doesNotMatch(correctedWhiteMark, /small white three-point surprise mark/);
assert.match(correctedWhiteMark, /\^\^\^/);
assert.doesNotMatch(correctedWhiteMark, /comic-style/);
savedSettings = { ...savedSettings, prompts: { ...savedSettings.prompts,
  'sleep.waking-rub': '(eyes wide open:1.2), startled expression, parted lips in surprise, (small white three-point surprise mark beside her head:1.15), (woman lying on her side in bed:1.35), exposed pussy, (penis_on_pussy:1.3), (tip of penis touching her vaginal opening from outside:1.3)' } };
assert.match(hooks.imagePrompt.after(interruptedInput, [wife]).prompt, /\^\^\^/,
  'the 1.41.81 default must regain the surprise mark token');
savedSettings = { ...savedSettings, prompts: { ...savedSettings.prompts,
  'sleep.waking-rub': '(eyes wide open:1.2), startled expression, parted lips in surprise, ^^^, (small white three-point surprise mark beside her head:1.15), (woman lying on her side in bed:1.35), exposed pussy, (penis_on_pussy:1.3), (tip of penis touching her vaginal opening from outside:1.3)' } };
assert.doesNotMatch(hooks.imagePrompt.after(interruptedInput, [wife]).prompt, /small white three-point surprise mark/,
  'the 1.41.82 default must drop the misplaced description');
savedSettings = { ...savedSettings, negativePrompts: { ...savedSettings.negativePrompts,
  'sleep.waking-rub': 'closed eyes, penetration, penis in pussy, fingering, fingers in pussy, handjob, fellatio, paizuri, red geometric mark on upper thigh, red painted symbol on hip, thigh tattoo' } };
assert.doesNotMatch(hooks.imagePrompt.after(interruptedInput, [wife]).negativePrompt, /red geometric mark on upper thigh/,
  'the 1.41.82 default negative must revert with the isolated prompt change');
savedSettings = beforeWakeDefaults;
const lateFingeredTags = 'solo focus, (pov hands:1.2), (fingering:1.3), (grabbing from behind:1.1), standing, head_back, open_mouth, pov, relaxed, closed eyes, thigh sex';
const finalWakePrompt = hooks.imagePromptTail.after({ ...interruptedPrompt,
  prompt: `${interruptedPrompt.prompt}, ${lateFingeredTags}`,
  negativePrompt: `${interruptedPrompt.negativePrompt}, bottomless, no panties, bare legs, revealing clothing`,
  parts: [...interruptedPrompt.parts, { label: '장면', tags: lateFingeredTags }],
}, [wife]);
assert.match(finalWakePrompt.prompt, /lying on (?:her |their )?side|lying on their sides/);
assert.match(finalWakePrompt.prompt, /penis_on_pussy|penis on pussy/);
assert.doesNotMatch(finalWakePrompt.prompt, /fingering|pov hands|grabbing from behind|standing|head_back|open_mouth|solo focus|\bpov\b|relaxed|closed eyes|thigh sex/,
  'late scene templates must not restore the previous action');
assert.doesNotMatch(finalWakePrompt.parts.map(part => part.tags).join(', '), /fingering|pov hands|grabbing from behind|standing|head_back|open_mouth|solo focus|\bpov\b|relaxed|closed eyes|thigh sex/);
assert.doesNotMatch(finalWakePrompt.negativePrompt, /bottomless|no panties|bare legs|revealing clothing/);
const beforeWakeMode = savedSettings;
savedSettings = { ...savedSettings, positionMode: 'modules' };
vmContext.__waywardHusbandLife = { owns: () => true, compat: { husPoseOf: () => '무릎 구강성교' } };
const interruptedModulePrompt = hooks.imagePrompt.after(interruptedInput, [wife]);
assert.match(interruptedModulePrompt.prompt, /lying on (?:her |their )?side|lying on their sides/);
assert.match(interruptedModulePrompt.prompt, /penis_on_pussy|penis on pussy/);
assert.doesNotMatch(interruptedModulePrompt.prompt, /fingering|kneeling|fellatio/,
  'a former module controller pose must not replace the waking rubbing scene');
delete vmContext.__waywardHusbandLife;
savedSettings = beforeWakeMode;
const oralBeforeWake = hooks.imagePrompt.after({ ...interruptedInput,
  key: wakingSceneKey,
  prompt: 'base_positive, one penis in mouth, fellatio, kneeling woman',
  parts: [{ label: '기본', tags: 'base_positive, one penis in mouth' },
    { label: '장면', tags: 'fellatio, kneeling woman' }],
}, [wife]);
assert.match(oralBeforeWake.prompt, /lying on (?:her |their )?side|lying on their sides/);
assert.match(oralBeforeWake.prompt, /penis_on_pussy|penis on pussy/);
assert.doesNotMatch(oralBeforeWake.prompt, /penis in mouth|fellatio|kneeling woman/);
delete state.activeScene.sex.__hs.sleep.how;
state.activeScene.sex.__hs.sleep.stage = 'asleep';
savedSettings.featurePrompts = { ...savedSettings.featurePrompts, sleep: false };
assert.doesNotMatch(hooks.imageKey.after(contactKey, [wife]), /state-sleep-/);
assert.match(hooks.imageKey.after(contactKey, [wife]), /__sleep-asleep(?:__|$)/,
  'a sleeping image must remain separate even when its prompt feature is off');
savedSettings = beforeCycleSettings;
state.activeScene = beforeCycleScene;
delete state.day;
assert.notEqual(outerEngine.imagePrompt.__wmlOriginal, true);
const hStatusGuard = 'exactly one of each described device, no duplicate jewelry, no extra vibrator';
const hStatusTags = `matching metal nipple jewelry on both breasts, a heart-shaped choker fitted around her neck, ${hStatusGuard}`;
outerPortraitInput = {
  key: 'elena__task-idle__outfit-modest__room-bedroom__v-0',
  prompt: `1girl, 1boy, ${hStatusTags}`,
  negativePrompt: 'base_negative',
  parts: [{ label: '성별', tags: '1girl, 1boy' }, { label: '상태', tags: hStatusTags }],
};
for (const stage of [1, 2]) {
  wife.situationStats = { jewelryState: { breasts: { stage }, vulva: { stage: 0 }, vibe: { type: null } } };
  const cleaned = outerEngine.imagePrompt(wife);
  assert.doesNotMatch(cleaned.prompt, /nipple jewelry|choker|vibrator|device/,
    'covered H Status jewelry and an unequipped choker must not leak into Positive');
  assert.match(cleaned.negativePrompt, /male nipple piercings/);
  assert.match(cleaned.negativePrompt, /heart-shaped choker/);
  assert.match(cleaned.negativePrompt, /vibrator/);
  assert.match(cleaned.negativePrompt,
    /^male nipple piercings, nipple rings on men, a heart-shaped choker fitted around her neck, vibrator, dildo, /,
    'unequipped accessory guards should lead a long SDXL Negative prompt');
}
wife.situationStats.jewelryState.breasts.stage = 3;
const equippedChoker = outerEngine.imagePrompt(wife);
assert.match(equippedChoker.prompt, /a heart-shaped choker fitted around her neck/);
assert.doesNotMatch(equippedChoker.prompt, /nipple jewelry|vibrator|device/);
assert.doesNotMatch(equippedChoker.negativePrompt, /choker/,
  'an equipped choker must not be suppressed by the reordered Negative guards');
wife.situationStats.jewelryState.breasts.stage = 0;
outerPortraitInput = {
  key: 'elena__task-idle__outfit-modest__room-bedroom__v-0',
  prompt: '1girl, bare neck',
  negativePrompt: 'base_negative',
  parts: [{ label: 'Character', tags: '1girl, bare neck' }],
};
const unequippedSoloPortrait = outerEngine.imagePrompt(wife);
assert.match(unequippedSoloPortrait.negativePrompt, /choker/,
  'an unequipped choker must also be excluded from solo portraits');
assert.match(unequippedSoloPortrait.negativePrompt, /vibrator/,
  'an unequipped toy must also be excluded from solo portraits');
outerPortraitInput = {
  ...outerPortraitInput,
  prompt: '1girl, black choker, white collar',
  parts: [{ label: 'Outfit', tags: '1girl, black choker, white collar' }],
};
const unequippedOutfitChoker = outerEngine.imagePrompt(wife);
assert.doesNotMatch(unequippedOutfitChoker.prompt, /choker/,
  'an outfit tag must not add a choker when H Status says none is equipped');
assert.match(unequippedOutfitChoker.prompt, /white collar/,
  'removing a choker must preserve unrelated outfit collar tags');
outfitDefinitions.push({ id: 'choker_outfit', imageTags: 'black choker, white collar' });
const chokerOutfitKey = 'elena__task-idle__outfit-choker_outfit__room-bedroom__v-0';
const suppressedChokerKey = hooks.imageKey.after(chokerOutfitKey, [wife]);
assert.match(suppressedChokerKey, /jewel-choker-suppressed-v2/,
  'unequipped outfit chokers need a fresh image key, not an old choker cache hit');
wife.situationStats.jewelryState.breasts.stage = 3;
outerPortraitInput = {
  key: chokerOutfitKey,
  prompt: '1girl, black choker, white collar, heart choker',
  negativePrompt: 'base_negative',
  parts: [
    { label: 'Outfit', tags: '1girl, black choker, white collar' },
    { label: '몸 상태', tags: 'heart choker' },
  ],
};
const uniqueHeartChoker = outerEngine.imagePrompt(wife);
assert.doesNotMatch(uniqueHeartChoker.prompt, /black choker/,
  'an outfit choker must not compete with the equipped H Status heart choker');
assert.equal((uniqueHeartChoker.prompt.match(/choker/g) || []).length, 1);
assert.match(uniqueHeartChoker.prompt, /heart choker, white collar|white collar, heart choker/);
const uniqueHeartChokerKey = hooks.imageKey.after(chokerOutfitKey, [wife]);
assert.match(uniqueHeartChokerKey, /jewel-choker-only-v3/,
  'the corrected heart choker prompt must not reuse an older double-choker image');
wife.situationStats.jewelryState.breasts.stage = 0;
outfitDefinitions.pop();
outerPortraitInput = {
  ...outerPortraitInput,
  prompt: `1girl, 1boy, (egg_vibrator:1.1), vaginal_object_insertion, vibrator_cord, (egg vibrator fully inside her vagina:1.45), (only its cord visible at the vaginal opening:1.3), an inserted egg vibrator concealed inside her vagina with only a thin retrieval cord visible, ${hStatusGuard}`,
  parts: [
    { label: '성별', tags: '1girl, 1boy' },
    { label: 'H Status · 토이', tags: '(egg_vibrator:1.1), vaginal_object_insertion, vibrator_cord, (egg vibrator fully inside her vagina:1.45), (only its cord visible at the vaginal opening:1.3)' },
    { label: '상태', tags: `an inserted egg vibrator concealed inside her vagina with only a thin retrieval cord visible, ${hStatusGuard}` },
  ],
};
const unequippedToy = outerEngine.imagePrompt(wife);
assert.doesNotMatch(unequippedToy.prompt, /vibrator|dildo|device/,
  'an old H Status toy part must not survive after the toy is unequipped');
assert.match(unequippedToy.negativePrompt, /vibrator/);
wife.situationStats.jewelryState.vibe = { type: 'egg', suspension: null };
const equippedEggPortrait = outerEngine.imagePrompt(wife);
assert.equal((equippedEggPortrait.prompt.match(/egg_vibrator/g) || []).length, 1,
  'the active toy must use one AIP tag prompt');
assert.doesNotMatch(equippedEggPortrait.prompt, /an inserted egg vibrator|no extra vibrator/,
  'the older H Status sentence and guard must not compete with the AIP tags');
assert.equal(equippedEggPortrait.parts.filter(part => part.label === 'H Status · 토이').length, 1);
wife.situationStats.jewelryState.vibe.suspension = { reason: 'temporarily removed' };
assert.doesNotMatch(outerEngine.imagePrompt(wife).prompt, /vibrator|dildo|device/,
  'a suspended toy must not leak through an old portrait part');
wife.situationStats.jewelryState.vibe = { type: null };
const staleEquippedWife = {
  ...wife,
  situationStats: { jewelryState: { breasts: { stage: 3 }, vulva: { stage: 0 }, vibe: { type: 'egg', suspension: null } } },
};
outerPortraitInput = {
  key: 'elena__task-idle__outfit-modest__room-bedroom__v-0',
  prompt: `1girl, a heart-shaped choker fitted around her neck, an inserted egg vibrator, ${hStatusGuard}`,
  negativePrompt: 'base_negative',
  parts: [
    { label: '성별', tags: '1girl' },
    { label: 'H Status · 토이', tags: 'an inserted egg vibrator' },
    { label: '상태', tags: `a heart-shaped choker fitted around her neck, ${hStatusGuard}` },
  ],
};
const staleAccessoryPortrait = outerEngine.imagePrompt(staleEquippedWife);
assert.doesNotMatch(staleAccessoryPortrait.prompt, /choker|vibrator|dildo/,
  'the current unequipped wife must override a stale character passed to the portrait wrapper');
assert.equal(hooks.imagePrompt.before([staleEquippedWife, 'bedroom'])[0].situationStats.jewelryState,
  wife.situationStats.jewelryState,
  'the base portrait function must receive current accessory state before building its key');
assert.equal(hooks.imageKey.before([staleEquippedWife])[0].situationStats.jewelryState,
  wife.situationStats.jewelryState,
  'a direct image-key call must receive current accessory state before calculating its base key');
const staleAccessoryKey = hooks.imageKey.after(outerPortraitInput.key, [staleEquippedWife]);
assert.doesNotMatch(staleAccessoryKey, /jewel-breasts-3|toy-vibe-egg/,
  'a stale character must not make the image key reuse equipped accessory art');
const staleAccessoryPrompt = hooks.imagePrompt.after({
  key: outerPortraitInput.key, prompt: '1girl', negativePrompt: '', parts: [{ label: '기본', tags: '1girl' }],
}, [staleEquippedWife, 'bedroom', null, 0, null, null]);
assert.doesNotMatch(staleAccessoryPrompt.prompt, /choker|vibrator|dildo/,
  'the active prompt must use current accessory state even when its character argument is stale');
wife.situationStats.jewelryState = {
  breasts: { stage: 3 }, vulva: { stage: 0 }, vibe: { type: 'egg', suspension: null },
};
const staleUnequippedWife = {
  ...wife,
  situationStats: { jewelryState: { breasts: { stage: 0 }, vulva: { stage: 0 }, vibe: { type: null } } },
};
const equippedFromCurrentState = outerEngine.imagePrompt(staleUnequippedWife);
assert.match(equippedFromCurrentState.prompt, /heart-shaped choker/,
  'current equipped jewelry must not be suppressed by a stale unequipped character');
assert.match(equippedFromCurrentState.prompt, /inserted egg vibrator/,
  'current equipped toy must not be suppressed by a stale unequipped character');
assert.match(hooks.imageKey.after(outerPortraitInput.key, [staleUnequippedWife]), /jewel-choker.*toy-vibe-egg/,
  'the image key must distinguish accessories equipped in current state');
delete wife.situationStats;
assert.equal(typeof hooks.imageLookup?.around, 'function');
assert.equal(hooks.imageLookup.priority, -1, 'state-specific lookup must wrap later image-pack optimizers');
assert.equal(typeof hooks.imageGenerate?.before, 'function');
assert.equal(typeof hooks.outfitById?.after, 'function');
assert.equal(typeof hooks.buildWifeArchetype?.after, 'function');
assert.equal(typeof hooks.wifePreviewBundle?.after, 'function');
assert.equal(typeof hooks.wifeBuilderDefaults?.after, 'function');
assert.equal(typeof hooks.wifeBuilder?.after, 'function');
assert.equal(typeof hooks.wifePicker?.after, 'function');
assert.equal(typeof hooks.wifeCharacterFromArchetype?.after, 'function');
assert.equal(typeof hooks.imagePreGenerateDialog?.before, 'function');
assert.equal(typeof hooks.imagePlanCharacter?.around, 'function');
assert.equal(typeof hooks.imagePlanList?.after, 'function');
assert.equal(typeof hooks.imageQueue?.around, 'function');
assert.equal(typeof settingsRenderer, 'function');
const residueBaseKey = 'situation_fluid__elena__mouth__stage-1';
assert.equal(hooks.imageKey.after(residueBaseKey, [wife]), residueBaseKey,
  'secret image names should not receive the normal situation state suffix');
const independentResiduePrompt = { key: residueBaseKey, prompt: 'secret-only', negativePrompt: 'secret-negative', parts: [] };
assert.equal(hooks.imagePrompt.after(independentResiduePrompt, [wife]), independentResiduePrompt,
  'secret prompts should not receive normal situation prompt groups');
const [cachedResidueRequest] = hooks.imageGenerate.before([{
  imageKey: residueBaseKey,
  prompt: 'base_positive',
  negativePrompt: 'base_negative',
  bypassCache: true,
  debug: { source: 'wayward-situation' },
}]);
assert.equal(cachedResidueRequest.bypassCache, false,
  'H-Status residue images should reuse their exact server cache after reload');
const [legacyMouthVibeRequest] = hooks.imageGenerate.before([{
  imageKey: `${residueBaseKey}__vibe-penis`,
  prompt: 'base_positive',
  negativePrompt: 'base_negative',
  bypassCache: true,
  debug: { source: 'wayward-situation' },
}]);
assert.equal(legacyMouthVibeRequest.imageKey, residueBaseKey,
  'legacy mouth image names should ignore a vibrator state that belongs to another body part');
const setupSettings = savedSettings;
savedSettings = {
  ...savedSettings,
  residuePrompts: { [residueBaseKey]: { positivePrompt: 'saved_residue', negativePrompt: 'saved_negative' } },
};
const [variantResidueRequest] = hooks.imageGenerate.before([{
  imageKey: `${residueBaseKey}__v-1700000000000`,
  prompt: 'base_positive',
  negativePrompt: 'base_negative',
  bypassCache: false,
  debug: { source: 'attention-image-prompt-residue' },
}]);
assert.equal(variantResidueRequest.prompt, 'saved_residue');
assert.equal(variantResidueRequest.negativePrompt, 'saved_negative');
savedSettings = setupSettings;
assert.equal(pauseEntry?.label.ko, '상황별 이미지 프롬프트 설정');
assert.equal(pauseEntry?.attributes['data-attention-image-prompt-settings'], '');
assert.equal(hooks.pauseMenu, undefined, 'WML 0.8 owns the pause menu insertion');
assert.equal(portraitLanguageButton?.textContent, '태그 표시: 영문');
assert.equal(portraitPositionButton?.textContent, '체위 변경');
assert.equal(portraitPositionButton?.title, '현재 상황의 체위 프리셋 변경');
assert.match(portraitPositionButton?.style.cssText || '', /display:inline-block!important/,
  'ImageStudio must not hide the AIP position shortcut');
assert.equal(portraitSimilarButton?.textContent, '비슷한 이미지');
assert.equal(portraitSimilarButton?.title, '현재와 비슷한 상황의 기존 이미지 선택');
assert.equal(portraitScenePromptButton?.textContent, '장면 프롬프트');
assert.equal(portraitScenePromptButton?.parentElement, portraitActionBar, 'scene shortcut is on the portrait alongside the existing controls');
assert.equal(portraitCameraButton?.textContent, '🎥');
assert.equal(portraitCameraButton?.attributes['aria-label'], '카메라 구도');
assert.equal(portraitCameraButton?.parentElement, portraitActionBar, 'camera shortcut is on the portrait');
const initialPortraitButtonTextWrites = portraitButtonTextWrites;
pauseObserverCallback();
pauseObserverCallback();
assert.equal(animationFrameRequests, 1, 'portrait DOM changes in one frame should be coalesced');
animationFrameCallback();
assert.equal(portraitButtonTextWrites, initialPortraitButtonTextWrites,
  'unchanged portrait tag scans must not rewrite observed DOM');
pauseEntry.onClick();
assert.equal(openedSettingsWindow?.options.title, '상황별 이미지 프롬프트 설정');
assert.ok(openedSettingsWindow?.body.children.length, 'pause menu button should open the settings UI');
assert.equal(openedSettingsWindow?.options.width, 1320);
assert.equal(openedSettingsWindow?.options.height, 840);
assert.deepEqual(openedSettingsWindow?.win.styles['z-index'], { value: '2147483647', priority: 'important' });
openedSettingsWindow.win.el.style.setProperty('left', '117px');
openedSettingsWindow.win.el.style.setProperty('top', '83px');
openedSettingsWindow.win.el.dispatchEvent({ type: 'pointerdown' });
openedSettingsWindow.win.refresh();
assert.equal(openedSettingsWindow.win.styles.left.value, '117px', 'clicking a moved settings window must not recenter it');
assert.equal(openedSettingsWindow.win.styles.top.value, '83px', 'settings refresh must preserve the moved position');

async function run() {
  assert.equal(await hooks.imageLookup.around(async () => ({ talentName: chokerOutfitKey, imagePath: 'old-choker.webp' }), suppressedChokerKey), null,
    'the unequipped key must reject an older choker image returned as nearest');
  assert.equal(await hooks.imageLookup.around(async () => ({ talentName: chokerOutfitKey, imagePath: 'old-double-choker.webp' }), uniqueHeartChokerKey), null,
    'the corrected heart choker key must reject an older double-choker image');
  const noAccessoryKey = 'elena__task-idle__v-0';
  assert.equal(await hooks.imageLookup.around(async () => ({ talentName: 'elena__task-idle__aip-toy-vibe-egg__v-0', imagePath: 'old-toy.webp' }), noAccessoryKey), null,
    'a no-toy scene must not fall back to an image with a toy');
  assert.equal(await hooks.imageLookup.around(async () => ({ talentName: 'elena__task-idle__aip-jewel-breasts-3__v-0', imagePath: 'old-choker.webp' }), noAccessoryKey), null,
    'an unequipped scene must not fall back to an image with a choker');
  const staleManifest = { version: 1, entries: { existing: { imagePath: 'existing.webp' } } };
  assert.equal(await hooks.imageManifest.around(async () => staleManifest), staleManifest,
    'before the optional pack loads, the image manifest must remain unchanged');
  completeImagePackLoad();
  await new Promise(resolve => setImmediate(resolve));
  const lateManifest = await hooks.imageManifest.around(async () => staleManifest);
  assert.equal(await hooks.imageManifest.around(async () => staleManifest), lateManifest,
    'stable pack identity must not force the image optimizer to rebuild its catalogue on every lookup');
  assert.equal(lateManifest.entries.existing.imagePath, 'existing.webp');
  assert.equal(lateManifest.entries['elena__aip-late-pack__v-0'].imagePath,
    'illustrious/characters/elena/late.webp',
    'a late image pack must appear even when the game reuses its earlier pack-list cache');
  assert.equal(lateManifest.entries['elena__aip-late-pack__v-0'].source, 'attention-image-prompt');
  const serverManifest = await hooks.imageManifest.around(async () => ({ version: 1, entries: {
    'elena__aip-late-pack__v-0': { imagePath: 'illustrious/characters/elena/new.webp', source: 'server' },
  } }));
  assert.equal(serverManifest.entries['elena__aip-late-pack__v-0'].imagePath,
    'illustrious/characters/elena/new.webp', 'a newly generated server image must beat an older exported pack entry');
  assert.equal(hooks.imageUrl.after('https://art.example/images/late.webp',
    [lateManifest.entries['elena__aip-late-pack__v-0']]), 'images/illustrious/characters/elena/late.webp');
  assert.equal(hooks.imageUrl.after('https://art.example/images/existing.webp',
    [staleManifest.entries.existing]), 'https://art.example/images/existing.webp');

  const settingsBody = {
    children: [],
    replaceChildren(...children) { this.children = children; },
    querySelector(selector) {
      const attribute = selector.match(/^\[([^\]]+)\]$/)?.[1];
      return attribute ? flattenNodes(this.children).find(node => Object.prototype.hasOwnProperty.call(node.props || {}, attribute)) : null;
    },
  };
  const settingsWin = { refresh() { settingsRenderer(settingsBody, settingsWin); } };
  const setShortImageKeysFromUi = enabled => {
    settingsWin.refresh();
    const tab = collectNodes().find(node => node.tag === 'button'
      && String(node.children[0]).startsWith('이미지 파일명 · '));
    assert.ok(tab, 'the filename switch must be visible in the settings tabs');
    tab.props.onclick();
    collectNodes().find(node => node.props?.['data-aip-short-image-keys'] === '')
      .props.onchange({ currentTarget: { checked: enabled } });
    assert.equal(savedSettings.shortImageKeys, enabled);
    assert.equal(collectNodes().find(node => node.tag === 'button'
      && String(node.children[0]).startsWith('이미지 파일명 · ')).children[0],
    `이미지 파일명 · ${enabled ? '켜짐' : '꺼짐'}`);
  };
  const collectNodes = () => {
    const nodes = [];
    const visit = node => {
      if (!node || typeof node !== 'object') return;
      nodes.push(node);
      for (const child of node.children || []) visit(child);
    };
    for (const child of settingsBody.children) visit(child);
    return nodes;
  };

  imageManifestEntries = {
    'cache-hash-1': { talentName: 'elena__aip-att-spent__v-0', imagePath: 'illustrious/characters/elena/spent.webp' },
    'elena__position-missionary__v-0': { talentName: 'elena__position-missionary__v-0', imagePath: 'illustrious/characters/elena/pose.webp' },
    'elena__scene-patron_chatting__aipk-test__v-0': { talentName: 'elena__scene-patron_chatting__aipk-test__v-0', imagePath: 'illustrious/characters/elena/bounded.webp' },
    'elena__aip-att-other__v-0': { talentName: 'elena__aip-att-other__v-0', imagePath: '../outside.webp' },
    'mara__aip-att-spent__v-0': { talentName: 'mara__aip-att-spent__v-0', imagePath: 'illustrious/characters/mara/spent.webp' },
  };
  const offlineKey = 'elena__aip-offline-fixture__v-0';
  const offlineShortKey = 'elena__scene-patron_chatting__aipk-offline__v-0';
  const offlinePreviewKey = 'wife_preview_test_1';
  const missingKey = 'elena__aip-missing-fixture__v-0';
  localCacheFixture = { version: 1, entries: {
    offline: { talentName: offlineKey, imagePath: 'illustrious/characters/elena/offline.webp', createdAt: 5 },
    offlineShort: { talentName: offlineShortKey, imagePath: 'illustrious/characters/elena/offline-short.webp',
      prompt: 'offline positive', negativePrompt: 'offline negative', createdAt: 5 },
    offlinePreview: { talentName: offlinePreviewKey, imagePath: 'illustrious/characters/unknown/wife_preview_test_1.webp', createdAt: 5 },
    stale: { talentName: offlineKey, imagePath: 'illustrious/characters/elena/stale.webp', createdAt: 1 },
    missing: { talentName: missingKey, imagePath: 'illustrious/characters/elena/missing.webp', createdAt: 6 },
    unsafe: { talentName: 'elena__aip-unsafe-fixture__v-0', imagePath: '../characters/elena/unsafe.webp', createdAt: 7 },
  } };
  settingsWin.refresh();
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '이미지 파일명 · 꺼짐').props.onclick();
  const shortKeyToggle = collectNodes().find(node => node.props?.['data-aip-short-image-keys'] === '');
  assert.equal(shortKeyToggle.props.checked, false);
  shortKeyToggle.props.onchange({ currentTarget: { checked: true } });
  assert.equal(savedSettings.shortImageKeys, true);
  collectNodes().find(node => node.props?.['data-aip-short-image-keys'] === '')
    .props.onchange({ currentTarget: { checked: false } });
  assert.equal(savedSettings.shortImageKeys, false);
  const beforePregnancyUiSettings = savedSettings;
  state.day = 12;
  vmContext.__wc2PregnancyBirth265 = {
    getOptions: () => ({ enabled: true }), getData: () => ({ pregnancy: { conceptionDay: 10 } }),
  };
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '임신 상태').props.onclick();
  const pregnancyFeatureToggle = collectNodes().find(node => node.props?.['data-aip-feature-toggle'] === 'pregnancy');
  assert.equal(pregnancyFeatureToggle.props.checked, true);
  pregnancyFeatureToggle.props.onchange({ currentTarget: { checked: false } });
  assert.equal(savedSettings.featurePrompts.pregnancy, false);
  collectNodes().find(node => node.props?.['data-aip-feature-toggle'] === 'pregnancy')
    .props.onchange({ currentTarget: { checked: true } });
  assert.match(collectNodes().find(node => node.props?.['data-pregnancy-state'] === '')?.children[0] || '',
    /현재 아내 · 임신 중기/, 'pregnancy settings should show the current mode stage');
  const pregnancyEarlyEditor = polarity => collectNodes().find(node => node.tag === 'textarea'
    && node.props?.['data-aip-field-prompt'] === `pregnancy.early:${polarity}`);
  assert.ok(pregnancyEarlyEditor('positive'), 'early pregnancy should have an editable prompt');
  assert.ok(collectNodes().some(node => node.tag === 'strong' && String(node.children[0]).startsWith('임신 중기')));
  assert.ok(collectNodes().some(node => node.tag === 'strong' && String(node.children[0]).startsWith('임신 후기')));
  pregnancyEarlyEditor('positive').props.onchange({ currentTarget: { value: 'ui_pregnancy_positive' } });
  assert.equal(savedSettings.prompts['pregnancy.early'], 'ui_pregnancy_positive');
  pregnancyEarlyEditor('negative').props.onchange({ currentTarget: { value: 'ui_pregnancy_negative' } });
  assert.equal(savedSettings.negativePrompts['pregnancy.early'], 'ui_pregnancy_negative');
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '생리 상태').props.onclick();
  const cycleFeatureToggle = collectNodes().find(node => node.props?.['data-aip-feature-toggle'] === 'cycle');
  assert.ok(cycleFeatureToggle);
  cycleFeatureToggle.props.onchange({ currentTarget: { checked: true } });
  assert.equal(savedSettings.featurePrompts.cycle, true);
  collectNodes().find(node => node.props?.['data-aip-field-prompt'] === 'cycle.vulva.ovulation:positive')
    .props.onchange({ currentTarget: { value: 'ui_cycle_positive' } });
  assert.equal(savedSettings.prompts['cycle.vulva.ovulation'], 'ui_cycle_positive');
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '첫경험').props.onclick();
  const firstExperienceToggle = collectNodes().find(node => node.props?.['data-aip-feature-toggle'] === 'firstExperience');
  assert.ok(firstExperienceToggle);
  firstExperienceToggle.props.onchange({ currentTarget: { checked: true } });
  assert.equal(savedSettings.featurePrompts.firstExperience, true);
  collectNodes().find(node => node.props?.['data-aip-field-prompt'] === 'firstExperience.vaginal:positive')
    .props.onchange({ currentTarget: { value: 'ui_first_experience_positive' } });
  assert.equal(savedSettings.prompts['firstExperience.vaginal'], 'ui_first_experience_positive');
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '수면 중 관계').props.onclick();
  const sleepFeatureToggle = collectNodes().find(node => node.props?.['data-aip-feature-toggle'] === 'sleep');
  assert.ok(sleepFeatureToggle);
  sleepFeatureToggle.props.onchange({ currentTarget: { checked: true } });
  assert.equal(savedSettings.featurePrompts.sleep, true);
  collectNodes().find(node => node.props?.['data-aip-field-prompt'] === 'sleep.deep:negative')
    .props.onchange({ currentTarget: { value: 'ui_sleep_negative' } });
  assert.equal(savedSettings.negativePrompts['sleep.deep'], 'ui_sleep_negative');
  savedSettings = beforePregnancyUiSettings;
  delete vmContext.__wc2PregnancyBirth265;
  delete state.day;
  const beforeCycleDebugSettings = savedSettings;
  const beforeCycleDebugScene = state.activeScene;
  const beforeCycleDebugDay = state.day;
  const beforeCycleDebugPortrait = activePortraitKey;
  const beforeCycleDebugInput = lastImagePromptInput;
  const beforeCycleDebugOverride = wife.sceneOverride;
  savedSettings = { ...savedSettings, featurePrompts: { ...savedSettings.featurePrompts, cycle: false },
    prompts: { ...savedSettings.prompts, 'cycle.vulva.ovulation': 'debug_cycle_positive' },
    negativePrompts: { ...savedSettings.negativePrompts, 'cycle.vulva.ovulation': 'debug_cycle_negative' } };
  const cycleDebugSettings = savedSettings;
  state.activeScene = { sex: { type: 'sex' } };
  wife.sceneOverride = 'sex';
  state.day = 10;
  const debugContactKey = 'elena__scene-sex__outfit-modest__exp-1111111__v-0';
  const debugContactBase = { key: debugContactKey, prompt: 'base_positive, woman sitting',
    negativePrompt: 'base_negative', parts: [{ label: '기본', tags: 'base_positive, woman sitting' }] };
  activePortraitKey = debugContactKey;
  lastImagePromptInput = { result: debugContactBase };
  hooks.imagePrompt.after(debugContactBase, [wife, 'cycle-debug']);
  const beforeFantasySettings = savedSettings;
  const beforeFantasyStats = wife.situationStats;
  wife.situationStats = { ...beforeFantasyStats, hypnosis: 0, crest: 0 };
  const fantasyZero = hooks.imagePrompt.after(debugContactBase, [wife, 'fantasy-stage']);
  assert.ok(!fantasyZero.parts.some(part => ['최면 상태', '음문 상태'].includes(part.label)));
  wife.situationStats.hypnosis = 20;
  wife.situationStats.crest = 41;
  const fantasyMiddle = hooks.imagePrompt.after(debugContactBase, [wife, 'fantasy-stage']);
  assert.match(fantasyMiddle.prompt, /ringed_eyes:0\.85/);
  assert.match(fantasyMiddle.prompt, /pubic_tattoo/);
  assert.match(fantasyMiddle.prompt, /single clear magenta crest on the woman's exposed lower abdomen between navel and pubic bone/);
  assert.doesNotMatch(fantasyMiddle.parts.find(part => part.label === '최면 상태').tags,
    /question marks?|hearts?|glow|pink/i, 'low hypnosis stages must leave the head and palette untouched');
  for (const [index, color] of ['faint pale pink', 'light pink', 'clear magenta', 'vivid magenta', 'deep crimson-magenta'].entries()) {
    wife.situationStats.crest = (index + 1) * 20;
    const stagePrompt = hooks.imagePrompt.after(debugContactBase, [wife, 'crest-stage']);
    const crestTags = stagePrompt.parts.find(part => part.label === '음문 상태').tags;
    assert.ok(crestTags.includes(`single ${color} crest on the woman's exposed lower abdomen between navel and pubic bone`));
    assert.equal((crestTags.match(/pubic_tattoo/g) || []).length, 1);
    assert.match(stagePrompt.negativePrompt, /male tattoo, hand tattoo, duplicate crest/);
    if (index < 3) assert.doesNotMatch(crestTags, /glow/);
    else assert.match(crestTags, index === 3 ? /glowing_tattoo:1\.15/ : /glowing_tattoo:1\.4/);
  }
  wife.situationStats.crest = 41;
  for (let stage = 1; stage <= 5; stage++) {
    wife.situationStats.hypnosis = stage * 20;
    const hypnosisTags = hooks.imagePrompt.after(debugContactBase, [wife, 'hypnosis-stage'])
      .parts.find(part => part.label === '최면 상태').tags;
    assert.equal((hypnosisTags.match(/question mark/g) || []).length, stage >= 3 ? 1 : 0);
    assert.doesNotMatch(hypnosisTags, /glowing_eyes|lighting|background|hearts?/);
    if (stage === 4) assert.match(hypnosisTags, /pink_eyes.*woman's irises/);
    if (stage === 5) assert.match(hypnosisTags, /purple_eyes.*woman's irises/);
  }
  wife.situationStats.hypnosis = 20;
  const coveredKey = 'elena__scene-sex__outfit-modest__exp-0000000__v-0';
  const coveredBase = { ...debugContactBase, key: coveredKey };
  const fantasyCovered = hooks.imagePrompt.after(coveredBase, [wife, 'fantasy-covered']);
  assert.match(fantasyCovered.prompt, /ringed_eyes/, 'hypnosis should also affect a clothed portrait');
  assert.doesNotMatch(fantasyCovered.prompt, /pubic_tattoo/, 'crest must stay hidden under a skirt');
  assert.doesNotMatch(fantasyCovered.negativePrompt, /male tattoo/, 'the crest Negative must stay hidden too');
  assert.ok(!fantasyCovered.parts.some(part => part.label === '음문 상태'));
  const coveredImageKey = hooks.imageKey.after(coveredKey, [wife]);
  wife.situationStats.crest = 100;
  assert.equal(hooks.imageKey.after(coveredKey, [wife]), coveredImageKey,
    'a hidden crest must not change the portrait image key');
  wife.situationStats.crest = 41;
  for (const exposedKey of ['elena__scene-sex__outfit-modest__exp-0001000__v-0',
    'elena__scene-sex__outfit-modest__exp-0000100__v-0',
    'elena__scene-sex__outfit-nude__exp-0000000__v-0']) {
    assert.match(hooks.imagePrompt.after({ ...debugContactBase, key: exposedKey }, [wife, 'fantasy-exposed']).prompt,
      /pubic_tattoo/, 'lifting or removing the skirt, or nudity, must expose the crest');
  }
  assert.doesNotMatch(hooks.imagePrompt.after({ ...debugContactBase,
    key: 'elena__scene-sex__outfit-modest__exp-0000010__v-0' }, [wife, 'fantasy-panties-aside']).prompt,
  /pubic_tattoo/, 'moving panties aside alone must not expose the lower abdomen');
  savedSettings = { ...beforeFantasySettings,
    prompts: { ...beforeFantasySettings.prompts, 'hstatus.hypnosis.1': '(slightly distant gaze:1.08)' } };
  assert.match(hooks.imagePrompt.after(debugContactBase, [wife, 'fantasy-stage']).prompt,
    /ringed_eyes/, 'the original saved default should migrate');
  savedSettings = { ...beforeFantasySettings,
    prompts: { ...beforeFantasySettings.prompts,
      'hstatus.hypnosis.1': '(slightly distant gaze:1.08), (one small pale pink question mark beside her head:1.2)',
      'hstatus.crest.3': '(clear magenta magical crest on her lower abdomen:1.25)' } };
  assert.match(hooks.imagePrompt.after(debugContactBase, [wife, 'fantasy-stage']).prompt,
    /pubic_tattoo/, 'the previous crest default should migrate');
  assert.match(hooks.imagePrompt.after(debugContactBase, [wife, 'fantasy-stage']).prompt,
    /ringed_eyes/, 'the previous saved hypnosis default should migrate');
  savedSettings = beforeFantasySettings;
  const fantasyMiddleKey = hooks.imageKey.after(debugContactKey, [wife]);
  wife.situationStats.hypnosis = 21;
  wife.situationStats.crest = 100;
  const fantasyHigh = hooks.imagePrompt.after(debugContactBase, [wife, 'fantasy-stage']);
  assert.match(fantasyHigh.prompt, /ringed_eyes:0\.95/);
  assert.match(fantasyHigh.prompt, /single deep crimson-magenta crest on the woman's exposed lower abdomen between navel and pubic bone/);
  assert.doesNotMatch(fantasyHigh.parts.find(part => part.label === '음문 상태').tags,
    /hands?|\bman\b/i, 'the crest Positive must stay localized to the woman');
  savedSettings = { ...beforeFantasySettings,
    prompts: { ...beforeFantasySettings.prompts,
      'hstatus.hypnosis.2': '(ringed_eyes:1.3), (unfocused gaze:1.2), (two pink question marks beside her head:1.25)',
      'hstatus.crest.5': '(pubic_tattoo:1.35), (intense crimson-magenta sigil centered on exposed lower abdomen between navel and pubic bone:1.4), bright glow confined to the sigil' } };
  const migratedFantasy = hooks.imagePrompt.after(debugContactBase, [wife, 'fantasy-migrated']);
  assert.match(migratedFantasy.prompt, /ringed_eyes:0\.95/);
  assert.match(migratedFantasy.prompt, /single deep crimson-magenta crest/);
  savedSettings = { ...beforeFantasySettings, prompts: { ...beforeFantasySettings.prompts,
    'hstatus.crest.4': '(pubic_tattoo:1.1), (single vivid magenta crest on the woman\'s exposed lower abdomen between navel and pubic bone:1.25), (faint glow confined to the crest:1.1)',
    'hstatus.crest.5': '(pubic_tattoo:1.1), (single deep crimson-magenta crest on the woman\'s exposed lower abdomen between navel and pubic bone:1.25), (visible glow confined to the crest:1.1)',
  } };
  for (const [stage, weight] of [[4, '1.15'], [5, '1.4']]) {
    wife.situationStats.crest = stage * 20;
    assert.ok(hooks.imagePrompt.after(debugContactBase, [wife, 'crest-default-migrated'])
      .prompt.includes(`glowing_tattoo:${weight}`), 'the last release\'s saved crest default must gain the learned glow tag');
  }
  wife.situationStats.crest = 100;
  savedSettings = beforeFantasySettings;
  savedSettings = { ...beforeFantasySettings,
    negativePrompts: { ...beforeFantasySettings.negativePrompts, 'hstatus.crest.5': '' } };
  assert.doesNotMatch(hooks.imagePrompt.after(debugContactBase, [wife, 'crest-negative-cleared']).negativePrompt,
    /male tattoo, hand tattoo, duplicate crest/, 'clearing the migrated Negative must remain editable');
  savedSettings = beforeFantasySettings;
  assert.notEqual(hooks.imageKey.after(debugContactKey, [wife]), fantasyMiddleKey,
    'crossing a status tier must change the portrait image key');
  collectNodes().find(node => node.tag === 'button' && node.children[0] === 'H Status').props.onclick();
  const fantasyField = collectNodes().find(node => node.props?.['data-aip-field-prompt'] === 'hstatus.hypnosis.2:positive');
  assert.match(fantasyField.props.value, /ringed_eyes:0\.95/);
  fantasyField.props.onchange({ currentTarget: { value: 'custom_hypnosis_stage_two' } });
  collectNodes().find(node => node.props?.['data-aip-field-prompt'] === 'hstatus.crest.5:negative')
    .props.onchange({ currentTarget: { value: 'custom_crest_negative' } });
  assert.equal(savedSettings.prompts['hstatus.hypnosis.2'], 'custom_hypnosis_stage_two');
  const fantasyEdited = hooks.imagePrompt.after(debugContactBase, [wife, 'fantasy-stage']);
  assert.match(fantasyEdited.prompt, /custom_hypnosis_stage_two/);
  assert.match(fantasyEdited.negativePrompt, /custom_crest_negative/);
  assert.doesNotMatch(hooks.imagePrompt.after(coveredBase, [wife, 'fantasy-covered']).negativePrompt,
    /custom_crest_negative/, 'a hidden crest must omit its Negative prompt too');
  assert.notEqual(hooks.imageKey.after(debugContactKey, [wife]), fantasyHigh.key,
    'editing the stage prompts must invalidate the portrait image key');
  savedSettings = beforeFantasySettings;
  if (beforeFantasyStats === undefined) delete wife.situationStats;
  else wife.situationStats = beforeFantasyStats;
  hooks.imagePrompt.after(debugContactBase, [wife, 'cycle-debug']);
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '이미지 디버거').props.onclick();
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '현재 장면 4단계 계산').props.onclick();
  assert.equal(collectNodes().filter(node => node.props?.['data-aip-cycle-variant'] !== undefined).length, 5,
    'the debugger must compare four cycle phases and the first vaginal insertion');
  assert.match(collectNodes().find(node => node.props?.['data-aip-cycle-positive'] === 'menstrual').props.value,
    /small visible trace of muted red menstrual blood/);
  assert.match(collectNodes().find(node => node.props?.['data-aip-cycle-negative'] === 'menstrual').props.value,
    /blood splatter/);
  assert.match(collectNodes().find(node => node.props?.['data-aip-cycle-positive'] === 'ovulation').props.value,
    /debug_cycle_positive/);
  assert.match(collectNodes().find(node => node.props?.['data-aip-cycle-negative'] === 'ovulation').props.value,
    /debug_cycle_negative/);
  assert.match(collectNodes().find(node => node.props?.['data-aip-cycle-positive'] === 'first-experience').props.value,
    /pained wince.*one sharply defined thin red blood streak/);
  assert.match(collectNodes().find(node => node.props?.['data-aip-cycle-negative'] === 'first-experience').props.value,
    /heavy bleeding.*multiple blood streaks/);
  assert.strictEqual(savedSettings, cycleDebugSettings, 'preview must not edit prompt settings');
  assert.equal(state.day, 10, 'preview must not advance the game cycle');
  assert.doesNotMatch(hooks.imagePrompt.after(debugContactBase, [wife, 'cycle-debug']).prompt, /menstrual blood/,
    'the virtual cycle phase must not leak into the live scene');
  const beforeDebugImages = generatedRequests.length;
  await collectNodes().find(node => node.tag === 'button' && node.children[0] === '4단계 비교 이미지 생성').props.onclick();
  const debugRequests = generatedRequests.slice(beforeDebugImages);
  assert.equal(debugRequests.length, 3, 'identical default phases should share one generated comparison image');
  assert.ok(debugRequests.every(request => request.imageKey.startsWith('aip_cycle_debug_')
    && request.bypassCache === true && request.debug?.source === 'attention-image-prompt-cycle-debug'));
  assert.ok(debugRequests.every(request => !Object.hasOwn(request, 'look')),
    'older debug prompt results without a look must retain their request shape');
  assert.equal(collectNodes().filter(node => node.props?.['data-aip-cycle-image'] !== undefined).length, 4);
  const firstExperienceCard = collectNodes().find(node => node.props?.['data-aip-cycle-variant'] === 'first-experience');
  await flattenNodes(firstExperienceCard).find(node => node.tag === 'button' && node.children[0] === '이미지 생성').props.onclick();
  assert.equal(generatedRequests.length, beforeDebugImages + 4, 'first experience generates only on its own button click');
  assert.match(generatedRequests.at(-1).imageKey, /^aip_cycle_debug_first-experience_/);
  assert.equal(collectNodes().filter(node => node.props?.['data-aip-cycle-image'] !== undefined).length, 5);
  const menstrualCard = collectNodes().find(node => node.props?.['data-aip-cycle-variant'] === 'menstrual');
  await flattenNodes(menstrualCard).find(node => node.tag === 'button' && node.children[0] === '다시 생성').props.onclick();
  assert.equal(generatedRequests.length, beforeDebugImages + 5, 'one phase can be regenerated independently');
  state.slot += 1;
  await flattenNodes(menstrualCard).find(node => node.tag === 'button' && node.children[0] === '다시 생성').props.onclick();
  assert.equal(generatedRequests.length, beforeDebugImages + 5, 'stale scene prompts must not generate');
  state.slot -= 1;
  activePortraitKey = 'elena__scene-other__outfit-modest__exp-1111111__v-0';
  await flattenNodes(menstrualCard).find(node => node.tag === 'button' && node.children[0] === '다시 생성').props.onclick();
  assert.equal(generatedRequests.length, beforeDebugImages + 5, 'a changed portrait scene must not generate from stale prompts');
  activePortraitKey = debugContactKey;
  debugContactBase.look = 'debug-look-a';
  hooks.imagePrompt.after(debugContactBase, [wife, 'cycle-debug']);
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '현재 장면 4단계 계산').props.onclick();
  let lookDebugCard = collectNodes().find(node => node.props?.['data-aip-cycle-variant'] === 'menstrual');
  await flattenNodes(lookDebugCard).find(node => node.tag === 'button' && node.children[0] === '이미지 생성').props.onclick();
  const firstLookDebugRequest = generatedRequests.at(-1);
  assert.equal(firstLookDebugRequest.look, 'debug-look-a', 'debug generation must retain the game look fingerprint');
  debugContactBase.look = 'debug-look-b';
  hooks.imagePrompt.after(debugContactBase, [wife, 'cycle-debug']);
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '현재 장면 4단계 계산').props.onclick();
  lookDebugCard = collectNodes().find(node => node.props?.['data-aip-cycle-variant'] === 'menstrual');
  await flattenNodes(lookDebugCard).find(node => node.tag === 'button' && node.children[0] === '이미지 생성').props.onclick();
  const secondLookDebugRequest = generatedRequests.at(-1);
  assert.equal(secondLookDebugRequest.look, 'debug-look-b');
  assert.notEqual(secondLookDebugRequest.imageKey, firstLookDebugRequest.imageKey,
    'debug images for different look fingerprints must not reuse the old image');
  delete debugContactBase.look;
  hooks.imagePrompt.after(debugContactBase, [wife, 'cycle-debug']);
  wife.situationStats = { ...beforeFantasyStats, hypnosis: 40, crest: 60 };
  const realFantasyStats = JSON.stringify(wife.situationStats);
  hooks.imagePrompt.after(debugContactBase, [wife, 'fantasy-debug']);
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '최면 0~5단계').props.onclick();
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '현재 장면 6단계 계산').props.onclick();
  assert.equal(collectNodes().filter(node => node.props?.['data-aip-cycle-variant'] !== undefined).length, 6);
  assert.match(collectNodes().find(node => node.props?.['data-aip-cycle-positive'] === 'hypnosis-1').props.value,
    /ringed_eyes:0\.85/);
  assert.match(collectNodes().find(node => node.props?.['data-aip-cycle-positive'] === 'hypnosis-5').props.value,
    /purple_eyes:1\.1/);
  assert.doesNotMatch(collectNodes().find(node => node.props?.['data-aip-cycle-positive'] === 'hypnosis-5').props.value,
    /glowing_eyes|pink question marks|hearts beside her head/);
  const hypnosisCard = collectNodes().find(node => node.props?.['data-aip-cycle-variant'] === 'hypnosis-5');
  await flattenNodes(hypnosisCard).find(node => node.tag === 'button' && node.children[0] === '이미지 생성').props.onclick();
  assert.match(generatedRequests.at(-1).imageKey, /^aip_hypnosis_debug_hypnosis-5_/);
  assert.match(generatedRequests.at(-1).prompt, /empty stare/);
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '음문 0~5단계').props.onclick();
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '현재 장면 6단계 계산').props.onclick();
  assert.equal(collectNodes().filter(node => node.props?.['data-aip-cycle-variant'] !== undefined).length, 6);
  assert.match(collectNodes().find(node => node.props?.['data-aip-cycle-positive'] === 'crest-1').props.value,
    /single faint pale pink crest/);
  assert.match(collectNodes().find(node => node.props?.['data-aip-cycle-positive'] === 'crest-5').props.value,
    /single deep crimson-magenta crest on the woman's exposed lower abdomen/);
  const crestCard = collectNodes().find(node => node.props?.['data-aip-cycle-variant'] === 'crest-5');
  await flattenNodes(crestCard).find(node => node.tag === 'button' && node.children[0] === '이미지 생성').props.onclick();
  assert.match(generatedRequests.at(-1).imageKey, /^aip_crest_debug_crest-5_/);
  assert.match(generatedRequests.at(-1).prompt, /single deep crimson-magenta crest/);
  assert.match(generatedRequests.at(-1).negativePrompt, /male tattoo, hand tattoo, duplicate crest/);
  assert.equal(JSON.stringify(wife.situationStats), realFantasyStats, 'debug previews must not change live H-Status values');
  assert.doesNotMatch(hooks.imagePrompt.after(debugContactBase, [wife, 'fantasy-debug']).prompt,
    /empty stare|single deep crimson-magenta crest/, 'debug stages must not leak into the live portrait');
  const toyDebugKey = debugContactKey.replace('outfit-modest', 'outfit-nude');
  const toyDebugBase = { ...debugContactBase, key: toyDebugKey };
  activePortraitKey = toyDebugKey;
  lastImagePromptInput = { result: toyDebugBase };
  hooks.imagePrompt.after(toyDebugBase, [wife, 'toy-debug']);
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '토이 3종').props.onclick();
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '현재 장면 토이 3종 계산').props.onclick();
  assert.equal(collectNodes().filter(node => node.props?.['data-aip-cycle-variant'] !== undefined).length, 3);
  assert.match(collectNodes().find(node => node.props?.['data-aip-cycle-positive'] === 'toy-egg').props.value,
    /egg_vibrator:1\.1.*vaginal_object_insertion.*vibrator_cord.*fully inside her vagina.*only its cord visible/);
  assert.match(collectNodes().find(node => node.props?.['data-aip-cycle-positive'] === 'toy-penis').props.value,
    /dildo:1\.1.*vibrator.*vaginal_object_insertion.*fully inside her vagina.*only its base visible/);
  assert.match(collectNodes().find(node => node.props?.['data-aip-cycle-negative'] === 'toy-egg').props.value,
    /multiple vibrators.*detached vibrator.*vibrator outside body:1\.4.*holding_sex_toy/);
  const eggCard = collectNodes().find(node => node.props?.['data-aip-cycle-variant'] === 'toy-egg');
  await flattenNodes(eggCard).find(node => node.tag === 'button' && node.children[0] === '이미지 생성').props.onclick();
  assert.match(generatedRequests.at(-1).imageKey, /^aip_toy_debug_toy-egg_/);
  assert.match(generatedRequests.at(-1).prompt, /egg_vibrator.*fully inside her vagina/);
  assert.match(generatedRequests.at(-1).negativePrompt, /vibrator outside body:1\.4.*holding_sex_toy/);
  const penisCard = collectNodes().find(node => node.props?.['data-aip-cycle-variant'] === 'toy-penis');
  await flattenNodes(penisCard).find(node => node.tag === 'button' && node.children[0] === '이미지 생성').props.onclick();
  assert.match(generatedRequests.at(-1).imageKey, /^aip_toy_debug_toy-penis_/);
  assert.match(generatedRequests.at(-1).prompt, /dildo:1\.1.*fully inside her vagina/);
  assert.match(generatedRequests.at(-1).negativePrompt, /dildo outside body:1\.4.*holding_sex_toy/);
  assert.equal(JSON.stringify(wife.situationStats), realFantasyStats, 'toy preview must not change live jewelry state');
  assert.doesNotMatch(hooks.imagePrompt.after(toyDebugBase, [wife, 'toy-debug']).prompt,
    /egg_vibrator|vaginal_object_insertion|dildo:1\.2/, 'virtual toys must not leak into the live portrait');
  if (beforeFantasyStats === undefined) delete wife.situationStats;
  else wife.situationStats = beforeFantasyStats;
  savedSettings = beforeCycleDebugSettings;
  state.activeScene = beforeCycleDebugScene;
  if (beforeCycleDebugDay === undefined) delete state.day;
  else state.day = beforeCycleDebugDay;
  activePortraitKey = beforeCycleDebugPortrait;
  lastImagePromptInput = beforeCycleDebugInput;
  if (beforeCycleDebugOverride === undefined) delete wife.sceneOverride;
  else wife.sceneOverride = beforeCycleDebugOverride;
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '이미지팩 제작').props.onclick();
  const packButton = collectNodes().find(node => node.tag === 'button' && node.children[0] === '현재 아내 이미지팩 만들기');
  assert.ok(packButton, 'dedicated image pack builder is visible');
  const packManifestResets = imageManifestResets;
  await packButton.props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(imageManifestResets, packManifestResets + 1, 'pack export must refresh generated image entries');
  assert.equal(savedImagePackFile?.name, 'image-pack.js');
  assert.equal(savedImagePackFile?.type, 'text/javascript');
  const packWindow = {};
  vm.runInNewContext(savedImagePackFile.data, { window: packWindow });
  const pack = packWindow.__WAYWARD_IMAGE_PACKS__[0];
  assert.equal(pack.entryCount, 5);
  assert.deepEqual(Object.keys(pack.entries).sort(), ['elena__aip-att-spent__v-0', offlineKey,
    'elena__position-missionary__v-0', offlineShortKey, 'elena__scene-patron_chatting__aipk-test__v-0']);
  assert.equal(pack.entries['elena__aip-att-spent__v-0'].source, 'attention-image-prompt');
  assert.equal(pack.entries['elena__scene-patron_chatting__aipk-test__v-0'].imagePath,
    'illustrious/characters/elena/bounded.webp');
  assert.equal(pack.entries[offlineKey].imagePath, 'illustrious/characters/elena/offline.webp');
  assert.equal(pack.entries[offlineShortKey].imagePath, 'illustrious/characters/elena/offline-short.webp');
  const writtenPackFiles = new Map();
  const testDirectory = prefix => ({
    async getDirectoryHandle(name) { return testDirectory(`${prefix}${name}/`); },
    async getFileHandle(name) { return { async createWritable() { return {
      async write(data) { writtenPackFiles.set(`${prefix}${name}`, data); },
      async close() {},
      async abort() {},
    }; } }; },
  });
  vmContext.window.showDirectoryPicker = async () => testDirectory('');
  settingsWin.refresh();
  const folderButton = collectNodes().find(node => node.tag === 'button' && node.children[0] === '그림 포함 폴더로 저장');
  assert.ok(folderButton, 'supported browsers should offer a complete image folder export');
  await folderButton.props.onclick();
  for (let attempt = 0; attempt < 20 && writtenPackFiles.size < 6; attempt++) await new Promise(resolve => setImmediate(resolve));
  const exportedPaths = [...writtenPackFiles.keys()];
  assert.equal(exportedPaths.filter(path => path.includes('/images/')).length, 5,
    'folder export must include every selected image file');
  const catalogPath = exportedPaths.find(path => path.endsWith('/wml/mods/attention-image-prompt/image-pack.js'));
  assert.match(catalogPath || '', /^attention-image-prompt-elena-\d+\//,
    'folder export must create a separate pack folder before writing');
  assert.equal(exportedPaths.at(-1), catalogPath, 'the catalog should be written only after all images');
  const folderPackWindow = {};
  vm.runInNewContext(writtenPackFiles.get(catalogPath).parts.join(''), { window: folderPackWindow });
  assert.equal(folderPackWindow.__WAYWARD_IMAGE_PACKS__[0].entryCount, 5);
  const cancelledPaths = [];
  const cancelDirectory = prefix => ({
    async getDirectoryHandle(name) { return cancelDirectory(`${prefix}${name}/`); },
    async getFileHandle(name) { return { async createWritable() { return {
      async write() {
        cancelledPaths.push(`${prefix}${name}`);
        if (cancelledPaths.length === 1) collectNodes().find(node => node.tag === 'button'
          && node.children[0] === '내보내기 중지').props.onclick();
      },
      async close() {},
      async abort() {},
    }; } }; },
  });
  vmContext.window.showDirectoryPicker = async () => cancelDirectory('');
  settingsWin.refresh();
  await collectNodes().find(node => node.tag === 'button' && node.children[0] === '그림 포함 폴더로 저장').props.onclick();
  for (let attempt = 0; attempt < 20 && !collectNodes().some(node =>
    String(node.children?.[0]).includes('이미지팩 내보내기 중지')); attempt++) await new Promise(resolve => setImmediate(resolve));
  assert.equal(cancelledPaths.filter(path => path.includes('/images/')).length, 1);
  assert.ok(!cancelledPaths.some(path => path.endsWith('/image-pack.js')),
    'cancelled exports must not leave a loadable incomplete catalog');
  const previousPackManifest = imageManifestEntries;
  const previousProfiles = vmContext.__WAYWARD_CHARACTER_PROMPT_PROFILES__;
  const previousGeneratedArchetype = wife.generatedArchetype;
  wife.generatedArchetype = { shortname: 'rezetest' };
  vmContext.__WAYWARD_CHARACTER_PROMPT_PROFILES__ = [{ shortname: 'rezetest' }];
  imageManifestEntries = {
    custom: { talentName: 'rezetest__aip-state-test__v-0', imagePath: 'illustrious/characters/unknown/rezetest_state_test.webp' },
    other: { talentName: 'otherwife__aip-state-test__v-0', imagePath: 'illustrious/characters/unknown/otherwife_state_test.webp' },
  };
  settingsWin.refresh();
  await collectNodes().find(node => node.tag === 'button' && node.children[0] === '현재 아내 이미지팩 만들기').props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  const customPackWindow = {};
  vm.runInNewContext(savedImagePackFile.data, { window: customPackWindow });
  assert.deepEqual(Object.keys(customPackWindow.__WAYWARD_IMAGE_PACKS__[0].entries), ['rezetest__aip-state-test__v-0'],
    'a custom wife image in the server unknown folder must be exportable without including other wives');
  imageManifestEntries = previousPackManifest;
  if (previousProfiles === undefined) delete vmContext.__WAYWARD_CHARACTER_PROMPT_PROFILES__;
  else vmContext.__WAYWARD_CHARACTER_PROMPT_PROFILES__ = previousProfiles;
  if (previousGeneratedArchetype === undefined) delete wife.generatedArchetype;
  else wife.generatedArchetype = previousGeneratedArchetype;
  delete vmContext.window.showDirectoryPicker;
  settingsWin.refresh();
  const offlineLookup = await hooks.imageLookup.around(async () => ({ talentName: 'old-nearest' }), offlineKey);
  assert.equal(offlineLookup?.imagePath, 'illustrious/characters/elena/offline.webp',
    'an offline generated image must remain available by exact key');
  const offlineShortLookup = await hooks.imageLookup.around(async () => null, offlineShortKey);
  assert.equal(offlineShortLookup?.imagePath, 'illustrious/characters/elena/offline-short.webp',
    'a compact generated image must remain available from the local cache without the server');
  assert.equal(offlineShortLookup?.prompt, 'offline positive');
  assert.equal(offlineShortLookup?.negativePrompt, 'offline negative');
  const offlinePreviewLookup = await hooks.imageLookup.around(async () => ({ talentName: 'old-nearest' }), offlinePreviewKey);
  assert.equal(offlinePreviewLookup?.imagePath, 'illustrious/characters/unknown/wife_preview_test_1.webp',
    'a previously generated ordinary portrait must load without the image server');
  assert.equal(hooks.imageUrl.after('', [offlinePreviewLookup]), 'images/illustrious/characters/unknown/wife_preview_test_1.webp');
  assert.equal(await hooks.imageLookup.around(async () => ({ talentName: 'old-nearest' }), missingKey), null,
    'missing local images must not appear in the pack or lookup');
  const deletedImageKey = 'elena__task-idle__v-98231';
  assert.equal(await hooks.imageLookup.around(async key => ({
    talentName: key, imagePath: 'missing.webp', source: 'server',
  }), deletedImageKey), null, 'a stale cache entry must not display a deleted image');
  const blockedExistingKey = 'elena__task-idle__v-98233';
  const blockedExistingEntry = { talentName: blockedExistingKey, imagePath: 'head-blocked-existing.webp', source: 'server' };
  assert.equal(await hooks.imageLookup.around(async () => blockedExistingEntry, blockedExistingKey), blockedExistingEntry,
    'an existing image must remain usable when the browser blocks HEAD');
  const blockedMissingKey = 'elena__task-idle__v-98234';
  const blockedMissingEntry = { talentName: blockedMissingKey, imagePath: 'head-blocked-missing.webp', source: 'server' };
  assert.equal(await hooks.imageLookup.around(async () => blockedMissingEntry, blockedMissingKey), null,
    'a failed image load must invalidate a stale cache entry when HEAD is blocked');
  assert.match(imageProbeUrls.at(-1), /head-blocked-missing\.webp\?aip_file_check=\d+/);
  let blockedMissingRegenerations = 0;
  await hooks.imageGenerate.around(async request => {
    assert.equal(request.imageKey, blockedMissingKey);
    if (await hooks.imageLookup.around(async () => blockedMissingEntry, request.imageKey)) return { url: 'broken.webp' };
    blockedMissingRegenerations += 1;
    return { url: 'replacement.webp' };
  }, { imageKey: blockedMissingKey, prompt: 'replacement portrait', negativePrompt: '' });
  assert.equal(blockedMissingRegenerations, 1, 'a missing image must regenerate with the unchanged key');
  let replacementKey = '';
  await hooks.imageGenerate.around(async request => {
    replacementKey = request.imageKey;
    return { url: 'https://example.test/replacement.webp' };
  }, { imageKey: deletedImageKey, prompt: 'replacement portrait', negativePrompt: '' });
  assert.equal(replacementKey, deletedImageKey,
    'regeneration after a missing file must use the original image key');
  const deletedPositionKey = 'elena__position-missing-fixture__v-98232';
  const deletedPositionRequest = { imageKey: deletedPositionKey, prompt: 'replacement pose', negativePrompt: '' };
  await hooks.imageGenerate.around(async () => ({ url: 'https://example.test/missing.webp' }), deletedPositionRequest);
  let replacementPositionCalls = 0;
  await hooks.imageGenerate.around(async request => {
    replacementPositionCalls += 1;
    assert.equal(request.imageKey, deletedPositionKey);
    return { url: 'https://example.test/replacement-position.webp' };
  }, deletedPositionRequest);
  assert.equal(replacementPositionCalls, 1,
    'a deleted in-memory position result must generate again under its original image key');
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '아내 캐릭터').props.onclick();
  imageManifestEntries = {};
  localCacheFixture = { version: 1, entries: {} };
  for (const scene of ['patron_anal_finish', 'finish_on_back_anal_internal']) {
    const key = `elena__scene-${scene}__outfit-modest__v-0`;
    const oral = { talentName: 'elena__scene-patron_blowjob__outfit-modest__v-0' };
    assert.equal(await hooks.imageLookup.around(async () => oral, key), null,
      'an anal finish must not display an unrelated oral fallback');
    const anal = { talentName: 'elena__scene-patron_anal__outfit-modest__v-0' };
    assert.equal(await hooks.imageLookup.around(async () => anal, key), anal,
      'an anal finish may reuse an anal-scene image');
  }

  const settingsBeforeResiduePicker = savedSettings;
  const wifeSituationBeforeResiduePicker = wife.situationStats;
  const pickerImageKey = 'situation_fluid__elena__mouth__stage-0';
  const firstPickerItem = { key: `${pickerImageKey}__v-1700000000101`, url: 'https://example.test/residue-selected.webp', createdAt: 1700000000101 };
  const secondPickerItem = { key: `${pickerImageKey}__v-1700000000102`, url: 'https://example.test/residue-other.webp', createdAt: 1700000000102 };
  savedSettings = {
    ...savedSettings,
    residueImageChoices: { [pickerImageKey]: { selected: firstPickerItem.key, items: [firstPickerItem, secondPickerItem] } },
    residuePrompts: {
      ...(savedSettings.residuePrompts || {}),
      [pickerImageKey]: { positivePrompt: 'masterpiece, face', negativePrompt: 'blurry, full body' },
    },
  };
  const residueWindowPacksBefore = vmContext.window.__WAYWARD_IMAGE_PACKS__;
  const residueGlobalPacksBefore = vmContext.__WAYWARD_IMAGE_PACKS__;
  const residueBuiltInPacks = [
    { packId: 'wayward-situation-pippa-v1', entries: {
      'situation_fluid__pippa__mouth__stage-0': { imagePath: 'illustrious/situation/info/pippa/mouth_stage-0.webp' },
      'situation_vulva__pippa__wetness-0__jewelry-0': { imagePath: 'illustrious/situation/info/pippa/vulva.webp' },
    } },
    { packId: 'wayward-situation-mara-v1', entries: {
      'situation_fluid__mara__mouth__stage-0': { imagePath: 'illustrious/situation/info/mara/mouth_stage-0.webp' },
    } },
    { packId: 'wayward-situation-status-v1', entries: {
      'situation_status__pippa__mouth-hypnosis__stage-3': { imagePath: 'illustrious/situation/status/pippa/mouth-3.webp' },
      'situation_status__pippa__mouth-hypnosis__stage-4': { imagePath: 'illustrious/situation/status/pippa/mouth-4.webp' },
      'situation_status__pippa__vulva-crest__stage-2': { imagePath: 'illustrious/situation/status/pippa/vulva-2.webp' },
      'situation_status__mara__mouth-hypnosis__stage-3': { imagePath: 'illustrious/situation/status/mara/mouth-3.webp' },
    } },
  ];
  vmContext.window.__WAYWARD_IMAGE_PACKS__ = residueBuiltInPacks;
  vmContext.__WAYWARD_IMAGE_PACKS__ = residueBuiltInPacks;
  savedSettings.residuePartSources = { vulva: 'pippa' };
  wife.situationStats = { hypnosis: 45, crest: 35 };
  const expandListeners = {};
  const residueExpand = {
    dataset: {},
    addEventListener(name, listener) { expandListeners[name] = listener; },
    click() { expandListeners.click?.({ preventDefault() {}, stopPropagation() {} }); },
    keydown(key) { expandListeners.keydown?.({ key, preventDefault() {}, stopPropagation() {} }); },
  };
  const residueImage = {
    src: 'https://example.test/residue-auto.webp', currentSrc: '', dataset: {}, style: {},
    getAttribute(name) { return name === 'src' ? this.src : null; },
  };
  const residueOverlay = { src: 'https://example.test/residue-overlay.webp', currentSrc: '' };
  let residueControls = null;
  const atelierStyle = () => ({
    setProperty(name, value) { this[name] = value; },
    removeProperty(name) { delete this[name]; },
  });
  const atelierBaseButton = { hidden: false, style: atelierStyle() };
  const atelierBaseInfo = { hidden: false, style: atelierStyle() };
  let atelierStatusButton = null;
  const atelierActions = { hidden: false, style: atelierStyle(),
    querySelectorAll: selector => selector === '[data-ca-kind="base"],[data-ca-info="base"]'
      ? [atelierBaseButton, atelierBaseInfo] : [],
    querySelector: selector => selector === '[data-ca-kind="status"]' ? atelierStatusButton : null,
  };
  const legacyResidueControls = { hidden: false, style: { setProperty(name, value, priority) {
    assert.deepEqual([name, value, priority], ['display', 'none', 'important']);
  } } };
  const residueCard = {
    dataset: {},
    querySelector(selector) {
      if (selector === 'img.ko-se-fluid-image') return residueImage;
      if (selector === '.ko-se-fluid-expand') return residueExpand;
      if (selector === '.ko-se-status-overlay') return residueOverlay;
      if (selector === ':scope > .ca-hstatus-actions') return atelierActions;
      if (selector === '[data-attention-residue-controls]') return legacyResidueControls;
      if (selector === '[data-aip-residue-controls]') return residueControls;
      if (selector === '[data-aip-residue-controls] [data-attention-residue-select]') return residueControls?.children.find(node => node.dataset?.attentionResidueSelect === '') || null;
      if (selector === '[data-aip-residue-controls] [data-attention-residue-source]') return residueControls?.children.find(node => node.dataset?.attentionResidueSource) || null;
      if (selector === '[data-aip-residue-controls] [data-attention-residue-regenerate]') return residueControls?.children.find(node => node.dataset?.attentionResidueRegenerate === '') || null;
      if (selector === '[data-aip-residue-controls],[data-ko-se-residue-settings],[data-ko-se-residue-regenerate]') return residueControls;
      return null;
    },
    append(node) { residueControls = node; node.remove = () => { if (residueControls === node) residueControls = null; }; },
  };
  secretSections = [{ querySelectorAll: selector => selector === '.ko-se-fluid-grid > .ko-se-fluid-card' ? [residueCard] : [] }];
  secretFullscreenImage = { src: 'https://example.test/black.webp', style: {} };
  secretFullscreenOverlay = { src: '', style: {} };
  pauseObserverCallback();
  animationFrameCallback();
  let residuePresetPack = residueBuiltInPacks.at(-1);
  assert.equal(residuePresetPack.packId, 'wayward-situation-aip-residue-presets');
  assert.equal(residuePresetPack.entries['situation_vulva__elena__wetness-0__jewelry-0']?.imagePath,
    'illustrious/situation/info/pippa/vulva.webp', 'the exact Pippa vulva state should replace the H-Status local lookup');
  assert.equal(residuePresetPack.entries['situation_status__elena__vulva-crest__stage-2']?.imagePath,
    'illustrious/situation/status/pippa/vulva-2.webp', 'the matching crest overlay should follow the selected character');
  assert.equal(legacyResidueControls.hidden, true, 'AIP should hide ImageStudio\'s bundled older controls');
  assert.ok(residueControls, 'AIP controls should render even when older controls exist');
  assert.equal(atelierBaseButton.hidden, true, 'AIP should hide the separate base-image regeneration button');
  assert.equal(atelierActions.hidden, true, 'AIP should hide the empty separate regeneration bar');
  const secretModeButton = secretModeToolbar?.children?.find(node => node.textContent === '부위별 이미지 생성 방식');
  assert.ok(secretModeButton, 'the secret tab should expose generation modes as a separate button');
  secretModeButton.click();
  assert.equal(openedSettingsWindow.options.title, '부위별 이미지 생성 방식');
  let secretModeNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.equal(secretModeNodes.filter(node => node.props?.['data-hstatus-generation-mode']).length, 5,
    'the secret-tab mode window should configure every H-Status body part');
  assert.equal(residueImage.src, firstPickerItem.url, 'the selected secret image should replace the automatic card image');
  assert.equal(residueImage.style.objectFit, 'cover', 'selected secret images should fill the original 4:3 H-Status frame');
  residueExpand.click();
  assert.equal(secretFullscreenImage.src, firstPickerItem.url,
    'fullscreen should use the currently displayed selected image instead of H-Status React state');
  assert.equal(secretFullscreenOverlay.src, residueOverlay.src, 'fullscreen should keep the matching status overlay');
  const residueSourceSelect = residueControls.children.find(node => node.dataset?.attentionResidueSource === 'mouth');
  assert.equal(residueSourceSelect.value, 'generate');
  residueSourceSelect.value = 'pippa';
  residueSourceSelect.onchange({ currentTarget: residueSourceSelect });
  residuePresetPack = residueBuiltInPacks.at(-1);
  assert.equal(residuePresetPack.entries[pickerImageKey]?.imagePath,
    'illustrious/situation/info/pippa/mouth_stage-0.webp', 'Pippa mode should resolve the same mouth state from the built-in pack');
  assert.equal(residuePresetPack.entries['situation_status__elena__mouth-hypnosis__stage-3']?.imagePath,
    'illustrious/situation/status/pippa/mouth-3.webp', 'the hypnosis overlay should use Pippa at the same tier');
  wife.situationStats.hypnosis = 61;
  pauseObserverCallback();
  animationFrameCallback();
  assert.equal(residuePresetPack.entries['situation_status__elena__mouth-hypnosis__stage-4']?.imagePath,
    'illustrious/situation/status/pippa/mouth-4.webp', 'changing status should replace the overlay tier');
  assert.equal(residuePresetPack.entries['situation_status__elena__mouth-hypnosis__stage-3'], undefined);
  wife.situationStats.hypnosis = 45;
  residueSourceSelect.value = 'mara';
  residueSourceSelect.onchange({ currentTarget: residueSourceSelect });
  assert.equal(savedSettings.residuePartSources.mouth, 'mara');
  assert.equal(residuePresetPack.entries[pickerImageKey]?.imagePath,
    'illustrious/situation/info/mara/mouth_stage-0.webp', 'switching presets must not leave Pippa artwork behind');
  assert.equal(residuePresetPack.entries['situation_status__elena__mouth-hypnosis__stage-3']?.imagePath,
    'illustrious/situation/status/mara/mouth-3.webp');
  residueSourceSelect.value = 'generate';
  residueSourceSelect.onchange({ currentTarget: residueSourceSelect });
  assert.equal(savedSettings.residuePartSources.mouth, 'generate');
  assert.equal(residuePresetPack.entries[pickerImageKey], undefined,
    'returning to generated mode must remove the built-in alias');
  assert.equal(residuePresetPack.entries['situation_status__elena__mouth-hypnosis__stage-3'], undefined);
  residueControls.children.find(node => node.textContent === '프롬프트 수정').click();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(openedSettingsWindow.options.title, '잔류 상태 프롬프트 · 입');
  assert.equal(openedSettingsWindow.options.width, 1180);
  let residueEditorNodes = flattenNodes(openedSettingsWindow.body.children);
  const residueEditorLayout = residueEditorNodes.find(node => node.props?.['data-residue-prompt-layout'] === '');
  assert.match(residueEditorLayout.props.style, /display:grid/);
  assert.match(residueEditorLayout.props.style, /grid-template-columns:minmax\(0,1fr\) 340px/,
    'the prompt library should stay in a fixed right-hand column');
  assert.ok(residueEditorNodes.find(node => node.props?.['data-residue-prompt-library'] === ''),
    'the secret prompt editor should keep its tag and preset library beside the text fields');
  for (const polarity of ['positive', 'negative']) {
    const applied = residueEditorNodes.find(node => node.props?.['data-residue-applied-tags'] === polarity);
    assert.ok(applied, `the current ${polarity} prompt should expose its Korean tag list`);
    assert.ok(flattenNodes(applied).some(node => node.props?.['data-prompt-tag']),
      `the current ${polarity} prompt should render translated prompt chips`);
  }
  const appliedMasterpiece = flattenNodes(residueEditorNodes.find(node =>
    node.props?.['data-residue-applied-tags'] === 'positive'))
    .find(node => node.props?.['data-prompt-tag'] === 'masterpiece');
  assert.deepEqual(appliedMasterpiece.children, ['최고 수준 작품']);
  assert.match(appliedMasterpiece.props.title, /한글: 최고 수준 작품\n영문: masterpiece/);
  const residueMasterpieceTag = residueEditorNodes.find(node => node.props?.['data-residue-prompt-tag'] === 'masterpiece');
  const residueFairSkinTag = residueEditorNodes.find(node => node.props?.['data-residue-prompt-tag'] === 'fair skin');
  const residueUterusPreset = residueEditorNodes.find(node => node.props?.['data-residue-prompt-preset'] === 'secret-uterus-cutaway');
  assert.deepEqual(residueMasterpieceTag.children, ['최고 수준 작품']);
  assert.deepEqual(residueFairSkinTag.children, ['밝은 피부']);
  assert.match(residueMasterpieceTag.props.title, /한글: 최고 수준 작품/);
  assert.match(residueMasterpieceTag.props.title, /영문: masterpiece/);
  assert.match(residueUterusPreset.props.title, /h-status 겹쳐 표시/i);
  assert.match(residueUterusPreset.props.title, /\(fixed crop from navel to upper thighs:1\.8\)/);
  residueMasterpieceTag.props.onclick();
  residueEditorNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.match(residueEditorNodes.find(node => node.props?.['data-residue-prompt-input'] === 'positive').props.value, /masterpiece/);
  residueEditorNodes.find(node => node.props?.['data-residue-prompt-target'] === 'negative').props.onclick();
  residueEditorNodes = flattenNodes(openedSettingsWindow.body.children);
  residueEditorNodes.find(node => node.props?.['data-residue-prompt-tag'] === 'full body').props.onclick();
  residueEditorNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.match(residueEditorNodes.find(node => node.props?.['data-residue-prompt-input'] === 'negative').props.value, /full body/,
    'library clicks should append to the explicitly selected Positive or Negative field');
  const residuePickerButton = residueControls.children.find(node => node.dataset?.attentionResidueSelect === '');
  residuePickerButton.click();
  assert.equal(openedSettingsWindow.options.title, '잔류 상태 이미지 선택 · 입');
  let residuePickerNodes = flattenNodes(openedSettingsWindow.body.children);
  let residueRemoveButtons = residuePickerNodes.filter(node => node.props?.['data-residue-image-remove']);
  assert.equal(residueRemoveButtons.length, 2);
  dropResidueImageChoiceWrites = true;
  residuePickerNodes.find(node => node.props?.['data-residue-image-choice'] === secondPickerItem.key).props.onclick();
  dropResidueImageChoiceWrites = false;
  animationFrameCallback();
  assert.equal(residueImage.src, secondPickerItem.url,
    'a secret image selection should apply immediately even when persistent settings storage is full');
  const selectedLookup = await hooks.imageLookup.around(async key => key === secondPickerItem.key
    ? { talentName: key, imagePath: 'illustrious/characters/elena/residue-other.webp' }
    : null, pickerImageKey);
  assert.equal(selectedLookup?.talentName, secondPickerItem.key,
    'the game image lookup should resolve the selected secret image instead of relying only on DOM replacement');
  residuePickerNodes = flattenNodes(openedSettingsWindow.body.children);
  residuePickerNodes.find(node => node.props?.['data-residue-image-choice'] === firstPickerItem.key).props.onclick();
  animationFrameCallback();
  assert.equal(savedSettings.residueImageChoices[pickerImageKey].items.length, 1,
    'browser settings should retain only the selected secret image instead of the whole generated list');
  residueRemoveButtons.find(node => node.props['data-residue-image-remove'] === firstPickerItem.key).props.onclick();
  assert.equal(Object.prototype.hasOwnProperty.call(savedSettings.residueImageChoices, pickerImageKey), false,
    'removing the selected item should fall back to the automatic image');
  animationFrameCallback();
  assert.equal(residueImage.src, 'https://example.test/residue-auto.webp');
  assert.equal(residueImage.style.objectFit, '');
  residuePickerNodes = flattenNodes(openedSettingsWindow.body.children);
  residueRemoveButtons = residuePickerNodes.filter(node => node.props?.['data-residue-image-remove']);
  residueRemoveButtons[0].props.onclick();
  assert.equal(Object.prototype.hasOwnProperty.call(savedSettings.residueImageChoices, pickerImageKey), false,
    'removing the last item should remove only its saved list entry');
  animationFrameCallback();
  const manifestBeforeResidueRecovery = imageManifestEntries;
  const recoveredPickerItem = {
    key: `${pickerImageKey}__v-1700000000103`,
    imagePath: 'illustrious/characters/elena/recovered-mouth.webp',
    createdAt: 1700000000103,
  };
  imageManifestEntries = { [recoveredPickerItem.key]: { talentName: recoveredPickerItem.key, ...recoveredPickerItem } };
  residuePickerButton.click();
  await new Promise(resolve => setImmediate(resolve));
  await new Promise(resolve => setImmediate(resolve));
  residuePickerNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.ok(residuePickerNodes.some(node => node.props?.['data-residue-image-choice'] === recoveredPickerItem.key),
    'the picker should recover a generated mouth image from the ImageStudio manifest when settings lost its list');
  imageManifestEntries = manifestBeforeResidueRecovery;
  const normalizedBreastCard = { dataset: {}, querySelector: () => null, append() {} };
  wife.situationStats = { jewelryState: { breasts: { type: 'necklace', stage: 2 } } };
  secretSections = [{ querySelectorAll: selector => selector === '.ko-se-fluid-grid > .ko-se-fluid-card'
    ? [residueCard, normalizedBreastCard] : [] }];
  pauseObserverCallback();
  animationFrameCallback();
  assert.equal(normalizedBreastCard.dataset.aipResidueKey,
    'situation_fluid__elena__breasts__stage-0__jewelry-piercing-stage-2',
    'AIP must use the same normalized secret-tab image key as the updated H-Status');
  secretSections = [];
  secretFullscreenImage = null;
  secretFullscreenOverlay = null;
  savedSettings = settingsBeforeResiduePicker;
  if (residueWindowPacksBefore === undefined) delete vmContext.window.__WAYWARD_IMAGE_PACKS__;
  else vmContext.window.__WAYWARD_IMAGE_PACKS__ = residueWindowPacksBefore;
  if (residueGlobalPacksBefore === undefined) delete vmContext.__WAYWARD_IMAGE_PACKS__;
  else vmContext.__WAYWARD_IMAGE_PACKS__ = residueGlobalPacksBefore;
  if (wifeSituationBeforeResiduePicker === undefined) delete wife.situationStats;
  else wife.situationStats = wifeSituationBeforeResiduePicker;

  const originalWife = { shortname: wife.shortname, archetypeId: wife.archetypeId, generatedArchetype: wife.generatedArchetype, situationStats: wife.situationStats };
  const originalSettings = savedSettings;
  const originalBridge = vmContext.__waywardSituationEventMod;
  const originalPacks = vmContext.__WAYWARD_SITUATION_PROMPT_PACKS__;
  const originalProfiles = vmContext.__WAYWARD_CHARACTER_PROMPT_PROFILES__;
  const customMouthKey = 'situation_fluid__iris__mouth__stage-4';
  const referenceMouthKey = 'situation_fluid__pippa__mouth__stage-4';
  const customVulvaKey = 'situation_vulva__iris__wetness-4__jewelry-0';
  const referenceVulvaKey = 'situation_vulva__pippa__wetness-4__jewelry-0';
  const customUterusKey = 'situation_fluid__iris__uterus__width-1__stage-1';
  const referenceUterusKey = 'situation_fluid__pippa__uterus__width-1__stage-1';
  const customThighsKey = 'situation_fluid__iris__thighs__stage-0';
  const referenceThighsKey = 'situation_fluid__pippa__thighs__stage-0';
  const customBreastLeftKey = 'situation_fluid__iris__breasts__stage-0__jewelry-piercing-stage-1';
  const referenceBreastLeftKey = 'situation_fluid__pippa__breasts__stage-0__jewelry-piercing-stage-1';
  const customBreastRightKey = 'situation_fluid__iris__breasts__stage-0__jewelry-piercing-right-stage-1';
  const referenceBreastRightKey = 'situation_fluid__pippa__breasts__stage-0__jewelry-piercing-right-stage-1';
  const customBreastBothKey = 'situation_fluid__iris__breasts__stage-0__jewelry-piercing-stage-2';
  const referenceBreastBothKey = 'situation_fluid__pippa__breasts__stage-0__jewelry-piercing-stage-2';
  const customBreastChokerKey = 'situation_fluid__iris__breasts__stage-0__jewelry-piercing-stage-3';
  const referenceBreastChokerKey = 'situation_fluid__pippa__breasts__stage-0__jewelry-piercing-stage-3';
  const customToyKey = 'situation_toy_info__iris__vulva__vibe-egg__width-2__inside-4';
  const referenceToyKey = 'situation_toy_info__pippa__vulva__vibe-egg__width-2__inside-4';
  const customPenisToyKey = 'situation_toy_info__iris__vulva__vibe-penis__width-2__inside-4';
  const referencePenisToyKey = 'situation_toy_info__pippa__vulva__vibe-penis__width-2__inside-4';
  const customPenisUterusKey = 'situation_toy_info__iris__uterus__vibe-penis__width-2__inside-4';
  const referencePenisUterusKey = 'situation_toy_info__pippa__uterus__vibe-penis__width-2__inside-4';
  const promptRequests = [];
  wife.shortname = 'iris';
  wife.archetypeId = 'pippa_waif';
  wife.generatedArchetype = {
    id: 'custom_secret_wife', shortname: 'iris', basedOn: 'pippa_waif',
    imageBase: '1girl, silver hair\n\nfreckles, amber eyes, cute face, pale skin, petite slim build, small breasts, hip tattoo', imageNegative: 'blue hair, dark skin',
  };
  wife.situationStats = { jewelryState: { vibe: { type: 'penis', suspension: null } } };
  savedSettings = {
    ...savedSettings,
    characterPrompt: {
      wifeKey: 'iris', positivePrompt: '1girl, silver hair\n\nfreckles, amber eyes, cute face, pale skin, petite slim build, small breasts, hip tattoo',
      negativePrompt: 'blue hair, dark skin', mode: 'replace', imagePolicy: 'reuse',
    },
    residuePrompts: {},
  };
  vmContext.__WAYWARD_SITUATION_PROMPT_PACKS__ = [{
    entries: {
      [referenceMouthKey]: {
        prompt: 'masterpiece, best quality, score_7, absurdres, approved face close-up, {{character_prompt}}, tavern, indoors, wooden interior, candlelight, fixed frontal camera',
        negativePrompt: 'bad anatomy', workflow: 'illustrious', width: 768, height: 576, steps: 8, cfg: 1,
      },
      [referenceVulvaKey]: {
        prompt: 'masterpiece, best quality, score_7, absurdres, warm candlelit fantasy tavern, detailed background, landscape, approved vulva state, {{character_prompt}}, fixed frontal camera',
        negativePrompt: 'wrong framing', workflow: 'illustrious', width: 768, height: 576, steps: 8, cfg: 1,
      },
      [referenceUterusKey]: {
        prompt: 'masterpiece, best quality, score_7, absurdres, warm candlelit fantasy tavern, approved uterus state, translucent skin, {{character_prompt}}, fixed frontal camera',
        negativePrompt: 'wrong framing', workflow: 'illustrious', width: 768, height: 576, steps: 8, cfg: 1,
      },
      [referenceThighsKey]: {
        prompt: 'masterpiece, best quality, score_7, absurdres, game cg, anime coloring, detailed background, landscape, approved thighs state, from front, three-quarter view, {{character_prompt}}, tavern, indoors, wooden interior, candlelight',
        negativePrompt: 'wrong framing, hidden vulva', workflow: 'illustrious', width: 768, height: 576, steps: 8, cfg: 1,
      },
      [referenceBreastLeftKey]: {
        prompt: 'masterpiece, best quality, score_7, absurdres, game cg, anime coloring, detailed background, landscape, approved breasts state, from front, three-quarter view, (left nipple piercing:2.0), single nipple piercing, (unpierced right nipple:2.0), {{character_prompt}}, tavern, candlelight',
        negativePrompt: 'wrong jewelry, right nipple piercing, two nipple piercings', workflow: 'illustrious', width: 768, height: 576, steps: 8, cfg: 1,
      },
      [referenceBreastRightKey]: {
        prompt: 'masterpiece, best quality, score_7, absurdres, game cg, anime coloring, detailed background, landscape, approved breasts state, from front, three-quarter view, (right nipple piercing:2.0), single nipple piercing, (unpierced left nipple:2.0), {{character_prompt}}, tavern, candlelight',
        negativePrompt: 'wrong jewelry, left nipple piercing, two nipple piercings', workflow: 'illustrious', width: 768, height: 576, steps: 8, cfg: 1,
      },
      [referenceBreastBothKey]: {
        prompt: 'masterpiece, best quality, score_7, absurdres, game cg, anime coloring, detailed background, landscape, approved breasts state, from front, three-quarter view, pierced nipples, two nipple piercings, {{character_prompt}}, tavern, candlelight',
        negativePrompt: 'wrong jewelry, single nipple piercing', workflow: 'illustrious', width: 768, height: 576, steps: 8, cfg: 1,
      },
      [referenceBreastChokerKey]: {
        prompt: 'masterpiece, best quality, score_7, absurdres, game cg, anime coloring, detailed background, landscape, approved breasts state, from front, three-quarter view, pierced nipples, two nipple piercings, black leather choker, heart choker, {{character_prompt}}, tavern, candlelight',
        negativePrompt: 'wrong jewelry, single nipple piercing, choker, collar around neck', workflow: 'illustrious', width: 768, height: 576, steps: 8, cfg: 1,
      },
      [referenceToyKey]: {
        prompt: 'masterpiece, best quality, score_7, absurdres, warm candlelit fantasy tavern, approved toy close-up, {{character_prompt}}, egg vibrator placement, 768 by 576 landscape composition',
        negativePrompt: 'wrong device', workflow: 'illustrious', width: 768, height: 576, steps: 8, cfg: 1,
      },
      [referencePenisToyKey]: {
        prompt: 'masterpiece, best quality, score_7, absurdres, warm candlelit fantasy tavern, approved toy close-up, {{character_prompt}}, exactly one opaque saturated-purple silicone dildo vibrator inserted into the vagina, two thirds of the device hidden inside, only the lower third and flared base visible, 768 by 576 landscape composition',
        negativePrompt: 'wrong device, human penis, glans, egg', workflow: 'illustrious', width: 768, height: 576, steps: 8, cfg: 1,
      },
      [referencePenisUterusKey]: {
        prompt: 'masterpiece, best quality, score_7, absurdres, warm candlelit fantasy tavern, frontal lower-torso erotic game x-ray status illustration, translucent skin, uterus visible through skin, x-ray view, x-ray vision, radiographic glow, translucent pink uterus, approved uterus cutaway, {{character_prompt}}, exactly one opaque saturated-purple silicone dildo vibrator inserted upward through the vagina toward the cervix, internal toy placement, 768 by 576 landscape composition',
        negativePrompt: 'wrong framing, human penis, glans, egg', workflow: 'illustrious', width: 768, height: 576, steps: 8, cfg: 1,
      },
    },
  }];
  const residueBatchButton = residueControls.children.find(node => node.textContent === '상태별 생성');
  assert.ok(residueBatchButton, 'each H-Status card should expose the state-by-state generator');
  residueBatchButton.click();
  assert.equal(openedSettingsWindow.options.title, '비밀 탭 상태별 이미지 생성');
  await new Promise(resolve => setImmediate(resolve));
  await new Promise(resolve => setImmediate(resolve));
  let residueBatchNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.equal(residueBatchNodes.find(node => node.props?.['data-residue-batch-part'] === '').props.value, 'mouth');
  assert.equal(residueBatchNodes.find(node => node.props?.['data-residue-batch-count'] === '').props.max, 10);
  assert.match(residueBatchNodes.find(node => node.props?.['data-residue-batch-summary'] === '').children[0], /상태 1개 · 총 1장/);
  assert.equal(residueBatchNodes.filter(node => node.props?.['data-residue-batch-state']).length, 1);
  residueBatchNodes.find(node => node.props?.['data-residue-batch-part'] === '').props.onchange({ currentTarget: { value: 'vulva' } });
  await new Promise(resolve => setImmediate(resolve));
  await new Promise(resolve => setImmediate(resolve));
  residueBatchNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.match(residueBatchNodes.find(node => node.props?.['data-residue-batch-summary'] === '').children[0], /상태 3개 · 총 3장/,
    'vulva bulk generation should include normal, egg-vibrator, and penis-shaped-vibrator states together');
  assert.equal(residueBatchNodes.filter(node => node.props?.['data-residue-batch-state']).length, 3);
  const batchGenerationCount = generatedRequests.length;
  residueBatchNodes.find(node => node.tag === 'button' && node.children.includes('전체 상태 생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(generatedRequests.length, batchGenerationCount + 3,
    'bulk generation should send one request for every selected part state and requested copy');
  for (const key of [customVulvaKey, customToyKey, customPenisToyKey]) {
    assert.equal(savedSettings.residueImageChoices[key].items.length, 1);
    assert.ok(savedSettings.residueImageChoices[key].selected,
      'each generated state should retain an independently selectable image');
  }
  const manifestBeforeImg2Img = imageManifestEntries;
  imageManifestEntries = {
    [referenceMouthKey]: {
      talentName: referenceMouthKey,
      imagePath: 'illustrious/situation/info/pippa/mouth_stage-4.webp',
    },
    [referenceBreastLeftKey]: {
      talentName: referenceBreastLeftKey,
      imagePath: 'illustrious/situation/info/pippa/breasts_stage-0_jewelry-piercing-1.webp',
    },
    [referenceBreastRightKey]: {
      talentName: referenceBreastRightKey,
      imagePath: 'illustrious/situation/info/pippa/breasts_stage-0_jewelry-piercing-right-1.webp',
    },
    [referenceBreastBothKey]: {
      talentName: referenceBreastBothKey,
      imagePath: 'illustrious/situation/info/pippa/breasts_stage-0_jewelry-piercing-2.webp',
    },
    [referenceUterusKey]: {
      talentName: referenceUterusKey,
      imagePath: 'illustrious/situation/info/pippa/uterus_width-1_stage-1.webp',
    },
    [referencePenisUterusKey]: {
      talentName: referencePenisUterusKey,
      imagePath: 'illustrious/situation/info/pippa/toy_uterus_vibe-penis_width-2_inside-4.webp',
    },
  };
  savedSettings = {
    ...savedSettings,
    hStatusGenerationModes: { mouth: 'img2img', breasts: 'text2img', uterus: 'img2img', vulva: 'text2img', thighs: 'text2img' },
    hStatusImg2Img: true,
  };
  relativeImageUrls = true;
  const img2imgCount = hStatusImg2ImgRequests.length;
  residueBatchNodes.find(node => node.props?.['data-residue-batch-part'] === '').props.onchange({ currentTarget: { value: 'mouth' } });
  await new Promise(resolve => setImmediate(resolve));
  await new Promise(resolve => setImmediate(resolve));
  residueBatchNodes = flattenNodes(openedSettingsWindow.body.children);
  residueBatchNodes.find(node => node.tag === 'button' && node.children.includes('전체 상태 생성')).props.onclick();
  for (let count = 0; count < 8 && hStatusImg2ImgRequests.length < img2imgCount + 1; count += 1) {
    await new Promise(resolve => setImmediate(resolve));
  }
  assert.equal(hStatusImg2ImgRequests.length, img2imgCount + 1,
    'a non-uterus part should use img2img when that part selects it');
  assert.equal(hStatusImg2ImgRequests[img2imgCount].referenceKey, referenceMouthKey);
  assert.equal(hStatusImg2ImgRequests[img2imgCount].denoise, 0.28);
  assert.match(hStatusImg2ImgRequests[img2imgCount].prompt, /matte cel-shaded skin/);
  assert.match(hStatusImg2ImgRequests[img2imgCount].negativePrompt, /white spots on skin/);
  const promptGenerationCount = generatedRequests.length;
  savedSettings.hStatusGenerationModes.mouth = 'text2img';
  residueBatchNodes.find(node => node.tag === 'button' && node.children.includes('전체 상태 생성')).props.onclick();
  for (let count = 0; count < 8 && generatedRequests.length < promptGenerationCount + 1; count += 1) {
    await new Promise(resolve => setImmediate(resolve));
  }
  assert.equal(generatedRequests.length, promptGenerationCount + 1,
    'the same part should return to prompt generation when the user selects text2img');
  assert.equal(hStatusImg2ImgRequests.length, img2imgCount + 1);
  savedSettings.hStatusGenerationModes.breasts = 'img2img';
  residueBatchNodes.find(node => node.props?.['data-residue-batch-part'] === '').props.onchange({ currentTarget: { value: 'breasts' } });
  await new Promise(resolve => setImmediate(resolve));
  await new Promise(resolve => setImmediate(resolve));
  residueBatchNodes = flattenNodes(openedSettingsWindow.body.children);
  const breastImg2ImgCount = hStatusImg2ImgRequests.length;
  residueBatchNodes.find(node => node.tag === 'button' && node.children.includes('전체 상태 생성')).props.onclick();
  for (let count = 0; count < 12 && hStatusImg2ImgRequests.length < breastImg2ImgCount + 3; count += 1) {
    await new Promise(resolve => setImmediate(resolve));
  }
  assert.equal(hStatusImg2ImgRequests.length, breastImg2ImgCount + 3);
  for (const request of hStatusImg2ImgRequests.slice(breastImg2ImgCount)) {
    assert.equal(request.denoise, 0.4, 'breast img2img should allow enough change to follow the wife size tags');
    assert.match(request.prompt, /breast volume follows the current wife size tags/);
    assert.match(request.negativePrompt, /white spots on skin/);
  }
  residueBatchNodes.find(node => node.props?.['data-residue-batch-part'] === '').props.onchange({ currentTarget: { value: 'uterus' } });
  await new Promise(resolve => setImmediate(resolve));
  await new Promise(resolve => setImmediate(resolve));
  residueBatchNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.equal(residueBatchNodes.filter(node => node.props?.['data-residue-batch-state']).length, 2);
  const uterusImg2ImgCount = hStatusImg2ImgRequests.length;
  residueBatchNodes.find(node => node.tag === 'button' && node.children.includes('전체 상태 생성')).props.onclick();
  for (let count = 0; count < 8 && hStatusImg2ImgRequests.length < uterusImg2ImgCount + 2; count += 1) {
    await new Promise(resolve => setImmediate(resolve));
  }
  assert.equal(hStatusImg2ImgRequests.length, uterusImg2ImgCount + 2,
    'every uterus state should use the dedicated img2img endpoint');
  assert.ok(fetchedUrls.includes('http://127.0.0.1:8189/images/illustrious/situation/info/pippa/uterus_width-1_stage-1.webp'),
    'a file:// game image path should be loaded from the ImageStudio image route');
  assert.equal(hStatusImg2ImgRequests[uterusImg2ImgCount].referenceKey, referenceUterusKey);
  assert.match(hStatusImg2ImgRequests[uterusImg2ImgCount].imageData, /^data:image\/webp;base64,/);
  relativeImageUrls = false;
  imageManifestEntries = manifestBeforeImg2Img;
  residueBatchNodes.find(node => node.props?.['data-residue-batch-part'] === '').props.onchange({ currentTarget: { value: 'vulva' } });
  await new Promise(resolve => setImmediate(resolve));
  await new Promise(resolve => setImmediate(resolve));
  residueBatchNodes = flattenNodes(openedSettingsWindow.body.children);
  residueBatchNodes.find(node => node.tag === 'button' && node.children.includes('이미지 선택 (1)')).props.onclick();
  assert.match(openedSettingsWindow.options.title, /잔류 상태 이미지 선택 · 보지/);
  vmContext.__waywardSituationEventMod = {
    async promptForImage(imageKey) {
      promptRequests.push(imageKey);
      return { prompt: `generic ${imageKey}`, negativePrompt: 'generic negative', workflow: 'illustrious', width: 512, height: 512 };
    },
  };
  const referenceRequest = await hooks.imageGenerate.around(request => request, {
    imageKey: `${customMouthKey}__v-1700000000001`, prompt: 'generic request', negativePrompt: '',
    workflow: 'illustrious', width: 512, height: 512, debug: { source: 'wayward-situation' },
  });
  assert.match(referenceRequest.prompt, /approved face close-up/);
  assert.match(referenceRequest.prompt, /silver hair/);
  assert.match(referenceRequest.prompt, /freckles/);
  assert.match(referenceRequest.prompt, /amber eyes/);
  assert.match(referenceRequest.prompt, /pale skin/);
  assert.doesNotMatch(referenceRequest.prompt, /small breasts|hip tattoo|petite slim build/,
    'the mouth card should keep facial traits without unrelated body traits');
  assert.match(referenceRequest.prompt, /consistent character identity/);
  assert.match(referenceRequest.prompt, /tavern, indoors, wooden interior, candlelight/,
    'custom-wife cards should retain the original H-Status background and lighting');
  assert.match(referenceRequest.prompt, /same camera angle and crop across every status level/);
  assert.doesNotMatch(referenceRequest.prompt, /character-accurate natural skin tone|consistent game cg anime coloring/,
    'the original H-Status rendering style should not be replaced by extra style or skin directives');
  assert.doesNotMatch(referenceRequest.prompt, /vibrat|internal pressure pleasure expression/,
    'mouth residue images should not inherit the currently attached toy or its reaction prompt');
  assert.match(referenceRequest.prompt, /^masterpiece, best quality, score_7, absurdres,/,
    'the original H-Status SDXL quality prefix should remain first and unchanged');
  assert.equal((referenceRequest.prompt.match(/masterpiece/g) || []).length, 1);
  assert.equal(referenceRequest.imageKey, `${customMouthKey}__v-1700000000001`);
  assert.doesNotMatch(referenceRequest.prompt, /\{\{character_prompt\}\}/);
  assert.match(referenceRequest.negativePrompt, /bad anatomy/);
  assert.match(referenceRequest.negativePrompt, /blue hair/);
  assert.match(referenceRequest.negativePrompt, /dark skin/);
  assert.equal(referenceRequest.width, 1216);
  assert.equal(referenceRequest.height, 832);
  assert.equal(referenceRequest.dimensions, '1216 x 832 (1.46:1)');
  assert.equal(referenceRequest.steps, 8);
  assert.equal(referenceRequest.cfg, 1);
  assert.ok(promptRequests.includes(referenceMouthKey), 'custom wife secret images should load the matching built-in reference prompt');
  const builtInRequest = {
    imageKey: referenceMouthKey, prompt: 'built-in final H-Status prompt', negativePrompt: 'built-in final H-Status negative',
    workflow: 'illustrious', width: 768, height: 576, debug: { source: 'wayward-situation' },
  };
  assert.deepEqual(await hooks.imageGenerate.around(request => request, builtInRequest), builtInRequest,
    'built-in H-Status requests should remain untouched; only custom-wife prompts are replaced');
  savedSettings = {
    ...savedSettings,
    residuePrompts: { [customMouthKey]: { positivePrompt: 'legacy saved mouth prompt', negativePrompt: 'legacy saved mouth negative' } },
  };
  const [legacyMouthRequest] = hooks.imageGenerate.before([{
    imageKey: customMouthKey, prompt: 'generic mouth request', negativePrompt: '',
    bypassCache: true, debug: { source: 'wayward-situation' },
  }]);
  const preservedLegacyMouthRequest = await hooks.imageGenerate.around(request => request, legacyMouthRequest);
  assert.equal(preservedLegacyMouthRequest.prompt, 'legacy saved mouth prompt');
  assert.equal(preservedLegacyMouthRequest.negativePrompt, 'legacy saved mouth negative');
  assert.equal(preservedLegacyMouthRequest.imageKey, customMouthKey);
  assert.equal(preservedLegacyMouthRequest.width, 1216);
  assert.equal(preservedLegacyMouthRequest.height, 832);
  assert.equal(preservedLegacyMouthRequest.dimensions, '1216 x 832 (1.46:1)',
    'saved custom-wife prompts should still use the supported H-Status landscape preset');
  savedSettings = { ...savedSettings, residuePrompts: {} };

  const vulvaReferenceRequest = await hooks.imageGenerate.around(request => request, {
    imageKey: customVulvaKey, prompt: 'generic vulva request', negativePrompt: '', debug: { source: 'wayward-situation' },
  });
  assert.match(vulvaReferenceRequest.prompt, /fixed frontal crop from waist to upper thighs/);
  assert.doesNotMatch(vulvaReferenceRequest.prompt, /extreme bare crotch|fully uncovered bare vulva|surrounding vulva skin|subtle healthy pink/,
    'the framing correction should not redefine anatomy, color, or rendering style');
  assert.doesNotMatch(vulvaReferenceRequest.prompt, /silver hair|amber eyes|freckles|cute face/,
    'lower-body cards should not inherit face-only traits');
  assert.match(vulvaReferenceRequest.prompt, /pale skin/);
  assert.match(vulvaReferenceRequest.prompt, /petite slim build/);
  assert.match(vulvaReferenceRequest.prompt, /hip tattoo/);
  assert.doesNotMatch(vulvaReferenceRequest.prompt, /generic vulva request|sex scene/,
    'a secret body-part prompt should not inherit the current normal situation prompt');
  assert.match(vulvaReferenceRequest.prompt, /warm candlelit fantasy tavern/);
  assert.match(vulvaReferenceRequest.prompt, /detailed background/);
  assert.match(vulvaReferenceRequest.prompt, /landscape/);
  assert.match(vulvaReferenceRequest.prompt, /natural skin tone stays unchanged/);
  assert.match(vulvaReferenceRequest.prompt, /labia majora clearly visible on both sides/);
  assert.match(vulvaReferenceRequest.prompt, /vaginal opening clearly visible/);
  assert.equal(vulvaReferenceRequest.imageKey, customVulvaKey);
  assert.match(vulvaReferenceRequest.negativePrompt, /wrong framing/);
  assert.match(vulvaReferenceRequest.negativePrompt, /full body/);
  assert.match(vulvaReferenceRequest.negativePrompt, /collage/);
  assert.match(vulvaReferenceRequest.negativePrompt, /viewfinder overlay/);
  assert.match(vulvaReferenceRequest.negativePrompt, /purple skin/);
  assert.match(vulvaReferenceRequest.negativePrompt, /hidden labia majora/);
  assert.match(vulvaReferenceRequest.negativePrompt, /hands in frame/);
  assert.doesNotMatch(vulvaReferenceRequest.prompt, /fixed frontal camera/,
    'body-part framing should not be interpreted as an in-scene camera or recording overlay');
  assert.doesNotMatch(vulvaReferenceRequest.negativePrompt, /covered vulva|fabric attached to vibrator|uniformly red genital area|x-ray/);

  const uterusReferenceRequest = await hooks.imageGenerate.around(request => request, {
    imageKey: customUterusKey, prompt: 'generic uterus request', negativePrompt: '', debug: { source: 'wayward-situation' },
  });
  assert.doesNotMatch(uterusReferenceRequest.prompt, /approved uterus state|warm candlelit fantasy tavern/,
    'default uterus generation should rebuild the prompt instead of retaining anatomy-triggering source prose');
  assert.match(uterusReferenceRequest.prompt, /exactly one adult woman/);
  assert.match(uterusReferenceRequest.prompt, /fixed crop from navel to upper thighs/);
  assert.match(uterusReferenceRequest.prompt, /flat translucent pink H-Status overlay centered on the lower abdomen/);
  assert.match(uterusReferenceRequest.prompt, /one short narrow central pink gap below the chamber/);
  assert.match(uterusReferenceRequest.prompt, /tiny opaque white status fill contained at the bottom/);
  assert.match(uterusReferenceRequest.prompt, /pale skin/);
  assert.match(uterusReferenceRequest.prompt, /hip tattoo/);
  assert.match(uterusReferenceRequest.prompt, /natural skin tone stays unchanged/);
  assert.doesNotMatch(uterusReferenceRequest.prompt, /translucent skin|x-ray view|radiographic glow|vaginal folds/);
  assert.doesNotMatch(uterusReferenceRequest.prompt, /purple color confined to the vibrator|dildo shaft already inside her vagina/,
    'non-toy uterus states should get the shared skin correction without toy-only wording');
  assert.match(uterusReferenceRequest.negativePrompt, /purple skin/);
  assert.match(uterusReferenceRequest.negativePrompt, /recording overlay/);
  assert.match(uterusReferenceRequest.negativePrompt, /fleshy tunnel/);
  assert.match(uterusReferenceRequest.negativePrompt, /stacked torsos/);
  assert.match(uterusReferenceRequest.negativePrompt, /stacked vaginal folds/);
  assert.match(uterusReferenceRequest.negativePrompt, /portrait orientation/);
  assert.match(uterusReferenceRequest.negativePrompt, /solid white shaft/);
  assert.doesNotMatch(uterusReferenceRequest.negativePrompt, /hands in frame|toy covering the entire vulva/);

  const thighsReferenceRequest = await hooks.imageGenerate.around(request => request, {
    imageKey: customThighsKey, prompt: 'generic thighs request', negativePrompt: '', debug: { source: 'wayward-situation' },
  });
  assert.match(thighsReferenceRequest.prompt, /approved thighs state/);
  assert.match(thighsReferenceRequest.prompt, /fixed frontal lower-body crop/);
  assert.match(thighsReferenceRequest.prompt, /both inner thighs inside frame/);
  assert.doesNotMatch(thighsReferenceRequest.prompt, /three-quarter view|extreme close-up|complete unobstructed natural vulva/);
  assert.match(thighsReferenceRequest.negativePrompt, /hidden vulva/);
  assert.match(thighsReferenceRequest.negativePrompt, /full body/);

  const breastLeftRequest = await hooks.imageGenerate.around(request => request, {
    imageKey: customBreastLeftKey, prompt: 'generic breasts request', negativePrompt: '', debug: { source: 'wayward-situation' },
  });
  assert.match(breastLeftRequest.prompt, /fixed frontal chest crop/);
  assert.match(breastLeftRequest.prompt, /\(left nipple piercing:2\.0\)/);
  assert.match(breastLeftRequest.prompt, /\(unpierced right nipple:2\.0\)/);
  assert.match(breastLeftRequest.prompt, /small breasts/);
  assert.match(breastLeftRequest.prompt, /both breasts inside frame/);
  assert.doesNotMatch(breastLeftRequest.prompt, /silver hair|amber eyes|freckles|cute face|hip tattoo/,
    'the breast card should keep chest and body proportions without face-only or lower-body traits');
  assert.doesNotMatch(breastLeftRequest.prompt, /three-quarter view|breast focus|extreme close-up|ring diameter much smaller than areola/);
  assert.match(breastLeftRequest.negativePrompt, /right nipple piercing/);
  assert.doesNotMatch(breastLeftRequest.negativePrompt, /large breasts|dangling nipple jewelry|hands holding nipple jewelry|gigantomastia/);
  const breastRightRequest = await hooks.imageGenerate.around(request => request, {
    imageKey: customBreastRightKey, prompt: 'generic breasts request', negativePrompt: '', debug: { source: 'wayward-situation' },
  });
  assert.match(breastRightRequest.prompt, /\(right nipple piercing:2\.0\)/);
  assert.match(breastRightRequest.prompt, /\(unpierced left nipple:2\.0\)/);
  assert.match(breastRightRequest.negativePrompt, /left nipple piercing/);
  const breastBothRequest = await hooks.imageGenerate.around(request => request, {
    imageKey: customBreastBothKey, prompt: 'generic breasts request', negativePrompt: '', debug: { source: 'wayward-situation' },
  });
  assert.match(breastBothRequest.prompt, /pierced nipples/);
  assert.match(breastBothRequest.prompt, /two nipple piercings/);
  assert.match(breastBothRequest.negativePrompt, /single nipple piercing/);
  assert.doesNotMatch(breastBothRequest.prompt, /choker|collar around (?:her )?neck/,
    'breast jewelry stages before the choker stage must not request a neck accessory');
  assert.match(breastBothRequest.negativePrompt, /heart-shaped choker/,
    'breast jewelry stages before stage 3 should actively suppress accidental chokers');
  const breastChokerRequest = await hooks.imageGenerate.around(request => request, {
    imageKey: customBreastChokerKey, prompt: 'generic breasts request', negativePrompt: '', debug: { source: 'wayward-situation' },
  });
  assert.match(breastChokerRequest.prompt, /black leather heart choker fitted snugly around her neck/);
  assert.match(breastChokerRequest.prompt, /base of neck visible at top of frame/);
  assert.doesNotMatch(breastChokerRequest.negativePrompt, /choker|collar around neck/,
    'the actual H-Status choker stage must remove conflicting no-choker negatives');
  savedSettings = { ...savedSettings, residuePartSources: { breasts: 'mara' } };
  const residuePresetLookupKeys = [];
  const residuePresetResult = await hooks.imageLookup.around(async key => {
    residuePresetLookupKeys.push(key);
    return { talentName: key, imagePath: 'mara-preset.webp' };
  }, customBreastLeftKey);
  assert.equal(residuePresetLookupKeys[0], referenceBreastLeftKey.replace('__pippa__', '__mara__'));
  assert.equal(residuePresetResult.talentName, referenceBreastLeftKey.replace('__pippa__', '__mara__'),
    'a body-part preset choice should display the matching built-in character image without generating');
  savedSettings = { ...savedSettings, residuePartSources: { breasts: 'generate' } };

  const toyReferenceRequest = await hooks.imageGenerate.around(request => request, {
    imageKey: customToyKey, prompt: 'generic toy request', negativePrompt: '', debug: { source: 'wayward-situation' },
  });
  assert.match(toyReferenceRequest.prompt, /approved toy close-up/);
  assert.match(toyReferenceRequest.prompt, /^masterpiece, best quality, score_7, absurdres,/);
  assert.match(toyReferenceRequest.prompt, /pale skin/);
  assert.match(toyReferenceRequest.prompt, /petite slim build/);
  assert.match(toyReferenceRequest.prompt, /hip tattoo/);
  assert.doesNotMatch(toyReferenceRequest.prompt, /silver hair|amber eyes|freckles|cute face|small breasts/,
    'a lower-body card should keep only traits visible in that crop');
  assert.match(toyReferenceRequest.prompt, /fixed frontal crop from waist to upper thighs/);
  assert.doesNotMatch(toyReferenceRequest.prompt, /extreme bare crotch|fully uncovered bare vulva|vulva centered and fills the frame/);
  assert.match(toyReferenceRequest.negativePrompt, /full body/);
  assert.match(toyReferenceRequest.negativePrompt, /distant shot/);
  assert.match(toyReferenceRequest.negativePrompt, /recording overlay/);
  assert.match(toyReferenceRequest.negativePrompt, /dark skin/);
  assert.match(toyReferenceRequest.prompt, /natural skin tone stays unchanged/);
  assert.match(toyReferenceRequest.prompt, /labia majora clearly visible on both sides/);
  assert.match(toyReferenceRequest.prompt, /vaginal opening clearly visible/);
  assert.doesNotMatch(toyReferenceRequest.prompt, /purple color confined to the vibrator|dildo shaft already inside her vagina/,
    'egg toys should get shared body-part corrections without penis-shaped-toy wording');
  assert.match(toyReferenceRequest.negativePrompt, /purple skin/);
  assert.match(toyReferenceRequest.negativePrompt, /hands in frame/);
  assert.doesNotMatch(toyReferenceRequest.negativePrompt, /toy covering the entire vulva/);
  assert.doesNotMatch(toyReferenceRequest.negativePrompt, /blue hair/,
    'lower-body Negative prompts should also omit face-only traits');
  assert.doesNotMatch(toyReferenceRequest.negativePrompt, /(?:^|, )tattoo(?:,|$)/,
    'a visible hip tattoo should remove the conflicting generic tattoo negative');
  assert.equal(toyReferenceRequest.width, 1216);
  assert.equal(toyReferenceRequest.height, 832);
  assert.equal(toyReferenceRequest.dimensions, '1216 x 832 (1.46:1)');
  const penisToyReferenceRequest = await hooks.imageGenerate.around(request => request, {
    imageKey: customPenisToyKey, prompt: 'generic toy request', negativePrompt: '', debug: { source: 'wayward-situation' },
  });
  assert.match(penisToyReferenceRequest.prompt, /opaque saturated-purple silicone dildo vibrator inserted into the vagina/);
  assert.doesNotMatch(penisToyReferenceRequest.prompt, /two thirds of the device hidden inside|only the lower third and flared base visible/);
  assert.match(penisToyReferenceRequest.prompt, /natural skin tone stays unchanged/);
  assert.match(penisToyReferenceRequest.prompt, /purple color confined to the vibrator/);
  assert.match(penisToyReferenceRequest.prompt, /labia majora clearly visible on both sides/);
  assert.match(penisToyReferenceRequest.prompt, /dildo shaft already inside her vagina/);
  assert.match(penisToyReferenceRequest.prompt, /only its base visible at the vaginal opening/);
  assert.doesNotMatch(penisToyReferenceRequest.prompt, /manufactured saturated-purple|straight vertical cylindrical sex toy|round flared safety base directly below/,
    'the original toy description should remain without an extra material or shape rewrite');
  assert.match(penisToyReferenceRequest.negativePrompt, /(?:^|, )glans(?:,|$)/);
  assert.match(penisToyReferenceRequest.negativePrompt, /human penis/);
  assert.match(penisToyReferenceRequest.negativePrompt, /egg/);
  assert.match(penisToyReferenceRequest.negativePrompt, /purple skin/);
  assert.match(penisToyReferenceRequest.negativePrompt, /toy covering the entire vulva/);
  assert.match(penisToyReferenceRequest.negativePrompt, /holding_sex_toy, dildo outside body/);
  assert.match(penisToyReferenceRequest.negativePrompt, /hands in frame/);
  assert.match(penisToyReferenceRequest.negativePrompt, /viewfinder overlay/);
  assert.doesNotMatch(penisToyReferenceRequest.negativePrompt, /foreskin|skin texture on device|real penis/);
  assert.equal(penisToyReferenceRequest.width, 1216);
  assert.equal(penisToyReferenceRequest.height, 832);
  const penisUterusReferenceRequest = await hooks.imageGenerate.around(request => request, {
    imageKey: customPenisUterusKey, prompt: 'generic uterus request', negativePrompt: '', debug: { source: 'wayward-situation' },
  });
  assert.match(penisUterusReferenceRequest.prompt, /flat translucent pink H-Status overlay/);
  assert.match(penisUterusReferenceRequest.prompt, /fixed crop from navel to upper thighs/);
  assert.match(penisUterusReferenceRequest.prompt, /one short moderately open central pink gap/);
  assert.match(penisUterusReferenceRequest.prompt, /opaque white status fill contained inside most of the pink chamber/);
  assert.match(penisUterusReferenceRequest.prompt, /exactly one small manufactured saturated-purple silicone dildo vibrator symbol/);
  assert.match(penisUterusReferenceRequest.prompt, /short straight shaft centered on the short pink stem/);
  assert.doesNotMatch(penisUterusReferenceRequest.prompt, /warm candlelit fantasy tavern|inserted upward through the vagina/);
  assert.match(penisUterusReferenceRequest.prompt, /natural skin tone stays unchanged/);
  assert.match(penisUterusReferenceRequest.prompt, /purple color confined to the vibrator/);
  assert.doesNotMatch(penisUterusReferenceRequest.prompt, /x-ray|translucent skin|radiographic glow|vaginal walls/);
  assert.match(penisUterusReferenceRequest.negativePrompt, /full body/);
  assert.match(penisUterusReferenceRequest.negativePrompt, /human penis/);
  assert.match(penisUterusReferenceRequest.negativePrompt, /purple skin/);
  assert.match(penisUterusReferenceRequest.negativePrompt, /recording overlay/);
  assert.match(penisUterusReferenceRequest.negativePrompt, /realistic internal tissue/);
  assert.match(penisUterusReferenceRequest.negativePrompt, /multiple vulvas/);
  assert.doesNotMatch(penisUterusReferenceRequest.negativePrompt, /hands in frame|toy covering the entire vulva/);
  assert.equal(penisUterusReferenceRequest.width, 1216);
  assert.equal(penisUterusReferenceRequest.height, 832);
  assert.equal(penisUterusReferenceRequest.dimensions, '1216 x 832 (1.46:1)');
  savedSettings = {
    ...savedSettings,
    residuePrompts: {
      [customToyKey]: { positivePrompt: 'saved toy prompt', negativePrompt: 'saved toy negative' },
      [customBreastLeftKey]: {
        positivePrompt: 'freckles, cute face, (breasts:1.6), small breasts, three-quarter view, (left nipple piercing:2.0)',
        negativePrompt: 'saved breast negative, right nipple piercing',
      },
    },
  };
  const [savedToyRequest] = hooks.imageGenerate.before([{
    imageKey: `${customToyKey}__v-1700000000002`, prompt: 'generic toy request', negativePrompt: '',
    debug: { source: 'attention-image-prompt-residue' },
  }]);
  const preservedToyRequest = await hooks.imageGenerate.around(request => request, savedToyRequest);
  assert.match(preservedToyRequest.prompt, /^saved toy prompt,/);
  assert.match(preservedToyRequest.prompt, /fixed frontal crop from waist to upper thighs/);
  assert.match(preservedToyRequest.negativePrompt, /^saved toy negative,/);
  assert.equal(preservedToyRequest.workflow, 'illustrious',
    'the H-Status-only generation profile should force the supported Illustrious workflow');
  assert.equal(preservedToyRequest.dimensions, '1216 x 832 (1.46:1)');
  const [savedBreastRequest] = hooks.imageGenerate.before([{
    imageKey: `${customBreastLeftKey}__v-1700000000003`, prompt: 'generic breast request', negativePrompt: '',
    debug: { source: 'attention-image-prompt-residue' },
  }]);
  const repairedSavedBreastRequest = await hooks.imageGenerate.around(request => request, savedBreastRequest);
  assert.doesNotMatch(repairedSavedBreastRequest.prompt, /freckles|cute face|three-quarter view/,
    'saved prompts should receive framing cleanup without a new anatomy rewrite');
  assert.match(repairedSavedBreastRequest.prompt, /\(breasts:1\.6\)/);
  assert.match(repairedSavedBreastRequest.prompt, /small breasts/);
  assert.match(repairedSavedBreastRequest.prompt, /\(left nipple piercing:2\.0\)/);
  assert.doesNotMatch(repairedSavedBreastRequest.negativePrompt, /dangling nipple jewelry/);

  const nativePromptForImage = vmContext.__waywardSituationEventMod.promptForImage;
  vmContext.__waywardSituationEventMod.promptForImage = async () => ({
    prompt: 'H-Status original prompt', negativePrompt: 'H-Status original negative',
    workflow: 'illustrious', width: 768, height: 576, steps: 8, cfg: 1, look: 'residue-look',
  });
  savedSettings = { ...savedSettings, residueGenerationProvider: 'aip',
    hStatusGenerationModes: { ...savedSettings.hStatusGenerationModes, mouth: 'hstatus' } };
  secretSections = [{ querySelectorAll: selector => selector === '.ko-se-fluid-grid > .ko-se-fluid-card' ? [residueCard] : [] }];
  pauseObserverCallback();
  animationFrameCallback();
  const nativeGenerationCount = generatedRequests.length;
  residueControls.children.find(node => node.dataset?.attentionResidueRegenerate === '').click();
  for (let count = 0; count < 6 && generatedRequests.length === nativeGenerationCount; count += 1) {
    await new Promise(resolve => setImmediate(resolve));
  }
  assert.equal(generatedRequests.length, nativeGenerationCount + 1);
  const nativeResidueRequest = generatedRequests.at(-1);
  assert.equal(nativeResidueRequest.look, 'residue-look', 'H-Status generation must retain the supplied look fingerprint');
  assert.deepEqual([nativeResidueRequest.prompt, nativeResidueRequest.width, nativeResidueRequest.height,
    nativeResidueRequest.steps, nativeResidueRequest.cfg], ['H-Status original prompt', 768, 576, 8, 1]);
  const preservedNativeRequest = await hooks.imageGenerate.around(request => request,
    { ...nativeResidueRequest, bypassCache: true });
  assert.equal(preservedNativeRequest.prompt, nativeResidueRequest.prompt,
    'H-Status default should bypass AIP framing and saved prompt overrides');
  assert.equal(preservedNativeRequest.width, 768);

  let studioOpenCount = 0;
  const studioRequests = [];
  vmContext.WW_ImageStudioPrompt = {
    open() { studioOpenCount += 1; },
    async generate(request) { studioRequests.push(request); return { draftId: 'draft-test' }; },
  };
  secretModeButton.click();
  let providerSelect = flattenNodes(openedSettingsWindow.body.children)
    .find(node => node.props?.['data-residue-generation-provider'] === '');
  assert.deepEqual(providerSelect.children.map(option => option.props.value), ['aip', 'imagestudio']);
  providerSelect.props.onchange({ currentTarget: { value: 'imagestudio' } });
  assert.equal(savedSettings.residueGenerationProvider, 'imagestudio');
  animationFrameCallback();
  assert.equal(atelierBaseButton.hidden, false, 'the separate regeneration button should return with ImageStudio mode');
  assert.equal(atelierActions.hidden, false);
  assert.ok(residueControls.children.some(node => node.textContent === 'ImageStudio 검수 생성'));
  assert.equal(residueControls.children.some(node => node.textContent === '상태별 생성'), false);
  const studioChoiceCount = savedSettings.residueImageChoices[residueCard.dataset.aipResidueKey]?.items.length || 0;
  residueControls.children.find(node => node.dataset?.attentionResidueRegenerate === '').click();
  for (let count = 0; count < 6 && !studioRequests.length; count += 1) {
    await new Promise(resolve => setImmediate(resolve));
  }
  assert.equal(studioOpenCount, 1);
  assert.deepEqual([studioRequests[0].prompt, studioRequests[0].width, studioRequests[0].height],
    ['H-Status original prompt', 768, 576]);
  assert.equal(generatedRequests.length, nativeGenerationCount + 1, 'studio review should not send an AIP direct generation');
  assert.equal(savedSettings.residueImageChoices[residueCard.dataset.aipResidueKey]?.items.length || 0,
    studioChoiceCount, 'a draft must not be selected before review approval');
  providerSelect = flattenNodes(openedSettingsWindow.body.children)
    .find(node => node.props?.['data-residue-generation-provider'] === '');
  providerSelect.props.onchange({ currentTarget: { value: 'aip' } });
  atelierStatusButton = {};
  animationFrameCallback();
  assert.equal(atelierBaseButton.hidden, true);
  assert.equal(atelierActions.hidden, false, 'status-overlay regeneration remains available in AIP mode');
  assert.ok(residueControls.children.some(node => node.textContent === '프롬프트 수정'));
  assert.ok(residueControls.children.some(node => node.textContent === '상태별 생성'));
  delete vmContext.WW_ImageStudioPrompt;
  vmContext.__waywardSituationEventMod.promptForImage = nativePromptForImage;
  savedSettings = { ...savedSettings, residueGenerationProvider: 'aip', residuePrompts: {},
    hStatusGenerationModes: { mouth: 'own', breasts: 'own', uterus: 'own', vulva: 'own', thighs: 'own' } };
  const ownRequest = key => hooks.imageGenerate.around(request => request, {
    imageKey: key, prompt: 'H-Status source prompt', negativePrompt: 'H-Status source negative',
    debug: { source: 'wayward-situation' },
  });
  const ownStates = [
    ['situation_fluid__iris__mouth__stage-0', /clean lips and tongue/],
    ['situation_fluid__iris__mouth__stage-1', /small semen trace on lower lip/],
    ['situation_fluid__iris__mouth__stage-2', /semen on tongue and lower lip/],
    ['situation_fluid__iris__mouth__stage-3', /semen pooled in mouth/],
    [customMouthKey, /semen overflowing mouth/],
    ['situation_fluid__iris__breasts__stage-0', /clean bare breasts/],
    ['situation_fluid__iris__breasts__stage-2', /semen marks on both breasts/],
    ['situation_fluid__iris__breasts__stage-4', /breasts covered in semen/],
    ['situation_fluid__iris__uterus__width-0__stage-0', /empty uterus and vaginal canal/],
    ['situation_fluid__iris__uterus__width-0__stage-1', /semen trace low in vaginal canal.*uterus empty/],
    ['situation_fluid__iris__uterus__width-1__stage-2', /vaginal canal filled with semen, small pool in uterus/],
    ['situation_fluid__iris__uterus__width-1__stage-3', /uterus half filled with semen, slight leak/],
    ['situation_fluid__iris__uterus__width-2__stage-4', /uterus and vaginal canal full of semen, visible overflow/],
    ['situation_vulva__iris__wetness-0__jewelry-0', /dry vulva/],
    ['situation_vulva__iris__wetness-2__jewelry-0', /clear droplets on labia/],
    [customVulvaKey, /clear fluid flowing down both inner thighs/],
    ['situation_fluid__iris__thighs__stage-0', /clean inner thighs/],
    ['situation_fluid__iris__thighs__stage-1', /one semen streak on one inner thigh/],
    ['situation_fluid__iris__thighs__stage-2', /semen streaks and drips on both inner thighs/],
    ['situation_toy_info__iris__vulva__vibe-egg__width-0__inside-0', /clean vaginal opening/],
    [customToyKey, /purple egg_vibrator.*vaginal_object_insertion.*vibrator_cord.*fully inside her vagina.*only its cord visible/],
    [customPenisToyKey, /purple dildo, vibrator, vaginal_object_insertion.*fully inside her vagina.*only its base visible/],
    ['situation_toy_info__iris__uterus__vibe-egg__width-0__inside-0', /purple egg_vibrator.*fully inside vaginal canal/],
    [customPenisUterusKey, /purple dildo, vibrator.*fully inside vaginal canal/],
  ];
  const ownPrompts = new Map();
  for (const [key, expected] of ownStates) {
    const result = await ownRequest(key);
    ownPrompts.set(key, result);
    assert.match(result.prompt, expected, `AIP's own prompt must identify ${key}`);
    assert.doesNotMatch(result.prompt, /H-Status source prompt|approved .* state|fantasy tavern/);
    assert.match(result.prompt, /^1girl, masterpiece, best quality, adult woman/);
    assert.doesNotMatch(result.prompt, /game cg|2D lineart|cel shading|same camera|fixed frontal|plain dark background/i);
    assert.ok(result.prompt.length < 600, `default prompt should stay short: ${key}`);
    assert.equal(result.checkpoint, 'waiIllustriousSDXL_v170.safetensors');
    assert.equal(result.steps, 18);
    assert.equal(result.cfg, 2.5);
    assert.equal(result.loraStrength, 0.8);
    assert.equal(result.width, 1216);
    assert.equal(result.height, 832);
  }
  assert.match(ownPrompts.get(customToyKey).negativePrompt, /dildo, multiple vibrators, holding_sex_toy, vibrator outside body/);
  assert.match(ownPrompts.get(customPenisToyKey).negativePrompt, /egg_vibrator, vibrator_cord, multiple vibrators, holding_sex_toy, dildo outside body/);
  assert.match(ownPrompts.get(customMouthKey).prompt, /silver hair|amber eyes/);
  assert.doesNotMatch(ownPrompts.get(customMouthKey).prompt, /hip tattoo/);
  assert.match(ownPrompts.get('situation_fluid__iris__breasts__stage-2').prompt, /small breasts/);
  assert.doesNotMatch(ownPrompts.get('situation_fluid__iris__breasts__stage-2').prompt, /silver hair/);
  assert.match(ownPrompts.get(customVulvaKey).prompt, /hip tattoo/);
  assert.doesNotMatch(ownPrompts.get(customVulvaKey).prompt, /silver hair/);
  assert.match(ownPrompts.get('situation_fluid__iris__uterus__width-0__stage-0').prompt,
    /x-ray view through intact skin, one pink uterus and vaginal canal/);
  assert.doesNotMatch(ownPrompts.get('situation_fluid__iris__uterus__width-0__stage-0').prompt,
    /status icon|fixed crop|same camera/i);
  assert.match(ownPrompts.get('situation_fluid__iris__uterus__width-0__stage-0').negativePrompt,
    /detached organ/);
  assert.match(ownPrompts.get('situation_fluid__iris__uterus__width-0__stage-0').negativePrompt,
    /semen, cum/);
  assert.doesNotMatch(ownPrompts.get('situation_fluid__iris__uterus__width-1__stage-2').negativePrompt,
    /(?:^|, )semen(?:,|$)/);
  assert.match(ownPrompts.get('situation_fluid__iris__mouth__stage-0').negativePrompt, /semen/);
  assert.doesNotMatch(ownPrompts.get(customMouthKey).negativePrompt, /semen/);
  assert.match((await ownRequest(customBreastRightKey)).prompt, /right nipple only/);
  assert.match((await ownRequest(customBreastBothKey)).prompt, /rings on both nipples/);
  const ownChoker = await ownRequest(customBreastChokerKey);
  assert.match(ownChoker.prompt, /black heart choker/);
  assert.doesNotMatch(ownChoker.negativePrompt, /(?:^|, )pendant(?:,|$)/);
  assert.match((await ownRequest('situation_vulva__iris__wetness-2__jewelry-1')).prompt, /silver clitoral piercing/);
  const originalOwnAppearance = savedSettings.characterPrompt;
  savedSettings = { ...savedSettings, characterPrompt: { ...originalOwnAppearance,
    positivePrompt: '(Kyouko Toshinou:1.2), petite slim build, bright green eyes, (straight blonde hair:1.1)',
    negativePrompt: 'blonde hair, child' } };
  const anchoredOwn = await ownRequest(customMouthKey);
  assert.match(anchoredOwn.prompt, /Kyouko Toshinou/);
  assert.doesNotMatch(anchoredOwn.negativePrompt, /blonde hair/);
  savedSettings = { ...savedSettings, characterPrompt: originalOwnAppearance };
  const ownGenerationCount = generatedRequests.length;
  residueControls.children.find(node => node.dataset?.attentionResidueRegenerate === '').click();
  for (let count = 0; count < 6 && generatedRequests.length === ownGenerationCount; count += 1) {
    await new Promise(resolve => setImmediate(resolve));
  }
  assert.equal(generatedRequests.length, ownGenerationCount + 1);
  assert.equal(generatedRequests.at(-1).debug.source, 'attention-image-prompt-residue-own');
  assert.equal(Object.hasOwn(generatedRequests.at(-1), 'look'), false, 'own residue prompts without look must remain unchanged');
  assert.match(generatedRequests.at(-1).prompt, /clean lips and tongue/);
  assert.equal(generatedRequests.at(-1).steps, 18);
  assert.equal(generatedRequests.at(-1).cfg, 2.5);
  assert.equal(generatedRequests.at(-1).loraStrength, 0.8);
  assert.equal(generatedRequests.at(-1).checkpoint, 'waiIllustriousSDXL_v170.safetensors');
  residueControls.children.find(node => node.textContent === '상태별 생성').click();
  await new Promise(resolve => setImmediate(resolve));
  await new Promise(resolve => setImmediate(resolve));
  let ownBatchNodes = flattenNodes(openedSettingsWindow.body.children);
  ownBatchNodes.find(node => node.props?.['data-residue-batch-part'] === '').props.onchange({ currentTarget: { value: 'vulva' } });
  await new Promise(resolve => setImmediate(resolve));
  await new Promise(resolve => setImmediate(resolve));
  ownBatchNodes = flattenNodes(openedSettingsWindow.body.children);
  const editOtherState = ownBatchNodes.find(node => node.props?.options?.['data-residue-batch-prompt'] === customToyKey);
  assert.ok(editOtherState, 'every listed state should expose its own prompt editor');
  editOtherState.props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  let ownEditorNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.match(ownEditorNodes.find(node => node.props?.['data-residue-prompt-input'] === 'positive').props.value,
    /purple egg_vibrator.*vaginal_object_insertion/);
  ownEditorNodes.find(node => node.props?.['data-residue-prompt-input'] === 'positive').props.oninput({ currentTarget: { value: 'my own egg state prompt' } });
  ownEditorNodes.find(node => node.props?.['data-residue-prompt-input'] === 'negative').props.oninput({ currentTarget: { value: 'my own egg state negative' } });
  ownEditorNodes.find(node => node.tag === 'button' && node.children.includes('저장')).props.onclick();
  assert.equal(savedSettings.residuePrompts[customToyKey].positivePrompt, 'my own egg state prompt');
  const [editedOwnRequest] = hooks.imageGenerate.before([{
    imageKey: customToyKey, prompt: 'H-Status source prompt', negativePrompt: '',
    debug: { source: 'wayward-situation' },
  }]);
  const editedOwnResult = await hooks.imageGenerate.around(request => request, editedOwnRequest);
  assert.equal(editedOwnResult.prompt, 'my own egg state prompt');
  assert.equal(editedOwnResult.negativePrompt, 'my own egg state negative');
  assert.equal(savedSettings.residuePrompts[customMouthKey], undefined,
    'editing a different state must not change the current mouth state');
  ownEditorNodes.find(node => node.tag === 'button' && node.children.includes('기본값으로 복원')).props.onclick();
  assert.equal(savedSettings.residuePrompts[customToyKey], undefined);
  ownEditorNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.match(ownEditorNodes.find(node => node.props?.['data-residue-prompt-input'] === 'positive').props.value,
    /purple egg_vibrator.*vaginal_object_insertion/);
  secretSections = [];

  wife.shortname = 'pippa';
  wife.archetypeId = 'pippa_waif';
  delete wife.generatedArchetype;
  savedSettings = {
    ...savedSettings,
    characterPrompt: {
      wifeKey: 'pippa_waif',
      positivePrompt: '1girl, blonde hair, bright green eyes, freckles, cute face, petite slim build, small breasts',
      negativePrompt: 'large breasts', mode: 'replace', imagePolicy: 'reuse',
    },
    residuePrompts: {},
  };
  const sameNameBuiltInRequest = await hooks.imageGenerate.around(request => request, {
    imageKey: `${referenceBreastLeftKey}__v-1700000000004`,
    prompt: 'unrepaired built-in prompt', negativePrompt: '',
    debug: { source: 'attention-image-prompt-residue' },
  });
  assert.match(sameNameBuiltInRequest.prompt, /small breasts/);
  assert.match(sameNameBuiltInRequest.prompt, /fixed frontal chest crop/);
  assert.doesNotMatch(sameNameBuiltInRequest.prompt, /freckles|cute face|three-quarter view|breast focus|extreme close-up/,
    'the mod regenerate button should apply only framing cleanup even when its image key is pippa');
  assert.match(sameNameBuiltInRequest.negativePrompt, /large breasts/);
  assert.doesNotMatch(sameNameBuiltInRequest.negativePrompt, /gigantomastia|dangling nipple jewelry/);
  assert.equal(sameNameBuiltInRequest.width, 1216);
  assert.equal(sameNameBuiltInRequest.height, 832);

  wife.shortname = originalWife.shortname;
  wife.archetypeId = originalWife.archetypeId;
  if (originalWife.generatedArchetype === undefined) delete wife.generatedArchetype;
  else wife.generatedArchetype = originalWife.generatedArchetype;
  if (originalWife.situationStats === undefined) delete wife.situationStats;
  else wife.situationStats = originalWife.situationStats;
  savedSettings = originalSettings;
  if (originalBridge === undefined) delete vmContext.__waywardSituationEventMod;
  else vmContext.__waywardSituationEventMod = originalBridge;
  if (originalPacks === undefined) delete vmContext.__WAYWARD_SITUATION_PROMPT_PACKS__;
  else vmContext.__WAYWARD_SITUATION_PROMPT_PACKS__ = originalPacks;
  if (originalProfiles === undefined) delete vmContext.__WAYWARD_CHARACTER_PROMPT_PROFILES__;
  else vmContext.__WAYWARD_CHARACTER_PROMPT_PROFILES__ = originalProfiles;

  let wifeBuilderOpened = false;
  let editedWifeId = null;
  let selectedCustomWife = null;
  const pickerProps = {
    onOpenBuilder(id) { wifeBuilderOpened = true; editedWifeId = id ?? null; },
    onSelect(...args) { selectedCustomWife = args; },
  };
  const pickerGameBefore = api.game;
  api.game = '2026-10-24-pre7';
  const nativePicker = fakeJsxNode('div', { children: [fakeJsxNode('button', { children: '원본 사용자 아내' })] });
  assert.equal(hooks.wifePicker.after(nativePicker, [pickerProps]), nativePicker,
    'pre7 must keep the native character picker without adding duplicate AIP controls');
  api.game = '2026-10-04';
  const renderPicker = () => hooks.wifePicker.after(
    { type: 'div', tag: 'div', props: { children: [
      { type: 'div', tag: 'div', props: { className: 'space-y-3 mb-6', children: [] } },
    ] } },
    [pickerProps],
  );
  let pickerNodes = flattenNodes(renderPicker());
  const wifeEnglishName = pickerNodes.find(node => node.tag === 'input' && node.props['data-wife-english-name'] === '');
  const addWifeForm = pickerNodes.find(node => node.tag === 'form' && node.props['data-add-wife-form'] === '');
  const addWifeButton = pickerNodes.find(node => node.tag === 'button' && node.props['data-add-wife-button'] === '');
  assert.ok(wifeEnglishName && addWifeForm && addWifeButton,
    'new-game wife picker should expose the English image name and Add wife action');
  api.game = pickerGameBefore;
  const withImageStudioForm = hooks.wifePicker.after(renderPicker(), [pickerProps]);
  assert.equal(flattenNodes(withImageStudioForm).filter(node => node.tag === 'button'
    && node.props['data-add-wife-button'] === '').length, 1,
    'ImageStudio and AIP must not render duplicate custom-wife creation buttons');
  assert.ok(flattenNodes(withImageStudioForm).some(node => node.tag === 'details'
    && node.props['data-add-wife-details'] === ''), 'custom-wife creation should be collapsed into the native picker');
  assert.equal(addWifeButton.props.className.includes('w-full'), false,
    'the custom-wife action should not stretch across the entire picker');
  const wrappedWifeList = fakeJsxNode(() => null, { children: fakeJsxNode('div', {
    className: 'space-y-3 mb-6', children: [fakeJsxNode('button', { children: '기존 아내' })],
  }) });
  const afterWrappedList = hooks.wifePicker.after(wrappedWifeList, [pickerProps]);
  const wifeListChildren = afterWrappedList.props.children.props.children;
  assert.equal(wifeListChildren.at(-1).props['data-attention-wife-tools'], '',
    'custom-wife creation must appear after the wife cards even when the picker has a React function wrapper');
  function LiveWifePicker({ onSelect, onOpenBuilder }) {
    const endpoint = 'wife-image-counts';
    assert.ok(endpoint && onSelect && onOpenBuilder);
    return fakeJsxNode('div', { children: fakeJsxNode('div', {
      className: 'space-y-3 mb-6', children: [fakeJsxNode('button', { children: '기존 아내' })],
    }) });
  }
  const livePickerElement = fakeJsxNode(LiveWifePicker, pickerProps);
  const wrappedPickerElement = hooks.wifePicker.after(livePickerElement, [pickerProps]);
  assert.equal(wrappedPickerElement.type === LiveWifePicker, false,
    'a deferred React wife picker should be decorated when it actually renders');
  assert.equal(wrappedPickerElement.type, hooks.wifePicker.after(livePickerElement, [pickerProps]).type,
    'the decorated picker component identity must stay stable across rerenders');
  const renderedWifeList = wrappedPickerElement.type(wrappedPickerElement.props).props.children;
  assert.equal(renderedWifeList.props.children.at(-1).props['data-attention-wife-tools'], '',
    'the live component should render the creation form below its wife cards');
  const opaquePicker = fakeJsxNode(() => null, {
    onSelect: pickerProps.onSelect,
    onOpenBuilder: pickerProps.onOpenBuilder,
    children: fakeJsxNode('div', { 'data-character-atelier-picker': '' }),
  });
  const visiblePicker = hooks.wifePicker.after(opaquePicker, [pickerProps]);
  assert.equal(visiblePicker.type, Symbol.for('react.fragment'),
    'an opaque picker component must be wrapped so its custom-wife tools are visible');
  assert.equal(flattenNodes(visiblePicker).filter(node => node.props?.['data-add-wife-button'] === '').length, 1);
  assert.equal(flattenNodes(hooks.wifePicker.after(visiblePicker, [pickerProps]))
    .filter(node => node.props?.['data-add-wife-button'] === '').length, 1,
  'rerendering an opaque picker must not duplicate its custom-wife button');
  assert.equal(pickerNodes.some(node => node.tag === 'select'), false,
    'appearance source selection should live inside the wife builder');
  wifeEnglishName.props.onChange({ currentTarget: { value: 'Pippa Nova' } });
  addWifeForm.props.onSubmit({ preventDefault() {} });
  assert.equal(wifeBuilderOpened, true, 'Add wife should open the game wife builder');
  const builderDefaults = hooks.wifeBuilderDefaults.after(api.fn('wifeBuilderDefaults')(), []);
  assert.equal(builderDefaults.__attentionImageEnglishName, 'Pippa Nova');
  assert.equal(builderDefaults.__attentionImageShortname, 'pippa_nova');
  assert.equal(builderDefaults.__attentionImageNegativePrompt, 'default_negative');
  assert.equal(builderDefaults.__attentionExtraLinesArchetypeId, 'elena_farmgirl');
  assert.deepEqual({ ...builderDefaults.__attentionImageOutfitColors }, { primary: '', secondary1: '', secondary2: '' });
  assert.equal(builderDefaults.customAppearance, '');
  const initialBuilderArchetype = hooks.buildWifeArchetype.after(
    { imageBase: 'brown hair, long hair, blue eyes' },
    [builderDefaults, 'builder-preview'],
  );
  assert.equal(initialBuilderArchetype.imageBase, 'brown hair, long hair, blue eyes');
  assert.equal(initialBuilderArchetype.shortname, 'pippa_nova',
    'the generated wife image key should use the normalized English name');
  assert.equal(initialBuilderArchetype.englishName, 'Pippa Nova');
  const registeredWifeProfile = vmContext.__WAYWARD_CHARACTER_PROMPT_PROFILES__
    .find(profile => profile.shortname === 'pippa_nova');
  assert.equal(registeredWifeProfile.archetypeId, 'pippa_nova');
  assert.equal(registeredWifeProfile.positiveTags, 'brown hair, long hair, blue eyes');
  assert.equal(registeredWifeProfile.negativeTags, 'default_negative');
  assert.equal(registeredWifeProfile.attentionImagePromptOwner, 'attention-image-prompt',
    'generated wives should register an H-Status character prompt profile');

  let builderBase = '';
  let builderPrompt = builderDefaults.customAppearance;
  let builderPromptUpdates = 0;
  const renderBuilder = (editId = null) => hooks.wifeBuilder.after(fakeJsxNode('div', { children: [
    fakeJsxNode('section', { title: '인물 정보', children: [] }),
    fakeJsxNode('section', { title: '외모 기준 캐릭터', children: [
      fakeJsxNode('select', {
        value: builderBase,
        onChange(event) { builderBase = event.target.value; },
        children: [
          fakeJsxNode('option', { value: '', children: '기준 캐릭터 없음' }),
          fakeJsxNode('option', { value: 'native_base', children: '기본 프리셋' }),
        ],
      }),
    ] }),
    fakeJsxNode('section', { title: '외모', children: [
      fakeJsxNode('div', { children: '추가 프롬프트 태그' }),
      fakeJsxNode('textarea', {
        value: builderPrompt,
        placeholder: '예: hair ribbon(머리 리본), calloused hands(굳은살 박인 손)',
        onChange(event) { builderPrompt = event.target.value; builderPromptUpdates += 1; },
      }),
    ] }),
  ] }), [{ editId }]);
  let builderNodes = flattenNodes(renderBuilder());
  const firstMode = nodes => nodes.find(node => node.tag === 'select' && node.props['data-wife-first-experience-mode'] === '');
  const firstPartner = nodes => nodes.find(node => node.tag === 'input' && node.props['data-wife-first-experience-partner'] === '');
  assert.equal(firstMode(builderNodes).props.value, 'random', 'new wives default to random first experience');
  assert.deepEqual(Array.from(firstMode(builderNodes).props.children, node => node.props.value), ['random', 'none', 'player', 'other']);
  assert.equal(firstPartner(builderNodes), undefined, 'partner name is only shown for another person');
  for (const mode of ['none', 'player', 'other']) {
    firstMode(builderNodes).props.onChange({ target: { value: mode } });
    builderNodes = flattenNodes(renderBuilder());
    assert.equal(firstMode(builderNodes).props.value, mode, `${mode} choice survives a rerender`);
    assert.equal(builderDefaults.__attentionFirstExperience.mode, mode, `${mode} is saved in builder inputs`);
  }
  assert.ok(firstPartner(builderNodes), 'other exposes the name field');
  firstPartner(builderNodes).props.onChange({ target: { value: '테스트 상대' } });
  builderNodes = flattenNodes(renderBuilder());
  assert.equal(firstPartner(builderNodes).props.value, '테스트 상대');
  assert.equal(builderDefaults.__attentionFirstExperience.partnerName, '테스트 상대');
  firstMode(builderNodes).props.onChange({ target: { value: 'player' } });
  builderNodes = flattenNodes(renderBuilder());
  assert.equal(firstPartner(builderNodes), undefined, 'changing away from other hides the partner field');
  firstMode(builderNodes).props.onChange({ target: { value: 'other' } });
  builderNodes = flattenNodes(renderBuilder());
  assert.equal(firstPartner(builderNodes).props.value, '테스트 상대', 'switching back retains the entered name');
  const editInputs = { ...builderDefaults, __attentionFirstExperience: { mode: 'other', partnerName: '저장된 상대' } };
  hooks.buildWifeArchetype.after({ imageBase: 'brown hair, long hair, blue eyes' }, [editInputs, 'existing-wife']);
  const editNodes = flattenNodes(renderBuilder('existing-wife'));
  assert.equal(firstMode(editNodes).props.value, 'other', 'editing restores the stored choice');
  assert.equal(firstPartner(editNodes).props.value, '저장된 상대', 'editing restores the stored partner');
  assert.deepEqual({ ...editInputs.__attentionFirstExperience }, { mode: 'other', partnerName: '저장된 상대' },
    'rendering the editor does not overwrite saved settings');
  const oldEditInputs = { ...editInputs };
  delete oldEditInputs.__attentionFirstExperience;
  hooks.buildWifeArchetype.after({ imageBase: 'brown hair, long hair, blue eyes' }, [oldEditInputs, 'old-wife']);
  const oldEditNodes = flattenNodes(renderBuilder('old-wife'));
  assert.equal(firstMode(oldEditNodes).props.value, 'random', 'old wives display the default choice');
  assert.equal(Object.hasOwn(oldEditInputs, '__attentionFirstExperience'), false,
    'opening an old wife without choosing a new setting preserves the original behavior');
  delete builderDefaults.__attentionFirstExperience;
  hooks.buildWifeArchetype.after({ imageBase: 'brown hair, long hair, blue eyes' }, [builderDefaults, 'builder-preview']);
  builderNodes = flattenNodes(renderBuilder());
  let builderBaseSelect = builderNodes.find(node => node.tag === 'select' && node.props['data-wife-builder-base'] === '');
  let noBaseControl = builderNodes.find(node => node.tag === 'label' && node.props['data-wife-no-base'] === '');
  let fullPromptInput = builderNodes.find(node => node.tag === 'textarea' && node.props['data-wife-full-prompt'] === '');
  let fullNegativeInput = builderNodes.find(node => node.tag === 'textarea' && node.props['data-wife-negative-prompt'] === '');
  let dialogueSourceInput = builderNodes.find(node => node.tag === 'select' && node.props['data-wife-dialogue-source'] === '');
  let outfitColorInputs = builderNodes.filter(node => node.tag === 'select' && node.props['data-wife-outfit-color']);
  assert.ok(builderBaseSelect && noBaseControl && fullPromptInput && fullNegativeInput && dialogueSourceInput,
    'wife builder should expose base, dialogue and full Positive/Negative prompt editors');
  assert.deepEqual(outfitColorInputs.map(node => node.props['data-wife-outfit-color']), ['primary', 'secondary1', 'secondary2']);
  assert.equal(dialogueSourceInput.props.value, 'elena_farmgirl');
  assert.equal(fullPromptInput.props.value, 'brown hair, long hair, blue eyes',
    'the editor should expose the complete prompt generated from appearance controls');
  assert.equal(fullNegativeInput.props.value, 'default_negative',
    'the editor should expose only the shared preview/in-game Negative prompt');
  const sourceOptions = builderNodes.filter(node => node.tag === 'option'
    && String(node.props.value || '').startsWith('attention-wife:'));
  const emptyBaseOption = builderNodes.find(node => node.tag === 'option' && node.props.value === '');
  assert.ok(sourceOptions.some(node => node.props.value === 'attention-wife:elena_farmgirl'));
  assert.ok(sourceOptions.some(node => node.props.value === 'attention-wife:pippa_waif'));
  assert.equal(emptyBaseOption?.props.hidden, true);
  assert.notEqual(emptyBaseOption?.props.children, '기준 캐릭터 없음',
    'the no-base choice should only be exposed as a checkbox');
  assert.equal(builderNodes.some(node => node.props?.children === '전체 외형 프롬프트 (기존 프롬프트 교체)'), true);
  builderBaseSelect.props.onChange({ target: { value: 'attention-wife:pippa_waif' } });
  assert.equal(builderBase, '');
  assert.equal(builderPrompt, wifeArchetypes.pippa_waif.imageBase,
    'selecting Pippa should load her complete prompt into the editor');
  assert.match(builderDefaults.__attentionImageNegativePrompt, /child/);
  assert.match(builderDefaults.__attentionImageNegativePrompt, /black hair/,
    'selecting a built-in source should load its character-specific Negative prompt');
  builderDefaults.customAppearance = builderPrompt;
  hooks.buildWifeArchetype.after(
    { imageBase: `brown hair, long hair, blue eyes, ${builderPrompt}` },
    [builderDefaults, 'builder-preview'],
  );
  builderNodes = flattenNodes(renderBuilder());
  builderBaseSelect = builderNodes.find(node => node.tag === 'select' && node.props['data-wife-builder-base'] === '');
  noBaseControl = builderNodes.find(node => node.tag === 'label' && node.props['data-wife-no-base'] === '');
  fullPromptInput = builderNodes.find(node => node.tag === 'textarea' && node.props['data-wife-full-prompt'] === '');
  assert.equal(builderBaseSelect.props.value, 'attention-wife:pippa_waif');
  assert.equal(noBaseControl.props.children[0].props.checked, false);
  const sourceHairChanged = hooks.buildWifeArchetype.after(
    { imageBase: `blonde hair, long hair, blue eyes, ${builderPrompt}` },
    [builderDefaults, 'builder-preview'],
  );
  assert.match(sourceHairChanged.imageBase, /blonde hair/);
  assert.match(sourceHairChanged.imageBase, /long hair/);
  assert.doesNotMatch(sourceHairChanged.imageBase, /short_brown_hair/,
    'changing hair controls should remove the source character hair prompt');
  assert.match(sourceHairChanged.imageBase, /hair_ribbon/,
    'hair accessories should survive a hair color change');
  assert.match(sourceHairChanged.imageBase, /tired_eyes/,
    'expression tags should survive an eye color change');
  builderNodes = flattenNodes(renderBuilder());
  fullPromptInput = builderNodes.find(node => node.tag === 'textarea' && node.props['data-wife-full-prompt'] === '');
  fullNegativeInput = builderNodes.find(node => node.tag === 'textarea' && node.props['data-wife-negative-prompt'] === '');
  assert.equal(fullPromptInput.props.value, sourceHairChanged.imageBase);
  fullPromptInput.props.onChange({ target: { value: '1girl, red hair, tavern, standing, smile, masterpiece' } });
  builderDefaults.customAppearance = builderPrompt;
  hooks.buildWifeArchetype.after(
    { imageBase: `blonde hair, long hair, blue eyes, ${builderPrompt}` },
    [builderDefaults, 'builder-preview'],
  );
  builderNodes = flattenNodes(renderBuilder());
  const cleanupWarning = builderNodes.find(node => node.props?.['data-wife-prompt-cleanup'] === '');
  const cleanupAction = builderNodes.find(node => node.tag === 'button' && node.props['data-wife-prompt-cleanup-action'] === '');
  assert.ok(cleanupWarning && cleanupAction,
    'direct full-prompt edits should warn when scene, action, mood or quality tags are mixed into appearance');
  cleanupAction.props.onClick();
  builderDefaults.customAppearance = builderPrompt;
  const cleanedBuilderArchetype = hooks.buildWifeArchetype.after(
    { imageBase: `blonde hair, long hair, blue eyes, ${builderPrompt}` },
    [builderDefaults, 'builder-preview'],
  );
  assert.equal(cleanedBuilderArchetype.imageBase, '1girl, red hair');
  builderNodes = flattenNodes(renderBuilder());
  assert.equal(builderNodes.some(node => node.props?.['data-wife-prompt-cleanup'] === ''), false,
    'cleanup should remove the warning after keeping only character appearance and outfit tags');
  fullPromptInput = builderNodes.find(node => node.tag === 'textarea' && node.props['data-wife-full-prompt'] === '');
  fullNegativeInput = builderNodes.find(node => node.tag === 'textarea' && node.props['data-wife-negative-prompt'] === '');
  builderDefaults.customAppearance = builderPrompt;
  fullPromptInput.props.onChange({ target: { value: 'edited_picker_prompt' } });
  builderDefaults.customAppearance = builderPrompt;
  const editedBuilderArchetype = hooks.buildWifeArchetype.after(
    { imageBase: `blonde hair, long hair, blue eyes, ${builderPrompt}` },
    [builderDefaults, 'builder-preview'],
  );
  assert.equal(editedBuilderArchetype.imageBase, 'edited_picker_prompt',
    'the full prompt editor should replace the generated wife appearance');
  assert.equal(editedBuilderArchetype.attentionImagePrompt.mode, 'replace');
  const updatesBeforeNegativeEdit = builderPromptUpdates;
  fullNegativeInput.props.onChange({ target: { value: 'bad_anatomy, watermark' } });
  assert.equal(builderPromptUpdates, updatesBeforeNegativeEdit + 1,
    'editing Negative should trigger the game wife-builder state update needed by a controlled textarea');
  const negativeEditedArchetype = hooks.buildWifeArchetype.after(
    { imageBase: `blonde hair, long hair, blue eyes, ${builderPrompt}` },
    [builderDefaults, 'builder-preview'],
  );
  assert.equal(builderDefaults.__attentionImageNegativePrompt, 'bad_anatomy, watermark');
  assert.equal(negativeEditedArchetype.attentionImagePrompt.negativePrompt, 'bad_anatomy, watermark');
  assert.equal(negativeEditedArchetype.attentionImageNegativeOverride, 'bad_anatomy, watermark');
  const rawWifePreview = api.fn('wifePreviewBundle')(negativeEditedArchetype);
  const editedWifePreview = hooks.wifePreviewBundle.after(rawWifePreview, [negativeEditedArchetype]);
  assert.equal(editedWifePreview.negativePrompt,
    'bad_anatomy, watermark, nude, naked, breasts_out, nipples, lingerie, heavy armor, cloak hiding body, cropped, close-up',
    'wife preview should combine the shared Negative with preview-only composition exclusions');
  const leakedWifePreview = hooks.wifePreviewBundle.after({
    ...rawWifePreview,
    prompt: `${rawWifePreview.prompt}, bad_anatomy, watermark`,
    parts: [{ label: '대상', tags: 'edited_picker_prompt, bad_anatomy, watermark' }],
  }, [negativeEditedArchetype]);
  assert.doesNotMatch(leakedWifePreview.prompt, /bad_anatomy|watermark/,
    'wife preview regeneration should remove Negative tags from its Positive prompt');
  assert.equal(leakedWifePreview.parts[0].tags, 'edited_picker_prompt');
  assert.equal(leakedWifePreview.genParams.promptLength, leakedWifePreview.prompt.length);
  const changedLookArchetype = hooks.buildWifeArchetype.after(
    { imageBase: `red hair, short hair, brown eyes, ${builderPrompt}` },
    [builderDefaults, 'builder-preview'],
  );
  assert.match(changedLookArchetype.imageBase, /red hair/);
  assert.match(changedLookArchetype.imageBase, /short hair/);
  assert.match(changedLookArchetype.imageBase, /brown eyes/);
  assert.doesNotMatch(changedLookArchetype.imageBase, /blonde hair/);
  assert.match(changedLookArchetype.imageBase, /edited_picker_prompt/);
  builderNodes = flattenNodes(renderBuilder());
  fullPromptInput = builderNodes.find(node => node.tag === 'textarea' && node.props['data-wife-full-prompt'] === '');
  assert.equal(fullPromptInput.props.value, changedLookArchetype.imageBase,
    'appearance changes should be reflected in the visible complete prompt');
  dialogueSourceInput = builderNodes.find(node => node.tag === 'select' && node.props['data-wife-dialogue-source'] === '');
  outfitColorInputs = builderNodes.filter(node => node.tag === 'select' && node.props['data-wife-outfit-color']);
  dialogueSourceInput.props.onChange({ target: { value: 'mara_citygirl' } });
  outfitColorInputs.find(node => node.props['data-wife-outfit-color'] === 'primary').props.onChange({ target: { value: 'red' } });
  outfitColorInputs.find(node => node.props['data-wife-outfit-color'] === 'secondary1').props.onChange({ target: { value: 'black' } });
  outfitColorInputs.find(node => node.props['data-wife-outfit-color'] === 'secondary2').props.onChange({ target: { value: 'gold' } });
  builderDefaults.customAppearance = builderPrompt;
  const coloredBuilderArchetype = hooks.buildWifeArchetype.after(
    { imageBase: `red hair, short hair, brown eyes, ${builderPrompt}` },
    [builderDefaults, 'builder-preview'],
  );
  assert.match(coloredBuilderArchetype.imageBase, /red clothing/);
  assert.match(coloredBuilderArchetype.imageBase, /black trim/);
  assert.match(coloredBuilderArchetype.imageBase, /gold accents/);
  assert.equal(coloredBuilderArchetype.attentionExtraLinesArchetypeId, 'mara_citygirl');
  builderDefaults.customAppearance = builderPrompt;
  noBaseControl.props.children[0].props.onChange({ target: { checked: true } });
  builderNodes = flattenNodes(renderBuilder());
  builderBaseSelect = builderNodes.find(node => node.tag === 'select' && node.props['data-wife-builder-base'] === '');
  noBaseControl = builderNodes.find(node => node.tag === 'label' && node.props['data-wife-no-base'] === '');
  assert.equal(builderBaseSelect.props.value, '');
  assert.equal(noBaseControl.props.children[0].props.checked, true);
  customWifeStore.getState().save({
    id: 'custom-picker-wife',
    inputs: {
      ...builderDefaults,
      name: '선택 아내',
      customTagline: '선택 가능',
      imageCheckpoint: 'anime/custom-wife.safetensors',
    },
  });
  pickerNodes = flattenNodes(renderPicker());
  const customWifeButton = pickerNodes.find(node => node.tag === 'button' && node.props['data-custom-wife-select'] === 'custom-picker-wife');
  assert.ok(customWifeButton, 'saved custom wives should be selectable from the new-game wife picker');
  customWifeButton.props.onClick();
  assert.equal(selectedCustomWife[0], 'custom-picker-wife');
  assert.equal(selectedCustomWife[1], 'spouse');
  assert.match(selectedCustomWife[2].imageBase, /red hair/);
  assert.match(selectedCustomWife[2].imageBase, /edited_picker_prompt/);
  assert.match(selectedCustomWife[2].imageBase, /red clothing/);
  const customWifeCharacter = hooks.wifeCharacterFromArchetype.after(
    { archetypeId: 'custom-picker-wife', generatedArchetype: selectedCustomWife[2] }, [selectedCustomWife[2], {}],
  );
  assert.equal(customWifeCharacter.archetypeId, 'mara_citygirl',
    'the generated character should expose the selected base heroine id to the extra-lines mod');
  assert.equal(customWifeCharacter.generatedArchetype.id, 'mara_citygirl',
    'the generated archetype id should stay aligned so image lookup keeps using the custom archetype');
  assert.equal(customWifeCharacter.generatedArchetype.attentionCustomWifeId, 'custom-picker-wife');
  assert.equal(customWifeCharacter.generatedArchetype.shortname, 'pippa_nova',
    'the selected dialogue voice must not replace the custom wife image name');
  const studioCustomWife = vmContext.WW_CustomWifeBridge.list()
    .find(entry => entry.entryId === 'custom-picker-wife');
  assert.equal(studioCustomWife.id, 'pippa_nova');
  assert.equal(studioCustomWife.name, '선택 아내');
  assert.match(studioCustomWife.archetype.imageBase, /edited_picker_prompt/);
  vmContext.window.__imageStudioLaunch.click();
  assert.deepEqual(Array.from(vmContext.window.__imageStudioEntries, entry => [...entry]).find(([id]) => id === 'pippa_nova'),
    ['pippa_nova', '선택 아내'], 'saved custom wives should appear after clicking the real Image Studio launch button');
  assert.equal(vm.runInContext('Object.entries === window.__imageStudioOriginalEntries', vmContext), true,
    'the Image Studio compatibility interception must be restored immediately after opening');
  vmContext.WW_ImageStudioBridge.openRandom('pippa_nova');
  assert.equal(vmContext.window.__imageStudioRandomWife, 'custom-picker-wife',
    'Image Studio random generation should resolve the visible image name to the saved wife id');
  hooks.imagePreGenerateDialog.before([]);
  hooks.imagePreGenerateDialog.before([]);
  assert.equal(preGenerateCharacters.filter(id => id === 'custom-picker-wife').length, 1,
    'saved custom wives should appear once in the image pre-generation list');
  const preGenerateDialog = hooks.imagePreGenerateDialog.after(fakeJsxNode('div', {
    children: [
      fakeJsxNode('span', { children: 'elena' }),
      fakeJsxNode('span', { children: 'custom-picker-wife' }),
    ],
  }), []);
  const customPreGenerateLabel = flattenNodes(preGenerateDialog)
    .find(node => node.tag === 'span' && node.props.children === '선택 아내 (생성한 아내)');
  assert.ok(customPreGenerateLabel, 'the pre-generation dialog should show the saved wife name');
  const customPreGenerateCharacter = hooks.imagePlanCharacter.around(
    id => ({ id: 'fallback', archetypeId: id }), 'custom-picker-wife',
  );
  assert.equal(customPreGenerateCharacter.id, 'wife');
  assert.equal(customPreGenerateCharacter.generatedArchetype.shortname, 'pippa_nova');
  assert.match(customPreGenerateCharacter.generatedArchetype.imageBase, /edited_picker_prompt/);
  assert.equal(customPreGenerateCharacter.generatedArchetype.imageCheckpoint, 'anime/custom-wife.safetensors');
  const studioAliasCharacter = hooks.imagePlanCharacter.around(
    id => ({ id: 'fallback', archetypeId: id }), 'pippa_nova',
  );
  assert.equal(studioAliasCharacter.generatedArchetype.shortname, 'pippa_nova',
    'Image Studio conditional generation should resolve the custom wife image name');
  assert.deepEqual(hooks.imagePlanCharacter.around(id => ({ id: 'fallback', archetypeId: id }), 'elena'),
    { id: 'fallback', archetypeId: 'elena' }, 'built-in pre-generation should keep the original planner');
  const explicitPlannerArchetype = { id: 'explicit-wife', imageBase: 'explicit planner appearance' };
  for (const id of ['elena', 'custom-picker-wife']) {
    const nativePlan = hooks.imagePlanCharacter.around(
      (actualId, archetype, extra) => ({ actualId, archetype, extra }), id, explicitPlannerArchetype, 'extra-argument',
    );
    assert.equal(nativePlan.actualId, id, 'planner must preserve the selected id');
    assert.equal(nativePlan.archetype, explicitPlannerArchetype, 'planner must pass an explicit generated archetype to the game');
    assert.equal(nativePlan.extra, 'extra-argument', 'planner must preserve additional game arguments');
  }
  const customPreGeneratePlan = hooks.imagePlanList.after([
    { talentId: 'pippa_nova__task-idle__v-0', prompt: 'planned', look: 'planner-look' },
  ], [{ archetype: 'custom-picker-wife' }]);
  assert.equal(customPreGeneratePlan[0].archetypeId, 'custom-picker-wife');
  assert.equal(customPreGeneratePlan[0].checkpoint, 'anime/custom-wife.safetensors');
  const explicitPlanEntries = [{ talentId: 'explicit__task-idle__v-0', archetypeId: 'explicit-wife', checkpoint: 'explicit-model' }];
  assert.equal(hooks.imagePlanList.after(explicitPlanEntries,
    [{ archetype: 'custom-picker-wife', generatedArchetype: explicitPlannerArchetype }]), explicitPlanEntries,
  'an explicit generated archetype must not be replaced by a saved wife or its checkpoint');
  const studioAliasPlan = hooks.imagePlanList.after([
    { talentId: 'pippa_nova__task-idle__v-0', prompt: 'planned' },
  ], [{ archetype: 'pippa_nova' }]);
  assert.equal(studioAliasPlan[0].archetypeId, 'custom-picker-wife');
  const customPreGenerateQueue = await hooks.imageQueue.around(
    async () => { throw new Error('custom-wife queue should preserve its checkpoint'); }, customPreGeneratePlan,
  );
  assert.equal(customPreGenerateQueue.accepted, 1);
  assert.equal(customPreGenerateQueue.alreadyCached, 0);
  assert.equal(customPreGenerateQueue.jobId, 'custom-wife-job');
  assert.equal(batchRequests[0].items[0].checkpoint, 'anime/custom-wife.safetensors');
  assert.equal(batchRequests[0].items[0].look, 'planner-look', 'custom checkpoint batches must retain the planned look fingerprint');
  let originalQueueCalled = false;
  await hooks.imageQueue.around(async entries => {
    originalQueueCalled = entries[0].talentId === 'elena__task-idle__v-0';
    return { accepted: 1 };
  }, [{ talentId: 'elena__task-idle__v-0' }]);
  assert.equal(originalQueueCalled, true, 'built-in pre-generation should keep the original queue path');
  assert.equal(batchRequests.length, 1);
  customWifeStore.getState().save({ id: 'temporary-pre-generation-wife', inputs: { ...builderDefaults, name: '임시 아내' } });
  hooks.imagePreGenerateDialog.before([]);
  assert.ok(preGenerateCharacters.includes('temporary-pre-generation-wife'));
  customWifeStore.getState().remove('temporary-pre-generation-wife');
  hooks.imagePreGenerateDialog.before([]);
  assert.equal(preGenerateCharacters.includes('temporary-pre-generation-wife'), false,
    'deleted custom wives should leave the image pre-generation list');
  const editCustomWifeButton = pickerNodes.find(node => node.tag === 'button'
    && node.props['data-custom-wife-edit'] === 'custom-picker-wife');
  assert.ok(editCustomWifeButton, 'saved custom wives should expose an edit action');
  editCustomWifeButton.props.onClick();
  assert.equal(editedWifeId, 'custom-picker-wife');
  customWifeStore.getState().save({ id: 'delete-picker-wife', inputs: { ...builderDefaults, name: '삭제 아내' } });
  pickerNodes = flattenNodes(renderPicker());
  const deleteCustomWifeButton = pickerNodes.find(node => node.tag === 'button'
    && node.props['data-custom-wife-delete'] === 'delete-picker-wife');
  assert.ok(deleteCustomWifeButton, 'saved custom wives should expose a delete action');
  deleteCustomWifeButton.props.onClick();
  assert.equal(savedWives.some(entry => entry.id === 'delete-picker-wife'), false);

  settingsRenderer(settingsBody, settingsWin);
  let settingsNodes = collectNodes();
  let detailGroupingToggle = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-detail-state-grouping-toggle'] === '');
  assert.equal(detailGroupingToggle?.props.checked, true,
    'similar detailed states should share images by default');
  detailGroupingToggle.props.onchange({ currentTarget: { checked: false } });
  assert.equal(savedSettings.groupSimilarDetailStates, false,
    'the settings UI should allow exact detailed-state image keys');
  settingsNodes = collectNodes();
  detailGroupingToggle = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-detail-state-grouping-toggle'] === '');
  detailGroupingToggle.props.onchange({ currentTarget: { checked: true } });
  assert.equal(savedSettings.groupSimilarDetailStates, true,
    'the settings UI should allow grouped detailed-state image keys');
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('대화 감지')).props.onclick();
  settingsNodes = collectNodes();
  const defaultDialogueInputs = settingsNodes.filter(node => node.tag === 'textarea');
  defaultDialogueInputs.find(node => node.props.value === 'blush, dazed expression')
    .props.onchange({ currentTarget: { value: 'keep_other_dialogue' } });
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'textarea' && node.props.value === 'tears, scared, humiliated expression')
    .props.onchange({ currentTarget: { value: 'temporary_dialogue_prompt' } });
  settingsNodes = collectNodes();
  settingsNodes.filter(node => node.tag === 'button' && node.children.includes('이 규칙 기본값으로'))[2].props.onclick();
  assert.equal(savedSettings.dialogueRules[0].positivePrompt, 'keep_other_dialogue',
    'resetting one dialogue rule must preserve the other user rules');
  assert.equal(savedSettings.dialogueRules[2].positivePrompt, 'tears, scared, humiliated expression');
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('기본 상황')).props.onclick();
  settingsNodes = collectNodes();
  const restraintInput = settingsNodes.find(node => node.tag === 'textarea'
    && String(node.props.value).includes('only female restrained'));
  assert.ok(restraintInput, 'settings UI should expose the restraint prompt');
  const restraintTranslation = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-tag'] === '(only female restrained:1.25)');
  assert.deepEqual(restraintTranslation.children, ['여성만 구속됨 · 강조 1.25']);
  await restraintTranslation.props.onclick();
  assert.equal(copiedText, '(only female restrained:1.25)', 'clicking a Korean tag should copy its English prompt');
  settingsNodes = collectNodes();
  restraintInput.props.onfocus();
  const libraryTag = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-library-tag'] === 'heart_choker');
  assert.ok(libraryTag, 'settings should expose a searchable all-tag side library');
  const tagLibrary = settingsNodes.find(node => node.tag === 'aside' && node.props['data-tag-library'] === '');
  assert.match(tagLibrary.props.style, /overflow-y:auto/, 'the tag library should have its own vertical scroll');
  assert.equal(flattenNodes(tagLibrary).some(node => node.props?.['data-prompt-preset-use']), false,
    'prompt presets should not remain embedded in the tag library');
  tagLibrary.props.onscroll({ currentTarget: { scrollTop: 137 } });
  const locationCategory = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-tag-category-option'] === 'location');
  assert.ok(locationCategory, 'tag library should expose category filters');
  locationCategory.props.onclick();
  settingsNodes = collectNodes();
  assert.equal(settingsNodes.find(node => node.props?.['data-tag-library'] === '').scrollTop, 137,
    'rerendering from a tag-library button must preserve its scroll position');
  const locationTags = settingsNodes.filter(node => node.tag === 'button' && node.props['data-library-tag']);
  assert.ok(locationTags.some(node => node.props['data-library-tag'] === 'tavern interior'));
  assert.equal(locationTags.every(node => node.props['data-library-category'] === 'location'), true,
    'a selected category should show only its own tags');
  const translatedLocation = locationTags.find(node => node.props['data-library-tag'] === 'tavern interior');
  assert.deepEqual(translatedLocation.children, ['선술집 내부']);
  settingsNodes.find(node => node.tag === 'button' && node.props['data-tag-category-option'] === 'all').props.onclick();
  settingsNodes = collectNodes();
  await libraryTag.props.onclick();
  assert.equal(copiedText, 'heart_choker');
  assert.match(savedSettings.prompts['restraint.handcuffed'], /heart_choker/,
    'a library tag should be inserted into the focused prompt');
  settingsNodes = collectNodes();
  const customLabelInput = settingsNodes.find(node => node.tag === 'input' && node.props['data-custom-tag-label'] === '');
  const customEnglishInput = settingsNodes.find(node => node.tag === 'input' && node.props['data-custom-tag-english'] === '');
  const customTagAdd = settingsNodes.find(node => node.tag === 'button' && node.props['data-custom-tag-add'] === '');
  customLabelInput.props.oninput({ currentTarget: { value: '사용자 자세' } });
  customEnglishInput.props.oninput({ currentTarget: { value: 'user_pose_tag' } });
  customTagAdd.props.onclick();
  assert.deepEqual(Array.from(savedSettings.customTags, entry => ({ ...entry })), [{ tag: 'user_pose_tag', label: '사용자 자세' }]);
  portraitLanguageButton.click();
  assert.equal(savedSettings.portraitTagLanguage, 'ko');
  assert.equal(portraitLanguageButton.textContent, '태그 표시: 한글');
  assert.equal(portraitBuiltInTag.textContent, '양손을 등 뒤로, 수갑을 참');
  assert.equal(portraitCustomTag.textContent, '사용자 자세');
  assert.equal(portraitSceneTag.textContent, '선술집 내부 · 강조 1.2, 수줍음, 따뜻한 촛불, 흰 블라우스, 서 있음');
  assert.equal(portraitNegativeTag.textContent, '족쇄');
  assert.equal(portraitBuiltInTag.getAttribute('data-attention-image-prompt-original'), 'hands_behind_back, handcuffed',
    'portrait translation must retain the English prompt source');
  assert.ok(portraitSummaryPanel.textContent.length > 0, 'state summary must stay visible with Korean prompts');
  assert.doesNotMatch(portraitSummaryPanel.textContent, /hands_behind_back|user_pose_tag/,
    'state summary must describe state instead of repeating prompt tags');
  portraitLanguageButton.click();
  assert.equal(savedSettings.portraitTagLanguage, 'en');
  assert.ok(portraitSummaryPanel.textContent.length > 0, 'state summary must stay visible with English prompts');
  assert.equal(portraitBuiltInTag.textContent, 'hands_behind_back, handcuffed');
  assert.equal(portraitCustomTag.textContent, 'user_pose_tag');
  assert.equal(portraitSceneTag.textContent, '(tavern interior:1.2), shy, warm candlelight, white blouse, standing');
  const stablePortraitButtonTextWrites = portraitButtonTextWrites;
  pauseObserverCallback();
  assert.equal(portraitButtonTextWrites, stablePortraitButtonTextWrites,
    'language toggles must settle instead of retriggering the MutationObserver forever');
  settingsNodes = collectNodes();
  const customLibraryTag = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-library-tag'] === 'user_pose_tag');
  assert.deepEqual(customLibraryTag.children, ['사용자 자세']);
  await customLibraryTag.props.onclick();
  assert.equal(copiedText, 'user_pose_tag');
  assert.match(savedSettings.prompts['restraint.handcuffed'], /user_pose_tag/);
  settingsNodes = collectNodes();
  const modelQualityPreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'wai-quality');
  const expressionPreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'wai-expression-shy');
  const secretUterusPreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-uterus-cutaway');
  const secretUterusStagePreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-uterus-stage-4');
  const secretEggUterusPreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-egg-uterus');
  const secretPenisNegativePreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-penis-negative');
  const secretVulvaNegativePreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-vulva-negative');
  const secretUterusNegativePreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-uterus-negative');
  const secretBreastsFramePreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-breasts-frame');
  const secretThighsFramePreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-thighs-frame');
  const secretPiercingLeftPreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-piercing-left');
  const secretPiercingRightPreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-piercing-right');
  const secretPiercingBothPreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-piercing-both');
  const secretBreastChokerPreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-breast-choker');
  const secretSkinToneNegativePreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-skin-tone-negative');
  const secretBreastSizeNegativePreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-breast-size-negative');
  const secretPiercingShapeNegativePreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-piercing-negative');
  const secretChokerNegativePreset = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === 'secret-choker-negative');
  const promptPresetLibrary = settingsNodes.find(node => node.tag === 'aside'
    && node.props['data-prompt-preset-library'] === '');
  assert.ok(modelQualityPreset && expressionPreset,
    'the current WAI model library should expose quality and expression prompt bundles');
  assert.ok(secretUterusPreset && secretUterusStagePreset && secretEggUterusPreset
    && secretPenisNegativePreset && secretVulvaNegativePreset && secretUterusNegativePreset,
    'the secret-image additions should be reusable from the prompt preset library');
  assert.ok(secretBreastsFramePreset && secretThighsFramePreset && secretPiercingLeftPreset
    && secretPiercingRightPreset && secretPiercingBothPreset && secretSkinToneNegativePreset
    && secretBreastSizeNegativePreset && secretPiercingShapeNegativePreset
    && secretBreastChokerPreset && secretChokerNegativePreset,
  'the fixed frames, piercing sides, choker state, and skin-tone guard should all remain reusable presets');
  assert.ok(promptPresetLibrary, 'prompt presets should render in their own sidebar beside the tag library');
  assert.deepEqual(modelQualityPreset.children, ['WAI 품질 기본'], 'preset chips should show only their title');
  assert.match(modelQualityPreset.props.title, /한글: 최고 수준 작품, 최고 품질, 뛰어난 품질/);
  assert.match(modelQualityPreset.props.title, /영문: masterpiece, best quality, amazing quality/);
  assert.match(secretUterusPreset.props.title, /h-status 겹쳐 표시/i);
  assert.match(secretUterusPreset.props.title, /\(fixed crop from navel to upper thighs:1\.8\)/);
  assert.match(secretUterusStagePreset.props.title, /영문: \(opaque white status fill contained inside most of the pink chamber:1\.75\)/);
  assert.match(secretEggUterusPreset.props.title, /영문: \(exactly one small manufactured purple egg-shaped vibrator symbol:1\.8\)/);
  assert.match(secretPiercingLeftPreset.props.title, /캐릭터 기준 왼쪽 유두\(화면 오른쪽\)에 아주 작은 은색 캡티브 비드 링 하나만/);
  assert.match(secretPiercingRightPreset.props.title, /캐릭터 기준 오른쪽 유두\(화면 왼쪽\)에 아주 작은 은색 캡티브 비드 링 하나만/);
  assert.match(secretPiercingBothPreset.props.title, /양쪽 유두 중앙에 아주 작은 은색 캡티브 비드 링을 하나씩/);
  assert.match(secretPenisNegativePreset.props.title, /에그형 바이브/);
  assert.match(secretPenisNegativePreset.props.title, /\(egg-shaped vibrator:1\.5\)/);
  assert.match(secretUterusNegativePreset.props.title, /한글: 전신 투명/);
  assert.match(secretUterusNegativePreset.props.title, /영문: transparent whole body/);
  promptPresetLibrary.props.onscroll({ currentTarget: { scrollTop: 91 } });
  await modelQualityPreset.props.onclick();
  settingsNodes = collectNodes();
  assert.equal(settingsNodes.find(node => node.props?.['data-prompt-preset-library'] === '').scrollTop, 91,
    'using a preset must preserve the preset sidebar scroll position');
  await expressionPreset.props.onclick();
  assert.match(savedSettings.prompts['restraint.handcuffed'], /masterpiece/);
  assert.match(savedSettings.prompts['restraint.handcuffed'], /averted gaze/);
  settingsNodes = collectNodes();
  const promptPresetName = settingsNodes.find(node => node.tag === 'input' && node.props['data-prompt-preset-name'] === '');
  const promptPresetPrompt = settingsNodes.find(node => node.tag === 'textarea' && node.props['data-prompt-preset-prompt'] === '');
  const promptPresetSave = settingsNodes.find(node => node.tag === 'button' && node.props['data-prompt-preset-save'] === '');
  promptPresetName.props.oninput({ currentTarget: { value: '따뜻한 표정' } });
  promptPresetPrompt.props.oninput({ currentTarget: { value: 'warm lighting, warm_lighting, (warm lighting:1.2), custom_bundle_tag' } });
  promptPresetSave.props.onclick();
  assert.equal(savedSettings.promptPresets.length, 1);
  assert.deepEqual({ ...savedSettings.promptPresets[0] }, {
    id: savedSettings.promptPresets[0].id,
    name: '따뜻한 표정',
    prompt: '(warm lighting:1.2), custom_bundle_tag',
  }, 'saving a user preset should keep the weighted semantic copy of each tag');
  settingsNodes = collectNodes();
  await settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-preset-use'] === savedSettings.promptPresets[0].id).props.onclick();
  assert.match(savedSettings.prompts['restraint.handcuffed'], /custom_bundle_tag/,
    'using a user preset should apply its entire prompt bundle to the focused field');
  const promptBeforeDedupe = savedSettings.prompts['restraint.handcuffed'];
  restraintInput.props.onchange({ currentTarget: { value: `${promptBeforeDedupe}, heart choker, (heart_choker:1.2)` } });
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.props['data-prompt-deduplicate'] === '').props.onclick();
  const semanticHeartTags = savedSettings.prompts['restraint.handcuffed'].split(',').map(tag => tag.trim())
    .filter(tag => tag.replace(/^\(|:\s*[\d.]+\)$/g, '').replaceAll('_', ' ').toLowerCase() === 'heart choker');
  assert.equal(semanticHeartTags.length, 1,
    'the duplicate cleanup action should merge spaces, underscores, and weighted forms of the same tag');
  settingsNodes = collectNodes();
  const directTagInput = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-prompt-tag-input'] === 'restraint.handcuffed');
  const directTagAdd = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-tag-add'] === 'restraint.handcuffed');
  directTagInput.props.oninput({ currentTarget: { value: 'user_custom_tag, handcuffed' } });
  directTagAdd.props.onclick();
  assert.match(savedSettings.prompts['restraint.handcuffed'], /user_custom_tag/);
  assert.equal(savedSettings.prompts['restraint.handcuffed'].split(',').map(tag => tag.trim()).filter(tag => tag === 'handcuffed').length, 1,
    'direct tag addition should remove exact duplicates');
  restraintInput.props.onchange({ currentTarget: { value: 'ui_custom_cuffs' } });
  assert.equal(savedSettings.prompts['restraint.handcuffed'], 'ui_custom_cuffs');
  const restraintLabel = settingsNodes.find(node => node.props?.['data-aip-state-row'] === 'restraint.handcuffed');
  assert.ok(restraintLabel, 'settings should expose the restraint condition');
  const restraintNudeState = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-outfit-state'] === 'restraint.handcuffed:nude');
  assert.equal(restraintNudeState.props.checked, true, 'each condition should expose all outfit-state checkboxes');
  restraintNudeState.props.onchange({ currentTarget: { checked: false } });
  assert.deepEqual([...savedSettings.outfitStates['restraint.handcuffed']], ['clothed', 'partial']);
  savedSettings.prompts['attention.spent'] = 'keep_other_situation';
  const restraintDefaultReset = flattenNodes(restraintLabel).find(node => node?.tag === 'button'
    && node.children.includes('이 항목 전체 기본값으로'));
  assert.ok(restraintDefaultReset, 'each situation row should expose an individual full reset');
  restraintDefaultReset.props.onclick();
  assert.match(savedSettings.prompts['restraint.handcuffed'], /only female restrained/);
  assert.equal(savedSettings.negativePrompts['restraint.handcuffed'], 'handcuffed man, male wrists bound, shared handcuffs');
  assert.deepEqual([...savedSettings.outfitStates['restraint.handcuffed']], ['clothed', 'partial', 'nude']);
  assert.equal(savedSettings.prompts['attention.spent'], 'keep_other_situation',
    'an item reset must not overwrite another situation value');

  settingsNodes = collectNodes();
  const characterTab = settingsNodes.find(node => node.tag === 'button' && node.children.includes('아내 캐릭터'));
  assert.ok(characterTab, 'settings UI should expose a wife character prompt tab');
  characterTab.props.onclick();
  settingsNodes = collectNodes();
  let characterSource = settingsNodes.find(node => node.tag === 'select' && node.props['data-character-prompt-source'] === '');
  let characterPositiveInput = settingsNodes.find(node => node.tag === 'textarea' && node.props['data-character-prompt'] === 'positive');
  assert.ok(characterSource && characterPositiveInput, 'character tab should expose source and directly editable Positive controls');
  assert.equal(characterPositiveInput.props.value, '1girl, brown_hair',
    'the editor should initially show the current wife appearance instead of an empty additive prompt');
  characterSource.props.onchange({ currentTarget: { value: 'mara_citygirl' } });
  assert.deepEqual({ ...savedSettings.characterPrompt }, {
    positivePrompt: '1girl, black_hair, blue_eyes', negativePrompt: 'long hair, tattoo', mode: 'replace',
    imagePolicy: 'reuse', wifeKey: 'elena_farmgirl', sourceId: 'mara_citygirl',
  });
  settingsNodes = collectNodes();
  characterSource = settingsNodes.find(node => node.tag === 'select' && node.props['data-character-prompt-source'] === '');
  characterPositiveInput = settingsNodes.find(node => node.tag === 'textarea' && node.props['data-character-prompt'] === 'positive');
  assert.equal(characterSource.props.value, 'mara_citygirl');
  assert.equal(characterPositiveInput.props.value, '1girl, black_hair, blue_eyes');
  characterPositiveInput.props.onchange({ currentTarget: { value: 'silver_hair, green_eyes' } });
  assert.deepEqual({ ...savedSettings.characterPrompt }, {
    positivePrompt: 'silver_hair, green_eyes', negativePrompt: 'long hair, tattoo', mode: 'replace',
    imagePolicy: 'reuse', wifeKey: 'elena_farmgirl',
  });
  const publishedCurrentWife = vmContext.__WAYWARD_CHARACTER_PROMPT_PROFILES__
    .find(profile => profile.archetypeId === 'elena_farmgirl' && profile.shortname === 'elena');
  assert.match(publishedCurrentWife.positiveTags, /silver_hair/,
    'changing the current wife should update the shared H-Status character profile');
  settingsNodes = collectNodes();
  const characterNegativeInput = settingsNodes.find(node => node.tag === 'textarea' && node.props['data-character-prompt'] === 'negative');
  characterNegativeInput.props.onchange({ currentTarget: { value: 'bad_anatomy' } });
  assert.equal(savedSettings.characterPrompt.negativePrompt, 'bad_anatomy');
  settingsNodes = collectNodes();
  assert.equal(settingsNodes.some(node => node.tag === 'button' && node.children.includes('새 아내로 등록')), false,
    'wife creation should live in the new-game Add wife flow');
  settingsNodes = collectNodes();
  const outfitTab = settingsNodes.find(node => node.tag === 'button' && node.children.includes('의상 프롬프트'));
  assert.ok(outfitTab, 'settings UI should expose registered outfit prompts');
  outfitTab.props.onclick();
  settingsNodes = collectNodes();
  let outfitSource = settingsNodes.find(node => node.tag === 'select' && node.props['data-outfit-prompt-source'] === '');
  assert.ok(outfitSource.children.some(option => option.props?.value === 'maid_dress'),
    'outfits registered by another mod should be editable');
  outfitSource.props.onchange({ currentTarget: { value: 'maid_dress' } });
  settingsNodes = collectNodes();
  const outfitHalfInput = field => collectNodes().find(node => node.tag === 'textarea'
    && node.props['data-aip-custom-outfit-edit-half'] === field);
  assert.equal(outfitHalfInput('topPrompt').props.value, 'maid blouse',
    'built-in and mod outfits should show their original top prompt');
  assert.equal(outfitHalfInput('skirtPrompt').props.value, 'black skirt',
    'built-in and mod outfits should show their original skirt prompt');
  settingsNodes.find(node => node.tag === 'textarea' && node.props['data-outfit-prompt'] === 'negative')
    .props.onchange({ currentTarget: { value: 'different negative' } });
  const negativeOnlyOutfit = hooks.outfitById.after(outfitDefinitions[1], ['maid_dress']);
  assert.equal(negativeOnlyOutfit.halves.top, 'maid blouse', 'editing only Negative must preserve original halves');
  assert.equal(negativeOnlyOutfit.halves.skirt, 'black skirt', 'editing only Negative must preserve original halves');
  let outfitPositiveInput = settingsNodes.find(node => node.tag === 'textarea' && node.props['data-outfit-prompt'] === 'positive');
  assert.equal(outfitPositiveInput.props.value, 'black maid dress, white apron');
  outfitPositiveInput.props.onchange({ currentTarget: { value: 'navy maid dress, silver apron' } });
  settingsNodes = collectNodes();
  const outfitNegativeInput = settingsNodes.find(node => node.tag === 'textarea' && node.props['data-outfit-prompt'] === 'negative');
  assert.equal(outfitNegativeInput.props.value, 'casual clothes, long skirt');
  outfitNegativeInput.props.onchange({ currentTarget: { value: 'red dress, casual clothes' } });
  assert.deepEqual({ ...savedSettings.outfitPrompts.maid_dress }, {
    positivePrompt: 'navy maid dress, silver apron', negativePrompt: 'red dress, casual clothes',
  });
  const replacedOutfit = hooks.outfitById.after(outfitDefinitions[1], ['maid_dress']);
  assert.equal(replacedOutfit.imageTags, 'navy maid dress, silver apron');
  assert.equal(replacedOutfit.negativeImageTags, 'red dress, casual clothes');
  assert.equal(replacedOutfit.halves, undefined,
    'edited outfits should not reintroduce stale original half-prompts during exposure changes');
  assert.equal(outfitDefinitions[1].imageTags, 'black maid dress, white apron',
    'another mod outfit definition must stay untouched');
  outfitHalfInput('topPrompt').props.onchange({ currentTarget: { value: 'navy blouse' } });
  assert.equal(savedSettings.outfitPrompts.maid_dress.topPrompt, 'navy blouse');
  let modifiedHalves = hooks.outfitById.after(outfitDefinitions[1], ['maid_dress']).halves;
  assert.equal(modifiedHalves.top, 'navy blouse', 'partial exposure should use the edited top');
  assert.equal(modifiedHalves.skirt, 'black skirt', 'an unedited half must keep the game value');
  outfitHalfInput('skirtPrompt').props.onchange({ currentTarget: { value: '' } });
  modifiedHalves = hooks.outfitById.after(outfitDefinitions[1], ['maid_dress']).halves;
  assert.equal(modifiedHalves.skirt, '', 'a deliberately empty half must remain empty');
  assert.equal(outfitDefinitions[1].halves.top, 'maid blouse', 'editing must not mutate the original outfit');
  settingsWin.refresh();
  assert.equal(outfitHalfInput('topPrompt').props.value, 'navy blouse', 'edited top must survive refresh');
  assert.equal(outfitHalfInput('skirtPrompt').props.value, '', 'empty skirt must survive refresh');
  collectNodes().find(node => node.tag === 'button' && node.children.includes('이 의상 원본 프롬프트로 복원')).props.onclick();
  assert.equal(savedSettings.outfitPrompts.maid_dress, undefined, 'restore must remove the entire outfit override');
  assert.equal(outfitHalfInput('topPrompt').props.value, 'maid blouse', 'restore must show the original top');
  assert.equal(outfitHalfInput('skirtPrompt').props.value, 'black skirt', 'restore must show the original skirt');
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('기본 상황')).props.onclick();

  settingsNodes = collectNodes();
  const importInput = settingsNodes.find(node => node.tag === 'input' && node.props.type === 'file');
  assert.ok(importInput, 'settings UI should expose JSON import');
  const importTarget = {
    files: [{ name: 'prompts.json', text: async () => JSON.stringify({
      groupSimilarDetailStates: false,
      hStatusImg2Img: false,
      residuePartSources: { mouth: 'pippa', breasts: 'mara', uterus: 'invalid', vulva: 'elena' },
      prompts: { 'restraint.handcuffed': 'imported_cuffs', unknown: 'ignored' },
      negativePrompts: { 'restraint.handcuffed': 'imported_negative' },
      characterPrompt: { positivePrompt: 'imported_character', negativePrompt: 'imported_character_negative', mode: 'append' },
      outfitPrompts: { maid_dress: { positivePrompt: 'imported_maid', negativePrompt: 'imported_maid_negative',
        topPrompt: 'imported_top', skirtPrompt: '' } },
      positionPresetPrompts: { cowgirl: 'custom_cowgirl_prompt, girl on top' },
      positionGroupPrompts: { h: 'imported_hand_slot, handjob' },
      positionStatePrompts: {
        'scene-patron_sex': 'imported_scene_state',
        'task-idle': { positivePrompt: 'imported_idle', negativePrompt: 'imported_idle_negative', onlyState: true },
      },
      positionRules: {
        'scene-patron_sex': 'doggystyle',
        'task-대기 중': 'standing',
        'look-legacy_pose|grp-1|gslot-f': [{
          presetId: 'doggystyle', groupSlots: 'f', details: {
            main: {
              placement: 'positioned behind her', pose: 'lying face down',
              action: 'fingering, female receiving hand stimulation, hand_on_pussy, fingers_in_pussy', target: 'pussy_focus',
            },
            extras: [{ placement: 'positioned between her legs', pose: 'kneeling', action: 'cunnilingus', target: 'pussy_focus' }],
          },
        }],
        unknown: 'missionary',
      },
      positionRuleDefaults: { 'scene-patron_sex': true, unknown: true },
      autoPositionPresets: true,
      outfitStates: { 'restraint.handcuffed': ['partial'], unknown: ['clothed'] },
      customTags: [{ tag: 'imported_custom_tag', label: '가져온 사용자 태그' }],
      promptPresets: [{ id: 'imported-preset', name: '가져온 묶음', prompt: 'soft smile, soft_smile, imported_bundle_tag' }],
      dialogueRules: [{
        id: 'imported-dialogue',
        text: '가져온 대사',
        positivePrompt: 'imported_scene',
        negativePrompt: 'imported_negative_scene',
        duration: 'scene',
        minutes: 10,
        outfitStates: ['partial'],
      }],
      wives: [{
        id: 'imported-json-wife',
        inputs: {
          name: '가져온 아내', customAppearance: 'imported_wife_appearance',
          __attentionImageEnglishName: 'Imported Wife', __attentionImageShortname: 'imported_wife',
          __attentionExtraLinesArchetypeId: 'pippa_waif',
          __attentionImageOutfitColors: { primary: 'blue', secondary1: 'white', secondary2: 'silver' },
        },
        portraitKey: 'wife_preview_imported_wife',
      }],
    }) }],
    value: 'prompts.json',
  };
  await importInput.props.onchange({ currentTarget: importTarget });
  assert.equal(savedSettings.groupSimilarDetailStates, false);
  assert.equal(savedSettings.hStatusImg2Img, false);
  assert.deepEqual({ ...savedSettings.hStatusGenerationModes }, {
    mouth: 'text2img', breasts: 'text2img', uterus: 'text2img', vulva: 'text2img', thighs: 'text2img',
  }, 'legacy JSON should migrate the former uterus toggle without changing the other body-part defaults');
  assert.deepEqual({ ...savedSettings.residuePartSources }, {
    mouth: 'pippa', breasts: 'mara', uterus: 'generate', vulva: 'elena', thighs: 'generate',
  });
  assert.equal(savedSettings.prompts['restraint.handcuffed'], 'imported_cuffs');
  assert.equal(savedSettings.negativePrompts['restraint.handcuffed'], 'imported_negative');
  assert.deepEqual({ ...savedSettings.characterPrompt }, {
    positivePrompt: 'imported_character', negativePrompt: 'imported_character_negative', mode: 'replace', imagePolicy: 'reuse',
  });
  assert.deepEqual({ ...savedSettings.outfitPrompts.maid_dress }, {
    positivePrompt: 'imported_maid', negativePrompt: 'imported_maid_negative', topPrompt: 'imported_top', skirtPrompt: '',
  });
  const importedHalves = hooks.outfitById.after(outfitDefinitions[1], ['maid_dress']).halves;
  assert.equal(importedHalves.top, 'imported_top', 'JSON import should restore the top prompt');
  assert.equal(importedHalves.skirt, '', 'JSON import should restore an empty skirt prompt');
  assert.deepEqual({ ...savedSettings.positionPresetPrompts }, { cowgirl: 'custom_cowgirl_prompt, girl on top' });
  assert.deepEqual({ ...savedSettings.positionGroupPrompts }, { h: 'imported_hand_slot, handjob' });
  assert.deepEqual(JSON.parse(JSON.stringify(savedSettings.positionStatePrompts)), { 'scene-patron_sex': {
    positivePrompt: 'imported_scene_state', negativePrompt: '', onlyState: false,
  }, 'task-idle': {
    positivePrompt: 'imported_idle', negativePrompt: 'imported_idle_negative', onlyState: true,
  } }, 'legacy state prompt strings should import as Positive');
  assert.deepEqual(JSON.parse(JSON.stringify(savedSettings.positionRules)), {
    'scene-patron_sex': [{ presetId: 'doggystyle', groupSlots: '' }],
    'task-대기 중': [{ presetId: 'standing', groupSlots: '' }],
    'look-legacy_pose|grp-1|gslot-f': [{
      presetId: '', groupSlots: 'f', details: {
        female: { pose: '(woman lying face down:1.35), prone, chest down, back up' },
        main: {
          placement: 'behind woman', pose: '',
          action: '(fingering:1.15), man fingering woman, hand on pussy, fingers in pussy, female focus', target: 'pussy focus',
        },
        extras: [{
          placement: "between woman's legs", pose: 'male kneeling',
          action: '(cunnilingus:1.15), man performing cunnilingus on woman, oral focus', target: 'pussy focus',
        }],
      },
    }],
  });
  assert.deepEqual({ ...savedSettings.positionRuleDefaults }, { 'scene-patron_sex': true });
  assert.equal(savedSettings.autoPositionPresets, true);
  delete savedSettings.positionRules['look-legacy_pose|grp-1|gslot-f'];
  assert.deepEqual([...savedSettings.outfitStates['restraint.handcuffed']], ['partial']);
  assert.deepEqual(Array.from(savedSettings.customTags, entry => ({ ...entry })), [{ tag: 'imported_custom_tag', label: '가져온 사용자 태그' }]);
  assert.deepEqual(Array.from(savedSettings.promptPresets, entry => ({ ...entry })), [{
    id: 'imported-preset', name: '가져온 묶음', prompt: 'soft smile, imported_bundle_tag',
  }]);
  assert.equal(savedSettings.dialogueRules[0].text, '가져온 대사');
  const importedWifeInputs = savedWives.find(entry => entry.id === 'imported-json-wife')?.inputs;
  assert.equal(importedWifeInputs.__attentionImageShortname, 'imported_wife');
  assert.equal(importedWifeInputs.__attentionExtraLinesArchetypeId, 'pippa_waif');
  assert.deepEqual({ ...importedWifeInputs.__attentionImageOutfitColors },
    { primary: 'blue', secondary1: 'white', secondary2: 'silver' });
  assert.equal(Object.prototype.hasOwnProperty.call(savedSettings.prompts, 'unknown'), false);
  assert.equal(Object.prototype.hasOwnProperty.call(savedSettings.outfitStates, 'unknown'), false);
  assert.equal(importTarget.value, '');
  const wifeOnlyImportTarget = {
    files: [{ name: 'wives.json', text: async () => JSON.stringify({
      format: 'wayward-state-image-prompts', version: 8,
      wives: [{
        id: 'wife-only-import',
        inputs: {
          name: '아내 전용 가져오기', customAppearance: 'wife_only_appearance',
          __attentionImageEnglishName: 'Wife Only', __attentionImageShortname: 'wife_only',
        },
      }],
    }) }],
    value: 'wives.json',
  };
  await importInput.props.onchange({ currentTarget: wifeOnlyImportTarget });
  assert.equal(savedWives.find(entry => entry.id === 'wife-only-import')?.inputs.__attentionImageShortname, 'wife_only');
  assert.equal(savedSettings.positionGroupPrompts.h, 'imported_hand_slot, handjob',
    'older JSON without placement prompts must retain the current placement prompt settings');
  assert.equal(savedSettings.promptPresets[0].id, 'imported-preset',
    'older JSON without prompt presets must retain the current user library');
  assert.deepEqual({ ...savedSettings.positionRuleDefaults }, { 'scene-patron_sex': true },
    'older JSON without the default-position option must retain the current choice');
  assert.equal(savedSettings.groupSimilarDetailStates, false,
    'older JSON without the grouping option must retain the current choice');
  assert.equal(savedSettings.residuePartSources.breasts, 'mara',
    'older JSON without body-part image sources must retain the current choices');
  assert.equal(savedSettings.hStatusGenerationModes.uterus, 'text2img',
    'older JSON without body-part generation modes must retain the migrated choice');
  const legacyImportedWife = vmContext.WW_CustomWifeBridge.list().find(entry => entry.entryId === 'wife-only-import');
  assert.equal(legacyImportedWife.archetype.attentionExtraLinesArchetypeId, 'elena_farmgirl',
    'older wife JSON without the dialogue field should retain the previous Elena dialogue behavior');
  assert.equal(legacyImportedWife.archetype.imageBase, 'wife_only_appearance',
    'older wife JSON without outfit colors should not gain new color tags');
  assert.equal(savedSettings.prompts['restraint.handcuffed'], 'imported_cuffs',
    'wife-only imports should preserve prompt settings');
  savedSettings.featurePrompts = { pregnancy: true, marks: true, cycle: true, sleep: true, firstExperience: true };
  const featureImportTarget = { files: [{ name: 'features.json', text: async () => JSON.stringify({
    format: 'wayward-state-image-prompts', featurePrompts: { pregnancy: false, marks: true },
  }) }], value: 'features.json' };
  await importInput.props.onchange({ currentTarget: featureImportTarget });
  assert.deepEqual({ ...savedSettings.featurePrompts }, { pregnancy: false, marks: true, cycle: true, sleep: true, firstExperience: true, erostat: true },
    'an older feature export should preserve the new switches');
  savedSettings.featurePrompts = { pregnancy: true, marks: true, cycle: true, sleep: true, firstExperience: true };
  const legacyDefaultsImportTarget = {
    files: [{ name: 'legacy-prompts.json', text: async () => JSON.stringify({
      format: 'wayward-state-image-prompts', version: 14,
      prompts: { 'restraint.handcuffed': legacyHandcuffPrompt },
      negativePrompts: { 'restraint.handcuffed': legacyHandcuffNegativePrompt },
    }) }],
    value: 'legacy-prompts.json',
  };
  await importInput.props.onchange({ currentTarget: legacyDefaultsImportTarget });
  assert.match(savedSettings.prompts['restraint.handcuffed'], /only female restrained/,
    'the former built-in handcuff prompt should migrate when imported');
  assert.match(savedSettings.negativePrompts['restraint.handcuffed'], /handcuffed man/,
    'the former built-in handcuff negative should migrate when imported');
  assert.equal(savedSettings.groupSimilarDetailStates, false,
    'legacy prompt JSON must retain the current grouping choice');
  assert.equal(legacyDefaultsImportTarget.value, '');

  const previousCrestPositive = savedSettings.prompts['hstatus.crest.4'];
  const previousCrestNegative = savedSettings.negativePrompts['hstatus.crest.4'];
  const oldCrestPrompt = '(pubic_tattoo:1.15), (single vivid magenta crest printed flat on the woman\'s exposed lower abdomen:1.35), (directly below her navel and above her pubic bone:1.3)';
  for (const [version, expectedNegative] of [[22, 'male tattoo, hand tattoo, duplicate crest'], [23, '']]) {
    await importInput.props.onchange({ currentTarget: { files: [{ name: `crest-v${version}.json`, text: async () => JSON.stringify({
      format: 'wayward-state-image-prompts', version,
      prompts: { 'hstatus.crest.4': oldCrestPrompt },
      negativePrompts: { 'hstatus.crest.4': '' },
    }) }], value: `crest-v${version}.json` } });
    assert.equal(savedSettings.negativePrompts['hstatus.crest.4'], expectedNegative,
      `crest Negative from v${version} must respect its format's default`);
  }
  savedSettings.prompts['hstatus.crest.4'] = previousCrestPositive;
  savedSettings.negativePrompts['hstatus.crest.4'] = previousCrestNegative;

  settingsNodes = collectNodes();
  detailGroupingToggle = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-detail-state-grouping-toggle'] === '');
  assert.equal(detailGroupingToggle?.props.checked, false);
  detailGroupingToggle.props.onchange({ currentTarget: { checked: true } });
  assert.equal(savedSettings.groupSimilarDetailStates, true);
  settingsNodes = collectNodes();
  const negativeRestraintInput = settingsNodes.find(node => node.tag === 'textarea'
    && node.props?.['data-aip-field-prompt'] === 'restraint.handcuffed:negative');
  assert.ok(negativeRestraintInput, 'Negative should appear below Positive for each condition');
  negativeRestraintInput.props.onchange({ currentTarget: { value: 'no_front_hands' } });
  assert.equal(savedSettings.negativePrompts['restraint.handcuffed'], 'no_front_hands');

  settingsNodes = collectNodes();
  const exportTagInput = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-prompt-tag-input'] === 'restraint.handcuffed');
  const exportTagAdd = settingsNodes.find(node => node.tag === 'button'
    && node.props['data-prompt-tag-add'] === 'restraint.handcuffed');
  exportTagInput.props.oninput({ currentTarget: { value: 'custom_export_tag' } });
  exportTagAdd.props.onclick();
  assert.match(savedSettings.prompts['restraint.handcuffed'], /custom_export_tag/);
  settingsNodes = collectNodes();
  const hStatusTab = settingsNodes.find(node => node.tag === 'button' && node.children.includes('H Status'));
  assert.ok(hStatusTab, 'settings UI should expose area tabs');
  hStatusTab.props.onclick();
  settingsNodes = collectNodes();
  assert.equal(settingsNodes.filter(node => node.tag === 'select'
    && node.props['data-hstatus-generation-mode']).length, 0,
  'generation mode selectors should live in the secret-tab button instead of the global H Status settings');
  secretModeButton.click();
  const hStatusGenerationModeSelects = flattenNodes(openedSettingsWindow.body.children).filter(node => node.tag === 'select'
    && node.props['data-hstatus-generation-mode']);
  assert.equal(hStatusGenerationModeSelects.length, 5,
    'every H-Status body part should expose its own generation mode');
  for (const select of hStatusGenerationModeSelects) {
    assert.deepEqual(select.children.map(option => option.props.value), ['text2img', 'img2img', 'hstatus', 'own']);
  }
  const mouthGenerationMode = hStatusGenerationModeSelects.find(node => node.props['data-hstatus-generation-mode'] === 'mouth');
  const uterusGenerationMode = hStatusGenerationModeSelects.find(node => node.props['data-hstatus-generation-mode'] === 'uterus');
  assert.equal(uterusGenerationMode.props.value, 'text2img', 'the imported legacy off toggle should migrate to prompt generation');
  mouthGenerationMode.props.onchange({ currentTarget: { value: 'img2img' } });
  assert.equal(savedSettings.hStatusGenerationModes.mouth, 'img2img');
  assert.equal(savedSettings.hStatusImg2Img, false, 'changing another body part must preserve the legacy uterus toggle');
  settingsNodes = collectNodes();
  assert.ok(settingsNodes.some(node => node.tag === 'textarea' && String(node.props.value).includes('nipple_piercing')),
    'H Status tab should expose jewelry prompts');
  assert.ok(settingsNodes.some(node => node.tag === 'textarea' && String(node.props.value).includes('egg_vibrator')),
    'H Status tab should expose an editable egg-vibrator prompt');
  assert.ok(settingsNodes.some(node => node.tag === 'textarea' && String(node.props.value).includes('(dildo:1.1)')),
    'H Status tab should expose an editable penis-shaped-vibrator prompt');
  const exposedMouthState = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-outfit-state'] === 'fluid.mouth.1:exposed');
  assert.ok(exposedMouthState, 'H Status prompts should expose the body-part visibility condition');
  const exposedBreastsState = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-outfit-state'] === 'fluid.breasts.1:exposed');
  const exposedThighsState = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-outfit-state'] === 'fluid.thighs.1:exposed');
  const exposedVulvaState = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-outfit-state'] === 'fluid.vulva.1:exposed');
  const exposedToyState = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-outfit-state'] === 'toy.vulva.egg:exposed');
  assert.equal(exposedMouthState.props.checked, false);
  assert.equal(exposedBreastsState.props.checked, true);
  assert.equal(exposedThighsState.props.checked, true);
  assert.equal(exposedVulvaState.props.checked, true,
    'breasts, thighs and vulva H Status prompts should default to exposed-only');
  assert.equal(exposedToyState.props.checked, true,
    'H Status toy prompts should expose and select the vulva-visible condition by default');
  const dialogueTab = settingsNodes.find(node => node.tag === 'button' && node.children.includes('대화 감지'));
  assert.ok(dialogueTab, 'settings UI should expose a dialogue tab');
  dialogueTab.props.onclick();
  settingsNodes = collectNodes();
  let importedDialogueCard = settingsNodes.find(node => node.props?.['data-aip-dialogue-rule'] === 'imported-dialogue');
  assert.equal(importedDialogueCard?.tag, 'details');
  assert.equal(importedDialogueCard.children[0]?.children[0], '가져온 대사');
  importedDialogueCard.props.ontoggle({ currentTarget: { open: true } });
  settingsWin.refresh();
  settingsNodes = collectNodes();
  assert.equal(settingsNodes.find(node => node.props?.['data-aip-dialogue-rule'] === 'imported-dialogue')?.props.open, true);
  const dialogueTextInput = settingsNodes.find(node => node.tag === 'input' && node.props.type === 'text');
  const dialogueTextareas = settingsNodes.filter(node => node.tag === 'textarea'
    && node.props['data-prompt-preset-prompt'] !== '');
  const dialogueDuration = settingsNodes.find(node => node.tag === 'select' && node.props.value === 'scene');
  const dialogueClothedState = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-outfit-state'] === 'imported-dialogue:clothed');
  assert.equal(dialogueTextInput.props.value, '가져온 대사');
  assert.equal(dialogueTextareas.length, 2);
  dialogueTextInput.props.onchange({ currentTarget: { value: '특별한 대사' } });
  importedDialogueCard = collectNodes().find(node => node.props?.['data-aip-dialogue-rule'] === 'imported-dialogue');
  assert.equal(importedDialogueCard.props.open, true, 'editing a dialogue rule should keep it open');
  assert.equal(importedDialogueCard.children[0]?.children[0], '특별한 대사');
  dialogueTextareas[0].props.onchange({ currentTarget: { value: 'dramatic_dialogue_scene' } });
  dialogueTextareas[1].props.onchange({ currentTarget: { value: 'blurry_dialogue' } });
  dialogueDuration.props.onchange({ currentTarget: { value: 'minutes' } });
  dialogueClothedState.props.onchange({ currentTarget: { checked: true } });
  settingsNodes = collectNodes();
  const minuteDurationSelect = settingsNodes.find(node => node.tag === 'select'
    && node.props['data-dialogue-duration'] === 'imported-dialogue');
  const minuteOption = minuteDurationSelect.children.find(node => node.props.value === 'minutes');
  const sceneOption = minuteDurationSelect.children.find(node => node.props.value === 'scene');
  assert.equal(minuteOption.props.selected, true, 'minute duration must be visibly selected');
  assert.equal(sceneOption.props.selected, false);
  const dialogueMinutes = settingsNodes.find(node => node.tag === 'input' && node.props.type === 'number');
  assert.ok(dialogueMinutes, 'minutes duration should expose a minute input');
  dialogueMinutes.props.onchange({ currentTarget: { value: '5' } });
  assert.equal(savedSettings.dialogueRules[0].id, 'imported-dialogue');
  assert.equal(savedSettings.dialogueRules[0].text, '특별한 대사');
  assert.equal(savedSettings.dialogueRules[0].positivePrompt, 'dramatic_dialogue_scene');
  assert.equal(savedSettings.dialogueRules[0].negativePrompt, 'blurry_dialogue');
  assert.equal(savedSettings.dialogueRules[0].duration, 'minutes');
  assert.equal(savedSettings.dialogueRules[0].minutes, 5);
  assert.deepEqual([...savedSettings.dialogueRules[0].outfitStates], ['partial', 'clothed']);
  minuteDurationSelect.props.onchange({ currentTarget: { value: 'scene' } });
  settingsNodes = collectNodes();
  assert.equal(savedSettings.dialogueRules[0].duration, 'scene');
  assert.equal(settingsNodes.some(node => node.tag === 'input' && node.props.type === 'number'), false,
    'scene duration must hide the minute input again');
  settingsNodes = collectNodes();
  const addDialogueRule = settingsNodes.find(node => node.tag === 'button' && node.children.includes('대화 규칙 추가'));
  assert.ok(addDialogueRule, 'dialogue settings should allow adding a rule');
  addDialogueRule.props.onclick();
  assert.equal(savedSettings.dialogueRules.length, 2);
  settingsNodes = collectNodes();
  const newDialogueCard = settingsNodes.find(node => node.props?.['data-aip-dialogue-rule'] === savedSettings.dialogueRules[1].id);
  assert.equal(newDialogueCard?.tag, 'details');
  assert.equal(newDialogueCard.props.open, true, 'a newly added dialogue rule should open for editing');
  assert.equal(newDialogueCard.children[0]?.children[0], '새 대화 규칙 2');
  const deleteDialogueRules = settingsNodes.filter(node => node.tag === 'button'
    && node.children.includes('삭제') && !node.props['data-custom-tag-remove'] && !node.props['data-prompt-preset-remove']);
  deleteDialogueRules.at(-1).props.onclick();
  assert.equal(savedSettings.dialogueRules.length, 1);

  settingsNodes = collectNodes();
  const situationPresetTab = settingsNodes.find(node => node.tag === 'button' && node.children.includes('상황 프리셋'));
  assert.ok(situationPresetTab, 'settings UI should expose situation prompt presets');
  situationPresetTab.props.onclick();
  settingsNodes = collectNodes();
  const presetEditor = settingsNodes.find(node => node.tag === 'select' && node.props['data-situation-preset-editor'] === '');
  assert.equal(presetEditor.props.value, 'default');
  const addSituationPreset = settingsNodes.find(node => node.tag === 'button' && node.children.includes('현재 설정을 복제해 새 프리셋 추가'));
  addSituationPreset.props.onclick();
  const createdSituationPresetId = savedSettings.situationPresets[0].id;
  assert.ok(createdSituationPresetId && createdSituationPresetId !== 'default');
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('현재 설정을 복제해 새 프리셋 추가')).props.onclick();
  assert.equal(savedSettings.situationPresets.length, 2, 'multiple situation presets should be stored independently');
  assert.notEqual(savedSettings.situationPresets[0].id, savedSettings.situationPresets[1].id);
  const secondSituationPresetId = savedSettings.situationPresets[1].id;
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'select' && node.props['data-situation-preset-editor'] === '')
    .props.onchange({ currentTarget: { value: createdSituationPresetId } });
  settingsNodes = collectNodes();
  const presetNameInput = settingsNodes.find(node => node.tag === 'input' && node.props['data-situation-preset-name'] === createdSituationPresetId);
  presetNameInput.props.onchange({ currentTarget: { value: '엘레나 전용 상태' } });
  settingsNodes = collectNodes();
  const elenaPresetSelect = settingsNodes.find(node => node.tag === 'select'
    && node.props['data-situation-preset-character'] === 'elena_farmgirl');
  elenaPresetSelect.props.onchange({ currentTarget: { value: secondSituationPresetId } });
  assert.equal(savedSettings.situationPresetAssignments.elena_farmgirl, secondSituationPresetId);
  elenaPresetSelect.props.onchange({ currentTarget: { value: createdSituationPresetId } });
  assert.equal(savedSettings.situationPresetAssignments.elena_farmgirl, createdSituationPresetId,
    'each character should store exactly one selected preset id');
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('기본 상황')).props.onclick();
  settingsNodes = collectNodes();
  assert.ok(settingsNodes.some(node => node.props?.['data-active-situation-preset'] === createdSituationPresetId));
  savedSettings.prompts['attention.escalation'] = 'legacy_escalation_keep';
  const presetEscalationLabel = settingsNodes.find(node => node.props?.['data-aip-state-row'] === 'attention.escalation');
  flattenNodes(presetEscalationLabel).find(node => node?.props?.['data-aip-field-prompt'] === 'attention.escalation:positive')
    .props.onchange({ currentTarget: { value: 'preset_custom_escalation' } });
  flattenNodes(presetEscalationLabel).find(node => node?.tag === 'button' && node.children.includes('이 항목 전체 기본값으로'))
    .props.onclick();
  assert.equal(savedSettings.situationPresets[0].prompts['attention.escalation'], 'tense expression');
  assert.equal(savedSettings.prompts['attention.escalation'], 'legacy_escalation_keep',
    'resetting a custom preset row must not overwrite the legacy default preset');
  settingsNodes = collectNodes();
  const presetSpentLabel = settingsNodes.find(node => node.props?.['data-aip-state-row'] === 'attention.spent');
  flattenNodes(presetSpentLabel).find(node => node?.props?.['data-aip-field-prompt'] === 'attention.spent:positive')
    .props.onchange({ currentTarget: { value: 'preset_spent_only' } });
  assert.equal(savedSettings.situationPresets[0].prompts['attention.spent'], 'preset_spent_only');
  assert.notEqual(savedSettings.prompts['attention.spent'], 'preset_spent_only',
    'editing a custom preset must not overwrite the legacy default settings');
  const presetApplied = hooks.imagePrompt.after({ key: 'elena__task-idle', prompt: 'portrait', negativePrompt: '', parts: [] }, [wife]);
  assert.match(presetApplied.prompt, /preset_spent_only/);
  savedSettings.situationPresetAssignments = { elena_farmgirl: '' };
  const presetDisabled = hooks.imagePrompt.after({ key: 'elena__task-idle', prompt: 'portrait', negativePrompt: '', parts: [] }, [wife]);
  assert.doesNotMatch(presetDisabled.prompt, /preset_spent_only|exhausted/,
    'the no-preset selection should disable situation prompts for that character');
  savedSettings.situationPresetAssignments = { elena_farmgirl: createdSituationPresetId };

  settingsNodes = collectNodes();
  const exportButton = settingsNodes.find(node => node.tag === 'button' && node.children.includes('JSON 내보내기'));
  assert.ok(exportButton, 'settings UI should expose JSON export');
  exportButton.props.onclick();
  assert.equal(exportClicked, true);
  const exported = JSON.parse(exportedText);
  assert.equal(exported.format, 'wayward-state-image-prompts');
  assert.equal(exported.version, 23);
  assert.equal(exported.hStatusImg2Img, false);
  assert.deepEqual(exported.hStatusGenerationModes, {
    mouth: 'img2img', breasts: 'text2img', uterus: 'text2img', vulva: 'text2img', thighs: 'text2img',
  });
  assert.equal(exported.groupSimilarDetailStates, true);
  const exportedCustomWife = exported.wives.find(entry => entry.id === 'custom-picker-wife');
  assert.equal(exportedCustomWife.inputs.__attentionImageShortname, 'pippa_nova');
  assert.equal(exportedCustomWife.inputs.__attentionExtraLinesArchetypeId, 'mara_citygirl');
  assert.deepEqual(exportedCustomWife.inputs.__attentionImageOutfitColors,
    { primary: 'red', secondary1: 'black', secondary2: 'gold' });
  assert.deepEqual(exported.characterPrompt, {
    positivePrompt: 'imported_character', negativePrompt: 'imported_character_negative', mode: 'replace', imagePolicy: 'reuse',
  });
  assert.deepEqual(exported.outfitPrompts.maid_dress, {
    positivePrompt: 'imported_maid', negativePrompt: 'imported_maid_negative', topPrompt: 'imported_top', skirtPrompt: '',
  });
  assert.equal(exported.situationPresets[0].name, '엘레나 전용 상태');
  assert.equal(exported.situationPresets[0].prompts['attention.spent'], 'preset_spent_only');
  assert.equal(exported.situationPresetAssignments.elena_farmgirl, createdSituationPresetId);
  assert.deepEqual(exported.positionPresetPrompts, { cowgirl: 'custom_cowgirl_prompt, girl on top' });
  assert.deepEqual(exported.positionGroupPrompts, { h: 'imported_hand_slot, handjob' });
  assert.deepEqual(exported.positionStatePrompts, { 'scene-patron_sex': {
    positivePrompt: 'imported_scene_state', negativePrompt: '', onlyState: false,
  }, 'task-idle': {
    positivePrompt: 'imported_idle', negativePrompt: 'imported_idle_negative', onlyState: true,
  } });
  assert.deepEqual(exported.positionRules, {
    'scene-patron_sex': [{ presetId: 'doggystyle', groupSlots: '' }],
    'task-대기 중': [{ presetId: 'standing', groupSlots: '' }],
  });
  assert.deepEqual(exported.positionRuleDefaults, { 'scene-patron_sex': true });
  assert.equal(exported.autoPositionPresets, true);
  assert.match(exported.prompts['restraint.handcuffed'], /custom_export_tag/);
  assert.equal(exported.negativePrompts['restraint.handcuffed'], 'no_front_hands');
  assert.deepEqual(exported.outfitStates['restraint.handcuffed'], ['partial']);
  assert.deepEqual(exported.residuePartSources, {
    mouth: 'pippa', breasts: 'mara', uterus: 'generate', vulva: 'elena', thighs: 'generate',
  });
  assert.deepEqual(exported.customTags, [{ tag: 'imported_custom_tag', label: '가져온 사용자 태그' }]);
  assert.deepEqual(exported.promptPresets, [{
    id: 'imported-preset', name: '가져온 묶음', prompt: 'soft smile, imported_bundle_tag',
  }]);
  assert.equal(exported.dialogueRules[0].positivePrompt, 'dramatic_dialogue_scene');
  settingsNodes = collectNodes();
  const presetOnlyButton = settingsNodes.find(node => node.tag === 'button' && node.children.includes('상황 프리셋만 내보내기'));
  assert.ok(presetOnlyButton);
  presetOnlyButton.props.onclick();
  const presetOnlyText = exportedText;
  const presetOnlyExport = JSON.parse(presetOnlyText);
  assert.deepEqual(Object.keys(presetOnlyExport).sort(), ['format', 'situationPresetAssignments', 'situationPresets', 'version']);
  assert.equal(exportFilename, 'wayward-situation-prompt-presets.json');
  savedSettings.situationPresets = [];
  savedSettings.situationPresetAssignments = {};
  await importInput.props.onchange({ currentTarget: {
    files: [{ name: 'situation-presets.json', text: async () => presetOnlyText }], value: 'situation-presets.json',
  } });
  assert.equal(savedSettings.situationPresets[0].name, '엘레나 전용 상태');
  assert.equal(savedSettings.situationPresetAssignments.elena_farmgirl, createdSituationPresetId);
  settingsNodes = collectNodes();
  const wifeOnlyButton = settingsNodes.find(node => node.tag === 'button' && node.children.includes('아내만 내보내기'));
  assert.ok(wifeOnlyButton, 'settings UI should expose a one-click wife-only export');
  wifeOnlyButton.props.onclick();
  const directWifeOnlyExport = JSON.parse(exportedText);
  assert.deepEqual(Object.keys(directWifeOnlyExport).sort(), ['format', 'version', 'wives']);
  assert.equal(exportFilename, 'wayward-custom-wives.json');
  settingsNodes = collectNodes();
  for (const key of ['negativePrompts', 'dialogueRules']) {
    const checkbox = settingsNodes.find(node => node.tag === 'input' && node.props['data-export-section'] === key);
    checkbox.props.onchange({ currentTarget: { checked: false } });
  }
  exportButton.props.onclick();
  const selectedExport = JSON.parse(exportedText);
  assert.deepEqual(selectedExport.featurePrompts, { pregnancy: true, marks: true, cycle: true, sleep: true, firstExperience: true, erostat: true },
    'the full settings export should include feature switches');
  assert.equal(selectedExport.shortImageKeys, false, 'the filename switch must survive export');
  assert.equal(selectedExport.generationWeightEnabled, false, 'generation weights default to off');
  assert.equal(selectedExport.generationWeightPercent, 100, 'generation weight is exported');
  assert.deepEqual([selectedExport.generationWeightStepsPercent, selectedExport.generationWeightCfgPercent,
    selectedExport.generationWeightLoraPercent], [100, 100, 100], 'independent weights are exported');
  savedSettings.shortImageKeys = true;
  savedSettings.generationWeightEnabled = true;
  savedSettings.generationWeightPercent = 50;
  await importInput.props.onchange({ currentTarget: {
    files: [{ name: 'image-keys.json', text: async () => JSON.stringify({
      format: 'wayward-state-image-prompts', version: 22, shortImageKeys: false,
    }) }], value: 'image-keys.json',
  } });
  assert.equal(savedSettings.shortImageKeys, false, 'a filename-only settings file must restore the switch');
  assert.equal(savedSettings.generationWeightEnabled, true, 'unrelated imports must preserve generation weight');
  assert.equal(savedSettings.generationWeightPercent, 50, 'unrelated imports must preserve the weight value');
  await importInput.props.onchange({ currentTarget: {
    files: [{ name: 'generation-weight.json', text: async () => JSON.stringify({
      format: 'wayward-state-image-prompts', version: 23, generationWeightEnabled: true, generationWeightPercent: 125,
    }) }], value: 'generation-weight.json',
  } });
  assert.equal(savedSettings.generationWeightEnabled, true, 'generation weight must be imported');
  assert.equal(savedSettings.generationWeightPercent, 125, 'generation weight percentage must be imported');
  assert.deepEqual([savedSettings.generationWeightStepsPercent, savedSettings.generationWeightCfgPercent,
    savedSettings.generationWeightLoraPercent], [125, 125, 125], 'legacy weight import replaces all independent weights');
  await importInput.props.onchange({ currentTarget: {
    files: [{ name: 'generation-weight-separate.json', text: async () => JSON.stringify({
      format: 'wayward-state-image-prompts', version: 23, generationWeightStepsPercent: 0,
      generationWeightCfgPercent: 50, generationWeightLoraPercent: 200,
    }) }], value: 'generation-weight-separate.json',
  } });
  assert.deepEqual([savedSettings.generationWeightStepsPercent, savedSettings.generationWeightCfgPercent,
    savedSettings.generationWeightLoraPercent], [0, 50, 200], 'independent weights import without legacy field');
  const choiceContext = { scene: 'task-idle', eventType: 'test-event', eventKind: '', choiceId: 'test-choice', mode: 'shown' };
  const importedChoice = { ...choiceContext, label: '시험 선택지', positivePrompt: 'talking', negativePrompt: 'text' };
  await importInput.props.onchange({ currentTarget: {
    files: [{ name: 'choices.json', text: async () => JSON.stringify({ buttonPromptRules: [importedChoice] }) }], value: 'choices.json',
  } });
  const choiceApi = vmContext.AttentionImagePrompt.choicePrompts;
  assert.equal(typeof vmContext.AttentionImagePrompt.promptTagSearch.search, 'function', 'prompt tag search is publicly available');
  assert.equal(typeof vmContext.AttentionImagePrompt.scenePrompts.get, 'function', 'scene prompt snapshot is publicly available');
  assert.equal(typeof vmContext.AttentionImagePrompt.scenePrompts.cacheToken, 'function', 'scene prompt cache token is publicly available');
  assert.equal(choiceApi.get(choiceContext), null, 'legacy shown prompt is no longer applied');
  assert.equal(choiceApi.cacheToken(choiceContext), '', 'legacy shown prompt has no active cache token');
  assert.equal(savedSettings.buttonPromptRules[0].positivePrompt, 'talking', 'old shown text survives JSON import');
  assert.equal(choiceApi.get({ ...choiceContext, mode: 'after' }), null);
  await importInput.props.onchange({ currentTarget: {
    files: [{ name: 'clear-choices.json', text: async () => JSON.stringify({ buttonPromptRules: [] }) }], value: 'clear-choices.json',
  } });
  assert.equal(choiceApi.get(choiceContext), null, 'choice API cache updates after importing a reset');
  for (const [section, fixture] of [
    ['sceneBaseOverrides', { 'task-idle': { positivePrompt: 'base override fixture' } }],
    ['cameraSceneSettings', { 'task-idle': { shots: [{ id: 'front', name: '정면', positive: 'front view', negative: '' }], selected: ['front'], removeTags: 'old view' } }],
    ['cameraImageMetadata', { 'elena__task-idle__v-0': { id: 'front', name: '정면', positive: 'front view', negative: '' } }],
    ['sceneStatePromptOverrides', { 'task-idle': { 'restraint.handcuffed': { positivePrompt: 'state override fixture' } } }],
    ['stateEditorGlobalChanges', { default: ['restraint.handcuffed'] }],
  ]) {
    const original = JSON.parse(JSON.stringify(savedSettings[section] || {}));
    const importSection = async value => {
      const text = JSON.stringify({ [section]: value });
      await importInput.props.onchange({ currentTarget: {
        files: [{ name: `${section}.json`, text: async () => text }], value: `${section}.json`,
      } });
    };
    await importSection(fixture);
    exportButton.props.onclick();
    assert.deepEqual(JSON.parse(exportedText)[section], fixture, `${section}: standalone import refreshes the export cache`);
    await importSection({});
    exportButton.props.onclick();
    assert.deepEqual(JSON.parse(exportedText)[section] || {}, {}, `${section}: importing an empty object clears the export cache`);
    await importSection(original);
  }
  const importMarkerFixture = async data => {
    const text = JSON.stringify(data);
    await importInput.props.onchange({ currentTarget: {
      files: [{ name: 'marker-fixture.json', text: async () => text }], value: 'marker-fixture.json',
    } });
  };
  const originalCameraForMigration = JSON.parse(JSON.stringify(savedSettings.cameraSceneSettings || {}));
  const originalMetadataForMigration = JSON.parse(JSON.stringify(savedSettings.cameraImageMetadata || {}));
  const originalCameraRevision = savedSettings.cameraPresetRevision;
  const oldCameraText = '(frontal camera view:1.3)';
  const oldCameraScenes = { 'task-idle': { shots: [
    { id: 'front', name: '이름 유지', positive: oldCameraText, negative: 'saved negative' },
    { id: 'side', name: '수정 구도', positive: '(side camera view:1.2)', negative: '' },
  ], selected: ['front'], removeTags: '' } };
  const oldCameraMetadata = { 'elena__task-idle__v-4': { id: 'front', name: '기존', positive: oldCameraText, negative: '' } };
  await importMarkerFixture({ cameraSceneSettings: oldCameraScenes, cameraImageMetadata: oldCameraMetadata });
  assert.equal(savedSettings.cameraPresetRevision, 2, 'old camera JSON is migrated and revision recorded');
  assert.equal(savedSettings.cameraSceneSettings['task-idle'].shots[0].positive, '(front view:1.3), (straight-on:1.3)');
  assert.equal(savedSettings.cameraSceneSettings['task-idle'].shots[0].name, '이름 유지');
  assert.equal(savedSettings.cameraSceneSettings['task-idle'].shots[0].negative, 'saved negative');
  assert.equal(savedSettings.cameraSceneSettings['task-idle'].shots[1].positive, '(side camera view:1.2)');
  assert.deepEqual(JSON.parse(JSON.stringify(savedSettings.cameraImageMetadata)), oldCameraMetadata, 'legacy metadata is unchanged');
  exportButton.props.onclick();
  assert.equal(JSON.parse(exportedText).cameraPresetRevision, 2, 'camera export includes the migration revision');
  const priorCameraScenes = { 'task-idle': { shots: [
    { id: 'side', name: '이름 유지', positive: '(from_side:1.3)', negative: 'saved negative' },
    { id: 'front', name: '수정 구도', positive: '(straight-on:1.2)', negative: '' },
  ], selected: ['side'], removeTags: '' } };
  await importMarkerFixture({ cameraSceneSettings: priorCameraScenes, cameraPresetRevision: 1 });
  assert.equal(savedSettings.cameraPresetRevision, 2, 'revision 1 is updated on import');
  assert.equal(savedSettings.cameraSceneSettings['task-idle'].shots[0].positive, '(side view:1.3), (from_side:1.3)');
  assert.equal(savedSettings.cameraSceneSettings['task-idle'].shots[1].positive, '(straight-on:1.2)', 'edited values are preserved');
  assert.equal(savedSettings.cameraSceneSettings['task-idle'].shots[0].negative, 'saved negative');
  await importMarkerFixture({ cameraSceneSettings: oldCameraScenes, cameraPresetRevision: 2 });
  assert.equal(savedSettings.cameraSceneSettings['task-idle'].shots[0].positive, oldCameraText,
    'a revision-marked file keeps intentionally saved old camera text');
  await importMarkerFixture({ prompts: { 'restraint.handcuffed': 'partial-only fixture' } });
  assert.equal(savedSettings.cameraPresetRevision, 2, 'imports without camera settings preserve the revision');
  assert.equal(savedSettings.cameraSceneSettings['task-idle'].shots[0].positive, oldCameraText,
    'imports without camera settings preserve existing camera prompts');
  await importMarkerFixture({ cameraSceneSettings: originalCameraForMigration, cameraImageMetadata: originalMetadataForMigration,
    cameraPresetRevision: Number.isSafeInteger(originalCameraRevision) ? originalCameraRevision : 0 });
  const modernSections = {
    sceneBaseOverrides: { 'task-idle': { positivePrompt: 'saved positive', nativePart: { label: '작업', text: 'verified native' } } },
    cameraSceneSettings: { 'task-idle': { shots: [{ id: 'front', name: '정면', positive: 'front view', negative: '' }], selected: ['front'], removeTags: 'old view' } },
    cameraImageMetadata: { 'elena__task-idle__v-0': { id: 'front', name: '정면', positive: 'front view', negative: '' } },
    sceneStatePromptOverrides: { 'task-idle': { 'restraint.handcuffed': { positivePrompt: 'saved state' } } },
    stateEditorGlobalChanges: { default: ['restraint.handcuffed'] },
  };
  const oldModernSections = Object.fromEntries(Object.keys(modernSections).map(key => [key,
    JSON.parse(JSON.stringify(savedSettings[key] || {}))]));
  await importMarkerFixture(modernSections);
  await importMarkerFixture({ format: 'attention-image-prompt', version: '1.53.0',
    prompts: { 'restraint.handcuffed': 'legacy prompt' }, negativePrompts: { 'restraint.handcuffed': 'legacy negative' } });
  for (const [key, value] of Object.entries(modernSections))
    assert.deepEqual(JSON.parse(JSON.stringify(savedSettings[key])), value, `old JSON without ${key} preserves existing settings`);
  exportButton.props.onclick();
  const oldImportExport = JSON.parse(exportedText);
  for (const [key, value] of Object.entries(modernSections))
    assert.deepEqual(oldImportExport[key], value, `old JSON preserves ${key} in the next export`);
  await importMarkerFixture(oldModernSections);
  await importMarkerFixture({ stateEditorGlobalChanges: {
    default: ['restraint.handcuffed'], 'preset-a': ['restraint.handcuffed'], 'preset-b': ['restraint.handcuffed'],
  } });
  await importMarkerFixture({ prompts: {}, stateEditorGlobalChanges: { default: ['attention.spent'] } });
  assert.deepEqual(JSON.parse(JSON.stringify(savedSettings.stateEditorGlobalChanges)), {
    default: ['attention.spent', 'restraint.handcuffed'], 'preset-a': ['restraint.handcuffed'], 'preset-b': ['restraint.handcuffed'],
  }, 'partial default prompt import merges default markers and preserves other presets');
  await importMarkerFixture({ situationPresets: [{ id: 'preset-a', name: 'Preset A' }],
    stateEditorGlobalChanges: { 'preset-a': ['attention.spent'] } });
  assert.deepEqual(JSON.parse(JSON.stringify(savedSettings.stateEditorGlobalChanges)), {
    default: ['attention.spent', 'restraint.handcuffed'], 'preset-a': ['attention.spent'], 'preset-b': ['restraint.handcuffed'],
  }, 'partial preset import preserves default and other preset markers');
  await importMarkerFixture({ stateEditorGlobalChanges: {} });
  assert.deepEqual(JSON.parse(JSON.stringify(savedSettings.stateEditorGlobalChanges)), {},
    'standalone empty marker import replaces all markers');
  assert.match(selectedExport.prompts['restraint.handcuffed'], /custom_export_tag/);
  assert.equal(Object.prototype.hasOwnProperty.call(selectedExport, 'negativePrompts'), false);
  assert.equal(Object.prototype.hasOwnProperty.call(selectedExport, 'dialogueRules'), false);
  settingsNodes = collectNodes();
  for (const key of ['gameDefaultPrompts', 'characterPrompt', 'outfitPrompts', 'customOutfits', 'situationPresets', 'positionPresetPrompts', 'positionGroupPrompts', 'positionStatePrompts', 'sceneBaseOverrides', 'cameraSettings', 'sceneStatePromptOverrides', 'buttonPromptRules', 'positionRules', 'positionModules', 'promptModRules', 'externalPrompts', 'featurePrompts', 'shortImageKeys', 'generationWeight', 'prompts', 'outfitStates', 'fluidDecay', 'residueGenerationProvider', 'hStatusGenerationModes', 'residuePrompts', 'residuePartSources', 'customTags', 'promptPresets', 'erostatPromptPresets', 'erostatPromptBundles']) {
    const checkbox = settingsNodes.find(node => node.tag === 'input' && node.props['data-export-section'] === key);
    checkbox.props.onchange({ currentTarget: { checked: false } });
  }
  exportButton.props.onclick();
  const wifeOnlyExport = JSON.parse(exportedText);
  assert.deepEqual(Object.keys(wifeOnlyExport).sort(), ['format', 'version', 'wives']);
  assert.equal(exportFilename, 'wayward-custom-wives.json');
  assert.ok(wifeOnlyExport.wives.some(entry => entry.id === 'imported-json-wife'));
  savedSettings = {};

  const base = { key: 'elena__task-idle', prompt: 'portrait', negativePrompt: 'base_negative, tattoo, piercing', parts: [] };
  const sceneKey = 'pippa__scene-patron_sex__outfit-modest__room-taproom__mood-shy__exp-0001010__grp-1__gslot-m__v-0';
  rows = [];
  const characterBase = {
    key: sceneKey,
    prompt: 'best quality, 1girl, brown_hair',
    negativePrompt: 'base_negative, tattoo, piercing',
    parts: [{ label: '품질', tags: 'best quality' }, { label: '기본', tags: '1girl, brown_hair' }],
  };
  settingsWin.refresh();
  collectNodes().find(node => node.tag === 'button' && node.children.includes('게임 기본 설정')).props.onclick();
  let gameDefaultEditor = collectNodes().find(node => node.props?.['data-game-default-prompt'] === 'positive');
  assert.equal(gameDefaultEditor.props.value, 'best quality');
  let livePreview = [];
  const previewContainer = { replaceChildren: (...children) => { livePreview = children; } };
  gameDefaultEditor.props.oninput({ currentTarget: { value: 'smile, blue eyes', parentElement: {
    querySelector: selector => selector === '[data-prompt-tag-preview]' ? previewContainer : null,
  } } });
  assert.deepEqual(flattenNodes(livePreview).filter(node => node?.props?.['data-prompt-tag']).map(node => node.props['data-prompt-tag']),
    ['smile', 'blue eyes'], 'typing updates translated prompt chips without refreshing the whole settings view');
  gameDefaultEditor.props.oninput({ currentTarget: { value: '', parentElement: {
    querySelector: selector => selector === '[data-prompt-tag-preview]' ? previewContainer : null,
  } } });
  assert.equal(livePreview.length, 0, 'clearing the prompt clears the translated chips');
  gameDefaultEditor.props.oninput({ currentTarget: { value: 'best quality' } });
  gameDefaultEditor.props.onfocus();
  await collectNodes().find(node => node.props?.['data-library-tag'] === 'heart_choker').props.onclick();
  assert.match(savedSettings.gameDefaultPrompts.positivePrompt, /heart_choker/,
    'the tag library must insert into the focused game default editor');
  gameDefaultEditor.props.onchange({ currentTarget: { value: 'edited_global_quality' } });
  gameDefaultEditor = collectNodes().find(node => node.props?.['data-game-default-prompt'] === 'negative');
  assert.equal(gameDefaultEditor.props.value, 'base_negative');
  gameDefaultEditor.props.onchange({ currentTarget: { value: 'edited_global_negative' } });
  assert.deepEqual({ ...savedSettings.gameDefaultPrompts }, {
    positivePrompt: 'edited_global_quality', negativePrompt: 'edited_global_negative',
  });
  collectNodes().find(node => node.props?.['data-export-section'] === 'gameDefaultPrompts')
    .props.onchange({ currentTarget: { checked: true } });
  collectNodes().find(node => node.tag === 'button' && node.children.includes('JSON 내보내기')).props.onclick();
  const exportedGameDefaults = JSON.parse(exportedText).gameDefaultPrompts;
  assert.deepEqual(exportedGameDefaults, { ...savedSettings.gameDefaultPrompts },
    'game defaults must be included in JSON export');
  savedSettings.gameDefaultPrompts = {};
  await importInput.props.onchange({ currentTarget: {
    files: [{ name: 'game-defaults.json', text: async () => JSON.stringify({
      format: 'wayward-state-image-prompts', version: 21, gameDefaultPrompts: exportedGameDefaults,
    }) }], value: 'game-defaults.json',
  } });
  assert.deepEqual({ ...savedSettings.gameDefaultPrompts }, exportedGameDefaults,
    'game defaults must survive JSON import');
  collectNodes().find(node => node.props?.['data-export-section'] === 'gameDefaultPrompts')
    .props.onchange({ currentTarget: { checked: false } });
  const editedGameDefaults = hooks.imagePrompt.after({ ...characterBase,
    negativePrompt: 'base_negative, tattoo, piercing, scene_negative' }, [wife]);
  assert.match(editedGameDefaults.prompt, /edited_global_quality/);
  assert.doesNotMatch(editedGameDefaults.prompt, /best quality/);
  assert.match(editedGameDefaults.prompt, /brown_hair/, 'editing game defaults must preserve wife appearance');
  assert.match(editedGameDefaults.negativePrompt, /edited_global_negative/);
  assert.doesNotMatch(editedGameDefaults.negativePrompt, /base_negative/);
  assert.match(editedGameDefaults.negativePrompt, /tattoo|piercing/,
    'editing game defaults must preserve wife-specific Negative');
  assert.match(editedGameDefaults.negativePrompt, /scene_negative/,
    'editing game defaults must preserve scene Negative');
  const repeatedSceneNegative = hooks.imagePrompt.after({ ...characterBase,
    negativePrompt: 'base_negative, tattoo, piercing, base_negative, scene_negative' }, [wife]);
  assert.match(repeatedSceneNegative.negativePrompt, /base_negative/,
    'a scene tag matching a game default must remain when only the default occurrence is replaced');
  const priorCharacterSetting = savedSettings.characterPrompt;
  savedSettings.characterPrompt = { positivePrompt: '', negativePrompt: 'wife_custom_negative', mode: 'replace', imagePolicy: 'reuse' };
  savedSettings.gameDefaultPrompts.negativePrompt = 'tattoo, edited_global_negative';
  const sharedNativeTag = hooks.imagePrompt.after(characterBase, [wife]);
  assert.match(sharedNativeTag.negativePrompt, /tattoo/,
    'replacing the wife Negative must preserve the same tag when explicitly set in game defaults');
  assert.match(sharedNativeTag.negativePrompt, /wife_custom_negative/);
  assert.doesNotMatch(sharedNativeTag.negativePrompt, /piercing/);
  savedSettings.characterPrompt = priorCharacterSetting;
  savedSettings.gameDefaultPrompts.negativePrompt = 'edited_global_negative';
  collectNodes().find(node => node.props?.['data-game-default-prompt'] === 'negative')
    .props.onchange({ currentTarget: { value: '' } });
  const emptyGameNegative = hooks.imagePrompt.after({ ...characterBase,
    negativePrompt: 'base_negative, tattoo, piercing, scene_negative' }, [wife]);
  assert.doesNotMatch(emptyGameNegative.negativePrompt, /base_negative/);
  assert.match(emptyGameNegative.negativePrompt, /tattoo|piercing|scene_negative/,
    'empty game Negative must preserve wife and scene negatives');
  collectNodes().find(node => node.tag === 'button' && node.children.includes('Negative 게임 원본으로 복원')).props.onclick();
  assert.equal(Object.prototype.hasOwnProperty.call(savedSettings.gameDefaultPrompts, 'negativePrompt'), false);
  collectNodes().find(node => node.tag === 'button' && node.children.includes('Positive 게임 원본으로 복원')).props.onclick();
  assert.deepEqual({ ...savedSettings.gameDefaultPrompts }, {});
  delete savedSettings.gameDefaultPrompts;
  const patronChatKey = sceneKey.replace('patron_sex', 'patron_chatting');
  const nativeSmile = {
    ...base,
    key: patronChatKey,
    prompt: 'portrait, smile, interested, gentle smile, content',
    parts: [{ label: '장면', tags: 'smile, interested' }, { label: '기분', tags: 'gentle smile, content' }],
  };
  const originalMood = wife.stats.mood;
  wife.stats.mood = 68;
  wife.feelings = [{ emotion: 'shame', intensity: 88 }];
  const distressedKey = hooks.imageKey.after(patronChatKey, [wife]);
  const distressedPrompt = hooks.imagePrompt.after(nativeSmile, [wife]);
  assert.equal(distressedPrompt.key, distressedKey, 'the corrected expression and lookup must use the same cache key');
  assert.doesNotMatch(distressedPrompt.prompt, /\b(?:smile|content)\b/,
    'strong shame should suppress automatic cheerful scene and mood tags');
  assert.match(distressedPrompt.prompt, /\binterested\b/);
  assert.equal(distressedPrompt.parts.some(part => /\b(?:smile|content)\b/.test(part.tags)), false,
    'inspectable prompt parts must match the generated prompt');
  const customSmile = hooks.imagePrompt.after({
    ...nativeSmile,
    parts: [...nativeSmile.parts, { label: '사용자 프롬프트', tags: 'gentle smile' }],
  }, [wife]);
  assert.match(customSmile.prompt, /gentle smile/, 'an explicitly added smile must remain available');
  wife.feelings = [{ emotion: 'shame', intensity: 60 }];
  assert.match(hooks.imagePrompt.after(nativeSmile, [wife]).prompt, /gentle smile/,
    'less intense shame should keep the native scene expression');
  assert.notEqual(hooks.imageKey.after(patronChatKey, [wife]), distressedKey,
    'the corrected image must not reuse the old smiling cache entry');
  wife.feelings = [];
  relationshipLatitude = -69;
  const closedOffPrompt = hooks.imagePrompt.after(nativeSmile, [wife]);
  assert.match(closedOffPrompt.key, /state-expression-v2/);
  assert.doesNotMatch(closedOffPrompt.prompt, /\b(?:smile|content)\b/,
    'a closed-off relationship must suppress cheerful native scene tags');
  relationshipLatitude = 0;
  wife.stats.mood = originalMood;
  rows = [{ kind: 'spent', characterId: 'wife', urgency: 50 }];
  const tiredTaskKey = 'pippa__task-taking_order__outfit-modest__room-taproom__v-0';
  const tiredTask = {
    ...base,
    key: tiredTaskKey,
    prompt: 'portrait, smile, gentle smile, content',
    parts: [{ label: '작업', tags: 'smile' }, { label: '기분', tags: 'gentle smile, content' }],
  };
  const tiredTaskPrompt = hooks.imagePrompt.after(tiredTask, [wife]);
  assert.equal(tiredTaskPrompt.key, hooks.imageKey.after(tiredTaskKey, [wife]));
  assert.match(tiredTaskPrompt.key, /state-expression-v2/,
    'a corrected tired expression must not reuse a previously generated smiling image');
  assert.doesNotMatch(tiredTaskPrompt.prompt, /\b(?:smile|content)\b/,
    'an exhausted task should not keep a cheerful native expression');
  assert.match(tiredTaskPrompt.prompt, /exhausted/);
  rows = [];
  const plannerEnergyBefore = wife.stats.energy;
  const plannerFeelingsBefore = wife.feelings;
  wife.stats.energy = 0;
  wife.feelings = [{ emotion: 'shame', intensity: 94 }];
  savedSettings = { autoPositionPresets: true };
  const plannerKey = sceneKey.replace('scene-patron_sex', 'scene-patron_blowjob');
  const plannerCharacter = { ...wife, stats: { ...wife.stats, energy: 75 }, feelings: [] };
  assert.equal(typeof hooks.imagePlanEntry?.around, 'function');
  assert.equal(hooks.imagePlanEntry.around(() => hooks.imageKey.after(plannerKey, [plannerCharacter])), plannerKey,
    'pre-generation must keep its native key even while automatic positions are enabled');
  const plannedPrompt = hooks.imagePlanEntry.around(() =>
    hooks.imagePrompt.after({ ...characterBase, key: plannerKey }, [plannerCharacter]));
  assert.equal(plannedPrompt.key, plannerKey,
    'the pre-generated prompt must use the same key as its queue entry');
  assert.doesNotMatch(plannedPrompt.prompt, /rough fellatio|deepthroat|exhausted|tears/,
    'generic pre-generation must not inherit the active wife\'s distress or position');
  assert.throws(() => hooks.imagePlanEntry.around(() => { throw new Error('planner failed'); }), /planner failed/);
  assert.match(hooks.imageKey.after(plannerKey, [wife]), /__position-/,
    'a failed planner call must not disable positions for later gameplay portraits');
  wife.stats.energy = plannerEnergyBefore;
  wife.feelings = plannerFeelingsBefore;
  savedSettings = {};
  const unchangedOutfitSituationKey = hooks.imageKey.after(sceneKey, [wife]);
  savedSettings = {
    outfitPrompts: { modest: { positivePrompt: 'blue fitted work dress', negativePrompt: 'red dress' } },
  };
  const outfitChangedKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.equal(outfitChangedKey, unchangedOutfitSituationKey,
    'editing an outfit prompt must keep the same situation image list');
  assert.equal((await hooks.imageLookup.around(async () => ({ talentName: sceneKey, imagePath: 'old.webp' }), outfitChangedKey))?.talentName, sceneKey,
    'an edited outfit prompt should keep the picture in the same situation list');
  const changedOutfitDefinition = hooks.outfitById.after(outfitDefinitions[0], ['modest']);
  const outfitPromptResult = hooks.imagePrompt.after({
    ...characterBase,
    prompt: `${characterBase.prompt}, ${changedOutfitDefinition.imageTags}`,
    negativePrompt: `base_negative, ${changedOutfitDefinition.negativeImageTags}`,
    parts: [...characterBase.parts, { label: '의상', tags: changedOutfitDefinition.imageTags }],
  }, [wife]);
  assert.match(outfitPromptResult.prompt, /blue fitted work dress/);
  assert.match(outfitPromptResult.negativePrompt, /red dress/);
  assert.equal(outfitPromptResult.parts.filter(part => part.label === '의상').length, 1,
    'the cache signature group must not duplicate the outfit part in the Positive prompt');
  savedSettings = {};
  const missingBuiltInNegative = hooks.imagePrompt.after({ ...characterBase, negativePrompt: 'base_negative' }, [wife]);
  assert.match(missingBuiltInNegative.negativePrompt, /tattoo/);
  assert.match(missingBuiltInNegative.negativePrompt, /piercing/,
    'built-in character imageNegative tags should be present in in-game prompts');
  wife.generatedArchetype = { attentionImagePrompt: {
    positivePrompt: 'custom_face',
    negativePrompt: 'default_negative, nude, naked, breasts_out, nipples, lingerie, heavy armor, cloak hiding body, cropped, close-up',
    mode: 'replace', imagePolicy: 'reuse',
  } };
  const customCharacterBase = { ...characterBase, negativePrompt: 'base_negative' };
  const migratedLegacyCharacter = hooks.imagePrompt.after(customCharacterBase, [wife]);
  assert.equal(migratedLegacyCharacter.negativePrompt, 'base_negative, default_negative',
    'legacy preview-only exclusions should be removed from in-game custom-wife scenes');
  assert.equal(migratedLegacyCharacter.parts.some(part => String(part.label).startsWith('Negative')), false,
    'custom-wife Negative tags must not enter the Positive parts used by portrait regeneration');
  wife.generatedArchetype.attentionImagePrompt.negativePrompt = '';
  const clearedCustomWifeNegative = hooks.imagePrompt.after(customCharacterBase, [wife]);
  assert.match(clearedCustomWifeNegative.negativePrompt, /base_negative/,
    'an empty custom-wife Negative must preserve the game default Negative');
  delete wife.generatedArchetype;
  savedSettings = {
    characterPrompt: { positivePrompt: 'silver_hair, green_eyes', negativePrompt: 'bad_anatomy', mode: 'replace', imagePolicy: 'regenerate' },
  };
  const characterImageKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.equal(characterImageKey, unchangedOutfitSituationKey,
    'a character prompt edit must keep the same situation image list');
  hooks.imagePrompt.after(characterBase, [wife]);
  assert.equal((await hooks.imageLookup.around(async () => ({ talentName: sceneKey, imagePath: 'old.webp' }), characterImageKey))?.talentName, sceneKey,
    'a character prompt edit should keep the picture in the same situation list');
  const nearestCharacterImage = { talentName: 'other-scene', imagePath: 'nearest.webp' };
  assert.equal(await hooks.imageLookup.around(async () => nearestCharacterImage, characterImageKey), null,
    'regenerate policy should still reject a nearest image when the exact situation is missing');
  const replacedCharacter = hooks.imagePrompt.after(characterBase, [wife]);
  assert.match(replacedCharacter.prompt, /silver_hair/);
  assert.match(replacedCharacter.prompt, /green_eyes/);
  assert.match(replacedCharacter.prompt, /best quality/);
  assert.doesNotMatch(replacedCharacter.prompt, /brown_hair/,
    'replace mode must replace only the original Base character tags');
  assert.match(replacedCharacter.negativePrompt, /bad_anatomy/);
  assert.match(replacedCharacter.negativePrompt, /base_negative/,
    'editing the wife Negative must preserve the game default Negative');
  assert.doesNotMatch(replacedCharacter.negativePrompt, /tattoo|piercing/,
    'editing the wife Negative should replace only the old wife-specific exclusions');
  assert.equal(replacedCharacter.parts.find(part => part.label === '기본').tags, 'silver_hair, green_eyes');
  savedSettings.characterPrompt.mode = 'append';
  const migratedAppendCharacter = hooks.imagePrompt.after(characterBase, [wife]);
  assert.doesNotMatch(migratedAppendCharacter.prompt, /brown_hair/,
    'legacy append settings must migrate to full appearance replacement');
  assert.match(migratedAppendCharacter.prompt, /silver_hair/);
  savedSettings.characterPrompt.negativePrompt = '';
  const clearedCharacterNegative = hooks.imagePrompt.after(characterBase, [wife]);
  assert.equal(clearedCharacterNegative.negativePrompt, 'base_negative, tattoo, piercing',
    'an empty built-in character Negative must preserve the game and archetype defaults');
  savedSettings.characterPrompt.imagePolicy = 'reuse';
  const reuseCharacterImageKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.equal(reuseCharacterImageKey, characterImageKey);
  hooks.imagePrompt.after(characterBase, [wife]);
  assert.equal(await hooks.imageLookup.around(async () => nearestCharacterImage, reuseCharacterImageKey), nearestCharacterImage,
    'reuse policy should allow the game nearest-image fallback for a neutral situation');
  const characterLookupKeys = [];
  const reusedCharacterImage = await hooks.imageLookup.around(async key => {
    characterLookupKeys.push(key);
    return key === reuseCharacterImageKey ? { talentName: key, imagePath: 'old.webp' } : null;
  }, reuseCharacterImageKey);
  assert.equal(reusedCharacterImage.imagePath, 'old.webp');
  assert.deepEqual(characterLookupKeys, [reuseCharacterImageKey],
    'the exact situation image should be reused after a character prompt edit');
  savedSettings.characterPrompt.wifeKey = 'another-wife';
  assert.equal(hooks.imageKey.after(sceneKey, [wife]), unchangedOutfitSituationKey,
    'a current-wife appearance override must not leak to another wife');

  wife.stats.energy = 0;
  savedSettings = { prompts: { 'status.energy.0': 'exhausted, weak posture, heavy eyelids' } };
  const migratedEnergyPrompt = hooks.imagePrompt.after(characterBase, [wife]);
  assert.match(migratedEnergyPrompt.prompt, /exhausted/);
  assert.doesNotMatch(migratedEnergyPrompt.prompt, /weak posture|heavy eyelids/,
    'a saved old default should use the shorter SDXL wording');
  wife.stats.energy = 50;

  rows = [];
  savedSettings = { autoPositionPresets: true };
  const autoSex = hooks.imagePrompt.after(characterBase, [wife]);
  assert.match(autoSex.key, /__position-missionary-/);
  assert.equal(autoSex.key, hooks.imageKey.after(sceneKey, [wife]),
    'the displayed image key must change with the applied position prompt');
  assert.match(autoSex.prompt, /missionary.*woman lying on her back/);
  const autoRiding = hooks.imagePrompt.after({ ...characterBase, key: sceneKey.replace('patron_sex', 'patron_riding') }, [wife]);
  assert.match(autoRiding.prompt, /cowgirl position/);
  const autoAnal = hooks.imagePrompt.after({ ...characterBase, key: sceneKey.replace('patron_sex', 'patron_anal') }, [wife]);
  assert.match(autoAnal.prompt, /anal sex from behind/);
  assert.doesNotMatch(autoAnal.prompt, /vaginal penetration/);
  const oralSceneKey = sceneKey.replace('scene-patron_sex', 'scene-patron_blowjob');
  const autoOral = hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]);
  assert.ok(autoOral.parts.some(part => part.label === '체위 프리셋 · 무릎 구강성교'));
  assert.match(autoOral.prompt, /fellatio/);
  assert.match(autoOral.prompt, /one penis in mouth/);
  assert.match(autoOral.negativePrompt, /multiple penises in mouth/);
  assert.match(autoOral.negativePrompt, /two penises in mouth/);
  assert.match(autoOral.negativePrompt, /extra penis in mouth/);
  assert.doesNotMatch(autoOral.prompt, /rough fellatio/);
  driveState.desire = 70;
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]).prompt, /longing gaze/);
  relationshipLatitude = -69;
  const closedOff = hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]);
  assert.match(closedOff.prompt, /uneasy expression/);
  assert.doesNotMatch(closedOff.prompt, /longing gaze|affectionate gaze/,
    'a closed-off relationship must not add inviting expressions over distress');
  relationshipLatitude = 0;
  const normalOralKey = hooks.imageKey.after(oralSceneKey, [wife]);
  wife.stats.mood = 10;
  const distressedOralKey = hooks.imageKey.after(oralSceneKey, [wife]);
  const distressedOral = hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]);
  assert.ok(distressedOral.parts.some(part => part.label === '체위 프리셋 · 거친 구강성교'));
  assert.match(distressedOral.prompt, /rough fellatio/);
  assert.match(distressedOral.prompt, /deepthroat/);
  assert.match(distressedOral.prompt, /tears/);
  assert.match(distressedOral.prompt, /trembling/);
  assert.match(distressedOral.prompt, /one eye closed/);
  assert.match(distressedOral.prompt, /other eye wide/);
  assert.ok((distressedOral.prompt.match(/(?:fellatio|deepthroat)/g) || []).length <= 2,
    'an extra man must not receive a second oral action when the main man occupies her mouth');
  assert.match(distressedOral.prompt, /supporting man.*watching nearby/);
  assert.doesNotMatch(distressedOral.prompt, /longing gaze|affectionate expression|alluring pose/,
    'distress should take priority over inviting expressions');
  assert.ok(distressedOral.prompt.split(',').length < 40, 'SDXL oral additions should remain concise');
  assert.match(distressedOral.prompt, /woman lying on back/);
  assert.match(distressedOral.prompt, /above woman/);
  assert.match(distressedOral.negativePrompt, /smile/);
  assert.match(distressedOral.negativePrompt, /closed mouth/);
  assert.match(distressedOral.negativePrompt, /both eyes closed/);
  assert.match(distressedOral.negativePrompt, /shallow fellatio/);
  driveState.desire = 0;
  assert.notEqual(distressedOralKey, normalOralKey, 'negative and neutral oral states still need separate image lists');
  savedSettings.autoPositionPresets = false;
  assert.doesNotMatch(hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]).prompt,
    /rough fellatio/, 'an off auto-position setting must preserve the original oral scene');
  savedSettings.autoPositionPresets = true;
  savedSettings.positionPresetPrompts = { 'rough-fellatio': 'custom rough oral wording' };
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]).prompt,
    /custom rough oral wording/, 'a saved rough oral prompt must override the new default');
  delete savedSettings.positionPresetPrompts;
  savedSettings.positionRules = { 'scene-patron_blowjob': 'rough-fellatio' };
  assert.ok(hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]).parts
    .some(part => part.label === '체위 프리셋 · 거친 구강성교'),
  'a saved rough scene rule should remain available');
  const analFinishKey = sceneKey.replace('pippa__scene-patron_sex', 'elena__scene-patron_anal_finish');
  const analFinishBase = {
    ...characterBase,
    key: analFinishKey,
    prompt: `${characterBase.prompt}, anal_finish_marker`,
    parts: [...characterBase.parts, { label: '장면', tags: 'anal_finish_marker' }],
  };
  const analFinishPrompt = hooks.imagePrompt.after(analFinishBase, [wife]);
  assert.equal(analFinishPrompt.key, hooks.imageKey.after(analFinishKey, [wife]),
    'the actual prompt and lookup key must agree after switching from oral to anal finish');
  assert.match(analFinishPrompt.key, /att-anal-finish-v3/,
    'the corrected anal prompt must use a new image list');
  assert.match(analFinishPrompt.prompt, /anal_finish_marker/);
  assert.match(analFinishPrompt.prompt, /anal ejaculation.*penis in anus/,
    'anal finish must specify the anatomical action instead of relying on cum_in_ass alone');
  assert.doesNotMatch(analFinishPrompt.prompt, /fellatio|deepthroat|penis[_ ]in[_ ]mouth/i,
    'an oral-only saved rule must not leak into an anal finish');
  assert.match(analFinishPrompt.negativePrompt, /fellatio, deepthroat, penis in mouth/,
    'the anal finish must exclude an oral composition');
  assert.doesNotMatch(analFinishPrompt.negativePrompt, /shallow fellatio|penises in mouth/i,
    'oral-only negative guards must not leak into an anal finish');
  assert.equal(analFinishPrompt.parts.some(part => /fellatio|deepthroat|penis[_ ]in[_ ]mouth/i.test(part.tags)), false,
    'inspectable prompt parts must match the switched scene');
  assert.equal(await hooks.imageLookup.around(async () => ({ talentName: analFinishKey, imagePath: 'old-anal.webp' }), analFinishPrompt.key), null,
    'the new anal finish list must not auto-reuse a previous wrong-composition image');
  delete savedSettings.positionRules;
  wife.stats.mood = 50;
  const oralSituationId = 'scene-patron_blowjob|grp-1|gslot-m';
  const roughOralAction = '(rough fellatio:1.25), (deepthroat:1.25), man receiving fellatio from woman, penis in mouth, tears, trembling, one eye closed, wide-eyed, oral focus';
  savedSettings.positionRules = { [oralSituationId]: [{
    groupSlots: 'm',
    details: {
      female: { pose: '(woman lying on side:1.3), side-lying' },
      main: { placement: 'in front of woman', pose: '', action: roughOralAction, target: 'mouth focus' },
      extras: [{}],
    },
  }] };
  const roughOralOnSide = hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]);
  assert.match(roughOralOnSide.prompt, /woman lying on side/);
  assert.doesNotMatch(roughOralOnSide.prompt, /woman lying on back/);
  assert.match(roughOralOnSide.prompt, /rough fellatio.*deepthroat.*tears.*trembling/);
  assert.match(roughOralOnSide.prompt, /one penis in mouth/);
  assert.match(roughOralOnSide.negativePrompt, /shallow fellatio/,
    'the rough-oral negative guard must also apply through an independent man preset');
  delete savedSettings.positionRules;
  const originalEnergy = wife.stats.energy;
  const originalIntoxication = wife.intoxication.level;
  wife.stats.energy = 0;
  wife.stats.mood = 61;
  wife.feelings = [{ emotion: 'shame', intensity: 94 }];
  const currentLikeOralKey = hooks.imageKey.after(oralSceneKey, [wife]);
  assert.match(currentLikeOralKey, /state-exhausted_state-expression-v2_state-patron-distressed/);
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]).prompt,
    /rough fellatio/, 'exhaustion and distress must select rough oral');
  const oldRoughOralOverride = {
    presetId: 'rough-fellatio', groupSlots: 'm', sourceKey: currentLikeOralKey,
    stateKey: currentLikeOralKey, imageKey: currentLikeOralKey.replace(/__v-0$/, '__v-4'),
  };
  savedModData.positionOverrides = { [oralSituationId]: { ...oldRoughOralOverride, manual: true } };
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]).prompt,
    /rough fellatio/, 'a manually selected rough override must remain active');
  savedModData.positionOverrides[oralSituationId] = { ...oldRoughOralOverride, automatic: true };
  wife.stats.energy = originalEnergy;
  wife.stats.mood = 50;
  wife.feelings = [];
  assert.doesNotMatch(hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]).prompt,
    /rough fellatio/, 'an automatic rough override must return to normal when the negative state ends');
  wife.stats.energy = 0;
  wife.stats.mood = 61;
  wife.feelings = [{ emotion: 'shame', intensity: 94 }];
  savedSettings.autoPositionPresets = false;
  assert.doesNotMatch(hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]).prompt,
    /rough fellatio/, 'turning auto presets off must ignore a previously generated automatic rough override');
  savedModData.positionOverrides[oralSituationId] = { ...oldRoughOralOverride, manual: true };
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]).prompt,
    /rough fellatio/, 'an explicitly chosen rough preset must still work with auto presets off');
  savedSettings.autoPositionPresets = true;
  delete savedModData.positionOverrides;
  wife.stats.energy = originalEnergy;
  wife.stats.mood = 50;
  wife.feelings = [];
  wife.intoxication.level = 50;
  assert.doesNotMatch(hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]).prompt,
    /rough fellatio/, 'intoxication must not automatically select rough oral');
  wife.stats.mood = 0;
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]).prompt,
    /rough fellatio/, 'intoxication must not hide a negative mood from automatic oral selection');
  wife.stats.mood = 50;
  wife.intoxication.level = originalIntoxication;
  wife.stats.energy = originalEnergy;
  wife.stats.mood = 50;
  wife.feelings = [];
  const autoPaizuri = hooks.imagePrompt.after({ ...characterBase, key: sceneKey.replace('scene-patron_sex', 'scene-titfuck') }, [wife]);
  assert.match(autoPaizuri.prompt, /\(paizuri:1\.15\)/);
  assert.match(autoPaizuri.prompt, /woman lying on back/);
  assert.match(autoPaizuri.prompt, /man above woman/);
  assert.match(autoPaizuri.prompt, /male torso visible/);
  assert.match(autoPaizuri.prompt, /penis attached to man/);
  assert.match(autoPaizuri.negativePrompt, /detached penis/);
  assert.match(autoPaizuri.negativePrompt, /penis growing from breasts/);
  assert.match(autoPaizuri.negativePrompt, /penis emerging from nipple/);
  assert.match(autoPaizuri.negativePrompt, /woman on top/);
  const paizuriWithoutOral = hooks.imagePrompt.after({
    ...characterBase,
    key: sceneKey.replace('scene-patron_sex', 'scene-titfuck').replace('__gslot-m', '__gslot-w'),
  }, [wife]);
  assert.doesNotMatch(paizuriWithoutOral.prompt, /one penis in mouth/);
  const supportingPaizuri = hooks.imagePrompt.after({ ...characterBase, key: sceneKey.replace('__gslot-m', '__gslot-b') }, [wife]);
  assert.match(supportingPaizuri.prompt, /supporting man at her chest/);
  assert.match(supportingPaizuri.prompt, /paizuri.*penis between breasts/);
  assert.match(supportingPaizuri.parts.map(part => part.label).join(', '), /파이즈리 해부·구도/);
  assert.match(supportingPaizuri.negativePrompt, /penis emerging from nipple/);
  const clothedPaizuri = hooks.imagePrompt.after({
    ...characterBase,
    key: sceneKey.replace('__gslot-m', '__gslot-b'),
    prompt: 'masterpiece, best quality, 1girl, (straight blonde hair:1.1), blue eyes, cream blouse, cream knee skirt, panties_aside',
    negativePrompt: 'bad anatomy, blonde hair, black hair, cream blouse, underwear',
    parts: [
      { label: '품질', tags: 'masterpiece, best quality' },
      { label: '기본', tags: '1girl, (straight blonde hair:1.1), blue eyes' },
      { label: '의상', tags: 'cream blouse, cream knee skirt' },
    ],
  }, [wife]);
  assert.match(clothedPaizuri.prompt, /^masterpiece, best quality, /,
    'the base quality prefix must remain first');
  assert.equal(clothedPaizuri.parts[0].label, '품질',
    'the prompt inspector should preserve the same base-first order');
  assert.doesNotMatch(clothedPaizuri.prompt, /man\'s penis extends from his visible pelvis/);
  assert.match(clothedPaizuri.prompt, /straight blonde hair/);
  assert.match(clothedPaizuri.prompt, /cream knee skirt/);
  assert.ok(clothedPaizuri.prompt.indexOf('paizuri') < clothedPaizuri.prompt.indexOf('cream blouse'),
    'the selected action should precede outfit details in the generated prompt');
  assert.doesNotMatch(clothedPaizuri.negativePrompt, /blonde hair|cream blouse|underwear/,
    'Negative must not ban the character and outfit requested by Positive');
  assert.match(clothedPaizuri.negativePrompt, /black hair/);
  assert.doesNotMatch(clothedPaizuri.prompt, /garment lowered|skirt lowered/,
    'paizuri framing must not suggest pulling down the skirt');
  assert.doesNotMatch(clothedPaizuri.prompt, /soft shading|muted colors/);
  assert.doesNotMatch(clothedPaizuri.negativePrompt, /harsh shadows|oversaturated colors/);
  const groupOralPaizuri = hooks.imagePrompt.after({
    ...characterBase,
    key: oralSceneKey.replace('__grp-1__gslot-m', '__grp-3__gslot-hhb'),
  }, [wife]);
  assert.match(groupOralPaizuri.prompt, /one penis in mouth/);
  assert.match(groupOralPaizuri.prompt, /paizuri.*penis between breasts/);
  assert.match(groupOralPaizuri.negativePrompt, /multiple penises in mouth/);
  savedSettings.positionGroupPrompts = { b: '(positioned at her chest:1.0), (paizuri:1.25), (penis between breasts:1.3), woman holding breasts together, breast_focus' };
  const groupPromptImageKey = hooks.imageKey.after(sceneKey.replace('__gslot-m', '__gslot-b'), [wife]);
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: sceneKey.replace('__gslot-m', '__gslot-b') }, [wife]).prompt,
    /paizuri.*penis between breasts/,
    'a previously saved paizuri group default should use the concise wording');
  savedSettings.positionGroupPrompts.b = '(supporting man facing her chest:1.1), (paizuri:1.25), (penis extending from supporting man\'s groin across her cleavage:1.3), (penis resting on breast skin outside her body:1.2), breasts pressed against both sides of his penis, separate bodies, breast_focus';
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: sceneKey.replace('__gslot-m', '__gslot-b') }, [wife]).prompt,
    /paizuri.*penis between breasts/, 'the previous paizuri group default should also use the concise wording');
  savedSettings.positionGroupPrompts.b = '(man beside her chest:1.1), (paizuri:1.2), separate bodies';
  assert.equal(hooks.imageKey.after(sceneKey.replace('__gslot-m', '__gslot-b'), [wife]), groupPromptImageKey,
    'editing a group-slot prompt must keep the same role and pose image key');
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: sceneKey.replace('__gslot-m', '__gslot-b') }, [wife]).prompt,
    /paizuri.*penis between breasts/, 'the latest paizuri group default should migrate as well');
  delete savedSettings.positionGroupPrompts;
  savedSettings.autoPositionPresets = false;
  const nativeOralBase = {
    ...characterBase,
    key: oralSceneKey,
    prompt: 'masterpiece, best quality, 1girl, fellatio',
    parts: [{ label: '품질', tags: 'masterpiece, best quality' }, { label: '기본', tags: '1girl' }, { label: '장면', tags: 'fellatio' }],
  };
  assert.match(hooks.imagePrompt.after(nativeOralBase, [wife]).prompt, /one penis in mouth/,
    'the mouth limit must also apply when automatic position presets are off');
  assert.match(hooks.imagePrompt.after({ ...nativeOralBase,
    prompt: 'masterpiece, best quality, 1girl, 69',
    parts: nativeOralBase.parts.map(part => part.label === '장면' ? { ...part, tags: '69' } : part),
  }, [wife]).prompt, /one penis in mouth/,
  'a native 69 tag must also reserve the wife’s mouth');
  savedSettings.positionStatePrompts = { 'scene-patron_blowjob|grp-1|gslot-m': { positivePrompt: 'state only', onlyState: true } };
  assert.doesNotMatch(hooks.imagePrompt.after(nativeOralBase, [wife]).prompt, /one penis in mouth/,
    'state-only mode must omit the position-specific mouth guard');
  delete savedSettings.positionStatePrompts;
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: sceneKey.replace('scene-patron_sex', 'scene-titfuck') }, [wife]).negativePrompt,
    /penis growing from breasts/, 'the paizuri anatomy guard must also apply without automatic presets');
  savedSettings.autoPositionPresets = true;
  savedSettings.positionPresetPrompts = { paizuri: 'custom paizuri wording' };
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: sceneKey.replace('scene-patron_sex', 'scene-titfuck') }, [wife]).prompt,
    /custom paizuri wording/, 'a saved paizuri prompt must override the new default');
  savedSettings.positionPresetPrompts.paizuri = '(paizuri:1.3), woman holding both breasts together around man\'s penis';
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: sceneKey.replace('scene-patron_sex', 'scene-titfuck') }, [wife]).prompt,
    /\(paizuri:1\.15\)/, 'a previously saved paizuri preset default should return to the original');
  savedSettings.positionPresetPrompts.paizuri = '(paizuri:1.3), (penis extending from man\'s groin over woman\'s cleavage:1.3), penis visibly outside breast skin, woman pressing both breasts against its sides';
  assert.doesNotMatch(hooks.imagePrompt.after({ ...characterBase, key: sceneKey.replace('scene-patron_sex', 'scene-titfuck') }, [wife]).prompt,
    /penis visibly outside breast skin/, 'the latest paizuri preset default should return to the original');
  delete savedSettings.positionPresetPrompts;
  savedSettings.positionRules = { 'scene-titfuck': { details: { female: {}, main: {
    action: '(paizuri:1.15), man receiving paizuri from woman, breast sex, breast press, breast focus',
  } } } };
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: sceneKey.replace('scene-patron_sex', 'scene-titfuck') }, [wife]).prompt,
    /paizuri.*penis between breasts/, 'saved paizuri details should use the concise action');
  savedSettings.positionRules['scene-titfuck'].details.main.action = '(paizuri:1.25), man receiving paizuri from woman, (penis between breasts:1.3), (woman squeezing breasts together around penis:1.25), breast focus';
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: sceneKey.replace('scene-patron_sex', 'scene-titfuck') }, [wife]).prompt,
    /paizuri.*penis between breasts/, 'the previous paizuri action default should also migrate');
  savedSettings.positionRules['scene-titfuck'].details.main.action = '(paizuri:1.25), man receiving paizuri from woman, (penis extending from man\'s groin between woman\'s breasts:1.3), penis resting on breast skin outside her body, woman pressing breasts against both sides of his penis, breast focus';
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: sceneKey.replace('scene-patron_sex', 'scene-titfuck') }, [wife]).prompt,
    /paizuri.*penis between breasts/, 'the latest paizuri action default should migrate as well');
  delete savedSettings.positionRules;
  const fingeredSceneKey = sceneKey.replace('scene-patron_sex', 'scene-fingered');
  const handjobSceneKey = sceneKey.replace('scene-patron_sex', 'scene-patron_handjob');
  assert.match(hooks.imageKey.after(fingeredSceneKey, [wife]), /__position-female-hand-stimulation-/);
  assert.match(hooks.imageKey.after(handjobSceneKey, [wife]), /__aip-att-handjob-anatomy-v1__v-0$/,
    'the handjob anatomy fix must use a new image key instead of reusing the malformed portrait');
  const fingeredGroupKey = hooks.imageKey.after(sceneKey.replace('__gslot-m', '__gslot-f'), [wife]);
  const handGroupKey = hooks.imageKey.after(sceneKey.replace('__gslot-m', '__gslot-h'), [wife]);
  assert.match(fingeredGroupKey, /__position-missionary-slots-f-/);
  assert.match(handGroupKey, /__position-missionary-slots-h-/);
  assert.notEqual(fingeredGroupKey, handGroupKey,
    'additional person roles must keep separate image keys after auto position is applied');
  assert.doesNotMatch(hooks.imagePrompt.after({ ...characterBase, key: patronChatKey }, [wife]).key, /pose-/,
    'non-sex scenes must retain the game pose');
  savedSettings = { positionRules: { 'scene-patron_sex': 'doggystyle' } };
  const singlePositionBase = {
    ...characterBase,
    key: sceneKey.replace('__grp-1__gslot-m', ''),
    prompt: 'best quality, 1girl, 1boy, sex from behind, bent_over, tavern interior, shy',
    parts: [
      { label: '품질', tags: 'best quality' },
      { label: '기본', tags: '1girl' },
      { label: '장면', tags: '1boy, sex from behind, bent_over' },
      { label: '장소', tags: 'tavern interior' },
      { label: '기분', tags: 'shy' },
    ],
  };
  const singlePosition = hooks.imagePrompt.after(singlePositionBase, [wife]);
  assert.match(singlePosition.prompt, /(?:^|,\s*)1boy(?:,|$)/,
    'position replacement must retain the original participant count when there is no separate gender group');
  assert.equal(singlePosition.parts.some(part => part.label === '성별·인원 유지' && part.tags === '1boy'), true);
  const positionChecks = [
    ['missionary', /woman lying on her back.*man visibly on top of woman/, /girl_on_top, cowgirl_position/],
    ['mating-press', /woman lying on back.*man visibly on top of woman.*male head and torso visible/, /solo, girl_on_top/],
    ['spooning', /both partners lying on their sides.*man lying behind woman/, /standing_sex/],
  ];
  for (const [presetId, posture, negative] of positionChecks) {
    savedSettings.positionRules['scene-patron_sex'] = presetId;
    const result = hooks.imagePrompt.after(singlePositionBase, [wife]);
    assert.match(result.prompt, posture, `${presetId} must anchor both partners' posture`);
    assert.match(result.prompt, /man's penis visibly inserted into woman's vagina/,
      `${presetId} must state the male-to-female penetration, not just the pose`);
    assert.match(result.negativePrompt, negative, `${presetId} must reject its common wrong pose`);
    assert.doesNotMatch(result.prompt, /sex from behind, bent_over/,
      'a chosen position must replace the native conflicting pose');
  }
  savedSettings.positionRules['scene-patron_sex'] = 'anal-doggystyle';
  assert.match(hooks.imagePrompt.after(singlePositionBase, [wife]).prompt,
    /man's penis visibly inserted into woman's anus/,
    'the anal preset must name its penetration target too');
  savedSettings.positionRules['scene-patron_sex'] = 'missionary';
  const supinePosition = hooks.imagePrompt.after(singlePositionBase, [wife]);
  savedSettings.positionRules['scene-patron_sex'] = 'spooning';
  const switchedPosition = hooks.imagePrompt.after(supinePosition, [wife]);
  assert.match(switchedPosition.negativePrompt, /standing_sex/);
  assert.doesNotMatch(switchedPosition.negativePrompt, /girl_on_top|cowgirl_position/,
    'switching positions must remove the previous posture guard');
  savedSettings.positionRules['scene-patron_sex'] = 'missionary';
  savedSettings.positionPresetPrompts = { missionary: 'custom missionary framing' };
  assert.doesNotMatch(hooks.imagePrompt.after(singlePositionBase, [wife]).negativePrompt, /girl_on_top/,
    'a custom preset prompt must not inherit an incompatible default Negative');
  savedSettings.positionPresetPrompts.missionary = '(missionary position:1.2), face-to-face';
  assert.match(hooks.imagePrompt.after(singlePositionBase, [wife]).prompt, /man visibly on top of woman/,
    'a saved copy of the previous default should adopt the corrected prompt');
  delete savedSettings.positionPresetPrompts;
  savedSettings.positionRules['scene-patron_sex'] = 'doggystyle';
  const positionBase = {
    ...characterBase,
    prompt: 'best quality, 1girl, 1boy, (2boys:1.25), threesome, mmf_threesome, sex from behind, bent_over, (fellatio:1.15), tavern interior, shy',
    parts: [
      { label: '품질', tags: 'best quality' },
      { label: '기본', tags: '1girl' },
      { label: '장면', tags: '1boy, sex from behind, bent_over' },
      { label: '성별', tags: '(2boys:1.25), threesome, mmf_threesome' },
      { label: '그룹', tags: '(fellatio:1.15)' },
      { label: '장소', tags: 'tavern interior' },
      { label: '기분', tags: 'shy' },
    ],
  };
  const fixedPosition = hooks.imagePrompt.after(positionBase, [wife]);
  assert.match(fixedPosition.key, /__position-doggystyle-/);
  assert.match(fixedPosition.prompt, /\(doggystyle:1\.3\)/, 'the default rear pose must carry its stronger emphasis');
  assert.match(fixedPosition.prompt, /woman on hands and knees/, 'the rear pose must identify the receiving posture');
  assert.match(fixedPosition.negativePrompt, /missionary/, 'the default rear pose must exclude a conflicting posture');
  savedSettings.positionPresetPrompts = { doggystyle: '(doggystyle:1.2), sex from behind' };
  assert.match(hooks.imagePrompt.after(positionBase, [wife]).prompt, /\(doggystyle:1\.3\)/,
    'the previously saved default must migrate to the stronger rear pose');
  savedSettings.positionPresetPrompts = { doggystyle: 'custom rear pose wording' };
  assert.match(hooks.imagePrompt.after(positionBase, [wife]).prompt, /custom rear pose wording/,
    'a custom rear pose must remain untouched');
  delete savedSettings.positionPresetPrompts;
  for (const [leading, remaining] of [
    ['shared_marker', '(shared_marker:1.4)'],
    ['(shared_marker:1.4)', 'shared_marker'],
  ]) {
    const input = { ...positionBase, prompt: `${positionBase.prompt}, ${leading}, ${remaining}`,
      parts: positionBase.parts.map((part, index) => index === 0 ? { ...part, tags: `${part.tags}, ${leading}` } : part) };
    const combined = hooks.imagePrompt.after(input, [wife]);
    assert.deepEqual(combined.prompt.split(', ').filter(tag => tag.includes('shared_marker')),
      ['(shared_marker:1.4)'], 'position composition must keep the weighted duplicate regardless of its source');
  }
  savedSettings.positionPresetPrompts = { doggystyle: 'reordered pose tags, edited pose wording' };
  assert.equal(hooks.imageKey.after(sceneKey, [wife]), fixedPosition.key,
    'editing position wording must keep the selected pose image key');
  assert.match(hooks.imagePrompt.after(positionBase, [wife]).prompt, /edited pose wording/);
  delete savedSettings.positionPresetPrompts;
  assert.match(fixedPosition.prompt, /doggystyle/);
  assert.match(fixedPosition.prompt, /woman on all fours/,
    'a legacy scene preset should hydrate the new separate woman pose');
  assert.match(fixedPosition.prompt, /primary man/);
  assert.match(fixedPosition.prompt, /behind woman/);
  assert.match(fixedPosition.prompt, /male kneeling/,
    'a legacy scene preset should hydrate the primary-man placement and pose');
  assert.doesNotMatch(fixedPosition.prompt, /bent_over|sex from behind, bent_over/,
    'a position preset should replace the original scene-position group');
  assert.doesNotMatch(fixedPosition.prompt, /(?:^|,\s*)1boy(?:,|$)/,
    'a multi-person gender group must replace the single-participant tag from the original scene group');
  assert.match(fixedPosition.prompt, /\(2boys:1\.25\)/);
  assert.match(fixedPosition.prompt, /threesome/);
  assert.match(fixedPosition.prompt, /separate male bodies/);
  assert.match(fixedPosition.prompt, /first supporting man/);
  assert.match(fixedPosition.prompt, /\(first supporting man:1\.0\)/);
  assert.match(fixedPosition.prompt, /\(fellatio:1\.1\)/,
    'the original gslot role must be rebuilt as an explicit extra-participant placement');
  assert.doesNotMatch(fixedPosition.prompt, /multiple_boys/,
    'the placement prompt must not duplicate and overemphasize the preserved participant count');
  assert.match(fixedPosition.prompt, /tavern interior/);
  assert.match(fixedPosition.prompt, /shy/,
    'position replacement must preserve location and mood groups');
  assert.equal(fixedPosition.parts.some(part => part.label === '장면'), false);
  assert.equal(fixedPosition.parts.some(part => part.label === '체위 프리셋 · 후배위'), true);
  assert.equal(fixedPosition.parts.some(part => part.label === '추가 인원 배치 · 1: 입'), true,
    'the gslot role should become an explicit extra-participant placement prompt');
  portraitPositionButton.click();
  assert.equal(openedSettingsWindow.options.title, '현재 체위 변경');
  const quickPositionNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.ok(quickPositionNodes.some(node => node.props?.['data-position-current'] === ''));
  assert.ok(quickPositionNodes.some(node => node.props?.['data-tag-library'] === ''),
    'the portrait position shortcut must include the same Korean tag library as settings');
  assert.ok(quickPositionNodes.some(node => node.props?.['data-library-tag'] === 'spanking'),
    'the quick window tag library must expose clickable Danbooru tags');
  const quickPresetEditor = quickPositionNodes.find(node => node.props?.['data-position-preset-prompt']);
  assert.ok(quickPresetEditor, 'the quick window needs a focused position prompt target');
  const quickPresetId = quickPresetEditor.props['data-position-preset-prompt'];
  const previousQuickPrompt = savedSettings.positionPresetPrompts?.[quickPresetId];
  quickPresetEditor.props.onfocus();
  await quickPositionNodes.find(node => node.props?.['data-library-tag'] === 'spanking').props.onclick();
  assert.match(savedSettings.positionPresetPrompts[quickPresetId], /spanking/,
    'a library click in the portrait quick window must save into its focused position prompt');
  if (previousQuickPrompt === undefined) delete savedSettings.positionPresetPrompts[quickPresetId];
  else savedSettings.positionPresetPrompts[quickPresetId] = previousQuickPrompt;
  const autoPositionToggle = quickPositionNodes.find(node => node.props?.['data-position-auto-presets'] === '');
  assert.equal(autoPositionToggle?.props.checked, false);
  autoPositionToggle.props.onchange({ currentTarget: { checked: true } });
  assert.equal(savedSettings.autoPositionPresets, true);
  assert.equal(hooks.imageKey.after(sceneKey, [wife]), fixedPosition.key,
    'a saved fixed position must take priority over automatic presets');
  flattenNodes(openedSettingsWindow.body.children).find(node => node.props?.['data-position-auto-presets'] === '')
    .props.onchange({ currentTarget: { checked: false } });
  assert.ok(quickPositionNodes.some(node => node.tag === 'button' && node.children.includes('이미지 추가 생성')),
    'the portrait-top button should open the same current-position controls directly');
  const fixedPositionKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.equal(fixedPositionKey, fixedPosition.key);
  assert.equal(await hooks.imageLookup.around(async () => ({ talentName: sceneKey, imagePath: 'old.webp' }), fixedPositionKey), null,
    'a changed position must not display an old image drawn for a different prompt');

  const similarPositionKey = fixedPositionKey.replace('__mood-shy', '__mood-happy').replace(/__v-0$/, '__v-2');
  savedSettings.similarImageChoices = { [fixedPositionKey.replace(/__v-\d+$/, '')]: similarPositionKey };
  assert.equal((await hooks.imageLookup.around(async key => ({ talentName: key, imagePath: 'legacy-choice.webp' }), fixedPositionKey))?.talentName, similarPositionKey,
    'the former single-string image choice should migrate to the multiple-selection reader');
  delete savedSettings.similarImageChoices;
  const otherSceneKey = similarPositionKey.replace('scene-patron_sex', 'scene-guest_chat');
  const otherCharacterKey = similarPositionKey.replace(/^pippa__/, 'mara__');
  const wifePreviewKey = 'wife_preview_pippa_1';
  imageManifestEntries = {
    [fixedPositionKey]: { talentName: fixedPositionKey, imagePath: 'current-position.webp', createdAt: 1 },
    [similarPositionKey]: { talentName: similarPositionKey, imagePath: 'similar-position.webp', createdAt: 2 },
    [otherSceneKey]: { talentName: otherSceneKey, imagePath: 'other-scene.webp', createdAt: 3 },
    [otherCharacterKey]: { talentName: otherCharacterKey, imagePath: 'other-character.webp', createdAt: 4 },
    [wifePreviewKey]: { talentName: wifePreviewKey, imagePath: 'wife-preview.webp', createdAt: 5 },
  };
  portraitSimilarButton.click();
  assert.equal(openedSettingsWindow.options.title, '현재 상황에 사용할 이미지 선택');
  await new Promise(resolve => setImmediate(resolve));
  let similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  let similarChoices = similarPickerNodes.filter(node => node.props?.['data-similar-image-choice']);
  assert.deepEqual(similarChoices.map(node => node.props['data-similar-image-choice']).sort(), [fixedPositionKey, similarPositionKey].sort(),
    'the picker should show the same character and scene, not unrelated characters or scenes');
  similarPickerNodes.find(node => node.props?.['data-similar-image-mode'] === 'all').props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.deepEqual(similarPickerNodes.filter(node => node.props?.['data-similar-image-choice'])
    .map(node => node.props['data-similar-image-choice']).sort(),
  [fixedPositionKey, similarPositionKey, otherSceneKey, wifePreviewKey].sort(),
  'the all-images tab should include every scene of the current character, not other characters');
  const imageSearch = similarPickerNodes.find(node => node.props?.['data-similar-image-search'] === '');
  imageSearch.props.oninput({ currentTarget: { value: 'other-scene.webp' } });
  similarPickerNodes.find(node => node.props?.['data-similar-image-search-submit'] === '').props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.deepEqual(similarPickerNodes.filter(node => node.props?.['data-similar-image-choice'])
    .map(node => node.props['data-similar-image-choice']), [otherSceneKey],
  'image search should match both image keys and file names');
  similarPickerNodes.find(node => node.props?.['data-similar-image-search-clear'] === '').props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-similar-image-mode'] === 'similar').props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarChoices = similarPickerNodes.filter(node => node.props?.['data-similar-image-choice']);
  const similarChoice = similarChoices.find(node => node.props['data-similar-image-choice'] === similarPositionKey);
  const galleryWindow = openedSettingsWindow;
  similarPickerNodes.find(node => node.props?.['data-similar-image-preview'] === similarPositionKey).props.onclick();
  assert.equal(openedSettingsWindow.options.title, '이미지 크게 보기');
  assert.ok(flattenNodes(openedSettingsWindow.body.children).some(node => node.tag === 'img'
    && node.props.src.endsWith('/similar-position.webp')),
  'gallery enlarge should show the full image without selecting it');
  openedSettingsWindow = galleryWindow;
  similarChoice.props.onclick();
  let storedSimilarChoice = Object.values(savedSettings.similarImageChoices).find(choice => choice.keys?.includes(similarPositionKey));
  assert.equal(storedSimilarChoice?.mode, 'selected',
    'the selected existing image should be stored for the current situation');
  assert.deepEqual([...storedSimilarChoice.keys], [similarPositionKey]);
  assert.equal(portraitImage.src, 'https://example.test/images/similar-position.webp',
    'selecting an existing image should update the visible portrait immediately');
  const manualLookupKeys = [];
  const manuallySelected = await hooks.imageLookup.around(async key => {
    manualLookupKeys.push(key);
    return imageManifestEntries[key] || null;
  }, fixedPositionKey);
  assert.equal(manuallySelected?.talentName, similarPositionKey);
  assert.deepEqual(manualLookupKeys, [similarPositionKey],
    'the selected existing image should override the automatic exact lookup');
  const missingSelectionLookupKeys = [];
  const missingSelectionFallback = await hooks.imageLookup.around(async key => {
    missingSelectionLookupKeys.push(key);
    return key === fixedPositionKey ? imageManifestEntries[fixedPositionKey] : null;
  }, fixedPositionKey);
  assert.equal(missingSelectionFallback?.talentName, fixedPositionKey);
  assert.deepEqual(missingSelectionLookupKeys, [similarPositionKey, fixedPositionKey],
    'a missing manual source should fall back to the automatic current-situation image');
  const anotherVariantKey = fixedPositionKey.replace(/__v-0$/, '__v-7');
  assert.equal(await hooks.imageLookup.around(async key => imageManifestEntries[key] || null, anotherVariantKey), null,
    'a new native + variant must not be replaced with the manually selected image');

  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-similar-image-mode'] === 'all').props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  const secondChoice = similarPickerNodes.find(node => node.props?.['data-similar-image-choice'] === otherSceneKey);
  const nativeAddClicksBefore = portraitNativeAddClicks;
  secondChoice.props.onclick();
  storedSimilarChoice = Object.values(savedSettings.similarImageChoices).find(choice => choice.keys?.includes(similarPositionKey));
  assert.deepEqual([...storedSimilarChoice.keys], [similarPositionKey, otherSceneKey],
    'more than one existing image should remain selected for the same situation');
  const secondVariantKey = Object.entries(storedSimilarChoice.manualVariants)
    .find(([, source]) => source === otherSceneKey)?.[0];
  assert.match(secondVariantKey || '', /__v-4$/);
  let selectedVariantState = api.fn('imageVariantState')(fixedPositionKey);
  assert.deepEqual([...selectedVariantState.variants], [fixedPositionKey, secondVariantKey],
    'selected-only mode should expose every selected image through the portrait variant list');
  assert.equal(selectedVariantState.currentIdx, 1);
  assert.equal(portraitNativeAddClicks, nativeAddClicksBefore + 1,
    'adding a second selection should update a mounted portrait through its native add control when tabs are unavailable');
  assert.equal((await hooks.imageLookup.around(async key => imageManifestEntries[key] || null, secondVariantKey))?.talentName, otherSceneKey,
    'each selected portrait variant should resolve to its own existing image');
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.equal(similarPickerNodes.find(node => node.props?.['data-similar-image-choice'] === similarPositionKey).props['aria-pressed'], 'true');
  assert.equal(similarPickerNodes.find(node => node.props?.['data-similar-image-choice'] === otherSceneKey).props['aria-pressed'], 'true');
  assert.ok(similarPickerNodes.some(node => node.props?.['data-similar-image-selected-count'] === '' && node.children.includes('선택 이미지 2개')));

  similarPickerNodes.find(node => node.props?.['data-similar-image-choice'] === otherSceneKey).props.onclick();
  storedSimilarChoice = Object.values(savedSettings.similarImageChoices).find(choice => choice.keys?.includes(similarPositionKey));
  assert.deepEqual([...storedSimilarChoice.keys], [similarPositionKey], 'clicking a selected card should deselect only that image');
  assert.deepEqual([...api.fn('imageVariantState')(fixedPositionKey).variants], [fixedPositionKey]);
  const staleDeselectedKeys = [];
  assert.equal((await hooks.imageLookup.around(async key => {
    staleDeselectedKeys.push(key);
    return imageManifestEntries[key] || null;
  }, secondVariantKey))?.talentName, fixedPositionKey);
  assert.deepEqual(staleDeselectedKeys, [fixedPositionKey],
    'a stale mounted variant from a deselected image should resolve to the automatic image, never generate');

  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-similar-image-choice'] === otherSceneKey).props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  const combinedChoice = similarPickerNodes.find(node => node.props?.['data-similar-image-use-mode'] === 'both');
  combinedChoice.props.onclick();
  storedSimilarChoice = Object.values(savedSettings.similarImageChoices).find(choice => choice.keys?.includes(similarPositionKey));
  assert.equal(storedSimilarChoice?.mode, 'both');
  const firstVariantKey = Object.entries(storedSimilarChoice.manualVariants)
    .find(([, source]) => source === similarPositionKey)?.[0];
  assert.match(firstVariantKey || '', /__v-5$/,
    'combined mode should reserve a dedicated native portrait variant for the first selected image too');
  const combinedVariantState = api.fn('imageVariantState')(fixedPositionKey);
  assert.deepEqual([...combinedVariantState.variants], [fixedPositionKey, firstVariantKey, secondVariantKey]);
  assert.equal(flattenNodes(openedSettingsWindow.body.children)
    .find(node => node.props?.['data-portrait-image-use'] === fixedPositionKey).props.disabled, true,
  'combined mode should retain its last automatic variant until selected-only mode is chosen');
  assert.equal((await hooks.imageLookup.around(async key => imageManifestEntries[key] || null, fixedPositionKey))?.talentName, fixedPositionKey,
    'combined mode should leave the automatic portrait variant untouched');
  assert.equal((await hooks.imageLookup.around(async key => imageManifestEntries[key] || null, firstVariantKey))?.talentName, similarPositionKey);
  assert.equal((await hooks.imageLookup.around(async key => imageManifestEntries[key] || null, secondVariantKey))?.talentName, otherSceneKey);

  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-similar-image-choice'] === similarPositionKey).props.onclick();
  storedSimilarChoice = Object.values(savedSettings.similarImageChoices).find(choice => choice.keys?.includes(otherSceneKey));
  assert.deepEqual([...storedSimilarChoice.keys], [otherSceneKey]);
  assert.deepEqual([...api.fn('imageVariantState')(fixedPositionKey).variants], [fixedPositionKey, secondVariantKey],
    'deselecting one image in combined mode should preserve the automatic image and every remaining selection');
  assert.equal((await hooks.imageLookup.around(async key => imageManifestEntries[key] || null, firstVariantKey))?.talentName, fixedPositionKey,
    'a removed combined variant should cleanly resolve to automatic while a mounted portrait is catching up');

  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  const clearSelections = similarPickerNodes.find(node => node.props?.['data-similar-image-clear'] === '');
  clearSelections.props.onclick();
  storedSimilarChoice = Object.values(savedSettings.similarImageChoices)[0];
  assert.equal(storedSimilarChoice?.mode, 'auto',
    'clearing every selection should restore automatic-only mode');
  assert.deepEqual([...storedSimilarChoice.keys], []);
  assert.deepEqual([...api.fn('imageVariantState')(fixedPositionKey).variants], [fixedPositionKey],
    'clearing selections should remove every manual variant from persisted portrait variants');
  const automaticLookupKeys = [];
  const automaticResult = await hooks.imageLookup.around(async key => {
    automaticLookupKeys.push(key);
    return imageManifestEntries[key] || null;
  }, fixedPositionKey);
  assert.equal(automaticResult?.talentName, fixedPositionKey);
  assert.deepEqual(automaticLookupKeys, [fixedPositionKey]);
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.equal(similarPickerNodes.find(node => node.props?.['data-similar-image-use-mode'] === 'selected').props.disabled, true);
  assert.equal(similarPickerNodes.find(node => node.props?.['data-similar-image-use-mode'] === 'both').props.disabled, true);
  const imageManifestResetsBeforeRefresh = imageManifestResets;
  const refreshSimilarImages = flattenNodes(openedSettingsWindow.body.children)
    .find(node => node.tag === 'button' && node.children.includes('목록 새로고침'));
  await refreshSimilarImages.props.onclick();
  assert.equal(imageManifestResets, imageManifestResetsBeforeRefresh + 1,
    'manual refresh should invalidate and reload the image manifest');

  const extraCharacterKeys = Array.from({ length: 90 }, (_, index) =>
    otherSceneKey.replace(/__v-\d+$/, `__v-${100 + index}`));
  for (const [index, key] of extraCharacterKeys.entries()) {
    imageManifestEntries[key] = { talentName: key, imagePath: `more-${index}.webp`, createdAt: index + 10 };
  }
  await refreshSimilarImages.props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-similar-image-mode'] === 'all').props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.equal(similarPickerNodes.filter(node => node.props?.['data-similar-image-choice']).length, 80,
    'large character galleries should render a bounded first page');
  assert.equal(similarPickerNodes.some(node => node.props?.['data-similar-image-choice'] === otherCharacterKey), false,
    'the full gallery must not mix in another character');
  assert.ok(similarPickerNodes.find(node => node.tag === 'img' && node.props?.alt?.includes('미리보기'))
    .props.style.includes('object-fit:contain'), 'gallery previews must show the whole image');
  similarPickerNodes.find(node => node.props?.['data-similar-image-mode'] === 'similar').props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-similar-image-search'] === '').props.oninput({ currentTarget: { value: 'more-0.webp' } });
  similarPickerNodes.find(node => node.props?.['data-similar-image-search-submit'] === '').props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.deepEqual(similarPickerNodes.filter(node => node.props?.['data-similar-image-choice'])
    .map(node => node.props['data-similar-image-choice']), [extraCharacterKeys[0]],
  'search should find an unloaded older image across every scene of the current character, even from the similar tab');
  similarPickerNodes.find(node => node.props?.['data-similar-image-search-clear'] === '').props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-similar-image-mode'] === 'all').props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-similar-image-more'] === '').props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.equal(similarPickerNodes.filter(node => node.props?.['data-similar-image-choice']).length, 94,
    'more should expose every current-character image, including older entries');

  const localGalleryKey = otherSceneKey.replace('scene-guest_chat', 'scene-local_cache');
  localCacheFixture = { version: 1, entries: {
    [localGalleryKey]: {
      talentName: localGalleryKey, imagePath: 'illustrious/characters/pippa/local-gallery.webp', createdAt: 1000,
    },
    [otherCharacterKey]: {
      talentName: otherCharacterKey, imagePath: 'illustrious/characters/mara/other-gallery.webp', createdAt: 1001,
    },
  } };
  await refreshSimilarImages.props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.ok(similarPickerNodes.some(node => node.props?.['data-similar-image-choice'] === localGalleryKey),
    'local generated images should remain in the picker when the generation server is unavailable');
  assert.equal(similarPickerNodes.some(node => node.props?.['data-similar-image-choice'] === otherCharacterKey), false);
  localCacheFixture = { version: 1, entries: {} };
  await refreshSimilarImages.props.onclick();

  const lookupOnlyVariant = fixedPositionKey.replace(/__v-\d+$/, '__v-9');
  imageLookupExtraEntries[lookupOnlyVariant] = {
    talentName: lookupOnlyVariant, imagePath: 'illustrious/characters/pippa/lookup-only.webp', createdAt: 201,
  };
  api.fn('saveImageVariantState')(fixedPositionKey, { variants: [fixedPositionKey, lookupOnlyVariant], currentIdx: 0 });
  await refreshSimilarImages.props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  const lookupPreviewCard = similarPickerNodes.find(node => node.children?.some?.(child =>
    child.props?.['data-portrait-image-use'] === lookupOnlyVariant));
  assert.ok(lookupPreviewCard?.children.some(child => child.tag === 'img'
    && child.props.src.endsWith('/lookup-only.webp')),
  'every portrait variant should preview its exact image even when it is absent from the manifest');
  imageLookupExtraEntries = {};

  const compactPreviewVariant = fixedPositionKey.replace(/__v-\d+$/, '__v-10');
  imageLookupExtraEntries[compactPreviewVariant] = {
    talentName: 'pippa__scene-patron_sex__aipk-stored__v-10',
    imagePath: 'illustrious/characters/pippa/compact-variant.webp', createdAt: 202,
  };
  api.fn('saveImageVariantState')(fixedPositionKey,
    { variants: [fixedPositionKey, compactPreviewVariant], currentIdx: 0 });
  await refreshSimilarImages.props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  const compactPreviewCard = similarPickerNodes.find(node => node.children?.some?.(child =>
    child.props?.['data-portrait-image-use'] === compactPreviewVariant));
  assert.ok(compactPreviewCard?.children.some(child => child.tag === 'img'
    && child.props.src.endsWith('/compact-variant.webp')),
  'a portrait variant stored under a compact image key should still show its preview');
  const pickerWindow = openedSettingsWindow;
  similarPickerNodes.find(node => node.props?.['data-portrait-image-preview'] === compactPreviewVariant).props.onclick();
  assert.equal(openedSettingsWindow.options.title, '이미지 크게 보기');
  assert.ok(flattenNodes(openedSettingsWindow.body.children).some(node => node.tag === 'img'
    && node.props.src.endsWith('/compact-variant.webp')),
  'the portrait enlarge button should open the selected image without changing its use state');
  openedSettingsWindow = pickerWindow;
  assert.deepEqual([...api.fn('imageVariantState')(fixedPositionKey).variants],
    [fixedPositionKey, compactPreviewVariant]);
  const wrongCharacterVariant = fixedPositionKey.replace(/__v-\d+$/, '__v-11');
  imageLookupExtraEntries[wrongCharacterVariant] = {
    talentName: 'mara__scene-patron_sex__aipk-unrelated__v-11', imagePath: 'wrong-character.webp',
  };
  api.fn('saveImageVariantState')(fixedPositionKey,
    { variants: [fixedPositionKey, compactPreviewVariant, wrongCharacterVariant], currentIdx: 0 });
  await refreshSimilarImages.props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  const wrongCharacterCard = similarPickerNodes.find(node => node.children?.some?.(child =>
    child.props?.['data-portrait-image-use'] === wrongCharacterVariant));
  assert.equal(wrongCharacterCard?.children.some(child => child.tag === 'img'), false,
    'a nearest image from another character must not masquerade as this portrait variant');
  imageLookupExtraEntries = {};

  const extraPortraitVariant = fixedPositionKey.replace(/__v-\d+$/, '__v-1');
  imageManifestEntries[extraPortraitVariant] = {
    talentName: extraPortraitVariant, imagePath: 'portrait-extra.webp', createdAt: 200,
  };
  api.fn('saveImageVariantState')(fixedPositionKey, { variants: [fixedPositionKey, extraPortraitVariant], currentIdx: 1 });
  await refreshSimilarImages.props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  failVariantSave = true;
  similarPickerNodes.find(node => node.props?.['data-portrait-image-use'] === extraPortraitVariant).props.onclick();
  failVariantSave = false;
  assert.deepEqual([...api.fn('imageVariantState')(fixedPositionKey).variants], [fixedPositionKey, extraPortraitVariant],
    'a failed native save must leave the portrait list unchanged');
  assert.equal(savedSettings.unusedPortraitImages?.[fixedPositionKey.replace(/__v-\d+$/, '')], undefined,
    'a failed native save must not create a false unused-image record');
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-portrait-image-use'] === extraPortraitVariant).props.onclick();
  assert.deepEqual([...api.fn('imageVariantState')(fixedPositionKey).variants], [fixedPositionKey],
    'unused portrait image should leave the native variant list without deleting its image entry');
  assert.deepEqual([...savedSettings.unusedPortraitImages[fixedPositionKey.replace(/__v-\d+$/, '')]], [extraPortraitVariant]);
  assert.ok(imageManifestEntries[extraPortraitVariant]);
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.equal(similarPickerNodes.find(node => node.props?.['data-portrait-image-use'] === extraPortraitVariant)
    .props['aria-pressed'], 'false', 'an unused image should remain available for restoration');
  similarPickerNodes.find(node => node.props?.['data-portrait-image-use'] === extraPortraitVariant).props.onclick();
  assert.deepEqual([...api.fn('imageVariantState')(fixedPositionKey).variants], [fixedPositionKey, extraPortraitVariant],
    'restoring an unused image should return it to the native portrait variant list');
  assert.equal(savedSettings.unusedPortraitImages[fixedPositionKey.replace(/__v-\d+$/, '')], undefined);
  const laterPortraitVariant = fixedPositionKey.replace(/__v-\d+$/, '__v-2');
  api.fn('saveImageVariantState')(fixedPositionKey,
    { variants: [fixedPositionKey, extraPortraitVariant, laterPortraitVariant], currentIdx: 2 });
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-portrait-image-use'] === extraPortraitVariant).props.onclick();
  let orderedPortraitState = api.fn('imageVariantState')(fixedPositionKey);
  assert.deepEqual({ variants: [...orderedPortraitState.variants], currentIdx: orderedPortraitState.currentIdx },
    { variants: [fixedPositionKey, laterPortraitVariant], currentIdx: 1 },
    'excluding a middle image must preserve the selected later image');
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  const activePortraitList = similarPickerNodes.find(node => node.props?.['data-portrait-active-list'] === '');
  const unusedPortraitList = similarPickerNodes.find(node => node.props?.['data-portrait-unused-list'] === '');
  const listedKeys = list => list.children.map(card => card.children.find(child =>
    child.props?.['data-portrait-image-use'])?.props['data-portrait-image-use']);
  assert.deepEqual(listedKeys(activePortraitList), [fixedPositionKey, laterPortraitVariant],
    'the active portrait list must not display an excluded card');
  assert.deepEqual(listedKeys(unusedPortraitList), [extraPortraitVariant],
    'excluded images must remain available only in the collapsed restore section');
  unusedPortraitList.children[0].children.find(child => child.props?.['data-portrait-image-use']).props.onclick();
  orderedPortraitState = api.fn('imageVariantState')(fixedPositionKey);
  assert.deepEqual({ variants: [...orderedPortraitState.variants], currentIdx: orderedPortraitState.currentIdx },
    { variants: [fixedPositionKey, extraPortraitVariant, laterPortraitVariant], currentIdx: 2 },
    'restoring an image must return it to its original position without changing the selected image');
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-portrait-image-use'] === extraPortraitVariant).props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-portrait-image-use'] === laterPortraitVariant).props.onclick();
  const newFirstVariant = fixedPositionKey.replace(/__v-\d+$/, '__v-6');
  api.fn('saveImageVariantState')(fixedPositionKey,
    { variants: [newFirstVariant, fixedPositionKey], currentIdx: 0 });
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-portrait-image-use'] === laterPortraitVariant).props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-portrait-image-use'] === extraPortraitVariant).props.onclick();
  orderedPortraitState = api.fn('imageVariantState')(fixedPositionKey);
  assert.deepEqual({ variants: [...orderedPortraitState.variants], currentIdx: orderedPortraitState.currentIdx },
    { variants: [newFirstVariant, fixedPositionKey, extraPortraitVariant, laterPortraitVariant], currentIdx: 0 },
    'multiple restores must preserve original relative order and a newly added first image');
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.equal(similarPickerNodes.find(node => node.props?.['data-portrait-image-use'] === fixedPositionKey)
    .props.disabled, false);
  api.fn('saveImageVariantState')(fixedPositionKey, { variants: [fixedPositionKey], currentIdx: 0 });

  const staleGroup = fixedPositionKey.replace(/__v-\d+$/, '');
  const staleAutoOne = fixedPositionKey.replace(/__v-\d+$/, '__v-20');
  const staleAutoTwo = fixedPositionKey.replace(/__v-\d+$/, '__v-21');
  const removedAuto = fixedPositionKey.replace(/__v-\d+$/, '__v-22');
  const manualVariant = fixedPositionKey.replace(/__v-\d+$/, '__v-23');
  const choicesBeforeStaleTest = savedSettings.similarImageChoices;
  savedSettings.similarImageChoices = {
    ...choicesBeforeStaleTest,
    [staleGroup]: {
      key: similarPositionKey, keys: [similarPositionKey], mode: 'both',
      manualVariants: { [manualVariant]: similarPositionKey }, autoKey: fixedPositionKey,
      autoVariants: [fixedPositionKey, staleAutoOne, staleAutoTwo, removedAuto],
    },
  };
  imageVariantStates[staleGroup] = {
    variants: [fixedPositionKey, staleAutoOne, staleAutoTwo, manualVariant], currentIdx: 0,
  };
  openedSettingsWindow.win.refresh();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-portrait-image-use'] === manualVariant).props.onclick();
  assert.deepEqual([...api.fn('imageVariantState')(fixedPositionKey).variants],
    [fixedPositionKey, staleAutoOne, staleAutoTwo],
    'excluding a manual image must not resurrect an auto image absent from the native list');
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-portrait-image-use'] === staleAutoTwo).props.onclick();
  assert.deepEqual([...api.fn('imageVariantState')(fixedPositionKey).variants],
    [fixedPositionKey, staleAutoOne],
    'excluding two of four images must leave exactly the two active images in order');
  if (choicesBeforeStaleTest === undefined) delete savedSettings.similarImageChoices;
  else savedSettings.similarImageChoices = choicesBeforeStaleTest;
  delete savedSettings.unusedPortraitImages?.[staleGroup];
  delete savedSettings.unusedPortraitImageOrder?.[staleGroup];
  api.fn('saveImageVariantState')(fixedPositionKey, { variants: [fixedPositionKey], currentIdx: 0 });

  const baseActiveOne = fixedPositionKey.replace(/__v-\d+$/, '__v-30');
  const baseExcludedTwo = fixedPositionKey.replace(/__v-\d+$/, '__v-31');
  const baseActiveTwo = fixedPositionKey.replace(/__v-\d+$/, '__v-32');
  let mountedPortraitVariants = {
    variants: [fixedPositionKey, baseActiveOne, baseExcludedTwo, baseActiveTwo], currentIdx: 0,
  };
  portraitActionBar.__reactFiberTest = {
    memoizedState: {
      memoizedState: mountedPortraitVariants,
      queue: { dispatch(value) {
        mountedPortraitVariants = value;
        portraitActionBar.__reactFiberTest.memoizedState.memoizedState = value;
      } },
      next: null,
    },
    return: null,
  };
  api.fn('saveImageVariantState')(fixedPositionKey, mountedPortraitVariants);
  openedSettingsWindow.win.refresh();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-portrait-image-use'] === fixedPositionKey).props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-portrait-image-use'] === baseExcludedTwo).props.onclick();
  assert.deepEqual([...mountedPortraitVariants.variants], [baseActiveOne, baseActiveTwo],
    'the mounted game portrait must show two active images after excluding the base and another image');
  mountedPortraitVariants = {
    variants: [fixedPositionKey, baseActiveOne, baseActiveTwo], currentIdx: 0,
  };
  portraitActionBar.__reactFiberTest.memoizedState.memoizedState = mountedPortraitVariants;
  pauseObserverCallback();
  animationFrameCallback?.();
  assert.deepEqual([...mountedPortraitVariants.variants], [baseActiveOne, baseActiveTwo],
    'a remounted game portrait must not reinsert an excluded base image');
  delete portraitActionBar.__reactFiberTest;
  delete savedSettings.unusedPortraitImages?.[staleGroup];
  delete savedSettings.unusedPortraitImageOrder?.[staleGroup];
  api.fn('saveImageVariantState')(fixedPositionKey, { variants: [fixedPositionKey], currentIdx: 0 });
  const beforeNormalAdd = portraitNativeAddClicks;
  const previousNormalAddKey = activePortraitKey;
  activePortraitKey = fixedPositionKey;
  portraitNativeAddButton.click();
  assert.equal(portraitNativeAddClicks, beforeNormalAdd + 1,
    'an ordinary native + click must still reach the game');
  let normalNativeRequest;
  await hooks.imageGenerate.around(async request => {
    normalNativeRequest = request;
    return { url: 'https://example.test/normal-native.webp', fresh: true };
  }, { imageKey: fixedPositionKey.replace(/__v-\d+$/, '__v-4'), prompt: 'old cached prompt', negativePrompt: '' });
  assert.equal(normalNativeRequest.bypassCache, false,
    'a native + request must not ask the server to delete an existing image');
  activePortraitKey = previousNormalAddKey;

  const currentAccessoryPrompt = { key: fixedPositionKey, prompt: '1girl, bare neck',
    negativePrompt: 'choker, vibrator', parts: [{ label: '기본', tags: '1girl, bare neck' }] };
  const shownPromptHook = {
    memoizedState: { ...currentAccessoryPrompt,
      key: fixedPositionKey.replace('__v-0', '__aip-jewel-choker_toy-vibe-egg__v-0'),
      prompt: '1girl, heart-shaped choker, egg vibrator' },
    queue: { dispatch(value) { shownPromptHook.memoizedState = value; } },
    next: { memoizedState: [currentAccessoryPrompt, []], next: null },
  };
  portraitActionBar.__reactFiberTest = { memoizedState: shownPromptHook, return: null };
  pauseObserverCallback();
  animationFrameCallback?.();
  assert.equal(JSON.stringify(shownPromptHook.memoizedState), JSON.stringify(currentAccessoryPrompt),
    'the visible prompt must drop stale toy and choker tags after equipment changes');
  shownPromptHook.memoizedState = { ...currentAccessoryPrompt,
    key: fixedPositionKey.replace('__v-0', '__v-5'), prompt: 'saved variant prompt' };
  pauseObserverCallback();
  animationFrameCallback?.();
  assert.equal(shownPromptHook.memoizedState.prompt, 'saved variant prompt',
    'a selected variant with the same accessory state keeps its own inspected prompt');
  const staleAccessoryKey = fixedPositionKey.replace('__v-0', '__aip-jewel-choker__v-0');
  const loadedPortraitRef = { memoizedState: { current: staleAccessoryKey }, next: null };
  shownPromptHook.next.next = {
    memoizedState: { variants: [fixedPositionKey], currentIdx: 0 }, next: loadedPortraitRef,
  };
  const originalPortraitQuery = portraitActionBar.querySelector;
  const staleImage = { style: { visibility: '' }, addEventListener() {} };
  portraitActionBar.querySelector = function (selector) {
    if (selector === 'img') return staleImage;
    if (selector === '[data-attention-stale-accessory-image]') return this.staleAccessoryVeil || null;
    return originalPortraitQuery.call(this, selector);
  };
  portraitActionBar.appendChild = function (node) {
    this.staleAccessoryVeil = node;
    node.remove = () => { this.staleAccessoryVeil = null; };
  };
  pauseObserverCallback();
  animationFrameCallback?.();
  assert.equal(staleImage.style.visibility, 'hidden',
    'a previously loaded choker image must be hidden while the unequipped image is unavailable');
  assert.ok(portraitActionBar.staleAccessoryVeil);
  loadedPortraitRef.memoizedState.current = fixedPositionKey;
  pauseObserverCallback();
  animationFrameCallback?.();
  assert.equal(staleImage.style.visibility, '', 'the new matching image must become visible');
  assert.equal(portraitActionBar.staleAccessoryVeil, null);
  portraitActionBar.querySelector = originalPortraitQuery;
  delete portraitActionBar.appendChild;
  delete portraitActionBar.__reactFiberTest;
  delete portraitActionBar.__attentionPromptSyncKey;
  const accessoryScanBefore = animationFrameRequests;
  storeListener();
  assert.equal(animationFrameRequests, accessoryScanBefore,
    'unrelated game updates must not rescan the portrait for accessory changes');
  const originalAccessoryStats = wife.situationStats;
  wife.situationStats = { ...wife.situationStats, jewelryState: {
    ...wife.situationStats?.jewelryState, breasts: { stage: 3 },
  } };
  storeListener();
  assert.ok(animationFrameRequests > accessoryScanBefore,
    'changing the equipped choker must schedule the portrait prompt correction');
  animationFrameCallback?.();
  wife.situationStats = originalAccessoryStats;
  storeListener();
  animationFrameCallback?.();

  const excludedNativeVariant = fixedPositionKey.replace(/__v-\d+$/, '__v-4');
  const nextNativeVariant = fixedPositionKey.replace(/__v-\d+$/, '__v-6');
  const originalActivePortraitKey = activePortraitKey;
  const originalExcludedEntry = imageManifestEntries[excludedNativeVariant];
  imageManifestEntries[excludedNativeVariant] = {
    talentName: excludedNativeVariant, imagePath: 'excluded-native-variant.webp', createdAt: 210,
  };
  api.fn('saveImageVariantState')(fixedPositionKey,
    { variants: [fixedPositionKey, excludedNativeVariant], currentIdx: 1 });
  await refreshSimilarImages.props.onclick();
  similarPickerNodes = flattenNodes(openedSettingsWindow.body.children);
  similarPickerNodes.find(node => node.props?.['data-portrait-image-use'] === excludedNativeVariant).props.onclick();
  assert.deepEqual([...api.fn('imageVariantState')(fixedPositionKey).variants], [fixedPositionKey]);
  api.fn('saveImageVariantState')(fixedPositionKey,
    { variants: [fixedPositionKey, excludedNativeVariant], currentIdx: 1 });
  assert.deepEqual([...api.fn('imageVariantState')(fixedPositionKey).variants], [fixedPositionKey],
    'a stale native portrait must not restore an excluded image');
  const viewClicks = { status: 0, portrait: 0 };
  portraitActionBar.parentElement = {
    querySelectorAll(selector) {
      return selector === 'button' ? [
        { title: '초상화 보기', click() { viewClicks.portrait += 1; } },
        { title: '캐릭터 정보 카드 보기', click() { viewClicks.status += 1; } },
      ] : [];
    },
  };
  activePortraitKey = fixedPositionKey;
  const nativeClicksBeforeExclusion = portraitNativeAddClicks;
  portraitNativeAddButton.click();
  animationFrameCallback?.();
  portraitActionBar.parentElement = null;
  assert.equal(portraitNativeAddClicks, nativeClicksBeforeExclusion,
    'native + must not reuse an excluded cached variant number');
  assert.deepEqual([...api.fn('imageVariantState')(fixedPositionKey).variants],
    [nextNativeVariant, fixedPositionKey], 'native + should reserve a fresh number after an unused image');
  assert.deepEqual(viewClicks, { status: 1, portrait: 1 },
    'the portrait must remount so the native view selects the fresh variant');
  assert.notEqual((await hooks.imageLookup.around(async key => imageManifestEntries[key] || null,
    nextNativeVariant))?.talentName, excludedNativeVariant,
  'the fresh variant must not resolve the excluded image');
  let freshNativeRequest;
  await hooks.imageGenerate.around(async request => {
    freshNativeRequest = request;
    return { url: 'https://example.test/fresh-native.webp' };
  }, { imageKey: nextNativeVariant, prompt: 'adult portrait', negativePrompt: '' });
  assert.equal(freshNativeRequest.bypassCache, false,
    'the intercepted native + must not ask the server to delete an existing image');
  assert.equal(hooks.currentPortraitImageKey.after(excludedNativeVariant), nextNativeVariant,
    'an excluded current image must not be restored by the native portrait mount');
  savedSettings.unusedPortraitImages[fixedPositionKey.replace(/__v-\d+$/, '')].push(fixedPositionKey);
  imageVariantStates[fixedPositionKey.replace(/__v-\d+$/, '')] = {
    variants: [fixedPositionKey, nextNativeVariant, excludedNativeVariant], currentIdx: 0,
  };
  assert.deepEqual([...api.fn('imageVariantState')(fixedPositionKey).variants], [nextNativeVariant],
    'old saved lists must hide excluded images immediately on read');
  assert.equal(hooks.currentPortraitImageKey.after(fixedPositionKey), nextNativeVariant,
    'excluding the base image must switch the portrait anchor to an active variant');
  api.fn('saveImageVariantState')(fixedPositionKey,
    { variants: [fixedPositionKey, nextNativeVariant, excludedNativeVariant], currentIdx: 0 });
  assert.deepEqual([...api.fn('imageVariantState')(fixedPositionKey).variants], [nextNativeVariant],
    'native remounts must not restore excluded base or variant images');
  delete savedSettings.unusedPortraitImages[fixedPositionKey.replace(/__v-\d+$/, '')];
  api.fn('saveImageVariantState')(fixedPositionKey, { variants: [fixedPositionKey], currentIdx: 0 });
  activePortraitKey = originalActivePortraitKey;
  if (originalExcludedEntry) imageManifestEntries[excludedNativeVariant] = originalExcludedEntry;
  else delete imageManifestEntries[excludedNativeVariant];

  settingsRenderer(settingsBody, settingsWin);
  settingsNodes = collectNodes();
  const positionTab = settingsNodes.find(node => node.tag === 'button' && node.children.includes('체위 설정'));
  assert.ok(positionTab, 'settings UI should expose a position preset tab');
  positionTab.props.onclick();
  settingsNodes = collectNodes();
  const firstPositionGroup = settingsNodes.find(node => node.props?.['data-position-preset-group']);
  assert.equal(firstPositionGroup?.tag, 'details', 'position presets should be grouped in collapsible sections');
  assert.equal(firstPositionGroup.props.open, false);
  firstPositionGroup.props.ontoggle({ currentTarget: { open: true } });
  settingsWin.refresh();
  settingsNodes = collectNodes();
  assert.equal(settingsNodes.find(node => node.props?.['data-position-preset-group'] === firstPositionGroup.props['data-position-preset-group'])?.props.open, true);
  assert.ok(settingsNodes.some(node => node.props?.['data-position-current'] === ''),
    'position tab should show the currently captured scene');
  assert.ok(settingsNodes.some(node => node.children?.some?.(child => typeof child === 'string' && child.includes('추가 남성 1명'))),
    'the current situation label should distinguish an extra participant');
  let includeDefaultPosition = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-position-include-default'] === 'scene-patron_sex');
  assert.ok(includeDefaultPosition && !includeDefaultPosition.props.checked,
    'a fixed position list should expose the game-default inclusion option');
  randomValue = 0.999;
  includeDefaultPosition.props.onchange({ currentTarget: { checked: true } });
  assert.deepEqual({ ...savedSettings.positionRuleDefaults }, { 'scene-patron_sex': true });
  const nativePositionCandidate = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife]);
  assert.equal(nativePositionCandidate.key, unchangedOutfitSituationKey,
    'the game default should remain an actual random candidate when the option is enabled');
  assert.doesNotMatch(nativePositionCandidate.prompt, /doggystyle/);
  settingsNodes = collectNodes();
  includeDefaultPosition = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-position-include-default'] === 'scene-patron_sex');
  assert.equal(includeDefaultPosition.props.checked, true);
  includeDefaultPosition.props.onchange({ currentTarget: { checked: false } });
  randomValue = 0;
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife]).prompt, /doggystyle/,
    'disabling the option should return to fixed-position-only selection');
  let groupSlotSelect = settingsNodes.find(node => node.tag === 'select' && node.props['data-position-group-slot'] === '0');
  assert.equal(groupSlotSelect.props.value, 'm', 'the placement editor should load the current gslot role');
  assert.equal(groupSlotSelect.children.find(option => option.props?.value === 'm').props.selected, true,
    'the visible select option must match the current mouth placement');
  assert.ok(settingsNodes.some(node => node.tag === 'button' && node.children.includes('여성 손 자극')),
    'the main partner should have a female hand-stimulation preset');
  assert.ok(groupSlotSelect.children.some(option => option.props?.value === 'f' && option.children.includes('여성 손 자극')),
    'each additional participant should be able to provide female hand stimulation');
  assert.ok(groupSlotSelect.children.some(option => option.props?.value === 'c' && option.children.includes('커닐링구스')),
    'each additional participant should expose cunnilingus as a fast role');
  assert.ok(groupSlotSelect.children.some(option => option.props?.value === 'h' && option.children.includes('남성 손 자극')),
    'each additional participant should expose female-to-male hand stimulation explicitly');
  assert.ok(groupSlotSelect.children.some(option => option.props?.value === 'b' && option.children.includes('파이즈리')),
    'each additional participant should expose paizuri by name');
  assert.ok(settingsNodes.some(node => node.tag === 'button' && node.children.includes('앉아서 남성 손 자극')),
    'the main partner should have an explicit female-to-male hand-stimulation preset');
  const femaleHandPreset = settingsNodes.find(node => node.tag === 'button' && node.children.includes('여성 손 자극'));
  femaleHandPreset.props.onclick();
  settingsNodes = collectNodes();
  assert.match(settingsNodes.find(node => node.props?.['data-position-prompt'] === 'female-hand-stimulation')
    .children.find(node => node?.tag === 'textarea').props.value, /fingering|hand_on_pussy/,
  'the female hand-stimulation preset should expose its complete SDXL prompt');

  let positionStatePrompt = settingsNodes.find(node => node.tag === 'textarea' && node.props['data-position-state-prompt'] === '');
  positionStatePrompt.props.onchange({ currentTarget: { value: 'custom_state_marker, restrained wrists' } });
  assert.deepEqual(JSON.parse(JSON.stringify(savedSettings.positionStatePrompts['scene-patron_sex|grp-1|gslot-m'])), {
    positivePrompt: 'custom_state_marker, restrained wrists', negativePrompt: '', onlyState: false,
  });
  const statePosition = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife]);
  assert.match(statePosition.prompt, /custom_state_marker/,
    'the current-state prompt should apply independently of the selected position editor state');
  assert.notEqual(statePosition.key, fixedPosition.key,
    'editing the scene prompt must change the automatic image key');
  settingsNodes = collectNodes();
  const negativeStatePrompt = settingsNodes.find(node => node.tag === 'textarea'
    && node.props['data-position-state-negative-prompt'] === '');
  negativeStatePrompt.props.onchange({ currentTarget: { value: 'state_negative_marker' } });
  settingsNodes = collectNodes();
  assert.equal(settingsNodes.find(node => node.props?.['data-position-state-prompt'] === '').props.value,
    'custom_state_marker, restrained wrists', 'Positive must persist when Negative is edited');
  assert.equal(settingsNodes.find(node => node.props?.['data-position-state-negative-prompt'] === '').props.value,
    'state_negative_marker', 'Negative must remain editable after a settings refresh');
  const withNegativeState = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife]);
  assert.match(withNegativeState.negativePrompt, /state_negative_marker/);
  assert.notEqual(withNegativeState.key, statePosition.key, 'Negative edits must change the automatic image key');
  const stateOnlyToggle = settingsNodes.find(node => node.props?.['data-position-state-only'] === '');
  assert.equal(stateOnlyToggle.props.checked, false);
  stateOnlyToggle.props.onchange({ currentTarget: { checked: true } });
  assert.equal(savedSettings.positionStatePrompts['scene-patron_sex|grp-1|gslot-m'].onlyState, true);
  settingsNodes = collectNodes();
  assert.equal(settingsNodes.find(node => node.props?.['data-position-state-only'] === '').props.checked, true);
  const stateOnlyPosition = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife]);
  assert.equal(stateOnlyPosition.key, hooks.imageKey.after(sceneKey, [wife]),
    'state-only prompt and image key must stay synchronized');
  assert.doesNotMatch(stateOnlyPosition.key, /pose-/);
  assert.match(stateOnlyPosition.prompt, /custom_state_marker/);
  assert.match(stateOnlyPosition.negativePrompt, /state_negative_marker/);
  assert.doesNotMatch(stateOnlyPosition.prompt, /doggystyle|woman on all fours|primary man/,
    'state-only mode must exclude the selected position preset and person details');
  assert.equal(stateOnlyPosition.parts.some(part => part.label.startsWith('체위 프리셋')), false);
  savedSettings.positionStatePrompts['scene-patron_sex|grp-1|gslot-m'].positivePrompt = 'edited_state_only_marker';
  const editedStateOnly = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife]);
  assert.notEqual(editedStateOnly.key, stateOnlyPosition.key,
    'editing state-only text must change the automatic image key');
  assert.match(editedStateOnly.prompt, /edited_state_only_marker/);
  savedSettings.positionStatePrompts['scene-patron_sex|grp-1|gslot-m'].positivePrompt = 'custom_state_marker, restrained wrists';
  const stateOnlyRequestCount = generatedRequests.length;
  await hooks.imageGenerate.around(request => api.fn('imageGenerate')(request), {
    imageKey: stateOnlyPosition.key, prompt: stateOnlyPosition.prompt,
    negativePrompt: stateOnlyPosition.negativePrompt, bypassCache: false,
  });
  assert.equal(generatedRequests.length, stateOnlyRequestCount + 1);
  assert.doesNotMatch(generatedRequests.at(-1).prompt, /doggystyle/);
  assert.match(generatedRequests.at(-1).negativePrompt, /state_negative_marker/);
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.props?.['data-position-state-only'] === '')
    .props.onchange({ currentTarget: { checked: false } });
  const restoredStatePosition = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife]);
  assert.match(restoredStatePosition.prompt, /doggystyle|woman on all fours/,
    'unchecking state-only mode should restore the selected position preset');
  assert.match(restoredStatePosition.negativePrompt, /state_negative_marker/);

  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('세부 설정만 사용')).props.onclick();
  settingsNodes = collectNodes();
  assert.ok(settingsNodes.some(node => node.props?.['data-position-female-settings'] === ''),
    'the woman must have a separate settings card');
  assert.ok(settingsNodes.some(node => node.tag === 'span' && node.children.includes('여성 자세 프리셋')),
    'the woman settings card should expose its own pose preset');
  assert.ok(settingsNodes.some(node => node.tag === 'strong' && node.children.includes('남성 설정 · 주 상대')),
    'the primary man must have a separate person card');
  assert.ok(settingsNodes.some(node => node.tag === 'strong' && node.children.includes('남성 설정 · 추가 남성 1')),
    'each supporting man must have a separate person card');
  let mainPersonPreset = settingsNodes.find(node => node.tag === 'select' && node.props['data-position-person-preset'] === 'main');
  let extraPersonPreset = settingsNodes.find(node => node.tag === 'select' && node.props['data-position-person-preset'] === '0');
  assert.ok(mainPersonPreset.children.some(option => option.props?.value === 'paizuri'));
  assert.ok(extraPersonPreset.children.some(option => option.props?.value === 'cunnilingus'));
  assert.ok(mainPersonPreset.children.some(option => option.props?.value === 'rough-fellatio'));
  assert.ok(extraPersonPreset.children.some(option => option.props?.value === 'rough-fellatio'));
  settingsNodes.find(node => node.tag === 'select' && node.props['data-position-female-pose'] === '')
    .props.onchange({ currentTarget: { value: '(woman lying on side:1.3), side-lying' } });
  settingsNodes = collectNodes();
  mainPersonPreset = settingsNodes.find(node => node.tag === 'select' && node.props['data-position-person-preset'] === 'main');
  mainPersonPreset.props.onchange({ currentTarget: { value: 'rough-fellatio' } });
  settingsNodes = collectNodes();
  assert.equal(settingsNodes.find(node => node.tag === 'select' && node.props['data-position-female-pose'] === '').props.value,
    '(woman lying on side:1.3), side-lying', 'a rough-oral man preset must preserve the selected woman pose');
  assert.match(settingsNodes.find(node => node.tag === 'select' && node.props['data-position-detail-main'] === 'action').props.value,
    /rough fellatio/, 'the rough-oral man preset should update that man action');
  assert.match(settingsNodes.find(node => node.tag === 'textarea' && node.props['data-position-person-prompt-preview'] === '').props.value,
    /deepthroat.*tears.*trembling/, 'the rough-oral man preset should expose its concise SDXL prompt');
  mainPersonPreset = settingsNodes.find(node => node.tag === 'select' && node.props['data-position-person-preset'] === 'main');
  mainPersonPreset.props.onchange({ currentTarget: { value: 'paizuri' } });
  settingsNodes = collectNodes();
  assert.match(settingsNodes.find(node => node.tag === 'select' && node.props['data-position-detail-main'] === 'action').props.value, /paizuri/,
    'a primary-man preset should update only that man details');
  extraPersonPreset = settingsNodes.find(node => node.tag === 'select' && node.props['data-position-person-preset'] === '0');
  extraPersonPreset.props.onchange({ currentTarget: { value: 'cunnilingus' } });
  settingsNodes = collectNodes();
  assert.equal(settingsNodes.find(node => node.tag === 'select' && node.props['data-position-group-slot'] === '0').props.value, 'c',
    'a supporting-man preset should update that person fast role');
  groupSlotSelect = settingsNodes.find(node => node.tag === 'select' && node.props['data-position-group-slot'] === '0');
  groupSlotSelect.props.onchange({ currentTarget: { value: 'f' } });
  const setPositionDetail = (attribute, key, value) => {
    settingsNodes = collectNodes();
    const select = settingsNodes.find(node => node.tag === 'select' && node.props[attribute] === key);
    assert.ok(select, `missing detailed position control ${attribute}=${key}`);
    select.props.onchange({ currentTarget: { value } });
  };
  const femalePoseSelect = settingsNodes.find(node => node.tag === 'select' && node.props['data-position-female-pose'] === '');
  femalePoseSelect.props.onchange({ currentTarget: { value: '(woman lying face down:1.35), prone, chest down, back up' } });
  settingsNodes = collectNodes();
  assert.equal(settingsNodes.some(node => node.props?.['data-position-prompt']), false,
    'manual person settings should clear a potentially conflicting whole-scene preset');
  const mainActionSelect = settingsNodes.find(node => node.tag === 'select' && node.props['data-position-detail-main'] === 'action');
  assert.ok(mainActionSelect.children.some(option => option.props?.value === '(handjob:1.15), man receiving handjob from woman, penis in hand, hand focus' && option.children.includes('남성 손 자극 받기')),
    'detailed actions should include female-to-male hand stimulation');
  assert.ok(mainActionSelect.children.some(option => option.props?.value === '(paizuri:1.15), man receiving paizuri from woman, breast sex, breast press, breast focus' && option.children.includes('파이즈리 받기')),
    'detailed actions should include paizuri');
  setPositionDetail('data-position-detail-main', 'placement', 'behind woman');
  setPositionDetail('data-position-detail-main', 'pose', 'male leaning over woman');
  setPositionDetail('data-position-detail-main', 'action', '(fingering:1.15), man fingering woman, hand on pussy, fingers in pussy, female focus');
  setPositionDetail('data-position-detail-main', 'target', 'pussy focus');
  setPositionDetail('data-position-detail-extra', '0:placement', "between woman's legs");
  setPositionDetail('data-position-detail-extra', '0:pose', 'male kneeling');
  setPositionDetail('data-position-detail-extra', '0:action', '(fingering:1.15), man fingering woman, hand on pussy, fingers in pussy, female focus');
  setPositionDetail('data-position-detail-extra', '0:target', 'pussy focus');
  settingsNodes = collectNodes();
  const personPromptPreview = settingsNodes.find(node => node.tag === 'textarea' && node.props['data-position-person-prompt-preview'] === '');
  assert.match(personPromptPreview.props.value, /woman lying face down/);
  assert.match(personPromptPreview.props.value, /primary man/);
  assert.match(personPromptPreview.props.value, /first supporting man/,
    'the settings UI should expose the exact combined person prompt before generation');
  const detailedGenerationCount = generatedRequests.length;
  const detailedStoreUpdates = storeUpdates;
  portraitImage.src = 'https://example.test/visible-before-position-add.webp';
  const beforeDetailedLookInput = lastImagePromptInput;
  lastImagePromptInput = { ...lastImagePromptInput, result: { ...lastImagePromptInput.result, look: 'position-look' } };
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('이미지 추가 생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  lastImagePromptInput = beforeDetailedLookInput;
  assert.equal(generatedRequests.length, detailedGenerationCount + 1,
    'the add action must submit a generation request without relying on a portrait rerender');
  assert.equal(generatedRequests.at(-1).look, 'position-look', 'position generation must retain the current look fingerprint');
  assert.equal(storeUpdates, detailedStoreUpdates + 1,
    'an add should rerender the portrait after saving its expanded native list');
  const detailedSelectedImageKey = hooks.imageKey.after(sceneKey, [wife]);
  const detailedPromptAfterAdd = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife]);
  assert.equal(detailedPromptAfterAdd.key, detailedSelectedImageKey,
    'the prompt must use the final portrait key that owns the native variant list');
  const detailedPositionRequest = {
    imageKey: detailedPromptAfterAdd.key,
    prompt: detailedPromptAfterAdd.prompt,
    negativePrompt: detailedPromptAfterAdd.negativePrompt,
    bypassCache: false,
  };
  const detailedPositionResult = await hooks.imageGenerate.around(request => api.fn('imageGenerate')(request), detailedPositionRequest);
  portraitImage.src = detailedPositionResult.url;
  assert.equal(generatedRequests.length, detailedGenerationCount + 1,
    'the native portrait flow must reuse the added image without generating it again');
  assert.match(detailedPositionRequest.imageKey, /__position-custom-slots-f-[^_]+__v-4$/,
    'custom pose controls must use a distinct position key and a new variant');
  assert.match(detailedPositionRequest.prompt, /woman pose/);
  assert.match(detailedPositionRequest.prompt, /woman lying face down/);
  assert.match(detailedPositionRequest.prompt, /prone, chest down, back up/,
    'the face-down preset should use explicit WAI Illustrious pose tags');
  assert.doesNotMatch(detailedPositionRequest.prompt, /woman lying on back/,
    'an explicit woman pose must remove the previously selected scene pose');
  assert.match(detailedPositionRequest.prompt, /primary man/);
  assert.match(detailedPositionRequest.prompt, /behind woman/);
  assert.match(detailedPositionRequest.prompt, /male leaning over woman/);
  assert.match(detailedPositionRequest.prompt, /first supporting man/);
  assert.match(detailedPositionRequest.prompt, /between woman's legs/);
  assert.match(detailedPositionRequest.prompt, /male kneeling/);
  assert.match(detailedPositionRequest.prompt, /fingering/);
  assert.match(detailedPositionRequest.prompt, /man fingering woman's vagina:1\.3/);
  assert.match(detailedPositionRequest.negativePrompt, /female_masturbation.*anal_fingering/,
    'a detailed male hand action must exclude self-touch and anal fingering');
  assert.match(detailedPositionRequest.prompt, /custom_state_marker/,
    'the independent current-state prompt should remain active with a detailed position');
  assert.equal(detailedPromptAfterAdd.key, detailedPositionRequest.imageKey,
    'the generated detail-only variant should remain selected when the portrait rerenders');
  const detailedVariantState = Object.values(imageVariantStates).find(entry => entry.variants.includes(detailedPositionRequest.imageKey));
  assert.deepEqual([...detailedVariantState.variants], [detailedPositionRequest.imageKey],
    'the custom pose must not cycle back to the original portrait');
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('이 상황에 고정 추가')).props.onclick();
  assert.deepEqual(JSON.parse(JSON.stringify(savedSettings.positionRules['scene-patron_sex|grp-1|gslot-m'])), [{
    presetId: '',
    groupSlots: 'f',
    details: {
      female: {
        pose: '(woman lying face down:1.35), prone, chest down, back up',
      },
      main: {
        placement: 'behind woman',
        pose: 'male leaning over woman',
        action: '(fingering:1.15), man fingering woman, hand on pussy, fingers in pussy, female focus',
        target: 'pussy focus',
      },
      extras: [{
        placement: "between woman's legs",
        pose: 'male kneeling',
        action: '(fingering:1.15), man fingering woman, hand on pussy, fingers in pussy, female focus',
        target: 'pussy focus',
      }],
    },
  }], 'detail-only combinations should be serializable as fixed situation rules');
  settingsNodes = collectNodes();
  const detailedRule = settingsNodes.find(node => node.props?.['data-position-rule'] === 'scene-patron_sex|grp-1|gslot-m');
  flattenNodes(detailedRule).find(node => node.tag === 'button' && node.children.includes('삭제')).props.onclick();
  assert.equal(Object.prototype.hasOwnProperty.call(savedSettings.positionRules, 'scene-patron_sex|grp-1|gslot-m'), false,
    'a detailed fixed rule should remain individually removable');

  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('세부 설정 초기화')).props.onclick();
  settingsNodes = collectNodes();
  groupSlotSelect = settingsNodes.find(node => node.tag === 'select' && node.props['data-position-group-slot'] === '0');
  groupSlotSelect.props.onchange({ currentTarget: { value: 'h' } });
  settingsNodes = collectNodes();
  groupSlotSelect = settingsNodes.find(node => node.tag === 'select' && node.props['data-position-group-slot'] === '0');
  assert.equal(groupSlotSelect.props.value, 'h', 'the selected additional-person role must survive a settings rerender');
  assert.equal(groupSlotSelect.children.find(option => option.props?.value === 'h').props.selected, true,
    'the browser-visible selected option must survive a settings rerender');
  const handPlacementPrompt = settingsNodes.find(node => node.tag === 'textarea' && node.props['data-position-group-prompt'] === 'h');
  assert.ok(handPlacementPrompt, 'each additional-person role should expose an editable prompt');
  handPlacementPrompt.props.onchange({ currentTarget: { value: '(positioned at her side:1.25), (handjob:1.4), penis_in_hand, hand_focus' } });
  assert.equal(savedSettings.positionGroupPrompts.h, '(positioned at her side:1.25), (handjob:1.4), penis_in_hand, hand_focus');
  const selectPositionPreset = name => {
    settingsNodes = collectNodes();
    const button = settingsNodes.find(node => node.tag === 'button' && node.children.includes(name));
    assert.ok(button, `missing position preset: ${name}`);
    button.props.onclick();
    settingsNodes = collectNodes();
    const preset = settingsNodes.find(node => node.props?.['data-position-prompt']);
    const preview = settingsNodes.find(node => node.props?.['data-position-person-prompt-preview'] === '');
    return `${preset?.children?.find(node => node?.tag === 'textarea')?.props.value || ''}, ${preview?.props.value || ''}`;
  };
  const missionaryPresetPrompt = selectPositionPreset('정상위');
  assert.match(missionaryPresetPrompt, /woman lying on her back.*man visibly on top of woman/);
  assert.match(missionaryPresetPrompt, /male partner between her legs/);
  const sidePresetPrompt = selectPositionPreset('측위');
  assert.match(sidePresetPrompt, /both partners lying on their sides.*man lying behind woman/);
  assert.match(sidePresetPrompt, /male lying on side/);
  const standingPresetPrompt = selectPositionPreset('입위');
  assert.match(standingPresetPrompt, /standing sex/);
  assert.match(standingPresetPrompt, /woman standing/);
  assert.match(standingPresetPrompt, /male standing/);
  assert.match(standingPresetPrompt, /in front of woman/);
  assert.doesNotMatch(standingPresetPrompt, /bent over|behind woman|sex from behind/,
    'the standing preset must not fall back to a bent-over rear-entry pose');
  const wallPinnedPrompt = selectPositionPreset('벽에 밀쳐서');
  assert.match(wallPinnedPrompt, /woman pinned against wall/);
  assert.match(wallPinnedPrompt, /woman standing with her back pressed against wall/);
  assert.match(wallPinnedPrompt, /male partner standing in front of woman/);
  assert.match(wallPinnedPrompt, /in front of woman/);
  assert.doesNotMatch(wallPinnedPrompt, /male (?:partner )?(?:leaning|pressed|pinned).*wall|behind woman|torso leaning forward/);
  const wallLeaningPrompt = selectPositionPreset('벽에 기대서');
  assert.match(wallLeaningPrompt, /woman leaning (?:forward with both palms on|against) wall/);
  assert.match(wallLeaningPrompt, /woman bracing both hands on wall/);
  assert.match(wallLeaningPrompt, /male partner standing behind woman/);
  assert.match(wallLeaningPrompt, /behind woman/);
  assert.doesNotMatch(wallLeaningPrompt, /male (?:partner )?(?:leaning|pressed|pinned).*wall/);
  const wallOneLegPrompt = selectPositionPreset('벽에서 한발만 들림');
  assert.match(wallOneLegPrompt, /woman standing side-on against wall/);
  assert.match(wallOneLegPrompt, /only one leg raised/);
  assert.match(wallOneLegPrompt, /other foot planted on floor/);
  assert.match(wallOneLegPrompt, /side penetration/);
  assert.match(wallOneLegPrompt, /man penetrating woman from the side/);
  assert.match(wallOneLegPrompt, /beside woman/);
  assert.match(wallOneLegPrompt, /male standing/);
  assert.doesNotMatch(wallOneLegPrompt, /both feet hanging|legs locked around|supporting woman under both thighs|behind woman|in front of woman/,
    'the one-leg wall preset must keep exactly one foot grounded and the man at her side');
  const liftedPrompt = selectPositionPreset('들려서');
  assert.match(liftedPrompt, /suspended congress/);
  assert.match(liftedPrompt, /supporting woman under both thighs/);
  assert.match(liftedPrompt, /legs locked around male partner waist/);
  assert.match(liftedPrompt, /both feet hanging in midair/);
  assert.match(liftedPrompt, /clear gap between feet and floor/);
  assert.match(liftedPrompt, /male standing/);
  assert.match(liftedPrompt, /in front of woman/);
  assert.doesNotMatch(liftedPrompt, /\blifted\b|lifting (?:her |the )?skirt/,
    'the carried preset must not use lifted wording that can be read as lifting a skirt');
  const feetOffGroundPrompt = selectPositionPreset('발이 땅에 닿지 않게');
  assert.match(feetOffGroundPrompt, /suspended congress/);
  assert.match(feetOffGroundPrompt, /woman pressed against wall/);
  assert.match(feetOffGroundPrompt, /supporting woman under both thighs/);
  assert.match(feetOffGroundPrompt, /both feet hanging in midair/);
  assert.match(feetOffGroundPrompt, /clear gap between feet and floor/);
  assert.match(feetOffGroundPrompt, /floor visible beneath both feet/);
  assert.doesNotMatch(feetOffGroundPrompt, /\blifted\b|lifting (?:her |the )?skirt/);
  assert.doesNotMatch(feetOffGroundPrompt, /male (?:partner )?(?:leaning|pressed|pinned).*wall|hands on wall|torso leaning forward|behind woman/);
  const pressPresetPrompt = selectPositionPreset('프레스(굴곡위)');
  assert.match(pressPresetPrompt, /mating press/);
  assert.match(pressPresetPrompt, /knees pressed beside shoulders/);
  assert.match(pressPresetPrompt, /thighs folded tightly against torso/);
  assert.match(pressPresetPrompt, /woman lying on back/);
  assert.match(pressPresetPrompt, /man visibly on top of woman/);
  assert.match(pressPresetPrompt, /male head and torso visible/);
  assert.match(pressPresetPrompt, /male torso lowered far over woman/);
  assert.match(pressPresetPrompt, /male chest over her folded legs/);
  assert.match(pressPresetPrompt, /pressing her knees down with his body weight/);
  assert.match(pressPresetPrompt, /forceful thrusting/);
  assert.match(pressPresetPrompt, /between woman's legs/);
  const sixtyNinePresetPrompt = selectPositionPreset('69');
  assert.match(sixtyNinePresetPrompt, /opposite-facing bodies/);
  assert.match(sixtyNinePresetPrompt, /beside woman/);
  assert.doesNotMatch(sixtyNinePresetPrompt, /above woman/,
    'the side-lying 69 preset should not place one side-lying body above the other');
  settingsNodes = collectNodes();
  const cowgirlPreset = settingsNodes.find(node => node.tag === 'button' && node.children.includes('기승위'));
  cowgirlPreset.props.onclick();
  settingsNodes = collectNodes();
  const selectedPositionPrompt = settingsNodes.find(node => node.props?.['data-position-prompt'] === 'cowgirl');
  assert.ok(selectedPositionPrompt, 'clicking a position name should select its bundled prompt');
  let positionPromptEditor = settingsNodes.find(node => node.tag === 'textarea' && node.props['data-position-preset-prompt'] === 'cowgirl');
  assert.ok(positionPromptEditor, 'a selected position preset should expose its full prompt for editing');
  positionPromptEditor.props.onfocus();
  collectNodes().find(node => node.props?.['data-tag-category-option'] === 'all').props.onclick();
  await collectNodes().find(node => node.props?.['data-library-tag'] === 'female_orgasm').props.onclick();
  assert.match(savedSettings.positionPresetPrompts.cowgirl, /female_orgasm/,
    'the side tag library should insert a tag into the focused legacy position prompt');
  positionPromptEditor = collectNodes().find(node => node.props?.['data-position-preset-prompt'] === 'cowgirl');
  const previousCowgirlPrompt = savedSettings.positionPresetPrompts?.cowgirl;
  positionPromptEditor.props.oninput({ currentTarget: { value: 'custom cowgirl pose, girl on top' } });
  assert.notEqual(savedSettings.positionPresetPrompts?.cowgirl, previousCowgirlPrompt);
  assert.equal(savedSettings.positionPresetPrompts?.cowgirl, 'custom cowgirl pose, girl on top',
    'typing should persist the prompt even if the settings window closes before blur');
  const promptSaveStatus = { textContent: '' };
  const editEvent = { currentTarget: {
    value: 'custom cowgirl pose, girl on top',
    parentElement: { querySelector: () => promptSaveStatus },
  } };
  dropPositionPresetPromptWrites = true;
  editEvent.currentTarget.value = 'quota failure cowgirl prompt';
  positionPromptEditor.props.onchange(editEvent);
  assert.equal(savedSettings.positionPresetPrompts?.cowgirl, 'custom cowgirl pose, girl on top');
  assert.match(promptSaveStatus.textContent, /저장 실패/,
    'a browser quota failure should be visible instead of silently losing the prompt');
  dropPositionPresetPromptWrites = false;
  editEvent.currentTarget.value = 'custom cowgirl pose, girl on top';
  positionPromptEditor.props.onchange(editEvent);
  assert.equal(savedSettings.positionPresetPrompts.cowgirl, 'custom cowgirl pose, girl on top');
  assert.equal(promptSaveStatus.textContent, '저장됨');
  assert.equal(collectNodes().find(node => node.props?.['data-position-preset-prompt'] === 'cowgirl'), positionPromptEditor,
    'typing must keep the active preset editor mounted for the next click');
  settingsNodes = collectNodes();
  const generationCount = generatedRequests.length;
  const cowgirlStoreUpdates = storeUpdates;
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('이미지 추가 생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(generatedRequests.length, generationCount + 1,
    'adding another position must request the new image immediately');
  assert.equal(storeUpdates, cowgirlStoreUpdates + 1,
    'each additional image should refresh the native portrait variant state');
  const addedSelectedImageKey = hooks.imageKey.after(sceneKey, [wife]);
  const addedPositionPrompt = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife]);
  assert.equal(addedPositionPrompt.key, addedSelectedImageKey,
    'each added prompt must remain attached to the final selected portrait variant');
  const addedPositionRequest = {
    imageKey: addedPositionPrompt.key,
    prompt: addedPositionPrompt.prompt,
    negativePrompt: addedPositionPrompt.negativePrompt,
    bypassCache: false,
  };
  await hooks.imageGenerate.around(request => api.fn('imageGenerate')(request), addedPositionRequest);
  assert.equal(generatedRequests.length, generationCount + 1,
    'the portrait rerender must not request a second image');
  assert.match(addedPositionRequest.imageKey, /__position-cowgirl-slots-h-[^_]+__v-4$/,
    'another pose must get its own key and first custom variant');
  assert.notEqual(addedPositionRequest.imageKey, detailedPositionRequest.imageKey);
  assert.match(addedPositionRequest.prompt, /custom cowgirl pose/);
  assert.match(addedPositionRequest.prompt, /woman straddling man/);
  assert.match(addedPositionRequest.prompt, /below woman/);
  assert.match(addedPositionRequest.prompt, /male lying on back/,
    'the improved cowgirl preset should assign woman and primary-man poses separately');
  assert.match(addedPositionRequest.prompt, /separate male bodies/);
  assert.match(addedPositionRequest.prompt, /\(first supporting man:1\.0\)/);
  assert.match(addedPositionRequest.prompt, /\(handjob:1\.4\)/);
  assert.match(addedPositionRequest.prompt, /custom_state_marker/,
    'changing from detailed controls to a preset must keep the independent current-state prompt');
  assert.doesNotMatch(addedPositionRequest.prompt, /fellatio|penis_in_mouth/);
  assert.doesNotMatch(addedPositionRequest.prompt, /doggystyle/);
  assert.equal(addedPositionRequest.bypassCache, false);
  assert.equal(hooks.imageKey.after(sceneKey, [wife]), addedPositionRequest.imageKey,
    'the selected added variant should stay active when portrait prompt details rerender');
  const persistedPositionOverride = Object.values(savedModData.positionOverrides || {})
    .find(override => override.imageKey === addedPositionRequest.imageKey);
  assert.ok(persistedPositionOverride, 'the current position and exact image key should be stored in the current save');
  assert.deepEqual([...persistedPositionOverride.generatedKeys],
    [detailedPositionRequest.imageKey, addedPositionRequest.imageKey],
    'every generated position variant should remain exact after reload, not only the current one');
  savedModData = JSON.parse(JSON.stringify(savedModData));
  const restoredPositionKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.equal(restoredPositionKey, addedPositionRequest.imageKey,
    'a serialized and reloaded save should restore the selected position image key');
  const previousSimilarChoices = savedSettings.similarImageChoices;
  savedSettings.similarImageChoices = {
    [restoredPositionKey.replace(/__v-\d+$/, '')]: {
      key: similarPositionKey, keys: [similarPositionKey], mode: 'selected', manualVariants: {}, autoVariants: [],
    },
  };
  const restoredLookupKeys = [];
  const restoredSimilarImage = await hooks.imageLookup.around(async key => {
    restoredLookupKeys.push(key);
    return key === restoredPositionKey
      ? { talentName: key, imagePath: 'restored-position.webp' }
      : imageManifestEntries[key] || null;
  }, restoredPositionKey);
  assert.equal(restoredSimilarImage?.talentName, restoredPositionKey,
    'a newly generated exact position variant must not be hidden by a situation-wide selected-image fallback');
  assert.deepEqual(restoredLookupKeys, [restoredPositionKey]);
  assert.deepEqual(savedSettings.similarImageChoices[restoredPositionKey.replace(/__v-\d+$/, '')].keys, [similarPositionKey],
    'showing the exact generated position must preserve the saved similar-image selection');
  const restoredOtherVariant = restoredPositionKey.replace(/__v-\d+$/, '__v-88');
  assert.equal(await hooks.imageLookup.around(async key => imageManifestEntries[key] || null, restoredOtherVariant), null,
    'a new native + variant must remain available for generation after restoring image selections');
  const nativePlusGenerationCount = generatedRequests.length;
  const nativePlusResult = await hooks.imageGenerate.around(async request => {
    const nearest = await hooks.imageLookup.around(async key => key === restoredPositionKey
      ? { talentName: key, imagePath: 'previous-position.webp' } : null, request.imageKey);
    assert.equal(nearest, null, 'native + must not display the previous variant as a nearest cache hit');
    return api.fn('imageGenerate')(request);
  }, { ...addedPositionRequest, imageKey: restoredOtherVariant });
  assert.equal(generatedRequests.length, nativePlusGenerationCount + 1);
  const shortenedVariantKey = generatedRequests.at(-1).imageKey;
  assert.match(shortenedVariantKey, /^pippa__scene-patron_sex__aipk-[a-z0-9]+__v-88$/);
  assert.ok(shortenedVariantKey.length < 140, 'the ComfyUI filename prefix must stay bounded');
  const shortenedVariant = { talentName: shortenedVariantKey, imagePath: 'short-position.webp' };
  assert.equal(await hooks.imageLookup.around(async key => key === shortenedVariantKey ? shortenedVariant : null,
    restoredOtherVariant), shortenedVariant,
  'the original full key must find the short generated image');
  assert.notEqual(nativePlusResult.url, `https://example.test/${encodeURIComponent(restoredPositionKey)}.webp`,
    'native + should display a newly generated image under its own variant key');
  if (previousSimilarChoices === undefined) delete savedSettings.similarImageChoices;
  else savedSettings.similarImageChoices = previousSimilarChoices;
  let duplicatePositionGenerations = 0;
  const reusedPositionResult = await hooks.imageGenerate.around(async () => {
    duplicatePositionGenerations += 1;
    return { url: 'https://example.test/unexpected-new-position.webp' };
  }, {
    imageKey: addedPositionRequest.imageKey,
    prompt: addedPositionRequest.prompt,
    negativePrompt: addedPositionRequest.negativePrompt,
  });
  assert.equal(duplicatePositionGenerations, 0,
    'opening portrait prompt details after a position add must reuse the generated result instead of generating the base variant');
  assert.equal(reusedPositionResult.url, `https://example.test/${encodeURIComponent(addedPositionRequest.imageKey)}.webp`);
  assert.equal(Object.hasOwn(reusedPositionResult, 'key'), false, 'older game cached result shape must remain unchanged');
  const gameBeforePositionCache = api.game;
  api.game = '2026-10-24-pre7';
  const pre7PositionCache = await hooks.imageGenerate.around(async () => { throw new Error('cached position must not generate'); }, {
    imageKey: addedPositionRequest.imageKey, prompt: addedPositionRequest.prompt, negativePrompt: addedPositionRequest.negativePrompt,
  });
  assert.equal(pre7PositionCache.key, addedPositionRequest.imageKey, 'pre7 position cache must supply the requested image key');
  assert.equal(pre7PositionCache.fresh, false, 'a reused position image must be marked cached');
  api.game = gameBeforePositionCache;
  await hooks.imageGenerate.around(async () => {
    duplicatePositionGenerations += 1;
    return { url: 'https://example.test/forced-position-regeneration.webp' };
  }, {
    imageKey: addedPositionRequest.imageKey,
    prompt: addedPositionRequest.prompt,
    negativePrompt: addedPositionRequest.negativePrompt,
    bypassCache: true,
  });
  assert.equal(duplicatePositionGenerations, 1, 'an explicit regeneration must still bypass the in-session generated result');
  const portraitPromptAfterAdd = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife]);
  assert.equal(portraitPromptAfterAdd.key, addedPositionRequest.imageKey,
    'clicking the portrait should expose the selected generated variant and its full prompt');
  assert.match(portraitPromptAfterAdd.prompt, /custom cowgirl pose/);
  assert.match(portraitPromptAfterAdd.prompt, /\(handjob:1\.4\)/);
  assert.equal(hooks.imageKey.after(sceneKey.replace('mood-shy', 'mood-happy'), [wife]), addedPositionRequest.imageKey,
    'a temporary position should keep its exact generated list until the current situation ends');
  const storedPositionVariants = Object.values(imageVariantStates).find(entry => entry.variants.includes(addedPositionRequest.imageKey));
  assert.deepEqual([...storedPositionVariants.variants], [addedPositionRequest.imageKey],
    'the cowgirl list must not show images generated for other poses');
  assert.deepEqual([...detailedVariantState.variants], [detailedPositionRequest.imageKey],
    'switching poses must preserve the previous pose image separately');
  let previousPositionGenerations = 0;
  const previousPositionResult = await hooks.imageGenerate.around(async () => {
    previousPositionGenerations += 1;
    return { url: 'https://example.test/previous-position.webp' };
  }, {
    imageKey: detailedPositionRequest.imageKey,
    prompt: detailedPositionRequest.prompt,
    negativePrompt: detailedPositionRequest.negativePrompt,
  });
  assert.equal(previousPositionGenerations, 0,
    'the prior selected position should retain its own exact generated result');
  assert.equal(previousPositionResult.url, `https://example.test/${encodeURIComponent(detailedPositionRequest.imageKey)}.webp`,
    'the prior portrait must not be aliased to the newly generated position image');
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('이 상황에 고정 추가')).props.onclick();
  assert.deepEqual(JSON.parse(JSON.stringify(savedSettings.positionRules['scene-patron_sex|grp-1|gslot-m'])), [
    { presetId: 'cowgirl', groupSlots: 'h' },
  ]);
  assert.deepEqual(JSON.parse(JSON.stringify(savedSettings.positionRules['scene-patron_sex'])), [
    { presetId: 'doggystyle', groupSlots: '' },
  ],
    'saving a detailed multi-person rule must retain the legacy base rule for other group layouts');
  settingsNodes = collectNodes();
  let detailedDefaultToggle = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-position-rule-default'] === 'scene-patron_sex|grp-1|gslot-m');
  let baseDefaultToggle = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-position-rule-default'] === 'scene-patron_sex');
  assert.ok(detailedDefaultToggle && baseDefaultToggle,
    'each fixed situation should expose its own game-default random option');
  detailedDefaultToggle.props.onchange({ currentTarget: { checked: true } });
  assert.deepEqual({ ...savedSettings.positionRuleDefaults }, { 'scene-patron_sex|grp-1|gslot-m': true },
    'enabling the detailed situation must not change the base situation setting');
  settingsNodes = collectNodes();
  detailedDefaultToggle = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-position-rule-default'] === 'scene-patron_sex|grp-1|gslot-m');
  baseDefaultToggle = settingsNodes.find(node => node.tag === 'input'
    && node.props['data-position-rule-default'] === 'scene-patron_sex');
  assert.equal(detailedDefaultToggle.props.checked, true);
  assert.equal(baseDefaultToggle.props.checked, false,
    'another situation must keep its independent default-random setting');
  detailedDefaultToggle.props.onchange({ currentTarget: { checked: false } });
  const cowgirlKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.equal(cowgirlKey, addedPositionRequest.imageKey,
    'fixing the generated combination must not discard its selected variant and create a missing base variant');
  const differentGroupKey = hooks.imageKey.after(sceneKey.replace('__grp-1__gslot-m', '__grp-2__gslot-mh'), [wife]);
  assert.match(differentGroupKey, /__grp-2__gslot-mh__aip-att-handjob-anatomy-v1__position-doggystyle-slots-mh-[^_]+__v-0$/,
    'another participant layout must keep its own fixed base pose and key');
  settingsNodes = collectNodes();
  const regenerationCount = generatedRequests.length;
  const previousPortraitUrl = portraitImage.src;
  let renderedPortraitUrl = '';
  portraitImage.__reactFiberTest = { memoizedState: { memoizedState: previousPortraitUrl,
    queue: { dispatch(url) { renderedPortraitUrl = url; portraitImage.src = url; } }, next: null } };
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('현재 이미지 재생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(generatedRequests.length, regenerationCount + 1);
  assert.equal(generatedRequests.at(-1).bypassCache, true);
  assert.equal(generatedRequests.at(-1).imageKey, addedPositionRequest.imageKey,
    'regenerating after inspecting the portrait should replace the selected variant instead of a missing base variant');
  assert.match(renderedPortraitUrl, /[?&]aip_refresh=\d+_\d+$/,
    'regeneration should update the React image state with a fresh display URL');
  assert.equal(renderedPortraitUrl.split('?')[0], previousPortraitUrl,
    'the persisted image URL should remain canonical');
  delete portraitImage.__reactFiberTest;
  portraitImage.src = previousPortraitUrl;

  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('정상위')).props.onclick();
  settingsNodes = collectNodes();
  groupSlotSelect = settingsNodes.find(node => node.tag === 'select' && node.props['data-position-group-slot'] === '0');
  groupSlotSelect.props.onchange({ currentTarget: { value: 'm' } });
  settingsNodes = collectNodes();
  groupSlotSelect = settingsNodes.find(node => node.tag === 'select' && node.props['data-position-group-slot'] === '0');
  assert.equal(groupSlotSelect.children.find(option => option.props?.value === 'm').props.selected, true,
    'mouth placement must remain selectable after another placement');
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('이 상황에 고정 추가')).props.onclick();
  assert.equal(savedSettings.positionRules['scene-patron_sex|grp-1|gslot-m'].length, 2,
    'one situation should retain multiple fixed position and placement combinations');
  vm.runInContext('Math.random = () => 0.999', vmContext);
  const randomSceneKey = sceneKey.replace('__v-0', '__v-8');
  const randomFixedKey = hooks.imageKey.after(randomSceneKey, [wife]);
  assert.match(randomFixedKey, /__position-missionary-slots-m-[^_]+__v-8$/,
    'fixed prompt combinations must use a pose-specific image key');
  const randomFixedPrompt = hooks.imagePrompt.after({ ...positionBase, key: randomSceneKey }, [wife]);
  assert.equal(randomFixedPrompt.key, randomFixedKey,
    'the random choice must stay stable between image key and prompt construction');
  assert.match(randomFixedPrompt.prompt, /missionary.*woman lying on her back/);
  assert.match(randomFixedPrompt.prompt, /\(fellatio:1\.1\)/);

  const changedOnlyKey = sceneKey.replace('scene-patron_sex', 'scene-guest_sex');
  activePortraitKey = changedOnlyKey;
  hooks.imagePrompt.after({ ...positionBase, key: changedOnlyKey }, [wife]);
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('복와위')).props.onclick();
  settingsNodes = collectNodes();
  groupSlotSelect = settingsNodes.find(node => node.tag === 'select' && node.props['data-position-group-slot'] === '0');
  groupSlotSelect.props.onchange({ currentTarget: { value: 'h' } });
  settingsNodes = collectNodes();
  assert.equal(savedSettings.positionRules['scene-guest_sex|grp-1|gslot-m'], undefined,
    'changing values must not silently fix the position to the situation');
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('이미지 추가 생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  const competingMultiPersonKey = changedOnlyKey.replace('__gslot-m', '__gslot-w');
  hooks.imagePrompt.after({ ...positionBase, key: competingMultiPersonKey }, [wife]);
  const changedRuntimeKey = changedOnlyKey.replace('mood-shy', 'mood-happy');
  rows = [{ kind: 'spent', characterId: 'wife', urgency: 50 }];
  const changedOnlyAddedKey = hooks.imageKey.after(changedRuntimeKey, [wife]);
  assert.equal(changedOnlyAddedKey, generatedRequests.at(-1).imageKey,
    'a one-minute state-key change must keep the exact generated image and its native list');
  const originalMoodAddedKey = hooks.imageKey.after(changedOnlyKey, [wife]);
  assert.deepEqual([...api.fn('imageVariantState')(originalMoodAddedKey).variants], [originalMoodAddedKey],
    'the new pose list must not fall back to the original image');
  assert.equal(hooks.imageKey.after(changedRuntimeKey, [wife]), changedOnlyAddedKey,
    'the added image must remain selected after the final key is settled');
  activePortraitKey = changedOnlyAddedKey;
  assert.equal(hooks.imagePrompt.after({ ...positionBase, key: changedRuntimeKey }, [wife]).key, changedOnlyAddedKey);
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('정상위')).props.onclick();
  settingsNodes = collectNodes();
  const afterMinuteGenerationCount = generatedRequests.length;
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('이미지 추가 생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(generatedRequests.length, afterMinuteGenerationCount + 1);
  const afterMinuteRequest = generatedRequests.at(-1);
  assert.match(afterMinuteRequest.prompt, /missionary.*woman lying on her back/,
    'changing pose after a state update must change the next generation prompt');
  assert.match(afterMinuteRequest.imageKey, /__aip-att-handjob-anatomy-v1_att-spent_state-expression-v2__position-missionary-slots-h-[^_]+__v-4$/,
    'generation after a state or pose change must use a new image key');
  assert.notEqual(afterMinuteRequest.imageKey, changedOnlyAddedKey);
  assert.deepEqual([...api.fn('imageVariantState')(afterMinuteRequest.imageKey).variants],
    [afterMinuteRequest.imageKey],
    'a state and pose change must not cycle through stale images');
  rows = [];
  activePortraitKey = afterMinuteRequest.imageKey;
  hooks.imagePrompt.after({ ...positionBase, key: changedOnlyKey }, [wife]);
  settingsNodes = collectNodes();
  const personPromptEditor = settingsNodes.find(node => node.tag === 'textarea'
    && node.props['data-position-person-prompt-preview'] === '');
  assert.equal(personPromptEditor.props.readOnly, undefined);
  assert.match(personPromptEditor.props.value, /primary man/);
  personPromptEditor.props.oninput({ currentTarget: { value: 'manual_person_marker, woman seated facing camera' } });
  settingsBody.replaceChildren();
  settingsRenderer(settingsBody, settingsWin);
  settingsNodes = collectNodes();
  assert.equal(settingsNodes.find(node => node.props?.['data-position-person-prompt-preview'] === '').props.value,
    'manual_person_marker, woman seated facing camera', 'the edited prompt should survive a settings refresh');
  const editedPersonGenerationCount = generatedRequests.length;
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('현재 이미지 재생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(generatedRequests.length, editedPersonGenerationCount + 1);
  assert.match(generatedRequests.at(-1).prompt, /manual_person_marker, woman seated facing camera/);
  assert.doesNotMatch(generatedRequests.at(-1).prompt, /\(primary man:1\.05\)|\(first supporting man:1\.0\)/,
    'the manual person prompt must replace generated person tags, not append to them');
  assert.equal(savedModData.positionOverrides['scene-guest_sex|grp-1|gslot-m'].personPrompt,
    'manual_person_marker, woman seated facing camera');
  savedModData = JSON.parse(JSON.stringify(savedModData));
  const restoredEditedPersonPrompt = hooks.imagePrompt.after({ ...positionBase, key: changedOnlyKey }, [wife]);
  assert.match(restoredEditedPersonPrompt.prompt, /manual_person_marker/,
    'the edited person prompt should remain in the generated prompt after save serialization');
  savedModData.positionOverrides['scene-guest_sex|grp-1|gslot-m'].personPrompt = 'reworded_person_marker';
  const rewordedPersonPrompt = hooks.imagePrompt.after({ ...positionBase, key: changedOnlyKey }, [wife]);
  assert.equal(rewordedPersonPrompt.key, restoredEditedPersonPrompt.key,
    'rewording people without changing their selected position must keep the image key');
  assert.match(rewordedPersonPrompt.prompt, /reworded_person_marker/);
  savedModData.positionOverrides['scene-guest_sex|grp-1|gslot-m'].personPrompt = 'manual_person_marker, woman seated facing camera';
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'select' && node.props['data-position-person-preset'] === 'main')
    .props.onchange({ currentTarget: { value: 'paizuri' } });
  settingsNodes = collectNodes();
  assert.doesNotMatch(settingsNodes.find(node => node.props?.['data-position-person-prompt-preview'] === '').props.value,
    /manual_person_marker/, 'changing a person preset should restore the automatically combined prompt');
  const customOnlySceneKey = changedOnlyKey.replace('scene-guest_sex', 'scene-unlisted_action')
    .replace('__grp-1__gslot-m', '');
  activePortraitKey = customOnlySceneKey;
  hooks.imagePrompt.after({ ...positionBase, key: customOnlySceneKey }, [wife]);
  settingsWin.refresh();
  settingsNodes = collectNodes();
  const emptyPersonEditor = settingsNodes.find(node => node.props?.['data-position-person-prompt-preview'] === '');
  assert.equal(emptyPersonEditor.props.value, '', 'the person prompt should be editable without choosing a preset');
  emptyPersonEditor.props.onchange({ currentTarget: { value: 'manual_only_person_marker' } });
  settingsNodes = collectNodes();
  const customOnlyGenerate = settingsNodes.find(node => node.tag === 'button'
    && node.children.includes('현재 이미지 재생성'));
  assert.equal(customOnlyGenerate.props.options.disabled, false);
  const customOnlyGenerationCount = generatedRequests.length;
  customOnlyGenerate.props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(generatedRequests.length, customOnlyGenerationCount + 1);
  assert.match(generatedRequests.at(-1).prompt, /manual_only_person_marker/);
  assert.match(generatedRequests.at(-1).imageKey, /__position-person-custom-[^_]+__v-0$/,
    'a custom person prompt must not reuse the unmodified scene image');
  assert.equal(savedModData.positionOverrides['scene-unlisted_action'].personPrompt, 'manual_only_person_marker');
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('이 상황에 고정 추가')).props.onclick();
  assert.equal(savedSettings.positionRules['scene-unlisted_action'][0].personPrompt, 'manual_only_person_marker');
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('현재 체위 변경 취소')).props.onclick();
  const fixedManualPrompt = hooks.imagePrompt.after({ ...positionBase,
    key: customOnlySceneKey.replace('__v-0', '__v-1') }, [wife]);
  assert.match(fixedManualPrompt.prompt, /manual_only_person_marker/,
    'a fixed situation should reuse its edited person prompt on another image variant');
  activePortraitKey = fixedManualPrompt.key;
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.props?.['data-position-state-prompt'] === '')
    .props.onchange({ currentTarget: { value: 'state_only_positive_marker' } });
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.props?.['data-position-state-negative-prompt'] === '')
    .props.onchange({ currentTarget: { value: 'state_only_negative_marker' } });
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.props?.['data-position-state-only'] === '')
    .props.onchange({ currentTarget: { checked: true } });
  const stateOnlyGenerationCount = generatedRequests.length;
  settingsNodes = collectNodes();
  settingsNodes.find(node => node.tag === 'button' && node.children.includes('현재 이미지 재생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(generatedRequests.length, stateOnlyGenerationCount + 1);
  const stateOnlyGenerated = generatedRequests.at(-1);
  assert.match(stateOnlyGenerated.imageKey, /__aip-[^_]*state-scene-prompt-[^_]+__v-1$/,
    'the state-only prompt must have a separate image key');
  assert.match(stateOnlyGenerated.prompt, /state_only_positive_marker/);
  assert.match(stateOnlyGenerated.negativePrompt, /state_only_negative_marker/);
  assert.doesNotMatch(stateOnlyGenerated.prompt, /manual_only_person_marker/,
    'manual regeneration with state-only enabled must exclude the fixed person prompt');
  assert.equal(hooks.imageKey.after(customOnlySceneKey.replace('__v-0', '__v-1'), [wife]),
    stateOnlyGenerated.imageKey, 'a saved state-only result should be found by its exact image key');
  savedSettings.positionStatePrompts['scene-unlisted_action'].positivePrompt = 'edited_state_only_marker';
  assert.equal(hooks.imageKey.after(customOnlySceneKey.replace('__v-0', '__v-1'), [wife]), stateOnlyGenerated.imageKey,
    'editing only the state prompt must preserve the selected variant');
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: customOnlySceneKey.replace('__v-0', '__v-1') }, [wife]).prompt,
    /edited_state_only_marker/);
  activePortraitKey = '';

  savedSettings = {};
  rows = [];
  wife.stats = { energy: 50, mood: 10, arousal: 0 };
  wife.feelings = [];
  wife.intoxication.level = 0;
  driveState = { financial: 0, approval: 0, desire: 0, security: 0, social: 0, pride: 0, longing: 0 };
  delete wife.situationStats;
  const groupedDistressKey = hooks.imageKey.after(sceneKey, [wife]);
  wife.stats.mood = 30;
  wife.feelings = [{ emotion: 'anger', intensity: 50 }];
  driveState.security = 50;
  const groupedDistressVariantKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.equal(groupedDistressVariantKey, groupedDistressKey,
    'visually similar detailed stat, feeling, and drive combinations should share one image key');
  const legacyDetailLookupKeys = [];
  const legacyDetailImage = await hooks.imageLookup.around(async key => {
    legacyDetailLookupKeys.push(key);
    return legacyDetailLookupKeys.length === 2 ? { talentName: key, imagePath: 'legacy-detail.webp' } : null;
  }, groupedDistressVariantKey);
  assert.equal(legacyDetailLookupKeys[0], groupedDistressVariantKey);
  assert.notEqual(legacyDetailLookupKeys[1], groupedDistressVariantKey,
    'a grouped key should try its former exact-detail cache key before generating');
  assert.equal(legacyDetailImage?.talentName, legacyDetailLookupKeys[1]);
  hooks.imagePrompt.after({ ...base, key: sceneKey }, [wife]);
  const v2ContentLookupKeys = [];
  const v2ContentImage = await hooks.imageLookup.around(async key => {
    v2ContentLookupKeys.push(key);
    return key.includes('__content-') ? { talentName: key, imagePath: 'old-content.webp' } : null;
  }, groupedDistressVariantKey);
  assert.match(v2ContentLookupKeys[1], /__content-[0-9a-f]{16}__v-0$/);
  assert.equal(v2ContentImage?.imagePath, 'old-content.webp',
    'an existing prompt-identical content image should remain readable through the v2 situation key');

  savedSettings = { groupSimilarDetailStates: false };
  wife.stats.mood = 10;
  wife.feelings = [];
  driveState.security = 0;
  const exactDistressKey = hooks.imageKey.after(sceneKey, [wife]);
  wife.stats.mood = 30;
  wife.feelings = [{ emotion: 'anger', intensity: 50 }];
  driveState.security = 50;
  const exactDistressVariantKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.notEqual(exactDistressVariantKey, exactDistressKey,
    'turning grouping off should restore per-combination detailed-state keys');

  savedSettings = {
    groupSimilarDetailStates: true,
    prompts: { 'status.mood.0': 'custom gloomy expression' },
  };
  wife.stats.mood = 10;
  wife.feelings = [];
  driveState.security = 0;
  assert.equal(hooks.imageKey.after(sceneKey, [wife]), groupedDistressKey,
    'editing detailed-state prompt text must keep the grouped situation key');

  savedSettings = {
    groupSimilarDetailStates: true,
    negativePrompts: {
      'jewelry.breasts.1': 'right nipple piercing, two nipple piercings, choker, heart choker, heart-shaped choker, black leather choker, slave collar, neck restraint, neck shackle, chain around neck',
      'jewelry.breasts.2': 'single nipple piercing, missing nipple piercing, choker, heart choker, heart-shaped choker, black leather choker, slave collar, neck restraint, neck shackle, chain around neck',
    },
  };
  wife.stats.mood = 50;
  const groupedExposedSceneKey = sceneKey.replace(/__exp-[01]{7}/, '__exp-1111111');
  const hStatusChokerPrompt = 'a heart-shaped choker fitted around her neck';
  const hStatusPortrait = {
    ...base,
    key: groupedExposedSceneKey,
    prompt: `${base.prompt}, matching metal nipple jewelry on both breasts, ${hStatusChokerPrompt}`,
    parts: [{ label: '상태', tags: `matching metal nipple jewelry on both breasts, ${hStatusChokerPrompt}` }],
  };
  wife.situationStats = { jewelryState: { breasts: { stage: 1 }, vulva: { stage: 0 } } };
  const singlePiercingKey = hooks.imageKey.after(groupedExposedSceneKey, [wife]);
  const singlePiercingPrompt = hooks.imagePrompt.after(hStatusPortrait, [wife]);
  assert.doesNotMatch(singlePiercingPrompt.prompt, /matching metal nipple jewelry on both breasts/);
  assert.match(singlePiercingPrompt.prompt, /single_nipple_piercing/,
    'an exposed stage-1 portrait should describe only one piercing');
  assert.doesNotMatch(singlePiercingPrompt.prompt, /a heart-shaped choker fitted around her neck/);
  assert.equal(singlePiercingPrompt.parts.some(part => part.tags.includes(hStatusChokerPrompt)), false,
    'breast jewelry stage 1 should remove the H-Status choker from inspectable Positive parts');
  assert.equal(singlePiercingPrompt.negativePrompt.split(',').filter(tag => tag.trim() === hStatusChokerPrompt).length, 1,
    'breast jewelry stage 1 should negate the exact choker phrase injected by H-Status once');
  const clothedPortrait = { ...hStatusPortrait, key: sceneKey };
  const clothedSinglePrompt = hooks.imagePrompt.after(clothedPortrait, [wife]);
  assert.doesNotMatch(clothedSinglePrompt.prompt, /matching metal nipple jewelry on both breasts|single_nipple_piercing/,
    'covered breasts should not show the stage-1 jewelry in the image prompt');
  assert.equal(clothedSinglePrompt.parts.some(part => /matching metal nipple jewelry on both breasts|single_nipple_piercing/.test(part.tags)), false,
    'covered jewelry must also disappear from inspectable Positive parts');
  wife.situationStats.jewelryState.breasts.stage = 2;
  const doublePiercingKey = hooks.imageKey.after(groupedExposedSceneKey, [wife]);
  const coveredDoublePiercingKey = hooks.imageKey.after(sceneKey, [wife]);
  const doublePiercingPrompt = hooks.imagePrompt.after(hStatusPortrait, [wife]);
  assert.match(doublePiercingPrompt.prompt, /matching metal nipple jewelry on both breasts/,
    'an exposed stage-2 portrait should keep bilateral jewelry');
  assert.doesNotMatch(doublePiercingPrompt.prompt, /a heart-shaped choker fitted around her neck/);
  assert.equal(doublePiercingPrompt.parts.some(part => part.tags.includes(hStatusChokerPrompt)), false,
    'breast jewelry stage 2 should remove the H-Status choker from inspectable Positive parts');
  assert.equal(doublePiercingPrompt.negativePrompt.split(',').filter(tag => tag.trim() === hStatusChokerPrompt).length, 1,
    'breast jewelry stage 2 should negate the exact choker phrase injected by H-Status once');
  assert.doesNotMatch(hooks.imagePrompt.after(clothedPortrait, [wife]).prompt,
    /matching metal nipple jewelry on both breasts|pierced_nipples/,
    'covered breasts should not show stage-2 jewelry');
  assert.notEqual(doublePiercingKey, singlePiercingKey,
    'piercing stages must remain distinct while detailed-state grouping is enabled');
  wife.situationStats.jewelryState.breasts.stage = 3;
  const coveredChokerKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.match(coveredChokerKey, /__aip-jewel-choker__v-0$/);
  assert.notEqual(coveredChokerKey, coveredDoublePiercingKey,
    'a visible choker needs its own situation even when breast jewelry is covered');
  const chokerEquippedPrompt = hooks.imagePrompt.after(hStatusPortrait, [wife]);
  assert.match(chokerEquippedPrompt.prompt, /matching metal nipple jewelry on both breasts/);
  assert.match(chokerEquippedPrompt.prompt, /a heart-shaped choker fitted around her neck/,
    'breast jewelry stage 3 should preserve the H-Status choker Positive prompt');
  assert.equal(chokerEquippedPrompt.negativePrompt.split(',').filter(tag => tag.trim() === hStatusChokerPrompt).length, 0,
    'breast jewelry stage 3 should not negate its equipped choker');
  const clothedChokerPrompt = hooks.imagePrompt.after(clothedPortrait, [wife]);
  assert.doesNotMatch(clothedChokerPrompt.prompt, /matching metal nipple jewelry on both breasts|pierced_nipples/);
  assert.match(clothedChokerPrompt.prompt, /a heart-shaped choker fitted around her neck/,
    'a neck accessory can remain visible when the breasts are covered');

  delete wife.situationStats;
  wife.stats.mood = 10;
  const eggToyKey = hooks.imageKey.after(sceneKey.replace(/__v-0$/, '__toy-vibe-egg__v-0'), [wife]);
  const penisToyKey = hooks.imageKey.after(sceneKey.replace(/__v-0$/, '__toy-vibe-penis__v-0'), [wife]);
  assert.notEqual(penisToyKey, eggToyKey,
    'H Status toy types in the native portrait key must remain distinct while grouping is enabled');

  savedSettings = {};
  rows = [{ kind: 'spent', characterId: 'wife', urgency: 50 }];
  wife.stats = { energy: 50, mood: 50, arousal: 0 };
  wife.feelings = [];
  driveState = { financial: 0, approval: 0, desire: 0, security: 0, social: 0, pride: 0, longing: 0 };
  const spentImageKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.match(spentImageKey, /__aip-att-spent_state-expression-v2__v-0$/, 'active situations should have readable codes');
  rows = [{ kind: 'spent', characterId: 'wife', urgency: 50 }, { kind: 'escalation', characterId: 'wife' }];
  const multiAttentionKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.match(multiAttentionKey, /__aip-att-escalation_att-spent_state-expression-v2__v-0$/);
  rows.reverse();
  assert.equal(hooks.imageKey.after(sceneKey, [wife]), multiAttentionKey,
    'the same active situations must use one tag order regardless of detection order');
  rows = [{ kind: 'spent', characterId: 'wife', urgency: 50 }];
  savedSettings = { prompts: { 'attention.spent': 'first marker, second marker' } };
  const firstPromptOrder = hooks.imagePrompt.after(base, [wife]);
  savedSettings.prompts['attention.spent'] = 'second marker, first marker';
  assert.equal(hooks.imageKey.after(sceneKey, [wife]), spentImageKey,
    'reordering Positive tags must not change the situation image list');
  const secondPromptOrder = hooks.imagePrompt.after(base, [wife]);
  assert.ok(firstPromptOrder.prompt.indexOf('first marker') < firstPromptOrder.prompt.indexOf('second marker'));
  assert.ok(secondPromptOrder.prompt.indexOf('second marker') < secondPromptOrder.prompt.indexOf('first marker'));
  savedSettings = {};
  assert.notEqual(spentImageKey, sceneKey);
  rows = [{ kind: 'spent', characterId: 'wife', urgency: -40 }];
  assert.doesNotMatch(hooks.imageKey.after(sceneKey, [wife]), /att-spent/,
    'a low-urgency spent row from the translated game must not mark a healthy wife as exhausted');
  assert.doesNotMatch(hooks.imagePrompt.after(base, [wife]).prompt, /exhausted/);
  rows = [{ kind: 'spent', characterId: 'wife', urgency: 50 }];
  const nearestFallback = { talentName: sceneKey, imagePath: 'old.webp' };
  const nearestResidue = { talentName: 'situation_fluid__elena__mouth__stage-0', imagePath: 'residue-old.webp' };
  assert.equal(await hooks.imageLookup.around(async () => nearestResidue, residueBaseKey), null,
    'a residue cache miss must generate instead of accepting a similar status image');
  const exactResidue = { talentName: residueBaseKey, imagePath: 'residue-exact.webp' };
  assert.equal(await hooks.imageLookup.around(async () => exactResidue, residueBaseKey), exactResidue,
    'an exact residue cache entry should be reused after reload');
  const residueVariantKey = `${residueBaseKey}__v-1700000000000`;
  assert.equal(await hooks.imageLookup.around(async () => exactResidue, residueVariantKey), null,
    'a manual residue regeneration must create its own selectable variant');
  const stateLookupKeys = [];
  assert.equal(await hooks.imageLookup.around(async key => {
    stateLookupKeys.push(key);
    return key === sceneKey ? nearestFallback : null;
  }, spentImageKey), null, 'an added state prompt must generate when its exact image is missing');
  assert.equal(stateLookupKeys[0], spentImageKey);
  assert.ok(stateLookupKeys.length >= 2,
    'a missing v2 situation should check its compatible saved keys before generating');
  assert.ok(stateLookupKeys.some(key => key.includes('__aipk-')),
    'a missing v2 situation should also check its bounded generation key');
  const exactStateImage = { talentName: spentImageKey, imagePath: 'state.webp' };
  assert.equal(await hooks.imageLookup.around(async () => exactStateImage, spentImageKey), exactStateImage,
    'an exact state image should still be reused');
  assert.equal(await hooks.imageLookup.around(async () => nearestFallback, sceneKey), nearestFallback,
    'ordinary image lookup fallback should remain unchanged');
  const ordinaryVariantKey = spentImageKey.replace(/__v-0$/, '__v-1');
  assert.equal(await hooks.imageLookup.around(async () => nearestFallback, ordinaryVariantKey), null,
    'every variant with an added state prompt should require an exact image');
  const addedVariantKey = spentImageKey.replace(/__v-0$/, '__v-4');
  assert.equal(await hooks.imageLookup.around(async () => exactStateImage, addedVariantKey), null,
    'the add-image variant must generate unless its exact key exists');
  const exactAddedVariant = { talentName: addedVariantKey, imagePath: 'added.webp' };
  assert.equal(await hooks.imageLookup.around(async () => exactAddedVariant, addedVariantKey), exactAddedVariant,
    'an existing add-image variant should be reused after reload');
  wife.generatedArchetype = { attentionImagePrompt: {
    positivePrompt: 'custom_face', negativePrompt: 'default_negative', mode: 'replace', imagePolicy: 'reuse',
  } };
  const customWifeStateKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.equal(customWifeStateKey, spentImageKey,
    'a custom-wife prompt edit should not change the active situation key');
  assert.equal(await hooks.imageLookup.around(async () => nearestFallback, customWifeStateKey), null,
    'custom-wife state prompts must not reuse the unchanged sleeping or scene image');
  delete wife.generatedArchetype;
  const spent = hooks.imagePrompt.after({ ...base, key: spentImageKey }, [wife]);
  assert.match(spent.prompt, /exhausted/);
  assert.equal(spent.negativePrompt, 'base_negative, tattoo, piercing');
  assert.equal(spent.key, spentImageKey, 'imagePrompt must not append the state twice');
  assert.equal(spent.parts[0].label, '대응 필요 상황');
  const repeatedSpent = hooks.imagePrompt.after(spent, [wife]);
  assert.equal(repeatedSpent.parts.filter(part => part.label === '대응 필요 상황').length, 1,
    'reprocessing a prompt must not duplicate the attention section');
  rows = [];
  const clearedSpent = hooks.imagePrompt.after(spent, [wife]);
  assert.equal(clearedSpent.parts.some(part => part.label === '대응 필요 상황'), false,
    'a cleared attention state must remove the previous section');
  assert.doesNotMatch(clearedSpent.prompt, /exhausted/,
    'a cleared attention state must remove its previous prompt tag');
  rows = [{ kind: 'spent', characterId: 'wife', urgency: 50 }];

  savedSettings = {
    prompts: { 'attention.spent': '' },
    negativePrompts: { 'attention.spent': 'blurry_hands' },
  };
  const negativeImageKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.notEqual(negativeImageKey, spentImageKey,
    'disabling the exhausted Positive must not reuse an image with the corrected tired expression');
  assert.match(negativeImageKey, /__aip-att-spent__v-0$/);
  const negativeSpent = hooks.imagePrompt.after(base, [wife]);
  assert.equal(negativeSpent.prompt, 'portrait');
  assert.match(negativeSpent.negativePrompt, /base_negative/);
  assert.match(negativeSpent.negativePrompt, /blurry_hands/);
  assert.equal(negativeSpent.parts.some(part => String(part.label).startsWith('Negative')), false,
    'Negative-only state tags must stay out of Positive portrait parts');
  savedSettings = {};

  const nudeSceneKey = sceneKey.replace('outfit-modest', 'outfit-nude');
  const partialSceneKey = sceneKey.replace('outfit-modest', 'outfit-panties_only');
  wife.outfit = 'nude';
  savedSettings = {
    prompts: { 'attention.spent': 'outfit_limited_prompt' },
    outfitStates: { 'attention.spent': ['partial'] },
  };
  assert.equal(hooks.imageKey.after(sceneKey, [wife]), sceneKey,
    'the image-key outfit must prevent a partial-only prompt on a fully clothed image');
  assert.equal(hooks.imageKey.after(nudeSceneKey, [wife]), nudeSceneKey,
    'a partial-only prompt must not apply to a nude image');
  assert.match(hooks.imageKey.after(partialSceneKey, [wife]), /__aip-att-spent_state-expression-v2__v-0$/,
    'a partial-only prompt should apply to an underwear image');
  assert.deepEqual(hooks.imagePrompt.after({ ...base, key: sceneKey }, [wife]), { ...base, key: sceneKey });
  assert.match(hooks.imagePrompt.after({ ...base, key: partialSceneKey }, [wife]).prompt, /outfit_limited_prompt/);
  savedSettings.outfitStates['attention.spent'] = ['clothed'];
  assert.match(hooks.imageKey.after(sceneKey, [wife]), /__aip-att-spent_state-expression-v2__v-0$/,
    'a fully-clothed-only prompt should apply to a modest outfit');
  assert.equal(hooks.imageKey.after(partialSceneKey, [wife]), partialSceneKey,
    'a fully-clothed-only prompt must not apply to partial clothing');
  assert.equal(hooks.imageKey.after(nudeSceneKey, [wife]), nudeSceneKey,
    'a fully-clothed-only prompt must not apply to a nude image');
  savedSettings = {
    prompts: { 'attention.spent': 'legacy_outfit_prompt' },
    outfitModes: { 'attention.spent': 'nude' },
  };
  assert.match(hooks.imageKey.after(nudeSceneKey, [wife]), /__aip-att-spent_state-expression-v2__v-0$/,
    'legacy nude-only settings should remain compatible');
  delete wife.outfit;
  savedSettings = {};

  rows = [{ kind: 'spent', characterId: 'someone-else', urgency: 50 }];
  assert.equal(hooks.imageKey.after(sceneKey, [wife]), sceneKey);
  assert.equal(hooks.imagePrompt.after(base, [wife]), base);

  state.modData.BadGuest = {
    restraint: { active: false, afterUntilSlot: 120 },
  };
  const restrainedImageKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.notEqual(restrainedImageKey, spentImageKey, 'a changed state must request a different image key');
  const restrained = hooks.imagePrompt.after(base, [wife]);
  for (const tag of [
    'only female restrained', 'handcuffed woman', 'wrists cuffed together',
    'short chain', 'men unrestrained',
  ]) assert.match(restrained.prompt, new RegExp(tag));
  assert.doesNotMatch(restrained.prompt, /behind[_ ]back|in front/i,
    'the default should keep the restrained woman\'s joined hand position unspecified');
  for (const tag of ['handcuffed man', 'male wrists bound', 'shared handcuffs']) {
    assert.match(restrained.negativePrompt, new RegExp(tag));
  }
  const cuffedHandjob = hooks.imagePrompt.after({ ...characterBase, key: handjobSceneKey }, [wife]);
  assert.match(cuffedHandjob.prompt, /handcuffed woman giving handjob/);
  assert.match(cuffedHandjob.prompt, /female cuffed wrists held together in front of her body/);
  assert.match(cuffedHandjob.prompt, /his penis rooted at his own groin/);
  assert.match(cuffedHandjob.negativePrompt, /girl with penis, penis attached to woman/);
  assert.match(cuffedHandjob.key, /handjob-anatomy-v1/);
  assert.equal(cuffedHandjob.parts.filter(part => part.label === '손 자극 해부 구분').length, 1);
  assert.equal(cuffedHandjob.parts.filter(part => part.label === '수갑 남성 손 자극').length, 1);
  assert.equal(hooks.imagePrompt.after(cuffedHandjob, [wife]).parts.filter(part => part.label === '손 자극 해부 구분').length, 1,
    'reprocessing must not duplicate the anatomy cue');
  assert.doesNotMatch(hooks.imagePrompt.after({ ...characterBase, key: sceneKey }, [wife]).prompt,
    /handcuffed woman giving handjob/, 'a non-handjob scene must not receive the handjob cue');
  const cuffedSupportingHandjob = hooks.imagePrompt.after({ ...characterBase, key: sceneKey.replace('__gslot-m', '__gslot-h') }, [wife]);
  assert.match(cuffedSupportingHandjob.prompt, /handcuffed woman giving handjob/,
    'a handjob role for an additional man should also receive the cuff cue');

  savedSettings = {
    prompts: { 'restraint.handcuffed': legacyHandcuffPrompt },
    negativePrompts: { 'restraint.handcuffed': legacyHandcuffNegativePrompt },
  };
  const migratedRestraint = hooks.imagePrompt.after(base, [wife]);
  assert.match(migratedRestraint.prompt, /only female restrained/,
    'the former built-in handcuff prompt stored in the browser should migrate');
  assert.doesNotMatch(migratedRestraint.prompt, /hands_behind_back|wrists_bound_behind_back/);
  assert.match(migratedRestraint.negativePrompt, /male wrists bound/);

  savedSettings = { prompts: { 'restraint.handcuffed': 'custom_cuffs' } };
  const customizedImageKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.equal(customizedImageKey, restrainedImageKey, 'editing the handcuff prompt must keep the same restraint situation key');
  const customized = hooks.imagePrompt.after(base, [wife]);
  assert.match(customized.prompt, /custom_cuffs/);
  assert.doesNotMatch(customized.prompt, /metal_handcuffs/);

  savedSettings = {};
  rows = [];
  state.modData.BadGuest.restraint.afterUntilSlot = 90;
  assert.doesNotMatch(hooks.imagePrompt.after({ ...characterBase, key: handjobSceneKey }, [wife]).prompt,
    /handcuffed woman giving handjob/, 'the cue must stop when the visible restraint expires');
  assert.match(hooks.imagePrompt.after({ ...characterBase, key: handjobSceneKey }, [wife]).prompt,
    /his penis rooted at his own groin/, 'the anatomy guard must also cover unrestrained handjob scenes');
  driveState = { ...driveState, desire: 50 };
  wife.stats.arousal = 70;
  wife.situationStats = {
    fluidState: { mouth: 3, breasts: 0, uterus: 2, thighs: 6 },
    jewelryState: { breasts: { stage: 3 }, vulva: { stage: 1 }, vibe: { type: 'egg', suspension: null } },
  };
  const fullyExposedSceneKey = sceneKey.replace(/__exp-[01]{7}/, '__exp-1111111');
  const fluid = hooks.imagePrompt.after({ ...base, key: fullyExposedSceneKey }, [wife]);
  const fluidSituationKey = hooks.imageKey.after(fullyExposedSceneKey, [wife]);
  assert.equal(fluid.key, fluidSituationKey);
  const studioSourceKey = fullyExposedSceneKey.replace('__v-0', `__bd-hccpctci__erostat-${'x'.repeat(12)}__v-0`);
  const studioKey = hooks.imageKey.after(studioSourceKey, [wife]);
  const studioPrompt = hooks.imagePrompt.after({ ...base, key: studioSourceKey }, [wife]);
  assert.equal(studioPrompt.key, studioKey, 'the ImageStudio plan and live portrait must share the bounded key');
  assert.match(studioKey, /__outfit-modest__room-taproom__/, 'the plan must keep its selectable outfit and room');
  assert.match(studioKey, /__aipk-[a-z0-9]+/, 'long AIP state tags must be compact before the planner queues them');
  assert.ok(Buffer.byteLength(`${studioKey}_portrait_00001_.png`) < 255);
  assert.equal(hooks.imageKey.after(studioKey, [wife]), studioKey);
  const crowdedStudioKey = hooks.imagePrompt.after({ ...base,
    key: studioSourceKey.replace('x'.repeat(12), 'x'.repeat(48)) }, [wife]).key;
  assert.match(crowdedStudioKey, /__outfit-modest__room-taproom__/,
    'even a longer base key must keep the ImageStudio planner selection fields');
  assert.ok(Buffer.byteLength(`${crowdedStudioKey}_portrait_00001_.png`) < 255);
  assert.equal(hooks.imageKey.after(crowdedStudioKey, [wife]), crowdedStudioKey);
  wife.situationStats.fluidState.uterus = 1;
  assert.notEqual(hooks.imageKey.after(studioSourceKey, [wife]), studioKey,
    'distinct fluid states must not share a shortened image key');
  wife.situationStats.fluidState.uterus = 2;
  const previousKeyLookups = [];
  const oldLongImage = await hooks.imageLookup.around(async key => {
    previousKeyLookups.push(key);
    return key.length > 220 && key.includes('__aip-')
      ? { talentName: key, imagePath: 'previous-long-name.webp',
        prompt: 'saved positive', negativePrompt: 'saved negative' } : null;
  }, studioKey);
  assert.equal(oldLongImage?.imagePath, 'previous-long-name.webp',
    'an image saved under the earlier full key must remain reachable');
  assert.equal(oldLongImage?.prompt, 'saved positive');
  assert.equal(oldLongImage?.negativePrompt, 'saved negative');
  assert.ok(previousKeyLookups.some(key => key.length > 220 && key.includes('__aip-')));
  const previousFullKey = previousKeyLookups.find(key => key.length > 220 && key.includes('__aip-'));
  const previousShortRequest = await hooks.imageGenerate.around(async request => request,
    { imageKey: previousFullKey, prompt: 'previous portrait', negativePrompt: '', bypassCache: true });
  const oldShortImage = { talentName: previousShortRequest.imageKey, imagePath: 'previous-short-name.webp',
    prompt: 'older positive', negativePrompt: 'older negative' };
  assert.match(oldShortImage.talentName, /__aipk-/);
  const foundOldShortImage = await hooks.imageLookup.around(async key => key === oldShortImage.talentName ? oldShortImage : null,
    studioKey);
  assert.equal(foundOldShortImage, oldShortImage, 'an image saved under the previous generated short key must remain reachable');
  assert.equal(foundOldShortImage?.prompt, 'older positive');
  assert.equal(foundOldShortImage?.negativePrompt, 'older negative');
  assert.equal(hooks.imageKey.after(fluidSituationKey, [wife]), fluidSituationKey,
    'the situation segment must not be duplicated when a key is read again');
  const tagOrder = ['state-', 'fluid-', 'jewel-', 'toy-'].map(tag => fluidSituationKey.indexOf(tag));
  assert.ok(tagOrder.every(index => index >= 0) && tagOrder.every((index, position) => !position || index > tagOrder[position - 1]),
    'multiple situation types must be serialized in the documented order');
  let v2GenerationRequest;
  await hooks.imageGenerate.around(async request => {
    v2GenerationRequest = request;
    return { url: 'https://example.test/v2.webp' };
  }, { imageKey: fluid.key, prompt: fluid.prompt, negativePrompt: fluid.negativePrompt });
  const v2GenerationKey = v2GenerationRequest.imageKey;
  assert.equal(v2GenerationRequest.prompt, fluid.prompt);
  assert.equal(v2GenerationRequest.negativePrompt, fluid.negativePrompt);
  assert.match(v2GenerationKey, /^pippa__scene-patron_sex__aipk-[a-z0-9]+__v-0$/);
  assert.ok(v2GenerationKey.length < 140, 'new generation must bound the ComfyUI filename prefix');
  const boundedImage = { talentName: v2GenerationKey, imagePath: 'bounded.webp' };
  assert.equal(await hooks.imageLookup.around(async key => key === v2GenerationKey ? boundedImage : null,
    fluid.key), boundedImage,
  'the full situation key must recover a generated short-key image after reload');
  imageManifestEntries[fluid.key] = { talentName: fluid.key, imagePath: 'existing-long.webp' };
  const preservedLongKey = await hooks.imageGenerate.around(async request => request,
    { imageKey: fluid.key, prompt: fluid.prompt, negativePrompt: fluid.negativePrompt });
  assert.equal(preservedLongKey.imageKey, fluid.key,
    'existing long-key images must remain reusable without migration');
  delete imageManifestEntries[fluid.key];
  const longOwner = `custom_${'a'.repeat(65)}`;
  const longOwnerKey = `${longOwner}__scene-patron_chatting__state-${'x'.repeat(80)}__aip-att-spent__v-0`;
  const longOwnerRequest = await hooks.imageGenerate.around(async request => request,
    { imageKey: longOwnerKey, prompt: 'adult portrait', negativePrompt: '', bypassCache: true });
  assert.ok(longOwnerRequest.imageKey.length < 140);
  assert.match(longOwnerRequest.imageKey, /^custom_a+-[a-z0-9]+__scene-patron_chatting__aipk-[a-z0-9]+__v-0$/);
  const otherLongOwnerKey = `${longOwner}b__scene-patron_chatting__state-${'x'.repeat(80)}__aip-att-spent__v-0`;
  const otherLongOwnerRequest = await hooks.imageGenerate.around(async request => request,
    { imageKey: otherLongOwnerKey, prompt: 'adult portrait', negativePrompt: '', bypassCache: true });
  assert.notEqual(longOwnerRequest.imageKey.split('__')[0], otherLongOwnerRequest.imageKey.split('__')[0],
    'long custom-wife names must not collapse into one generated image folder');
  const reportedLongKey = ['mara', 'scene-patron_intimate', 'outfit-modest', 'room-back_room',
    'mood-shy', 'exp-1001001', 'grp-1', 'gslot-x', 'bd-hccpctci', 'aip-att-escalation',
    'state-expression-v2', 'state-intoxicated', 'state-patron-distressed', 'fluid-uterus-1',
    'fluid-vulva-4', 'jewel-choker', 'jewel-vulva-1', 'v-0', 'toy-breast-3', 'vulva-1'].join('__');
  let reportedSubmittedKey = '';
  await hooks.imageGenerate.around(async request => {
    reportedSubmittedKey = request.imageKey;
    return { url: 'https://example.test/mara.webp' };
  }, { imageKey: reportedLongKey, prompt: 'patron intimate portrait', negativePrompt: '', bypassCache: true });
  assert.match(reportedSubmittedKey, /^mara__scene-patron_intimate__aipk-[a-z0-9]+__v-0$/);
  assert.ok(Buffer.byteLength(`${reportedSubmittedKey}_portrait_00001_.png`) < 255,
    'the reported 284-byte ComfyUI filename must be bounded before submission');
  const lateTaggedKey = `${studioKey}__toy-${'x'.repeat(145)}__fluid-vulva-4`;
  const disabledLateRequest = await hooks.imageGenerate.around(async request => request,
    { imageKey: lateTaggedKey, prompt: 'saved positive', negativePrompt: 'saved negative', bypassCache: true });
  assert.equal(disabledLateRequest.imageKey, lateTaggedKey, 'the new behavior must remain opt-in');
  setShortImageKeysFromUi(true);
  const oldLateImage = { talentName: lateTaggedKey, imagePath: 'old-late.webp',
    prompt: 'old positive', negativePrompt: 'old negative' };
  imageManifestEntries[lateTaggedKey] = oldLateImage;
  assert.equal(await hooks.imageLookup.around(async key => key === lateTaggedKey ? oldLateImage : null,
    lateTaggedKey), oldLateImage, 'enabling must still find an image made while disabled');
  const reusedLate = await hooks.imageGenerate.around(async request => request,
    { imageKey: lateTaggedKey, prompt: 'new positive', negativePrompt: 'new negative' });
  assert.equal(reusedLate.imageKey, lateTaggedKey, 'an existing full-key image must keep its original key');
  const oldLateBatch = await hooks.imageQueue.around(async entries => entries,
    [{ talentId: lateTaggedKey, prompt: 'old batch positive' }]);
  assert.equal(oldLateBatch[0].talentId, lateTaggedKey, 'batch requests must keep existing full-key images');
  delete imageManifestEntries[lateTaggedKey];
  const lateRequest = await hooks.imageGenerate.around(async request => request,
    { imageKey: lateTaggedKey, prompt: 'new positive', negativePrompt: 'new negative', bypassCache: true });
  assert.notEqual(lateRequest.imageKey, lateTaggedKey);
  assert.match(lateRequest.imageKey, /^pippa__scene-patron_sex__aipk-[a-z0-9]+__v-0$/);
  assert.ok(Buffer.byteLength(`${lateRequest.imageKey}_portrait_00001_.png`) < 200);
  assert.equal(lateRequest.prompt, 'new positive', 'only the transport key may change');
  assert.equal(lateRequest.negativePrompt, 'new negative');
  const otherLateRequest = await hooks.imageGenerate.around(async request => request,
    { imageKey: `${lateTaggedKey}__toy-extra`, prompt: 'new positive', negativePrompt: 'new negative', bypassCache: true });
  assert.notEqual(otherLateRequest.imageKey, lateRequest.imageKey, 'later mod tags must stay distinct');
  const shortLateImage = { talentName: lateRequest.imageKey, imagePath: 'late-short.webp',
    prompt: 'per-image positive', negativePrompt: 'per-image negative' };
  setShortImageKeysFromUi(false);
  const foundLate = await hooks.imageLookup.around(async key => key === shortLateImage.talentName ? shortLateImage : null,
    lateTaggedKey);
  assert.equal(foundLate, shortLateImage, 'disabling the option must still find images made with it');
  assert.equal(foundLate.prompt, 'per-image positive');
  assert.equal(foundLate.negativePrompt, 'per-image negative');
  imageLookupExtraEntries[lateTaggedKey] = shortLateImage;
  const reusedWhileDisabled = await hooks.imageGenerate.around(async () => {
    throw new Error('disabling must still reuse an image made with the short key');
  }, { imageKey: lateTaggedKey, prompt: 'new positive', negativePrompt: 'new negative' });
  assert.equal(reusedWhileDisabled.url, 'https://example.test/images/late-short.webp');
  assert.equal(Object.hasOwn(reusedWhileDisabled, 'key'), false, 'older short-key cached result shape must stay unchanged');
  const gameBeforeShortCache = api.game;
  api.game = '2026-10-24-pre7';
  const pre7ShortCache = await hooks.imageGenerate.around(async () => { throw new Error('short cache must not generate'); },
    { imageKey: lateTaggedKey, prompt: 'new positive', negativePrompt: 'new negative' });
  assert.equal(pre7ShortCache.key, shortLateImage.talentName, 'pre7 short cache must report the actual reused key');
  assert.equal(pre7ShortCache.fresh, false, 'a reused short-key image must be marked cached');
  api.game = gameBeforeShortCache;
  const cachedWhileDisabled = await hooks.imageQueue.around(async entries => ({
    accepted: entries.length, alreadyCached: 0,
  }), [{ talentId: lateTaggedKey, prompt: 'batch positive' }]);
  assert.equal(cachedWhileDisabled.accepted, 0);
  assert.equal(cachedWhileDisabled.alreadyCached, 1);
  setShortImageKeysFromUi(true);
  assert.equal(await hooks.imageLookup.around(async key => key === shortLateImage.talentName ? shortLateImage : null,
    lateTaggedKey), shortLateImage, 're-enabling must keep the same saved image');
  const reusedShortLate = await hooks.imageGenerate.around(async () => {
    throw new Error('a matching short-key image must not start another render');
  }, { imageKey: lateTaggedKey, prompt: 'new positive', negativePrompt: 'new negative' });
  assert.equal(reusedShortLate.url, 'https://example.test/images/late-short.webp');
  const cachedLateBatch = await hooks.imageQueue.around(async entries => ({
    accepted: entries.length, alreadyCached: 0,
  }), [{ talentId: lateTaggedKey, prompt: 'batch positive' }]);
  assert.equal(cachedLateBatch.accepted, 0);
  assert.equal(cachedLateBatch.alreadyCached, 1, 'batch lookup must reuse an existing short-key image');
  delete imageLookupExtraEntries[lateTaggedKey];
  imageLookupExtraEntries[lateTaggedKey] = { talentName: 'another-scene__v-0', imagePath: 'other-scene.webp' };
  const unrelatedLate = await hooks.imageGenerate.around(async request => request,
    { imageKey: lateTaggedKey, prompt: 'new positive', negativePrompt: 'new negative' });
  assert.equal(unrelatedLate.imageKey, lateRequest.imageKey, 'a nearest unrelated image must not be reused');
  delete imageLookupExtraEntries[lateTaggedKey];
  const queuedLate = await hooks.imageQueue.around(async entries => entries,
    [{ talentId: lateTaggedKey, prompt: 'batch positive', negativePrompt: 'batch negative' }]);
  assert.equal(queuedLate[0].talentId, lateRequest.imageKey, 'native batch generation must use the bounded final key');
  assert.equal(queuedLate[0].prompt, 'batch positive');
  const batchBefore = batchRequests.length;
  await hooks.imageQueue.around(async () => { throw new Error('checkpoint queue must use the batch endpoint'); },
    [{ talentId: lateTaggedKey, prompt: 'batch positive', negativePrompt: 'batch negative', checkpoint: 'custom.safetensors' }]);
  assert.equal(batchRequests.length, batchBefore + 1);
  assert.equal(batchRequests.at(-1).items[0].talentId, lateRequest.imageKey,
    'checkpoint batches must also shorten the final key');
  assert.equal(Object.hasOwn(batchRequests.at(-1).items[0], 'look'), false, 'older planned entries without a look must remain unchanged');
  setShortImageKeysFromUi(false);
  assert.match(fluid.prompt, /cum_in_mouth/);
  assert.match(fluid.prompt, /cum_in_pussy/);
  assert.match(fluid.prompt, /cum_dripping_thighs/);
  assert.match(fluid.prompt, /pussy_juice_dripping/);
  assert.match(fluid.prompt, /nipple_piercing/);
  assert.match(fluid.prompt, /heart_choker/);
  assert.match(fluid.prompt, /clitoris_piercing/);
  assert.match(fluid.prompt, /egg_vibrator.*vaginal_object_insertion/);
  assert.match(fluid.prompt, /egg vibrator fully inside her vagina.*only its cord visible/);
  assert.match(fluid.negativePrompt, /vibrator outside body:1\.4.*holding_sex_toy/);
  assert.equal(fluid.parts.some(part => part.label === 'H Status · 토이'), true,
    'a physically attached H Status toy should have its own inspectable prompt group');
  const beforeToyDefaults = savedSettings;
  savedSettings = { ...savedSettings, prompts: { ...savedSettings.prompts,
    'toy.vulva.egg': 'an inserted egg vibrator concealed inside her vagina with only a thin retrieval cord visible',
    'toy.vulva.penis': 'an inserted penis-shaped vibrator concealed inside her vagina with its base visible',
  } };
  for (const [type, tag] of [['egg', 'egg_vibrator:1.1'], ['penis', 'dildo:1.1']]) {
    wife.situationStats.jewelryState.vibe = { type, suspension: null };
    assert.ok(hooks.imagePrompt.after({ ...base, key: fullyExposedSceneKey }, [wife]).prompt.includes(tag),
      'the previous built-in toy sentence must migrate to the learned tag prompt');
  }
  savedSettings = { ...savedSettings, prompts: { ...savedSettings.prompts,
    'toy.vulva.egg': '(egg_vibrator:1.25), vaginal_object_insertion, vibrator_cord, only the cord visible',
    'toy.vulva.penis': '(dildo:1.2), vibrator, vaginal_object_insertion, vibrator base visible',
  }, negativePrompts: { ...savedSettings.negativePrompts,
    'toy.vulva.egg': 'penis-shaped vibrator, dildo, multiple vibrators, detached vibrator, vibrator outside body',
    'toy.vulva.penis': 'egg vibrator, vibrator cord, multiple vibrators, detached vibrator, vibrator outside body',
  } };
  for (const [type, tag] of [['egg', 'egg_vibrator:1.1'], ['penis', 'dildo:1.1']]) {
    wife.situationStats.jewelryState.vibe = { type, suspension: null };
    const migratedToy = hooks.imagePrompt.after({ ...base, key: fullyExposedSceneKey }, [wife]);
    assert.ok(migratedToy.prompt.includes(tag), 'saved 1.46.4 toy Positive must migrate to the first 1.46.5 default');
    assert.match(migratedToy.negativePrompt, /outside body:1\.4.*holding_sex_toy/);
  }
  savedSettings = { ...savedSettings, prompts: { ...savedSettings.prompts,
    'toy.vulva.egg': '(egg_vibrator:1.1), vaginal_object_insertion, vibrator_cord, (exactly one vibrator:1.35), (egg vibrator fully inside her vagina:1.45), (only its cord visible at the vaginal opening:1.3)',
    'toy.vulva.penis': 'vaginal_object_insertion, (exactly one dildo vibrator:1.35), (dildo shaft fully inside her vagina:1.45), (only its base visible at the vaginal opening:1.3)',
  }, negativePrompts: { ...savedSettings.negativePrompts,
    'toy.vulva.egg': 'dildo, (multiple vibrators:1.5), (extra vibrator:1.5), (vibrator outside body:1.5), holding_sex_toy',
    'toy.vulva.penis': 'egg_vibrator, vibrator_cord, (multiple vibrators:1.5), (extra dildo:1.5), (dildo outside body:1.5), holding_sex_toy',
  } };
  for (const [type, tag] of [['egg', 'egg_vibrator:1.1'], ['penis', 'dildo:1.1']]) {
    wife.situationStats.jewelryState.vibe = { type, suspension: null };
    const rolledBackToy = hooks.imagePrompt.after({ ...base, key: fullyExposedSceneKey }, [wife]);
    assert.ok(rolledBackToy.prompt.includes(tag), 'saved late 1.46.5 toy Positive must return to the first insertion default');
    assert.match(rolledBackToy.negativePrompt, /outside body:1\.4.*holding_sex_toy/);
    assert.doesNotMatch(rolledBackToy.prompt, /exactly one vibrator:1\.35|exactly one dildo vibrator:1\.35/);
    assert.doesNotMatch(rolledBackToy.negativePrompt, /extra vibrator:1\.5|extra dildo:1\.5/);
  }
  savedSettings = { ...savedSettings, prompts: { ...savedSettings.prompts,
    'toy.vulva.egg': 'custom_egg_placement' }, negativePrompts: { ...savedSettings.negativePrompts,
    'toy.vulva.egg': 'custom_egg_exclusion' } };
  wife.situationStats.jewelryState.vibe = { type: 'egg', suspension: null };
  const customToy = hooks.imagePrompt.after({ ...base, key: fullyExposedSceneKey }, [wife]);
  assert.match(customToy.prompt, /custom_egg_placement/);
  assert.match(customToy.negativePrompt, /custom_egg_exclusion/);
  savedSettings = beforeToyDefaults;
  for (const label of ['입', '가슴', '자궁', '보지', '허벅지']) {
    assert.equal(fluid.parts.some(part => part.label === `부위별 상태 · ${label}`), true,
      `each active body part should have its own prompt group: ${label}`);
  }
  state.modData.BadGuest.restraint.active = true;
  const restrainedWithChoker = hooks.imagePrompt.after({ ...base, key: fullyExposedSceneKey }, [wife]);
  assert.match(restrainedWithChoker.prompt, /heart_choker/);
  assert.doesNotMatch(restrainedWithChoker.negativePrompt, /heart-shaped choker|black leather choker/,
    'handcuff correction must not suppress a choker that H-Status actually has equipped');
  wife.situationStats.jewelryState.breasts.stage = 2;
  const restrainedWithoutChoker = hooks.imagePrompt.after({ ...base, key: fullyExposedSceneKey }, [wife]);
  assert.doesNotMatch(restrainedWithoutChoker.prompt, /heart_choker/);
  assert.match(restrainedWithoutChoker.negativePrompt, /heart-shaped choker/);
  assert.match(restrainedWithoutChoker.negativePrompt, /a heart-shaped choker fitted around her neck/);
  wife.situationStats.jewelryState.breasts.stage = 3;
  state.modData.BadGuest.restraint.active = false;
  const configuredEggToyKey = hooks.imageKey.after(fullyExposedSceneKey, [wife]);
  wife.situationStats.jewelryState.vibe = { type: 'penis', suspension: null };
  const penisToyPrompt = hooks.imagePrompt.after({ ...base, key: fullyExposedSceneKey }, [wife]);
  assert.match(penisToyPrompt.prompt, /dildo:1\.1.*vaginal_object_insertion.*dildo shaft fully inside her vagina/);
  assert.match(penisToyPrompt.negativePrompt, /egg_vibrator.*dildo outside body:1\.4/);
  assert.notEqual(hooks.imageKey.after(fullyExposedSceneKey, [wife]), configuredEggToyKey,
    'egg and penis-shaped H Status toy settings must keep distinct exact image keys');
  wife.situationStats.jewelryState.vibe.suspension = { reason: 'temporarily removed' };
  const suspendedToyPrompt = hooks.imagePrompt.after({ ...base, key: fullyExposedSceneKey }, [wife]);
  assert.doesNotMatch(suspendedToyPrompt.prompt, /egg_vibrator|dildo:1\.1|vaginal_object_insertion/,
    'a suspended toy should not be described as physically attached');

  savedSettings = {
    prompts: { 'fluid.breasts.0': 'breasts_visible_marker', 'fluid.uterus.0': 'uterus_visible_marker' },
    outfitStates: { 'fluid.breasts.0': ['exposed'], 'fluid.uterus.0': ['exposed'] },
  };
  wife.situationStats = { fluidState: { mouth: 0, breasts: 0, uterus: 0, thighs: 0 } };
  const exposedSceneKey = sceneKey.replace(/__exp-[01]{7}/, '__exp-0110000');
  const exposedPrompt = hooks.imagePrompt.after({ ...base, key: exposedSceneKey }, [wife]);
  assert.match(exposedPrompt.prompt, /breasts_visible_marker/,
    'top exposure bits should allow a breasts-only prompt');
  assert.doesNotMatch(exposedPrompt.prompt, /uterus_visible_marker/,
    'top exposure bits must not be treated as genital exposure');

  wife.situationStats = { jewelryState: { breasts: { stage: 1 }, vulva: { stage: 0 } } };
  savedSettings = {};
  const jewelryOnly = hooks.imagePrompt.after({ ...base, key: fullyExposedSceneKey }, [wife]);
  assert.match(jewelryOnly.prompt, /single_nipple_piercing/);
  wife.situationStats.jewelryState.breasts.stage = 0;
  const oldCoveredKey = hooks.imageKey.after(sceneKey, [wife]);
  wife.situationStats.jewelryState.breasts.stage = 1;
  const coveredPiercingKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.match(coveredPiercingKey, /jewel-breasts-1-covered/,
    'a covered one-sided piercing needs a new key so old false-choker art is not reused');
  const oldArt = { talentName: oldCoveredKey, imagePath: 'illustrious/characters/elena/old-choker.webp' };
  assert.equal(await hooks.imageLookup.around(async key => key === oldCoveredKey ? oldArt : null, coveredPiercingKey), null,
    'a new covered-jewelry key must not fall back to art made for an old accessory state');
  const oldGeneratedKey = oldCoveredKey.replace(/__v-0$/, '__v-4');
  savedModData.positionOverrides = { 'scene-patron_sex|grp-1|gslot-m': {
    sourceKey: oldCoveredKey, stateKey: oldCoveredKey, imageKey: oldGeneratedKey,
    generatedKeys: [oldGeneratedKey], manual: true,
  } };
  assert.notEqual(hooks.imageKey.after(sceneKey, [wife]), oldGeneratedKey,
    'a saved image variant must not override a changed accessory state');
  delete savedModData.positionOverrides;

  delete wife.situationStats;
  assert.doesNotThrow(() => hooks.imagePrompt.after(base, [wife]));

  wife.stats.arousal = 0;
  driveState = { financial: 0, approval: 0, desire: 0, security: 0, social: 0, pride: 0, longing: 0 };
  state.slot = 100;
  state.log = [{ seq: 1, slot: 100, text: '그녀가 특별한 대사를 조용히 말한다.', imageKey: sceneKey, coLocated: true }];
  savedSettings = { dialogueRules: [{
    id: 'dialogue-test',
    text: '특별한 대사',
    positivePrompt: 'dramatic_dialogue_scene',
    negativePrompt: 'blurry_dialogue',
    duration: 'scene',
    minutes: 5,
    outfitStates: ['partial'],
  }] };
  assert.equal(hooks.imageKey.after(sceneKey, [wife]), sceneKey,
    'dialogue rules must honor their outfit-state limit');
  assert.match(hooks.imageKey.after(partialSceneKey, [wife]), /__aip-talk-dialogue-test__v-0$/,
    'a partial-only dialogue rule should apply to partial clothing');
  savedSettings.dialogueRules[0].outfitStates = ['clothed', 'partial', 'nude'];
  const dialogueImageKey = hooks.imageKey.after(sceneKey, [wife]);
  assert.match(dialogueImageKey, /__aip-talk-dialogue-test__v-0$/);
  savedSettings.dialogueRules[0].id = 'dialogue_test';
  assert.match(hooks.imageKey.after(sceneKey, [wife]), /__aip-talk-dialogue-test-[a-z0-9]+__v-0$/,
    'a custom rule ID with an underscore must not collide with the readable hyphenated ID');
  savedSettings.dialogueRules[0].id = 'dialogue-test';
  const dialoguePrompt = hooks.imagePrompt.after({ ...base, key: sceneKey }, [wife]);
  assert.equal(dialoguePrompt.key, dialogueImageKey);
  assert.match(dialoguePrompt.prompt, /dramatic_dialogue_scene/);
  assert.match(dialoguePrompt.negativePrompt, /blurry_dialogue/);
  assert.equal(dialoguePrompt.parts.some(part => part.label === '대화 감지'), true);
  assert.equal(await hooks.imageLookup.around(async () => nearestFallback, dialogueImageKey), null,
    'a dialogue image must generate when its exact key is missing');
  const exactDialogueImage = { talentName: dialogueImageKey, imagePath: 'dialogue.webp' };
  assert.equal(await hooks.imageLookup.around(async () => exactDialogueImage, dialogueImageKey), exactDialogueImage,
    'an existing dialogue image should be exposed instead of regenerated');

  const endedSceneKey = sceneKey.replace('room-taproom', 'room-bedroom');
  assert.equal(hooks.imageKey.after(endedSceneKey, [wife]), endedSceneKey,
    'scene-scoped dialogue prompts must stop when the situation changes');

  savedSettings.dialogueRules[0].duration = 'minutes';
  state.slot = 104;
  assert.match(hooks.imageKey.after(endedSceneKey, [wife]), /__aip-talk-dialogue-test__v-0$/,
    'minute-scoped dialogue prompts should survive scene changes within the configured time');
  state.slot = 105;
  assert.equal(hooks.imageKey.after(endedSceneKey, [wife]), endedSceneKey,
    'minute-scoped dialogue prompts must expire at the configured time');
  state.slot = 101;
  state.log[0].coLocated = false;
  assert.equal(hooks.imageKey.after(endedSceneKey, [wife]), endedSceneKey,
    'dialogue hidden by proximity mode must not trigger a prompt');

  const manifestBeforeStatusCache = imageManifestEntries;
  imageManifestEntries = {};
  const settingsBeforeStatusCache = JSON.stringify(savedSettings);
  const dataBeforeStatusCache = JSON.stringify(savedModData);
  const statusA = 'elena__task-idle__mood-sad__state-a__v-0';
  const statusB = 'elena__task-idle__mood-tired__state-b__v-0';
  const statusRequest = {
    imageKey: statusA, prompt: 'same final portrait', negativePrompt: 'blur',
    width: 1216, height: 832, steps: 24, cfg: 6, loraStrength: 0.8,
  };
  const statusRequests = [];
  const captureStatus = async request => {
    statusRequests.push(request);
    return { url: `https://example.test/${encodeURIComponent(request.imageKey)}.webp` };
  };
  await hooks.imageGenerate.around(captureStatus, statusRequest);
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: statusB });
  const sharedStatusKey = statusRequests[0].imageKey;
  assert.equal(sharedStatusKey, statusA);
  assert.equal(statusRequests[1].imageKey, statusB,
    'different situation keys must stay distinct even when their prompts match');
  const toyStatusA = `${statusA}__toy-breast-1`;
  const toyStatusB = `${statusB}__toy-breast-1`;
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: toyStatusA });
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: toyStatusB });
  const sharedToyStatusKey = statusRequests.at(-2).imageKey;
  assert.equal(sharedToyStatusKey, toyStatusA);
  assert.equal(statusRequests.at(-1).imageKey, toyStatusB,
    'equipment situation keys must not be replaced with prompt-content keys');
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: `${toyStatusA}__v-4` });
  assert.equal(statusRequests.at(-1).imageKey, `${toyStatusA}__v-4`,
    'manual equipment variants must stay independent');
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: `${statusA.replace('__v-0', '__v-4')}__toy-breast-1` });
  assert.equal(statusRequests.at(-1).imageKey, `${statusA.replace('__v-0', '__v-4')}__toy-breast-1`,
    'manual variants followed by equipment must stay independent');
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: statusB, negativePrompt: 'noise' });
  assert.equal(statusRequests.at(-1).imageKey, statusB,
    'editing Negative must keep the original image key');
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: statusB, steps: 25 });
  assert.equal(statusRequests.at(-1).imageKey, statusB,
    'editing generation parameters must keep the original image key');
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: statusB, prompt: 'different portrait' });
  assert.equal(statusRequests.at(-1).imageKey, statusB,
    'editing Positive must keep the original image key');
  assert.equal(statusRequests.at(-1).prompt, 'different portrait');
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: statusB, prompt: 'same, final, portrait' });
  const orderedStatusKey = statusRequests.at(-1).imageKey;
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: statusB, prompt: 'portrait, same, final' });
  assert.equal(statusRequests.at(-1).imageKey, orderedStatusKey,
    'reordering Positive must not create a different image key');
  const nearestStatus = { talentName: 'elena__task-idle__v-0', imagePath: 'nearest.webp' };
  const sharedStatus = { talentName: sharedStatusKey, imagePath: 'shared.webp' };
  const statusLookupKeys = [];
  assert.equal(await hooks.imageLookup.around(async key => {
    statusLookupKeys.push(key);
    return key === sharedStatusKey ? sharedStatus : nearestStatus;
  }, statusA), sharedStatus, 'a portrait lookup should resolve the exact shared image');
  assert.deepEqual(statusLookupKeys, [statusA]);
  assert.equal(await hooks.imageLookup.around(async () => nearestStatus, sharedStatusKey), null,
    'a shared cache key must never accept a nearest image with a different prompt');

  const { legacyContentKey } = require('./rebuild-legacy-cache.cjs');
  const legacySource = {
    talentName: statusA, imagePath: 'illustrious/characters/elena/old.webp', imageType: 'portrait',
    prompt: statusRequest.prompt, negativePrompt: statusRequest.negativePrompt,
    genParams: { width: statusRequest.width, height: statusRequest.height,
      steps: statusRequest.steps, cfg: statusRequest.cfg, loraStrength: statusRequest.loraStrength },
  };
  const previousContentKey = legacyContentKey(legacySource);
  assert.match(previousContentKey, /__content-[0-9a-f]{16}__v-0$/,
    'old content-named images must remain addressable for read-only lookup');
  assert.equal(legacyContentKey({ ...legacySource, userCreated: true }), null);
  assert.equal(legacyContentKey({ ...legacySource, negativePrompt: undefined }), null);
  assert.notEqual(legacyContentKey({ ...legacySource, genParams: { ...legacySource.genParams, steps: 25 } }), previousContentKey);
  const packOnlyPrompt = hooks.imagePrompt.after({
    key: 'elena__task-idle__mood-sad__v-2', prompt: 'pack-only portrait', negativePrompt: 'blur',
    parts: [{ label: '기본', tags: 'pack-only portrait' }],
    genParams: { steps: 24, cfg: 6, loraStrength: 0.8 },
  }, [wife]);
  const packOnlyContentKey = legacyContentKey({
    ...legacySource,
    talentName: packOnlyPrompt.key,
    prompt: packOnlyPrompt.prompt,
    negativePrompt: packOnlyPrompt.negativePrompt,
    genParams: { ...packOnlyPrompt.genParams, width: 1216, height: 832 },
  });
  assert.ok(packOnlyContentKey, 'the pack-only portrait must have a content key');
  const packedStatus = { talentName: packOnlyContentKey, imagePath: 'packed.webp' };
  assert.equal(await hooks.imageLookup.around(async key => key === packOnlyContentKey ? packedStatus : null, packOnlyPrompt.key), null,
    'a new situation key must not be redirected to a prompt-content key');
  legacyCacheFixture.entries[previousContentKey] = [statusA, 'illustrious/characters/elena/old.webp'];
  const oldStatusEntry = { talentName: statusA, imagePath: 'illustrious/characters/elena/old.webp' };
  imageManifestEntries[statusA] = oldStatusEntry;
  const reusedLegacy = await hooks.imageGenerate.around(async () => {
    throw new Error('a matching old image must not start a new render');
  }, { ...statusRequest, imageKey: statusB });
  assert.equal(reusedLegacy.url, 'https://example.test/images/illustrious/characters/elena/old.webp');
  assert.equal(Object.hasOwn(reusedLegacy, 'key'), false, 'older legacy cached result shape must stay unchanged');
  const gameBeforeLegacyCache = api.game;
  api.game = '2026-10-24-pre7';
  const pre7LegacyCache = await hooks.imageGenerate.around(async () => { throw new Error('legacy cache must not generate'); },
    { ...statusRequest, imageKey: statusB });
  assert.equal(pre7LegacyCache.key, oldStatusEntry.talentName, 'pre7 legacy cache must report the actual reused key');
  assert.equal(pre7LegacyCache.fresh, false, 'a reused legacy image must be marked cached');
  const pre7Forwarded = await hooks.imageGenerate.around(async () => ({ url: 'https://example.test/new.webp', fresh: true, key: 'native-key' }),
    { imageKey: 'elena__task-idle__v-0', prompt: 'new portrait', bypassCache: true });
  assert.equal(pre7Forwarded.key, 'native-key', 'a native result key must not be replaced');
  assert.equal(pre7Forwarded.fresh, true, 'a fresh native result must not be marked cached');
  const pre7MissingKey = await hooks.imageGenerate.around(async () => ({ url: 'https://example.test/new.webp', fresh: true }),
    { imageKey: 'elena__task-idle__v-0', prompt: 'new portrait', bypassCache: true });
  assert.equal(pre7MissingKey.key, 'elena__task-idle__v-0', 'a successful pre7 result without a key must receive its requested key');
  api.game = gameBeforeLegacyCache;
  assert.equal(await hooks.imageLookup.around(async key => imageManifestEntries[key] || null, statusB), oldStatusEntry,
    'the portrait lookup must show the reused old image');
  const skippedLegacy = await hooks.imageQueue.around(async entries => ({
    accepted: entries.length, alreadyCached: 0, jobId: 'legacy-job',
  }), [{ ...statusRequest, talentId: statusB }, { ...statusRequest, talentId: statusB, negativePrompt: 'changed' }]);
  assert.equal(skippedLegacy.accepted, 1);
  assert.equal(skippedLegacy.alreadyCached, 0,
    'batch generation must use the latest edited prompt under the same image key');
  imageManifestEntries[statusA] = { ...oldStatusEntry, imagePath: 'replaced.webp' };
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: statusB });
  assert.equal(statusRequests.at(-1).imageKey, statusB,
    'a stale sidecar path must not rename the new generation request');
  delete legacyCacheFixture.entries[previousContentKey];

  const exactStatus = { talentName: statusA, imagePath: 'old-exact.webp' };
  imageManifestEntries[statusA] = exactStatus;
  await hooks.imageGenerate.around(captureStatus, statusRequest);
  assert.equal(statusRequests.at(-1).imageKey, statusA,
    'an existing exact status image should retain its original cache key');
  assert.equal(await hooks.imageLookup.around(async key => key === statusA ? exactStatus : sharedStatus, statusA), exactStatus);
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: statusB, bypassCache: true });
  assert.equal(statusRequests.at(-1).imageKey, statusB, 'forced regeneration must keep its requested key');
  const afterBypassLookups = [];
  assert.equal(await hooks.imageLookup.around(async key => {
    afterBypassLookups.push(key);
    return nearestStatus;
  }, statusB), null);
  assert.deepEqual(afterBypassLookups, [statusB], 'forced regeneration should clear the previous shared alias');
  const manualStatus = statusA.replace('__v-0', '__v-4');
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: manualStatus });
  assert.equal(statusRequests.at(-1).imageKey, manualStatus, 'manual variants must stay independent');
  const selectedStatus = statusA.replace('__mood-sad__state-a', '__mood-selected__state-c');
  const previousStatusChoices = savedSettings.similarImageChoices;
  savedSettings.similarImageChoices = {
    [selectedStatus.replace(/__v-\d+$/, '')]: { keys: [manualStatus], mode: 'selected' },
  };
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: selectedStatus });
  assert.equal(statusRequests.at(-1).imageKey, selectedStatus,
    'a manually selected image must not be redirected to the automatic shared cache');
  if (previousStatusChoices === undefined) delete savedSettings.similarImageChoices;
  else savedSettings.similarImageChoices = previousStatusChoices;
  const positionStatus = statusA.replace('__v-0', '__position-custom__v-0');
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: positionStatus });
  assert.equal(statusRequests.at(-1).imageKey, positionStatus, 'position images must stay independent');
  savedSettings.autoPositionPresets = true;
  const autoPositionA = statusA.replace('__v-0', '__position-missionary-abc__v-0');
  const autoPositionB = statusB.replace('__v-0', '__position-missionary-abc__v-0');
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: autoPositionA });
  const sharedPositionKey = statusRequests.at(-1).imageKey;
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: autoPositionB });
  assert.equal(sharedPositionKey, autoPositionA);
  assert.equal(statusRequests.at(-1).imageKey, autoPositionB,
    'automatic positions must retain their distinct situation keys');
  assert.notEqual(sharedPositionKey, sharedStatusKey, 'different positions must remain separate');
  delete savedSettings.autoPositionPresets;
  const residueStatus = 'situation_fluid__elena__mood-sad__v-0';
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: residueStatus });
  assert.equal(statusRequests.at(-1).imageKey, residueStatus, 'H-Status images must stay independent');

  imageManifestEntries = {};
  const queuedStatus = [];
  const batchStatusEntries = [
    { ...statusRequest, talentId: statusA },
    { ...statusRequest, talentId: statusB },
    { ...statusRequest, talentId: statusB, negativePrompt: 'noise' },
    { ...statusRequest, talentId: manualStatus },
    { ...statusRequest, talentId: positionStatus },
    { ...statusRequest, talentId: toyStatusA },
    { ...statusRequest, talentId: toyStatusB },
  ].map(({ imageKey, ...entry }) => entry);
  const statusQueueResult = await hooks.imageQueue.around(async entries => {
    queuedStatus.push(...entries);
    return { accepted: entries.length, alreadyCached: 0, jobId: 'status-job' };
  }, batchStatusEntries);
  assert.equal(statusQueueResult.accepted, 6);
  assert.equal(queuedStatus.length, 6, 'batch generation should deduplicate only identical image keys');
  assert.equal(queuedStatus[0].talentId, sharedStatusKey);
  assert.equal(queuedStatus[1].talentId, statusB);
  assert.equal(queuedStatus[2].talentId, manualStatus);
  assert.equal(queuedStatus[3].talentId, positionStatus);
  assert.equal(queuedStatus[4].talentId, sharedToyStatusKey);
  assert.equal(queuedStatus[5].talentId, toyStatusB);
  await hooks.imageGenerate.around(captureStatus, { ...statusRequest, imageKey: statusB });
  assert.equal(statusRequests.at(-1).imageKey, statusB,
    'a later portrait request should retain the same image key');
  const checkpointBatchBefore = batchRequests.length;
  const checkpointQueue = await hooks.imageQueue.around(async () => {
    throw new Error('checkpoint batches must use the existing custom queue');
  }, batchStatusEntries.slice(0, 2).map(entry => ({ ...entry, checkpoint: 'custom.safetensors' })));
  assert.equal(checkpointQueue.accepted, 2);
  assert.equal(batchRequests.length, checkpointBatchBefore + 1);
  assert.equal(batchRequests.at(-1).items[0].checkpoint, 'custom.safetensors');
  assert.equal(batchRequests.at(-1).items.length, 2, 'checkpoint batches must preserve both situation keys');

  const cancelStatus = statusA.replace('__mood-sad__state-a', '__mood-calm__state-c');
  const cancelSlot = { cancelRequested: false, promise: Promise.resolve(null) };
  imageGenerationInFlight.set(cancelStatus, cancelSlot);
  await hooks.imageGenerate.around(async request => {
    assert.equal(request.imageKey, cancelStatus);
    assert.equal(imageGenerationInFlight.get(cancelStatus), cancelSlot,
      'the native request should remain reachable by its original key while generating');
    cancelSlot.cancelRequested = true;
    return null;
  }, { ...statusRequest, imageKey: cancelStatus });
  assert.equal(imageGenerationInFlight.has(cancelStatus), true,
    'a request with an unchanged key must leave the native in-flight slot alone');
  imageGenerationInFlight.delete(cancelStatus);

  const waitingStatus = statusA.replace('__mood-sad__state-a', '__mood-hopeful__state-d');
  const sharedInFlightResult = { url: 'https://example.test/already-running.webp' };
  const activeSlot = { cancelRequested: false, promise: Promise.resolve(sharedInFlightResult) };
  const waitingSlot = { cancelRequested: false, promise: Promise.resolve(null) };
  imageGenerationInFlight.set(sharedStatusKey, activeSlot);
  imageGenerationInFlight.set(waitingStatus, waitingSlot);
  assert.equal(await hooks.imageGenerate.around(async request => {
    assert.equal(request.imageKey, waitingStatus);
    return sharedInFlightResult;
  }, { ...statusRequest, imageKey: waitingStatus }), sharedInFlightResult);
  assert.equal(imageGenerationInFlight.get(sharedStatusKey), activeSlot);
  activeSlot.promise = Promise.resolve(null);
  let retriedStatus = false;
  await hooks.imageGenerate.around(async request => {
    retriedStatus = true;
    assert.equal(request.imageKey, waitingStatus);
    assert.equal(imageGenerationInFlight.get(waitingStatus), waitingSlot);
    return sharedInFlightResult;
  }, { ...statusRequest, imageKey: waitingStatus });
  assert.equal(retriedStatus, true, 'a cancelled first request should let the next status retry');
  assert.equal(imageGenerationInFlight.has(sharedStatusKey), true);
  imageGenerationInFlight.delete(sharedStatusKey);
  imageGenerationInFlight.delete(waitingStatus);
  assert.equal(JSON.stringify(savedSettings), settingsBeforeStatusCache,
    'status cache aliases must not consume browser settings storage');
  assert.equal(JSON.stringify(savedModData), dataBeforeStatusCache,
    'status cache aliases must not consume game save storage');
  imageManifestEntries = manifestBeforeStatusCache;

  savedSettings = { autoPositionPresets: false };
  const defaultSceneKey = sceneKey.replace('scene-patron_sex', 'scene-guest_chat');
  activePortraitKey = defaultSceneKey;
  hooks.imagePrompt.after({ ...positionBase, key: defaultSceneKey }, [wife]);
  portraitPositionButton.click();
  const defaultAddButton = flattenNodes(openedSettingsWindow.body.children)
    .find(node => node.tag === 'button' && node.children.includes('이미지 추가 생성'));
  assert.equal(defaultAddButton.props.options.disabled, false,
    'the game default scene must allow another image without selecting a position preset');
  lastImagePromptInput.result = {
    ...lastImagePromptInput.result,
    prompt: `${lastImagePromptInput.result.prompt}, immediate_positive_edit`,
    negativePrompt: `${lastImagePromptInput.result.negativePrompt}, immediate_negative_edit`,
    parts: [...lastImagePromptInput.result.parts, { label: '사용자 프롬프트', tags: 'immediate_positive_edit' }],
  };
  const defaultGenerationCount = generatedRequests.length;
  defaultAddButton.props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(generatedRequests.length, defaultGenerationCount + 1);
  assert.match(generatedRequests.at(-1).prompt, /immediate_positive_edit/,
    'add image must rebuild the current Positive prompt before the next game tick');
  assert.match(generatedRequests.at(-1).negativePrompt, /immediate_negative_edit/,
    'add image must rebuild the current Negative prompt before the next game tick');
  const defaultAddedKey = generatedRequests.at(-1).imageKey;
  assert.match(defaultAddedKey, /__v-\d+$/);
  assert.equal(generatedRequests.at(-1).bypassCache, false);
  assert.equal(Object.hasOwn(generatedRequests.at(-1), 'look'), false, 'older portraits without a look must retain their request shape');
  assert.equal(hooks.imageKey.after(defaultSceneKey, [wife]), defaultAddedKey,
    'the default scene must select the added variant on the native portrait');
  assert.equal(hooks.imagePrompt.after({ ...positionBase, key: defaultSceneKey }, [wife]).key, defaultAddedKey,
    'the default-scene prompt must follow the displayed variant');

  const toySceneKey = sceneKey.replace('scene-patron_sex', 'scene-guest_toy')
    .replace(/__v-0$/, '__v-0__toy-breast-1');
  activePortraitKey = toySceneKey;
  hooks.imagePrompt.after({ ...positionBase, key: toySceneKey }, [wife]);
  portraitPositionButton.click();
  flattenNodes(openedSettingsWindow.body.children)
    .find(node => node.tag === 'button' && node.children.includes('이미지 추가 생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  const toyAddedKey = generatedRequests.at(-1).imageKey;
  assert.match(toyAddedKey, /__v-0__toy-breast-1__v-4$/,
    'a native toy suffix must stay on the same variant list when another image is added');
  assert.equal(hooks.imageKey.after(toySceneKey, [wife]), toyAddedKey);
  assert.equal(hooks.imagePrompt.after({ ...positionBase, key: toySceneKey }, [wife]).key, toyAddedKey);
  const legacyToyKey = toySceneKey.replace('__v-0__toy-breast-1', '__v-4__toy-breast-1');
  savedModData.positionOverrides['scene-guest_toy|grp-1|gslot-m'] = {
    ...savedModData.positionOverrides['scene-guest_toy|grp-1|gslot-m'],
    sourceKey: toySceneKey, stateKey: toySceneKey, imageKey: legacyToyKey,
  };
  assert.equal(hooks.imageKey.after(toySceneKey, [wife]), legacyToyKey,
    'an earlier image with the toy suffix after its variant number must remain addressable');

  const quotaSceneKey = sceneKey.replace('scene-patron_sex', 'scene-guest_quota');
  activePortraitKey = quotaSceneKey;
  hooks.imagePrompt.after({ ...positionBase, key: quotaSceneKey }, [wife]);
  portraitPositionButton.click();
  failVariantSave = true;
  flattenNodes(openedSettingsWindow.body.children)
    .find(node => node.tag === 'button' && node.children.includes('이미지 추가 생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  failVariantSave = false;
  assert.ok(flattenNodes(openedSettingsWindow.body.children).some(node =>
    node.tag === 'p' && node.children.some(child => String(child).includes('목록 저장에 실패'))),
  'browser storage exhaustion must be shown after a generated image could not join the list');

  savedSettings = { autoPositionPresets: true };
  wife.stats.energy = originalEnergy;
  wife.stats.mood = 50;
  wife.feelings = [];
  wife.intoxication.level = originalIntoxication;
  delete savedModData.positionOverrides?.[oralSituationId];
  activePortraitKey = oralSceneKey;
  hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]);
  portraitPositionButton.click();
  assert.ok(flattenNodes(openedSettingsWindow.body.children).some(node =>
    node.props?.['data-position-prompt'] === 'kneeling-fellatio'));
  wife.stats.energy = 0;
  wife.stats.mood = 61;
  wife.feelings = [{ emotion: 'shame', intensity: 94 }];
  activePortraitKey = hooks.imageKey.after(oralSceneKey, [wife]);
  hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]);
  portraitPositionButton.click();
  let oralNodes = flattenNodes(openedSettingsWindow.body.children);
  assert.ok(oralNodes.some(node => node.props?.['data-position-prompt'] === 'rough-fellatio'),
    'a changed negative state must select the rough oral preset');
  assert.ok(!oralNodes.some(node => node.props?.['data-position-prompt'] === 'kneeling-fellatio'),
    'the normal oral preset must no longer be selected in a negative state');
  oralNodes.find(node => node.tag === 'button' && node.children.includes('이미지 추가 생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.match(generatedRequests.at(-1).prompt, /rough fellatio/,
    'adding an image in a negative state must submit the rough oral prompt');
  assert.match(generatedRequests.at(-1).negativePrompt, /multiple penises in mouth/);
  assert.equal(savedModData.positionOverrides[oralSituationId].automatic, true);
  oralNodes = flattenNodes(openedSettingsWindow.body.children);
  oralNodes.find(node => node.tag === 'button' && node.children.includes('무릎 구강성교')).props.onclick();
  oralNodes = flattenNodes(openedSettingsWindow.body.children);
  oralNodes.find(node => node.tag === 'button' && node.children.includes('이미지 추가 생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.doesNotMatch(generatedRequests.at(-1).prompt, /rough fellatio/,
    'a directly chosen normal preset must keep the normal oral prompt');
  assert.equal(savedModData.positionOverrides[oralSituationId].manual, true);

  const analSceneKey = sceneKey.replace('patron_sex', 'patron_anal');
  const interleavedSceneKey = sceneKey.replace('patron_sex', 'patron_chatting');
  const analInput = { ...positionBase, key: analSceneKey };
  const otherInput = { ...positionBase, key: interleavedSceneKey };
  promptInputByContext = new Map([['anal-context', analInput], ['other-context', otherInput]]);
  activePortraitKey = analSceneKey;
  hooks.imagePrompt.after(analInput, [wife, 'anal-context']);
  hooks.imagePrompt.after(otherInput, [wife, 'other-context']);
  savedSettings.positionPresetPrompts = { ...savedSettings.positionPresetPrompts,
    'anal-doggystyle': 'aip_anal_edited_pose' };
  portraitPositionButton.click();
  const beforeAnalRegeneration = generatedRequests.length;
  flattenNodes(openedSettingsWindow.body.children)
    .find(node => node.tag === 'button' && node.children.includes('현재 이미지 재생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(generatedRequests.length, beforeAnalRegeneration + 1,
    'a different prompt inspection must not cancel regeneration of the active patron anal scene');
  assert.match(generatedRequests.at(-1).prompt, /aip_anal_edited_pose/,
    'the patron anal regeneration must submit the edited position prompt');
  assert.match(generatedRequests.at(-1).imageKey, /scene-patron_anal/);
  const capturedAnalWife = { ...wife, sceneOverride: 'patron_anal' };
  promptInputByContext = new Map([['anal-transition', character => ({ ...analInput,
    key: analSceneKey.replace('patron_anal', character.sceneOverride) })]]);
  hooks.imagePrompt.after(analInput, [capturedAnalWife, 'anal-transition']);
  state.characters.wife = { ...wife, sceneOverride: 'patron_anal_climax' };
  const beforeTransitionRegeneration = generatedRequests.length;
  flattenNodes(openedSettingsWindow.body.children)
    .find(node => node.tag === 'button' && node.children.includes('현재 이미지 재생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(generatedRequests.length, beforeTransitionRegeneration + 1,
    'the displayed patron anal image should regenerate after the game moves to its climax state');
  assert.match(generatedRequests.at(-1).imageKey, /scene-patron_anal(?:__|$)/);
  state.characters.wife = wife;
  delete savedSettings.positionPresetPrompts['anal-doggystyle'];
  promptInputByContext = null;
  activePortraitKey = oralSceneKey;
  hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]);

  const savedCharacterPrompt = savedSettings.characterPrompt;
  settingsWin.refresh();
  collectNodes().find(node => node.tag === 'button' && node.children.includes('아내 캐릭터')).props.onclick();
  const wifePositiveEditor = collectNodes().find(node => node.props?.['data-character-prompt'] === 'positive');
  dropCharacterPromptWrites = true;
  wifePositiveEditor.props.oninput({ currentTarget: { value: '1girl, silver hair, aip_unsaved_wife_edit' } });
  assert.equal(savedSettings.characterPrompt, savedCharacterPrompt,
    'a rejected immediate save should retain the prior persisted prompt');
  oralNodes = flattenNodes(openedSettingsWindow.body.children);
  const beforeRejectedWifeEdit = generatedRequests.length;
  oralNodes.find(node => node.tag === 'button' && node.children.includes('이미지 추가 생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  dropCharacterPromptWrites = false;
  assert.equal(generatedRequests.length, beforeRejectedWifeEdit,
    'a failed current-wife prompt save must cancel generation instead of silently sending the old prompt');
  assert.ok(flattenNodes(openedSettingsWindow.body.children).some(node =>
    node.tag === 'p' && node.children.some(child => String(child).includes('현재 아내 프롬프트를 저장하지 못했습니다'))));
  oralNodes = flattenNodes(openedSettingsWindow.body.children);
  oralNodes.find(node => node.tag === 'button' && node.children.includes('이미지 추가 생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.match(generatedRequests.at(-1).prompt, /aip_unsaved_wife_edit/,
    'adding an image must flush the current wife Positive editor even before its change event');
  assert.equal(savedSettings.characterPrompt.positivePrompt, '1girl, silver hair, aip_unsaved_wife_edit');
  const wifeNegativeEditor = collectNodes().find(node => node.props?.['data-character-prompt'] === 'negative');
  wifeNegativeEditor.props.oninput({ currentTarget: { value: 'bad anatomy, aip_unsaved_negative_edit' } });
  const secondWifePositiveEditor = collectNodes().find(node => node.props?.['data-character-prompt'] === 'positive');
  secondWifePositiveEditor.props.oninput({ currentTarget: { value: '1girl, red hair, aip_second_unsaved_edit' } });
  assert.equal(savedSettings.characterPrompt.positivePrompt, '1girl, red hair, aip_second_unsaved_edit',
    'a successful wife prompt edit should persist before the settings window closes');
  settingsWin.refresh();
  assert.equal(collectNodes().find(node => node.props?.['data-character-prompt'] === 'positive').props.value,
    '1girl, red hair, aip_second_unsaved_edit', 'a settings refresh should preserve the visible uncommitted wife draft');
  oralNodes = flattenNodes(openedSettingsWindow.body.children);
  oralNodes.find(node => node.tag === 'button' && node.children.includes('이미지 추가 생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.match(generatedRequests.at(-1).prompt, /aip_second_unsaved_edit/,
    'simultaneous Positive and Negative drafts must both reach the next image');
  assert.match(generatedRequests.at(-1).negativePrompt, /aip_unsaved_negative_edit/,
    'adding an image must flush the current wife Negative editor too');

  const staleNativePortrait = {
    imageKey: `${activePortraitKey}__v-98765`, prompt: 'stale_native_positive',
    negativePrompt: 'stale_native_negative', width: 1216, height: 832,
    debug: { stats: { energy: wife.stats.energy } },
  };
  let nativePortraitRequest;
  await hooks.imageGenerate.around(async request => {
    nativePortraitRequest = request;
    return { url: 'https://example.test/native-portrait.webp', fresh: true };
  }, staleNativePortrait);
  assert.match(nativePortraitRequest.prompt, /aip_second_unsaved_edit/,
    'the native portrait + button must replace its stale cached Positive prompt');
  assert.match(nativePortraitRequest.negativePrompt, /aip_unsaved_negative_edit/,
    'the native portrait + button must replace its stale cached Negative prompt');
  const beforeLookFixture = lastImagePromptInput;
  for (const look of ['current_look_hash', undefined]) {
    lastImagePromptInput = { ...beforeLookFixture, result: { ...beforeLookFixture.result, look } };
    let currentLookRequest;
    await hooks.imageGenerate.around(async request => {
      currentLookRequest = request;
      return { url: 'https://example.test/current-look.webp', fresh: true };
    }, { ...staleNativePortrait, look: 'stale_look_hash', bypassCache: true });
    assert.equal(currentLookRequest.look, look, 'native portrait generation must use the current look fingerprint');
  }
  lastImagePromptInput = beforeLookFixture;
  let oldGameRequest;
  await hooks.imageGenerate.around(async request => { oldGameRequest = request; return { url: 'https://example.test/old-look.webp' }; },
    { ...staleNativePortrait, look: 'existing_look', bypassCache: true });
  assert.equal(oldGameRequest.look, 'existing_look', 'older game prompt results without look must preserve the request');
  const staleShownPrompt = { key: activePortraitKey, prompt: staleNativePortrait.prompt,
    negativePrompt: staleNativePortrait.negativePrompt, parts: [{ label: '기본', tags: staleNativePortrait.prompt }] };
  const nativeShownHook = {
    memoizedState: staleShownPrompt,
    queue: { dispatch(value) { nativeShownHook.memoizedState = value; } },
    next: { memoizedState: [staleShownPrompt, []], next: {
      memoizedState: { variants: [activePortraitKey, staleNativePortrait.imageKey], currentIdx: 1 },
      next: { memoizedState: { current: staleNativePortrait.imageKey }, next: null },
    } },
  };
  portraitActionBar.__reactFiberTest = { memoizedState: nativeShownHook, return: null };
  pauseObserverCallback();
  animationFrameCallback?.();
  assert.match(nativeShownHook.memoizedState.prompt, /aip_second_unsaved_edit/,
    'the added image must display the Positive prompt sent to generation without advancing game time');
  assert.match(nativeShownHook.memoizedState.negativePrompt, /aip_unsaved_negative_edit/,
    'the added image must display the Negative prompt sent to generation');
  nativeShownHook.next.next.memoizedState.currentIdx = 0;
  nativeShownHook.next.next.next.memoizedState.current = activePortraitKey;
  nativeShownHook.memoizedState = staleShownPrompt;
  pauseObserverCallback();
  animationFrameCallback?.();
  assert.equal(nativeShownHook.memoizedState, staleShownPrompt,
    'a different portrait variant must not inherit the newly added image prompt');
  delete portraitActionBar.__reactFiberTest;
  let otherCharacterRequest;
  await hooks.imageGenerate.around(async request => {
    otherCharacterRequest = request;
    return { url: 'https://example.test/other-character.webp' };
  }, { ...staleNativePortrait, imageKey: 'mara__task-idle__v-98765' });
  assert.equal(otherCharacterRequest.prompt, 'stale_native_positive',
    'another character must keep its own generation prompt');

  savedSettings.characterPrompt = { positivePrompt: '', negativePrompt: '', mode: 'replace', imagePolicy: 'reuse' };
  state.characters.wife = { ...wife, generatedArchetype: {
    id: 'elena_farmgirl', shortname: 'elena', imageBase: '1girl, blue hair, aip_fresh_wife_state',
    imageNegative: 'aip_fresh_wife_negative',
    attentionImagePrompt: {
      positivePrompt: '1girl, blue hair, aip_fresh_wife_state',
      negativePrompt: 'aip_fresh_wife_negative', mode: 'replace', imagePolicy: 'reuse',
    },
  } };
  oralNodes = flattenNodes(openedSettingsWindow.body.children);
  oralNodes.find(node => node.tag === 'button' && node.children.includes('이미지 추가 생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.match(generatedRequests.at(-1).prompt, /aip_fresh_wife_state/,
    'the next image must use the current game character, not the previous portrait argument');
  assert.match(generatedRequests.at(-1).negativePrompt, /aip_fresh_wife_negative/);
  state.characters.wife = wife;
  if (savedCharacterPrompt === undefined) delete savedSettings.characterPrompt;
  else savedSettings.characterPrompt = savedCharacterPrompt;
  hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey }, [wife]);

  vmContext.WML.status = () => ({ loaded: ['h-status', 'prompt-tags', 'outfitqueue'] });
  settingsWin.refresh();
  assert.ok(portraitReviewButton, 'portrait prompt overlay must offer prompt review');
  portraitReviewButton.click();
  assert.ok(flattenNodes(openedSettingsWindow.body.children).some(node => node.props?.['data-prompt-mod-current'] === ''),
    'portrait review must open the mod influence tab');
  settingsWin.refresh();
  const actualRequestView = () => {
    settingsWin.refresh();
    return collectNodes().find(node => node.props?.['data-prompt-server-request'] === '');
  };
  assert.ok(flattenNodes(actualRequestView()).some(node => String(node.children?.[0]).includes('아직 관찰된 서버 생성 요청이 없습니다')),
    'before a server request the panel must explain that cache or blocking may produce no request');
  const fetchReceiver = { id: 'request receiver' };
  const requestUrl = 'https://images.example.test/api/image/generate';
  const requestOptions = { method: 'POST', body: JSON.stringify({ talentId: 'elena__task-idle__v-12',
    prompt: 'actual positive, request hook tag', negativePrompt: 'actual negative' }) };
  const fetchPromise = vmContext.fetch.call(fetchReceiver, requestUrl, requestOptions);
  const forwardedRequest = serverRequestFetches.at(-1);
  assert.equal(forwardedRequest.receiver, fetchReceiver, 'observer must preserve the fetch receiver');
  assert.equal(forwardedRequest.url, requestUrl);
  assert.equal(forwardedRequest.options, requestOptions, 'observer must forward the original request options');
  assert.equal(fetchPromise, forwardedRequest.promise, 'observer must return the original fetch promise');
  assert.equal(await fetchPromise, serverRequestResponse, 'observer must preserve the original response');
  const actualRequestNodes = flattenNodes(actualRequestView());
  assert.ok(actualRequestNodes.some(node => String(node.children?.[0]).includes('elena__task-idle__v-12')),
    'the observed request must display its image key');
  assert.deepEqual(actualRequestNodes.filter(node => node.tag === 'code').map(node => node.children[0]),
    ['actual positive, request hook tag', 'actual negative'], 'the UI must show the exact sent Positive and Negative');
  await vmContext.fetch(requestUrl, { method: 'GET' });
  await vmContext.fetch(`${requestUrl}/other`, { method: 'POST', body: JSON.stringify({ talentId: 'other', prompt: 'wrong route' }) });
  await vmContext.fetch(requestUrl, { method: 'POST', body: '{invalid json' });
  assert.deepEqual(flattenNodes(actualRequestView()).filter(node => node.tag === 'code').map(node => node.children[0]),
    ['actual positive, request hook tag', 'actual negative'], 'other requests and invalid JSON must not replace the record');
  assert.throws(() => vmContext.fetch(requestUrl, { method: 'POST', testThrow: true }), error => error === serverRequestError,
    'a synchronous fetch exception must be preserved');
  await hooks.imageGenerate.around(async () => ({ url: 'https://example.test/from-cache.webp', fresh: false }),
    { imageKey: 'cached__task-idle__v-0', prompt: 'cached prompt' });
  assert.deepEqual(flattenNodes(actualRequestView()).filter(node => node.tag === 'code').map(node => node.children[0]),
    ['actual positive, request hook tag', 'actual negative'], 'a cache hit without a POST must not fabricate a server record');
  const requestObject = new Request(requestUrl, { method: 'POST', body: JSON.stringify({
    talentId: 'mara__task-idle__v-0', prompt: 'request object positive',
  }) });
  assert.equal(await vmContext.fetch(requestObject), serverRequestResponse);
  for (let attempts = 0; attempts < 20 && !flattenNodes(actualRequestView()).some(node => node.tag === 'code'
    && node.children[0] === 'request object positive'); attempts += 1) await new Promise(resolve => setImmediate(resolve));
  assert.equal(requestObject.bodyUsed, false, 'observer must not consume the original Request body');
  assert.deepEqual(flattenNodes(actualRequestView()).filter(node => node.tag === 'code').map(node => node.children[0]),
    ['request object positive', ''], 'Request bodies and absent Negative must be recorded without consuming the request');
  let resolveOlderRequest;
  const slowRequest = { url: requestUrl, method: 'POST', clone: () => ({
    text: () => new Promise(resolve => { resolveOlderRequest = resolve; }),
  }) };
  await vmContext.fetch(slowRequest);
  await vmContext.fetch(requestUrl, { method: 'POST', body: JSON.stringify({ talentId: 'newer', prompt: 'newer prompt' }) });
  resolveOlderRequest(JSON.stringify({ talentId: 'older', prompt: 'older prompt' }));
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(flattenNodes(actualRequestView()).filter(node => node.tag === 'code').map(node => node.children[0]),
    ['newer prompt', ''], 'a slow Request clone must not overwrite a later request');
  await new Promise(resolve => setImmediate(resolve));
  const reviewWindow = openedSettingsWindow.win;
  const reviewBody = openedSettingsWindow.body;
  const beforeFocusedChildren = reviewBody.children;
  const originalReviewRefresh = reviewWindow.refresh;
  let reviewRefreshes = 0;
  let blurHandler;
  const focusedDraft = {
    tagName: 'INPUT', value: '작성 중인 태그',
    addEventListener(type, listener, options) {
      assert.equal(type, 'blur');
      assert.equal(options.once, true);
      blurHandler = listener;
    },
  };
  reviewWindow.el.contains = element => element === focusedDraft;
  reviewWindow.refresh = function () { reviewRefreshes += 1; return originalReviewRefresh.call(this); };
  vmContext.document.activeElement = focusedDraft;
  await vmContext.fetch(requestUrl, { method: 'POST', body: JSON.stringify({ talentId: 'focused', prompt: 'latest while typing' }) });
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(reviewRefreshes, 0, 'a request must not rerender the review while an input has focus');
  assert.equal(vmContext.document.activeElement, focusedDraft);
  assert.equal(focusedDraft.value, '작성 중인 태그', 'a request must preserve the unsaved input');
  assert.equal(reviewBody.children, beforeFocusedChildren, 'the visible editor must remain mounted while typing');
  assert.equal(typeof blurHandler, 'function', 'the deferred refresh must listen for blur');
  vmContext.document.activeElement = null;
  blurHandler();
  await new Promise(resolve => setTimeout(resolve, 20));
  assert.equal(reviewRefreshes, 1, 'the review must refresh after input blur');
  assert.ok(flattenNodes(reviewBody.children).some(node => node.tag === 'code' && node.children[0] === 'latest while typing'),
    'the deferred refresh must display the latest captured request');
  reviewWindow.refresh = originalReviewRefresh;
  delete reviewWindow.el.contains;
  const beforePreviewRequests = generatedRequests.length;
  collectNodes().find(node => node.tag === 'button' && node.children[0] === 'prompt-tags').props.onclick();
  const preview = collectNodes().find(node => node.props?.['data-prompt-mod-preview'] === 'prompt-tags');
  assert.ok(preview, 'an active prompt hook should offer a disable preview');
  const previewValues = flattenNodes(preview).filter(node => node.tag === 'code');
  assert.ok(previewValues.some(node => String(node.children?.[0]).includes('from mod')));
  assert.ok(previewValues.some(node => String(node.children?.[0]).includes('from mod negative')));
  assert.ok(previewValues.every(node => node.props.translate === 'no'),
    'preview tags must stay verbatim in the translated game UI');
  const promptModRow = (tag, source = 'current', polarity = 'positive') => collectNodes().find(node =>
    node.props?.['data-prompt-mod-tag'] === tag && node.props?.['data-prompt-mod-source'] === source
    && node.props?.['data-prompt-mod-polarity'] === polarity);
  assert.ok(flattenNodes(promptModRow('blush')).some(node => node.props?.['data-prompt-mod-translation'] === ''
    && String(node.children?.[0]).includes('홍조')), 'the Korean tag explanation should be visible without hovering');
  assert.match(flattenNodes(promptModRow('blush')).find(node => node.props?.['data-prompt-mod-chip'] === 'blush').props.title, /홍조/,
    'mod influence tags should include Korean explanations');
  const positiveModSection = collectNodes().find(node => node.props?.['data-prompt-mod-section'] === 'positive:current');
  assert.equal(positiveModSection.props.open, false, 'mod influence sections should start collapsed');
  positiveModSection.props.ontoggle({ currentTarget: { open: true } });
  settingsWin.refresh();
  assert.equal(collectNodes().find(node => node.props?.['data-prompt-mod-section'] === 'positive:current').props.open, true);
  flattenNodes(promptModRow('from mod')).find(node => node.props?.['data-prompt-mod-chip'] === 'from mod')
    .props.onclick({ altKey: false, ctrlKey: false });
  assert.equal(savedSettings.promptModRules[0].enabled, false, 'tag exclusion must persist in AIP settings');
  assert.equal(flattenNodes(promptModRow('from mod')).find(node => node.props?.['data-prompt-mod-chip'] === 'from mod').props['aria-pressed'], 'false',
    'excluded tags must expose their state');
  flattenNodes(promptModRow('from mod')).find(node => node.props?.['data-prompt-mod-restore'] === 'from mod').props.onclick();
  assert.equal(savedSettings.promptModRules.some(rule => rule.tag === 'from mod'), false,
    'the visible restore control must remove the exclusion without a modifier key');
  flattenNodes(promptModRow('from mod')).find(node => node.props?.['data-prompt-mod-chip'] === 'from mod').props.onclick({});
  flattenNodes(promptModRow('from mod')).find(node => node.props?.['data-prompt-mod-edit'] === 'from mod').props.onclick();
  flattenNodes(promptModRow('from mod')).find(node => node.props?.['data-prompt-mod-korean-input'] === '')
    .props.onchange({ currentTarget: { value: '모드가 추가한 태그' } });
  assert.ok(flattenNodes(promptModRow('from mod')).some(node => String(node.children?.[0]).includes('모드가 추가한 태그')),
    'untranslated tags should allow a saved Korean explanation');
  flattenNodes(promptModRow('from mod negative', 'current', 'negative'))
    .find(node => node.props?.['data-prompt-mod-edit'] === 'from mod negative').props.onclick();
  flattenNodes(promptModRow('from mod negative', 'current', 'negative'))
    .find(node => node.props?.['data-prompt-mod-replacement'] === '').props.onchange({ currentTarget: { value: 'less noise' } });
  const negativeInput = { key: 'elena__task-idle__v-0', prompt: 'base', negativePrompt: 'bad, from mod negative', parts: [] };
  const negativeFor = key => hooks.imagePromptTail.after({ ...negativeInput, key }).negativePrompt;
  assert.equal(negativeFor('elena__scene-other__v-0'), 'bad, less noise', 'a global Negative replacement must apply in other scenes');
  flattenNodes(promptModRow('from mod negative', 'current', 'negative'))
    .find(node => node.props?.['data-prompt-mod-chip'] === 'from mod negative').props.onclick({});
  assert.equal(negativeFor('elena__scene-other__v-0'), 'bad', 'global Negative exclusion must apply in other scenes');
  flattenNodes(promptModRow('from mod negative', 'current', 'negative'))
    .find(node => node.props?.['data-prompt-mod-restore'] === 'from mod negative').props.onclick();
  assert.equal(negativeFor('elena__scene-other__v-0'), 'bad, from mod negative', 'global Negative restore must recover the original tag');
  flattenNodes(promptModRow('from mod negative', 'current', 'negative'))
    .find(node => node.props?.['data-prompt-mod-edit'] === 'from mod negative').props.onclick();
  flattenNodes(promptModRow('from mod negative', 'current', 'negative'))
    .find(node => node.props?.['data-prompt-mod-replacement'] === '').props.onchange({ currentTarget: { value: 'less noise' } });
  collectNodes().find(node => node.props?.['data-prompt-mod-scope-select'] === '')
    .props.onchange({ currentTarget: { value: 'scene' } });
  settingsWin.refresh();
  assert.equal(collectNodes().find(node => node.props?.['data-prompt-mod-scope-select'] === '').props.value, 'scene',
    'the selected scene scope must remain visible after refresh');
  flattenNodes(promptModRow('from mod negative', 'current', 'negative'))
    .find(node => node.props?.['data-prompt-mod-chip'] === 'from mod negative').props.onclick({});
  assert.equal(negativeFor('elena__task-idle__v-0'), 'bad', 'scene Negative exclusion must override the global replacement');
  assert.equal(negativeFor('elena__scene-other__v-0'), 'bad, less noise', 'scene Negative exclusion must not affect other scenes');
  flattenNodes(promptModRow('from mod negative', 'current', 'negative'))
    .find(node => node.props?.['data-prompt-mod-edit'] === 'from mod negative').props.onclick();
  flattenNodes(promptModRow('from mod negative', 'current', 'negative'))
    .find(node => node.props?.['data-prompt-mod-replacement'] === '').props.onchange({ currentTarget: { value: 'scene correction' } });
  assert.equal(negativeFor('elena__task-idle__v-0'), 'bad, scene correction', 'scene Negative editing must apply only in that scene');
  assert.equal(negativeFor('elena__scene-other__v-0'), 'bad, less noise');
  flattenNodes(promptModRow('from mod negative', 'current', 'negative'))
    .find(node => node.props?.['data-prompt-mod-restore'] === 'from mod negative').props.onclick();
  assert.equal(negativeFor('elena__task-idle__v-0'), 'bad, less noise', 'restoring the scene rule must inherit the global Negative rule');
  collectNodes().find(node => node.props?.['data-prompt-mod-add-polarity'] === '')
    .props.onchange({ currentTarget: { value: 'negative' } });
  collectNodes().find(node => node.props?.['data-prompt-mod-add-input'] === '')
    .props.oninput({ currentTarget: { value: 'scene negative addition' } });
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '태그 추가').props.onclick();
  assert.equal(negativeFor('elena__task-idle__v-0'), 'bad, less noise, scene negative addition');
  assert.equal(negativeFor('elena__scene-other__v-0'), 'bad, less noise', 'scene Negative addition must not affect other scenes');
  const sceneNegativeAddition = savedSettings.promptModRules.find(rule => rule.tag === 'scene negative addition');
  assert.equal(sceneNegativeAddition?.scope, 'task-idle');
  assert.equal(sceneNegativeAddition?.polarity, 'negative');
  flattenNodes(collectNodes().find(node => node.props?.['data-prompt-mod-saved'] === ''))
    .find(node => node.props?.['data-prompt-mod-restore'] === 'scene negative addition').props.onclick();
  flattenNodes(promptModRow('recovered', 'without'))
    .find(node => node.props?.['data-prompt-mod-chip'] === 'recovered').props.onclick({});
  assert.equal(savedSettings.promptModRules.find(rule => rule.tag === 'recovered').scope, 'task-idle',
    'a tag restored in scene scope must be saved for that scene');
  collectNodes().find(node => node.props?.['data-prompt-mod-scope-select'] === '')
    .props.onchange({ currentTarget: { value: 'global' } });
  collectNodes().find(node => node.props?.['data-prompt-mod-add-input'] === '')
    .props.oninput({ currentTarget: { value: 'global negative addition' } });
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '태그 추가').props.onclick();
  assert.equal(negativeFor('elena__task-idle__v-0'), 'bad, less noise, global negative addition');
  assert.equal(negativeFor('elena__scene-other__v-0'), 'bad, less noise, global negative addition');
  const globalNegativeAddition = savedSettings.promptModRules.find(rule => rule.tag === 'global negative addition');
  assert.equal(globalNegativeAddition?.scope, '');
  assert.equal(globalNegativeAddition?.polarity, 'negative');
  flattenNodes(collectNodes().find(node => node.props?.['data-prompt-mod-saved'] === ''))
    .find(node => node.props?.['data-prompt-mod-restore'] === 'global negative addition').props.onclick();
  const editedPreview = collectNodes().find(node => node.props?.['data-prompt-mod-effective'] === '');
  const editedPrompts = flattenNodes(editedPreview).filter(node => node.tag === 'code').map(node => node.children[0]);
  assert.deepEqual(editedPrompts, ['base, blush, recovered', 'bad, less noise'],
    'the on-screen applied preview must use the saved tag decisions');
  const editedResult = hooks.imagePromptTail.after({ key: 'elena__task-idle__v-0',
    prompt: 'base, from mod, blush', negativePrompt: 'bad, from mod negative',
    parts: [{ label: 'Base', tags: 'base, from mod, blush' }] });
  assert.equal(editedResult.key, 'elena__task-idle__v-0',
    'excluding or replacing a mod tag must not change the image key');
  assert.equal(editedResult.prompt, 'base, blush, recovered');
  assert.equal(editedResult.negativePrompt, 'bad, less noise');
  assert.equal(editedResult.parts[0].tags, 'base, blush');
  assert.equal(editedResult.parts[1].tags, 'recovered');
  assert.equal(hooks.imagePromptTail.after({ key: 'elena__scene-other__v-0',
    prompt: 'base', negativePrompt: 'bad', parts: [] }).prompt, 'base',
  'a tag suppressed in one scene must not be restored to a different scene');
  let submittedPrompt;
  await hooks.imageGenerate.around(async request => { submittedPrompt = request; return { url: 'cached.webp' }; },
    { imageKey: 'wife_preview_test_1', prompt: editedResult.prompt, negativePrompt: editedResult.negativePrompt });
  assert.equal(submittedPrompt.prompt, editedPrompts[0], 'generation must receive the displayed Positive prompt');
  assert.equal(submittedPrompt.negativePrompt, editedPrompts[1], 'generation must receive the displayed Negative prompt');
  vmContext.WML.status = () => ({ loaded: ['h-status'] });
  assert.equal(hooks.imagePromptTail.after({ prompt: 'base, from mod', negativePrompt: 'bad' }).prompt,
    'base, from mod', 'rules for a disabled mod must not affect the prompt');
  vmContext.WML.status = () => ({ loaded: ['h-status', 'prompt-tags', 'outfitqueue'] });
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '기본 상황').props.onclick();
  collectNodes().find(node => node.props?.['data-export-section'] === 'promptModRules')
    .props.onchange({ currentTarget: { checked: true } });
  collectNodes().find(node => node.tag === 'button' && node.children[0] === 'JSON 내보내기').props.onclick();
  assert.equal(JSON.parse(exportedText).promptModRules.length, 3, 'tag decisions must be included in settings export');
  const promptRulesExport = JSON.stringify({ format: 'wayward-state-image-prompts', version: 21,
    promptModRules: JSON.parse(exportedText).promptModRules });
  savedSettings.promptModRules = [];
  await importInput.props.onchange({ currentTarget: {
    files: [{ name: 'mod-prompt-rules.json', text: async () => promptRulesExport }], value: 'mod-prompt-rules.json',
  } });
  assert.equal(savedSettings.promptModRules.length, 3, 'tag decisions must survive settings import');
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '모드 영향').props.onclick();
  assert.ok(collectNodes().some(node => String(node.children?.[0]).includes('생성 요청 단계 모드: outfitqueue')));
  assert.equal(generatedRequests.length, beforePreviewRequests, 'preview must not request image generation');
  collectNodes().find(node => node.tag === 'button' && node.children[0] === 'prompt-tags').props.onclick();
  assert.ok(collectNodes().some(node => node.props?.['data-prompt-mod-preview'] === 'prompt-tags'));
  hooks.imagePrompt.after({ ...characterBase, key: oralSceneKey,
    negativePrompt: 'aip_mod_preview_scene_changed' }, [wife]);
  settingsWin.refresh();
  assert.ok(!collectNodes().some(node => node.props?.['data-prompt-mod-preview'] === 'prompt-tags'),
    'a changed current prompt must discard the old mod-influence preview');
  const savedRuleList = collectNodes().find(node => node.props?.['data-prompt-mod-saved'] === '');
  assert.ok(savedRuleList, 'saved tag decisions must remain accessible after preview invalidation');
  const excludedRule = flattenNodes(savedRuleList).find(node => node.props?.['data-prompt-mod-tag'] === 'from mod');
  assert.ok(excludedRule, 'an excluded tag must still offer a restore control');
  flattenNodes(excludedRule).find(node => node.props?.['data-prompt-mod-chip'] === 'from mod').props.onclick({});
  assert.equal(savedSettings.promptModRules.find(rule => rule.tag === 'from mod').enabled, true);
  assert.match(hooks.imagePromptTail.after({ key: 'elena__task-idle__v-0',
    prompt: 'base, from mod', negativePrompt: 'bad' }).prompt, /from mod/,
  'restoring a tag must affect the next prompt without changing the image key');
  flattenNodes(collectNodes().find(node => node.props?.['data-prompt-mod-saved'] === ''))
    .find(node => node.props?.['data-prompt-mod-restore'] === 'from mod').props.onclick();
  assert.equal(savedSettings.promptModRules.some(rule => rule.tag === 'from mod'), false,
    'the visible restore control must remove the saved rule and its Korean explanation');
  const oldPromptModRules = savedSettings.promptModRules;
  const importPromptRuleFixture = async rules => {
    const text = JSON.stringify({ format: 'wayward-state-image-prompts', version: 23, promptModRules: rules });
    await importInput.props.onchange({ currentTarget: {
      files: [{ name: 'prompt-rules-fixture.json', text: async () => text }], value: 'prompt-rules-fixture.json',
    } });
  };
  const basePromptRules = [
    { owner: 'prompt-tags', polarity: 'positive', source: 'current', tag: 'scene tag', scope: 'task-idle', enabled: false },
    { owner: 'prompt-tags', polarity: 'negative', source: 'current', tag: 'old negative', scope: '', enabled: true, replacement: 'new negative' },
    { owner: api.id, polarity: 'positive', source: 'add', tag: 'added scene', scope: 'task-idle', enabled: true },
    { owner: api.id, polarity: 'negative', source: 'add', tag: 'added global', scope: '', enabled: true },
  ];
  await importPromptRuleFixture(basePromptRules);
  const ruleInput = { key: 'elena__task-idle__v-0', prompt: 'base, scene tag', negativePrompt: 'old negative', parts: [] };
  const scopedResult = hooks.imagePromptTail.after(ruleInput);
  assert.equal(scopedResult.prompt, 'base, added scene');
  assert.equal(scopedResult.negativePrompt, 'new negative, added global');
  const otherSceneResult = hooks.imagePromptTail.after({ ...ruleInput, key: 'elena__scene-other__v-0' });
  assert.equal(otherSceneResult.prompt, 'base, scene tag', 'scene rules must not affect other situations');
  assert.equal(otherSceneResult.negativePrompt, 'new negative, added global', 'global rules must apply in other situations');
  await importPromptRuleFixture([...basePromptRules,
    { owner: api.id, polarity: 'positive', source: 'add', tag: 'korean scene', scope: 'task-대기 중', enabled: true }]);
  assert.match(hooks.imagePromptTail.after({ ...ruleInput, key: 'elena__task-대기 중__v-0' }).prompt,
    /korean scene/, 'translated scene keys must remain valid scopes');
  await importPromptRuleFixture([...basePromptRules,
    { owner: 'prompt-tags', polarity: 'positive', source: 'current', tag: 'scene tag', scope: '', enabled: false },
    { owner: 'prompt-tags', polarity: 'positive', source: 'current', tag: 'scene tag', scope: 'scene-other', enabled: true },
  ]);
  assert.equal(hooks.imagePromptTail.after({ ...ruleInput, key: 'elena__scene-other__v-0' }).prompt,
    'base, scene tag', 'a scene rule must override the global rule for the same tag');
  await importPromptRuleFixture(basePromptRules);
  vmContext.WML.status = () => ({ loaded: [] });
  const disabledResult = hooks.imagePromptTail.after(ruleInput);
  assert.equal(disabledResult.prompt, 'base, scene tag, added scene', 'disabled mod rules must not apply, but user additions must remain');
  assert.equal(disabledResult.negativePrompt, 'old negative, added global');
  vmContext.WML.status = () => ({ loaded: ['h-status', 'prompt-tags', 'outfitqueue'] });
  await importPromptRuleFixture([...basePromptRules,
    { owner: api.id, polarity: 'negative', source: 'add', tag: 'added scene negative', scope: 'task-idle', enabled: true }]);
  const scopedExport = JSON.stringify({ format: 'wayward-state-image-prompts', version: 21,
    promptModRules: savedSettings.promptModRules });
  await importPromptRuleFixture([]);
  await importInput.props.onchange({ currentTarget: {
    files: [{ name: 'scoped-rules.json', text: async () => scopedExport }], value: 'scoped-rules.json',
  } });
  assert.equal(savedSettings.promptModRules.length, 5, 'scoped and added tag rules must survive settings import');
  assert.equal(hooks.imagePromptTail.after(ruleInput).prompt, 'base, added scene');
  assert.equal(hooks.imagePromptTail.after(ruleInput).negativePrompt, 'new negative, added global, added scene negative',
    'global and scene Negative additions must survive settings import');
  assert.equal(hooks.imagePromptTail.after({ ...ruleInput, key: 'elena__scene-other__v-0' }).negativePrompt,
    'new negative, added global', 'the imported scene Negative addition must not affect another scene');
  await importPromptRuleFixture(oldPromptModRules || []);
  const hookOwners = api.hookOwners;
  const previewHook = api.previewHook;
  api.hookOwners = undefined;
  api.previewHook = undefined;
  settingsWin.refresh();
  const compatNodes = collectNodes();
  assert.ok(compatNodes.some(node => node.props?.['data-prompt-mod-compat'] === ''),
    'WML without preview APIs must show a useful read-only fallback');
  assert.ok(compatNodes.some(node => node.props?.['data-prompt-mod-current'] === ''),
    'the fallback must show the actual current Positive and Negative prompts');
  assert.ok(compatNodes.some(node => String(node.children?.[0]).includes('활성 모드 전체 (3)')));
  assert.equal(generatedRequests.length, beforePreviewRequests,
    'the compatibility view must never request an image');
  let devEnabled = false;
  const devPromptHooks = { before: [], around: [], after: [{ owner: 'prompt-tags' }, { owner: api.id }], replace: null };
  const devGenerateHooks = { before: [], around: [], after: [{ owner: 'outfitqueue' }], replace: null };
  const devHooks = new Map([['imagePrompt', devPromptHooks], ['imageGenerate', devGenerateHooks]]);
  const originalImagePrompt = api.engine.imagePrompt;
  vmContext.localStorage = {
    setItem(key, value) { assert.equal(key, 'wml.dev'); devEnabled = value === 'true'; },
    removeItem(key) { assert.equal(key, 'wml.dev'); devEnabled = false; },
  };
  vmContext.WML.dev = () => {
    if (!devEnabled) throw new Error('developer mode is off');
    return { hooks: devHooks };
  };
  api.engine.imagePrompt = () => ({
    prompt: devPromptHooks.after.some(hook => hook.owner === 'prompt-tags') ? 'base, from mod' : 'base',
    negativePrompt: devPromptHooks.after.some(hook => hook.owner === 'prompt-tags') ? 'bad, from mod negative' : 'bad',
  });
  settingsWin.refresh();
  collectNodes().find(node => node.tag === 'button' && node.children[0] === 'WML 진단 모드 켜고 미리보기').props.onclick();
  assert.equal(devEnabled, true, 'developer mode must require an explicit button click');
  collectNodes().find(node => node.tag === 'button' && node.children[0] === 'prompt-tags').props.onclick();
  const devPreview = collectNodes().find(node => node.props?.['data-prompt-mod-preview'] === 'prompt-tags');
  assert.ok(devPreview, 'WML developer hooks should support an AIP-only comparison');
  assert.ok(flattenNodes(devPreview).some(node => node.tag === 'code' && String(node.children?.[0]).includes('from mod')));
  assert.deepEqual(devPromptHooks.after.map(hook => hook.owner), ['prompt-tags', api.id],
    'preview must restore all live hook registrations');
  assert.equal(generatedRequests.length, beforePreviewRequests, 'developer preview must not generate an image');
  collectNodes().find(node => node.tag === 'button' && node.children[0] === 'WML 진단 모드 끄기').props.onclick();
  assert.equal(devEnabled, false);
  assert.ok(collectNodes().some(node => node.props?.['data-prompt-mod-compat'] === ''));
  api.engine.imagePrompt = originalImagePrompt;
  delete vmContext.WML.dev;
  delete vmContext.localStorage;
  api.hookOwners = hookOwners;
  api.previewHook = previewHook;

  const unfinishedBase = {
    key: 'elena__scene-patron_blowjob__v-0',
    prompt: 'best quality, 1girl, shared_tag, cum_in_mouth', negativePrompt: 'base_negative',
    parts: [{ label: '품질', tags: 'best quality' }, { label: '기본', tags: '1girl, shared_tag' },
      { label: '정사 후 정황', tags: 'shared_tag, cum_in_mouth' }],
  };
  state.activeScene = { patron: { customerId: 'guest-1', startedAtSlot: 90, stage: 'blowjob_patron' } };
  state.customers = [{ id: 'guest-1', climaxSlots: [89] }];
  wife.aftermathTags = [];
  for (const [stage, sceneName] of [['blowjob_patron', 'blowjob'], ['handjob_patron', 'handjob'],
    ['rubbing_patron', 'rubbing'], ['sex_patron', 'sex']]) {
    state.activeScene.patron.stage = stage;
    const result = hooks.imagePrompt.after({ ...unfinishedBase,
      key: `elena__scene-patron_${sceneName}__v-0` }, [wife]);
    assert.ok(!result.parts.some(part => part.label === '정사 후 정황'),
      `unfinished ${stage} must not inherit a false aftermath part`);
    assert.doesNotMatch(result.prompt, /cum_in_mouth/);
    assert.match(result.prompt, /shared_tag/, 'a tag shared with another part must remain');
  }
  state.customers[0].climaxSlots.push(95);
  assert.ok(hooks.imagePrompt.after(unfinishedBase, [wife]).parts.some(part => part.label === '정사 후 정황'),
    'a recorded climax in the current interaction must preserve aftermath');
  state.customers[0].climaxSlots.pop();
  state.activeScene.patron.joinedPatronIds = ['guest-2'];
  state.customers.push({ id: 'guest-2', climaxSlots: [95] });
  assert.ok(hooks.imagePrompt.after(unfinishedBase, [wife]).parts.some(part => part.label === '정사 후 정황'),
    'a joined patron climax must preserve aftermath');
  delete state.activeScene.patron.joinedPatronIds;
  state.customers.pop();
  wife.aftermathTags = ['cum_on_body'];
  assert.ok(hooks.imagePrompt.after(unfinishedBase, [wife]).parts.some(part => part.label === '정사 후 정황'),
    'a native aftermath record must preserve the part');
  delete wife.aftermathTags;
  delete state.activeScene;
  delete state.customers;

  savedSettings = { positionRules: { 'scene-patron_sex': 'doggystyle' } };
  delete savedModData.positionOverrides;
  delete savedModData.positionModuleOverrides;
  activePortraitKey = sceneKey;
  promptInputByContext = new Map([['modules', positionBase]]);
  const beforeFitSettings = savedSettings;
  const beforeFitScene = state.activeScene;
  const beforeHStatus = vmContext.__waywardSituationEventMod;
  const beforeErostat = vmContext.__waywardErostatPlus;
  state.activeScene = { patron: { customerId: 'guest-1', stage: 'sex_patron', primarySlot: 'inside' } };
  vmContext.__waywardSituationEventMod = { playerPenis: () => ({ lengthCm: 15, girthCm: 12 }) };
  let fitBand = 'strain';
  let fitHoles = ['vaginal'];
  vmContext.__waywardErostatPlus = {
    insertions: () => fitHoles.map(hole => ({ who: { type: 'patron', customerId: 'guest-1' }, hole })),
    fit: () => ({ band: fitBand, label: fitBand === 'strain' ? '버거움' : '한계',
      size: { lengthCm: 22, girthCm: 16 } }),
  };
  const defaultFitPrompts = [
    ['loose', /without visible physical strain/, null, false],
    ['snug', /faint involuntary shiver/, /\(tense expression:1\.1\)/, false],
    ['full', /slight body trembling/, /\(strained expression:1\.25\)/, true],
    ['strain', /body trembling/, /\(glazed eyes:1\.3\).*unfocused upward gaze.*half-lidded eyes.*lips parted in a breathless gasp/, true],
    ['limit', /whole body shaking/, /\(overwhelmed expression:1\.35\).*open_mouth.*rounded lips in a breathless gasp/, true],
  ];
  for (const [band, reaction, face, contour] of defaultFitPrompts) {
    fitBand = band;
    const generated = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
    assert.match(generated.prompt, reaction, `${band} needs its built-in size reaction`);
    if (face) assert.match(generated.prompt, face, `${band} needs a visible facial reaction`);
    assert.equal(/penis-shaped bulge visible low on her abdomen/.test(generated.prompt), contour, `${band} belly contour`);
    assert.doesNotMatch(generated.prompt, /penis-shaped bulge pushing out/, 'the former oversized belly bulge must be gone');
  }
  const smilingFitBase = { ...positionBase, prompt: `${positionBase.prompt}, smile`,
    parts: positionBase.parts.map(part => part.label === '기분' ? { ...part, tags: 'smile' } : part) };
  const fitAttentionRows = rows;
  const fitWifeStats = wife.stats;
  const fitWifeFeelings = wife.feelings;
  const fitLatitude = relationshipLatitude;
  rows = [];
  wife.stats = { energy: 80, mood: 80, arousal: 0 };
  wife.feelings = [];
  relationshipLatitude = 25;
  fitBand = 'loose';
  assert.match(hooks.imagePrompt.after(smilingFitBase, [wife, 'modules']).prompt, /(?:^|, )smile(?:,|$)/);
  fitBand = 'full';
  assert.doesNotMatch(hooks.imagePrompt.after(smilingFitBase, [wife, 'modules']).prompt, /(?:^|, )smile(?:,|$)/,
    'a visibly strained size reaction must remove the native cheerful expression');
  rows = fitAttentionRows;
  wife.stats = fitWifeStats;
  wife.feelings = fitWifeFeelings;
  relationshipLatitude = fitLatitude;
  const oldFitSettings = savedSettings;
  fitBand = 'strain';
  savedSettings = { ...savedSettings, prompts: {
    'erostat.fit.strain': '(visibly struggling to accommodate the size:1.2), (body trembling:1.25), (clear penis-shaped bulge pushing out her lower abdomen from within:1.25)',
    'erostat.anal.limit': '(at her physical limit from anal penetration:1.3), (whole body shaking:1.35), (tense hips:1.3)',
  } };
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /localized shallow penis-shaped bulge/, 'a saved copy of the previous default must adopt the current contour');
  savedSettings.prompts['erostat.fit.strain'] = '(strained expression:1.3), (furrowed brow:1.25), grimace, (visibly struggling to accommodate the size:1.2), (body trembling:1.25), (very slight penis-shaped rise low on her abdomen from vaginal insertion:0.8)';
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /localized shallow penis-shaped bulge/, 'the 1.41.87 default must also adopt the visible contour');
  savedSettings.prompts['erostat.fit.strain'] = '(strained expression:1.3), (furrowed brow:1.25), (lips parted in a pained gasp:1.2), (visibly struggling to accommodate the size:1.2), (body trembling:1.25), (localized shallow penis-shaped bulge visible low on her abdomen from vaginal insertion:1.15)';
  const migratedStrainPrompt = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt;
  assert.match(migratedStrainPrompt, /glazed eyes/, 'the previous built-in strain prompt must adopt the unfocused gaze');
  assert.doesNotMatch(migratedStrainPrompt, /furrowed brow:1\.25/, 'the strain reaction must not keep the old frown');
  savedSettings.prompts['erostat.fit.strain'] += ', (struggling to draw a full breath:1.3), (gasping with mouth open:1.3), (trembling shoulders:1.2)';
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /glazed eyes/, 'the retired 1.41.89 breathless bundle must return to the first preset');
  savedSettings.prompts['erostat.fit.strain'] = '(dazed vacant gaze:1.25), (slightly glassy eyes:1.15), (unfocused eyes drifting subtly upward:1.12), (lips parted in a breathless gasp:1.2), (visibly struggling to accommodate the size:1.2), (body trembling:1.25), (localized shallow penis-shaped bulge visible low on her abdomen from vaginal insertion:1.15)';
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /glazed eyes/, 'the 1.41.90 vaginal default must adopt the stronger gaze');
  savedSettings.prompts['erostat.fit.strain'] += ', (half-lidded unfocused upward gaze:1.2), (struggling to draw a full breath:1.3), (gasping with mouth open:1.3), (trembling shoulders:1.2)';
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /glazed eyes/, 'the retired 1.41.90 breathless bundle must return to the first preset');
  fitHoles = ['anal'];
  savedSettings.prompts['erostat.anal.strain'] = '(strained expression:1.3), (furrowed brow:1.25), (lips parted in a pained gasp:1.2), (visibly struggling with anal penetration:1.2), (tense hips:1.2), (body trembling:1.25)';
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /glazed eyes/, 'the previous anal strain prompt must adopt the unfocused gaze');
  savedSettings.prompts['erostat.anal.strain'] = '(dazed vacant gaze:1.25), (slightly glassy eyes:1.15), (unfocused eyes drifting subtly upward:1.12), (lips parted in a breathless gasp:1.2), (visibly struggling with anal penetration:1.2), (tense hips:1.2), (body trembling:1.25)';
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /glazed eyes/, 'the 1.41.90 anal default must adopt the stronger gaze');
  savedSettings.prompts['erostat.anal.strain'] += ', (half-lidded unfocused upward gaze:1.2), (struggling to draw a full breath:1.3), (gasping with mouth open:1.3), (trembling shoulders:1.2)';
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /glazed eyes/, 'the retired anal breathless bundle must return to the first preset');
  fitHoles = ['vaginal'];
  fitBand = 'full';
  savedSettings.prompts['erostat.fit.full'] = '(strained expression:1.25), (furrowed brow:1.15), parted lips, (uneven breathing from the size:1.12), (slight body trembling:1.12)';
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /small shallow penis-shaped bulge/, 'the previous full-stage default must regain a modest belly contour');
  fitHoles = ['anal'];
  fitBand = 'limit';
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /\(open_mouth:1\.3\)/, 'the previous anal default must adopt the open-mouth reaction');
  savedSettings.prompts['erostat.anal.limit'] = '(grimace:1.35), (furrowed brow:1.3), (clenched_teeth:1.2), (at her physical limit from anal penetration:1.3), (whole body shaking:1.35), (tense hips:1.3)';
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /rounded lips in a breathless gasp/, 'the 1.41.87 anal default must drop clenched teeth');
  savedSettings = oldFitSettings;
  fitBand = 'strain';
  fitHoles = ['vaginal'];
  const vaginalFitKey = hooks.imageKey.after(sceneKey, [wife]);
  fitHoles = ['anal'];
  const analFitPrompt = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(analFitPrompt.prompt, /visibly struggling with anal penetration/);
  assert.match(analFitPrompt.prompt, /\(glazed eyes:1\.3\).*unfocused upward gaze.*half-lidded eyes.*lips parted in a breathless gasp/);
  assert.doesNotMatch(analFitPrompt.prompt, /penis-shaped (?:bulge|rise)/);
  assert.notEqual(hooks.imageKey.after(sceneKey, [wife]), vaginalFitKey,
    'anal and vaginal fit must use separate image situations');
  fitHoles = ['vaginal', 'anal'];
  const combinedFitPrompt = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(combinedFitPrompt.prompt, /visibly struggling to accommodate the size/);
  assert.match(combinedFitPrompt.prompt, /visibly struggling with anal penetration/);
  fitHoles = ['oral'];
  assert.doesNotMatch(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /penis-shaped (?:bulge|rise)/, 'the built-in belly contour must stay out of oral scenes');
  fitHoles = ['vaginal'];
  savedSettings = { ...savedSettings, prompts: Object.fromEntries(defaultFitPrompts.map(([band]) => [`erostat.fit.${band}`, ''])) };
  const fitBase = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  settingsRenderer(settingsBody, settingsWin);
  collectNodes().find(node => node.tag === 'button' && node.children.includes('에로스테 크기')).props.onclick();
  assert.equal(collectNodes().filter(node => node.tag === 'option'
    && /^default-(?:fit|anal)-/.test(String(node.props?.value))).length, 10,
  'both sets of five built-in stage presets must remain selectable');
  assert.match(collectNodes().find(node => node.props?.['data-erostat-fit-current'] === '')?.children[0] || '',
    /버거움.*22cm.*16cm/, 'the editor must show the live H-Status size fit');
  assert.equal(collectNodes().find(node => node.props?.['data-erostat-preset-select'] === '').props.value, '',
    'a manually edited stage must not appear to use a built-in preset');
  assert.equal(collectNodes().find(node => node.props?.['data-erostat-preset-select'] === '')
    .children.find(node => node.props?.value === '').props.selected, true,
    'the real select widget needs a selected option for the manual state');
  assert.match(collectNodes().find(node => node.props?.['data-erostat-preset-applied'] === '').children[0], /직접 수정한 문구/);
  collectNodes().find(node => node.props?.['data-aip-field-prompt'] === 'erostat.fit.strain:positive')
    .props.onchange({ currentTarget: { value: '(aip_fit_expression_marker:1.2)' } });
  collectNodes().find(node => node.props?.['data-aip-field-prompt'] === 'erostat.fit.strain:negative')
    .props.onchange({ currentTarget: { value: 'aip_fit_negative_marker' } });
  const fitChanged = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(fitChanged.prompt, /\(aip_fit_expression_marker:1\.2\)/);
  assert.match(fitChanged.negativePrompt, /aip_fit_negative_marker/);
  assert.notEqual(fitChanged.key, fitBase.key, 'a configured size reaction must use its own image key');
  const sizeToggle = () => collectNodes().find(node => node.props?.['data-aip-feature-toggle'] === 'erostat');
  assert.equal(sizeToggle().props.checked, true, 'size reactions retain their previous enabled default');
  sizeToggle().props.onchange({ currentTarget: { checked: false } });
  assert.equal(savedSettings.featurePrompts.erostat, false);
  const fitDisabled = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.doesNotMatch(fitDisabled.prompt, /aip_fit_expression_marker/);
  assert.doesNotMatch(fitDisabled.negativePrompt, /aip_fit_negative_marker/);
  assert.equal(fitDisabled.key, fitBase.key, 'disabling size reactions restores the image key without size');
  assert.match(collectNodes().find(node => node.props?.['data-erostat-fit-current'] === '')?.children[0] || '', /버거움/,
    'disabling the prompt must not hide the current fit or reset saved presets');
  sizeToggle().props.onchange({ currentTarget: { checked: true } });
  const fitReenabled = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.equal(fitReenabled.key, fitChanged.key, 'reenabling the same reaction restores its original image key');
  assert.match(fitReenabled.prompt, /aip_fit_expression_marker/);
  assert.match(fitReenabled.negativePrompt, /aip_fit_negative_marker/);
  fitBand = 'limit';
  assert.doesNotMatch(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /aip_fit_expression_marker/, 'another fit band must not inherit the previous expression');
  fitBand = 'strain';
  collectNodes().find(node => node.props?.['data-erostat-preset-name'] === '')
    .props.oninput({ currentTarget: { value: '첫 표정' } });
  collectNodes().find(node => node.tag === 'button'
    && node.children.includes('현재 단계 문구를 프리셋으로 저장')).props.onclick();
  assert.equal(savedSettings.erostatPromptPresets?.length, 1, JSON.stringify({ keys: Object.keys(savedSettings), positive: savedSettings.prompts?.['erostat.fit.strain'], negative: savedSettings.negativePrompts?.['erostat.fit.strain'] }));
  assert.equal(collectNodes().find(node => node.props?.['data-erostat-preset-select'] === '').props.value,
    savedSettings.erostatPromptPresets[0].id, 'the dropdown must select the applied stage preset');
  assert.match(collectNodes().find(node => node.props?.['data-erostat-preset-applied'] === '').children[0], /첫 표정/);
  collectNodes().find(node => node.props?.['data-aip-field-prompt'] === 'erostat.fit.strain:positive')
    .props.onchange({ currentTarget: { value: 'second_fit_expression_marker' } });
  assert.equal(collectNodes().find(node => node.props?.['data-erostat-preset-select'] === '').props.value, '');
  assert.match(collectNodes().find(node => node.props?.['data-erostat-preset-applied'] === '').children[0], /직접 수정한 문구/);
  collectNodes().find(node => node.props?.['data-erostat-preset-name'] === '')
    .props.oninput({ currentTarget: { value: '둘째 표정' } });
  collectNodes().find(node => node.tag === 'button'
    && node.children.includes('현재 단계 문구를 프리셋으로 저장')).props.onclick();
  assert.equal(savedSettings.erostatPromptPresets.length, 2, 'multiple custom reactions can be saved');
  collectNodes().find(node => node.props?.['data-erostat-preset-select'] === '')
    .props.onchange({ currentTarget: { value: savedSettings.erostatPromptPresets[0].id } });
  collectNodes().find(node => node.tag === 'button'
    && node.children.includes('선택한 단계에 불러오기')).props.onclick();
  assert.equal(savedSettings.prompts['erostat.fit.strain'], '(aip_fit_expression_marker:1.2)');
  assert.equal(savedSettings.negativePrompts['erostat.fit.strain'], 'aip_fit_negative_marker');
  assert.equal(collectNodes().find(node => node.props?.['data-erostat-preset-select'] === '').props.value,
    savedSettings.erostatPromptPresets[0].id);
  collectNodes().find(node => node.props?.['data-erostat-preset-select'] === '')
    .props.onchange({ currentTarget: { value: 'default-fit-limit' } });
  assert.equal(collectNodes().find(node => node.tag === 'button' && node.children.includes('프리셋 삭제')).props.options.disabled, true,
    'built-in presets must not be deletable');
  collectNodes().find(node => node.tag === 'button'
    && node.children.includes('선택한 단계에 불러오기')).props.onclick();
  assert.match(savedSettings.prompts['erostat.fit.strain'], /whole body shaking/,
    'a built-in preset must load into the selected band');
  collectNodes().find(node => node.props?.['data-erostat-preset-part'] === '')
    .props.onchange({ currentTarget: { value: 'anal' } });
  collectNodes().find(node => node.props?.['data-erostat-preset-select'] === '')
    .props.onchange({ currentTarget: { value: 'default-anal-limit' } });
  collectNodes().find(node => node.tag === 'button'
    && node.children.includes('선택한 단계에 불러오기')).props.onclick();
  assert.match(savedSettings.prompts['erostat.anal.strain'], /whole body shaking/,
    'the anal preset must load into the anal field without changing vaginal settings');
  savedSettings.prompts['erostat.fit.strain'] = 'saved_vaginal_reaction';
  savedSettings.prompts['erostat.anal.full'] = 'saved_anal_reaction';
  savedSettings.negativePrompts['erostat.anal.full'] = 'saved_anal_negative';
  settingsRenderer(settingsBody, settingsWin);
  assert.ok(collectNodes().some(node => node.tag === 'option' && node.props?.value === 'default-erostat'),
    'the built-in ten-stage prompts must appear as a selectable bundle');
  assert.ok(collectNodes().some(node => node.tag === 'option' && node.props?.value === 'default-erostat-breathless'),
    'the restored second built-in bundle must be offered');
  assert.equal(collectNodes().find(node => node.tag === 'button' && node.children.includes('묶음 삭제')).props.options.disabled, true,
    'the built-in bundle must not be deletable');
  collectNodes().find(node => node.props?.['data-erostat-bundle-name'] === '')
    .props.oninput({ currentTarget: { value: '전체 반응' } });
  collectNodes().find(node => node.tag === 'button' && node.children.includes('현재 10단계 묶음 저장')).props.onclick();
  assert.equal(savedSettings.erostatPromptBundles.length, 1);
  assert.equal(Object.keys(savedSettings.erostatPromptBundles[0].prompts).length, 10,
    'a bundle must capture both insertion sites and all five stages');
  assert.equal(savedSettings.erostatPromptBundles[0].negativePrompts['erostat.anal.full'], 'saved_anal_negative');
  assert.equal(collectNodes().find(node => node.props?.['data-erostat-bundle-select'] === '').props.value,
    savedSettings.erostatPromptBundles[0].id, 'the dropdown must select the applied bundle');
  assert.equal(collectNodes().find(node => node.props?.['data-erostat-preset-select'] === '').props.value,
    `${savedSettings.erostatPromptBundles[0].id}-stage-erostat.anal.strain`,
    'the stage dropdown must reflect the applied bundle');
  assert.match(collectNodes().find(node => node.props?.['data-erostat-bundle-applied'] === '').children[0], /전체 반응/);
  collectNodes().find(node => node.props?.['data-erostat-bundle-select'] === '')
    .props.onchange({ currentTarget: { value: savedSettings.erostatPromptBundles[0].id } });
  collectNodes().find(node => node.tag === 'button' && node.children.includes('선택한 묶음 불러오기')).props.onclick();
  assert.equal(savedSettings.prompts['erostat.fit.strain'], 'saved_vaginal_reaction');
  assert.equal(savedSettings.prompts['erostat.anal.full'], 'saved_anal_reaction');
  assert.equal(savedSettings.negativePrompts['erostat.anal.full'], 'saved_anal_negative');
  collectNodes().find(node => node.props?.['data-erostat-bundle-select'] === '')
    .props.onchange({ currentTarget: { value: 'default-erostat' } });
  collectNodes().find(node => node.tag === 'button' && node.children.includes('선택한 묶음 불러오기')).props.onclick();
  assert.match(savedSettings.prompts['erostat.fit.strain'], /localized shallow penis-shaped bulge/,
    'the module defaults must load through the same bundle picker as custom bundles');
  assert.match(savedSettings.prompts['erostat.anal.full'], /strained expression/);
  assert.equal(savedSettings.negativePrompts['erostat.anal.full'], '');
  const firstBundlePrompts = Object.fromEntries(Object.entries(savedSettings.prompts)
    .filter(([key]) => /^erostat\.(?:fit|anal)\./.test(key)));
  const previousBreathlessReactions = {
    loose: '(breath briefly catching:1.1), (lips slightly parted:1.1)',
    snug: '(breath catching:1.15), (short shallow breaths:1.15), (lips parted:1.15)',
    full: '(visibly breathless expression:1.25), (short uneven breaths:1.25), (mouth open in a gasp:1.2)',
    strain: '(eyes almost rolled upward:1.2), (pupils still visible:1.15), (struggling to draw a full breath:1.3), (gasping with mouth open:1.3), (trembling shoulders:1.2)',
    limit: '(barely able to catch her breath:1.35), (mouth held open in a breathless gasp:1.35), (rapid shallow breaths:1.3)',
  };
  savedSettings.prompts = { ...savedSettings.prompts, ...Object.fromEntries(Object.keys(savedSettings.prompts)
    .filter(key => /^erostat\.(?:fit|anal)\./.test(key))
    .map(key => [key, `${savedSettings.prompts[key]}, ${previousBreathlessReactions[key.split('.').at(-1)]}`])) };
  settingsRenderer(settingsBody, settingsWin);
  collectNodes().find(node => node.props?.['data-erostat-bundle-select'] === '')
    .props.onchange({ currentTarget: { value: '' } });
  assert.equal(collectNodes().find(node => node.props?.['data-erostat-bundle-select'] === '').props.value,
    'default-erostat-breathless', 'a saved copy of the original appended bundle must remain the second preset');
  collectNodes().find(node => node.props?.['data-erostat-bundle-select'] === '')
    .props.onchange({ currentTarget: { value: 'default-erostat-breathless' } });
  assert.equal(collectNodes().find(node => node.tag === 'button' && node.children.includes('묶음 삭제')).props.options.disabled, true,
    'the breathless built-in bundle must not be deletable');
  collectNodes().find(node => node.tag === 'button' && node.children.includes('선택한 묶음 불러오기')).props.onclick();
  for (const [key, base] of Object.entries(firstBundlePrompts)) {
    assert.equal(savedSettings.prompts[key], `${base}, ${previousBreathlessReactions[key.split('.').at(-1)]}`,
      `the restored second bundle must append the original reaction for ${key}`);
    assert.equal(savedSettings.negativePrompts[key], '',
      `the restored second bundle must keep the native negative for ${key}`);
  }
  assert.match(savedSettings.prompts['erostat.fit.limit'], /overwhelmed expression.*furrowed brow.*open_mouth.*barely able to catch her breath.*rapid shallow breaths/);
  savedSettings.prompts['erostat.fit.limit'] = '(vacant unfocused eyes:1.4), (eyes nearly rolled upward:1.3), (pupils still visible:1.15), (mouth held open in a silent gasp:1.35), (rapid shallow breaths:1.35), (whole body shaking:1.35), (distinct small penis-shaped bulge visible low on her abdomen from vaginal insertion:1.2)';
  savedSettings.negativePrompts['erostat.fit.limit'] = '';
  settingsRenderer(settingsBody, settingsWin);
  assert.equal(collectNodes().find(node => node.props?.['data-erostat-bundle-select'] === '').props.value,
    'default-erostat-breathless', 'a saved 1.41.92 stage must migrate to the restored second preset');
  collectNodes().find(node => node.tag === 'button' && node.children.includes('선택한 묶음 불러오기')).props.onclick();
  assert.equal(savedSettings.prompts['erostat.fit.limit'],
    `${firstBundlePrompts['erostat.fit.limit']}, ${previousBreathlessReactions.limit}`);
  assert.equal(savedSettings.negativePrompts['erostat.fit.limit'], '');
  savedSettings.prompts['erostat.fit.limit'] = '(confused overwhelmed gaze:1.4), (eyes wavering upward:1.25), (pupils clearly visible:1.15), (mouth open as she forcefully exhales:1.35), (ragged breath spilling from her lips:1.35), (whole body shaking:1.35), (distinct small penis-shaped bulge visible low on her abdomen from vaginal insertion:1.2)';
  savedSettings.negativePrompts['erostat.fit.limit'] = 'metal gag, metal mouthpiece, metal bar in mouth, biting metal';
  settingsRenderer(settingsBody, settingsWin);
  assert.equal(collectNodes().find(node => node.props?.['data-erostat-bundle-select'] === '').props.value,
    'default-erostat-breathless', 'the saved 1.41.93 stage must migrate to the restored reaction');
  collectNodes().find(node => node.tag === 'button' && node.children.includes('선택한 묶음 불러오기')).props.onclick();
  assert.equal(savedSettings.negativePrompts['erostat.fit.limit'], '');
  savedSettings.prompts['erostat.fit.limit'] = '(slightly hollow dazed eyes with visible pupils:1.35), (gaze drifting upward slightly:1.25), (slightly furrowed brows:1.15), (lips forming a small rounded gasp:1.35), (breath catching repeatedly in short broken gasps:1.35), (whole body shaking:1.35), (distinct small penis-shaped bulge visible low on her abdomen from vaginal insertion:1.2)';
  savedSettings.negativePrompts['erostat.fit.limit'] = 'metal gag, metal mouthpiece, metal bar in mouth, biting metal';
  settingsRenderer(settingsBody, settingsWin);
  assert.equal(collectNodes().find(node => node.props?.['data-erostat-bundle-select'] === '').props.value,
    'default-erostat-breathless', 'the saved 1.41.94 stage must migrate to the restored reaction');
  savedSettings.negativePrompts['erostat.fit.limit'] = 'manual_negative';
  settingsRenderer(settingsBody, settingsWin);
  assert.equal(savedSettings.negativePrompts['erostat.fit.limit'], 'manual_negative',
    'a directly edited negative must remain unchanged');
  assert.match(collectNodes().find(node => node.props?.['data-erostat-bundle-applied'] === '').children[0], /직접 수정/,
    'a directly edited negative must not be treated as the applied built-in bundle');
  collectNodes().find(node => node.props?.['data-erostat-bundle-select'] === '')
    .props.onchange({ currentTarget: { value: 'default-erostat-breathless' } });
  collectNodes().find(node => node.tag === 'button' && node.children.includes('선택한 묶음 불러오기')).props.onclick();
  const breathlessFitStrain = savedSettings.prompts['erostat.fit.strain'];
  assert.equal(collectNodes().find(node => node.props?.['data-erostat-bundle-select'] === '').props.value,
    'default-erostat-breathless');
  assert.equal(collectNodes().find(node => node.tag === 'option'
    && node.props?.value === 'default-erostat-breathless').props.selected, true,
  'the applied bundle must be selected in the real dropdown');
  assert.equal(collectNodes().find(node => node.props?.['data-erostat-preset-select'] === '').props.value,
    'default-erostat-breathless-stage-erostat.anal.strain');
  assert.match(collectNodes().find(node => node.props?.['data-erostat-bundle-applied'] === '').children[0], /숨이 막히는 듯/);
  assert.match(collectNodes().find(node => node.props?.['data-erostat-preset-applied'] === '').children[0], /숨이 막히는 듯/);
  collectNodes().find(node => node.props?.['data-aip-field-prompt'] === 'erostat.anal.strain:positive')
    .props.onchange({ currentTarget: { value: 'manual_anal_expression' } });
  assert.equal(collectNodes().find(node => node.props?.['data-erostat-bundle-select'] === '').props.value, '');
  assert.match(collectNodes().find(node => node.props?.['data-erostat-bundle-applied'] === '').children[0], /직접 수정/);
  collectNodes().find(node => node.props?.['data-erostat-bundle-select'] === '')
    .props.onchange({ currentTarget: { value: savedSettings.erostatPromptBundles[0].id } });
  collectNodes().find(node => node.tag === 'button' && node.children.includes('선택한 묶음 불러오기')).props.onclick();
  assert.equal(savedSettings.positionRules['scene-patron_sex'], 'doggystyle',
    'loading a size bundle must leave unrelated settings alone');
  collectNodes().find(node => node.props?.['data-export-section'] === 'erostatPromptPresets')
    .props.onchange({ currentTarget: { checked: true } });
  collectNodes().find(node => node.props?.['data-export-section'] === 'erostatPromptBundles')
    .props.onchange({ currentTarget: { checked: true } });
  collectNodes().find(node => node.props?.['data-export-section'] === 'featurePrompts')
    .props.onchange({ currentTarget: { checked: true } });
  savedSettings.featurePrompts = { ...savedSettings.featurePrompts, erostat: false };
  collectNodes().find(node => node.tag === 'button' && node.children.includes('JSON 내보내기')).props.onclick();
  assert.equal(JSON.parse(exportedText).erostatPromptPresets.length, 2,
    'size reaction presets must be included in settings export');
  assert.equal(JSON.parse(exportedText).erostatPromptBundles[0].prompts['erostat.fit.strain'], 'saved_vaginal_reaction',
    'the complete size bundle must be included in settings export');
  const exportedBundleSettings = JSON.parse(exportedText);
  assert.equal(exportedBundleSettings.featurePrompts.erostat, false, 'export must preserve the size switch');
  exportedBundleSettings.erostatPromptBundles.push({ id: '../invalid', name: 'invalid', prompts: {} });
  savedSettings.erostatPromptBundles = [];
  savedSettings.featurePrompts = { ...savedSettings.featurePrompts, erostat: true };
  await collectNodes().find(node => node.tag === 'input' && node.props?.type === 'file').props.onchange({
    currentTarget: { files: [{ name: 'size-bundles.json', text: async () => JSON.stringify(exportedBundleSettings) }], value: 'size-bundles.json' },
  });
  assert.equal(savedSettings.erostatPromptBundles.length, 1, 'bundle import must restore valid presets and reject invalid IDs');
  assert.equal(savedSettings.featurePrompts.erostat, false, 'import must restore the size switch');
  savedSettings.featurePrompts = { ...savedSettings.featurePrompts, erostat: true };
  assert.equal(savedSettings.erostatPromptBundles[0].negativePrompts['erostat.anal.full'], 'saved_anal_negative');
  collectNodes().find(node => node.tag === 'button' && node.children.includes('묶음 삭제')).props.onclick();
  assert.equal(savedSettings.erostatPromptBundles.length, 0);
  const sizeFitForClimax = vmContext.__waywardErostatPlus;
  savedSettings = beforeFitSettings;
  state.activeScene = beforeFitScene;
  vmContext.__waywardSituationEventMod = beforeHStatus;
  vmContext.__waywardErostatPlus = beforeErostat;
  const legacyModuleBaseline = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(legacyModuleBaseline.key, /__position-doggystyle-/);
  settingsRenderer(settingsBody, settingsWin);
  const climaxMenu = collectNodes().find(node => node.tag === 'button'
    && node.children.includes('절정 프롬프트'));
  assert.ok(climaxMenu, 'climax prompts need a direct settings menu');
  climaxMenu.props.onclick();
  assert.equal(savedSettings.positionMode, undefined, 'opening the editor must not switch position modes');
  assert.ok(collectNodes().some(node => node.props?.['data-climax-mode-note'] === ''));
  assert.ok(collectNodes().some(node => node.props?.['data-position-module-prompt'] === 'climax-1:positivePrompt'),
    'the first climax tier should open for editing immediately');
  assert.deepEqual(collectNodes().filter(node => node.props?.['data-position-module-id'])
    .map(node => node.props['data-position-module-id']), ['climax-1', 'climax-2', 'climax-3']);
  assert.ok(collectNodes().some(node => node.props?.['data-tag-library'] === ''),
    'the climax editor should show the Korean tag library beside its inputs');
  assert.ok(collectNodes().some(node => node.props?.['data-library-tag'] === 'female_orgasm'
    && node.children.includes('여성 절정')));
  collectNodes().find(node => node.props?.['data-climax-tier-add'] === '4').props.onclick();
  assert.ok(collectNodes().some(node => node.props?.['data-position-module-prompt'] === 'custom-climax-4:positivePrompt'));
  const fourthTierInput = collectNodes().find(node => node.props?.['data-position-module-prompt'] === 'custom-climax-4:positivePrompt');
  fourthTierInput.props.oninput({ currentTarget: { value: 'tongue_out' } });
  assert.equal(savedSettings.positionModules.find(module => module.id === 'custom-climax-4').positivePrompt, 'tongue_out',
    'the module prompt must persist on input before blur or window close');
  settingsBody.replaceChildren();
  settingsRenderer(settingsBody, settingsWin);
  assert.equal(collectNodes().find(node => node.props?.['data-position-module-prompt'] === 'custom-climax-4:positivePrompt').props.value,
    'tongue_out', 'closing and reopening settings should keep the typed prompt');
  collectNodes().find(node => node.props?.['data-climax-tier-add'] === '5').props.onclick();
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === 'custom-climax-5:positivePrompt')
    .props.oninput({ currentTarget: { value: 'dazed' } });
  assert.equal(savedSettings.positionModules.find(module => module.id === 'custom-climax-5').positivePrompt, 'dazed');
  collectNodes().find(node => node.props?.['data-controller-module-edit'] === 'climax-2').props.onclick();
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === 'climax-2:positivePrompt')
    .props.onchange({ currentTarget: { value: 'trembling, sweat, torogao' } });
  assert.equal(savedSettings.positionModulePrompts['climax-2'].positivePrompt, 'trembling, sweat, torogao');
  collectNodes().find(node => node.tag === 'button' && node.children.includes('기본 태그 복원')).props.onclick();
  assert.equal(savedSettings.positionModulePrompts['climax-2'], undefined);
  collectNodes().find(node => node.tag === 'button' && node.children.includes('체위 설정')).props.onclick();
  collectNodes().find(node => node.props?.['data-position-mode'] === 'modules').props.onclick();
  assert.equal(savedSettings.positionMode, 'modules');
  assert.ok(collectNodes().some(node => node.props?.['data-tag-library'] === ''),
    'position settings should also show the Korean tag library beside the editor');
  assert.ok(collectNodes().some(node => node.props?.['data-position-module-current'] === ''),
    'module mode should render without any external scene API');
  assert.ok(collectNodes().some(node => node.props?.['data-position-module-group-layout']
    === 'scene-patron_sex|grp-1|gslot-m'), 'module mode should expose the group layout editor');
  const moduleGroupOnly = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(moduleGroupOnly.key, /__position-modules-slots-m-/);
  assert.match(moduleGroupOnly.prompt, /separate male bodies.*first supporting man.*fellatio/,
    'native group placement must remain when no action module is selected');
  assert.doesNotMatch(moduleGroupOnly.prompt, /(?:^|, )1boy(?:,|$)/,
    'the single-man scene tag must not conflict with the group count');
  savedSettings.positionGroupPrompts = { m: 'legacy_group_marker' };
  assert.doesNotMatch(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /legacy_group_marker/, 'module layouts must not inherit edits from the legacy group-role editor');
  delete savedSettings.positionGroupPrompts;
  const twoGuestKey = sceneKey.replace('__grp-1__gslot-m', '__grp-2__gslot-mw');
  const twoGuestSituation = 'scene-patron_sex|grp-2|gslot-mw';
  const twoGuestResult = hooks.imagePrompt.after({ ...positionBase, key: twoGuestKey }, [wife, 'modules']);
  assert.match(twoGuestResult.prompt, /first supporting man.*fellatio.*second supporting man.*watching/,
    'two extra men must retain separate roles');
  assert.match(twoGuestResult.prompt, /3boys/);
  assert.doesNotMatch(twoGuestResult.prompt, /(?:^|, )\(?2boys/,
    'a larger group must not keep an outdated smaller male count');
  assert.match(twoGuestResult.key, /__position-modules-slots-mw-/);
  savedSettings.positionModuleGroupLayouts = { [twoGuestSituation]: { groupSlots: 'fw',
    personPrompts: { main: '', extras: ['first_extra_marker', 'second_extra_marker'] } } };
  const editedTwoGuestResult = hooks.imagePrompt.after({ ...positionBase, key: twoGuestKey }, [wife, 'modules']);
  assert.match(editedTwoGuestResult.prompt, /first supporting man.*fingering.*first_extra_marker.*second supporting man.*watching.*second_extra_marker/);
  assert.doesNotMatch(editedTwoGuestResult.prompt, /fellatio/);
  assert.notEqual(editedTwoGuestResult.key, twoGuestResult.key);
  savedSettings.positionModuleGroupLayouts = {};
  savedSettings.positionModuleSelections = { 'scene-patron_sex|grp-1|gslot-m': ['action-4'] };
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /first supporting man.*watching nearby/,
    'a main-partner oral action must not assign a second penis to the same mouth');
  savedSettings.positionModuleSelections = {};
  hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  const findModule = (section, predicate, scope = 'patron') => {
    collectNodes().find(node => node.props?.['data-position-module-section'] === section).props.onclick();
    collectNodes().find(node => node.props?.['data-position-module-scope'] === scope)?.props.onclick();
    const find = () => collectNodes().find(predicate);
    let module = find();
    if (module) return module;
    for (const group of collectNodes().filter(node => node.props?.['data-position-module-group'])
      .map(node => node.props['data-position-module-group'])) {
      collectNodes().find(node => node.props?.['data-position-module-group'] === group).props.onclick();
      module = find();
      if (module) return module;
    }
    return null;
  };
  findModule('climax', node => node.props?.['data-controller-module-edit'] === 'custom-climax-4').props.onclick();
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === 'custom-climax-4:negativePrompt').props.onfocus();
  await collectNodes().find(node => node.props?.['data-library-tag'] === 'spanking').props.onclick();
  assert.match(savedSettings.positionModules.find(module => module.id === 'custom-climax-4').negativePrompt, /spanking/,
    'clicking a Korean library tag should update the focused module field');
  const selectModuleKind = (kind, value) => {
    const section = kind === 'pose' ? 'posture' : kind === 'position' ? 'position' : 'action';
    const module = findModule(section, node => node.props?.['data-position-module-kind'] === kind
      && node.props?.['data-position-module-id'] === value);
    assert.ok(module, `${kind}/${value} must be reachable through its category`);
    module.props.onclick();
  };
  assert.ok(findModule('position', node => node.props?.['data-position-module-id'] === 'pose-9'),
    'cowgirl belongs to the position category');
  assert.equal(findModule('posture', node => node.props?.['data-position-module-id'] === 'pose-9'), null,
    'female posture must not contain a complete sex position');
  collectNodes().find(node => node.props?.['data-position-module-section'] === 'posture').props.onclick();
  collectNodes().find(node => node.props?.['data-position-module-group'] === '서기·앉기').props.onclick();
  assert.ok(!collectNodes().some(node => node.props?.['data-position-module-id'] === 'pose-8'),
    'lying with both legs raised must not appear among standing and sitting postures');
  collectNodes().find(node => node.props?.['data-position-module-group'] === '눕기·엎드리기').props.onclick();
  assert.ok(collectNodes().some(node => node.props?.['data-position-module-id'] === 'pose-8'));
  state.activeScene = { patron: { customerId: 'guest-1', stage: 'sex_patron', primarySlot: 'inside' } };
  const originalSlot = state.slot;
  const originalOrgasmSlot = wife.lastOrgasmSlot;
  const originalOrgasmsToday = wife.orgasmsToday;
  state.activeScene.patron.startedAtSlot = 90;
  state.activeScene.patron.elenaPleasure = 99;
  const scenePrompt = key => hooks.imagePrompt.after({ ...positionBase, key }, [wife, 'modules']);
  const recordHeroineOrgasm = (scene, countKey, flagKey, count, options = {}) => {
    const before = { ...state, characters: { ...state.characters, wife: { ...wife } } };
    scene[countKey] = count;
    scene[flagKey] = true;
    wife.lastOrgasmSlot = state.slot;
    wife.orgasmsToday = (wife.orgasmsToday || 0) + 1;
    assert.equal(hooks.heroineOrgasm.after(state, [before, 'wife', options]), state);
  };
  const beforeFemaleClimax = scenePrompt(sceneKey);
  assert.doesNotMatch(beforeFemaleClimax.prompt, /female_orgasm|ahegao/,
    'high pleasure alone must not imply a heroine climax');
  const climaxButton = findModule('climax', node => node.props?.['data-position-module-id'] === 'climax-1');
  assert.ok(climaxButton, 'the female climax module must be reachable as a button');
  climaxButton.props.onclick();
  assert.match(scenePrompt(sceneKey).prompt, /female_orgasm/, 'manual climax module selection must work');
  assert.match(scenePrompt(sceneKey).prompt, /emphasis line/, 'the default orgasm prompt should add emphasis lines');
  savedSettings.positionModulePrompts = { ...savedSettings.positionModulePrompts,
    'climax-1': { positivePrompt: 'female_orgasm, moaning, blush, heavy_breathing' } };
  assert.match(scenePrompt(sceneKey).prompt, /emphasis line/,
    'the previous saved default should migrate without changing custom orgasm prompts');
  delete savedSettings.positionModulePrompts['climax-1'];
  findModule('climax', node => node.props?.['data-position-module-id'] === 'climax-1').props.onclick();
  assert.doesNotMatch(scenePrompt(sceneKey).prompt, /female_orgasm/);
  findModule('climax', node => node.props?.['data-controller-module-edit'] === 'climax-1').props.onclick();
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === 'climax-1:positivePrompt')
    .props.onchange({ currentTarget: { value: 'female_orgasm, moaning, blush, heavy_breathing, half-closed_eyes' } });
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === 'climax-1:negativePrompt')
    .props.onchange({ currentTarget: { value: 'crying' } });
  assert.match(savedSettings.positionModulePrompts['climax-1'].positivePrompt, /half-closed_eyes/);
  const patronScene = state.activeScene.patron;
  patronScene.elenaPleasure = 100;
  recordHeroineOrgasm(patronScene, 'elenaInteractionClimaxCount', 'elenaClimaxedDuringInteraction', 1);
  const firstFemaleClimax = scenePrompt(sceneKey);
  assert.match(firstFemaleClimax.prompt, /female_orgasm/);
  assert.match(firstFemaleClimax.prompt, /half-closed_eyes/);
  assert.match(firstFemaleClimax.negativePrompt, /crying/);
  const previousFitSettings = savedSettings;
  const previousHStatusForClimax = vmContext.__waywardSituationEventMod;
  const previousErostatForClimax = vmContext.__waywardErostatPlus;
  savedSettings = { ...savedSettings, prompts: { ...savedSettings.prompts,
    'erostat.fit.strain': breathlessFitStrain }, negativePrompts: { ...savedSettings.negativePrompts,
    'erostat.fit.strain': '' } };
  vmContext.__waywardSituationEventMod = {};
  vmContext.__waywardErostatPlus = sizeFitForClimax;
  const climaxWithFit = scenePrompt(sceneKey);
  assert.match(climaxWithFit.prompt, /female_orgasm/);
  assert.match(climaxWithFit.prompt, /eyes almost rolled upward/,
    'the active size reaction must remain in the final prompt during a heroine climax');
  assert.doesNotMatch(climaxWithFit.negativePrompt, /metal bar in mouth/,
    'the restored second preset must use the native negative prompt');
  savedSettings = previousFitSettings;
  vmContext.__waywardSituationEventMod = previousHStatusForClimax;
  vmContext.__waywardErostatPlus = previousErostatForClimax;
  assert.notEqual(firstFemaleClimax.key, beforeFemaleClimax.key,
    'a real heroine climax must use a different image key');
  patronScene.characterId = 'another-woman';
  assert.doesNotMatch(scenePrompt(sceneKey).prompt, /female_orgasm/,
    'another character climax must not appear on the primary heroine');
  delete patronScene.characterId;
  settingsWin.refresh();
  assert.ok(collectNodes().some(node => node.props?.['data-position-climax-auto'] === ''),
    'the settings panel must show automatic climax detection');
  state.slot += 1;
  assert.match(scenePrompt(sceneKey).prompt, /female_orgasm/,
    'climax expression must persist while the same scene continues');
  recordHeroineOrgasm(patronScene, 'elenaInteractionClimaxCount', 'elenaClimaxedDuringInteraction', 2);
  const secondFemaleClimax = scenePrompt(sceneKey);
  assert.match(secondFemaleClimax.prompt, /trembling/);
  assert.notEqual(secondFemaleClimax.key, firstFemaleClimax.key);
  recordHeroineOrgasm(patronScene, 'elenaInteractionClimaxCount', 'elenaClimaxedDuringInteraction', 3);
  const thirdFemaleClimax = scenePrompt(sceneKey);
  assert.match(thirdFemaleClimax.prompt, /ahegao/);
  assert.notEqual(thirdFemaleClimax.key, secondFemaleClimax.key);
  assert.doesNotMatch(thirdFemaleClimax.prompt, /tongue_out|dazed/);
  recordHeroineOrgasm(patronScene, 'elenaInteractionClimaxCount', 'elenaClimaxedDuringInteraction', 4);
  const fourthFemaleClimax = scenePrompt(sceneKey);
  assert.match(fourthFemaleClimax.prompt, /tongue_out/);
  assert.doesNotMatch(fourthFemaleClimax.prompt, /dazed/);
  assert.notEqual(fourthFemaleClimax.key, thirdFemaleClimax.key);
  recordHeroineOrgasm(patronScene, 'elenaInteractionClimaxCount', 'elenaClimaxedDuringInteraction', 5);
  assert.match(scenePrompt(sceneKey).prompt, /tongue_out.*dazed/);
  findModule('climax', node => node.props?.['data-controller-module-edit'] === 'custom-climax-4').props.onclick();
  collectNodes().find(node => node.props?.['data-climax-tier-remove'] === 'custom-climax-4').props.onclick();
  assert.doesNotMatch(scenePrompt(sceneKey).prompt, /tongue_out/);
  assert.ok(collectNodes().some(node => node.props?.['data-climax-tier-add'] === '4'),
    'deleting a tier should allow the missing count to be added again');
  findModule('climax', node => node.props?.['data-controller-module-edit'] === 'custom-climax-5').props.onclick();
  collectNodes().find(node => node.props?.['data-climax-tier-remove'] === 'custom-climax-5').props.onclick();
  assert.doesNotMatch(scenePrompt(sceneKey).prompt, /dazed/);
  state.activeScene = { patron: { customerId: 'guest-2', startedAtSlot: state.slot,
    stage: 'sex_patron', elenaPleasure: 99 } };
  assert.doesNotMatch(scenePrompt(sceneKey).prompt, /female_orgasm|ahegao/,
    'another patron scene in the same slot must not inherit the prior climax');
  const playerSceneKey = sceneKey.replace('scene-patron_sex', 'scene-sex');
  state.activeScene = { sex: { type: 'sex', startedAtSlot: state.slot, elenaMoaning: 99 } };
  assert.doesNotMatch(scenePrompt(playerSceneKey).prompt, /female_orgasm/,
    'high player-scene pleasure alone must not add the climax module');
  state.activeScene.sex.elenaMoaning = 100;
  recordHeroineOrgasm(state.activeScene.sex, 'elenaClimaxCount', 'elenaClimaxedDuringScene', 1);
  assert.match(scenePrompt(playerSceneKey).prompt, /female_orgasm/);
  state.activeScene = { sex: { type: 'handjob', startedAtSlot: state.slot, elenaMoaning: 75,
    finish: { elenaAlsoOrgasmed: true } } };
  const beforeFinish = { ...state, characters: { ...state.characters, wife: { ...wife } } };
  wife.orgasmsToday += 1;
  hooks.heroineOrgasm.after(state, [beforeFinish, 'wife', {}]);
  assert.match(scenePrompt(playerSceneKey.replace('scene-sex', 'scene-handjob')).prompt, /female_orgasm/,
    'a finish-time heroine climax must be recognized without a tick climax counter');
  delete savedSettings.positionModulePrompts['climax-1'];
  if (originalOrgasmSlot === undefined) delete wife.lastOrgasmSlot;
  else wife.lastOrgasmSlot = originalOrgasmSlot;
  if (originalOrgasmsToday === undefined) delete wife.orgasmsToday;
  else wife.orgasmsToday = originalOrgasmsToday;
  state.slot = originalSlot;
  state.activeScene = { patron: { customerId: 'guest-1', stage: 'sex_patron', primarySlot: 'inside' } };
  selectModuleKind('pose', 'pose-8');
  const lyingPosition = findModule('position', node => node.props?.['aria-label'] === '손님 · 누워서 · 정상위');
  assert.ok(lyingPosition);
  lyingPosition.props.onclick();
  collectNodes().find(node => node.props?.['data-position-pose-link-save'] === 'pose-8').props.onclick();
  assert.equal(savedSettings.positionModulePoseAssignments['pose-8'], lyingPosition.props['data-position-module-id']);
  assert.ok(!savedSettings.positionModuleSelections['scene-patron_sex|grp-1|gslot-m']
    .includes(lyingPosition.props['data-position-module-id']),
  'the saved pose rule must replace the direct position selection in this scene');
  const linkedPose = hooks.imagePrompt.after({ ...positionBase, key: sceneKey,
    prompt: `${positionBase.prompt}, girl_on_top`,
    parts: positionBase.parts.map(part => part.label === '장면'
      ? { ...part, tags: `${part.tags}, girl_on_top` } : part) }, [wife, 'modules']);
  assert.match(linkedPose.prompt, /on_back, legs_up/);
  assert.match(linkedPose.prompt, /missionary/);
  assert.doesNotMatch(linkedPose.prompt, /sex from behind|bent_over|girl_on_top/,
    'a linked position must remove conflicting native scene-position tags');
  assert.match(linkedPose.prompt, /fellatio/,
    'a linked position must retain a separate native action');
  const otherSituation = 'scene-patron_handjob|grp-1|gslot-m';
  savedSettings.positionModuleSelections[otherSituation] = ['pose-8'];
  assert.match(hooks.imagePrompt.after({ ...positionBase,
    key: sceneKey.replace('scene-patron_sex', 'scene-patron_handjob') }, [wife, 'modules']).prompt,
    /missionary/, 'the linked position must follow the same female posture in another situation');
  delete savedSettings.positionModuleSelections[otherSituation];
  selectModuleKind('position', 'pose-9');
  const directPosition = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(directPosition.prompt, /cowgirl_position/);
  assert.doesNotMatch(directPosition.prompt, /missionary/,
    'a directly selected position must override the pose rule');
  const priorStudioUse = vmContext.WML.use;
  const studioTailFixtureKey = sceneKey.replace(/__v-\d+$/, '') + '__sleep-aip-b-othermod__v-9';
  assert.equal(hooks.imageKeyStudioTail.after(studioTailFixtureKey, [wife]), studioTailFixtureKey, 'other keys are unchanged without the Studio compatibility editor');
  vmContext.WML.use = id => id === 'imagestudio-compatible-attention-image-prompt' ? {} : undefined;
  const restoredStudioKey = hooks.imageKeyStudioTail.after(studioTailFixtureKey, [wife]);
  assert.match(restoredStudioKey, /__position-modules-[a-z0-9]+/);
  assert.match(restoredStudioKey, /__sleep-aip-b-othermod/);
  assert.match(restoredStudioKey, /__v-9$/);
  assert.equal(hooks.imageKeyStudioTail.after(restoredStudioKey, [wife]), restoredStudioKey, 'restoring the position key is idempotent');
  vmContext.WML.use = priorStudioUse;
  selectModuleKind('position', 'pose-9');
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /missionary/, 'removing the direct position must restore the pose rule');
  delete state.activeScene;
  selectModuleKind('pose', 'pose-5');
  selectModuleKind('action', 'action-9');
  collectNodes().find(node => node.tag === 'button' && node.children.includes('새 모듈 추가')).props.onclick();
  const customModuleId = savedSettings.positionModules[0].id;
  collectNodes().find(node => node.props?.['data-position-module-name'] === customModuleId)
    .props.onchange({ currentTarget: { value: '어두운 분위기' } });
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === `${customModuleId}:positivePrompt`)
    .props.onchange({ currentTarget: { value: '(aip_modular_mood_marker:1.2)' } });
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === `${customModuleId}:negativePrompt`)
    .props.onchange({ currentTarget: { value: '(aip_modular_negative_marker:1.15)' } });
  collectNodes().find(node => node.props?.['data-position-module-select'] === customModuleId)
    .props.onclick();
  assert.equal(collectNodes().find(node => node.props?.['data-position-module-select'] === customModuleId)
    .props['aria-pressed'], 'true', 'a selected mood chip should visibly stay active');
  const modularResult = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(modularResult.key, /__position-modules-/);
  assert.match(modularResult.prompt, /on_stomach/);
  assert.match(modularResult.prompt, /anal/);
  assert.match(modularResult.prompt, /aip_modular_mood_marker/);
  assert.match(modularResult.prompt, /\(aip_modular_mood_marker:1\.2\)/,
    'custom module weights must reach the generated Positive prompt');
  assert.doesNotMatch(modularResult.prompt, /sex from behind|bent_over/,
    'a module action should replace old scene posture');
  assert.match(modularResult.prompt, /first supporting man.*fellatio/,
    'a separate oral role must survive an action module for the main partner');
  assert.match(modularResult.prompt, /primary man in foreground:1\.3.*male torso visible:1\.2/,
    'the modular group layout should keep a visible primary man before any manual person preset');
  assert.match(modularResult.negativePrompt, /base_negative/);
  assert.match(modularResult.negativePrompt, /missing foreground man/);
  assert.match(modularResult.negativePrompt, /aip_modular_negative_marker/);
  assert.match(modularResult.negativePrompt, /\(aip_modular_negative_marker:1\.15\)/,
    'custom module weights must reach the generated Negative prompt');
  collectNodes().find(node => node.props?.['data-position-module-group-slot'] === '0')
    .props.onchange({ currentTarget: { value: 'f' } });
  assert.equal(savedSettings.positionModuleGroupLayouts['scene-patron_sex|grp-1|gslot-m'].groupSlots, 'f');
  collectNodes().find(node => node.props?.['data-position-module-person-preset'] === 'main')
    .props.onchange({ currentTarget: { value: 'vaginal-front' } });
  const extraTagsInput = collectNodes().find(node => node.props?.['data-position-module-person-tags'] === '0');
  extraTagsInput.props.oninput({ currentTarget: { value: '(aip_extra_man_marker:1.2)' } });
  extraTagsInput.props.onchange({ currentTarget: { value: '(aip_extra_man_marker:1.2)' } });
  const revisedGroupResult = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.notEqual(revisedGroupResult.key, modularResult.key,
    'changing an extra man must select a new image key');
  assert.match(revisedGroupResult.prompt, /primary man.*vaginal sex/);
  assert.match(revisedGroupResult.prompt, /first supporting man.*fingering.*aip_extra_man_marker/);
  assert.match(revisedGroupResult.prompt, /\(aip_extra_man_marker:1\.2\)/,
    'per-person prompt weights must reach the generated prompt');
  assert.doesNotMatch(revisedGroupResult.prompt, /first supporting man[^]*fellatio/,
    'the old oral role must be removed after choosing a hand role');
  assert.match(revisedGroupResult.key, /__position-modules-slots-f-/);
  const modularGenerationCount = generatedRequests.length;
  collectNodes().find(node => node.tag === 'button' && node.children.includes('현재 이미지 재생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(generatedRequests.length, modularGenerationCount + 1);
  assert.match(generatedRequests.at(-1).imageKey, /__position-modules-/);
  assert.match(generatedRequests.at(-1).negativePrompt, /aip_modular_negative_marker/);
  assert.ok(savedModData.positionModuleOverrides?.['scene-patron_sex|grp-1|gslot-m']);
  assert.equal(savedModData.positionOverrides, undefined,
    'module generation must not overwrite the legacy position save');
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === `${customModuleId}:negativePrompt`)
    .props.onchange({ currentTarget: { value: 'aip_modular_negative_changed' } });
  const revisedModularResult = hooks.imagePrompt.after(modularResult, [wife, 'modules']);
  assert.notEqual(revisedModularResult.key, modularResult.key,
    'editing a module must not reuse an image generated from its old prompt');
  assert.match(revisedModularResult.negativePrompt, /aip_modular_negative_changed/);
  assert.doesNotMatch(revisedModularResult.negativePrompt, /aip_modular_negative_marker/,
    'reapplying modules must replace the old Negative contribution');
  collectNodes().find(node => node.props?.['data-position-mode'] === 'legacy').props.onclick();
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).key,
    /__position-doggystyle-/, 'switching back should restore the legacy position behavior');
  collectNodes().find(node => node.props?.['data-position-mode'] === 'modules').props.onclick();
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).key,
    /__position-modules-/, 'the saved module combination should return after switching modes');
  collectNodes().find(node => node.props?.['data-export-section'] === 'positionModules')
    .props.onchange({ currentTarget: { checked: true } });
  collectNodes().find(node => node.tag === 'button' && node.children.includes('JSON 내보내기')).props.onclick();
  const moduleExport = JSON.parse(exportedText);
  assert.equal(moduleExport.positionMode, 'modules');
  assert.equal(moduleExport.positionModules[0].name, '어두운 분위기');
  assert.ok(moduleExport.positionModuleSelections['scene-patron_sex|grp-1|gslot-m'].includes(customModuleId));
  assert.equal(moduleExport.positionModuleGroupLayouts['scene-patron_sex|grp-1|gslot-m'].groupSlots, 'f');
  assert.equal(moduleExport.positionModulePoseAssignments['pose-8'], lyingPosition.props['data-position-module-id']);
  savedSettings.positionMode = 'legacy';
  savedSettings.positionModules = [];
  savedSettings.positionModuleSelections = {};
  savedSettings.positionModuleGroupLayouts = {};
  savedSettings.positionModulePoseAssignments = {};
  await importInput.props.onchange({ currentTarget: { files: [{ name: 'modules.json',
    text: async () => JSON.stringify({ format: moduleExport.format, version: moduleExport.version,
      positionMode: moduleExport.positionMode, positionModules: moduleExport.positionModules,
      positionModuleSelections: moduleExport.positionModuleSelections,
      positionModuleGroupLayouts: moduleExport.positionModuleGroupLayouts,
      positionModulePoseAssignments: { ...moduleExport.positionModulePoseAssignments,
        'pose-5': 'action-9', invalid_pose: 'pose-9' } }) }], value: 'modules.json' } });
  assert.equal(savedSettings.positionMode, 'modules');
  assert.equal(savedSettings.positionModuleGroupLayouts['scene-patron_sex|grp-1|gslot-m'].groupSlots, 'f');
  assert.equal(savedSettings.positionModulePoseAssignments['pose-8'], lyingPosition.props['data-position-module-id']);
  assert.equal(Object.keys(savedSettings.positionModulePoseAssignments).length, 1,
    'import must reject non-pose keys and non-position targets');
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /aip_modular_mood_marker/, 'module settings should survive JSON import');
  savedSettings.positionModuleGroupLayouts = {};
  state.activeScene = { patron: { customerId: 'guest-1', stage: 'sex_patron', primarySlot: 'inside' } };
  selectModuleKind('pose', 'pose-8');
  collectNodes().find(node => node.props?.['data-position-pose-link-remove'] === 'pose-8').props.onclick();
  assert.equal(savedSettings.positionModulePoseAssignments['pose-8'], undefined,
    'the pose rule must be removable from the same inline control');
  delete state.activeScene;
  savedSettings.positionModuleSelections = {};
  state.activeScene = { patron: { customerId: 'guest-1', stage: 'sex_patron', primarySlot: 'inside' } };
  controllerDomButtons = [];
  controllerPanels = [];
  vmContext.__waywardActExpansion = undefined;
  vmContext.__waywardHusbandLife = undefined;
  vmContext.__waywardScenePose = undefined;
  settingsWin.refresh();
  const staticAction = findModule('action', node => node.props?.['aria-label'] === '손님 · 행위 · 몸 비비기');
  const staticPose = findModule('position', node => node.props?.['aria-label'] === '손님 · 엎드려 · 후배위');
  const staticCaress = findModule('body', node => node.props?.['aria-label']?.includes('엉덩이 때리기'));
  const staticHand = findModule('hands', node => node.props?.['aria-label'] === '손님 · 오른손 · 가슴');
  const staticClothing = findModule('clothes', node => node.props?.['aria-label'] === '손님 · 옷 상태 · 가슴 드러남');
  const staticPlayerAct = findModule('action', node => node.props?.['aria-label'] === '당신 · 행위 · 깊게 입');
  assert.ok(staticAction && staticPose && staticCaress && staticHand && staticClothing && !staticPlayerAct,
    'a patron scene should expose separate action, position, body, hand, and clothing categories without either mod');
  const patronPosition = label => findModule('position', node =>
    node.props?.['aria-label'] === `손님 · 누워서 · ${label}`);
  for (const [label, posture, negative] of [
    ['정상위', /missionary, on_back, boy_on_top/, 'girl_on_top, cowgirl_position'],
    ['프레스(굴곡위)', /mating_press, missionary, on_back, folded, boy_on_top/, 'solo, girl_on_top'],
    ['측위', /spooning, on_side, lying/, 'standing_sex'],
  ]) {
    const chip = patronPosition(label);
    assert.match(chip.props.title, posture, `${label} must include its supported posture`);
    assert.match(chip.props.title, new RegExp(`Negative: ${negative}`),
      `${label} must reject the reported wrong composition`);
    chip.props.onclick();
    const result = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
    assert.match(result.prompt, posture);
    assert.match(result.prompt, /sex, vaginal, penis, pussy/,
      `${label} must retain the current penile penetration without an external pose API`);
    assert.match(result.negativePrompt, new RegExp(negative));
  }
  patronPosition('프레스(굴곡위)').props.onclick();
  state.activeScene.patron.primarySlot = 'inside_anal';
  const analPress = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(analPress.prompt, /sex, anal, penis, ass/);
  assert.doesNotMatch(analPress.prompt, /sex, vaginal, penis, pussy/,
    'the same press pose must follow the current insertion site');
  state.activeScene.patron.primarySlot = 'inside';
  patronPosition('측위').props.onclick();
  const sideModuleId = patronPosition('측위').props['data-controller-module-select'];
  savedSettings.positionModulePrompts = { [sideModuleId]: {
    positivePrompt: 'hetero, on_side', negativePrompt: '' } };
  assert.match(patronPosition('측위').props.title, /spooning, on_side, lying.*Negative: standing_sex/,
    'a saved copy of the old module default must use the corrected defaults');
  savedSettings.positionModulePrompts[sideModuleId] = {
    positivePrompt: 'hetero, spooning, on_side, lying', negativePrompt: 'standing_sex' };
  assert.match(patronPosition('측위').props.title,
    /both partners lying on their sides.*man lying on his side directly behind her.*Negative: standing_sex, missionary, on_back, boy_on_top/,
    'the previous saved side-position default must migrate its pose and composition Negative');
  savedSettings.positionModulePrompts[sideModuleId].negativePrompt = 'custom_side_negative';
  assert.match(patronPosition('측위').props.title, /Negative: custom_side_negative/,
    'a custom side-position Negative must be preserved');
  savedSettings.positionModulePrompts[sideModuleId].positivePrompt = 'standing_sex';
  savedSettings.positionModulePrompts[sideModuleId].negativePrompt = '';
  assert.doesNotMatch(patronPosition('측위').props.title, /Negative: standing_sex/,
    'a custom module Positive must not inherit an incompatible default Negative');
  delete savedSettings.positionModulePrompts[sideModuleId];
  savedSettings.positionModuleSelections = {};
  const moduleDirection = node => flattenNodes(node).find(child => child.tag === 'small')?.children?.[0];
  assert.equal(moduleDirection(staticAction), '아내 ↔ 손님');
  assert.equal(moduleDirection(staticHand), '손님 → 아내 · 손 위치');
  assert.match(staticHand.props.title, /Negative: female_masturbation/);
  assert.match(findModule('action', node => node.props?.['data-position-module-id'] === 'action-2').props.title,
    /hand_on_another's_crotch.*Negative: female_masturbation, hand_on_own_crotch, spread_pussy/);
  savedSettings.positionModulePrompts['action-2'] = {
    positivePrompt: "hetero, fingering, hand_on_another's_crotch, clitoral_stimulation", negativePrompt: '' };
  assert.match(findModule('action', node => node.props?.['data-position-module-id'] === 'action-2').props.title,
    /man fingering woman's vagina:1\.3/,
    'a saved copy of the old fingering default must adopt the explicit actor and vaginal target');
  delete savedSettings.positionModulePrompts['action-2'];
  const patronSexActionId = findModule('action', node => node.props?.['aria-label'] === '손님 · 행위 · 성관계')
    .props['data-controller-module-select'];
  savedSettings.positionModulePrompts = {
    'action-8': { positivePrompt: 'hetero, vaginal', negativePrompt: '' },
    [patronSexActionId]: { positivePrompt: 'hetero, vaginal', negativePrompt: '' },
  };
  assert.match(findModule('action', node => node.props?.['data-position-module-id'] === 'action-8').props.title,
    /hetero, sex, vaginal, penis, pussy/, 'a stored copy of the former default must adopt the new action');
  assert.match(findModule('action', node => node.props?.['data-controller-module-select'] === patronSexActionId).props.title,
    /hetero, sex, vaginal, penis, pussy/);
  delete savedSettings.positionModulePrompts['action-8'];
  delete savedSettings.positionModulePrompts[patronSexActionId];
  assert.equal(moduleDirection(staticClothing), '상태 대상: 아내');
  assert.equal(moduleDirection(findModule('action', node => node.props?.['data-position-module-id'] === 'action-4')),
    '아내 → 손님', 'built-in oral sex must identify who gives and who receives');
  const patronOral = findModule('action', node => node.props?.['aria-label'] === '손님 · 행위 · 입으로 애무받기');
  const patronCunnilingus = findModule('action', node => node.props?.['aria-label'] === '손님 · 행위 · 그녀를 입으로 애무하기');
  assert.match(patronOral.props.title, /Positive: hetero, fellatio, penis, open_mouth/);
  assert.doesNotMatch(patronOral.props.title, /licking_penis/,
    'full oral contact must not default to exterior licking');
  assert.match(patronCunnilingus.props.title, /Positive: hetero, cunnilingus, pussy/);
  assert.match(findModule('action', node => node.props?.['data-position-module-id'] === 'action-12').props.title,
    /69, fellatio, cunnilingus/, '69 must describe both mouth actions, not only their position');
  const nippleCaress = findModule('body', node => node.props?.['aria-label'] === '손님 · 기본 · 젖꼭지 빨기');
  const neckCaress = findModule('body', node => node.props?.['aria-label'] === '손님 · 기본 · 목덜미·귀');
  const fingerCaress = findModule('body', node => node.props?.['aria-label'] === '손님 · 입·손가락 · 손가락 빨리기');
  assert.match(nippleCaress.props.title, /breast_sucking, face_to_breasts/);
  assert.match(neckCaress.props.title, /kissing_neck, kissing_ear/);
  assert.equal(moduleDirection(neckCaress), '손님 → 아내');
  assert.match(findModule('body', node => node.props?.['aria-label'] === '손님 · 거칠게 · 목덜미 깨물기').props.title,
    /biting_neck/);
  const tongueKiss = findModule('body', node => node.props?.['aria-label'] === '손님 · 입·손가락 · 혀 얽기');
  assert.match(tongueKiss.props.title, /Positive: hetero, kiss, french_kiss/);
  assert.match(tongueKiss.props.title, /Negative: tongue_out/);
  assert.equal(moduleDirection(tongueKiss), '아내 ↔ 손님');
  tongueKiss.props.onclick();
  const tongueKissPrompt = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(tongueKissPrompt.prompt, /hetero, kiss, french_kiss/);
  assert.match(tongueKissPrompt.negativePrompt, /tongue_out/);
  assert.doesNotMatch(tongueKissPrompt.parts.find(part => part.label.includes('혀 얽기')).tags,
    /(?:^|, )tongue(?:,|$)/, 'a tongue-kiss module must not become a solo tongue-out expression');
  findModule('body', node => node.props?.['data-controller-module-select']
    === tongueKiss.props['data-controller-module-select']).props.onclick();
  assert.doesNotMatch(hooks.imagePrompt.after(tongueKissPrompt, [wife, 'modules']).negativePrompt, /tongue_out/,
    'turning off the tongue-kiss module must remove its Negative tag');
  const patronAnalHand = findModule('body', node => node.props?.['aria-label'] === '손님 · 입·손가락 · 애널 손가락');
  assert.match(patronAnalHand.props.title, /anal_fingering, fingering, hand_on_another's_ass/);
  assert.equal(moduleDirection(patronAnalHand), '손님 → 아내');
  assert.match(fingerCaress.props.title, /finger_sucking, finger_in_another's_mouth/);
  assert.equal(moduleDirection(fingerCaress), '아내 → 손님');
  fingerCaress.props.onclick();
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /finger_sucking, finger_in_another's_mouth/);
  findModule('body', node => node.props?.['data-controller-module-select']
    === fingerCaress.props['data-controller-module-select']).props.onclick();
  patronOral.props.onclick();
  const patronOralPrompt = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(patronOralPrompt.prompt, /fellatio, penis, open_mouth/);
  assert.doesNotMatch(patronOralPrompt.prompt, /licking_penis|cum_in_mouth/);
  findModule('action', node => node.props?.['data-controller-module-select']
    === patronOral.props['data-controller-module-select']).props.onclick();
  findModule('action', node => node.props?.['data-position-module-id'] === 'action-12').props.onclick();
  const mutualOralPrompt = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(mutualOralPrompt.prompt, /69, fellatio, cunnilingus/);
  assert.match(mutualOralPrompt.prompt, /one penis in mouth/);
  findModule('action', node => node.props?.['data-position-module-id'] === 'action-12').props.onclick();
  state.activeScene.sex = { type: 'deepthroat' };
  settingsWin.refresh();
  const playerDeepthroat = findModule('action', node => node.props?.['aria-label'] === '당신 · 행위 · 깊게 입', 'you');
  assert.ok(playerDeepthroat,
  'both actors’ modules should appear when both scenes are active');
  assert.equal(moduleDirection(playerDeepthroat), '당신 → 아내');
  assert.equal(moduleDirection(findModule('action', node => node.props?.['aria-label'] === '당신 · 행위 · 69', 'you')),
    '아내 ↔ 당신', 'mutual oral sex must keep both actors in the displayed direction');
  const wifeWish = findModule('action', node => node.props?.['aria-label'] === '당신 · 그녀의 바람 · 항문', 'you');
  assert.equal(moduleDirection(wifeWish), '아내의 바람 · 현재 행위 아님');
  assert.match(wifeWish.props.title, /Positive: 없음/, 'a preference must not become an active anal act');
  const bothActors = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(bothActors.prompt, /vaginal/);
  assert.match(bothActors.prompt, /deepthroat/);
  assert.match(bothActors.prompt, /irrumatio/, 'rough oral sex must carry the male actor direction');
  assert.match(bothActors.prompt, /irrumatio, deepthroat, (?:\(fellatio:[\d.]+\)|fellatio), open_mouth/);
  assert.match(bothActors.prompt, /(?:^|, )penis(?:,|$)/,
    'a shared anatomy tag should remain after the two actions are deduplicated');
  const soloYouKey = 'pippa__scene-deepthroat__outfit-modest__room-bedroom__v-0';
  const soloPatronKey = 'pippa__scene-patron_sex__outfit-modest__room-bedroom__v-0';
  const soloBase = key => ({ key, prompt: 'best quality, 1girl, 1boy', negativePrompt: '',
    parts: [{ label: '품질', tags: 'best quality' }, { label: '성별', tags: '1girl, 1boy' }] });
  const beforeSoloSelections = savedSettings.positionModuleSelections;
  savedSettings.positionModuleSelections = { ...savedSettings.positionModuleSelections,
    'scene-deepthroat': ['pose-1'], 'scene-patron_sex': ['pose-1'] };
  const soloYou = hooks.imagePrompt.after(soloBase(soloYouKey), [wife, 'modules']);
  assert.match(soloYou.prompt, /irrumatio/,
    'a single player scene must include the player’s current act');
  assert.doesNotMatch(soloYou.prompt, /vaginal/,
    'an unrelated active patron scene must not automatically add a second actor’s act');
  const soloPatron = hooks.imagePrompt.after(soloBase(soloPatronKey), [wife, 'modules']);
  assert.match(soloPatron.prompt, /vaginal/,
    'a single patron scene must include the patron’s current act');
  assert.doesNotMatch(soloPatron.prompt, /irrumatio|deepthroat/,
    'an unrelated active player scene must not automatically add a second actor’s act');
  savedSettings.positionModuleSelections['scene-deepthroat'] = ['pose-1', patronSexActionId];
  const explicitPatron = hooks.imagePrompt.after(soloBase(soloYouKey), [wife, 'modules']);
  assert.match(explicitPatron.prompt, /vaginal/,
    'a manually selected patron module remains available in the player scene');
  savedSettings.positionModuleSelections = beforeSoloSelections;
  assert.match(findModule('action', node => node.props?.['aria-label'] === '당신 · 행위 · 뒤 손가락', 'you').props.title,
    /anal_fingering, fingering, hand_on_another's_ass/);
  const pantiesCaress = findModule('body', node => node.props?.['aria-label'] === '당신 · 기본 · 팬티 위로 핥기', 'you');
  assert.match(pantiesCaress.props.title, /licking_panties, panties/);
  assert.equal(moduleDirection(pantiesCaress), '당신 → 아내');
  pantiesCaress.props.onclick();
  const pantiesPrompt = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt;
  assert.match(pantiesPrompt, /licking_panties, panties/);
  assert.doesNotMatch(pantiesPrompt, /cunnilingus/,
    'licking over panties must not become bare-genital oral sex');
  findModule('body', node => node.props?.['data-controller-module-select']
    === pantiesCaress.props['data-controller-module-select'], 'you').props.onclick();
  const patronClothes = findModule('clothes', node => node.props?.['aria-label'] === '손님 · 옷 상태 · 가슴 드러남');
  patronClothes.props.onclick();
  const youNude = findModule('clothes', node => node.props?.['aria-label'] === '당신 · 옷 상태 · 완전 나체', 'you');
  youNude.props.onclick();
  assert.ok(savedSettings.positionModuleSelections['scene-patron_sex|grp-1|gslot-m']
    .includes(patronClothes.props['data-position-module-id']),
  'changing the player clothing module must preserve patron clothing');
  assert.ok(savedSettings.positionModuleSelections['scene-patron_sex|grp-1|gslot-m']
    .includes(youNude.props['data-position-module-id']));
  savedSettings.positionModuleSelections = {};
  delete state.activeScene.sex;
  settingsWin.refresh();
  findModule('action', node => node.props?.['data-position-module-id'] === staticAction.props['data-position-module-id']).props.onclick();
  const secondPatronAct = findModule('action', node => node.props?.['aria-label'] === '손님 · 행위 · 손으로 애무받기');
  assert.equal(moduleDirection(secondPatronAct), '아내 → 손님');
  assert.doesNotMatch(secondPatronAct.props.title, /female_masturbation|spread_pussy/,
    'a woman-to-man hand action must not receive the male-hand guard');
  secondPatronAct.props.onclick();
  assert.ok(savedSettings.positionModuleSelections['scene-patron_sex|grp-1|gslot-m'].includes(staticAction.props['data-position-module-id']),
    'group scenes must retain multiple patron actions');
  const staticPoseId = staticPose.props['data-position-module-id'];
  const staticCaressId = staticCaress.props['data-controller-module-select'];
  findModule('position', node => node.props?.['data-position-module-id'] === staticPoseId).props.onclick();
  findModule('body', node => node.props?.['data-controller-module-select'] === staticCaressId).props.onclick();
  findModule('hands', node => node.props?.['data-controller-module-select'] === staticHand.props['data-controller-module-select']).props.onclick();
  findModule('clothes', node => node.props?.['data-controller-module-select'] === staticClothing.props['data-controller-module-select']).props.onclick();
  const withoutController = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  for (const tag of ['frottage', 'handjob', "grabbing_another's_penis", 'doggystyle', 'spanking',
    "grabbing_another's_breast", 'breasts_out'])
    assert.match(withoutController.prompt, new RegExp(tag));
  findModule('body', node => node.props?.['data-controller-module-edit'] === staticCaressId).props.onclick();
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === `${staticCaressId}:positivePrompt`)
    .props.onchange({ currentTarget: { value: 'spanking, blush' } });
  assert.equal(savedSettings.positionModulePrompts[staticCaressId].positivePrompt, 'spanking, blush');
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt, /spanking, blush/);
  savedSettings.positionModuleSelections = {};
  const controllerButton = (label, group, active = false, actorId = 'main') => {
    const panel = { hidden: false, closest: () => null,
      querySelector: selector => selector === '.wpc-select' ? { value: actorId } : null };
    const row = { querySelector: () => ({ textContent: group }) };
    return {
      textContent: label,
      classList: { contains: name => name === 'wpc-active' && active },
      getAttribute: () => null,
      closest(selector) {
        if (selector === '.wpc-ctl, .wpc-dock, .hlc-dock') return panel;
        if (selector === '.wpc-ctl-row, .hlc-row') return row;
        if (selector === 'button.wpc-ctl-cmd, button.hlc-chip') return this;
        return null;
      },
    };
  };
  state.activeScene.patron.stage = 'rubbing_patron';
  controllerDomButtons = [controllerButton('삽입 준비', '삽입', true)];
  const preparation = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  const preparationTags = preparation.parts.find(part => part.label.includes('삽입 준비'))?.tags;
  assert.match(preparationTags, /imminent_vaginal, penis_on_pussy/);
  assert.ok(!preparationTags.split(', ').some(tag => ['vaginal', 'anal'].includes(tag)),
    'preparation must describe contact with the wife, not completed intercourse');
  assert.doesNotMatch(preparation.prompt, /(?:^|, )sex(?:,|$)/,
    'preparation must not inherit intercourse from the live-stage fallback');
  controllerDomButtons = [controllerButton('뒤로 삽입 준비', '삽입', true)];
  const analPreparation = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  const analPreparationTags = analPreparation.parts.find(part => part.label.includes('뒤로 삽입 준비'))?.tags;
  assert.match(analPreparationTags, /imminent_anal, penis_on_ass/);
  assert.ok(!analPreparationTags.split(', ').some(tag => ['vaginal', 'anal'].includes(tag)));
  state.activeScene.patron.stage = 'sex_patron';
  state.activeScene.sex = { type: 'deepthroat' };
  controllerDomButtons = [controllerButton('양쪽 장면 주인공 동작', '그 밖'),
    controllerButton('입구에 맞댐 ✓ (뒤)', '삽입')];
  settingsWin.refresh();
  assert.ok(savedSettings.controllerButtonCatalog.some(entry => entry.key === 'you|그 밖|양쪽 장면 주인공 동작'),
    'the patron-control panel belongs to the player when the player scene is active');
  assert.ok(!savedSettings.controllerButtonCatalog.some(entry => entry.key === 'patron|삽입|입구에 맞댐 ✓ (뒤)'),
    'the controller status mark must not become a separate patron module');
  delete state.activeScene.sex;
  controllerDomButtons = [];
  const poseButton = controllerButton('후배위 ♥', '체위', true);
  const cuffButton = controllerButton('수갑 채우기', '나쁜 손님');
  const defaultButton = controllerButton('게임대로', '사정 위치', true);
  controllerDomButtons = [poseButton, cuffButton, defaultButton];
  const controllerButtonsResult = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(controllerButtonsResult.prompt, /doggystyle/);
  assert.ok(savedSettings.controllerButtonCatalog.some(entry => entry.key === 'patron|체위|후배위'),
    'a newly observed controller layout must become an editable module');
  const finishTarget = controllerButton('입 안에', '사정 위치', true);
  controllerDomButtons = [poseButton, finishTarget];
  assert.doesNotMatch(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /cum_in_mouth/, 'a selected finish destination must not look like a completed climax');
  const finishTargetId = findModule('action', node => node.props?.['aria-label'] === '손님 · 사정 위치 · 입 안에')
    .props['data-controller-module-select'];
  findModule('action', node => node.props?.['data-controller-module-select'] === finishTargetId).props.onclick();
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /cum_in_mouth/, 'manual module selection can still request the finish tag');
  findModule('action', node => node.props?.['data-controller-module-select'] === finishTargetId).props.onclick();
  controllerDomButtons = [poseButton, cuffButton, defaultButton];
  const hiddenButton = controllerButton('미약 타기', '나쁜 손님', true);
  let foldOpen = false;
  const foldedPanel = { hidden: false, closest: () => null,
    querySelectorAll: selector => selector === 'button.wpc-ctl-fold' ? [{ textContent: `${foldOpen ? '▾' : '▸'} 나쁜 손님`, click() {
      foldOpen = !foldOpen;
      controllerDomButtons = foldOpen ? [poseButton, cuffButton, defaultButton, hiddenButton]
        : [poseButton, cuffButton, defaultButton];
    } }] : [] };
  controllerPanels = [foldedPanel];
  settingsWin.refresh();
  assert.equal(foldOpen, false, 'catalog scan must restore the controller fold');
  assert.ok(findModule('other', node => node.props?.['aria-label']?.includes('미약 타기')),
    'folded commands are available even before the panel opens');
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt, /dazed/,
    'a folded active command should still contribute its tags');
  const cuffModuleId = findModule('other', node => node.props?.['aria-label']?.includes('수갑 채우기'))
    .props['data-controller-module-select'];
  settingsWin.refresh();
  assert.ok(findModule('other', node => node.props?.['data-controller-module-select'] === cuffModuleId));
  findModule('other', node => node.props?.['data-controller-module-edit'] === cuffModuleId).props.onclick();
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === `${cuffModuleId}:positivePrompt`)
    .props.onchange({ currentTarget: { value: 'handcuffs, bound wrists!' } });
  assert.equal(savedSettings.positionModulePrompts[cuffModuleId].positivePrompt, 'handcuffs, bound wrists!',
    'free-form prompt text must not be rejected by Danbooru tag rules');
  const spacedTagInput = collectNodes().find(node => node.props?.['data-position-module-prompt'] === `${cuffModuleId}:positivePrompt`);
  spacedTagInput.props.oninput({ currentTarget: { value: 'from ' } });
  spacedTagInput.props.oninput({ currentTarget: { value: 'from behind' } });
  assert.equal(savedSettings.positionModulePrompts[cuffModuleId].positivePrompt, 'from behind',
    'typing a space inside a tag must save the whole tag');
  spacedTagInput.props.onchange({ currentTarget: { value: 'from behind' } });
  assert.equal(savedSettings.positionModulePrompts[cuffModuleId].positivePrompt, 'from behind');
  const weightedPrompt = '(from behind:1.25), cinematic lighting';
  spacedTagInput.props.oninput({ currentTarget: { value: weightedPrompt } });
  assert.equal(savedSettings.positionModulePrompts[cuffModuleId].positivePrompt, weightedPrompt,
    'a weight and free-form phrase must save while typing');
  spacedTagInput.props.onchange({ currentTarget: { value: weightedPrompt } });
  assert.equal(savedSettings.positionModulePrompts[cuffModuleId].positivePrompt, weightedPrompt);
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === `${cuffModuleId}:positivePrompt`)
    .props.onchange({ currentTarget: { value: 'handcuffs, bound_wrists' } });
  assert.equal(savedSettings.positionModulePrompts[cuffModuleId].positivePrompt, 'handcuffs, bound_wrists');
  assert.equal(collectNodes().some(node => node.props?.['data-position-danbooru-tag']), false,
    'module editors should use the side tag library without a duplicate bottom chooser');
  assert.ok(collectNodes().some(node => node.props?.['data-position-module-translation'] === `${cuffModuleId}:positivePrompt`));
  collectNodes().find(node => node.props?.['data-custom-tag-label'] === '')
    .props.oninput({ currentTarget: { value: '내 시험 태그' } });
  collectNodes().find(node => node.props?.['data-custom-tag-english'] === '')
    .props.oninput({ currentTarget: { value: 'custom_tag' } });
  collectNodes().find(node => node.props?.['data-custom-tag-add'] === '').props.onclick();
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === `${cuffModuleId}:positivePrompt`)
    .props.onchange({ currentTarget: { value: '내 시험 태그, bound_wrists' } });
  assert.equal(savedSettings.positionModulePrompts[cuffModuleId].positivePrompt, '내 시험 태그, bound_wrists',
    'typing a Korean library label must not replace the authored prompt');
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === `${cuffModuleId}:positivePrompt`)
    .props.onchange({ currentTarget: { value: 'handcuffs, bound_wrists' } });
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === `${cuffModuleId}:positivePrompt`).props.onfocus();
  await collectNodes().find(node => node.props?.['data-library-tag'] === 'rope').props.onclick();
  assert.match(savedSettings.positionModulePrompts[cuffModuleId].positivePrompt, /rope/);
  await collectNodes().find(node => node.props?.['data-library-tag'] === 'garter belt').props.onclick();
  assert.match(savedSettings.positionModulePrompts[cuffModuleId].positivePrompt, /garter belt/,
    'a library tag with a space must be inserted into the selected module');
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === `${cuffModuleId}:positivePrompt`)
    .props.onchange({ currentTarget: { value: 'handcuffs, bound_wrists, rope, garter belt, (garter belt:1.3)' } });
  collectNodes().find(node => node.props?.['data-position-module-prompt'] === `${cuffModuleId}:negativePrompt`)
    .props.onchange({ currentTarget: { value: '(aip_weighted_negative_marker:1.15)' } });
  assert.equal(savedSettings.positionModulePrompts[cuffModuleId].positivePrompt,
    'handcuffs, bound_wrists, rope, garter belt, (garter belt:1.3)');
  findModule('other', node => node.props?.['data-controller-module-select'] === cuffModuleId).props.onclick();
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt, /bound_wrists/);
  const weightedControllerPrompt = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(weightedControllerPrompt.prompt, /\(garter belt:1\.3\)/,
    'a selected module must pass a weighted tag into the generated prompt');
  assert.deepEqual(weightedControllerPrompt.prompt.split(', ').filter(tag => tag.includes('garter belt')),
    ['(garter belt:1.3)'], 'deduplication must keep the weighted tag over its plain copy');
  assert.match(weightedControllerPrompt.negativePrompt, /\(aip_weighted_negative_marker:1\.15\)/);
  findModule('other', node => node.props?.['data-controller-module-select'] === cuffModuleId).props.onclick();
  documentClickListener({ target: cuffButton });
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt, /handcuffs/,
    'a just clicked controller command should contribute for its immediate scene');
  state.slot += 2;
  assert.doesNotMatch(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt, /handcuffs/,
    'one shot controller actions must expire after the next minute');
  state.slot -= 2;
  documentClickListener({ target: defaultButton });
  settingsWin.refresh();
  collectNodes().find(node => node.props?.['data-position-state-prompt'] === '')
    .props.onchange({ currentTarget: { value: 'module_state_marker' } });
  collectNodes().find(node => node.props?.['data-position-state-only'] === '')
    .props.onchange({ currentTarget: { checked: true } });
  const onlyStateModule = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(onlyStateModule.prompt, /module_state_marker/);
  assert.doesNotMatch(onlyStateModule.prompt, /doggystyle|handcuffs/);
  collectNodes().find(node => node.props?.['data-position-state-only'] === '')
    .props.onchange({ currentTarget: { checked: false } });
  collectNodes().find(node => node.props?.['data-position-state-prompt'] === '')
    .props.onchange({ currentTarget: { value: '' } });
  findModule('other', node => node.props?.['data-controller-module-edit'] === cuffModuleId).props.onclick();
  assert.ok(savedSettings.customTags.some(entry => entry.tag === 'custom_tag'));
  collectNodes().find(node => node.props?.['data-export-section'] === 'customTags')
    .props.onchange({ currentTarget: { checked: true } });
  collectNodes().find(node => node.tag === 'button' && node.children.includes('JSON 내보내기')).props.onclick();
  const controllerExport = JSON.parse(exportedText);
  assert.ok(controllerExport.controllerButtonCatalog.some(entry => entry.key === 'patron|체위|후배위'));
  assert.equal(controllerExport.positionModulePrompts[cuffModuleId].positivePrompt,
    'handcuffs, bound_wrists, rope, garter belt, (garter belt:1.3)');
  assert.equal(controllerExport.positionModulePrompts[cuffModuleId].negativePrompt,
    '(aip_weighted_negative_marker:1.15)');
  assert.equal(controllerExport.guestAppearance, true);
  assert.ok(controllerExport.customTags.some(entry => entry.tag === 'custom_tag'));
  savedSettings.positionModulePrompts = {};
  savedSettings.controllerButtonCatalog = [];
  savedSettings.customTags = [];
  savedSettings.guestAppearance = false;
  await importInput.props.onchange({ currentTarget: { files: [{ name: 'controller-modules.json',
    text: async () => JSON.stringify({ format: controllerExport.format, version: controllerExport.version,
      positionModulePrompts: controllerExport.positionModulePrompts,
       guestAppearance: controllerExport.guestAppearance,
      controllerButtonCatalog: controllerExport.controllerButtonCatalog,
       customTags: controllerExport.customTags }) }], value: 'controller-modules.json' } });
  assert.ok(savedSettings.controllerButtonCatalog.some(entry => entry.key === 'patron|체위|후배위'));
  assert.match(savedSettings.positionModulePrompts[cuffModuleId].positivePrompt, /bound_wrists/);
  assert.match(savedSettings.positionModulePrompts[cuffModuleId].positivePrompt, /\(garter belt:1\.3\)/);
  assert.equal(savedSettings.positionModulePrompts[cuffModuleId].negativePrompt,
    '(aip_weighted_negative_marker:1.15)');
  assert.equal(savedSettings.guestAppearance, true);
  assert.ok(savedSettings.customTags.some(entry => entry.tag === 'custom_tag'));
  controllerDomButtons = [];
  controllerPanels = [];
  state.slot += 1;
  let controllerPose = '정상위';
  vmContext.__waywardActExpansion = { pose: { now: () => ({ customerId: 'guest-1', group: 'front', pose: controllerPose }) } };
  const controllerFront = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(controllerFront.prompt, /missionary, on_back, boy_on_top/);
  assert.match(controllerFront.negativePrompt, /girl_on_top, cowgirl_position/);
  assert.match(controllerFront.prompt, /vaginal/);
  assert.match(controllerFront.prompt, /fellatio/, 'another patron action should stay in the group prompt');
  assert.doesNotMatch(controllerFront.prompt, /sex from behind|bent_over/,
    'the controller pose must replace native pose tags without losing the current action');
  settingsWin.refresh();
  assert.equal(findModule('position', node => node.props?.['data-position-module-kind'] === 'position'
    && node.props?.['data-position-module-id'] === '').props['aria-pressed'], 'true');
  controllerPose = '프레스(굴곡위)';
  const controllerPress = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(controllerPress.prompt, /mating_press, missionary, on_back, folded, boy_on_top/);
  assert.match(controllerPress.negativePrompt, /solo, girl_on_top/);
  controllerPose = '측위';
  const controllerSide = hooks.imagePrompt.after(controllerPress, [wife, 'modules']);
  assert.match(controllerSide.prompt, /spooning, on_side, lying/);
  assert.match(controllerSide.prompt, /both partners lying on their sides.*man lying on his side directly behind her/);
  assert.doesNotMatch(controllerSide.prompt, /missionary|on_back|boy_on_top/,
    'the previous front-facing pose must not remain in the side-position Positive');
  assert.match(controllerSide.negativePrompt, /standing_sex, missionary, on_back, boy_on_top/);
  assert.notEqual(controllerSide.key, controllerPress.key,
    'switching to side position must use a distinct image key');
  assert.doesNotMatch(controllerSide.negativePrompt, /girl_on_top|cowgirl_position/,
    'changing the observed pose must remove the previous pose Negative');
  controllerPose = '후배위';
  const controllerBack = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.notEqual(controllerBack.key, controllerFront.key, 'controller pose changes need a new image key');
  assert.match(controllerBack.prompt, /doggystyle/);
  assert.match(controllerBack.prompt, /\(doggystyle:1\.3\)/, 'the controller rear pose must carry its stronger emphasis');
  assert.match(controllerBack.negativePrompt, /missionary/, 'the controller rear pose must exclude conflicting postures');
  settingsWin.refresh();
  selectModuleKind('pose', 'pose-5');
  assert.equal(collectNodes().find(node => node.props?.['data-position-module-kind'] === 'pose'
    && node.props?.['data-position-module-id'] === 'pose-5').props['aria-pressed'], 'true');
  const manualPose = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(manualPose.prompt, /on_stomach/);
  assert.doesNotMatch(manualPose.prompt, /doggystyle/, 'a clicked pose must override the controller');
  selectModuleKind('pose', '');
  assert.match(hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']).prompt,
    /doggystyle/, 'the game button should restore controller following');
  controllerPose = '여성 손 자극';
  state.activeScene.patron.stage = 'handjob_patron';
  const handSceneKey = 'pippa__scene-patron_handjob__v-0';
  const handSceneBase = { key: handSceneKey, prompt: 'best quality, 1girl, 1boy, handjob', negativePrompt: 'base_negative',
    parts: [{ label: '품질', tags: 'best quality' }, { label: '기본', tags: '1girl' },
      { label: '장면', tags: '1boy, handjob' }] };
  const handScene = hooks.imagePrompt.after(handSceneBase, [wife, 'modules']);
  assert.match(handScene.prompt, /sitting/);
  assert.match(handScene.prompt, /handjob/);
  assert.doesNotMatch(handScene.prompt, /fingering/,
    'the patron handjob pose must not reuse AIP\'s similarly named fingering preset');
  vmContext.__waywardScenePose = { now: () => ({ source: 'patron', scene: 'patron_handjob',
    customerId: 'guest-1', pose: '여성 손 자극', group: 'hand', poseNegative: '',
    mood: [{ id: 'tears', label: '눈물', tags: 'tears, teary scene marker' }],
    him: { tags: 'old_count, leather_armor, anime_style, oil_painting, best_quality, tavern_interior, studio_background, cinematic_lighting, depth_of_field',
      filth: 'blue beard, sweat, watercolor' }, negative: 'child, bad_anatomy, wrong expression' }) };
  const patronBridge = hooks.imagePrompt.after(handSceneBase, [wife, 'modules']);
  assert.match(patronBridge.prompt, /tears/);
  assert.match(patronBridge.prompt, /old_count, leather_armor/);
  assert.match(patronBridge.prompt, /sweat/);
  assert.doesNotMatch(patronBridge.prompt,
    /anime_style|oil_painting|best_quality|tavern_interior|studio_background|cinematic_lighting|depth_of_field|watercolor/,
    'guest appearance must keep the person while excluding style, background, lighting and composition');
  const styledBridgeNow = vmContext.__waywardScenePose.now;
  vmContext.__waywardScenePose.now = () => ({ ...styledBridgeNow(),
    him: { tags: 'old_count, leather_armor', filth: 'sweat' } });
  assert.equal(hooks.imagePrompt.after(handSceneBase, [wife, 'modules']).key, patronBridge.key,
    'discarded guest style tags must not create a separate image cache key');
  vmContext.__waywardScenePose.now = styledBridgeNow;
  assert.doesNotMatch(patronBridge.prompt, /teary scene marker|blue beard/);
  assert.match(patronBridge.negativePrompt, /base_negative/);
  assert.match(patronBridge.negativePrompt, /child, bad_anatomy/);
  assert.doesNotMatch(patronBridge.negativePrompt, /wrong expression/);
  const handBridgeNow = vmContext.__waywardScenePose.now;
  controllerPose = '';
  state.activeScene.patron.stage = 'groping';
  vmContext.__waywardScenePose.now = () => ({ source: 'patron', scene: 'patron_groping',
    customerId: 'guest-1', mood: [{ id: 'tears', tags: 'tears' }], him: { tags: 'old_count' } });
  const bridgeOnlyBase = { ...handSceneBase,
    key: 'pippa__scene-patron_groping__v-0', prompt: 'best quality, 1girl, 1boy, groping, bedroom',
    parts: handSceneBase.parts.map(part => part.label === '장면'
      ? { ...part, tags: '1boy, groping, bedroom' } : part) };
  const bridgeOnly = hooks.imagePrompt.after(bridgeOnlyBase, [wife, 'modules']);
  const reorderedBridgeOnly = hooks.imagePrompt.after({ ...bridgeOnlyBase,
    prompt: '1girl, bedroom, best quality, groping, 1boy' }, [wife, 'modules']);
  assert.equal(reorderedBridgeOnly.key, bridgeOnly.key,
    'the same prompt tags in another order must retain the existing image key');
  assert.ok(bridgeOnly.prompt.indexOf('best quality') < bridgeOnly.prompt.indexOf('tears'));
  assert.ok(bridgeOnly.prompt.indexOf('1girl') < bridgeOnly.prompt.indexOf('old_count'),
    'guest-only modules must not push the character and quality behind guest tags');
  assert.match(bridgeOnly.prompt, /bedroom/, 'the scene background must remain');
  controllerPose = '여성 손 자극';
  state.activeScene.patron.stage = 'handjob_patron';
  vmContext.__waywardScenePose.now = handBridgeNow;
  settingsWin.refresh();
  const guestAppearanceToggle = collectNodes().find(node => node.props?.['data-aip-guest-appearance'] === '');
  assert.equal(guestAppearanceToggle?.props.checked, true, 'guest appearance starts enabled');
  guestAppearanceToggle.props.onchange({ currentTarget: { checked: false } });
  assert.equal(savedSettings.guestAppearance, false);
  const withoutGuestAppearance = hooks.imagePrompt.after(handSceneBase, [wife, 'modules']);
  assert.doesNotMatch(withoutGuestAppearance.prompt, /old_count|leather_armor/);
  assert.match(withoutGuestAppearance.prompt, /tears/, 'the guest switch must leave other bridge modules active');
  assert.notEqual(withoutGuestAppearance.key, patronBridge.key, 'the guest switch must select a distinct image key');
  const disabledGuestToggle = collectNodes().find(node => node.props?.['data-aip-guest-appearance'] === '');
  assert.equal(disabledGuestToggle?.props.checked, false);
  disabledGuestToggle.props.onchange({ currentTarget: { checked: true } });
  assert.match(hooks.imagePrompt.after(handSceneBase, [wife, 'modules']).prompt, /old_count, leather_armor/);
  state.activeScene.patron.stage = 'rubbing_patron';
  vmContext.__waywardScenePose.now = () => ({ source: 'patron', scene: 'patron_rubbing',
    customerId: 'guest-1', pose: '스마타', poseId: 'thigh_sex', group: 'rub', mood: [],
    him: null, negative: '' });
  const thighScene = hooks.imagePrompt.after({ ...handSceneBase,
    key: 'pippa__scene-patron_rubbing__v-0', prompt: 'best quality, 1girl, 1boy, frottage',
    parts: handSceneBase.parts.map(part => part.label === '장면'
      ? { ...part, tags: '1boy, frottage' } : part) }, [wife, 'modules']);
  assert.match(thighScene.prompt, /thigh_sex, penis, thighs/,
    'the extension-only twentieth pose must resolve to a Danbooru thigh contact prompt');
  state.activeScene.patron.stage = 'handjob_patron';
  vmContext.__waywardScenePose.now = () => ({ source: 'patron', scene: 'patron_handjob',
    customerId: 'another-guest', pose: '여성 손 자극', him: { tags: 'wrong guest marker' } });
  assert.doesNotMatch(hooks.imagePrompt.after(handSceneBase, [wife, 'modules']).prompt,
    /wrong guest marker/, 'a bridge snapshot from another patron must not leak into this image');
  const scenePoseSource = modSource.split('const SCENE_POSE_PRESET_IDS =')[1];
  assert.equal((scenePoseSource.split('const SCENE_POSE_MOOD_PROMPTS')[0]
    .match(/\b[a-z_]+: '[^']+'/g) || []).length, 20, 'all 20 extension pose IDs need AIP mappings');
  assert.equal((scenePoseSource.split('const SCENE_POSE_LOOK_PROMPTS')[0]
    .match(/\b[a-z]+: \[/g) || []).length, 12, 'all 12 extension moods need AIP prompts');
  assert.equal((scenePoseSource.split('const SCENE_POSE_LOOK_PROMPTS')[1]
    .split('const SCENE_POSE_FILTH_PROMPTS')[0]
    .match(/'[^']+\/[^']+': '/g) || []).length, 40, 'all 40 extension guest looks need AIP prompts');
  assert.equal((scenePoseSource.split('const SCENE_POSE_ROUGH_PROMPTS')[1]
    .split('function controllerPositionModules')[0].match(/'[^']+': /g) || []).length, 16,
  'all 16 extension rough-pose labels need AIP prompts');
  vmContext.__waywardScenePose.now = () => ({ source: 'patron', scene: 'patron_handjob',
    customerId: 'guest-1', pose: '여성 손 자극', poseId: 'handjob', group: 'hand',
    mood: [{ id: 'coerced', label: '강요당함', tags: 'unwilling, forced' },
      { id: 'climax', label: '절정', tags: 'female_orgasm' }],
    him: { key: 'nobleman/recently_widowed', tags: '', filth: 'white roots in beard, liver spots' },
    hostile: true, negative: 'smile, ahegao, bored, expressionless, bad_anatomy' });
  const staleHostility = hooks.imagePrompt.after(handSceneBase, [wife, 'modules']);
  assert.match(staleHostility.prompt, /old_man, beard, ring, key/,
    'the guest look key must resolve to a full Danbooru prompt');
  assert.match(staleHostility.prompt, /grey_beard, liver_spots/,
    'the hostile guest filth hook must also use Danbooru tags');
  assert.doesNotMatch(staleHostility.prompt, /struggling|resisting|female_orgasm/,
    'historical hostility and high pleasure must not claim current force or climax');
  assert.doesNotMatch(staleHostility.negativePrompt, /(?:^|, )(?:smile|ahegao)(?:,|$)/,
    'a historical relation must not ban a smile or an actual climax expression');
  assert.doesNotMatch(staleHostility.negativePrompt, /bored|expressionless/,
    'a false extension climax must not add its Negative tags either');
  const beforeForceSlot = state.slot;
  state.activeScene.patron.coercedSinceSlot = state.slot;
  const currentForce = hooks.imagePrompt.after(handSceneBase, [wife, 'modules']);
  assert.match(currentForce.prompt, /struggling, resisting, tears, frown, averting_eyes/);
  assert.match(currentForce.negativePrompt, /smile, happy, seductive_smile/);
  const smilingScene = { ...handSceneBase, prompt: `${handSceneBase.prompt}, smile`,
    parts: [...handSceneBase.parts, { label: '분위기', tags: 'smile' }] };
  assert.doesNotMatch(hooks.imagePrompt.after(smilingScene, [wife, 'modules']).prompt,
    /(?:^|, )smile(?:,|$)/, 'current force must remove a contradictory positive smile');
  assert.notEqual(currentForce.key, staleHostility.key,
    'current coercion must select a new image key');
  delete vmContext.__waywardScenePose;
  delete vmContext.__waywardActExpansion;
  const forcedWithoutMods = hooks.imagePrompt.after(handSceneBase, [wife, 'modules']);
  assert.match(forcedWithoutMods.prompt, /struggling, resisting/,
    'the game coercion record must work without either optional mod');
  state.slot += 16;
  assert.doesNotMatch(hooks.imagePrompt.after(handSceneBase, [wife, 'modules']).prompt,
    /struggling|resisting/, 'an expired coercion record must stop changing the portrait');
  state.slot = beforeForceSlot;
  delete state.activeScene.patron.coercedSinceSlot;
  vmContext.__waywardActExpansion = { scene: () => ({
    customer: { id: 'guest-1' }, forcedIn: true }) };
  assert.match(hooks.imagePrompt.after(handSceneBase, [wife, 'modules']).prompt,
    /struggling, resisting/, 'a matching scene hook must also expose current coercion');
  vmContext.__waywardActExpansion.scene = () => ({ customer: { id: 'another-guest' }, forcedIn: true });
  assert.doesNotMatch(hooks.imagePrompt.after(handSceneBase, [wife, 'modules']).prompt,
    /struggling|resisting/, 'another patron\'s coercion state must not leak into this portrait');
  delete vmContext.__waywardActExpansion;
  state.slot += 2;
  const noControllerGroup = hooks.imagePrompt.after({ ...positionBase, key: sceneKey }, [wife, 'modules']);
  assert.match(noControllerGroup.key, /__position-modules-slots-m-/,
    'the group layout must work without the controller API');
  assert.match(noControllerGroup.prompt, /first supporting man.*fellatio/);
  state.activeScene.patron.joinedPatronIds = ['guest-2'];
  hooks.imagePrompt.after(handSceneBase, [wife, 'modules']);
  documentClickListener({ target: controllerButton('몸 비비기', '행위', false, 'main') });
  documentClickListener({ target: controllerButton('입으로 애무받기', '행위', false, 'guest-2') });
  const twoPatrons = hooks.imagePrompt.after(handSceneBase, [wife, 'modules']);
  assert.match(twoPatrons.prompt, /frottage/);
  assert.match(twoPatrons.prompt, /fellatio/);
  state.slot += 2;
  delete state.activeScene.patron.joinedPatronIds;
  state.activeScene = { sex: { type: 'blowjob' } };
  vmContext.__waywardHusbandLife = { owns: () => true, compat: { husPoseOf: () => '무릎 구강성교' } };
  const heroKey = 'pippa__scene-blowjob__v-0';
  const heroBase = { key: heroKey, prompt: 'best quality, 1girl, 1boy, fellatio', negativePrompt: 'base_negative',
    parts: [{ label: '품질', tags: 'best quality' }, { label: '기본', tags: '1girl' },
      { label: '장면', tags: '1boy, fellatio' }] };
  activePortraitKey = heroKey;
  const heroResult = hooks.imagePrompt.after(heroBase, [wife, 'modules']);
  assert.match(heroResult.prompt, /kneeling/,
    'the player controller pose should also feed the module prompt');
  assert.match(heroResult.prompt, /fellatio/);
  settingsWin.refresh();
  assert.ok(findModule('action', node => node.props?.['aria-label'] === '당신 · 행위 · 이라마치오', 'you'));
  assert.ok(!findModule('action', node => node.props?.['aria-label'] === '손님 · 행위 · 몸 비비기'),
  'a player-only scene must hide patron action buttons');
  const hlcPanel = { hidden: false, closest: () => null };
  const hlcRow = { querySelector: () => ({ textContent: '행위' }) };
  controllerDomButtons = [{ textContent: '이라마치오 ♥', classList: { contains: name => ['hlc-chip', 'on'].includes(name) },
    getAttribute: () => null, closest(selector) {
      if (selector === '.wpc-ctl, .wpc-dock, .hlc-dock') return hlcPanel;
      if (selector === '.wpc-ctl-row, .hlc-row') return hlcRow;
      if (selector === 'button.wpc-ctl-cmd, button.hlc-chip') return this;
      return null;
    } }];
  assert.match(hooks.imagePrompt.after(heroBase, [wife, 'modules']).prompt, /deepthroat/,
    'the husband-life controller can contribute an active action when installed');
  const activeHusbandButton = controllerDomButtons[0];
  for (const [type, label, posture] of [
    ['riding', '기승위', /cowgirl_position, girl_on_top/],
    ['standing_sex', '선 채로', /standing_sex/],
  ]) {
    state.activeScene.sex.type = type;
    vmContext.__waywardHusbandLife.compat.husPoseOf = () => label;
    activeHusbandButton.textContent = `${label} ♥`;
    const result = hooks.imagePrompt.after({ ...heroBase, key: `pippa__scene-${type}__v-0` }, [wife, 'modules']);
    assert.match(result.prompt, posture);
    assert.match(result.prompt, /sex, vaginal, penis, pussy/,
      `${label} controller action must include actual intercourse, not only posture`);
  }
  const ridingAction = findModule('action', node => node.props?.['aria-label'] === '당신 · 행위 · 기승위', 'you');
  const ridingActionId = ridingAction.props['data-controller-module-select'];
  savedSettings.positionModulePrompts[ridingActionId] = {
    positivePrompt: 'hetero, cowgirl_position, girl_on_top', negativePrompt: '' };
  assert.match(findModule('action', node => node.props?.['data-controller-module-select'] === ridingActionId, 'you').props.title,
    /sex, vaginal, penis, pussy/, 'a saved copy of the old riding default must update');
  delete savedSettings.positionModulePrompts[ridingActionId];
  state.activeScene.sex.type = 'blowjob';
  vmContext.__waywardHusbandLife.compat.husPoseOf = () => '무릎 구강성교';
  controllerDomButtons = [];
  let bridgeMood = 'blush';
  vmContext.__waywardScenePose = { now: () => ({ source: 'husband', scene: 'blowjob',
    pose: '무릎 구강성교', roughPose: '손목 눌러 붙잡고', poseNegative: 'doggystyle',
     mood: [{ id: 'loving', label: '다정함', tags: bridgeMood }],
     him: null, negative: 'doggystyle, child, bad_anatomy' }) };
  const bridgeResult = hooks.imagePrompt.after(heroBase, [wife, 'modules']);
  assert.match(bridgeResult.prompt, /blush/);
  assert.match(bridgeResult.prompt, /holding_another's_wrist, restrained/,
    'the extension rough-pose hook must add its current visual action');
  const bridgeNow = vmContext.__waywardScenePose.now;
  vmContext.__waywardScenePose.now = () => ({ ...bridgeNow(), roughPose: '목조르기 섹스' });
  assert.match(hooks.imagePrompt.after(heroBase, [wife, 'modules']).prompt,
    /man's hand gripping the woman's neck:1\.4/,
    'the extension neck pose must use the same explicit action prompt');
  vmContext.__waywardScenePose.now = bridgeNow;
  assert.match(bridgeResult.negativePrompt, /base_negative/);
  assert.match(bridgeResult.negativePrompt, /child, bad_anatomy/);
  assert.match(bridgeResult.negativePrompt, /doggystyle/,
    'the extension pose negative should follow its current pose');
  savedSettings.positionModuleSelections = { 'scene-blowjob': ['action-9'] };
  assert.doesNotMatch(hooks.imagePrompt.after(heroBase, [wife, 'modules']).negativePrompt, /doggystyle/,
    'the extension pose negative must yield to a manually selected action');
  savedSettings.positionModuleSelections = {};
  bridgeMood = 'tears';
  const changedBridge = hooks.imagePrompt.after(heroBase, [wife, 'modules']);
  assert.notEqual(changedBridge.key, bridgeResult.key, 'changed extension tags need a new image key');
  assert.match(changedBridge.prompt, /tears/);
  delete vmContext.__waywardScenePose;
  assert.doesNotMatch(hooks.imagePrompt.after(heroBase, [wife, 'modules']).prompt,
    /blush|tears/, 'the optional extension must be removable without stale tags');
  delete vmContext.__waywardHusbandLife;
  const contactKey = 'pippa__scene-fingering__v-0';
  const contactBase = { key: contactKey, prompt: 'best quality, 1girl, 1boy, fingering',
    negativePrompt: 'base_negative', parts: [{ label: '품질', tags: 'best quality' },
      { label: '기본', tags: '1girl, 1boy' }, { label: '장면', tags: 'fingering' }] };
  promptInputByContext = new Map([['modules', contactBase]]);
  state.activeScene = { sex: { type: 'fingering', __hs: { her: { prep: 'ready:sex' } } } };
  activePortraitKey = contactKey;
  savedSettings.positionModuleSelections = {};
  controllerDomButtons = [];
  const contactWithoutPanel = hooks.imagePrompt.after(contactBase, [wife, 'modules']);
  assert.match(contactWithoutPanel.prompt, /erection, penis, pussy, imminent_vaginal, penis_on_pussy/,
    'the active entrance state must show penile contact even when the controller panel is absent');
  assert.doesNotMatch(contactWithoutPanel.prompt, /(?:^|, )fingering(?:,|$)/,
    'penile contact must replace a stale native finger-action tag');
  assert.match(contactWithoutPanel.negativePrompt, /solo, disembodied_penis/);
  assert.doesNotMatch(contactWithoutPanel.negativePrompt, /hand_focus|imminent_fingering/,
    'penile contact must not suppress a second hand touching the clitoris');
  assert.match(contactWithoutPanel.negativePrompt, /base_negative/);
  settingsWin.refresh();
  const contactButton = findModule('action', node => node.props?.['aria-label'] === '당신 · 삽입 · 입구에 맞댐', 'you');
  assert.match(contactButton.props.title, /Negative: solo, disembodied_penis/,
    'the entrance-contact guard must be visible and editable as a module Negative prompt');
  const clitHand = findModule('hands', node => node.props?.['aria-label'] === '당신 · 오른손 · 클리', 'you');
  assert.ok(clitHand);
  let playerClitOn = true;
  vmContext.__waywardActExpansion = {
    CARESS_SETS: [['basic', '기본']], CARESS: { clit: { label: '클리', set: 'basic' } },
    husCaressKeys: () => playerClitOn ? ['clit'] : [],
  };
  assert.match(hooks.imagePrompt.after(contactBase, [wife, 'modules']).prompt,
    /hand_on_another's_crotch, clitoral_stimulation, clitoris/,
    'the player clit caress must work without an open controller panel');
  playerClitOn = false;
  assert.doesNotMatch(hooks.imagePrompt.after(contactBase, [wife, 'modules']).prompt,
    /clitoral_stimulation/, 'turning off the player caress must remove its tags immediately');
  delete vmContext.__waywardActExpansion;
  clitHand.props.onclick();
  const contactWithClit = hooks.imagePrompt.after(contactBase, [wife, 'modules']);
  assert.match(contactWithClit.prompt, /hand_on_another's_crotch/);
  assert.match(contactWithClit.prompt, /clitoral_stimulation, clitoris/);
  assert.match(contactWithClit.prompt, /clitoris_tweak/);
  assert.match(contactWithClit.negativePrompt,
    /female_masturbation, hand_on_own_crotch, spread_pussy/);
  assert.match(contactWithClit.prompt, /penis_on_pussy/,
    'clitoral hand placement and penile entrance contact must both remain');
  const otherHand = findModule('hands', node => node.props?.['aria-label'] === '당신 · 왼손 · 가슴', 'you');
  otherHand.props.onclick();
  const twoMaleHands = hooks.imagePrompt.after(contactBase, [wife, 'modules']);
  assert.match(twoMaleHands.prompt, /hand_on_another's_crotch/);
  assert.match(twoMaleHands.prompt, /grabbing_another's_breast/);
  assert.match(twoMaleHands.negativePrompt, /female_masturbation, hand_on_own_crotch, spread_pussy/,
    'two simultaneous male hand acts must still exclude the wife touching herself');
  assert.doesNotMatch(contactWithClit.prompt, /(?:^|, )fingering(?:,|$)/);
  assert.doesNotMatch(contactWithClit.prompt, /[\uac00-\ud7a3]/,
    'module labels are Korean UI text, not text sent in the positive prompt');
  const contactRequestCount = generatedRequests.length;
  collectNodes().find(node => node.tag === 'button' && node.children.includes('현재 이미지 재생성')).props.onclick();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(generatedRequests.length, contactRequestCount + 1);
  assert.match(generatedRequests.at(-1).prompt, /clitoral_stimulation.*penis_on_pussy|penis_on_pussy.*clitoral_stimulation/);
  assert.match(generatedRequests.at(-1).prompt, /grabbing_another's_breast/);
  assert.match(generatedRequests.at(-1).negativePrompt,
    /female_masturbation, hand_on_own_crotch, spread_pussy/);
  assert.match(generatedRequests.at(-1).negativePrompt, /solo, disembodied_penis/,
    'the same Positive and Negative must reach the image generation request');
  assert.doesNotMatch(generatedRequests.at(-1).negativePrompt, /hand_focus|imminent_fingering/);
  vmContext.__waywardHusbandLife = { owns: () => true,
    compat: { husPoseOf: () => '무릎 구강성교' } };
  const staleOralPose = hooks.imagePrompt.after(contactBase, [wife, 'modules']);
  assert.doesNotMatch(staleOralPose.prompt, /(?:^|, )fellatio(?:,|$)/,
    'a stale oral pose must not override penile entrance contact');
  delete vmContext.__waywardHusbandLife;
  state.activeScene.sex.__hs.her.prep = 'ready:anal';
  const backContact = hooks.imagePrompt.after(contactBase, [wife, 'modules']);
  assert.match(backContact.prompt, /anus, imminent_anal, penis_on_ass/);
  assert.match(backContact.prompt, /clitoral_stimulation/);
  assert.doesNotMatch(backContact.prompt, /penis_on_pussy/);
  state.activeScene.sex.__hs.her.prep = 'none';
  const afterContact = hooks.imagePrompt.after(contactWithClit, [wife, 'modules']);
  assert.doesNotMatch(afterContact.prompt, /penis_on_pussy|imminent_vaginal/,
    'contact tags must disappear when the entrance state ends');
  assert.doesNotMatch(afterContact.negativePrompt, /disembodied_penis/,
    'contact Negative tags must not persist after the state ends');
  controllerDomButtons = [controllerButton('입구에 맞댐 ✓', '삽입', true)];
  state.activeScene.sex.type = 'sex';
  savedSettings.positionModuleSelections['scene-sex'] = ['pose-9'];
  const enteredSex = hooks.imagePrompt.after({ ...contactBase, key: 'pippa__scene-sex__v-0' }, [wife, 'modules']);
  assert.match(enteredSex.prompt, /sex, vaginal, penis, pussy/);
  assert.doesNotMatch(enteredSex.prompt, /imminent_vaginal|penis_on_pussy/,
    'a stale entrance button must yield once the game enters intercourse');
  delete savedSettings.positionModuleSelections['scene-sex'];
  state.activeScene.sex.type = 'fingering';
  const panelContact = hooks.imagePrompt.after(contactBase, [wife, 'modules']);
  assert.match(panelContact.prompt, /penis_on_pussy/,
    'an active controller status must work even without the optional status hook');
  assert.match(panelContact.prompt, /clitoral_stimulation/);
  controllerDomButtons = [];
  state.activeScene.sex.type = 'sex';
  let overTopOn = false;
  vmContext.__waywardHusbandLife = { owns: () => true, compat: {
    CARESS_SETS: [['basic', '기본', ['overTop']]],
    CARESS: { overTop: { label: '옷 위로 만지기' } },
    husCaressKeys: () => overTopOn ? ['overTop'] : [],
  } };
  const insertionKey = 'pippa__scene-sex__v-0';
  const insertionOnlyKey = hooks.imageKey.after(insertionKey, [wife]);
  overTopOn = true;
  const clothedTouchKey = hooks.imageKey.after(insertionKey, [wife]);
  assert.notEqual(clothedTouchKey, insertionOnlyKey,
    'insertion with an active over-clothes caress needs its own portrait key');
  const clothedTouch = hooks.imagePrompt.after({ ...contactBase, key: insertionKey }, [wife, 'modules']);
  assert.match(clothedTouch.prompt, /man's hand touching woman's breast through her clothes/);
  assert.equal(clothedTouch.key, clothedTouchKey);
  const beforeCaressRefresh = storeUpdates;
  documentClickListener({ target: controllerButton('옷 위로 만지기 (손) ↻', '기본', true) });
  assert.equal(storeUpdates, beforeCaressRefresh + 1,
    'a relationship caress button must refresh the portrait immediately');
  overTopOn = false;
  assert.equal(hooks.imageKey.after(insertionKey, [wife]), insertionOnlyKey,
    'turning off over-clothes touch must return to the insertion-only image');
  delete vmContext.__waywardHusbandLife;
  state.activeScene = { patron: { customerId: 'guest-1', stage: 'rubbing_patron',
    __actPrep: { into: 'inside_anal' } } };
  savedSettings.positionModuleSelections = {};
  const patronContactKey = 'pippa__scene-patron_rubbing__v-0';
  activePortraitKey = patronContactKey;
  vmContext.__waywardActExpansion = { pose: { now: () => ({ customerId: 'guest-1',
    pose: '후방 항문위' }) } };
  const patronContact = hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']);
  assert.match(patronContact.prompt, /penis_on_ass/);
  assert.doesNotMatch(patronContact.prompt, /penis_on_pussy/,
    'the patron entrance state must choose the actual hole, not always front');
  assert.ok(!patronContact.prompt.split(', ').includes('anal'),
    'a cached anal position must not claim completed penetration during preparation');
  delete state.activeScene.patron.__actPrep;
  let patronClitOn = true;
  vmContext.__waywardActExpansion = {
    CARESS_SETS: [['basic', '기본']], CARESS: { clit: { label: '클리', set: 'basic' } },
    caressKeys: () => patronClitOn ? ['clit'] : [],
  };
  const clitToggle = controllerButton('클리 (손)', '기본', true);
  controllerDomButtons = [clitToggle];
  const patronClit = hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']);
  assert.match(patronClit.prompt, /hand_on_another's_crotch, clitoral_stimulation, clitoris/,
    'the patron controller clit button must keep its actor and target tags');
  controllerDomButtons = [];
  assert.match(hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']).prompt,
    /clitoral_stimulation/, 'the active caress hook must work with the controller panel closed');
  controllerDomButtons = [clitToggle];
  documentClickListener({ target: clitToggle });
  patronClitOn = false;
  controllerDomButtons = [controllerButton('클리 (손)', '기본', false)];
  const patronClitOff = hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']);
  assert.doesNotMatch(patronClitOff.prompt, /clitoral_stimulation/,
    'clicking an active caress to turn it off must not leave a recent-click prompt');
  assert.notEqual(patronClitOff.key, patronClit.key, 'caress cancellation must invalidate the image key');
  delete vmContext.__waywardActExpansion;
  assert.doesNotMatch(hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']).prompt,
    /clitoral_stimulation/, 'controller cancellation must also work without the optional caress API');
  let patronHairOn = true;
  vmContext.__waywardActExpansion = {
    CARESS_SETS: [['basic', '기본']], CARESS: { hair: { label: '머리채', set: 'basic' } },
    caressKeys: () => patronHairOn ? ['hair'] : [],
  };
  const patronHair = hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']);
  assert.match(patronHair.prompt, /grabbing_another's_hair/,
    'an active patron hair caress must appear without the controller panel');
  patronHairOn = false;
  const patronHairOff = hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']);
  assert.doesNotMatch(patronHairOff.prompt, /grabbing_another's_hair/);
  assert.notEqual(patronHair.key, patronHairOff.key);
  const previousLog = state.log;
  const actionSlot = state.slot;
  const hairLine = { slot: actionSlot, extraLine: true, coLocated: true,
    groupKey: 'interaction:guest-1:rubbing_patron', text: '손님이 그녀의 머리채를 움켜쥐고 고개를 젖힌다.' };
  state.log = [hairLine];
  const dialogueHair = hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']);
  assert.match(dialogueHair.prompt, /grabbing_another's_hair/,
    'a narrated patron action must add a scene action even without an active caress');
  assert.ok(dialogueHair.parts.some(part => part.label === '장면 동작'));
  assert.notEqual(dialogueHair.key, patronHairOff.key);
  state.slot = actionSlot + 1;
  assert.match(hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']).prompt,
    /grabbing_another's_hair/, 'a line stamped at the action minute must reach the next image');
  state.slot = actionSlot;
  settingsWin.refresh();
  const hairModuleId = findModule('body', node => node.props?.['aria-label'] === '손님 · 폭력성 · 머리채')
    .props['data-controller-module-select'];
  const oldHairModule = savedSettings.positionModulePrompts?.[hairModuleId];
  savedSettings.positionModulePrompts = { ...savedSettings.positionModulePrompts,
    [hairModuleId]: { positivePrompt: '(custom hair action:1.2)', negativePrompt: 'hair_action_negative' } };
  const customHair = hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']);
  assert.match(customHair.prompt, /\(custom hair action:1\.2\)/);
  assert.match(customHair.negativePrompt, /hair_action_negative/,
    'narrated actions must honor edited module prompts');
  savedSettings.positionModulePrompts[hairModuleId].positivePrompt = '';
  const negativeOnlyHair = hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']);
  assert.match(negativeOnlyHair.negativePrompt, /hair_action_negative/);
  assert.notEqual(negativeOnlyHair.key, patronHairOff.key,
    'a negative-only scene action must still change the image key');
  if (oldHairModule) savedSettings.positionModulePrompts[hairModuleId] = oldHairModule;
  else delete savedSettings.positionModulePrompts[hairModuleId];
  state.log = [{ ...hairLine, groupKey: 'extra:patron' }];
  assert.match(hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']).prompt,
    /grabbing_another's_hair/, 'extra dialogue during the patron scene must also be recognized');
  state.log = [{ ...hairLine, groupKey: 'interaction:another-guest:rubbing_patron' }];
  assert.doesNotMatch(hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']).prompt,
    /grabbing_another's_hair/, 'another patron’s line must not affect this scene');
  state.log = [{ ...hairLine, text: '그녀가 그의 머리채를 움켜쥔다.' }];
  assert.doesNotMatch(hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']).prompt,
    /grabbing_another's_hair/, 'the wife grabbing his hair must not reverse the actor');
  state.activeScene.patron.customerName = '콘라트';
  state.log = [{ ...hairLine, text: '그녀가 콘라트의 머리채를 잡아당긴다.' }];
  assert.doesNotMatch(hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']).prompt,
    /grabbing_another's_hair/, 'a named patron’s hair must not be mistaken for the wife’s');
  delete state.activeScene.patron.customerName;
  state.log = [{ ...hairLine, text: '손님이 그녀의 두 손목을 한 손에 모아 쥐고 붙든다.' }];
  assert.match(hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']).prompt,
    /holding_another's_wrist/, 'a similar narrated restraint must map to its visual action');
  wife.name = '엘레나';
  state.log = [{ ...hairLine, text: '손님이 엘레나의 목을 조른다.' }];
  const narratedNeck = hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']);
  assert.match(narratedNeck.prompt, /man's hand gripping the woman's neck:1\.4/,
    'a named wife must receive an explicit weighted neck action');
  delete wife.name;
  state.log = [{ ...hairLine, slot: actionSlot - 2 }];
  assert.doesNotMatch(hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']).prompt,
    /grabbing_another's_hair/, 'an old action must expire');
  state.log = [];
  vmContext.__waywardActExpansion.strike = { state: () => ({ customerId: 'guest-1',
    log: [{ part: 'hair', minute: actionSlot }, { part: 'choke', minute: actionSlot }] }) };
  const strikeActions = hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']);
  assert.match(strikeActions.prompt, /grabbing_another's_hair/);
  assert.match(strikeActions.prompt, /man's hand gripping the woman's neck:1\.4/,
    'one-time patron actions must survive a closed controller panel');
  vmContext.__waywardActExpansion.strike.state = () => ({ customerId: 'guest-1',
    log: [], lastScream: { trigger: 'hair', minute: actionSlot } });
  assert.match(hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']).prompt,
    /grabbing_another's_hair/, 'a violent narrated move must work when only its scream is structured');
  vmContext.__waywardActExpansion.strike.state = () => ({ customerId: 'another-guest',
    log: [{ part: 'hair', minute: actionSlot }] });
  assert.doesNotMatch(hooks.imagePrompt.after({ ...contactBase, key: patronContactKey }, [wife, 'modules']).prompt,
    /grabbing_another's_hair/);
  state.log = previousLog;
  delete vmContext.__waywardActExpansion;
  const rubbingHandBase = { key: patronContactKey, prompt: 'best quality, 1girl, 1boy, frottage',
    negativePrompt: 'base_negative', parts: [{ label: '품질', tags: 'best quality' },
      { label: '기본', tags: '1girl, 1boy' }, { label: '장면', tags: 'frottage' }] };
  promptInputByContext = new Map([['modules', rubbingHandBase]]);
  controllerDomButtons = [];
  hooks.imagePrompt.after(rubbingHandBase, [wife, 'modules']);
  const intimateKey = patronContactKey.replace('patron_rubbing', 'patron_intimate');
  const intimateBase = { ...rubbingHandBase, key: intimateKey,
    prompt: 'best quality, 1girl, 1boy, cum on fingers, wet hands',
    parts: [{ label: '품질', tags: 'best quality' }, { label: '기본', tags: '1girl, 1boy' },
      { label: '정사 후 정황', tags: 'cum on fingers, wet hands' }] };
  state.activeScene.patron.stage = 'intimate';
  activePortraitKey = intimateKey;
  wife.aftermathTags = ['cum_on_hands'];
  vmContext.__waywardActExpansion = { pose: { now: () => ({ customerId: 'guest-1', pose: '여성 손 자극' }) } };
  const intimateFinger = hooks.imagePrompt.after(intimateBase, [wife, 'modules']);
  assert.match(intimateFinger.prompt, /man fingering woman's vagina:1\.3/);
  assert.match(intimateFinger.prompt, /man's fingers at woman's vulva:1\.25/);
  assert.match(intimateFinger.prompt, /cum on fingers, wet hands/,
    'real aftermath remains visible without changing who performs the current action');
  assert.doesNotMatch(intimateFinger.prompt, /anal_fingering|fingers_in_ass/);
  assert.match(intimateFinger.negativePrompt, /female_masturbation.*hand_on_own_crotch.*anal_fingering.*fingers_in_ass/);
  delete vmContext.__waywardActExpansion;
  delete wife.aftermathTags;
  state.activeScene.patron.stage = 'rubbing_patron';
  activePortraitKey = patronContactKey;
  hooks.imagePrompt.after(rubbingHandBase, [wife, 'modules']);
  settingsWin.refresh();
  const analHandDuringRubbing = findModule('body', node => node.props?.['aria-label'] === '손님 · 입·손가락 · 애널 손가락');
  analHandDuringRubbing.props.onclick();
  const manualAnalRub = hooks.imagePrompt.after(rubbingHandBase, [wife, 'modules']);
  assert.match(manualAnalRub.prompt, /frottage/);
  assert.match(manualAnalRub.prompt, /anal_fingering, fingering, hand_on_another's_ass/);
  assert.doesNotMatch(manualAnalRub.prompt, /(?:^|, )anal(?:,|$)|penis_on_ass/,
    'manual anal caress during rubbing must not become penile anal penetration');
  assert.match(manualAnalRub.negativePrompt, /penis_on_ass/);
  state.activeScene.patron.__actPrep = { into: 'inside_anal' };
  const actualAnalContact = hooks.imagePrompt.after(manualAnalRub, [wife, 'modules']);
  assert.match(actualAnalContact.prompt, /penis_on_ass/);
  assert.match(actualAnalContact.prompt, /anal_fingering, fingering, hand_on_another's_ass/);
  assert.doesNotMatch(actualAnalContact.negativePrompt, /penis_on_ass/,
    'a real penile contact state must not be negated by simultaneous hand caress');
  delete state.activeScene.patron.__actPrep;
  const backToRubbing = hooks.imagePrompt.after(actualAnalContact, [wife, 'modules']);
  assert.match(backToRubbing.negativePrompt, /penis_on_ass/);
  findModule('body', node => node.props?.['data-controller-module-select']
    === analHandDuringRubbing.props['data-controller-module-select']).props.onclick();
  assert.doesNotMatch(hooks.imagePrompt.after(backToRubbing, [wife, 'modules']).negativePrompt, /penis_on_ass/,
    'the hand-only guard must disappear when the anal hand module is turned off');
  state.activeScene = { sex: { type: 'anal_fingering' } };
  savedSettings.positionModuleSelections = { 'scene-anal_fingering': ['pose-8'] };
  const playerAnalHand = hooks.imagePrompt.after({ ...rubbingHandBase,
    key: 'pippa__scene-anal_fingering__v-0' }, [wife, 'modules']);
  assert.match(playerAnalHand.prompt, /anal_fingering, fingering, hand_on_another's_ass/,
    'the game-provided player anal-hand action must use the same actor and hand tags');
  assert.match(playerAnalHand.negativePrompt, /penis_on_ass/);
  const markBase = { key: 'pippa__task-idle__v-0', prompt: 'portrait', negativePrompt: '', parts: [] };
  for (const [degree, phrase] of [[1, 'bruise_on_face:1.1'],
    [3, 'bruise_on_face:1.3']]) {
    state.waywardMarks = { id: 'wife', list: [{ part: 'slap', degree }] };
    const cheekOnly = hooks.imagePrompt.after(markBase, [wife]);
    assert.match(cheekOnly.prompt, new RegExp(phrase));
    assert.doesNotMatch(cheekOnly.prompt, /handprint|palm print|bruise_on_arm|bruise_on_leg|red mark on buttock/,
      'the restored cheek default should not draw a stamped hand or add body marks');
    assert.doesNotMatch(cheekOnly.negativePrompt, /scratches|cuts|bleeding|scars|bruise_on_arm/,
      'cheek defaults must not weaken the mark with a broad injury Negative');
  }
  portraitLanguageButton.click();
  assert.match(portraitSummaryPanel.textContent, /손찌검: 뺨 · 흔적 3단계/,
    'state summary should explain the active mark instead of displaying its prompt');
  portraitLanguageButton.click();
  savedSettings.prompts['mark.slap.2'] = 'red handprint on cheek';
  state.waywardMarks = { id: 'wife', list: [
    { part: 'slap', degree: 2 }, { part: 'butt', degree: 1 },
  ] };
  delete state.activeScene;
  const visibleFaceMark = hooks.imagePrompt.after(markBase, [wife]);
  assert.match(visibleFaceMark.prompt, /bruise_on_face:1\.2/,
    'a prior default cheek mark should use the restored prompt');
  assert.doesNotMatch(visibleFaceMark.prompt, /red mark on buttock/,
    'a clothed idle portrait should not reveal body marks through clothing');
  savedSettings.prompts['mark.slap.2'] = '(bruise_on_face:1.2), (red swollen left cheek:1.3)';
  assert.match(hooks.imagePrompt.after(markBase, [wife]).prompt, /bruise_on_face:1\.2/,
    'the reported cheek trial prompt should use the restored default');
  savedSettings.prompts['mark.slap.2'] = '(clear red handprint confined to her left cheek:1.3), (mild swelling of her left cheek:1.15)';
  assert.match(hooks.imagePrompt.after(markBase, [wife]).prompt, /bruise_on_face:1\.2/,
    'the immediately prior cheek default should migrate to the restored prompt');
  savedSettings.prompts['mark.slap.2'] = '(clear red handprint only on her left cheek:1.35), (left cheek slightly swollen:1.2)';
  assert.match(hooks.imagePrompt.after(markBase, [wife]).prompt, /bruise_on_face:1\.2/,
    'the overly sharp trial default should migrate to the restored prompt');
  savedSettings.prompts['mark.slap.2'] = '(soft diffuse redness confined to her left cheek:1.25), (slight swelling of her left cheek:1.1)';
  assert.match(hooks.imagePrompt.after(markBase, [wife]).prompt, /bruise_on_face:1\.2/,
    'the overly weak trial default should also migrate');
  savedSettings.prompts['mark.slap.2'] = '(red handprint only on her left cheek:1.15), (left cheek slightly swollen:1.05)';
  assert.match(hooks.imagePrompt.after(markBase, [wife]).prompt, /bruise_on_face:1\.2/,
    'the 1.41.72 default should migrate to the restored prompt');
  savedSettings.prompts['mark.slap.2'] = 'my_custom_cheek_mark';
  assert.match(hooks.imagePrompt.after(markBase, [wife]).prompt, /my_custom_cheek_mark/,
    'unrelated user-authored cheek prompts must remain untouched');
  delete savedSettings.prompts['mark.slap.2'];
  state.activeScene = { patron: { customerId: 'guest-1', stage: 'sex_patron',
    __actStrikes: [{ part: 'breast', degree: 3 }] } };
  const liveStrike = hooks.imagePrompt.after({ ...markBase, key: 'pippa__scene-patron_sex__v-0' }, [wife]);
  assert.match(liveStrike.prompt, /dark bruise on her left breast/,
    'a current scene strike should appear before the persistent mark record is written');
  assert.match(liveStrike.prompt, /red palm print on her left buttock/);
  savedSettings.prompts['mark.breast.3'] = 'bruised breast, red handprint on breast';
  assert.match(hooks.imagePrompt.after({ ...markBase, key: 'pippa__scene-patron_sex__v-0' }, [wife]).prompt,
    /dark bruise on her left breast/,
    'a prior body-mark default should migrate to the restored prompt');
  savedSettings.prompts['mark.breast.3'] = '(dark purple-red palm print confined to her left breast:1.35), (localized swelling of her left breast:1.2)';
  assert.match(hooks.imagePrompt.after({ ...markBase, key: 'pippa__scene-patron_sex__v-0' }, [wife]).prompt,
    /dark bruise on her left breast/, 'the immediately prior body-mark default should migrate too');
  savedSettings.prompts['mark.breast.3'] = '(dark bruise on her left breast:1.3), (visibly swollen left breast:1.4)';
  assert.match(hooks.imagePrompt.after({ ...markBase, key: 'pippa__scene-patron_sex__v-0' }, [wife]).prompt,
    /dark bruise on her left breast/, 'the last packaged default should remain active');
  savedSettings.prompts['mark.breast.3'] = '(deep crimson handprint confined to her left breast:1.45), (localized swelling of her left breast:1.3)';
  assert.match(hooks.imagePrompt.after({ ...markBase, key: 'pippa__scene-patron_sex__v-0' }, [wife]).prompt,
    /dark bruise on her left breast/, 'the overly sharp body-mark default should migrate too');
  savedSettings.prompts['mark.breast.3'] = '(uneven muted red discoloration confined to her left breast:1.3), (localized swelling of her left breast:1.2)';
  assert.match(hooks.imagePrompt.after({ ...markBase, key: 'pippa__scene-patron_sex__v-0' }, [wife]).prompt,
    /dark bruise on her left breast/, 'the overly weak body-mark default should migrate too');
  savedSettings.prompts['mark.breast.3'] = '(red handprint confined to her left breast:1.2), (localized swelling of her left breast:1.1)';
  assert.match(hooks.imagePrompt.after({ ...markBase, key: 'pippa__scene-patron_sex__v-0' }, [wife]).prompt,
    /dark bruise on her left breast/, 'the 1.41.72 body default should migrate too');
  savedSettings.prompts['mark.breast.3'] = 'my_custom_breast_mark';
  assert.match(hooks.imagePrompt.after({ ...markBase, key: 'pippa__scene-patron_sex__v-0' }, [wife]).prompt,
    /my_custom_breast_mark/, 'a user-authored body mark must remain untouched');
  delete savedSettings.prompts['mark.breast.3'];
  state.activeScene = undefined;
  state.waywardMarks = { id: 'another-wife', list: [{ part: 'slap', degree: 3 }] };
  assert.doesNotMatch(hooks.imagePrompt.after(markBase, [wife]).prompt, /bruise_on_face:1\.3/,
    'another character mark record must not leak into the current wife portrait');
  state.waywardMarks = { id: 'wife', list: [{ part: 'slap', degree: 0 }] };
  assert.doesNotMatch(hooks.imagePrompt.after(markBase, [wife]).prompt, /bruise_on_face/,
    'healed marks should stop contributing tags');
  state.waywardMarks = { id: 'wife', list: [{ part: 'sex', degree: 2 }] };
  assert.doesNotMatch(hooks.imagePrompt.after(markBase, [wife]).prompt, /red palm-shaped mark on her vulva/,
    'a covered genital mark should stay hidden');
  const priorExposure = wife.exposure;
  wife.exposure = { ...priorExposure, pantiesAside: true };
  assert.match(hooks.imagePrompt.after(markBase, [wife]).prompt, /red palm-shaped mark on her vulva:1\.3/,
    'a lasting genital mark should appear when the underwear is aside');
  assert.match(hooks.imageKey.after(markBase.key, [wife]), /mark-sex-2/,
    'an exposed lasting mark should change the image situation');
  wife.exposure = priorExposure;
  state.waywardMarks = { id: 'wife', list: [] };
  state.activeScene = { patron: { customerId: 'guest-1', stage: 'chatting_patron',
    __actStrikes: [{ part: 'sex', degree: 1 }] } };
  const liveSexMark = hooks.imagePrompt.after({ ...markBase, key: 'pippa__scene-patron_chatting__v-0' }, [wife]);
  assert.match(liveSexMark.prompt, /red slap mark on her vulva:1\.2/,
    'the current strike should appear even before exposure flags and persistent state update');
  savedSettings.negativePrompts['mark.sex.1'] = 'test_mark_negative';
  assert.match(hooks.imagePrompt.after({ ...markBase, key: 'pippa__scene-patron_chatting__v-0' }, [wife]).negativePrompt,
    /test_mark_negative/);
  savedSettings.featurePrompts = { pregnancy: true, marks: false };
  const disabledMark = hooks.imagePrompt.after({ ...markBase, key: 'pippa__scene-patron_chatting__v-0' }, [wife]);
  assert.doesNotMatch(disabledMark.prompt,
    /red slap mark on her vulva/, 'the mark switch should suppress live marks');
  assert.doesNotMatch(disabledMark.negativePrompt, /test_mark_negative/,
    'the mark switch should suppress Negative marks too');
  assert.doesNotMatch(hooks.imageKey.after('pippa__scene-patron_chatting__v-0', [wife]), /mark-sex-/,
    'the mark switch should suppress mark image-key states');
  savedSettings.featurePrompts = { pregnancy: true, marks: true };
  delete savedSettings.negativePrompts['mark.sex.1'];
  state.activeScene = undefined;
  savedSettings.prompts['mark.sex.3'] = '(dark bruise on her vulva:1.3), (visibly swollen vulva:1.4)';
  state.waywardMarks = { id: 'wife', list: [{ part: 'sex', degree: 3 }] };
  wife.exposure = { ...priorExposure, pantiesRemoved: true };
  assert.match(hooks.imagePrompt.after(markBase, [wife]).prompt, /dark bruise on her vulva/,
    'the former dark bruise default should remain active');
  savedSettings.prompts['mark.sex.3'] = '(deep crimson palm-shaped mark across her vulva and pubic mound:1.5), (visibly swollen vulva:1.3)';
  assert.match(hooks.imagePrompt.after(markBase, [wife]).prompt, /dark bruise on her vulva/,
    'the overly sharp genital default should also migrate');
  savedSettings.prompts['mark.sex.3'] = '(noticeable muted red discoloration on her vulva and pubic mound:1.35), (localized swelling of her vulva:1.25)';
  assert.match(hooks.imagePrompt.after(markBase, [wife]).prompt, /dark bruise on her vulva/,
    'the overly weak genital default should also migrate');
  savedSettings.prompts['mark.sex.3'] = '(red palm-shaped mark across her vulva and pubic mound:1.25), (visibly swollen vulva:1.15)';
  assert.match(hooks.imagePrompt.after(markBase, [wife]).prompt, /dark bruise on her vulva/,
    'the 1.41.72 genital default should also migrate');
  wife.exposure = priorExposure;
  delete savedSettings.prompts['mark.sex.3'];
  settingsWin.refresh();
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '손찌검 흔적').props.onclick();
  const markFeatureToggle = collectNodes().find(node => node.props?.['data-aip-feature-toggle'] === 'marks');
  assert.equal(markFeatureToggle.props.checked, true);
  markFeatureToggle.props.onchange({ currentTarget: { checked: false } });
  assert.equal(savedSettings.featurePrompts.marks, false);
  collectNodes().find(node => node.props?.['data-aip-feature-toggle'] === 'marks')
    .props.onchange({ currentTarget: { checked: true } });
  assert.ok(collectNodes().some(node => node.props?.['data-aip-state-group'] === 'mark.slap'));
  collectNodes().find(node => node.props?.['data-aip-field-prompt'] === 'mark.slap.2:positive')
    .props.onchange({ currentTarget: { value: 'custom_cheek_mark' } });
  collectNodes().find(node => node.props?.['data-aip-field-prompt'] === 'mark.slap.2:negative')
    .props.onchange({ currentTarget: { value: 'unmarked_cheek' } });
  assert.equal(savedSettings.prompts['mark.slap.2'], 'custom_cheek_mark');
  assert.equal(savedSettings.negativePrompts['mark.slap.2'], 'unmarked_cheek');
  delete state.waywardMarks;
  promptInputByContext = null;

  settingsWin.refresh();
  collectNodes().find(node => node.tag === 'button' && node.children[0] === '의상 프롬프트').props.onclick();
  let createOutfitPanel = collectNodes().find(node => node.props?.['data-aip-custom-outfit-create'] === '');
  assert.equal(createOutfitPanel?.tag, 'details');
  createOutfitPanel.props.ontoggle({ currentTarget: { open: true } });
  settingsWin.refresh();
  createOutfitPanel = collectNodes().find(node => node.props?.['data-aip-custom-outfit-create'] === '');
  assert.equal(createOutfitPanel.props.open, true, 'the new-outfit form should stay open after refresh');
  const draftFields = [
    ['data-aip-custom-outfit-prompt', 'positivePrompt'],
    ['data-aip-custom-outfit-prompt', 'negativePrompt'],
    ['data-aip-custom-outfit-half', 'topPrompt'],
    ['data-aip-custom-outfit-half', 'skirtPrompt'],
  ];
  const outfitSettingsBeforeDraft = JSON.stringify(savedSettings.outfitPrompts);
  const existingOutfitsBeforeDraft = JSON.stringify(savedSettings.customOutfits);
  const draftField = (attribute, field) => collectNodes().find(node => node.props?.[attribute] === field);
  for (const [attribute, field] of draftFields) {
    let input = draftField(attribute, field);
    input.props.oninput({ currentTarget: { value: 'blue silk, (blue_silk:1.2)', closest: () => null } });
    input.props.onfocus();
    collectNodes().find(node => node.props?.['data-prompt-deduplicate'] === '').props.onclick();
    assert.equal(draftField(attribute, field).props.value.split(',').length, 1, `${field}: deduplication should affect the draft field`);
    await collectNodes().find(node => node.props?.['data-library-tag'] === 'heart_choker').props.onclick();
    assert.match(draftField(attribute, field).props.value, /heart_choker/, `${field}: library tag should enter the draft field`);
    assert.equal(JSON.stringify(savedSettings.outfitPrompts), outfitSettingsBeforeDraft, `${field}: existing outfit prompts changed`);
    assert.equal(JSON.stringify(savedSettings.customOutfits), existingOutfitsBeforeDraft, `${field}: existing custom outfits changed`);
    draftField(attribute, field).props.oninput({ currentTarget: { value: '', closest: () => null } });
  }
  draftField(...draftFields[0]).props.onfocus();
  collectNodes().find(node => node.props?.['data-aip-custom-outfit-create'] === '').props.ontoggle({ currentTarget: { open: false } });
  await collectNodes().find(node => node.props?.['data-library-tag'] === 'heart_choker').props.onclick();
  assert.equal(JSON.stringify(savedSettings.outfitPrompts), outfitSettingsBeforeDraft, 'closed draft should not change existing outfits');
  collectNodes().find(node => node.props?.['data-aip-custom-outfit-create'] === '').props.ontoggle({ currentTarget: { open: true } });
  settingsWin.refresh();
  createOutfitPanel = collectNodes().find(node => node.props?.['data-aip-custom-outfit-create'] === '');
  assert.equal(draftField(...draftFields[0]).props.value, '', 'closed draft should not receive a library tag');
  const createOutfitNodes = flattenNodes(createOutfitPanel);
  assert.equal(createOutfitNodes.find(node => node.props?.['data-aip-custom-outfit-boldness'] === '')?.props.value, 30);
  const customOutfitPositive = 'blue silk dress with silver embroidery and lace cuffs, fitted waist, long sleeves';
  createOutfitNodes.find(node => node.props?.['data-aip-custom-outfit-name'] === '').props.oninput({ currentTarget: { value: '달빛 의상' } });
  createOutfitNodes.find(node => node.props?.['data-aip-custom-outfit-description'] === '').props.oninput({ currentTarget: { value: '은실로 장식한 푸른 의상' } });
  const autoPriceLabel = createOutfitNodes.find(node => node.props?.['data-aip-custom-outfit-auto-price'] === '');
  createOutfitNodes.find(node => node.props?.['data-aip-custom-outfit-prompt'] === 'positivePrompt').props.oninput({
    currentTarget: { value: customOutfitPositive, closest: () => ({ querySelector: () => autoPriceLabel }) },
  });
  createOutfitNodes.find(node => node.props?.['data-aip-custom-outfit-prompt'] === 'negativePrompt').props.oninput({ currentTarget: { value: 'red dress, torn fabric' } });
  assert.equal(autoPriceLabel.textContent, '자동 가격 45G', 'the displayed automatic price should follow Positive length');
  const priorWifeOutfit = wife.outfit;
  const priorWifeTask = wife.currentTask;
  const priorOwnedOutfits = wife.ownedOutfits;
  const priorSceneOverride = wife.sceneOverride;
  const priorTryonExposure = wife.exposure;
  const priorTryonLookFocus = wife.lookFocus;
  const priorActiveScene = state.activeScene;
  const priorPortraitKey = activePortraitKey;
  const priorPromptInput = lastImagePromptInput;
  wife.outfit = 'modest';
  wife.ownedOutfits = ['modest'];
  wife.currentTask = 'sleeping';
  wife.sceneOverride = 'sex';
  wife.exposure = { topRemoved: true };
  wife.lookFocus = 'pussy';
  state.activeScene = { sex: { type: 'sex' } };
  activePortraitKey = debugContactKey;
  lastImagePromptInput = { result: debugContactBase };
  let previewCharacter;
  let shopPreviewCalls = 0;
  let shopPreviewLook;
  promptInputByContext = new Map([['taproom', character => {
    shopPreviewCalls += 1;
    previewCharacter = character;
    const selected = hooks.outfitById.after(api.fn('outfitById')(character.outfit), [character.outfit]);
    assert.ok(selected, 'draft and saved outfits should resolve for native imagePrompt');
    return { ...debugContactBase,
      key: `elena__task-idle__outfit-${character.outfit}__room-taproom__v-0`,
      prompt: `base_positive, ${selected.imageTags}`,
      negativePrompt: `base_negative, ${selected.negativeImageTags}`,
      ...(shopPreviewLook === undefined ? {} : { look: shopPreviewLook }),
      parts: [{ label: '기본', tags: 'base_positive' }, { label: '의상', tags: selected.imageTags }],
    };
  }]]);
  const outfitCountBeforeDraft = api.fn('outfitList').length;
  const savedCountBeforeDraft = (savedSettings.customOutfits || []).length;
  const draftPreviewButton = createOutfitNodes.find(node => node.props?.['data-aip-custom-outfit-draft-preview'] === '');
  assert.equal(draftPreviewButton?.children[0], '작성 중 의상 시착');
  await draftPreviewButton.props.onclick();
  const firstDraftRequest = generatedRequests.at(-1);
  assert.equal(firstDraftRequest.debug.source, 'attention-image-prompt-outfit-preview');
  assert.equal(Object.hasOwn(firstDraftRequest, 'look'), false, 'older outfit previews without a look must retain their request shape');
  assert.match(firstDraftRequest.prompt, /blue silk dress with silver embroidery/);
  assert.match(firstDraftRequest.negativePrompt, /red dress, torn fabric/);
  const draftLayout = collectNodes().find(node => node.props?.['data-aip-outfit-layout'] === '');
  assert.ok(flattenNodes(draftLayout).some(node => node.props?.['data-aip-outfit-preview'] === 'aip-outfit-draft-preview'),
    'draft preview should appear in the right-side outfit layout');
  assert.equal(previewCharacter.outfit, 'aip-outfit-draft-preview');
  assert.equal(previewCharacter.currentTask, 'idle');
  assert.equal(previewCharacter.sceneOverride, undefined);
  assert.equal(previewCharacter.exposure, undefined);
  assert.equal(previewCharacter.lookFocus, undefined);
  assert.equal(api.fn('outfitList').length, outfitCountBeforeDraft);
  assert.equal((savedSettings.customOutfits || []).length, savedCountBeforeDraft);
  assert.equal(wife.outfit, 'modest');
  assert.deepEqual(wife.ownedOutfits, ['modest']);
  assert.equal(wife.currentTask, 'sleeping');
  assert.equal(wife.sceneOverride, 'sex');
  assert.deepEqual(wife.exposure, { topRemoved: true });
  assert.equal(wife.lookFocus, 'pussy');
  let draftNodes = flattenNodes(collectNodes().find(node => node.props?.['data-aip-custom-outfit-create'] === ''));
  draftNodes.find(node => node.props?.['data-aip-custom-outfit-prompt'] === 'positivePrompt').props.oninput({
    currentTarget: { value: 'blue velvet dress, silver lace', closest: () => ({ querySelector: () => autoPriceLabel }) },
  });
  draftNodes.find(node => node.props?.['data-aip-custom-outfit-prompt'] === 'negativePrompt').props.oninput({ currentTarget: { value: 'orange clothes, torn fabric' } });
  shopPreviewLook = 'outfit-look';
  const requestsBeforeSecondDraft = generatedRequests.length;
  draftNodes = flattenNodes(collectNodes().find(node => node.props?.['data-aip-custom-outfit-create'] === ''));
  await draftNodes.find(node => node.props?.['data-aip-custom-outfit-draft-preview'] === '').props.onclick();
  assert.equal(generatedRequests.length, requestsBeforeSecondDraft + 1);
  const secondDraftRequest = generatedRequests.at(-1);
  assert.equal(secondDraftRequest.look, 'outfit-look', 'outfit previews must retain the game look fingerprint');
  assert.notEqual(secondDraftRequest.imageKey, firstDraftRequest.imageKey);
  assert.match(secondDraftRequest.prompt, /blue velvet dress, silver lace/);
  assert.doesNotMatch(secondDraftRequest.prompt, /blue silk dress with silver embroidery/);
  assert.match(secondDraftRequest.negativePrompt, /orange clothes, torn fabric/);
  assert.equal(api.fn('outfitList').length, outfitCountBeforeDraft);
  assert.equal((savedSettings.customOutfits || []).length, savedCountBeforeDraft);
  draftNodes = flattenNodes(collectNodes().find(node => node.props?.['data-aip-custom-outfit-create'] === ''));
  draftNodes.find(node => node.props?.['data-aip-custom-outfit-prompt'] === 'positivePrompt').props.oninput({
    currentTarget: { value: customOutfitPositive, closest: () => ({ querySelector: () => autoPriceLabel }) },
  });
  draftNodes.find(node => node.props?.['data-aip-custom-outfit-prompt'] === 'negativePrompt').props.oninput({ currentTarget: { value: 'red dress, torn fabric' } });
  draftNodes.find(node => node.props?.['data-aip-custom-outfit-half'] === 'topPrompt').props.oninput({ currentTarget: { value: 'moon blouse' } });
  draftNodes.find(node => node.props?.['data-aip-custom-outfit-half'] === 'skirtPrompt').props.oninput({ currentTarget: { value: 'moon skirt' } });
  draftNodes.find(node => node.tag === 'button' && node.children[0] === '의상 추가').props.onclick();
  const addedOutfit = savedSettings.customOutfits.at(-1);
  assert.match(addedOutfit.id, /^aip-outfit-/);
  assert.equal(addedOutfit.name, '달빛 의상');
  assert.equal(addedOutfit.manualPrice, null);
  assert.equal(addedOutfit.boldnessScore, 30);
  assert.equal(addedOutfit.wear, 'floor', 'existing and new outfits must default to ordinary floor clothing');
  assert.equal(addedOutfit.topPrompt, 'moon blouse');
  assert.equal(addedOutfit.skirtPrompt, 'moon skirt');
  assert.equal(api.fn('outfitList').find(entry => entry.id === addedOutfit.id)?.price, 45,
    'the game shop list should contain the saved outfit with its automatic price');
  assert.equal(api.fn('outfitById')(addedOutfit.id)?.imageTags, customOutfitPositive);
  assert.equal(api.fn('outfitById')(addedOutfit.id)?.halves?.top, 'moon blouse');
  assert.equal(api.fn('outfitById')(addedOutfit.id)?.halves?.skirt, 'moon skirt');
  collectNodes().find(node => node.props?.['data-aip-custom-outfit-edit-half'] === 'topPrompt')
    .props.oninput({ currentTarget: { value: 'edited moon blouse' } });
  assert.equal(api.fn('outfitById')(addedOutfit.id).halves.top, 'edited moon blouse',
    'editing a saved top prompt must update the game outfit immediately');
  collectNodes().find(node => node.props?.['data-aip-custom-outfit-edit-half'] === 'topPrompt')
    .props.oninput({ currentTarget: { value: 'moon blouse' } });
  collectNodes().find(node => node.props?.['data-aip-custom-outfit-edit-half'] === 'skirtPrompt')
    .props.oninput({ currentTarget: { value: 'edited moon skirt' } });
  assert.equal(api.fn('outfitById')(addedOutfit.id).halves.skirt, 'edited moon skirt',
    'editing a saved skirt prompt must update the game outfit immediately');
  collectNodes().find(node => node.props?.['data-aip-custom-outfit-edit-half'] === 'skirtPrompt')
    .props.oninput({ currentTarget: { value: 'moon skirt' } });
  assert.equal(hooks.outfitById.after(api.fn('outfitById')(addedOutfit.id), [addedOutfit.id]).price, 45);
  assert.equal(api.fn('outfitById')(addedOutfit.id).boldnessScore, 30);
  assert.deepEqual(preGenerateFloorOutfits, ['modest', 'maid_dress', addedOutfit.id, 'naked'],
    'new floor outfits must appear in the planner without replacing existing outfit IDs');
  assert.deepEqual(preGenerateBathOutfits, ['base-bath-outfit', 'nude']);
  const changeOutfitWear = wear => collectNodes().find(node => node.props?.['data-aip-custom-outfit-edit-wear'] === '')
    .props.onchange({ currentTarget: { value: wear } });
  changeOutfitWear('bath');
  assert.deepEqual(preGenerateFloorOutfits, ['modest', 'maid_dress', 'naked'], 'bath outfits must leave the floor list');
  assert.deepEqual(preGenerateBathOutfits, ['base-bath-outfit', addedOutfit.id, 'nude'],
    'bath outfits must be inserted before the native nude entry');
  changeOutfitWear('bath');
  assert.equal(preGenerateBathOutfits.filter(id => id === addedOutfit.id).length, 1, 'planner entries must not duplicate');
  changeOutfitWear('sleep');
  assert.deepEqual(preGenerateFloorOutfits, ['modest', 'maid_dress', addedOutfit.id, 'naked'],
    'the native planner groups sleep outfits with floor outfits');
  assert.deepEqual(preGenerateBathOutfits, ['base-bath-outfit', 'nude']);
  changeOutfitWear('floor');
  plannerOutfitSymbolsAvailable = false;
  changeOutfitWear('bath');
  assert.deepEqual(preGenerateFloorOutfits, ['modest', 'maid_dress', addedOutfit.id, 'naked'],
    'unsupported planner symbols must not alter existing lists');
  assert.deepEqual(preGenerateBathOutfits, ['base-bath-outfit', 'nude']);
  plannerOutfitSymbolsAvailable = true;
  changeOutfitWear('bath');
  assert.deepEqual(preGenerateBathOutfits, ['base-bath-outfit', addedOutfit.id, 'nude'],
    'planner lists must synchronize once optional symbols are available');
  changeOutfitWear('floor');
  let customOutfitPrice = collectNodes().find(node => node.props?.['data-aip-custom-outfit-edit-price'] === '');
  customOutfitPrice.props.onchange({ currentTarget: { value: '123' } });
  assert.equal(api.fn('outfitById')(addedOutfit.id).price, 123, 'a manual price should override the computed price');
  collectNodes().find(node => node.props?.['data-aip-custom-outfit-edit-boldness'] === '')
    .props.onchange({ currentTarget: { value: '65' } });
  assert.equal(api.fn('outfitById')(addedOutfit.id).boldnessScore, 65);
  collectNodes().find(node => node.props?.['data-outfit-prompt'] === 'positive')
    .props.onchange({ currentTarget: { value: 'blue velvet dress, silver lace' } });
  collectNodes().find(node => node.props?.['data-outfit-prompt'] === 'negative')
    .props.onchange({ currentTarget: { value: 'orange clothes, torn fabric' } });
  customOutfitPrice = collectNodes().find(node => node.props?.['data-aip-custom-outfit-edit-price'] === '');
  customOutfitPrice.props.onchange({ currentTarget: { value: '' } });
  assert.equal(api.fn('outfitById')(addedOutfit.id).price, 20, 'clearing the override should recalculate from edited Positive');
  assert.equal(api.fn('outfitById')(addedOutfit.id).imageTags, 'blue velvet dress, silver lace');
  assert.equal(api.fn('outfitById')(addedOutfit.id).negativeImageTags, 'orange clothes, torn fabric');
  assert.equal(savedSettings.customOutfits.at(-1).positivePrompt, 'blue velvet dress, silver lace');
  settingsWin.refresh();
  const outfitLayout = collectNodes().find(node => node.props?.['data-aip-outfit-layout'] === '');
  assert.ok(outfitLayout, 'outfit editor and preview should share a responsive layout');
  assert.ok(flattenNodes(outfitLayout).some(node => node.props?.['data-aip-outfit-preview'] === addedOutfit.id),
    'the preview should be in the right-side outfit layout');
  const previewSection = collectNodes().find(node => node.props?.['data-aip-outfit-preview'] === addedOutfit.id);
  const requestsBeforePreview = generatedRequests.length;
  await flattenNodes(previewSection).find(node => node.tag === 'button' && node.children[0] === '시착 이미지 생성').props.onclick();
  assert.equal(generatedRequests.length, requestsBeforePreview + 1);
  assert.ok(shopPreviewCalls >= 3, 'draft and saved try-on should use the shop portrait room');
  const outfitPreviewRequest = generatedRequests.at(-1);
  assert.equal(outfitPreviewRequest.debug.source, 'attention-image-prompt-outfit-preview');
  assert.match(outfitPreviewRequest.prompt, /blue velvet dress, silver lace/);
  assert.match(outfitPreviewRequest.negativePrompt, /orange clothes, torn fabric/);
  assert.equal(outfitPreviewRequest.bypassCache, true);
  assert.equal(previewCharacter.outfit, addedOutfit.id);
  assert.notEqual(previewCharacter, wife, 'the preview must use a clone of the current wife');
  assert.equal(previewCharacter.currentTask, 'idle');
  assert.equal(previewCharacter.sceneOverride, undefined);
  assert.equal(previewCharacter.exposure, undefined);
  assert.equal(previewCharacter.lookFocus, undefined);
  assert.equal(wife.outfit, 'modest');
  assert.deepEqual(wife.ownedOutfits, ['modest'], 'preview must not purchase or equip the outfit');
  collectNodes().find(node => node.props?.['data-aip-outfit-preview-image'] === addedOutfit.id).props.onclick();
  assert.equal(openedSettingsWindow.options.id, 'similar-image-preview');
  assert.equal(openedSettingsWindow.options.title, '이미지 크게 보기');
  collectNodes().find(node => node.props?.['data-export-section'] === 'customOutfits')
    .props.onchange({ currentTarget: { checked: true } });
  const outfitExportButton = collectNodes().find(node => node.tag === 'button' && node.children[0] === 'JSON 내보내기');
  outfitExportButton.props.onclick();
  const outfitExport = JSON.parse(exportedText);
  assert.equal(outfitExport.customOutfits.find(entry => entry.id === addedOutfit.id)?.positivePrompt, 'blue velvet dress, silver lace');
  assert.equal(outfitExport.customOutfits.find(entry => entry.id === addedOutfit.id)?.boldnessScore, 65);
  assert.equal(outfitExport.customOutfits.find(entry => entry.id === addedOutfit.id)?.topPrompt, 'moon blouse');
  assert.equal(outfitExport.customOutfits.find(entry => entry.id === addedOutfit.id)?.skirtPrompt, 'moon skirt');
  assert.equal(outfitExport.customOutfits.find(entry => entry.id === addedOutfit.id)?.wear, 'floor');
  savedSettings = { ...savedSettings, customOutfits: [] };
  const outfitImport = collectNodes().find(node => node.tag === 'input' && node.props.type === 'file');
  await outfitImport.props.onchange({ currentTarget: { files: [{ name: 'custom-outfits.json', text: async () => JSON.stringify({
    format: outfitExport.format, version: outfitExport.version, customOutfits: outfitExport.customOutfits,
  }) }], value: 'custom-outfits.json' } });
  assert.equal(savedSettings.customOutfits.find(entry => entry.id === addedOutfit.id)?.negativePrompt, 'orange clothes, torn fabric');
  assert.equal(api.fn('outfitById')(addedOutfit.id).halves.top, 'moon blouse');
  assert.equal(api.fn('outfitById')(addedOutfit.id).halves.skirt, 'moon skirt');
  assert.equal(api.fn('outfitById')(addedOutfit.id).price, 20, 'imported outfits should remain available in the shop');
  assert.equal(api.fn('outfitById')(addedOutfit.id).boldnessScore, 65);
  assert.deepEqual(preGenerateFloorOutfits, ['modest', 'maid_dress', addedOutfit.id, 'naked'],
    'imported outfit registration must restore the planner list without duplicates');
  assert.deepEqual(preGenerateBathOutfits, ['base-bath-outfit', 'nude']);
  const originalOutfitGameVersion = api.game;
  const legacyOutfit = { id: addedOutfit.id, name: addedOutfit.name, description: '',
    positivePrompt: 'blue dress, white apron', negativePrompt: 'red dress', boldnessScore: 30, manualPrice: null };
  savedSettings = { ...savedSettings, customOutfits: [] };
  api.game = '2026-10-24-pre7';
  await outfitImport.props.onchange({ currentTarget: { files: [{ name: 'legacy-outfits.json', text: async () => JSON.stringify({
    format: outfitExport.format, version: outfitExport.version, customOutfits: [legacyOutfit],
  }) }], value: 'legacy-outfits.json' } });
  const migratedOutfit = savedSettings.customOutfits.find(entry => entry.id === addedOutfit.id);
  assert.equal(migratedOutfit.wear, 'floor', 'legacy outfits must retain normal clothing type');
  assert.equal(migratedOutfit.topPrompt, '', 'legacy outfits must not invent a saved top prompt');
  assert.equal(migratedOutfit.skirtPrompt, '', 'legacy outfits must not invent a saved skirt prompt');
  assert.equal(typeof api.fn('outfitById')(addedOutfit.id).halves?.top, 'string',
    'pre7 must provide a safe top fallback for old saved outfits');
  assert.equal(typeof api.fn('outfitById')(addedOutfit.id).halves?.skirt, 'string',
    'pre7 must provide a safe skirt fallback for old saved outfits');
  api.game = originalOutfitGameVersion;
  savedSettings = { ...savedSettings, customOutfits: [] };
  await outfitImport.props.onchange({ currentTarget: { files: [{ name: 'custom-outfits.json', text: async () => JSON.stringify({
    format: outfitExport.format, version: outfitExport.version, customOutfits: outfitExport.customOutfits,
  }) }], value: 'custom-outfits.json' } });
  const outfitGuardScene = (id, tags, negativePrompt, male = true) => ({
    key: `elena__${male ? 'scene-sex' : 'task-idle'}__outfit-${id}__room-bedroom__v-0`,
    prompt: `best quality, 1girl, ${male ? '(1boy:1.2), sex, ' : ''}${tags}`,
    negativePrompt: `base_negative, ${male ? 'matching outfits, ' : ''}${negativePrompt}`,
    parts: [{ label: 'Base', tags: '1girl' },
      ...(male ? [{ label: 'Gender', tags: '(1boy:1.2)' }, { label: 'Scene', tags: 'sex' }] : []),
      { label: 'Outfit', tags }],
  });
  wife.outfit = addedOutfit.id;
  wife.sceneOverride = 'sex';
  wife.exposure = undefined;
  state.activeScene = { sex: { type: 'sex' } };
  const customScene = outfitGuardScene(addedOutfit.id, 'blue velvet dress, silver lace', 'orange clothes, torn fabric');
  const customScenePrompt = hooks.imagePrompt.after(customScene, [wife, 'bedroom']);
  assert.doesNotMatch(customScenePrompt.prompt, /\(only woman wearing the outfit:1\.25\)/,
    'a saved custom outfit must retain native outfit handling');
  assert.doesNotMatch(customScenePrompt.negativePrompt, /male wearing the same outfit/,
    'a saved custom outfit must not add the removed custom-only negative');
  assert.match(customScenePrompt.negativePrompt, /matching outfits/,
    'the base game\'s matching-outfits negative must remain intact');
  const customSceneKey = hooks.imageKey.after(customScene.key, [wife]);
  assert.match(customSceneKey, /att-custom-outfit-[a-z0-9]+/,
    'saved custom outfits need a new image key so old shared-outfit images are not reused');
  const soloCustomScene = outfitGuardScene(addedOutfit.id, 'blue velvet dress, silver lace', 'orange clothes, torn fabric', false);
  const soloCustomPrompt = hooks.imagePrompt.after(soloCustomScene, [wife, 'bedroom']);
  assert.doesNotMatch(soloCustomPrompt.prompt, /only woman wearing the outfit/,
    'a solo portrait must keep its existing custom-outfit prompt');
  assert.doesNotMatch(soloCustomPrompt.negativePrompt, /male wearing the same outfit/);
  assert.match(hooks.imageKey.after(soloCustomScene.key, [wife]), /att-custom-outfit-[a-z0-9]+/);
  const plannedCustomKey = hooks.imagePlanEntry.around(() => hooks.imageKey.after(customScene.key, [wife]));
  const plannedCustomPrompt = hooks.imagePlanEntry.around(() => hooks.imagePrompt.after(customScene, [wife, 'bedroom']));
  const plannedCustomEntries = hooks.imagePlanList.after([{ talentId: customScene.key, prompt: 'planned' }], [{}]);
  assert.equal(plannedCustomPrompt.key, plannedCustomKey, 'planned prompt and image key must agree for custom outfits');
  assert.equal(plannedCustomEntries[0].talentId, plannedCustomKey,
    'native planner candidates must use the custom outfit key used for generation');
  assert.equal(plannedCustomKey.match(/att-custom-outfit-[a-z0-9]+/)?.[0], customSceneKey.match(/att-custom-outfit-[a-z0-9]+/)?.[0],
    'planner and live portrait keys must share the same custom-outfit fingerprint');
  const defaultPlanEntries = [{ talentId: 'elena__task-idle__outfit-modest__v-0', prompt: 'base' }];
  assert.equal(hooks.imagePlanList.after(defaultPlanEntries, [{}]), defaultPlanEntries,
    'ordinary outfit plans must keep their existing array and key');
  wife.outfit = 'modest';
  const builtInScene = outfitGuardScene('modest', 'plain brown dress, white apron', 'cleavage, breasts_out');
  const builtInPrompt = hooks.imagePrompt.after(builtInScene, [wife, 'bedroom']);
  assert.doesNotMatch(builtInPrompt.prompt, /only woman wearing the outfit/,
    'built-in outfits must retain the game prompt');
  assert.doesNotMatch(builtInPrompt.negativePrompt, /male wearing the same outfit/);
  assert.doesNotMatch(hooks.imageKey.after(builtInScene.key, [wife]), /att-custom-outfit-/);
  wife.outfit = addedOutfit.id;
  const originalOutfitsForKey = savedSettings.customOutfits;
  savedSettings.customOutfits = originalOutfitsForKey.map(entry => entry.id === addedOutfit.id
    ? { ...entry, positivePrompt: 'green velvet dress, silver lace' } : entry);
  const editedPositiveKey = hooks.imageKey.after(customScene.key, [wife]);
  assert.notEqual(editedPositiveKey, customSceneKey,
    'editing a saved custom outfit Positive must invalidate its image key');
  savedSettings.customOutfits = savedSettings.customOutfits.map(entry => entry.id === addedOutfit.id
    ? { ...entry, negativePrompt: 'purple clothes, torn fabric' } : entry);
  assert.notEqual(hooks.imageKey.after(customScene.key, [wife]), editedPositiveKey,
    'editing a saved custom outfit Negative must invalidate its image key');
  savedSettings.customOutfits = originalOutfitsForKey.map(entry => entry.id === addedOutfit.id
    ? { ...entry, positivePrompt: 'silver lace, blue velvet dress', negativePrompt: 'torn fabric, orange clothes' } : entry);
  assert.equal(hooks.imageKey.after(customScene.key, [wife]), customSceneKey,
    'reordering the same custom outfit tags must reuse the same image key');
  for (const [field, value] of [['topPrompt', 'new blouse'], ['skirtPrompt', 'new skirt'],
    ['wear', 'bath'], ['boldnessScore', 85]]) {
    savedSettings.customOutfits = originalOutfitsForKey.map(entry => entry.id === addedOutfit.id ? { ...entry, [field]: value } : entry);
    assert.notEqual(hooks.imageKey.after(customScene.key, [wife]), customSceneKey,
      `editing a saved custom outfit ${field} must invalidate its image key`);
  }
  savedSettings.customOutfits = originalOutfitsForKey.map(entry => entry.id === addedOutfit.id ? { ...entry, manualPrice: 999 } : entry);
  assert.equal(hooks.imageKey.after(customScene.key, [wife]), customSceneKey,
    'changing an outfit price must not invalidate its image key');
  savedSettings.customOutfits = originalOutfitsForKey;
  if (priorWifeOutfit === undefined) delete wife.outfit; else wife.outfit = priorWifeOutfit;
  if (priorWifeTask === undefined) delete wife.currentTask; else wife.currentTask = priorWifeTask;
  if (priorOwnedOutfits === undefined) delete wife.ownedOutfits; else wife.ownedOutfits = priorOwnedOutfits;
  if (priorSceneOverride === undefined) delete wife.sceneOverride; else wife.sceneOverride = priorSceneOverride;
  if (priorTryonExposure === undefined) delete wife.exposure; else wife.exposure = priorTryonExposure;
  if (priorTryonLookFocus === undefined) delete wife.lookFocus; else wife.lookFocus = priorTryonLookFocus;
  state.activeScene = priorActiveScene;
  activePortraitKey = priorPortraitKey;
  lastImagePromptInput = priorPromptInput;
  promptInputByContext = null;

  for (const [tab, selector] of [['상세 상태', '[data-aip-state-group]'], ['수면 중 관계', '[data-aip-state-row]'], ['H Status', '[data-aip-state-group]']]) {
    settingsWin.refresh();
    collectNodes().find(node => node.tag === 'button' && node.children[0] === tab).props.onclick();
    const expanded = collectNodes().find(node => node.tag === 'details' && (selector === '[data-aip-state-group]'
      ? node.props?.['data-aip-state-group'] : node.props?.['data-aip-state-row']));
    assert.ok(expanded, `${tab} should have collapsible prompt sections`);
    const key = selector === '[data-aip-state-group]' ? 'data-aip-state-group' : 'data-aip-state-row';
    const id = expanded.props[key];
    expanded.props.ontoggle({ currentTarget: { open: true } });
    settingsWin.refresh();
    assert.equal(collectNodes().find(node => node.props?.[key] === id)?.props.open, true,
      `${tab} expanded prompt section should stay open after refresh`);
  }

  console.log('attention-image-prompt: ok');
}

run().catch(error => {
  console.error(error);
  process.exitCode = 1;
}).finally(() => {
  for (const win of [...fixtureWindows]) win.close();
});
