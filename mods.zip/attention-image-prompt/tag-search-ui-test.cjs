const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, 'source/settings-panels.js'), 'utf8');
const start = source.indexOf('    function renderPromptTagSearch(h) {');
const end = source.indexOf('    function renderGameDefaultPrompt(h, win) {', start);
assert.ok(start >= 0 && end > start);

class Element {
  constructor(tag, props, children) {
    this.tag = tag; this.props = props || {}; this.children = []; this.value = this.props.value || '';
    this.hidden = !!this.props.hidden; this.textContent = ''; this.listeners = {};
    this.append(...children.filter(child => child != null));
  }
  append(...children) { this.children.push(...children); }
  replaceChildren(...children) { this.children = []; this.append(...children); }
  addEventListener(type, fn) { this.listeners[type] = fn; }
}
const h = (tag, props, ...children) => new Element(tag, props, children);
let calls = 0, fail = false, response = { matches: [], warnings: [] };
const search = query => { calls++; if (fail) throw new Error('unavailable'); return { query, ...response }; };
const render = new Function('searchPromptTag', `${source.slice(start, end)}\nreturn renderPromptTagSearch;`)(search);
const section = render(h);
const all = node => node instanceof Element ? [node, ...node.children.flatMap(all)] : [];
const find = attr => all(section).find(node => Object.hasOwn(node.props, attr));
const input = find('data-prompt-tag-search-input'), status = find('data-prompt-tag-search-status');
const results = find('data-prompt-tag-search-results'), form = all(section).find(node => node.tag === 'form');
assert.ok(input && status && results && form);
const submit = () => { let prevented = false; form.props.onsubmit({ preventDefault() { prevented = true; } }); assert.equal(prevented, true); };
input.value = '   '; submit();
assert.equal(calls, 0, 'blank searches do not scan settings');
assert.match(status.textContent, /입력/);
input.value = ' side_view ';
assert.equal(calls, 0, 'typing does not trigger the search');
submit();
assert.equal(calls, 1);
assert.match(status.textContent, /없어요/);
response = { matches: Array.from({ length: 205 }, (_, i) => ({ scope: i ? 'candidate' : 'current',
  source: 'AIP', location: `장면 ${i}`, polarity: i === 1 ? 'negative' : 'positive', field: 'scene',
  prompt: 'side view, smile', matchedTags: ['side view'] })), warnings: ['게임 기본 표 일부를 읽지 못했어요.'] };
submit();
assert.match(status.textContent, /205개/);
assert.equal(all(results).filter(node => Object.hasOwn(node.props, 'data-prompt-tag-search-match')).length, 100);
const text = node => node instanceof Element ? [node.textContent, ...node.children.map(text)].join(' ') : String(node);
assert.match(text(results), /현재 장면/);
assert.match(text(results), /설정·기본 후보/);
assert.match(text(results), /Negative/);
assert.match(text(results), /side view/);
assert.match(text(results), /일부를 읽지 못했어요/);
let more = find('data-prompt-tag-search-more');
assert.equal(more.hidden, false);
more.listeners.click();
assert.equal(all(results).filter(node => Object.hasOwn(node.props, 'data-prompt-tag-search-match')).length, 200);
more.listeners.click();
assert.equal(all(results).filter(node => Object.hasOwn(node.props, 'data-prompt-tag-search-match')).length, 205);
assert.equal(more.hidden, true);
fail = true; submit();
assert.match(status.textContent, /검색하지 못했어요/);
assert.equal(results.children.length, 0, 'a failed search does not show stale results');
assert.match(source.slice(end, source.indexOf('    function renderCharacterPrompt', end)), /renderPromptTagSearch\(h\)/,
  'search is included at the end of game default settings');
console.log('prompt tag search UI: ok');
