const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const source = fs.readFileSync(`${__dirname}/source/image-browser.js`, 'utf8');
const start = source.indexOf('    function portraitImageMissing(');
const end = source.indexOf('    function decoratePortraitPositionButton(', start);
assert.ok(start >= 0 && end > start);

class Element {
  constructor(tag) { this.tag = tag; this.attrs = {}; this.children = []; this.style = {}; this.events = {}; this.textContent = ''; this.isConnected = true; }
  setAttribute(name, value) { this.attrs[name] = value; }
  append(...nodes) { for (const node of nodes) { node.parent = this; this.children.push(node); } }
  appendChild(node) { this.append(node); }
  remove() { if (this.parent) this.parent.children = this.parent.children.filter(node => node !== this); this.isConnected = false; }
  addEventListener(name, fn) { this.events[name] = fn; }
  querySelector(selector) {
    if (selector === '[data-attention-offline-area]') return this.children.find(node => node.attrs['data-attention-offline-area'] === '') || null;
    if (selector === '[data-sfw-placeholder], video') return this.hiddenImage ? {} : null;
    if (selector === '[data-attention-stale-accessory-image]') return this.staleImage ? {} : null;
    if (selector === 'img') return this.image || null;
    return null;
  }
  querySelectorAll(selector) { return selector === 'div' ? (this.texts || []).map(textContent => ({ textContent })) : []; }
}

let status = 'unconfigured', message = '', selected = true, chooseCalls = 0, reconnectCalls = 0, scans = 0, refreshes = 0, pendingChoice = null;
let activeKey = 'wife__scene-sex__v-0', host, frames = [], resizeHandler;
const api = {
  getState: () => ({ status, message }),
  choose: () => { chooseCalls += 1; return pendingChoice || Promise.resolve(selected); },
  reconnect: () => { reconnectCalls += 1; return Promise.resolve(selected); },
};
const context = { document: { createElement: tag => new Element(tag) }, offlineCache: api,
  offlineImageRefreshView: () => { refreshes += 1; }, scheduleUiScan: () => { scans += 1; },
  activePortraitImageKey: () => activeKey, latestScenePrompt: null, portraitViewHost: () => host,
  window: { requestAnimationFrame: fn => frames.push(fn), addEventListener: (type, fn) => { if (type === 'resize') resizeHandler = fn; } }, console };
const { portraitImageMissing, decorateOfflinePortraitFolder } = vm.runInNewContext(
  `${source.slice(start, end)}\n({portraitImageMissing, decorateOfflinePortraitFolder})`, context);
const event = () => ({ preventDefault() {}, stopPropagation() {} });
const settle = () => new Promise(resolve => setImmediate(resolve));

(async () => {
  resizeHandler();
  assert.equal(scans, 1, 'a viewport change schedules the portrait and choice button scan');
  const portrait = new Element('div');
  portrait.texts = ['이미지 없음'];
  assert.equal(portraitImageMissing(portrait), true);
  portrait.texts = ['생성 중...'];
  assert.equal(portraitImageMissing(portrait), false);
  portrait.texts = ['업데이트 중...'];
  assert.equal(portraitImageMissing(portrait), false);
  portrait.texts = ['이미지 없음']; portrait.hiddenImage = true;
  assert.equal(portraitImageMissing(portrait), false);
  portrait.hiddenImage = false; portrait.texts = []; portrait.staleImage = true;
  assert.equal(portraitImageMissing(portrait), true, 'a failed stale portrait is still missing');
  portrait.texts = ['업데이트 중...'];
  assert.equal(portraitImageMissing(portrait), false, 'an ongoing update must not show the folder button');
  portrait.staleImage = false; portrait.texts = [];
  portrait.image = new Element('img');
  Object.assign(portrait.image, { complete: false, naturalWidth: 0, src: 'https://example.test/picture.png' });
  assert.equal(portraitImageMissing(portrait), false);
  portrait.image.complete = true;
  assert.equal(portraitImageMissing(portrait), true);
  portrait.image.events.error();
  assert.ok(scans > 0);
  portrait.image.naturalWidth = 4;
  assert.equal(portraitImageMissing(portrait), false);
  portrait.image.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent('<svg viewBox="0 0 832 1216"><text>이미지 없음</text></svg>');
  assert.equal(portraitImageMissing(portrait), true);
  portrait.image.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent('<svg viewBox="0 0 10 10"><text>이미지 없음</text></svg>');
  assert.equal(portraitImageMissing(portrait), false);
  portrait.image = null; portrait.texts = ['이미지 없음'];
  decorateOfflinePortraitFolder(portrait);
  let area = portrait.querySelector('[data-attention-offline-area]');
  assert.ok(area);
  const [button, note] = area.children;
  assert.equal(button.textContent, '기존 이미지 폴더 연결');
  let cardClicks = 0, portraitClicks = 0, cardSelected = false;
  host = { isConnected: true, querySelectorAll: () => [
    { title: '초상화 보기', click: () => { portraitClicks += 1; } },
    { title: '캐릭터 정보 카드 보기', classList: { contains: token => token === 'bg-amber-900/40' && cardSelected }, click: () => { cardClicks += 1; cardSelected = true; } },
  ] };
  button.events.click(event());
  assert.equal(chooseCalls, 1, 'folder picker must be invoked in the click gesture');
  await settle();
  assert.equal(refreshes, 1); assert.equal(cardClicks, 1);
  frames.shift()(); assert.equal(portraitClicks, 1);
  button.events.click(event()); await settle();
  activeKey = 'wife__scene-new__v-0'; frames.shift()();
  assert.equal(portraitClicks, 1, 'a changed scene must not reopen the old portrait');
  button.events.click(event()); await settle();
  cardSelected = false; frames.shift()();
  assert.equal(portraitClicks, 1, 'a manually changed view must not be reopened');
  let finishChoice;
  pendingChoice = new Promise(resolve => { finishChoice = resolve; });
  const variantState = { variants: ['wife__scene-new__v-0', 'wife__scene-new__v-1'], currentIdx: 0 };
  portrait.__reactFiberTest = { memoizedState: { memoizedState: variantState, next: null }, return: null };
  const cardsBeforeChoice = cardClicks;
  button.events.click(event());
  variantState.currentIdx = 1; finishChoice(true); pendingChoice = null;
  await settle();
  assert.equal(cardClicks, cardsBeforeChoice, 'a changed image variant must not remount the old view');
  status = 'permission'; selected = false; message = '이전 연결 저장 오류';
  button.events.click(event()); assert.equal(reconnectCalls, 1);
  await settle();
  assert.equal(note.textContent, '폴더 읽기 권한을 허용해 주세요.');
  status = 'unavailable'; message = '폴더에 접근하지 못했어요. 다시 선택해 주세요.';
  const previousChoose = chooseCalls;
  button.events.click(event()); assert.equal(chooseCalls, previousChoose + 1, 'unavailable folder must offer a new folder selection');
  await settle();
  status = 'unconfigured'; message = ''; button.events.click(event()); await settle();
  assert.equal(note.textContent, '', 'cancelling selection stays quiet');
  portrait.texts = ['생성 중...']; decorateOfflinePortraitFolder(portrait);
  assert.equal(portrait.querySelector('[data-attention-offline-area]'), null);
  console.log('portrait offline button: ok');
})().catch(error => { console.error(error); process.exitCode = 1; });
