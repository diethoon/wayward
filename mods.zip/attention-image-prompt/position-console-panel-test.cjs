const assert = require('node:assert/strict');
const fs = require('node:fs');

class Node {
  constructor(tag, classes = []) {
    this.tagName = tag.toUpperCase();
    this.children = [];
    this.parentNode = null;
    this.attrs = {};
    this.style = { display: '', cssText: '' };
    this.classList = { contains: value => classes.includes(value) };
    this.textContent = '';
    this.listeners = {};
  }
  setAttribute(key, value) { this.attrs[key] = value; }
  getAttribute(key) { return this.attrs[key] ?? null; }
  hasAttribute(key) { return Object.hasOwn(this.attrs, key); }
  querySelector(selector) { return selector === '.hlc-x' && this.hasOffButton ? {} : null; }
  addEventListener(type, callback) { this.listeners[type] = callback; }
  append(...nodes) { for (const node of nodes) this.appendChild(node); }
  appendChild(node) { if (node.parentNode) node.remove(); node.parentNode = this; this.children.push(node); return node; }
  insertBefore(node, before) {
    if (node.parentNode) node.remove();
    node.parentNode = this;
    const index = this.children.indexOf(before);
    this.children.splice(index < 0 ? this.children.length : index, 0, node);
    return node;
  }
  replaceChildren(...nodes) { this.children = nodes; }
  remove() {
    if (this.parentNode) this.parentNode.children.splice(this.parentNode.children.indexOf(this), 1);
    this.parentNode = null;
  }
  get firstChild() { return this.children[0] || null; }
  get nextSibling() { return this.parentNode?.children[this.parentNode.children.indexOf(this) + 1] || null; }
}

const pane = new Node('div', ['flex-1', 'min-h-0', 'overflow-y-auto', 'p-2', 'xl:p-3']);
const native = new Node('div');
const gauges = new Node('div'); gauges.textContent = '당신 40% 그녀 60%';
const grid = new Node('div', ['grid', 'grid-cols-1', 'gap-2']);
const choice = label => { const node = new Node('button'); node.textContent = label; return node; };
const pose = choice('후배위'); pose.style.display = 'inline-flex';
const finish = choice('마무리');
const unavailable = choice('구강');
grid.append(pose, finish, unavailable);
native.append(gauges, grid);
const hl = new Node('div'); hl.textContent = 'HL 기존 쾌감과 행동';
const hlBody = new Node('div', ['hlc-body']);
const hlHead = new Node('div', ['hlc-head']); hlHead.textContent = 'HL 쾌감과 상태';
const hlFlow = new Node('div', ['hlc-flow']); hlFlow.textContent = 'HL 행동';
hlBody.append(hlHead, hlFlow); hl.append(hlBody);
const hlPose = choice('HL 후배위'); hlPose.setAttribute('data-choice-id', 'act_pose:후배위');
const hlCaress = choice('HL 손 애무'); hlCaress.setAttribute('data-choice-id', 'act_toggle:hand'); hlCaress.hasOffButton = true;
const hlSpeed = choice('HL 속도'); hlSpeed.setAttribute('data-choice-id', 'go_faster');
pane.querySelectorAll = () => [hlPose, hlCaress, hlSpeed];
pane.querySelector = selector => selector === '.hlc-dock.hlc-dock-fixed > .hlc-body' ? hlBody : null;
globalThis.__waywardHusbandLife = { owns: () => true, ui: { POSE_TYPE: { '후배위': 'sex' } } };
pane.append(native, hl);
const game = { activeScene: { sex: { type: 'sex' } }, pendingEvent: { type: 'sex_scene', choices: [
  { id: 'switch_to_sex', label: '후배위' }, { id: 'finish', label: '마무리' },
  { id: 'switch_to_blowjob', label: '구강' },
] } };
const state = { enabled: false, sceneToken: 'scene', reason: 'disabled', imageWarning: '', sceneLabel: '당신' };
const entries = [
  { id: 'native:switch_to_sex', actionId: 'switch_to_sex', provider: 'game', label: '후배위', available: true, scope: 'you', effect: 'game' },
  { id: 'native:switch_to_blowjob', actionId: 'switch_to_blowjob', provider: 'game', label: '구강', available: false, scope: 'you', effect: 'game' },
  { id: 'you-back', label: '후배위', available: true, scope: 'you', effect: 'game' },
  { id: 'you-back-duplicate', label: '후배위', group: '누워서', available: true, scope: 'you', effect: 'game' },
  { id: 'you-prone-front', label: '복와위', group: '앞/뒤', available: true, scope: 'you', effect: 'game' },
  { id: 'you-prone-lying', label: '복와위', group: '누워서', available: true, scope: 'you', effect: 'game', detail: '다른 설명이지만 같은 동작' },
  { id: 'you-prone-prone', label: '복와위', group: '엎드려', available: true, scope: 'you', effect: 'game' },
  { id: 'you-prone-conditional', label: '복와위', group: '특수', available: true, scope: 'you', effect: 'game', actionId: 'different-route', detail: '별도 경로' },
  { id: 'patron-prone', label: '복와위', group: '엎드려', available: true, scope: 'patron', effect: 'game' },
  { id: 'patron-prone-duplicate', label: '복와위', group: '누워서', available: true, scope: 'patron', effect: 'game' },
  { id: 'hl:caress:hand', actionId: 'act_toggle:hand', provider: 'husband-caress', caressKey: 'hand', caressMode: 'focus', label: '손 애무', active: true, available: true, scope: 'you', effect: 'game' },
  { id: 'image-right', provider: 'aip-prompt', label: '가슴', group: '이미지 · 오른손', available: true, scope: 'you', effect: 'image_only' },
  { id: 'image-left', provider: 'aip-prompt', label: '가슴', group: '이미지 · 왼손', available: true, scope: 'you', effect: 'image_only' },
];
const controller = { getState: () => state, list: () => entries, setEnabled(value) {
  state.enabled = value; state.reason = value ? '' : 'disabled'; return { ok: true };
} };
let fallback = 0;
let launchWindow, floatingWindow, floatingBody;
const windowController = { getState: () => ({ ...state, reason: state.reason === 'disabled' ? '' : state.reason }),
  list: () => entries, execute(id) { const row = entries.find(entry => entry.id === id); row.active = !row.active;
    return { ok: true, effect: 'image_only' }; } };
const api = { store: { game: () => game, subscribe() {} }, ui: {
  h: (tag, props, ...children) => ({ tag, props, children }),
  addButton(options) { fallback++; launchWindow = options.onClick; return { remove() { fallback--; } }; },
  window(options) { floatingBody = new Node('div'); floatingWindow = {
    refresh() { options.render(floatingBody, floatingWindow); },
    close() { options.onClose(); },
  }; floatingWindow.refresh(); return floatingWindow; },
} };
const document = { querySelectorAll: () => [pane], createElement: tag => new Node(tag) };
const window = {};
const source = fs.readFileSync(`${__dirname}/source/position-controller-ui.js`, 'utf8');
const { sync } = new Function('api', 'document', 'window', 'MutationObserver', 'positionControllerApi', 'positionControllerWindowApi',
  'positionControllerState', 'positionControllerList',
  `${source}\nreturn { sync: syncPositionControllerButton };`)(api, document, window, undefined, controller, windowController,
    () => controller.getState(), allowWindow => allowWindow ? windowController.list() : controller.list());

const header = pane.children.find(node => node.hasAttribute('data-aip-position-console-panel'));
const body = pane.children.find(node => node.hasAttribute('data-aip-position-console-body'));
assert.ok(header && body, 'the console toggle is available even when disabled');
assert.deepEqual(pane.children, [native, hl, header, body], 'console and toggle follow game and HL UI');
assert.equal(header.children[0].checked, false);
assert.equal(body.hidden, true);
assert.equal(pose.style.display, 'inline-flex');
assert.equal(fallback, 1, 'the floating launcher is always available');
assert.ok(pane.children.includes(native) && pane.children.includes(hl));

controller.setEnabled(true); sync();
assert.equal(header.children[0].checked, true);
assert.equal(body.hidden, false);
hlBody.replaceChildren(hlHead, hlFlow);
sync();
assert.deepEqual(pane.children, [native, hl, header, body], 'HL redraw leaves the console below its UI');
const lateGameUi = new Node('div');
pane.appendChild(lateGameUi); sync();
assert.deepEqual(pane.children, [native, hl, lateGameUi, header, body], 'newly added game UI remains above the console');
lateGameUi.remove(); sync();
const flatten = value => value && typeof value === 'object'
  ? [value, ...(value.children || []).flatMap(flatten)] : [];
const rendered = flatten(body.children[0]);
const consolePose = rendered.find(node => node.props?.['data-aip-position-controller-action'] === 'native:switch_to_sex');
assert.match(consolePose.props.style, /min-height:32px/, 'compact buttons retain a 32px target');
assert.match(consolePose.props['aria-label'], /후배위.*실제 행동/);
assert.ok(rendered.some(node => /minmax\(min\(100%,64px\),1fr\)/.test(node.props?.style || '')),
  'the console uses a compact grid that can fit multiple buttons in a narrow panel');
assert.ok(rendered.some(node => node.props?.['data-aip-position-controller-action'] === 'you-back'));
assert.ok(!rendered.some(node => node.props?.['data-aip-position-controller-action'] === 'you-back-duplicate'),
  'identical HL poses in multiple groups appear once');
assert.ok(rendered.some(node => node.props?.['data-aip-position-controller-action'] === 'you-prone-front')
  && !rendered.some(node => ['you-prone-lying', 'you-prone-prone'].includes(node.props?.['data-aip-position-controller-action'])),
  'identical 복와위 across 앞/뒤, 누워서 and 엎드려 appears once');
assert.ok(rendered.some(node => node.props?.['data-aip-position-controller-action'] === 'you-prone-conditional')
  && rendered.some(node => node.props?.['data-aip-position-controller-action'] === 'patron-prone'),
  'a different route or role remains a distinct action');
assert.ok(!rendered.some(node => node.props?.['data-aip-position-controller-action'] === 'patron-prone-duplicate'),
  'identical patron poses are also combined across groups');
assert.ok(rendered.some(node => node.props?.['data-aip-position-controller-action'] === 'image-right')
  && rendered.some(node => node.props?.['data-aip-position-controller-action'] === 'image-left'),
  'image-only hand slots remain separate even when their labels match');
assert.ok(!rendered.some(node => node.props?.['data-aip-position-controller-action'] === 'native:switch_to_blowjob'),
  'unavailable game actions are hidden from the console');
assert.ok(!rendered.some(node => node.props?.['data-aip-position-controller-unavailable'] !== undefined),
  'unavailable actions are not shown in an expandable section');
assert.equal(pose.style.display, 'none', 'the matching supported native action is replaced');
assert.equal(finish.style.display, '', 'finish remains usable');
assert.equal(unavailable.style.display, '', 'unavailable actions remain in the native panel');
assert.equal(hlPose.style.display, 'none', 'the matching available HL pose is replaced');
assert.equal(hlCaress.style.display, '', 'an active HL caress keeps its off control if the console cannot replace it');
assert.equal(hlSpeed.style.display, '', 'HL speed remains usable');
assert.equal(gauges.textContent, '당신 40% 그녀 60%');
assert.equal(hl.textContent, 'HL 기존 쾌감과 행동');
assert.equal(fallback, 1, 'the floating launcher remains available while docked');
const actionIds = () => flatten(body.children[0]).filter(node => node.props?.['data-aip-position-controller-action'])
  .map(node => node.props['data-aip-position-controller-action']);
const originalOrder = actionIds();
entries.push({ id: 'hl:caress-off:hand', actionId: 'act_off:hand', provider: 'husband-caress', caressKey: 'hand', caressMode: 'off', label: '손 애무 끄기', available: true, scope: 'you', effect: 'game' });
sync();
assert.equal(hlCaress.style.display, 'none', 'HL caress is replaced only when its off control is also available');
assert.deepEqual(actionIds().filter(id => id !== 'hl:caress-off:hand'), originalOrder,
  'the temporary off control does not reorder the main buttons');
const offWrapper = flatten(body.children[0]).find(node => node.children?.some(child => child?.props?.['data-aip-position-controller-action'] === 'hl:caress-off:hand'));
assert.ok(offWrapper.children.some(child => child?.props?.['data-aip-position-controller-action'] === 'hl:caress:hand'),
  'the off control occupies the same grid cell as the main action');
entries.find(row => row.id === 'hl:caress:hand').available = false;
sync();
assert.ok(actionIds().includes('hl:caress:hand') && actionIds().includes('hl:caress-off:hand'),
  'an unavailable active caress remains visible when its off action is available');
entries.find(row => row.id === 'hl:caress:hand').available = true;
entries.find(row => row.id === 'hl:caress:hand').active = false;
entries.find(row => row.id === 'image-right').active = true;
entries.find(row => row.id === 'patron-prone').available = false;
entries.find(row => row.id === 'patron-prone').reason = 'occupied';
entries.find(row => row.id === 'patron-prone-duplicate').available = false;
entries.find(row => row.id === 'patron-prone-duplicate').reason = 'occupied';
sync();
assert.ok(!actionIds().includes('patron-prone') && !actionIds().includes('patron-prone-duplicate'),
  'an action disappears when it becomes unavailable');
assert.deepEqual(actionIds().filter(id => id !== 'hl:caress-off:hand'), originalOrder.filter(id => id !== 'patron-prone'),
  'remaining buttons keep their relative order');
entries.find(row => row.id === 'patron-prone').available = true;
entries.find(row => row.id === 'patron-prone').reason = '';
sync();
assert.ok(actionIds().includes('patron-prone'), 'an action reappears when it becomes available');

controller.setEnabled(false); sync();
assert.equal(pose.style.display, 'inline-flex', 'disabling restores the exact native display style');
assert.equal(hlPose.style.display, '', 'disabling restores HL pose buttons');
assert.equal(hlCaress.style.display, '', 'disabling restores HL caress buttons');
assert.equal(finish.style.display, '');
assert.equal(body.hidden, true);

entries.find(row => row.id === 'image-left').available = false;
launchWindow();
assert.equal(state.enabled, false, 'opening the window does not enable the screen console');
assert.ok(!flatten(floatingBody.children[0]).some(node => node.props?.['data-aip-position-controller-action'] === 'image-left'),
  'the floating console also hides unavailable actions');
entries.find(row => row.id === 'image-left').available = true;
floatingWindow.refresh();
assert.ok(flatten(floatingBody.children[0]).some(node => node.props?.['data-aip-position-controller-action'] === 'image-left'),
  'the floating console restores an action when it becomes available');
const floatingImage = flatten(floatingBody.children[0]).find(node => node.props?.['data-aip-position-controller-action'] === 'image-right');
assert.ok(floatingImage && !floatingImage.props.disabled, 'window actions remain available with the screen console off');
floatingImage.props.onclick();
setImmediate(() => {
  assert.equal(state.enabled, false, 'window actions do not enable the screen console');
  assert.equal(entries.find(row => row.id === 'image-right').active, false, 'the window executes the shared selection');
  controller.setEnabled(true); sync();
  const panelImage = flatten(body.children[0]).find(node => node.props?.['data-aip-position-controller-action'] === 'image-right');
  assert.equal(panelImage.props['aria-pressed'], 'false', 'the inline console reflects the window selection');
  assert.ok(floatingWindow && floatingBody.children.length, 'the open window survives docking and enabling');
  floatingWindow.close();
  assert.equal(state.enabled, true, 'closing the window does not disable the screen console');
  pane.querySelector = () => null;
  sync();
  assert.deepEqual(native.children, [gauges, grid], 'the native status and choices remain intact');
  assert.deepEqual(pane.children, [native, hl, header, body], 'the console remains below the game UI without HL');
  game.pendingEvent.type = 'wife_conversation'; sync();
  assert.equal(pose.style.display, 'inline-flex', 'leaving the scene restores native actions');
  assert.equal(header.parentNode, null);
  assert.equal(body.parentNode, null);
  assert.equal(fallback, 1, 'the launcher remains available when no scene panel is docked');
  delete globalThis.__waywardHusbandLife;
  console.log('position console panel: ok');
});
