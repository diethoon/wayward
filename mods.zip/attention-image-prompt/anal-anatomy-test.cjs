const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const keys = fs.readFileSync(path.join(__dirname, 'source/image-cache-and-keys.js'), 'utf8');
const rules = fs.readFileSync(path.join(__dirname, 'source/prompt-mod-rules.js'), 'utf8');
const slice = (source, begin, end) => {
  const from = source.indexOf(`    function ${begin}(`), to = source.indexOf(`    function ${end}(`, from + 1);
  assert.ok(from >= 0 && to > from);
  return source.slice(from, to);
};
let state = { primaryCharacterId: 'wife', activeScene: { sex: { type: 'anal', characterId: 'wife' } } };
let onlyState = false;
const scope = {
  imagePlanDepth: 0,
  api: { store: { game: () => state } },
  positionSituationId: key => key.split('__').find(part => part.startsWith('scene-'))
    + (key.includes('__grp-') ? '|grp-1' : ''),
  basePositionSituationId: id => id.split('|')[0],
  positionGroupCount: id => /(?:^|\|)grp-[1-9]/.test(id) ? 1 : 0,
  currentPositionStatePrompt: () => ({ onlyState, positivePrompt: onlyState ? 'custom' : '' }),
  positionStateOnly: value => value.onlyState && !!value.positivePrompt,
  multiplePatronActions: () => !!state.activeScene?.patron?.joinedPatronIds?.length,
  deduplicatePrompt: value => [...new Set(String(value).split(', ').filter(Boolean))].join(', '),
  joinPrompt: value => String(value).split(', ').filter(Boolean).join(', '),
  promptGenParams: prompt => ({ length: prompt.length }),
};
vm.createContext(scope);
vm.runInContext(`${slice(keys, 'singleAnalAnatomyScene', 'situationImageKey')}\n${slice(rules, 'alignAnalInsertion', 'alignAnalFinish')}\nthis.align = (result, id = 'wife') => alignAnalInsertion(result, id); this.eligible = singleAnalAnatomyScene; this.conflicts = analAnatomyConflictingPrompt;`, scope);
const base = { key: 'wife__scene-anal__v-0', prompt: '1girl, anal, (menstruation:1.1), (small trace of blood at her vaginal opening:1.25)',
  negativePrompt: 'bad anatomy', parts: [{ label: '장면', tags: 'anal' }, { label: '생리', tags: '(menstruation:1.1), (small trace of blood at her vaginal opening:1.25)' }] };
let output = scope.align(base);
assert.match(output.prompt, /penis inserted into her anus/);
assert.match(output.prompt, /vaginal opening/, 'menstruation must remain visible');
assert.match(output.negativePrompt, /penis in vagina/);
assert.equal(output.parts.at(-1).label, '항문 삽입 구분');
assert.equal(scope.align(output), output, 'the guard must be idempotent');
assert.equal(scope.eligible(base.key, 'wife'), true);
assert.equal(scope.eligible(base.key, 'other'), false, 'another character must not get the key marker');
assert.equal(scope.eligible(base.key, undefined), false, 'unknown character must not get the key marker');
assert.equal(scope.align(base, 'other'), base, 'another character must not get the prompt adjustment');
scope.imagePlanDepth = 1;
assert.equal(scope.align(base), base, 'pre-generation must preserve the external plan prompt');
scope.imagePlanDepth = 0;
for (const tag of ['vaginal', '(vaginal:1.3)', 'vaginal penetration', 'penis_in_pussy', 'vaginal_object_insertion', 'fingering', '(fingering:1.2)', 'fellatio', '2boys']) {
  const mixed = { ...base, prompt: `${base.prompt}, ${tag}` };
  assert.equal(scope.align(mixed), mixed, `do not override explicit mixed act ${tag}`);
}
const group = { ...base, key: 'wife__scene-anal__grp-1__v-0' };
assert.equal(scope.align(group), group);
const extra = { ...base, parts: [...base.parts, { label: '추가 인원 배치 · 손님', tags: 'other' }] };
assert.equal(scope.align(extra), extra);
onlyState = true; assert.equal(scope.align(base), base); onlyState = false;
state.activeScene.sex.type = 'sex'; assert.equal(scope.align(base), base);
state.activeScene = { sex: { type: 'anal' }, patron: { stage: 'sex_patron' } };
assert.equal(scope.align(base), base, 'simultaneous scenes must remain untouched');
state.activeScene = { patron: { stage: 'sex_patron', primarySlot: 'inside_anal', customerId: 'guest' } };
const guest = { ...base, key: 'wife__scene-patron_anal__v-0' };
assert.match(scope.align(guest).prompt, /penis inserted into her anus/);
state.activeScene.patron.joinedPatronIds = ['other']; assert.equal(scope.align(guest), guest);
assert.match(keys, /if \(singleAnalAnatomyScene\(base, characterId\) && !choice\?\.conflictingNativeAct\) \{\s*const analChoiceTags/);
assert.match(keys, /!analAnatomyConflictingPrompt\(analChoiceTags\)\) add\('att', 'anal-anatomy-v1'\)/);
const hook = fs.readFileSync(path.join(__dirname, 'source/mod.wml.js'), 'utf8');
assert.match(hook, /alignAnalFinish\(outerHStatusPortrait \? aligned : alignPortraitAccessories\(aligned, character\), characterId\)/);
assert.equal(scope.conflicts('vaginal_opening'), false);
assert.equal(scope.conflicts('(vaginal:1.3)'), true);
assert.equal(scope.conflicts('fingering'), true);
console.log('anal anatomy prompt: ok');
