const assert = require('node:assert/strict');
const fs = require('node:fs');
const source = fs.readFileSync(require('node:path').join(__dirname, 'source/scene-native-prompts.js'), 'utf8');
const tables = {
  gameScenePromptTable: { patron_chatting: ['talking one', 'talking two'] },
  gameBedScenePromptTable: { patron_chatting: ['in bed'] },
  gameTaskPromptTable: { idle: 'standing', cooking: 'cooking', idle_bedroom: 'on bed' },
  gameLookPromptTable: { tits: ['front', 'side'] },
  gameLookReactionPromptTable: { coy: 'shy' },
  gameSexPromptTable: [{ tags: 'vaginal, pose one', surfaces: ['bed'] }, { tags: 'vaginal, pose two', surfaces: ['floor'] }],
  gameRoughSexPromptTable: [{ tags: 'rough, vaginal', surfaces: ['bed'] }],
};
const api = { has: name => Object.hasOwn(tables, name), fn: name => tables[name] };
const get = new Function('api', `${source}\nreturn nativeScenePromptCandidates;`)(api);
assert.deepEqual(get('scene-patron_chatting').map(x => [x.source, x.text]), [
  ['scene', 'talking one'], ['scene', 'talking two'], ['bed', 'in bed'],
]);
assert.deepEqual(get('scene-sex').map(x => [x.source, x.text]), [['scene', 'vaginal, pose one'], ['scene', 'vaginal, pose two']]);
assert.deepEqual(get('scene-sex_rough').map(x => [x.source, x.text]), [['scene', 'rough, vaginal']]);
assert.deepEqual(get('task-cooking').map(x => [x.source, x.text]), [['task', 'cooking'], ['bedroom', 'on bed']]);
for (const task of ['composing', 'away', 'bathing', 'resting', 'at_market']) {
  assert.deepEqual(get(`task-${task}`).map(x => [x.source, x.text]),
    [['task', 'standing'], ['bedroom', 'on bed']], `${task} uses the game's idle and bedroom fallbacks`);
}
assert.deepEqual(get('look-tits|reaction-coy').map(x => [x.source, x.text]), [
  ['look', 'front'], ['look', 'side'], ['reaction', 'shy'],
]);
assert.deepEqual(get('task-sleeping'), [], 'special sleeping prompt must not be mislabeled as idle');
const htmlPath = require('node:path').resolve(__dirname, '../../../Wayward_WML_ko.html');
if (fs.existsSync(htmlPath)) {
  const html = fs.readFileSync(htmlPath, 'utf8'), start = html.indexOf('function HE('), end = html.indexOf('const l$e=', start);
  assert.ok(start >= 0 && end > start, 'pre7 native function located');
  const original = new Function(`return (${html.slice(start, end)});`)();
  tables.imagePrompt = Object.assign(function dispatcher() {}, { __wmlOriginal: original });
  assert.deepEqual(get('task-sleeping').map(x => x.text), [
    'sleeping peacefully, lying in bed, closed_eyes, head on pillow, blanket pulled up, soft morning light',
  ]);
  assert.equal(get('task-passed_out').length, 2, 'both native intoxication locations are identified');
  tables.imagePrompt = function unknown() {};
  assert.deepEqual(get('task-sleeping'), [], 'a changed or unavailable original must not invent a candidate');
}
assert.deepEqual(get('scene-mod-specific'), []);
assert.deepEqual(get(null), []);
tables.gameScenePromptTable.patron_chatting = [null, {}, '', 'valid'];
tables.gameBedScenePromptTable = [];
assert.deepEqual(get('scene-patron_chatting').map(x => x.text), ['valid']);
delete tables.gameTaskPromptTable;
assert.deepEqual(get('task-cooking'), []);
api.fn = () => { throw new Error('unavailable'); };
assert.deepEqual(get('look-tits|reaction-coy'), []);
console.log('native scene prompt candidates: ok');
