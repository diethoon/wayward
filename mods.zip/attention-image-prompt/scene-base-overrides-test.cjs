const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, 'source/scene-base-overrides.js'), 'utf8');
const shared = fs.readFileSync(path.join(__dirname, 'source/prompt-mod-rules.js'), 'utf8');
const split = shared.slice(shared.indexOf('    function splitFinalPrompt('), shared.indexOf('    function deduplicateFinalPrompt('));
const identity = shared.slice(shared.indexOf('    function promptTagIdentity('), shared.indexOf('    function translatedPromptTag('));
let settings = { sceneBaseOverrides: {} }, registered, notifications = 0;
const api = {
  settings: { get: defaults => ({ ...defaults, ...settings }), set: changes => { settings = { ...settings, ...changes }; } },
  hook: (name, value) => { assert.equal(name, 'imagePrompt'); registered = value; },
  store: { game: () => ({ primaryCharacterId: 'wife' }) },
  ui: { button: (label, onClick, options) => ({ label, onClick, options }) },
};
const make = new Function('api', 'nativeScenePromptCandidates', 'shortHash', 'promptGenParams', 'notifyExternalPromptChange',
  `let imagePlanDepth = 0, promptPreviewing = false;\n${split}\n${identity}\n${source}\nreturn {
    normalizeSceneBaseOverrides, reloadSceneBaseOverrides, sceneBaseOverride, saveSceneBaseOverride,
    resetSceneBaseOverride, sceneBaseOverrideFingerprint, evaluateSceneBaseOverride, installSceneBaseOverrideHook,
    setPlan: value => { imagePlanDepth = value; }, setPreview: value => { sceneBaseOverridePreviewing = value; },
    status: () => lastSceneBaseOverrideStatus, renderSceneBaseOverride,
    capture: (id, key) => { sceneBaseNativeCurrent = readCurrentNativeScenePart(id, key); return sceneBaseNativeCurrent; },
  };`);
const candidateMap = {
  'scene-patron_chatting': [{ source: 'scene', text: '1boy, talking, (hands, face:1.2)' }],
  'scene-ambiguous': [{ source: 'scene', text: 'a, b, c' }, { source: 'scene', text: 'a, b, d' }],
  'task-cooking': [{ source: 'task', text: 'cooking, kitchen' }],
  'task-sleeping': [{ source: 'pose', text: 'sleeping, closed eyes' }],
  'task-passed_out': [{ source: 'pose', text: 'passed out in bed' }, { source: 'pose', text: 'passed out at bar' }],
  'look-tits|reaction-coy': [{ source: 'look', text: 'breasts focus, close-up' }, { source: 'reaction', text: 'shy' }],
};
const nativeSource = fs.readFileSync(path.join(__dirname, 'source/scene-native-prompts.js'), 'utf8');
const taskTable = { idle: 'standing, relaxed', idle_bedroom: 'sitting, on_bed' };
const nativeTaskCandidates = new Function('api', `${nativeSource}\nreturn nativeScenePromptCandidates;`)({
  has: name => name === 'gameTaskPromptTable', fn: () => taskTable,
});
candidateMap['task-composing'] = nativeTaskCandidates('task-composing');
const candidates = id => candidateMap[id] || candidateMap[id.split('|')[0]] || [];
const feature = make(api, candidates, value => require('node:crypto').createHash('sha256').update(value).digest('hex').slice(0, 12),
  prompt => ({ prompt }), () => { notifications++; });
const getId = key => String(key || '').split('__').filter(part => /^(?:scene|task|look|reaction|abed|grp|gslot|sleep)-/.test(part)).join('|');
// Position identity is supplied by the existing shared game-key helper.
global.positionSituationId = getId;
global.baseSituationImageKey = value => String(value || '').replace(/__aip-[^_]+/g, '');
global.latestScenePrompt = null;
global.activeTagTarget = null;
global.promptTagPreview = () => null;
global.updatePromptTagPreview = () => {};
global.nativeInlinePoseCandidates = () => ({ sleeping: ['verified'] });
global.sceneCandidatePoolCount = 0;
global.sceneCandidateFingerprint = () => '';
global.sceneCandidateEntryForResult = () => null;
global.appendSelectedSceneCandidate = result => result;
let portraitRefreshes = 0;
global.refreshPortraitImage = () => { portraitRefreshes++; };
const scene = {
  key: 'wife__scene-patron_chatting__v-0',
  prompt: '(1boy:1.2), talking, (hands, face:1.2), white shirt', negativePrompt: 'watermark',
  parts: [{ label: '성별', tags: '(1boy:1.2)' }, { label: '장면', tags: '1boy, talking, (hands, face:1.2)' },
    { label: '의상', tags: 'white shirt' }], genParams: { old: true },
};
assert.equal(feature.evaluateSceneBaseOverride(scene).reason, 'no_override');
assert.equal(feature.saveSceneBaseOverride('scene-patron_chatting', 'whispering, (hand on table:1.2)'), true);
const firstToken = feature.sceneBaseOverrideFingerprint('scene-patron_chatting');
assert.ok(firstToken);
const applied = feature.evaluateSceneBaseOverride(scene);
assert.equal(applied.reason, 'applied');
assert.equal(applied.result.prompt, 'whispering, (hand on table:1.2), (1boy:1.2), white shirt');
assert.equal(applied.result.negativePrompt, scene.negativePrompt);
assert.equal(applied.result.parts[0], scene.parts[0], 'shared tag owner is untouched');
assert.equal(applied.result.parts[1].tags, 'whispering, (hand on table:1.2)');
assert.deepEqual(applied.result.genParams, { prompt: applied.result.prompt });
assert.equal(scene.parts[1].tags, '1boy, talking, (hands, face:1.2)', 'original object is not mutated');
const filteredScene = { ...scene, prompt: '(1boy:1.2), talking, white shirt',
  parts: scene.parts.map(part => part.label === '장면' ? { ...part, tags: '1boy, talking' } : part) };
assert.equal(feature.evaluateSceneBaseOverride(filteredScene).result.prompt,
  'whispering, (hand on table:1.2), (1boy:1.2), white shirt', 'a unique ordered subset is accepted');
feature.saveSceneBaseOverride('scene-ambiguous', 'replacement');
for (const tags of ['a, b', 'a, x, c', 'b, a, c', 'a, (b:1.2), c']) {
  const ambiguous = { key: 'wife__scene-ambiguous__v-0', prompt: tags, parts: [{ label: '장면', tags }] };
  assert.equal(feature.evaluateSceneBaseOverride(ambiguous).reason, 'unknown_source',
    'multiple candidates, inserted tags, reordered tags and changed weights are not accepted');
}

for (const input of [
  { ...scene, parts: scene.parts.filter(part => part.label !== '장면') },
  { ...scene, parts: [...scene.parts, { label: 'Scene', tags: 'other' }] },
  { ...scene, parts: scene.parts.map(part => part.label === '장면' ? { ...part, tags: 'other mod text' } : part) },
  { ...scene, prompt: scene.prompt + ', talking' },
  { ...scene, prompt: '(1boy:1.2), (talking:1.4), (hands, face:1.2), white shirt' },
  { ...scene, prompt: 'broken (prompt' },
]) {
  const result = feature.evaluateSceneBaseOverride(input);
  assert.notEqual(result.reason, 'applied');
  assert.equal(result.result, input, 'uncertain source stays untouched');
}
assert.equal(feature.saveSceneBaseOverride('scene-patron_chatting', ''), true, 'empty replacement deliberately removes scene-only tags');
assert.notEqual(feature.sceneBaseOverrideFingerprint('scene-patron_chatting'), firstToken);
assert.equal(feature.evaluateSceneBaseOverride(scene).result.prompt, '(1boy:1.2), white shirt');
assert.equal(feature.sceneBaseOverride('scene-patron_chatting|abed-1').positivePrompt, '', 'base scene inherits to a detailed scene');
assert.equal(feature.sceneBaseOverride('scene-patron_chatting|sleep-asleep'), null, 'sleep is not inherited');
const inheritedFingerprint = feature.sceneBaseOverrideFingerprint('scene-patron_chatting|abed-1');
assert.ok(inheritedFingerprint);
assert.equal(feature.saveSceneBaseOverride('scene-patron_chatting|abed-1', 'bed only'), true);
assert.equal(feature.sceneBaseOverride('scene-patron_chatting|abed-1').positivePrompt, 'bed only', 'specific setting overrides base');
assert.notEqual(feature.sceneBaseOverrideFingerprint('scene-patron_chatting|abed-1'), inheritedFingerprint);
assert.equal(feature.resetSceneBaseOverride('scene-patron_chatting|abed-1'), true);
assert.equal(feature.sceneBaseOverrideFingerprint('scene-patron_chatting|abed-1'), inheritedFingerprint, 'reset returns to the base setting');
assert.equal(feature.saveSceneBaseOverride('scene-patron_chatting__v-1', 'bad'), false);

const task = { key: 'wife__task-cooking__v-0', prompt: '1girl, cooking, kitchen, dress', negativePrompt: 'bad',
  parts: [{ label: '기본', tags: '1girl' }, { label: '작업', tags: 'cooking, kitchen' }, { label: '의상', tags: 'dress' }] };
feature.saveSceneBaseOverride('task-cooking', 'washing');
assert.equal(feature.evaluateSceneBaseOverride(task).result.prompt, '1girl, washing, dress');
feature.saveSceneBaseOverride('task-composing', 'composing music');
for (const tags of [taskTable.idle, taskTable.idle_bedroom]) {
  const fallbackTask = { key: 'wife__task-composing__v-0', prompt: `1girl, ${tags}, dress`, negativePrompt: 'bad',
    parts: [{ label: '기본', tags: '1girl' }, { label: '작업', tags }, { label: '의상', tags: 'dress' }] };
  const result = feature.evaluateSceneBaseOverride(fallbackTask);
  assert.equal(result.reason, 'applied', `verified fallback ${tags} should be editable`);
  assert.equal(result.result.prompt, '1girl, composing music, dress');
  assert.equal(result.result.negativePrompt, 'bad');
}
const dynamicWife = { id: 'wife' };
let dynamicState = { primaryCharacterId: 'wife', characters: { wife: dynamicWife }, day: 1, slot: 1, activeScene: {} };
const dynamicResult = { key: 'wife__task-cooking__v-0', prompt: '1girl, passed out in bed, dress', negativePrompt: 'bad',
  parts: [{ label: '기본', tags: '1girl' }, { label: '자세', tags: 'passed out in bed' }, { label: '의상', tags: 'dress' }] };
const native = () => dynamicResult;
const dispatcher = Object.assign(() => {}, { __wmlOriginal: native });
const nativeSymbols = { imagePrompt: dispatcher, portraitSceneContext: () => ({}), portraitMoodContext: () => null,
  portraitFinishContext: () => null, wifeLocation: () => 'bedroom', imageRoom: value => value,
  playerSexScene: () => null, patronScene: () => null };
api.store.game = () => dynamicState;
api.has = name => Object.hasOwn(nativeSymbols, name);
api.fn = name => nativeSymbols[name];
assert.equal(feature.capture('task-cooking', dynamicResult.key).text, 'passed out in bed');
assert.equal(feature.evaluateSceneBaseOverride(dynamicResult).result.prompt, '1girl, washing, dress', 'current dynamic pose can be edited');
dynamicState = { ...dynamicState, characters: { wife: { ...dynamicWife } } };
assert.notEqual(feature.evaluateSceneBaseOverride(dynamicResult).reason, 'applied', 'different character state invalidates dynamic candidate');
assert.equal(feature.capture('task-cooking', 'wife__task-cooking__v-1'), null, 'different image key is rejected');
feature.saveSceneBaseOverride('task-cooking', 'washing', { label: '자세', text: 'passed out in bed' });
feature.reloadSceneBaseOverrides(false);
assert.equal(feature.evaluateSceneBaseOverride(dynamicResult).result.prompt, '1girl, washing, dress', 'verified part survives settings reload');
const changedDynamic = { ...dynamicResult, prompt: '1girl, passed out at bar, dress',
  parts: dynamicResult.parts.map(part => part.label === '자세' ? { ...part, tags: 'passed out at bar' } : part) };
assert.notEqual(feature.evaluateSceneBaseOverride(changedDynamic).reason, 'applied', 'changed dynamic native text is not overwritten');
nativeSymbols.imagePrompt = () => {};
assert.notEqual(feature.evaluateSceneBaseOverride(dynamicResult).reason, 'applied', 'unknown wrapper is not trusted');
nativeSymbols.imagePrompt = dispatcher;
feature.saveSceneBaseOverride('task-cooking', 'washing');
api.store.game = () => ({ primaryCharacterId: 'wife' });
for (const [id, tags] of [['sleeping', 'sleeping, closed eyes'], ['passed_out', 'passed out in bed'], ['passed_out', 'passed out at bar']]) {
  feature.saveSceneBaseOverride(`task-${id}`, 'new pose');
  const input = { key: `wife__task-${id}__v-0`, prompt: `1girl, ${tags}, dress`, negativePrompt: 'bad',
    parts: [{ label: '기본', tags: '1girl' }, { label: '자세', tags }, { label: '의상', tags: 'dress' }] };
  const result = feature.evaluateSceneBaseOverride(input);
  assert.equal(result.reason, 'applied');
  assert.equal(result.result.prompt, '1girl, new pose, dress');
  assert.equal(result.result.negativePrompt, 'bad');
  const unknown = { ...input, parts: input.parts.map(p => p.label === '자세' ? { ...p, tags: 'unknown pose' } : p) };
  assert.equal(feature.evaluateSceneBaseOverride(unknown).reason, 'unknown_source');
  feature.resetSceneBaseOverride(`task-${id}`);
}
const look = { key: 'wife__look-tits__reaction-coy__v-0', prompt: 'breasts focus, close-up, shy', negativePrompt: 'bad',
  parts: [{ label: '초점', tags: 'breasts focus, close-up' }, { label: '반응', tags: 'shy' }] };
feature.saveSceneBaseOverride('look-tits|reaction-coy', 'face focus');
assert.equal(feature.evaluateSceneBaseOverride(look).result.prompt, 'face focus, shy');

feature.installSceneBaseOverrideHook();
assert.equal(registered.priority, Number.MAX_SAFE_INTEGER);
feature.setPlan(1);
assert.equal(registered.around(() => task), task, 'bulk planning is not affected');
feature.setPreview(true);
assert.equal(registered.around(() => task).prompt, '1girl, washing, dress', 'explicit isolated preview includes overrides');
feature.setPreview(false); feature.setPlan(0);
assert.equal(registered.around(() => task).prompt, '1girl, washing, dress');
assert.equal(feature.status().reason, 'applied');
assert.equal(feature.resetSceneBaseOverride('task-cooking'), true);
assert.equal(feature.sceneBaseOverrideFingerprint('task-cooking'), '');
assert.ok(notifications >= 4);
settings.sceneBaseOverrides = { 'task-cooking': { positivePrompt: 'reloaded' } };
feature.reloadSceneBaseOverrides();
assert.equal(feature.sceneBaseOverride('task-cooking').positivePrompt, 'reloaded');
feature.resetSceneBaseOverride('task-cooking');
const element = (tag, props, ...children) => ({ tag, props, children });
const walk = node => !node || typeof node !== 'object' ? [] : [node, ...(node.children || []).flatMap(walk)];
const win = { refresh() {} };
const render = (id, key = '') => walk({ children: feature.renderSceneBaseOverride(element, win, id, key) });
let nodes = render('task-cooking');
nodes.find(node => node.label === '이 장면 프롬프트 변경').onClick();
nodes = render('task-cooking');
assert.equal(nodes.some(node => node.props?.['data-scene-base-draft'] !== undefined), false,
  'unobserved situations require the user to select an actual candidate');
nodes.find(node => node.props?.['data-scene-base-candidate'] !== undefined).props.onchange({ currentTarget: { value: '0' } });
nodes = render('task-cooking');
let draft = nodes.find(node => node.props?.['data-scene-base-draft'] !== undefined);
assert.equal(draft.props.value, 'cooking, kitchen');
draft.props.oninput({ currentTarget: { value: 'new cooking' } });
assert.equal(feature.sceneBaseOverride('task-cooking'), null, 'typing alone never saves');
nodes.find(node => node.label === '취소').onClick();
assert.equal(feature.sceneBaseOverride('task-cooking'), null);
nodes = render('task-cooking'); nodes.find(node => node.label === '이 장면 프롬프트 변경').onClick();
nodes = render('task-cooking');
nodes.find(node => node.props?.['data-scene-base-candidate'] !== undefined).props.onchange({ currentTarget: { value: '0' } });
nodes = render('task-cooking'); draft = nodes.find(node => node.props?.['data-scene-base-draft'] !== undefined);
draft.props.oninput({ currentTarget: { value: 'new cooking' } });
nodes.find(node => node.label === '변경 저장').onClick();
assert.equal(feature.sceneBaseOverride('task-cooking').positivePrompt, 'new cooking');
nodes = render('task-cooking'); nodes.find(node => node.label === '이 장면 프롬프트 변경').onClick();
nodes = render('task-cooking'); draft = nodes.find(node => node.props?.['data-scene-base-draft'] !== undefined);
assert.equal(draft.props.value, 'new cooking');
draft.props.oninput({ currentTarget: { value: '' } });
nodes.find(node => node.label === '변경 저장').onClick();
assert.equal(feature.sceneBaseOverride('task-cooking').positivePrompt, '', 'empty override is explicitly saved');
nodes = render('task-cooking'); nodes.find(node => node.label === '이 장면 프롬프트 변경').onClick();
nodes = render('task-cooking'); nodes.find(node => node.label === '원본 복원').onClick();
assert.equal(feature.sceneBaseOverride('task-cooking'), null);
feature.resetSceneBaseOverride('scene-patron_chatting');
global.latestScenePrompt = { characterId: 'wife', result: scene };
nodes = render('scene-patron_chatting', scene.key); nodes.find(node => node.label === '이 장면 프롬프트 변경').onClick();
nodes = render('scene-patron_chatting', scene.key);
assert.equal(nodes.find(node => node.props?.['data-scene-base-draft'] !== undefined).props.value,
  '1boy, talking, (hands, face:1.2)', 'verified current candidate may initialize the draft');
nodes.find(node => node.label === '취소').onClick();
global.latestScenePrompt = { characterId: 'other', result: scene };
nodes = render('scene-patron_chatting', scene.key); nodes.find(node => node.label === '이 장면 프롬프트 변경').onClick();
nodes = render('scene-patron_chatting', scene.key);
assert.equal(nodes.some(node => node.props?.['data-scene-base-draft'] !== undefined), false,
  'a different character cannot supply the current candidate');
feature.saveSceneBaseOverride('scene-patron_chatting', 'base text');
nodes = render('scene-patron_chatting|abed-1');
assert.ok(nodes.some(node => node.props?.['data-scene-base-inherited'] !== undefined), 'inherited settings are clearly labeled');
nodes.find(node => node.label === '이 장면 프롬프트 변경').onClick();
nodes = render('scene-patron_chatting|abed-1');
assert.equal(nodes.find(node => node.props?.['data-scene-base-draft'] !== undefined).props.value, 'base text');
nodes.find(node => node.props?.['data-scene-base-draft'] !== undefined).props.oninput({ currentTarget: { value: 'bed only' } });
nodes.find(node => node.label === '변경 저장').onClick();
nodes = render('scene-patron_chatting|abed-1'); nodes.find(node => node.label === '이 장면 프롬프트 변경').onClick();
nodes = render('scene-patron_chatting|abed-1'); nodes.find(node => node.label === '세부 설정 삭제').onClick();
assert.equal(feature.sceneBaseOverride('scene-patron_chatting|abed-1').positivePrompt, 'base text');
assert.equal(feature.sceneBaseOverride('scene-patron_chatting').positivePrompt, 'base text', 'resetting a detail must not delete base settings');
assert.equal(portraitRefreshes, 0, 'off-screen edits and cancellation do not refresh the portrait');
feature.resetSceneBaseOverride('task-cooking');
api.store.game = () => dynamicState;
nodes = render('task-cooking', dynamicResult.key); nodes.find(node => node.label === '이 장면 프롬프트 변경').onClick();
nodes = render('task-cooking', dynamicResult.key);
nodes.find(node => node.props?.['data-scene-base-candidate'] !== undefined).props.onchange({ currentTarget: { value: '0' } });
nodes = render('task-cooking', dynamicResult.key);
assert.equal(nodes.find(node => node.props?.['data-scene-base-draft'] !== undefined).props.value, 'passed out in bed');
nodes.find(node => node.props?.['data-scene-base-draft'] !== undefined).props.oninput({ currentTarget: { value: 'new dynamic pose' } });
nodes.find(node => node.label === '변경 저장').onClick();
assert.deepEqual(feature.sceneBaseOverride('task-cooking').nativePart, { label: '자세', text: 'passed out in bed' });
feature.reloadSceneBaseOverrides(false);
assert.equal(feature.evaluateSceneBaseOverride(dynamicResult).result.prompt, '1girl, new dynamic pose, dress');
api.store.game = () => ({ primaryCharacterId: 'wife' });
settings.sceneBaseOverrides = {};
feature.reloadSceneBaseOverrides(false);
global.positionSituationId = () => { throw new Error('unconfigured hook must not parse keys'); };
for (let index = 0; index < 100; index++) assert.equal(registered.around(() => scene), scene);
delete global.positionSituationId;
delete global.baseSituationImageKey;
delete global.latestScenePrompt;
delete global.activeTagTarget;
delete global.promptTagPreview;
delete global.updatePromptTagPreview;
delete global.nativeInlinePoseCandidates;
delete global.refreshPortraitImage;
console.log('scene base overrides: ok');
