const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const read = name => fs.readFileSync(path.join(__dirname, 'source', name), 'utf8');
const shared = read('prompt-mod-rules.js');
const split = shared.slice(shared.indexOf('    function splitFinalPrompt('), shared.indexOf('    function deduplicateFinalPrompt('));
let saved = {}, reads = 0, notifications = 0, reject = false;
const api = { settings: { get: defaults => { reads++; return { ...defaults, ...saved }; },
  set: patch => { if (reject) throw Error('storage'); saved = { ...saved, ...patch }; } } };
const feature = new Function('api', 'shortHash', 'notifyExternalPromptChange', 'promptGenParams',
  `const legacyDetailImageKeys = new Map(), statusCacheAliases = new Map(); ${split}\n${read('global-prompt-exclusions.js')}
  return { currentGlobalPromptExclusions, saveGlobalPromptExclusions, reloadGlobalPromptExclusions,
    globalPromptExclusionsFingerprint, removeGlobalPromptExclusions, applyGlobalPromptExclusions };`)(api,
  value => crypto.createHash('sha256').update(value).digest('hex').slice(0, 12), () => notifications++, value => ({ value }));
assert.equal(feature.globalPromptExclusionsFingerprint(), '');
assert.equal(feature.removeGlobalPromptExclusions('smile, (blue_eyes:1.2)'), 'smile, (blue_eyes:1.2)');
assert.equal(feature.saveGlobalPromptExclusions('blue eyes, smile'), true);
assert.equal(feature.saveGlobalPromptExclusions('watermark, smile', 'negative'), true);
assert.equal(feature.removeGlobalPromptExclusions('1girl, (blue_eyes:1.25), smile, smiling, (smile:0.8), <lora:test:1>'), '1girl, smiling, <lora:test:1>');
assert.equal(feature.removeGlobalPromptExclusions('smile\n(blue eyes:1.1)\nclear skin'), 'clear skin');
assert.equal(feature.removeGlobalPromptExclusions('(blue eyes, smile:1.2), smile'), '(blue eyes, smile:1.2)');
assert.equal(feature.removeGlobalPromptExclusions('smile, (broken'), 'smile, (broken');
const input = { prompt: 'smile, blue eyes, watermark, face', negativePrompt: '(smile:1.4), blue_eyes, watermark, blurry',
  parts: [{ label: 'scene', tags: 'smile, hair' }], genParams: { steps: 8 } };
const cleaned = feature.applyGlobalPromptExclusions(input);
assert.equal(cleaned.prompt, 'watermark, face');
assert.equal(cleaned.negativePrompt, 'blue_eyes, blurry');
assert.equal(cleaned.parts[0].tags, 'hair');
assert.deepEqual(cleaned.genParams, { steps: 8 }, 'existing generation parameters are not overwritten');
assert.equal(input.prompt, 'smile, blue eyes, watermark, face');
const key = feature.globalPromptExclusionsFingerprint();
assert.equal(feature.saveGlobalPromptExclusions('smile, BLUE_EYES, smile'), true);
assert.equal(feature.globalPromptExclusionsFingerprint(), key);
assert.equal(feature.saveGlobalPromptExclusions('(invalid'), false);
assert.equal(feature.globalPromptExclusionsFingerprint(), key);
reject = true;
assert.equal(feature.saveGlobalPromptExclusions('new tag'), false);
assert.equal(feature.globalPromptExclusionsFingerprint(), key);
reject = false;
saved.globalPromptExclusions = '';
saved.globalPromptExclusionsPositive = '';
saved.globalPromptExclusionsNegative = '';
feature.reloadGlobalPromptExclusions();
assert.equal(feature.globalPromptExclusionsFingerprint(), '');
assert.equal(feature.removeGlobalPromptExclusions('smile, blue eyes'), 'smile, blue eyes');
saved = { globalPromptExclusions: 'legacy_tag' };
feature.reloadGlobalPromptExclusions();
assert.equal(feature.currentGlobalPromptExclusions('positive'), 'legacy_tag');
assert.equal(feature.currentGlobalPromptExclusions('negative'), 'legacy_tag');
assert.equal(feature.removeGlobalPromptExclusions('legacy tag, fine', 'negative'), 'fine');
assert.equal(feature.saveGlobalPromptExclusions('positive only', 'positive'), true);
assert.equal(feature.currentGlobalPromptExclusions('negative'), 'legacy_tag');
const withPositive = feature.globalPromptExclusionsFingerprint();
assert.equal(feature.saveGlobalPromptExclusions('', 'positive'), true);
assert.notEqual(feature.globalPromptExclusionsFingerprint(), withPositive, 'each polarity contributes to cache key');
assert.equal(feature.removeGlobalPromptExclusions('positive only, legacy tag', 'positive'), 'positive only, legacy tag');
assert.equal(feature.removeGlobalPromptExclusions('positive only, legacy tag', 'negative'), 'positive only');
assert.equal(reads, 3);
assert.equal(notifications, 5);
const cameraNegative = new Function(`${read('camera-presets.js')}\nreturn CAMERA_NEGATIVE_DEFAULTS;`)();
assert.equal(feature.saveGlobalPromptExclusions('visible camera', 'negative'), true);
const cameraResult = feature.applyGlobalPromptExclusions({ prompt: '(frontal camera view:1.3)', negativePrompt: cameraNegative });
assert.doesNotMatch(cameraResult.negativePrompt, /visible camera/, 'global negative exclusion can remove a camera default');
assert.match(cameraResult.negativePrompt, /camera device/, 'unrelated camera defaults stay applied');
assert.match(cameraResult.prompt, /frontal camera view/, 'negative exclusions do not alter camera angles');
console.log('global prompt exclusions: ok');
