const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const source = fs.readFileSync(`${__dirname}/source/camera-ui.js`, 'utf8');
let game = { primaryCharacterId: 'pippa', characters: { pippa: { name: '피파' } }, scene: 'scene-sex' };
let snapshots = {}, savedSnapshots = {};
let menu, root, refreshes = 0, previewCalls = [], generatedRequests = [], resize;
const rect = { left: 100, top: 24, width: 600, height: 720 };
const viewport = { innerWidth: 800, innerHeight: 600, addEventListener(name, fn) { if (name === 'resize') resize = fn; } };
const windowElement = { isConnected: true, style: { setProperty(name, value) { rect[name] = Number.parseFloat(value); } },
  getBoundingClientRect() { return { ...rect, right: rect.left + rect.width, bottom: rect.top + rect.height }; } };
const groups = [
  { id: 'direction', label: '방향', items: [
    { id: 'front', name: '정면', positive: '(frontal camera view:1.3)', negative: '' },
    { id: 'side', name: '측면', positive: 'from side', negative: '' },
    { id: 'rear', name: '후면', positive: 'from behind', negative: '' },
  ] },
  { id: 'elevation', label: '높이', items: [{ id: 'above', name: '위', positive: '(high-angle camera view:1.3)', negative: '' }] },
  { id: 'framing', label: '범위', items: [{ id: 'close_up', name: '얼굴', positive: 'close-up', negative: '' }] },
  { id: 'viewpoint', label: '시점', items: [{ id: 'pov', name: '1인칭', positive: 'pov', negative: '' },
    { id: 'pov_below', name: '아래 1인칭', positive: 'pov, from below', negative: '' }] },
  { id: 'tilt', label: '기울기', items: [{ id: 'dutch', name: '기울임', positive: 'dutch angle', negative: '' }] },
  { id: 'lens', label: '렌즈', items: [{ id: 'fisheye', name: '어안', positive: 'fisheye', negative: '' }] },
];
const snapshot = id => snapshots[id] || savedSnapshots[id] || { situationId: id, sourceId: id, shots: [], selected: [], removeTags: '', active: false, dirty: false, warnings: [] };
const h = (tag, props, ...children) => ({ tag, props: props || {}, children: children.flat().filter(x => x != null) });
const body = { replaceChildren(node) { root = node; } };
const controller = {
  list: () => ({ groups, removeDefaults: ['pov'], negativeDefaults: 'camera in frame, visible camera' }),
  get: id => snapshot(id || game.scene),
  apply(id, patch) { snapshots[id] = { ...snapshot(id), ...structuredClone(patch), active: patch.selected.length > 0, dirty: true }; return { ok: true }; },
  set(id, patch) { savedSnapshots[id] = { ...snapshot(id), ...structuredClone(patch), active: patch.selected.length > 0, dirty: false }; delete snapshots[id]; return { ok: true }; },
  reset(id) { delete snapshots[id]; delete savedSnapshots[id]; return { ok: true }; },
  preview(id, prompt, negative, options) { previewCalls.push({ id, options }); return { prompt: `${prompt}, front view`, negativePrompt: negative, shotId: snapshot(id).selected[0] }; },
};
const api = {
  store: { game: () => game, subscribe() {} },
  ui: { h, addButton(value) { menu = value; return {}; }, window(opts) { const win = { el: windowElement, refresh() { opts.render(body, win); } }; win.refresh(); return win; } },
  has: name => name === 'imageGenerate',
  fn: name => name === 'imageGenerate' ? async request => { generatedRequests.push(request); return { url: 'https://example.test/image.png' }; } : null,
};
const context = { api, cameraController: controller, cameraSceneSettings: savedSnapshots, structuredClone, window: viewport,
  activePortraitImageKey: (_, state) => `${state.primaryCharacterId}__${state.scene}`,
  positionSituationId: key => key.split('__')[1] || '', positionSituationLabel: id => id,
  promptTagPreview: () => null, updatePromptTagPreview() {}, refreshPortraitImage() { refreshes++; },
  deduplicateFinalPrompt: value => [...new Set(value.split(',').map(item => item.trim()).filter(Boolean))].join(', '),
  splitFinalPrompt: value => (value.split('(').length === value.split(')').length ? { tokens: value.split(',') } : null),
  scenePreviewRequest: () => { const request = { prompt: 'base, front view', negativePrompt: 'bad', checkpoint: 'model' };
    Object.defineProperty(request, '__aipCameraPreviewShotId', { value: 'preview-shot' }); return request; },
  shortHash: () => 'hash', diagnosticText: error => String(error.message), queueMicrotask, Promise,
};
vm.runInNewContext(source, context);
const flatten = node => !node || typeof node !== 'object' ? [] : [node, ...(node.children || []).flatMap(flatten)];
const get = (name, value) => flatten(root).find(node => node.props?.[name] === value);
const click = (name, value) => { const node = get(name, value); assert.ok(node, `${name}=${value}`); node.props.onclick(); };
assert.equal(menu.label, '카메라 구도');
menu.onClick();
assert.ok(get('data-aip-camera-window', ''));
assert.equal(rect.height, 584, 'window must fit when first opened');
viewport.innerWidth = 390;
resize();
assert.equal(rect.width, 374, 'window must fit a narrow viewport');
assert.equal(rect.left, 8);
rect.top = 10;
rect.height = 550;
resize();
assert.equal(rect.top, 10, 'a valid user position must not move');
click('data-aip-camera-angle', 'front');
assert.equal(snapshot(game.scene).selected.length, 1);
assert.ok(get('data-aip-camera-negative-defaults', ''), 'shared equipment-blocking negative is visible near the editor');
assert.equal(snapshot(game.scene).shots[0].positive, '(frontal camera view:1.3)');
assert.equal(savedSnapshots[game.scene], undefined, 'clicking a view applies temporarily without saving');
assert.equal(flatten(root).filter(node => node.props?.['data-aip-camera-shot']).length, 0, 'unsaved combinations do not appear in saved views');
click('data-aip-camera-angle', 'above');
assert.equal(snapshot(game.scene).shots.find(s => s.id === snapshot(game.scene).selected[0]).positive, '(frontal camera view:1.3), (high-angle camera view:1.3)');
assert.equal(snapshot(game.scene).shots.length, 1, 'intermediate unsaved combinations are discarded');
const shotId = snapshot(game.scene).selected[0];
get('data-aip-camera-prompt', 'positive').props.onchange({ currentTarget: { value: 'custom pose' } });
assert.equal(snapshot(game.scene).shots.find(s => s.id === shotId).positive, 'custom pose');
get('data-aip-camera-prompt', 'negative').props.onchange({ currentTarget: { value: 'custom negative' } });
click('data-aip-camera-reset-prompt', '');
assert.equal(snapshot(game.scene).shots.find(s => s.id === shotId).positive, '(frontal camera view:1.3), (high-angle camera view:1.3)');
assert.equal(snapshot(game.scene).shots.find(s => s.id === shotId).negative, '');
assert.equal(savedSnapshots[game.scene], undefined, 'restoring default prompts is a draft until saved');
get('data-aip-camera-prompt', 'positive').props.onchange({ currentTarget: { value: 'custom pose' } });
get('data-aip-camera-remove', 'positive').props.onchange({ currentTarget: { value: 'old view' } });
assert.equal(snapshot(game.scene).removeTags, 'old view');
click('data-aip-camera-save', '');
assert.ok(get('data-aip-camera-shot', shotId), 'only explicit save adds the view to the saved list');
click('data-aip-camera-reset-prompt', '');
assert.equal(snapshot(game.scene).shots.find(s => s.id === shotId).positive, '(frontal camera view:1.3), (high-angle camera view:1.3)');
assert.equal(savedSnapshots[game.scene].shots.find(s => s.id === shotId).positive, 'custom pose', 'reset does not overwrite a saved custom prompt before explicit save');
get('data-aip-camera-prompt', 'positive').props.onchange({ currentTarget: { value: 'custom pose' } });
click('data-aip-camera-mode', 'random');
click('data-aip-camera-angle', 'side');
const sideId = snapshot(game.scene).shots.find(s => s.positive === 'from side, (high-angle camera view:1.3)').id;
assert.equal(get('data-aip-camera-shot', sideId), undefined, 'new random composition is not automatically saved');
assert.equal(get('data-aip-camera-add-random', ''), undefined, 'an unsaved composition cannot be added to random candidates');
assert.deepEqual(snapshot(game.scene).selected, [shotId], 'editing an unsaved view does not add it to random candidates');
click('data-aip-camera-save', '');
assert.ok(get('data-aip-camera-shot', sideId), 'saving adds the new composition to saved views');
assert.deepEqual(snapshot(game.scene).selected, [shotId], 'saving does not implicitly select the new random candidate');
click('data-aip-camera-shot', sideId);
assert.deepEqual(snapshot(game.scene).selected, [shotId, sideId], 'a saved view can be selected as a random candidate');
assert.ok(refreshes >= 5);
click('data-aip-camera-mode', 'single');
click('data-aip-camera-angle', 'pov_below');
assert.match(snapshot(game.scene).shots.find(s => s.id === snapshot(game.scene).selected[0]).positive, /from below/);
assert.doesNotMatch(snapshot(game.scene).shots.find(s => s.id === snapshot(game.scene).selected[0]).positive, /high-angle camera view/,
  'opposing elevation must be cleared');
const savedShots = snapshot(game.scene).shots.length;
click('data-aip-camera-save', '');
assert.equal(savedSnapshots[game.scene].shots.length, savedShots, 'save explicitly persists the current views');
assert.equal(snapshot(game.scene).dirty, false);
click('data-aip-camera-reset', '');
assert.equal(snapshot(game.scene).selected.length, 0);
assert.equal(snapshot(game.scene).shots.length, savedShots, 'restoring the original view must keep user shots');
assert.notEqual(savedSnapshots[game.scene].selected.length, 0, 'reset is temporary until saved');
click('data-aip-camera-angle', 'front');
for (const angle of ['pov', 'above', 'close_up', 'dutch', 'fisheye']) {
  click('data-aip-camera-angle', angle);
  assert.equal(get('data-aip-camera-angle', angle).props['aria-pressed'], 'true', `${angle} is selected`);
  click('data-aip-camera-angle', angle);
  assert.equal(get('data-aip-camera-angle', angle).props['aria-pressed'], 'false', `${angle} is deselected on repeat`);
  assert.equal(snapshot(game.scene).selected.length, 1, 'other axes remain applied');
}
click('data-aip-camera-angle', 'front');
assert.equal(snapshot(game.scene).selected.length, 0, 'deselecting the last axis restores the original view');
assert.equal(get('data-aip-camera-angle', 'front').props['aria-pressed'], 'false');
click('data-aip-camera-shot', shotId);
assert.equal(get('data-aip-camera-shot', shotId).props['aria-pressed'], 'true');
click('data-aip-camera-shot', shotId);
assert.equal(snapshot(game.scene).selected.length, 0, 'clicking the active shot restores the original view');
assert.equal(get('data-aip-camera-shot', shotId).props['aria-pressed'], 'false');
assert.notEqual(savedSnapshots[game.scene].selected.length, 0, 'repeated click changes remain temporary until saved');
click('data-aip-camera-mode', 'random');
click('data-aip-camera-shot', shotId);
click('data-aip-camera-shot', sideId);
click('data-aip-camera-shot', shotId);
assert.deepEqual(snapshot(game.scene).selected, [sideId], 'random shot toggling preserves other selections');
click('data-aip-camera-angle', 'side');
click('data-aip-camera-angle', 'above');
click('data-aip-camera-angle', 'side');
assert.deepEqual(snapshot(game.scene).selected, [sideId], 'clearing the random editor axes preserves selected candidates');
context.cameraUiGeneratePreview({ id: game.scene, characterId: 'pippa' }).then(() => {
  assert.equal(generatedRequests.length, 1);
  assert.equal(generatedRequests[0].prompt, 'base, front view');
  assert.equal(previewCalls.length, 0, 'the UI must not draw a second random shot');
  assert.ok(flatten(root).some(node => node.tag === 'img' && node.props.src === 'https://example.test/image.png'));
  const stale = get('data-aip-camera-angle', 'front');
  game = { ...game, scene: 'task-idle' };
  stale.props.onclick();
  assert.equal(snapshots['task-idle'], undefined, 'stale controls must not change a new scene');
  controller.set('task-idle', { shots: [{ id: 'front', name: '외부 프리셋', positive: 'custom', negative: 'custom negative' }], selected: ['front'], removeTags: '' });
  menu.onClick();
  click('data-aip-camera-reset-prompt', '');
  assert.equal(snapshot('task-idle').shots[0].positive, '(frontal camera view:1.3)', 'single preset ID from API restores its default');
  assert.equal(snapshot('task-idle').shots[0].negative, '');
  assert.equal(savedSnapshots['task-idle'].shots[0].positive, 'custom', 'single preset restore is not persisted until save');
  controller.set('task-idle', { shots: [{ id: 'external-custom', name: '외부 사용자 구도', positive: 'custom', negative: '' }], selected: ['external-custom'], removeTags: '' });
  menu.onClick();
  assert.equal(get('data-aip-camera-reset-prompt', '').props.disabled, true, 'custom IDs have no invented default');
  controller.set('task-idle', { shots: [
    { id: 'front', name: '정면', positive: 'front', negative: '' },
    { id: 'side', name: '측면', positive: 'side', negative: '' },
    { id: 'external-custom', name: '사용자 구도', positive: 'custom', negative: '' },
  ], selected: ['front', 'side'], removeTags: 'old view' });
  menu.onClick();
  assert.equal(get('data-aip-camera-delete-saved', 'front').props['aria-label'], '정면 구도 삭제');
  click('data-aip-camera-delete-saved', 'front');
  assert.equal(get('data-aip-camera-shot', 'front'), undefined, 'deleted saved shot disappears from the draft list');
  assert.deepEqual(snapshot('task-idle').selected, ['side'], 'deleting one random candidate preserves the other');
  assert.deepEqual(savedSnapshots['task-idle'].selected, ['front', 'side'], 'deletion is not persisted before save');
  click('data-aip-camera-save', '');
  assert.deepEqual(savedSnapshots['task-idle'].shots.map(shot => shot.id), ['side', 'external-custom']);
  assert.equal(savedSnapshots['task-idle'].removeTags, 'old view', 'unrelated settings are preserved');
  const staleDelete = get('data-aip-camera-delete-saved', 'side');
  game = { ...game, scene: 'scene-other' };
  staleDelete.props.onclick();
  assert.deepEqual(savedSnapshots['task-idle'].shots.map(shot => shot.id), ['side', 'external-custom'], 'stale delete cannot modify another scene');
  game = { ...game, scene: 'task-idle' };
  menu.onClick();
  click('data-aip-camera-delete-saved', 'side');
  assert.deepEqual(snapshot('task-idle').selected, [], 'deleting the last selected shot restores the original view');
  click('data-aip-camera-save', '');
  assert.deepEqual(savedSnapshots['task-idle'].shots.map(shot => shot.id), ['external-custom']);
  assert.equal(savedSnapshots['task-idle'].active, false);
  game = { ...game, scene: 'task-reading' };
  menu.onClick();
  click('data-aip-camera-angle', 'front');
  const unsavedId = snapshot('task-reading').selected[0];
  click('data-aip-camera-mode', 'random');
  assert.deepEqual(snapshot('task-reading').selected, [], 'switching from an unsaved single view does not select it for random');
  assert.equal(get('data-aip-camera-shot', unsavedId), undefined, 'unsaved views are absent from the saved random list');
  assert.equal(get('data-aip-camera-add-random', ''), undefined, 'no control adds an unsaved random candidate');
  click('data-aip-camera-save', '');
  assert.deepEqual(savedSnapshots['task-reading'].selected, [], 'saving a new view does not select it as a random candidate');
  click('data-aip-camera-shot', unsavedId);
  assert.deepEqual(snapshot('task-reading').selected, [unsavedId], 'saved view is selectable for random use');
  game = { ...game, scene: 'task-legacy' };
  controller.apply('task-legacy', { shots: [
    { id: 'legacy-a', name: '기존 A', positive: 'a', negative: '' },
    { id: 'legacy-b', name: '기존 B', positive: 'b', negative: '' },
  ], selected: ['legacy-a', 'legacy-b'], removeTags: '' });
  menu.onClick();
  assert.deepEqual(snapshot('task-legacy').selected, ['legacy-a', 'legacy-b'], 'opening the UI preserves a pre-existing API draft');
  assert.equal(get('data-aip-camera-shot', 'legacy-a'), undefined, 'unsaved API draft is not listed as saved');
  click('data-aip-camera-mode', 'random');
  assert.deepEqual(snapshot('task-legacy').selected, [], 'explicit random mode selection removes unsaved candidates');
  console.log('camera ui: ok');
}).catch(error => { console.error(error); process.exitCode = 1; });
