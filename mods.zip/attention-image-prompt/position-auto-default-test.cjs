const assert = require('node:assert/strict');
const { harness } = require('./position-controller-test.cjs');

async function main() {
  async function start({ enabled = true, owner = false, dual = false, selections = {}, initial = null } = {}) {
    const h = harness('2026-10-24-pre7');
    if (!dual) delete h.state.activeScene.patron;
    if (initial) h.state.activeScene.sex = initial;
    h.state.pendingEvent = initial ? { type: 'sex_scene', choices: [] } : null;
    h.husbandProviderPresent = owner; h.latest = null; h.activeKey = 'scene-sex'; h.selections = selections;
    const listeners = []; h.api.store.subscribe = callback => { listeners.push(callback); };
    const controller = h.make(); controller.setEnabled(enabled);
    return { h, controller, async change(fn) { fn(h.state); listeners.forEach(listener => listener()); await Promise.resolve(); } };
  }
  const sex = () => ({ type: 'sex', characterId: 'wife', startedAtSlot: 431,
    testPose: null, __hs: { her: { prep: 'ready:inside' } }, pleasure: 42 });
  for (const owner of [false, true]) for (const dual of [false, true]) {
    const t = await start({ owner, dual });
    const prior = structuredClone(t.h.state);
    await t.change(s => { s.activeScene.sex = sex(); s.pendingEvent = { type: 'sex_scene', choices: [] }; });
    assert.equal(t.controller.getPose()?.label, '정상위', `${owner}/${dual}: default pose selected`);
    assert.equal(t.h.state.activeScene.sex.pleasure, 42);
    if (dual) assert.deepEqual(t.h.state.activeScene.patron, prior.activeScene.patron);
    const count = t.h.calls.length + t.h.chooseCalls.length;
    await t.change(s => { s.slot++; });
    assert.equal(t.h.calls.length + t.h.chooseCalls.length, count, 'repeated updates never dispatch the action again');
    await t.change(s => { s.activeScene.sex.type = 'riding'; s.activeScene.sex.startedAtSlot = s.slot; });
    assert.equal(t.h.calls.length + t.h.chooseCalls.length, count,
      'changing act and start slot during an existing scene does not start another default');
  }
  {
    const t = await start({ enabled: false });
    await t.change(s => { s.activeScene.sex = sex(); s.pendingEvent = { type: 'sex_scene', choices: [] }; });
    t.controller.setEnabled(true);
    await t.change(s => { s.slot++; });
    assert.equal(t.controller.getPose(), null, 'turning on during an existing scene does not trigger a default');
  }
  {
    const t = await start({ initial: sex(), owner: true });
    await t.change(s => { s.slot++; });
    assert.equal(t.controller.getPose(), null, 'an already loaded scene is not treated as newly entered');
    assert.deepEqual(t.h.calls, []);
  }
  {
    const t = await start({ selections: { 'scene-sex': ['you-back'] } });
    await t.change(s => { s.activeScene.sex = sex(); s.pendingEvent = { type: 'sex_scene', choices: [] }; });
    assert.equal(t.controller.getPose(), null, 'explicit saved image pose is not overridden');
    assert.deepEqual(t.h.selections, { 'scene-sex': ['you-back'] });
  }
  {
    const t = await start({ owner: true });
    await t.change(s => { s.activeScene.sex = { ...sex(), testPose: '후배위' }; s.pendingEvent = { type: 'sex_scene', choices: [] }; });
    assert.equal(t.controller.getPose().label, '후배위', 'HL-owned pose takes priority');
    assert.deepEqual(t.h.calls, []);
  }
  {
    const t = await start({ owner: true });
    await t.change(s => { s.activeScene.sex = { ...sex(), type: 'mutual_touching' }; s.pendingEvent = { type: 'sex_scene', choices: [] }; });
    assert.equal(t.h.calls.length, 0);
    await t.change(s => { s.slot++; s.activeScene.sex.type = 'sex'; s.activeScene.sex.startedAtSlot = s.slot; });
    assert.equal(t.controller.getPose()?.label, '정상위', 'supported act after prelude is applied once');
  }
  {
    const t = await start({ owner: true }); t.h.routeMode = 'unlock';
    await t.change(s => { s.activeScene.sex = sex(); s.pendingEvent = { type: 'sex_scene', choices: [] }; });
    assert.equal(t.controller.getPose(), null);
    assert.deepEqual(t.h.calls, [], 'automatic action must not propose or bypass HL unlock checks');
    t.h.routeMode = 'fits';
    await t.change(s => { s.slot++; });
    assert.deepEqual(t.h.calls, [], 'a later unlock must not trigger an old scene-start action');
  }
  {
    const t = await start(); t.h.stateOnly = true;
    await t.change(s => { s.activeScene.sex = sex(); s.pendingEvent = { type: 'sex_scene', choices: [] }; });
    assert.equal(t.controller.getPose(), null, 'explicit state-only image prompt is preserved');
  }
  {
    const t = await start();
    let reads = 0;
    const get = t.h.api.settings.get;
    t.h.api.settings.get = defaults => { reads++; return get(defaults); };
    for (let i = 0; i < 100; i++) await t.change(() => {});
    assert.equal(reads, 0, 'idle store updates do not recalculate controller or image settings');
    await t.change(s => { s.activeScene.sex = sex(); s.pendingEvent = { type: 'sex_scene', choices: [] }; });
    reads = 0;
    for (let i = 0; i < 100; i++) await t.change(() => {});
    assert.equal(reads, 0, 'completed automatic actions do not cause repeated settings or portrait checks');
  }
  async function guest({ enabled = true, existingPose = null, asked = null, group = 'front', patronControl = false,
    apply = true, dual = false, override = null, imageDelayed = false } = {}) {
    const h = harness('2026-10-24-pre7');
    h.state.activeScene = {};
    h.latest.controllerSceneIdentity = JSON.stringify(['patron', 7, 431, null, 'wife', 'guest-1', null, null]);
    h.poseNow = { customerId: 'guest-1', group, pose: existingPose, asked, choices: ['정상위', '후배위'] };
    h.patronProviderPresent = patronControl; h.askResult = apply; h.override = override;
    if (imageDelayed) h.activeKey = 'scene-unrelated';
    const listeners = []; h.api.store.subscribe = callback => listeners.push(callback);
    const controller = h.make(); controller.setEnabled(enabled);
    async function change(fn) { fn(h.state); listeners.forEach(listener => listener()); await Promise.resolve(); }
    await change(state => { state.activeScene.patron = { customerId: 'guest-1', customerName: '손님',
      stage: 'sex_patron', startedAtSlot: 431, patronPleasure: 67 };
      if (dual) { state.activeScene.sex = sex(); state.pendingEvent = { type: 'sex_scene', choices: [] }; } });
    return { h, controller, change };
  }
  {
    const t = await guest();
    assert.deepEqual(t.h.asks, ['정상위']);
    assert.equal(t.h.state.slot, 432, 'guest pose request uses exactly one game minute');
    assert.equal(t.h.poseNow.pose, '정상위');
    await t.change(s => { s.slot++; });
    assert.equal(t.h.asks.length, 1, 'guest action cannot repeat on store updates');
  }
  {
    const t = await guest({ group: 'back' });
    assert.deepEqual(t.h.asks, ['후배위'], 'anal group uses the expansion default');
    assert.equal(t.h.state.slot, 432);
  }
  for (const options of [{ existingPose: '후배위' }, { asked: '후배위' }, { group: 'rub' },
    { patronControl: true }, { dual: true }, { override: { manual: true } }, { enabled: false }]) {
    const t = await guest(options);
    assert.deepEqual(t.h.asks, [], `guest safety guard ${JSON.stringify(options)}`);
  }
  {
    const t = await guest({ apply: false });
    assert.deepEqual(t.h.asks, ['정상위']);
    await t.change(s => { s.slot++; });
    assert.equal(t.h.asks.length, 1, 'a rejected request is never repeated');
    assert.equal(t.h.calls.length, 0, 'a rejected request does not advance time');
  }
  {
    const realNow = Date.now, realSetTimeout = global.setTimeout, realClearTimeout = global.clearTimeout;
    let now = 10000, nextId = 1;
    const timers = new Map();
    Date.now = () => now;
    global.setTimeout = (fn, delay) => { const id = nextId++; timers.set(id, { fn, at: now + delay }); return id; };
    global.clearTimeout = id => timers.delete(id);
    const tick = async ms => {
      now += ms;
      for (const [id, timer] of [...timers]) if (timer.at <= now) { timers.delete(id); timer.fn(); }
      await Promise.resolve();
    };
    try {
      const waitingPlayer = await start();
      await waitingPlayer.change(s => { s.activeScene.sex = sex(); s.pendingEvent = null; });
      await tick(2100);
      await waitingPlayer.change(s => { s.pendingEvent = { type: 'sex_scene', choices: [] }; });
      assert.equal(waitingPlayer.controller.getPose(), null, 'a late player event cannot revive an old start request');

      const t = await guest({ imageDelayed: true });
      assert.equal(timers.size, 1, 'one retry timer is installed');
      for (let i = 0; i < 30; i++) await t.change(() => {});
      assert.equal(timers.size, 1, 'repeated store events do not schedule duplicate timers');
      for (let i = 0; i < 4; i++) await tick(250);
      assert.equal(timers.size, 1, 'the full retry window remains after one second');
      t.h.activeKey = null;
      await t.change(() => {});
      assert.deepEqual(t.h.asks, ['정상위'], 'a late portrait can trigger the pending action');
      assert.equal(timers.size, 0, 'successful action cancels the outstanding timer');

      const expired = await guest({ imageDelayed: true });
      for (let i = 0; i < 8; i++) await tick(250);
      assert.equal(timers.size, 0, 'deadline stops retrying after two seconds');
      expired.h.activeKey = null;
      await expired.change(() => {});
      assert.deepEqual(expired.h.asks, [], 'a portrait after the deadline cannot revive the old request');

      const ended = await guest({ imageDelayed: true });
      assert.equal(timers.size, 1);
      await ended.change(s => { delete s.activeScene.patron; });
      assert.equal(timers.size, 0, 'scene exit cancels the pending timer');

      const disabled = await guest({ imageDelayed: true });
      disabled.controller.setEnabled(false);
      assert.equal(timers.size, 0, 'turning off the console immediately cancels the pending timer');
      disabled.controller.setEnabled(true);
      disabled.h.activeKey = null;
      await disabled.change(() => {});
      assert.deepEqual(disabled.h.asks, [], 'toggling on again does not revive the canceled request');
    } finally {
      Date.now = realNow; global.setTimeout = realSetTimeout; global.clearTimeout = realClearTimeout;
    }
  }
  console.log('automatic representative pose: ok');
}
main().catch(error => { console.error(error); process.exitCode = 1; });
