const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, 'source/portrait-fresh-variants.js'), 'utf8');
const modSource = fs.readFileSync(path.join(__dirname, 'source/mod.wml.js'), 'utf8');
const promptSource = fs.readFileSync(path.join(__dirname, 'source/prompt-mod-rules.js'), 'utf8');
const dedupSource = promptSource.match(/function splitFinalPrompt\([\s\S]*?(?=    function withoutPromptTags\()/);
assert.ok(dedupSource, 'final request deduplication helper should exist');
const deduplicateFinalRequest = new Function(`${dedupSource[0]}; return deduplicateFinalRequest;`)();
const forwardSource = modSource.match(/const forward = async forwarded => \{[\s\S]*?\n          \};/);
assert.ok(forwardSource, 'fresh forwarding path should exist');
const cleanupSource = modSource.match(/if \(result\?\.url[^\n]+nativeFreshVariantKeys\.delete\(trace\.key\);/);
assert.ok(cleanupSource, 'fresh marker cleanup path should exist');
const cleanup = new Function('result', 'trace', 'nativeFreshVariantKeys', cleanupSource[0]);
const createForward = new Function('next', 'nativeFresh', 'nativeFreshKey', 'nativeFreshVariantKeys',
  'beginImageRequestTrace', 'args', 'trace', 'imageRequestObserver', 'api', 'deduplicateFinalRequest', `${forwardSource[0]}; return forward;`);
const base = 'wife__scene-sex';
const variant = n => `${base}__v-${n}`;

function harness() {
  const hooks = {};
  const nativeFreshVariantKeys = new Set();
  let entries = {}, local = {}, unused = {}, choice = null, variants = [base, variant(4)];
  let manifestError = null, manifestValue, lookupOverride = null;
  const warnings = [];
  const api = {
    hook: (name, spec) => { hooks[name] = spec; },
    has: name => ['imageManifest', 'imageManifestReset'].includes(name),
    fn: name => name === 'imageManifestReset' ? () => {} : async () => {
      if (manifestError) throw manifestError;
      return manifestValue !== undefined ? manifestValue : { entries };
    },
  };
  const compact = key => `compact:${key}`;
  const module = new Function('api', 'nativeFreshVariantKeys', 'similarImageSituationKey',
    'similarImageChoice', 'portraitImageVariants', 'unusedPortraitImages', 'localGeneratedEntries',
    'compactGenerationKey', 'USER_VARIANT_START', 'similarImageLookupOverride', 'imageEntryExists', 'imageEntryUrl',
    'window', 'console', `${source}; return { portraitFreshVariantKey, portraitFreshReservations };`)(
    api, nativeFreshVariantKeys, key => key.replace(/__v-\d+$/, ''), () => choice,
    () => ({ variants }), () => unused, async () => local, compact, 4, () => lookupOverride,
    async entry => entry.exists !== false, entry => entry.imagePath ? `image:${entry.imagePath}` : '',
    { alert: message => warnings.push(message) }, { warn() {} });
  const backendRequests = [];
  const studioRequests = [];
  let backend = async request => ({ url: `generated:${request.imageKey}`, key: request.imageKey, fresh: true });
  const studio = async request => {
    studioRequests.push({ ...request });
    if (!request.bypassCache) return { url: 'old-image', key: request.imageKey, fresh: false };
    const next = async forwarded => { backendRequests.push({ ...forwarded }); return backend(forwarded); };
    const forward = createForward(next, nativeFreshVariantKeys.has(request.imageKey), request.imageKey,
      nativeFreshVariantKeys, () => () => {}, [], { key: request.imageKey }, null, api, deduplicateFinalRequest);
    const result = await forward(request);
    cleanup(result, { key: request.imageKey }, nativeFreshVariantKeys);
    return result;
  };
  return { hooks, module, nativeFreshVariantKeys, backendRequests, studioRequests, warnings, studio,
    set entries(v) { entries = v; }, set local(v) { local = v; }, set unused(v) { unused = v; },
    set choice(v) { choice = v; }, set variants(v) { variants = v; }, set backend(v) { backend = v; },
    set manifestError(v) { manifestError = v; }, set manifestValue(v) { manifestValue = v; },
    set lookupOverride(v) { lookupOverride = v; } };
}

async function run() {
  {
    const h = harness();
    h.entries = { [variant(4)]: {}, [`compact:${variant(5)}`]: {} };
    h.unused = { [base]: [variant(6)] };
    h.choice = { manualVariants: { [variant(7)]: 'other-image' }, autoVariants: [] };
    h.nativeFreshVariantKeys.add(variant(4));
    const out = await h.hooks.imageGenerate.around(h.studio, { imageKey: variant(4),
      prompt: 'hetero, hetero', negativePrompt: 'bad, bad' });
    assert.equal(out.key, variant(8), 'server, compact, unused and manual variants must be skipped');
    assert.equal(out.fresh, true);
    assert.equal(h.studioRequests[0].bypassCache, true, 'ImageStudio must bypass similar-image matching');
    assert.equal(h.backendRequests[0].bypassCache, false, 'server must not destructively bypass cache');
    assert.equal(h.backendRequests[0].prompt, 'hetero');
    assert.equal(h.backendRequests[0].negativePrompt, 'bad');
    assert.equal(h.nativeFreshVariantKeys.has(variant(4)), false);
    assert.equal(h.module.portraitFreshReservations.size, 0);
  }
  {
    const h = harness();
    h.nativeFreshVariantKeys.add(variant(4));
    let count = 0;
    h.backend = async request => ({ url: `image:${request.imageKey}`, fresh: ++count > 1 });
    const out = await h.hooks.imageGenerate.around(h.studio, { imageKey: variant(4) });
    assert.equal(out.key, variant(5), 'cached response should retry a different key');
    assert.equal(h.backendRequests.length, 2);
    assert.ok(h.backendRequests.every(request => request.bypassCache === false));
  }
  {
    const h = harness();
    h.nativeFreshVariantKeys.add(variant(4));
    h.backend = async () => null;
    assert.equal(await h.hooks.imageGenerate.around(h.studio, { imageKey: variant(4) }), null);
    assert.equal(h.nativeFreshVariantKeys.has(variant(4)), true, 'failed request must remain eligible for retry');
    assert.equal(h.module.portraitFreshReservations.size, 0);
    let lookupCalled = false;
    assert.equal(await h.hooks.imageLookup.around(async () => { lookupCalled = true; return { imagePath: 'old.png' }; }, variant(4)), null);
    assert.equal(lookupCalled, false, 'failed fresh slot must not fall back to an old picture');
  }
  {
    const h = harness();
    h.nativeFreshVariantKeys.add(variant(4));
    let count = 0;
    h.backend = async () => ++count === 1 ? { url: 'cached', fresh: false } : null;
    assert.equal(await h.hooks.imageGenerate.around(h.studio, { imageKey: variant(4) }), null);
    assert.equal(h.nativeFreshVariantKeys.has(variant(4)), true,
      'a failed retry after a cache hit must remain eligible for retry');
  }
  {
    const h = harness();
    h.nativeFreshVariantKeys.add(variant(4));
    h.backend = async () => ({ url: 'unknown-result' });
    assert.equal(await h.hooks.imageGenerate.around(h.studio, { imageKey: variant(4) }), null,
      'a URL with unknown freshness must not be claimed as new generation');
  }
  {
    const h = harness();
    h.nativeFreshVariantKeys.add(variant(4));
    h.backend = async () => ({ url: 'cached-image', fresh: false });
    assert.equal(await h.hooks.imageGenerate.around(h.studio, { imageKey: variant(4) }), null);
    assert.equal(h.backendRequests.length, 8, 'cached aliases should not loop indefinitely');
    assert.equal(h.nativeFreshVariantKeys.has(variant(4)), true, 'exhausted retries must retain original marker');
    assert.equal(h.module.portraitFreshReservations.size, 0);
  }
  {
    const h = harness();
    h.variants = [base, variant(4), variant(5)];
    h.entries = { [`compact:${variant(4)}`]: { imagePath: 'stored-4.png', talentName: `compact:${variant(4)}` } };
    let calls = 0;
    const next = async () => { calls++; return { talentName: 'nearest', imagePath: 'nearest.png' }; };
    const exact = await h.hooks.imageLookup.around(next, variant(4));
    assert.equal(exact.imagePath, 'stored-4.png');
    assert.equal(exact.talentName, variant(4));
    assert.equal(calls, 0, 'selected variant must use exact full or compact key');
    assert.equal(await h.hooks.imageLookup.around(next, variant(5)), null, 'missing selected variant must not use nearest');
    assert.equal((await h.hooks.imageLookup.around(next, variant(9))).talentName, 'nearest', 'non-selected lookup is unchanged');
    h.lookupOverride = { key: 'manual-image' };
    assert.equal((await h.hooks.imageLookup.around(next, variant(5))).talentName, 'nearest', 'manual mapping is preserved');
  }
  {
    const h = harness();
    h.variants = [variant(0), variant(4)];
    h.entries = { [variant(0)]: { imagePath: 'original-0.png', talentName: variant(0) } };
    let calls = 0;
    const next = async () => { calls++; return { talentName: 'nearest', imagePath: 'nearest.png' }; };
    const original = await h.hooks.imageLookup.around(next, variant(0));
    assert.equal(original.imagePath, 'original-0.png', 'the original variant should prefer its exact image');
    assert.equal(calls, 0, 'ImageStudio matching should not replace an exact original');
    h.entries = {};
    assert.equal((await h.hooks.imageLookup.around(next, variant(0))).talentName, 'nearest',
      'an original without an exact entry should retain the normal lookup fallback');
    h.entries = { [variant(0)]: { imagePath: 'original-0.png', talentName: variant(0) } };
    h.lookupOverride = { key: 'manual-image' };
    assert.equal((await h.hooks.imageLookup.around(next, variant(0))).talentName, 'nearest',
      'the user manual mapping must take precedence over an exact original');
    h.lookupOverride = null;
    h.variants = [variant(0)];
    assert.equal((await h.hooks.imageLookup.around(next, variant(0))).talentName, 'nearest',
      'an unchanged list should keep its existing matching behavior');
  }
  {
    const h = harness();
    h.variants = [variant(0), variant(5)];
    h.entries = {
      [variant(0)]: { imagePath: 'original-0.png', talentName: variant(0) },
      [`compact:${variant(5)}`]: { imagePath: 'added-5.png', talentName: `compact:${variant(5)}` },
    };
    let calls = 0;
    const next = async request => { calls++; return { url: 'studio-picked', fresh: false, key: request.imageKey }; };
    const previous = await h.hooks.imageGenerate.around(next, { imageKey: variant(0) });
    const following = await h.hooks.imageGenerate.around(next, { imageKey: variant(5) });
    assert.deepEqual(previous, { url: 'image:original-0.png', fresh: false, key: variant(0) });
    assert.deepEqual(following, { url: 'image:added-5.png', fresh: false, key: variant(5) });
    assert.equal(calls, 0, 'navigation to an existing variant must not redraw from ImageStudio');
    h.entries = {};
    assert.equal((await h.hooks.imageGenerate.around(next, { imageKey: variant(0) })).url, 'studio-picked',
      'original without an exact entry should fall back to existing ImageStudio lookup');
    assert.equal(await h.hooks.imageGenerate.around(next, { imageKey: variant(5) }), null,
      'added variant without an exact entry must not show a different image');
    assert.equal((await h.hooks.imageGenerate.around(next, { imageKey: variant(5), bulk: true })).url, 'studio-picked',
      'bulk generation must be allowed when the selected variant has no exact entry');
    assert.equal((await h.hooks.imageGenerate.around(next, { imageKey: variant(5), debug: { source: 'another-mod' } })).url, 'studio-picked',
      'other mods should retain their explicit generation path');
    h.entries = { [variant(0)]: { imagePath: 'original-0.png', talentName: variant(0) } };
    h.lookupOverride = { key: 'manual-image' };
    assert.equal((await h.hooks.imageGenerate.around(next, { imageKey: variant(0) })).url, 'studio-picked',
      'a user-selected mapping must retain precedence over exact original');
    h.lookupOverride = null;
    assert.equal((await h.hooks.imageGenerate.around(next, { imageKey: variant(0), bypassCache: true })).url, 'studio-picked',
      'explicit regenerate must bypass exact-image reuse');
  }
  {
    const h = harness();
    h.nativeFreshVariantKeys.add(variant(4));
    let release;
    const gate = new Promise(resolve => { release = resolve; });
    h.backend = async request => { await gate; return { url: `new:${request.imageKey}`, fresh: true }; };
    const a = h.hooks.imageGenerate.around(h.studio, { imageKey: variant(4) });
    const b = h.hooks.imageGenerate.around(h.studio, { imageKey: variant(4) });
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(h.module.portraitFreshReservations.size, 2, 'simultaneous requests must reserve distinct variants');
    release();
    const both = await Promise.all([a, b]);
    assert.equal(new Set(both.map(result => result.key)).size, 2);
    assert.equal(h.module.portraitFreshReservations.size, 0);
  }
  {
    const h = harness();
    h.nativeFreshVariantKeys.add(variant(4));
    h.manifestError = new Error('manifest offline');
    assert.equal(await h.hooks.imageGenerate.around(h.studio, { imageKey: variant(4) }), null);
    assert.equal(h.backendRequests.length, 0, 'failed manifest lookup must not start generation');
    assert.equal(h.nativeFreshVariantKeys.has(variant(4)), true);
    assert.equal(h.warnings.length, 1);
  }
  {
    const h = harness();
    h.nativeFreshVariantKeys.add(variant(4));
    h.manifestValue = null;
    const out = await h.hooks.imageGenerate.around(h.studio, { imageKey: variant(4) });
    const number = Number(out?.key?.match(/__v-(\d+)$/)?.[1]);
    assert.ok(Number.isSafeInteger(number) && number > 1000000,
      'an unavailable manifest requires a high, safe-integer variant');
    assert.equal(h.backendRequests[0].bypassCache, false, 'server cache must remain protected');
  }
  console.log('portrait fresh variants: ok');
}

run().catch(error => { console.error(error); process.exitCode = 1; });
