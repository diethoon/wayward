const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const source = fs.readFileSync(require('node:path').join(__dirname, 'source/current-state-editor.js'), 'utf8');
let state = { primaryCharacterId: 'wife', characters: { wife: { id: 'wife' } }, slot: 1 };
let imageKey = 'wife__scene-chatting__v-0';
let provider = new Map();
const externalProvider = { key: 'foreign/energy', id: 'foreign', entryId: 'energy', title: '외부 제공자' };
const foreignSettings = { value: '외부 모드 원본 설정' };
let providerValues = { positivePrompt: 'mod positive', negativePrompt: 'mod negative' }, providerNotifications = 0;
let gameReads = 0, providerReads = 0, contextCalls = 0, refreshes = 0, probeActive = true;
const settingsWrites = [];
let settingsObserver = null, rejectSettingsWrite = false;
const assigned = { id: 'assigned', name: '아내용', prompts: { 'status.energy.1': 'tired', 'restraint.handcuffed': 'cuffs' },
  negativePrompts: { 'status.energy.1': 'vigorous', 'restraint.handcuffed': '' } };
const other = { id: 'other', name: '다른 것', prompts: { 'status.energy.1': 'other' }, negativePrompts: {} };
const storage = { situationPresets: [assigned, other], sceneStatePromptOverrides: {} };
let currentPreset = 'assigned';
const fields = [
  { key: 'status.energy.1', label: '기력 낮음' }, { key: 'restraint.handcuffed', label: '수갑' },
  { key: 'cycle.vulva.menstrual', label: '생리' }, { key: 'fluid.vulva.1', label: '음부 상태' },
  { key: 'hstatus.hypnosis.2', label: '최면 2단계' }, { key: 'erostat.anal.full', label: '애널 수용' },
];
const api = {
  settings: { get: defaults => ({ ...defaults, ...storage }), set: patch => {
    if (rejectSettingsWrite) throw new Error('settings unavailable');
    settingsWrites.push(patch); Object.assign(storage, patch); settingsObserver?.();
  } },
  store: { game: () => { gameReads++; return state; } },
  ui: { button: (label, action) => ({ tag: 'button', props: { label, action }, children: [] }) },
};
const h = (tag, props, ...children) => ({ tag, props: props || {}, children: children.flat().filter(Boolean) });
const groups = () => ({
  positiveGroups: [{ id: 'detail', label: '상세 상태', value: { codes: ['energy-1', 'feeling-shame'], tags: ['tired', 'worried'] } },
    { id: 'attention', label: '대응 필요 상황', value: { codes: ['handcuffed'], tags: ['cuffs'] } }],
  negativeGroups: [{ id: 'detail', label: '상세 상태', value: { codes: ['energy-1'], tags: ['vigorous'] } }],
});
const context = {
  api, FIELD_GROUPS: [{ fields }], LEGACY_SITUATION_PRESET_ID: 'default', activeSituationPresetId: 'other',
  promptTagPreview: (h, value) => h('span', { 'data-test-tag-preview': value }),
  updatePromptTagPreview: () => {},
  currentSituationPresets: () => storage.situationPresets,
  situationConfigForCharacter: () => storage.situationPresets.find(item => item.id === currentPreset) || null,
  positionSituationId: key => String(key || '').split('__').find(value => /^(scene|task|look)-/.test(value)) || '',
  activePortraitImageKey: () => imageKey,
  baseSituationImageKey: key => key,
  externalFieldProviders: () => { providerReads++; return provider; },
  externalPromptsForField: (prompts, field) => provider.has('status.energy.1')
    ? { ...prompts, 'status.energy.1': providerValues[field] } : prompts,
  saveExternalPrompt: (owner, entry, source, changes) => {
    assert.equal(owner, 'foreign'); assert.equal(entry, 'energy'); assert.equal(source, 'mod');
    providerValues = { ...providerValues, ...changes };
    api.settings.set({ externalPromptData: [{ owner, id: entry, source, ...providerValues }] });
    providerNotifications++; return true;
  },
  promptContext: () => { contextCalls++; return groups(); },
  cleanPrompt: value => typeof value === 'string' ? value.trim() : '',
  promptGroups: (state, character, characterId, prompts) => probeActive && prompts['status.energy.1']
    ? [{ id: 'detail', label: '상세 상태', value: { codes: ['energy-1'], tags: [prompts['status.energy.1']] } }] : [],
  notifyExternalPromptChange: () => {}, refreshPortraitImage: () => { refreshes++; }, settingsMessage: '',
  shortHash: text => require('node:crypto').createHash('sha256').update(text).digest('hex').slice(0, 12),
};
const helpers = vm.runInNewContext(`${source}\n({ normalizeSceneStatePromptOverrides, currentSceneStatePromptOverrides, reloadSceneStatePromptOverrides,
  normalizeStateEditorGlobalChanges, currentStateEditorGlobalChanges, reloadStateEditorGlobalChanges, stateEditorHasGlobalChanges, stateEditorGlobalProbePrompts, stateEditorGlobalFingerprint,
  effectiveSceneStatePrompts, sceneStatePromptFingerprint, stateEditorFieldKey, stateEditorContext, saveCurrentStateEditorPrompt,
  resetCurrentSceneStatePrompt, renderCurrentStateEditor })`, context);
const plain = value => JSON.parse(JSON.stringify(value));
const nodes = node => !node || typeof node !== 'object' ? [] : [node, ...(node.children || []).flatMap(nodes)];
const by = (tree, attr) => nodes(tree).find(node => Object.hasOwn(node.props, attr));
const before = { 'status.energy.1': 'tired', 'restraint.handcuffed': 'cuffs' };
const scene = 'scene-chatting';
const snap = helpers.stateEditorContext(scene);
assert.deepEqual(plain(snap.fields), ['status.energy.1', 'restraint.handcuffed']);
assert.deepEqual(plain(snap.unsupported), ['상세 상태']);
assert.equal(helpers.stateEditorFieldKey('cycle', 'cycle-vulva-menstrual'), 'cycle.vulva.menstrual');
assert.equal(helpers.stateEditorFieldKey('body-vulva', 'vulva-1'), 'fluid.vulva.1');
assert.equal(helpers.stateEditorFieldKey('hypnosis', 'hstatus-hypnosis-2-hash'), 'hstatus.hypnosis.2');
assert.equal(helpers.stateEditorFieldKey('erostat', 'erostat-anal-full-hash'), 'erostat.anal.full');
assert.equal(helpers.stateEditorFieldKey('detail', 'feeling-shame'), '', 'map entries are not guessed');

const idleProviders = providerReads;
assert.equal(helpers.effectiveSceneStatePrompts(before, scene, 'positivePrompt'), before);
assert.equal(helpers.sceneStatePromptFingerprint(scene), '');
assert.equal(providerReads, idleProviders, 'an unconfigured scene does not read providers');
const oldWrites = settingsWrites.length;
assert.equal(helpers.saveCurrentStateEditorPrompt(snap, scene, 'status.energy.1', 'positivePrompt', 'tired', 'global'), true);
assert.equal(settingsWrites.length, oldWrites, 'saving the unchanged global value does not create a marker');
assert.equal(helpers.saveCurrentStateEditorPrompt(snap, scene, 'status.energy.1', 'positivePrompt', 'edited', 'scene'), true);
assert.equal(storage.situationPresets[0].prompts['status.energy.1'], 'tired', 'scene edit preserves assigned preset');
assert.equal(helpers.effectiveSceneStatePrompts(before, scene, 'positivePrompt')['status.energy.1'], 'edited');
assert.equal(helpers.effectiveSceneStatePrompts(before, 'scene-other', 'positivePrompt'), before);
const fingerprint = helpers.sceneStatePromptFingerprint(scene);
assert.ok(fingerprint);
assert.equal(helpers.saveCurrentStateEditorPrompt(snap, scene, 'status.energy.1', 'negativePrompt', '', 'scene'), true);
assert.equal(helpers.effectiveSceneStatePrompts({ 'status.energy.1': 'vigorous' }, scene, 'negativePrompt')['status.energy.1'], '', 'blank override is retained');
assert.notEqual(helpers.sceneStatePromptFingerprint(scene), fingerprint);
settingsObserver = () => assert.ok(helpers.stateEditorGlobalFingerprint(storage.situationPresets[0], groups(), 'scene-other'),
  'synchronous settings observers see the new global marker');
assert.equal(helpers.saveCurrentStateEditorPrompt(snap, scene, 'status.energy.1', 'positivePrompt', 'global edit', 'global'), true);
settingsObserver = null;
assert.ok(settingsWrites.at(-1).situationPresets && settingsWrites.at(-1).stateEditorGlobalChanges, 'preset and marker are saved atomically');
assert.deepEqual(plain(storage.stateEditorGlobalChanges), { assigned: ['status.energy.1'] });
rejectSettingsWrite = true;
assert.throws(() => helpers.saveCurrentStateEditorPrompt(snap, scene, 'restraint.handcuffed', 'positivePrompt', 'blocked', 'global'));
rejectSettingsWrite = false;
assert.deepEqual(plain(helpers.currentStateEditorGlobalChanges()), { assigned: ['status.energy.1'] }, 'failed settings write rolls back the marker cache');
assert.equal(storage.situationPresets.find(item => item.id === 'assigned').prompts['status.energy.1'], 'global edit');
assert.equal(storage.situationPresets.find(item => item.id === 'other').prompts['status.energy.1'], 'other', 'selected UI preset is never altered');
assert.equal(helpers.effectiveSceneStatePrompts({ 'status.energy.1': 'global edit' }, scene, 'positivePrompt')['status.energy.1'], 'edited');
provider = new Map([['status.energy.1', externalProvider]]);
assert.equal(helpers.effectiveSceneStatePrompts(before, scene, 'positivePrompt')['status.energy.1'], 'edited', 'scene override takes priority over provider');
assert.ok(helpers.sceneStatePromptFingerprint(scene), 'scene override remains part of the key with a provider');
assert.equal(helpers.saveCurrentStateEditorPrompt(snap, scene, 'status.energy.1', 'positivePrompt', 'stale provider', 'global'), false,
  'a provider enabled since the UI snapshot cannot be edited using stale ownership');
assert.equal(helpers.resetCurrentSceneStatePrompt(snap, scene, 'status.energy.1'), false);
const providerSnapshot = helpers.stateEditorContext(scene);
assert.equal(helpers.saveCurrentStateEditorPrompt(providerSnapshot, scene, 'status.energy.1', 'positivePrompt', 'mod edited', 'global'), true);
assert.equal(providerValues.positivePrompt, 'mod edited');
assert.equal(providerNotifications, 1, 'provider API notifies after saving');
assert.equal(storage.externalPromptData[0].positivePrompt, 'mod edited', 'provider edit is stored in AIP settings');
assert.equal(storage.situationPresets.find(item => item.id === 'assigned').prompts['status.energy.1'], 'global edit', 'provider edit preserves AIP preset');
assert.deepEqual(foreignSettings, { value: '외부 모드 원본 설정' }, 'other mod settings remain untouched');
assert.equal(helpers.saveCurrentStateEditorPrompt(providerSnapshot, scene, 'status.energy.1', 'negativePrompt', '', 'global'), true);
assert.equal(providerValues.negativePrompt, '', 'provider supports explicitly empty negative');
const providerFingerprint = helpers.sceneStatePromptFingerprint(scene);
assert.equal(helpers.saveCurrentStateEditorPrompt(providerSnapshot, scene, 'status.energy.1', 'positivePrompt', 'scene provider edit', 'scene'), true);
assert.equal(helpers.saveCurrentStateEditorPrompt(providerSnapshot, scene, 'status.energy.1', 'negativePrompt', '', 'scene'), true);
assert.notEqual(helpers.sceneStatePromptFingerprint(scene), providerFingerprint, 'provider scene edits change the scene key token');
assert.equal(helpers.effectiveSceneStatePrompts({ 'status.energy.1': providerValues.positivePrompt }, scene, 'positivePrompt')['status.energy.1'], 'scene provider edit');
assert.equal(helpers.effectiveSceneStatePrompts({ 'status.energy.1': providerValues.positivePrompt }, 'scene-other', 'positivePrompt')['status.energy.1'], 'mod edited');
assert.equal(providerValues.positivePrompt, 'mod edited', 'scene edits do not change provider content');
const providerSceneBeforeFailure = helpers.sceneStatePromptFingerprint(scene);
rejectSettingsWrite = true;
assert.throws(() => helpers.saveCurrentStateEditorPrompt(providerSnapshot, scene, 'status.energy.1', 'positivePrompt', 'not saved', 'scene'));
assert.throws(() => helpers.resetCurrentSceneStatePrompt(providerSnapshot, scene, 'status.energy.1'));
rejectSettingsWrite = false;
assert.equal(helpers.sceneStatePromptFingerprint(scene), providerSceneBeforeFailure, 'failed scene edit and reset roll back cache');
assert.equal(helpers.effectiveSceneStatePrompts(before, scene, 'positivePrompt')['status.energy.1'], 'scene provider edit');
provider = new Map([['status.energy.1', { ...externalProvider, key: 'another/energy', id: 'another' }]]);
assert.equal(helpers.saveCurrentStateEditorPrompt(providerSnapshot, scene, 'status.energy.1', 'positivePrompt', 'wrong provider', 'global'), false);
assert.equal(helpers.resetCurrentSceneStatePrompt(providerSnapshot, scene, 'status.energy.1'), false, 'provider replacement rejects stale reset');
provider = new Map([['status.energy.1', externalProvider]]);
assert.equal(helpers.resetCurrentSceneStatePrompt(providerSnapshot, scene, 'status.energy.1'), true);
assert.equal(helpers.effectiveSceneStatePrompts({ 'status.energy.1': providerValues.positivePrompt }, scene, 'positivePrompt')['status.energy.1'], 'mod edited', 'reset returns to provider output');
assert.equal(helpers.sceneStatePromptFingerprint(scene), '');
assert.equal(helpers.saveCurrentStateEditorPrompt(providerSnapshot, scene, 'status.energy.1', 'positivePrompt', 'persist after disabling', 'scene'), true);
provider = new Map();
assert.equal(helpers.effectiveSceneStatePrompts(before, scene, 'positivePrompt')['status.energy.1'], 'persist after disabling', 'scene edit remains if provider is disabled');
const disabledProviderSnapshot = helpers.stateEditorContext(scene);
assert.equal(helpers.resetCurrentSceneStatePrompt(disabledProviderSnapshot, scene, 'status.energy.1'), true);
assert.equal(helpers.sceneStatePromptFingerprint(scene), '');
assert.equal(helpers.resetCurrentSceneStatePrompt(snap, scene, 'status.energy.1'), false);
const currentConfig = storage.situationPresets.find(item => item.id === 'assigned');
const globalMark = helpers.stateEditorGlobalFingerprint(currentConfig, groups(), scene);
assert.ok(globalMark, 'active field edited globally gains a signature');
assert.equal(helpers.stateEditorGlobalFingerprint(storage.situationPresets.find(item => item.id === 'other'), groups(), scene), '', 'other preset is not affected');
assert.equal(helpers.stateEditorGlobalFingerprint(currentConfig, { positiveGroups: [], negativeGroups: [] }, scene), '', 'inactive fields do not change keys');
const changedOutside = { ...currentConfig, prompts: { ...currentConfig.prompts, 'status.energy.1': 'changed elsewhere' } };
assert.notEqual(helpers.stateEditorGlobalFingerprint(changedOutside, groups(), scene), globalMark, 'actual values are hashed even if changed through another editor');
assert.equal(helpers.saveCurrentStateEditorPrompt(snap, scene, 'status.energy.1', 'negativePrompt', 'different negative', 'global'), true);
const withNegative = storage.situationPresets.find(item => item.id === 'assigned');
assert.notEqual(helpers.stateEditorGlobalFingerprint(withNegative, groups(), scene), globalMark, 'negative edits change the signature');
assert.equal(helpers.stateEditorGlobalProbePrompts(withNegative, 'positivePrompt'), null, 'nonempty values need no synthetic probe');
assert.equal(helpers.stateEditorGlobalProbePrompts(withNegative, 'negativePrompt'), null, 'nonempty negatives need no synthetic probe');
const emptyConfig = { ...withNegative, prompts: { ...withNegative.prompts, 'status.energy.1': '' },
  negativePrompts: { ...withNegative.negativePrompts, 'status.energy.1': '' } };
assert.equal(helpers.stateEditorGlobalProbePrompts(emptyConfig, 'positivePrompt')['status.energy.1'], 'aip_state_probe');
assert.equal(helpers.stateEditorGlobalProbePrompts(emptyConfig, 'negativePrompt')['status.energy.1'], 'aip_state_probe');
assert.ok(helpers.stateEditorGlobalFingerprint(emptyConfig, groups(), scene), 'cleared values can still receive a signature when the probe finds their active condition');
assert.equal(helpers.stateEditorGlobalProbePrompts(storage.situationPresets.find(item => item.id === 'other'), 'positivePrompt'), null, 'unmarked presets skip probe work');
assert.equal(helpers.stateEditorHasGlobalChanges(withNegative), true);
assert.equal(helpers.stateEditorHasGlobalChanges(storage.situationPresets.find(item => item.id === 'other')), false);
provider = new Map([['status.energy.1', externalProvider]]);
assert.equal(helpers.stateEditorGlobalFingerprint(withNegative, groups(), scene), '', 'external provider is excluded');
provider = new Map();
helpers.reloadStateEditorGlobalChanges();
assert.equal(helpers.stateEditorGlobalFingerprint(withNegative, groups(), scene), helpers.stateEditorGlobalFingerprint(withNegative, groups(), scene), 'markers survive reload');
assert.deepEqual(plain(helpers.normalizeStateEditorGlobalChanges({ assigned: ['status.energy.1', 'status.energy.1', 'missing'], 'bad/id': ['status.energy.1'] })),
  { assigned: ['status.energy.1'] });

assert.deepEqual(plain(helpers.normalizeSceneStatePromptOverrides({
  'scene-chatting': { 'status.energy.1': { positivePrompt: '', negativePrompt: 'x' }, missing: { positivePrompt: 'x' } },
  'scene-invalid__v-0': { 'status.energy.1': { positivePrompt: 'x' } },
})), { 'scene-chatting': { 'status.energy.1': { positivePrompt: '', negativePrompt: 'x' } } });
assert.deepEqual(plain(helpers.normalizeSceneStatePromptOverrides({ 'scene-chatting': { 'status.energy.1': { positivePrompt: 'x'.repeat(12001) } } })), {});
const oldState = state; state = { ...state, slot: 2 };
assert.equal(helpers.saveCurrentStateEditorPrompt(snap, scene, 'status.energy.1', 'positivePrompt', 'stale', 'global'), false);
state = oldState; imageKey = 'wife__scene-other__v-0';
assert.equal(helpers.stateEditorContext(scene), null);
assert.equal(helpers.saveCurrentStateEditorPrompt(snap, scene, 'status.energy.1', 'positivePrompt', 'stale', 'scene'), false);
imageKey = 'wife__scene-chatting__v-0'; currentPreset = 'other';
assert.equal(helpers.saveCurrentStateEditorPrompt(snap, scene, 'status.energy.1', 'positivePrompt', 'stale', 'global'), false);
currentPreset = 'assigned';
const calls = contextCalls, reads = gameReads;
helpers.renderCurrentStateEditor(h, { refresh() {} }, scene, false);
assert.equal(contextCalls, calls); assert.equal(gameReads, reads, 'inactive settings panel does not inspect state');
let tree = helpers.renderCurrentStateEditor(h, { refresh() {} }, scene, true);
assert.ok(by(tree, 'data-current-state-field'));
assert.ok(nodes(tree).some(node => node.tag === 'p' && node.children.join('').includes('자동으로 연결할 수 없는 상태')));
const control = by(tree, 'data-current-state-scope');
control.props.onchange({ currentTarget: { value: 'scene' } });
tree = helpers.renderCurrentStateEditor(h, { refresh() {} }, scene, true);
assert.equal(by(tree, 'data-current-state-scope').children.find(item => item.props.value === 'scene').props.selected, true);
const input = by(tree, 'data-current-state-prompt');
input.props.onchange({ currentTarget: { value: 'scene ui' } });
assert.equal(storage.sceneStatePromptOverrides[scene]['status.energy.1'].positivePrompt, 'scene ui');
assert.equal(refreshes, 1);
rejectSettingsWrite = true;
assert.doesNotThrow(() => input.props.onchange({ currentTarget: { value: 'cannot save' } }));
assert.match(context.settingsMessage, /저장하지 못했어요/);
rejectSettingsWrite = false;
assert.equal(helpers.effectiveSceneStatePrompts(before, scene, 'positivePrompt')['status.energy.1'], 'scene ui');
provider = new Map([['status.energy.1', externalProvider]]);
tree = helpers.renderCurrentStateEditor(h, { refresh() {} }, scene, true);
assert.notEqual(by(tree, 'data-current-state-prompt').props.disabled, true);
assert.ok(nodes(tree).some(node => node.tag === 'p' && node.children.join('').includes('외부 제공자')));
assert.ok(nodes(tree).some(node => node.tag === 'p' && node.children.join('').includes('모든 캐릭터와 상황')));
assert.ok(nodes(tree).some(node => node.tag === 'p' && node.children.join('').includes('연결되지 않은 다른 모드')));
provider = new Map();
const fresh = helpers.stateEditorContext(scene);
assert.equal(helpers.saveCurrentStateEditorPrompt(fresh, scene, 'status.energy.1', 'positivePrompt', '', 'scene'), true);
assert.equal(helpers.saveCurrentStateEditorPrompt(fresh, scene, 'status.energy.1', 'negativePrompt', '', 'scene'), true);
context.promptContext = () => {
  const positive = helpers.effectiveSceneStatePrompts({ 'status.energy.1': 'global' }, scene, 'positivePrompt');
  const negative = helpers.effectiveSceneStatePrompts({ 'status.energy.1': 'global' }, scene, 'negativePrompt');
  return { positiveGroups: positive['status.energy.1'] ? groups().positiveGroups.slice(0, 1) : [],
    negativeGroups: negative['status.energy.1'] ? groups().negativeGroups : [] };
};
assert.ok(helpers.stateEditorContext(scene).fields.includes('status.energy.1'), 'blank scene overrides keep the original active state editable');
assert.equal(helpers.effectiveSceneStatePrompts({ 'status.energy.1': 'global' }, scene, 'positivePrompt')['status.energy.1'], '',
  'temporarily inspecting the base state cannot leak past the inspection');
storage.situationPresets = storage.situationPresets.map(preset => preset.id === 'assigned'
  ? { ...preset, prompts: { ...preset.prompts, 'status.energy.1': '' }, negativePrompts: { ...preset.negativePrompts, 'status.energy.1': '' } } : preset);
context.promptContext = () => ({ positiveGroups: [], negativeGroups: [] });
assert.ok(helpers.stateEditorContext(scene).fields.includes('status.energy.1'), 'blank global and scene values remain editable when the state condition is active');
assert.equal(storage.situationPresets[0].prompts['status.energy.1'], '', 'the detection sentinel never changes saved prompts');
probeActive = false;
assert.ok(!helpers.stateEditorContext(scene).fields.includes('status.energy.1'), 'a previously edited but inactive state is hidden');
console.log('current state editor: ok');
