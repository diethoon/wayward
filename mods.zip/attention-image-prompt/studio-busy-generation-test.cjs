const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, 'source/portrait-fresh-variants.js'), 'utf8');
const snippet = source.slice(source.indexOf('    function studioAutomaticGenerationBusy()'),
  source.indexOf('    async function portraitFreshVariantKey('));
assert.ok(snippet.includes("priority: -3000001"));

function fixture(options = {}) {
  let time = 0, sleeps = 0, busy = options.busy ?? true, offline = options.offline ?? false;
  let backendMode = options.backendMode ?? 'auto', canceled = false, nextCalls = 0, lookups = 0, portraitKey = options.portraitKey ?? 'different-canonical-key';
  const key = 'wife__scene-sex__v-0';
  const hooks = [];
  const globals = { WW_ImageStudio: { isBusy() { if (options.busyThrows) throw Error('busy'); return busy; } },
    get __WW_STUDIO_OFFLINE_ONLY__() { return offline; } };
  const settingsStore = { getState: () => ({ imageBackendMode: backendMode }) };
  const nativeFreshVariantKeys = new Set(options.nativeFresh ? [key] : []);
  const queue = new Map(options.noOwner ? [] : [[key, { get cancelRequested() { return canceled; } }]]);
  const api = {
    has: name => !(name === 'imageGenerationInFlight' && options.noQueue) && !(name === 'currentPortraitImageKey' && options.noPortrait)
      && ['imageGenerate', 'imageLookup', 'imageGenerationInFlight', 'currentPortraitImageKey'].includes(name),
    fn: name => name === 'imageGenerationInFlight' ? queue : name === 'currentPortraitImageKey' ? () => {
      if (options.portraitThrows) throw Error('portrait');
      return portraitKey;
    } : undefined,
    store: { game: () => ({}) },
    hook: (name, spec) => hooks.push({ name, ...spec }),
  };
  const imageLookup = options.noLookup ? null : async () => {
      lookups++;
      if (options.lookupThrows) throw Error('lookup');
      return options.cached ? { talentName: key, imagePath: 'cached.png' } : null;
  };
  const setTimeout = callback => {
    sleeps++;
    time += 250;
    if (options.releaseAt && time >= options.releaseAt) busy = false;
    if (options.offlineAt && time >= options.offlineAt) offline = true;
    if (options.offAt && time >= options.offAt) backendMode = 'off';
    if (options.cancelAt && time >= options.cancelAt) canceled = true;
    if (options.portraitChangeAt && time >= options.portraitChangeAt) portraitKey = 'new-situation';
    callback();
  };
  new Function('api', 'imageLookup', 'settingsStore', 'nativeFreshVariantKeys', 'globalThis', 'Date', 'setTimeout', snippet)(
    api, imageLookup, settingsStore, nativeFreshVariantKeys, globals, { now: () => time }, setTimeout);
  const hook = hooks.find(item => item.name === 'imageGenerate');
  assert.ok(hook);
  const run = request => hook.around(() => {
    nextCalls++;
    if (options.nextThrows) throw Error('next');
    return { url: 'image', key };
  }, { imageKey: key, ...request });
  return { run, get nextCalls() { return nextCalls; }, get lookups() { return lookups; },
    get sleeps() { return sleeps; }, get time() { return time; } };
}

(async () => {
  for (const request of [{ bypassCache: true }, { bulk: true }, { debug: { source: 'another-mod' } }]) {
    const f = fixture();
    assert.equal((await f.run(request)).url, 'image');
    assert.equal(f.nextCalls, 1); assert.equal(f.lookups, 0); assert.equal(f.sleeps, 0);
  }
  for (const options of [{ busy: false }, { offline: true }, { backendMode: 'off' }, { busyThrows: true }, { cached: true }, { lookupThrows: true }, { noLookup: true }, { noQueue: true }, { noOwner: true }, { nativeFresh: true }, { noPortrait: true }, { portraitThrows: true }, { portraitKey: '' }]) {
    const f = fixture(options);
    assert.equal((await f.run()).url, 'image');
    assert.equal(f.nextCalls, 1); assert.equal(f.sleeps, 0);
  }
  {
    const f = fixture({ releaseAt: 1250 });
    assert.equal((await f.run()).url, 'image');
    assert.equal(f.nextCalls, 1); assert.equal(f.lookups, 1); assert.equal(f.time, 1250);
  }
  {
    const f = fixture();
    assert.equal((await f.run()).url, 'image');
    assert.equal(f.nextCalls, 1); assert.equal(f.time, 30000);
  }
  for (const options of [{ offlineAt: 500 }, { offAt: 500 }]) {
    const f = fixture(options);
    assert.equal((await f.run()).url, 'image');
    assert.equal(f.nextCalls, 1); assert.equal(f.time, 500);
  }
  {
    const f = fixture({ cancelAt: 500 });
    assert.equal(await f.run(), null); assert.equal(f.nextCalls, 0); assert.equal(f.time, 500);
  }
  {
    const f = fixture({ portraitChangeAt: 500 });
    assert.equal(await f.run(), null); assert.equal(f.nextCalls, 0); assert.equal(f.time, 500);
  }
  {
    const f = fixture({ cached: true, nextThrows: true });
    await assert.rejects(f.run(), /next/); assert.equal(f.nextCalls, 1);
  }
  console.log('studio busy automatic generation: ok');
})().catch(error => { console.error(error); process.exitCode = 1; });
