const assert = require('node:assert/strict');
const fs = require('node:fs');
const source = fs.readFileSync(require('node:path').join(__dirname, 'source/button-prompts.js'), 'utf8');

function harness(initialRules = []) {
  let state, hook, portraitHook, observer, settingsReads = 0, gameReads = 0, notifications = 0, saved = { buttonPromptRules: initialRules };
  let portraitKey = 'wife__scene-chatting__v-0';
  const api = {
    has: name => name === 'reduceGameAction' || name === 'currentPortraitImageKey' || name === 'gamePressTopicTable',
    fn: name => name === 'gamePressTopicTable' ? { grope_ass: { scene: 'groped_ass' } } : undefined,
    hook: (name, value) => { if (name === 'reduceGameAction') hook = value; else if (name === 'currentPortraitImageKey') portraitHook = value; else assert.fail(name); },
    actions: { observe: fn => { observer = fn; } },
    store: { game: () => { gameReads++; return state; } },
    settings: { get: defaults => { settingsReads++; return { ...defaults, ...saved }; }, set: value => { saved = { ...saved, ...value }; } },
    ui: { button: (label, onClick) => ({ label, onClick }) },
  };
  const latestScenePrompt = { characterId: 'wife', result: { key: 'wife__scene-chatting__v-0', prompt: 'base positive', negativePrompt: 'base negative' } };
  const factory = new Function('api', 'latestScenePrompt', 'positionSituationId', 'positionSituationLabel', 'refreshPortraitImage', 'activePortraitImageKey', 'shortHash', 'notifyExternalPromptChange', 'promptTagPreview', 'updatePromptTagPreview', 'nativeScenePromptCandidates', 'scenePromptCatalog', `let scenePromptEditorId = '', activeSettingsTab = '', activeTagTarget = null;\n${source}\nreturn { buttonPromptGroups, buttonEventContext, buttonActionChoiceId, buttonSameStateContext, buttonSameInputContext, buttonSameResultContext, buttonFreshWifeResponse, nativeChoiceSceneCandidates, normalizeButtonPromptRules, getButtonPromptRule, buttonPromptRuleToken, getButtonPromptOutcome, buttonPromptOutcomeToken, reloadButtonPromptSettings, saveButtonPromptRule, installButtonPromptObserver, renderButtonPrompts, navigation: () => ({ scenePromptEditorId, activeSettingsTab }) };`);
  const feature = factory(api, latestScenePrompt, key => String(key).split('__').find(s => /^(scene|task|look)-/.test(s)) || '', id => id, () => {}, () => portraitKey, value => value, () => { notifications++; }, () => null, () => {}, id => id === 'scene-chatting' ? [{ label: '게임 후보', text: 'chatting' }] : id === 'scene-groped_ass' ? [{ label: '게임 후보', text: 'ass_grab' }] : [], () => [{ id: 'scene-bold_touch', label: '대담한 접촉' }, { id: 'scene-other', label: '다른 장면' }]);
  feature.installButtonPromptObserver();
  return { ...feature, hook: () => hook, observe: value => observer(value), setState: value => { state = value; },
    replaceSettings: value => { saved = value; }, settings: () => saved, reads: () => settingsReads, gameReads: () => gameReads, notifications: () => notifications,
    setPortrait: key => { portraitKey = key; latestScenePrompt.result.key = key; }, setActiveKey: key => { portraitKey = key; }, setLastCharacter: id => { latestScenePrompt.characterId = id; },
    portrait: fn => portraitHook.around(fn) };
}

const context = { scene: 'scene-chatting', eventType: 'patron_interaction', eventKind: '', choiceId: 'talk', label: '대화' };
const rule = { ...context, mode: 'shown', positivePrompt: 'talking', negativePrompt: 'silent' };
function scene(stage = 'chatting', overrides = {}) {
  return { day: 1, primaryCharacterId: 'wife', characters: { wife: { sceneOverride: stage } },
    activeScene: { patron: { customerId: 'guest', stage, startedAtSlot: 3 } },
    pendingEvent: { type: 'patron_interaction', choices: [{ id: 'talk', label: '대화' }] }, ...overrides };
}
const image = stage => `wife__scene-${stage}__v-0`;
const h = harness([rule]);
let state = scene(); h.setState(state);
assert.deepEqual(h.buttonPromptGroups(state, 'wife', image('chatting')).positive, [], 'legacy shown rules are never applied');
assert.deepEqual(h.buttonPromptGroups(state, 'wife', image('chatting')).negative, []);
assert.equal(h.buttonPromptGroups(state, 'other', image('chatting')).positive.length, 0);
assert.equal(h.buttonPromptGroups(state, 'wife', image('chatting'), true).positive.length, 0);
assert.equal(h.buttonPromptGroups(scene('chatting', { activeScene: { patron: state.activeScene.patron, sex: {} } }), 'wife', image('chatting')).positive.length, 0);
assert.equal(h.buttonPromptGroups(scene('chatting', { pendingEvent: { type: 'other', choices: [{ id: 'talk' }] } }), 'wife', image('chatting')).positive.length, 0);
assert.equal(h.buttonEventContext(scene('chatting', { pendingEvent: { type: 'patron_interaction', choices: [{ id: 'talk' }, { id: 'talk' }] } }), 'scene-chatting').length, 0);
assert.equal(h.buttonEventContext(scene('chatting', { pendingEvent: { type: 'patron_interaction', choices: [{ id: 'talk', disabled: true }] } }), 'scene-chatting').length, 0);
assert.equal(h.buttonActionChoiceId({ type: 'sex_scene' }, { type: 'scene_action', actionId: 'x' }), 'x');
assert.equal(h.buttonActionChoiceId({ type: 'wife_conversation' }, { type: 'wife_topic', topicId: 'x' }), 'x');
assert.equal(h.buttonActionChoiceId({ type: 'patron_interaction' }, { type: 'resolve_event', choiceId: 'x' }), null);
const reads = h.reads();
for (let i = 0; i < 100; i++) h.buttonPromptGroups(state, 'wife', image('chatting'));
assert.equal(h.reads(), reads, 'image hot path does not repeatedly read browser settings');
assert.equal(h.normalizeButtonPromptRules(Array.from({ length: 300 }, (_, i) => ({ ...rule, choiceId: String(i) }))).length, 256);
assert.equal(h.normalizeButtonPromptRules([{ ...rule, positivePrompt: 'x'.repeat(4001) }]).length, 0);
assert.equal(h.normalizeButtonPromptRules([rule, { ...rule, positivePrompt: 'new' }])[0].positivePrompt, 'new');
assert.equal(h.getButtonPromptRule(context, 'shown'), null, 'shown mode is no longer exposed');
assert.equal(h.getButtonPromptRule(context, 'after'), null);
assert.equal(h.getButtonPromptRule({ ...context, choiceId: '' }, 'shown'), null);
assert.equal(h.buttonPromptRuleToken(context, 'after'), '');
assert.equal(h.buttonPromptRuleToken(context, 'shown'), '');
assert.equal(h.getButtonPromptOutcome(context, 'scene-bold_touch'), null);

h.saveButtonPromptRule({ ...rule, mode: 'after' });
assert.equal(h.notifications(), 1);
const before = state, after = scene('bold_touch');
const outcomes = [{ situationId: 'scene-bold_touch', positivePrompt: 'first outcome', negativePrompt: 'first negative' }, { situationId: 'scene-other', positivePrompt: 'other outcome', negativePrompt: '' }];
h.saveButtonPromptRule({ ...rule, mode: 'after', outcomes });
assert.deepEqual(h.getButtonPromptOutcome(context, 'scene-bold_touch'), outcomes[0]);
const outcomeCopy = h.getButtonPromptOutcome(context, 'scene-bold_touch'); outcomeCopy.positivePrompt = 'changed';
assert.equal(h.getButtonPromptOutcome(context, 'scene-bold_touch').positivePrompt, 'first outcome');
assert.ok(h.buttonPromptOutcomeToken(context, 'scene-bold_touch'));
assert.equal(h.buttonPromptOutcomeToken(context, 'scene-unknown'), '');
assert.equal(h.getButtonPromptOutcome(context, 'scene-bold_touch|bed-1').situationId, 'scene-bold_touch');
assert.deepEqual(h.normalizeButtonPromptRules([{ ...rule, mode: 'after', outcomes }])[0].outcomes, outcomes, 'outcomes survive settings normalization');
assert.equal(h.normalizeButtonPromptRules([rule])[0].outcomes, undefined, 'older JSON without outcomes stays valid');
const action = { type: 'patron_interaction_choice', choiceId: 'talk' };
assert.equal(h.buttonSameInputContext({ ...before }, before), true, 'top-level copied game state remains the same context');
assert.equal(h.buttonSameInputContext({ ...before, pendingEvent: { ...before.pendingEvent } }, before), false);
assert.equal(h.buttonSameInputContext({ ...before, activeScene: { ...before.activeScene } }, before), false);
assert.equal(h.buttonSameInputContext({ ...before, characters: { wife: { ...before.characters.wife } } }, before), false);
assert.equal(h.buttonSameInputContext({ ...before, primaryCharacterId: 'other' }, before), false);
assert.equal(h.buttonSameInputContext({ ...before, day: 2 }, before), false);
assert.equal(h.buttonSameInputContext({ ...before, slot: 123 }, before), false);
assert.equal(h.hook().after(after, [{ ...before }, action]), after);
const copiedResult = { ...after, rngState: 42, characters: { wife: { ...after.characters.wife, lastActionDelta: 3 } } }; h.setState(copiedResult);
assert.equal(h.buttonSameStateContext(after, copiedResult), false);
assert.equal(h.buttonSameResultContext(after, copiedResult), true, 'native lastActionDelta copies the character without changing portrait identity');
for (const [field, value] of [['id', 'different'], ['sceneOverride', 'other'], ['currentTask', 'other'], ['outfit', 'other'], ['location', 'other'], ['exposure', {}]])
  assert.equal(h.buttonSameResultContext(after, { ...copiedResult, characters: { wife: { ...copiedResult.characters.wife, [field]: value } } }), false, `different ${field} is rejected`);
assert.equal(h.buttonSameResultContext(after, { ...copiedResult, locations: {} }), false);
assert.equal(h.buttonSameResultContext(after, { ...copiedResult, activeScene: {} }), false);
assert.equal(h.buttonSameResultContext(after, { ...copiedResult, day: 2 }), false);
assert.equal(h.buttonSameResultContext(after, { ...copiedResult, primaryCharacterId: 'other' }), false);
// A synchronous store subscriber can request the image before actions.observe runs.
assert.deepEqual(h.portrait(() => h.buttonPromptGroups(copiedResult, 'wife', image('bold_touch'))).positive.map(group => group.value.tags[0]), ['talking', 'first outcome']);
h.observe({ type: action.type, action });
const unrelatedUpdate = { ...copiedResult, supplies: { food: 1 } };
h.setState(unrelatedUpdate);
assert.equal(h.buttonPromptGroups(unrelatedUpdate, 'wife', image('bold_touch')).positive.length, 2);
assert.equal(h.buttonPromptGroups(scene('flirting'), 'wife', image('flirting')).positive.length, 0);
assert.equal(h.buttonPromptGroups({ ...unrelatedUpdate, day: 2 }, 'wife', image('bold_touch')).positive.length, 0);
h.observe({ type: 'load_game', action: { type: 'load_game' } });
assert.equal(h.buttonPromptGroups(unrelatedUpdate, 'wife', image('bold_touch')).positive.length, 0);

// The selected result-only candidate applies for all image variants and never leaks to a different result.
const candidateRule = { ...rule, mode: 'after', positivePrompt: '', negativePrompt: '', outcomes: [{
  situationId: 'scene-bold_touch', positivePrompt: '', negativePrompt: '', candidateSelection: 'c2', candidates: [
    { id: 'c1', positivePrompt: 'candidate one', negativePrompt: 'avoid one' },
    { id: 'c2', positivePrompt: 'candidate two', negativePrompt: 'avoid two' },
  ],
}] };
const varied = harness([candidateRule]); varied.setState(before);
varied.hook().after(after, [before, action]); varied.setState(after);
assert.deepEqual(varied.portrait(() => varied.buttonPromptGroups(after, 'wife', 'wife__scene-bold_touch__v-0')).positive.map(group => group.value.tags[0]), ['candidate two']);
assert.deepEqual(varied.buttonPromptGroups(after, 'wife', 'wife__scene-bold_touch__v-1').positive.map(group => group.value.tags[0]), ['candidate two']);
assert.deepEqual(varied.buttonPromptGroups(after, 'wife', 'wife__scene-bold_touch__v-1').negative.map(group => group.value.tags[0]), ['avoid two']);
const groupsBeforeRename = varied.buttonPromptGroups(after, 'wife', 'wife__scene-bold_touch__v-1');
varied.saveButtonPromptRule({ ...candidateRule, outcomes: [{ ...candidateRule.outcomes[0], candidates: candidateRule.outcomes[0].candidates.map(c => ({ ...c, name: c.id === 'c2' ? '이름만 변경' : '' })) }] });
assert.deepEqual(varied.buttonPromptGroups(after, 'wife', 'wife__scene-bold_touch__v-1'), groupsBeforeRename, 'renaming preserves prompt groups and the image-key signature');
assert.equal(varied.buttonPromptGroups(scene('other'), 'wife', image('other')).positive.length, 0);
const manyCandidates = Array.from({ length: 5 }, (_, index) => ({ id: `c${index + 1}`, positivePrompt: `candidate ${index + 1}`, negativePrompt: '' }));
const fifth = harness([{ ...candidateRule, outcomes: [{ ...candidateRule.outcomes[0], candidates: manyCandidates, candidateSelection: 'c5' }] }]);
fifth.setState(before); fifth.hook().after(after, [before, action]); fifth.setState(after);
assert.deepEqual(fifth.portrait(() => fifth.buttonPromptGroups(after, 'wife', 'wife__scene-bold_touch__v-0')).positive.map(group => group.value.tags[0]), ['candidate 5'], 'fifth candidate can be activated explicitly');

// Failed/no-transition and a different actual result cannot activate the configured rule.
h.setState(before); h.hook().after(before, [before, action]); h.observe({ type: action.type, action });
assert.equal(h.buttonPromptGroups(before, 'wife', image('chatting')).positive.length, 0);

// Same image scene can be distinguished only by a real changed follow-up event.
const followupRule = { ...rule, mode: 'after', positivePrompt: 'common', negativePrompt: '', outcomes: [
  { situationId: 'scene-chatting', positivePrompt: 'generic', negativePrompt: '' },
  { situationId: 'scene-chatting', eventType: 'patron_interrupt_refused', eventKind: '', positivePrompt: 'refused', negativePrompt: 'forced' },
] };
const follow = harness([followupRule]); const start = scene();
const refused = { ...start, pendingEvent: { type: 'patron_interrupt_refused', choices: [] } };
follow.setState(start); follow.hook().after(refused, [start, action]); follow.setState(refused);
assert.deepEqual(follow.portrait(() => follow.buttonPromptGroups(refused, 'wife', image('chatting'))).positive.map(group => group.value.tags[0]), ['common', 'refused']);
assert.deepEqual(follow.buttonPromptGroups(refused, 'wife', image('chatting')).negative.map(group => group.value.tags[0]), ['forced']);
assert.equal(follow.getButtonPromptOutcome(context, 'scene-chatting', refused.pendingEvent).positivePrompt, 'refused');
assert.equal(follow.getButtonPromptOutcome(context, 'scene-chatting').positivePrompt, 'generic');
assert.notEqual(follow.buttonPromptOutcomeToken(context, 'scene-chatting', refused.pendingEvent), follow.buttonPromptOutcomeToken(context, 'scene-chatting'));
follow.observe({ type: action.type, action });
const eventClosed = { ...refused, pendingEvent: null }; follow.setState(eventClosed);
assert.equal(follow.buttonPromptGroups(eventClosed, 'wife', image('chatting')).positive.length, 0, 'closing the follow-up event removes its result prompt');
follow.observe({ type: 'resolve_event', action: {} });
follow.setState(refused);
assert.equal(follow.buttonPromptGroups(refused, 'wife', image('chatting')).positive.length, 0, 'old follow-up event cannot revive a cleared result');

const previewSafe = harness([followupRule]); previewSafe.setState(start);
previewSafe.hook().after(refused, [start, action]); previewSafe.setState(refused);
previewSafe.portrait(() => previewSafe.buttonPromptGroups(refused, 'wife', image('chatting')));
previewSafe.observe({ type: action.type, action });
previewSafe.buttonPromptGroups({ ...refused, pendingEvent: null }, 'wife', image('chatting'));
assert.deepEqual(previewSafe.buttonPromptGroups(refused, 'wife', image('chatting')).positive.map(group => group.value.tags[0]), ['common', 'refused'], 'hypothetical preview does not clear the real follow-up');
h.hook().after(after, [before, action]); const differentResult = { ...after, pendingEvent: { ...after.pendingEvent } }; h.setState(differentResult);
assert.equal(h.buttonSameResultContext(after, differentResult), false);
assert.equal(h.portrait(() => h.buttonPromptGroups(differentResult, 'wife', image('bold_touch'))).positive.length, 0);
h.observe({ type: action.type, action });
assert.equal(h.buttonPromptGroups(differentResult, 'wife', image('bold_touch')).positive.length, 0);
h.replaceSettings({ buttonPromptRules: [] }); h.reloadButtonPromptSettings();
assert.equal(h.notifications(), 3);
assert.equal(h.buttonPromptGroups(before, 'wife', image('chatting')).positive.length, 0);

// Non-relationship actions bind to the real prior and resulting portrait IDs.
const taskContext = { ...context, scene: 'task-clean', eventType: 'work', choiceId: 'next' };
const task = harness([{ ...taskContext, mode: 'after', positivePrompt: 'mopping', negativePrompt: '' }]);
const taskBefore = { day: 1, primaryCharacterId: 'wife', characters: { wife: {} }, activeScene: {},
  pendingEvent: { type: 'work', choices: [{ id: 'next' }] } };
const taskAfter = { ...taskBefore, pendingEvent: null };
const taskAction = { type: 'resolve_event', choiceId: 'next' };
task.setPortrait('wife__task-clean__v-0'); task.setState(taskBefore);
task.hook().after(taskAfter, [taskBefore, taskAction]); task.setState(taskAfter);
assert.equal(task.portrait(() => task.buttonPromptGroups(taskAfter, 'wife', 'wife__task-cook__v-0')).positive.length, 1);
task.observe({ type: taskAction.type, action: taskAction });
assert.equal(task.buttonPromptGroups({ ...taskAfter }, 'wife', 'wife__task-cook__v-0').positive.length, 1);
assert.equal(task.portrait(() => task.buttonPromptGroups(taskAfter, 'wife', 'wife__task-clean__v-0')).positive.length, 0);
assert.equal(task.buttonPromptGroups(taskAfter, 'wife', 'wife__task-cook__v-0').positive.length, 0, 'scene re-entry cannot revive an old selection');
task.setState(taskBefore); task.setPortrait('wife__scene-outdated__v-0'); task.setActiveKey('wife__task-clean__v-0');
task.hook().after(taskAfter, [taskBefore, taskAction]); task.setState(taskAfter);
assert.equal(task.portrait(() => task.buttonPromptGroups(taskAfter, 'wife', 'wife__task-cook__v-0')).positive.length, 1,
  'cached portraits use the actual current key rather than the last generated prompt');
task.observe({ type: 'load_game', action: { type: 'load_game' } });
task.setState(taskBefore); task.setActiveKey('wife__task-other__v-0');
task.hook().after(taskAfter, [taskBefore, taskAction]); task.setState(taskAfter);
assert.equal(task.portrait(() => task.buttonPromptGroups(taskAfter, 'wife', 'wife__task-cook__v-0')).positive.length, 0, 'stale prior portrait is ignored');
task.setState(taskBefore); task.setActiveKey('wife__task-clean__v-0');
task.hook().after(taskAfter, [{ ...taskBefore, pendingEvent: { ...taskBefore.pendingEvent } }, taskAction]); task.setState(taskAfter);
assert.equal(task.portrait(() => task.buttonPromptGroups(taskAfter, 'wife', 'wife__task-cook__v-0')).positive.length, 0, 'different event object is rejected');

// Settings UI edits the post-choice result and preserves old shown rules without applying them.
const form = harness(); form.setState(scene());
const idleReads = form.gameReads();
for (let i = 0; i < 100; i++) {
  form.hook().after({}, [scene(), { type: 'patron_interaction_choice', choiceId: 'talk' }]);
  form.observe({ type: 'patron_interaction_choice', action: {} });
}
assert.equal(form.gameReads(), idleReads, 'unconfigured choices do not read game state on every action');
const element = (tag, props, ...children) => ({ tag, props, children });
const walk = node => !node || typeof node !== 'object' ? [] : [node, ...(node.children || []).flatMap(walk)];
const refresh = { refresh() {} };
let tree = form.renderButtonPrompts(element, refresh);
assert.equal(walk(tree).some(node => node.props?.['data-choice-current-prompt'] !== undefined || node.props?.['data-choice-base-prompts'] !== undefined), false, 'redundant current and native read-only sections are absent');
assert.equal(walk(tree).some(node => node.props?.['data-button-prompt-mode'] !== undefined), false);
const initialNodes = walk(tree);
assert.ok(initialNodes.findIndex(node => node.props?.['data-choice-outcomes'] !== undefined) < initialNodes.findIndex(node => node.tag === 'strong' && node.children.includes('선택 후 공통 추가 문구')), 'result editor precedes the common prompt');
walk(tree).find(node => node.props?.['data-choice-add-outcome'] !== undefined).props.onclick();
tree = form.renderButtonPrompts(element, refresh);
walk(tree).find(node => node.props?.['data-choice-outcome-field'] === 'positivePrompt').props.onchange({ currentTarget: { value: 'first result' } });
tree = form.renderButtonPrompts(element, refresh);
walk(tree).find(node => node.props?.['data-choice-outcome-field'] === 'negativePrompt').props.onchange({ currentTarget: { value: 'avoid result' } });
assert.equal(form.getButtonPromptOutcome(context, 'scene-bold_touch').positivePrompt, 'first result');
assert.equal(form.getButtonPromptOutcome(context, 'scene-bold_touch').negativePrompt, 'avoid result');
tree = form.renderButtonPrompts(element, refresh);
walk(tree).find(node => node.props?.['data-choice-candidate-field'] === 'positivePrompt').props.onchange({ currentTarget: { value: 'candidate one' } });
tree = form.renderButtonPrompts(element, refresh);
walk(tree).find(node => node.label === '후보 추가').onClick();
tree = form.renderButtonPrompts(element, refresh);
walk(tree).find(node => node.props?.['data-choice-candidate-field'] === 'positivePrompt').props.onchange({ currentTarget: { value: 'candidate two' } });
const outcomeWithCandidates = form.getButtonPromptOutcome(context, 'scene-bold_touch');
assert.deepEqual(outcomeWithCandidates.candidates.map(candidate => candidate.positivePrompt), ['candidate one', 'candidate two']);
outcomeWithCandidates.candidates[0].positivePrompt = 'mutated';
assert.equal(form.getButtonPromptOutcome(context, 'scene-bold_touch').candidates[0].positivePrompt, 'candidate one', 'API returns an independent candidate copy');
const selectedToken = form.buttonPromptOutcomeToken(context, 'scene-bold_touch');
assert.ok(selectedToken, 'candidate configuration contributes to outcome token');
tree = form.renderButtonPrompts(element, refresh);
walk(tree).find(node => node.props?.['data-choice-candidate-select'] !== undefined).props.onchange({ currentTarget: { value: 'candidate-1' } });
assert.equal(form.getButtonPromptOutcome(context, 'scene-bold_touch').candidateSelection, 'candidate-1');
assert.notEqual(form.buttonPromptOutcomeToken(context, 'scene-bold_touch'), selectedToken, 'changing selected candidate changes the cache token');
tree = form.renderButtonPrompts(element, refresh);
const nameToken = form.buttonPromptOutcomeToken(context, 'scene-bold_touch');
walk(tree).find(node => node.props?.['data-choice-candidate-name'] !== undefined).props.onchange({ currentTarget: { value: '밤의 대화' } });
assert.equal(form.getButtonPromptOutcome(context, 'scene-bold_touch').candidates[0].name, '밤의 대화');
assert.equal(form.buttonPromptOutcomeToken(context, 'scene-bold_touch'), nameToken, 'renaming a candidate does not change its image token');
tree = form.renderButtonPrompts(element, refresh);
assert.ok(walk(tree).some(node => node.tag === 'option' && node.children.some(text => typeof text === 'string' && text.includes('밤의 대화'))));
form.reloadButtonPromptSettings();
assert.equal(form.getButtonPromptOutcome(context, 'scene-bold_touch').candidates[0].name, '밤의 대화', 'candidate name survives settings reload');
tree = form.renderButtonPrompts(element, refresh);
let field = walk(tree).find(node => node.props?.['data-button-prompt-field'] === 'positivePrompt');
field.props.onchange({ currentTarget: { value: 'positive' } });
tree = form.renderButtonPrompts(element, refresh);
field = walk(tree).find(node => node.props?.['data-button-prompt-field'] === 'negativePrompt');
field.props.onchange({ currentTarget: { value: 'negative' } });
assert.deepEqual(form.getButtonPromptRule(context, 'after'), { mode: 'after', positivePrompt: 'positive', negativePrompt: 'negative' });
tree = form.renderButtonPrompts(element, refresh);
const select = walk(tree).find(node => node.props?.['data-button-prompt-select'] !== undefined);
assert.match(select.children[0].children.join(''), /대화 · 현재 표시 중/);
const identity = walk(tree).find(node => node.props?.['data-button-prompt-identity'] !== undefined);
assert.deepEqual(walk(identity).filter(node => node.tag === 'code').map(node => node.children.join('')), ['patron_interaction', 'talk'], 'identifiers use translation-protected code elements');
const withSaved = harness([{ ...rule, choiceId: 'other', label: '예전 선택지' }]);
withSaved.setState(scene());
const savedOptions = walk(withSaved.renderButtonPrompts(element, refresh)).filter(node => node.tag === 'option').map(node => node.children.join(''));
assert.ok(savedOptions.some(label => label.includes('예전 선택지 · 저장됨')));
assert.ok(savedOptions.some(label => label.includes('대화 · 현재 표시 중')));
const legacy = harness([rule]); legacy.setState(scene());
let legacyTree = legacy.renderButtonPrompts(element, refresh);
assert.ok(walk(legacyTree).some(node => node.tag === 'p' && node.children.some(child => typeof child === 'string' && child.includes('이전의 표시 중 문구'))));
walk(legacyTree).find(node => node.props?.['data-choice-add-outcome'] !== undefined).props.onclick();
assert.deepEqual(legacy.settings().buttonPromptRules[0].legacyShownPrompt, { positivePrompt: 'talking', negativePrompt: 'silent' });
assert.equal(legacy.settings().buttonPromptRules[0].positivePrompt, '', 'old shown text is not applied after choosing a result');
select.props.onchange({ currentTarget: { value: select.props.value } });
walk(tree).find(node => node.label === '선택지 설정 삭제').onClick();
assert.equal(form.getButtonPromptRule(context, 'after'), null);

const wifeContext = { scene: 'task-idle', eventType: 'wife_conversation', eventKind: '', choiceId: 'grope_ass', label: '엉덩이' };
const wifeRule = { ...wifeContext, mode: 'after', positivePrompt: '', negativePrompt: '', outcomes: [
  { situationId: 'task-idle', response: 'refuse', positivePrompt: 'refused', negativePrompt: 'avoid accept' },
  { situationId: 'task-idle', response: 'accept', positivePrompt: 'accepted', negativePrompt: '' },
] };
const wf = harness([wifeRule]);
assert.equal(wf.nativeChoiceSceneCandidates(wifeContext)[0].text, 'ass_grab');
assert.equal(wf.nativeChoiceSceneCandidates({ ...wifeContext, choiceId: 'press_grope_ass_1' })[0].situationId, 'scene-groped_ass');
assert.deepEqual(wf.nativeChoiceSceneCandidates({ ...wifeContext, choiceId: 'hug' }), []);
const wb = { day: 1, slot: 100, primaryCharacterId: 'wife', characters: { wife: { id: 'wife', lastResponse: 'old', lastResponseType: 'refuse', lastResponseSlot: 90 } },
  pendingEvent: { type: 'wife_conversation', choices: [{ id: 'grope_ass', label: '엉덩이' }] }, activeScene: {} };
const wa = { ...wb, slot: 102, characters: { wife: { ...wb.characters.wife, lastResponse: 'new', lastResponseType: 'refuse', lastResponseSlot: 100 } }, pendingEvent: null };
const waction = { type: 'wife_topic', topicId: 'grope_ass' };
assert.equal(wf.buttonFreshWifeResponse(wb, wa, waction), 'refuse');
assert.equal(wf.buttonFreshWifeResponse(wb, { ...wa, characters: wb.characters }, waction), '', 'unchanged old response never identifies this choice');
assert.equal(wf.buttonFreshWifeResponse(wb, { ...wa, characters: { wife: { ...wa.characters.wife, lastResponseSlot: 99 } } }, waction), '');
assert.equal(wf.getButtonPromptOutcome(wifeContext, 'task-idle', null, 'refuse').positivePrompt, 'refused');
assert.equal(wf.getButtonPromptOutcome(wifeContext, 'task-idle', null, 'accept').positivePrompt, 'accepted');
assert.equal(wf.getButtonPromptOutcome(wifeContext, 'task-idle', null, ''), null);
wf.setPortrait('wife__task-idle__v-0'); wf.setState(wb);
wf.hook().after(wa, [wb, waction]); wf.setState(wa);
assert.deepEqual(wf.portrait(() => wf.buttonPromptGroups(wa, 'wife', 'wife__task-idle__v-0')).positive.flatMap(group => group.value.tags), ['refused']);
wf.observe({ type: waction.type, action: waction });
wf.observe({ type: 'wait', action: { type: 'wait' } });
assert.equal(wf.buttonPromptGroups(wa, 'wife', 'wife__task-idle__v-0').positive.length, 0, 'new action clears response-specific tracking');
wf.setState(wb);
const wt = wf.renderButtonPrompts(element, refresh);
const wifeOptions = walk(wt).filter(node => node.tag === 'option').map(node => node.children.join(''));
assert.ok(wifeOptions.some(label => label.includes('거절 후 밀어붙이기')));
assert.ok(wifeOptions.some(label => label.includes('다시 강하게 밀어붙이기')));
assert.equal(walk(wt).some(node => node.props?.['data-choice-base-prompts'] !== undefined), false);
console.log('button-prompts: ok');
