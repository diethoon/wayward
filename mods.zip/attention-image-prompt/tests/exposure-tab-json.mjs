// 실행: node wml/mods/attention-image-prompt_hl/tests/exposure-tab-json.mjs [--mobile]
// 단독 및 ImageStudio 연결을 격리 저장소에서 검사합니다. GPU·사용자 설정/파일 쓰기 없음, seed=1138.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { playStart, playEval, playStop, playStatus, shutdown } from '../../../../MCP/lib/play.mjs';

const session = 'attention-exposure-json';
const viewport = process.argv.includes('--mobile') ? { width: 390, height: 844 } : { width: 1500, height: 950 };
let listed = [];
vm.runInNewContext(fs.readFileSync(new URL('../../mods.js', import.meta.url), 'utf8'), { WML: { folders() {}, enable: value => { listed = value; } } });
const disabled = Object.fromEntries(listed.map(value => [value.replace(/:off$/, ''), false]));

try {
  for (const studio of [false, true]) {
    const started = await playStart({ id: session, viewport, mods: { ...disabled, 'addon-compat': true,
      'attention-image-prompt': true, imagestudio: studio, 'imagestudio-compatible-attention-image-prompt': studio } });
    assert.deepEqual(started.failed, []);
    const response = await playEval({ id: session, timeoutMs: 30000, code: `
      let seed=1138;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
      const d=WML.dev(),before=JSON.stringify(d.store.game()),key='wml.mod.attention-image-prompt';
      const saved=()=>JSON.parse(localStorage.getItem(key)||'{}');
      const initial=saved();localStorage.setItem(key,JSON.stringify({...initial,marker1138:'keep',nativeAxisPrompts:{mood:{default:{positivePrompt:'keep mood'}}}}));
      WML.openManager();const row=[...document.querySelectorAll('.wml-id')].find(e=>e.textContent==='attention-image-prompt').closest('tr');
      [...row.querySelectorAll('button')].find(b=>b.textContent==='⚙').click();
      const tab=title=>[...document.querySelectorAll('button')].find(b=>b.textContent===title).click();
      tab('노출 상태 프롬프트');
      const source=document.querySelector('[data-attention-exposure-source]');
      const ids=[...source.options].map(o=>o.value);
      source.value='0100000';source.dispatchEvent(new Event('change',{bubbles:true}));
      const edit=document.querySelector('[data-attention-exposure-prompt="positive"]');
      edit.value='exposure_positive_1138';edit.dispatchEvent(new Event('change',{bubbles:true}));
      tab('Negative');
      const neg=document.querySelector('[data-attention-exposure-prompt="negative"]');
      neg.value='exposure_negative_1138';neg.dispatchEvent(new Event('change',{bubbles:true}));
      const state=d.store.game(),wife=d.fn('wife')(state),character={...wife,outfit:'modest',exposure:{topPulledDown:true}};
      d.store.update(()=>({...state,characters:{...state.characters,[state.primaryCharacterId]:character}}));
      const live=d.fn('imagePrompt')(d.fn('wife')(d.store.game()),'taproom');
      d.store.update(()=>state);
      const originalURL=URL.createObjectURL,originalClick=HTMLAnchorElement.prototype.click,downloads=[];
      URL.createObjectURL=blob=>{downloads.push(blob);return originalURL(blob);};HTMLAnchorElement.prototype.click=function(){};
      const exportTab=async()=>{const n=downloads.length;tab('해당 탭 JSON 내보내기');for(let i=0;i<100&&downloads.length===n;i++)await new Promise(r=>setTimeout(r,10));return JSON.parse(await downloads.at(-1).text());};
      const upload=async data=>{
        const input=document.querySelector('[data-attention-tab-json-input]'),dt=new DataTransfer();
        dt.items.add(new File([JSON.stringify(data)],'test.json',{type:'application/json'}));input.files=dt.files;input.dispatchEvent(new Event('change',{bubbles:true}));
        for(let i=0;i<100&&input.isConnected;i++)await new Promise(r=>setTimeout(r,10));
      };
      const exported=await exportTab();
      const other=saved().nativeAxisPrompts.mood;
      await upload({...exported,nativeAxisPrompts:{exposure:{}}});
      const cleared=Object.keys(saved().nativeAxisPrompts.exposure).length===0;
      await upload(exported);
      const roundtrip=JSON.stringify(saved().nativeAxisPrompts.exposure)===JSON.stringify(exported.nativeAxisPrompts.exposure);
      const snapshot=JSON.stringify(saved());
      await upload({...exported,tabId:'outfit-prompts'});
      const wrongTabPreserved=snapshot===JSON.stringify(saved());
      await upload({...exported,nativeAxisPrompts:{exposure:{'0100000':{positivePrompt:1138}}}});
      const malformedPreserved=snapshot===JSON.stringify(saved());
      const fields=['bodiceUnlaced','topPulledDown','topRemoved','skirtUp','skirtRemoved','pantiesAside','pantiesRemoved'];
      const canonicalCodes=new Set();
      for(let index=0;index<128;index++){
        const code=index.toString(2).padStart(7,'0');
        const flags=Object.fromEntries(fields.map((field,i)=>[field,code[i]==='1']));
        const canonical=d.fn('Mte')(flags);
        canonicalCodes.add(fields.map(field=>canonical[field]?'1':'0').join(''));
      }
      const previous=saved();localStorage.setItem(key,JSON.stringify({...previous,nativeAxisPrompts:{...previous.nativeAxisPrompts,exposure:{...previous.nativeAxisPrompts.exposure,'1100000':{positivePrompt:'alias_should_not_override'}}}}));
      const aliasPriority=d.fn('_2e')({bodiceUnlaced:true,topPulledDown:true}).positive==='exposure_positive_1138';
      document.querySelector('[data-attention-exposure-prompt="negative"]').value='';
      document.querySelector('[data-attention-exposure-prompt="negative"]').dispatchEvent(new Event('change',{bubbles:true}));
      const blankNegative=d.fn('_2e')({topPulledDown:true}).negative==='';
      tab('이 노출 상태를 게임 기본값으로 복원');
      const resetAliases=!saved().nativeAxisPrompts.exposure['0100000']&&!saved().nativeAxisPrompts.exposure['1100000'];
      await upload(exported);
      localStorage.setItem(key,JSON.stringify({...saved(),nativeAxisPrompts:{...saved().nativeAxisPrompts,exposure:{...saved().nativeAxisPrompts.exposure,none:{positivePrompt:'normal_exposure_1138',negativePrompt:'normal_negative_1138'}}}}));
      const normalState=d.store.game();
      d.store.update(()=>({...normalState,characters:{...normalState.characters,[normalState.primaryCharacterId]:{...wife,exposure:{}}}}));
      const normal=d.fn('imagePrompt')(d.fn('wife')(d.store.game()),'taproom');d.store.update(()=>normalState);
      const normalPrompt=normal.prompt.includes('normal_exposure_1138')&&normal.negativePrompt.includes('normal_negative_1138');
      // 프리셋의 상세 상태 탭만 갱신하고 다른 탭·전역 설정은 보존합니다.
      tab('상황 프리셋');
      const add=[...document.querySelectorAll('button')].find(b=>b.textContent.includes('새 프리셋'));
      if(!add)throw Error('새 프리셋 버튼 없음');add.click();
      const presetSelect=document.querySelector('[data-situation-preset-editor]');
      const presetId=presetSelect.value;
      tab('상세 상태');
      const detail=await exportTab();const detailKey=Object.keys(detail.prompts)[0];
      const prior=saved();
      await upload({...detail,prompts:{[detailKey]:'detail_import_1138'},outfitPrompts:{modest:{positivePrompt:'wrong',negativePrompt:'wrong'}}});
      const after=saved(),preset=after.situationPresets.find(p=>p.id===presetId);
      const detailApplied=preset.prompts[detailKey]==='detail_import_1138';
      const globalPreserved=JSON.stringify(after.prompts)===JSON.stringify(prior.prompts);
      const outfitPreserved=JSON.stringify(after.outfitPrompts)===JSON.stringify(prior.outfitPrompts);
      // 편집 가능한 각 탭에서 JSON을 왕복하고 설정 데이터가 없는 진단 탭은 제외합니다.
      const roundtrips=[];
      for(const title of ['아내 캐릭터','의상 프롬프트','노출 상태 프롬프트','상황 프리셋','체위 설정','기본 상황','상세 상태','H Status','대화 감지']){
        const button=[...document.querySelectorAll('button')].find(b=>b.textContent===title);if(!button)throw Error('설정 탭 없음: '+title);button.click();
        const data=await exportTab();await upload(data);roundtrips.push(data.tabId);
      }
      const allIndex=downloads.length;tab('JSON 내보내기');
      for(let i=0;i<100&&downloads.length===allIndex;i++)await new Promise(r=>setTimeout(r,10));
      const full=JSON.parse(await downloads.at(-1).text());
      const fullIncludesExposure=full.version===17&&full.nativeAxisPrompts.exposure['0100000'].positivePrompt==='exposure_positive_1138';
      localStorage.setItem(key,JSON.stringify({...saved(),nativeAxisPrompts:{...saved().nativeAxisPrompts,exposure:{}}}));
      const fullInput=document.querySelector('[data-attention-full-json-input]'),transfer=new DataTransfer();
      transfer.items.add(new File([JSON.stringify(full)],'all.json',{type:'application/json'}));fullInput.files=transfer.files;fullInput.dispatchEvent(new Event('change',{bubbles:true}));
      for(let i=0;i<100&&fullInput.isConnected;i++)await new Promise(r=>setTimeout(r,10));
      const fullRestored=saved().nativeAxisPrompts.exposure['0100000'].positivePrompt==='exposure_positive_1138';
      URL.createObjectURL=originalURL;HTMLAnchorElement.prototype.click=originalClick;
      let plan=null,shared=null,sharedPriority=true;
      if(${studio}){
        const b=WW_ImageStudioBridge;await b.ready();
        const selected={situation:['idle'],outfit:['modest'],room:['taproom'],mood:['default'],men:['0'],exposure:['0100000'],aftermath:['none'],variant:['0']};
        const space=WW_ImageStudioPrompt.combinationSpace({});plan=b.randomSpace('elena',selected).build(0n,space.at(0n))[0];
        const ck='wml.mod.imagestudio-compatible-attention-image-prompt';const c=JSON.parse(localStorage.getItem(ck)||'{}');
        localStorage.setItem(ck,JSON.stringify({...c,nativeAxisPrompts:{...c.nativeAxisPrompts,exposure:exported.nativeAxisPrompts.exposure}}));
        shared=WML.use('imagestudio-compatible-attention-image-prompt').nativeAxisPrompt('exposure','0100000');
        const cs=JSON.parse(localStorage.getItem(ck));localStorage.setItem(ck,JSON.stringify({...cs,nativeAxisPrompts:{...cs.nativeAxisPrompts,exposure:{'0100000':{positivePrompt:'shared_exposure_1138',negativePrompt:'shared_negative_1138'}}}}));
        const ds=WW_ImageStudioPrompt.combinationSpace({}),sp=b.randomSpace('elena',selected).build(0n,ds.at(0n))[0];
        sharedPriority=sp.prompt.includes('shared_exposure_1138')&&!sp.prompt.includes('exposure_positive_1138')&&sp.negativePrompt.includes('shared_negative_1138');
      }
      return {ids,live,livePositive:live.prompt.includes('exposure_positive_1138'),liveNegative:live.negativePrompt.includes('exposure_negative_1138'),exported,
        cleared,roundtrip,wrongTabPreserved,malformedPreserved,canonicalCount:canonicalCodes.size,aliasPriority,blankNegative,resetAliases,normalPrompt,sharedPriority,otherPreserved:JSON.stringify(saved().nativeAxisPrompts.mood)===JSON.stringify(other),
        detailApplied,globalPreserved,outfitPreserved,roundtrips,fullIncludesExposure,fullRestored,plan:plan&&{positive:plan.prompt.includes('exposure_positive_1138'),negative:plan.negativePrompt.includes('exposure_negative_1138')},shared,
        unchanged:before===JSON.stringify(d.store.game())};
    ` });
    assert.equal(response.error, undefined, JSON.stringify(response));
    if (response.pageErrorsSoFar) console.log(JSON.stringify(await playStatus({ id: session })));
    assert.equal(response.pageErrorsSoFar, 0);
    const r = response.result;
    if (!r.livePositive) console.log(JSON.stringify({live:r.live,shared:r.shared,plan:r.plan}));
    assert.equal(r.ids.length, 36);
    assert.equal(new Set(r.ids).size, 36);
    assert.equal(r.canonicalCount,36);
    for (const key of ['livePositive','liveNegative','cleared','roundtrip','wrongTabPreserved','malformedPreserved','aliasPriority','blankNegative','resetAliases','normalPrompt','sharedPriority','fullIncludesExposure','fullRestored','otherPreserved','detailApplied','globalPreserved','outfitPreserved','unchanged']) assert.equal(r[key], true, key);
    assert.equal(r.roundtrips.length, 9, JSON.stringify(r.roundtrips));
    if (studio) {
      assert.equal(r.plan.positive, true);
      assert.equal(r.plan.negative, true);
      assert.equal(r.shared.positivePrompt, 'exposure_positive_1138');
    }
    console.log('PASS exposure UI / live prompt / scoped JSON round trips / active preset and other fields preserved / invalid imports / unchanged game: studio=' + studio);
    await playStop({ id: session });
  }
} finally { await shutdown(); setTimeout(() => process.exit(process.exitCode || 0), 200).unref(); }
