// Isolated browser; no GPU or user saves. [--zip] [--mobile]
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {registerHooks,createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const require=createRequire(new URL('../../../../wayward-wml-ko_old/MCP/package.json',import.meta.url));
registerHooks({resolve(s,c,n){try{return n(s,c);}catch(e){if(e.code==='ERR_MODULE_NOT_FOUND'&&!s.startsWith('.')&&!s.includes(':'))return n(pathToFileURL(require.resolve(s)).href,c);throw e;}}});
const p=await import('../../../../MCP/lib/play.mjs');
const id='planner-halves',zip=process.argv.includes('--zip'),mobile=process.argv.includes('--mobile');
const version=fs.readFileSync(new URL('../source/mod.wml.js',import.meta.url),'utf8').match(/version:\s*['"]([^'"]+)/)[1];
const call=async(fn,args)=>{const r=await p.playEval({id,timeoutMs:20000,code:'return ('+fn.toString()+')('+JSON.stringify(args??null)+');'});assert.equal(r.pageErrorsSoFar,0);return r.result;};
try{
 const started=await p.playStart({id,viewport:mobile?{width:390,height:844}:{width:1500,height:1000}});assert.deepEqual(started.failed,[]);
 if(zip){const installed=await call(async v=>{
  const append=Node.prototype.appendChild;Node.prototype.appendChild=function(node){if(node.tagName==='SCRIPT'&&node.src.endsWith('/attention-image-prompt/mod.js')){queueMicrotask(()=>node.dispatchEvent(new Event('error')));return node;}return append.call(this,node);};
  try{return await WML.install([{path:'attention-image-prompt.zip',blob:await(await fetch('wml/mods/attention-image-prompt/attention-image-prompt-'+v+'-20261101.zip')).blob()}]);}finally{Node.prototype.appendChild=append;}
 },version);assert.equal(installed[0].mode,'browser');assert.deepEqual((await p.playReload({id})).failed,[]);}
 const result=await call(async()=>{
  const d=WML.dev(),b=WW_ImageStudioBridge;d.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true});d.store.get().newGame();await b.ready();
  const key='wml.mod.attention-image-prompt',initial=JSON.parse(localStorage.getItem(key)||'{}');
  const game=JSON.stringify(d.store.game()),original=structuredClone(d.fn('outfitById')('modest').halves),errors=[],checks={},diagnostic=[];let attempts=0,generated=0;
  const configs={whole:{positivePrompt:'test_edited_dress',negativePrompt:''},parts:{positivePrompt:'test_edited_dress',negativePrompt:'avoid_old_dress',topPrompt:'saved_top_1772',skirtPrompt:'saved_skirt_1772'},original:null};
  for(const [config,override] of Object.entries(configs)){
   localStorage.setItem(key,JSON.stringify({...initial,outfitPrompts:override?{...initial.outfitPrompts,modest:override}:{}}));
   const outfit=d.fn('outfitById')('modest');diagnostic.push({config,tags:outfit.imageTags,halves:outfit.halves});
   if(config==='original')checks.originalPreserved=JSON.stringify(outfit.halves)===JSON.stringify(original);
   if(config==='whole')checks.wholeHalves=typeof outfit.halves?.top==='string'&&typeof outfit.halves?.skirt==='string';
   if(config==='parts')checks.explicitPreserved=outfit.halves?.top==='saved_top_1772'&&outfit.halves?.skirt==='saved_skirt_1772';
   for(const target of ['iroha','pippa','elena'])for(const row of WW_ImageStudioMatching.matcher.exposureStates){
    const source='pippa__task-idle__outfit-modest__room-taproom__exp-'+row.value+'__v-0';
    const sel={situation:['idle'],outfit:['modest'],room:['taproom'],mood:['default'],men:['0'],exposure:[row.value==='0000000'?'none':row.value],aftermath:['none'],variant:['0']};
    attempts++;
    try{const space=b.randomSpace(target,sel,[source]);const items=space.build(0n,WW_ImageStudioPrompt.combinationSpace({}).at(0n));generated+=items.length;
     if(target==='iroha'&&row.value==='0000010'&&config==='whole'){diagnostic.push({config,target,exposure:row.value,items:items.map(x=>({key:x.talentId,prompt:x.prompt}))});checks.reportedCase=items.length>0&&items.every(x=>x.talentId.startsWith('iroha__')&&x.prompt.includes('test_edited_dress'));}
    }catch(e){errors.push({config,target,exposure:row.value,error:e.message,stack:errors.length?undefined:e.stack});}
   }
  }
  checks.gameUnchanged=JSON.stringify(d.store.game())===game;
  return {attempts,generated,checks,errors,diagnostic};
 });
 const report={version,zip,mobile,loaded:started.loaded.length,result};console.log(JSON.stringify(report,null,2));
 fs.writeFileSync(new URL('planner-halves-'+(zip?'zip':'source')+(mobile?'-mobile':'-pc')+'.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
 {assert.deepEqual(result.errors,[]);assert.ok(Object.values(result.checks).every(Boolean));}
}finally{await p.shutdown();}
