// Actual UI downloads/file inputs in a disposable browser. [--mobile] [--zip]
import fs from 'node:fs';import assert from 'node:assert/strict';
import {createRequire,registerHooks} from 'node:module';import {pathToFileURL} from 'node:url';
const req=createRequire(new URL('../../../../wayward-wml-ko_old/MCP/package.json',import.meta.url));
registerHooks({resolve(s,c,n){try{return n(s,c);}catch(e){if(e.code==='ERR_MODULE_NOT_FOUND'&&!s.startsWith('.')&&!s.includes(':'))return n(pathToFileURL(req.resolve(s)).href,c);throw e;}}});
const p=await import('../../../../MCP/lib/play.mjs');const id='aip-tab-json',mobile=process.argv.includes('--mobile'),zip=process.argv.includes('--zip');
const version=fs.readFileSync(new URL('../source/mod.wml.js',import.meta.url),'utf8').match(/version:\s*['"]([^'"]+)/)[1];
const call=async(fn,args)=>{const r=await p.playEval({id,timeoutMs:20000,code:'return ('+fn.toString()+')('+JSON.stringify(args??null)+');'});assert.equal(r.pageErrorsSoFar,0,JSON.stringify(r));return r.result;};
try{
 const loaded=await p.playStart({id,viewport:mobile?{width:390,height:844}:{width:1500,height:1000}});assert.deepEqual(loaded.failed,[]);
 if(zip){const r=await call(async version=>{
  const append=Node.prototype.appendChild;Node.prototype.appendChild=function(node){if(node.tagName==='SCRIPT'&&node.src.endsWith('/attention-image-prompt/mod.js')){queueMicrotask(()=>node.dispatchEvent(new Event('error')));return node;}return append.call(this,node);};
  try{return await WML.install([{path:'attention-image-prompt.zip',blob:await(await fetch('wml/mods/attention-image-prompt/attention-image-prompt-'+version+'-20261101.zip')).blob()}]);}finally{Node.prototype.appendChild=append;}
 },version);assert.equal(r[0].mode,'browser');assert.deepEqual((await p.playReload({id})).failed,[]);}
 const result=await call(async()=>{
  const d=WML.dev();d.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true});d.store.get().newGame();await WW_ImageStudioBridge.ready();WW_ImageStudioPrompt.open();
  const sleep=()=>new Promise(r=>setTimeout(r,45)),root=()=>document.querySelector('[data-wwis-aip-editor]'),storage='wml.mod.attention-image-prompt';await sleep();
  const read=()=>JSON.parse(localStorage.getItem(storage));const original=JSON.stringify(d.store.game());
  const blobs=new Map(),downloads=[],created=URL.createObjectURL,anchor=HTMLAnchorElement.prototype.click;
  URL.createObjectURL=function(blob){const url=created.call(URL,blob);blobs.set(url,blob);return url;};
  HTMLAnchorElement.prototype.click=function(){if(blobs.has(this.href)){downloads.push(blobs.get(this.href));return;}return anchor.call(this);};
  const choose=async tab=>{const s=root().querySelector('[data-aip-mobile-tab]');s.value=tab;s.dispatchEvent(new Event('change'));await sleep();};
  const save=async()=>{root().querySelector('[data-aip-tab-json-save]').click();for(let i=0;i<80&&!root().textContent.includes('탭 설정을 저장했습니다.');i++)await new Promise(r=>setTimeout(r,25));if(!root().textContent.includes('탭 설정을 저장했습니다.'))throw Error('JSON save did not complete');return JSON.parse(await downloads.at(-1).text());};
  const load=async value=>{const input=root().querySelector('[data-aip-tab-json-input]'),dt=new DataTransfer();dt.items.add(new File([JSON.stringify(value)],'tab.json',{type:'application/json'}));input.files=dt.files;input.dispatchEvent(new Event('change'));for(let i=0;i<80&&input.value;i++)await new Promise(r=>setTimeout(r,25));if(input.value)throw Error('JSON import did not complete');await sleep();};
  const tabs=[...root().querySelector('[data-aip-mobile-tab]').options].map(o=>o.value),rows=[];
  try{
   for(const tab of tabs){await choose(tab);const box=root().querySelector('[data-aip-tab-json]');if(!box){rows.push({tab,excluded:true});continue;}
    const data=await save(),before=read();await load(data);const after=read(),imported=root().textContent.includes('탭 설정을 불러왔습니다.'),message=imported?'':root().querySelector('main')?.innerText.slice(0,1200);
    const owned=new Set(Object.keys(data).filter(k=>!['format','version','scope','tabId','presetId'].includes(k)));
    const untouched=Object.keys(before).every(key=>owned.has(key)||JSON.stringify(before[key])===JSON.stringify(after[key]));
    const beforeWrong=localStorage.getItem(storage);await load({...data,tabId:'wrong-tab'});
    rows.push({tab,saved:data.scope==='tab'&&data.tabId===tab,untouched,wrongRejected:localStorage.getItem(storage)===beforeWrong,
      imported,message});
   }
   await choose('general');let data=await save();const field=Object.keys(data.prompts)[0],state=read();
   localStorage.setItem(storage,JSON.stringify({...state,situationPresets:[{id:'tab-test-a',name:'A',prompts:{[field]:'a-before',unknown_extension:'keep-unknown'}},{id:'tab-test-b',name:'B',prompts:{[field]:'b-keep'}}]}));
   await choose('situation-presets');let select=root().querySelector('[data-situation-preset-editor]');select.value='tab-test-a';select.dispatchEvent(new Event('change'));await sleep();await choose('general');
   const beforePreset=read();await load({...data,prompts:{[field]:''},negativePrompts:{[field]:'negative-tab-test'}});
   const afterPreset=read(),a=afterPreset.situationPresets.find(x=>x.id==='tab-test-a');
   const presetChecks={unknownPreserved:a.prompts.unknown_extension==='keep-unknown',empty:a.prompts[field]==='',negative:a.negativePrompts[field]==='negative-tab-test',otherPreset:JSON.stringify(afterPreset.situationPresets.find(x=>x.id==='tab-test-b'))===JSON.stringify(beforePreset.situationPresets.find(x=>x.id==='tab-test-b')),base:JSON.stringify(afterPreset.prompts)===JSON.stringify(beforePreset.prompts)};
   const invalidBefore=localStorage.getItem(storage);await load({...data,prompts:{[field]:42}});presetChecks.invalidAtomic=localStorage.getItem(storage)===invalidBefore;
   await choose('outfit-prompts');const beforeFull=read();await load({format:'wayward-state-image-prompts',version:23,outfitPrompts:{modest:{positivePrompt:'json-outfit-test',negativePrompt:''}},prompts:{[field]:'must-not-leak'},shortImageKeys:!beforeFull.shortImageKeys});
   const afterFull=read();presetChecks.fullScoped=afterFull.outfitPrompts.modest.positivePrompt==='json-outfit-test'&&JSON.stringify(afterFull.prompts)===JSON.stringify(beforeFull.prompts)&&afterFull.shortImageKeys===beforeFull.shortImageKeys;
   const fields=read();localStorage.setItem(storage,JSON.stringify({...fields,positionModulePrompts:{'pose-1':{positivePrompt:'pose-keep',negativePrompt:''},'climax-1':{positivePrompt:'climax-save',negativePrompt:''}}}));
   await choose('climax-prompts');const climax=await save();
   localStorage.setItem(storage,JSON.stringify({...read(),positionModulePrompts:{'pose-1':{positivePrompt:'pose-changed',negativePrompt:''},'climax-1':{positivePrompt:'climax-changed',negativePrompt:''}}}));
   await load(climax);const final=read();presetChecks.climaxPartition=final.positionModulePrompts['pose-1'].positivePrompt==='pose-changed'&&final.positionModulePrompts['climax-1'].positivePrompt==='climax-save';
   await choose('outfit-prompts');
   presetChecks.gameUnchanged=JSON.stringify(d.store.game())===original;
   return {rows,presetChecks};
  }finally{URL.createObjectURL=created;HTMLAnchorElement.prototype.click=anchor;}
 });
 const status=await p.playStatus({id});console.log(JSON.stringify({version,mobile,zip,loaded:loaded.loaded.length,result,pageErrors:status.pageErrors},null,2));
 assert.deepEqual(status.pageErrors,[]);assert.ok(result.rows.filter(r=>!r.excluded).every(r=>r.saved&&r.untouched&&r.wrongRejected&&r.imported));assert.ok(Object.values(result.presetChecks).every(Boolean));
 fs.writeFileSync(new URL('tab-json-'+(zip?'zip-':'')+(mobile?'mobile':'pc')+'.json',import.meta.url),JSON.stringify({version,mobile,zip,result},null,2)+'\n');
 fs.writeFileSync(new URL('tab-json-'+(zip?'zip-':'')+(mobile?'mobile':'pc')+'.jpg',import.meta.url),Buffer.from(await p.playScreenshot({id}),'base64'));
}finally{await p.shutdown();}
