// Isolated WML/DOM integration. Never queues work or touches user browser storage.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL } from 'node:url';
const req = createRequire(new URL('../../../../wayward-wml-ko_old/MCP/package.json', import.meta.url));
registerHooks({ resolve(s,c,n) { try { return n(s,c); } catch(e) {
  if(e.code==='ERR_MODULE_NOT_FOUND'&&!s.startsWith('.')&&!s.includes(':')) return n(pathToFileURL(req.resolve(s)).href,c); throw e;
} } });
const p = await import('../../../../MCP/lib/play.mjs');
const mobile = process.argv.includes('--mobile'), zip = process.argv.includes('--zip');
const versions = Object.fromEntries(['attention-image-prompt','imagestudio-compatible-attention-image-prompt'].map(id =>
  [id,fs.readFileSync(new URL('../../'+id+'/source/mod.wml.js',import.meta.url),'utf8').match(/version:\s*['"]([^'"]+)/)[1]]));
const mods = Object.fromEntries([...fs.readFileSync(new URL('../../mods.js',import.meta.url),'utf8').matchAll(/"([^"\n]+)"/g)].map(m=>[m[1],false]));
const results=[];
const call=async(id,fn,arg)=>{const r=await p.playEval({id,timeoutMs:20000,code:'return ('+fn.toString()+')('+JSON.stringify(arg??null)+');'});assert.equal(r.pageErrorsSoFar,0);return r.result;};
try {
  for (const standalone of [false,true]) {
    const id='aip-selection-'+standalone;
    const started=await p.playStart({id,viewport:mobile?{width:390,height:844}:{width:1500,height:1000},
      mods:standalone?{...mods,'attention-image-prompt':true}:{}});
    assert.deepEqual(started.failed,[]);
    if(zip) {
      const packages=standalone?{'attention-image-prompt':versions['attention-image-prompt']}:versions;
      const installed=await call(id,async packages=>{
        const append=Node.prototype.appendChild;
        Node.prototype.appendChild=function(node){if(node.tagName==='SCRIPT'&&Object.keys(packages).some(id=>node.src.endsWith('/'+id+'/mod.js'))){queueMicrotask(()=>node.dispatchEvent(new Event('error')));return node;}return append.call(this,node);};
        try{return await WML.install(await Promise.all(Object.entries(packages).map(async([id,v])=>({path:id+'.zip',blob:await(await fetch('wml/mods/'+id+'/'+id+'-'+v+'-20261101.zip')).blob()}))));}
        finally{Node.prototype.appendChild=append;}
      },packages);
      assert.ok(installed.every(row=>row.mode==='browser'));assert.deepEqual((await p.playReload({id})).failed,[]);
    }
    const result=await call(id,async standalone=>{
      const d=WML.dev();d.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true});d.store.get().newGame();
      if(!standalone)await WW_ImageStudioBridge.ready();
      const game=JSON.stringify(d.store.game()),store='wml.mod.attention-image-prompt',initial=JSON.parse(localStorage.getItem(store)||'{}');
      const key='iroha__task-idle__outfit-modest__room-taproom__v-0',v1=key.replace('__v-0','__v-1');
      const target='pippa__task-cleaning__outfit-modest__room-taproom__v-0',source=target.replace('outfit-modest','outfit-barmaid_corset');
      const preferred={...initial,unusedPortraitImages:{[key.replace('__v-0','')]:[key]},
        similarImageChoices:{[target.replace('__v-0','')]:{keys:[source],mode:'selected'}},
        residueImageChoices:{'situation_status__pippa__diagnostic':{selected:'diagnostic-choice'}}};
      const rows=[];
      for(const enabled of standalone?[null]:[true,false]) {
        if(enabled!==null)WW_ImageStudioMatching.set({...WW_ImageStudioMatching.get(),enabled});
        localStorage.setItem(store,JSON.stringify(initial));
        d.fn('Ip')(key,{variants:[key,v1],currentIdx:0});
        localStorage.setItem(store,JSON.stringify(preferred));
        const variants=d.fn('NB')(key);
        d.fn('Ip')(key,{variants:[key,v1],currentIdx:0});
        const saved=d.fn('NB')(key);
        const portraitHook=d.hooks.get('bee'),portraitOld={orig:portraitHook.orig,around:portraitHook.around,after:portraitHook.after};
        let portraitKey;
        try {
          portraitHook.orig=()=>key;
          portraitHook.around=portraitHook.around.filter(row=>row.owner==='attention-image-prompt');
          portraitHook.after=portraitHook.after.filter(row=>row.owner==='attention-image-prompt');
          portraitKey=d.fn('bee')(d.store.game());
        } finally {Object.assign(portraitHook,portraitOld);}
        // Keep the real AIP wrappers but use a deterministic native catalogue and HEAD result.
        const hook=d.hooks.get('vy'),old={orig:hook.orig,before:hook.before,around:hook.around,after:hook.after,replace:hook.replace},fetchOriginal=window.fetch;
        let found;
        try {
          for(const group of ['before','around','after'])hook[group]=hook[group].filter(row=>row.owner==='attention-image-prompt');
          hook.replace=hook.replace?.owner==='attention-image-prompt'?hook.replace:null;
          hook.orig=k=>({talentName:k,imagePath:'diagnostic.webp',imageType:'portrait',source:'server'});
          window.fetch=(url,options)=>options?.method==='HEAD'?Promise.resolve(new Response(null,{status:200})):fetchOriginal(url,options);
          found=await d.fn('vy')(target);
        } finally {Object.assign(hook,old);window.fetch=fetchOriginal;}
        rows.push({enabled,variants:variants.variants,saved:saved.variants,portraitKey,resolved:found?.talentName});
      }
      // A synthetic portrait exercises the actual observer; these are not real user images.
      const portrait=document.createElement('div');portrait.className='relative overflow-hidden bg-stone-800 cursor-pointer';
      const attributes=['data-attention-position-quick','data-attention-similar-images','data-attention-scene-prompt-entry','data-attention-camera-entry'];
      if(!standalone)for(const attr of attributes){const b=document.createElement('button');b.setAttribute(attr,'');portrait.append(b);}
      (document.getElementById('root')||document.body).append(portrait);
      await new Promise(r=>setTimeout(r,600));
      const buttons=attributes.map(attr=>!!portrait.querySelector('['+attr+']'));
      portrait.remove();
      let promptPreserved=true,editorVersion=null;
      if(!standalone){
        const selected={},combination=WW_ImageStudioPrompt.combinationSpace(selected).at(0n);
        const item=WW_ImageStudioBridge.fromKey('iroha',key,selected,true,combination)[0];
        promptPreserved=!!item?.prompt&&item.talentId.startsWith('iroha__');
        WW_ImageStudioPrompt.open();await new Promise(r=>setTimeout(r,80));
        editorVersion=document.querySelector('[data-wwis-aip-editor]')?.getAttribute('data-wwis-aip-editor');
      }
      localStorage.setItem(store,JSON.stringify(initial));
      return {rows,buttons,promptPreserved,editorVersion,gameUnchanged:JSON.stringify(d.store.game())===game};
    },standalone);
    const key='iroha__task-idle__outfit-modest__room-taproom__v-0',v1=key.replace('__v-0','__v-1');
    for(const row of result.rows){assert.deepEqual(row.variants,standalone?[v1]:[key,v1]);assert.deepEqual(row.saved,standalone?[v1]:[key,v1]);assert.equal(row.portraitKey,standalone?v1:key);
      assert.equal(row.resolved,standalone?'pippa__task-cleaning__outfit-barmaid_corset__room-taproom__v-0':'pippa__task-cleaning__outfit-modest__room-taproom__v-0');}
    assert.ok(result.buttons.every(value=>value===standalone),JSON.stringify(result));
    assert.equal(result.promptPreserved,true);assert.equal(result.gameUnchanged,true);
    if(!standalone)assert.equal(result.editorVersion,versions['attention-image-prompt']);
    const status=await p.playStatus({id});assert.deepEqual(status.pageErrors,[]);
    results.push({standalone,loaded:started.loaded.length,...result});console.log(JSON.stringify(results.at(-1)));
  }
  fs.writeFileSync(new URL('studio-selection-'+(zip?'zip-':'')+(mobile?'mobile':'pc')+'.json',import.meta.url),JSON.stringify({versions,mobile,zip,results},null,2)+'\n');
} finally {await p.shutdown();}
