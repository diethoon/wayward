// 모더용 예제입니다. 이 파일은 AIP가 자동 실행하지 않습니다.
// 새 모드의 mod.js로 복사할 때 id와 이름을 바꾸세요.
WML.define({
  id: 'aip-example-mod',
  name: { ko: 'AIP 연결 예제', en: 'AIP integration example' },
  version: '1.0.0',
  author: 'AIP example',
  tags: ['image', 'prompt'],
  requires: ['attention-image-prompt'],
  requiresVersion: { 'attention-image-prompt': '>=1.52.0' },
  symbols: {
    "imagePlanList": {"raw":{"2026-10-04":"r6e"},"find":{"all":["\"elena_farmgirl\""],"len":3258,"any":[".exposureLimit",".sexVariants","patronScene:",".maxEntries",".aftermaths",".archetype"]},"optional":true}
  },
  setup(api) {
    const aip = api.use('attention-image-prompt');
    const owner = 'aip-example-mod';
    const entry = 'example-scene';
    const promptGenParams = api.fn('promptGenParams');

    // 이 독립 항목은 예제로 침실에만 적용합니다. 실제 모드의 장면 조건으로 바꾸세요.
    const applies = room => room === 'bedroom';
    const keyForExample = key => {
      if (typeof key !== 'string' || key.includes('__aip-example-')) return key;
      const token = aip.cacheToken(owner, entry);
      return token ? key.replace(/(__v-\d+)?$/, `__aip-example-${token}$1`) : key;
    };
    api.hook('imageKey', {
      after(key, [, room]) { return applies(room) ? keyForExample(key) : key; },
    });
    api.hook('imagePrompt', {
      after(result, [, room]) {
        if (!applies(room) || !result || !Array.isArray(result.parts)) return result;
        const selected = aip.resolve(owner, entry);
        if (!selected) return result;
        const prompt = [result.prompt, selected.positivePrompt].filter(Boolean).join(', ');
        return { ...result, key: keyForExample(result.key), prompt,
          negativePrompt: [result.negativePrompt, selected.negativePrompt].filter(Boolean).join(', '),
          parts: [...result.parts, { label: 'AIP 연결 예제', tags: selected.positivePrompt }],
          genParams: promptGenParams(prompt) };
      },
    });
    // 게임 사전 생성 목록은 imageKey 훅을 거치지 않을 수 있습니다.
    if (api.has('imagePlanList')) api.hook('imagePlanList', {
      after(result) {
        if (!Array.isArray(result)) return result;
        return result.map(item => typeof item?.talentId === 'string' && /__room-bedroom(?:__|$)/.test(item.talentId)
          ? { ...item, talentId: keyForExample(item.talentId) } : item);
      },
    });

    // 내 모드의 독립 기능이 자기 이미지 요청을 만들 때 이 값을 사용합니다.
    // 키와 프롬프트는 반드시 같은 조건에서 함께 사용하세요.
    api.provide({
      examplePrompt() {
        const selected = aip.resolve(owner, 'example-scene');
        return selected && {
          positivePrompt: selected.positivePrompt,
          negativePrompt: selected.negativePrompt,
          cacheToken: aip.cacheToken(owner, 'example-scene'),
        };
      },
    });

    // 등록은 setup의 마지막에 수행합니다. register가 반환하는 함수로 등록을 해제할 수 있습니다.
    aip.register({
      id: owner,
      title: 'AIP 연결 예제',
      note: '수면 항목은 AIP가 적용하며, 독립 항목은 이 모드가 직접 사용합니다.',
      entries: [
        {
          id: 'light-sleep', label: '얕은 수면', hook: 'imagePrompt',
          aipField: 'sleep.light',
          positivePrompt: 'light sleep, relaxed expression',
          negativePrompt: 'wide awake',
        },
        {
          id: 'example-scene', label: '독립 장면 · 침실', hook: 'imagePrompt / imageKey',
          positivePrompt: 'warm light', negativePrompt: 'harsh lighting',
        },
        {
          id: 'modest-outfit', label: '단정한 의상', hook: 'outfitById',
          target: { kind: 'outfit', id: 'modest' },
          positivePrompt: 'blue blouse, white skirt', negativePrompt: 'red dress',
          topPrompt: 'blue blouse', skirtPrompt: 'white skirt',
        },
        {
          id: 'doggystyle-pose', label: '후배위 체위', hook: 'imagePrompt',
          target: { kind: 'position-preset', id: 'doggystyle' },
          positivePrompt: 'doggystyle, rear view', negativePrompt: 'front view',
        },
      ],
    });
  },
});
