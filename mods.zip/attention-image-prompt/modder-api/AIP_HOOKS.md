# AIP가 사용하는 WML 훅

이 목록은 AIP가 게임에 등록하는 WML 훅을 설명합니다. 훅 이름은 WML 심볼 이름이며, 외부 모드가 AIP의 설정 화면에 항목을 등록하는 API와는 별개입니다. 외부 모드 연결 방법과 실행 가능한 예제는 [모더 API 안내](./MODDER_API.md)를 참고하세요.

| WML 심볼 | AIP에서 하는 일 | 단계 |
| --- | --- | --- |
| `imageManifest` | AIP 이미지팩 항목을 이미지 목록에 합침 | around, 선택적 |
| `imagePackReset` | pre7 원본 설치 팩 매칭 목록을 무효화하고 다시 읽음 | before, 선택적 |
| `imageUrl` | AIP 이미지팩 항목의 경로를 URL로 변환 | after, 선택적 |
| `wifePicker` | 구형 게임에 캐릭터 선택 도구 추가, pre7은 원본 선택창 유지 | after |
| `wifeBuilderDefaults` | 캐릭터 작성 기본값 추가 | after |
| `wifeBuilder` | 캐릭터 작성 화면 확장 | after |
| `buildWifeArchetype` | 입력한 캐릭터 프롬프트와 메타데이터 보존 | after |
| `wifeCharacterFromArchetype` | 캐릭터의 대사 원형 연결 | after |
| `wifePreviewBundle` | 캐릭터 미리보기 Positive/Negative 조합 | after |
| `imagePreGenerateDialog` | 사전 생성 캐릭터와 표시 이름 연결 | before, after |
| `imagePlanEntry` | 사전 생성 실행 범위 표시 | around |
| `imagePlanCharacter` | 사전 생성용 캐릭터 구성 | around |
| `imagePlanList` | 사전 생성 후보의 캐릭터·사용자 의상 키 보정 | after |
| `imageQueue` | 사전 생성 항목의 이미지 재사용·키 처리 | around |
| `imageGenerate` | 생성 요청의 키·프롬프트 처리, 초상화 카메라 구도의 생성 시 선택 및 결과 기록 | before, around, after; 선택적 |
| `outfitById` | 의상 전체 및 부분 탈의 상·하의 프롬프트 오버라이드 | after |
| `imageLookup` | 기존 이미지와 변형 이미지 검색 | around |
| `imageVariantState` | 초상화 변형 선택 상태 읽기 | after, 선택적 |
| `saveImageVariantState` | 초상화 변형 선택 상태 저장 | around, 선택적 |
| `currentPortraitImageKey` | 초상화 이미지 키·변형 선택 및 선택 후 결과 장면 확인 | around, after, 선택적 |
| `reduceGameAction` | 공통 사건 선택지의 결과 장면 확인. 게임 상태는 수정하지 않음 | before, after, 선택적 |
| `imageKey` | 장면 인자 보정과 상황별 이미지 키 구성 | before, after |
| `imagePrompt` | 장면 인자 보정, 확인된 원본 장면 Positive 교체, 상황 프롬프트·카메라 구도와 최종 태그 규칙 적용 | before, around, after |
| `heroineOrgasm` | 절정 장면 상태 기록 | after |

`imageKey`와 `imagePrompt`는 여러 훅이 공유할 수 있습니다. 모드 로드 순서와 WML 훅 우선순위에 따라 결과가 달라질 수 있으므로, 다른 모드의 결과를 무조건 덮어쓰지 말고 `result`와 `parts`를 보존해 필요한 부분만 바꾸세요. WML 버전과 게임 빌드에 따라 선택적 심볼이 없을 수 있습니다. 자신의 모드가 선택적으로 사용하는 심볼은 `api.has()`로 확인하세요. 심볼 정의와 훅 계약은 해당 설치본의 WML `docs/SDK.md`를 따릅니다.

1.74.0의 카메라 구도는 초상화 요청의 `imagePrompt`와 `imageGenerate`에서만 AIP가 자동 처리합니다. 여러 구도는 생성 직전에 하나를 선택하며 이미지 키별 기록과 재시도 시 선택을 유지합니다. 독립 서버 직접 요청·별도 대기열·H-Status는 자동 적용 대상이 아닙니다. 외부 모드는 `cameraController` API와 사용자 선택 범위를 확인하고 자신이 관리하는 요청·캐시 키에 일관되게 연결하세요. `style-lock`의 POV 제거, 전역 제거 등 이후 처리로 태그가 빠질 수 있으므로 해당 모드의 설정을 변경하거나 중복 후킹하지 마세요.

1.75.0부터 ImageStudio가 연결 상태 때문에 초상화 생성을 미룬 경우, AIP는 게임의 `imageBackendProbe`로 현재 서버 상태를 다시 확인한 뒤 기존 생성 경로를 재시도합니다. 게임 이미지 생성 끔 또는 ImageStudio 오프라인 전용 설정은 유지합니다. 이 재확인은 게임의 공통 연결 상태를 갱신하며 외부 모드가 별도로 직접 보내는 요청에는 적용되지 않습니다.

1.76.0부터 카메라 구도를 적용할 때 촬영 기기·녹화 UI 방지 공통 Negative가 추가됩니다. 목록은 `cameraController.list().negativeDefaults`에서 확인하며 사용자 문구는 보존합니다. 선택하지 않은 장면이나 독립 요청에는 자동으로 추가되지 않습니다.

1.76.1은 이 공통 목록에 카메라 본체·삼각대 등 물리적인 장비와 화면 UI 표현을 더합니다. 활성 구도의 이미지 키와 `cacheToken`은 공통 Negative 변경에 따라 갱신되므로 호출자가 반환한 토큰을 그대로 사용하세요.

1.76.2의 기본 구도 Positive는 촬영 기기 이름을 사용하지 않습니다. 사용자가 승인한 이전 기본값과 정확히 일치하는 저장 구도만 새 기본 문구로 전환하며, 직접 수정한 문구와 기존 이미지 기록은 유지합니다. 카메라 설정 JSON은 `cameraPresetRevision`으로 전환 여부를 추적합니다.

1.76.3의 기본 구도에는 `view` 시점 표현을 추가하며, 이전 기본값에 정확히 일치하는 저장 구도만 새 값으로 전환합니다.

`cameraController.apply()`로 적용한 미저장 설정은 창을 닫거나 장면을 이동해도 현재 세션에 유지되며 `get().dirty`로 확인할 수 있습니다. `set()`은 저장 후 초안을 지우고, 새로고침이나 JSON 가져오기는 임시 초안을 지웁니다. 생성 이미지 기록은 별도로 저장됩니다. 실제 화면 새로고침은 API 호출자가 담당합니다.

카메라 Positive는 확인된 품질·기본 캐릭터 문구 뒤에 들어갑니다. 외부 요청에서 동일한 배치를 원하면 `cameraController.preview()`의 `options.parts`에 원본 `imagePrompt.parts`를 전달하세요. 식별 가능한 기본 부분이 없으면 선두에 배치하며 반환값 `placement`가 `after-base` 또는 `fallback`인지 확인할 수 있습니다.

일부 다른 모드는 WML 훅 외부에서 함수를 감쌀 수 있습니다. 위 목록만으로 모든 모드의 호출 순서나 실제 최종 생성 요청을 보장할 수는 없습니다.

1.58.1부터 프롬프트 관리자 0.3.1의 재생성에는 AIP를 먼저 로드합니다. 관리자가 리뷰의 원본 키로 편집값을 적용한 뒤 서버 전송 키를 축약하며, 원본 리뷰 요청은 변경하지 않습니다. 이 연결은 별도 공개 API가 아니라 해당 모드의 기존 요청 방식에 대한 호환 처리입니다.

pre7에서는 이미지스튜디오 브리지의 팩과 사용자 캐릭터 조회도 연결합니다. 별도 `imagestudio-native-packs` 모드가 켜진 경우 그 모드가 연결을 맡습니다.
