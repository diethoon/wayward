# AIP 연결 가능한 상황·상태 필드

AIP 1.52.0의 listFields() 결과입니다. key를 aipField에 지정하세요. 조건과 프리셋은 AIP가 처리합니다. 의상·체위는 [모더 API 안내](./MODDER_API.md)의 target 연결을 참고하세요.

| 그룹 | 항목 | aipField |
| --- | --- | --- |
| 기본 상황 | 대응 필요 · 긴급/고조 | attention.escalation |
| 기본 상황 | 대응 필요 · 보이지 않는 상황 | attention.unwatched |
| 기본 상황 | 대응 필요 · 문제 발생 | attention.trouble |
| 기본 상황 | 대응 필요 · 기진맥진 | attention.spent |
| 기본 상황 | 수갑을 채웠음 | restraint.handcuffed |
| 상세 상태 | 기력 0–19 | status.energy.0 |
| 상세 상태 | 기력 20–39 | status.energy.1 |
| 상세 상태 | 기력 40–59 | status.energy.2 |
| 상세 상태 | 기력 60–79 | status.energy.3 |
| 상세 상태 | 기력 80–100 | status.energy.4 |
| 상세 상태 | 기분 0–19 | status.mood.0 |
| 상세 상태 | 기분 20–39 | status.mood.1 |
| 상세 상태 | 기분 40–59 | status.mood.2 |
| 상세 상태 | 기분 60–79 | status.mood.3 |
| 상세 상태 | 기분 80–100 | status.mood.4 |
| 상세 상태 | 흥분도 0–19 | status.arousal.0 |
| 상세 상태 | 흥분도 20–39 | status.arousal.1 |
| 상세 상태 | 흥분도 40–59 | status.arousal.2 |
| 상세 상태 | 흥분도 60–79 | status.arousal.3 |
| 상세 상태 | 흥분도 80–100 | status.arousal.4 |
| 상세 상태 | 심신 상태 0–19 | status.wellbeing.0 |
| 상세 상태 | 심신 상태 20–39 | status.wellbeing.1 |
| 상세 상태 | 심신 상태 40–59 | status.wellbeing.2 |
| 상세 상태 | 심신 상태 60–79 | status.wellbeing.3 |
| 상세 상태 | 심신 상태 80–100 | status.wellbeing.4 |
| 상세 상태 | 주목도 60 이상 | status.allure.high |
| 상세 상태 | 신뢰 30 미만 | status.trust.low |
| 상세 상태 | 애정·욕망 60 이상 | status.desire.high |
| 상세 상태 | 원망도 35–59 | status.resentment.medium |
| 상세 상태 | 원망도 60 이상 | status.resentment.high |
| 상세 상태 | 심적 이탈 35 이상 | status.drift.high |
| 상세 상태 | 허용 인식 0 미만 | status.latitude.negative |
| 상세 상태 | 취기 · 살짝 취함 | status.intoxication.tipsy |
| 상세 상태 | 취기 · 취함 | status.intoxication.drunk |
| 상세 상태 | 취기 · 만취 | status.intoxication.wasted |
| 상세 상태 | 취기 · 몸을 못 가눔 | status.intoxication.sloppy |
| 상세 상태 | 취기 · 의식 없음 | status.intoxication.blacked_out |
| 상세 상태 | 강한 감정 매핑 | status.feelings.map |
| 상세 상태 | 가장 강한 욕구 매핑 | status.drives.map |
| 임신 상태 | 임신 초기 · 수태 후 0–1일 | pregnancy.early |
| 임신 상태 | 임신 중기 · 수태 후 2일 | pregnancy.middle |
| 임신 상태 | 임신 후기 · 수태 후 3일 이상 | pregnancy.late |
| 생리 상태 | 월경기 · 음부 | cycle.vulva.menstrual |
| 생리 상태 | 난포기 · 음부 | cycle.vulva.follicular |
| 생리 상태 | 배란기 · 음부 | cycle.vulva.ovulation |
| 생리 상태 | 황체기 · 음부 | cycle.vulva.luteal |
| 첫경험 | 첫 질 삽입 · 표정과 혈흔 | firstExperience.vaginal |
| 수면 중 관계 | 얕은 잠 · 곧 깨어남 | sleep.light |
| 수면 중 관계 | 보통 잠 | sleep.middle |
| 수면 중 관계 | 깊은 잠 | sleep.deep |
| 수면 중 관계 | 삽입 직전 깨어남 · 측위 입구 맞댐 | sleep.waking-rub |
| 에로스테 크기 | 크기 · 여유 | erostat.fit.loose |
| 에로스테 크기 | 크기 · 꼭 맞음 | erostat.fit.snug |
| 에로스테 크기 | 크기 · 꽉 참 | erostat.fit.full |
| 에로스테 크기 | 크기 · 버거움 | erostat.fit.strain |
| 에로스테 크기 | 크기 · 한계 | erostat.fit.limit |
| 에로스테 크기 | 크기 · 여유 | erostat.anal.loose |
| 에로스테 크기 | 크기 · 꼭 맞음 | erostat.anal.snug |
| 에로스테 크기 | 크기 · 꽉 참 | erostat.anal.full |
| 에로스테 크기 | 크기 · 버거움 | erostat.anal.strain |
| 에로스테 크기 | 크기 · 한계 | erostat.anal.limit |
| 손찌검 흔적 | 뺨 · 흔적 1단계 | mark.slap.1 |
| 손찌검 흔적 | 뺨 · 흔적 2단계 | mark.slap.2 |
| 손찌검 흔적 | 뺨 · 흔적 3단계 | mark.slap.3 |
| 손찌검 흔적 | 가슴 · 흔적 1단계 | mark.breast.1 |
| 손찌검 흔적 | 가슴 · 흔적 2단계 | mark.breast.2 |
| 손찌검 흔적 | 가슴 · 흔적 3단계 | mark.breast.3 |
| 손찌검 흔적 | 엉덩이 · 흔적 1단계 | mark.butt.1 |
| 손찌검 흔적 | 엉덩이 · 흔적 2단계 | mark.butt.2 |
| 손찌검 흔적 | 엉덩이 · 흔적 3단계 | mark.butt.3 |
| 손찌검 흔적 | 음부 · 흔적 1단계 | mark.sex.1 |
| 손찌검 흔적 | 음부 · 흔적 2단계 | mark.sex.2 |
| 손찌검 흔적 | 음부 · 흔적 3단계 | mark.sex.3 |
| 손찌검 흔적 | 배 · 흔적 1단계 | mark.belly.1 |
| 손찌검 흔적 | 배 · 흔적 2단계 | mark.belly.2 |
| 손찌검 흔적 | 배 · 흔적 3단계 | mark.belly.3 |
| H Status | 입 · 없음 | fluid.mouth.0 |
| H Status | 입 · 흔적이 남음 | fluid.mouth.1 |
| H Status | 입 · 묻어 있음 | fluid.mouth.2 |
| H Status | 입 · 많이 묻어 있음 | fluid.mouth.3 |
| H Status | 입 · 넘쳐남 | fluid.mouth.4 |
| H Status | 가슴 · 없음 | fluid.breasts.0 |
| H Status | 가슴 · 흔적이 남음 | fluid.breasts.1 |
| H Status | 가슴 · 묻어 있음 | fluid.breasts.2 |
| H Status | 가슴 · 많이 묻어 있음 | fluid.breasts.3 |
| H Status | 가슴 · 넘쳐남 | fluid.breasts.4 |
| H Status | 자궁 · 없음 | fluid.uterus.0 |
| H Status | 자궁 · 질내 잔류 | fluid.uterus.1 |
| H Status | 자궁 · 자궁 내 일부 | fluid.uterus.2 |
| H Status | 자궁 · 가득참 | fluid.uterus.3 |
| H Status | 자궁 · 넘쳐남 | fluid.uterus.4 |
| H Status | 보지 · 건조함 | fluid.vulva.0 |
| H Status | 보지 · 은은하게 젖음 | fluid.vulva.1 |
| H Status | 보지 · 애액이 맺힘 | fluid.vulva.2 |
| H Status | 보지 · 허벅지 안쪽까지 흐름 | fluid.vulva.3 |
| H Status | 보지 · 애액이 허벅지를 타고 흐름 | fluid.vulva.4 |
| H Status | 허벅지 · 없음 | fluid.thighs.0 |
| H Status | 허벅지 · 흔적이 남음 | fluid.thighs.1 |
| H Status | 허벅지 · 묻어 있음 | fluid.thighs.2 |
| H Status | 가슴 · 장신구 없음 | jewelry.breasts.0 |
| H Status | 가슴 · 좌측 유두 피어싱 | jewelry.breasts.1 |
| H Status | 가슴 · 양쪽 유두 피어싱 | jewelry.breasts.2 |
| H Status | 가슴 · 양쪽 유두 피어싱 · 하트 초커 | jewelry.breasts.3 |
| H Status | 보지 · 장신구 없음 | jewelry.vulva.0 |
| H Status | 보지 · 클리 피어싱 | jewelry.vulva.1 |
| H Status | 보지 · 에그 바이브 장착 | toy.vulva.egg |
| H Status | 보지 · 자지형 바이브 장착 | toy.vulva.penis |
| H Status | 최면 · 0단계 | hstatus.hypnosis.0 |
| H Status | 최면 · 1단계 | hstatus.hypnosis.1 |
| H Status | 최면 · 2단계 | hstatus.hypnosis.2 |
| H Status | 최면 · 3단계 | hstatus.hypnosis.3 |
| H Status | 최면 · 4단계 | hstatus.hypnosis.4 |
| H Status | 최면 · 5단계 | hstatus.hypnosis.5 |
| H Status | 음문 · 0단계 | hstatus.crest.0 |
| H Status | 음문 · 1단계 | hstatus.crest.1 |
| H Status | 음문 · 2단계 | hstatus.crest.2 |
| H Status | 음문 · 3단계 | hstatus.crest.3 |
| H Status | 음문 · 4단계 | hstatus.crest.4 |
| H Status | 음문 · 5단계 | hstatus.crest.5 |
