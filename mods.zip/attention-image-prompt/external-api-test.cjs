const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const settings = {};
const custom = [{ id: 'aip-outfit-test', name: '예시', positivePrompt: 'aip blouse, aip skirt',
  negativePrompt: 'aip bad', topPrompt: 'aip blouse', skirtPrompt: 'aip skirt' }];
const outfits = [{ id: 'aip-outfit-test', name: '예시' }];
let settingsReads = 0;
const api = { settings: {
  get: defaults => { settingsReads++; return { ...defaults, ...settings }; },
  set: changes => Object.assign(settings, changes),
} };
const defaults = { 'cycle.menstrual': 'aip positive' };
const negatives = { 'cycle.menstrual': 'aip negative' };
let active = { prompts: { ...defaults }, negativePrompts: { ...negatives } };
const source = fs.readFileSync(path.join(__dirname, 'source/prompt-mod-rules.js'), 'utf8');
const targetsSource = fs.readFileSync(path.join(__dirname, 'source/external-targets.js'), 'utf8');
const helpers = new Function('api', 'FIELD_GROUPS', 'DEFAULT_PROMPTS', 'DEFAULT_NEGATIVE_PROMPTS',
  'activeSituationConfig', 'saveActiveSituationSection', 'settingsWindowHandle', 'shortHash',
  'currentCustomOutfits', 'outfitList', 'saveCustomOutfit', 'syncCustomOutfits', 'normalizeOutfitPrompts', 'currentOutfitPrompts', `${source}\n${targetsSource}\nreturn {
    registerExternalPromptMenu, resolveExternalPrompt, setExternalPromptSource, saveExternalPrompt,
    resetExternalPrompt, externalPromptsForField, externalPromptMenus, normalizeExternalPromptData,
    normalizeExternalPromptPresets, externalFieldCacheSignature, registerExternalTargetAdapter, effectiveExternalTarget, externalTargetSnapshot,
  };`)(api, [{ title: '상태', fields: [{ key: 'cycle.menstrual', label: '월경' }] }], defaults, negatives,
  () => active, (section, value) => { active[section] = value; }, null,
  value => require('node:crypto').createHash('sha256').update(value).digest('hex').slice(0, 12),
  () => custom, outfits, value => Object.assign(custom.find(item => item.id === value.id), value), () => {},
  value => value || {}, () => settings.outfitPrompts || {});
const { registerExternalPromptMenu: register, resolveExternalPrompt: resolve, setExternalPromptSource: choose,
  saveExternalPrompt: save, resetExternalPrompt: reset, externalPromptsForField: apply } = helpers;

const entry = { id: 'cycle', label: '월경', aipField: 'cycle.menstrual', hook: 'imagePrompt',
  positivePrompt: 'mod positive', negativePrompt: 'mod negative' };
const disposeA = register({ id: 'first', title: '첫 모드', entries: [entry] });
register({ id: 'second', title: '둘째 모드', entries: [{ ...entry, positivePrompt: 'second positive' }] });
const initialKey = helpers.externalFieldCacheSignature(active);
assert.deepEqual(resolve('first', 'cycle'), { source: 'aip', positivePrompt: 'aip positive', negativePrompt: 'aip negative' });
assert.equal(save('first', 'cycle', 'mod', { positivePrompt: '', negativePrompt: 'changed negative' }), true);
choose('first', 'cycle', 'mod');
assert.notEqual(helpers.externalFieldCacheSignature(active), initialKey);
const chosenKey = helpers.externalFieldCacheSignature(active);
save('first', 'cycle', 'mod', { negativePrompt: 'changed again' });
assert.notEqual(helpers.externalFieldCacheSignature(active), chosenKey);
save('first', 'cycle', 'mod', { negativePrompt: 'changed negative' });
assert.deepEqual(resolve('first', 'cycle'), { source: 'mod', positivePrompt: '', negativePrompt: 'changed negative' });
assert.equal(apply({ 'cycle.menstrual': 'aip positive' }, 'positivePrompt')['cycle.menstrual'], '');
choose('second', 'cycle', 'mod');
assert.equal(resolve('first', 'cycle').source, 'aip');
assert.equal(helpers.externalPromptMenus()[0].entries[0].activeProvider.id, 'second');
choose('first', 'cycle', 'aip');
assert.equal(helpers.externalPromptMenus()[0].entries[0].activeProvider, null);
choose('second', 'cycle', 'mod');
assert.equal(apply({ 'cycle.menstrual': 'aip positive' }, 'positivePrompt')['cycle.menstrual'], 'second positive');
assert.equal(resolve('first', 'cycle', 'mod').negativePrompt, 'changed negative');
choose('first', 'cycle', 'mod');
assert.equal(resolve('first', 'cycle').positivePrompt, '');
disposeA();
choose('second', 'cycle', 'mod');
register({ id: 'first', title: '첫 모드', entries: [entry] });
assert.equal(resolve('second', 'cycle').source, 'mod');
assert.equal(resolve('first', 'cycle').source, 'aip');
choose('first', 'cycle', 'mod');
save('first', 'cycle', 'aip', { positivePrompt: 'edited aip' });
assert.equal(active.prompts['cycle.menstrual'], 'edited aip');
reset('first', 'cycle', 'aip');
assert.equal(active.prompts['cycle.menstrual'], 'aip positive');
reset('first', 'cycle', 'mod');
assert.equal(resolve('first', 'cycle').positivePrompt, 'mod positive');
assert.equal(apply({ 'cycle.menstrual': null }, 'positivePrompt')['cycle.menstrual'], null);
register({ id: 'independent', title: '독립 모드', entries: [{ id: 'detail', label: '훅', positivePrompt: 'independent' }] });
assert.equal(resolve('independent', 'detail').source, 'mod');
assert.equal(resolve('missing', 'detail'), null);
assert.throws(() => register({ id: 'bad/id', title: '잘못된 ID', entries: [entry] }));
assert.throws(() => register({ id: 'bad', title: '잘못된 필드', entries: [{ ...entry, aipField: 'unknown' }] }));
assert.deepEqual(helpers.normalizeExternalPromptData([{ owner: 'good', id: 'x', positivePrompt: '' }, { owner: '__proto__/x', id: 'bad' }]),
  [{ owner: 'good', id: 'x', source: 'aip', positivePrompt: '' }]);
assert.equal(helpers.normalizeExternalPromptPresets([{ id: 'p', modId: 'good', name: 'test', entries: [
  { id: 'x', source: 'mod', positivePrompt: '', negativePrompt: '' },
] }])[0].entries[0].positivePrompt, '');
register({ id: 'outfit-provider', title: '의상 모드', entries: [{ id: 'outfit', label: '의상',
  target: { kind: 'outfit', id: 'aip-outfit-test' }, positivePrompt: 'mod blouse, mod skirt',
  negativePrompt: 'mod bad', topPrompt: 'mod blouse', skirtPrompt: 'mod skirt' }] });
assert.equal(resolve('outfit-provider', 'outfit').topPrompt, 'aip blouse');
choose('outfit-provider', 'outfit', 'mod');
assert.equal(helpers.effectiveExternalTarget('outfit', 'aip-outfit-test', custom[0]).topPrompt, 'mod blouse');
assert.equal(custom[0].topPrompt, 'aip blouse');
save('outfit-provider', 'outfit', 'mod', { topPrompt: '', skirtPrompt: 'edited skirt' });
assert.equal(helpers.effectiveExternalTarget('outfit', 'aip-outfit-test', custom[0]).topPrompt, '');
choose('outfit-provider', 'outfit', 'aip');
assert.equal(helpers.effectiveExternalTarget('outfit', 'aip-outfit-test', custom[0]), custom[0]);
save('outfit-provider', 'outfit', 'aip', { topPrompt: 'aip edited' });
assert.equal(custom[0].topPrompt, 'aip edited');
choose('outfit-provider', 'outfit', 'mod');
assert.equal(resolve('outfit-provider', 'outfit').skirtPrompt, 'edited skirt');
assert.equal(helpers.normalizeExternalPromptPresets([{ id: 'p', modId: 'outfit-provider', name: 'old', entries: [
  { id: 'outfit', source: 'mod', positivePrompt: '', negativePrompt: '' },
] }])[0].entries[0].topPrompt, undefined);
disposeA(); // An old unregister function must not remove a newer registration.
assert.notEqual(resolve('first', 'cycle'), null);

// A single position calculation resolves many modules, including selected modules twice.
// The snapshot must be short-lived: settings and registered providers can change between calls.
const modules = Array.from({ length: 80 }, (_, i) => ({ id: `m${i}`, positivePrompt: `base ${i}`, negativePrompt: '' }));
helpers.registerExternalTargetAdapter('position-module', {
  list: () => modules, read: id => modules.find(module => module.id === id) || null, save() {}, reset() {},
});
const providerEntries = modules.map((module, i) => ({ id: module.id, label: module.id,
  target: { kind: 'position-module', id: module.id }, positivePrompt: `provider ${i}`, negativePrompt: '' }));
let disposeMany = register({ id: 'many', title: '모듈 제공자', entries: providerEntries });
settings.externalPromptData = modules.map(module => ({ owner: 'many', id: module.id, source: 'mod' }));
function calculateModules(useSnapshot) {
  const before = settingsReads, snapshot = useSnapshot ? helpers.externalTargetSnapshot() : undefined;
  const mapped = modules.map(module => helpers.effectiveExternalTarget('position-module', module.id, module, snapshot));
  const selected = mapped.slice(0, 10).map(module => helpers.effectiveExternalTarget('position-module', module.id, module, snapshot));
  return { mapped, selected, reads: settingsReads - before };
}
const oldCalculation = calculateModules(false), newCalculation = calculateModules(true);
assert.deepEqual(newCalculation.mapped, oldCalculation.mapped);
assert.deepEqual(newCalculation.selected, oldCalculation.selected);
assert.equal(oldCalculation.reads, 180, 'unsnapshotted provider lookup and prompt resolution each read settings');
assert.equal(newCalculation.reads, 1, 'one synchronous calculation reads external settings once');
settings.externalPromptData[0].positivePrompt = 'edited';
assert.equal(calculateModules(true).mapped[0].positivePrompt, 'edited', 'next calculation observes changed settings');
disposeMany();
assert.equal(calculateModules(true).mapped[0].positivePrompt, 'base 0', 'next calculation observes provider removal');
disposeMany = register({ id: 'many', title: '대체 제공자', entries: providerEntries.map(entry => ({ ...entry, positivePrompt: 'replacement' })) });
delete settings.externalPromptData[0].positivePrompt;
assert.equal(calculateModules(true).mapped[0].positivePrompt, 'replacement', 'next calculation observes provider replacement');
disposeMany();

const keySource = fs.readFileSync(path.join(__dirname, 'source/image-cache-and-keys.js'), 'utf8');
const signatureSource = keySource.slice(keySource.indexOf('    function externalSignatureFromImageKey('),
  keySource.indexOf('    function situationImageKey('));
const positionSource = keySource.slice(keySource.indexOf('    function keyWithPosition('),
  keySource.indexOf('    function applyPositionPreset('));
const positionKey = new Function('compactSituationAliases', 'stripPositionKey', 'positionSituationId', 'positionGroupCount',
  'currentPositionStatePrompt', 'positionStateOnly', 'effectivePositionDetails', `${signatureSource}\n${positionSource}\nreturn keyWithPosition;`)(
  new Map(), key => key, () => 'scene-test', () => 0, () => null, () => false, () => null);
const pending = { pendingPreviousKey: 'earlier', imageKey: 'wife__scene-test__aip-att-external-old__v-1' };
assert.equal(positionKey('wife__scene-test__aip-att-external-old', pending), pending.imageKey);
assert.equal(positionKey('wife__scene-test__aip-att-external-new', pending), 'wife__scene-test__aip-att-external-new');
assert.equal(positionKey('wife__scene-test', { ...pending, imageKey: 'wife__scene-test__v-1' }), 'wife__scene-test__v-1');
console.log('external prompt API: ok');
