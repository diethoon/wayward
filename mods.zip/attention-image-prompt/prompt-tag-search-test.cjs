const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, 'source/prompt-tag-search.js'), 'utf8');
const ruleSource = fs.readFileSync(path.join(__dirname, 'source/prompt-mod-rules.js'), 'utf8');
const excludeSource = fs.readFileSync(path.join(__dirname, 'source/global-prompt-exclusions.js'), 'utf8');
function extract(text, name) {
  const start = text.indexOf(`    function ${name}(`), end = text.indexOf('\n    function ', start + 8);
  assert.ok(start >= 0 && end > start, name);
  return text.slice(start, end);
}
let currentKey = 'wife__scene-hug__v-0', reads = 0, settingsWrites = 0;
const fixtures = {
  api: { store: { game: () => ({ primaryCharacterId: 'wife' }) }, settings: { set: () => { settingsWrites++; } } },
  latestScenePrompt: { characterId: 'wife', situationId: 'scene-hug', result: {
    key: 'wife__scene-hug__v-0', prompt: '1girl, (side_view:1.3)', negativePrompt: 'bad anatomy' } },
  activePortraitImageKey: () => currentKey,
  positionSituationLabel: id => ({ 'scene-hug': '포옹', 'task-sleeping': '수면' })[id] || id,
  currentCustomTags: () => [], translatedPromptTag: tag => /side[_ ]view/i.test(tag) ? '측면 시점' : tag,
  currentGameDefaultPrompts: () => ({}), GAME_PROMPT_QUALITY: 'masterpiece, best quality', GAME_PROMPT_NEGATIVE: 'bad anatomy',
  FIELD_GROUPS: [{ title: '상태', fields: [{ key: 'expression', label: '표정' }] }],
  currentPrompts: () => ({ expression: 'side_view' }), currentNegativePrompts: () => ({ expression: 'bad anatomy' }),
  currentDialogueRules: () => [{ id: 'talk', name: '손님 대화', positivePrompt: 'side view', negativePrompt: '' }],
  currentSituationPresets: () => [{ name: '프리셋', prompts: { expression: '(side view:1.2)' }, negativePrompts: {} }],
  scenePromptCatalog: () => { reads++; return [{ id: 'task-sleeping', label: '수면' }]; },
  nativeScenePromptCandidates: () => [{ label: '수면 자세 기본 후보', text: 'sleeping, (side_view:1.1)' }],
  currentPositionStatePrompts: () => ({ 'scene-hug': { positivePrompt: '(side view:1.2)', negativePrompt: '' } }),
  sceneBaseOverrides: {}, sceneStatePromptOverrides: {}, currentSceneCandidatePools: () => ({}),
  buttonPromptRules: [{ mode: 'after', label: '껴안기', scene: 'scene-hug', choiceId: 'hug', positivePrompt: '', negativePrompt: '',
    outcomes: [{ situationId: 'scene-hug', response: 'refuse', positivePrompt: 'side_view', negativePrompt: '', candidates: [] }] }],
  currentOutfitPrompts: () => ({}), outfitPromptSources: () => [], outfitPromptValues: source => source,
  currentCustomOutfits: () => [], availablePositionModules: () => [], POSITION_PRESETS: {}, GROUP_SLOT_BY_ID: {},
  positionPresetById: () => null, positionGroupPromptById: () => '', cameraSceneSettings: {}, cameraDrafts: {},
  externalPromptMenus: () => [{ title: '다른 모드', id: 'test', entries: [{ id: 'pose', label: '자세', positivePrompt: 'side view', negativePrompt: '' }] }],
  currentWifePromptContext: () => ({ name: '아내' }), currentWifeCharacterPrompt: () => ({}), currentResiduePrompts: () => ({}),
};
const names = Object.keys(fixtures);
const search = new Function(...names, `${extract(ruleSource, 'splitFinalPrompt')}\n${extract(excludeSource, 'globalPromptExclusionIdentity')}\n${source}\nreturn searchPromptTag;`)(...Object.values(fixtures));
assert.deepEqual(search(''), { query: '', matches: [], warnings: [] });
assert.equal(reads, 0, 'empty queries must not scan any sources');
const result = search('side view');
assert.ok(result.matches.some(m => m.scope === 'current' && m.polarity === 'positive' && m.matchedTags.includes('(side_view:1.3)')));
assert.ok(result.matches.some(m => m.source === '게임 기본 장면 후보' && m.location.includes('수면')));
assert.ok(result.matches.some(m => m.source === '선택지 반응 설정' && m.location.includes('refuse')));
assert.ok(result.matches.some(m => m.source === '다른 모드 · 다른 모드'));
assert.ok(result.matches.some(m => m.source === '대화 감지 설정' && m.location.includes('손님 대화')));
assert.ok(search('측면 시점').matches.some(m => m.matchedTags.includes('(side_view:1.3)')), 'Korean translation should find weighted tags');
assert.ok(search('bad anatomy').matches.some(m => m.scope === 'current' && m.polarity === 'negative'));
currentKey = 'wife__task-idle__v-0';
assert.ok(!search('side_view').matches.some(m => m.scope === 'current'), 'do not mark stale portraits as current');
assert.equal(settingsWrites, 0, 'search must never write settings');
console.log('prompt tag search: ok');
