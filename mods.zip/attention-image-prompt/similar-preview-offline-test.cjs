const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const source = fs.readFileSync(`${__dirname}/source/image-browser.js`, 'utf8');
const start = source.indexOf('    async function loadSimilarImages(');
const end = source.indexOf('    function openSimilarImagePicker(', start);
assert.ok(start >= 0 && end > start);

const target = 'elena__scene-sex__v-0';
const disabled = 'elena__scene-sex__v-1';
const compact = 'elena__scene-sex__aipk-fixture__v-1';
const savedUnused = { 'elena__scene-sex': [disabled] };
let online = false, cached, resetCount = 0, lookupCalls = 0, localAvailable = true, holdManifest = null;
let timerId = 0;
const timers = new Map();
const serverEntry = { talentName: compact, imagePath: 'illustrious/characters/elena/server.webp', source: 'server', createdAt: 4 };
const localEntry = { talentName: compact, imagePath: 'illustrious/characters/elena/offline.webp', source: 'attention-image-prompt-offline', offlineUrl: 'blob:fixture' };
const manifest = async () => {
  if (holdManifest) { const pending = holdManifest; holdManifest = null; return pending; }
  if (cached === undefined) cached = online ? { entries: { [compact]: serverEntry } } : null;
  return cached;
};
const api = {
  has: name => ['imageManifest', 'imageManifestReset'].includes(name),
  fn(name) {
    return {
      imageManifest: manifest,
      imageManifestReset: () => { cached = undefined; resetCount++; },
      imageLookup: async () => { lookupCalls++; return null; },
    }[name];
  },
};
const context = {
  api, console,
  setTimeout(fn, delay) { const id = ++timerId; timers.set(id, { fn, delay }); return id; },
  clearTimeout(id) { timers.delete(id); },
  settingsStore: { getState: () => ({ imageBackendMode: 'auto' }) },
  imageServerUrl: path => `http://127.0.0.1:8189${path}`,
  fetch: async () => ({ ok: online }),
  similarImageProfile: () => ({ character: 'elena' }),
  manifestImageEntries: result => Object.values(result?.entries || {}),
  isCharacterImage: key => typeof key === 'string' && key.startsWith('elena__'),
  localGeneratedEntries: async () => ({}),
  similarImageChoice: () => null,
  portraitImageVariants: () => ({ variants: [target], currentIdx: 0 }),
  unusedPortraitImages: () => savedUnused,
  similarImageSituationKey: () => 'elena__scene-sex',
  offlineImageCandidates: key => key === disabled ? [disabled, compact] : [key],
  offlineCache: { resolve: async keys => localAvailable && keys.includes(compact) ? localEntry : null },
  similarImageEntries: (_key, entries) => entries,
  diagnosticText: error => String(error),
  imageLookup: async () => { throw new Error('must use current hooked lookup'); },
};
const { loadSimilarImages: load, monitorSimilarImageRecovery: monitor, stopSimilarImageRecovery: stop, armSimilarImageRecovery: arm } = vm.runInNewContext(
  `${source.slice(start, end)}\n({loadSimilarImages, monitorSimilarImageRecovery, stopSimilarImageRecovery, armSimilarImageRecovery})`, context);
const win = { refresh() {} };

(async () => {
  const picker = { targetKey: target, previewEntries: {} };
  await load(picker, win);
  assert.equal(picker.previewEntries[disabled], localEntry, 'an excluded image remains visible from the connected offline folder');
  assert.equal(savedUnused['elena__scene-sex'][0], disabled, 'preview lookup does not reactivate an excluded image');
  assert.ok(lookupCalls > 0, 'the current hooked lookup is used');

  online = true;
  localAvailable = false;
  await load(picker, win);
  assert.ok(picker.allEntries.includes(serverEntry), 'opening after server recovery reloads the cached empty manifest');
  assert.equal(picker.previewEntries[disabled], serverEntry, 'an excluded full key previews its compact server entry after recovery');
  assert.equal(resetCount, 2, 'each gallery opening or refresh invalidates a stale game manifest');
  assert.equal(savedUnused['elena__scene-sex'][0], disabled, 'server recovery preserves the excluded state');

  online = false;
  localAvailable = true;
  const open = { targetKey: target, previewEntries: {}, closed: false };
  await load(open, win);
  monitor(open, win);
  let tick = [...timers.entries()].find(([, timer]) => timer.delay === 5000);
  assert.ok(tick, 'an open offline gallery schedules a bounded recovery check');
  timers.delete(tick[0]); await tick[1].fn();
  assert.ok([...timers.values()].some(timer => timer.delay === 5000), 'offline state retries without refreshing the gallery');
  const beforeRecovery = resetCount;
  online = true; localAvailable = false;
  tick = [...timers.entries()].find(([, timer]) => timer.delay === 5000);
  timers.delete(tick[0]); await tick[1].fn();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(resetCount, beforeRecovery + 1, 'server recovery refreshes the open gallery once');
  assert.equal(open.previewEntries[disabled], serverEntry, 'the open gallery restores the excluded preview');
  assert.equal([...timers.values()].filter(timer => timer.delay === 5000).length, 0, 'polling stops after recovery');
  assert.equal(savedUnused['elena__scene-sex'][0], disabled, 'automatic recovery does not reactivate images');

  const alreadyOpen = { targetKey: target, previewEntries: {}, closed: false };
  arm(alreadyOpen, win, true);
  await new Promise(resolve => setImmediate(resolve));
  assert.equal([...timers.values()].filter(timer => timer.delay === 5000).length, 0, 'an online gallery does not poll continuously');
  online = false;
  arm(alreadyOpen, win, true); // The user disables an image after the server stops.
  await new Promise(resolve => setImmediate(resolve));
  tick = [...timers.entries()].find(([, timer]) => timer.delay === 5000);
  assert.ok(tick, 'disabling an image while offline starts recovery monitoring even if the gallery opened online');
  online = true;
  const beforeReconnection = resetCount;
  timers.delete(tick[0]); await tick[1].fn();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(resetCount, beforeReconnection + 1, 'an already-open gallery refreshes once after reconnection');
  assert.equal(savedUnused['elena__scene-sex'][0], disabled, 'the user selection survives reconnection');

  // A successful response started before the user disables an image is stale: the
  // server may have gone offline and recovered while that response was pending.
  let releaseHealth;
  let checks = 0;
  context.fetch = () => ++checks === 1
    ? new Promise(resolve => { releaseHealth = resolve; })
    : Promise.resolve({ ok: true });
  const rapid = { targetKey: target, previewEntries: {}, closed: false };
  const beforeRapid = resetCount;
  arm(rapid, win, true); // Opening the online gallery starts a request.
  arm(rapid, win, true, true); // Disable while its old response is pending.
  releaseHealth({ ok: true });
  await new Promise(resolve => setImmediate(resolve));
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(checks, 2, 'a disable during a pending health check triggers a fresh check');
  assert.equal(resetCount, beforeRapid + 1, 'a server already back online still refreshes exactly once');
  assert.equal(rapid.previewEntries[disabled], serverEntry);
  assert.equal(savedUnused['elena__scene-sex'][0], disabled, 'the rapid recovery preserves the disabled choice');
  assert.equal([...timers.values()].filter(timer => timer.delay === 5000).length, 0, 'rapid recovery does not start polling');
  context.fetch = async () => ({ ok: online });

  online = false;
  const closing = { targetKey: target, previewEntries: {}, closed: false };
  monitor(closing, win);
  assert.ok(timers.has(closing.recoveryTimer));
  stop(closing);
  assert.equal([...timers.values()].filter(timer => timer.delay === 5000).length, 0, 'closing the gallery cancels recovery polling');

  let releaseClosingHealth;
  context.fetch = () => new Promise(resolve => { releaseClosingHealth = resolve; });
  const closingDuringProbe = { targetKey: target, previewEntries: {}, closed: false };
  const beforeClose = resetCount;
  arm(closingDuringProbe, win, true, true);
  stop(closingDuringProbe);
  releaseClosingHealth({ ok: false });
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(resetCount, beforeClose, 'a health response after closing must not refresh the gallery');
  assert.equal([...timers.values()].filter(timer => timer.delay === 5000).length, 0,
    'a late health response after closing must not restart polling');
  context.fetch = async () => ({ ok: online });

  let releaseOld;
  holdManifest = new Promise(resolve => { releaseOld = resolve; });
  const stale = { targetKey: target, previewEntries: {}, closed: false };
  const older = load(stale, win);
  online = true;
  await load(stale, win);
  releaseOld(null);
  await older;
  assert.equal(stale.previewEntries[disabled], serverEntry, 'a late offline response cannot replace a newer gallery');
  console.log('offline-to-online similar image preview: ok');
})().catch(error => { console.error(error); process.exitCode = 1; });
