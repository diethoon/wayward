const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const read = name => fs.readFileSync(path.join(__dirname, 'source', name), 'utf8');
const shared = read('prompt-mod-rules.js');
const split = shared.slice(shared.indexOf('    function splitFinalPrompt('), shared.indexOf('    function deduplicateFinalPrompt('));
const identity = shared.slice(shared.indexOf('    function promptTagIdentity('), shared.indexOf('    function translatedPromptTag('));
let settings = {}, hook;
const api = { settings: { get: defaults => ({ ...defaults, ...settings }), set: patch => { settings = { ...settings, ...patch }; } },
  hook: (_, value) => { hook = value; }, store: { game: () => ({ primaryCharacterId: 'wife' }) },
  ui: { button: (label, onclick) => ({ label, onclick }) } };
const candidateMap = {
  'scene-chat': [{ source: 'scene', label: '첫 후보', text: 'hello, smile' }, { source: 'scene', label: '둘째 후보', text: 'wave, smile' }],
  'scene-empty': [],
};
const make = new Function('api', 'nativeScenePromptCandidates', 'shortHash', 'positionSituationId', 'promptGenParams', 'joinPrompt', 'characterIdOf',
  'notifyExternalPromptChange', 'nativeInlinePoseCandidates', `let imagePlanDepth = 0, promptPreviewing = false;
  ${split}\n${identity}\n${read('scene-base-overrides.js')}\n${read('scene-candidate-pool.js')}
  return { installSceneBaseOverrideHook, saveSceneBaseOverride, resetSceneBaseOverride, saveSceneCandidatePool,
    currentSceneCandidatePools, reloadSceneCandidatePools, sceneCandidateSnapshot, sceneBaseOverrideFingerprint, sceneCandidateEntryForResult };`);
const feature = make(api, id => candidateMap[id.split('|')[0]] || [],
  value => require('node:crypto').createHash('sha256').update(value).digest('hex').slice(0, 12),
  key => String(key || '').split('__').find(part => /^(scene|task|look)-/.test(part)) || '',
  prompt => ({ prompt }), prompt => prompt.replace(/^,\s*/, ''), () => 'wife', () => {}, () => ({}));
const result = (id, tags) => ({ key: `wife__${id}__v-0`, prompt: `1girl, ${tags}, dress`, negativePrompt: 'watermark',
  parts: [{ label: '기본', tags: '1girl' }, ...(tags ? [{ label: '장면', tags }] : []), { label: '의상', tags: 'dress' }] });
feature.installSceneBaseOverrideHook();
const apply = value => hook.around(() => value, { id: 'wife' });
const initialKey = feature.sceneBaseOverrideFingerprint('scene-chat');
assert.equal(initialKey, '');
feature.saveSceneCandidatePool('scene-chat', { edits: [{ source: 'scene', original: 'hello, smile', prompt: 'hello, smile', name: '첫 인사' }], additions: [], selected: '' });
assert.equal(feature.sceneBaseOverrideFingerprint('scene-chat'), initialKey, 'naming an unchanged native candidate leaves image key intact');
assert.equal(apply(result('scene-chat', 'hello, smile')).prompt, '1girl, hello, smile, dress', 'naming does not change native prompt');
assert.equal(feature.sceneCandidateSnapshot('scene-chat').candidates[0].name, '첫 인사');
feature.saveSceneCandidatePool('scene-chat', { edits: [], additions: [{ id: 'add-1', prompt: 'new candidate', name: '새 이름' }], selected: '' });
assert.equal(feature.sceneBaseOverrideFingerprint('scene-chat'), initialKey, 'inactive additional candidates do not change image key');
assert.equal(apply(result('scene-chat', 'hello, smile')).prompt, '1girl, hello, smile, dress');
assert.equal(feature.saveSceneCandidatePool('scene-chat', { edits: [{ source: 'scene', original: 'hello, smile', prompt: 'whisper, smile' }], additions: [], selected: '' }), true);
assert.notEqual(feature.sceneBaseOverrideFingerprint('scene-chat'), initialKey);
assert.equal(apply(result('scene-chat', 'hello, smile')).prompt, '1girl, whisper, smile, dress');
assert.equal(apply(result('scene-chat', 'wave, smile')).prompt, '1girl, wave, smile, dress', 'other native candidates retain their content');
assert.equal(apply(result('scene-chat', 'hello, smile')).negativePrompt, 'watermark');
assert.equal(candidateMap['scene-chat'][0].text, 'hello, smile', 'game table is not mutated');
const twoEdits = [{ source: 'scene', original: 'hello, smile', prompt: 'whisper, smile', name: '이전' },
  { source: 'scene', original: 'wave, smile', prompt: 'wave edited' }];
feature.saveSceneCandidatePool('scene-chat', { edits: twoEdits, additions: [], selected: '' });
const twoEditToken = feature.sceneBaseOverrideFingerprint('scene-chat');
feature.saveSceneCandidatePool('scene-chat', { edits: [twoEdits[1], { ...twoEdits[0], name: '이름 변경' }], additions: [], selected: '' });
assert.equal(feature.sceneBaseOverrideFingerprint('scene-chat'), twoEditToken, 'renaming does not change keys when edit order changes');
const snapshot = feature.sceneCandidateSnapshot('scene-chat');
assert.equal(snapshot.candidates[0].prompt, 'whisper, smile');
snapshot.candidates[0].prompt = 'not saved';
assert.equal(feature.sceneCandidateSnapshot('scene-chat').candidates[0].prompt, 'whisper, smile');
assert.equal(feature.saveSceneCandidatePool('scene-chat', { edits: [], additions: [{ id: 'add-1', prompt: 'new candidate' }], selected: 'add-1' }), true);
assert.equal(apply(result('scene-chat', 'wave, smile')).prompt, '1girl, new candidate, dress');
const selectedToken = feature.sceneBaseOverrideFingerprint('scene-chat');
feature.saveSceneCandidatePool('scene-chat', { edits: [], additions: [{ id: 'add-1', prompt: 'new candidate', name: '이름 변경' }], selected: 'add-1' });
assert.equal(feature.sceneBaseOverrideFingerprint('scene-chat'), selectedToken, 'renaming the active candidate does not change image key');
assert.equal(feature.sceneCandidateSnapshot('scene-chat').additions[0].name, '이름 변경');
feature.saveSceneCandidatePool('scene-empty', { edits: [], additions: [{ id: 'add-1', prompt: 'created candidate' }], selected: 'add-1' });
const noNative = result('scene-empty', '');
assert.match(apply(noNative).prompt, /created candidate/);
assert.equal(apply(noNative).parts.at(-1).label, 'AIP 추가 장면 후보');
feature.saveSceneBaseOverride('scene-chat', 'legacy override');
assert.equal(apply(result('scene-chat', 'wave, smile')).prompt, '1girl, legacy override, dress', 'legacy whole-scene override keeps precedence');
assert.equal(feature.sceneCandidateSnapshot('scene-chat').blockedByBaseOverride, true);
feature.resetSceneBaseOverride('scene-chat');
const stored = JSON.parse(JSON.stringify(settings));
feature.saveSceneCandidatePool('scene-empty', { edits: [], additions: [], selected: '' });
settings = stored; feature.reloadSceneCandidatePools(false);
assert.equal(feature.currentSceneCandidatePools()['scene-empty'].additions[0].prompt, 'created candidate');
console.log('scene candidate pool: ok');
