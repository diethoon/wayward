const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, 'source/generation-weight.js'), 'utf8');
const prompt = n => Array.from({ length: n }, (_, i) => `tag${i}`).join(', ');
function harness() {
  let saved = {}, loaded = [], styleLockSettings = null, current = 'elena__scene-sex__v-0';
  const state = { primaryCharacterId: 'wife' }, snapshot = {};
  const api = { settings: { get: defaults => ({ ...defaults, ...saved }) }, store: { game: () => state } };
  const globalObject = { WML: { status: () => ({ loaded }) }, localStorage: { getItem: () => styleLockSettings } };
  const functions = new Function('api', 'globalThis', 'activePortraitImageKey', 'similarImageSituationKey', 'latestScenePrompt',
    `${source}\nreturn { generationWeightSettings, generationWeightForPrompt, generationWeightStyleLockActive, generationWeightAdjustRequest, generationWeightCurrentPortraitPrompt };`)(
    api, globalObject, () => current, value => value.replace(/__v-\d+$/, ''), snapshot);
  return { ...functions, set saved(value) { saved = value; }, set loaded(value) { loaded = value; },
    set styleLockSettings(value) { styleLockSettings = value; }, set current(value) { current = value; }, state, snapshot };
}

const h = harness();
assert.deepEqual(h.generationWeightSettings(), { enabled: false, percent: 100, stepsPercent: 100, cfgPercent: 100, loraPercent: 100 });
for (const [n, expected] of [[40, [8, 1.5, 1]], [41, [12, 2, 0.9]], [60, [12, 2, 0.9]], [61, [18, 2.5, 0.8]]]) {
  const result = h.generationWeightForPrompt(prompt(n), 100);
  assert.deepEqual([result.steps, result.cfg, result.loraStrength], expected, `original game boundary ${n}`);
}
assert.deepEqual(h.generationWeightForPrompt(`${prompt(39)}, (one, two:1.2),,`, 100),
  { steps: 12, cfg: 2, loraStrength: 0.9 }, 'match native comma counting even inside parentheses');
assert.equal(h.generationWeightForPrompt('  '), null);
assert.deepEqual(h.generationWeightForPrompt(prompt(81), 0), { steps: 8, cfg: 1.5, loraStrength: 1 });
assert.deepEqual(h.generationWeightForPrompt(prompt(81), 50), { steps: 13, cfg: 2, loraStrength: 0.9 });
assert.deepEqual(h.generationWeightForPrompt(prompt(81), 200), { steps: 28, cfg: 3.5, loraStrength: 0.6 });
assert.deepEqual(h.generationWeightForPrompt(prompt(50), 50), { steps: 10, cfg: 1.75, loraStrength: 0.95 });
assert.deepEqual(h.generationWeightForPrompt(prompt(10), 200), { steps: 8, cfg: 1.5, loraStrength: 1 });
for (const [input, expected] of [[NaN, 100], [Infinity, 100], ['50', 100], [-20, 0], [999, 200], [47.6, 48]]) {
  h.saved = { generationWeightEnabled: true, generationWeightPercent: input };
  assert.equal(h.generationWeightSettings().percent, expected);
  assert.deepEqual([h.generationWeightSettings().stepsPercent, h.generationWeightSettings().cfgPercent, h.generationWeightSettings().loraPercent], [expected, expected, expected], 'legacy percentage applies to each unset value');
}
h.saved = { generationWeightEnabled: true, generationWeightPercent: 50, generationWeightStepsPercent: 0, generationWeightCfgPercent: 200, generationWeightLoraPercent: 25 };
assert.deepEqual(h.generationWeightForPrompt(prompt(81), h.generationWeightSettings()), { steps: 8, cfg: 3.5, loraStrength: 0.95 }, 'independent percentages scale the matching parameter only');
assert.deepEqual(h.generationWeightForPrompt(prompt(50), { stepsPercent: 200, cfgPercent: 0, loraPercent: 100 }), { steps: 16, cfg: 1.5, loraStrength: 0.9 });
h.saved = { generationWeightPercent: 50, generationWeightStepsPercent: -1, generationWeightCfgPercent: 220, generationWeightLoraPercent: 'bad' };
assert.deepEqual([h.generationWeightSettings().stepsPercent, h.generationWeightSettings().cfgPercent, h.generationWeightSettings().loraPercent], [0, 200, 50], 'individual values clamp and invalid values fall back to legacy');
h.saved = { generationWeightEnabled: 'true', generationWeightPercent: 50 };
assert.equal(h.generationWeightSettings().enabled, false, 'invalid enabled value cannot enable the feature');
const request = { imageKey: 'elena__scene-sex__v-0', prompt: prompt(81), steps: 18, cfg: 2.5, loraStrength: 0.8, debug: { stats: {} } };
assert.equal(h.generationWeightAdjustRequest(request), request, 'disabled leaves request unchanged');
h.saved = { generationWeightEnabled: true, generationWeightPercent: 50 };
assert.deepEqual(h.generationWeightAdjustRequest(request), { ...request, steps: 13, cfg: 2, loraStrength: 0.9 });
h.saved = { generationWeightEnabled: true, generationWeightPercent: 50, generationWeightStepsPercent: 0, generationWeightCfgPercent: 200, generationWeightLoraPercent: 25 };
assert.deepEqual(h.generationWeightAdjustRequest(request), { ...request, steps: 8, cfg: 3.5, loraStrength: 0.95 });
h.saved = { generationWeightEnabled: true, generationWeightPercent: 50 };
assert.equal(request.steps, 18, 'the original request is not mutated');
h.loaded = ['style-lock'];
assert.equal(h.generationWeightStyleLockActive(), true, 'style-lock defaults to lock enabled');
assert.equal(h.generationWeightAdjustRequest(request), request, 'do not pretend to override style-lock');
h.styleLockSettings = '{invalid';
assert.equal(h.generationWeightStyleLockActive(), true, 'invalid style-lock settings fail safely');
h.styleLockSettings = JSON.stringify({ lockParams: false, tidyConflict: true });
assert.equal(h.generationWeightStyleLockActive(), false);
assert.equal(h.generationWeightAdjustRequest(request).steps, 13);
h.loaded = [];
for (const patch of [
  { bulk: true }, { imageType: 'video' }, { imageData: 'data:x' }, { referenceKey: 'ref' },
  { referenceImage: 'ref' }, { initImage: 'ref' }, { mask: 'ref' }, { denoise: 0 },
  { debug: { source: 'another-mod', stats: {} } }, { debug: { source: 'attention-image-prompt-residue' } },
  { debug: { source: 'attention-image-prompt-outfit-preview' } }, { prompt: '' },
]) {
  const item = { ...request, ...patch };
  assert.equal(h.generationWeightAdjustRequest(item), item, `special request must be unchanged: ${JSON.stringify(patch)}`);
}
const position = { ...request, debug: { source: 'attention-image-prompt-position' } };
assert.equal(h.generationWeightAdjustRequest(position).steps, 13, 'AIP position images use the requested adjustment');
const native = { ...request, imageKey: 'elena__scene-sex__v-7', debug: undefined };
assert.equal(h.generationWeightAdjustRequest(native).steps, 13, 'native portrait redraw with no stats remains supported');
h.current = 'elena__task-idle__v-0';
assert.equal(h.generationWeightAdjustRequest(native), native, 'unrelated native requests are left unchanged');
assert.equal(h.generationWeightCurrentPortraitPrompt(), null, 'no current portrait prompt is reported unavailable');
h.snapshot.characterId = 'wife';
h.snapshot.result = { key: 'elena__task-idle__v-0', prompt: prompt(61) };
assert.equal(h.generationWeightCurrentPortraitPrompt(), h.snapshot.result.prompt, 'idle portrait prompt is supported');
h.current = 'elena__task-idle__v-8';
assert.equal(h.generationWeightCurrentPortraitPrompt(), h.snapshot.result.prompt, 'different variants of the same current portrait are compatible');
h.current = 'elena__scene-sex__v-0';
assert.equal(h.generationWeightCurrentPortraitPrompt(), null, 'a changed scene must not display stale prompt counts');
h.snapshot.result = { key: 'elena__scene-sex__v-0', prompt: prompt(81) };
assert.equal(h.generationWeightCurrentPortraitPrompt(), h.snapshot.result.prompt, 'current scene prompt is supported');
h.state.primaryCharacterId = 'new-wife';
assert.equal(h.generationWeightCurrentPortraitPrompt(), null, 'another primary character must not inherit the old portrait prompt');
h.state.primaryCharacterId = 'wife'; h.current = '';
assert.equal(h.generationWeightCurrentPortraitPrompt(), null, 'missing current key is treated as unavailable');
console.log('generation weight unit: boundaries, scaling, lock, exclusions and request preservation OK');
