'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(require('node:path').join(__dirname, 'source/camera-presets.js'), 'utf8');
const result = vm.runInNewContext(`${source}\n({ groups: CAMERA_PRESET_GROUPS, remove: CAMERA_REMOVE_DEFAULTS })`);
const groups = Array.from(result.groups);
const items = groups.flatMap(group => Array.from(group.items));
assert.deepEqual(groups.map(group => group.id), ['viewpoint', 'direction', 'elevation', 'framing', 'tilt', 'lens']);
assert.equal(new Set(items.map(item => item.id)).size, items.length, 'preset IDs must be unique');
for (const item of items) {
  assert.match(item.id, /^[a-z0-9_]+$/);
  assert.ok(item.name && typeof item.positive === 'string' && typeof item.negative === 'string');
  assert.ok(item.positive, 'each default describes its camera view');
  assert.doesNotMatch(item.positive, /camera/i, 'view tags should not name a camera');
  for (const term of item.positive.split(', ')) assert.match(term, /^\(.+:1\.3\)$/, 'default camera terms are weighted');
}
for (const id of ['pov', 'third_person', 'front', 'three_quarter', 'side', 'above', 'ceiling_near', 'below', 'between_legs', 'portrait', 'face_close'])
  assert.ok(items.some(item => item.id === id), `${id} must be available`);
const thirdPerson = items.find(item => item.id === 'third_person');
assert.equal(thirdPerson.positive, '(third-person view:1.3)', 'third-person view must not force a direction');
assert.ok(result.remove.includes('pov'), 'observer preset uses the default camera removal list to clear POV');
const ceiling = items.find(item => item.id === 'ceiling_near');
const betweenLegs = items.find(item => item.id === 'between_legs');
assert.equal(betweenLegs.positive, '(low-angle view:1.3), (from_below:1.3), (thighs:1.3)');
assert.doesNotMatch(betweenLegs.positive, /view_between_legs|standing/i);
assert.match(ceiling.positive, /from_above/);
assert.match(ceiling.positive, /top view/);
assert.match(ceiling.positive, /cowboy_shot/);
assert.doesNotMatch(ceiling.positive, /wide|far|standing/i);
for (const [id, view] of [['front', 'front view'], ['three_quarter', 'three-quarter view'],
  ['side', 'side view'], ['rear', 'back view'], ['above', 'top view'], ['below', 'low-angle view'],
  ['high_up', 'high-angle view'], ['pov', 'first-person view']]) {
  const item = items.find(entry => entry.id === id);
  assert.ok(item.positive.includes(`(${view}:1.3)`), `${id} should include its weighted view`);
}
assert.match(items.find(item => item.id === 'side').positive, /from_side/, 'side view keeps the existing tag as support');
assert.match(items.find(item => item.id === 'front').positive, /straight-on/, 'front view keeps the existing tag as support');
assert.match(items.find(item => item.id === 'rear').positive, /from_behind/, 'back view keeps the existing tag as support');
const normalize = term => term.replace(/_/g, ' ').toLowerCase();
const removed = new Set(Array.from(result.remove, normalize));
const sharedPhysical = new Set(['from behind', 'pov hands', 'thighs']);
for (const item of items) for (const term of item.positive.split(',').map(value => value.trim().replace(/^\((.+):1\.3\)$/, '$1')))
  assert.ok(removed.has(normalize(term)) || sharedPhysical.has(normalize(term)), `view term must be replaceable or shared with physical action: ${term}`);
for (const unsafe of ['from behind', 'sex from behind', 'looking at viewer', 'hand between legs', 'head between legs', 'pov hands'])
  assert.equal(removed.has(normalize(unsafe)), false, `${unsafe} is ambiguous action or gaze and must not be removed by default`);
console.log('camera presets: ok');
