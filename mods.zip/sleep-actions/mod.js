WML.define({
  id: 'sleep-actions',
  name: '수면 중 행동 기반',
  author: '민트좋아',
  // mod symbols (wml/tools/mod-symbols.mjs keeps this block; data only)
  symbols: {
    "applyEffects": {"raw":{"2026-11-01":"ft"},"doc":"원본 효과 적용기; 실제 수면 중 만지기의 플레이어와 대상 흥분도 변화를 원본 규칙으로 반영"},
    "nextSceneVariant": {"raw":{"2026-11-01":"ey"},"doc":"원본 행동 이미지 장면 변형 순환; 수면 행동도 기존 만지기 행동과 같은 변형 선택 사용"},
    "processPlayerFemaleClimax": {"raw":{"2026-11-01":"J3e"},"doc":"원본 플레이어 성행위 중 대상 절정 판정·기록·감정·로그 처리"},
    "wifeScene": {"raw":{"2026-11-01":"Wg"},"doc":"원본 우측 대상 초상화의 현재 장면 선택; 수면 행동 장면을 원본 성행위 초상화 경로에 표시"},
    "PleasureGauge": {"raw":{"2026-11-01":"wb"},"doc":"원본 플레이어 성행위 화면의 이름·백분율·색상 절정 게이지 한 줄 컴포넌트"},
    "sexAftermathTags": {"raw":{"2026-11-01":"nx"},"doc":"원본 성행위 종류와 사정 위치로 몸에 남는 aftermathTags를 계산"},
    "sexAftermathFadeAt": {"raw":{"2026-11-01":"H_"},"doc":"원본 사정 흔적 태그별 소멸 시각을 계산"},
    "canApplyExposureChange": {"raw":{"2026-11-01":"Vu"},"doc":"현재 복장과 노출 상태에 지정한 옷 벗기기 변화를 적용할 수 있는지 판정"},
    "patronSceneActionId": {"raw":{"2026-11-01":"Yp"},"doc":"원본 손님 행동 단계와 자리에서 사정 흔적 계산에 사용할 성행위 장면 ID를 결정"},
    "recentPatronIntimacySummary": {"raw":{"2026-11-01":"j_e"},"doc":"최근 목격한 손님 친밀행위의 주관적 좋음·중립·나쁨 요약; unaware 기록을 감정 분류에서 제외"},
    "intimacyReceptionLabels": {"raw":{"2026-11-01":"doe"},"doc":"원본 만남 기록 화면의 수용 상태 표시표; unaware 기록을 인지하지 못함으로 안전하게 표시"},
    "wifeExposureAftermathTick": {"raw":{"2026-11-01":"yxe"},"doc":"원본 개인 분 단위 노출·사후 흔적 정리; 기절 중 자발적인 복장 복구를 멈추는 데 사용"},
    "playerSexPleasureMultiplier": {"raw":{"2026-11-01":"fOe"},"doc":"원본 플레이어 성행위의 대상 절정 게이지 증가에 적용하는 동적 쾌감 배율; 실제 흥분도 20% 계산에도 같은 값을 사용"},
    "patronStageArousal": {"raw":{"2026-11-01":"dN"},"doc":"원본 손님 상호작용 단계별 대상 흥분도 기본값"},
    "originalIntimateFamiliarity": {"raw":{"2026-11-01":"Iue"},"doc":"원본 intimateHistory에서 상대·수용 범주별 친밀행위 익숙함 보정을 계산"},
    "recordActionAffinity": {"raw":{"2026-11-01":"Yc"},"doc":"인지된 사건의 행동 선호 노출 횟수와 완화된 valence를 원본 규칙으로 갱신"},
    "retireWife": {"raw":{"2026-11-01":"cm"},"doc":"원본 대상 인물의 위층 이동·잠옷·은퇴 상태 처리; 물약 대기 종료 시점에 호출"},
    "wifeSleepRoom": {"raw":{"2026-11-01":"ho"},"doc":"bedTonight을 우선하고 관계 기본값으로 대체하는 원본 당일 취침실 조회"},
    "nightIndex": {"raw":{"2026-11-01":"pt"},"doc":"새벽 경계를 포함해 현재 슬롯이 속한 영업 밤 번호를 계산"},
    "availablePrivateRoomInfo": {"raw":{"2026-11-01":"vj"},"doc":"pre6 원본의 실제 개방 방 목록; backRoomReady와 hasRoom/hasRoom2를 적용한 방 소유·침대 정보"},
    "privateRoomAvailableForPatron": {"raw":{"2026-11-01":"ux"},"doc":"pre6 원본의 개인 방 사용 가능 판정; 활성 사적 장면·뒷방 모임·플레이어·제삼자 점유를 검사"},
    "processPassedOutTransition": {"raw":{"2026-11-01":"qJe"},"doc":"원본 주 대상 인물의 음주 기절 전환; 같은 틱의 복귀 처리 전에 기존 이동·활동 예약을 폐기"},
    "ClosedDoorActions": {"raw":{"2026-11-01":"M5"},"doc":"일반 수면 손님 장면이 진행 중인 방의 원본 문 행동을 수면 장면 전용 문 행동으로 대체"},
    "approachClosedDoor": {"raw":{"2026-11-01":"m$"},"doc":"일반 수면 손님 장면의 대상 방 문밖으로 플레이어를 실제 이동"},
    "roomSideForOccupant": {"raw":{"2026-11-01":"nD"},"doc":"수면 손님 장면의 문 앞 플레이어를 원본 위치 패널에서 outside로 유지"},
    "relationshipInfluence": {"raw":{"2026-11-01":"fC"},"doc":"개입을 반기지 않을 때 플레이어의 제지를 따를 관계 영향력(Your say) 조회"},
    "wifeRestNeed": {"raw":{"2026-11-01":"Qn"},"doc":"원본 대상 인물의 현재 휴식 필요도; 기력·기분·원망·통증·당일 손님 학대를 합쳐 점진적 기상 속도를 조절"},
    "intoxicationBand": {"raw":{"2026-11-01":"Sn"},"doc":"원본 도수 단계 판정; blacked_out 단계에서는 기절 회복을 보류"},
    "settleWifeNaturalWake": {"raw":{"2026-11-01":"_et"},"doc":"원본 자연 기상 처리; wakeSlot·영업 시작·질병 상태를 그대로 적용"},
    "wifeSick": {"raw":{"2026-11-01":"Zj"},"doc":"원본 대상 인물 질병 판정; 앓는 중인 자연 수면은 점진 기상으로 강제 종료하지 않음"},
    "openingMinuteOfDay": {"raw":{"2026-11-01":"hn"},"doc":"원본 저녁 영업 시작 분; 자연 수면의 예정 기상 상한과 심도 감쇠 구간 계산"},
    "patronEscalationAwayAlert": {"raw":{"2026-11-01":"SG"},"doc":"원본 손님 행동이 몸 더듬기 경계를 넘었을 때 플레이어가 현장에 없으면 선을 넘는 중대 경고를 대기열에 추가"}
  },
  version: "1.14.9",
  game: "2026-11-01",
  loadAfter: ['badguest', 'qualified-experience', 'attention-image-prompt'],
  tags: ['h-scene'],
  description: '잠든 인물에게 적용할 수면 심도와 행동·사건 기반을 제공합니다.',

  async setup(api) {
    const ID = api.id;
    const T = (ko, en) => api.t({ ko, en });
    const h = api.ui.h;
    const React = api.fn('React');
    const JSX = api.fn('jsx');
    const ActionButton = api.fn('ActionButton');
    const PleasureGauge = api.fn('PleasureGauge');
    const intimacyReceptionLabels = api.fn('intimacyReceptionLabels');
    if (intimacyReceptionLabels && typeof intimacyReceptionLabels === 'object'
      && !intimacyReceptionLabels.unaware) {
      intimacyReceptionLabels.unaware = Object.freeze({
        label: T('인지하지 못함', 'Unaware'),
        color: 'text-stone-400',
      });
    }
    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
    const number = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
    const whole = (value, fallback = 0) => Math.round(number(value, fallback));
    const nonNegative = (value, fallback = 0) => Math.max(0, number(value, fallback));
    const SCHEMA_VERSION = 32;
    const LEGACY_POTION_ROOM_OWNER = `${ID}:legacy-potion-room`;
    const ENCOUNTER_HISTORY_LIMIT = 200;
    const MORNING_DISCOVERY_HISTORY_LIMIT = 100;
    const SLEEP_SELF_PLEASURE_RECORD_ID = 'sleep_self_pleasure';
    const IMAGE_PROMPT_MARKERS = Object.freeze({
      SELF_PLEASURE: 'sleep-actions:self-pleasure',
    });
    const AIP_SLEEP_LEVELS = Object.freeze(['light', 'middle', 'deep']);
    const AIP_BED_ROOMS = new Set(['bedroom', 'elena_room', 'upstairs_room_1', 'upstairs_room_2']);
    let attentionImagePrompt = null;
    const OPEN_ACTION = `${ID}/open`;
    const FORCE_PASS_OUT_ACTION = `${ID}/test-pass-out`;
    const CARRY_SLEEPING_TO_BED_ACTION = `${ID}/carry-sleeping-to-bed`;
    const PATRON_DOOR_KNOCK_ACTION = `${ID}/patron-door-knock`;
    const PATRON_DOOR_PEEK_ACTION = `${ID}/patron-door-peek`;
    const PATRON_DOOR_OPEN_ACTION = `${ID}/patron-door-open`;
    const PATRON_QUIET_SEPARATE_ACTION = `${ID}/patron-quiet-separate`;
    const PATRON_WAKE_INTERVENE_ACTION = `${ID}/patron-wake-intervene`;
    const PATRON_DOOR_LEAVE_ACTION = `${ID}/patron-door-leave`;
    const NATIVE_PATRON_DOOR_ACTIONS = new Set(['knock_on_door', 'peek_inside', 'open_the_door']);
    const PASSED_OUT_AUTONOMY_GUARD_SLOT = Number.MAX_SAFE_INTEGER;
    const PLAYER_SELF_PLEASURE_ID = 'player_self_pleasure';
    const PLAYER_PLEASURE_MULTIPLIER = 1;
    const WIFE_PLEASURE_MULTIPLIER = 1;
    const PLAYER_SELF_PLEASURE_BASE_GAIN = 16;
    const PLAYER_SELF_PLEASURE_AROUSAL_RATIO = 0.3;
    const ACTION_LOG_META = 'sleepActionsAction';

    const PLAYER_TOUCH_ACTIONS = Object.freeze({
      stroke: Object.freeze({
        label: T('쓰다듬기', 'Stroke her gently'),
        description: T('다정하고 익숙한 손길로 머리카락을 쓸어 넘깁니다.', 'Brush her hair back with a gentle, familiar touch.'),
        idle: true,
        log: name => T(
          `당신은 ${name}의 머리카락과 팔을 가볍게 쓰다듬습니다. 그녀는 고른 숨을 이어 갑니다.`,
          `You lightly stroke ${name}'s hair and arm. Her breathing remains even.`,
        ),
      }),
      kiss_real: Object.freeze({
        label: T('키스하기', 'Kiss her'),
        description: T('그녀를 가까이 끌어당겨 깊게 키스합니다.', 'Draw her close and kiss her deeply.'),
        imageScene: 'kissing',
        wifeArousal: 2,
        playerArousal: 2,
        log: name => T(
          `당신은 ${name}의 입술에 조심스럽게 입을 맞춥니다. 그녀의 입술이 희미하게 움직이지만 눈은 뜨지 않습니다.`,
          `You carefully kiss ${name}'s lips. They move faintly, but her eyes stay closed.`,
        ),
      }),
      touch_breasts: Object.freeze({
        label: T('가슴 만지기', 'Touch her breasts'),
        description: T('그녀의 가슴을 손바닥으로 감싸 쥐고 어루만집니다.', 'Cup her breasts in your palms and caress them.'),
        imageScene: 'groped_tits',
        wifeArousal: 2,
        playerArousal: 2,
        wifePleasure: 4,
        climaxScene: 'breast_worship',
        log: name => T(
          `당신은 ${name}의 가슴을 천천히 만집니다. 그녀의 호흡이 잠시 흐트러졌다가 다시 이어집니다.`,
          `You slowly touch ${name}'s breasts. Her breathing falters, then settles again.`,
        ),
      }),
      touch_over_clothes: Object.freeze({
        label: T('엉덩이 만지기', 'Touch her ass'),
        description: T('그녀의 엉덩이를 꽉 쥐고 천천히 어루만집니다.', 'Grip her ass and caress it slowly.'),
        imageScene: 'groped_ass',
        wifeArousal: 1,
        playerArousal: 1,
        wifePleasure: 3,
        climaxScene: 'ass_worship',
        log: name => T(
          `당신은 ${name}의 엉덩이를 천천히 만집니다. 그녀는 작게 숨을 내쉬지만 눈을 뜨지는 않습니다.`,
          `You slowly touch ${name}'s ass. She exhales softly without opening her eyes.`,
        ),
      }),
      manual_receiving: Object.freeze({
        label: T('치마 안쪽을 만지기', 'Touch between her thighs'),
        description: T('그녀의 다리 사이를 손가락으로 어루만집니다.', 'Caress between her legs with your fingers.'),
        imageScene: 'fingered',
        wifeArousal: 3,
        playerArousal: 2,
        wifePleasure: 14,
        climaxScene: 'fingering',
        log: name => T(
          `당신은 ${name}의 허벅지 안쪽으로 손을 움직여 은밀한 곳을 만집니다. 그녀의 다리가 미세하게 움직이고 숨이 조금 깊어집니다.`,
          `You move your hand along ${name}'s inner thigh and touch her intimately. Her legs shift slightly and her breathing deepens.`,
        ),
      }),
    });

    const PLAYER_UNDRESS_ACTIONS = Object.freeze({
      undress_bodice: Object.freeze({
        label: T('앞섶 풀기', 'Unlace her bodice'),
        description: T('그녀의 앞섶을 풀어 옷을 느슨하게 만듭니다.', 'Unlace her bodice and loosen her clothes.'),
        exposure: Object.freeze({ bodiceUnlaced: true, source: 'player' }),
        playerExposure: Object.freeze({ bodiceUnlaced: true, source: 'player' }),
        acceptanceActionId: 'visual_explicit',
      }),
      undress_top_down: Object.freeze({
        label: T('상의 내리기', 'Pull down her top'),
        description: T('그녀의 상의를 아래로 내려 가슴을 드러냅니다.', 'Pull down her top and bare her breasts.'),
        exposure: Object.freeze({ topPulledDown: true, source: 'player' }),
        playerExposure: Object.freeze({ bodiceUnlaced: true, topPulledDown: true, source: 'player' }),
        acceptanceActionId: 'visual_explicit',
      }),
      undress_top_remove: Object.freeze({
        label: T('상의 벗기기', 'Remove her top'),
        description: T('그녀의 상의를 완전히 벗깁니다.', 'Remove her top completely.'),
        exposure: Object.freeze({ topRemoved: true, source: 'player' }),
        playerExposure: Object.freeze({ bodiceUnlaced: true, topPulledDown: true, topRemoved: true, source: 'player' }),
        acceptanceActionId: 'visual_explicit',
      }),
      undress_skirt_up: Object.freeze({
        label: T('치마 걷기', 'Lift her skirt'),
        description: T('그녀의 치마를 허리까지 걷어 올립니다.', 'Lift her skirt to her waist.'),
        exposure: Object.freeze({ skirtUp: true, source: 'player' }),
        playerExposure: Object.freeze({ skirtUp: true, source: 'player' }),
        acceptanceActionId: 'visual_explicit',
      }),
      undress_skirt_remove: Object.freeze({
        label: T('치마 벗기기', 'Remove her skirt'),
        description: T('그녀의 치마를 완전히 벗깁니다.', 'Remove her skirt completely.'),
        exposure: Object.freeze({ skirtRemoved: true, source: 'player' }),
        playerExposure: Object.freeze({ skirtUp: true, skirtRemoved: true, source: 'player' }),
        acceptanceActionId: 'visual_explicit',
      }),
      undress_panties_aside: Object.freeze({
        label: T('속옷 옆으로 밀기', 'Move her panties aside'),
        description: T('그녀의 치마를 걷고 속옷을 옆으로 밀어 놓습니다.', 'Lift her skirt and move her panties aside.'),
        exposure: Object.freeze({ pantiesAside: true, source: 'player' }),
        playerExposure: Object.freeze({ skirtUp: true, pantiesAside: true, source: 'player' }),
        acceptanceActionId: 'visual_explicit',
      }),
      undress_panties_remove: Object.freeze({
        label: T('속옷 벗기기', 'Remove her panties'),
        description: T('그녀의 치마를 걷고 속옷을 완전히 벗깁니다.', 'Lift her skirt and remove her panties completely.'),
        exposure: Object.freeze({ pantiesRemoved: true, source: 'player' }),
        playerExposure: Object.freeze({ skirtUp: true, pantiesAside: true, pantiesRemoved: true, source: 'player' }),
        acceptanceActionId: 'visual_explicit',
      }),
    });
    const PLAYER_SELF_PLEASURE_ACTION = Object.freeze({
      label: T('자위하기', 'Masturbate'),
      description: T(
        '그녀의 곁에서 손으로 자신을 자극합니다.',
        'Touch yourself beside her.',
      ),
      imageScene: 'patron_self_stroke',
    });
    const PLAYER_ACTIONS = Object.freeze({
      ...PLAYER_TOUCH_ACTIONS,
      ...PLAYER_UNDRESS_ACTIONS,
      [PLAYER_SELF_PLEASURE_ID]: PLAYER_SELF_PLEASURE_ACTION,
    });

    const SEX_ACTION_IDS = Object.freeze([
      'grinding', 'thigh_job',
      'handjob', 'fingering',
      'blowjob', 'deepthroat', 'cunnilingus',
      'titfuck',
      'sex', 'doggy_style',
      'anal_fingering', 'anal',
    ]);
    const SEX_ACTION_SET = new Set(SEX_ACTION_IDS);
    const PLAYER_SESSION_ACTION_SET = new Set([...SEX_ACTION_IDS, PLAYER_SELF_PLEASURE_ID]);
    const SEX_ACCEPTANCE = Object.freeze({
      grinding: 'genital_rubbing',
      thigh_job: 'genital_rubbing',
      handjob: 'manual_giving',
      fingering: 'manual_receiving',
      blowjob: 'oral_giving',
      deepthroat: 'oral_giving',
      cunnilingus: 'oral_receiving',
      titfuck: 'oral_giving',
      sex: 'sex_vaginal',
      doggy_style: 'sex_vaginal',
      anal_fingering: 'sex_anal',
      anal: 'sex_anal',
    });
    const SEX_ACTION_DESCRIPTIONS = Object.freeze({
      grinding: T('옷을 입은 채 서로 몸을 비비기', 'Grinding together while still clothed'),
      thigh_job: T('삽입 없이 그녀의 허벅지 사이에 끼우기', 'Sliding between her thighs without penetration'),
      handjob: T('당신의 자지에 그녀의 손을 얹기', 'Putting her hand around your cock'),
      fingering: T('그녀의 안으로 손가락을 밀어 넣기', 'Sliding your fingers inside her'),
      blowjob: T('그녀의 입에 당신의 자지를 물리기', 'Putting your cock in her mouth'),
      deepthroat: T('당신의 자지를 목구멍 끝까지 받아들이게 하기', 'Making her take your cock to the back of her throat'),
      cunnilingus: T('그녀의 보지에 입을 대기', 'Putting your mouth on her pussy'),
      titfuck: T('그녀의 두 가슴 사이에 당신의 자지를 끼우기', 'Sliding your cock between her breasts'),
      sex: T('그녀의 보지에 삽입하기', 'Entering her pussy'),
      doggy_style: T('허리를 숙인 그녀에게 뒤에서 삽입하기', 'Entering her from behind while she bends over'),
      anal_fingering: T('항문에 손가락을 넣어 반응 보기', 'Sliding a finger into her anus and feeling her response'),
      anal: T('그녀의 항문에 삽입하기', 'Entering her anus'),
    });
    const SEX_EXPOSURE_REQUIREMENTS = Object.freeze({
      thigh_job: 'lower',
      fingering: 'lower',
      cunnilingus: 'lower',
      titfuck: 'upper',
      sex: 'lower',
      doggy_style: 'lower',
      anal_fingering: 'lower',
      anal: 'full',
    });
    const ACTION_AFFINITY_KEYS = Object.freeze({
      kiss_real: 'kiss',
      touch_over_clothes: 'grope_ass',
      touch_breasts: 'grope_tits',
      touch_under_skirt: 'touch_under_skirt',
      manual_receiving: 'finger_her',
      manual_giving: 'ask_handjob',
      oral_receiving: 'ask_oral_receive',
      oral_giving: 'ask_blowjob',
      genital_rubbing: 'ask_fuck',
      sex_vaginal: 'ask_fuck',
      sex_anal: 'ask_anal',
      visual_explicit: 'flash_naked',
      undress_bodice: 'flash_naked',
      undress_top_down: 'flash_naked',
      undress_top_remove: 'flash_naked',
      undress_skirt_up: 'flash_naked',
      undress_skirt_remove: 'flash_naked',
      undress_panties_aside: 'flash_naked',
      undress_panties_remove: 'flash_naked',
      cum_on_skin: 'cum_on_body',
    });
    const FINISH_LABELS = Object.freeze({
      cum_inside: Object.freeze({ label: T('안에 사정하기', 'Finish inside her'), description: T('몸을 빼지 않고 그녀의 안에 사정합니다.', 'Come inside her without pulling out.') }),
      cum_in_mouth: Object.freeze({ label: T('입안에 사정하기', 'Finish in her mouth'), description: T('그녀의 입안에 사정합니다.', 'Climax in her mouth.') }),
      cum_on_face: Object.freeze({ label: T('얼굴에 사정하기', 'Finish on her face'), description: T('몸을 빼고 얼굴에 사정합니다.', 'Pull away and finish on her face.') }),
      cum_on_breasts: Object.freeze({ label: T('가슴에 사정하기', 'Finish on her breasts'), description: T('가슴 위에 사정합니다.', 'Finish across her breasts.') }),
      cum_on_body: Object.freeze({ label: T('몸에 사정하기', 'Finish on her body'), description: T('몸을 빼고 피부 위에 사정합니다.', 'Pull out and finish on her body.') }),
      pull_out: Object.freeze({
        label: T('들키지 않게 마무리하기', 'Finish without leaving a trace'),
        description: T('몸에 흔적을 남기지 않도록 밖에 사정하고 조용히 정리합니다.', 'Finish away from her body and quietly clean up any trace.'),
      }),
    });
    const PLAYER_SELF_FINISH_IDS = Object.freeze([
      'cum_on_face', 'cum_on_breasts', 'cum_on_body', 'pull_out',
    ]);
    const PLAYER_SELF_FINISH_FLUID_TAGS = Object.freeze({
      cum_on_face: Object.freeze(['cum_on_face']),
      cum_on_breasts: Object.freeze(['cum_on_chest']),
      cum_on_body: Object.freeze(['cum_on_body']),
    });
    const SLEEP_IMAGE_SCENES = new Set([
      ...Object.values(PLAYER_ACTIONS).map(action => action.imageScene).filter(Boolean),
      ...SEX_ACTION_IDS.map(id => id === 'fingering' ? 'fingered' : id),
      'facial', 'cum_in_mouth', 'finish_on_chest', 'finish_on_stomach', 'finish_on_back',
    ]);
    const AFTERMATH_FLUID_TAGS = new Set([
      'cum_on_face', 'cum_on_chest', 'cum_on_body', 'cum_on_hands', 'cum_dripping_thighs',
    ]);
    const MORNING_FAMILIARITY_ACTIONS = Object.freeze({
      blowjob: Object.freeze({ category: 'oral_giving', setting: 'morningActionBlowjobChance' }),
      deepthroat: Object.freeze({ category: 'oral_giving', setting: 'morningActionDeepthroatChance' }),
      cunnilingus: Object.freeze({ category: 'oral_receiving', setting: 'morningActionCunnilingusChance' }),
      sex: Object.freeze({ category: 'sex_vaginal', setting: 'morningActionSexChance' }),
      doggy_style: Object.freeze({ category: 'sex_vaginal', setting: 'morningActionDoggyChance' }),
      anal_fingering: Object.freeze({ category: 'sex_anal', setting: 'morningActionAnalFingeringChance' }),
      anal: Object.freeze({ category: 'sex_anal', setting: 'morningActionAnalChance' }),
    });
    const MORNING_FINISH_CHANCE_SETTINGS = Object.freeze({
      cum_on_face: 'morningFinishFaceChance',
      cum_on_breasts: 'morningFinishBreastsChance',
      cum_on_body: 'morningFinishBodyChance',
      cum_in_mouth: 'morningFinishMouthChance',
      cum_inside_vaginal: 'morningFinishVaginalChance',
      cum_inside_anal: 'morningFinishAnalChance',
    });

    const PATRON_STAGES = Object.freeze([
      'chatting', 'flirting', 'light_touch', 'bold_touch', 'groping',
      'intimate', 'handjob_patron', 'blowjob_patron', 'rubbing_patron', 'sex_patron',
    ]);
    const PATRON_STAGE_INDEX = Object.freeze(Object.fromEntries(PATRON_STAGES.map((stage, index) => [stage, index])));
    const PATRON_SELF_STROKE_STAGE = 'self_stroke';
    const PATRON_ESCALATION_WARNING_INDEX = PATRON_STAGE_INDEX.groping;
    const PATRON_APPROACH_STYLES = Object.freeze([
      'cautious', 'teasing', 'direct', 'opportunistic', 'secretive',
    ]);
    const PATRON_STYLE_WEIGHT_SETTINGS = Object.freeze({
      cautious: 'patronStyleCautiousWeight',
      teasing: 'patronStyleTeasingWeight',
      direct: 'patronStyleDirectWeight',
      opportunistic: 'patronStyleOpportunisticWeight',
      secretive: 'patronStyleSecretiveWeight',
    });
    const PATRON_STYLE_RISK_SETTINGS = Object.freeze({
      cautious: 'patronRiskCautiousBonus',
      teasing: 'patronRiskTeasingBonus',
      direct: 'patronRiskDirectBonus',
      opportunistic: 'patronRiskOpportunisticBonus',
      secretive: 'patronRiskSecretiveBonus',
    });
    const DEFAULT_PATRON_GOAL_DROP_WEIGHTS = Object.freeze([50, 30, 20]);
    const DEFAULT_PATRON_ROUTE_PATTERN_WEIGHTS = Object.freeze([
      Object.freeze({ id: 'focused', weight: 10 }),
      Object.freeze({ id: 'upper-tour', weight: 20 }),
      Object.freeze({ id: 'lower-tour', weight: 20 }),
      Object.freeze({ id: 'full-tour', weight: 30 }),
      Object.freeze({ id: 'full-lower-focus', weight: 20 }),
    ]);
    const PATRON_PRIVATE_ROOMS = Object.freeze(['upstairs_room_2', 'back_room']);
    const PATRON_PRIVATE_FALLBACK_ROOMS = Object.freeze(['bathroom']);
    const LEGACY_POTION_GUEST_ROOMS = Object.freeze(['upstairs_hall', 'upstairs_room_2']);
    const PATRON_STAGE_ACTIONS = Object.freeze({
      bold_touch: Object.freeze({ actionId: 'touch_over_clothes', rate: 0, scene: 'patron_bold' }),
      groping: Object.freeze({ actionId: 'touch_breasts', rate: 0, scene: 'patron_groping' }),
      intimate: Object.freeze({ actionId: 'manual_receiving', rate: 0, scene: 'patron_intimate' }),
      handjob_patron: Object.freeze({ actionId: 'manual_giving', rate: 12, scene: 'patron_handjob' }),
      blowjob_patron: Object.freeze({ actionId: 'oral_giving', rate: 16, scene: 'patron_blowjob' }),
      rubbing_patron: Object.freeze({ actionId: 'genital_rubbing', rate: 7, wifeRate: 10, scene: 'patron_rubbing' }),
      sex_patron: Object.freeze({ actionId: 'sex_vaginal', rate: 8, wifeRate: 14, scene: 'patron_sex' }),
      [PATRON_SELF_STROKE_STAGE]: Object.freeze({
        actionId: 'watch_him', rate: 16, wifeRate: 0, scene: 'patron_self_stroke', noContact: true,
      }),
    });
    const PATRON_JOIN_SLOT_STAGE = Object.freeze({
      breasts: 'intimate',
      behind: 'groping',
      hand: 'handjob_patron',
      mouth: 'blowjob_patron',
      rubbing: 'rubbing_patron',
      inside: 'sex_patron',
      inside_anal: 'sex_patron',
      astride: 'sex_patron',
    });
    const PATRON_INTENTS = Object.freeze(['drink_only', 'talk_only', 'flirt_curious', 'interested', 'predatory']);
    const DEFAULT_PATRON_UNAWARE_SEARCH_MIN_CHANCE = 15;
    const DEFAULT_PATRON_UNAWARE_SEARCH_MAX_CHANCE = 45;
    const DEFAULT_PATRON_SEARCH_INTENT_MODIFIERS = Object.freeze({
      interested: 0,
      predatory: 15,
    });
    const DEFAULT_PATRON_SEARCH_TYPE_MODIFIERS = Object.freeze({
      regular: 0,
      charmer: 2,
      drunk_bold: -5,
      nobleman: 2,
      rogue: 10,
      wealthy_pervert: 12,
    });
    const DEFAULT_PATRON_SEARCH_TACTIC_MODIFIERS = Object.freeze({
      warm_builder: -4,
      smooth_charmer: 1,
      drink_pusher: 4,
      lap_grabber: 5,
      transactional: 4,
    });
    // Only the shared bedroom is protected from patrons searching across rooms.
    // Elena's own room remains reachable when she sleeps or passes out there.
    const PATRON_REMOTE_SEARCH_EXCLUDED_ROOMS = new Set(['bedroom']);
    const LEGACY_POTION_REQUEST_HISTORY_LIMIT = 128;

    const DEFAULTS = Object.freeze({
      initialDepth: 100,
      normalDepthCap: 100,
      recoveryPerMinuteMin: 1,
      recoveryPerMinuteMax: 3,
      repeatWindowMinutes: 2,
      sameActionMultiplier: 1,
      minimumDepthCost: 1,
      passedOutDepthMultiplier: 0.5,
      acceptanceDeficitRatio: 0.2,
      lightTouchDepthMin: 1,
      lightTouchDepthMax: 5,
      intimateTouchDepthMin: 2,
      intimateTouchDepthMax: 8,
      manualOralDepthMin: 3,
      manualOralDepthMax: 12,
      rubbingDepthMin: 4,
      rubbingDepthMax: 16,
      sexDepthMin: 5,
      sexDepthMax: 20,
      finishDepthMin: 2,
      finishDepthMax: 8,
      morningLowFamiliarityThreshold: 4,
      patronActionsEnabled: true,
      patronMinimumBoldness: 65,
      patronDepthEstimateVariance: 0.2,
      patronCooldownMinutes: 30,
      patronWatchMinMinutes: 3,
      patronWatchMaxMinutes: 7,
      patronUnawareSearchBaseChance: 30,
      patronUnawareSearchMinimum: 15,
      patronUnawareSearchMaximum: 45,
      patronSearchAbilityCenter: 50,
      patronSearchAbilityInfluence: 0.5,
      patronSearchWitWeight: 0.35,
      patronSearchComposureWeight: 0.25,
      patronSearchBoldnessWeight: 0.25,
      patronSearchCharmWeight: 0.15,
      patronSearchInterestedModifier: 0,
      patronSearchPredatoryModifier: 15,
      patronSearchRegularModifier: 0,
      patronSearchCharmerModifier: 2,
      patronSearchDrunkBoldModifier: -5,
      patronSearchNoblemanModifier: 2,
      patronSearchRogueModifier: 10,
      patronSearchWealthyPervertModifier: 12,
      patronSearchWarmBuilderModifier: -4,
      patronSearchSmoothCharmerModifier: 1,
      patronSearchDrinkPusherModifier: 4,
      patronSearchLapGrabberModifier: 5,
      patronSearchTransactionalModifier: 4,
      patronNonFinishMinTicks: 8,
      unconsciousRecoveryDelayMinutes: 90,
      wakeDepthLossMin: 1,
      wakeDepthLossMax: 3,
      patronPrivateMoveChance: 25,
      patronRiskyFinishBoldness: 65,
      patronStyleCautiousWeight: 1,
      patronStyleTeasingWeight: 1,
      patronStyleDirectWeight: 1,
      patronStyleOpportunisticWeight: 1,
      patronStyleSecretiveWeight: 1,
      patronRiskPredatoryBonus: 10,
      patronRiskCautiousBonus: -5,
      patronRiskTeasingBonus: 5,
      patronRiskDirectBonus: 10,
      patronRiskOpportunisticBonus: 10,
      patronRiskSecretiveBonus: 5,
      patronGoalMaximumWeight: 50,
      patronGoalOneBelowWeight: 30,
      patronGoalTwoBelowWeight: 20,
      patronRouteFocusedWeight: 10,
      patronRouteUpperTourWeight: 20,
      patronRouteLowerTourWeight: 20,
      patronRouteFullTourWeight: 30,
      patronRouteFullLowerFocusWeight: 20,
      patronStageComfortThreshold: 65,
      patronStageComfortBonus: 1,
      patronStageArousalThreshold: 55,
      patronStageArousalBonus: 1,
      patronStageIntoxicationThreshold: 30,
      patronStageIntoxicationBonus: 1,
      patronStageFullExposureBonus: 3,
      patronStagePartialExposureBonus: 2,
      patronStageSkirtOffBonus: 1,
      patronStageInterestedBoldnessThreshold: 60,
      patronStageInterestedBoldnessBonus: 2,
      patronStageInterestedHighBoldnessThreshold: 80,
      patronStageInterestedHighBoldnessBonus: 1,
      patronWakeAcceptancePenalty: 8,
      patronExplanationBeliefBonus: 8,
      patronExplanationEagerMargin: 15,
      patronExplanationEmphaticMargin: 20,
      patronInterventionInfluenceMargin: 15,
      patronInterventionInfluenceScale: 30,
      morningActionBlowjobChance: 48,
      morningActionDeepthroatChance: 68,
      morningActionCunnilingusChance: 38,
      morningActionSexChance: 62,
      morningActionDoggyChance: 68,
      morningActionAnalFingeringChance: 48,
      morningActionAnalChance: 82,
      morningFinishFaceChance: 49,
      morningFinishBreastsChance: 47,
      morningFinishBodyChance: 44,
      morningFinishMouthChance: 38,
      morningFinishVaginalChance: 36,
      morningFinishAnalChance: 44,
      morningRepeatEvidenceBonus: 5,
      morningRepeatEvidenceCap: 15,
      morningSecondaryEvidenceBonus: 4,
      morningSecondaryEvidenceCap: 12,
      morningNoticeWitWeight: 0.45,
      morningNoticeComposureWeight: 0.15,
      morningNoticeMinimum: 5,
      morningNoticeMaximum: 99,
      morningConfrontBaseChance: 45,
      morningConfrontConfidenceWeight: 0.45,
      morningConfrontHonestyWeight: 0.2,
      morningConfrontComposureWeight: 0.15,
      morningConfrontTrustWeight: 0.1,
      morningConfrontResentmentWeight: 0.2,
      morningConfrontDominantBonus: 18,
      morningConfrontSelfProtectiveBonus: 15,
      morningConfrontPrudeBonus: 12,
      morningConfrontPragmatistBonus: 8,
      morningConfrontPressureBonus: -18,
      morningConfrontSubmissiveBonus: -12,
      morningConfrontCorruptionBonus: -10,
      morningConfrontGuiltBonus: -8,
      morningConfrontRomanceBonus: -5,
      morningConfrontMinimum: 5,
      morningConfrontMaximum: 95,
      morningDenialBaseChance: 35,
      morningDenialCunningWeight: 0.55,
      morningDenialWitWeight: 0.45,
      morningDenialConfidenceWeight: 0.15,
      morningDenialMinimum: 5,
      morningDenialMaximum: 75,
    });

    const DEPTH_RULES = Object.freeze({
      light_touch: Object.freeze({ min: 1, max: 5 }),
      intimate_touch: Object.freeze({ min: 2, max: 8 }),
      manual_oral: Object.freeze({ min: 3, max: 12 }),
      rubbing: Object.freeze({ min: 4, max: 16 }),
      sex: Object.freeze({ min: 5, max: 20 }),
      finish: Object.freeze({ min: 2, max: 8 }),
    });
    const DEPTH_SETTING_KEYS = Object.freeze({
      light_touch: Object.freeze({ min: 'lightTouchDepthMin', max: 'lightTouchDepthMax' }),
      intimate_touch: Object.freeze({ min: 'intimateTouchDepthMin', max: 'intimateTouchDepthMax' }),
      manual_oral: Object.freeze({ min: 'manualOralDepthMin', max: 'manualOralDepthMax' }),
      rubbing: Object.freeze({ min: 'rubbingDepthMin', max: 'rubbingDepthMax' }),
      sex: Object.freeze({ min: 'sexDepthMin', max: 'sexDepthMax' }),
      finish: Object.freeze({ min: 'finishDepthMin', max: 'finishDepthMax' }),
    });

    const ACTION_CLASSES = Object.freeze({
      visual_modest: 'light_touch',
      visual_thigh: 'light_touch',
      visual_undergarments: 'light_touch',
      visual_explicit: 'intimate_touch',
      visual_topless: 'intimate_touch',
      visual_bottomless: 'intimate_touch',
      visual_full_nude: 'intimate_touch',
      kiss_chaste: 'light_touch',
      kiss_real: 'intimate_touch',
      touch_over_clothes: 'light_touch',
      touch_breasts: 'intimate_touch',
      touch_under_skirt: 'intimate_touch',
      manual_giving: 'manual_oral',
      manual_receiving: 'manual_oral',
      oral_giving: 'manual_oral',
      oral_receiving: 'manual_oral',
      watch_him: 'manual_oral',
      genital_rubbing: 'rubbing',
      sex_vaginal: 'sex',
      sex_rough: 'sex',
      sex_anal: 'sex',
      sex_public: 'sex',
      cum_on_skin: 'finish',
      cum_on_face: 'finish',
      cum_in_mouth: 'finish',
      cum_swallow: 'finish',
    });

    const listeners = new Map();
    const patronFlowOwners = new Map();
    const patronWakeObservers = new Map();
    const patronSearchResolvers = new Map();
    let statusWindow = null;

    function settings() {
      const raw = api.settings.get({}) || {};
      const saved = { ...DEFAULTS, ...raw };
      const hasSplitRecovery = Object.prototype.hasOwnProperty.call(raw, 'recoveryPerMinuteMin')
        || Object.prototype.hasOwnProperty.call(raw, 'recoveryPerMinuteMax');
      const legacyRecovery = !hasSplitRecovery && Number.isFinite(Number(raw.recoveryPerMinute))
        ? nonNegative(raw.recoveryPerMinute, DEFAULTS.recoveryPerMinuteMin) : null;
      const recoveryMin = legacyRecovery ?? nonNegative(
        saved.recoveryPerMinuteMin, DEFAULTS.recoveryPerMinuteMin,
      );
      const recoveryMax = legacyRecovery ?? nonNegative(
        saved.recoveryPerMinuteMax, DEFAULTS.recoveryPerMinuteMax,
      );
      return {
        initialDepth: Math.max(1, number(saved.initialDepth, DEFAULTS.initialDepth)),
        normalDepthCap: Math.max(1, number(saved.normalDepthCap, DEFAULTS.normalDepthCap)),
        recoveryPerMinuteMin: recoveryMin,
        recoveryPerMinuteMax: Math.max(recoveryMin, recoveryMax),
        repeatWindowMinutes: Math.max(0, whole(saved.repeatWindowMinutes, DEFAULTS.repeatWindowMinutes)),
        sameActionMultiplier: nonNegative(saved.sameActionMultiplier, DEFAULTS.sameActionMultiplier),
        minimumDepthCost: nonNegative(saved.minimumDepthCost, DEFAULTS.minimumDepthCost),
        passedOutDepthMultiplier: nonNegative(saved.passedOutDepthMultiplier, DEFAULTS.passedOutDepthMultiplier),
        acceptanceDeficitRatio: nonNegative(saved.acceptanceDeficitRatio, DEFAULTS.acceptanceDeficitRatio),
        lightTouchDepthMin: nonNegative(saved.lightTouchDepthMin, DEFAULTS.lightTouchDepthMin),
        lightTouchDepthMax: nonNegative(saved.lightTouchDepthMax, DEFAULTS.lightTouchDepthMax),
        intimateTouchDepthMin: nonNegative(saved.intimateTouchDepthMin, DEFAULTS.intimateTouchDepthMin),
        intimateTouchDepthMax: nonNegative(saved.intimateTouchDepthMax, DEFAULTS.intimateTouchDepthMax),
        manualOralDepthMin: nonNegative(saved.manualOralDepthMin, DEFAULTS.manualOralDepthMin),
        manualOralDepthMax: nonNegative(saved.manualOralDepthMax, DEFAULTS.manualOralDepthMax),
        rubbingDepthMin: nonNegative(saved.rubbingDepthMin, DEFAULTS.rubbingDepthMin),
        rubbingDepthMax: nonNegative(saved.rubbingDepthMax, DEFAULTS.rubbingDepthMax),
        sexDepthMin: nonNegative(saved.sexDepthMin, DEFAULTS.sexDepthMin),
        sexDepthMax: nonNegative(saved.sexDepthMax, DEFAULTS.sexDepthMax),
        finishDepthMin: nonNegative(saved.finishDepthMin, DEFAULTS.finishDepthMin),
        finishDepthMax: nonNegative(saved.finishDepthMax, DEFAULTS.finishDepthMax),
        morningLowFamiliarityThreshold: nonNegative(
          saved.morningLowFamiliarityThreshold, DEFAULTS.morningLowFamiliarityThreshold,
        ),
        patronActionsEnabled: saved.patronActionsEnabled !== false,
        patronMinimumBoldness: nonNegative(saved.patronMinimumBoldness, DEFAULTS.patronMinimumBoldness),
        patronDepthEstimateVariance: nonNegative(saved.patronDepthEstimateVariance, DEFAULTS.patronDepthEstimateVariance),
        patronCooldownMinutes: nonNegative(saved.patronCooldownMinutes, DEFAULTS.patronCooldownMinutes),
        patronWatchMinMinutes: nonNegative(saved.patronWatchMinMinutes, DEFAULTS.patronWatchMinMinutes),
        patronWatchMaxMinutes: nonNegative(saved.patronWatchMaxMinutes, DEFAULTS.patronWatchMaxMinutes),
        patronUnawareSearchBaseChance: nonNegative(
          saved.patronUnawareSearchBaseChance, DEFAULTS.patronUnawareSearchBaseChance,
        ),
        patronUnawareSearchMinimum: number(saved.patronUnawareSearchMinimum, DEFAULTS.patronUnawareSearchMinimum),
        patronUnawareSearchMaximum: number(saved.patronUnawareSearchMaximum, DEFAULTS.patronUnawareSearchMaximum),
        patronSearchAbilityCenter: number(saved.patronSearchAbilityCenter, DEFAULTS.patronSearchAbilityCenter),
        patronSearchAbilityInfluence: number(saved.patronSearchAbilityInfluence, DEFAULTS.patronSearchAbilityInfluence),
        patronSearchWitWeight: nonNegative(saved.patronSearchWitWeight, DEFAULTS.patronSearchWitWeight),
        patronSearchComposureWeight: nonNegative(saved.patronSearchComposureWeight, DEFAULTS.patronSearchComposureWeight),
        patronSearchBoldnessWeight: nonNegative(saved.patronSearchBoldnessWeight, DEFAULTS.patronSearchBoldnessWeight),
        patronSearchCharmWeight: nonNegative(saved.patronSearchCharmWeight, DEFAULTS.patronSearchCharmWeight),
        patronNonFinishMinTicks: nonNegative(saved.patronNonFinishMinTicks, DEFAULTS.patronNonFinishMinTicks),
        unconsciousRecoveryDelayMinutes: nonNegative(
          saved.unconsciousRecoveryDelayMinutes, DEFAULTS.unconsciousRecoveryDelayMinutes,
        ),
        wakeDepthLossMin: nonNegative(saved.wakeDepthLossMin, DEFAULTS.wakeDepthLossMin),
        wakeDepthLossMax: nonNegative(saved.wakeDepthLossMax, DEFAULTS.wakeDepthLossMax),
        patronPrivateMoveChance: nonNegative(saved.patronPrivateMoveChance, DEFAULTS.patronPrivateMoveChance),
        patronRiskyFinishBoldness: number(saved.patronRiskyFinishBoldness, DEFAULTS.patronRiskyFinishBoldness),
        patronStyleCautiousWeight: nonNegative(saved.patronStyleCautiousWeight, DEFAULTS.patronStyleCautiousWeight),
        patronStyleTeasingWeight: nonNegative(saved.patronStyleTeasingWeight, DEFAULTS.patronStyleTeasingWeight),
        patronStyleDirectWeight: nonNegative(saved.patronStyleDirectWeight, DEFAULTS.patronStyleDirectWeight),
        patronStyleOpportunisticWeight: nonNegative(saved.patronStyleOpportunisticWeight, DEFAULTS.patronStyleOpportunisticWeight),
        patronStyleSecretiveWeight: nonNegative(saved.patronStyleSecretiveWeight, DEFAULTS.patronStyleSecretiveWeight),
        patronRiskPredatoryBonus: number(saved.patronRiskPredatoryBonus, DEFAULTS.patronRiskPredatoryBonus),
        patronRiskCautiousBonus: number(saved.patronRiskCautiousBonus, DEFAULTS.patronRiskCautiousBonus),
        patronRiskTeasingBonus: number(saved.patronRiskTeasingBonus, DEFAULTS.patronRiskTeasingBonus),
        patronRiskDirectBonus: number(saved.patronRiskDirectBonus, DEFAULTS.patronRiskDirectBonus),
        patronRiskOpportunisticBonus: number(saved.patronRiskOpportunisticBonus, DEFAULTS.patronRiskOpportunisticBonus),
        patronRiskSecretiveBonus: number(saved.patronRiskSecretiveBonus, DEFAULTS.patronRiskSecretiveBonus),
        ...Object.fromEntries([
          'patronSearchInterestedModifier', 'patronSearchPredatoryModifier',
          'patronSearchRegularModifier', 'patronSearchCharmerModifier',
          'patronSearchDrunkBoldModifier', 'patronSearchNoblemanModifier',
          'patronSearchRogueModifier', 'patronSearchWealthyPervertModifier',
          'patronSearchWarmBuilderModifier', 'patronSearchSmoothCharmerModifier',
          'patronSearchDrinkPusherModifier', 'patronSearchLapGrabberModifier',
          'patronSearchTransactionalModifier', 'patronStageComfortThreshold',
          'patronStageComfortBonus', 'patronStageArousalThreshold', 'patronStageArousalBonus',
          'patronStageIntoxicationThreshold', 'patronStageIntoxicationBonus',
          'patronStageFullExposureBonus', 'patronStagePartialExposureBonus',
          'patronStageSkirtOffBonus', 'patronStageInterestedBoldnessThreshold',
          'patronStageInterestedBoldnessBonus', 'patronStageInterestedHighBoldnessThreshold',
          'patronStageInterestedHighBoldnessBonus', 'patronWakeAcceptancePenalty',
          'patronExplanationBeliefBonus', 'patronExplanationEagerMargin',
          'patronExplanationEmphaticMargin', 'patronInterventionInfluenceMargin',
          'morningActionBlowjobChance', 'morningActionDeepthroatChance',
          'morningActionCunnilingusChance', 'morningActionSexChance', 'morningActionDoggyChance',
          'morningActionAnalFingeringChance', 'morningActionAnalChance', 'morningFinishFaceChance',
          'morningFinishBreastsChance', 'morningFinishBodyChance', 'morningFinishMouthChance',
          'morningFinishVaginalChance', 'morningFinishAnalChance', 'morningRepeatEvidenceBonus',
          'morningRepeatEvidenceCap', 'morningSecondaryEvidenceBonus', 'morningSecondaryEvidenceCap',
          'morningNoticeWitWeight', 'morningNoticeComposureWeight', 'morningNoticeMinimum',
          'morningNoticeMaximum', 'morningConfrontBaseChance', 'morningConfrontConfidenceWeight',
          'morningConfrontHonestyWeight', 'morningConfrontComposureWeight', 'morningConfrontTrustWeight',
          'morningConfrontResentmentWeight', 'morningConfrontDominantBonus',
          'morningConfrontSelfProtectiveBonus', 'morningConfrontPrudeBonus',
          'morningConfrontPragmatistBonus', 'morningConfrontPressureBonus',
          'morningConfrontSubmissiveBonus', 'morningConfrontCorruptionBonus',
          'morningConfrontGuiltBonus', 'morningConfrontRomanceBonus', 'morningConfrontMinimum',
          'morningConfrontMaximum', 'morningDenialBaseChance', 'morningDenialCunningWeight',
          'morningDenialWitWeight', 'morningDenialConfidenceWeight', 'morningDenialMinimum',
          'morningDenialMaximum',
        ].map(key => [key, number(saved[key], DEFAULTS[key])])),
        ...Object.fromEntries([
          'patronGoalMaximumWeight', 'patronGoalOneBelowWeight', 'patronGoalTwoBelowWeight',
          'patronRouteFocusedWeight', 'patronRouteUpperTourWeight', 'patronRouteLowerTourWeight',
          'patronRouteFullTourWeight', 'patronRouteFullLowerFocusWeight',
          'patronInterventionInfluenceScale',
        ].map(key => [key, nonNegative(saved[key], DEFAULTS[key])])),
      };
    }

    function depthRule(value, actionClass) {
      const fallback = DEPTH_RULES[actionClass] || DEPTH_RULES.intimate_touch;
      const keys = DEPTH_SETTING_KEYS[actionClass] || DEPTH_SETTING_KEYS.intimate_touch;
      const min = nonNegative(value[keys.min], fallback.min);
      return {
        ratio: nonNegative(value.acceptanceDeficitRatio, DEFAULTS.acceptanceDeficitRatio),
        min,
        max: Math.max(min, nonNegative(value[keys.max], fallback.max)),
      };
    }

    function normalizePatronRoute(source, fallbackStage) {
      if (!Array.isArray(source)) return [];
      return source.flatMap(step => {
        if (step?.kind === 'action' && PATRON_STAGE_ACTIONS[step.stage]) {
          return [{
            kind: 'action',
            stage: step.stage,
            ticks: Math.max(1, whole(step.ticks, DEFAULTS.patronNonFinishMinTicks)),
            actionId: step.stage === 'groping'
              && ['touch_breasts', 'touch_under_skirt'].includes(step.actionId)
              ? step.actionId : null,
          }];
        }
        if (step?.kind === 'undress' && PLAYER_UNDRESS_ACTIONS[step.actionId]) {
          return [{
            kind: 'undress',
            actionId: step.actionId,
            exposure: { ...PLAYER_UNDRESS_ACTIONS[step.actionId].exposure, source: 'patron' },
          }];
        }
        return [];
      }).filter((step, index, steps) => step.kind !== 'action'
        || step.stage !== fallbackStage || index === steps.length - 1);
    }

    function normalizePatronApproach(source) {
      if (!source || typeof source !== 'object' || typeof source.customerId !== 'string') return null;
      return {
        customerId: source.customerId,
        customerName: typeof source.customerName === 'string' ? source.customerName : source.customerId,
        startedAtSlot: whole(source.startedAtSlot),
        readyAtSlot: Math.max(whole(source.startedAtSlot), whole(source.readyAtSlot)),
        style: PATRON_APPROACH_STYLES.includes(source.style) ? source.style : 'cautious',
        preferPrivate: source.preferPrivate === true,
        forcePrivate: source.forcePrivate === true,
        sourceRoom: typeof source.sourceRoom === 'string' ? source.sourceRoom : null,
        targetRoom: typeof source.targetRoom === 'string' ? source.targetRoom : null,
        reason: typeof source.reason === 'string' ? source.reason : null,
        ownerId: typeof source.ownerId === 'string' ? source.ownerId : null,
        minimumIntent: PATRON_INTENTS.includes(source.minimumIntent)
          ? source.minimumIntent : null,
      };
    }

    function normalizePatronTransfer(source) {
      if (!source || typeof source !== 'object' || typeof source.originRoom !== 'string') return null;
      return {
        originRoom: source.originRoom,
        destinationRoom: typeof source.destinationRoom === 'string' ? source.destinationRoom : null,
        returnRoom: typeof source.returnRoom === 'string' ? source.returnRoom : source.originRoom,
        customerId: typeof source.customerId === 'string' ? source.customerId : null,
        sleepUnderway: source.sleepUnderway !== false,
      };
    }

    function normalizePatronParticipants(source) {
      const result = {};
      for (const [customerId, participant] of Object.entries(source || {})) {
        if (!participant || !PATRON_STAGE_ACTIONS[participant.stage]) continue;
        const targetStage = PATRON_STAGE_ACTIONS[participant.targetStage]
          ? participant.targetStage : participant.stage;
        const route = normalizePatronRoute(participant.route, targetStage);
        result[customerId] = {
          customerId,
          customerName: typeof participant.customerName === 'string' ? participant.customerName : customerId,
          stage: participant.stage,
          actionId: ['touch_breasts', 'touch_under_skirt'].includes(participant.actionId)
            ? participant.actionId : null,
          slot: typeof participant.slot === 'string' ? participant.slot : null,
          pleasure: clamp(number(participant.pleasure), 0, 100),
          ticks: Math.max(0, whole(participant.ticks)),
          stepTicks: Math.max(0, whole(participant.stepTicks)),
          routeIndex: clamp(whole(participant.routeIndex), 0, Math.max(0, route.length - 1)),
          route,
          targetStage,
          approachStyle: PATRON_APPROACH_STYLES.includes(participant.approachStyle)
            ? participant.approachStyle : 'cautious',
          completed: participant.completed === true,
          wakeRisk: participant.wakeRisk === true,
          finishActionId: typeof participant.finishActionId === 'string' ? participant.finishActionId : null,
          returnRoom: typeof participant.returnRoom === 'string' ? participant.returnRoom : null,
          cooldownMinutes: participant.cooldownMinutes == null ? null
            : clamp(whole(participant.cooldownMinutes), 0, 240),
        };
      }
      return result;
    }

    function normalizePendingPatronRoomReturns(source) {
      const result = {};
      for (const [customerId, item] of Object.entries(source || {})) {
        if (!item || typeof customerId !== 'string' || !customerId) continue;
        result[customerId] = {
          customerId,
          returnRoom: typeof item.returnRoom === 'string' ? item.returnRoom : null,
        };
      }
      return result;
    }

    function normalizePatronFinishSignals(source) {
      if (!Array.isArray(source)) return [];
      return source.flatMap(signal => {
        if (!signal || signal.vaginalDeposit !== true || typeof signal.sourceId !== 'string') return [];
        return [{
          sourceId: signal.sourceId,
          sourceName: typeof signal.sourceName === 'string' ? signal.sourceName : signal.sourceId,
          position: typeof signal.position === 'string' ? signal.position : 'inside',
          boldness: number(signal.boldness, 56),
          comfort: number(signal.comfort, 0),
          pleasure: clamp(number(signal.pleasure), 0, 100),
          slot: whole(signal.slot),
          vaginalDeposit: true,
        }];
      }).slice(-8);
    }

    function normalizeEncounterHistory(source) {
      if (!Array.isArray(source)) return [];
      return source.slice(-ENCOUNTER_HISTORY_LIMIT).flatMap(entry => {
        if (!entry || typeof entry !== 'object' || typeof entry.eventId !== 'string') return [];
        return [{
          eventId: entry.eventId,
          characterId: String(entry.characterId || ''),
          sourceType: entry.sourceType === 'patron' ? 'patron' : 'player',
          sourceId: String(entry.sourceId || entry.sourceType || ''),
          sourceName: typeof entry.sourceName === 'string' ? entry.sourceName : null,
          actionId: typeof entry.actionId === 'string' ? entry.actionId : null,
          stage: typeof entry.stage === 'string' ? entry.stage : null,
          position: typeof entry.position === 'string' ? entry.position : null,
          finishId: typeof entry.finishId === 'string' ? entry.finishId : null,
          vaginalDeposit: entry.vaginalDeposit === true,
          orgasmed: entry.orgasmed === true,
          awareness: 'unaware',
          playerWitnessed: entry.playerWitnessed === true,
          day: whole(entry.day, 1),
          slot: whole(entry.slot),
        }];
      });
    }

    function normalizeMorningEvidence(source) {
      if (!Array.isArray(source)) return [];
      return source.flatMap(item => {
        if (!item || typeof item !== 'object' || typeof item.key !== 'string') return [];
        return [{
          key: item.key,
          kind: item.kind === 'finish' ? 'finish' : 'action',
          actionId: typeof item.actionId === 'string' ? item.actionId : null,
          category: typeof item.category === 'string' ? item.category : null,
          finishId: typeof item.finishId === 'string' ? item.finishId : null,
          affinityKey: typeof item.affinityKey === 'string' ? item.affinityKey : null,
          sourceId: item.sourceId == null ? null : String(item.sourceId),
          sourceName: typeof item.sourceName === 'string' ? item.sourceName : null,
          chance: clamp(number(item.chance), 0, 100),
          count: Math.max(1, whole(item.count, 1)),
        }];
      }).slice(-20);
    }

    function normalizeMorningIncidents(source) {
      if (!Array.isArray(source)) return [];
      return source.flatMap(item => {
        if (!item || typeof item !== 'object' || typeof item.id !== 'string') return [];
        const evidence = normalizeMorningEvidence(item.evidence);
        if (!evidence.length) return [];
        return [{
          id: item.id,
          characterId: String(item.characterId || ''),
          sourceType: item.sourceType === 'patron' ? 'patron' : 'player',
          patrons: Array.isArray(item.patrons) ? item.patrons.flatMap(patron => (
            patron && patron.id != null ? [{
              id: String(patron.id),
              name: typeof patron.name === 'string' ? patron.name : String(patron.id),
            }] : []
          )).slice(-8) : [],
          sessionStartedAtSlot: whole(item.sessionStartedAtSlot),
          dayStarted: whole(item.dayStarted, 1),
          readyAtSlot: item.readyAtSlot == null ? null : whole(item.readyAtSlot),
          noticeRoll: clamp(number(item.noticeRoll, 1), 0, 1),
          confrontRoll: clamp(number(item.confrontRoll, 1), 0, 1),
          denialRoll: clamp(number(item.denialRoll, 1), 0, 1),
          evidence,
        }];
      }).slice(-12);
    }

    function normalizeMorningDiscoveryHistory(source) {
      if (!Array.isArray(source)) return [];
      return source.filter(item => item && typeof item === 'object' && typeof item.id === 'string')
        .slice(-MORNING_DISCOVERY_HISTORY_LIMIT)
        .map(item => ({
          ...item,
          id: item.id,
          characterId: String(item.characterId || ''),
          sourceType: item.sourceType === 'patron' ? 'patron' : 'player',
          patrons: Array.isArray(item.patrons) ? item.patrons.flatMap(patron => (
            patron && patron.id != null ? [{
              id: String(patron.id),
              name: typeof patron.name === 'string' ? patron.name : String(patron.id),
            }] : []
          )).slice(-8) : [],
          reaction: typeof item.reaction === 'string' ? item.reaction : null,
          finishCount: Math.max(0, whole(item.finishCount)),
          noticed: item.noticed === true,
          confronted: item.confronted === true,
          day: whole(item.day, 1),
          slot: whole(item.slot),
        }));
    }

    function normalizePatronCooldowns(source) {
      const result = {};
      for (const [customerId, untilSlot] of Object.entries(source || {})) {
        if (!customerId || !Number.isFinite(Number(untilSlot))) continue;
        result[customerId] = Math.max(0, whole(untilSlot));
      }
      return result;
    }

    function normalizePatronDoor(source) {
      if (!source || typeof source !== 'object'
        || typeof source.customerId !== 'string'
        || typeof source.room !== 'string') return null;
      return {
        customerId: source.customerId,
        room: source.room,
        side: source.side === 'inside' ? 'inside' : 'outside',
        returnRoom: typeof source.returnRoom === 'string' ? source.returnRoom : null,
      };
    }

    function normalizePendingInterventionReturn(source) {
      if (!source || typeof source !== 'object'
        || typeof source.customerId !== 'string') return null;
      return { customerId: source.customerId };
    }

    function normalizeLegacyPotionRequests(source) {
      if (!Array.isArray(source)) return [];
      return source.flatMap(item => {
        if (!item || typeof item !== 'object'
          || typeof item.requestId !== 'string' || !item.requestId
          || typeof item.source !== 'string' || !item.source
          || typeof item.targetCharacterId !== 'string' || !item.targetCharacterId) return [];
        return [{
          status: 'completed',
          requestId: item.requestId,
          source: item.source,
          actorId: typeof item.actorId === 'string' && item.actorId ? item.actorId : null,
          targetCharacterId: item.targetCharacterId,
          doseNumber: Math.max(1, whole(item.doseNumber, 1)),
          effectiveUnits: Math.max(0, number(item.effectiveUnits)),
          depthAdded: Math.max(0, number(item.depthAdded)),
          moveAtSlot: Math.max(0, whole(item.moveAtSlot)),
          room: LEGACY_POTION_GUEST_ROOMS.includes(item.room) ? item.room : null,
          requestedAtSlot: Math.max(0, whole(item.requestedAtSlot)),
        }];
      }).slice(-LEGACY_POTION_REQUEST_HISTORY_LIMIT);
    }

    function normalizeData(value) {
      const source = value && typeof value === 'object' ? value : {};
      return {
        schemaVersion: SCHEMA_VERSION,
        session: source.session && typeof source.session === 'object' ? {
          kind: source.session.kind === 'patron' ? 'patron' : 'player',
          characterId: source.session.characterId,
          unconsciousState: source.session.unconsciousState === 'passed_out' ? 'passed_out'
            : source.session.unconsciousState === 'sleeping' ? 'sleeping'
              : source.session.kind === 'patron' ? 'passed_out' : 'sleeping',
          startedAtSlot: whole(source.session.startedAtSlot),
          lastDepthUpdateSlot: source.session.lastDepthUpdateSlot == null
            ? null : whole(source.session.lastDepthUpdateSlot),
          depth: Math.max(0, number(source.session.depth, DEFAULTS.initialDepth)),
          lastActionKey: source.session.lastActionKey || null,
          lastActionSlot: source.session.lastActionSlot == null ? null : whole(source.session.lastActionSlot),
          lastActionSlots: source.session.lastActionSlots && typeof source.session.lastActionSlots === 'object'
            ? source.session.lastActionSlots : {},
          activeThisMinute: source.session.activeThisMinute === true,
          experienceSessionId: typeof source.session.experienceSessionId === 'string'
            && source.session.experienceSessionId ? source.session.experienceSessionId
            : `sleep-actions:${source.session.characterId || 'unknown'}:${whole(source.session.startedAtSlot)}:${source.session.kind === 'patron' ? 'patron' : 'player'}`,
          completedActionSequence: Math.max(0, whole(source.session.completedActionSequence)),
          imageActionId: PLAYER_ACTIONS[source.session.imageActionId] || SEX_ACTION_SET.has(source.session.imageActionId)
            ? source.session.imageActionId : null,
          playerPleasure: clamp(number(source.session.playerPleasure), 0, 100),
          wifePleasure: clamp(number(source.session.wifePleasure), 0, 100),
          wifeClimaxCount: Math.max(0, whole(source.session.wifeClimaxCount)),
          sexStarted: source.session.sexStarted === true,
          currentSexActionId: PLAYER_SESSION_ACTION_SET.has(source.session.currentSexActionId)
            ? source.session.currentSexActionId : null,
          finishScene: typeof source.session.finishScene === 'string' ? source.session.finishScene : null,
          playerFinished: source.session.playerFinished === true,
          patronPrimaryId: typeof source.session.patronPrimaryId === 'string'
            ? source.session.patronPrimaryId : null,
          patronOwnerId: typeof source.session.patronOwnerId === 'string'
            ? source.session.patronOwnerId : null,
          patronApproach: normalizePatronApproach(source.session.patronApproach),
          patronAwareCustomerIds: Array.isArray(source.session.patronAwareCustomerIds)
            ? [...new Set(source.session.patronAwareCustomerIds.filter(
              customerId => typeof customerId === 'string' && customerId,
            ))].slice(-64) : [],
          patronParticipants: normalizePatronParticipants(source.session.patronParticipants),
          patronTransfer: normalizePatronTransfer(source.session.patronTransfer),
        } : null,
        sleepEncounterHistory: normalizeEncounterHistory(source.sleepEncounterHistory),
        morningIncidents: normalizeMorningIncidents(source.morningIncidents),
        morningDiscoveryHistory: normalizeMorningDiscoveryHistory(source.morningDiscoveryHistory),
        patronCooldowns: normalizePatronCooldowns(source.patronCooldowns),
        patronFinishSignals: normalizePatronFinishSignals(source.patronFinishSignals),
        patronResumeScene: source.patronResumeScene && typeof source.patronResumeScene === 'object'
          ? source.patronResumeScene : null,
        pendingPatronReturn: normalizePatronTransfer(source.pendingPatronReturn),
        pendingPatronRoomReturns: normalizePendingPatronRoomReturns(
          source.pendingPatronRoomReturns,
        ),
        patronDoor: normalizePatronDoor(source.patronDoor),
        pendingInterventionReturn: normalizePendingInterventionReturn(
          source.pendingInterventionReturn,
        ),
        pendingSleepPotionDepth: Math.max(0, number(source.pendingSleepPotionDepth)),
        pendingSleepPotionMoveAtSlot: source.pendingSleepPotionMoveAtSlot == null
          ? whole(source.schemaVersion) < 20 && number(source.pendingSleepPotionDepth) > 0 ? 0 : null
          : Math.max(0, whole(source.pendingSleepPotionMoveAtSlot)),
        pendingSleepPotionRoom: LEGACY_POTION_GUEST_ROOMS.includes(source.pendingSleepPotionRoom)
          ? source.pendingSleepPotionRoom : null,
        sleepPotionRoomWatch: source.sleepPotionRoomWatch
          && LEGACY_POTION_GUEST_ROOMS.includes(source.sleepPotionRoomWatch.room)
          && typeof source.sleepPotionRoomWatch.renterId === 'string'
          ? {
            room: source.sleepPotionRoomWatch.room,
            renterId: source.sleepPotionRoomWatch.renterId,
            returnRoom: typeof source.sleepPotionRoomWatch.returnRoom === 'string'
              ? source.sleepPotionRoomWatch.returnRoom : null,
          } : null,
        sleepPotionRequests: normalizeLegacyPotionRequests(source.sleepPotionRequests),
        lastSession: source.lastSession && typeof source.lastSession === 'object' ? source.lastSession : null,
      };
    }

    const dataOf = state => normalizeData(state?.mods?.[ID]);
    const writeData = (state, data) => ({
      ...state,
      mods: { ...(state?.mods || {}), [ID]: normalizeData(data) },
    });
    const characterOf = (state, characterId = state?.primaryCharacterId) =>
      state?.characters?.[characterId] || null;
    const isSleeping = (state, characterId = state?.primaryCharacterId) =>
      characterOf(state, characterId)?.currentTask === 'sleeping';
    const isPassedOut = (state, characterId = state?.primaryCharacterId) =>
      characterOf(state, characterId)?.currentTask === 'passed_out';
    const isUnconscious = (state, characterId = state?.primaryCharacterId) =>
      isSleeping(state, characterId) || isPassedOut(state, characterId);
    const unconsciousStateOf = (state, characterId = state?.primaryCharacterId) =>
      isPassedOut(state, characterId) ? 'passed_out' : isSleeping(state, characterId) ? 'sleeping' : null;
    const actualSleepRoom = state => state ? api.fn('wifeSleepRoom')(state) : null;

    function bedSharingAgreement(state) {
      if (!state) return null;
      const character = characterOf(state);
      const night = api.fn('nightIndex')(whole(state.slot));
      const room = actualSleepRoom(state);
      const playerRoom = typeof state.player?.bedTonight === 'string'
        ? state.player.bedTonight : null;
      const sameBed = !!room && playerRoom === room;
      const sleepOnly = sameBed && whole(character?.justToSleepNight, -1) === night;
      return Object.freeze({
        night,
        room,
        playerRoom,
        sameBed,
        sleepOnly,
        decision: sameBed ? (sleepOnly ? 'sleep-only' : 'share') : 'separate',
      });
    }

    function nativePatronFlowOccupied(state) {
      if (!state) return false;
      const renters = [state.tavern?.tonightRenter, state.tavern?.tonightRenter2];
      if (renters.some(renter => renter?.nightReach)) return true;
      return Object.values(state.locations || {}).some(room => (
        room?.meta?.privatePatron || room?.meta?.privateAsk
      ));
    }

    function canStartPatronFlow(state) {
      return !!state && !nativePatronFlowOccupied(state);
    }

    function legacyPotionGuestRoomOpen(state, room) {
      return room === 'upstairs_hall' ? !!state?.tavern?.hasRoom
        : room === 'upstairs_room_2' ? !!state?.tavern?.hasRoom2 : false;
    }

    function legacyPotionRoomAssignment(state, room) {
      const assignment = room === 'upstairs_hall' ? state?.tavern?.tonightRenter
        : room === 'upstairs_room_2' ? state?.tavern?.tonightRenter2 : null;
      return typeof assignment?.customerId === 'string' ? assignment : null;
    }

    function legacyPotionRoomRenter(state, room, renterId = null) {
      const assignment = legacyPotionRoomAssignment(state, room);
      const customerId = renterId || assignment?.customerId;
      if (!customerId || assignment?.customerId !== customerId
        || !state?.locations?.[room]?.occupants?.includes(customerId)) return null;
      return (state.customers || []).find(customer => customer.id === customerId) || null;
    }

    function clearLegacyPotionRoomWatch(state) {
      const data = dataOf(state);
      return data.sleepPotionRoomWatch
        ? writeData(state, { ...data, sleepPotionRoomWatch: null }) : state;
    }

    function legacyPotionRoomNoticeEvent(state, renter, wifeName) {
      const scenePatron = state.activeScene?.patron;
      const otherName = scenePatron?.customerName
        || (state.customers || []).find(customer => customer.id === scenePatron?.customerId)?.name
        || T('다른 손님', 'another patron');
      return {
        type: 'sleep_potion_room_notice',
        text: T(
          `${renter.name}은(는) 자기 객실에 들어갔다가 곧 물러나 당신을 찾습니다. "${wifeName}이(가) 제 방에서 자고 있는데, ${otherName}이(가) 곁에 있습니다."`,
          `${renter.name} enters his room, quickly backs out, and finds you. "${wifeName} is asleep in my room, and ${otherName} is in there with her."`,
        ),
        choices: [{
          id: 'sleep:potion-room:notice:acknowledge',
          label: T('알겠다고 답하기', 'Acknowledge him'),
        }],
        sleepActionsPotionRoomNotice: {
          resumeEvent: state.pendingEvent || null,
        },
      };
    }

    function resolveLegacyPotionRoomNotice(state, choiceId) {
      const notice = state?.pendingEvent?.sleepActionsPotionRoomNotice;
      if (!notice || choiceId !== 'sleep:potion-room:notice:acknowledge') return state;
      return { ...state, pendingEvent: notice.resumeEvent || undefined };
    }

    function resolveLegacyPotionRoomRenter(state) {
      const watch = dataOf(state).sleepPotionRoomWatch;
      if (!watch) return state;
      if (!isUnconscious(state) || api.fn('wifeLocation')(state) !== watch.room) {
        return clearLegacyPotionRoomWatch(state);
      }
      const assignment = legacyPotionRoomAssignment(state, watch.room);
      if (!assignment || assignment.customerId !== watch.renterId) {
        return clearLegacyPotionRoomWatch(state);
      }
      const renter = legacyPotionRoomRenter(state, watch.room, watch.renterId);
      if (!renter) return state;
      const wifeName = characterOf(state)?.name || T('그녀', 'her');
      if (renter.intent === 'drink_only' || renter.intent === 'talk_only') {
        if (state.activeScene?.patron) {
          let next = clearLegacyPotionRoomWatch(state);
          const session = dataOf(next).session;
          const primaryId = session?.patronPrimaryId || next.activeScene?.patron?.customerId;
          const participant = session?.patronParticipants?.[primaryId];
          const otherName = participant?.customerName
            || next.activeScene?.patron?.customerName
            || T('다른 손님', 'another patron');
          const roomLine = participant ? patronActionLine(next, participant) : T(
            `${otherName}의 손이 잠든 ${wifeName}의 옷 안에 들어가 있습니다.`,
            `${otherName}'s hand is beneath sleeping ${wifeName}'s clothes.`,
          );
          if (Array.isArray(next.locations?.taproom?.occupants)) {
            next = api.fn('moveOccupant')(next, renter.id, 'taproom');
          }
          next = api.fn('log')(next, `${T(
            `${renter.name}은(는) 자기 객실 문을 열었다가 그 자리에 굳어 섭니다.`,
            `${renter.name} opens the door to his room and freezes in the doorway.`,
          )} ${roomLine} ${T(
            '그는 아무 말 없이 문을 닫고 홀로 돌아가 하던 일을 계속합니다.',
            'Without a word, he closes the door, returns to the taproom, and resumes what he was doing.',
          )}`);
          if (!api.fn('patronControlPlayerAway')(next)) {
            return { ...next, pendingEvent: legacyPotionRoomNoticeEvent(next, renter, wifeName) };
          }
          return next;
        }
        const intendedRoom = actualSleepRoom(state);
        const returnRoom = watch.returnRoom && Array.isArray(state.locations?.[watch.returnRoom]?.occupants)
          ? watch.returnRoom : intendedRoom && Array.isArray(state.locations?.[intendedRoom]?.occupants)
            ? intendedRoom : null;
        if (!returnRoom) return state;
        let next = api.fn('moveOccupant')(
          clearLegacyPotionRoomWatch(state), state.primaryCharacterId, returnRoom,
        );
        return api.fn('log')(next, T(
          `${renter.name}은(는) 자기 객실에서 약기운에 잠든 ${wifeName}을(를) 발견합니다. 대화하거나 술을 마실 생각뿐이었던 그는 그녀를 원래 잠들 방으로 옮겨 조심스럽게 눕힙니다.`,
          `${renter.name} finds ${wifeName} asleep under the potion's effects in his room. Since he only meant to talk or drink, he carries her back to the room where she was meant to sleep and carefully lays her down.`,
        ));
      }
      let next = api.fn('log')(clearLegacyPotionRoomWatch(state), T(
        `${renter.name}은(는) 자기 객실에 들어와 약기운에 깊이 잠든 ${wifeName}을(를) 발견합니다.`,
        `${renter.name} enters his room and finds ${wifeName} deeply asleep under the potion's effects.`,
      ));
      next = schedulePatronApproach(next, {
        customerId: renter.id,
        alreadyPrivate: true,
        minimumIntent: 'flirt_curious',
        reason: 'sleep_potion_room',
      });
      return next;
    }

    function settlePassedOutAutonomy(state) {
      const wife = characterOf(state);
      if (!wife || wife.currentTask !== 'passed_out') return state;
      let next = state;
      const guardedDuringWorldTick = wife.locationUntilSlot === PASSED_OUT_AUTONOMY_GUARD_SLOT;
      if (wife.taskTarget !== undefined
        || wife.locationUntilSlot !== undefined && !guardedDuringWorldTick
        || wife.passedOutAcknowledged !== true) {
        next = api.fn('updateWife')(next, current => ({
          ...current,
          taskTarget: undefined,
          locationUntilSlot: guardedDuringWorldTick
            ? PASSED_OUT_AUTONOMY_GUARD_SLOT : undefined,
          passedOutAcknowledged: true,
        }));
      }
      const data = dataOf(next);
      if (data.pendingSleepPotionDepth > 0 || data.pendingSleepPotionMoveAtSlot != null
        || data.pendingSleepPotionRoom != null) {
        next = writeData(next, {
          ...data,
          pendingSleepPotionDepth: 0,
          pendingSleepPotionMoveAtSlot: null,
          pendingSleepPotionRoom: null,
        });
      }
      return next;
    }

    function releasePassedOutAutonomyGuard(state) {
      const wife = characterOf(state);
      if (!wife || wife.locationUntilSlot !== PASSED_OUT_AUTONOMY_GUARD_SLOT) {
        return settlePassedOutAutonomy(state);
      }
      return settlePassedOutAutonomy(api.fn('updateWife')(state, current => ({
        ...current,
        locationUntilSlot: undefined,
      })));
    }

    function guardPassedOutAutonomyDuringWorldTick(state) {
      const settled = settlePassedOutAutonomy(state);
      const wife = characterOf(settled);
      if (!wife || wife.currentTask !== 'passed_out'
        || wife.locationUntilSlot === PASSED_OUT_AUTONOMY_GUARD_SLOT) {
        return settled;
      }
      return api.fn('updateWife')(settled, current => ({
        ...current,
        locationUntilSlot: PASSED_OUT_AUTONOMY_GUARD_SLOT,
      }));
    }

    function afterOriginalPassedOutTransition(result, args = []) {
      const before = args[0];
      return result && before && !isPassedOut(before) && isPassedOut(result)
        ? guardPassedOutAutonomyDuringWorldTick(result) : result;
    }

    function exposureChangeAllowed(character, exposure) {
      return !!character && api.fn('canApplyExposureChange')(
        character.outfit, character.exposure, exposure,
      );
    }

    function playerUndressCandidates(character) {
      if (!character || character.outfit === 'naked') return [];
      const current = character.exposure || {};
      const unavailable = {
        undress_bodice: current.bodiceUnlaced || current.topPulledDown || current.topRemoved,
        undress_top_down: current.topPulledDown || current.topRemoved,
        undress_top_remove: current.topRemoved,
        undress_skirt_up: current.skirtUp || current.skirtRemoved,
        undress_skirt_remove: current.skirtRemoved,
        undress_panties_aside: current.pantiesAside || current.pantiesRemoved,
        undress_panties_remove: current.pantiesRemoved,
      };
      return Object.keys(PLAYER_UNDRESS_ACTIONS).filter(actionId => !unavailable[actionId]);
    }

    function playerUndressExposure(character, actionId) {
      return playerUndressCandidates(character).includes(actionId)
        ? PLAYER_UNDRESS_ACTIONS[actionId].playerExposure : null;
    }

    function undressLine(state, name, exposure, actorName = null) {
      const actorKo = actorName ? `${actorName}은(는)` : '당신은';
      const actorEn = actorName || 'You';
      const conditionKo = isPassedOut(state) ? '의식을 잃은' : '잠든';
      const conditionEn = isPassedOut(state) ? 'unconscious' : 'sleeping';
      if (exposure.topRemoved) return T(
        `${actorKo} ${conditionKo} ${name}의 상의를 완전히 벗깁니다.`,
        `${actorEn} completely removes ${conditionEn} ${name}'s top.`,
      );
      if (exposure.topPulledDown) return T(
        `${actorKo} ${conditionKo} ${name}의 상의를 아래로 끌어내려 가슴을 드러냅니다.`,
        `${actorEn} pulls down ${conditionEn} ${name}'s top and bares her breasts.`,
      );
      if (exposure.bodiceUnlaced) return T(
        `${actorKo} ${conditionKo} ${name}의 앞섶을 풀어 옷을 느슨하게 벌립니다.`,
        `${actorEn} loosens ${conditionEn} ${name}'s bodice and opens the fabric.`,
      );
      if (exposure.pantiesRemoved) return T(
        `${actorKo} ${conditionKo} ${name}의 속옷을 벗겨 냅니다.`,
        `${actorEn} removes ${conditionEn} ${name}'s underwear.`,
      );
      if (exposure.pantiesAside) return T(
        `${actorKo} ${conditionKo} ${name}의 속옷을 옆으로 밀어 둡니다.`,
        `${actorEn} moves ${conditionEn} ${name}'s underwear aside.`,
      );
      if (exposure.skirtRemoved) return T(
        `${actorKo} ${conditionKo} ${name}의 치마를 완전히 벗깁니다.`,
        `${actorEn} completely removes ${conditionEn} ${name}'s skirt.`,
      );
      if (exposure.skirtUp) return T(
        `${actorKo} ${conditionKo} ${name}의 치마를 허리까지 걷어 올립니다.`,
        `${actorEn} lifts ${conditionEn} ${name}'s skirt to her waist.`,
      );
      return T(
        `${actorKo} ${conditionKo} ${name}의 속옷을 옆으로 밀어 둡니다.`,
        `${actorEn} moves ${conditionEn} ${name}'s underwear aside.`,
      );
    }

    function applyExposureChange(state, exposure) {
      return api.fn('updateWife')(state, wife => ({
        ...wife,
        exposure: { ...(wife.exposure || {}), ...exposure, setAtSlot: whole(state.slot) },
      }));
    }

    const actionClassOf = actionId => ACTION_CLASSES[actionId]
      || ACTION_CLASSES[SEX_ACCEPTANCE[actionId]] || 'intimate_touch';

    function sexActionDefinition(actionId) {
      if (!SEX_ACTION_SET.has(actionId)) return null;
      const scene = api.fn('sceneDef')(actionId);
      if (!scene || scene.playerAvailable === false) return null;
      return {
        actionId,
        label: scene.name || actionId,
        description: SEX_ACTION_DESCRIPTIONS[actionId] || scene.description || '',
        imageScene: actionId === 'fingering' ? 'fingered' : actionId,
        scene,
        acceptanceActionId: SEX_ACCEPTANCE[actionId],
      };
    }

    function playerSexClothingStatus(character, action) {
      if (!character || !action) {
        return { allowed: false, reason: T('그녀에게 손을 댈 수 없습니다.', 'You cannot reach her.') };
      }
      if (character.outfit === 'naked') return { allowed: true, reason: '' };
      const exposure = api.fn('exposureSummary')(character);
      const requirement = action.scene?.requiresNudity === 'full'
        ? 'full'
        : SEX_EXPOSURE_REQUIREMENTS[action.actionId]
          || (action.scene?.requiresNudity === 'partial' ? 'lower' : 'none');
      if (requirement === 'none') return { allowed: true, reason: '' };
      if (requirement === 'upper') {
        return {
          allowed: exposure.topBare === true,
          reason: T('가슴을 드러낸 뒤 할 수 있습니다.', 'Her breasts must be exposed first.'),
        };
      }
      if (requirement === 'full') {
        return {
          allowed: exposure.topBare === true && exposure.baredBelow === true,
          reason: T('상의와 하체를 모두 드러낸 뒤 할 수 있습니다.', 'Her upper and lower body must both be exposed first.'),
        };
      }
      return {
        allowed: exposure.baredBelow === true,
        reason: T('하체를 드러낸 뒤 할 수 있습니다.', 'Her lower body must be exposed first.'),
      };
    }

    function playerActionDefinition(actionId) {
      return PLAYER_ACTIONS[actionId] || sexActionDefinition(actionId);
    }

    function playerActionLogDirection(actionId) {
      if (actionId === PLAYER_SELF_PLEASURE_ID) return 'self';
      const scene = SEX_ACTION_SET.has(actionId) ? sexActionDefinition(actionId)?.scene : null;
      if (scene?.focus === 'him') return 'giving';
      if (scene?.focus === 'her') return 'receiving';
      return SEX_ACTION_SET.has(actionId) ? 'mutual' : 'receiving';
    }

    function playerActionLogMeta(state, actionId, phase) {
      const action = playerActionDefinition(actionId);
      const characterId = dataOf(state).session?.characterId || state?.primaryCharacterId;
      return {
        kind: 'player',
        actionId,
        label: action?.label || actionId,
        direction: playerActionLogDirection(actionId),
        characterId,
        characterName: characterOf(state, characterId)?.name || T('그녀', 'her'),
        ...(phase ? { phase } : {}),
      };
    }

    function patronActionLogMeta(state, participant, phase) {
      if (!participant) return null;
      const action = PATRON_STAGE_ACTIONS[participant.stage];
      return {
        kind: 'patron',
        actionId: action?.actionId || participant.stage,
        stage: participant.stage,
        primarySlot: participant.slot || patronPrimarySlot(participant.stage),
        lateral: participant.stage === PATRON_SELF_STROKE_STAGE
          ? PATRON_SELF_STROKE_STAGE : undefined,
        patronId: participant.customerId,
        patronName: participant.customerName,
        characterId: state?.primaryCharacterId,
        characterName: characterOf(state)?.name || T('그녀', 'her'),
        ...(phase ? { phase } : {}),
      };
    }

    function tagAddedActionLog(before, after, meta) {
      if (!meta || !Array.isArray(after?.log)) return after;
      const previousLength = Array.isArray(before?.log) ? before.log.length : 0;
      if (after.log.length <= previousLength) return after;
      const index = after.log.length - 1;
      const entry = after.log[index];
      if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return after;
      const log = [...after.log];
      log[index] = { ...entry, [ACTION_LOG_META]: meta };
      return { ...after, log };
    }

    function logSleepAction(state, line, meta) {
      return tagAddedActionLog(state, api.fn('log')(state, line), meta);
    }

    function emit(type, detail) {
      const frozen = Object.freeze({ type, ...detail });
      for (const listener of listeners.get(type) || []) {
        try { listener(frozen); } catch (error) { api.warn(`[${ID}] ${type} listener failed: ${error?.message || error}`); }
      }
    }

    function actionAffinityKey(actionId, explicitKey) {
      if (typeof explicitKey === 'string' && explicitKey) return explicitKey;
      return ACTION_AFFINITY_KEYS[actionId] || actionId;
    }

    function recordUnawareActionExposure(state, actionId, explicitKey) {
      const key = actionAffinityKey(actionId, explicitKey);
      if (!state || !key) return state;
      return api.fn('updateWife')(state, wife => {
        const old = wife.actionAffinity?.[key] || {};
        return {
          ...wife,
          actionAffinity: {
            ...(wife.actionAffinity || {}),
            [key]: {
              exposures: Math.max(0, whole(old.exposures)) + 1,
              valence: number(old.valence),
              lastSlot: whole(state.slot),
            },
          },
        };
      });
    }

    function qualifiedExperienceApi(minimumVersion) {
      let qualified = null;
      try {
        qualified = api.use('qualified-experience');
      } catch {}
      const apiVersion = Number(qualified?.apiVersion);
      return Number.isFinite(apiVersion) && apiVersion >= minimumVersion ? qualified : null;
    }

    function reportUnawareOriginalExperience(record) {
      const qualified = qualifiedExperienceApi(2);
      if (typeof qualified?.reportExperience !== 'function') return record;
      try {
        const reported = qualified.reportExperience(record, ID, {
          general: false,
          relationship: false,
        });
        return reported && typeof reported === 'object' ? reported : record;
      } catch {
        return record;
      }
    }

    function reportUnawarePhysicalExperience(state, details) {
      const qualified = qualifiedExperienceApi(3);
      if (typeof qualified?.reportPhysicalExperience !== 'function') return state;
      try {
        const reported = qualified.reportPhysicalExperience(state, ID, {
          ...details,
          general: false,
        });
        return reported && typeof reported === 'object' ? reported : state;
      } catch {
        return state;
      }
    }

    function appendUnawareIntimateHistory(state, event) {
      return api.fn('updateWife')(state, wife => {
        const old = Array.isArray(wife.intimateHistory) ? wife.intimateHistory : [];
        const record = reportUnawareOriginalExperience({
          actId: event.actionId || event.stage || 'unknown',
          partner: event.sourceType === 'player' ? 'player' : (event.sourceName || event.sourceId),
          partnerType: event.sourceType === 'player' ? 'player' : 'patron',
          day: event.day,
          slot: event.slot,
          reception: 'unaware',
          awareness: 'unaware',
          orgasmed: event.orgasmed === true,
          herPleasure: event.orgasmed === true ? 100 : undefined,
          husbandWitnessed: event.playerWitnessed === true,
          sleepEventId: event.eventId,
          sourceId: event.sourceId,
        });
        return {
          ...wife,
          intimateHistory: [
            ...old.filter(item => item?.sleepEventId !== event.eventId),
            record,
          ].slice(-ENCOUNTER_HISTORY_LIMIT),
        };
      });
    }

    function morningIncidentId(session, sourceType = session?.kind === 'patron' ? 'patron' : 'player') {
      return session
        ? `sleep-morning:${sourceType}:${session.characterId}:${whole(session.startedAtSlot)}`
        : null;
    }

    function queueMorningEvidence(state, evidence, options = {}) {
      const data = dataOf(state);
      const session = data.session;
      const sourceType = options.sourceType === 'patron' ? 'patron' : 'player';
      if (!session || !evidence?.key || (sourceType === 'player'
        ? session.unconsciousState !== 'sleeping'
        : !['sleeping', 'passed_out'].includes(session.unconsciousState))) return state;
      const id = morningIncidentId(session, sourceType);
      const existing = data.morningIncidents.find(item => item.id === id);
      const oldEvidence = existing?.evidence || [];
      const matched = oldEvidence.find(item => item.key === evidence.key);
      const nextEvidence = matched
        ? oldEvidence.map(item => item.key === evidence.key
          ? { ...item, count: options.incrementRepeat === false ? item.count : item.count + 1 } : item)
        : [...oldEvidence, { ...evidence, count: 1 }];
      const incident = existing ? { ...existing, evidence: nextEvidence } : {
        id,
        characterId: session.characterId,
        sourceType,
        patrons: [],
        sessionStartedAtSlot: whole(session.startedAtSlot),
        dayStarted: whole(state.day, 1),
        readyAtSlot: null,
        noticeRoll: Math.random(),
        confrontRoll: Math.random(),
        denialRoll: Math.random(),
        evidence: nextEvidence,
      };
      if (sourceType === 'patron' && options.sourceId != null) {
        const patron = {
          id: String(options.sourceId),
          name: options.sourceName || String(options.sourceId),
        };
        incident.patrons = [
          ...(incident.patrons || []).filter(item => item.id !== patron.id),
          patron,
        ].slice(-8);
      }
      return writeData(state, {
        ...data,
        morningIncidents: [
          ...data.morningIncidents.filter(item => item.id !== id),
          incident,
        ].slice(-12),
      });
    }

    function queueLowFamiliarityEvidence(state, actionId, options = {}) {
      const definition = MORNING_FAMILIARITY_ACTIONS[actionId];
      if (!definition) return state;
      const wife = characterOf(state);
      if (!wife) return state;
      const familiarity = number(
        api.fn('originalIntimateFamiliarity')(
          wife, options.sourceType === 'patron' ? 'patron' : 'player', definition.category,
        ),
      );
      if (familiarity >= settings().morningLowFamiliarityThreshold) return state;
      return queueMorningEvidence(state, {
        key: `action:${actionId}`,
        kind: 'action',
        actionId,
        category: definition.category,
        finishId: null,
        affinityKey: actionId,
        sourceId: options.sourceId == null ? null : String(options.sourceId),
        sourceName: options.sourceName || null,
        chance: settings()[definition.setting],
      }, {
        ...options,
        incrementRepeat: options.sourceType === 'patron' ? false : options.incrementRepeat,
      });
    }

    function queueFinishEvidence(state, actionId, finishId, options = {}) {
      if (!finishId || (finishId === 'pull_out' && options.sourceType !== 'patron')) return state;
      const evidenceFinishId = finishId === 'pull_out' ? 'cum_on_body' : finishId;
      const anal = actionId === 'anal' || actionId === 'anal_fingering';
      const chanceKey = evidenceFinishId === 'cum_inside'
        ? (anal ? 'cum_inside_anal' : 'cum_inside_vaginal')
        : evidenceFinishId;
      const chanceSetting = MORNING_FINISH_CHANCE_SETTINGS[chanceKey];
      const chance = chanceSetting ? settings()[chanceSetting] : null;
      if (chance == null) return state;
      return queueMorningEvidence(state, {
        key: `finish:${chanceKey}`,
        kind: 'finish',
        actionId,
        category: anal ? 'sex_anal' : SEX_ACCEPTANCE[actionId] || null,
        finishId: evidenceFinishId,
        affinityKey: finishId,
        sourceId: options.sourceId == null ? null : String(options.sourceId),
        sourceName: options.sourceName || null,
        chance,
      }, options);
    }

    function currentMorningIncidentMatches(item, session, sourceType) {
      if (!item || !session) return false;
      return item.characterId === session.characterId
        && whole(item.sessionStartedAtSlot) === whole(session.startedAtSlot)
        && (item.sourceType || 'player') === sourceType;
    }

    function discardCurrentMorningIncident(state, sourceType = dataOf(state).session?.kind === 'patron'
      ? 'patron' : 'player', sourceSession = dataOf(state).session) {
      const data = dataOf(state);
      if (!sourceSession || !data.morningIncidents.some(item => (
        currentMorningIncidentMatches(item, sourceSession, sourceType)
      ))) return state;
      return writeData(state, {
        ...data,
        morningIncidents: data.morningIncidents.filter(item => (
          !currentMorningIncidentMatches(item, sourceSession, sourceType)
        )),
      });
    }

    function markCurrentMorningIncidentReady(state, priorState) {
      const priorData = dataOf(priorState);
      if (!priorData.session || !['sleeping', 'passed_out'].includes(priorData.session.unconsciousState)) {
        return state;
      }
      const data = dataOf(state);
      if (!data.morningIncidents.some(item => (
        item?.characterId === priorData.session.characterId
          && whole(item.sessionStartedAtSlot) === whole(priorData.session.startedAtSlot)
      ))) return state;
      return writeData(state, {
        ...data,
        morningIncidents: data.morningIncidents.map(item => (
          item?.characterId === priorData.session.characterId
            && whole(item.sessionStartedAtSlot) === whole(priorData.session.startedAtSlot)
          ? { ...item, readyAtSlot: whole(state.slot) } : item
        )),
      });
    }

    function clearPlayerFinishSignal(state) {
      if (!state?.activeScene?.sex?.sleepActionsUnaware) return state;
      const activeScene = { ...(state.activeScene || {}) };
      delete activeScene.sex;
      return { ...state, activeScene: Object.keys(activeScene).length ? activeScene : undefined };
    }

    function publishPlayerFinishSignal(state, detail) {
      if (!state || !detail?.actionId || !detail?.finishId) return state;
      const session = dataOf(state).session;
      const reason = ['cum_inside', 'cum_in_mouth', 'cum_on_face'].includes(detail.finishId)
        ? detail.finishId : 'pull_out';
      return {
        ...state,
        activeScene: {
          ...(state.activeScene || {}),
          sex: {
            characterId: detail.characterId || session?.characterId || state.primaryCharacterId,
            type: detail.actionId,
            ticksElapsed: 1,
            playerPleasure: 100,
            elenaMoaning: clamp(number(detail.wifePleasure), 0, 100),
            elenaClimaxCount: Math.max(0, whole(detail.wifeClimaxCount)),
            elenaClimaxedDuringScene: detail.orgasmed === true,
            startedAtSlot: session?.startedAtSlot ?? whole(state.slot),
            sleepActionsUnaware: true,
            finish: {
              scene: finishSceneFor(detail.actionId, detail.finishId),
              reason,
              facialBoundary: null,
              elenaAlsoOrgasmed: detail.orgasmed === true,
              startedAtSlot: whole(state.slot),
              commandsIssued: 0,
              awareness: 'unaware',
            },
          },
        },
      };
    }

    function queuePatronFinishSignals(state, details) {
      const incoming = details.filter(detail => detail.vaginalDeposit === true).map(detail => ({
        sourceId: String(detail.sourceId),
        sourceName: detail.sourceName || String(detail.sourceId),
        position: detail.position || 'inside',
        boldness: number(detail.boldness, 56),
        comfort: number(detail.comfort, 0),
        pleasure: clamp(number(detail.pleasure), 0, 100),
        slot: whole(state.slot),
        vaginalDeposit: true,
      }));
      if (!incoming.length) return state;
      const data = dataOf(state);
      return writeData(state, {
        ...data,
        patronFinishSignals: [...data.patronFinishSignals, ...incoming].slice(-8),
      });
    }

    function consumePatronFinishSignal(state) {
      if (!state?.activeScene?.patron?.sleepActionsUnawareFinish) return state;
      const data = dataOf(state);
      const activeScene = { ...(state.activeScene || {}) };
      if (data.patronResumeScene) activeScene.patron = data.patronResumeScene;
      else delete activeScene.patron;
      return writeData({
        ...state,
        activeScene: Object.keys(activeScene).length ? activeScene : undefined,
      }, { ...data, patronResumeScene: null });
    }

    function publishNextPatronFinishSignal(state) {
      const data = dataOf(state);
      if (state?.activeScene?.patron?.sleepActionsUnawareFinish || !data.patronFinishSignals.length) return state;
      const [signal, ...rest] = data.patronFinishSignals;
      const resume = state.activeScene?.patron || null;
      const next = writeData(state, {
        ...data,
        patronFinishSignals: rest,
        patronResumeScene: resume,
      });
      return {
        ...next,
        activeScene: {
          ...(next.activeScene || {}),
          patron: {
            customerId: signal.sourceId,
            customerName: signal.sourceName,
            stage: 'sex_patron',
            primarySlot: signal.position,
            patronBoldness: Math.max(56, number(signal.boldness, 56)),
            elenaComfort: number(signal.comfort, 0),
            patronPleasure: 100,
            elenaPleasure: signal.pleasure,
            sleepActionsUnawareFinish: true,
            afterglow: {
              sinceSlot: signal.slot,
              untilSlot: signal.slot,
              witnessed: false,
              awareness: 'unaware',
            },
          },
        },
      };
    }

    function clearNativeFinishSignals(state) {
      return consumePatronFinishSignal(clearPlayerFinishSignal(state));
    }

    function sameActionRoom(state) {
      if (!state) return false;
      const playerRoom = api.fn('playerLocation')(state);
      const wifeRoom = api.fn('wifeLocation')(state);
      if (playerRoom !== wifeRoom) return false;
      return isPassedOut(state) || playerRoom === actualSleepRoom(state);
    }

    function canStartPlayerSleepActions(state) {
      return !!state
        && !state.pendingEvent
        && !state.errandSession
        && !state.activeScene?.patron
        && !state.activeScene?.sex
        && isUnconscious(state, state.primaryCharacterId)
        && sameActionRoom(state);
    }

    function finishChoices(state) {
      const session = dataOf(state).session;
      if (session?.currentSexActionId === PLAYER_SELF_PLEASURE_ID) {
        return PLAYER_SELF_FINISH_IDS.map(id => ({
          id: `sleep:finish:${id}`,
          label: FINISH_LABELS[id].label,
          description: FINISH_LABELS[id].description,
        }));
      }
      const scene = session?.currentSexActionId ? api.fn('sceneDef')(session.currentSexActionId) : null;
      const supported = [...new Set((scene?.canFinishWith || [])
        .filter(id => FINISH_LABELS[id]))];
      if (!supported.length) supported.push('cum_on_body');
      return supported.map(id => ({
        id: `sleep:finish:${id}`,
        label: FINISH_LABELS[id].label,
        description: FINISH_LABELS[id].description,
      }));
    }

    function actionScreenChoices(state) {
      const session = dataOf(state).session;
      const previousAction = session?.currentSexActionId
        ? sexActionDefinition(session.currentSexActionId) : null;
      const character = characterOf(state);
      const previousClothing = previousAction
        ? playerSexClothingStatus(character, previousAction) : null;
      const undressCandidates = new Set(playerUndressCandidates(characterOf(state)));
      const touchChoices = Object.entries(PLAYER_TOUCH_ACTIONS).map(([actionId, action]) => ({
        id: `sleep:act:${actionId}`,
        label: action.label,
        description: action.description,
      }));
      const strokeChoice = touchChoices.find(choice => choice.id === 'sleep:act:stroke');
      return [
        ...(strokeChoice ? [strokeChoice] : []),
        {
          id: 'sleep:self-pleasure',
          label: PLAYER_SELF_PLEASURE_ACTION.label,
          description: PLAYER_SELF_PLEASURE_ACTION.description,
        },
        ...touchChoices.filter(choice => choice !== strokeChoice),
        {
          id: 'sleep:sex:continue',
          label: T('계속하기', 'Continue'),
          description: previousAction
            ? T(
              `방금 하던 ${previousAction.label}을(를) 같은 속도로 이어갑니다.`,
              `Keep doing ${previousAction.label} at the same pace.`,
            )
            : T('먼저 그녀에게 어떻게 할지 고릅니다.', 'First choose what you will do with her.'),
          disabled: !previousAction || previousClothing?.allowed === false,
        },
        ...SEX_ACTION_IDS.map(sexActionDefinition).filter(Boolean).map(action => {
          const clothing = playerSexClothingStatus(character, action);
          return {
            id: `sleep:sex:${action.actionId}`,
            label: action.label,
            description: clothing.allowed
              ? action.description : `${action.description} ${clothing.reason}`,
            disabled: !clothing.allowed,
          };
        }),
        ...Object.entries(PLAYER_UNDRESS_ACTIONS).map(([actionId, action]) => ({
          id: `sleep:undress:${actionId}`,
          label: action.label,
          description: action.description,
          disabled: !undressCandidates.has(actionId),
        })),
        { id: 'sleep:stop', label: T('그만두기', 'Stop') },
      ];
    }

    function sleepActionEvent(state, screen = 'root', text = '', detail = null) {
      const character = characterOf(state);
      const name = character?.name || T('그녀', 'her');
      let choices;
      if (screen === 'root' || screen === 'touch' || screen === 'sex') {
        choices = actionScreenChoices(state);
      } else if (screen === 'finish') {
        choices = finishChoices(state);
      } else if (screen === 'wake_discovery') {
        choices = [
          {
            id: 'sleep:wake:apologize',
            label: T('그녀에게 사과하기', 'Apologize to her'),
            description: T(
              '즉시 손을 거두고, 의식이 없는 동안 건드린 일을 사과합니다.',
              'Take your hands away and apologize for touching her while she was unaware.',
            ),
          },
          {
            id: 'sleep:wake:ask-continue',
            label: T('계속 이어가도 될지 묻기', 'Ask whether you may continue'),
            description: T(
              `방금 하던 ${detail?.actionLabel || T('일', 'thing')}을(를) 계속해도 되는지 묻습니다.`,
              `Ask whether you may continue ${detail?.actionLabel || T('what you were doing', 'what you were doing')}.`,
            ),
          },
        ];
      } else choices = [{ id: 'sleep:stop', label: T('그만두기', 'Stop') }];
      const defaultText = screen === 'wake_discovery'
        ? T(
          `${name}이(가) 화들짝 눈을 뜨고 당신을 바라봅니다. "잠깐… 지금 뭐 하는 거야?"`,
          `${name} startles awake and stares at you. "Wait… what are you doing?"`,
        )
        : screen === 'finish'
          ? T('곧 쌀 것 같습니다. 어디에 사정할지 고릅니다.', 'You are about to come. Choose where to finish.')
          : isPassedOut(state)
            ? T(`${name}은(는) 의식을 잃은 채 누워 있습니다.`, `${name} is lying unconscious.`)
            : T(`${name}은(는) 침대에서 잠들어 있습니다.`, `${name} is asleep in bed.`);
      return {
        type: 'sex_scene',
        customerId: '',
        customerName: name,
        text: text || defaultText,
        choices,
        sleepActions: { screen, ...(detail ? { wake: detail } : {}) },
      };
    }

    function openPlayerSleepActions(state) {
      if (!canStartPlayerSleepActions(state)) return state;
      const next = beginSession(state, { characterId: state.primaryCharacterId });
      return { ...next, pendingEvent: sleepActionEvent(next, 'root') };
    }

    function beginSession(state, options = {}) {
      if (!state) return state;
      const characterId = options.characterId || state.primaryCharacterId;
      const kind = options.kind === 'patron' ? 'patron' : 'player';
      if (!isUnconscious(state, characterId)) return state;
      const witnessedCustomerIds = (state.customers || []).flatMap(customer => (
        api.fn('patronControlCustomerLocation')(state, customer.id) === api.fn('wifeLocation')(state)
          ? [customer.id] : []
      ));
      let prepared = state;
      let data = dataOf(prepared);
      const pendingPotionDepth = isSleeping(state, characterId)
        ? data.pendingSleepPotionDepth : 0;
      const pendingPotionRoom = isSleeping(state, characterId)
        && LEGACY_POTION_GUEST_ROOMS.includes(data.pendingSleepPotionRoom)
        && legacyPotionGuestRoomOpen(state, data.pendingSleepPotionRoom)
        ? data.pendingSleepPotionRoom : null;
      const pendingPotionReturnRoom = pendingPotionRoom
        ? api.fn('wifeLocation')(prepared) : null;
      if (pendingPotionRoom && api.fn('wifeLocation')(prepared) !== pendingPotionRoom) {
        prepared = api.fn('moveOccupant')(prepared, characterId, pendingPotionRoom);
        prepared = api.fn('log')(prepared, T(
          `${characterOf(prepared, characterId)?.name || '그녀'}은(는) 약기운에 눈을 제대로 뜨지 못한 채 위층으로 올라가, 자기 침실로 착각한 듯 열린 객실로 들어갑니다. 침대에 몸을 누이자마자 깊이 잠듭니다.`,
          `${characterOf(prepared, characterId)?.name || 'She'} climbs upstairs through the drugged haze and wanders into an open guest room as though mistaking it for her own. She sinks into a deep sleep as soon as she lies down.`,
        ));
        data = dataOf(prepared);
      }
      if (data.session?.characterId === characterId && data.session.kind === kind) {
        if (!(pendingPotionDepth > 0) && !pendingPotionRoom) return prepared;
        const roomAssignment = pendingPotionRoom
          ? legacyPotionRoomAssignment(prepared, pendingPotionRoom) : null;
        const resumed = writeData(prepared, {
          ...data,
          pendingSleepPotionDepth: 0,
          pendingSleepPotionMoveAtSlot: null,
          pendingSleepPotionRoom: null,
          sleepPotionRoomWatch: pendingPotionRoom
            ? roomAssignment ? {
              room: pendingPotionRoom,
              renterId: roomAssignment.customerId,
              returnRoom: typeof pendingPotionReturnRoom === 'string'
                ? pendingPotionReturnRoom : null,
            } : null
            : data.sleepPotionRoomWatch,
          session: { ...data.session, depth: data.session.depth + pendingPotionDepth },
        });
        return resumed;
      }
      if (data.session) {
        prepared = endSession(prepared, 'sleep-state-changed');
        data = dataOf(prepared);
      }
      const value = settings();
      const character = characterOf(prepared, characterId);
      const unconsciousState = unconsciousStateOf(prepared, characterId);
      const startedAtSlot = unconsciousState === 'passed_out'
        && Number.isFinite(Number(character?.passedOutAtSlot))
        ? whole(character.passedOutAtSlot) : whole(prepared.slot);
      const roomAssignment = pendingPotionRoom
        ? legacyPotionRoomAssignment(prepared, pendingPotionRoom) : null;
      const started = writeData(prepared, {
        ...data,
        pendingSleepPotionDepth: pendingPotionDepth > 0 ? 0 : data.pendingSleepPotionDepth,
        pendingSleepPotionMoveAtSlot: pendingPotionDepth > 0
          ? null : data.pendingSleepPotionMoveAtSlot,
        pendingSleepPotionRoom: pendingPotionDepth > 0 || pendingPotionRoom
          ? null : data.pendingSleepPotionRoom,
        sleepPotionRoomWatch: pendingPotionRoom
          ? roomAssignment ? {
            room: pendingPotionRoom,
            renterId: roomAssignment.customerId,
            returnRoom: typeof pendingPotionReturnRoom === 'string'
              ? pendingPotionReturnRoom : null,
          } : null
          : data.sleepPotionRoomWatch,
        session: {
          kind,
          characterId,
          unconsciousState,
          startedAtSlot,
          lastDepthUpdateSlot: whole(prepared.slot),
          depth: value.initialDepth + pendingPotionDepth,
          lastActionKey: null,
          lastActionSlot: null,
          lastActionSlots: {},
          activeThisMinute: false,
          experienceSessionId: `${ID}:${characterId}:${whole(state.slot)}:${kind}:${Math.random().toString(36).slice(2)}`,
          completedActionSequence: 0,
          imageActionId: null,
          playerPleasure: 0,
          sexStarted: false,
          currentSexActionId: null,
          finishScene: null,
          playerFinished: false,
          patronPrimaryId: null,
          patronOwnerId: null,
          patronApproach: null,
          patronAwareCustomerIds: witnessedCustomerIds,
          patronParticipants: {},
          patronTransfer: null,
        },
      });
      return started;
    }

    function addSessionDepth(state, input = {}) {
      if (!state) {
        return {
          state,
          result: Object.freeze({ status: 'ineligible', reason: 'state_missing' }),
        };
      }
      if (!input || typeof input !== 'object' || Array.isArray(input)
        || Object.keys(input).some(key => !['characterId', 'amount'].includes(key))
        || typeof input.characterId !== 'string' || !input.characterId
        || typeof input.amount !== 'number' || !Number.isFinite(input.amount)
        || !(input.amount > 0)) {
        return {
          state,
          result: Object.freeze({ status: 'ineligible', reason: 'invalid_request' }),
        };
      }
      const characterId = input.characterId;
      if (!characterOf(state, characterId)) {
        return {
          state,
          result: Object.freeze({
            status: 'ineligible', reason: 'target_missing', characterId,
          }),
        };
      }
      if (!isUnconscious(state, characterId)) {
        return {
          state,
          result: Object.freeze({
            status: 'ineligible', reason: 'target_conscious', characterId,
          }),
        };
      }
      const current = dataOf(state).session;
      if (current && current.characterId !== characterId) {
        return {
          state,
          result: Object.freeze({
            status: 'ineligible', reason: 'session_conflict', characterId,
          }),
        };
      }
      const prepared = current ? state : beginSession(state, { characterId });
      const data = dataOf(prepared);
      if (!data.session || data.session.characterId !== characterId) {
        return {
          state,
          result: Object.freeze({
            status: 'ineligible', reason: 'session_unavailable', characterId,
          }),
        };
      }
      const depthBefore = data.session.depth;
      const depthAfter = depthBefore + input.amount;
      const next = writeData(prepared, {
        ...data,
        session: { ...data.session, depth: depthAfter },
      });
      return {
        state: next,
        result: Object.freeze({
          status: 'applied', characterId, depthAdded: input.amount, depthBefore, depthAfter,
        }),
      };
    }

    function setSleepActionImage(state, actionId) {
      const action = playerActionDefinition(actionId);
      const data = dataOf(state);
      if (!action || !data.session) return state;
      const next = api.fn('updateWife')(state, wife => ({
        ...wife,
        sceneOverride: action.imageScene,
        sceneVariant: api.fn('nextSceneVariant')(),
        sceneSetAtSlot: whole(state.slot),
      }));
      return writeData(next, {
        ...data,
        session: { ...data.session, imageActionId: actionId, finishScene: null },
      });
    }

    function setFinishImage(state, scene) {
      const data = dataOf(state);
      if (!data.session) return state;
      const next = api.fn('updateWife')(state, wife => ({
        ...wife,
        sceneOverride: scene || undefined,
        sceneVariant: scene ? api.fn('nextSceneVariant')() : undefined,
        sceneSetAtSlot: scene ? whole(state.slot) : undefined,
      }));
      return writeData(next, {
        ...data,
        session: {
          ...data.session,
          imageActionId: null,
          finishScene: scene || null,
          playerPleasure: 0,
          playerFinished: true,
        },
      });
    }

    function resetAfterFinish(state, options = {}) {
      const preserveFinishImage = options.preserveFinishImage === true;
      const prepared = preserveFinishImage ? state : clearSleepActionImage(state);
      const data = dataOf(prepared);
      if (!data.session) return prepared;
      return writeData(prepared, {
        ...data,
        session: {
          ...data.session,
          imageActionId: null,
          playerPleasure: 0,
          wifePleasure: 0,
          wifeClimaxCount: 0,
          sexStarted: false,
          currentSexActionId: null,
          finishScene: preserveFinishImage ? data.session.finishScene : null,
          playerFinished: false,
        },
      });
    }

    function clearSleepActionImage(state) {
      const data = dataOf(state);
      if (!data.session?.imageActionId && !data.session?.finishScene) return state;
      const next = api.fn('updateWife')(state, wife => ({
        ...wife,
        sceneOverride: undefined,
        sceneVariant: undefined,
        sceneSetAtSlot: undefined,
      }));
      return writeData(next, {
        ...data,
        session: { ...data.session, imageActionId: null, finishScene: null },
      });
    }

    function endSession(state, reason = 'ended') {
      if (!state) return state;
      const prepared = state;
      const data = dataOf(prepared);
      const session = data.session;
      if (!session) return prepared;
      const cleanState = clearSleepActionImage(prepared);
      const pendingPatronRoomReturns = session.kind === 'patron' && prepared.activeScene?.patron
        ? mergePatronRoomReturns(
          patronRoomReturnsFromSession(session, prepared.activeScene.patron),
          data.pendingPatronRoomReturns,
        )
        : data.pendingPatronRoomReturns;
      const next = writeData(cleanState, {
        ...data,
        session: null,
        pendingPatronReturn: session.patronTransfer || data.pendingPatronReturn,
        pendingPatronRoomReturns,
        lastSession: {
          characterId: session.characterId,
          startedAtSlot: session.startedAtSlot,
          endedAtSlot: whole(prepared.slot),
          finalDepth: session.depth,
          reason,
        },
      });
      emit('sessionEnded', {
        characterId: session.characterId,
        reason,
        startedAtSlot: session.startedAtSlot,
        endedAtSlot: whole(prepared.slot),
      });
      return next;
    }

    function calculateDepthCost(state, actionId, options = {}) {
      const value = settings();
      const data = dataOf(state);
      const session = data.session;
      const actionClass = options.actionClass || actionClassOf(actionId);
      const rule = depthRule(value, actionClass);
      let evaluation = options.evaluation || null;
      if (!evaluation && Number.isFinite(Number(options.score)) && Number.isFinite(Number(options.threshold))) {
        evaluation = { score: Number(options.score), threshold: Number(options.threshold) };
      }
      if (!evaluation && state && actionId) {
        const context = options.context || {
          kind: 'player_intimate',
          characterId: options.characterId || session?.characterId || state.primaryCharacterId,
        };
        evaluation = api.fn('evaluateIntimacy')(
          state, options.acceptanceActionId || actionId, context,
        );
      }
      const deficit = Number.isFinite(Number(options.negativeAcceptance))
        ? Math.max(0, -Number(options.negativeAcceptance))
        : Math.max(0, number(evaluation?.threshold) - number(evaluation?.score));
      const base = clamp(rule.min + deficit * rule.ratio, rule.min, rule.max);
      const slot = whole(state?.slot);
      const repeatKey = options.repeatKey || actionId;
      const keyedLastSlot = session?.lastActionSlots?.[repeatKey];
      const repeated = !!session && (keyedLastSlot != null
        ? slot - keyedLastSlot <= value.repeatWindowMinutes
        : session.lastActionKey === actionId
          && session.lastActionSlot != null
          && slot - session.lastActionSlot <= value.repeatWindowMinutes);
      const rawCost = Math.max(
        value.minimumDepthCost,
        Math.round(base * (repeated ? value.sameActionMultiplier : 1)),
      );
      const stateMultiplier = isPassedOut(state, session?.characterId)
        ? value.passedOutDepthMultiplier : 1;
      const cost = rawCost * stateMultiplier;
      return Object.freeze({
        cost, rawCost, baseCost: base, stateMultiplier,
        deficit, repeated, actionClass, evaluation,
      });
    }

    function applySleepAction(state, options = {}) {
      const actionId = options.actionId;
      if (!state || !actionId) return state;
      const data = dataOf(state);
      const session = data.session;
      const validState = isUnconscious(state, session?.characterId);
      if (!session || !validState) return state;
      const scope = options.scope || 'player';
      const calculated = calculateDepthCost(state, actionId, options);
      const depthCost = Number.isFinite(Number(options.depthCostOverride))
        ? Math.max(0, Number(options.depthCostOverride))
        : calculated.cost;
      const completed = options.completed !== false;
      const completedActionSequence = Math.max(0, whole(session.completedActionSequence))
        + (completed ? 1 : 0);
      const nextSession = {
        ...session,
        depth: Math.max(0, session.depth - depthCost),
        lastActionKey: actionId,
        lastActionSlot: whole(state.slot),
        lastActionSlots: {
          ...(session.lastActionSlots || {}),
          [options.repeatKey || actionId]: whole(state.slot),
        },
        activeThisMinute: true,
        completedActionSequence,
      };
      let next = writeData(state, { ...data, session: nextSession });
      const physicalEventId = completed
        ? `${nextSession.experienceSessionId}:action:${completedActionSequence}` : null;
      if (completed && options.physicalExperience !== false) {
        next = reportUnawarePhysicalExperience(next, {
          characterId: session.characterId,
          actionId,
          sessionId: nextSession.experienceSessionId,
          eventId: physicalEventId,
        });
      }
      if (completed) next = recordUnawareActionExposure(next, actionId, options.affinityKey);
      if (completed) emit('actionCompleted', {
        characterId: session.characterId,
        actionId,
        sessionId: nextSession.experienceSessionId,
        eventId: physicalEventId,
        scope,
        slot: whole(state.slot),
        depthBefore: session.depth,
        depthAfter: nextSession.depth,
        depthCost,
        actionClass: calculated.actionClass,
      });
      return next;
    }

    function playerWakeContext(state, actionId, acceptanceActionId, options = {}) {
      const session = dataOf(state).session;
      const action = playerActionDefinition(actionId);
      return Object.freeze({
        characterId: session?.characterId || state.primaryCharacterId,
        actionId,
        acceptanceActionId: acceptanceActionId || action?.acceptanceActionId || actionId,
        actionClass: options.actionClass || actionClassOf(acceptanceActionId || actionId),
        actionLabel: options.actionLabel || action?.label || T('그 행동', 'that action'),
        continueSceneId: options.continueSceneId || null,
        unconsciousState: session?.unconsciousState || unconsciousStateOf(state, state.primaryCharacterId),
      });
    }

    function playerWakeQuestion(state, context) {
      const character = characterOf(state);
      const name = character?.name || T('그녀', 'She');
      const passedOut = context?.unconsciousState === 'passed_out';
      return passedOut ? T(
        `${name}이(가) 몸을 크게 움찔하며 의식을 되찾고, 놀란 얼굴로 당신을 쳐다봅니다. "잠깐… 내가 정신을 잃은 동안 뭘 하고 있었던 거야?"`,
        `${name}'s body jolts as she regains consciousness, and she stares at you in alarm. "Wait… what were you doing while I was out?"`,
      ) : T(
        `${name}이(가) 화들짝 눈을 뜨고 당신을 바라봅니다. "잠깐… 내가 자는 동안 뭘 하고 있었던 거야?"`,
        `${name} startles awake and stares at you. "Wait… what were you doing while I was asleep?"`,
      );
    }

    function openPlayerWakeDiscovery(state, reason, context) {
      let next = discardCurrentMorningIncident(state);
      if (isUnconscious(next, context?.characterId || next.primaryCharacterId)) {
        next = wakeUnconsciousCharacter(next);
      }
      if (dataOf(next).session) next = endSession(next, reason);
      const text = playerWakeQuestion(next, context);
      next = api.fn('log')(next, text);
      return {
        ...next,
        pendingEvent: sleepActionEvent(next, 'wake_discovery', text, context),
      };
    }

    function wakeFromDepletedDepth(state, context) {
      return openPlayerWakeDiscovery(state, 'depth-depleted', context);
    }

    function applyOriginalFemaleClimax(state, actionId, playerPleasure, wifeClimaxCount) {
      const previousActiveScene = state.activeScene;
      const previousSex = previousActiveScene?.sex;
      const session = dataOf(state).session;
      const stagedSex = {
        characterId: session?.characterId || state.primaryCharacterId,
        type: actionId,
        ticksElapsed: 1,
        playerPleasure: clamp(number(playerPleasure), 0, 100),
        elenaMoaning: 100,
        elenaClimaxCount: Math.max(0, whole(wifeClimaxCount)),
        elenaClimaxedDuringScene: wifeClimaxCount > 0,
        startedAtSlot: session?.startedAtSlot ?? whole(state.slot),
      };
      const staged = {
        ...state,
        activeScene: { ...(previousActiveScene || {}), sex: stagedSex },
      };
      const resolved = api.fn('processPlayerFemaleClimax')(staged, actionId);
      const resolvedSex = resolved.activeScene?.sex || stagedSex;
      const restoredActiveScene = { ...(resolved.activeScene || {}) };
      if (previousSex) restoredActiveScene.sex = previousSex;
      else delete restoredActiveScene.sex;
      return {
        state: {
          ...resolved,
          activeScene: Object.keys(restoredActiveScene).length ? restoredActiveScene : undefined,
        },
        wifePleasure: clamp(number(resolvedSex.elenaMoaning, 55), 0, 100),
        wifeClimaxCount: Math.max(
          wifeClimaxCount + 1,
          whole(resolvedSex.elenaClimaxCount, wifeClimaxCount + 1),
        ),
      };
    }

    function wifePleasureGain(action, scene) {
      return Math.max(0, number(action.wifePleasure, scene?.pleasureRate?.elena))
        * WIFE_PLEASURE_MULTIPLIER;
    }

    function originalPlayerWifeArousalGain(state, actionId, scene) {
      const rate = Math.max(0, number(scene?.pleasureRate?.elena));
      const multiplier = Math.max(0, number(
        api.fn('playerSexPleasureMultiplier')(state, actionId),
        1,
      ));
      return Math.round(rate * multiplier * 0.2);
    }

    function applyTouchPleasure(state, actionId, action, scene) {
      const data = dataOf(state);
      const session = data.session;
      if (!session) return { state, wifeClimaxed: false };
      const gain = wifePleasureGain(action, scene);
      if (!(gain > 0)) return { state, wifeClimaxed: false };
      const rawWifePleasure = session.wifePleasure + gain;
      if (rawWifePleasure < 100) {
        return {
          state: writeData(state, {
            ...data,
            session: { ...session, wifePleasure: clamp(rawWifePleasure, 0, 100) },
          }),
          wifeClimaxed: false,
        };
      }
      const climaxActionId = action.climaxScene || actionId;
      const climax = applyOriginalFemaleClimax(
        state, climaxActionId, session.playerPleasure, session.wifeClimaxCount,
      );
      return {
        state: writeData(climax.state, {
          ...data,
          session: {
            ...session,
            wifePleasure: climax.wifePleasure,
            wifeClimaxCount: climax.wifeClimaxCount,
          },
        }),
        wifeClimaxed: true,
      };
    }

    function playerSelfPleasureLine(state) {
      const name = characterOf(state)?.name || T('그녀', 'her');
      const conditionKo = isPassedOut(state) ? '의식을 잃은' : '잠든';
      const conditionEn = isPassedOut(state) ? 'unconscious' : 'sleeping';
      return rotatingLine(state, stringSeed(PLAYER_SELF_PLEASURE_ID), [
        `당신은 ${conditionKo} ${name}을(를) 바라보며 손으로 자신을 천천히 자극합니다.`,
        `당신은 숨을 죽이고 ${name}의 곁에서 손을 움직입니다.`,
        `당신은 ${conditionKo} ${name}의 곁에서 일정한 속도로 자신을 어루만집니다.`,
      ], [
        `You slowly touch yourself while watching ${conditionEn} ${name}.`,
        `You move your hand quietly beside ${name}.`,
        `You pleasure yourself at a steady pace beside ${conditionEn} ${name}.`,
      ]);
    }

    function applyPlayerSelfPleasure(state) {
      const screen = state.pendingEvent?.sleepActions?.screen;
      if (!['root', 'touch', 'sex'].includes(screen)) return state;
      let next = { ...state, pendingEvent: undefined };
      if (!dataOf(next).session) next = beginSession(next, { characterId: next.primaryCharacterId });
      if (!isUnconscious(next, next.primaryCharacterId) || !sameActionRoom(next)) {
        return endSession(next, 'unavailable');
      }

      next = clearSleepActionImage(next);
      const data = dataOf(next);
      const session = data.session;
      const gain = PLAYER_SELF_PLEASURE_BASE_GAIN * PLAYER_PLEASURE_MULTIPLIER;
      next = writeData(next, {
        ...data,
        session: {
          ...session,
          playerPleasure: clamp(session.playerPleasure + gain, 0, 100),
          sexStarted: true,
          currentSexActionId: PLAYER_SELF_PLEASURE_ID,
          finishScene: null,
          playerFinished: false,
        },
      });
      next = api.fn('applyEffects')(next, {
        targetCharacterId: next.primaryCharacterId,
        playerStatDeltas: {
          arousal: Math.round(PLAYER_SELF_PLEASURE_BASE_GAIN * PLAYER_SELF_PLEASURE_AROUSAL_RATIO),
        },
        wifeStatDeltas: {},
        wifeTraitDeltas: {},
      });
      const wakeContext = playerWakeContext(next, PLAYER_SELF_PLEASURE_ID, 'watch_him', {
        actionClass: 'manual_oral',
        actionLabel: PLAYER_SELF_PLEASURE_ACTION.label,
      });
      const name = characterOf(next)?.name || T('그녀', 'her');
      const narration = `${playerSelfPleasureLine(next)} ${isPassedOut(next)
        ? T(`${name}은(는) 의식 없이 축 늘어져 있고 호흡도 달라지지 않습니다.`, `${name} remains limp and unconscious, her breathing unchanged.`)
        : T(`${name}은(는) 눈을 뜨지 않고 고른 숨을 이어 갑니다.`, `${name} keeps breathing evenly without opening her eyes.`)}`;
      next = logSleepAction(
        next, narration, playerActionLogMeta(next, PLAYER_SELF_PLEASURE_ID),
      );
      next = api.fn('tick')(next);

      const afterTick = dataOf(next);
      if (!afterTick.session || !isUnconscious(next, next.primaryCharacterId)) {
        return openPlayerWakeDiscovery(next, 'woke', wakeContext);
      }
      next = setSleepActionImage(next, PLAYER_SELF_PLEASURE_ID);
      if (afterTick.session.playerPleasure >= 100) {
        return next.pendingEvent
          ? next
          : { ...next, pendingEvent: sleepActionEvent(next, 'finish') };
      }
      return next.pendingEvent
        ? next
        : { ...next, pendingEvent: sleepActionEvent(next, screen, narration) };
    }

    function applyPlayerTouchAction(state, actionId) {
      if (actionId === PLAYER_SELF_PLEASURE_ID) return state;
      const action = PLAYER_ACTIONS[actionId];
      const screen = state.pendingEvent?.sleepActions?.screen;
      if (!action || !['root', 'touch', 'sex'].includes(screen)) return state;
      let next = { ...state, pendingEvent: undefined };
      const session = dataOf(next).session;
      if (!session) next = beginSession(next, { characterId: next.primaryCharacterId });
      if (!isUnconscious(next, next.primaryCharacterId) || !sameActionRoom(next)) {
        next = endSession(next, 'unavailable');
        return next;
      }

      const character = characterOf(next);
      const name = character?.name || T('그녀', 'her');
      const scene = action.originalScene ? api.fn('sceneDef')(actionId) : null;
      const undressExposure = action.exposure ? playerUndressExposure(character, actionId) : null;
      if (action.exposure && !undressExposure) {
        const text = T(
          `${name}의 옷이 가로막혀 손을 넣을 틈이 없습니다.`,
          `${name}'s clothes leave no opening for your hand.`,
        );
        return { ...next, pendingEvent: sleepActionEvent(next, 'touch', text) };
      }
      if (action.idle) {
        const wakeContext = playerWakeContext(next, actionId, 'kiss_chaste', {
          actionClass: 'light_touch',
          actionLabel: action.label,
        });
        next = clearSleepActionImage(next);
        next = api.fn('tick')(next);
        const idleSession = dataOf(next).session;
        const narration = `${playerActionLine(next, actionId)} ${unconsciousReactionLine(
          next, idleSession?.wifePleasure || 0, false,
        )}`;
        next = logSleepAction(next, narration, playerActionLogMeta(next, actionId));
        if (!dataOf(next).session || !isUnconscious(next, next.primaryCharacterId)) {
          return openPlayerWakeDiscovery(next, 'woke', wakeContext);
        }
        return next.pendingEvent
          ? next
          : { ...next, pendingEvent: sleepActionEvent(next, 'touch', narration) };
      }
      const acceptanceActionId = action.acceptanceActionId || actionId;
      const wakeContext = playerWakeContext(next, actionId, acceptanceActionId, {
        actionLabel: action.label,
        continueSceneId: action.originalScene ? actionId : null,
      });
      next = applySleepAction(next, {
        actionId,
        acceptanceActionId,
        actionClass: actionClassOf(acceptanceActionId),
        scope: 'player',
      });
      let wifeClimaxed = false;
      if (undressExposure) {
        next = applyExposureChange(next, undressExposure);
      } else {
        const wifeArousal = action.originalScene
          ? originalPlayerWifeArousalGain(next, actionId, scene)
          : action.wifeArousal;
        const playerArousal = action.originalScene
          ? Math.round(Math.max(0, number(scene?.pleasureRate?.actor)) * 0.3)
          : action.playerArousal;
        next = api.fn('applyEffects')(next, {
          targetCharacterId: next.primaryCharacterId,
          playerStatDeltas: { arousal: playerArousal },
          wifeStatDeltas: { arousal: wifeArousal },
          wifeTraitDeltas: {},
        });
        const pleasure = applyTouchPleasure(next, actionId, action, scene);
        next = pleasure.state;
        wifeClimaxed = pleasure.wifeClimaxed;
      }
      const actionSession = dataOf(next).session;
      const narration = `${playerActionLine(next, actionId, undressExposure)} ${unconsciousReactionLine(
        next, actionSession?.wifePleasure || 0, wifeClimaxed,
      )}`;
      next = logSleepAction(next, narration, playerActionLogMeta(next, actionId));
      next = api.fn('tick')(next);
      next = undressExposure ? clearSleepActionImage(next) : setSleepActionImage(next, actionId);

      const afterTick = dataOf(next);
      if (afterTick.session?.depth <= 0 && isUnconscious(next, afterTick.session.characterId)) {
        return wakeFromDepletedDepth(next, wakeContext);
      }
      if (!afterTick.session || !isUnconscious(next, next.primaryCharacterId)) {
        return openPlayerWakeDiscovery(next, 'woke', wakeContext);
      }
      return next.pendingEvent
        ? next
        : { ...next, pendingEvent: sleepActionEvent(next, 'touch', narration) };
    }

    function applySexPleasure(state, action) {
      const data = dataOf(state);
      const session = data.session;
      if (!session) return { state, wifeClimaxed: false };
      const rates = action.scene.pleasureRate || {};
      const first = !session.sexStarted;
      const playerBase = first ? 15 : session.playerPleasure;
      const wifeBase = first
        ? (number(action.scene.stimulation) <= 0 ? 0 : action.scene.elenaReceiving ? 20 : 10)
        : session.wifePleasure;
      const playerPleasure = clamp(
        playerBase + Math.max(0, number(rates.actor)) * PLAYER_PLEASURE_MULTIPLIER,
        0, 100,
      );
      const rawWifePleasure = wifeBase
        + Math.max(0, number(rates.elena)) * WIFE_PLEASURE_MULTIPLIER;
      const wifeClimaxed = rawWifePleasure >= 100;
      let next = state;
      let wifePleasure = clamp(rawWifePleasure, 0, 100);
      let wifeClimaxCount = session.wifeClimaxCount;
      if (wifeClimaxed) {
        const climax = applyOriginalFemaleClimax(
          state, action.actionId, playerPleasure, session.wifeClimaxCount,
        );
        next = climax.state;
        wifePleasure = climax.wifePleasure;
        wifeClimaxCount = climax.wifeClimaxCount;
      }
      const nextSession = {
        ...session,
        playerPleasure,
        wifePleasure,
        wifeClimaxCount,
        sexStarted: true,
        currentSexActionId: action.actionId,
      };
      return {
        state: writeData(next, { ...data, session: nextSession }),
        wifeClimaxed,
      };
    }

    function applyPlayerSexAction(state, actionId) {
      const action = sexActionDefinition(actionId);
      const screen = state.pendingEvent?.sleepActions?.screen;
      if (!action || !['root', 'touch', 'sex'].includes(screen)) return state;
      let next = { ...state, pendingEvent: undefined };
      if (!dataOf(next).session) next = beginSession(next, { characterId: next.primaryCharacterId });
      if (!isUnconscious(next, next.primaryCharacterId) || !sameActionRoom(next)) {
        return endSession(next, 'unavailable');
      }

      const character = characterOf(next);
      const name = character?.name || T('그녀', 'her');
      const clothing = playerSexClothingStatus(character, action);
      if (!clothing.allowed) {
        const text = `${action.description} ${clothing.reason}`;
        return { ...next, pendingEvent: sleepActionEvent(next, 'sex', text) };
      }
      const acceptanceActionId = action.acceptanceActionId;
      const wakeContext = playerWakeContext(next, actionId, acceptanceActionId, {
        actionLabel: action.label,
        continueSceneId: actionId,
      });
      next = queueLowFamiliarityEvidence(next, actionId);
      next = applySleepAction(next, {
        actionId,
        acceptanceActionId,
        actionClass: actionClassOf(acceptanceActionId),
        scope: 'player',
      });
      const rates = action.scene.pleasureRate || {};
      const wifeArousal = originalPlayerWifeArousalGain(next, actionId, action.scene);
      next = api.fn('applyEffects')(next, {
        targetCharacterId: next.primaryCharacterId,
        playerStatDeltas: { arousal: Math.round(Math.max(0, number(rates.actor)) * 0.3) },
        wifeStatDeltas: { arousal: wifeArousal },
        wifeTraitDeltas: {},
      });
      const pleasure = applySexPleasure(next, action);
      next = pleasure.state;
      const actionSession = dataOf(next).session;
      const narration = `${playerActionLine(next, actionId)} ${unconsciousReactionLine(
        next, actionSession?.wifePleasure || 0, pleasure.wifeClimaxed,
      )}`;
      next = logSleepAction(next, narration, playerActionLogMeta(next, actionId));
      next = api.fn('tick')(next);
      next = setSleepActionImage(next, actionId);

      const afterTick = dataOf(next);
      if (afterTick.session?.depth <= 0 && isUnconscious(next, afterTick.session.characterId)) {
        return wakeFromDepletedDepth(next, wakeContext);
      }
      if (!afterTick.session || !isUnconscious(next, next.primaryCharacterId)) {
        return openPlayerWakeDiscovery(next, 'woke', wakeContext);
      }
      if (afterTick.session?.playerPleasure >= 100) {
        return next.pendingEvent
          ? next
          : { ...next, pendingEvent: sleepActionEvent(next, 'finish') };
      }
      return next.pendingEvent
        ? next
        : { ...next, pendingEvent: sleepActionEvent(next, 'sex', narration) };
    }

    function finishSceneFor(actionId, finishId) {
      if (finishId === 'pull_out') return null;
      if (finishId === 'cum_on_face') return 'facial';
      if (finishId === 'cum_in_mouth') return 'cum_in_mouth';
      if (finishId === 'cum_on_breasts') return 'finish_on_chest';
      if (finishId === 'cum_inside') return playerActionDefinition(actionId)?.imageScene || actionId;
      const outsideScenes = {
        handjob: 'handjob',
        blowjob: 'facial',
        deepthroat: 'cum_in_mouth',
        titfuck: 'finish_on_chest',
        anal: 'finish_on_back',
      };
      return outsideScenes[actionId] || 'finish_on_stomach';
    }

    function finishAcceptanceId(actionId, finishId) {
      if (finishId === 'cum_inside') return SEX_ACCEPTANCE[actionId] || 'sex_vaginal';
      if (finishId === 'cum_on_face') return 'cum_on_face';
      if (finishId === 'cum_in_mouth') return 'cum_in_mouth';
      return 'cum_on_skin';
    }

    function finishNarration(state, name, finishId) {
      const conditionKo = isPassedOut(state) ? '의식을 잃은' : '잠든';
      const conditionEn = isPassedOut(state) ? 'unconscious' : 'sleeping';
      const text = {
        cum_inside: T(`당신은 깊이 밀어 넣은 채 ${conditionKo} ${name}의 안에 사정합니다.`, `You climax deep inside ${conditionEn} ${name}.`),
        cum_in_mouth: T(`당신은 ${conditionKo} ${name}의 입안에 사정합니다.`, `You climax in ${conditionEn} ${name}'s mouth.`),
        cum_on_face: T(`당신은 몸을 빼고 ${conditionKo} ${name}의 얼굴에 사정합니다.`, `You pull away and finish on ${conditionEn} ${name}'s face.`),
        cum_on_breasts: T(`당신은 ${conditionKo} ${name}의 가슴 위에 사정합니다.`, `You finish across ${conditionEn} ${name}'s breasts.`),
        cum_on_body: T(`당신은 몸을 빼고 ${conditionKo} ${name}의 몸 위에 사정합니다.`, `You pull out and finish across ${conditionEn} ${name}'s body.`),
        pull_out: T(
          `당신은 ${conditionKo} ${name}의 몸에 흔적이 남지 않도록 밖에 사정한 뒤 조용히 정리합니다.`,
          `You finish away from ${conditionEn} ${name}'s body, then quietly clean up every trace.`,
        ),
      };
      return text[finishId] || text.cum_on_body;
    }

    function applySexAftermath(state, actionId, finishId, fromPatron = false, fluidTags) {
      if (!state || !actionId || !finishId) return state;
      const wife = characterOf(state);
      if (!wife) return state;
      const effective = api.fn('getEffectiveAttributes')(wife) || wife.attributes || {};
      const openness = clamp(number(effective.openness), 0, 100);
      // 잠든 대상이 스스로 흔적을 정리하는 분기는 없으므로, 원본 태그 종류는 항상 남도록 계산한다.
      const calculatedTags = api.fn('sexAftermathTags')(actionId, finishId, 100) || [];
      const baseTags = calculatedTags.filter(tag => typeof tag === 'string' && tag
        && (!Array.isArray(fluidTags) || !AFTERMATH_FLUID_TAGS.has(tag)));
      const tags = [...new Set([...baseTags, ...(Array.isArray(fluidTags) ? fluidTags : [])]
        .filter(tag => typeof tag === 'string' && tag))];
      if (!tags.length) return state;
      const calculatedFade = api.fn('sexAftermathFadeAt')(tags, whole(state.slot), openness) || {};
      return api.fn('updateWife')(state, current => {
        const aftermathTags = [...new Set([...(current.aftermathTags || []), ...tags])];
        const aftermathFadeAt = { ...(current.aftermathFadeAt || {}) };
        for (const tag of tags) {
          const existing = Number(aftermathFadeAt[tag]);
          const incoming = Number(calculatedFade[tag]);
          if (Number.isFinite(incoming)) {
            aftermathFadeAt[tag] = Number.isFinite(existing) ? Math.max(existing, incoming) : incoming;
          }
        }
        return {
          ...current,
          aftermathTags,
          aftermathFadeAt,
          aftermathFromPatron: fromPatron ? true : undefined,
        };
      });
    }

    function recordFinishCompleted(state, detail) {
      const data = dataOf(state);
      const characterId = detail.characterId || data.session?.characterId || state.primaryCharacterId;
      const wifeRoom = api.fn('wifeLocation')(state);
      const playerWitnessed = detail.sourceType === 'player'
        || (!state.errandSession && wifeRoom && wifeRoom === api.fn('playerLocation')(state));
      const sourceId = detail.sourceId == null ? detail.sourceType : String(detail.sourceId);
      const event = {
        eventId: `sleep-finish:${characterId}:${whole(state.slot)}:${detail.sourceType}:${sourceId}:${detail.finishId}`,
        characterId,
        sourceType: detail.sourceType,
        sourceId,
        sourceName: detail.sourceName || null,
        actionId: detail.actionId,
        stage: detail.stage || null,
        position: detail.position || null,
        finishId: detail.finishId,
        vaginalDeposit: detail.finishId === 'cum_inside'
          && detail.actionId === 'sex'
          && detail.position !== 'inside_anal',
        orgasmed: detail.orgasmed === true,
        awareness: 'unaware',
        playerWitnessed,
        day: whole(state.day, 1),
        slot: whole(state.slot),
      };
      const sleepEncounterHistory = [
        ...data.sleepEncounterHistory.filter(entry => entry.eventId !== event.eventId),
        event,
      ].slice(-ENCOUNTER_HISTORY_LIMIT);
      let next = state;
      if (event.sourceType === 'patron') {
        const source = {
          sourceType: 'patron',
          sourceId: event.sourceId,
          sourceName: event.sourceName,
        };
        next = queueLowFamiliarityEvidence(next, event.actionId, source);
        next = queueFinishEvidence(next, event.actionId, event.finishId, source);
      }
      const nextData = dataOf(next);
      next = writeData(next, { ...nextData, sleepEncounterHistory });
      if (detail.recordOriginalHistory !== false) next = appendUnawareIntimateHistory(next, event);
      emit('finishCompleted', { ...event, wifeAware: false });
      return next;
    }

    function applyPlayerSelfPleasureFinish(state, finishId) {
      const session = dataOf(state).session;
      if (!session) return state;
      const quiet = finishId === 'pull_out';
      const acceptanceActionId = finishAcceptanceId(PLAYER_SELF_PLEASURE_ID, finishId);
      const wakeContext = playerWakeContext(state, `finish:${finishId}`, acceptanceActionId, {
        actionClass: 'finish',
        actionLabel: FINISH_LABELS[finishId]?.label || T('마무리', 'finishing'),
      });
      let next = { ...state, pendingEvent: undefined };
      if (!quiet) {
        next = applySleepAction(next, {
          actionId: `finish:${finishId}`,
          affinityKey: finishId,
          acceptanceActionId,
          actionClass: 'finish',
          scope: 'player',
        });
      }
      next = clearSleepActionImage(next);
      const climaxSlots = [...(next.player?.climaxSlots || []), whole(next.slot)].slice(-4);
      next = {
        ...next,
        player: {
          ...(next.player || {}),
          climaxSlots,
          stats: { ...(next.player?.stats || {}), arousal: 0 },
        },
      };
      const name = characterOf(next)?.name || T('그녀', 'her');
      const narration = finishNarration(next, name, finishId);
      if (!quiet) {
        next = applySexAftermath(
          next, 'handjob', finishId, false, PLAYER_SELF_FINISH_FLUID_TAGS[finishId],
        );
        next = queueFinishEvidence(next, PLAYER_SELF_PLEASURE_ID, finishId);
        next = recordFinishCompleted(next, {
          sourceType: 'player',
          sourceId: 'player',
          sourceName: T('당신', 'You'),
          actionId: SLEEP_SELF_PLEASURE_RECORD_ID,
          stage: PLAYER_SELF_PLEASURE_ID,
          finishId,
          orgasmed: session.wifeClimaxCount > 0,
          recordOriginalHistory: false,
        });
      }
      next = logSleepAction(
        next, narration, playerActionLogMeta(next, PLAYER_SELF_PLEASURE_ID, 'finished'),
      );
      next = api.fn('tick')(next);
      next = setFinishImage(next, quiet ? null : finishSceneFor(PLAYER_SELF_PLEASURE_ID, finishId));
      const afterTick = dataOf(next);
      if (afterTick.session?.depth <= 0 && isUnconscious(next, afterTick.session.characterId)) {
        return wakeFromDepletedDepth(next, wakeContext);
      }
      if (!dataOf(next).session || !isUnconscious(next, next.primaryCharacterId)) {
        return openPlayerWakeDiscovery(next, 'woke', wakeContext);
      }
      const data = dataOf(next);
      next = writeData(next, {
        ...data,
        session: {
          ...data.session,
          playerPleasure: 0,
          sexStarted: false,
          currentSexActionId: null,
          finishScene: quiet ? null : data.session.finishScene,
          playerFinished: false,
        },
      });
      return next.pendingEvent
        ? next
        : { ...next, pendingEvent: sleepActionEvent(next, 'root', narration) };
    }

    function applyPlayerFinish(state, finishId) {
      const session = dataOf(state).session;
      const allowed = new Set(finishChoices(state).map(choice => choice.id.slice('sleep:finish:'.length)));
      if (state.pendingEvent?.sleepActions?.screen !== 'finish'
        || !session || session.playerPleasure < 100 || !allowed.has(finishId)) return state;
      const actionId = session.currentSexActionId;
      if (actionId === PLAYER_SELF_PLEASURE_ID) return applyPlayerSelfPleasureFinish(state, finishId);
      const acceptanceActionId = finishAcceptanceId(actionId, finishId);
      const wakeContext = playerWakeContext(state, `finish:${finishId}`, acceptanceActionId, {
        actionClass: 'finish',
        actionLabel: FINISH_LABELS[finishId]?.label || T('마무리', 'finishing'),
        continueSceneId: actionId,
      });
      let next = { ...state, pendingEvent: undefined };
      next = applySleepAction(next, {
        actionId: `finish:${finishId}`,
        affinityKey: finishId,
        acceptanceActionId,
        actionClass: 'finish',
        scope: 'player',
      });
      const name = characterOf(next)?.name || T('그녀', 'her');
      const narration = finishNarration(next, name, finishId);
      const climaxSlots = [...(next.player?.climaxSlots || []), whole(next.slot)].slice(-4);
      next = {
        ...next,
        player: {
          ...(next.player || {}),
          climaxSlots,
          stats: { ...(next.player?.stats || {}), arousal: 0 },
        },
      };
      if (finishId !== 'pull_out') {
        next = applySexAftermath(next, actionId, finishId, false);
      }
      next = queueFinishEvidence(next, actionId, finishId);
      next = recordFinishCompleted(next, {
        sourceType: 'player',
        sourceId: 'player',
        sourceName: T('당신', 'You'),
        actionId,
        finishId,
        orgasmed: session.wifeClimaxCount > 0,
      });
      next = logSleepAction(
        next, narration, playerActionLogMeta(next, actionId, 'finished'),
      );
      next = api.fn('tick')(next);
      next = setFinishImage(next, finishSceneFor(actionId, finishId));
      next = publishPlayerFinishSignal(next, {
        characterId: session.characterId,
        actionId,
        finishId,
        wifePleasure: session.wifePleasure,
        wifeClimaxCount: session.wifeClimaxCount,
        orgasmed: session.wifeClimaxCount > 0,
      });

      const afterTick = dataOf(next);
      if (afterTick.session?.depth <= 0 && isUnconscious(next, afterTick.session.characterId)) {
        return wakeFromDepletedDepth(next, wakeContext);
      }
      if (!afterTick.session || !isUnconscious(next, next.primaryCharacterId)) {
        return openPlayerWakeDiscovery(next, 'woke', wakeContext);
      }
      next = resetAfterFinish(next, { preserveFinishImage: true });
      return { ...next, pendingEvent: sleepActionEvent(next, 'root', narration) };
    }

    function playerWakeSeverity(context) {
      return {
        light_touch: 1,
        intimate_touch: 2,
        manual_oral: 3,
        sex: 4,
        finish: 4,
      }[context?.actionClass] || 2;
    }

    function playerWakeReactionEffects(choice, decision, context) {
      const severity = playerWakeSeverity(context);
      const apologizing = choice === 'apologize';
      if (decision.accepted) {
        return {
          playerStatDeltas: { mood: apologizing ? -1 : decision.eager ? 1 : 0 },
          wifeStatDeltas: { mood: apologizing ? (decision.eager ? 0 : -1) : decision.eager ? 1 : 0 },
          wifeTraitDeltas: apologizing ? {} : { openness: decision.eager ? 0.2 : 0.1 },
        };
      }
      if (decision.emphatic) {
        return {
          playerStatDeltas: { mood: apologizing ? -2 : -3 },
          wifeStatDeltas: { mood: -(2 + severity) },
          wifeTraitDeltas: apologizing ? {} : { openness: -0.3 },
          trustDelta: -Math.ceil(severity / 2),
          resentDelta: apologizing ? severity : severity + 2,
          resentSource: 'sleep-actions:player-discovered',
        };
      }
      return {
        playerStatDeltas: { mood: apologizing ? -1 : -2 },
        wifeStatDeltas: { mood: -(1 + Math.ceil(severity / 2)) },
        wifeTraitDeltas: apologizing ? {} : { openness: -0.1 },
        trustDelta: apologizing ? (severity >= 3 ? -1 : 0) : (severity >= 3 ? -2 : -1),
        resentDelta: apologizing ? Math.ceil(severity / 2) : severity,
        resentSource: 'sleep-actions:player-discovered',
      };
    }

    function playerWakeResponseLine(state, choice, decision) {
      const name = characterOf(state)?.name || T('그녀', 'She');
      const key = `${choice}:${decision.accepted}:${decision.eager}:${decision.emphatic}`;
      const pools = choice === 'apologize' ? {
        eager: [
          [`당신은 손을 거두고 사과합니다. ${name}은(는) 숨을 고른 뒤 말합니다. "놀랐어. 다음에는 먼저 깨워서 물어봐."`, `You take your hands away and apologize. ${name} catches her breath. "You startled me. Wake me and ask first next time."`],
          [`당신의 사과를 듣고 ${name}은(는) 한동안 말이 없습니다. 이윽고 고개를 돌리고 말합니다. "다음에는 내가 대답할 수 있을 때 먼저 물어봐."`, `${name} says nothing for a while after hearing your apology. At last, she turns her head away. "Next time, ask when I can answer."`],
        ],
        accepted: [
          [`당신이 사과하자 ${name}은(는) 한동안 당신을 살피다가 고개를 끄덕입니다. "알겠어. 하지만 다음부터는 내가 깨어 있을 때 먼저 물어봐."`, `${name} studies you after your apology, then nods. "All right. But ask me first while I'm awake next time."`],
          [`${name}은(는) 사과를 듣고 몸을 뒤로 뺍니다. "지금은 그만해. 다음에는 먼저 깨워서 물어봐."`, `${name} draws back after hearing your apology. "Stop now. Next time, wake me and ask first."`],
        ],
        emphatic: [
          [`당신이 사과하자 ${name}은(는) 몸을 가리고 물러섭니다. "지금은 가까이 오지 마. 내가 모르는 사이에 그런 건 싫어."`, `When you apologize, ${name} covers herself and steps back. "Don't come near me. I hate that happening without my knowledge."`],
          [`${name}은(는) 당신의 사과를 끝까지 듣지 않고 거리를 벌립니다. "됐어. 지금은 나가 줘."`, `${name} steps away before you finish apologizing. "Enough. Leave me alone now."`],
        ],
        refused: [
          [`당신이 사과하자 ${name}은(는) 굳은 얼굴로 고개를 끄덕입니다. "알았어. 그래도 지금은 혼자 있게 해 줘."`, `${name} nods stiffly at your apology. "I heard you. Leave me alone for now."`],
          [`${name}은(는) 당신의 손을 피하고 한 발 물러섭니다. "사과는 들었어. 다음엔 먼저 물어봐."`, `${name} avoids your hand and steps back. "I heard the apology. Ask first next time."`],
        ],
      } : {
        eager: [
          [`당신이 계속해도 되는지 묻자 ${name}은(는) 숨을 고르고 당신의 손을 잡습니다. "이제는 깼잖아. 계속해도 돼."`, `When you ask whether you may continue, ${name} catches her breath and takes your hand. "I'm awake now. You can continue."`],
          [`${name}은(는) 당신을 똑바로 바라본 뒤 손을 잡습니다. "이번에는 내가 고른 거야. 천천히 해."`, `${name} looks directly at you, then takes your hand. "This time, it's my choice. Go slowly."`],
        ],
        accepted: [
          [`당신이 묻자 ${name}은(는) 잠시 망설이다가 작게 고개를 끄덕입니다. "먼저 물었어야지. 그래도… 천천히 해."`, `When you ask, ${name} hesitates, then nods faintly. "You should have asked first. Still… go slowly."`],
          [`${name}은(는) 한동안 당신의 손을 바라보다가 고개를 끄덕입니다. "계속해도 돼. 대신 내 반응을 살피면서 천천히 해."`, `${name} watches your hand for a while, then nods. "You can continue. But watch my reactions and go slowly."`],
        ],
        emphatic: [
          [`당신이 묻자 ${name}은(는) 몸을 거칠게 빼냅니다. "그걸 지금 묻는 거야? 당장 나한테서 떨어져."`, `When you ask, ${name} jerks away. "You're asking that now? Get away from me."`],
          [`${name}은(는) 당신의 말을 끊고 문 쪽으로 물러섭니다. "아니. 더는 묻지도 마."`, `${name} cuts you off and moves toward the door. "No. Don't ask again."`],
        ],
        refused: [
          [`당신이 묻자 ${name}은(는) 손을 밀어냅니다. "아니. 지금은 그만해. 내가 깨어 있을 때 먼저 물었어야 해."`, `When you ask, ${name} pushes your hand away. "No. Stop now. You should have asked while I was awake."`],
          [`${name}은(는) 자세를 바로잡고 당신과 거리를 둡니다. "그만해. 나는 계속하고 싶지 않아."`, `${name} sits upright and puts distance between you. "Stop. I don't want to continue."`],
        ],
      };
      const response = decision.accepted ? decision.eager ? 'eager' : 'accepted'
        : decision.emphatic ? 'emphatic' : 'refused';
      const voicePools = {
        mara: {
          accepted: [
            [`${name}은(는) 당신의 손을 붙잡고 눈을 마주칩니다. "이번엔 내가 결정할게. 서두르지 마."`, `${name} catches your hand and meets your eyes. "I'll decide this time. Don't rush me."`],
            [`${name}은(는) 잠시 생각한 뒤 고개를 끄덕입니다. "계속해도 돼. 하지만 내가 멈추라고 하면 바로 멈춰."`, `${name} considers it, then nods. "You can continue. But if I tell you to stop, stop immediately."`],
          ],
          refused: [
            [`${name}은(는) 손을 밀어내고 단호하게 말합니다. "그만. 다음에는 내 허락부터 받아."`, `${name} pushes your hand away. "Stop. Ask for my permission first next time."`],
            [`${name}은(는) 당신과 거리를 둡니다. "싫어. 이제 손 떼."`, `${name} moves away from you. "No. Take your hands off me now."`],
          ],
        },
        pippa: {
          accepted: [
            [`${name}은(는) 당신을 바라보다 손을 잡습니다. "먼저 깨워 줬으면 좋았잖아. 지금은 괜찮아. 천천히 해."`, `${name} looks at you, then takes your hand. "You should have woken me first. I'm all right now. Go slowly."`],
            [`${name}은(는) 잠깐 숨을 고릅니다. "놀랐어. 그래도 지금은 내가 고른 거야. 천천히 해."`, `${name} catches her breath. "You startled me. But I'm choosing now. Go slowly."`],
          ],
          refused: [
            [`${name}은(는) 당신의 손을 놓고 고개를 젓습니다. "싫어. 지금은 멈춰 줘."`, `${name} lets go of your hand and shakes her head. "No. Please stop now."`],
            [`${name}은(는) 몸을 일으켜 당신과 거리를 둡니다. "먼저 물어봤어야지. 지금은 혼자 있을래."`, `${name} sits up and moves away. "You should have asked first. I want to be alone now."`],
          ],
        },
      };
      const lines = choice === 'apologize' ? pools[response]
        : voicePools[state.primaryCharacterId]?.[response] || pools[response];
      return sceneLine(state, `wake:${key}:${state.primaryCharacterId}`, lines);
    }

    function resolvePlayerWakeChoice(state, choiceId) {
      const context = state.pendingEvent?.sleepActions?.wake;
      if (!context || !['sleep:wake:apologize', 'sleep:wake:ask-continue'].includes(choiceId)) {
        return state;
      }
      const choice = choiceId === 'sleep:wake:apologize' ? 'apologize' : 'ask-continue';
      let next = { ...state, pendingEvent: undefined };
      const evaluation = api.fn('evaluateIntimacy')(
        next,
        context.acceptanceActionId,
        { kind: 'player_intimate', characterId: context.characterId || next.primaryCharacterId },
      );
      const decision = sleepWakeDecision(evaluation);
      const line = playerWakeResponseLine(next, choice, decision);
      next = api.fn('applyEffects')(next, {
        targetCharacterId: context.characterId || next.primaryCharacterId,
        ...playerWakeReactionEffects(choice, decision, context),
      });
      next = api.fn('updateWife')(next, wife => ({
        ...wife,
        lastResponse: line,
        lastResponseSlot: whole(next.slot),
        lastResponseType: sleepWakeResponseType(decision),
      }));
      next = api.fn('log')(next, line);
      if (choice === 'ask-continue' && decision.accepted && context.continueSceneId) {
        const scene = api.fn('sceneDef')(context.continueSceneId);
        if (scene?.playerAvailable !== false) {
          return api.fn('startPlayerSex')(next, context.continueSceneId, context.characterId);
        }
      }
      return next;
    }

    function morningEvidenceScore(evidence) {
      const value = settings();
      const repeated = Math.max(1, whole(evidence?.count, 1)) - 1;
      return clamp(
        number(evidence?.chance)
          + Math.min(value.morningRepeatEvidenceCap, repeated * value.morningRepeatEvidenceBonus),
        0, 100,
      );
    }

    function strongestMorningEvidence(incident) {
      return [...(incident?.evidence || [])].sort((left, right) => (
        morningEvidenceScore(right) - morningEvidenceScore(left)
      ))[0] || null;
    }

    function morningNoticeChance(state, incident) {
      const value = settings();
      const wife = characterOf(state, incident.characterId);
      const attributes = api.fn('getEffectiveAttributes')(wife) || wife?.attributes || {};
      const strongest = strongestMorningEvidence(incident);
      const secondary = Math.min(
        value.morningSecondaryEvidenceCap,
        Math.max(0, (incident.evidence.length - 1) * value.morningSecondaryEvidenceBonus),
      );
      const minimum = clamp(Math.min(value.morningNoticeMinimum, value.morningNoticeMaximum), 0, 100);
      const maximum = clamp(Math.max(value.morningNoticeMinimum, value.morningNoticeMaximum), 0, 100);
      return clamp(Math.round(
        morningEvidenceScore(strongest)
        + secondary
        + (number(attributes.wit, 50) - 50) * value.morningNoticeWitWeight
        + (number(attributes.composure, 50) - 50) * value.morningNoticeComposureWeight,
      ), minimum, maximum);
    }

    function hasLatentTrait(character, trait) {
      return Array.isArray(character?.latentTraits) && character.latentTraits.includes(trait);
    }

    function morningConfrontChance(state, incident) {
      const value = settings();
      const wife = characterOf(state, incident.characterId);
      const attributes = api.fn('getEffectiveAttributes')(wife) || wife?.attributes || {};
      let chance = value.morningConfrontBaseChance
        + (number(attributes.confidence, 50) - 50) * value.morningConfrontConfidenceWeight
        + (number(attributes.honesty, 50) - 50) * value.morningConfrontHonestyWeight
        + (number(attributes.composure, 50) - 50) * value.morningConfrontComposureWeight
        + (number(wife?.relationship?.trust, 50) - 50) * value.morningConfrontTrustWeight
        + number(api.fn('resentment')(wife)) * value.morningConfrontResentmentWeight;
      if (hasLatentTrait(wife, 'latent_dominant')) chance += value.morningConfrontDominantBonus;
      if (hasLatentTrait(wife, 'self_protective')) chance += value.morningConfrontSelfProtectiveBonus;
      if (hasLatentTrait(wife, 'true_prude')) chance += value.morningConfrontPrudeBonus;
      if (hasLatentTrait(wife, 'cold_pragmatist')) chance += value.morningConfrontPragmatistBonus;
      if (hasLatentTrait(wife, 'breaks_under_pressure')) chance += value.morningConfrontPressureBonus;
      if (hasLatentTrait(wife, 'latent_submissive')) chance += value.morningConfrontSubmissiveBonus;
      if (hasLatentTrait(wife, 'wants_to_be_corrupted')) chance += value.morningConfrontCorruptionBonus;
      if (hasLatentTrait(wife, 'guilt_eroticizer')) chance += value.morningConfrontGuiltBonus;
      if (hasLatentTrait(wife, 'romance_starved')) chance += value.morningConfrontRomanceBonus;
      const minimum = clamp(Math.min(value.morningConfrontMinimum, value.morningConfrontMaximum), 0, 100);
      const maximum = clamp(Math.max(value.morningConfrontMinimum, value.morningConfrontMaximum), 0, 100);
      return clamp(Math.round(chance), minimum, maximum);
    }

    function morningDisposition(state, characterId) {
      const wife = characterOf(state, characterId);
      const attributes = api.fn('getEffectiveAttributes')(wife) || wife?.attributes || {};
      if (hasLatentTrait(wife, 'true_prude') || hasLatentTrait(wife, 'self_protective')
        || number(attributes.openness, 50) < 35) return 'guarded';
      if (hasLatentTrait(wife, 'wants_to_be_corrupted') || hasLatentTrait(wife, 'guilt_eroticizer')
        || (number(attributes.openness, 50) >= 65 && number(attributes.libido, 50) >= 60)) return 'curious';
      if (hasLatentTrait(wife, 'cold_pragmatist') || number(attributes.composure, 50) >= 65) {
        return 'controlled';
      }
      return 'hurt';
    }

    function morningEvidencePhrase(evidence) {
      if (evidence?.kind === 'finish') {
        if (evidence.finishId === 'cum_on_face') return T(
          '얼굴과 머리카락에 말라붙은 낯선 흔적',
          'the unfamiliar dried traces on her face and hair',
        );
        if (evidence.finishId === 'cum_on_breasts') return T(
          '가슴에 남은 끈적한 얼룩',
          'the sticky stain left across her chest',
        );
        if (evidence.finishId === 'cum_on_body' && evidence.actionId === 'handjob') return T(
          '손과 손목에 남은 굳은 얼룩',
          'the dried stain on her hand and wrist',
        );
        if (evidence.finishId === 'cum_on_body' && evidence.actionId === 'thigh_job') return T(
          '허벅지에 남은 굳은 얼룩',
          'the dried stain on her thigh',
        );
        if (evidence.finishId === 'cum_on_body') return T(
          '피부에 굳어 있는 얼룩',
          'the dried stain on her skin',
        );
        if (evidence.finishId === 'cum_in_mouth') return T(
          '입안에 남은 낯선 맛과 냄새',
          'the unfamiliar taste and smell lingering in her mouth',
        );
        if (evidence.finishId === 'cum_inside' && evidence.category === 'sex_anal') return T(
          '뒤쪽에 남은 통증과 흘러나온 흔적',
          'the soreness and leaking trace left behind',
        );
        return T(
          '허벅지 안쪽과 몸 안에서 흘러나온 흔적',
          'the trace leaking from inside her and along her inner thighs',
        );
      }
      const phrases = {
        blowjob: T('입술과 턱에 남은 낯선 뻐근함', 'the unfamiliar ache in her lips and jaw'),
        deepthroat: T('목 안쪽에 남은 뚜렷한 쓰라림', 'the unmistakable soreness deep in her throat'),
        cunnilingus: T('다리 사이에 남은 낯선 감각', 'the unfamiliar sensation between her thighs'),
        sex: T('몸 안쪽에 남은 묵직한 감각', 'the lingering heaviness inside her'),
        doggy_style: T('허리와 몸 안쪽에 남은 낯선 뻐근함', 'the unfamiliar ache in her back and deep inside'),
        anal_fingering: T('뒤쪽에 남은 낯선 자극감', 'the unfamiliar sensitivity behind her'),
        anal: T('뒤쪽에 남은 분명한 통증', 'the unmistakable soreness behind her'),
      };
      return phrases[evidence?.actionId] || T('몸에 남은 낯선 감각', 'an unfamiliar sensation left in her body');
    }

    function morningUnnoticedLine(state, incident) {
      const name = characterOf(state, incident.characterId)?.name || T('그녀', 'She');
      const evidence = strongestMorningEvidence(incident);
      const key = evidence?.kind === 'finish'
        ? evidence.finishId === 'cum_on_body' && evidence.actionId === 'handjob' ? 'cum_on_hands'
          : evidence.finishId === 'cum_on_body' && evidence.actionId === 'thigh_job' ? 'cum_on_thighs'
            : `${evidence.finishId}${evidence.finishId === 'cum_inside' && evidence.category === 'sex_anal' ? ':anal' : ''}`
        : evidence?.actionId || 'other';
      const alternatives = {
        cum_on_face: [`${name}은(는) 세수를 하다 얼굴에 남은 자국을 보고 손을 멈춥니다. 한참 문지른 뒤 다시 물을 끼얹습니다.`, `${name} pauses while washing when she notices a mark on her face. She rubs at it for a long moment, then splashes on more water.`],
        cum_on_breasts: [`${name}은(는) 몸에 남은 얼룩을 발견하고 가까이 들여다봅니다. 곧 젖은 천으로 닦아 냅니다.`, `${name} notices a stain on her body and looks closer. She wipes it away with a damp cloth.`],
        cum_on_body: [`${name}은(는) 피부에 남은 자국을 손끝으로 확인하고 물을 찾습니다.`, `${name} checks a mark on her skin with her fingertips, then looks for water.`],
        cum_on_hands: [`${name}은(는) 손을 씻다가 손목에 남은 자국을 발견합니다. 물로 몇 번 더 문질러 닦습니다.`, `${name} notices a mark on her wrist while washing her hands. She scrubs it again with water.`],
        cum_on_thighs: [`${name}은(는) 허벅지에 남은 얼룩을 발견하고 손끝으로 문질러 닦습니다.`, `${name} finds a stain on her thigh and rubs it away with her fingertips.`],
        cum_in_mouth: [`${name}은(는) 입안의 낯선 맛 때문에 물을 마십니다. 잔을 내려놓고도 다시 목을 가다듬습니다.`, `${name} drinks water to clear an unfamiliar taste. After setting the cup down, she clears her throat again.`],
        'cum_inside:anal': [`${name}은(는) 앉으려다 뒤쪽의 통증에 멈칫합니다. 잠시 서 있다가 조심스럽게 자세를 바꿉니다.`, `${name} stops while sitting at a pain behind her. She stands for a moment, then carefully shifts position.`],
        cum_inside: [`${name}은(는) 걸음을 옮기다 몸 안쪽의 묵직한 감각에 멈춥니다. 숨을 고른 뒤 천천히 움직입니다.`, `${name} pauses at a heavy feeling inside her. She catches her breath before moving on slowly.`],
        blowjob: [`${name}은(는) 말하려다 입술이 뻐근해 말을 줄입니다. 손끝으로 입가를 한번 누릅니다.`, `${name} starts to speak, then stops at the soreness in her lips. She presses her fingertips to her mouth.`],
        deepthroat: [`${name}은(는) 목이 쓰라려 물을 한 모금 더 마십니다.`, `${name} takes another sip of water to ease her sore throat.`],
        cunnilingus: [`${name}은(는) 다리 사이에 남은 축축한 감각에 걸음을 멈춥니다. 잠시 자세를 고친 뒤 다시 움직입니다.`, `${name} pauses at a damp feeling between her legs. She shifts position, then moves on.`],
        sex: [`${name}은(는) 걷다가 몸 안쪽의 뻐근함에 걸음을 늦춥니다.`, `${name} slows her steps at an ache deep in her body.`],
        doggy_style: [`${name}은(는) 허리를 펴다가 얼굴을 찡그립니다. 잠깐 숨을 고른 뒤 다시 움직입니다.`, `${name} winces as she straightens her back. She catches her breath before moving again.`],
        anal_fingering: [`${name}은(는) 의자에 앉았다가 불편한 듯 자세를 고칩니다.`, `${name} sits down, then shifts position in discomfort.`],
        anal: [`${name}은(는) 앉기 전에 한동안 의자를 바라봅니다. 결국 천천히 몸을 낮춥니다.`, `${name} studies the chair for a moment before lowering herself carefully.`],
        other: [`${name}은(는) 몸에 남은 낯선 감각에 잠시 움직임을 멈춥니다. 곧 하던 일을 이어 갑니다.`, `${name} pauses at an unfamiliar feeling in her body, then returns to what she was doing.`],
      };
      // The original observation and a different physical follow-up share the same evidence filter.
      const alternative = alternatives[key] || alternatives.other;
      const original = (() => {
      if (evidence?.kind === 'finish') {
        if (evidence.finishId === 'cum_on_face') return T(
          `${name}은(는) 얼굴과 머리카락에 굳은 끈적함을 느끼고 손으로 훔쳐 냅니다. 손바닥을 한번 들여다보고는 손을 털어 냅니다.`,
          `${name} feels something sticky dried on her face and hair and wipes it away. She glances at her palm, then shakes it off.`,
        );
        if (evidence.finishId === 'cum_on_breasts') return T(
          `${name}은(는) 가슴에 굳은 얼룩을 보고 손으로 문질러 닦습니다.`,
          `${name} sees a dried stain on her breasts and rubs it away with her hand.`,
        );
        if (evidence.finishId === 'cum_on_body' && evidence.actionId === 'handjob') return T(
          `${name}은(는) 손과 손목에 굳은 얼룩을 보고 물로 문질러 닦습니다.`,
          `${name} sees a dried stain on her hand and wrist and rubs it away with water.`,
        );
        if (evidence.finishId === 'cum_on_body' && evidence.actionId === 'thigh_job') return T(
          `${name}은(는) 허벅지에 굳은 얼룩을 보고 손으로 문질러 닦습니다.`,
          `${name} sees a dried stain on her thigh and rubs it away with her hand.`,
        );
        if (evidence.finishId === 'cum_on_body') return T(
          `${name}은(는) 피부에 남은 끈적한 얼룩을 손끝으로 문지르다가 닦아 냅니다.`,
          `${name} rubs the sticky stain on her skin with her fingertips, then wipes it away.`,
        );
        if (evidence.finishId === 'cum_in_mouth') return T(
          `${name}은(는) 입안에 남은 비릿한 맛에 몇 번이나 침을 삼키고 물을 찾습니다.`,
          `${name} swallows several times at the bitter taste in her mouth and reaches for water.`,
        );
        if (evidence.finishId === 'cum_inside' && evidence.category === 'sex_anal') return T(
          `${name}은(는) 항문 안쪽의 묵직한 통증에 움찔합니다. 끈적한 것이 흘러나오자 서둘러 옷을 살핍니다.`,
          `${name} flinches at a deep ache in her anus. When something sticky leaks out, she hurriedly checks her clothes.`,
        );
        return T(
          `${name}은(는) 몸 안쪽이 묵직한 데다 허벅지로 끈적한 것이 흘러내려 잠깐 걸음을 멈춥니다.`,
          `${name} pauses as a heavy feeling inside her is followed by something sticky running down her thigh.`,
        );
      }
      const lines = {
        blowjob: T(
          `${name}은(는) 뻐근한 입술과 턱을 손끝으로 문지릅니다.`,
          `${name} rubs her sore lips and jaw with her fingertips.`,
        ),
        deepthroat: T(
          `${name}은(는) 목 안쪽이 쓰라려 몇 번이나 침을 삼키고 목을 가다듬습니다.`,
          `${name} swallows several times at the soreness deep in her throat and clears it.`,
        ),
        cunnilingus: T(
          `${name}은(는) 다리 사이에 남은 축축한 감각에 옷매무새를 고칩니다.`,
          `${name} adjusts her clothes at the lingering damp feeling between her legs.`,
        ),
        sex: T(
          `${name}은(는) 몸 안쪽의 낯선 뻐근함에 잠깐 멈춰 서서 숨을 고릅니다.`,
          `${name} pauses to catch her breath at the unfamiliar soreness inside her.`,
        ),
        doggy_style: T(
          `${name}은(는) 허리와 몸 안쪽이 뻐근해 허리를 짚고 잠시 몸을 폅니다.`,
          `${name} braces her lower back and stretches at the ache there and deep inside her.`,
        ),
        anal_fingering: T(
          `${name}은(는) 뒤쪽이 화끈거려 옷자락을 만지작거리며 자세를 고칩니다.`,
          `${name} shifts her position and fidgets with her clothes at a raw feeling behind her.`,
        ),
        anal: T(
          `${name}은(는) 항문 안쪽이 묵직하게 아파 조심스럽게 자세를 고쳐 앉습니다.`,
          `${name} carefully shifts her position at the deep ache inside her anus.`,
        ),
      };
      return lines[evidence?.actionId] || T(
        `${name}은(는) 몸에 남은 낯선 감각에 잠시 멈춰 섰다가 다시 움직입니다.`,
        `${name} pauses at an unfamiliar sensation in her body, then moves on.`,
      );
      })();
      return sceneLine(state, `morning:unnoticed:${incident.id}:${key}`,
        [[original, original], alternative], whole(incident.day || state.day));
    }

    function morningConfrontationText(state, incident) {
      const wife = characterOf(state, incident.characterId);
      const name = wife?.name || T('그녀', 'She');
      const evidence = morningEvidencePhrase(strongestMorningEvidence(incident));
      const voice = incident.characterId === 'pippa' ? 'pippa'
        : incident.characterId === 'mara' ? 'mara' : 'elena';
      const pools = {
        elena: [
          [`${name}이(가) 굳은 얼굴로 당신을 찾아옵니다. "아침에 ${evidence}이(가) 있었어. 어젯밤 나한테 무슨 짓을 한 거야?"`, `${name} comes to find you with a hard look. "This morning I found ${evidence}. What did you do to me last night?"`],
          [`${name}은(는) 당신 앞에 서서 한동안 말을 고릅니다. "아침에 ${evidence}이(가) 남아 있었어. 이게 왜 생겼는지 알고 있지?"`, `${name} stands before you, choosing her words. "There was ${evidence} this morning. You know how it got there, don't you?"`],
          [`${name}은(는) 당신의 눈을 피하지 않습니다. "${evidence}을(를) 봤어. 어젯밤 일을 처음부터 말해 줘."`, `${name} holds your gaze. "I found ${evidence}. Tell me what happened last night, from the beginning."`],
        ],
        mara: [
          [`${name}은(는) 하던 일을 내려놓고 당신을 부릅니다. "아침에 ${evidence}이(가) 있었어. 설명해 봐."`, `${name} sets her work aside and calls you over. "There was ${evidence} this morning. Explain it."`],
          [`${name}은(는) 문 앞을 막아서며 말합니다. "${evidence}을(를) 봤어. 무슨 일이었는지 똑바로 말해."`, `${name} stands in the doorway. "I found ${evidence}. Tell me plainly what happened."`],
        ],
        pippa: [
          [`${name}은(는) 당신의 소매를 잡았다가 놓습니다. "아침에 ${evidence}이(가) 있었어. 나한테 무슨 일이 있었던 거야?"`, `${name} takes your sleeve, then lets go. "This morning I found ${evidence}. What happened to me?"`],
          [`${name}은(는) 당신을 올려다봅니다. "${evidence}을(를) 봤어. 나한테 숨기는 거 있어?"`, `${name} looks up at you. "I found ${evidence}. Are you hiding something from me?"`],
        ],
      };
      return sceneLine(state, `morning:confront:${incident.id}:${voice}`, pools[voice], whole(incident.day || state.day));
    }

    function morningConfrontationEvent(state, incident, noticeChance, confrontChance) {
      const text = morningConfrontationText(state, incident);
      return {
        type: 'sleep_actions_morning_confrontation',
        customerId: '',
        customerName: characterOf(state, incident.characterId)?.name || T('그녀', 'She'),
        text,
        choices: [
          {
            id: 'sleep:morning:apologize',
            label: T('인정하고 사과하기', 'Admit it and apologize'),
            description: T('어젯밤 일을 솔직히 인정하고 진심으로 사과합니다.', 'Tell her the truth about last night and apologize sincerely.'),
          },
          {
            id: 'sleep:morning:dismiss',
            label: T('인정하지만 대수롭지 않게 여기기', 'Admit it but dismiss her concern'),
            description: T('당신이 한 일은 인정하지만 큰일은 아니었다고 말합니다.', 'Admit what you did, but tell her it was not a serious matter.'),
          },
          {
            id: 'sleep:morning:deny',
            label: T('모른다고 부인하기', 'Deny knowing anything'),
            description: T('어젯밤 일은 모른다고 잡아뗍니다.', 'Insist that you know nothing about what happened last night.'),
          },
        ],
        sleepActionsMorning: { incident, noticeChance, confrontChance },
      };
    }

    function appendMorningDiscoveryHistory(state, incident, result) {
      const data = dataOf(state);
      const record = {
        id: incident.id,
        characterId: incident.characterId,
        sourceType: incident.sourceType || 'player',
        patrons: (incident.patrons || []).map(item => ({ ...item })),
        noticed: result.noticed === true,
        confronted: result.confronted === true,
        choice: result.choice || null,
        disposition: result.disposition || null,
        reaction: result.reaction || null,
        finishCount: Math.max(0, whole(result.finishCount)),
        denialBelieved: result.denialBelieved === true,
        noticeChance: result.noticeChance,
        confrontChance: result.confrontChance,
        evidence: incident.evidence.map(item => ({ ...item })),
        day: whole(state.day, 1),
        slot: whole(state.slot),
      };
      return writeData(state, {
        ...data,
        morningDiscoveryHistory: [
          ...data.morningDiscoveryHistory.filter(item => item.id !== incident.id),
          record,
        ].slice(-MORNING_DISCOVERY_HISTORY_LIMIT),
      });
    }

    function removeMorningIncident(state, incidentId) {
      const data = dataOf(state);
      return writeData(state, {
        ...data,
        morningIncidents: data.morningIncidents.filter(item => item.id !== incidentId),
      });
    }

    function applyRecognizedActionPreference(state, incident, input) {
      let next = state;
      const keys = [...new Set(incident.evidence.map(item => item.affinityKey).filter(Boolean))];
      for (const key of keys) {
        const wife = characterOf(next, incident.characterId);
        const old = wife?.actionAffinity?.[key];
        const exposures = Math.max(0, whole(old?.exposures));
        if (exposures <= 0) continue;
        const staged = api.fn('updateWife')(next, current => ({
          ...current,
          actionAffinity: {
            ...(current.actionAffinity || {}),
            [key]: { ...current.actionAffinity?.[key], exposures: exposures - 1 },
          },
        }));
        const learned = api.fn('recordActionAffinity')(staged, key, input);
        next = api.fn('updateWife')(learned, current => ({
          ...current,
          actionAffinity: {
            ...(current.actionAffinity || {}),
            [key]: { ...current.actionAffinity?.[key], exposures },
          },
        }));
      }
      return next;
    }

    function morningSeverity(incident) {
      const score = morningEvidenceScore(strongestMorningEvidence(incident));
      return score >= 90 ? 4 : score >= 75 ? 3 : score >= 55 ? 2 : 1;
    }

    function morningPrivateOutcome(disposition, severity) {
      const table = {
        guarded: { mood: -4, trust: -2, resent: 3, affinity: -25 },
        hurt: { mood: -3, trust: -2, resent: 2, affinity: -18 },
        controlled: { mood: -1, trust: -1, resent: 1, affinity: -8 },
        curious: { mood: 0, trust: -1, resent: 0, affinity: -3 },
      };
      const result = { ...(table[disposition] || table.hurt) };
      const extra = Math.max(0, severity - 2);
      result.mood -= extra;
      result.resent += extra;
      result.affinity -= extra * 3;
      return result;
    }

    function morningConfrontOutcome(choice, disposition, severity, denialBelieved) {
      const tables = {
        apologize: {
          guarded: { mood: -3, trust: -1, resent: 1, affinity: -22 },
          hurt: { mood: -2, trust: 0, resent: 1, affinity: -14 },
          controlled: { mood: -1, trust: 0, resent: 0, affinity: -8 },
          curious: { mood: 0, trust: 0, resent: 0, affinity: -3 },
        },
        dismiss: {
          guarded: { mood: -7, trust: -5, resent: 6, affinity: -40 },
          hurt: { mood: -6, trust: -4, resent: 5, affinity: -32 },
          controlled: { mood: -4, trust: -3, resent: 3, affinity: -22 },
          curious: { mood: -2, trust: -2, resent: 2, affinity: -12 },
        },
        deny: {
          guarded: { mood: -7, trust: -6, resent: 6, affinity: -38 },
          hurt: { mood: -6, trust: -5, resent: 5, affinity: -30 },
          controlled: { mood: -4, trust: -4, resent: 3, affinity: -20 },
          curious: { mood: -3, trust: -3, resent: 2, affinity: -12 },
        },
      };
      if (choice === 'deny' && denialBelieved) {
        return { mood: -1, trust: -1, resent: 1, affinity: -8 };
      }
      const result = { ...(tables[choice]?.[disposition] || tables.apologize.hurt) };
      const extra = Math.max(0, severity - 2);
      if (choice !== 'apologize') {
        result.mood -= extra;
        result.trust -= Math.ceil(extra / 2);
        result.resent += extra;
        result.affinity -= extra * 4;
      }
      return result;
    }

    function applyMorningOutcomeEffects(state, incident, outcome) {
      let next = api.fn('applyEffects')(state, {
        targetCharacterId: incident.characterId,
        playerStatDeltas: { mood: outcome.trust < -2 ? -2 : -1 },
        wifeStatDeltas: { mood: outcome.mood },
        wifeTraitDeltas: {},
        trustDelta: outcome.trust,
        resentDelta: outcome.resent,
        resentSource: 'sleep-actions:morning-discovery',
      });
      next = applyRecognizedActionPreference(next, incident, outcome.affinity);
      return next;
    }

    function morningPrivateReactionLine(state, incident, disposition) {
      const name = characterOf(state, incident.characterId)?.name || T('그녀', 'She');
      const lines = {
        guarded: T(`${name}은(는) 팔로 몸을 감싸고 당신이 다가오면 한 걸음 물러섭니다. 입술을 달싹이다가도 말은 꺼내지 않습니다.`, `${name} wraps her arms around herself and steps back when you approach. Her lips part, but she says nothing.`),
        hurt: T(`${name}은(는) 당신이 가까이 오자 말없이 자리를 피합니다.`, `${name} silently moves away when you come close.`),
        controlled: T(`${name}은(는) 평소처럼 일을 시작합니다. 다만 당신이 가까이 오면 손을 멈추고 바라봅니다.`, `${name} starts her work as usual. When you come near, she pauses and looks at you.`),
        curious: T(`${name}은(는) 아무 말도 꺼내지 않고 돌아서다 한 번 더 당신을 봅니다.`, `${name} says nothing, but looks back at you once before turning away.`),
      };
      return lines[disposition] || lines.hurt;
    }

    function morningResponseBaseLine(state, incident, choice, disposition, denialBelieved) {
      const name = characterOf(state, incident.characterId)?.name || T('그녀', 'She');
      if (choice === 'apologize') {
         if (disposition === 'guarded') return T(`당신이 사과하자 ${name}은(는) 팔로 몸을 감쌉니다. "사과했다고 없던 일이 되진 않아. 다시는 그러지 마."`, `When you apologize, ${name} folds her arms around herself. "An apology doesn't erase it. Don't do it again."`);
         if (disposition === 'curious') return T(`당신이 사과하자 ${name}은(는) 시선을 내립니다. "무슨 일이었는지는 들었어. 다음에는 내가 깨어 있을 때 먼저 물어봐."`, `When you apologize, ${name} lowers her gaze. "I heard what happened. Next time, ask me first while I'm awake."`);
         if (disposition === 'controlled') return T(`${name}은(는) 사과를 듣고 잠시 침묵합니다. "알겠어. 다시는 그러지 마. 다음에는 먼저 물어봐."`, `${name} listens to your apology in silence. "All right. Don't do it again. Ask me first next time."`);
         return T(`당신이 사과하자 ${name}은(는) 한참 뒤에야 고개를 끄덕입니다. "사과는 들었어. 지금은 혼자 있고 싶어."`, `When you apologize, ${name} nods only after a long silence. "I heard you. I want to be alone now."`);
      }
      if (choice === 'dismiss') {
         if (disposition === 'curious') return T(`당신이 별일 아니라고 하자 ${name}의 표정이 굳습니다. "그걸 왜 네가 정해?"`, `When you call it nothing, ${name}'s expression hardens. "Why do you get to decide that?"`);
         return T(`당신이 대수롭지 않게 넘기자 ${name}은(는) 당신을 노려봅니다. "내가 자고 있었는데, 그게 아무 일도 아니야?" 대답을 듣지 않고 돌아섭니다.`, `When you dismiss it, ${name} glares at you. "I was asleep, and you think that makes it nothing?" She turns away before you can answer.`);
      }
       if (denialBelieved) return T(`당신이 모른다고 하자 ${name}은(는) 당신을 한참 보다가 시선을 거둡니다. "…그래. 일단 알겠어."`, `When you deny knowing anything, ${name} studies you, then looks away. "…All right. For now."`);
       return T(`당신이 모른다고 잡아떼자 ${name}의 표정이 굳습니다. "거짓말하지 마. 그럼 이건 어떻게 설명할 건데?" 그녀는 대답을 기다리지 않고 돌아섭니다.`, `When you deny it, ${name}'s expression hardens. "Don't lie to me. How do you explain this, then?" She turns away without waiting for an answer.`);
    }

    function morningResponseLine(state, incident, choice, disposition, denialBelieved) {
      const name = characterOf(state, incident.characterId)?.name || T('그녀', 'She');
      const key = choice === 'apologize' ? `${choice}:${disposition}`
        : choice === 'deny' ? `${choice}:${denialBelieved ? 'believed' : 'doubted'}`
          : choice;
      const alternatives = {
        'apologize:guarded': [`${name}은(는) 사과를 듣고 손을 움켜쥡니다. "내가 모르는 사이였잖아. 다시는 그러지 마."`, `${name} clenches her hand at your apology. "I didn't even know it was happening. Never do that again."`],
        'apologize:curious': [`${name}은(는) 고개를 끄덕이지 않습니다. "사과는 들었어. 아직 바로 괜찮다고는 못 하겠어."`, `${name} does not nod. "I heard your apology. I can't say I'm all right yet."`],
        'apologize:controlled': [`${name}은(는) 당신의 말을 끝까지 듣습니다. "알겠어. 다음엔 내가 대답할 수 있을 때 물어봐."`, `${name} lets you finish. "All right. Next time, ask when I can answer."`],
        'apologize:hurt': [`${name}은(는) 한참 뒤에야 입을 엽니다. "사과는 들었어. 지금은 좀 떨어져 있어 줘."`, `${name} speaks only after a long pause. "I heard your apology. Give me some space now."`],
        dismiss: [`${name}은(는) 당신이 말을 마치기도 전에 등을 돌립니다. "내가 겪은 일을 어떻게 별일 아니라고 할 수 있어?"`, `${name} turns away before you finish. "How can you call what happened to me nothing?"`],
        'deny:believed': [`${name}은(는) 당신을 한참 바라보다 고개를 돌립니다. "그래. 하지만 이상한 게 더 있으면 다시 물을 거야."`, `${name} studies you for a long moment, then turns away. "All right. But if I find anything else, I'll ask again."`],
        'deny:doubted': [`${name}은(는) 당신의 대답에 고개를 젓습니다. "그 말은 믿을 수 없어." 더 묻지 않고 자리를 뜹니다.`, `${name} shakes her head at your answer. "I can't believe that." She leaves without asking more.`],
      };
      const original = morningResponseBaseLine(state, incident, choice, disposition, denialBelieved);
      return sceneLine(state, `morning:response:${incident.id}:${key}`,
        [[original, original], alternatives[key] || alternatives['apologize:hurt']],
        whole(incident.dayStarted || state.day));
    }

    function patronMorningFinishCount(incident) {
      return (incident?.evidence || []).reduce((total, evidence) => (
        total + (evidence.kind === 'finish' ? Math.max(1, whole(evidence.count, 1)) : 0)
      ), 0);
    }

    function patronMorningReaction(state, characterId) {
      const wife = characterOf(state, characterId);
      const attributes = api.fn('getEffectiveAttributes')(wife) || wife?.attributes || {};
      if (hasLatentTrait(wife, 'true_prude') || hasLatentTrait(wife, 'self_protective')
        || number(attributes.openness, 50) < 35) return 'alarmed';
      if (hasLatentTrait(wife, 'latent_dominant')) return 'indignant';
      if (hasLatentTrait(wife, 'wants_to_be_corrupted')
        || (number(attributes.openness, 50) >= 70 && number(attributes.libido, 50) >= 65)) {
        return 'pleased';
      }
      if (hasLatentTrait(wife, 'guilt_eroticizer') || hasLatentTrait(wife, 'latent_submissive')
        || hasLatentTrait(wife, 'romance_starved')) return 'conflicted';
      if (hasLatentTrait(wife, 'cold_pragmatist') || number(attributes.composure, 50) >= 65) {
        return 'controlled';
      }
      return 'embarrassed';
    }

    function patronMorningOutcome(reaction, finishCount) {
      const table = {
        alarmed: { mood: -5, affinity: -28 },
        indignant: { mood: -4, affinity: -24 },
        embarrassed: { mood: -2, affinity: -10 },
        conflicted: { mood: -1, affinity: 3 },
        controlled: { mood: 0, affinity: -3 },
        pleased: { mood: 2, affinity: 12 },
      };
      const result = { ...(table[reaction] || table.embarrassed) };
      const extra = Math.min(3, Math.max(0, finishCount));
      if (reaction === 'pleased') {
        result.mood += extra;
        result.affinity += extra * 6;
      } else if (reaction === 'conflicted') {
        result.mood -= extra;
        result.affinity += extra * 2;
      } else if (reaction === 'controlled') {
        result.mood -= Math.ceil(extra / 2);
        result.affinity -= extra;
      } else {
        result.mood -= extra;
        result.affinity -= extra * (reaction === 'embarrassed' ? 4 : 7);
      }
      return result;
    }

    function patronMorningCountLine(finishCount) {
      if (finishCount <= 0) return '';
      if (finishCount === 1) return T(
        '그녀의 손이 잠깐 멈춥니다.',
        'Her hand pauses for a moment.',
      );
      if (finishCount === 2) return T(
        '그녀는 한참 동안 몸을 다시 살핍니다.',
        'She looks over her body again for a long moment.',
      );
      return T(
        '그녀는 몇 차례 숨을 고른 뒤 손끝을 움켜쥡니다.',
        'She takes several breaths, then curls her fingers into her palm.',
      );
    }

    function patronMorningReactionLine(state, incident, reaction, finishCount) {
      const name = characterOf(state, incident.characterId)?.name || T('그녀', 'She');
      const evidence = morningEvidencePhrase(strongestMorningEvidence(incident));
      const countLine = patronMorningCountLine(finishCount);
      const opening = T(
        `정신을 차린 ${name}은(는) 몸을 살피다가 ${evidence}을(를) 알아차리고 멈칫합니다.`,
        `After coming to, ${name} notices ${evidence} while checking herself and pauses.`,
      );
      const reactions = {
        alarmed: [
          ['그녀는 숨을 삼키고 황급히 몸을 가립니다. "누가…?" 문 쪽을 보며 한 걸음 물러섭니다.', 'She catches her breath and hurriedly covers herself. "Who…?" She looks toward the door and steps back.'],
          ['그녀는 문을 확인한 뒤 몸을 가립니다. "여기 누가 있었어?"', 'She checks the door, then covers herself. "Was someone here?"'],
        ],
        indignant: [
          ['그녀는 팔로 몸을 가리고 문 쪽을 노려봅니다. "누가 여기 들어왔어?"', 'She covers herself with her arms and glares toward the door. "Who came in here?"'],
          ['그녀는 문 쪽으로 성큼 다가갔다가 멈춥니다. "누구였든 그냥 넘어가진 않을 거야."', 'She strides toward the door, then stops. "Whoever it was, I will not let this pass."'],
        ],
        embarrassed: [
          ['그녀는 얼굴을 붉히고 손끝을 만지작거립니다. "무슨 일이 있었던 거지…"', 'Her face reddens and she fidgets with her fingers. "What happened…?"'],
          ['그녀는 자신을 살피다 손을 멈춥니다. "이게 왜…"', 'She pauses while looking herself over. "Why is this…"'],
        ],
        conflicted: [
          ['그녀는 몸을 굳힌 채 한동안 자신을 살핍니다. 손을 거두었다가 다시 뻗지만 끝내 아무 말도 하지 않습니다.', 'She goes still and studies herself. Her hand draws back, then reaches out again, but she says nothing.'],
          ['그녀는 문 쪽을 보다가 시선을 내립니다. 『무슨 일이 있었는지 먼저 알아야 해.』', 'She looks toward the door, then lowers her gaze. 『I need to find out what happened first.』'],
        ],
        controlled: [
          ['그녀는 몸을 차분히 살핀 뒤 주위를 둘러봅니다. 표정은 쉽게 바뀌지 않습니다.', 'She calmly checks herself, then looks around. Her expression barely changes.'],
          ['그녀는 문과 몸에 남은 흔적을 차례로 확인합니다. 서둘러 결론을 내리지 않고 한참 생각에 잠깁니다.', 'She checks the door, then the traces on her body. She takes a long moment to think before drawing any conclusion.'],
        ],
        pleased: [
          ['그녀는 처음엔 놀라 굳어 있다가 입가에 옅은 미소를 띱니다. "누구였을까…"', 'She freezes in surprise at first, then a faint smile reaches her lips. "Who was it…?"'],
          ['그녀는 손끝을 내려다보다 고개를 갸웃합니다. "이상하네… 누가 왔던 걸까?"', 'She looks down at her fingertips and tilts her head. "Strange… did someone come in?"'],
        ],
      };
      const line = sceneLine(state, `morning:patron:${incident.id}:${reaction}`,
        reactions[reaction] || reactions.embarrassed, whole(incident.dayStarted || state.day));
      return [opening, countLine, line].filter(Boolean).join(' ');
    }

    function resolvePatronMorningIncident(state, incident, noticeChance) {
      const reaction = patronMorningReaction(state, incident.characterId);
      const finishCount = patronMorningFinishCount(incident);
      const outcome = patronMorningOutcome(reaction, finishCount);
      let next = api.fn('applyEffects')(state, {
        targetCharacterId: incident.characterId,
        playerStatDeltas: {},
        wifeStatDeltas: { mood: outcome.mood },
        wifeTraitDeltas: {},
      });
      next = applyRecognizedActionPreference(next, incident, outcome.affinity);
      const line = patronMorningReactionLine(next, incident, reaction, finishCount);
      next = api.fn('updateWife')(next, wife => ({
        ...wife,
        lastResponse: line,
        lastResponseSlot: whole(next.slot),
        lastResponseType: reaction === 'pleased' ? 'eager'
          : ['alarmed', 'indignant'].includes(reaction) ? 'angry' : 'hesitant',
      }));
      next = api.fn('log')(next, line);
      return appendMorningDiscoveryHistory(next, incident, {
        noticed: true,
        confronted: false,
        reaction,
        finishCount,
        noticeChance,
        confrontChance: null,
      });
    }

    function maybeResolveMorningIncident(state) {
      if (!state || state.pendingEvent || isUnconscious(state, state.primaryCharacterId)) return state;
      const data = dataOf(state);
      const incident = data.morningIncidents.find(item => item.readyAtSlot != null);
      if (!incident) return state;
      const noticeChance = morningNoticeChance(state, incident);
      const noticed = incident.noticeRoll * 100 < noticeChance;
      let next = removeMorningIncident(state, incident.id);
      if (!noticed) {
        next = api.fn('log')(next, morningUnnoticedLine(next, incident));
        return appendMorningDiscoveryHistory(next, incident, {
          noticed: false,
          confronted: false,
          finishCount: incident.sourceType === 'patron' ? patronMorningFinishCount(incident) : 0,
          noticeChance,
          confrontChance: null,
        });
      }
      if (incident.sourceType === 'patron') {
        return resolvePatronMorningIncident(next, incident, noticeChance);
      }
      const confrontChance = morningConfrontChance(next, incident);
      const confronted = incident.confrontRoll * 100 < confrontChance;
      if (confronted) {
        const text = morningConfrontationText(next, incident);
        next = api.fn('log')(next, text);
        return {
          ...next,
          pendingEvent: morningConfrontationEvent(next, incident, noticeChance, confrontChance),
        };
      }
      const disposition = morningDisposition(next, incident.characterId);
      const outcome = morningPrivateOutcome(disposition, morningSeverity(incident));
      next = applyMorningOutcomeEffects(next, incident, outcome);
      const line = morningPrivateReactionLine(next, incident, disposition);
      next = api.fn('updateWife')(next, wife => ({
        ...wife,
        lastResponse: line,
        lastResponseSlot: whole(next.slot),
        lastResponseType: disposition === 'guarded' ? 'angry' : 'hesitant',
      }));
      next = api.fn('log')(next, line);
      return appendMorningDiscoveryHistory(next, incident, {
        noticed: true,
        confronted: false,
        disposition,
        noticeChance,
        confrontChance,
      });
    }

    function resolveMorningConfrontation(state, choiceId) {
      const context = state.pendingEvent?.sleepActionsMorning;
      const choices = {
        'sleep:morning:apologize': 'apologize',
        'sleep:morning:dismiss': 'dismiss',
        'sleep:morning:deny': 'deny',
      };
      const choice = choices[choiceId];
      if (!context?.incident || !choice) return state;
      const incident = context.incident;
      const disposition = morningDisposition(state, incident.characterId);
      let denialBelieved = false;
      if (choice === 'deny') {
        const value = settings();
        const wife = characterOf(state, incident.characterId);
        const attributes = api.fn('getEffectiveAttributes')(wife) || wife?.attributes || {};
        const cunning = number(state.player?.personality?.cunning, 40);
        const minimum = clamp(Math.min(value.morningDenialMinimum, value.morningDenialMaximum), 0, 100);
        const maximum = clamp(Math.max(value.morningDenialMinimum, value.morningDenialMaximum), 0, 100);
        const believedChance = clamp(Math.round(
          value.morningDenialBaseChance + (cunning - 50) * value.morningDenialCunningWeight
          - (number(attributes.wit, 50) - 50) * value.morningDenialWitWeight
          - (number(attributes.confidence, 50) - 50) * value.morningDenialConfidenceWeight,
        ), minimum, maximum);
        denialBelieved = incident.denialRoll * 100 < believedChance;
      }
      const outcome = morningConfrontOutcome(
        choice, disposition, morningSeverity(incident), denialBelieved,
      );
      let next = { ...state, pendingEvent: undefined };
      next = applyMorningOutcomeEffects(next, incident, outcome);
      const line = morningResponseLine(next, incident, choice, disposition, denialBelieved);
      next = api.fn('updateWife')(next, wife => ({
        ...wife,
        lastResponse: line,
        lastResponseSlot: whole(next.slot),
        lastResponseType: choice === 'apologize' ? 'hesitant'
          : choice === 'dismiss' || !denialBelieved ? 'angry' : 'refuse',
      }));
      next = api.fn('log')(next, line);
      return appendMorningDiscoveryHistory(next, incident, {
        noticed: true,
        confronted: true,
        choice,
        disposition,
        denialBelieved,
        noticeChance: context.noticeChance,
        confrontChance: context.confrontChance,
      });
    }

    function resolvePlayerSleepChoice(state, choiceId) {
      state = clearNativeFinishSignals(state);
      if (!state?.pendingEvent?.sleepActions) return state;
      if (choiceId === 'sleep:touch') {
        return { ...state, pendingEvent: sleepActionEvent(state, 'touch') };
      }
      if (choiceId === 'sleep:sex') {
        return { ...state, pendingEvent: sleepActionEvent(state, 'sex') };
      }
      if (choiceId === 'sleep:back') {
        const next = clearSleepActionImage(state);
        return { ...next, pendingEvent: sleepActionEvent(next, 'root') };
      }
      if (choiceId === 'sleep:stop') {
        return { ...clearSleepActionImage(state), pendingEvent: undefined };
      }
      if (choiceId === 'sleep:wake:apologize' || choiceId === 'sleep:wake:ask-continue') {
        return resolvePlayerWakeChoice(state, choiceId);
      }
      if (choiceId === 'sleep:self-pleasure') {
        return applyPlayerSelfPleasure(state);
      }
      if (typeof choiceId === 'string' && choiceId.startsWith('sleep:act:')) {
        return applyPlayerTouchAction(state, choiceId.slice('sleep:act:'.length));
      }
      if (typeof choiceId === 'string' && choiceId.startsWith('sleep:undress:')) {
        return applyPlayerTouchAction(state, choiceId.slice('sleep:undress:'.length));
      }
      if (choiceId === 'sleep:sex:continue') {
        const actionId = dataOf(state).session?.currentSexActionId;
        return actionId ? applyPlayerSexAction(state, actionId) : state;
      }
      if (typeof choiceId === 'string' && choiceId.startsWith('sleep:sex:')) {
        return applyPlayerSexAction(state, choiceId.slice('sleep:sex:'.length));
      }
      if (typeof choiceId === 'string' && choiceId.startsWith('sleep:finish:')) {
        return applyPlayerFinish(state, choiceId.slice('sleep:finish:'.length));
      }
      return state;
    }

    function getEncounterHistory(state = api.store.game(), options = {}) {
      if (!state) return [];
      let result = dataOf(state).sleepEncounterHistory;
      if (options.characterId != null) {
        const characterId = String(options.characterId);
        result = result.filter(entry => entry.characterId === characterId);
      }
      if (options.sourceType === 'player' || options.sourceType === 'patron') {
        result = result.filter(entry => entry.sourceType === options.sourceType);
      }
      if (options.sourceId != null) {
        const sourceId = String(options.sourceId);
        result = result.filter(entry => entry.sourceId === sourceId);
      }
      const limit = options.limit == null ? result.length : Math.max(0, whole(options.limit));
      return (limit === 0 ? [] : result.slice(-limit)).map(entry => ({ ...entry }));
    }

    function getMorningDiscoveryHistory(state = api.store.game(), options = {}) {
      if (!state) return [];
      let result = dataOf(state).morningDiscoveryHistory;
      if (options.characterId != null) {
        const characterId = String(options.characterId);
        result = result.filter(entry => entry.characterId === characterId);
      }
      const limit = options.limit == null ? result.length : Math.max(0, whole(options.limit));
      return (limit === 0 ? [] : result.slice(-limit)).map(entry => ({
        ...entry,
        patrons: Array.isArray(entry.patrons) ? entry.patrons.map(item => ({ ...item })) : [],
        evidence: Array.isArray(entry.evidence) ? entry.evidence.map(item => ({ ...item })) : [],
      }));
    }

    function advanceDay(state) {
      if (!state || !state.mods?.[ID]) return state;
      const data = dataOf(state);
      if (!data.session) return state;
      const validState = isUnconscious(state, data.session.characterId);
      return validState ? state : endSession(state, 'new-day');
    }

    function afterWakeUp(state, args = []) {
      let next = advanceDay(state);
      const priorState = args[0];
      if (priorState?.activeScene?.patron && dataOf(priorState).session?.kind === 'patron') {
        next = discardCurrentMorningIncident(
          next, 'patron', dataOf(priorState).session,
        );
      } else if (priorState) next = markCurrentMorningIncidentReady(next, priorState);
      return maybeResolveMorningIncident(next);
    }

    function settleNaturalSleepWake(state, priorState) {
      const priorSession = dataOf(priorState).session;
      if (!priorSession || priorSession.kind !== 'player'
        || priorSession.unconsciousState !== 'sleeping'
        || !isUnconscious(priorState, priorSession.characterId)
        || isUnconscious(state, priorSession.characterId)) return state;
      const ready = markCurrentMorningIncidentReady(state, priorState);
      return endSession(ready, 'woke');
    }

    function drainLegacyPotionReservation(state) {
      if (!state) return state;
      if (isPassedOut(state)) return settlePassedOutAutonomy(state);
      const data = dataOf(state);
      if (!(data.pendingSleepPotionDepth > 0)
        || data.pendingSleepPotionMoveAtSlot == null
        || whole(state.slot) < data.pendingSleepPotionMoveAtSlot) return state;
      let next = api.fn('retireWife')(state, 'spent');
      next = api.fn('updateWife')(next, wife => ({
        ...wife,
        currentTask: 'sleeping',
        taskTarget: undefined,
        busyUntilSlot: 0,
        locationUntilSlot: undefined,
      }));
      next = writeData(next, {
        ...dataOf(next),
        pendingSleepPotionMoveAtSlot: null,
      });
      return beginSession(next, { characterId: next.primaryCharacterId });
    }

    function advanceSleepMinute(state) {
      if (!state) return state;
      const sessionBeforeMinute = dataOf(state).session;
      let advanced = drainLegacyPotionReservation(state);
      let data = dataOf(advanced);
      const primary = advanced.primaryCharacterId;
      if (!sessionBeforeMinute && data.session) return advanced;
      if (!data.session && isUnconscious(advanced, primary)) {
        advanced = beginSession(advanced, { characterId: primary });
        data = dataOf(advanced);
      }
      if (!data.session) return advanced;
      if (!isUnconscious(advanced, data.session.characterId)) return endSession(advanced, 'woke');
      return advanceUnconsciousTimeline(advanced, { settleScheduledWake: false });
    }

    function passiveWakeDepthLoss(state) {
      const value = settings();
      const minimum = nonNegative(value.wakeDepthLossMin, DEFAULTS.wakeDepthLossMin);
      const maximum = Math.max(
        minimum, nonNegative(value.wakeDepthLossMax, DEFAULTS.wakeDepthLossMax),
      );
      const wife = characterOf(state);
      const energy = clamp(number(wife?.stats?.energy, 50), 0, 100) / 100;
      const originalRestNeed = clamp(number(api.fn('wifeRestNeed')(state)), 0, 100) / 100;
      return (minimum + (maximum - minimum) * energy) * (1 - originalRestNeed * 0.5);
    }

    function scheduledNaturalWakeSlot(state, wife = characterOf(state)) {
      if (!Number.isFinite(Number(wife?.wakeSlot))) return null;
      const slot = whole(state.slot);
      const dayStart = Math.floor(slot / 1440) * 1440;
      const opening = dayStart + whole(api.fn('openingMinuteOfDay'));
      return Math.min(whole(wife.wakeSlot), opening >= slot ? opening : slot);
    }

    function passiveWakeDepthShouldFall(state, session) {
      if (!session || session.depth <= 0 || session.depth > settings().normalDepthCap) return false;
      const loss = passiveWakeDepthLoss(state);
      if (!(loss > 0)) return false;
      const wife = characterOf(state, session.characterId);
      if (!wife) return false;
      if (session.unconsciousState === 'sleeping') {
        if (api.fn('wifeSick')(state)) return false;
        const scheduledWake = scheduledNaturalWakeSlot(state, wife);
        if (scheduledWake != null) {
          return scheduledWake - whole(state.slot) <= Math.ceil(session.depth / loss);
        }
      } else if (session.unconsciousState === 'passed_out') {
        const band = api.fn('intoxicationBand')(number(wife.intoxication?.level));
        if (band === 'blacked_out') return false;
      }
      const start = session.unconsciousState === 'passed_out'
        && Number.isFinite(Number(wife.passedOutAtSlot))
        ? whole(wife.passedOutAtSlot) : whole(session.startedAtSlot);
      return whole(state.slot) - start >= settings().unconsciousRecoveryDelayMinutes;
    }

    function advanceSessionDepthMinute(state, session) {
      const value = settings();
      if (session.depth > value.normalDepthCap) {
        return {
          ...session,
          activeThisMinute: false,
          depth: Math.max(value.normalDepthCap, session.depth - 1),
        };
      }
      if (session.activeThisMinute) return { ...session, activeThisMinute: false };
      if (passiveWakeDepthShouldFall(state, session)) {
        return { ...session, depth: Math.max(0, session.depth - passiveWakeDepthLoss(state)) };
      }
      if (session.depth >= value.normalDepthCap) return session;
      const recoverySpan = Math.max(0, Math.floor(
        value.recoveryPerMinuteMax - value.recoveryPerMinuteMin,
      ));
      const recovery = value.recoveryPerMinuteMin
        + (recoverySpan > 0 ? Math.floor(Math.random() * (recoverySpan + 1)) : 0);
      return {
        ...session,
        depth: Math.min(value.normalDepthCap, Math.max(0, session.depth + recovery)),
      };
    }

    function naturalRecoveryLine(state, unconsciousState, startedAtSlot) {
      const name = characterOf(state)?.name || T('그녀', 'She');
      const pairs = unconsciousState === 'passed_out' ? [
        [
          `${name}의 손끝이 움직입니다. 잠시 뒤 그녀는 눈을 몇 번 깜빡이고 이마를 짚습니다.`,
          `${name}'s fingers stir. A moment later, she blinks several times and presses a hand to her forehead.`,
        ],
        [
          `${name}은(는) 길게 숨을 들이쉰 뒤 눈을 뜹니다. 그녀의 시선이 천천히 주위를 훑습니다.`,
          `${name} draws a long breath and opens her eyes. Her gaze slowly moves around her surroundings.`,
        ],
      ] : [
        [
          `${name}은(는) 눈을 뜨고 잠시 가만히 있습니다. 이윽고 주위를 둘러보며 몸을 추스릅니다.`,
          `${name} opens her eyes and stays still for a moment. Then she looks around and gathers herself.`,
        ],
        [
          `${name}은(는) 몸을 뒤척이다 눈을 뜹니다. 잠기운을 떨치듯 얼굴을 한 번 쓸어내립니다.`,
          `${name} stirs and opens her eyes, then rubs a hand over her face as the last of sleep fades.`,
        ],
      ];
      return sceneLine(state, `natural-recovery:${unconsciousState}`, pairs, startedAtSlot);
    }

    function finishPassiveNaturalWake(state, sourceSession) {
      const participants = sourceSession?.patronParticipants || {};
      if (sourceSession?.kind === 'patron' && state.activeScene?.patron) {
        return finishPassedOutPatronFlow(state, 'natural-recovery', true);
      }
      let next = sourceSession?.kind === 'patron'
        ? clearPatronFlowScene(state, participants) : state;
      const prior = next;
      next = wakeUnconsciousCharacter(next);
      if (sourceSession?.unconsciousState === 'sleeping') {
        next = api.fn('updateWife')(next, wife => ({ ...wife, retiredAtSlot: undefined }));
      }
      next = endSession(next, 'natural-recovery');
      next = markCurrentMorningIncidentReady(next, prior);
      return api.fn('log')(next, naturalRecoveryLine(
        next, sourceSession?.unconsciousState, sourceSession?.startedAtSlot,
      ));
    }

    function advanceUnconsciousTimeline(state, options = {}) {
      if (!state) return state;
      let data = dataOf(state);
      const sourceSession = data.session;
      if (!sourceSession) return state;
      const depthDepletedBeforeTimeline = sourceSession.depth <= 0;
      if (!isUnconscious(state, sourceSession.characterId)) {
        return sourceSession.kind === 'patron'
          ? finishPassedOutPatronFlow(state, 'patron-interrupted')
          : endSession(state, 'woke');
      }

      let next = state;
      if (sourceSession.unconsciousState === 'sleeping'
        && options.settleScheduledWake !== false) {
        const naturallyAdvanced = api.fn('settleWifeNaturalWake')(next);
        if (!isUnconscious(naturallyAdvanced, sourceSession.characterId)) {
          if (sourceSession.kind === 'patron' && naturallyAdvanced.activeScene?.patron) {
            return resolvePatronWake(
              naturallyAdvanced,
              'scheduled-natural-wake',
              sourceSession.patronParticipants || {},
              { alreadyAwake: true },
            );
          }
          const ready = markCurrentMorningIncidentReady(naturallyAdvanced, next);
          return endSession(ready, 'woke');
        }
        next = naturallyAdvanced;
      }

      data = dataOf(next);
      let session = data.session;
      const currentSlot = whole(next.slot);
      if (session.lastDepthUpdateSlot == null) {
        return writeData(next, {
          ...data, session: { ...session, lastDepthUpdateSlot: currentSlot },
        });
      }
      const previousSlot = Math.min(currentSlot, whole(session.lastDepthUpdateSlot));
      const firstSlot = Math.max(previousSlot + 1, currentSlot - 1439);
      for (let minuteSlot = firstSlot; minuteSlot <= currentSlot && session.depth > 0; minuteSlot += 1) {
        session = advanceSessionDepthMinute({ ...next, slot: minuteSlot }, session);
      }
      session = { ...session, lastDepthUpdateSlot: currentSlot };
      next = writeData(next, { ...data, session });
      if (session.depth > 0) return next;
      if (depthDepletedBeforeTimeline) return next;

      const wife = characterOf(next, session.characterId);
      if (session.unconsciousState === 'sleeping' && Number.isFinite(Number(wife?.wakeSlot))) {
        if (options.settleScheduledWake === false) return next;
        const naturallyAdvanced = api.fn('settleWifeNaturalWake')(next);
        if (isUnconscious(naturallyAdvanced, session.characterId)) return next;
        if (session.kind === 'patron' && naturallyAdvanced.activeScene?.patron) {
          return resolvePatronWake(
            naturallyAdvanced,
            'scheduled-natural-wake',
            session.patronParticipants || {},
            { alreadyAwake: true },
          );
        }
        const ready = markCurrentMorningIncidentReady(naturallyAdvanced, next);
        return endSession(ready, 'woke');
      }
      if (session.unconsciousState === 'sleeping' && api.fn('wifeSick')(next)) return next;
      return finishPassiveNaturalWake(next, session);
    }

    function patronIntentEligible(customer, minimumIntent = 'interested') {
      const minimumIndex = PATRON_INTENTS.indexOf(minimumIntent);
      return PATRON_INTENTS.indexOf(customer?.intent)
        >= (minimumIndex >= 0 ? minimumIndex : PATRON_INTENTS.indexOf('interested'));
    }

    function promoteDrinkBlackoutPatron(state, customerId) {
      if (!state || !customerId) return state;
      const customer = (state.customers || []).find(item => item.id === customerId);
      if (!customer) return state;
      let next = {
        ...state,
        customers: state.customers.map(item => item.id === customerId
          ? { ...item, intent: 'predatory' } : item),
      };
      if (next.activeScene?.patron?.customerId === customerId) {
        next = {
          ...next,
          activeScene: { ...(next.activeScene || {}), patron: undefined },
          pendingEvent: next.pendingEvent?.type === 'patron_interaction'
            ? undefined : next.pendingEvent,
        };
        next = api.fn('updateWife')(next, wife => ({
          ...wife,
          sceneOverride: undefined,
          sceneVariant: undefined,
          sceneSetAtSlot: undefined,
        }));
      }
      next = api.fn('log')(next, T(
        `${customer.name}은(는) 자신이 건넨 술에 그녀가 완전히 정신을 잃자 태도를 바꾸고 곁에 남습니다.`,
        `${customer.name} changes his manner and stays close when the drink he offered leaves her unconscious.`,
      ));
      next = schedulePatronApproach(next, {
        customerId,
        immediate: true,
        style: 'opportunistic',
        reason: 'drink_blackout',
        knowsLocation: true,
      });
      return beginPassedOutPatronFlow(next);
    }

    function afterOriginalPatronTick(result, args = []) {
      const before = args[0];
      if (!result || !before) return result;
      let next = result;
      if (!isPassedOut(before) && isPassedOut(next)) {
        const beforeLevel = number(characterOf(before)?.intoxication?.level);
        const afterLevel = number(characterOf(next)?.intoxication?.level);
        const customerId = before.activeScene?.patron?.customerId;
        if (customerId && afterLevel > beforeLevel && afterLevel >= 95) {
          next = promoteDrinkBlackoutPatron(next, customerId);
        }
      }
      return finalizePendingInterventionReturn(settlePendingPatronRoomReturns(next));
    }

    function ownsUnconsciousPatronTick(state) {
      const data = dataOf(state);
      return data.session?.kind === 'patron'
        && data.session.characterId === state?.primaryCharacterId
        && !!state?.activeScene?.patron?.sleepActionsStage
        && isUnconscious(state, data.session.characterId);
    }

    function processPatronTickAtOwnershipBoundary(next, state, ...rest) {
      if (ownsUnconsciousPatronTick(state)) return state;
      return next(state, ...rest);
    }

    function patronOnCooldown(state, customerId) {
      return whole(dataOf(state).patronCooldowns?.[customerId]) > whole(state?.slot);
    }

    function patronCooldownStatus(state, customerId) {
      const data = dataOf(state);
      const untilSlot = Math.max(0, whole(data.patronCooldowns?.[customerId]));
      const participant = data.session?.patronParticipants?.[customerId];
      return Object.freeze({
        untilSlot,
        remainingMinutes: Math.max(0, untilSlot - whole(state?.slot)),
        nextMinutes: participant?.cooldownMinutes ?? settings().patronCooldownMinutes,
      });
    }

    function setPatronCooldown(state, request = {}) {
      const customerId = request.customerId;
      if (!state || typeof customerId !== 'string' || !customerId
        || !(state.customers || []).some(customer => customer.id === customerId)
        || request.minutes == null || !Number.isFinite(Number(request.minutes))
        || Number(request.minutes) < 0) return state;
      const data = dataOf(state);
      const patronCooldowns = { ...data.patronCooldowns };
      const minutes = clamp(whole(request.minutes), 0, 240);
      if (minutes === 0) delete patronCooldowns[customerId];
      else patronCooldowns[customerId] = whole(state.slot) + minutes;
      return writeData(state, { ...data, patronCooldowns });
    }

    function setPatronNextCooldown(state, request = {}) {
      const customerId = request.customerId;
      if (!state || typeof customerId !== 'string' || !customerId
        || request.minutes == null || !Number.isFinite(Number(request.minutes))
        || Number(request.minutes) < 0) return state;
      const data = dataOf(state);
      const participant = data.session?.kind === 'patron'
        ? data.session.patronParticipants?.[customerId] : null;
      if (!participant || participant.completed) return state;
      const minutes = clamp(whole(request.minutes), 0, 240);
      return writeData(state, {
        ...data,
        session: {
          ...data.session,
          patronParticipants: {
            ...data.session.patronParticipants,
            [customerId]: { ...participant, cooldownMinutes: minutes },
          },
        },
      });
    }

    function startPatronCooldowns(state, customerIds, participants = {}) {
      if (!state || !customerIds?.length) return state;
      const data = dataOf(state);
      const patronCooldowns = { ...data.patronCooldowns };
      for (const customerId of new Set(customerIds.filter(Boolean))) {
        if (whole(patronCooldowns[customerId]) <= whole(state.slot)) {
          const override = participants[customerId]?.cooldownMinutes;
          const minutes = override == null ? settings().patronCooldownMinutes
            : clamp(whole(override), 0, 240);
          patronCooldowns[customerId] = whole(state.slot) + minutes;
        }
      }
      return writeData(state, { ...data, patronCooldowns });
    }

    function patronStageAction(stage, actionId = null) {
      const action = PATRON_STAGE_ACTIONS[stage] || null;
      if (stage !== 'groping' || !action
        || !['touch_breasts', 'touch_under_skirt'].includes(actionId)) return action;
      return { ...action, actionId };
    }

    function patronFinishAction(stage, customer) {
      const risky = number(customer?.boldness) > settings().patronRiskyFinishBoldness;
      if (stage === PATRON_SELF_STROKE_STAGE) return 'self_stroke_away';
      if (stage === 'handjob_patron' || stage === 'rubbing_patron') return 'cum_on_body';
      if (stage === 'blowjob_patron') return risky ? 'cum_in_mouth' : 'cum_on_face';
      if (stage === 'sex_patron') return risky ? 'cum_inside' : 'pull_out';
      return null;
    }

    function patronSelfStrokeFinishTarget(state) {
      const exposure = api.fn('exposureSummary')(characterOf(state));
      if (exposure.topBare) {
        return { actionId: 'titfuck', finishId: 'cum_on_breasts', fluidTags: ['cum_on_chest'] };
      }
      if (exposure.baredBelow || exposure.skirtOff) {
        return { actionId: 'sex', finishId: 'cum_on_body', fluidTags: ['cum_on_body'] };
      }
      return { actionId: 'blowjob', finishId: 'cum_on_face', fluidTags: ['cum_on_face'] };
    }

    function patronFinishFluidTags(participant, customer, finishId) {
      if (participant.stage === 'handjob_patron') return ['cum_on_hands'];
      if (participant.stage === 'blowjob_patron') {
        return finishId === 'cum_on_face' ? ['cum_on_face'] : [];
      }
      if (participant.stage === 'rubbing_patron') {
        return number(customer?.boldness) > settings().patronRiskyFinishBoldness
          ? ['cum_on_body', 'cum_dripping_thighs'] : ['cum_dripping_thighs'];
      }
      if (participant.stage === 'sex_patron') {
        if (finishId === 'cum_inside') return ['cum_dripping_thighs'];
        return participant.slot === 'astride' ? ['cum_dripping_thighs'] : ['cum_on_body'];
      }
      return null;
    }

    function patronFinishAcceptanceAction(stage, finishId) {
      if (finishId === 'cum_in_mouth') return 'cum_in_mouth';
      if (finishId === 'cum_on_face') return 'cum_on_face';
      if (finishId === 'cum_inside' && stage === 'sex_patron') return 'sex_vaginal';
      return 'cum_on_skin';
    }

    function patronIntimacyContext(state, customer, interaction) {
      return {
        kind: 'patron_request',
        characterId: state.primaryCharacterId,
        comfortWithPatron: number(interaction?.elenaComfort, 0),
        activeCustomerId: customer.id,
        isReturning: false,
        pressureLevel: 0,
      };
    }

    function patronCalculatedMaxStage(state, customer, interaction) {
      const wife = characterOf(state);
      const config = settings();
      let index = customer.intent === 'predatory'
        ? PATRON_STAGE_INDEX.sex_patron : PATRON_STAGE_INDEX.intimate;
      let additions = 0;
      if (number(interaction?.elenaComfort) >= config.patronStageComfortThreshold) {
        additions += config.patronStageComfortBonus;
      }
      if (number(wife?.stats?.arousal) >= config.patronStageArousalThreshold) {
        additions += config.patronStageArousalBonus;
      }
      if (number(wife?.intoxication?.level) >= config.patronStageIntoxicationThreshold) {
        additions += config.patronStageIntoxicationBonus;
      }
      const exposure = api.fn('exposureSummary')(wife);
      additions += exposure.topBare && exposure.baredBelow ? config.patronStageFullExposureBonus
        : exposure.topBare || exposure.baredBelow ? config.patronStagePartialExposureBonus
          : exposure.skirtOff ? config.patronStageSkirtOffBonus : 0;
      if (customer.intent === 'interested'
        && number(customer.boldness) >= config.patronStageInterestedBoldnessThreshold) {
        additions += config.patronStageInterestedBoldnessBonus;
      }
      if (customer.intent === 'interested'
        && number(customer.boldness) >= config.patronStageInterestedHighBoldnessThreshold) {
        additions += config.patronStageInterestedHighBoldnessBonus;
      }
      index += Math.min(6, additions);
      return clamp(index, PATRON_STAGE_INDEX.bold_touch, PATRON_STAGE_INDEX.sex_patron);
    }

    function stableHash(value) {
      return [...String(value || '')].reduce(
        (hash, character) => Math.imul(hash ^ character.codePointAt(0), 16777619) >>> 0,
        2166136261,
      );
    }

    function patronSearchIncidentKey(state) {
      const data = dataOf(state);
      const wife = characterOf(state);
      const unconscious = unconsciousStateOf(state) || 'awake';
      const startedAtSlot = data.session?.characterId === state?.primaryCharacterId
        && data.session.unconsciousState === unconscious
        ? data.session.startedAtSlot
        : unconscious === 'passed_out' && wife?.passedOutAtSlot != null
          ? wife.passedOutAtSlot
          : wife?.retiredAtSlot != null ? wife.retiredAtSlot : whole(state?.day, 1) * 1440;
      return `${state?.primaryCharacterId || 'primary'}:${unconscious}:${whole(startedAtSlot)}`;
    }

    function patronUnawareSearchChance(state, customer) {
      const attributes = customer?.attributes || {};
      const config = settings();
      const capabilityWeights = [
        config.patronSearchWitWeight,
        config.patronSearchComposureWeight,
        config.patronSearchBoldnessWeight,
        config.patronSearchCharmWeight,
      ];
      const weightTotal = capabilityWeights.reduce((sum, weight) => sum + weight, 0);
      const normalizedTotal = weightTotal > 0 ? weightTotal : 4;
      const normalizedWeights = weightTotal > 0 ? capabilityWeights : [1, 1, 1, 1];
      const capability = (
        number(attributes.wit, 50) * normalizedWeights[0]
        + number(attributes.composure, 50) * normalizedWeights[1]
        + number(customer?.boldness, 50) * normalizedWeights[2]
        + number(customer?.charm, 50) * normalizedWeights[3]
      ) / normalizedTotal;
      const intentModifiers = {
        interested: config.patronSearchInterestedModifier,
        predatory: config.patronSearchPredatoryModifier,
      };
      const typeModifiers = {
        regular: config.patronSearchRegularModifier,
        charmer: config.patronSearchCharmerModifier,
        drunk_bold: config.patronSearchDrunkBoldModifier,
        nobleman: config.patronSearchNoblemanModifier,
        rogue: config.patronSearchRogueModifier,
        wealthy_pervert: config.patronSearchWealthyPervertModifier,
      };
      const tacticModifiers = {
        warm_builder: config.patronSearchWarmBuilderModifier,
        smooth_charmer: config.patronSearchSmoothCharmerModifier,
        drink_pusher: config.patronSearchDrinkPusherModifier,
        lap_grabber: config.patronSearchLapGrabberModifier,
        transactional: config.patronSearchTransactionalModifier,
      };
      const searchMinimum = Math.min(
        config.patronUnawareSearchMinimum, config.patronUnawareSearchMaximum,
      );
      const searchMaximum = Math.max(
        config.patronUnawareSearchMinimum, config.patronUnawareSearchMaximum,
      );
      return clamp(
        config.patronUnawareSearchBaseChance
          + (capability - config.patronSearchAbilityCenter) * config.patronSearchAbilityInfluence
          + number(intentModifiers[customer?.intent])
          + number(typeModifiers[customer?.patronType])
          + number(tacticModifiers[customer?.tacticStyle]),
        searchMinimum,
        searchMaximum,
      );
    }

    function patronKnowsUnconsciousLocation(state, customer, options = {}) {
      const wifeRoom = api.fn('wifeLocation')(state);
      const customerRoom = api.fn('patronControlCustomerLocation')(state, customer.id);
      if (customerRoom === wifeRoom) return true;
      if ((options.knowsLocation === true || options.ownerId)
        && options.customerId === customer.id) return true;
      if (dataOf(state).session?.patronAwareCustomerIds?.includes(customer.id)) return true;
      const incidentKey = patronSearchIncidentKey(state);
      const chance = patronUnawareSearchChance(state, customer);
      const roll = (stableHash(
        `${customer.id}:unconscious-search:${incidentKey}`,
      ) % 10000) / 100;
      const searchContext = Object.freeze({
        customer,
        wifeRoom,
        customerRoom,
        unconsciousState: unconsciousStateOf(state),
        incidentKey,
        chance,
        roll,
      });
      for (const registration of [...patronSearchResolvers.values()]) {
        const resolved = registration.listener(state, searchContext);
        if (resolved === true) return true;
        if (resolved == null || resolved === false) continue;
        throw new TypeError('search resolver must return true, false, null, or undefined');
      }
      return roll < chance;
    }

    function weightedIndex(seed, weights) {
      const total = weights.reduce((sum, weight) => sum + Math.max(0, number(weight)), 0);
      if (total <= 0) return 0;
      let remaining = ((seed >>> 0) / 4294967296) * total;
      for (let index = 0; index < weights.length; index++) {
        remaining -= Math.max(0, number(weights[index]));
        if (remaining < 0) return index;
      }
      return Math.max(0, weights.length - 1);
    }

    function patronApproachProfile(state, customer) {
      const value = settings();
      const seedRoot = `${customer.id}:approach:${whole(state.day, 1)}:${whole(state.slot)}`;
      const seed = stableHash(seedRoot);
      const weightedStyles = PATRON_APPROACH_STYLES.map(style => ({
        style, weight: Math.max(0, number(value[PATRON_STYLE_WEIGHT_SETTINGS[style]])),
      }));
      const totalWeight = weightedStyles.reduce((sum, item) => sum + item.weight, 0);
      let style = PATRON_APPROACH_STYLES[seed % PATRON_APPROACH_STYLES.length];
      if (totalWeight > 0) {
        style = weightedStyles[weightedIndex(seed, weightedStyles.map(item => item.weight))].style;
      }
      const watchMin = Math.max(0, whole(value.patronWatchMinMinutes));
      const watchMax = Math.max(watchMin, whole(value.patronWatchMaxMinutes));
      const span = watchMax - watchMin + 1;
      const privateChance = clamp(value.patronPrivateMoveChance, 0, 100);
      return {
        style,
        watchMinutes: watchMin + (stableHash(`${seedRoot}:watch`) % span),
        preferPrivate: style === 'secretive'
          || (stableHash(`${seedRoot}:private`) % 10000) / 100 < privateChance,
      };
    }

    function patronRoutePattern(state, customer, targetStage, style, slot = null) {
      const targetIndex = PATRON_STAGE_INDEX[targetStage];
      const baseUpper = targetStage === 'groping' && slot !== 'behind';
      const baseLower = targetStage === 'intimate'
        || targetStage === 'rubbing_patron' || targetStage === 'sex_patron'
        || slot === 'behind';
      const baseUpperTouch = targetIndex > PATRON_STAGE_INDEX.groping
        && style !== 'opportunistic';
      const baseLowerTouch = targetIndex > PATRON_STAGE_INDEX.intimate
        && (style === 'cautious' || style === 'teasing' || style === 'secretive');
      if (targetIndex < PATRON_STAGE_INDEX.handjob_patron) return {
        id: 'focused', needsUpper: baseUpper, needsLower: baseLower,
        upperTouch: baseUpperTouch, lowerTouch: baseLowerTouch,
      };
      const routeKey = `${customer?.id}:${targetStage}:${style}:${whole(state.day, 1)}:${whole(state.slot)}`;
      const config = settings();
      const routePatterns = [
        { id: 'focused', weight: config.patronRouteFocusedWeight },
        { id: 'upper-tour', weight: config.patronRouteUpperTourWeight },
        { id: 'lower-tour', weight: config.patronRouteLowerTourWeight },
        { id: 'full-tour', weight: config.patronRouteFullTourWeight },
        { id: 'full-lower-focus', weight: config.patronRouteFullLowerFocusWeight },
      ];
      const variant = routePatterns[weightedIndex(
        stableHash(routeKey), routePatterns.map(item => item.weight),
      )].id;
      if (variant === 'upper-tour') return {
        id: 'upper-tour', needsUpper: true, needsLower: baseLower,
        upperTouch: true, lowerTouch: baseLowerTouch,
      };
      if (variant === 'lower-tour') return {
        id: 'lower-tour', needsUpper: baseUpper, needsLower: true,
        upperTouch: baseUpperTouch, lowerTouch: true,
      };
      if (variant === 'full-tour') return {
        id: 'full-tour', needsUpper: true, needsLower: true,
        upperTouch: true, lowerTouch: true,
      };
      if (variant === 'full-lower-focus') return {
        id: 'full-lower-focus', needsUpper: true, needsLower: true,
        upperTouch: false, lowerTouch: true,
      };
      return {
        id: 'focused', needsUpper: baseUpper, needsLower: baseLower,
        upperTouch: baseUpperTouch, lowerTouch: baseLowerTouch,
      };
    }

    function patronUndressRoute(character, style, pattern) {
      if (!character) return { upper: [], lower: [] };
      const thorough = style === 'teasing';
      let virtual = { ...character, exposure: { ...(character.exposure || {}) } };
      const upper = [];
      const lower = [];
      const add = (target, actionId) => {
        const action = PLAYER_UNDRESS_ACTIONS[actionId];
        if (!action || !exposureChangeAllowed(virtual, action.exposure)) return;
        const exposure = { ...action.exposure, source: 'patron' };
        target.push({ kind: 'undress', actionId, exposure });
        virtual = { ...virtual, exposure: { ...virtual.exposure, ...exposure } };
      };
      const initial = api.fn('exposureSummary')(virtual);
      if (pattern.needsUpper && !initial.topBare) {
        add(upper, 'undress_bodice');
        add(upper, 'undress_top_down');
        if (thorough) add(upper, 'undress_top_remove');
      }
      const afterUpper = api.fn('exposureSummary')(virtual);
      if (pattern.needsLower && !afterUpper.baredBelow) {
        add(lower, 'undress_skirt_up');
        if (thorough) add(lower, 'undress_skirt_remove');
        add(lower, 'undress_panties_aside');
        if (thorough) add(lower, 'undress_panties_remove');
      }
      return { upper, lower };
    }

    function patronRoute(state, customer, targetStage, style, startingPleasure = 0, slot = null) {
      const targetActionId = targetStage === 'groping' && slot === 'behind'
        ? 'touch_under_skirt' : null;
      const target = patronStageAction(targetStage, targetActionId);
      if (!target) return [];
      if (targetStage === PATRON_SELF_STROKE_STAGE) {
        return [{ kind: 'action', stage: targetStage, ticks: Math.ceil((100 - startingPleasure) / target.rate) }];
      }
      const targetIndex = PATRON_STAGE_INDEX[targetStage];
      const exposure = api.fn('exposureSummary')(characterOf(state));
      const alreadyExposed = exposure.topBare || exposure.baredBelow || exposure.skirtOff;
      const prepTicks = style === 'cautious' || style === 'teasing' ? 4 : 3;
      const pattern = patronRoutePattern(state, customer, targetStage, style, slot);
      const clothes = patronUndressRoute(characterOf(state), style, pattern);
      const route = [];
      const addStage = (stage, actionId = null) => {
        if ((stage !== targetStage || actionId !== targetActionId)
          && !route.some(step => step.kind === 'action'
            && step.stage === stage && (step.actionId || null) === actionId)) {
          route.push({ kind: 'action', stage, ticks: prepTicks, actionId });
        }
      };
      if (targetIndex > PATRON_STAGE_INDEX.bold_touch) {
        if (!alreadyExposed) addStage('bold_touch');
        else if (targetStage !== 'groping') addStage(
          'groping', exposure.baredBelow && !exposure.topBare ? 'touch_under_skirt' : 'touch_breasts',
        );
      }
      route.push(...clothes.upper);
      if (pattern.upperTouch) addStage('groping', 'touch_breasts');
      route.push(...clothes.lower);
      if (pattern.lowerTouch) addStage('groping', 'touch_under_skirt');
      if (!route.some(step => step.kind === 'action') && targetIndex > PATRON_STAGE_INDEX.bold_touch) {
        addStage(alreadyExposed ? 'groping' : 'bold_touch');
      }
      const targetTicks = target.rate > 0
        ? Math.max(1, Math.ceil((100 - startingPleasure) / target.rate))
        : Math.max(1, whole(settings().patronNonFinishMinTicks));
      route.push({ kind: 'action', stage: targetStage, ticks: targetTicks, actionId: targetActionId });
      if (target.rate <= 0) {
        const selfStroke = patronStageAction(PATRON_SELF_STROKE_STAGE);
        route.push({
          kind: 'action',
          stage: PATRON_SELF_STROKE_STAGE,
          ticks: Math.max(1, Math.ceil(100 / selfStroke.rate)),
        });
      }
      return route;
    }

    function patronEstimatedRouteCost(state, customer, interaction, route, repeatRoot) {
      const context = patronIntimacyContext(state, customer, interaction);
      let total = 0;
      for (let index = 0; index < route.length; index++) {
        const step = route[index];
        if (step.kind === 'undress') {
          total += calculateDepthCost(state, step.actionId, {
            context, acceptanceActionId: 'visual_explicit', actionClass: 'intimate_touch',
            repeatKey: `${repeatRoot}:undress:${step.actionId}`,
          }).cost;
          continue;
        }
        const action = patronStageAction(step.stage, step.actionId);
        if (!action || action.noContact) continue;
        const calculated = calculateDepthCost(state, action.actionId, {
          context, actionClass: actionClassOf(action.actionId), repeatKey: `${repeatRoot}:${index}`,
        });
        const value = settings();
        const first = calculated.rawCost * calculated.stateMultiplier;
        const repeated = Math.max(
          value.minimumDepthCost,
          Math.round(calculated.baseCost * value.sameActionMultiplier),
        ) * calculated.stateMultiplier;
        total += first + Math.max(0, step.ticks - 1) * repeated;
      }
      const finalStep = [...route].reverse().find(step => step.kind === 'action');
      const finalStage = finalStep?.stage;
      const finalAction = patronStageAction(finalStage, finalStep?.actionId);
      if (finalAction?.rate > 0 && !finalAction.noContact) {
        const finishActionId = patronFinishAction(finalStage, customer);
        total += calculateDepthCost(state, patronFinishAcceptanceAction(finalStage, finishActionId), {
          context, actionClass: 'finish', repeatKey: `${repeatRoot}:finish`,
        }).cost;
      }
      return total;
    }

    function patronSelfStrokePlan(state, customer, interaction, maxStageIndex, availableDepth, style = 'cautious') {
      if (availableDepth <= 0
        || maxStageIndex < PATRON_STAGE_INDEX.groping
        || interaction?.patronExposed === true) return null;
      const route = patronRoute(state, customer, PATRON_SELF_STROKE_STAGE, style, 0, null);
      return {
        customer,
        interaction,
        stage: PATRON_SELF_STROKE_STAGE,
        targetStage: PATRON_SELF_STROKE_STAGE,
        style,
        route,
        slot: null,
        estimatedCost: 0,
        calculatedCost: 0,
        repeatKey: `patron:${customer.id}:${PATRON_SELF_STROKE_STAGE}`,
        wakeRisk: false,
      };
    }

    function patronPlanForStage(state, customer, interaction, maxStageIndex, availableDepth, slot = null, style = 'cautious', requestedStage = null) {
      const preferredStageDrop = style === 'cautious' ? 1 : 0;
      let possible = requestedStage && PATRON_STAGE_ACTIONS[requestedStage]
        ? [requestedStage]
        : slot
        ? [PATRON_JOIN_SLOT_STAGE[slot]].filter(Boolean)
        : PATRON_STAGES.slice(PATRON_STAGE_INDEX.bold_touch,
          Math.max(PATRON_STAGE_INDEX.bold_touch, maxStageIndex - preferredStageDrop) + 1).reverse();
      if (!requestedStage && !slot && possible.length > 1) {
        const goalSeed = stableHash(
          `${customer.id}:goal:${style}:${whole(state.day, 1)}:${whole(state.slot)}`,
        );
        const config = settings();
        const goalDrop = Math.min(
          weightedIndex(goalSeed, [
            config.patronGoalMaximumWeight,
            config.patronGoalOneBelowWeight,
            config.patronGoalTwoBelowWeight,
          ]), possible.length - 1,
        );
        possible = possible.slice(goalDrop);
      }
      for (const stage of possible) {
        if (PATRON_STAGE_INDEX[stage] > maxStageIndex) continue;
        const repeatKey = `patron:${customer.id}:${stage}`;
        const startingPleasure = slot ? 0 : patronStageAction(stage).rate > 0 ? 15 : 0;
        const route = patronRoute(state, customer, stage, style, startingPleasure, slot);
        const routeTargetStage = [...route].reverse()
          .find(step => step.kind === 'action')?.stage || stage;
        const calculatedCost = patronEstimatedRouteCost(state, customer, interaction, route, repeatKey);
        const variance = settings().patronDepthEstimateVariance;
        const estimateFactor = requestedStage ? 1 : 1 + (Math.random() * 2 - 1) * variance;
        const estimatedCost = calculatedCost === 0
          ? 0 : Math.max(0, Math.round(calculatedCost * estimateFactor));
        const safe = estimatedCost === 0 ? availableDepth > 0 : estimatedCost < availableDepth;
        const effectiveRiskBoldness = number(customer.boldness)
          + (customer.intent === 'predatory' ? settings().patronRiskPredatoryBonus : 0)
          + number(settings()[PATRON_STYLE_RISK_SETTINGS[style]]);
        const acceptsWakeRisk = !safe
          && effectiveRiskBoldness >= settings().patronMinimumBoldness;
        if (safe || acceptsWakeRisk) {
          return {
            customer, interaction, stage, targetStage: routeTargetStage, style, route, slot,
            estimatedCost, calculatedCost, repeatKey,
            wakeRisk: !safe,
          };
        }
      }
      return null;
    }

    function generalPatronActionsOpen(state) {
      return state?.phase === 'service' || state?.phase === 'last_call';
    }

    function eligibleUnconsciousPatrons(state, options = {}) {
      if (!settings().patronActionsEnabled
        || !state || !isUnconscious(state) || state.pendingEvent
        || state.activeScene?.patron || state.activeScene?.sex
        || (!options.ownerId && options.reason !== 'sleep_potion_room'
          && !generalPatronActionsOpen(state))
        || nativePatronFlowOccupied(state)) return [];
      const wifeRoom = api.fn('wifeLocation')(state);
      const minimumIntent = options.minimumIntent === 'flirt_curious'
        ? 'flirt_curious' : 'interested';
      return (state.customers || []).filter(customer => {
        const customerRoom = api.fn('patronControlCustomerLocation')(state, customer.id);
        const remotePrivateSearch = customerRoom !== wifeRoom
          && PATRON_REMOTE_SEARCH_EXCLUDED_ROOMS.has(wifeRoom);
        return patronIntentEligible(customer, minimumIntent)
          && (!options.customerId || customer.id === options.customerId)
          && canStartPatronFlow(state, { customerId: customer.id, room: wifeRoom })
          && !remotePrivateSearch
          && !patronOnCooldown(state, customer.id)
          && customer.status !== 'gone'
          && customer.status !== 'leaving'
          && customer.forceDecidedTonight !== 'trouble'
          && !!customerRoom
          && patronKnowsUnconsciousLocation(state, customer, options)
          && !api.fn('brothelCustomerBusy')(state, customer.id);
      });
    }

    function wifeAndPlayerTogetherInHall(state) {
      const wifeRoom = api.fn('wifeLocation')(state);
      return wifeRoom === 'taproom' && api.fn('playerLocation')(state) === wifeRoom;
    }

    function patronPrimarySlot(stage) {
      return stage === 'sex_patron' ? 'inside' : undefined;
    }

    function setPatronScene(state, interaction, stage, actionId = null) {
      const action = patronStageAction(stage, actionId);
      const originalStage = stage === PATRON_SELF_STROKE_STAGE ? 'groping' : stage;
      let nextInteraction = api.fn('transitionPatronStage')(
        interaction, originalStage, characterOf(state), {
          by: 'sleep-actions',
          slot: patronPrimarySlot(stage),
          ...(originalStage === 'groping' && action.actionId === 'touch_under_skirt'
            ? { place: 'under_skirt' } : {}),
        },
      );
      nextInteraction = {
        ...nextInteraction,
        sleepActionsStage: stage,
        sleepActionsActionId: action.actionId,
        watchedHimStroke: undefined,
        ...(stage === PATRON_SELF_STROKE_STAGE ? {
          lateralAct: { kind: PATRON_SELF_STROKE_STAGE, untilSlot: whole(state.slot) + 7 },
          patronExposed: true,
        } : { lateralAct: undefined }),
      };
      let next = {
        ...state,
        activeScene: { ...(state.activeScene || {}), patron: nextInteraction },
        pendingEvent: undefined,
      };
      next = api.fn('updateWife')(next, wife => ({
        ...wife,
        sceneOverride: action.scene,
        sceneVariant: api.fn('nextSceneVariant')(),
        sceneSetAtSlot: whole(state.slot),
      }));
      return next;
    }

    function patronInteractionPreview(state, customer) {
      const preview = api.fn('startPatronInteraction')(
        state, customer.id, undefined, '', { abed: true },
      );
      return preview.activeScene?.patron?.customerId === customer.id
        ? preview.activeScene.patron : null;
    }

    function schedulePatronApproach(state, options = {}) {
      const candidates = eligibleUnconsciousPatrons(state, options);
      if (!candidates.length) return state;
      const customer = options.customerId
        ? candidates[0]
        : [...candidates].sort((left, right) => (
        PATRON_INTENTS.indexOf(right.intent) - PATRON_INTENTS.indexOf(left.intent)
        || number(right.boldness) - number(left.boldness)
      ))[0];
      const profile = patronApproachProfile(state, customer);
      const wifeRoom = api.fn('wifeLocation')(state);
      const canRelocatePrivately = wifeRoom === 'taproom';
      const forcePrivate = canRelocatePrivately
        && (options.forcePrivate === true || wifeAndPlayerTogetherInHall(state));
      const approach = {
        customerId: customer.id,
        customerName: customer.name,
        startedAtSlot: whole(state.slot),
        readyAtSlot: whole(state.slot) + (options.immediate === true ? 0 : profile.watchMinutes),
        style: options.style || profile.style,
        preferPrivate: canRelocatePrivately && options.alreadyPrivate !== true
          && (forcePrivate || profile.preferPrivate),
        forcePrivate,
        sourceRoom: api.fn('patronControlCustomerLocation')(state, customer.id),
        targetRoom: api.fn('wifeLocation')(state),
        reason: options.reason || null,
        ownerId: typeof options.ownerId === 'string' ? options.ownerId : null,
        minimumIntent: PATRON_INTENTS.includes(options.minimumIntent)
          ? options.minimumIntent : null,
      };
      if ((approach.preferPrivate || approach.forcePrivate)
        && wifeRoom === 'taproom'
        && !privateRoomDestination(state, customer)) return state;
      let next = state;
      let data = dataOf(next);
      const reusable = data.session?.characterId === next.primaryCharacterId
        && data.session.unconsciousState === unconsciousStateOf(next);
      if (!reusable) {
        if (data.session) next = endSession(next, 'replaced-by-patron-watch');
        next = beginSession(next, { characterId: next.primaryCharacterId, kind: 'patron' });
        data = dataOf(next);
      }
      next = writeData(next, {
        ...data,
        session: {
          ...data.session,
          kind: 'patron',
          patronApproach: approach,
          patronAwareCustomerIds: [...new Set([
            ...(data.session?.patronAwareCustomerIds || []),
            customer.id,
          ])],
        },
      });
      if (options.immediate === true) return next;
      return api.fn('log')(next, approach.sourceRoom === api.fn('wifeLocation')(next) ? T(
        `${customer.name}은(는) 곧장 다가가지 않고 주변의 시선과 그녀의 숨결을 번갈아 살핍니다.`,
        `${customer.name} does not approach at once, instead watching the room and the rhythm of her breathing.`,
      ) : T(
          `${customer.name}은(는) 다른 방에서 나와 그녀가 있는 쪽의 기척을 살핍니다.`,
          `${customer.name} leaves the other room and listens for movement where she is.`,
      ));
    }

    function patronRentedRoom(state, customerId) {
      if (state.tavern?.tonightRenter?.customerId === customerId) return 'upstairs_hall';
      if (state.tavern?.tonightRenter2?.customerId === customerId) return 'upstairs_room_2';
      return null;
    }

    function patronRelationshipRecord(state, customer) {
      return (state.patronRecords || []).find(record => record.name === customer?.name) || null;
    }

    function privateRoomInfo(state, room) {
      if (room === 'bathroom') {
        return state.locations?.bathroom
          ? { room, owner: { kind: 'house' }, bed: false } : null;
      }
      const rooms = api.fn('availablePrivateRoomInfo')(state);
      return Array.isArray(rooms) ? rooms.find(item => item?.room === room) || null : null;
    }

    function privateRoomAvailableToPatron(state, room, customerId) {
      const info = privateRoomInfo(state, room);
      return !!info && api.fn('privateRoomAvailableForPatron')(state, info, customerId);
    }

    function emptyPrivateRooms(state, customerId) {
      return PATRON_PRIVATE_ROOMS.filter(room => {
        const occupants = state.locations?.[room]?.occupants;
        if (!privateRoomAvailableToPatron(state, room, customerId)
          || !Array.isArray(occupants) || occupants.length !== 0) return false;
        if (room === 'upstairs_room_2') {
          const assignedTo = state.tavern?.tonightRenter2?.customerId;
          if (assignedTo && assignedTo !== customerId) return false;
        }
        return true;
      });
    }

    function privateRoomDestination(state, customer, excludedRooms = new Set()) {
      const rentedRoom = patronRentedRoom(state, customer.id);
      if (rentedRoom && !excludedRooms.has(rentedRoom)
        && privateRoomAvailableToPatron(state, rentedRoom, customer.id)) return rentedRoom;
      const rooms = emptyPrivateRooms(state, customer.id)
        .filter(room => room !== rentedRoom && !excludedRooms.has(room));
      if (rooms.length) {
        return rooms[Math.abs(stringSeed(customer.id) + whole(state.slot)) % rooms.length];
      }
      return PATRON_PRIVATE_FALLBACK_ROOMS.find(room => (
        !excludedRooms.has(room) && privateRoomAvailableToPatron(state, room, customer.id)
      )) || null;
    }

    function maybeMovePatronPairToPrivateRoom(state, approach, customer) {
      const requested = (approach.preferPrivate || approach.forcePrivate)
        && api.fn('wifeLocation')(state) === 'taproom';
      if (!requested) return { state, requested: false, moved: false };
      const excludedRooms = new Set();
      let room = privateRoomDestination(state, customer, excludedRooms);
      while (room && !privateRoomAvailableToPatron(state, room, customer.id)) {
        excludedRooms.add(room);
        room = privateRoomDestination(state, customer, excludedRooms);
      }
      if (!room) return { state, requested: true, moved: false };
      const originRoom = api.fn('wifeLocation')(state);
      let next = api.fn('moveOccupant')(state, state.primaryCharacterId, room);
      next = api.fn('moveOccupant')(next, customer.id, room);
      const data = dataOf(next);
      next = writeData(next, {
        ...data,
        session: {
          ...data.session,
          patronTransfer: {
            originRoom,
            destinationRoom: room,
            returnRoom: originRoom,
            customerId: customer.id,
            sleepUnderway: true,
          },
        },
      });
      const wifeName = characterOf(next)?.name || T('그녀', 'her');
      const rentedRoom = patronRentedRoom(state, customer.id);
      const roomName = room === rentedRoom ? T('자기 객실', 'his own guest room')
        : room === 'back_room' ? T('뒷방', 'back room')
          : room === 'bathroom' ? T('욕실', 'bathroom') : T('빈 객실', 'empty guest room');
      next = api.fn('log')(next, T(
        `${customer.name}은(는) 아무도 보지 않는 틈을 타 ${wifeName}을(를) ${roomName}(으)로 조심스럽게 옮깁니다.`,
        `${customer.name} waits until no one is looking, then carefully carries ${wifeName} into the ${roomName}.`,
      ));
      return { state: next, requested: true, moved: true, room };
    }

    function participantFromPlan(plan, primary = false, returnRoom = null) {
      const firstIndex = Math.max(0, plan.route.findIndex(step => step.kind === 'action'));
      const firstStage = plan.route[firstIndex]?.stage || plan.targetStage;
      return {
        customerId: plan.customer.id,
        customerName: plan.customer.name,
        stage: firstStage,
        actionId: ['touch_breasts', 'touch_under_skirt'].includes(plan.route[firstIndex]?.actionId)
          ? plan.route[firstIndex].actionId : null,
        targetStage: plan.targetStage,
        approachStyle: plan.style,
        route: plan.route,
        routeIndex: 0,
        stepTicks: 0,
        slot: primary ? patronPrimarySlot(plan.targetStage) || null : plan.slot,
        pleasure: primary && patronStageAction(plan.targetStage).rate > 0 ? 15 : 0,
        ticks: 0,
        completed: false,
        wakeRisk: plan.wakeRisk,
        finishActionId: patronFinishAction(plan.targetStage, plan.customer),
        returnRoom,
      };
    }

    function patronReturnRoom(state, approach, customer) {
      const currentRoom = api.fn('patronControlCustomerLocation')(state, customer.id);
      const sourceRoom = customer.id === approach.customerId ? approach.sourceRoom : currentRoom;
      const targetRoom = approach.targetRoom || api.fn('wifeLocation')(state);
      return sourceRoom && sourceRoom !== targetRoom
        ? sourceRoom : patronRentedRoom(state, customer.id) || 'taproom';
    }

    function patronRoomReturnsFromParticipants(participants) {
      const result = {};
      for (const participant of Object.values(participants || {})) {
        if (!participant?.customerId) continue;
        result[participant.customerId] = {
          customerId: participant.customerId,
          returnRoom: typeof participant.returnRoom === 'string'
            ? participant.returnRoom : null,
        };
      }
      return result;
    }

    function patronRoomReturnsFromSession(session, interaction) {
      const result = patronRoomReturnsFromParticipants(session?.patronParticipants);
      const transfer = session?.patronTransfer;
      if (transfer?.customerId && !result[transfer.customerId]) {
        result[transfer.customerId] = {
          customerId: transfer.customerId,
          returnRoom: typeof transfer.returnRoom === 'string' ? transfer.returnRoom : null,
        };
      }
      const activeIds = [
        interaction?.customerId,
        ...(interaction?.joinedPatronIds || []),
        ...(interaction?.crowdPatronIds || []),
      ];
      for (const customerId of new Set(activeIds.filter(Boolean))) {
        if (!result[customerId]) result[customerId] = { customerId, returnRoom: null };
      }
      return result;
    }

    function mergePatronRoomReturns(records, fallbacks) {
      const preferred = patronRoomReturnsFromParticipants(records);
      const fallback = patronRoomReturnsFromParticipants(fallbacks);
      const result = { ...fallback };
      for (const [customerId, record] of Object.entries(preferred)) {
        result[customerId] = {
          ...fallback[customerId],
          ...record,
          returnRoom: record.returnRoom || fallback[customerId]?.returnRoom || null,
        };
      }
      return result;
    }

    function cancelPatronApproach(state, approach, options = {}) {
      let next = state;
      const transfer = dataOf(next).session?.patronTransfer;
      if (transfer?.originRoom && Array.isArray(next.locations?.[transfer.originRoom]?.occupants)
        && api.fn('wifeLocation')(next) !== transfer.originRoom) {
        next = api.fn('moveOccupant')(next, next.primaryCharacterId, transfer.originRoom);
      }
      if (approach?.sourceRoom && Array.isArray(next.locations?.[approach.sourceRoom]?.occupants)) {
        const currentRoom = api.fn('patronControlCustomerLocation')(next, approach.customerId);
        if (currentRoom !== approach.sourceRoom) {
          next = api.fn('moveOccupant')(next, approach.customerId, approach.sourceRoom);
        }
      }
      const data = dataOf(next);
      next = writeData(next, {
        ...data,
        session: data.session ? {
          ...data.session,
          patronApproach: null,
          patronTransfer: null,
        } : null,
      });
      return options.cooldown === true
        ? startPatronCooldowns(next, [approach.customerId]) : next;
    }

    function beginPassedOutPatronFlow(state, options = {}) {
      const before = dataOf(state);
      const pendingApproach = before.session?.patronApproach;
      if (pendingApproach && !canStartPatronFlow(state, {
        customerId: pendingApproach.customerId,
        room: api.fn('wifeLocation')(state),
      })) {
        return before.session?.patronApproach
          ? cancelPatronApproach(state, before.session.patronApproach)
          : state;
      }
      if (!before.session?.patronApproach) return schedulePatronApproach(state);
      const approach = before.session.patronApproach;
      if (whole(state.slot) < approach.readyAtSlot) return state;
      const watchedCustomer = (state.customers || []).find(item => item.id === approach.customerId);
      if (!watchedCustomer || watchedCustomer.status === 'gone' || watchedCustomer.status === 'leaving'
        || api.fn('brothelCustomerBusy')(state, watchedCustomer.id)) {
        return writeData(state, {
          ...before,
          session: { ...before.session, patronApproach: null },
        });
      }
      const wifeRoom = api.fn('wifeLocation')(state);
      if (approach.targetRoom && wifeRoom !== approach.targetRoom) {
        return cancelPatronApproach(state, approach);
      }
      const customerRoom = api.fn('patronControlCustomerLocation')(state, watchedCustomer.id);
      const privateMove = maybeMovePatronPairToPrivateRoom(state, approach, watchedCustomer);
      if (privateMove.requested && !privateMove.moved) return state;
      state = privateMove.state;
      if (!privateMove.moved && customerRoom !== wifeRoom) {
        state = api.fn('moveOccupant')(state, watchedCustomer.id, wifeRoom);
      }
      const candidates = eligibleUnconsciousPatrons(state, {
        ...(approach.ownerId || approach.reason === 'sleep_potion_room'
          ? { customerId: approach.customerId } : {}),
        ...(approach.ownerId ? { ownerId: approach.ownerId } : {}),
        ...(approach.reason ? { reason: approach.reason } : {}),
        ...(approach.minimumIntent || approach.reason === 'sleep_potion_room'
          ? { minimumIntent: approach.minimumIntent || 'flirt_curious' } : {}),
      });
      if (!candidates.length) return cancelPatronApproach(state, approach);
      const value = settings();
      const requestedStage = PATRON_STAGE_ACTIONS[options.targetStage]
        ? options.targetStage : null;
      const existingSession = dataOf(state).session;
      const continuingUnconsciousSession = existingSession?.characterId === state.primaryCharacterId
        && existingSession.unconsciousState === unconsciousStateOf(state);
      const prepared = candidates.filter(customer => (
        !requestedStage || customer.id === approach.customerId
      )).map(customer => {
        const interaction = patronInteractionPreview(state, customer);
        const profile = customer.id === approach.customerId
          ? approach : patronApproachProfile(state, customer);
        return interaction ? {
          customer,
          interaction,
          style: profile.style,
          returnRoom: patronReturnRoom(state, approach, customer),
          maxStageIndex: patronCalculatedMaxStage(state, customer, interaction),
        } : null;
      }).filter(Boolean).sort((left, right) => Number(right.customer.id === approach.customerId)
        - Number(left.customer.id === approach.customerId)
        || right.maxStageIndex - left.maxStageIndex
        || number(right.customer.boldness) - number(left.customer.boldness));
      const startingDepth = continuingUnconsciousSession
        ? Math.max(0, number(existingSession.depth))
        : Math.max(1, value.initialDepth);
      let primaryPlan = null;
      for (const candidate of prepared) {
        primaryPlan = requestedStage === PATRON_SELF_STROKE_STAGE
          ? patronSelfStrokePlan(
            state, candidate.customer, candidate.interaction,
            candidate.maxStageIndex, startingDepth, candidate.style,
          )
          : patronPlanForStage(
            state, candidate.customer, candidate.interaction,
            candidate.maxStageIndex, startingDepth, null, candidate.style, requestedStage,
          );
        if (primaryPlan) break;
      }
      if (!primaryPlan && !requestedStage) {
        for (const candidate of prepared) {
          primaryPlan = patronSelfStrokePlan(
            state, candidate.customer, candidate.interaction, candidate.maxStageIndex, startingDepth,
            candidate.style,
          );
          if (primaryPlan) break;
        }
      }
      if (!primaryPlan) return cancelPatronApproach(state, approach);

      let next = api.fn('startPatronInteraction')(
        state, primaryPlan.customer.id, undefined,
        isSleeping(state) ? T(
          `${primaryPlan.customer.name}은(는) 잠든 그녀 곁으로 다가갑니다.`,
          `${primaryPlan.customer.name} approaches her while she sleeps.`,
        ) : T(
          `${primaryPlan.customer.name}은(는) 의식을 잃은 그녀 곁으로 다가갑니다.`,
          `${primaryPlan.customer.name} approaches her while she is unconscious.`,
        ),
        { abed: true },
      );
      const started = next.activeScene?.patron;
      if (!started || started.customerId !== primaryPlan.customer.id) {
        return cancelPatronApproach(state, approach);
      }
      const startedSession = dataOf(next).session;
      const reusesPassedOutSession = startedSession?.kind === 'patron'
        && startedSession.characterId === next.primaryCharacterId;
      if (startedSession && !reusesPassedOutSession) {
        next = endSession(next, 'replaced-by-patron-flow');
      }
      const primaryCandidate = prepared.find(candidate => candidate.customer.id === primaryPlan.customer.id);
      const primary = participantFromPlan(primaryPlan, true, primaryCandidate?.returnRoom || null);
      const primaryStep = primary.route?.[primary.routeIndex];
      next = setPatronScene(next, started, primary.stage, primaryStep?.actionId);
      next = beginSession(next, { characterId: next.primaryCharacterId, kind: 'patron' });
      let remainingDepth = startingDepth - primaryPlan.estimatedCost;
      const participants = {
        [primaryPlan.customer.id]: primary,
      };

      for (const candidate of prepared) {
        if (candidate.customer.id === primaryPlan.customer.id) continue;
        const interaction = next.activeScene.patron;
        const exposure = api.fn('exposureSummary')(characterOf(next));
        const openSlots = primaryPlan.targetStage === PATRON_SELF_STROKE_STAGE ? [] : api.fn('joinSlots')(
          interaction, primaryPlan.targetStage, interaction.joinedPatronSlots || {}, exposure.baredBelow,
        ).filter(slot => PATRON_JOIN_SLOT_STAGE[slot])
          .sort((left, right) => PATRON_STAGE_INDEX[PATRON_JOIN_SLOT_STAGE[right]]
            - PATRON_STAGE_INDEX[PATRON_JOIN_SLOT_STAGE[left]]);
        let plan = null;
        if (primaryPlan.targetStage !== PATRON_SELF_STROKE_STAGE) {
          for (const slot of openSlots) {
            plan = patronPlanForStage(
              next, candidate.customer, candidate.interaction,
              candidate.maxStageIndex, remainingDepth, slot, candidate.style,
            );
            if (plan) break;
          }
        }
        if (!plan) plan = patronSelfStrokePlan(
          next, candidate.customer, candidate.interaction, candidate.maxStageIndex, remainingDepth,
          candidate.style,
        );
        if (!plan) continue;
        const sceneRoom = api.fn('wifeLocation')(next);
        if (api.fn('patronControlCustomerLocation')(next, plan.customer.id) !== sceneRoom) {
          next = api.fn('moveOccupant')(next, plan.customer.id, sceneRoom);
        }
        const current = next.activeScene.patron;
        next = {
          ...next,
          activeScene: {
            ...next.activeScene,
            patron: {
              ...current,
              crowdPatronIds: [...new Set([...(current.crowdPatronIds || []), plan.customer.id])],
              joinedPatronIds: [...new Set([...(current.joinedPatronIds || []), plan.customer.id])],
              joinedPatronSlots: { ...(current.joinedPatronSlots || {}), [plan.customer.id]: plan.slot },
              joinedPatronPleasure: { ...(current.joinedPatronPleasure || {}), [plan.customer.id]: 0 },
            },
          },
        };
        participants[plan.customer.id] = participantFromPlan(plan, false, candidate.returnRoom);
        remainingDepth -= plan.estimatedCost;
      }

      const data = dataOf(next);
      next = writeData(next, {
        ...data,
        session: {
          ...data.session,
          patronApproach: null,
          patronPrimaryId: primaryPlan.customer.id,
          patronOwnerId: approach.ownerId
            || (approach.reason === 'sleep_potion_room' ? LEGACY_POTION_ROOM_OWNER : null),
          patronParticipants: participants,
          activeThisMinute: true,
          lastDepthUpdateSlot: whole(next.slot),
        },
      });
      const joinedNames = Object.values(participants)
        .filter(participant => participant.customerId !== primaryPlan.customer.id)
        .map(participant => participant.customerName);
      if (joinedNames.length) {
        next = api.fn('log')(next, T(
          `${joinedNames.join(', ')}도 방 안을 한동안 지켜보다 침대 곁으로 다가옵니다.`,
          `${joinedNames.join(', ')} watch from the room for a while before moving to the bedside.`,
        ));
      }
      return api.fn('log')(next, isSleeping(next) ? T(
        `${characterOf(next)?.name || '그녀'}은(는) 아직 눈을 뜨지 않고 잠을 이어 갑니다.`,
        `${characterOf(next)?.name || 'She'} remains asleep without opening her eyes.`,
      ) : T(
        `${characterOf(next)?.name || '그녀'}은(는) 의식을 잃은 채 아무 반응 없이 늘어져 있습니다.`,
        `${characterOf(next)?.name || 'She'} remains unconscious and unresponsive.`,
      ));
    }

    function joinActivePatronFlow(state, request = {}) {
      const declined = reason => ({ state, joined: false, reason });
      const customerId = request.customerId;
      if (!state || typeof customerId !== 'string' || !customerId) return declined('customer-required');
      const data = dataOf(state);
      const session = data.session;
      const interaction = state.activeScene?.patron;
      if (!settings().patronActionsEnabled || !session || session.kind !== 'patron'
        || session.characterId !== state.primaryCharacterId || !interaction?.sleepActionsStage
        || !isUnconscious(state, session.characterId) || session.depth <= 0) {
        return declined('no-active-sleep-flow');
      }
      if (state.pendingEvent) return declined('scene-paused');
      if (session.patronOwnerId && session.patronOwnerId !== request.ownerId) {
        return declined('owned-by-another-flow');
      }
      if (session.patronParticipants?.[customerId]) return declined('already-participating');
      const customer = (state.customers || []).find(item => item.id === customerId);
      if (!customer || customer.status === 'gone' || customer.status === 'leaving'
        || customer.forceDecidedTonight === 'trouble') return declined('customer-unavailable');
      const minimumIntent = request.minimumIntent === 'flirt_curious' ? 'flirt_curious' : 'interested';
      if (!patronIntentEligible(customer, minimumIntent)
        || api.fn('brothelCustomerBusy')(state, customerId)) return declined('customer-ineligible');
      const wifeRoom = api.fn('wifeLocation')(state);
      const customerRoom = api.fn('patronControlCustomerLocation')(state, customerId);
      if (!wifeRoom || customerRoom !== wifeRoom) return declined('different-room');
      if (patronOnCooldown(state, customerId)) return declined('cooldown');

      // Preview the new patron's own comfort without replacing the active scene.
      const previewState = {
        ...state,
        activeScene: { ...state.activeScene, patron: undefined },
      };
      const preview = patronInteractionPreview(previewState, customer);
      if (!preview) return declined('interaction-unavailable');
      const maxStageIndex = clamp(
        patronCalculatedMaxStage(state, customer, preview)
          + clamp(whole(request.stageBonus), 0, PATRON_STAGE_INDEX.sex_patron),
        PATRON_STAGE_INDEX.bold_touch, PATRON_STAGE_INDEX.sex_patron,
      );
      const primary = session.patronParticipants?.[session.patronPrimaryId];
      const primaryStage = primary?.targetStage || interaction.sleepActionsStage;
      const exposure = api.fn('exposureSummary')(characterOf(state));
      const openSlots = primaryStage === PATRON_SELF_STROKE_STAGE ? [] : api.fn('joinSlots')(
        interaction, primaryStage, interaction.joinedPatronSlots || {}, exposure.baredBelow,
      ).filter(slot => PATRON_JOIN_SLOT_STAGE[slot])
        .sort((left, right) => PATRON_STAGE_INDEX[PATRON_JOIN_SLOT_STAGE[right]]
          - PATRON_STAGE_INDEX[PATRON_JOIN_SLOT_STAGE[left]]);
      const style = PATRON_APPROACH_STYLES.includes(request.style)
        ? request.style : patronApproachProfile(state, customer).style;
      let plan = null;
      for (const slot of openSlots) {
        plan = patronPlanForStage(state, customer, preview, maxStageIndex,
          session.depth, slot, style);
        if (plan) break;
      }
      if (!plan) plan = patronSelfStrokePlan(
        state, customer, { ...preview, patronExposed: interaction.patronExposed },
        maxStageIndex, session.depth, style,
      );
      if (!plan) return declined('no-available-action');

      const returnRoom = patronReturnRoom(state, {
        customerId, sourceRoom: customerRoom, targetRoom: wifeRoom,
      }, customer);
      const participant = participantFromPlan(plan, false, returnRoom);
      const joinedPatronIds = [...new Set([...(interaction.joinedPatronIds || []), customerId])];
      let next = {
        ...state,
        activeScene: {
          ...state.activeScene,
          patron: {
            ...interaction,
            crowdPatronIds: [...new Set([...(interaction.crowdPatronIds || []), customerId])],
            joinedPatronIds,
            joinedPatronSlots: { ...(interaction.joinedPatronSlots || {}), [customerId]: plan.slot },
            joinedPatronPleasure: { ...(interaction.joinedPatronPleasure || {}), [customerId]: 0 },
          },
        },
      };
      next = writeData(next, {
        ...data,
        session: {
          ...session,
          patronParticipants: { ...session.patronParticipants, [customerId]: participant },
          patronAwareCustomerIds: [...new Set([...(session.patronAwareCustomerIds || []), customerId])],
        },
      });
      next = api.fn('log')(next, T(
        `${customer.name}도 침대 곁으로 다가옵니다.`,
        `${customer.name} moves to the bedside too.`,
      ));
      return { state: next, joined: true, reason: null, participant };
    }

    function stringSeed(value) {
      return [...String(value || '')].reduce((total, character) => total + character.codePointAt(0), 0);
    }

    function rotatingLine(state, salt, koLines, enLines, divisor = 1) {
      const index = Math.abs(Math.floor(whole(state?.slot) / divisor) + whole(salt)) % koLines.length;
      return T(koLines[index], enLines[index]);
    }

    // Narration uses existing time, scene, and log data. It never consumes a judgment roll.
    function sceneLine(state, key, pairs, step = whole(state?.slot)) {
      const start = Math.abs(stringSeed(String(key)) + whole(step) + whole(state?.day)) % pairs.length;
      const recent = (Array.isArray(state?.logs) ? state.logs : Array.isArray(state?.log) ? state.log : [])
        .slice(-24).map(entry => typeof entry === 'string' ? entry : String(entry?.text || ''));
      for (let offset = 0; offset < pairs.length; offset++) {
        const pair = pairs[(start + offset) % pairs.length];
        const line = T(pair[0], pair[1]);
        if (!recent.some(previous => previous.includes(line))) return line;
      }
      const pair = pairs[start];
      return T(pair[0], pair[1]);
    }

    function playerActionLine(state, actionId, exposure = null) {
      const name = characterOf(state)?.name || T('그녀', 'her');
      if (exposure) return undressLine(state, name, exposure);
      const action = playerActionDefinition(actionId);
      const label = action?.label || actionId;
      const lines = {
        stroke: [
          [`당신은 ${name}의 머리카락과 팔을 가볍게 쓰다듬습니다.`, `You lightly stroke ${name}'s hair and arm.`],
          [`당신은 ${name}의 어깨와 팔을 천천히 쓰다듬습니다.`, `You slowly stroke ${name}'s shoulder and arm.`],
          [`당신은 ${name}의 머리카락을 귀 뒤로 넘깁니다. 그녀의 숨결은 그대로 고르게 이어집니다.`, `You brush ${name}'s hair behind her ear. Her breathing continues evenly.`],
        ],
        kiss_real: [
          [`당신은 ${name}의 입술에 조심스럽게 입을 맞추었다 떼어 냅니다.`, `You carefully kiss ${name}'s lips and draw back.`],
          [`당신은 ${name}의 입술을 짧게 누르며 입을 맞춥니다.`, `You press a brief kiss to ${name}'s lips.`],
          [`당신은 ${name}에게 입을 맞춘 뒤 잠시 얼굴을 듭니다. 그녀는 여전히 눈을 감고 있습니다.`, `You kiss ${name}, then lift your face for a moment. Her eyes remain closed.`],
        ],
        touch_breasts: [
          [`당신은 ${name}의 옷 안으로 손을 넣어 맨가슴을 만집니다.`, `You slip a hand beneath ${name}'s clothes and touch her bare breasts.`],
          [`당신은 옷감 아래에서 ${name}의 가슴을 천천히 쓰다듬습니다.`, `You slowly caress ${name}'s breasts beneath the fabric.`],
          [`당신은 ${name}의 가슴에 손을 둡니다. 그녀의 손은 제자리에 그대로 놓여 있습니다.`, `You rest a hand on ${name}'s breast. Her hand stays where it lies.`],
        ],
        touch_over_clothes: [
          [`당신은 옷 위로 ${name}의 엉덩이를 천천히 만집니다.`, `You slowly touch ${name}'s ass through her clothes.`],
          [`당신은 옷감 너머로 ${name}의 엉덩이를 손바닥으로 더듬습니다.`, `You feel ${name}'s ass with your palm through the fabric.`],
          [`당신은 옷감 위로 ${name}의 엉덩이를 만집니다. 천이 손바닥 아래에서 조금씩 구겨집니다.`, `You touch ${name}'s backside through her clothes. The fabric bunches beneath your palm.`],
        ],
        manual_receiving: [
          [`당신은 ${name}의 허벅지 안쪽으로 손을 움직여 은밀한 곳을 만집니다.`, `You move your hand along ${name}'s inner thigh and touch her intimately.`],
          [`당신은 ${name}의 다리 사이로 손을 밀어 넣어 천천히 움직입니다.`, `You slide a hand between ${name}'s thighs and move slowly.`],
          [`당신의 손이 ${name}의 허벅지 안쪽에 머뭅니다. 그녀의 손끝은 움직이지 않습니다.`, `Your hand lingers at ${name}'s inner thigh. Her fingers do not move.`],
        ],
        grinding: [
          [`당신은 옷을 입은 채 ${name}에게 몸을 밀착하고 골반을 천천히 비빕니다.`, `Still clothed, you press against ${name} and slowly grind your hips.`],
          [`당신은 ${name}에게 몸을 밀착합니다. 옷감이 서로 스치며 작은 소리를 냅니다.`, `You press close to ${name}. The fabric brushes together with a faint sound.`],
          [`당신은 천 너머로 전해지는 감촉을 느끼며 ${name}에게 계속 몸을 비빕니다.`, `Feeling her through the fabric, you keep grinding against ${name}.`],
        ],
        thigh_job: [
          [`당신은 ${name}의 두 허벅지를 모아 그 사이에 자지를 끼우고 천천히 밀어 넣습니다.`, `You press ${name}'s thighs together around your cock and thrust slowly between them.`],
          [`당신의 자지가 ${name}의 허벅지 사이를 일정한 박자로 미끄러집니다.`, `Your cock slides between ${name}'s thighs at a steady rhythm.`],
          [`당신은 ${name}의 허벅지를 붙잡고 몸을 움직입니다. 그녀의 다리에는 힘이 들어가지 않습니다.`, `You hold ${name}'s thighs as you move. Her legs offer no movement of their own.`],
        ],
        handjob: [
          [`당신은 ${name}의 손가락을 자지에 감아 쥐게 하고 천천히 움직입니다.`, `You close ${name}'s fingers around your cock and move her hand slowly.`],
          [`당신은 늘어진 ${name}의 손을 붙잡아 자지 위로 일정하게 왕복시킵니다.`, `You take ${name}'s limp hand and guide it steadily up and down your cock.`],
          [`당신은 ${name}의 손을 잡고 움직입니다. 놓을 때마다 그녀의 손가락이 다시 느슨해집니다.`, `You guide ${name}'s hand. Each time you release it, her fingers fall loose again.`],
        ],
        fingering: [
          [`당신의 손가락이 ${name}의 허벅지 사이로 미끄러져 들어갑니다.`, `Your fingers slide between ${name}'s thighs.`],
          [`당신은 젖은 살을 천천히 쓰다듬다가 손가락을 ${name}의 안으로 밀어 넣습니다.`, `You stroke her wet flesh slowly, then slide your fingers inside ${name}.`],
          [`당신은 손가락을 움직이다 ${name}의 호흡을 살핍니다. 그녀는 눈을 뜨지 않습니다.`, `You move your fingers, then watch ${name}'s breathing. She does not open her eyes.`],
        ],
        blowjob: [
          [`당신은 ${name}의 입술 사이로 자지를 밀어 넣고 천천히 허리를 움직입니다.`, `You slide your cock between ${name}'s lips and move your hips slowly.`],
          [`당신은 ${name}의 머리를 받친 채 입안으로 일정하게 움직입니다.`, `Supporting ${name}'s head, you move steadily inside her mouth.`],
          [`당신은 ${name}의 고개를 받친 채 움직입니다. 그녀의 손은 움직이지 않습니다.`, `You support ${name}'s head as you move. Her hands remain still.`],
        ],
        deepthroat: [
          [`당신은 ${name}의 머리를 붙잡고 자지를 목구멍 깊숙이 밀어 넣습니다.`, `You hold ${name}'s head and push your cock deep into her throat.`],
          [`당신의 자지가 ${name}의 목 안쪽을 누를 때마다 그녀의 몸이 작게 들썩입니다.`, `${name}'s body gives a small jolt whenever your cock presses into her throat.`],
          [`당신은 ${name}의 고개를 받쳐 자세를 바꿉니다. 그녀는 눈을 뜨지 않습니다.`, `You support ${name}'s head and change position. She does not open her eyes.`],
        ],
        cunnilingus: [
          [`당신은 ${name}의 다리 사이에 얼굴을 묻고 젖은 살을 혀로 가릅니다.`, `You bury your face between ${name}'s legs and part her wet flesh with your tongue.`],
          [`당신은 ${name}의 허벅지를 벌린 채 입을 대고 천천히 핥습니다.`, `You hold ${name}'s thighs apart, press your mouth to her, and lick slowly.`],
          [`당신은 ${name}의 다리 사이에 머뭅니다. 그녀의 숨소리가 잠깐 흔들렸다가 다시 고르게 이어집니다.`, `You remain between ${name}'s legs. Her breathing wavers briefly, then steadies again.`],
        ],
        titfuck: [
          [`당신은 ${name}의 두 가슴을 모아 그 사이에 자지를 끼웁니다.`, `You press ${name}'s breasts together around your cock.`],
          [`당신의 자지가 ${name}의 가슴 사이를 미끄러지며 젖꼭지 곁을 오갑니다.`, `Your cock slides between ${name}'s breasts and past her nipples.`],
          [`당신은 ${name}의 가슴을 모아 쥔 채 몸을 움직입니다. 그녀의 팔은 힘없이 놓여 있습니다.`, `You hold ${name}'s breasts together as you move. Her arms remain limp.`],
        ],
        sex: [
          [`당신은 ${name}의 다리를 벌리고 젖은 안으로 천천히 밀어 넣습니다.`, `You spread ${name}'s legs and slowly push into her wet pussy.`],
          [`당신은 ${name}의 허리를 붙잡고 안쪽 깊이 일정한 박자로 움직입니다.`, `You hold ${name}'s waist and move deep inside her at a steady rhythm.`],
          [`당신은 ${name}의 허벅지 사이에 몸을 밀착한 채 움직입니다. 그녀는 스스로 자세를 바꾸지 않습니다.`, `You move close between ${name}'s thighs. She does not change position herself.`],
        ],
        doggy_style: [
          [`당신은 ${name}의 허리를 숙이고 뒤에서 안으로 밀어 넣습니다.`, `You bend ${name} forward and enter her from behind.`],
          [`당신은 ${name}의 엉덩이를 붙잡고 뒤에서 일정한 박자로 허리를 움직입니다.`, `You grip ${name}'s hips and thrust from behind at a steady rhythm.`],
          [`당신은 엎드린 ${name}의 허리를 받치고 움직입니다. 그녀의 손은 제자리에 놓여 있습니다.`, `You support the prone ${name}'s waist as you move. Her hands remain where they fell.`],
        ],
        anal_fingering: [
          [`당신은 ${name}의 엉덩이를 벌리고 뒤쪽을 천천히 손가락으로 문지릅니다.`, `You spread ${name}'s cheeks and slowly rub her anus with a finger.`],
          [`당신은 힘을 뺀 ${name}의 항문에 손가락 하나를 조심스럽게 밀어 넣습니다.`, `You carefully slide one finger into ${name}'s relaxed anus.`],
          [`당신은 ${name}의 뒤쪽에 손을 댄 채 움직입니다. 그녀는 깨어나지 않습니다.`, `You continue moving with a hand against ${name}'s backside. She does not wake.`],
        ],
        anal: [
          [`당신은 ${name}의 엉덩이를 벌리고 항문에 자지를 천천히 밀어 넣습니다.`, `You spread ${name}'s cheeks and slowly push your cock into her anus.`],
          [`당신은 엎드린 ${name}의 허리를 붙잡고 뒤쪽 깊이 움직입니다.`, `You hold the prone ${name}'s hips and move deep inside her ass.`],
          [`당신은 ${name}의 등을 받치고 움직입니다. 그녀의 호흡만 조용히 이어집니다.`, `You support ${name}'s back as you move. Only her quiet breathing continues.`],
        ],
      };
      const pairs = lines[actionId] || [
        [`당신은 ${name}에게 ${label}을(를) 계속합니다.`, `You continue ${label} with ${name}.`],
        [`당신은 ${name}의 몸을 살피며 ${label}을(를) 되풀이합니다.`, `You watch ${name}'s body and repeat ${label}.`],
        [`당신은 같은 속도로 ${name}에게 ${label}을(를) 이어갑니다.`, `You keep the same pace and continue ${label} with ${name}.`],
      ];
      return sceneLine(state, `player:${actionId}`, pairs);
    }

    function patronActionLine(state, participant, order = 0) {
      const name = participant.customerName;
      const pools = {
        bold_touch: [
          [`${name}이(가) 가까이 다가와 손을 뻗습니다. 그녀는 여전히 눈을 감고 있습니다.`, `${name} steps closer and reaches out. She keeps her eyes closed.`],
          [`${name}의 손이 그녀의 옷 위에 머뭅니다. 방 안에서는 그녀의 숨소리만 들립니다.`, `${name}'s hand lingers over her clothes. Only her breathing can be heard in the room.`],
          [`${name}은(는) 그녀가 움직이지 않는 것을 보고 다시 손을 뻗습니다.`, `${name} sees that she has not moved and reaches out again.`],
          [`${name}이(가) 몸을 숙입니다. 그녀의 손은 제자리에 힘없이 놓여 있습니다.`, `${name} bends closer. Her hand lies motionless where it fell.`],
        ],
        groping: [
          [`${name}의 손이 옷자락 안으로 들어갑니다. 그녀에게서는 대답이 없습니다.`, `${name}'s hand slips beneath her clothing. She gives no answer.`],
          [`${name}은(는) 옷을 한쪽으로 밀고 손을 움직입니다. 그녀는 여전히 깨어나지 않습니다.`, `${name} pushes the fabric aside and moves his hand. She still does not wake.`],
          [`${name}의 손길에 옷매무새가 흐트러집니다. 그녀는 자세를 바로잡지 못합니다.`, `${name}'s touch leaves her clothing disordered. She does not straighten it.`],
          [`${name}은(는) 손을 멈췄다가 다시 뻗습니다. 그녀의 호흡만 고르게 이어집니다.`, `${name} pauses, then reaches out again. Her breathing continues evenly.`],
        ],
        intimate: [
          [`${name}은(는) 더 가까이 몸을 붙입니다. 그녀의 손끝이 잠깐 움직였다 멈춥니다.`, `${name} moves closer. Her fingers stir briefly, then fall still.`],
          [`${name}의 손이 옷 안에서 움직입니다. 그녀는 눈을 뜨지 않습니다.`, `${name}'s hand moves beneath her clothing. She does not open her eyes.`],
          [`${name}은(는) 그녀의 반응을 살피며 손길을 이어 갑니다. 대답은 돌아오지 않습니다.`, `${name} watches for a response as he continues. None comes.`],
          [`${name}의 움직임에 그녀의 숨이 한번 어긋납니다. 그 뒤로 방은 다시 조용해집니다.`, `Her breathing catches once at ${name}'s movement. Then the room falls quiet again.`],
        ],
        handjob_patron: [
          [`${name}은(는) 힘없는 그녀의 손을 잡아 움직입니다.`, `${name} takes her limp hand and guides it.`],
          [`${name}이(가) 그녀의 손을 놓자 손가락이 다시 축 늘어집니다.`, `When ${name} releases her hand, her fingers fall loose again.`],
          [`${name}은(는) 그녀의 손목을 받친 채 자기 쪽으로 끌어옵니다. 그녀는 눈을 뜨지 않습니다.`, `${name} supports her wrist and draws her hand toward himself. She does not open her eyes.`],
          [`${name}은(는) 손의 위치를 고쳐 잡습니다. 그녀의 팔에는 힘이 들어가지 않습니다.`, `${name} adjusts his hold on her hand. Her arm offers no movement of its own.`],
        ],
        blowjob_patron: [
          [`${name}은(는) 그녀의 고개를 받칩니다. 그녀는 눈을 감은 채 반응하지 않습니다.`, `${name} supports her head. Her eyes remain closed and she does not respond.`],
          [`${name}이(가) 잠깐 움직임을 멈추지만 그녀에게서는 말이 나오지 않습니다.`, `${name} pauses briefly, but she says nothing.`],
          [`${name}은(는) 그녀의 턱을 받쳐 자세를 바꿉니다. 그녀의 손은 움직이지 않습니다.`, `${name} steadies her jaw and changes position. Her hands do not move.`],
          [`${name}의 거친 숨소리 사이로 그녀의 조용한 호흡이 이어집니다.`, `Her quiet breathing continues beneath the sound of ${name}'s uneven breaths.`],
        ],
        rubbing_patron: [
          [`${name}은(는) 그녀의 다리를 붙잡고 몸을 가까이 댑니다.`, `${name} holds her legs and presses close.`],
          [`${name}의 움직임에 그녀의 자세가 조금 흐트러집니다. 그녀는 바로잡지 않습니다.`, `Her position shifts slightly with ${name}'s movement. She does not correct it.`],
          [`${name}은(는) 다리 사이에 머문 채 움직임을 이어 갑니다. 그녀는 눈을 뜨지 않습니다.`, `${name} remains between her legs and keeps moving. She does not open her eyes.`],
          [`${name}이(가) 잠시 숨을 고릅니다. 그녀의 다리는 힘없이 놓여 있습니다.`, `${name} pauses for breath. Her legs remain limp.`],
        ],
        [PATRON_SELF_STROKE_STAGE]: [
          [`${name}은(는) 그녀에게 닿지 않은 채 곁에 머뭅니다.`, `${name} stays beside her without touching her.`],
          [`${name}은(는) 거리를 두고 혼자 움직입니다. 그녀는 고른 숨을 쉬고 있습니다.`, `${name} keeps his distance and moves alone. Her breathing remains even.`],
          [`${name}이(가) 그녀를 바라보다가 다시 시선을 내립니다. 몸에는 손을 대지 않습니다.`, `${name} looks at her, then lowers his gaze. He does not touch her.`],
          [`${name}의 숨소리가 방 안에 커집니다. 그녀는 여전히 움직이지 않습니다.`, `${name}'s breathing grows louder in the room. She remains still.`],
        ],
        sex_patron: [
          [`${name}은(는) 그녀의 허리를 붙잡고 움직입니다. 그녀의 눈은 감겨 있습니다.`, `${name} holds her waist and moves. Her eyes remain closed.`],
          [`${name}의 움직임에 그녀의 자세가 조금씩 밀립니다. 그녀는 스스로 자세를 바꾸지 않습니다.`, `Her position shifts with ${name}'s movement. She does not change position herself.`],
          [`${name}은(는) 잠깐 멈춰 그녀를 살핍니다. 대답이 없자 다시 움직입니다.`, `${name} pauses to look at her. When she gives no answer, he moves again.`],
          [`${name}의 거친 숨이 이어집니다. 그녀의 손은 제자리에 그대로 놓여 있습니다.`, `${name}'s uneven breathing continues. Her hand stays where it lies.`],
        ],
      };
      const pairs = pools[participant.stage];
      return pairs ? sceneLine(state, `${participant.customerId}:${participant.stage}:${order}`,
        pairs, whole(participant.stepTicks) + order) : '';
    }

    function unconsciousReactionLine(state, wifePleasure, climaxed) {
      const name = characterOf(state)?.name || T('그녀', 'She');
      const normalDepthCap = settings().normalDepthCap;
      const depth = clamp(
        number(dataOf(state).session?.depth) / normalDepthCap * 100,
        0, 100,
      );
      let pleasureKey = 'quiet';
      if (climaxed) {
        pleasureKey = 'climax';
      } else if (wifePleasure >= 80) {
        pleasureKey = 'near';
      } else if (wifePleasure >= 55) {
        pleasureKey = 'high';
      } else if (wifePleasure >= 25) {
        pleasureKey = 'mid';
      }

      const pleasureLines = {
        quiet: [
          [`${name}은(는) 몸에 힘을 뺀 채 축 늘어져 있고`, `${name} remains limp and loose`],
          [`${name}은(는) 손끝 하나 움직이지 않은 채 누워 있고`, `${name} lies without so much as moving a fingertip`],
          [`${name}의 몸은 아무 움직임 없이 무겁게 늘어져 있고`, `${name}'s body remains heavy and still`],
        ],
        mid: [
          [`${name}은(는) 작게 움찔하며 흐트러진 숨을 내쉬고`, `${name} twitches softly and her breathing falters`],
          [`${name}은(는) 희미하게 몸을 떨며 짧은 숨을 흘리고`, `${name} trembles faintly and lets out a short breath`],
          [`${name}의 손끝이 가볍게 떨리고 호흡이 조금 빨라지고`, `${name}'s fingertips quiver as her breathing quickens slightly`],
        ],
        high: [
          [`${name}은(는) 몸을 희미하게 뒤틀며 거친 숨을 몰아쉬고`, `${name} shifts faintly and breathes hard`],
          [`${name}은(는) 무의식적으로 허리를 움직이며 뜨거운 숨을 흘리고`, `${name} moves her hips unconsciously and exhales hot, uneven breaths`],
          [`${name}의 몸은 자극을 따라 천천히 비틀리고 호흡은 거칠어지고`, `${name}'s body slowly twists with the stimulation as her breathing grows rough`],
        ],
        near: [
          [`${name}은(는) 무의식중에도 허리를 떨며 가쁜 숨을 흘리고`, `${name}'s hips tremble and her breath comes fast even while unconscious`],
          [`${name}의 몸은 연달아 떨리고 입술 사이로 가쁜 숨이 새어 나오고`, `${name}'s body trembles repeatedly as quick breaths escape her lips`],
          [`${name}은(는) 절정을 앞둔 듯 몸을 긴장시키며 거칠게 숨 쉬고`, `${name} tenses as if nearing climax and breathes harshly`],
        ],
        climax: [
          [`${name}의 몸은 무의식적으로 크게 떨리고`, `${name}'s body shudders hard in an involuntary climax`],
          [`${name}은(는) 의식 없이도 온몸을 떨며 절정의 경련을 보이고`, `${name} convulses in climax even without regaining consciousness`],
          [`${name}의 허리가 크게 들썩이고 몸은 연달아 경련하고`, `${name}'s hips buck as her body spasms again and again`],
        ],
      };
      const pleasurePair = pleasureLines[pleasureKey][Math.abs(whole(state.slot)) % 3];

      let depthKey = 'deep';
      if (depth <= 0) {
        depthKey = 'awake';
      } else if (depth < 25) {
        depthKey = 'brink';
      } else if (depth < 50) {
        depthKey = 'shallow';
      } else if (depth < 75) {
        depthKey = 'stirring';
      }
      const depthLines = {
        deep: [
          ['눈꺼풀은 움직이지 않은 채 깊은 잠을 이어 갑니다.', 'while her eyelids remain still in deep sleep.'],
          ['고른 숨결은 흐트러지지 않고 깊은 잠은 계속됩니다.', 'while her even breathing continues undisturbed in deep sleep.'],
          ['몸은 무겁게 늘어진 채 잠든 상태를 그대로 유지합니다.', 'while her body remains heavy and deeply asleep.'],
        ],
        stirring: [
          ['미간이 잠깐 움직이지만 여전히 잠에서 벗어나지 못합니다.', 'while her brow briefly tightens without bringing her out of sleep.'],
          ['숨결이 잠시 흔들리지만 눈을 뜨지는 않습니다.', 'while her breathing wavers briefly without her opening her eyes.'],
          ['고개가 조금 움직여도 의식은 여전히 깊이 가라앉아 있습니다.', 'while her head shifts slightly and her consciousness remains submerged.'],
        ],
        shallow: [
          ['잠은 얕아져 눈꺼풀이 가끔 떨리지만 아직 깨지는 않습니다.', 'while her sleep grows shallow and her eyelids flutter without opening.'],
          ['몸이 가끔 움찔하고 호흡도 불규칙해지지만 잠은 이어집니다.', 'while her body twitches and her breathing turns uneven, though she remains asleep.'],
          ['눈꺼풀이 몇 번 떨리고 얼굴에 희미한 긴장이 스치지만 깨어나지는 않습니다.', 'while her eyelids flicker and faint tension crosses her face without waking her.'],
        ],
        brink: [
          ['온몸에 힘이 들어가고 눈꺼풀이 파르르 떨려 금방이라도 깨어날 듯합니다.', 'as her body tenses and her fluttering eyelids make her seem about to wake.'],
          ['호흡이 크게 흐트러지고 손끝이 움직여 잠에서 빠져나오기 직전처럼 보입니다.', 'as her breathing breaks and her fingers move, making her seem close to waking.'],
          ['얼굴을 찡그리고 몸을 뒤척여 조금만 더 자극해도 깨어날 듯합니다.', 'as she grimaces and shifts, looking ready to wake at any further disturbance.'],
        ],
        awake: [
          ['온몸이 크게 움찔하더니 눈을 뜨기 시작합니다.', 'before her whole body jolts and her eyes begin to open.'],
          ['갑자기 몸에 힘이 들어가며 흐릿하게 눈꺼풀을 들어 올립니다.', 'before her body suddenly stiffens and her eyelids begin to lift.'],
          ['거친 숨을 들이켜고 몸을 움직이며 의식을 되찾기 시작합니다.', 'before she draws a sharp breath, moves, and begins to regain consciousness.'],
        ],
      };
      const passedOutDepthLines = {
        deep: [
          ['눈꺼풀은 움직이지 않고 몸은 무겁게 늘어져 있습니다.', 'while her eyelids stay still and her body hangs heavily.'],
          ['고른 숨소리만 들릴 뿐 몸은 움직이지 않습니다.', 'while only her even breathing can be heard.'],
          ['손끝까지 힘이 빠진 채 눈을 뜨지 않습니다.', 'while her hands stay limp and her eyes remain closed.'],
        ],
        stirring: [
          ['미간이 잠깐 찌푸려져도 눈은 뜨지 않습니다.', 'while her brow tightens briefly and her eyes stay closed.'],
          ['숨결이 한 차례 흔들린 뒤 다시 고르게 이어집니다.', 'while her breathing wavers once, then steadies.'],
          ['고개가 조금 움직이지만 다시 축 늘어집니다.', 'while her head shifts slightly, then falls still again.'],
        ],
        shallow: [
          ['눈꺼풀이 떨리고 손끝이 조금 움직입니다.', 'while her eyelids flutter and her fingers move slightly.'],
          ['몸이 가끔 움찔하고 호흡이 불규칙해집니다.', 'while her body twitches and her breathing turns uneven.'],
          ['눈꺼풀이 몇 번 떨리지만 아직 눈을 뜨지 않습니다.', 'while her eyelids flutter several times without opening.'],
        ],
        brink: [
          ['온몸에 힘이 들어가고 눈꺼풀이 파르르 떨립니다.', 'as her body tenses and her eyelids flutter rapidly.'],
          ['호흡이 크게 흐트러지고 손끝이 움직입니다.', 'as her breathing breaks and her fingers move.'],
          ['얼굴을 찡그리며 자세를 고쳐 눕습니다.', 'as she grimaces and shifts her position.'],
        ],
        awake: depthLines.awake,
      };
      const visibleDepthLines = isPassedOut(state) ? passedOutDepthLines : depthLines;
      const depthPair = visibleDepthLines[depthKey][Math.floor(Math.abs(whole(state.slot)) / 3) % 3];
      return T(`${pleasurePair[0]}, ${depthPair[0]}`, `${pleasurePair[1]}, ${depthPair[1]}`);
    }

    function patronFinishLine(state, participant, customer, finishId) {
      const patron = participant.customerName;
      const wife = characterOf(state)?.name || T('그녀', 'her');
      const bold = number(customer?.boldness) > settings().patronRiskyFinishBoldness;
      if (participant.stage === PATRON_SELF_STROKE_STAGE) {
        if (finishId === 'cum_on_breasts') return T(
          `${patron}은(는) 그녀의 드러난 가슴 위에 사정한 뒤 조용히 물러납니다.`,
          `${patron} climaxes across her exposed breasts, then quietly steps away.`,
        );
        if (finishId === 'cum_on_body') return T(
          `${patron}은(는) 그녀의 드러난 몸 위에 사정한 뒤 조용히 물러납니다.`,
          `${patron} climaxes across her exposed body, then quietly steps away.`,
        );
        if (finishId === 'cum_on_face') return T(
          `${patron}은(는) 그녀의 얼굴 위에 사정한 뒤 조용히 물러납니다.`,
          `${patron} climaxes across her face, then quietly steps away.`,
        );
        return T(
          `${patron}은(는) 그녀의 몸에 닿지 않은 채 바닥 쪽으로 사정하고 조용히 정리합니다.`,
          `${patron} climaxes toward the floor without touching her body, then quietly cleans up.`,
        );
      }
      if (finishId === 'cum_in_mouth') return T(
        `${patron}은(는) ${wife}의 입안에 사정한 뒤 물러납니다.`,
        `${patron} climaxes inside ${wife}'s mouth, then steps away.`,
      );
      if (finishId === 'cum_on_face') return T(
        `${patron}은(는) 입에서 빼낸 뒤 ${wife}의 얼굴에 사정하고 물러납니다.`,
        `${patron} pulls out of her mouth, climaxes across ${wife}'s face, then steps away.`,
      );
      if (finishId === 'cum_inside') return participant.slot === 'inside_anal' ? T(
        `${patron}은(는) ${wife}의 항문 안에 사정한 뒤 몸을 빼고 물러납니다.`,
        `${patron} climaxes inside ${wife}'s anus, withdraws, then steps away.`,
      ) : T(
        `${patron}은(는) ${wife}의 안에 사정한 뒤 몸을 빼고 물러납니다.`,
        `${patron} climaxes inside ${wife}, withdraws, then steps away.`,
      );
      if (finishId === 'pull_out') return participant.slot === 'astride' ? T(
        `${wife}의 몸을 들어 올린 ${patron}은(는) 그녀의 허벅지에 사정하고 물러납니다.`,
        `${patron} lifts ${wife} off him, climaxes across her thighs, then steps away.`,
      ) : T(
        `${patron}은(는) 몸을 빼낸 뒤 ${wife}의 등에 사정하고 물러납니다.`,
        `${patron} pulls out, climaxes across ${wife}'s back, then steps away.`,
      );
      if (participant.stage === 'rubbing_patron') return bold ? T(
        `${patron}은(는) 끝까지 넣지 않은 채 ${wife}의 음부와 아랫배 위에 사정하고 물러납니다.`,
        `${patron} never enters her, climaxing across ${wife}'s vulva and lower belly before stepping away.`,
      ) : T(
        `${patron}은(는) 끝까지 넣지 않은 채 ${wife}의 허벅지에 사정하고 물러납니다.`,
        `${patron} never enters her, climaxing across ${wife}'s thigh before stepping away.`,
      );
      return bold ? T(
        `${patron}은(는) ${wife}의 손과 손목에 사정하고 물러납니다.`,
        `${patron} climaxes across ${wife}'s hand and wrist, then steps away.`,
      ) : T(
        `${patron}은(는) ${wife}의 손에 사정하고 물러납니다.`,
        `${patron} climaxes onto ${wife}'s hand, then steps away.`,
      );
    }

    function returnTransferredWife(state) {
      const data = dataOf(state);
      const transfer = data.session?.patronTransfer || data.pendingPatronReturn;
      if (!transfer) return state;
      const currentRoom = api.fn('wifeLocation')(state);
      const leaveInPrivateRoom = transfer.returnRoom === 'taproom';
      const canReturn = !!transfer.returnRoom
        && Array.isArray(state.locations?.[transfer.returnRoom]?.occupants);
      let next = leaveInPrivateRoom || !canReturn || currentRoom === transfer.returnRoom
        ? state : api.fn('moveOccupant')(state, state.primaryCharacterId, transfer.returnRoom);
      const latest = dataOf(next);
      next = writeData(next, {
        ...latest,
        pendingPatronReturn: null,
        session: latest.session ? { ...latest.session, patronTransfer: null } : null,
      });
      if (leaveInPrivateRoom || !canReturn || currentRoom === transfer.returnRoom) return next;
      const wifeName = characterOf(next)?.name || T('그녀', 'She');
      return api.fn('log')(next, T(
        `${wifeName}은(는) 손님이 물러난 뒤 원래 있던 곳으로 돌아옵니다.`,
        `${wifeName} returns to where she had been after the patron withdraws.`,
      ));
    }

    function registerPatronFlowOwner(ownerId, handlers = {}) {
      if (typeof ownerId !== 'string' || !ownerId) {
        throw new TypeError('ownerId must be a non-empty string');
      }
      if (!handlers || typeof handlers !== 'object') {
        throw new TypeError('handlers must be an object');
      }
      patronFlowOwners.set(ownerId, Object.freeze({ ...handlers }));
      return () => patronFlowOwners.delete(ownerId);
    }

    function patronFlowOwner(session) {
      return session?.patronOwnerId ? patronFlowOwners.get(session.patronOwnerId) || null : null;
    }

    function logPatronActionForOwner(state, line, meta) {
      const owner = patronFlowOwner(dataOf(state).session);
      if (typeof owner?.onActionLog !== 'function') return logSleepAction(state, line, meta);
      const replacement = owner.onActionLog(state, Object.freeze({ line }));
      if (replacement === null) return state;
      if (replacement === undefined) return logSleepAction(state, line, meta);
      if (typeof replacement !== 'string' || !replacement.trim()) {
        throw new TypeError('onActionLog must return a non-empty string, null, or undefined');
      }
      return logSleepAction(state, replacement, meta);
    }

    function registerPatronWakeObserver(observerId, listener) {
      if (typeof observerId !== 'string' || !observerId) {
        throw new TypeError('observerId must be a non-empty string');
      }
      if (typeof listener !== 'function') {
        throw new TypeError('listener must be a function');
      }
      const registration = Object.freeze({ observerId, listener });
      patronWakeObservers.set(observerId, registration);
      let active = true;
      return () => {
        if (!active) return false;
        active = false;
        if (patronWakeObservers.get(observerId) !== registration) return false;
        return patronWakeObservers.delete(observerId);
      };
    }

    function registerPatronSearchResolver(resolverId, listener) {
      if (typeof resolverId !== 'string' || !resolverId) {
        throw new TypeError('resolverId must be a non-empty string');
      }
      if (typeof listener !== 'function') {
        throw new TypeError('listener must be a function');
      }
      const registration = Object.freeze({ resolverId, listener });
      patronSearchResolvers.set(resolverId, registration);
      let active = true;
      return () => {
        if (!active) return false;
        active = false;
        if (patronSearchResolvers.get(resolverId) !== registration) return false;
        return patronSearchResolvers.delete(resolverId);
      };
    }

    function returnPatronsToRecordedRooms(state, records) {
      let next = state;
      for (const record of Object.values(records || {})) {
        const customer = (next.customers || []).find(item => item.id === record.customerId);
        if (!customer || customer.status === 'gone' || customer.status === 'leaving') continue;
        const currentRoom = api.fn('patronControlCustomerLocation')(next, customer.id);
        const returnRoom = record.returnRoom || patronRentedRoom(next, customer.id) || 'taproom';
        if (currentRoom !== returnRoom && Array.isArray(next.locations?.[returnRoom]?.occupants)) {
          next = api.fn('moveOccupant')(next, customer.id, returnRoom);
        }
      }
      return next;
    }

    function settlePendingPatronRoomReturns(state) {
      if (!state || state.activeScene?.patron) return state;
      const data = dataOf(state);
      if (!Object.keys(data.pendingPatronRoomReturns).length) return state;
      let next = returnPatronsToRecordedRooms(state, data.pendingPatronRoomReturns);
      const latest = dataOf(next);
      next = writeData(next, { ...latest, pendingPatronRoomReturns: {} });
      return returnTransferredWife(next);
    }

    function clearPatronFlowScene(state, participants) {
      const returnRecords = mergePatronRoomReturns(
        participants,
        dataOf(state).pendingPatronRoomReturns,
      );
      let next = returnPatronsToRecordedRooms(state, returnRecords);
      next = {
        ...next,
        activeScene: { ...(next.activeScene || {}), patron: undefined },
        pendingEvent: next.pendingEvent?.type === 'patron_interaction' ? undefined : next.pendingEvent,
      };
      next = startPatronCooldowns(next, Object.keys(participants || {}), participants);
      const data = dataOf(next);
      next = writeData(next, { ...data, pendingPatronRoomReturns: {} });
      next = api.fn('updateWife')(next, wife => ({
        ...wife,
        sceneOverride: undefined,
        sceneVariant: undefined,
        sceneSetAtSlot: undefined,
      }));
      return returnTransferredWife(next);
    }

    function baseSleepPatronContext(state) {
      const data = dataOf(state);
      const interaction = state?.activeScene?.patron;
      const owner = patronFlowOwner(data.session);
      if (data.session?.kind !== 'patron'
        || (data.session.patronOwnerId != null
          && typeof owner?.onPlayerIntervention !== 'function')
        || data.session.characterId !== state?.primaryCharacterId
        || !interaction?.sleepActionsStage
        || !isUnconscious(state, data.session.characterId)) return null;
      const customer = (state.customers || []).find(item => item.id === interaction.customerId);
      const room = api.fn('wifeLocation')(state);
      if (!customer || !room) return null;
      return { data, session: data.session, interaction, customer, room };
    }

    function settlePatronInterventionOwner(state, context, mode) {
      const handler = patronFlowOwner(context.session)?.onPlayerIntervention;
      if (typeof handler !== 'function') return state;
      const result = handler(state, Object.freeze({
        mode,
        sourceSession: context.session,
        interaction: context.interaction,
        customer: context.customer,
        participants: Object.freeze({ ...context.session.patronParticipants }),
      }));
      if (result == null) return state;
      if (!result.characters || !result.locations) {
        throw new TypeError('onPlayerIntervention must return a game state, null, or undefined');
      }
      return result;
    }

    function patronDoorMatches(state, door = dataOf(state).patronDoor) {
      const context = baseSleepPatronContext(state);
      return !!door && !!context
        && context.customer.id === door.customerId
        && context.room === door.room
        && api.fn('playerLocation')(state) === door.room;
    }

    function writePatronDoor(state, patronDoor) {
      const data = dataOf(state);
      return writeData(state, { ...data, patronDoor });
    }

    function leavePatronDoor(state) {
      const door = dataOf(state).patronDoor;
      if (!door) return state;
      let next = state;
      if (door.returnRoom && door.returnRoom !== door.room
        && api.fn('playerLocation')(next) === door.room
        && Array.isArray(next.locations?.[door.returnRoom]?.occupants)) {
        next = api.fn('moveOccupant')(next, 'player', door.returnRoom);
      }
      next = writePatronDoor(next, null);
      return api.fn('log')(next, T(
        '당신은 문에서 물러나 원래 있던 곳으로 돌아갑니다.',
        'You step away from the door and return to where you were.',
      ));
    }

    function reconcilePatronDoor(state) {
      const door = dataOf(state).patronDoor;
      if (!door) return state;
      if (api.fn('playerLocation')(state) !== door.room) return writePatronDoor(state, null);
      if (patronDoorMatches(state, door)) return state;
      return leavePatronDoor(state);
    }

    function playerPatronSceneSide(state, context = baseSleepPatronContext(state)) {
      if (!context) return null;
      const door = context.data.patronDoor;
      if (door?.customerId === context.customer.id && door.room === context.room
        && api.fn('playerLocation')(state) === context.room) return door.side;
      if (api.fn('playerLocation')(state) !== context.room) return null;
      return api.fn('roomSideForOccupant')(state, context.room, 'player') === 'outside'
        ? 'outside' : 'inside';
    }

    function insideBaseSleepPatronContext(state) {
      const context = baseSleepPatronContext(state);
      return context && playerPatronSceneSide(state, context) === 'inside' ? context : null;
    }

    function approachBasePatronDoor(state, requestedRoom = null) {
      const context = baseSleepPatronContext(state);
      if (!context || (requestedRoom && requestedRoom !== context.room)) return state;
      const existing = context.data.patronDoor;
      if (existing?.customerId === context.customer.id && existing.room === context.room) return state;
      const playerRoom = api.fn('playerLocation')(state);
      const returnRoom = playerRoom === context.room
        ? (Array.isArray(state.locations?.taproom?.occupants) ? 'taproom' : null)
        : playerRoom;
      const approached = api.fn('approachClosedDoor')(state, context.room);
      if (!approached?.state || approached.caught) return approached?.state || state;
      let next = writePatronDoor(approached.state, {
        customerId: context.customer.id,
        room: context.room,
        side: 'outside',
        returnRoom,
      });
      const wifeName = characterOf(next)?.name || T('그녀', 'her');
      return api.fn('log')(next, T(
        `당신은 수상한 기척을 따라 ${wifeName}이(가) 있는 방 문 앞까지 다가갑니다.`,
        `You follow the suspicious sounds to the door of the room where ${wifeName} is sleeping.`,
      ));
    }

    function currentPrimaryPatronActionLine(state, slotOffset = 0) {
      const context = baseSleepPatronContext(state);
      if (!context) return '';
      const primaryId = context.session.patronPrimaryId || context.interaction.customerId;
      const participant = context.session.patronParticipants?.[primaryId]
        || context.session.patronParticipants?.[context.interaction.customerId];
      return participant ? patronActionLine(
        { ...state, slot: whole(state.slot) + slotOffset },
        { ...participant, stepTicks: whole(participant.stepTicks) + slotOffset },
      ) : '';
    }

    function rewritePatronDoorTickLog(before, after, actionLine, prefix = null) {
      if (!actionLine) return { state: after, merged: false };
      const key = Array.isArray(before?.log) && Array.isArray(after?.log)
        ? 'log' : Array.isArray(before?.logs) && Array.isArray(after?.logs) ? 'logs' : null;
      if (!key) return { state: after, merged: false };
      const entries = [...after[key]];
      const start = before[key].length;
      const index = entries.findIndex((entry, entryIndex) => entryIndex >= start
        && (typeof entry === 'string' ? entry : entry?.text || '').includes(actionLine));
      if (index < 0) return { state: after, merged: false };
      if (prefix == null) entries.splice(index, 1);
      else if (typeof entries[index] === 'string') entries[index] = `${prefix} ${entries[index]}`;
      else entries[index] = { ...entries[index], text: `${prefix} ${entries[index].text}` };
      return { state: { ...after, [key]: entries }, merged: true };
    }

    function replaceFirstAddedLog(before, after, line) {
      const key = Array.isArray(before?.log) && Array.isArray(after?.log)
        ? 'log' : Array.isArray(before?.logs) && Array.isArray(after?.logs) ? 'logs' : null;
      if (!key) return api.fn('log')(after, line);
      const index = before[key].length;
      if (after[key].length <= index) return api.fn('log')(after, line);
      const entries = [...after[key]];
      entries[index] = typeof entries[index] === 'string'
        ? line : { ...entries[index], text: line };
      return { ...after, [key]: entries };
    }

    function basePatronBackRoomEntryLine(state, context = baseSleepPatronContext(state)) {
      if (!context) return '';
      const wifeName = characterOf(state)?.name || T('그녀', 'She');
      const actionLine = currentPrimaryPatronActionLine(state);
      const condition = unconsciousStateOf(state) === 'passed_out'
        ? T(`${wifeName}은(는) 소파에 의식을 잃은 채 늘어져 있습니다.`, `${wifeName} lies unconscious on the couch.`)
        : T(`${wifeName}은(는) 소파에서 깊이 잠들어 있습니다.`, `${wifeName} is deeply asleep on the couch.`);
      const activity = actionLine || T(
        `${context.customer.name}은(는) 그 곁에 머물러 있습니다.`,
        `${context.customer.name} remains beside her.`,
      );
      return T(
        `당신은 뒷방으로 들어갑니다. ${condition} ${activity}`,
        `You step into the back room. ${condition} ${activity}`,
      );
    }

    function patronDoorStateLine(state, kind) {
      const wifeName = characterOf(state)?.name || T('그녀', 'She');
      const door = dataOf(state).patronDoor;
      const place = door?.room || api.fn('wifeLocation')(state);
      const unconscious = unconsciousStateOf(state);
      if (kind === 'knock') {
        if (unconscious === 'passed_out') return T(
          `당신은 ${wifeName}이(가) 있는 방 문을 조용히 두드립니다. 아무런 반응이 없습니다.`,
          `You knock softly on the door of the room where ${wifeName} lies. There is no response.`,
        );
        if (unconscious === 'sleeping') return T(
          `당신은 ${wifeName}이(가) 있는 방 문을 조용히 두드립니다. 대답이 없습니다. ${wifeName}은(는) 잠들어 있습니다.`,
          `You knock softly on the door of the room where ${wifeName} sleeps. There is no answer. ${wifeName} remains asleep.`,
        );
        return T(`문 너머에서 깨어난 ${wifeName}의 움직임이 들립니다.`, `You hear the awakened ${wifeName} moving beyond the door.`);
      }
      if (unconscious === 'passed_out') return T(
        `당신은 문틈으로 안을 들여다봅니다. ${wifeName}은(는) 의식이 없는 듯합니다.`,
        `You peer through the gap. ${wifeName} appears to be unconscious.`,
      );
      if (unconscious === 'sleeping') return T(
        `당신은 문틈으로 안을 들여다봅니다. ${wifeName}은(는) 잠들어 있습니다.`,
        `You peer through the gap. ${wifeName} is asleep.`,
      );
      return T(`당신은 문틈으로 안을 들여다봅니다. ${wifeName}은(는) 깨어 있습니다.`, `You peer through the gap. ${wifeName} is awake.`);
    }

    function performBasePatronDoorCheck(state, kind, requestedRoom = null) {
      let prepared = approachBasePatronDoor(state, requestedRoom);
      const context = baseSleepPatronContext(prepared);
      const door = dataOf(prepared).patronDoor;
      if (!context || !door || door.side !== 'outside') return prepared;
      const expectedActionLine = currentPrimaryPatronActionLine(prepared, 1);
      const advanced = api.fn('tick')(prepared);
      const prefix = patronDoorStateLine(advanced, kind);
      const rewritten = rewritePatronDoorTickLog(
        prepared, advanced, expectedActionLine, kind === 'peek' ? prefix : null,
      );
      let next = rewritten.state;
      if (kind === 'knock') next = api.fn('log')(next, prefix);
      else if (!rewritten.merged) {
        next = api.fn('log')(next, expectedActionLine ? `${prefix} ${expectedActionLine}` : prefix);
      }
      return reconcilePatronDoor(next);
    }

    function enterBasePatronDoor(state, requestedRoom = null) {
      let next = approachBasePatronDoor(state, requestedRoom);
      const context = baseSleepPatronContext(next);
      const door = dataOf(next).patronDoor;
      if (!context || !door || door.side !== 'outside') return next;
      next = writePatronDoor(next, { ...door, side: 'inside' });
      return api.fn('log')(next, T(
        `당신은 조용히 문을 열고 방 안으로 들어갑니다. ${context.customer.name}은(는) 그녀 곁에 있습니다.`,
        `You quietly open the door and step into the room. ${context.customer.name} is beside her.`,
      ));
    }

    function requestOpenBasePatronDoor(state, requestedRoom = null) {
      const prepared = approachBasePatronDoor(state, requestedRoom);
      const context = baseSleepPatronContext(prepared);
      const door = dataOf(prepared).patronDoor;
      if (!context || !door || door.side !== 'outside') return prepared;
      return api.fn('reduceGameAction')(prepared, {
        type: 'open_the_door',
        room: context.room,
      });
    }

    function quietSeparatePatron(state) {
      const context = insideBaseSleepPatronContext(state);
      if (!context) return state;
      const participants = patronRoomReturnsFromSession(context.session, context.interaction);
      let next = api.fn('log')(state, T(
        `당신은 그녀를 건드리지 않고 ${context.customer.name}에게 다가가 조용히 떼어 놓습니다.`,
        `Without touching her, you approach ${context.customer.name} and quietly separate him from her.`,
      ));
      next = clearPatronFlowScene(next, participants);
      const latest = dataOf(next);
      next = writeData(next, {
        ...latest,
        patronDoor: null,
        session: latest.session ? {
          ...latest.session,
          kind: 'player',
          patronPrimaryId: null,
          patronOwnerId: null,
          patronApproach: null,
          patronParticipants: {},
          patronTransfer: null,
        } : null,
      });
      next = settlePatronInterventionOwner(next, context, 'quiet');
      return api.fn('tick')(next);
    }

    function adjustedWakeAcceptance(evaluation) {
      const config = settings();
      const adjusted = {
        ...(evaluation || {}),
        score: number(evaluation?.score, Number.NEGATIVE_INFINITY) - config.patronWakeAcceptancePenalty,
      };
      return { raw: evaluation, adjusted, decision: sleepWakeDecision(adjusted) };
    }

    function adjustedExplanationBelief(evaluation) {
      const config = settings();
      const score = number(evaluation?.score, Number.NEGATIVE_INFINITY)
        + config.patronExplanationBeliefBonus;
      const threshold = number(evaluation?.threshold, Number.POSITIVE_INFINITY);
      const believed = score >= threshold;
      return {
        raw: evaluation,
        adjusted: { ...(evaluation || {}), score },
        decision: {
          believed,
          eager: believed && score >= threshold + config.patronExplanationEagerMargin,
          emphatic: !believed && threshold - score >= config.patronExplanationEmphaticMargin,
          score,
          threshold,
          outcome: believed && score >= threshold + config.patronExplanationEagerMargin ? 'eager'
            : believed ? 'hesitant'
            : evaluation?.outcome === 'offended' ? 'offended' : 'refuse',
        },
      };
    }

    function normalizeAwakeAvailability(state) {
      return api.fn('updateWife')(state, wife => ({
        ...wife,
        currentTask: 'idle',
        taskTarget: undefined,
        busyUntilSlot: whole(state.slot),
        locationUntilSlot: undefined,
        retiredAtSlot: undefined,
      }));
    }

    function finishPlayerWakeIntervention(state, mode, line) {
      const arousal = number(characterOf(state)?.stats?.arousal);
      const comfort = number(state.activeScene?.patron?.elenaComfort, 50);
      let next = clearPatronFlowScene({ ...state, pendingEvent: undefined }, {});
      next = normalizeAwakeAvailability(next);
      if (mode === 'welcomed') {
        next = api.fn('applyEffects')(next, {
          targetCharacterId: next.primaryCharacterId,
          playerStatDeltas: {}, wifeStatDeltas: {}, wifeTraitDeltas: {},
          trustDelta: 2, resentDelta: 0,
        });
      } else if (mode === 'reluctant') {
        next = api.fn('applyEffects')(next, {
          targetCharacterId: next.primaryCharacterId,
          playerStatDeltas: {}, wifeStatDeltas: { mood: -2 }, wifeTraitDeltas: {},
          trustDelta: -1, resentDelta: 0,
        });
      } else if (mode === 'forced') {
        next = api.fn('addFeeling')(next, 'anger', {
          intensity: 35 + comfort * 0.35,
          source: 'forced-interrupt-of-patron',
          target: { kind: 'husband' },
        });
        next = api.fn('applyEffects')(next, {
          targetCharacterId: next.primaryCharacterId,
          playerStatDeltas: { mood: -3 },
          wifeStatDeltas: { mood: -8, arousal: -arousal },
          wifeTraitDeltas: {}, trustDelta: -4,
        });
      }
      const responseType = mode === 'welcomed' ? 'hesitant'
        : mode === 'forced' ? 'angry' : 'neutral';
      next = api.fn('updateWife')(next, wife => ({
        ...wife, lastResponse: line, lastResponseType: responseType, lastResponseSlot: whole(next.slot),
      }));
      next = api.fn('log')(next, line);
      const data = dataOf(next);
      return writeData(next, { ...data, patronDoor: null, pendingInterventionReturn: null });
    }

    function interventionExplanationLine(state, customer) {
      const wifeName = characterOf(state)?.name || T('그녀', 'She');
      const conditionKo = isPassedOut(state) ? '정신을 잃고' : '잠들어';
      const conditionEn = isPassedOut(state) ? 'unconscious' : 'asleep';
      const enteredThroughDoor = dataOf(state).patronDoor?.side === 'inside';
      const route = enteredThroughDoor ? 'door' : 'same-room';
      const lines = enteredThroughDoor ? [
        [`당신은 ${wifeName}에게 말합니다. "문밖에서 수상한 기척이 들려 들어왔어. ${customer.name}이(가) 네 몸에 손을 대고 있는 걸 보고 널 깨운 거야."`, `You tell ${wifeName}, "I heard something suspicious outside the door and came in. I saw ${customer.name} touching you, so I woke you."`],
        [`당신은 손을 거두고 ${wifeName}이(가) 당신을 볼 때까지 기다립니다. "문밖에서 이상한 소리가 들렸어. 문을 열어 보니 네가 ${conditionKo} 있었고, ${customer.name}이(가) 네 몸에 손을 대고 있었어. 그래서 널 깨웠어."`, `You take your hands away and wait for ${wifeName} to look at you. "I heard a strange sound outside the door. When I opened it, you were ${conditionEn}, and ${customer.name} was touching you. That's why I woke you."`],
      ] : [
        [`당신은 ${wifeName}에게 말합니다. "눈을 떠 보니 ${customer.name}이(가) 네 몸에 손을 대고 있었어. 그냥 둘 수 없어서 널 깨운 거야."`, `You tell ${wifeName}, "When I opened my eyes, ${customer.name} was touching you. I couldn't leave it alone, so I woke you."`],
        [`당신은 손을 거두고 ${wifeName}이(가) 당신을 볼 때까지 기다립니다. "방 안의 기척에 눈을 떴어. ${customer.name}이(가) 네 몸에 손을 대고 있어서 널 깨운 거야."`, `You take your hands away and wait for ${wifeName} to look at you. "The movement in the room woke me. ${customer.name} was touching you, so I woke you."`],
      ];
      return sceneLine(state, `intervention:explain:${customer.id}:${route}:${conditionKo}`, lines);
    }

    function interventionResultLine(state, customer, currentAccepted, explanationBelieved) {
      const wifeName = characterOf(state)?.name || T('그녀', 'She');
      const key = !currentAccepted && explanationBelieved ? 'refused-believed'
        : currentAccepted && explanationBelieved ? 'accepted-believed' : 'unbelieved';
      const pools = {
        'refused-believed': [
          [`${wifeName}은(는) ${customer.name}을(를) 밀어내고 당신 쪽으로 물러섭니다. "알겠어. 저 사람을 내보내 줘."`, `${wifeName} pushes ${customer.name} away and steps toward you. "All right. Get him out of here."`],
          [`${wifeName}은(는) ${customer.name}에게서 떨어져 당신 뒤로 옵니다. "저 사람을 내보내 줘. 더는 가까이 있고 싶지 않아."`, `${wifeName} pulls away from ${customer.name} and comes behind you. "Make him leave. I don't want him near me anymore."`],
        ],
        'accepted-believed': [
          [`${wifeName}은(는) ${customer.name}을(를) 돌아보다가 손을 떼고 물러섭니다. "잠깐… 네 말이 맞다면 여기서 그만할게."`, `${wifeName} looks back at ${customer.name}, then pulls away. "Wait… If you're right, I'll stop here."`],
          [`${wifeName}은(는) 두 사람을 번갈아 보다가 ${customer.name}에게서 떨어집니다. "무슨 일이었는지는 알겠어. 지금은 여기서 멈출게."`, `${wifeName} looks between you, then moves away from ${customer.name}. "I understand what happened. I'll stop here for now."`],
        ],
        unbelieved: [
          [`${wifeName}은(는) ${customer.name}에게서 몸을 빼내고 두 사람을 번갈아 봅니다. "그만해. 방금 한 설명도 아직은 믿기 어려워."`, `${wifeName} pulls away from ${customer.name} and looks between the two of you. "Stop. I still can't believe the explanation you just gave me."`],
          [`${wifeName}은(는) 한 걸음 물러나 두 사람과 거리를 둡니다. "둘 다 멈춰. 지금은 어느 쪽 말도 못 믿겠어."`, `${wifeName} steps back from both of you. "Both of you stop. I can't trust either of you right now."`],
        ],
      };
      return sceneLine(state, `intervention:result:${customer.id}:${key}`, pools[key]);
    }

    function requiredInterventionInfluence(explanation) {
      const config = settings();
      return clamp(
        (number(explanation?.decision?.threshold) + config.patronInterventionInfluenceMargin
          - number(explanation?.decision?.score))
          / Math.max(Number.EPSILON, config.patronInterventionInfluenceScale),
        0, 1,
      );
    }

    function startPlayerWakeIntervention(state) {
      const context = insideBaseSleepPatronContext(state);
      if (!context) return state;
      const sourceSession = context.session;
      const participantReturns = patronRoomReturnsFromSession(sourceSession, context.interaction);
      let next = discardCurrentMorningIncident(state, 'patron', sourceSession);
      next = endSession(next, 'player-woke-to-intervene');
      next = wakeUnconsciousCharacter(next);
      next = startPatronCooldowns(next, Object.keys(participantReturns), sourceSession.patronParticipants);
      next = settlePatronInterventionOwner(next, context, 'wake');
      const action = patronStageAction(
        context.interaction.sleepActionsStage || context.interaction.stage,
        context.interaction.sleepActionsActionId,
      );
      if (!action) return finishPlayerWakeIntervention(next, 'neutral', T(
         `${characterOf(next)?.name || T('그녀', 'She')}은(는) 눈을 뜨고, ${context.customer.name}은(는) 황급히 물러납니다.`,
         `${characterOf(next)?.name || T('She', 'She')} opens her eyes, and ${context.customer.name} hurriedly backs away.`,
      ));
      const current = adjustedWakeAcceptance(api.fn('evaluateIntimacy')(
        next, action.actionId, patronIntimacyContext(next, context.customer, context.interaction),
      ));
      const explanation = adjustedExplanationBelief(api.fn('evaluateIntimacy')(
        next, 'interrupt_patron', { kind: 'player_interrupt' },
      ));
      next = applyPatronWakeFeelings(
        next, action, current.decision, context.customer,
      );
      next = api.fn('log')(next, interventionExplanationLine(state, context.customer));
      if (!current.decision.accepted || explanation.decision.believed) {
        const line = interventionResultLine(
          next, context.customer, current.decision.accepted, explanation.decision.believed,
        );
        return finishPlayerWakeIntervention(
          next, explanation.decision.believed ? 'welcomed' : 'neutral', line,
        );
      }
      const requiredInfluence = requiredInterventionInfluence(explanation);
      const actualInfluence = clamp(number(api.fn('relationshipInfluence')(next)), 0, 1);
      if (actualInfluence >= requiredInfluence) return finishPlayerWakeIntervention(next, 'reluctant', T(
         `당신이 물러서지 않자 그녀는 ${context.customer.name}에게서 떨어집니다. "네 말은 못 믿겠어. 그래도 여기서 그만할게."`,
         `When you stand your ground, she steps away from ${context.customer.name}. "I don't believe you. But I'll stop here."`,
      ));
      const wifeName = characterOf(next)?.name || T('그녀', 'She');
      return {
        ...next,
        pendingEvent: {
          type: 'sleep_actions_patron_intervention_refused',
          text: T(
             `${wifeName}은(는) ${context.customer.name}의 곁에 남아 당신을 바라봅니다. "난 괜찮아. 내 일은 내가 결정할게."`,
             `${wifeName} stays beside ${context.customer.name} and looks at you. "I'm all right. I'll decide for myself."`,
          ),
          choices: [
            { id: 'back_off', label: T('두 사람을 두고 나가기', 'Leave them alone') },
            { id: 'force', label: T('억지로 떼어놓기', 'Pull them apart by force') },
          ],
          customerId: context.customer.id,
          customerName: context.customer.name,
          currentRawScore: number(current.raw?.score),
          currentEffectiveScore: current.decision.score,
          currentThreshold: current.decision.threshold,
          explanationRawScore: number(explanation.raw?.score),
          explanationEffectiveScore: explanation.decision.score,
          explanationThreshold: explanation.decision.threshold,
          requiredInfluence,
          actualInfluence,
          sleepActionsPatronInterventionRefused: true,
        },
      };
    }

    function handOffAwakePatronScene(state) {
      const customerName = state.pendingEvent?.customerName || state.activeScene?.patron?.customerName;
      let next = { ...state, pendingEvent: undefined };
      const data = dataOf(next);
      next = writeData(next, {
        ...data,
        patronDoor: null,
        pendingInterventionReturn: { customerId: state.pendingEvent?.customerId || state.activeScene?.patron?.customerId },
      });
      next = api.fn('updateWife')(next, wife => ({
        ...wife,
        lastResponse: T(
          `당신은 더 개입하지 않습니다. 그녀는 굳은 표정으로 당신을 바라본 뒤 ${customerName}에게 다시 몸을 돌립니다.`,
          `You stop intervening. She gives you a tense look, then turns back toward ${customerName}.`,
        ),
        lastResponseType: 'neutral',
        lastResponseSlot: whole(next.slot),
      }));
      next = api.fn('log')(next, characterOf(next).lastResponse);
      next = {
        ...next,
        activeScene: {
          ...next.activeScene,
          patron: { ...next.activeScene.patron, ticksAtStage: -1 },
        },
      };
      return api.fn('processPatronInteractionTick')(next);
    }

    function resolvePlayerInterventionChoice(state, choiceId) {
      const event = state.pendingEvent;
      if (!event?.sleepActionsPatronInterventionRefused) return state;
      if (choiceId === 'back_off') return handOffAwakePatronScene(state);
      if (choiceId === 'force') return finishPlayerWakeIntervention(state, 'forced', T(
        `당신은 그녀의 뜻을 더 묻지 않고 ${event.customerName}을(를) 억지로 떼어 놓습니다. 그녀는 굳은 얼굴로 당신의 손을 뿌리칩니다.`,
        `Without asking her wishes again, you forcibly pull ${event.customerName} away. She knocks your hand aside with a hard expression.`,
      ));
      return state;
    }

    function finalizePendingInterventionReturn(state) {
      const data = dataOf(state);
      if (!data.pendingInterventionReturn) return state;
      if (isUnconscious(state, state.primaryCharacterId)) {
        return writeData(state, { ...data, pendingInterventionReturn: null, patronDoor: null });
      }
      if (state.activeScene?.patron) return state;
      let next = settlePendingPatronRoomReturns(state);
      next = normalizeAwakeAvailability(next);
      const latest = dataOf(next);
      return writeData(next, { ...latest, pendingInterventionReturn: null, patronDoor: null });
    }

    function wakeUnconsciousCharacter(state) {
      const passedOut = isPassedOut(state);
      let next = api.fn('updateWife')(state, wife => ({
        ...wife,
        currentTask: 'idle',
        busyUntilSlot: whole(state.slot),
        retiredAtSlot: passedOut ? wife.retiredAtSlot : whole(state.slot),
        wakeSlot: undefined,
        passedOutAtSlot: passedOut ? undefined : wife.passedOutAtSlot,
        passedOutAcknowledged: passedOut ? undefined : wife.passedOutAcknowledged,
        intoxication: passedOut && wife.intoxication ? {
          ...wife.intoxication,
          level: Math.min(94, number(wife.intoxication.level)),
        } : wife.intoxication,
      }));
      return next;
    }

    function sleepWakeDecision(evaluation) {
      const score = number(evaluation?.score, Number.NEGATIVE_INFINITY);
      const threshold = number(evaluation?.threshold, Number.POSITIVE_INFINITY);
      const outcome = evaluation?.outcome;
      const blocked = outcome === 'refuse' || outcome === 'offended';
      const accepted = !blocked && score >= threshold;
      const deficit = Math.max(0, threshold - score);
      return {
        accepted,
        emphatic: outcome === 'offended' || deficit >= 20,
        eager: accepted && (outcome === 'eager' || score - threshold >= 15),
        score,
        threshold,
        outcome,
      };
    }

    function sleepWakeResponseType(decision) {
      if (decision.accepted) return decision.eager ? 'eager' : 'hesitant';
      return decision.emphatic ? 'angry' : 'refuse';
    }

    function patronWakeActionSeverity(action) {
      const actionClass = action?.noContact ? 'light_touch' : actionClassOf(action?.actionId);
      return actionClass === 'rubbing' || actionClass === 'sex' ? 4
        : playerWakeSeverity({ actionClass });
    }

    function applyPatronWakeFeelings(state, action, decision, customer) {
      const severity = patronWakeActionSeverity(action);
      const customerName = customer?.name || T('그 손님', 'the patron');
      const lastNameCharacter = [...customerName.trim()].at(-1) || '';
      const lastCodePoint = lastNameCharacter.codePointAt(0) || 0;
      const koreanSource = lastCodePoint >= 0xAC00 && lastCodePoint <= 0xD7A3
        ? `잠든 사이 ${customerName}${(lastCodePoint - 0xAC00) % 28 ? '이' : '가'} 한 일`
        : `잠든 사이 ${customerName}의 행동`;
      const source = `__raw__${T(
        koreanSource,
        `what ${customerName} did while she slept`,
      )}`;
      const feelings = decision.accepted
        ? decision.eager ? [['desire', 20 + 3 * severity]]
          : [['shame', 20 + 3 * severity]]
        : decision.emphatic
          ? [['shame', 25 + 3 * severity],
            [decision.outcome === 'offended' ? 'disgust' : 'anger', 30 + 5 * severity]]
          : [['shame', 30 + 4 * severity]];
      let next = state;
      for (const [emotion, intensity] of feelings) {
        next = api.fn('addFeeling')(next, emotion, {
          intensity, source, durationSlots: 200,
        });
      }
      return next;
    }

    function returnRefusedWakeToTaproom(state) {
      let next = state;
      const wasAway = api.fn('wifeLocation')(next) !== 'taproom';
      if (wasAway && Array.isArray(next.locations?.taproom?.occupants)) {
        next = api.fn('moveWife')(next, 'taproom');
      }
      next = api.fn('updateWife')(next, wife => ({
        ...wife,
        currentTask: 'idle',
        taskTarget: undefined,
        busyUntilSlot: whole(next.slot),
        locationUntilSlot: undefined,
        retiredAtSlot: undefined,
      }));
      if (!wasAway || api.fn('wifeLocation')(next) !== 'taproom') return next;
      const wifeName = characterOf(next)?.name || T('그녀', 'She');
      return api.fn('log')(next, T(
        `${wifeName}은(는) 그에게서 떨어진 뒤 홀로 돌아갑니다.`,
        `${wifeName} pulls away from him and returns to the taproom.`,
      ));
    }

    function sleepWakeResponse(state, customer, decision, participants, options = {}) {
      const wife = characterOf(state);
      const wifeName = wife?.name || T('그녀', 'She');
      let line;
      if (decision.accepted) {
        line = decision.eager
          ? T(
            `${wifeName}은(는) 눈을 뜨고 몸에 닿은 ${customer.name}의 손을 내려다봅니다. 놀라 숨을 고른 뒤 그의 손목을 잡고 계속해도 된다고 말합니다.`,
            `${wifeName} opens her eyes and looks down at ${customer.name}'s hand on her body. After catching her breath, she takes his wrist and tells him he may continue.`,
          )
          : T(
            `${wifeName}은(는) 눈을 뜨고 ${customer.name}을(를) 한동안 바라봅니다. 이윽고 작게 고개를 끄덕이며 계속해도 되지만 서두르지 말라고 합니다.`,
            `${wifeName} opens her eyes and studies ${customer.name} for a long moment. At last, she gives a small nod and says he may continue, but should not rush.`,
          );
      } else {
        line = decision.emphatic
          ? T(
            `${wifeName}은 눈을 뜨자마자 몸을 거칠게 빼내며 그만하라고 쏘아붙입니다. ${customer.name}은 손을 떼고 황급히 거리를 둡니다.`,
            `${wifeName} jerks away the instant she opens her eyes and sharply tells him to stop. ${customer.name} takes his hands off her and hurriedly backs away.`,
          )
          : T(
            `${wifeName}은 눈을 뜨고 몸에 닿은 손을 밀어냅니다. ${customer.name}은 더 이어 가지 않고 물러납니다.`,
            `${wifeName} opens her eyes and pushes the hand away from her body. ${customer.name} stops instead of continuing and steps back.`,
          );
      }
      let next = api.fn('updateWife')(state, current => ({
        ...current,
        lastResponse: line,
        lastResponseSlot: whole(state.slot),
        lastResponseType: sleepWakeResponseType(decision),
      }));
      next = api.fn('log')(next, line);
      if (decision.accepted) return next;
      next = clearPatronFlowScene(next, participants);
      return options.returnToTaproom === true ? returnRefusedWakeToTaproom(next) : next;
    }

    function resolvePatronWake(state, reason, participants, options = {}) {
      const sourceSession = dataOf(state).session;
      const owner = patronFlowOwner(sourceSession);
      const interaction = state.activeScene?.patron;
      const customer = interaction
        ? state.customers?.find(item => item.id === interaction.customerId)
        : null;
      const action = patronStageAction(
        interaction?.sleepActionsStage || interaction?.stage,
        interaction?.sleepActionsActionId,
      );
      let next = discardCurrentMorningIncident(state, 'patron', sourceSession);
      if (options.alreadyAwake !== true) next = wakeUnconsciousCharacter(next);
      next = endSession(next, reason);
      next = startPatronCooldowns(next, Object.keys(participants || {}), participants);
      if (!interaction || !customer || !action) return clearPatronFlowScene(next, participants);

      const evaluation = api.fn('evaluateIntimacy')(
        next,
        action.actionId,
        patronIntimacyContext(next, customer, interaction),
      );
      const decision = sleepWakeDecision(evaluation);
      const wakeContext = Object.freeze({
        reason, participants: { ...(participants || {}) }, sourceSession,
        interaction, customer, action, evaluation, decision,
      });
      if (reason === 'depth-depleted') next = applyPatronWakeFeelings(
        next, action, decision, customer,
      );
      if (typeof owner?.onWake === 'function') {
        const handled = owner.onWake(next, wakeContext);
        if (handled) return handled;
      }
      for (const registration of [...patronWakeObservers.values()]) {
        const handled = registration.listener(next, wakeContext);
        if (handled == null) continue;
        if (typeof handled !== 'object') {
          throw new TypeError('wake observer must return a state object, null, or undefined');
        }
        return handled;
      }
      next = sleepWakeResponse(next, customer, decision, participants, {
        returnToTaproom: reason === 'depth-depleted',
      });
      if (!decision.accepted) return next;

      next = {
        ...next,
        activeScene: {
          ...next.activeScene,
          patron: {
            ...next.activeScene.patron,
            ...(action.actionId === 'watch_him' ? { watchedHimStroke: true } : {}),
            // The original tick increments first. Start at -1 so this handoff tick reacts
            // at dwell 0 and cannot immediately run a second escalation acceptance check.
            ticksAtStage: -1,
          },
        },
      };
      return api.fn('processPatronInteractionTick')(next);
    }

    function finishPassedOutPatronFlow(state, reason, wake = false) {
      const data = dataOf(state);
      const participants = data.session?.patronParticipants || {};
      if (wake) return resolvePatronWake(state, reason, participants);
      const owner = patronFlowOwner(data.session);
      if (typeof owner?.onFinish === 'function') {
        const handled = owner.onFinish(state, Object.freeze({
          reason, participants: { ...participants }, sourceSession: data.session,
        }));
        if (handled) return handled;
      }
      let next = clearPatronFlowScene(state, participants);
      if (!isUnconscious(next, data.session?.characterId)) return endSession(next, reason);
      const latestData = dataOf(next);
      return writeData(next, {
        ...latestData,
        session: {
          ...latestData.session,
          patronPrimaryId: null,
          patronOwnerId: null,
          patronParticipants: {},
        },
      });
    }

    function rotatePatronPrimary(state, participants) {
      const remaining = Object.values(participants).filter(participant => !participant.completed)
        .sort((left, right) => number(PATRON_STAGE_INDEX[right.stage], -1)
          - number(PATRON_STAGE_INDEX[left.stage], -1));
      if (!remaining.length) return state;
      const primary = remaining[0];
      const customer = state.customers.find(item => item.id === primary.customerId);
      const old = state.activeScene?.patron;
      if (!old || !customer) return state;
      const staged = {
        ...old,
        customerId: customer.id,
        customerName: customer.name,
        patronBoldness: customer.boldness,
        patronCharm: customer.charm,
        joinedPatronIds: remaining.slice(1).map(participant => participant.customerId),
        joinedPatronSlots: Object.fromEntries(remaining.slice(1).map(participant => [participant.customerId, participant.slot])),
        joinedPatronPleasure: Object.fromEntries(remaining.slice(1).map(participant => [participant.customerId, participant.pleasure])),
      };
      const primaryStep = primary.route?.[primary.routeIndex];
      let next = setPatronScene(state, staged, primary.stage, primaryStep?.actionId);
      const interaction = next.activeScene.patron;
      next = {
        ...next,
        activeScene: {
          ...next.activeScene,
          patron: { ...interaction, patronPleasure: primary.pleasure },
        },
      };
      const data = dataOf(next);
      return writeData(next, {
        ...data,
        session: { ...data.session, patronPrimaryId: primary.customerId, patronParticipants: participants },
      });
    }

    function advancePassedOutPatronFlowInternal(state) {
      if (!state) return state;
      let data = dataOf(state);
      if (!settings().patronActionsEnabled) {
        if (data.session?.kind === 'patron' && state.activeScene?.patron) {
          return finishPassedOutPatronFlow(state, 'patron-actions-disabled');
        }
        return data.session?.patronApproach ? writeData(state, {
          ...data,
          session: { ...data.session, kind: 'player', patronApproach: null },
        }) : state;
      }
      const flowOwnerId = data.session?.patronOwnerId || data.session?.patronApproach?.ownerId
        || (data.session?.patronApproach?.reason === 'sleep_potion_room'
          ? LEGACY_POTION_ROOM_OWNER : null);
      if (!flowOwnerId && !generalPatronActionsOpen(state)
        && data.session?.kind === 'patron') {
        let next = state;
        if (state.activeScene?.patron) {
          next = finishPassedOutPatronFlow(state, 'business-closed');
        } else if (data.session?.patronApproach) {
          next = cancelPatronApproach(state, data.session.patronApproach);
        }
        data = dataOf(next);
        if (data.session?.kind !== 'patron') return next;
        return writeData(next, {
          ...data,
          session: {
            ...data.session,
            kind: 'player',
            patronApproach: null,
            patronPrimaryId: null,
            patronOwnerId: null,
            patronParticipants: {},
          },
        });
      }
      if (data.session?.kind !== 'patron') return beginPassedOutPatronFlow(state);
      if (!isUnconscious(state, data.session.characterId)) {
        return finishPassedOutPatronFlow(state, 'patron-interrupted');
      }
      if (data.session.depth <= 0) return finishPassedOutPatronFlow(state, 'depth-depleted', true);
      if (!state.activeScene?.patron) return beginPassedOutPatronFlow(state);
      const sceneRoom = api.fn('wifeLocation')(state);
      const participantSeparated = Object.keys(data.session.patronParticipants || {}).some(customerId => (
        api.fn('patronControlCustomerLocation')(state, customerId) !== sceneRoom
      ));
      if (!sceneRoom || participantSeparated) {
        return finishPassedOutPatronFlow(state, 'patron-separated');
      }
      let next = state;
      let participants = { ...data.session.patronParticipants };
      let interaction = { ...state.activeScene.patron };
      const actionLines = [];
      const finishLines = [];
      const completedFinishDetails = [];
      let wifeGain = 0;
      let wifeClimaxed = false;
      const participantEntries = Object.entries(participants)
        .sort(([, left], [, right]) => Number(right.stage === PATRON_SELF_STROKE_STAGE)
          - Number(left.stage === PATRON_SELF_STROKE_STAGE));
      for (const [customerId, original] of participantEntries) {
        if (original.completed) continue;
        const participant = { ...original };
        const customer = next.customers.find(item => item.id === customerId);
        const route = participant.route?.length ? participant.route : [{
          kind: 'action', stage: participant.stage,
          ticks: patronStageAction(participant.stage)?.rate > 0
            ? Math.ceil(100 / patronStageAction(participant.stage).rate)
            : Math.max(1, whole(settings().patronNonFinishMinTicks)),
        }];
        const routeIndex = clamp(whole(participant.routeIndex), 0, Math.max(0, route.length - 1));
        const step = route[routeIndex];
        if (!customer || !step) {
          participant.completed = true;
          participants[customerId] = participant;
          next = startPatronCooldowns(next, [customerId], participants);
          continue;
        }
        if (step.kind === 'undress') {
          if (exposureChangeAllowed(characterOf(next), step.exposure)) {
            next = applySleepAction(next, {
              actionId: step.actionId,
              scope: 'nonPlayer',
              context: patronIntimacyContext(next, customer, interaction),
              acceptanceActionId: 'visual_explicit',
              actionClass: 'intimate_touch',
              repeatKey: `patron:${customerId}:undress:${step.actionId}`,
            });
            next = applyExposureChange(next, { ...step.exposure, source: 'patron' });
            actionLines.push(undressLine(next, characterOf(next)?.name || T('그녀', 'her'), step.exposure, customer.name));
          }
          participant.routeIndex = Math.min(route.length - 1, routeIndex + 1);
          participant.stepTicks = 0;
          const nextStep = route[participant.routeIndex];
          if (nextStep?.kind === 'action') {
            participant.stage = nextStep.stage;
            if (customerId === data.session.patronPrimaryId) {
              next = setPatronScene(
                next, next.activeScene.patron, participant.stage, nextStep.actionId,
              );
              interaction = { ...next.activeScene.patron };
            }
          }
          participants[customerId] = participant;
          if (dataOf(next).session?.depth <= 0) break;
          continue;
        }
        const action = patronStageAction(step.stage, step.actionId);
        if (!action) {
          participant.completed = true;
          participants[customerId] = participant;
          next = startPatronCooldowns(next, [customerId], participants);
          continue;
        }
        participant.stage = step.stage;
        participant.actionId = action.actionId;
        const crossesEscalationBoundary = participant.stepTicks <= 0
          && number(PATRON_STAGE_INDEX[step.stage], -1) >= PATRON_ESCALATION_WARNING_INDEX
          && !route.slice(0, routeIndex).some(previous => previous.kind === 'action'
            && number(PATRON_STAGE_INDEX[previous.stage], -1) >= PATRON_ESCALATION_WARNING_INDEX);
        if (!action.noContact) {
          const traceActionId = api.fn('patronSceneActionId')({
            ...interaction,
            stage: participant.stage,
            primarySlot: participant.slot || patronPrimarySlot(participant.stage),
          });
          next = queueLowFamiliarityEvidence(next, traceActionId, {
            sourceType: 'patron', sourceId: customer.id, sourceName: customer.name,
          });
        }
        next = applySleepAction(next, {
          actionId: action.actionId,
          scope: 'nonPlayer',
          context: patronIntimacyContext(next, customer, interaction),
          actionClass: actionClassOf(action.actionId),
          repeatKey: `patron:${customerId}:${participant.stage}`,
          depthCostOverride: action.noContact ? 0 : undefined,
          completed: action.noContact ? false : undefined,
        });
        if (crossesEscalationBoundary && !action.noContact) {
          next = api.fn('patronEscalationAwayAlert')(
            next,
            customer.id,
            customer.name,
            characterOf(next)?.name || T('그녀', 'her'),
            participant.stage,
          );
        }
        if (!action.noContact) {
          const patronArousal = Math.max(0, number(
            api.fn('patronStageArousal')(participant.stage),
          ));
          if (patronArousal > 0) {
            next = api.fn('applyEffects')(next, {
              targetCharacterId: next.primaryCharacterId,
              playerStatDeltas: {},
              wifeStatDeltas: { arousal: patronArousal },
              wifeTraitDeltas: {},
              arousalContext: {
                source: `patron_stage_${customer.name}_${participant.stage}`,
                patronName: customer.name,
                distress: false,
              },
            });
          }
        }
        participant.ticks = Math.max(0, whole(participant.ticks)) + 1;
        participant.stepTicks = Math.max(0, whole(participant.stepTicks)) + 1;
        actionLines.push(patronActionLine(next, participant, actionLines.length));
        if (action.rate > 0 && step.stage === participant.targetStage) {
          participant.pleasure = clamp(participant.pleasure + action.rate, 0, 100);
          wifeGain += nonNegative(action.wifeRate) * WIFE_PLEASURE_MULTIPLIER;
          if (participant.pleasure >= 100) {
            const selfStrokeFinish = action.noContact ? patronSelfStrokeFinishTarget(next) : null;
            const finishId = selfStrokeFinish?.finishId
              || participant.finishActionId || patronFinishAction(participant.stage, customer);
            if (!action.noContact) {
              next = applySleepAction(next, {
                actionId: patronFinishAcceptanceAction(participant.stage, finishId),
                affinityKey: finishId,
                scope: 'nonPlayer',
                context: patronIntimacyContext(next, customer, interaction),
                actionClass: 'finish',
                repeatKey: `patron:${customerId}:${participant.stage}:finish`,
              });
              const traceActionId = api.fn('patronSceneActionId')({
                ...interaction,
                stage: participant.stage,
                primarySlot: participant.slot || patronPrimarySlot(participant.stage),
              });
              next = applySexAftermath(
                next, traceActionId, finishId, true,
                patronFinishFluidTags(participant, customer, finishId),
              );
              completedFinishDetails.push({
                sourceType: 'patron',
                sourceId: customer.id,
                sourceName: customer.name,
                actionId: traceActionId,
                stage: participant.stage,
                position: participant.slot || patronPrimarySlot(participant.stage),
                finishId,
                vaginalDeposit: finishId === 'cum_inside'
                  && traceActionId === 'sex'
                  && participant.slot !== 'inside_anal',
                boldness: customer.boldness,
                comfort: interaction.elenaComfort,
                pleasure: interaction.elenaPleasure,
              });
            } else if (selfStrokeFinish) {
              next = applySexAftermath(
                next, selfStrokeFinish.actionId, selfStrokeFinish.finishId, true,
                selfStrokeFinish.fluidTags,
              );
              next = queueFinishEvidence(
                next, selfStrokeFinish.actionId, selfStrokeFinish.finishId, {
                  sourceType: 'patron', sourceId: customer.id, sourceName: customer.name,
                },
              );
            }
            participant.finishActionId = finishId;
            participant.completed = true;
            finishLines.push({
              line: patronFinishLine(next, participant, customer, finishId),
              meta: patronActionLogMeta(next, participant, 'finished'),
            });
          }
        }
        if (!participant.completed && participant.stepTicks >= Math.max(1, whole(step.ticks))) {
          if (routeIndex < route.length - 1) {
            participant.routeIndex = routeIndex + 1;
            participant.stepTicks = 0;
            const nextStep = route[participant.routeIndex];
            if (nextStep?.kind === 'action') {
              participant.stage = nextStep.stage;
              if (customerId === data.session.patronPrimaryId) {
                const followingStep = route[participant.routeIndex];
                next = setPatronScene(
                  next, next.activeScene.patron, participant.stage, followingStep?.actionId,
                );
                interaction = { ...next.activeScene.patron };
              }
            }
          } else if (action.rate <= 0) participant.completed = true;
        }
        participants[customerId] = participant;
        if (!original.completed && participant.completed) {
          next = startPatronCooldowns(next, [customerId], participants);
        }
        if (dataOf(next).session?.depth <= 0) break;
      }
      interaction = { ...next.activeScene.patron };
      const previousWifePleasure = clamp(number(interaction.elenaPleasure), 0, 100);
      let wifePleasure = previousWifePleasure + wifeGain;
      let wifeClimaxCount = Math.max(0, whole(interaction.elenaInteractionClimaxCount));
      if (wifePleasure >= 100) {
        wifePleasure = 55;
        wifeClimaxed = true;
        wifeClimaxCount += 1;
        next = api.fn('updateWife')(next, wife => ({
          ...wife,
          lastOrgasmSlot: next.slot,
          orgasmsToday: Math.max(0, whole(wife.orgasmsToday)) + 1,
          stats: {
            ...(wife.stats || {}),
            arousal: wifeClimaxCount > 1 ? 80 : 72,
          },
        }));
      }
      const primaryId = data.session.patronPrimaryId;
      const primary = participants[primaryId];
      interaction = {
        ...interaction,
        patronPleasure: primary?.pleasure ?? interaction.patronPleasure,
        elenaPleasure: wifePleasure,
        elenaClimaxedDuringInteraction: interaction.elenaClimaxedDuringInteraction === true || wifeClimaxed,
        elenaInteractionClimaxCount: wifeClimaxCount,
        joinedPatronPleasure: {
          ...(interaction.joinedPatronPleasure || {}),
          ...Object.fromEntries(Object.values(participants)
            .filter(participant => participant.customerId !== primaryId && !participant.completed)
            .map(participant => [participant.customerId, participant.pleasure])),
        },
        joinedPatronIds: (interaction.joinedPatronIds || []).filter(id => !participants[id]?.completed),
      };
      for (const detail of completedFinishDetails) {
        next = recordFinishCompleted(next, {
          ...detail,
          orgasmed: interaction.elenaClimaxedDuringInteraction === true,
        });
      }
      next = queuePatronFinishSignals(next, completedFinishDetails);
      const reaction = unconsciousReactionLine(next, wifePleasure, wifeClimaxed);
      next = { ...next, activeScene: { ...next.activeScene, patron: interaction } };
      if (actionLines.length) {
        next = logPatronActionForOwner(
          next,
          `${actionLines.filter(Boolean).join(' ')} ${reaction}`.trim(),
          patronActionLogMeta(next, primary),
        );
      }
      for (const finish of finishLines) {
        next = logSleepAction(next, finish.line, finish.meta);
      }
      const latestData = dataOf(next);
      next = writeData(next, {
        ...latestData,
        session: { ...latestData.session, patronParticipants: participants },
      });
      if (latestData.session?.depth <= 0) return finishPassedOutPatronFlow(next, 'depth-depleted', true);
      if (Object.values(participants).every(participant => participant.completed)) {
        next = api.fn('log')(next, isSleeping(next) ? T(
          `손님들이 하나둘 물러나도 ${characterOf(next)?.name || '그녀'}은(는) 잠에서 깨지 않습니다.`,
          `Even as the patrons step away one by one, ${characterOf(next)?.name || 'she'} does not wake.`,
        ) : T(
          `손님들이 하나둘 물러나도 ${characterOf(next)?.name || '그녀'}은(는) 의식을 되찾지 못합니다.`,
          `Even as the patrons step away one by one, ${characterOf(next)?.name || 'she'} does not regain consciousness.`,
        ));
        return finishPassedOutPatronFlow(next, 'patron-complete');
      }
      if (participants[primaryId]?.completed) next = rotatePatronPrimary(next, participants);
      return next;
    }

    function advancePassedOutPatronFlow(state) {
      const cleaned = clearNativeFinishSignals(state);
      const advanced = advanceUnconsciousTimeline(cleaned);
      if (!isUnconscious(advanced)
        || dataOf(advanced).session?.kind !== 'patron') {
        return publishNextPatronFinishSignal(advanced);
      }
      return publishNextPatronFinishSignal(advancePassedOutPatronFlowInternal(advanced));
    }

    function forcePassedOutForTest(state) {
      if (!state || state.pendingEvent || state.activeScene?.patron || state.activeScene?.sex) return state;
      let next = api.fn('updateWife')(state, wife => ({
        ...wife,
        currentTask: 'passed_out',
        taskTarget: undefined,
        busyUntilSlot: whole(state.slot) + 9999,
        passedOutAtSlot: whole(state.slot),
        passedOutAcknowledged: true,
        retiredAtSlot: undefined,
        intoxication: { ...(wife.intoxication || {}), level: 100 },
      }));
      next = settlePassedOutAutonomy(next);
      next = api.fn('log')(next, T(
        `${characterOf(next)?.name || '그녀'}을(를) 시험용 기절 상태로 바꿨습니다.`,
        `${characterOf(next)?.name || 'She'} has been placed in the test passed-out state.`,
      ));
      return next;
    }

    function depthGauge(state) {
      const data = dataOf(state);
      const normalDepthCap = settings().normalDepthCap;
      const depth = Math.max(0, number(data.session?.depth, data.lastSession?.finalDepth));
      const depthWidth = clamp(depth / normalDepthCap * 100, 0, 100);
      return JSX.jsxs('div', {
        className: 'mb-3 rounded border border-violet-800/70 bg-stone-900/80 p-2',
        'data-sleep-actions-depth': depth,
        children: [
          JSX.jsxs('div', {
            className: 'mb-1 flex items-center justify-between text-xs text-stone-300',
            children: [
              JSX.jsx('span', { children: T('수면 심도', 'Sleep depth') }),
              JSX.jsx('strong', { className: 'text-violet-200', children: `${Math.round(depth * 10) / 10} / ${normalDepthCap}` }),
            ],
          }),
          JSX.jsx('div', {
            className: 'h-2 overflow-hidden rounded-full bg-stone-700',
            children: JSX.jsx('div', {
              className: 'h-full bg-violet-500 transition-all',
              style: { width: `${depthWidth}%` },
            }),
          }),
        ],
      }, 'sleep-actions-depth');
    }

    function originalPleasureGauges(state) {
      const session = dataOf(state).session;
      const patronScene = state.activeScene?.patron || null;
      const playerPleasure = Math.round(clamp(number(
        patronScene?.patronPleasure, session?.playerPleasure,
      ), 0, 100));
      const wifePleasure = Math.round(clamp(number(
        patronScene?.elenaPleasure, session?.wifePleasure,
      ), 0, 100));
      return JSX.jsxs('div', {
        className: 'mb-3 space-y-1.5',
        children: [
          JSX.jsx(PleasureGauge, {
            label: patronScene?.customerName || T('당신', 'You'),
            value: playerPleasure,
            color: 'bg-blue-500',
          }, 'sleep-actions-player-pleasure'),
          JSX.jsx(PleasureGauge, {
            label: T('그녀', 'Her'),
            value: wifePleasure,
            color: 'bg-pink-500',
          }, 'sleep-actions-wife-pleasure'),
        ],
      }, 'sleep-actions-original-pleasure');
    }

    function insertAfterOriginalHeading(element, additions) {
      if (!React.isValidElement(element)) return { element, inserted: false };
      const children = React.Children.toArray(element.props.children);
      const headingIndex = children.findIndex(child => child?.type === 'h3'
        && child?.props?.className === 'text-sm font-bold text-amber-400 uppercase tracking-wider mb-1');
      if (headingIndex >= 0) {
        const nextChildren = [...children];
        nextChildren.splice(headingIndex + 1, 0, ...additions);
        return { element: React.cloneElement(element, {}, nextChildren), inserted: true };
      }
      for (let index = 0; index < children.length; index += 1) {
        const nested = insertAfterOriginalHeading(children[index], additions);
        if (!nested.inserted) continue;
        const nextChildren = [...children];
        nextChildren[index] = nested.element;
        return { element: React.cloneElement(element, {}, nextChildren), inserted: true };
      }
      return { element, inserted: false };
    }

    function removeNativePassedOutNotice(element) {
      if (!React.isValidElement(element)) return element;
      const classTokens = new Set(String(element.props?.className || '').split(/\s+/).filter(Boolean));
      const isPassedOutNotice = classTokens.has('border-red-900') && classTokens.has('bg-red-950/30');
      if (isPassedOutNotice) return null;
      const children = React.Children.toArray(element.props.children);
      let changed = false;
      const nextChildren = [];
      for (const child of children) {
        const nested = removeNativePassedOutNotice(child);
        if (nested !== child) changed = true;
        if (nested != null) nextChildren.push(nested);
      }
      return changed ? React.cloneElement(element, {}, nextChildren) : element;
    }

    function shouldRemoveNativePassedOutNotice(state) {
      const wife = characterOf(state);
      return !!wife && wife.currentTask === 'passed_out' && wife.passedOutAcknowledged === true
        && wife.retiredAtSlot == null;
    }

    function canCarryUnconsciousWifeToBedroom(state) {
      if (!state || !isUnconscious(state) || state.pendingEvent
        || state.activeScene?.patron || state.activeScene?.sex) return false;
      const playerRoom = api.fn('playerLocation')(state);
      const wifeRoom = api.fn('wifeLocation')(state);
      const sleepRoom = actualSleepRoom(state);
      return !!wifeRoom && playerRoom === wifeRoom
        && !!sleepRoom && wifeRoom !== sleepRoom;
    }

    function returnPlayerToTaproom(state) {
      if (!state || api.fn('playerLocation')(state) === 'taproom'
        || !Array.isArray(state.locations?.taproom?.occupants)) return state;
      let next = api.fn('moveOccupant')(state, 'player', 'taproom');
      next = api.fn('log')(next, T(
        '당신은 그녀가 누운 것을 확인하고 홀로 내려옵니다.',
        'Once you are sure she is settled, you return to the taproom.',
      ));
      return next;
    }

    function carrySleepingWifeToBedroom(state) {
      const sleepRoom = actualSleepRoom(state);
      if (!isSleeping(state) || !canCarryUnconsciousWifeToBedroom(state)
        || !sleepRoom || !Array.isArray(state.locations?.[sleepRoom]?.occupants)) return state;
      const name = characterOf(state)?.name || T('그녀', 'her');
      let next = api.fn('log')(state, T(
        `당신은 ${name}을(를) 조심스럽게 안아 침실의 침대에 눕힙니다. 그녀는 잠에서 깨지 않습니다.`,
        `You carefully carry ${name} to the bedroom and lay her on the bed. She does not wake.`,
      ));
      next = api.fn('moveOccupant')(next, next.primaryCharacterId, sleepRoom);
      for (let minute = 0; minute < 10; minute += 1) next = api.fn('tick')(next);
      return returnPlayerToTaproom(next);
    }

    function unconsciousCarryButton(state) {
      const actionType = isPassedOut(state) ? 'carry_to_bed' : CARRY_SLEEPING_TO_BED_ACTION;
      return JSX.jsx(ActionButton, {
        __sleepActionsCarry: true,
        label: T('그녀를 침실로 데려가기', 'Carry her to the bedroom'),
        time: 10,
        description: T(
          '그녀를 안아 침실의 침대에 눕힙니다.',
          'Carry her to the bedroom and lay her on the bed.',
        ),
        onClick: () => api.store.dispatch({ type: actionType }),
        primary: true,
      }, 'sleep-actions-carry-to-bed');
    }

    function cleanPassedOutActionPanel(original, state) {
      return (shouldRemoveNativePassedOutNotice(state) || !!baseSleepPatronContext(state))
        ? removeNativePassedOutNotice(original) : original;
    }

    function sleepActionButton(choice) {
      return JSX.jsx(ActionButton, {
        label: choice.label,
        description: choice.description || '',
        disabled: choice.disabled === true,
        onClick: () => api.store.dispatch({ type: 'scene_action', actionId: choice.id }),
      }, choice.id);
    }

    function patronSceneActionButton(action) {
      return JSX.jsx(ActionButton, {
        label: action.label,
        time: action.time,
        description: action.description || '',
        primary: action.primary === true,
        onClick: () => api.store.dispatch(action.dispatch),
      }, action.key || action.dispatch?.type || action.label);
    }

    function patronDoorActions(state, side, room = api.fn('wifeLocation')(state)) {
      if (side === 'outside') return [
        {
          key: PATRON_DOOR_KNOCK_ACTION,
          label: T('노크하기', 'Knock'), time: 1,
          description: T('조용히 문을 두드리고 안쪽의 반응을 살핍니다.', 'Knock softly and listen for a response.'),
          dispatch: { type: PATRON_DOOR_KNOCK_ACTION, room },
        },
        {
          key: PATRON_DOOR_PEEK_ACTION,
          label: T('안을 들여다보기', 'Peek inside'), time: 1,
          description: T('문틈 너머로 방 안에서 벌어지는 일을 확인합니다.', 'Look through the gap to see what is happening inside.'),
          dispatch: { type: PATRON_DOOR_PEEK_ACTION, room },
        },
        {
          key: PATRON_DOOR_OPEN_ACTION,
          label: T('문 열기', 'Open the door'),
          description: T('잠겨 있지 않다면 문을 열고 조용히 방 안으로 들어갑니다.', 'If it is not locked, open the door and quietly step inside.'),
          primary: true,
          dispatch: { type: PATRON_DOOR_OPEN_ACTION, room },
        },
        ...(dataOf(state).patronDoor ? [{
          key: PATRON_DOOR_LEAVE_ACTION,
          label: T('물러서기', 'Step away'),
          description: T('문에서 물러나 원래 있던 곳으로 돌아갑니다.', 'Step away from the door and return.'),
          dispatch: { type: PATRON_DOOR_LEAVE_ACTION },
        }] : []),
      ];
      const inside = [
        {
          key: PATRON_QUIET_SEPARATE_ACTION,
          label: T('깨우지 않고 조용히 떼어놓기', 'Separate them without waking her'), time: 1,
          description: T('그녀를 건드리지 않고 손님만 조용히 물러나게 합니다.', 'Quietly make the patron leave without touching her.'),
          dispatch: { type: PATRON_QUIET_SEPARATE_ACTION },
        },
        {
          key: PATRON_WAKE_INTERVENE_ACTION,
          label: T('그녀를 깨우고 개입하기', 'Wake her and intervene'),
          description: T('그녀를 깨워 손님이 한 일을 알리고, 어떻게 할지 듣습니다.', 'Wake her, tell her what the patron did, and hear what she wants to do.'),
          primary: true,
          dispatch: { type: PATRON_WAKE_INTERVENE_ACTION },
        },
      ];
      if (dataOf(state).patronDoor) inside.push({
        key: PATRON_DOOR_LEAVE_ACTION,
        label: T('방에서 물러서기', 'Leave the room'),
        description: T('아무것도 하지 않고 방 밖으로 물러납니다.', 'Leave the room without intervening.'),
        dispatch: { type: PATRON_DOOR_LEAVE_ACTION },
      });
      return inside;
    }

    function patronSceneControls(state, side, room = api.fn('wifeLocation')(state), compact = false) {
      const actions = patronDoorActions(state, side, room);
      const waitActions = compact ? [] : [1, 5, 15].map(minutes => ({
        key: `sleep-actions-patron-wait-${minutes}`,
        label: T(`${minutes}분 흐르기`, `Wait ${minutes} minute${minutes === 1 ? '' : 's'}`),
        time: minutes,
        description: side === 'outside'
          ? T('문밖에서 기다리며 방 안의 시간이 흐르게 둡니다.', 'Wait outside while time passes in the room.')
          : T('방 안에서 지켜보며 시간이 흐르게 둡니다.', 'Stay in the room and watch as time passes.'),
        dispatch: { type: 'wait', minutes },
      }));
      return JSX.jsxs('div', {
        className: compact ? 'grid grid-cols-1 gap-2' : 'space-y-3',
        'data-sleep-actions-patron-intervention': side,
        children: [
          compact ? null : JSX.jsx('h3', {
            className: 'text-sm font-bold text-amber-400 uppercase tracking-wider mb-1',
            children: side === 'outside'
              ? T('그녀가 있는 방 문앞', 'Outside her room')
              : T('그녀와 손님이 있는 방', 'Room with her and the patron'),
          }),
          JSX.jsx('div', {
            className: 'grid grid-cols-1 gap-2',
            children: actions.map(patronSceneActionButton),
          }),
          waitActions.length ? JSX.jsx('div', {
            className: 'grid grid-cols-3 gap-2',
            'data-sleep-actions-patron-wait': '',
            children: waitActions.map(patronSceneActionButton),
          }) : null,
          compact ? null : depthGauge(state),
        ].filter(Boolean),
      });
    }

    function sleepActionCategory(title, kind, choices, borderClass, titleClass) {
      return JSX.jsxs('section', {
        className: `rounded-lg border ${borderClass} bg-stone-900/50 p-3`,
        'data-sleep-actions-category': kind,
        children: [
          JSX.jsx('h4', {
            className: `mb-2 text-xs font-bold uppercase tracking-wider ${titleClass}`,
            children: title,
          }),
          JSX.jsx('div', {
            className: 'grid grid-cols-3 gap-2',
            'data-sleep-actions-grid': kind,
            children: choices.map(sleepActionButton),
          }),
        ],
      }, `sleep-actions-category-${kind}`);
    }

    function groupedActionChoices(state) {
      const choices = state.pendingEvent?.choices || [];
      const strokeChoice = choices.find(choice => choice.id === 'sleep:act:stroke');
      const selfPleasureChoice = choices.find(choice => choice.id === 'sleep:self-pleasure');
      const continueChoice = choices.find(choice => choice.id === 'sleep:sex:continue');
      const touchChoices = choices.filter(choice => choice.id?.startsWith('sleep:act:')
        && choice.id !== 'sleep:act:stroke');
      const sexChoices = choices.filter(choice => choice.id?.startsWith('sleep:sex:')
        && choice.id !== 'sleep:sex:continue');
      const undressChoices = choices.filter(choice => choice.id?.startsWith('sleep:undress:'));
      const stopChoice = choices.find(choice => choice.id === 'sleep:stop');
      return JSX.jsxs('div', {
        className: 'space-y-3',
        'data-sleep-actions-groups': '',
        children: [
          JSX.jsx('div', {
            className: 'grid grid-cols-3 gap-2',
            'data-sleep-actions-primary': '',
            children: [strokeChoice, selfPleasureChoice, continueChoice].filter(Boolean).map(sleepActionButton),
          }, 'sleep-actions-primary'),
          sleepActionCategory(
            T('만지기', 'Touching'), 'touch', touchChoices,
            'border-violet-700/70', 'text-violet-300',
          ),
          sleepActionCategory(
            T('성관계', 'Sexual actions'), 'sex', sexChoices,
            'border-pink-700/70', 'text-pink-300',
          ),
          sleepActionCategory(
            T('옷 벗기기', 'Undressing'), 'undress', undressChoices,
            'border-amber-700/70', 'text-amber-300',
          ),
          stopChoice ? JSX.jsx('div', {
            className: 'grid grid-cols-1 gap-2',
            children: sleepActionButton(stopChoice),
          }, 'sleep-actions-stop') : null,
        ],
      }, 'sleep-actions-groups');
    }

    function replaceOriginalChoiceGrid(element, replacement) {
      if (!React.isValidElement(element)) return { element, replaced: false };
      const children = React.Children.toArray(element.props.children);
      const choiceIndex = children.findIndex(child => {
        if (child?.type !== 'div') return false;
        const classes = new Set(
          String(child.props?.className || '').split(/\s+/).filter(Boolean),
        );
        return classes.has('grid') && classes.has('grid-cols-1') && classes.has('gap-2');
      });
      if (choiceIndex >= 0) {
        const nextChildren = [...children];
        nextChildren[choiceIndex] = replacement;
        return { element: React.cloneElement(element, {}, nextChildren), replaced: true };
      }
      for (let index = 0; index < children.length; index += 1) {
        const nested = replaceOriginalChoiceGrid(children[index], replacement);
        if (!nested.replaced) continue;
        const nextChildren = [...children];
        nextChildren[index] = nested.element;
        return { element: React.cloneElement(element, {}, nextChildren), replaced: true };
      }
      return { element, replaced: false };
    }

    function activeSleepImage(state, character) {
      if (!character) return null;
      const session = state ? dataOf(state).session : null;
      if (session?.characterId === character.id && session.finishScene) {
        return {
          actionId: `finish:${session.finishScene}`,
          action: { imageScene: session.finishScene },
        };
      }
      if (session?.characterId === character.id) {
        if (session.kind === 'patron') {
          const patron = state.activeScene?.patron;
          const action = patronStageAction(patron?.sleepActionsStage, patron?.sleepActionsActionId);
          return action?.scene && character.sceneSetAtSlot != null
            && character.sceneOverride === action.scene
            ? { actionId: `patron:${patron.sleepActionsStage}`, action: { imageScene: action.scene } }
            : null;
        }
        const action = playerActionDefinition(session.imageActionId);
        if (action) return { actionId: session.imageActionId, action };
      }
      return (character.currentTask === 'sleeping' || character.currentTask === 'passed_out')
        && character.sceneSetAtSlot != null
        && SLEEP_IMAGE_SCENES.has(character.sceneOverride)
        ? { actionId: character.sceneOverride, action: { imageScene: character.sceneOverride } }
        : null;
    }

    function activeAipSleepEntry(state, character) {
      const session = state && dataOf(state).session;
      if (!session || !character || session.characterId !== character.id
        || !isUnconscious(state, character.id) || !activeSleepImage(state, character)) return null;
      const room = api.fn('wifeLocation')(state);
      const ratio = number(session.depth) / settings().normalDepthCap;
      const level = ratio >= 0.67 ? 'deep' : ratio >= 0.34 ? 'middle' : 'light';
      const inBed = AIP_BED_ROOMS.has(room);
      const kind = isPassedOut(state, character.id) ? 'blackout' : 'sleep';
      return { entry: inBed ? `${kind}-${level}` : `${kind}-elsewhere-${level}`, inBed };
    }

    function aipPromptOutsideBed(value, negative = false) {
      return String(value || '').split(',').map(part => {
        const tag = part.trim();
        if (negative && /^\(?(?:sitting|kneeling) woman(?::[\d.]+)?\)?$/i.test(tag)) return '';
        if (/\b(?:pillow|mattress|bedroom|bedside|headboard|bedsheet|bedspread|blanket|duvet)\b/i.test(tag)) return '';
        const withoutBed = tag.replace(/\s+\b(?:in|on|at)\s+(?:(?:a|the)\s+)?bed\b/gi, '').trim();
        if (!negative && /^\(?(?:woman )?lying down(?::[\d.]+)?\)?$/i.test(withoutBed)) return '';
        return /\bbed\b/i.test(withoutBed) ? '' : withoutBed;
      }).filter(Boolean).join(', ');
    }

    function aipSleepSelection(character) {
      if (!attentionImagePrompt || !character) return null;
      const state = api.store.game();
      const current = state && characterOf(state, character.id);
      if (!current || character.sceneOverride !== current.sceneOverride
        || character.sceneSetAtSlot !== current.sceneSetAtSlot) return null;
      const context = activeAipSleepEntry(state, current);
      if (!context) return null;
      const chosen = attentionImagePrompt.resolve(ID, context.entry);
      return chosen ? {
        ...context,
        chosen: context.inBed ? chosen : {
          ...chosen,
          positivePrompt: aipPromptOutsideBed(chosen.positivePrompt),
          negativePrompt: aipPromptOutsideBed(chosen.negativePrompt, true),
        },
        token: attentionImagePrompt.cacheToken(ID, context.entry),
      } : null;
    }

    function aipSleepKey(key, selected) {
      if (typeof key !== 'string' || !selected?.token || key.includes('__sleep-aip-')) return key;
      return key.replace(/(__v-\d+)?$/, `__sleep-aip-${selected.inBed ? 'b' : 'o'}-${selected.token}$1`);
    }

    function getImagePromptContext(state = api.store.game(), characterId = state?.primaryCharacterId) {
      if (!state || !characterId) return null;
      const character = characterOf(state, characterId);
      const session = dataOf(state).session;
      if (!character || session?.characterId !== characterId || !isUnconscious(state, characterId)) return null;
      const active = activeSleepImage(state, character);
      if (active?.action?.imageScene !== 'patron_self_stroke') return null;
      const actorType = session.kind === 'patron' ? 'patron' : 'player';
      const actorId = actorType === 'patron'
        ? (state.activeScene?.patron?.customerId || session.patronPrimaryId || null)
        : 'player';
      return {
        marker: IMAGE_PROMPT_MARKERS.SELF_PLEASURE,
        kind: 'self_pleasure',
        actorType,
        actorId,
        characterId,
        unconsciousState: session.unconsciousState,
        subjectAwareness: 'unaware',
        subjectParticipation: 'passive',
        eyes: 'closed',
        scene: active.action.imageScene,
      };
    }

    api.hook('recentPatronIntimacySummary', {
      around(next, history, ...rest) {
        const conscious = Array.isArray(history)
          ? history.filter(entry => entry?.awareness !== 'unaware' && entry?.reception !== 'unaware')
          : history;
        return next(conscious, ...rest);
      },
    });
    api.hook('wifeScene', {
      after(result, [state]) {
        const character = characterOf(state);
        const active = activeSleepImage(state, character);
        return active ? {
          scene: active.action.imageScene,
          sceneVariant: character?.sceneVariant,
        } : result;
      },
    });
    api.hook('imageDescriptor', {
      after(result, [character]) {
        const state = api.store.game();
        const active = activeSleepImage(state, character);
        if (!result || !active) return result;
        const promptContext = getImagePromptContext(state, character?.id);
        return {
          ...result,
          kind: 'scene',
          scene: active.action.imageScene,
          task: undefined,
          variant: character.sceneVariant ?? result.variant,
          abed: true,
          ...(promptContext ? { sleepActionsPromptContext: promptContext } : {}),
        };
      },
    });
    api.hook('imageKey', {
      priority: -2000000,
      after(result, [character]) {
        return aipSleepKey(result, aipSleepSelection(character));
      },
    });
    api.hook('imagePrompt', {
      priority: -2000000,
      after(result, [character]) {
        if (!result || !Array.isArray(result.parts)) return result;
        const selected = aipSleepSelection(character);
        if (!selected) return result;
        const { positivePrompt, negativePrompt } = selected.chosen;
        const prompt = [result.prompt, positivePrompt].filter(Boolean).join(', ');
        return {
          ...result,
          key: aipSleepKey(result.key, selected),
          prompt,
          negativePrompt: [result.negativePrompt, negativePrompt].filter(Boolean).join(', '),
          parts: [...result.parts, { label: T('수면 중 행동', 'Sleep Actions'), tags: positivePrompt }],
          genParams: api.fn('promptGenParams')(prompt),
        };
      },
    });
    api.hook('wifeExposureAftermathTick', {
      around(next, state, ...rest) {
        return isPassedOut(state) ? state : next(state, ...rest);
      },
    });
    api.hook('processPatronInteractionTick', {
      around: processPatronTickAtOwnershipBoundary,
      after: afterOriginalPatronTick,
    });
    api.hook('processPassedOutTransition', { after: afterOriginalPassedOutTransition });
    api.hook('minuteTick', { after: advanceSleepMinute });
    api.hook('worldTick', {
      around(next, state, ...rest) {
        const cleaned = guardPassedOutAutonomyDuringWorldTick(clearNativeFinishSignals(state));
        const woke = settleNaturalSleepWake(next(cleaned, ...rest), cleaned);
        const advanced = settlePendingPatronRoomReturns(advanceUnconsciousTimeline(
          releasePassedOutAutonomyGuard(woke),
        ));
        const enteredRoom = resolveLegacyPotionRoomRenter(advanced);
        if (enteredRoom.pendingEvent?.sleepActionsPotionRoomNotice
          && !advanced.pendingEvent?.sleepActionsPotionRoomNotice) return enteredRoom;
        return reconcilePatronDoor(finalizePendingInterventionReturn(maybeResolveMorningIncident(
          publishNextPatronFinishSignal(advancePassedOutPatronFlowInternal(enteredRoom)),
        )));
      },
    });
    api.hook('wakeUp', { after: afterWakeUp });
    api.hook('reduceGameAction', {
      around(next, state, action, ...rest) {
        const cleaned = releasePassedOutAutonomyGuard(clearNativeFinishSignals(state));
        const baseContext = baseSleepPatronContext(cleaned);
        if (baseContext && NATIVE_PATRON_DOOR_ACTIONS.has(action?.type)) {
          const targetRoom = action.room || baseContext.room;
          if (targetRoom === baseContext.room) {
            if (action.type === 'knock_on_door') {
              return performBasePatronDoorCheck(cleaned, 'knock', targetRoom);
            }
            if (action.type === 'peek_inside') {
              return performBasePatronDoorCheck(cleaned, 'peek', targetRoom);
            }
            return enterBasePatronDoor(cleaned, targetRoom);
          }
        }
        const returnToTaproomAfterCarry = action?.type === 'carry_to_bed'
          && canCarryUnconsciousWifeToBedroom(cleaned);
        if (action?.type === 'resolve_event'
          && cleaned?.pendingEvent?.sleepActionsPatronInterventionRefused) {
          return resolvePlayerInterventionChoice(cleaned, action.choiceId);
        }
        if (action?.type === 'resolve_event'
          && cleaned?.pendingEvent?.sleepActionsPotionRoomNotice) {
          return resolveLegacyPotionRoomNotice(cleaned, action.choiceId);
        }
        if (action?.type === 'resolve_event' && cleaned?.pendingEvent?.sleepActionsMorning) {
          return resolveMorningConfrontation(cleaned, action.choiceId);
        }
        if (action?.type === 'scene_action' && cleaned?.pendingEvent?.sleepActions) {
          return resolvePlayerSleepChoice(cleaned, action.actionId);
        }
        const originalInterventionChoice = action?.type === 'patron_interaction_choice'
          ? action.choiceId : action?.type === 'scene_action' ? action.actionId : null;
        if (baseContext && playerPatronSceneSide(cleaned, baseContext) === 'inside'
          && ['step_in', 'pull_away', 'stop'].includes(originalInterventionChoice)) {
          return startPlayerWakeIntervention(cleaned);
        }
        const directBackRoomEntry = baseContext?.room === 'back_room'
          && action?.type === 'go_to_back_room'
          && api.fn('playerLocation')(cleaned) !== 'back_room';
        let originalResult = next(cleaned, action, ...rest);
        if (directBackRoomEntry && api.fn('playerLocation')(originalResult) === 'back_room') {
          originalResult = replaceFirstAddedLog(
            cleaned, originalResult, basePatronBackRoomEntryLine(cleaned, baseContext),
          );
        }
        const reduced = finalizePendingInterventionReturn(
          settlePendingPatronRoomReturns(originalResult),
        );
        const acknowledged = releasePassedOutAutonomyGuard(reduced);
        return reconcilePatronDoor(
          returnToTaproomAfterCarry ? returnPlayerToTaproom(acknowledged) : acknowledged,
        );
      },
      priority: 10,
    });
    api.hook('ActionButton', {
      around(next, props, ...rest) {
        if (props?.__sleepActionsCarry) {
          const { __sleepActionsCarry, ...own } = props;
          return next(own, ...rest);
        }
        const rendered = next(props, ...rest);
        const state = api.store.game();
        const wife = characterOf(state);
        if (!canCarryUnconsciousWifeToBedroom(state) || props?.label !== wife?.name) return rendered;
        return JSX.jsxs(React.Fragment, {
          children: [rendered, unconsciousCarryButton(state)],
        });
      },
    });
    api.hook('ActionPanel', {
      after(original) {
        const state = api.store.game();
        if (!React.isValidElement(original) || !state) return original;
        const basePanel = cleanPassedOutActionPanel(original, state);
        const baseContext = baseSleepPatronContext(state);
        if (baseContext && !state.pendingEvent) {
          const side = playerPatronSceneSide(state, baseContext);
          if (side) {
            const controls = patronSceneControls(state, side, baseContext.room);
            const replaced = replaceOriginalChoiceGrid(basePanel, controls);
            if (replaced.replaced) return replaced.element;
            return React.cloneElement(basePanel, {}, [
              ...React.Children.toArray(basePanel.props.children), controls,
            ]);
          }
        }
        if (state.pendingEvent?.sleepActions) {
          const screen = state.pendingEvent.sleepActions.screen;
          if (screen === 'wake_discovery') return basePanel;
          const showGroups = screen === 'root' || screen === 'touch' || screen === 'sex';
          const groups = showGroups ? groupedActionChoices(state) : null;
          const replaced = groups
            ? replaceOriginalChoiceGrid(basePanel, groups)
            : { element: basePanel, replaced: false };
          const panel = replaced.element;
          const additions = [originalPleasureGauges(state), depthGauge(state)];
          const inserted = insertAfterOriginalHeading(panel, additions);
          let result = inserted.inserted
            ? inserted.element
            : React.cloneElement(panel, {}, [
              ...additions,
              ...React.Children.toArray(panel.props.children),
            ]);
          if (groups && !replaced.replaced) {
            result = React.cloneElement(result, {}, [
              ...React.Children.toArray(result.props.children), groups,
            ]);
          }
          return result;
        }
        const originalChildren = React.Children.toArray(basePanel.props.children);
        const children = [...originalChildren];
        if (canStartPlayerSleepActions(state)) {
          const passedOut = isPassedOut(state);
          const entry = JSX.jsx(ActionButton, {
            label: passedOut
              ? T('의식을 잃은 그녀에게 다가가기', 'Approach her while she is unconscious')
              : T('잠든 그녀에게 다가가기', 'Approach her while she sleeps'),
            description: passedOut
              ? T('의식을 잃고 쓰러진 그녀의 곁으로 조심스럽게 다가갑니다.', 'Carefully approach her while she lies unconscious.')
              : T('잠든 그녀의 곁으로 조심스럽게 다가갑니다.', 'Carefully approach her while she sleeps.'),
            onClick: () => api.store.dispatch({ type: OPEN_ACTION }),
          }, 'sleep-actions-open');
          children.push(JSX.jsx('div', {
            className: 'mt-3 grid grid-cols-1 gap-2',
            'data-sleep-actions-entry': '',
            children: entry,
          }, 'sleep-actions-entry'));
        }
        return children.length === originalChildren.length
          ? basePanel : React.cloneElement(basePanel, {}, children);
      },
    });

    api.hook('ClosedDoorActions', {
      around(next, props, ...rest) {
        const state = api.store.game();
        const context = state ? baseSleepPatronContext(state) : null;
        if (!context || props?.room !== context.room) return next(props, ...rest);
        const door = context.data.patronDoor;
        if (door?.customerId === context.customer.id && door.room === context.room
          && door.side === 'inside') return null;
        return patronSceneControls(state, 'outside', context.room, true);
      },
    });

    api.hook('roomSideForOccupant', {
      around(next, state, room, occupantId, ...rest) {
        const door = dataOf(state).patronDoor;
        const isPlayer = occupantId == null || occupantId === 'player';
        const context = baseSleepPatronContext(state);
        if (context && door?.side === 'outside' && door.room === room
          && door.customerId === context.customer.id && context.room === room && isPlayer
          && api.fn('playerLocation')(state) === room) return 'outside';
        return next(state, room, occupantId, ...rest);
      },
    });

    function publicActionDescriptor(value) {
      return Object.freeze({
        description: '',
        eligible: true,
        reason: null,
        ...value,
      });
    }

    function playerChoiceGroup(choiceId) {
      if (choiceId?.startsWith('sleep:finish:')) return 'player-finish';
      if (choiceId?.startsWith('sleep:undress:')) return 'player-undress';
      if (choiceId?.startsWith('sleep:sex:')) return 'player-sex';
      if (choiceId?.startsWith('sleep:act:')) return 'player-touch';
      if (choiceId?.startsWith('sleep:wake:')) return 'player-wake';
      if (choiceId?.startsWith('sleep:morning:')) return 'morning-response';
      if (choiceId?.startsWith('sleep:potion-room:')) return 'potion-room-response';
      return 'player-action';
    }

    function ownedPendingChoices(state) {
      const event = state?.pendingEvent;
      if (!event || !Array.isArray(event.choices)) return [];
      return event.sleepActions || event.sleepActionsMorning || event.sleepActionsPotionRoomNotice
        ? event.choices : [];
    }

    function patronPublicActionLabel(stage) {
      const labels = {
        bold_touch: T('옷 위로 몸을 만지기', 'Touch her over her clothes'),
        groping: T('가슴이나 치마 아래를 만지기', 'Grope her breasts or under her skirt'),
        intimate: T('다리 사이를 손으로 만지기', 'Touch her between the legs'),
        handjob_patron: T('그녀의 손으로 자극받기', 'Use her hand for stimulation'),
        blowjob_patron: T('그녀의 입으로 자극받기', 'Use her mouth for stimulation'),
        rubbing_patron: T('그녀의 몸에 비비기', 'Rub against her body'),
        sex_patron: T('그녀와 성교하기', 'Have sex with her'),
        [PATRON_SELF_STROKE_STAGE]: T('곁에서 자위하기', 'Masturbate beside her'),
      };
      return labels[stage] || stage;
    }

    function patronPublicActionAvailability(state, customerId, stage) {
      if (!state) return { eligible: false, reason: 'state_missing' };
      if (!PATRON_STAGE_ACTIONS[stage]) return { eligible: false, reason: 'action_unknown' };
      const customer = (state.customers || []).find(item => item.id === customerId);
      if (!customer) return { eligible: false, reason: 'customer_missing' };
      if (!settings().patronActionsEnabled) return { eligible: false, reason: 'patron_actions_disabled' };
      if (!isUnconscious(state)) return { eligible: false, reason: 'target_awake' };
      if (state.pendingEvent) return { eligible: false, reason: 'pending_event' };
      if (state.activeScene?.patron || state.activeScene?.sex) {
        return { eligible: false, reason: 'scene_occupied' };
      }
      if (nativePatronFlowOccupied(state)) return { eligible: false, reason: 'native_flow_occupied' };
      if (!eligibleUnconsciousPatrons(state, { customerId }).some(item => item.id === customerId)) {
        return { eligible: false, reason: 'patron_ineligible' };
      }
      if (wifeAndPlayerTogetherInHall(state) && !privateRoomDestination(state, customer)) {
        return { eligible: false, reason: 'private_room_unavailable' };
      }
      const interaction = patronInteractionPreview(state, customer);
      if (!interaction) return { eligible: false, reason: 'interaction_unavailable' };
      const maxStageIndex = patronCalculatedMaxStage(state, customer, interaction);
      const currentSession = dataOf(state).session;
      const continuing = currentSession?.characterId === state.primaryCharacterId
        && currentSession.unconsciousState === unconsciousStateOf(state);
      const availableDepth = continuing
        ? Math.max(0, number(currentSession.depth)) : Math.max(1, settings().initialDepth);
      const style = patronApproachProfile(state, customer).style;
      const plan = stage === PATRON_SELF_STROKE_STAGE
        ? patronSelfStrokePlan(state, customer, interaction, maxStageIndex, availableDepth, style)
        : patronPlanForStage(
          state, customer, interaction, maxStageIndex, availableDepth, null, style, stage,
        );
      return plan
        ? { eligible: true, reason: null, plan }
        : { eligible: false, reason: 'stage_or_depth_ineligible' };
    }

    function publicActionCatalog(state, context = {}) {
      if (!state) return [];
      const includeIneligible = context.includeIneligible !== false;
      const activeChoices = new Map(ownedPendingChoices(state).map(choice => [choice.id, choice]));
      const choices = new Map();
      for (const choice of actionScreenChoices(state)) choices.set(choice.id, choice);
      const session = dataOf(state).session;
      if (session?.currentSexActionId) {
        for (const choice of finishChoices(state)) choices.set(choice.id, choice);
      }
      for (const choice of activeChoices.values()) choices.set(choice.id, choice);

      const result = [];
      result.push(publicActionDescriptor({
        id: 'player:open',
        group: 'player-control',
        label: isPassedOut(state)
          ? T('의식을 잃은 그녀에게 다가가기', 'Approach her while she is unconscious')
          : T('잠든 그녀에게 다가가기', 'Approach her while she sleeps'),
        eligible: canStartPlayerSleepActions(state),
        reason: canStartPlayerSleepActions(state) ? null : 'player_action_unavailable',
      }));
      result.push(publicActionDescriptor({
        id: 'carry:bedroom',
        group: 'player-control',
        label: T('그녀를 침실로 데려가기', 'Carry her to the bedroom'),
        eligible: canCarryUnconsciousWifeToBedroom(state),
        reason: canCarryUnconsciousWifeToBedroom(state) ? null : 'carry_unavailable',
      }));

      for (const choice of choices.values()) {
        const active = activeChoices.get(choice.id);
        const eligible = !!active && active.disabled !== true;
        result.push(publicActionDescriptor({
          id: choice.id,
          group: playerChoiceGroup(choice.id),
          label: choice.label,
          description: choice.description || '',
          eligible,
          reason: eligible ? null : active?.disabled === true ? 'choice_disabled' : 'event_not_open',
        }));
      }

      for (const stage of Object.keys(PATRON_STAGE_ACTIONS)) {
        const availability = patronPublicActionAvailability(state, context.customerId, stage);
        result.push(publicActionDescriptor({
          id: `patron:${stage}`,
          group: 'patron-stage',
          label: patronPublicActionLabel(stage),
          customerId: context.customerId || null,
          stage,
          eligible: availability.eligible,
          reason: availability.reason,
        }));
      }
      return Object.freeze(result.filter(action => includeIneligible || action.eligible));
    }

    function publicActionResult(state, next, actionId, reason = 'conditions_not_met') {
      return next !== state
        ? { state: next, status: 'applied', actionId }
        : { state, status: 'ineligible', reason, actionId };
    }

    function executePublicAction(state, request = {}) {
      const actionId = request.actionId || request.id;
      if (!state) return { state, status: 'invalid', reason: 'state_missing', actionId };
      if (typeof actionId !== 'string') {
        return { state, status: 'invalid', reason: 'action_missing', actionId: null };
      }
      const action = publicActionCatalog(state, {
        customerId: request.customerId,
        includeIneligible: true,
      }).find(item => item.id === actionId);
      if (!action) return { state, status: 'invalid', reason: 'action_unknown', actionId };
      if (!action.eligible) {
        return { state, status: 'ineligible', reason: action.reason, actionId };
      }
      if (actionId === 'player:open') {
        return publicActionResult(state, openPlayerSleepActions(state), actionId);
      }
      if (actionId === 'carry:bedroom') {
        return publicActionResult(state, carrySleepingWifeToBedroom(state), actionId);
      }
      if (actionId.startsWith('patron:')) {
        const stage = actionId.slice('patron:'.length);
        let next = schedulePatronApproach(state, {
          customerId: request.customerId,
          immediate: true,
          forcePrivate: false,
          reason: 'public-action',
          knowsLocation: true,
        });
        if (next === state) return publicActionResult(state, state, actionId);
        next = beginPassedOutPatronFlow(next, { targetStage: stage });
        return publicActionResult(state, next, actionId, 'stage_begin_failed');
      }
      let next = state;
      if (state.pendingEvent?.sleepActions) {
        next = resolvePlayerSleepChoice(state, actionId);
      } else if (state.pendingEvent?.sleepActionsMorning) {
        next = resolveMorningConfrontation(state, actionId);
      } else if (state.pendingEvent?.sleepActionsPotionRoomNotice) {
        next = resolveLegacyPotionRoomNotice(state, actionId);
      }
      return publicActionResult(state, next, actionId, 'event_not_open');
    }

    api.actions.register(OPEN_ACTION, openPlayerSleepActions, {
      label: T('그녀에게 다가가기', 'Approach her'),
    });
    api.actions.register(CARRY_SLEEPING_TO_BED_ACTION, carrySleepingWifeToBedroom, {
      label: T('그녀를 침실로 데려가기', 'Carry her to the bedroom'),
    });
    api.actions.register(PATRON_DOOR_KNOCK_ACTION, (state, action = {}) => (
      performBasePatronDoorCheck(state, 'knock', action.room)
    ), { label: T('노크하기', 'Knock') });
    api.actions.register(PATRON_DOOR_PEEK_ACTION, (state, action = {}) => (
      performBasePatronDoorCheck(state, 'peek', action.room)
    ), { label: T('안을 들여다보기', 'Peek inside') });
    api.actions.register(PATRON_DOOR_OPEN_ACTION, (state, action = {}) => (
      requestOpenBasePatronDoor(state, action.room)
    ), { label: T('문 열기', 'Open the door') });
    api.actions.register(PATRON_QUIET_SEPARATE_ACTION, quietSeparatePatron, {
      label: T('깨우지 않고 조용히 떼어놓기', 'Separate them without waking her'),
    });
    api.actions.register(PATRON_WAKE_INTERVENE_ACTION, startPlayerWakeIntervention, {
      label: T('그녀를 깨우고 개입하기', 'Wake her and intervene'),
    });
    api.actions.register(PATRON_DOOR_LEAVE_ACTION, leavePatronDoor, {
      label: T('물러서기', 'Step away'),
    });
    api.actions.register(FORCE_PASS_OUT_ACTION, forcePassedOutForTest, {
      label: T('그녀를 기절 상태로 만들기 (시험)', 'Put her in a passed-out state (test)'),
    });

    const publicDefinitions = Object.freeze({
      ids: Object.freeze({
        open: OPEN_ACTION,
        carryToBedroom: CARRY_SLEEPING_TO_BED_ACTION,
        forcePassOutForTest: FORCE_PASS_OUT_ACTION,
        patronDoorKnock: PATRON_DOOR_KNOCK_ACTION,
        patronDoorPeek: PATRON_DOOR_PEEK_ACTION,
        patronDoorOpen: PATRON_DOOR_OPEN_ACTION,
        patronQuietSeparate: PATRON_QUIET_SEPARATE_ACTION,
        patronWakeIntervene: PATRON_WAKE_INTERVENE_ACTION,
        patronDoorLeave: PATRON_DOOR_LEAVE_ACTION,
      }),
      player: Object.freeze({
        touchActions: PLAYER_TOUCH_ACTIONS,
        undressActions: PLAYER_UNDRESS_ACTIONS,
        selfPleasureId: PLAYER_SELF_PLEASURE_ID,
        selfPleasureAction: PLAYER_SELF_PLEASURE_ACTION,
        sexActionIds: SEX_ACTION_IDS,
        sexAcceptance: SEX_ACCEPTANCE,
        sexDescriptions: SEX_ACTION_DESCRIPTIONS,
        sexExposureRequirements: SEX_EXPOSURE_REQUIREMENTS,
        finishLabels: FINISH_LABELS,
        selfFinishIds: PLAYER_SELF_FINISH_IDS,
        selfFinishFluidTags: PLAYER_SELF_FINISH_FLUID_TAGS,
      }),
      patron: Object.freeze({
        stages: PATRON_STAGES,
        stageIndex: PATRON_STAGE_INDEX,
        stageActions: PATRON_STAGE_ACTIONS,
        selfStrokeStage: PATRON_SELF_STROKE_STAGE,
        joinSlotStage: PATRON_JOIN_SLOT_STAGE,
        intents: PATRON_INTENTS,
        approachStyles: PATRON_APPROACH_STYLES,
        goalDropWeights: DEFAULT_PATRON_GOAL_DROP_WEIGHTS,
        routePatternWeights: DEFAULT_PATRON_ROUTE_PATTERN_WEIGHTS,
        privateRooms: PATRON_PRIVATE_ROOMS,
        privateFallbackRooms: PATRON_PRIVATE_FALLBACK_ROOMS,
        remoteSearchExcludedRooms: Object.freeze([...PATRON_REMOTE_SEARCH_EXCLUDED_ROOMS]),
        searchChanceRange: Object.freeze({
          min: DEFAULT_PATRON_UNAWARE_SEARCH_MIN_CHANCE,
          max: DEFAULT_PATRON_UNAWARE_SEARCH_MAX_CHANCE,
        }),
        searchIntentModifiers: DEFAULT_PATRON_SEARCH_INTENT_MODIFIERS,
        searchTypeModifiers: DEFAULT_PATRON_SEARCH_TYPE_MODIFIERS,
        searchTacticModifiers: DEFAULT_PATRON_SEARCH_TACTIC_MODIFIERS,
      }),
      rules: Object.freeze({
        actionClasses: ACTION_CLASSES,
        depthRules: DEPTH_RULES,
        actionAffinityKeys: ACTION_AFFINITY_KEYS,
        morningFamiliarityActions: MORNING_FAMILIARITY_ACTIONS,
        morningFinishChanceSettings: MORNING_FINISH_CHANCE_SETTINGS,
      }),
      limits: Object.freeze({
        encounterHistory: ENCOUNTER_HISTORY_LIMIT,
        morningDiscoveryHistory: MORNING_DISCOVERY_HISTORY_LIMIT,
      }),
    });

    const publicApi = Object.freeze({
      apiVersion: 14,
      schemaVersion: SCHEMA_VERSION,
      defaults: DEFAULTS,
      definitions: publicDefinitions,
      actionClasses: ACTION_CLASSES,
      sexActionIds: SEX_ACTION_IDS,
      imagePromptMarkers: IMAGE_PROMPT_MARKERS,
      getSettings: settings,
      updateSettings(patch = {}) { api.settings.set(patch); return settings(); },
      resetSettings() { api.settings.set({ ...DEFAULTS }); return settings(); },
      getState(state = api.store.game()) { return state ? dataOf(state) : null; },
      beginSession,
      endSession,
      calculateDepthCost,
      applySleepAction,
      canStartPlayerSleepActions,
      openPlayerSleepActions,
      resolvePlayerSleepChoice,
      beginPassedOutPatronFlow,
      advancePassedOutPatronFlow,
      forcePassedOutForTest,
      getEncounterHistory,
      getMorningDiscoveryHistory,
      getImagePromptContext,
      state: Object.freeze({
        get(state = api.store.game()) { return state ? dataOf(state) : null; },
        character: characterOf,
        sleepRoom: actualSleepRoom,
        bedSharing: bedSharingAgreement,
        unconsciousState: unconsciousStateOf,
        isSleeping,
        isPassedOut,
        isUnconscious,
        hasLatentTrait,
        morningDisposition,
        sameActionRoom,
      }),
      rules: Object.freeze({
        actionClass: actionClassOf,
        affinityKey: actionAffinityKey,
        depth(actionClass, value = settings()) { return depthRule(value, actionClass); },
        exposureChangeAllowed,
        stableHash,
        weightedIndex,
        finishScene: finishSceneFor,
        finishAcceptance: finishAcceptanceId,
      }),
      actions: Object.freeze({
        classes: ACTION_CLASSES,
        sexIds: SEX_ACTION_IDS,
        touchIds: Object.freeze(Object.keys(PLAYER_TOUCH_ACTIONS)),
        undressIds: Object.freeze(Object.keys(PLAYER_UNDRESS_ACTIONS)),
        selfPleasureId: PLAYER_SELF_PLEASURE_ID,
        classOf: actionClassOf,
        playerDefinition: playerActionDefinition,
        sexDefinition: sexActionDefinition,
        screenChoices: actionScreenChoices,
        finishChoices,
        catalog: publicActionCatalog,
        execute: executePublicAction,
        clothingStatus: playerSexClothingStatus,
        undressCandidates: playerUndressCandidates,
      }),
      session: Object.freeze({
        begin: beginSession,
        end: endSession,
        addDepth: addSessionDepth,
        calculateDepthCost,
        applyAction: applySleepAction,
      }),
      player: Object.freeze({
        canStart: canStartPlayerSleepActions,
        open: openPlayerSleepActions,
        resolveChoice: resolvePlayerSleepChoice,
        event: sleepActionEvent,
        applySelfPleasure: applyPlayerSelfPleasure,
        applyTouch: applyPlayerTouchAction,
        applySex: applyPlayerSexAction,
        applySelfPleasureFinish: applyPlayerSelfPleasureFinish,
        applyFinish: applyPlayerFinish,
        applyExposure: applyExposureChange,
        applyAftermath: applySexAftermath,
        applyOriginalFemaleClimax,
        wifePleasureGain,
        originalWifeArousalGain: originalPlayerWifeArousalGain,
        applyTouchPleasure,
        applySexPleasure,
        finishScene: finishSceneFor,
        finishAcceptance: finishAcceptanceId,
        finishNarration,
        resetAfterFinish,
        undressExposure: playerUndressExposure,
        wakeContext: playerWakeContext,
        wakeSeverity: playerWakeSeverity,
        wakeReactionEffects: playerWakeReactionEffects,
        wakeResponseLine: playerWakeResponseLine,
        openWakeDiscovery: openPlayerWakeDiscovery,
        resolveWakeChoice: resolvePlayerWakeChoice,
      }),
      patron: Object.freeze({
        intentEligible: patronIntentEligible,
        eligible: eligibleUnconsciousPatrons,
        onCooldown: patronOnCooldown,
        cooldownStatus: patronCooldownStatus,
        setCooldown: setPatronCooldown,
        setNextCooldown: setPatronNextCooldown,
        startCooldowns: startPatronCooldowns,
        approachProfile: patronApproachProfile,
        scheduleApproach: schedulePatronApproach,
        begin: beginPassedOutPatronFlow,
        advance: advancePassedOutPatronFlow,
        joinActive: joinActivePatronFlow,
        rentedRoom: patronRentedRoom,
        relationship: patronRelationshipRecord,
        interactionPreview: patronInteractionPreview,
        intimacyContext: patronIntimacyContext,
        actionLine: patronActionLine,
        nativeFlowOccupied: nativePatronFlowOccupied,
        canStartFlow: canStartPatronFlow,
        clearFlow: clearPatronFlowScene,
        returnTransferredTarget: returnTransferredWife,
        discardCurrentMorningIncident,
        registerFlowOwner: registerPatronFlowOwner,
        registerWakeObserver: registerPatronWakeObserver,
        registerSearchResolver: registerPatronSearchResolver,
        stageAction: patronStageAction,
        finishAction: patronFinishAction,
        finishAcceptanceAction: patronFinishAcceptanceAction,
        selfStrokeFinishTarget: patronSelfStrokeFinishTarget,
        finishFluidTags: patronFinishFluidTags,
        calculatedMaxStage: patronCalculatedMaxStage,
        searchIncidentKey: patronSearchIncidentKey,
        unawareSearchChance: patronUnawareSearchChance,
        knowsLocation: patronKnowsUnconsciousLocation,
        routePattern: patronRoutePattern,
        undressRoute: patronUndressRoute,
        route: patronRoute,
        estimatedRouteCost: patronEstimatedRouteCost,
        selfStrokePlan: patronSelfStrokePlan,
        planForStage: patronPlanForStage,
        privateRoomInfo,
        privateRoomAvailable: privateRoomAvailableToPatron,
        emptyPrivateRooms,
        privateRoomDestination,
        participantFromPlan,
        returnRoom: patronReturnRoom,
        roomReturnsFromParticipants: patronRoomReturnsFromParticipants,
        roomReturnsFromSession: patronRoomReturnsFromSession,
        mergeRoomReturns: mergePatronRoomReturns,
        returnPatronsToRecordedRooms,
        cancelApproach: cancelPatronApproach,
        wifeAndPlayerTogetherInHall,
        primarySlot: patronPrimarySlot,
        setScene: setPatronScene,
        finish: finishPassedOutPatronFlow,
        rotatePrimary: rotatePatronPrimary,
      }),
      wake: Object.freeze({
        character: wakeUnconsciousCharacter,
        decision: sleepWakeDecision,
        responseType: sleepWakeResponseType,
        applyPatronResponse: sleepWakeResponse,
        advanceNaturalRecovery: advanceUnconsciousTimeline,
        enforcePassedOutMaximum: advanceUnconsciousTimeline,
        returnRefusalToTaproom: returnRefusedWakeToTaproom,
        resolvePatron: resolvePatronWake,
      }),
      intervention: Object.freeze({
        context: baseSleepPatronContext,
        doorMatches: patronDoorMatches,
        side: playerPatronSceneSide,
        inside: insideBaseSleepPatronContext,
        approachDoor: approachBasePatronDoor,
        leaveDoor: leavePatronDoor,
        reconcileDoor: reconcilePatronDoor,
        checkDoor: performBasePatronDoorCheck,
        openDoor: requestOpenBasePatronDoor,
        quietSeparate: quietSeparatePatron,
        adjustedWakeAcceptance,
        adjustedExplanationBelief,
        normalizeAwakeAvailability,
        finishWake: finishPlayerWakeIntervention,
        startWake: startPlayerWakeIntervention,
        resolveChoice: resolvePlayerInterventionChoice,
        handOffAwakeScene: handOffAwakePatronScene,
        finalizeReturn: finalizePendingInterventionReturn,
      }),
      records: Object.freeze({
        actionAffinityKey,
        recordUnawareActionExposure,
        appendUnawareIntimateHistory,
        queueMorningEvidence,
        queueLowFamiliarityEvidence,
        queueFinishEvidence,
        discardCurrentMorningIncident,
        markCurrentMorningIncidentReady,
        recordFinishCompleted,
        morningIncidentId,
        currentMorningIncidentMatches,
        appendMorningDiscoveryHistory,
        removeMorningIncident,
        applyRecognizedActionPreference,
      }),
      morning: Object.freeze({
        evidenceScore: morningEvidenceScore,
        strongestEvidence: strongestMorningEvidence,
        noticeChance: morningNoticeChance,
        confrontChance: morningConfrontChance,
        disposition: morningDisposition,
        severity: morningSeverity,
        privateOutcome: morningPrivateOutcome,
        confrontOutcome: morningConfrontOutcome,
        applyOutcomeEffects: applyMorningOutcomeEffects,
        confrontationEvent: morningConfrontationEvent,
        patronFinishCount: patronMorningFinishCount,
        patronReaction: patronMorningReaction,
        patronOutcome: patronMorningOutcome,
        resolvePatronIncident: resolvePatronMorningIncident,
        resolvePending: maybeResolveMorningIncident,
        resolveChoice: resolveMorningConfrontation,
      }),
      timeline: Object.freeze({
        advanceDay,
        advanceSleepMinute,
        advanceUnconscious: advanceUnconsciousTimeline,
        settleNaturalWake: settleNaturalSleepWake,
        enforcePassedOutMaximum: advanceUnconsciousTimeline,
        settlePendingPatronRoomReturns,
      }),
      narration: Object.freeze({
        playerAction: playerActionLine,
        patronAction: patronActionLine,
        unconsciousReaction: unconsciousReactionLine,
        patronFinish: patronFinishLine,
        playerFinish: finishNarration,
        morningEvidence: morningEvidencePhrase,
        morningUnnoticed: morningUnnoticedLine,
        morningConfrontation: morningConfrontationText,
        morningPrivateReaction: morningPrivateReactionLine,
        morningResponse: morningResponseLine,
        patronMorningCount: patronMorningCountLine,
        patronMorningReaction: patronMorningReactionLine,
        interventionResult: interventionResultLine,
      }),
      carry: Object.freeze({
        canCarryToBedroom: canCarryUnconsciousWifeToBedroom,
        toBedroom: carrySleepingWifeToBedroom,
        returnPlayerToTaproom,
      }),
      history: Object.freeze({
        encounters: getEncounterHistory,
        morningDiscoveries: getMorningDiscoveryHistory,
      }),
      images: Object.freeze({
        markers: IMAGE_PROMPT_MARKERS,
        active: activeSleepImage,
        promptContext: getImagePromptContext,
        setAction: setSleepActionImage,
        setFinish: setFinishImage,
        clear: clearSleepActionImage,
        resetAfterFinish,
      }),
      events: Object.freeze({
        types: Object.freeze(['actionCompleted', 'finishCompleted', 'sessionEnded']),
        on(type, listener) {
          if (typeof listener !== 'function') throw new TypeError('listener must be a function');
          const set = listeners.get(type) || new Set();
          set.add(listener);
          listeners.set(type, set);
          return () => set.delete(listener);
        },
      }),
    });
    api.provide(publicApi);

    function row(label, value) {
      return h('div', { style: 'display:flex;justify-content:space-between;gap:16px;margin:7px 0' },
        h('span', { class: 'wml-muted' }, label), h('strong', {}, value));
    }

    function renderStatus(body) {
      const state = api.store.game();
      if (!state) {
        body.append(h('div', { class: 'wml-note' }, T('게임을 시작하면 수면 상태를 표시합니다.', 'Start a game to see sleep status.')));
        return;
      }
      const data = dataOf(state);
      const session = data.session;
      const normalDepthCap = settings().normalDepthCap;
      body.append(h('section', { class: 'wml-section' },
        h('h3', { style: 'margin:0 0 10px' }, T('수면 상태', 'Sleep status')),
        row(T('세션', 'Session'), session ? T('진행 중', 'Active') : T('없음', 'Inactive')),
        session ? row(T('종류', 'Type'), session.kind === 'patron'
          ? T('손님 자동 행동', 'Automatic patron action') : T('플레이어 행동', 'Player action')) : null,
        session?.patronApproach ? row(T('손님 상태', 'Patron state'), T('주변을 살피는 중', 'Watching for an opening')) : null,
        session ? row(T('수면 심도', 'Sleep depth'), `${Math.round(session.depth * 10) / 10} / ${normalDepthCap}`) : null,
        session ? h('div', { style: 'height:10px;background:#292524;border-radius:999px;overflow:hidden' },
          h('div', { style: `height:100%;width:${clamp(session.depth / normalDepthCap * 100, 0, 100)}%;background:#7c3aed` })) : null,
        session?.lastActionKey ? row(T('최근 행동', 'Last action'), session.lastActionKey) : null,
        h('p', { class: 'wml-note', style: 'margin:12px 0 0' }, T(
          '그녀가 잠들어 있으면 곁으로 다가갈 수 있습니다. 관심을 보이던 손님들도 주변의 눈을 살핀 뒤 조심스럽게 접근할 수 있습니다.',
          'You can approach her while she sleeps. Patrons who have shown interest may also watch for prying eyes before moving closer.',
        )),
        h('button', {
          type: 'button',
          style: 'margin-top:12px;width:100%;padding:8px;border:1px solid #991b1b;border-radius:6px;background:#292524;color:#fecaca;cursor:pointer',
          onclick: () => api.store.dispatch({ type: FORCE_PASS_OUT_ACTION }),
        }, T('그녀를 기절 상태로 만들기 (시험)', 'Put her in a passed-out state (test)')),
      ));
    }

    function openStatus() {
      statusWindow = api.ui.window({
        id: 'status', title: T('수면 중 행동', 'Sleep actions'), width: 520, height: 390,
        render: renderStatus, onClose: () => { statusWindow = null; },
      });
    }
    api.ui.addButton({ label: '🌙', title: T('수면 중 행동', 'Sleep actions'), onClick: openStatus });
    api.store.subscribe(() => statusWindow?.refresh());

    api.ui.settings((body, win) => {
      const value = settings();
      const section = (title, ...children) => h('section', { class: 'wml-section', style: 'margin-bottom:12px' },
        h('h3', { style: 'margin:0 0 9px' }, title), ...children);
      const numberRow = (key, label, min, step, note = '') => {
        const attributes = {
          type: 'number', step, value: value[key],
          'data-sleep-actions-setting': key,
          style: 'width:100px;padding:5px;background:#292524;color:#fafaf9;border:1px solid #78716c;border-radius:5px',
          onchange: event => { api.settings.set({ [key]: Number(event.target.value) }); win.refresh(); },
        };
        if (min != null) attributes.min = min;
        const input = h('input', attributes);
        return h('label', { style: 'display:grid;grid-template-columns:1fr 100px minmax(150px,auto);gap:10px;align-items:center;margin:7px 0' },
          h('span', {}, label), input, h('span', { class: 'wml-muted', style: 'font-size:.85em;text-align:right' }, note));
      };
      const checkboxRow = (key, label) => h('label', { style: 'display:flex;gap:8px;align-items:center;margin:7px 0' },
        h('input', {
          type: 'checkbox', checked: value[key] === true,
          'data-sleep-actions-setting': key,
          onchange: event => { api.settings.set({ [key]: !!event.target.checked }); win.refresh(); },
        }), h('span', {}, label));
      body.append(
        section(T('수면 심도', 'Sleep depth'),
          numberRow('initialDepth', T('시작 수면 심도', 'Initial depth'), 1, 1),
          numberRow('normalDepthCap', T('일반 회복 상한·게이지 기준', 'Normal recovery cap and gauge scale'), 1, 1),
          numberRow('recoveryPerMinuteMin', T('1분당 회복 최소값', 'Minimum recovery per minute'), 0, 0.1),
          numberRow('recoveryPerMinuteMax', T('1분당 회복 최대값', 'Maximum recovery per minute'), 0, 0.1),
          numberRow('repeatWindowMinutes', T('같은 행동 연속 판정 시간', 'Repeat window'), 0, 1, T('분', 'minutes')),
          numberRow('sameActionMultiplier', T('연속 행동 소모 배율', 'Repeat cost multiplier'), 0, 0.05),
          numberRow('minimumDepthCost', T('행동 1회 최소 심도 감소', 'Minimum depth loss per action'), 0, 0.1),
          numberRow('passedOutDepthMultiplier', T('기절 중 최종 심도 감소 배율', 'Final depth-loss multiplier while passed out'), 0, 0.05),
          numberRow('unconsciousRecoveryDelayMinutes', T('예정 시각 없는 의식 회복 최소 휴식', 'Minimum rest before unscheduled recovery'), 0, 1, T('분', 'minutes')),
          numberRow('wakeDepthLossMin', T('점진 기상 심도 감소 최소', 'Minimum gradual wake depth loss'), 0, 0.1, T('1분당', 'per minute')),
          numberRow('wakeDepthLossMax', T('점진 기상 심도 감소 최대', 'Maximum gradual wake depth loss'), 0, 0.1, T('1분당', 'per minute'))),
        section(T('행동군별 수면 심도 소모', 'Sleep-depth cost by action group'),
          numberRow('acceptanceDeficitRatio', T('공통 수용도 부족분 반영률', 'Shared acceptance-deficit ratio'), 0, 0.01),
          numberRow('lightTouchDepthMin', T('가벼운 접촉 · 최소 감소', 'Light touch · minimum loss'), 0, 0.1),
          numberRow('lightTouchDepthMax', T('가벼운 접촉 · 최대 감소', 'Light touch · maximum loss'), 0, 0.1),
          numberRow('intimateTouchDepthMin', T('은밀한 접촉 · 최소 감소', 'Intimate touch · minimum loss'), 0, 0.1),
          numberRow('intimateTouchDepthMax', T('은밀한 접촉 · 최대 감소', 'Intimate touch · maximum loss'), 0, 0.1),
          numberRow('manualOralDepthMin', T('손·구강 행위 · 최소 감소', 'Manual/oral · minimum loss'), 0, 0.1),
          numberRow('manualOralDepthMax', T('손·구강 행위 · 최대 감소', 'Manual/oral · maximum loss'), 0, 0.1),
          numberRow('rubbingDepthMin', T('몸 비비기 · 최소 감소', 'Body rubbing · minimum loss'), 0, 0.1),
          numberRow('rubbingDepthMax', T('몸 비비기 · 최대 감소', 'Body rubbing · maximum loss'), 0, 0.1),
          numberRow('sexDepthMin', T('성교 · 최소 감소', 'Sex · minimum loss'), 0, 0.1),
          numberRow('sexDepthMax', T('성교 · 최대 감소', 'Sex · maximum loss'), 0, 0.1),
          numberRow('finishDepthMin', T('사정 관련 · 최소 감소', 'Finishing · minimum loss'), 0, 0.1),
          numberRow('finishDepthMax', T('사정 관련 · 최대 감소', 'Finishing · maximum loss'), 0, 0.1),
          h('p', { class: 'wml-note' }, T(
            '최대 감소를 최소 감소보다 작게 입력하면 계산에서는 최소 감소와 같은 값으로 처리합니다.',
            'If a maximum loss is set below its minimum, calculations use the minimum for both.',
          ))),
        section(T('손님 자동 행동', 'Automatic patron actions'),
          checkboxRow('patronActionsEnabled', T('잠든·기절한 대상에게 손님이 자동으로 접근', 'Allow patrons to approach a sleeping or passed-out target')),
          numberRow('patronMinimumBoldness', T('기상 위험을 감수할 최소 대담함', 'Minimum boldness to accept wake-up risk'), 0, 1),
          numberRow('patronDepthEstimateVariance', T('예상 심도 소모 오차율', 'Projected depth-cost error rate'), 0, 0.01, T('기본 0.2 = ±20%', 'Default 0.2 = ±20%')),
          numberRow('patronCooldownMinutes', T('손님별 재접근 대기', 'Per-patron reapproach cooldown'), 0, 1, T('분', 'minutes')),
          numberRow('patronWatchMinMinutes', T('접근 전 눈치보기 최소', 'Minimum watch time before approach'), 0, 1, T('분', 'minutes')),
          numberRow('patronWatchMaxMinutes', T('접근 전 눈치보기 최대', 'Maximum watch time before approach'), 0, 1, T('분', 'minutes')),
          numberRow('patronUnawareSearchBaseChance', T('비목격 손님의 탐색 기준 확률', 'Base search chance for an unwitnessed target'), 0, 1, '%'),
          numberRow('patronUnawareSearchMinimum', T('비목격 탐색 최종 하한', 'Final unwitnessed-search floor'), null, 1, '%'),
          numberRow('patronUnawareSearchMaximum', T('비목격 탐색 최종 상한', 'Final unwitnessed-search ceiling'), null, 1, '%'),
          numberRow('patronNonFinishMinTicks', T('사정 없는 행동 최소 유지', 'Minimum ticks for non-finishing acts'), 0, 1, T('틱', 'ticks')),
          numberRow('patronPrivateMoveChance', T('은밀한 장소 선호 확률', 'Chance to prefer a private room'), 0, 1, '%'),
          numberRow('patronRiskyFinishBoldness', T('위험한 사정 방식을 고를 대담함', 'Boldness threshold for risky finishes'), null, 1),
          h('p', { class: 'wml-note' }, T(
            '비목격 탐색은 아래 능력치·목표·유형·전술 보정을 모두 적용한 뒤 설정한 하한과 상한으로 제한합니다. 같은 수면·기절 사건에서는 손님별 결과가 바뀌지 않습니다.',
            'Unwitnessed searches apply all attribute, intent, type, and tactic modifiers below, then clamp to the configured floor and ceiling. Each patron keeps the same result during one sleep or blackout incident.',
          ))),
        section(T('비목격 탐색 능력치 계산', 'Unwitnessed-search attributes'),
          numberRow('patronSearchAbilityCenter', T('능력치 기준점', 'Attribute center'), null, 1),
          numberRow('patronSearchAbilityInfluence', T('능력치 차이 반영률', 'Attribute-difference influence'), null, 0.05),
          numberRow('patronSearchWitWeight', T('재치 가중치', 'Wit weight'), 0, 0.05),
          numberRow('patronSearchComposureWeight', T('침착성 가중치', 'Composure weight'), 0, 0.05),
          numberRow('patronSearchBoldnessWeight', T('대담함 가중치', 'Boldness weight'), 0, 0.05),
          numberRow('patronSearchCharmWeight', T('매력 가중치', 'Charm weight'), 0, 0.05),
          h('p', { class: 'wml-note' }, T(
            '가중치는 자동으로 합계에 맞춰 비율화합니다. 전부 0이면 네 능력치를 같은 비율로 사용합니다.',
            'Weights are normalized by their total. If all are zero, the four attributes are weighted equally.',
          ))),
        section(T('비목격 탐색 목표·유형 보정', 'Search intent and patron-type modifiers'),
          numberRow('patronSearchInterestedModifier', T('관심 있음 목표', 'Interested intent'), null, 1),
          numberRow('patronSearchPredatoryModifier', T('약탈적 목표', 'Predatory intent'), null, 1),
          numberRow('patronSearchRegularModifier', T('일반 손님', 'Regular patron'), null, 1),
          numberRow('patronSearchCharmerModifier', T('매력가', 'Charmer'), null, 1),
          numberRow('patronSearchDrunkBoldModifier', T('취한 대담가', 'Drunk and bold'), null, 1),
          numberRow('patronSearchNoblemanModifier', T('귀족', 'Nobleman'), null, 1),
          numberRow('patronSearchRogueModifier', T('불한당', 'Rogue'), null, 1),
          numberRow('patronSearchWealthyPervertModifier', T('부유한 변태', 'Wealthy pervert'), null, 1)),
        section(T('비목격 탐색 접근 전술 보정', 'Search tactic modifiers'),
          numberRow('patronSearchWarmBuilderModifier', T('친근한 관계 쌓기', 'Warm builder'), null, 1),
          numberRow('patronSearchSmoothCharmerModifier', T('능숙한 유혹', 'Smooth charmer'), null, 1),
          numberRow('patronSearchDrinkPusherModifier', T('술 권하기', 'Drink pusher'), null, 1),
          numberRow('patronSearchLapGrabberModifier', T('무릎에 끌어당기기', 'Lap grabber'), null, 1),
          numberRow('patronSearchTransactionalModifier', T('거래형 접근', 'Transactional'), null, 1)),
        section(T('손님 접근 유형 가중치', 'Patron approach-style weights'),
          numberRow('patronStyleCautiousWeight', T('조심형 가중치', 'Cautious weight'), 0, 0.1),
          numberRow('patronStyleTeasingWeight', T('희롱형 가중치', 'Teasing weight'), 0, 0.1),
          numberRow('patronStyleDirectWeight', T('직접형 가중치', 'Direct weight'), 0, 0.1),
          numberRow('patronStyleOpportunisticWeight', T('기회주의형 가중치', 'Opportunistic weight'), 0, 0.1),
          numberRow('patronStyleSecretiveWeight', T('은밀형 가중치', 'Secretive weight'), 0, 0.1),
          h('p', { class: 'wml-note' }, T(
            '가중치가 클수록 해당 접근 유형이 자주 선택됩니다. 전부 0이면 다섯 유형을 같은 비율로 고릅니다.',
            'Larger weights make that approach style more common. If all are zero, all five styles are equally likely.',
          ))),
        section(T('손님 기상 위험 대담함 보정', 'Patron wake-risk boldness modifiers'),
          numberRow('patronRiskPredatoryBonus', T('약탈적 목적 보정', 'Predatory-intent modifier'), null, 1),
          numberRow('patronRiskCautiousBonus', T('조심형 보정', 'Cautious-style modifier'), null, 1),
          numberRow('patronRiskTeasingBonus', T('희롱형 보정', 'Teasing-style modifier'), null, 1),
          numberRow('patronRiskDirectBonus', T('직접형 보정', 'Direct-style modifier'), null, 1),
          numberRow('patronRiskOpportunisticBonus', T('기회주의형 보정', 'Opportunistic-style modifier'), null, 1),
          numberRow('patronRiskSecretiveBonus', T('은밀형 보정', 'Secretive-style modifier'), null, 1),
          h('p', { class: 'wml-note' }, T(
            '손님의 대담함에 더한 뒤 위의 기상 위험 기준과 비교합니다. 음수도 사용할 수 있습니다.',
            'These values are added to patron boldness before comparing it with the wake-risk threshold. Negative values are allowed.',
          ))),
        section(T('손님 목표 단계 가중치', 'Patron target-stage weights'),
          numberRow('patronGoalMaximumWeight', T('계산된 최고 단계', 'Calculated maximum stage'), 0, 1),
          numberRow('patronGoalOneBelowWeight', T('최고 단계보다 한 단계 아래', 'One stage below maximum'), 0, 1),
          numberRow('patronGoalTwoBelowWeight', T('최고 단계보다 두 단계 아래', 'Two stages below maximum'), 0, 1),
          h('p', { class: 'wml-note' }, T(
            '손님이 가능한 최고 단계까지 항상 밀어붙이지 않도록 목표 단계를 고르는 상대 가중치입니다.',
            'These relative weights choose a target stage so patrons do not always push to their calculated maximum.',
          ))),
        section(T('손님 행동 경로 가중치', 'Patron action-route weights'),
          numberRow('patronRouteFocusedWeight', T('목표 집중형', 'Focused'), 0, 1),
          numberRow('patronRouteUpperTourWeight', T('상체 경유형', 'Upper-body tour'), 0, 1),
          numberRow('patronRouteLowerTourWeight', T('하체 경유형', 'Lower-body tour'), 0, 1),
          numberRow('patronRouteFullTourWeight', T('전신 경유형', 'Full-body tour'), 0, 1),
          numberRow('patronRouteFullLowerFocusWeight', T('전신·하체 집중형', 'Full tour with lower-body focus'), 0, 1),
          h('p', { class: 'wml-note' }, T(
            '목표 단계에 이르는 중간 행동 순서를 고르는 상대 가중치입니다. 전부 0이면 같은 비율로 고릅니다.',
            'These relative weights choose the intermediate action route toward the target stage. If all are zero, routes are equally likely.',
          ))),
        section(T('손님 최고 행동 단계 보정', 'Patron maximum-stage modifiers'),
          numberRow('patronStageComfortThreshold', T('편안함 기준', 'Comfort threshold'), null, 1),
          numberRow('patronStageComfortBonus', T('편안함 충족 단계 보정', 'Comfort stage bonus'), null, 1),
          numberRow('patronStageArousalThreshold', T('흥분 기준', 'Arousal threshold'), null, 1),
          numberRow('patronStageArousalBonus', T('흥분 충족 단계 보정', 'Arousal stage bonus'), null, 1),
          numberRow('patronStageIntoxicationThreshold', T('취기 기준', 'Intoxication threshold'), null, 1),
          numberRow('patronStageIntoxicationBonus', T('취기 충족 단계 보정', 'Intoxication stage bonus'), null, 1),
          numberRow('patronStageFullExposureBonus', T('상·하체 모두 노출 단계 보정', 'Full exposure stage bonus'), null, 1),
          numberRow('patronStagePartialExposureBonus', T('상·하체 한쪽 노출 단계 보정', 'Partial exposure stage bonus'), null, 1),
          numberRow('patronStageSkirtOffBonus', T('치마 벗음 단계 보정', 'Skirt-off stage bonus'), null, 1),
          numberRow('patronStageInterestedBoldnessThreshold', T('관심형 대담함 1차 기준', 'Interested boldness threshold'), null, 1),
          numberRow('patronStageInterestedBoldnessBonus', T('관심형 1차 단계 보정', 'Interested stage bonus'), null, 1),
          numberRow('patronStageInterestedHighBoldnessThreshold', T('관심형 대담함 2차 기준', 'Interested high-boldness threshold'), null, 1),
          numberRow('patronStageInterestedHighBoldnessBonus', T('관심형 2차 단계 보정', 'Interested high-boldness stage bonus'), null, 1)),
        section(T('수면 중 기상·개입 판정', 'Wake and intervention checks'),
          numberRow('patronWakeAcceptancePenalty', T('깨어난 직후 현재 행위 수용 감점', 'Current-act acceptance penalty after waking'), null, 1),
          numberRow('patronExplanationBeliefBonus', T('상황 설명을 믿을 가점', 'Explanation-belief bonus'), null, 1),
          numberRow('patronExplanationEagerMargin', T('설명을 쉽게 믿을 여유값', 'Ready-belief margin'), null, 1),
          numberRow('patronExplanationEmphaticMargin', T('설명을 강하게 불신할 부족값', 'Strong-disbelief deficit'), null, 1),
          numberRow('patronInterventionInfluenceMargin', T('관계 영향력 요구 여유값', 'Relationship-influence margin'), null, 1),
          numberRow('patronInterventionInfluenceScale', T('관계 영향력 요구 환산폭', 'Relationship-influence scale'), 0.01, 1),
          h('p', { class: 'wml-note' }, T(
            '현재 행위 수용과 당신의 상황 설명을 믿을지를 각각 한 번 판정합니다. 설명을 믿지 않더라도 관계 영향력이 충분하면 같은 설명 뒤에 마지못해 중단하며, 부족하면 두고 나가거나 강제로 떼어놓을 수 있습니다.',
            'The current act and belief in your explanation are checked once each. Even if she doubts you, sufficient relationship influence can make her stop after that same explanation; otherwise you can leave them alone or separate them by force.',
          ))),
        section(T('아침 행위 흔적 발견률', 'Morning act-evidence chances'),
          numberRow('morningActionBlowjobChance', T('입으로 해준 행위', 'Oral giving'), null, 1, '%'),
          numberRow('morningActionDeepthroatChance', T('깊은 구강 행위', 'Deepthroat'), null, 1, '%'),
          numberRow('morningActionCunnilingusChance', T('입으로 받은 행위', 'Oral receiving'), null, 1, '%'),
          numberRow('morningActionSexChance', T('질 성교', 'Vaginal sex'), null, 1, '%'),
          numberRow('morningActionDoggyChance', T('뒤에서 한 성교', 'Sex from behind'), null, 1, '%'),
          numberRow('morningActionAnalFingeringChance', T('항문 손가락 행위', 'Anal fingering'), null, 1, '%'),
          numberRow('morningActionAnalChance', T('항문 성교', 'Anal sex'), null, 1, '%'),
          numberRow('morningLowFamiliarityThreshold', T('흔적으로 남기는 익숙함 상한', 'Familiarity threshold for evidence'), 0, 0.25),
          h('p', { class: 'wml-note' }, T(
            '원본 익숙함이 설정한 값보다 낮은 행위만 아침 증거가 됩니다.',
            'Only acts below the configured original-familiarity value become morning evidence.',
          ))),
        section(T('아침 사정 흔적 발견률', 'Morning finish-evidence chances'),
          numberRow('morningFinishFaceChance', T('얼굴', 'Face'), null, 1, '%'),
          numberRow('morningFinishBreastsChance', T('가슴', 'Breasts'), null, 1, '%'),
          numberRow('morningFinishBodyChance', T('몸', 'Body'), null, 1, '%'),
          numberRow('morningFinishMouthChance', T('입안', 'Mouth'), null, 1, '%'),
          numberRow('morningFinishVaginalChance', T('질내', 'Vaginal'), null, 1, '%'),
          numberRow('morningFinishAnalChance', T('항문 내부', 'Anal'), null, 1, '%')),
        section(T('아침 발견률 계산 보정', 'Morning discovery modifiers'),
          numberRow('morningRepeatEvidenceBonus', T('같은 증거 반복 1회당 보정', 'Bonus per repeated evidence'), null, 1),
          numberRow('morningRepeatEvidenceCap', T('같은 증거 반복 보정 상한', 'Repeated-evidence bonus cap'), null, 1),
          numberRow('morningSecondaryEvidenceBonus', T('추가 증거 1종당 보정', 'Bonus per additional evidence type'), null, 1),
          numberRow('morningSecondaryEvidenceCap', T('추가 증거 보정 상한', 'Additional-evidence bonus cap'), null, 1),
          numberRow('morningNoticeWitWeight', T('대상 재치 1점당 보정', 'Modifier per target wit point'), null, 0.01),
          numberRow('morningNoticeComposureWeight', T('대상 침착성 1점당 보정', 'Modifier per target composure point'), null, 0.01),
          numberRow('morningNoticeMinimum', T('최종 발견률 하한', 'Final discovery chance floor'), null, 1, '%'),
          numberRow('morningNoticeMaximum', T('최종 발견률 상한', 'Final discovery chance ceiling'), null, 1, '%'),
          h('p', { class: 'wml-note' }, T(
            '재치와 침착성은 50을 기준으로 보정합니다. 상한과 하한을 거꾸로 입력해도 계산에서 자동으로 정렬합니다.',
            'Wit and composure modifiers are centered on 50. Reversed floor and ceiling values are sorted during calculation.',
          ))),
        section(T('아침 추궁 확률 계산', 'Morning confrontation chance'),
          numberRow('morningConfrontBaseChance', T('기본 추궁 확률', 'Base confrontation chance'), null, 1, '%'),
          numberRow('morningConfrontConfidenceWeight', T('자신감 1점당 보정', 'Modifier per confidence point'), null, 0.01),
          numberRow('morningConfrontHonestyWeight', T('정직성 1점당 보정', 'Modifier per honesty point'), null, 0.01),
          numberRow('morningConfrontComposureWeight', T('침착성 1점당 보정', 'Modifier per composure point'), null, 0.01),
          numberRow('morningConfrontTrustWeight', T('신뢰 1점당 보정', 'Modifier per trust point'), null, 0.01),
          numberRow('morningConfrontResentmentWeight', T('원망 1점당 보정', 'Modifier per resentment point'), null, 0.01),
          numberRow('morningConfrontMinimum', T('최종 추궁률 하한', 'Final confrontation chance floor'), null, 1, '%'),
          numberRow('morningConfrontMaximum', T('최종 추궁률 상한', 'Final confrontation chance ceiling'), null, 1, '%')),
        section(T('아침 추궁 성향 보정', 'Morning confrontation trait modifiers'),
          numberRow('morningConfrontDominantBonus', T('지배적 성향', 'Dominant'), null, 1),
          numberRow('morningConfrontSelfProtectiveBonus', T('자기보호 성향', 'Self-protective'), null, 1),
          numberRow('morningConfrontPrudeBonus', T('금욕적 성향', 'Prudish'), null, 1),
          numberRow('morningConfrontPragmatistBonus', T('냉정한 실리 성향', 'Cold pragmatist'), null, 1),
          numberRow('morningConfrontPressureBonus', T('압박에 약한 성향', 'Breaks under pressure'), null, 1),
          numberRow('morningConfrontSubmissiveBonus', T('복종적 성향', 'Submissive'), null, 1),
          numberRow('morningConfrontCorruptionBonus', T('타락 욕구 성향', 'Wants corruption'), null, 1),
          numberRow('morningConfrontGuiltBonus', T('죄책감 성애화 성향', 'Guilt eroticizer'), null, 1),
          numberRow('morningConfrontRomanceBonus', T('애정 결핍 성향', 'Romance-starved'), null, 1),
          h('p', { class: 'wml-note' }, T(
            '양수는 추궁 가능성을 높이고 음수는 낮춥니다.',
            'Positive values raise confrontation chance; negative values lower it.',
          ))),
        section(T('아침 부인 성공 확률', 'Morning denial success chance'),
          numberRow('morningDenialBaseChance', T('기본 믿을 확률', 'Base chance she believes the denial'), null, 1, '%'),
          numberRow('morningDenialCunningWeight', T('플레이어 교활함 1점당 보정', 'Modifier per player cunning point'), null, 0.01),
          numberRow('morningDenialWitWeight', T('대상 재치 1점당 감점', 'Penalty per target wit point'), null, 0.01),
          numberRow('morningDenialConfidenceWeight', T('대상 자신감 1점당 감점', 'Penalty per target confidence point'), null, 0.01),
          numberRow('morningDenialMinimum', T('최종 성공률 하한', 'Final success chance floor'), null, 1, '%'),
          numberRow('morningDenialMaximum', T('최종 성공률 상한', 'Final success chance ceiling'), null, 1, '%'),
          h('p', { class: 'wml-note' }, T(
            '교활함·재치·자신감은 50을 기준으로 보정합니다.',
            'Cunning, wit, and confidence modifiers are centered on 50.',
          ))),
        section(T('수면 전용 기록', 'Sleep-only records'),
          h('p', { class: 'wml-note' }, T(
            '사정이 끝난 사건은 대상이 알지 못한 수면 전용 이력으로 저장합니다. 원본 친밀행위 이력과 행동기억은 바꾸지 않습니다.',
            'Completed finishes are stored as sleep-only encounters that she did not perceive. Original intimate history and action memory remain unchanged.',
          ))),
      );
    });
    try {
      const aip = api.use('attention-image-prompt');
      if (aip?.version === 1 && typeof aip.register === 'function'
        && typeof aip.resolve === 'function' && typeof aip.cacheToken === 'function') {
        const sleepBedEntries = [
          {
            id: `sleep-${AIP_SLEEP_LEVELS[0]}`,
            label: T('얕은 잠 · 곧 깨어남', 'Light sleep · close to waking'),
            hook: 'imagePrompt / imageKey',
            positivePrompt: '(closed eyes:1.35), (woman lying down in bed:1.35), head on pillow, drowsy sleeping expression, slight stirring',
            negativePrompt: 'open eyes, wide eyes, looking at viewer, eye contact, standing woman, sitting woman, kneeling woman, cowgirl',
          },
          {
            id: `sleep-${AIP_SLEEP_LEVELS[1]}`,
            label: T('보통 잠', 'Middle sleep'),
            hook: 'imagePrompt / imageKey',
            positivePrompt: '(closed eyes:1.45), (woman lying down in bed:1.35), head on pillow, asleep, relaxed sleeping face, slow breathing',
            negativePrompt: 'open eyes, wide eyes, looking at viewer, eye contact, standing woman, sitting woman, kneeling woman, cowgirl',
          },
          {
            id: `sleep-${AIP_SLEEP_LEVELS[2]}`,
            label: T('깊은 잠', 'Deep sleep'),
            hook: 'imagePrompt / imageKey',
            positivePrompt: '(closed eyes:1.55), (woman lying down in bed:1.35), head on pillow, deep sleep, peaceful sleeping face, still posture',
            negativePrompt: 'open eyes, wide eyes, looking at viewer, eye contact, standing woman, sitting woman, kneeling woman, cowgirl',
          },
        ];
        const blackoutBedEntries = [
          {
            id: `blackout-${AIP_SLEEP_LEVELS[0]}`,
            label: T('만취 기절 · 얕은 심도', 'Alcohol blackout · light depth'),
            hook: 'imagePrompt / imageKey',
            positivePrompt: '(closed eyes:1.35), (woman lying down in bed:1.35), head on pillow, heavily drunk, passed out, faint stirring',
            negativePrompt: 'open eyes, wide eyes, looking at viewer, eye contact, standing woman, kneeling woman',
          },
          {
            id: `blackout-${AIP_SLEEP_LEVELS[1]}`,
            label: T('만취 기절 · 보통 심도', 'Alcohol blackout · middle depth'),
            hook: 'imagePrompt / imageKey',
            positivePrompt: '(closed eyes:1.45), (woman lying down in bed:1.35), head on pillow, heavily drunk, passed out, slack expression, slow breathing',
            negativePrompt: 'open eyes, wide eyes, looking at viewer, eye contact, standing woman, kneeling woman',
          },
          {
            id: `blackout-${AIP_SLEEP_LEVELS[2]}`,
            label: T('만취 기절 · 깊은 심도', 'Alcohol blackout · deep depth'),
            hook: 'imagePrompt / imageKey',
            positivePrompt: '(closed eyes:1.55), (woman lying down in bed:1.35), head on pillow, heavily drunk, passed out, motionless posture, slow breathing',
            negativePrompt: 'open eyes, wide eyes, looking at viewer, eye contact, standing woman, kneeling woman',
          },
        ];
        const outsideEntries = entries => entries.map(entry => ({
          ...entry,
          id: entry.id.replace(/^([^-]+)-/, '$1-elsewhere-'),
          label: `${T('침대 밖', 'Outside bed')} · ${entry.label}`,
          positivePrompt: aipPromptOutsideBed(entry.positivePrompt),
          negativePrompt: aipPromptOutsideBed(entry.negativePrompt, true),
        }));
        aip.register({
          id: ID,
          title: T('수면 중 행동 · 이미지', 'Sleep Actions · images'),
          note: T('실제 수면·기절 행동 장면에서 침대 안팎과 심도에 맞는 항목을 적용합니다.',
            'Applies the matching depth and bed-location entry to active sleep or passed-out scenes.'),
          entries: [
            ...sleepBedEntries,
            ...outsideEntries(sleepBedEntries),
            ...blackoutBedEntries,
            ...outsideEntries(blackoutBedEntries),
          ],
        });
        attentionImagePrompt = aip;
      }
    } catch (error) {
      api.warn?.(`Sleep Actions AIP integration unavailable: ${error?.message || error}`);
    }
  },
});
