// Image Search Customize / Brothel compatibility by Hina_Lover.
WML.define({
  id: 'image-search-customize-compatible-brothel',
  name: { ko: '이미지 기준 · 창관 지하방', en: 'Image Search Customize · Brothel' },
  author: 'Hina_Lover',
  version: '1.0.0', game: '2026-11-01', lang: 'ko',
  tags: ['image', 'util'],
  requires: ['image-search-customize', 'brothel'],
  requiresVersion: { 'image-search-customize': '>=1.0.2 <2', brothel: '>=3.16.0 <4' },
  description: '창관 지하방1·2의 본편 이미지 장소를 객실 기준으로 연결합니다.',
  symbols: { imageRoom: { raw: { '2026-11-01': 'ER' } } },
  setup(api) {
    const cellars = new Set(['brothel_cellar_1', 'brothel_cellar_2']);
    api.hook('imageRoom', {
      around(next, room, ...args) {
        // The first vanilla guest room uses upstairs_hall and maps to bedroom.
        return next(cellars.has(room) ? 'upstairs_hall' : room, ...args);
      },
    });
    api.ui.settings(body => body.replaceChildren(
      api.ui.h('p', {}, '지하방1·2는 본편 객실과 같은 이미지 장소 기준을 사용합니다.'),
      api.ui.h('p', {}, '현재 게임의 객실 이미지 키는 bedroom입니다. 이미지 기준의 장소 설정에서는 침실/bedroom 항목으로 비교하며, 침대 위 조건은 별도로 유지합니다.')));
  },
});
