import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire,registerHooks} from 'node:module';
import {pathToFileURL} from 'node:url';
const require=createRequire(new URL('../../../../MCP/package.json',import.meta.url));
registerHooks({resolve(name,context,next){try{return next(name,context);}catch(error){
  if(error.code==='ERR_MODULE_NOT_FOUND'&&!name.startsWith('.')&&!name.includes(':'))return next(pathToFileURL(require.resolve(name)).href,context);
  throw error;
}}});
const play=await import('../../../../MCP/lib/play.mjs');
const own='image-search-customize-compatible-brothel';
const mobile=process.argv.includes('--mobile'),all=process.argv.includes('--all');
const modsRoot=new URL('../../',import.meta.url);
const ids=[...fs.readFileSync(new URL('mods.js',modsRoot),'utf8').matchAll(/^\s*"([^":]+)"/gm)].map(row=>row[1]);
const fingerprints=()=>Object.fromEntries(['brothel','image-search-customize','attention-image-prompt','imagestudio'].map(id=>[id,createHash('sha256').update(fs.readFileSync(new URL(id+'/mod.js',modsRoot))).digest('hex')]));
const before=fingerprints();
const call=async(fn,arg)=>{
  const response=await play.playEval({id:'cellar-patch',timeoutMs:30000,code:'return ('+fn.toString()+')('+JSON.stringify(arg??null)+');'});
  assert.equal(response.pageErrorsSoFar,0);return response.result;
};
try{
  const enabled=Object.fromEntries(ids.map(id=>[id,all]));
  Object.assign(enabled,{'addon-compat':true,brothel:true});
  const start=await play.playStart({id:'cellar-patch',mods:enabled,viewport:mobile?{width:390,height:844}:{width:1500,height:1000}});
  assert.deepEqual(start.failed,[]);
  const packages={'image-search-customize':'1.0.2',[own]:'1.0.0'};
  const installed=await call(async packages=>{
    const append=Node.prototype.appendChild;
    Node.prototype.appendChild=function(node){if(node.tagName==='SCRIPT'&&Object.keys(packages).some(id=>node.src.endsWith('/'+id+'/mod.js'))){queueMicrotask(()=>node.dispatchEvent(new Event('error')));return node;}return append.call(this,node);};
    try{return await WML.install(await Promise.all(Object.entries(packages).map(async([id,version])=>({path:id+'.zip',blob:await(await fetch('wml/mods/'+id+'/'+id+'-'+version+'-20261101.zip')).blob()}))));}
    finally{Node.prototype.appendChild=append;}
  },packages);
  assert.ok(installed.every(row=>row.mode==='browser'));
  const loaded=await play.playReload({id:'cellar-patch'});assert.deepEqual(loaded.failed,[]);assert.ok(loaded.loaded.includes(own));
  const result=await call(async()=>{
    const d=WML.dev();d.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true,imageBackendMode:'off'});d.store.get().newGame();
    const game=JSON.stringify(d.store.game()),state=d.store.game();
    const wife={...state.characters[state.primaryCharacterId],currentTask:'cleaning',sceneOverride:undefined,sceneVariant:0};
    const room=d.fn('ER'),prompt=d.fn('DR'),brothel=globalThis.__waywardBrothelPublic;
    const reference=room('upstairs_hall');
    const rows=['brothel_cellar_1','brothel_cellar_2','back_room','elena_room','upstairs_room_2','bathroom','taproom'].map(location=>({location,native:room(location),brothel:brothel.imageRoom(location),key:prompt(wife,room(location)).key}));
    const matcher=WW_ImageStudioMatching.matcher,config=matcher.defaults();config.rules.room.allowSimilar=false;
    const pairs=rows.slice(0,2).map(row=>({location:row.location,score:!!matcher.score(matcher.describe(row.key),matcher.describe(prompt(wife,reference).key),config)}));
    const key=rows[0].key;
    const entry={talentName:key,imagePath:'cellar-test.webp',imageType:'portrait',source:'server'};
    const undoManifest=d.hook('bh',{replace:async()=>({entries:{[key]:entry}})});
    const undoBackend=d.hook('yh',{replace:()=>({baseUrl:'',comfyui:false})});
    const bridge=globalThis.WW_ImageStudioBridge,oldPacks=bridge?.packs;
    if(bridge){await bridge.ready();bridge.packs=()=>[{entries:{[key]:entry}}];}
    const originalFetch=window.fetch;
    window.fetch=(url,options)=>options?.method==='HEAD'?Promise.resolve(new Response(null,{status:200})):originalFetch(url,options);
    let resolved;
    try{
      WW_ImageStudioMatching.set(config);WW_ImageStudioMatching.refresh();
      resolved=(await WW_ImageStudioMatching.resolve(rows[1].key))?.entry?.talentName;
    }finally{undoManifest();undoBackend();window.fetch=originalFetch;if(bridge)bridge.packs=oldPacks;}
    return {reference,rows,pairs,resolved,gameUnchanged:JSON.stringify(d.store.game())===game};
  });
  assert.equal(result.reference,'bedroom');
  for(const row of result.rows.slice(0,2)){assert.equal(row.native,result.reference);assert.equal(row.brothel,result.reference);assert.ok(row.key.includes('__room-bedroom'));}
  assert.deepEqual(result.rows.slice(2).map(row=>row.native),['back_room','bedroom','bedroom','bathhouse','taproom']);
  assert.ok(result.pairs.every(row=>row.score));assert.equal(result.resolved,result.rows[0].key);assert.equal(result.gameUnchanged,true);
  assert.deepEqual(fingerprints(),before);
  fs.writeFileSync(new URL('regression-'+(all?'all-':'')+(mobile?'mobile':'pc')+'.json',import.meta.url),JSON.stringify({mobile,all,loaded:loaded.loaded.length,...result},null,2)+'\n');
  console.log(JSON.stringify({loaded:loaded.loaded.length,...result}));
}finally{await play.shutdown();}
