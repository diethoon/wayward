// 직원의 손님 관계와 독립 후 편지는 세이브 안에서 고용 인물별로 관리합니다.
function Brothel_손님관계엔진만들기(context) {
  const { readData, writeData, workers, readWorker, makeCharacter, recordInteraction, notify, log,
    hireCost, canDiscuss, finishDialogue, depart, randomInt } = context;
  const employeeKey = worker => worker.relationshipId || `legacy:${worker.id}`;
  const finite = value => Number.isFinite(Number(value)) ? Number(value) : 0;
  const clamp = (value, min = -100, max = 100) => Math.max(min, Math.min(max, finite(value)));
  const gain = (value, delta, overflow = false) => {
    // 원본의 Yo/Do 감소 곡선. 우호도만 사건 조건에 맞춰 상한을 열어 둡니다.
    const amount = delta > 0 ? delta * (.2 + .8 * Math.max(0, (100 - value) / 100)) : delta;
    return clamp(value + amount, -100, overflow ? Number.POSITIVE_INFINITY : 100);
  };
  const stageWeights = {
    chatting: [.4, 0], flirting: [.6, .3], light_touch: [.3, .7], bold_touch: [.2, 1],
    groping: [.1, 1.4], intimate: [0, 1.8], handjob_patron: [0, 2.3],
    blowjob_patron: [0, 2.5], titfuck_patron: [0, 2.5], sex_patron: [0, 3]
  };

  function employee(state, worker) {
    const stored = readData(state).patronRelationships?.[worker.id];
    return stored?.employeeKey === employeeKey(worker)
      ? { ...stored, records: [...(stored.records || [])] }
      : { employeeKey: employeeKey(worker), records: [], marriageRequest: null };
  }
  function writeEmployee(state, worker, data) {
    return writeData(state, { patronRelationships: { ...readData(state).patronRelationships, [worker.id]: data } });
  }
  function readRecord(state, worker, name) {
    return employee(state, worker).records.find(record => record.name === name) || null;
  }
  function blankRecord(state, customer) {
    return { name: customer.name, patronType: customer.patronType, intent: customer.intent,
      tacticStyle: customer.tacticStyle, charm: customer.charm, boldness: customer.boldness,
      attributes: customer.attributes, chemistry: customer.chemistry, personaTags: customer.personaTags,
      platonic: 0, romantic: 0, sexual: 0, visitCount: 0, lastVisitDay: state.day,
      maxStageReached: 'chatting', totalTipped: 0 };
  }
  function saveRecord(data, record) {
    const index = data.records.findIndex(item => item.name === record.name);
    if (index < 0) data.records.push(record);
    else data.records[index] = record;
  }
  function checkRequest(state, worker, customer) {
    const data = employee(state, worker), record = readRecord(state, worker, customer.name);
    if (data.marriageRequest || !(finite(record?.platonic) > 100)) return state;
    data.marriageRequest = { customerId: customer.id, customerName: customer.name,
      day: state.day, slot: state.slot, workerName: worker.name };
    let next = writeEmployee(state, worker, data);
    const body = `${customer.name}이(가) 당신에게 조심스럽게 말을 건넵니다. “${worker.name} 씨를 아내로 맞이하고 싶습니다. 그분도 자기 삶을 선택할 수 있도록 독립할 기회를 주실 수 있겠습니까?”\n${worker.name}과(와) 대화할 때 ‘독립 권유’를 선택할 수 있습니다.`;
    next = log(next, body, worker.id);
    return notify(next, { kind: 'marriage-request', title: `${customer.name}의 결혼 요청 · ${worker.name}`,
      body, choices: [{ id: 'acknowledge', label: '요청을 듣고 기억해 둔다' }] });
  }
  function recordStage(state, worker, customer, stage) {
    const data = employee(state, worker), record = readRecord(state, worker, customer.name) || blankRecord(state, customer);
    const [like, sexual] = stageWeights[stage] || [0, 0];
    saveRecord(data, { ...record, platonic: gain(finite(record.platonic), like, true),
      sexual: gain(finite(record.sexual), sexual), lastVisitDay: state.day });
    return checkRequest(writeEmployee(state, worker, data), worker, customer);
  }
  function finishInteraction(state, worker, customer, interaction) {
    if (!customer || !interaction) return state;
    const data = employee(state, worker);
    const current = readRecord(state, worker, customer.name) || blankRecord(state, customer);
    // 원본 접객 관계 계산에 독립된 직원 캐릭터와 관계표만 전달합니다.
    // 아내의 신뢰·감정·손님 관계는 계산에 사용하지 않습니다.
    const character = makeCharacter(state, worker, data.character);
    data.character = character;
    const isolated = { ...state, primaryCharacterId: worker.id, characters: { [worker.id]: character },
      relationshipStartSlot: state.slot, patronRecords: data.records, customers: [customer] };
    const nativeStage = interaction.stage === 'titfuck_patron' ? 'handjob_patron' : interaction.stage;
    const scene = { ...interaction, stage: nativeStage, customerId: customer.id, customerName: customer.name,
      characterId: worker.id, patronBoldness: customer.boldness ?? 50, patronCharm: customer.charm ?? 50,
      elenaComfort: finite(interaction.comfort ?? worker.stats?.mood),
      elenaPleasure: finite(interaction.pleasure), playerEncouragements: 0 };
    const calculated = recordInteraction(isolated, scene, 0).patronRecords.find(record => record.name === customer.name);
    if (!calculated) return state;
    // 원본은 100에서 잘리므로 우호도의 원본 증가분만 상한 밖으로 이어 붙입니다.
    const bad = finite(customer.mistreatmentTonight) > 0;
    const good = !bad && (scene.elenaComfort > 50 || scene.elenaPleasure >= 50);
    const delta = current.visitCount > 0 ? good ? 5 : bad || scene.elenaComfort < 30 ? -2 : 0 : good ? 10 : 0;
    saveRecord(data, { ...calculated, platonic: gain(finite(current.platonic), delta, true) });
    return checkRequest(writeEmployee(state, worker, data), worker, customer);
  }
  function checkRequests(state) {
    let next = state;
    for (const worker of workers(next)) {
      if (employee(next, worker).marriageRequest) continue;
      const customer = (next.customers || []).find(item => !['gone', 'leaving'].includes(item.status)
        && finite(readRecord(next, worker, item.name)?.platonic) > 100);
      if (customer) next = checkRequest(next, worker, customer);
    }
    return next;
  }
  function request(state, workerId) {
    const worker = readWorker(state, workerId);
    return worker ? employee(state, worker).marriageRequest : null;
  }
  function openIndependence(state, action) {
    const worker = readWorker(state, action.workerId);
    if (!worker || readData(state).independenceOffer) return state;
    const reason = canDiscuss(state, worker.id);
    if (reason) return log(state, reason, worker.id);
    const amount = hireCost(worker), marriage = request(state, worker.id);
    const offer = { workerId: worker.id, workerName: worker.name, employeeKey: employeeKey(worker), amount,
      customerName: marriage?.customerName || null };
    let next = writeData(state, { independenceOffer: offer });
    const body = `당신은 ${worker.name}에게 독립해서 새로운 삶을 시작해 보는 것이 어떻겠냐고 권합니다.\n“저도 ${marriage ? `${marriage.customerName} 씨와 함께할 앞날을` : '제 힘으로 살아갈 앞날을'} 생각해 봤어요. 하지만 독립자금이 부족해요. 저를 고용할 때 드셨던 비용만큼, ${amount}골드를 빌려주실 수 있나요?”\n빌려주면 ${worker.name}은(는) 일을 그만두고 떠납니다.`;
    next = log(next, body, worker.id);
    return notify(next, { kind: 'independence', title: `독립 권유 · ${worker.name}`, body,
      choices: [{ id: 'lend', label: `독립자금 ${amount}골드를 빌려준다` }, { id: 'keep', label: '지금은 보류한다' }] });
  }
  function resolveIndependence(state, choice) {
    const offer = readData(state).independenceOffer;
    if (!offer) return state;
    let next = writeData(state, { independenceOffer: null });
    const worker = readWorker(next, offer.workerId);
    if (!worker || employeeKey(worker) !== offer.employeeKey) return next;
    if (choice !== 'lend') return log(next, `${worker.name}의 독립 이야기는 지금은 보류합니다.`, worker.id);
    const blocked = canDiscuss(next, worker.id);
    if (blocked) return log(next, blocked, worker.id);
    if (finite(next.economy?.gold) < offer.amount) return log(next, `독립자금 ${offer.amount}골드를 빌려주기에는 가진 돈이 부족합니다. ${worker.name}은(는) 가게에 남습니다.`, worker.id);
    next = finishDialogue(next, worker.id);
    const data = readData(next), sequence = finite(data.independenceSequence) + 1;
    const id = `departure:${sequence}:${state.slot}`;
    const departure = { id, employeeKey: offer.employeeKey, workerId: worker.id, workerName: worker.name,
      customerName: offer.customerName, loan: offer.amount, repayment: offer.amount * 2,
      departureDay: state.day, departureSlot: state.slot, dueDay: state.day + randomInt(5, 10), status: 'waiting' };
    next = { ...next, economy: { ...next.economy, gold: finite(next.economy?.gold) - offer.amount } };
    next = writeData(next, { independenceSequence: sequence,
      departures: [...(readData(next).departures || []), departure] });
    next = depart(next, worker);
    return log(next, `${worker.name}에게 독립자금 ${offer.amount}골드를 빌려주었습니다. 그녀는 고맙다고 인사한 뒤 짐을 꾸려 가게를 떠납니다.`, worker.id);
  }
  function morning(state) {
    if (!state || state.gameOver) return state;
    let next = state;
    for (const departure of readData(state).departures || []) {
      if (departure.status !== 'waiting' || state.day < departure.dueDay) continue;
      next = writeData(next, { departures: readData(next).departures.map(item => item.id === departure.id
        ? { ...item, status: 'arrived', arrivedDay: state.day } : item) });
      const body = `기상 직후 집 앞에 도착한 편지 봉투에서 ${departure.workerName}의 이름을 발견합니다.\n\n“사장님께. 독립할 수 있도록 도와주셔서 정말 감사해요. ${departure.customerName ? `${departure.customerName} 씨와 새 살림을 꾸려 잘 지내고 있어요.` : '새 보금자리를 마련하고 잘 지내고 있어요.'} 빌려주신 ${departure.loan}골드에 감사의 마음을 더해 두 배로 보내드려요. 늘 건강하세요.\n${departure.workerName} 드림.”\n\n편지에는 ${departure.repayment}골드가 들어 있습니다.`;
      next = log(next, body, departure.workerId);
      next = notify(next, { kind: 'independence-letter', title: `집 앞에 도착한 편지 · ${departure.workerName}`, body,
        choices: [{ id: `receive:${departure.id}`, label: `편지와 ${departure.repayment}골드를 받는다` }] });
    }
    return next;
  }
  function receiveLetter(state, choice) {
    if (!String(choice).startsWith('receive:')) return state;
    const id = choice.slice('receive:'.length), departure = (readData(state).departures || []).find(item => item.id === id);
    if (!departure || departure.status !== 'arrived') return state;
    let next = writeData(state, { departures: readData(state).departures.map(item => item.id === id
      ? { ...item, status: 'paid', paidDay: state.day, paidSlot: state.slot } : item) });
    next = { ...next, economy: { ...next.economy, gold: finite(next.economy?.gold) + departure.repayment } };
    return log(next, `${departure.workerName}의 감사 편지를 읽고 동봉된 ${departure.repayment}골드를 받았습니다.`, departure.workerId);
  }
  return { record: readRecord, employee, recordStage, finishInteraction, checkRequests, request,
    openIndependence, resolveIndependence, morning, receiveLetter };
}
globalThis.__waywardBrothelPatronLifeFactory = Brothel_손님관계엔진만들기;
