// 창관 운영 — WML 포팅판
// 원본: brothel.src.js (md5 c0bde912082fd6b6f54810c2adbdfcdd), 9-30 한글판 모드 매니저용 애드온.
// 원본에서 고친 곳 18군데: brothel.fixes.json
// 원본 코드는 아래 setup() 안에서 그대로 실행돼요. 게임 함수 연결은 addon-compat 모드가 해 줘요.
WML.define({
  tags: ["content","h-scene"],
  id: "brothel",
  author: "Hina_Lover",
  name: "창관 모드",
  version: "3.16.0",
  game: "2026-11-01",
  lang: 'ko',
  description: "창부 고용·시설·영업을 관리하며 이야기 로그, 수입 통계, 행위별 최소 요금과 종업원별 성행위 기록을 제공합니다.",
  requires: ["addon-compat"],
  loadAfter: [],
  conflicts: ["arhka-slave"],
  symbols: {
    "brothelHallActions": {"raw":{"2026-11-01":"Int"},"doc":"홀의 기본 행동과 아내 대화 자리"},
    "brothelBedroomActions": {"raw":{"2026-11-01":"$nt"}},
    "brothelBathhouseActions": {"raw":{"2026-11-01":"Nnt"}},
    "brothelBathroomActions": {"raw":{"2026-11-01":"Ant"}},
    "brothelBackRoomActions": {"raw":{"2026-11-01":"jnt"}},
    "brothelKitchenActions": {"raw":{"2026-11-01":"Lnt"}},
    "brothelGuestRoomActions": {"raw":{"2026-11-01":"Ynt"}},
    "brothelPrivateRoomActions": {"raw":{"2026-11-01":"Wnt"}},
    "brothelCharacterFromArchetype": {"raw":{"2026-11-01":"RZe"},"doc":"직원의 기반 캐릭터로 아내와 독립된 캐릭터 상태 생성"},
    "brothelRecordPatronInteraction": {"raw":{"2026-11-01":"IG"},"doc":"원본 접객 종료 시 손님 우호·연애·성적 관계 계산"}
  },

  setup(wmlApi) {
    const api = globalThis.__waywardPauseSettingsUiFactory.connect(wmlApi, {"id":"brothel","label":"창관 운영","bindings":{"2026-10-04":{"store":"ae","settingsStore":"At","React":"Z","jsx":"u","ActionButton":"Ze","ActionPanel":"aO","wife":"_","updateWife":"O","updateCharacter":"nn","log":"N","tick":"Jt","intoxLabel":"In","playerId":"fe","wifeId":"Re","locationOf":"$e","wifeLocation":"_e","playerLocation":"bt","moveOccupant":"Pt","patronScene":"Y","playerSexScene":"Le","setScene":"MV","patronSceneLocation":"tt","isSexualStage":"it","sceneDef":"ls","sceneOutfitState":"bx","garmentWorn":"vr","exposureSummary":"nf","patronWatchChoices":"Xae","patronChoice":"tNe","startPlayerSex":"_p","playerSexEvent":"Fl","ensureHusbandLed":"F8","addJoinedPatron":"nfe","joinSlots":"NH","registerAlert":"nr","queueAlert":"gn","drainAlerts":"gl","imagePrompt":"r8","imageKey":"s8","imageKeyOf":"n8","imageDescriptor":"o8","makeCustomer":"ff","addCustomer":"Ka","carryToBed":"RDe","talkToWife":"EF","actionTimes":"Oo","addFeeling":"we","addIdentityStrainFromPatronAct":"Kf","getCustomerLocation":"Yn","getEffectiveAttributes":"B","heroineConditioningMax":"QX","heroineDriveCalc":"si","moveWife":"pt","outfits":"fh","patronControlCustomerLocation":"ht","wifeById":"ul","wifePreview":"gue","reduceGameAction":"wT","brothelLog":"hs","decisionCategories":"bo","decisionResolve":"G$e","manaMax":"ms","minuteTick":"gp","recordPlayerTone":"Rt","wives":"mh","imageBackend":"Eh","brothelCustomerBusy":"XO","buildPatronMoveCandidates":"Phe","ejectCustomer":"Q5","endPatronInteraction":"jt","finishBackRoomService":"xF","forceAttemptChance":"Ppe","patronControlAcquaintanceStop":"_Ie","patronControlAttemptRoll":"Iy","patronControlBackRoomOpen":"Tr","patronControlBareForPushIn":"O5","patronControlChooseMove":"Yhe","patronControlCoercionEscape":"cpe","patronControlFavorTable":"h3","patronControlHerBackRoomProposal":"ipe","patronControlIntentEvolve":"z$","patronControlJoinerComfort":"wh","patronControlJoinerPushIn":"jIe","patronControlLineUp":"Gce","patronControlLungePlan":"Vre","patronControlMortifyingCheck":"b$","patronControlMoveCustomer":"Yt","patronControlNaturalEnd":"hI","patronControlPatronBackRoomProposal":"ape","patronControlPatronDrift":"Kbe","patronControlPlayerAway":"Tt","patronControlPositionWeights":"Fhe","patronControlPrivateSession":"wpe","patronControlPrivateSessionInfo":"a0","patronControlPushIn":"qce","patronControlPushInAnalReaction":"p6","patronControlPushInReaction":"R6","patronControlRelentChance":"Bpe","patronControlRequestTable":"E2e","patronControlSelfEscalationRoll":"Qre","patronControlShameStop":"dpe","patronControlSlotFree":"kS","patronControlSmallRequest":"R2e","patronControlStageLabel":"hG","patronControlStrengthContest":"Za","patronControlTacticTable":"lIe","patronControlUndressAttempt":"AIe","patronControlVerbalAsk":"$5e","patronControlWitnessesFor":"Ks","patronControlYieldRoll":"pB","playerActionPublicRefusal":"Rs","processPatronGroupJoin":"BS","processPatronGroupParticipants":"WS","processPatronInteractionTick":"R7","recordPatronMistreatment":"yl","recordPatronReach":"K5e","resolvePatronEscalation":"ub","resolvePatronForce":"gB","rotatePatronGroupAfterPrimary":"Gie","selectPatronTactic":"gIe","startPatronInteraction":"Go","transitionPatronStage":"Dn","evaluateIntimacy":"Pe","getMaritalDrift":"E4","getPatronAttachment":"Uo","nudgeRelationship":"Mo","recordAffection":"Iw","recordIntimateHistory":"Wd","recordPatronBoundary":"Qi","brothelRoomLabels":"bO","imageRoom":"lue","waitressAlternative":"u$","waitressAvailable":"Bd","waitressChooseOrder":"Jle","waitressConsume":"_w","waitressIncome":"Qt","waitressMissing":"CP","waitressPrice":"d$","waitressRecordDrink":"vw","waitressRecordWord":"VB","playerActionRespond":"P1e","playerActionTopicFatigue":"GY","playerActionTouchedOut":"er","promptJoin":"J6","promptRoomFilter":"$de","promptGenParams":"q6","outfitById":"Ot","saveSlotInfo":"Mb","listDayStarts":"ZI","saveDayStart":"UDe","wifePortraits":"z6e","resentment":"Ue","marriageBond":"VT","wakeUp":"FI","gameOverScreen":"HLe","allureScore":"Ir","normalVisitRoll":"nhe","lodgingChance":"IB","worldTick":"Dp","hotkeyAction":"sG","confirmAction":"N4e","busyTask":"X0","imageManifest":"Wb","imageServerUrl":"Cs","imageGenerate":"LPe","imageQueue":"g6e","imageBackendProbe":"JU","imageBackendForget":"UD","imagePackReset":"qD","imageAutoProbeAllowed":"KU"}, "2026-11-01": {"store":"ae","settingsStore":"at","React":"J","jsx":"u","ActionButton":"ht","ActionPanel":"SB","wife":"_","updateWife":"C","updateCharacter":"rn","log":"j","tick":"Jt","intoxLabel":"Sn","playerId":"ge","wifeId":"Ee","locationOf":"Ae","wifeLocation":"we","playerLocation":"vt","moveOccupant":"Ht","patronScene":"U","playerSexScene":"Be","setScene":"dK","patronSceneLocation":"Je","isSexualStage":"ct","sceneDef":"Sr","sceneOutfitState":"KMe","garmentWorn":"Zr","exposureSummary":"_g","patronWatchChoices":"Dbe","patronChoice":"uZ","startPlayerSex":"uh","playerSexEvent":"Kl","ensureHusbandLed":"ihe","addJoinedPatron":"C3e","joinSlots":"eU","registerAlert":"ar","queueAlert":"_n","drainAlerts":"oi","imagePrompt":"DR","imageKey":"zz","imageKeyOf":"CR","imageDescriptor":"RR","makeCustomer":"Ag","addCustomer":"Fi","carryToBed":"r5e","talkToWife":"gee","actionTimes":"tn","addFeeling":"Se","addIdentityStrainFromPatronAct":"Qf","getCustomerLocation":"Jn","getEffectiveAttributes":"B","heroineConditioningMax":"eue","heroineDriveCalc":"il","moveWife":"Nt","outfits":"Oi","patronControlCustomerLocation":"et","wifeById":"$m","wifePreview":"WL","reduceGameAction":"p5","brothelLog":"ds","decisionCategories":"Ho","decisionResolve":"DFe","manaMax":"Ys","minuteTick":"ry","recordPlayerTone":"qn","wives":"kr","imageBackend":"yh","brothelCustomerBusy":"z5","buildPatronMoveCandidates":"Zve","ejectCustomer":"HR","endPatronInteraction":"Rt","finishBackRoomService":"IV","forceAttemptChance":"iIe","patronControlAcquaintanceStop":"OUe","patronControlAttemptRoll":"g0","patronControlBackRoomOpen":"xS","patronControlBareForPushIn":"Q2","patronControlChooseMove":"sxe","patronControlCoercionEscape":"YOe","patronControlFavorTable":"wY","patronControlHerBackRoomProposal":"dGe","patronControlIntentEvolve":"AC","patronControlJoinerComfort":"ch","patronControlJoinerPushIn":"KUe","patronControlLineUp":"ADe","patronControlLungePlan":"s8e","patronControlMortifyingCheck":"b_","patronControlMoveCustomer":"lo","patronControlNaturalEnd":"GC","patronControlPatronBackRoomProposal":"cGe","patronControlPatronDrift":"NHe","patronControlPlayerAway":"yt","patronControlPositionWeights":"rxe","patronControlPrivateSession":"ZJ","patronControlPrivateSessionInfo":"Nh","patronControlPushIn":"jDe","patronControlPushInAnalReaction":"N9","patronControlPushInReaction":"wz","patronControlRelentChance":"mIe","patronControlRequestTable":"JGe","patronControlSelfEscalationRoll":"l8e","patronControlShameStop":"WOe","patronControlSlotFree":"G$","patronControlSmallRequest":"QGe","patronControlStageLabel":"Ote","patronControlStrengthContest":"el","patronControlTacticTable":"$Ue","patronControlUndressAttempt":"zUe","patronControlVerbalAsk":"A7e","patronControlWitnessesFor":"hs","patronControlYieldRoll":"Xq","playerActionPublicRefusal":"ir","processPatronGroupJoin":"gN","processPatronGroupParticipants":"XS","processPatronInteractionTick":"cZ","recordPatronMistreatment":"yl","recordPatronReach":"bPe","resolvePatronEscalation":"_b","resolvePatronForce":"Zq","rotatePatronGroupAfterPrimary":"jle","selectPatronTactic":"MUe","startPatronInteraction":"Xo","transitionPatronStage":"js","evaluateIntimacy":"We","getMaritalDrift":"i4","getPatronAttachment":"Uo","nudgeRelationship":"ko","recordAffection":"Iw","recordIntimateHistory":"Om","recordPatronBoundary":"tl","brothelRoomLabels":"LB","imageRoom":"ER","waitressAlternative":"JA","waitressAvailable":"zr","waitressChooseOrder":"uTe","waitressConsume":"v_","waitressIncome":"vo","waitressMissing":"K7","waitressPrice":"zv","waitressRecordDrink":"ox","waitressRecordWord":"vK","playerActionRespond":"IWe","playerActionTopicFatigue":"sX","playerActionTouchedOut":"er","promptJoin":"Yz","promptRoomFilter":"uMe","promptGenParams":"Dz","outfitById":"Ot","saveSlotInfo":"Bk","listDayStarts":"h$","saveDayStart":"y5e","wifePortraits":"Uit","resentment":"qe","marriageBond":"dA","wakeUp":"vD","gameOverScreen":"kat","allureScore":"aa","normalVisitRoll":"wTe","lodgingChance":"mK","worldTick":"py","hotkeyAction":"KG","confirmAction":"NYe","busyTask":"sv","imageManifest":"bh","imageServerUrl":"es","imageGenerate":"xst","imageQueue":"eit","imageBackendProbe":"FD","imageBackendForget":"iM","imagePackReset":"t_","imageAutoProbeAllowed":"eoe"}}});
    api.ui.menuSettings({label:"창관 운영",legacyButton:".ww-brothel-menu-button",windowSelector:"#ww-settings",attributes:{"class":"ww-brothel-menu-button"},onClick:()=>globalThis.__waywardBrothelPublic?.openSettings?.()});
    try { api.ui.pauseSettings?.({label:{ko:'창관 운영',en:'Brothel settings'},onClick:()=>globalThis.__waywardBrothelPublic?.openSettings?.()}); } catch (error) { console.warn("[brothel] 공통 설정 메뉴 등록 실패: 기존 직접 삽입 방식으로 계속합니다.", error); }

    // ---- 현재 게임에 맞춘 보정 ----
    // The 9-30 mod manager added data-wayward-room / data-wayward-room-section attributes to the
    // "where everyone is" room cards and per-room sections. Here the same markers are put on the rendered
    // cards by reading their room names (the game's own label tables, so it works in any language).
    const LG = globalThis.__WML_LEGACY__;
    const Brothel_등록캐릭터읽기 = () => api.fn('wives') || [];
    const roomOfLabel = () => {
      const m = new Map();
      const add = (label, id) => { if (typeof label === 'string' && label.trim()) m.set(label.trim().replace(/^the /i, '').toLowerCase(), id); };
      for (const table of [LG.get('nY'), LG.get('o3')]) for (const [id, label] of Object.entries(table || {})) add(label, id);
      for (const id of LG.get('Xi') || []) add(id.replace(/_/g, ' '), id);
      return m;
    };
    let labels = null, labelsAt = 0;
    const lookupRoom = text => {
      if (!labels || Date.now() - labelsAt > 5000) { labels = roomOfLabel(); labelsAt = Date.now(); }
      return labels.get(String(text || '').trim().replace(/^the /i, '').toLowerCase());
    };
    function markRooms() {
      // room cards: <div class="p-1.5 rounded border …"><div>Room name</div>…
      for (const card of document.querySelectorAll('#root div.rounded.border')) {
        if (!/\bp-1\.5\b/.test(card.className) || card.dataset.waywardRoom) continue;
        const head = card.firstElementChild;
        const id = head && lookupRoom(head.textContent);
        if (id) card.dataset.waywardRoom = id;
      }
      // per-room sections: <div class="mb-2"><div class="flex items-center gap-2 mb-0.5"><span>Room</span>…
      for (const sec of document.querySelectorAll('#root div.mb-2')) {
        if (sec.dataset.waywardRoomSection) continue;
        const head = sec.firstElementChild;
        if (!head || !/\bmb-0\.5\b/.test(head.className)) continue;
        const id = lookupRoom(head.firstElementChild && head.firstElementChild.textContent);
        if (id) sec.dataset.waywardRoomSection = id;
      }
    }
    let markQueued = false;
    const queueMark = () => { if (markQueued) return; markQueued = true; Promise.resolve().then(() => { markQueued = false; try { markRooms(); } catch (e) { console.warn('[brothel] room markers', e); } }); };
    new MutationObserver(queueMark).observe(document.body, { childList: true, subtree: true, characterData: true });
    queueMark();
    
    // WML-side data and UI helpers for the Brothel port. Keeping these additions in
    // the port layer lets the original addon remain a reproducible read-only input.
    const WBE = (() => {
      const stages = ['groping', 'intimate', 'handjob_patron', 'blowjob_patron', 'titfuck_patron', 'sex_patron'];
      const stageSet = new Set(stages);
      const minimumDefaults = { petting: 1, manual: 3, oral: 5, penetrationOutside: 7, penetrationInside: 10 };
      const minimumLabels = [
        ['petting', '애무'],
        ['manual', '손으로 빼주기'],
        ['oral', '입으로 빼주기(구강성교)'],
        ['penetrationOutside', '삽입 / 애널(외부 사정)'],
        ['penetrationInside', '삽입 / 애널(내부 사정)']
      ];
      const incomeKeys = ['gross', 'house', 'wages', 'wageTopups', 'serviceGross', 'rent', 'transactions', 'stays'];
      const number = value => Math.max(0, Number(value) || 0);
      const integer = value => Math.floor(number(value));
      const el = (tag, className, text) => {
        const node = document.createElement(tag);
        if (className) node.className = className;
        if (text != null) node.textContent = text;
        return node;
      };
      const emptyCounts = () => Object.fromEntries(stages.map(stage => [stage, 0]));
      const emptyWorkerData = () => ({ sexualExperience: emptyCounts(), sexualHistory: [] });
      const emptyBucket = () => ({ gross: 0, house: 0, wages: 0, wageTopups: 0, serviceGross: 0, rent: 0, transactions: 0, stays: 0 });
      const emptyIncome = () => ({ ...emptyBucket(), byDay: {}, byWorker: {}, recent: [] });
      const normalizeMinimumPrices = raw => Object.fromEntries(minimumLabels.map(([key]) => [key,
        Math.max(1, Math.min(999, integer(raw?.[key] ?? minimumDefaults[key])))
      ]));
      const minimumPrice = (config, stage, customer) => {
        const prices = normalizeMinimumPrices(config?.minimumPrices);
        if (stage === 'groping' || stage === 'intimate') return prices.petting;
        if (stage === 'handjob_patron' || stage === 'titfuck_patron') return prices.manual;
        if (stage === 'blowjob_patron') return prices.oral;
        if (stage === 'sex_patron') return Number(customer?.boldness) > 55 ? prices.penetrationInside : prices.penetrationOutside;
        return 0;
      };
      const normalizeRecord = record => ({
        day: integer(record?.day) || 1,
        slot: integer(record?.slot),
        stage: stageSet.has(record?.stage) ? record.stage : 'intimate',
        partner: String(record?.partner || '이름 없는 손님').slice(0, 80),
        room: String(record?.room || 'taproom').slice(0, 60),
        fee: integer(record?.fee)
      });
      const normalizeWorker = raw => ({
        sexualExperience: Object.fromEntries(stages.map(stage => [stage, integer(raw?.sexualExperience?.[stage])])),
        sexualHistory: (Array.isArray(raw?.sexualHistory) ? raw.sexualHistory : []).slice(-80).map(normalizeRecord)
      });
      const normalizeBucket = raw => Object.fromEntries(incomeKeys.map(key => [key, integer(raw?.[key])]));
      const normalizeIncome = raw => {
        const result = { ...emptyIncome(), ...normalizeBucket(raw) };
        const dayEntries = Object.entries(raw?.byDay && typeof raw.byDay === 'object' ? raw.byDay : {})
          .filter(([day]) => /^\d+$/.test(day)).sort((a, b) => Number(a[0]) - Number(b[0])).slice(-31);
        result.byDay = Object.fromEntries(dayEntries.map(([day, bucket]) => [day, normalizeBucket(bucket)]));
        result.byWorker = Object.fromEntries(Object.entries(raw?.byWorker && typeof raw.byWorker === 'object' ? raw.byWorker : {})
          .slice(-12).map(([id, bucket]) => [String(id), normalizeBucket(bucket)]));
        result.recent = (Array.isArray(raw?.recent) ? raw.recent : []).slice(-80).map(record => ({
          day: integer(record?.day) || 1,
          slot: integer(record?.slot),
          workerId: String(record?.workerId || ''),
          workerName: String(record?.workerName || '종업원').slice(0, 80),
          customer: String(record?.customer || '손님').slice(0, 80),
          kind: record?.kind === 'stay' ? 'stay' : record?.kind === 'wage_topup' ? 'wage_topup' : 'service',
          stage: stageSet.has(record?.stage) ? record.stage : null,
          gross: integer(record?.gross), house: integer(record?.house), wage: integer(record?.wage)
        }));
        return result;
      };
      const addBucket = (target, delta) => {
        for (const key of incomeKeys) target[key] = integer(target[key]) + integer(delta[key]);
      };
      const recordExperience = (worker, state, runtime, customer, stage, fee) => {
        if (!stageSet.has(stage)) return false;
        const data = normalizeWorker(worker);
        data.sexualExperience[stage]++;
        data.sexualHistory.push(normalizeRecord({ day: state?.day, slot: state?.slot, stage, partner: customer?.name, room: runtime?.location, fee }));
        worker.sexualExperience = data.sexualExperience;
        worker.sexualHistory = data.sexualHistory.slice(-80);
        return true;
      };
      const recordIncome = (config, state, worker, customer, entry) => {
        const stats = normalizeIncome(config?.incomeStats);
        const kind = entry?.kind === 'stay' ? 'stay' : 'service';
        const delta = {
          gross: integer(entry?.gross), house: integer(entry?.house), wages: integer(entry?.wage),
          serviceGross: kind === 'service' ? integer(entry?.gross) : 0,
          rent: kind === 'stay' ? integer(entry?.gross) : 0,
          transactions: 1, stays: kind === 'stay' ? 1 : 0
        };
        addBucket(stats, delta);
        const day = String(integer(state?.day) || 1);
        stats.byDay[day] ??= emptyBucket();
        addBucket(stats.byDay[day], delta);
        const days = Object.keys(stats.byDay).sort((a, b) => Number(a) - Number(b));
        for (const old of days.slice(0, -31)) delete stats.byDay[old];
        const workerId = String(worker?.id || 'unknown');
        stats.byWorker[workerId] ??= emptyBucket();
        addBucket(stats.byWorker[workerId], delta);
        stats.recent.push({ day: integer(state?.day) || 1, slot: integer(state?.slot), workerId,
          workerName: String(worker?.name || '종업원'), customer: String(customer?.name || '손님'), kind,
          stage: stageSet.has(entry?.stage) ? entry.stage : null,
          gross: delta.gross, house: delta.house, wage: delta.wages });
        stats.recent = stats.recent.slice(-80);
        config.incomeStats = stats;
      };
      const recordWageTopup = (config, state, worker, amount) => {
        const paid=integer(amount);if(!paid)return;
        const stats=normalizeIncome(config?.incomeStats),delta={gross:0,house:0,wages:paid,wageTopups:paid,serviceGross:0,rent:0,transactions:0,stays:0};
        addBucket(stats,delta);const day=String(integer(state?.day)||1);stats.byDay[day]??=emptyBucket();addBucket(stats.byDay[day],delta);
        const workerId=String(worker?.id||'unknown');stats.byWorker[workerId]??=emptyBucket();addBucket(stats.byWorker[workerId],delta);
        stats.recent.push({day:integer(state?.day)||1,slot:integer(state?.slot),workerId,workerName:String(worker?.name||'종업원'),customer:'업소',kind:'wage_topup',stage:null,gross:0,house:0,wage:paid});
        stats.recent=stats.recent.slice(-80);config.incomeStats=stats;
      };
      const log = (api, state, text, workerId) => {
        let next;
        if (api.brothel?.log) next = api.brothel.log(state, text, workerId);
        else next = { ...state, log: [...(state.log ?? []), { slot: state.slot, text, ...(workerId ? { wwWorkerId: workerId } : {}) }] };
        const entries = next?.log;
        if (!Array.isArray(entries) || entries.length === 0) return next;
        const latest = entries.at(-1);
        const tagged = { ...latest, coLocated: true, eventCategory: latest?.eventCategory ?? 'brothel', ...(workerId ? { wwWorkerId: workerId } : {}) };
        return { ...next, log: [...entries.slice(0, -1), tagged] };
      };
      const statCard = (label, value, suffix = '골드') => {
        const card = el('div', 'ww-stat-card');
        card.append(el('span', 'ww-stat-label', label), el('strong', 'ww-stat-value', `${integer(value)}${suffix}`));
        return card;
      };
      const experiencePanel = (worker, stageLabels, locationLabels, formatTime) => {
        const data = normalizeWorker(worker), section = el('section', 'ww-sex-history');
        section.dataset.brothelExperience = worker.id;
        section.append(el('h4', 'ww-section-title', '성행위 경험 · 기록'));
        const total = stages.reduce((sum, stage) => sum + data.sexualExperience[stage], 0), counts = el('div', 'ww-sex-counts');
        counts.append(statCard('전체', total, '회'));
        for (const stage of stages) counts.append(statCard(stageLabels[stage] ?? stage, data.sexualExperience[stage], '회'));
        section.append(counts);
        const history = el('div', 'ww-sex-records');
        history.append(el('div', 'ww-record-heading', '최근 기록'));
        if (data.sexualHistory.length === 0) history.append(el('p', 'ww-help', '아직 기록된 성행위가 없습니다. 업데이트 이전의 행위는 소급 집계되지 않습니다.'));
        else for (const record of data.sexualHistory.slice(-6).reverse()) {
          const row = el('div', 'ww-sex-record');
          const title = el('strong', '', `${record.partner} · ${stageLabels[record.stage] ?? record.stage}`);
          const where = locationLabels[record.room] ?? record.room;
          const when = typeof formatTime === 'function' ? formatTime(record.slot) : '';
          row.append(title, el('span', '', `${record.day}일차 ${when} · ${where}${record.fee ? ` · ${record.fee}골드` : ''}`));
          history.append(row);
        }
        section.append(history);
        return section;
      };
      const incomePanel = (config, state, stageLabels, formatTime) => {
        const stats = normalizeIncome(config?.incomeStats), panel = el('details', 'ww-income-stats');
        panel.dataset.brothelIncome = 'true';
        const summary = el('summary', 'ww-editor-head'), title = el('h3', '', '골드 수입 통계'), fold = el('span', 'ww-fold-label', '펼치기');
        summary.append(title, fold); panel.append(summary); panel.addEventListener('toggle', () => { fold.textContent = panel.open ? '접기' : '펼치기'; });
        const body = el('div', 'ww-income-body');
        body.append(el('p', 'ww-help', '창관 모드가 직접 만든 서비스비와 숙박료만 집계합니다. 업데이트 이전 수입은 소급 집계되지 않습니다.'));
        const totals = el('div', 'ww-income-grid');
        totals.append(statCard('총매출', stats.gross), statCard('업소 수익', stats.house), statCard('종업원 급료', stats.wages),statCard('고정 일당',stats.wageTopups),
          statCard('서비스 매출', stats.serviceGross), statCard('숙박료', stats.rent), statCard('결제 건수', stats.transactions, '건'));
        body.append(el('h4', 'ww-section-title', '누적'), totals);
        const today = stats.byDay[String(integer(state?.day) || 1)] ?? emptyBucket(), todayGrid = el('div', 'ww-income-grid');
        todayGrid.append(statCard('오늘 총매출', today.gross), statCard('오늘 업소 수익', today.house), statCard('오늘 급료', today.wages), statCard('오늘 숙박료', today.rent));
        body.append(el('h4', 'ww-section-title', `${integer(state?.day) || 1}일차`), todayGrid);
        const workerRows = el('div', 'ww-income-workers');
        for (const worker of config?.workers ?? []) {
          if (!worker.enabled && !stats.byWorker[worker.id]) continue;
          const bucket = stats.byWorker[worker.id] ?? emptyBucket(), row = el('div', 'ww-income-worker');
          row.append(el('strong', '', worker.name), el('span', '', `매출 ${bucket.gross} · 업소 ${bucket.house} · 급료 ${bucket.wages} (일당 ${bucket.wageTopups}) · 결제 ${bucket.transactions}건`));
          workerRows.append(row);
        }
        body.append(el('h4', 'ww-section-title', '종업원별'), workerRows.childElementCount ? workerRows : el('p', 'ww-help', '아직 종업원 수입 기록이 없습니다.'));
        const recent = el('div', 'ww-income-recent');
        for (const record of stats.recent.slice(-10).reverse()) {
          const row = el('div', 'ww-income-row'), label = record.kind === 'stay' ? '숙박료' : record.kind === 'wage_topup' ? '고정 일당' : stageLabels[record.stage] ?? '서비스';
          const when = typeof formatTime === 'function' ? formatTime(record.slot) : '';
          row.append(el('span', '', `${record.day}일차 ${when}`), el('strong', '', `${record.workerName} · ${record.customer} · ${label}`), el('span', '', `${record.gross}골드 (업소 ${record.house} / 급료 ${record.wage})`));
          recent.append(row);
        }
        body.append(el('h4', 'ww-section-title', '최근 수입'), recent.childElementCount ? recent : el('p', 'ww-help', '아직 기록된 수입이 없습니다.'));
        panel.append(body);
        return panel;
      };
      const pricingPanel = (config, onSave) => {
        config.minimumPrices = normalizeMinimumPrices(config.minimumPrices);
        const section = el('div', 'ww-display-settings ww-price-settings'), head = el('div', 'ww-display-head');
        head.append(el('h4', '', '행위별 최소 서비스 금액'));
        section.append(head, el('p', 'ww-help', '손님의 소지금이 최저가보다 적으면 해당 행위 전에 접객을 중단합니다. 실제 요금은 손님의 재력에 따라 더 높아질 수 있습니다. 가슴 서비스는 손 서비스 금액을 사용하며, 대담함 55 초과 손님의 삽입 단계는 내부 사정 금액을 사용합니다.'));
        const grid = el('div', 'ww-price-grid');
        for (const [key, label] of minimumLabels) {
          const row = el('label', 'ww-price-row'), input = el('input'), unit = el('span', 'ww-display-unit', 'G');
          input.type = 'number'; input.min = '1'; input.max = '999'; input.step = '1'; input.value = String(config.minimumPrices[key]);
          input.addEventListener('change', () => {
            config.minimumPrices[key] = Math.max(1, Math.min(999, integer(input.value)));
            input.value = String(config.minimumPrices[key]);
            onSave?.();
          });
          row.append(el('span', '', label), input, unit); grid.append(row);
        }
        section.append(grid);
        return section;
      };
      const css = `#ww-settings .ww-income-stats,#ww-settings .ww-sex-history{border:1px solid #44403c;background:#0c0a09aa;border-radius:9px;padding:13px;margin-bottom:12px}#ww-settings .ww-income-stats>summary{cursor:pointer;color:#fbbf24;font-weight:700}#ww-settings .ww-income-body{padding-top:10px}#ww-settings .ww-income-grid,#ww-settings .ww-sex-counts{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px}#ww-settings .ww-stat-card{display:flex;flex-direction:column;gap:3px;border:1px solid #292524;border-radius:6px;background:#1c1917;padding:8px}#ww-settings .ww-stat-label{color:#a8a29e;font-size:10px}#ww-settings .ww-stat-value{color:#fcd34d;font-size:13px}#ww-settings .ww-sex-history{margin-top:10px;background:#1c191755}#ww-settings .ww-sex-records,#ww-settings .ww-income-workers,#ww-settings .ww-income-recent{display:grid;gap:5px;margin-top:8px}#ww-settings .ww-record-heading{color:#a8a29e;font-size:10px;font-weight:700;letter-spacing:.08em}#ww-settings .ww-sex-record,#ww-settings .ww-income-worker,#ww-settings .ww-income-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:7px;border-bottom:1px solid #292524;padding:6px 2px;color:#a8a29e;font-size:11px}#ww-settings .ww-sex-record strong,#ww-settings .ww-income-worker strong,#ww-settings .ww-income-row strong{color:#e7e5e4}#ww-settings .ww-income-row{grid-template-columns:82px minmax(0,1fr) auto}#ww-settings .ww-price-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px 14px;margin-top:8px}#ww-settings .ww-price-row{display:grid;grid-template-columns:minmax(0,1fr) 72px 18px;gap:6px;align-items:center;color:#d6d3d1;font-size:12px}#ww-settings .ww-price-row input{width:100%;box-sizing:border-box}@media(max-width:700px){#ww-settings .ww-income-grid,#ww-settings .ww-sex-counts{grid-template-columns:repeat(2,minmax(0,1fr))}#ww-settings .ww-income-row,#ww-settings .ww-sex-record,#ww-settings .ww-income-worker{grid-template-columns:1fr}#ww-settings .ww-price-grid{grid-template-columns:1fr}}`;
      return { stages, emptyWorkerData, emptyIncome, normalizeWorker, normalizeIncome, normalizeMinimumPrices, minimumPrice, recordExperience, recordIncome, recordWageTopup, log, experiencePanel, incomePanel, pricingPanel, css };
    })();
    // ---- 원본 애드온 ----
/* Wayward Brothel Addon - 2026-09-30 vanilla / MOD v2.107
 * A tavern-compatible brothel system.  It intentionally uses its own globals,
 * storage and UI identifiers so Waitress.js can be installed alongside it.
 */
/* --- Four-worker brothel system v3.3 --- */
(()=>{
  'use strict';
  if(globalThis.__WAYWARD_BROTHEL_ADDON_LOADED__)return;
  const api=globalThis.__WAYWARD_ADDON_API__;
  if(!api){console.error('[Wayward Addon] 게임 브리지를 찾지 못했습니다. Install_Addons.cmd를 먼저 실행하세요.');return}
  if(!api.ue?.getState||typeof api.Ol!=='function'||typeof api.Oe!=='function'){console.error('[Brothel Addon] 설치기를 다시 실행해 최신 게임 브리지를 적용하세요.');return}
  globalThis.__WAYWARD_BROTHEL_ADDON_LOADED__=true;
  const {ue,vt,g,ND,Oe,B,_t,Mt,Koe,Cj,Nj,pp,R0,Ji,ho,Ot,St}=api;
  let Ol=api.Ol;
  const WW_KEY='wayward-brothel-v3';
  const WW_NOTICE="전쟁으로 인해 젊은 나이에 과부가 되어 생활이 곤란한 여성들이 안전한 매춘 장소를 찾고 있었습니다. 그녀는 이들을 어떻게 도울까 질문했고, 당신은 이러한 소식을 듣고, 장소를 제공하고, 서비스 요금의 절반을 장소료 및 보호료로 받기로 했습니다. 그녀는 곤란해했지만, 자발적으로 희망하는 사람들에 한해서 허용하기로 했습니다. 그들은 홀에서 일을 하지 않고, 손님을 꼬셔서 가급적 보이지 않는 곳에서 농밀한 서비스를 하려고 할 것이며, 홀이 아닌 곳에서는 악명에 영향을 주지 않게 됩니다. 가급적 뒷방, 객실 등을 설치한 후에";
  const WW_CELLARS=[
    {id:'brothel_cellar_1',field:'hasBrothelCellar1',label:'지하방1'},
    {id:'brothel_cellar_2',field:'hasBrothelCellar2',label:'지하방2'}
  ];
  const WW_BREAK_ROOM={id:'brothel_break_room',field:'hasBrothelBreakRoom',label:'휴게실'};
  const WW_CUSTOM_ROOMS=[...WW_CELLARS,WW_BREAK_ROOM];
  const WW_CELLAR_COST=400,WW_CELLAR_MAINTENANCE=15;
  const WW_CELLAR_DESCRIPTION='지하 창고를 매춘을 위한 장소로 바꿉니다.';
  const WW_BREAK_ROOM_COST=200;
  const WW_BREAK_ROOM_DESCRIPTION="종업원들을 위한 휴게공간입니다. 당신, 그녀, 종업원만 들어올 수 있습니다.";
  const WW_HIRE_NOTICE='매춘부는 최대 4명까지 고용이 가능합니다. 해고시 기존의 매춘부의 기록은 사라지고, 새로운 매춘부를 고용하게 됩니다.';
  const WW_HIRE_TIERS=[
    {id:'ordinary',label:'일반 직원',cost:300,minWage:10,budgetMultiplier:1.3,traitEdits:1,sexRequestChance:.35,description:'기본 총점보다 30% 많은 능력치 예산을 사용합니다.'},
    {id:'skilled',label:'숙련 직원',cost:600,minWage:15,budgetMultiplier:1.6,traitEdits:3,sexRequestChance:.60,description:'기본 총점보다 60% 많은 능력치 예산을 사용합니다.'},
    {id:'beautiful',label:'최상급 직원',cost:1000,minWage:20,budgetMultiplier:2,traitEdits:6,sexRequestChance:.85,description:'기본 총점의 최대 두 배 능력치 예산을 사용합니다.'}
  ];
  const WW_PERSONALITIES=[
    ['shy','수줍음'],['pure','순수'],['cute','애교'],['girlish','낭만적'],['tsun','츤데레'],['yan','일편단심'],['devil','장난기'],['allure','여유로움'],
    ['noble','몰락 영애'],['holy','신앙심'],['queen','당당함'],['maso','인내심'],['cool','쿨데레'],['sporty','활발함'],['secretary','비서형']
  ];
  const WW_PERSONALITY_PRESETS={
    shy:{attributes:{confidence:25,openness:35},tendencies:{sociability:35,daring:25,intimacy:38},latentTraits:['self_protective']},
    pure:{attributes:{honesty:82,openness:34},tendencies:{service:68,flirtation:28,daring:25},latentTraits:['true_prude']},
    cute:{attributes:{charm:70,confidence:55},tendencies:{sociability:70,flirtation:58},latentTraits:['romance_starved']},
    girlish:{attributes:{openness:66,charm:62},tendencies:{intimacy:70,sociability:62},latentTraits:['romance_starved']},
    tsun:{attributes:{confidence:68,honesty:45,composure:68},tendencies:{sociability:42,intimacy:48},latentTraits:['self_protective']},
    yan:{attributes:{confidence:62,composure:42},tendencies:{intimacy:82,libido:68},latentTraits:['jealousy_kindled']},
    devil:{attributes:{wit:72,openness:74,confidence:70},tendencies:{flirtation:78,daring:70},traits:['flirtatious']},
    allure:{attributes:{charm:80,composure:72,confidence:72},tendencies:{flirtation:82,intimacy:72},latentTraits:['latent_exhibitionist']},
    noble:{attributes:{composure:80,honesty:68,charm:66},tendencies:{service:66,sociability:50},latentTraits:['cold_pragmatist']},
    holy:{attributes:{honesty:90,composure:72,openness:30},tendencies:{service:76,daring:24},latentTraits:['true_prude']},
    queen:{attributes:{confidence:86,composure:80},tendencies:{daring:76,sociability:65},latentTraits:['latent_dominant'],traits:['bold']},
    maso:{attributes:{vigor:70,composure:64},tendencies:{intimacy:68,libido:70},latentTraits:['latent_masochist'],traits:['submissive']},
    cool:{attributes:{composure:84,confidence:64,openness:42},tendencies:{sociability:36,service:66},latentTraits:['self_protective']},
    sporty:{attributes:{strength:70,vigor:80,deftness:64},tendencies:{sociability:74,daring:66},traits:['bold']},
    secretary:{attributes:{wit:82,composure:80,honesty:74},tendencies:{service:84,sociability:58},latentTraits:['cold_pragmatist'],traits:['pragmatic']}
  };
  const WW_WORKER_NAMES=['아그네스','로자','안나','클라라','이사벨','테레사','밀라','소피아','루시아','카타리나','베라','니나'];
  const WW_CANDIDATES=[
    {id:'elena',archetypeId:'elena_farmgirl',name:'엘레나'},
    {id:'mara',archetypeId:'mara_citygirl',name:'마라'},
    {id:'pippa',archetypeId:'pippa_waif',name:'피파'}
  ];
  const WW_DEFAULT_CANDIDATES=WW_CANDIDATES.map(candidate=>({...candidate}));
  const WW_CHARACTER_ID=/^[a-z0-9][a-z0-9_-]{0,99}$/;
  const WW_NUMERIC={
    stats:[['energy','기력'],['mood','기분'],['arousal','흥분도']],
    attributes:[['strength','힘'],['deftness','손재주'],['vigor','활력'],['wit','재치'],['composure','침착함'],['charm','매력'],['openness','개방성'],['confidence','자신감'],['honesty','정직성']],
    tendencies:[['service','업무 성실도'],['sociability','사교성'],['flirtation','유혹 성향'],['daring','대담함'],['intimacy','친밀 행동 성향'],['libido','성욕']]
  };
  const WW_TRAITS=[
    ['cautious','신중함'],['flirtatious','능숙한 유혹'],['bold','대담한 성격'],
    ['submissive','수동적 성향'],['pragmatic','실리적 성향'],['exhibitionist','시선 즐김']
  ];
  const WW_LATENT_TRAITS=[
    ['true_prude','극도로 보수적','노출·대담함·성적 행동 전반에 강한 저항을 보입니다.'],
    ['self_protective','자기보호적','위험하거나 꺼림칙한 상황에서 자신을 더 강하게 방어합니다.'],
    ['latent_dominant','지배 성향','상대보다 주도권을 잡는 행동에 더 기울어집니다.'],
    ['romance_starved','애정에 굶주림','다정함과 정서적 친밀감에 더 크게 반응합니다.'],
    ['likes_cheating','외도 성향','금기와 배우자 밖의 관계에 더 쉽게 끌릴 수 있습니다.'],
    ['cold_pragmatist','냉정한 실리주의자','감정보다 현실적 이득과 금전적 보상을 중시합니다.'],
    ['breaks_under_pressure','압박에 약함','지속적인 압박에 더 쉽게 흔들립니다.'],
    ['guilt_eroticizer','죄책감에서 흥분','죄책감이나 수치심이 자극으로 바뀌기 쉽습니다.'],
    ['latent_exhibitionist','노출 성향','남의 시선과 공개적인 노출에 긍정적으로 반응합니다.'],
    ['public_thrill_seeker','공개 스릴 추구','들킬 위험과 공개적인 상황의 긴장감을 즐깁니다.'],
    ['latent_submissive','복종 성향','상대에게 주도권을 넘기는 행동에 더 기울어집니다.'],
    ['easily_intoxicated','술에 쉽게 취함','술과 관련된 상황에서 판단과 반응이 크게 변합니다.'],
    ['enjoys_making_him_jealous','질투 유발을 즐김','배우자의 질투를 유도하는 상황에서 자극을 느낍니다.'],
    ['wants_to_be_corrupted','타락 욕구','점차 변하고 선을 넘는 과정 자체에 끌립니다.'],
    ['latent_masochist','피학 성향','거친 자극·고통·굴욕 계열에 반응할 수 있습니다.'],
    ['latent_voyeur','관음 성향','다른 사람의 행동을 지켜보는 상황에 반응합니다.'],
    ['curious_about_women','여성에게 호기심','여성 대상 관계나 사건에 호기심을 보입니다.'],
    ['jealousy_kindled','질투로 자극받음','질투와 경쟁 구도가 감정적·성적 자극이 됩니다.'],
    ['wary_of_drinks','술을 경계함','술과 관련된 권유와 상황을 조심스럽게 받아들입니다.'],
    ['latent_self_pleasure','숨겨진 자기쾌락 성향','혼자 욕구를 해소하는 상황에 반응합니다.']
  ];
  const WW_AFFINITIES=[
    ['romantic','로맨스','애정·다정함·정서적 친밀감'],['oral','구강','구강 계열 행동'],['vaginal','성관계','일반 성관계'],['anal','항문','항문 계열 행동'],['exhibition','노출','노출 및 남의 시선'],['submission','복종','상대에게 주도권을 넘기는 행동'],['domination','지배','본인이 주도권을 잡는 행동'],['prostitution','금전 관계','금전 대가가 있는 상황'],['drinking','음주','술과 음주 상황'],['taboo','금기','금기와 선을 넘는 상황']
  ];
  const WW_OUTFITS=[
    ['modest','수수한 작업복'],['nightshift','잠옷'],['bath_linen_wrap','린넨 목욕 두르개'],['bath_shift','목욕용 속옷'],['bath_towel','목욕 수건'],['peasant_smock','농부의 작업복'],['serving_dress','앞섶을 끈으로 여미는 드레스'],['patched_sundress','기워 입은 여름 원피스'],['linen_shift','린넨 속옷'],['barmaid_corset','주점 종업원의 코르셋'],['wench_bodice','몸을 감싸는 상의와 골반 치마'],['his_shirt',"당신의 셔츠"],['crop_blouse_skirt','짧은 블라우스와 미니스커트'],['strapless_thigh_boots','끈 없는 미니 원피스와 허벅지 부츠'],['silk_robe','비단 가운'],['lingerie','레이스 란제리'],['pink_babydoll','분홍 베이비돌'],['auburn_babydoll','적갈색 베이비돌'],['satin_babydoll','새틴 베이비돌'],['sheer_chemise','비치는 슈미즈'],['sheer_nightgown','비치는 잠옷'],['panties_only','팬티만 착용'],['slave_collar','목줄과 쇠사슬'],['nude','나체']
  ];
  const WW_AUTO_OUTFITS=WW_OUTFITS.map(([id])=>id).filter(id=>!['nightshift','bath_linen_wrap','bath_shift','bath_towel','panties_only','slave_collar','nude'].includes(id));
  const WW_TASK_TIME={rest:30};
  const WW_TASK_LABEL={idle:'손님을 찾는 중',rest:'휴게실에서 쉬는 중',aftercare:'서비스 후 정리 중',night_rest:'밤 휴식 중',interaction:'손님과 함께 있음'};
  const WW_STAGE_LABEL={chatting:'대화',flirting:'추파와 농담',light_touch:'가벼운 접촉',bold_touch:'대담한 접촉',groping:'짙은 스킨십',intimate:'은밀한 애무',handjob_patron:'손으로 해 주는 중',blowjob_patron:'입으로 해 주는 중',titfuck_patron:'가슴으로 해 주는 중',sex_patron:'성관계 중'};
  const WW_SCENE={chatting:'patron_chatting',flirting:'patron_flirting',light_touch:'patron_flirting',bold_touch:'patron_groping',groping:'patron_groping',intimate:'patron_intimate',handjob_patron:'patron_handjob',blowjob_patron:'patron_blowjob',titfuck_patron:'patron_titfuck',sex_patron:'patron_sex'};
  const WW_LOCATION_LABEL={...api.brothel?.roomLabels,taproom:'홀',back_room:'뒷방',bedroom:'침실',elena_room:'그녀의 방',bathhouse:'목욕탕',bathroom:'욕실',kitchen:'부엌',upstairs_hall:'객실 1',upstairs_room_2:'객실 2',brothel_cellar_1:'지하방1',brothel_cellar_2:'지하방2',brothel_break_room:'휴게실',market:'시장',side_job:'부업',merchant:'상인',wilds:'숲',village:'마을'};
  // Only customer-accessible service rooms belong here. Bedrooms, kitchen and
  // outdoor locations still have labels/image mappings but are never recruited.
  const WW_SERVICE_ROOMS=[
    ...WW_CELLARS,
    {id:'upstairs_hall',field:'hasRoom',renterField:'tonightRenter'},
    {id:'upstairs_room_2',field:'hasRoom2',renterField:'tonightRenter2'},
    {id:'back_room',field:'backRoomReady'},
    {id:'bathroom'},
    {id:'bathhouse',field:'hasBathhouse'}
  ];
  const wwPositive=value=>Number.isSafeInteger(value)&&value>=1;
  function wwPanelLayout(value){const [columns,rows]=String(value).split('x').map(Number);return wwPositive(columns)&&wwPositive(rows)&&Number.isSafeInteger(columns*rows)?{columns,rows,capacity:columns*rows,width:Math.min(1100,columns*285),height:Math.min(900,rows*380)}:null;}
  const WW_CORE_WINDOW_KEY='wayward-brothel-core-windows-v1',WW_CORE_PANES=['story','house','focus','actions'],WW_CORE_LABELS={story:'이야기',house:'가게',focus:'그녀',actions:'행동'},WW_CORE_HEADER=30;
  const WW_PAID_STAGES=new Set(['groping','intimate','handjob_patron','blowjob_patron','titfuck_patron','sex_patron']);
  const WW_AFTERCARE_MINUTES={groping:2,intimate:2,handjob_patron:4,blowjob_patron:4,titfuck_patron:4,sex_patron:6};
  const WW_EXPOSED_STAGES=new Set(['handjob_patron','blowjob_patron','titfuck_patron','sex_patron']);
  const WW_PRIVATE_ROOMS=new Set(WW_SERVICE_ROOMS.map(room=>room.id));
  let wwConfig=null,wwSavedRaw=null,wwOriginalOl=null,wwLastSlot=null,wwLastDay=null,wwSelectedId='brothel_worker_1',wwUi=null,wwDecorateQueued=false,wwEditorRevision=0;
  const wwNewHireDraft=()=>({tierId:'ordinary',candidateId:'elena',personality:'shy',name:'',mode:'random',template:null,templateKey:'',attributes:{},traits:{},latentTraits:{}});
  let wwHireDraft=wwNewHireDraft(),wwHireWindow=null,wwHireView=null;
  let wwCoreLayout=null,wwCoreZ=100;
  const wwRuntime=new Map(),wwPortraitCache=new Map(),wwCoreWindows=new Map();

  function wwClamp(value,min=0,max=100){return Math.max(min,Math.min(max,Number(value)||0))}
  function wwClone(value){try{return structuredClone(value)}catch{return JSON.parse(JSON.stringify(value))}}
  function Brothel_성인캐릭터인지읽기(wife){
    const age=Number(wife.age),text=[wife.tagline,wife.backstory,wife.imageBase].filter(Boolean).join(' ');
    if(Number.isFinite(age)&&age>0&&age<18)return false;
    if(/미성년|초등|중학생|아동|어린이|\b(?:minor|underage|preteen|child|loli|shota)\b/i.test(text))return false;
    return ![...text.matchAll(/\b(\d{1,3})\s*(?:세|살|years?\s*old|year-old|y\/o)/gi)].some(match=>Number(match[1])<18);
  }
  function Brothel_캐릭터탐색하기(){
    const previous=new Set(WW_CANDIDATES.map(candidate=>candidate.id)),characters=new Map();let skipped=0;
    for(const wife of [...Brothel_등록캐릭터읽기(),...(globalThis.__WAYWARD_WIFE_ADDONS__||[])]){
      if(!wife||typeof wife!=='object'){skipped++;continue}
      const id=String(wife.shortname||'').trim().toLowerCase(),archetypeId=String(wife.id||'').trim();
      if(!WW_CHARACTER_ID.test(id)||id==='patron'||!archetypeId||characters.has(id)||!Brothel_성인캐릭터인지읽기(wife)){skipped++;continue}
      characters.set(id,{id,archetypeId,name:String(wife.name||id).trim().slice(0,100)||id,archetype:wife});
    }
    for(const candidate of WW_DEFAULT_CANDIDATES)if(!characters.has(candidate.id))characters.set(candidate.id,{...candidate});
    WW_CANDIDATES.splice(0,WW_CANDIDATES.length,...characters.values());
    return{characters:WW_CANDIDATES.map(({id,archetypeId,name})=>({id,archetypeId,name})),added:WW_CANDIDATES.filter(candidate=>!previous.has(candidate.id)).length,skipped};
  }
  function wwCandidate(id){
    let candidate=WW_CANDIDATES.find(item=>item.id===id);
    if(!candidate){Brothel_캐릭터탐색하기();candidate=WW_CANDIDATES.find(item=>item.id===id)}
    return candidate??null;
  }
  function wwCurrentWifePortrait(state){
    try{return ND(g(state).archetypeId,g(state).generatedArchetype)}catch{return'elena'}
  }
  function wwRandomInt(min,max){return min+Math.floor(Math.random()*(max-min+1))}
  function wwGeneratedCharacter(candidate,state,name){
    try{
      const archetype=candidate?.archetype??wmlApi.fn('wifeById')(candidate?.archetypeId)??wmlApi.fn('wifeById')('elena_farmgirl');
      return wmlApi.fn('brothelCharacterFromArchetype')(archetype,{id:'brothel_hire_preview',name,day:state?.day??1});
    }catch{return null}
  }
  function wwApplyPersonality(worker,personality){
    const preset=WW_PERSONALITY_PRESETS[personality]??WW_PERSONALITY_PRESETS.shy;
    for(const[key,value]of Object.entries(preset.attributes??{}))if(Object.hasOwn(worker.attributes,key))worker.attributes[key]=wwClamp(value);
    for(const[key,value]of Object.entries(preset.tendencies??{}))if(Object.hasOwn(worker.tendencies,key))worker.tendencies[key]=wwClamp(value);
    for(const key of preset.traits??[])if(Object.hasOwn(worker.traits,key))worker.traits[key]=true;
    for(const key of preset.latentTraits??[])if(Object.hasOwn(worker.latentTraits,key))worker.latentTraits[key]=true;
    worker.personality=personality;return worker;
  }
  function wwPreset(id,name,state,personality='shy'){
    const candidate=wwCandidate(id),character=wwGeneratedCharacter(candidate,state,name);
    const stats=Object.fromEntries(WW_NUMERIC.stats.map(([key])=>[key,wwClamp(character?.stats?.[key]??(key==='arousal'?wwRandomInt(0,25):key==='mood'?wwRandomInt(45,90):wwRandomInt(60,100)))]));
    const attributes=Object.fromEntries(WW_NUMERIC.attributes.map(([key])=>[key,wwClamp(character?.attributes?.[key]??wwRandomInt(20,90))]));
    const tendencies=Object.fromEntries(WW_NUMERIC.tendencies.map(([key])=>[key,50]));
    const traits=Object.fromEntries(WW_TRAITS.map(([key])=>[key,Math.random()<.38]));
    const characterTraits=new Set(character?.latentTraits??[]),latentTraits=Object.fromEntries(WW_LATENT_TRAITS.map(([key])=>[key,characterTraits.has(key)]));
    const affinities=Object.fromEntries(WW_AFFINITIES.map(([key])=>[key,wwClamp(character?.affinities?.[key]??Math.round((Math.random()*4-2)*10)/10,-2,2)]));
    return wwApplyPersonality({id:'',enabled:false,name,portrait:id,outfitMode:'auto',showPanel:true,hireTier:null,stats,attributes,tendencies,traits,latentTraits,affinities,...WBE.emptyWorkerData()},personality);
  }
  function wwHireTemplate(state,options={}){
    Brothel_캐릭터탐색하기();const candidate=wwCandidate(options.candidateId)??WW_CANDIDATES[0],personality=WW_PERSONALITIES.some(([id])=>id===options.personality)?options.personality:'shy';
    const used=new Set(wwActiveWorkers().map(worker=>worker.name));used.add(g(state)?.name);const names=WW_WORKER_NAMES.filter(name=>!used.has(name));
    const name=String(options.name||'').trim().slice(0,24)||names[Math.floor(Math.random()*names.length)]||'새 매춘부';
    const worker=wwPreset(candidate.id,name,state,personality),baseAttributes={...worker.attributes},baseTraits={...worker.traits},baseLatentTraits={...worker.latentTraits};
    return{candidateId:candidate.id,personality,name,worker,baseAttributes,baseTraits,baseLatentTraits};
  }
  function wwRandomAllocation(base,budget){
    const values={...base};let remaining=Math.max(0,budget-Math.round(Object.values(values).reduce((sum,value)=>sum+Number(value||0),0))),open=Object.keys(values).filter(key=>values[key]<100);
    while(remaining>0&&open.length){const index=Math.floor(Math.random()*open.length),key=open[index],gain=Math.min(remaining,100-values[key],1+Math.floor(Math.random()*8));values[key]+=gain;remaining-=gain;if(values[key]>=100)open.splice(index,1)}
    return values;
  }
  function wwCreateHiredWorker(index,tier,state,options={}){
    let template=options.template;
    if(!template||template.candidateId!==(options.candidateId||'elena')||template.personality!==(options.personality||'shy'))template=wwHireTemplate(state,options);else template=wwClone(template);
    const worker=template.worker,baseAttributes=Object.fromEntries(WW_NUMERIC.attributes.map(([key])=>[key,wwClamp(template.baseAttributes?.[key]??worker.attributes[key])]));
    const baseTotal=Math.round(Object.values(baseAttributes).reduce((sum,value)=>sum+value,0)),budget=Math.min(WW_NUMERIC.attributes.length*100,Math.round(baseTotal*tier.budgetMultiplier));
    if(options.mode==='specified'){
      for(const[key]of WW_NUMERIC.attributes){const value=Number(options.attributes?.[key]);if(!Number.isFinite(value)||value<0||value>100)throw Error('지정 고용 능력치는 각각 0~100이어야 합니다.');worker.attributes[key]=Math.round(value)}
      if(WW_NUMERIC.attributes.reduce((sum,[key])=>sum+worker.attributes[key],0)>budget)throw Error('지정 고용 능력치 총점이 등급별 배분 예산을 넘었습니다.');
      for(const[key]of WW_TRAITS)worker.traits[key]=!!options.traits?.[key];for(const[key]of WW_LATENT_TRAITS)worker.latentTraits[key]=!!options.latentTraits?.[key];
    }else worker.attributes=wwRandomAllocation(baseAttributes,budget);
    const traitChanges=WW_TRAITS.filter(([key])=>!!worker.traits[key]!==!!template.baseTraits?.[key]).length+WW_LATENT_TRAITS.filter(([key])=>!!worker.latentTraits[key]!==!!template.baseLatentTraits?.[key]).length;
    if(traitChanges>tier.traitEdits)throw Error('이 등급에서 바꿀 수 있는 체크형 특성 수를 넘었습니다.');
    worker.name=String(options.name||template.name||worker.name).trim().slice(0,24)||template.name||`새 매춘부 ${index+1}`;
    worker.id=`brothel_worker_${index+1}`;worker.enabled=true;worker.hireTier=tier.id;worker.hireCost=tier.cost;worker.lastFullRestDay=state.day??1;
    worker.relationshipId=globalThis.crypto?.randomUUID?.()??`${Date.now()}:${Math.random()}`;
    worker.hireAllocation={mode:options.mode==='specified'?'specified':'random',baseTotal,budget,baseAttributes,baseTraits:template.baseTraits,baseLatentTraits:template.baseLatentTraits,traitChanges};
    worker.wageLedger={day:state.day??1,serviceWages:0,worked:false,unpaid:0,lastSettledDay:(state.day??1)-1,blockedNotified:false};
    return worker;
  }
  function wwDefaults(state){
    const wifePortrait=wwCurrentWifePortrait(state),others=WW_CANDIDATES.filter(item=>item.id!==wifePortrait);
    const workers=[
      wwPreset(wifePortrait,'아그네스',state),
      wwPreset(others[0]?.id??'mara',others[0]?.name??'마라',state),
      wwPreset(others[1]?.id??'pippa',others[1]?.name??'피파',state),
      wwPreset(others[0]?.id??'elena','로자',state)
    ];
    workers.forEach((worker,index)=>worker.id=`brothel_worker_${index+1}`);
    return{version:12,enabled:false,allowTaproomSex:false,serviceRenownGainMultiplier:1,showLivePanel:false,showWifePanel:true,panelLayout:'3x2',panelRect:null,panelSide:'right',liveImageHeight:145,liveStatusHeight:62,liveStoryHeight:135,minimumPrices:WBE.normalizeMinimumPrices(),incomeStats:WBE.emptyIncome(),workers};
  }
  function wwMergeWorker(base,raw){
    const out={...base,...raw,stats:{...base.stats,...raw?.stats},attributes:{...base.attributes,...raw?.attributes},tendencies:{...base.tendencies,...raw?.tendencies},traits:{...base.traits,...raw?.traits},latentTraits:{...base.latentTraits,...raw?.latentTraits},affinities:{...base.affinities,...raw?.affinities}};
    for(const group of Object.keys(WW_NUMERIC))for(const[key]of WW_NUMERIC[group])out[group][key]=wwClamp(out[group][key]);
    for(const[key]of WW_TRAITS)out.traits[key]=!!out.traits[key];for(const[key]of WW_LATENT_TRAITS)out.latentTraits[key]=!!out.latentTraits[key];for(const[key]of WW_AFFINITIES)out.affinities[key]=wwClamp(out.affinities[key],-2,2);
    out.enabled=raw?.enabled===true;out.personality=WW_PERSONALITIES.some(([id])=>id===out.personality)?out.personality:'shy';
    const ledger=raw?.wageLedger??{},day=Math.max(1,Math.floor(Number(ledger.day)||1));out.wageLedger={day,serviceWages:Math.max(0,Math.floor(Number(ledger.serviceWages)||0)),worked:ledger.worked===true,unpaid:Math.max(0,Math.floor(Number(ledger.unpaid)||0)),lastSettledDay:Math.max(0,Math.floor(Number(ledger.lastSettledDay)||day-1)),blockedNotified:ledger.blockedNotified===true};
    out.name=String(out.name??base.name).trim().slice(0,24)||base.name;
    const portrait=String(out.portrait??'').trim().toLowerCase();
    out.portrait=WW_CHARACTER_ID.test(portrait)&&portrait!=='patron'?portrait:base.portrait;
    out.outfitMode=out.outfitMode==='auto'||WW_OUTFITS.some(([id])=>id===out.outfitMode)?out.outfitMode:'auto';Object.assign(out,WBE.normalizeWorker(raw));
    return out;
  }
  function wwReadSaved(){
    try{return JSON.parse(localStorage.getItem(WW_KEY)||'null')}catch{return null}
  }
  function wwEnsureConfig(state){
    if(wwConfig)return wwConfig;
    Brothel_캐릭터탐색하기();
    const base=wwDefaults(state),saved=wwSavedRaw??wwReadSaved(),raw=saved??{};
    const migrateRoster=Number(raw.version??0)<8;
    wwConfig={...base,...raw,version:12,minimumPrices:WBE.normalizeMinimumPrices(raw.minimumPrices),incomeStats:WBE.normalizeIncome(raw.incomeStats),enabled:raw.enabled===true,allowTaproomSex:raw.allowTaproomSex===true,serviceRenownGainMultiplier:Math.round(wwClamp(raw.serviceRenownGainMultiplier??base.serviceRenownGainMultiplier,0,1)*10)/10,showLivePanel:raw.showLivePanel===true,panelLayout:wwPanelLayout(raw.panelLayout)?raw.panelLayout:base.panelLayout,liveImageHeight:Math.round(wwClamp(raw.liveImageHeight??base.liveImageHeight,70,1080)),liveStatusHeight:Math.round(wwClamp(raw.liveStatusHeight??base.liveStatusHeight,40,220)),liveStoryHeight:Math.round(wwClamp(raw.liveStoryHeight??base.liveStoryHeight,60,360)),workers:base.workers.map((worker,index)=>wwMergeWorker(worker,raw.workers?.[index]??{}))};
    delete wwConfig.liveFontScale;
    if(migrateRoster){wwConfig.enabled=false;for(const worker of wwConfig.workers)worker.enabled=false}
    if(!saved||migrateRoster)try{localStorage.setItem(WW_KEY,JSON.stringify(wwConfig))}catch{}
    return wwConfig;
  }
  function wwActiveWorkers(config=wwConfig){return config?config.workers.filter(worker=>worker.enabled):[]}
  function wwSave(){
    if(!wwConfig)return;
    try{localStorage.setItem(WW_KEY,JSON.stringify(wwConfig));wwEditorRevision++}catch{}
    wwRenderLive();wwScheduleDecorate();
  }
  function wwPersistConfig(){if(wwConfig)try{localStorage.setItem(WW_KEY,JSON.stringify(wwConfig));wwEditorRevision++}catch{}}
  function wwFreshCampaign(state){return state?.day===1&&state.phase==='prep'&&(state.economy?.gold??0)===50&&(state.economy?.debt??0)===1000&&(state.patronRecords?.length??0)===0&&state.tavern?.quality===30&&!state.tavern?.backRoomReady&&!state.tavern?.hasRoom}
  function wwResetRoster(){if(!wwConfig)return;wwConfig.enabled=false;for(const worker of wwConfig.workers)worker.enabled=false;wwRuntime.clear();wwPersistConfig()}
  function wwInitializeCampaign(state){
    if(!state||state.brothelAddonCampaignVersion>=1)return state;
    wwEnsureConfig(state);if(wwFreshCampaign(state))wwResetRoster();
    return{...state,brothelAddonCampaignVersion:1};
  }
  function wwGetRuntime(worker,state){
    let runtime=wwRuntime.get(worker.id);
    if(!runtime){runtime={id:worker.id,task:'idle',taskTarget:null,location:'taproom',busyUntil:state.slot,stats:{...worker.stats},interaction:null,pendingInteractId:null,wagesEarned:0,situation:'홀에서 함께 시간을 보낼 손님을 찾고 있습니다.',portraitKey:null,currentOutfit:'serving_dress',outfitSignature:null};wwRuntime.set(worker.id,runtime)}
    const assignment=state?.mods?.brothel?.assignments?.[worker.id];
    if(assignment){runtime.externalOwner=assignment.owner;runtime.task=assignment.task;runtime.location=assignment.location;runtime.situation=assignment.situation;runtime.busyUntil=assignment.busyUntil??Number.POSITIVE_INFINITY;runtime.interaction=assignment.interaction?wwClone(assignment.interaction):null}
    else if(runtime.externalOwner){runtime.externalOwner=null;runtime.task='idle';runtime.location='taproom';runtime.busyUntil=state.slot;runtime.situation='출장 작업을 마치고 홀로 돌아왔습니다.'}
    return runtime;
  }
  function wwResetRuntime(state){
    wwRuntime.clear();
    const config=wwEnsureConfig(state);
    for(const worker of config.workers)wwGetRuntime(worker,state);
  }
  function wwSyncConfiguredStats(worker){
    const runtime=wwRuntime.get(worker.id);if(runtime)runtime.stats={...runtime.stats,...worker.stats};
  }
  function wwInvalidateLook(worker){const runtime=wwRuntime.get(worker.id);if(runtime){runtime.portraitKey=null;runtime.outfitSignature=null}}
  function wwSeededRandom(text){let seed=2166136261;for(let i=0;i<text.length;i++)seed=Math.imul(seed^text.charCodeAt(i),16777619);return()=>{seed+=0x6D2B79F5;let value=seed;value=Math.imul(value^value>>>15,value|1);value^=value+Math.imul(value^value>>>7,value|61);return((value^value>>>14)>>>0)/4294967296}}
  function wwResolveOutfit(worker,runtime,state){
    if(worker.outfitMode!=='auto'){runtime.currentOutfit=worker.outfitMode;return runtime.currentOutfit}const day=state.day??Math.floor((state.slot??0)/1440),signature=`${day}|${worker.portrait}|${worker.attributes.openness}|${worker.attributes.confidence}|${worker.tendencies.daring}|${worker.tendencies.intimacy}|${Object.values(worker.latentTraits).map(Number).join('')}|${Object.values(worker.affinities).join(',')}`;if(runtime.outfitSignature===signature&&runtime.currentOutfit)return runtime.currentOutfit;
    const lt=worker.latentTraits,af=worker.affinities,random=wwSeededRandom(`${worker.id}:${signature}`),dressLatitude=(af.exhibition+af.taboo)*12+(lt.latent_exhibitionist?12:0)+(lt.public_thrill_seeker?8:0)+(lt.true_prude?-18:0),libido=wwClamp(38+worker.tendencies.intimacy*.35+af.vaginal*6+af.oral*4+(lt.wants_to_be_corrupted?8:0),8,95),moneyPressure=worker.traits.pragmatic||lt.cold_pragmatist?58:22;
    try{runtime.currentOutfit=Koe({traits:{...worker.attributes},stats:runtime.stats,ownedOutfits:WW_AUTO_OUTFITS,unwornOutfits:[],moneyPressure,libido,dressLatitude,wit:worker.attributes.wit},random)}catch{const target=wwClamp(worker.attributes.openness*.45+worker.attributes.confidence*.25+worker.tendencies.daring*.2+dressLatitude*.25);const available=WW_OUTFITS.filter(([id])=>WW_AUTO_OUTFITS.includes(id));runtime.currentOutfit=(available[Math.min(available.length-1,Math.floor(target/101*available.length))]??['serving_dress'])[0]}
    runtime.outfitSignature=signature;return runtime.currentOutfit;
  }
  function wwOutfitName(id){return WW_OUTFITS.find(([key])=>key===id)?.[1]??id}
  function wwLog(state,text,workerId){return WBE.log(api,state,text,workerId)}
  function wwRegisterRooms(){
    for(const room of WW_CUSTOM_ROOMS){
      if(Array.isArray(api.Va)&&!api.Va.includes(room.id))api.Va.push(room.id);
      api.uM?.add?.(room.id);
      const exits=new Set(['taproom','back_room']);
      if(typeof api.H2?.set==='function')api.H2.set(room.id,exits);else if(api.H2)api.H2[room.id]=exits;
      const taproomExits=typeof api.H2?.get==='function'?api.H2.get('taproom'):api.H2?.taproom;taproomExits?.add?.(room.id);
      if(api.R2)api.R2[room.id]=room.label;
      if(api.brothel?.roomLabels)api.brothel.roomLabels[room.id]=room.label;
    }
  }
  function wwEnsureRooms(state){
    if(!state?.locations)return state;
    let locations=state.locations,changed=false;
    for(const room of WW_CUSTOM_ROOMS)if(!locations[room.id]){if(!changed)locations={...locations};locations[room.id]={occupants:[]};changed=true}
    return changed?{...state,locations}:state;
  }
  function wwNormalizeOrphanedCustomers(state){
    if(typeof ho!=='function')return state;let next=state;
    for(const room of WW_SERVICE_ROOMS){
      const reservation=next.locations?.[room.id]?.meta?.brothelReservation;if(!reservation)continue;
      const runtime=wwRuntime.get(reservation.workerId),customer=next.customers?.find(item=>item.id===reservation.customerId);
      if(runtime?.interaction?.customerId===reservation.customerId&&runtime.location===room.id)continue;
      next=wwClearReservation(next,room.id,reservation.customerId);
      if(customer&&wwCustomerRoom(next,customer)===room.id&&B(next)?.customerId!==customer.id&&!api.brothel?.customerBusy?.(next,customer.id))next=wwMoveCustomer(next,customer.id,'taproom');
    }
    for(const room of WW_CELLARS)for(const id of next.locations?.[room.id]?.occupants??[]){
      if(!next.customers?.some(customer=>customer.id===id))continue;
      if(B(next)?.customerId===id||api.brothel?.customerBusy?.(next,id))continue;
      const active=[...wwRuntime.values()].some(runtime=>runtime.interaction?.customerId===id&&runtime.location===room.id);
      if(!active)try{next=ho(next,id,'taproom')}catch{}
    }
    for(const id of next.locations?.[WW_BREAK_ROOM.id]?.occupants??[])if(next.customers?.some(customer=>customer.id===id))next=wwMoveCustomer(next,id,'taproom');
    return next;
  }
  function wwClearReservation(state,room,customerId){
    const location=state.locations?.[room];if(location?.meta?.brothelReservation?.customerId!==customerId)return state;
    const meta={...location.meta};delete meta.brothelReservation;
    return{...state,locations:{...state.locations,[room]:{...location,meta}}};
  }
  function wwInstallMaintenance(){
    if(typeof api.Bb!=='function')return;const base=api.Bb;
    api.Bb=state=>base(state)+WW_CELLARS.reduce((sum,room)=>sum+(state?.tavern?.[room.field]?WW_CELLAR_MAINTENANCE:0),0);
  }
  function wwRoomBuilt(state,room){
    const definition=[...WW_SERVICE_ROOMS,WW_BREAK_ROOM].find(item=>item.id===room);
    if(!definition)return false;
    if(room==='upstairs_room_2'&&!state.tavern?.hasRoom)return false;
    return definition.field?state.tavern?.[definition.field]===true:!!state.locations?.[room];
  }
  function wwRoomFree(state,room,customerId){
    if(!wwRoomBuilt(state,room))return false;
    const definition=WW_SERVICE_ROOMS.find(item=>item.id===room),renter=state.tavern?.[definition?.renterField];
    // A reservation without a spawned customer ID is still an occupied room.
    if(renter&&(!customerId||renter.customerId!==customerId))return false;
    if(api.brothel?.roomBusy?.(state,room))return false;
    const meta=state.locations?.[room]?.meta;
    if(meta?.privatePatron&&state.slot<meta.privatePatron.returnAtSlot||meta?.party&&state.slot<meta.party.endSlot)return false;
    const occupants=state.locations?.[room]?.occupants??[];
    if(occupants.some(id=>id!==customerId))return false;
    return ![...wwRuntime.values()].some(runtime=>runtime.interaction&&runtime.location===room&&runtime.interaction.customerId!==customerId);
  }
  function wwChoosePrivateRoom(state,customerId){
    return WW_SERVICE_ROOMS.find(room=>wwRoomFree(state,room.id,customerId))?.id??null;
  }
  function wwMoveCustomer(state,customerId,room){
    let next=wwEnsureRooms(state);
    if(typeof ho==='function')try{next=ho(next,customerId,room)}catch{}
    if(next.locations?.[room]?.occupants?.includes(customerId))return next;
    const locations={...next.locations};
    for(const key of Object.keys(locations)){const current=locations[key];if(!current?.occupants?.includes(customerId))continue;locations[key]={...current,occupants:current.occupants.filter(id=>id!==customerId)}}
    locations[room]={...(locations[room]??{}),occupants:[...(locations[room]?.occupants??[]),customerId]};
    return{...next,locations};
  }
  function wwMoveInteractionToRoom(state,worker,runtime,customer,room){
    let next=wwMoveCustomer(state,customer.id,room);
    const location=next.locations[room];next={...next,locations:{...next.locations,[room]:{...location,meta:{...location.meta,brothelReservation:{workerId:worker.id,customerId:customer.id}}}}};
    if(runtime.interaction?.sharedWithWife&&Oe(next)==='taproom'&&typeof St==='function')try{next=St(next,room,undefined)}catch{}
    runtime.location=room;
    return wwLog(next,`${worker.name}이(가) ${customer.name}의 손을 잡고 ${WW_LOCATION_LABEL[room]}(으)로 이끕니다.`,worker.id);
  }
  function wwCustomerRoom(state,customer){try{return _t(state,customer.id)??'taproom'}catch{return'taproom'}}
  function wwWifeAvailable(state){
    try{const wife=g(state),task=wife.currentTask;return Oe(state)==='taproom'&&wife.retiredAtSlot==null&&!['sleeping','passed_out','bathing'].includes(task)}catch{return false}
  }
  function wwWifeCanTakeInteraction(state){
    try{const wife=g(state),task=wife.currentTask;return Oe(state)==='taproom'&&wife.retiredAtSlot==null&&!B(state)&&(!task||task==='idle')&&!['sleeping','passed_out','bathing'].includes(task)}catch{return false}
  }
  function wwBegin(worker,runtime,state,task,duration,target,situation){
    runtime.task=task;runtime.taskTarget=target??null;runtime.busyUntil=state.slot+duration;runtime.location='taproom';runtime.situation=situation??WW_TASK_LABEL[task]??'근무 중';
  }
  function wwServiceEnergyCost(worker,stage){
    const base={chatting:0,flirting:0,light_touch:1,bold_touch:2,groping:4,intimate:7,handjob_patron:10,blowjob_patron:12,titfuck_patron:12,sex_patron:20}[stage]??0;if(base===0)return 0;
    const libido=wwClamp(worker.tendencies?.libido??50),multiplier=wwClamp(1.4-libido/100,.55,1.6);return base*multiplier;
  }
  function wwSpend(worker,runtime,energy,mood=0,arousal=0){
    const energyMultiplier=globalThis.__waywardBrothelPregnancy?.energyMultiplier?.(worker.id)??1;
    runtime.stats.energy=wwClamp(runtime.stats.energy-energy*energyMultiplier);runtime.stats.mood=wwClamp(runtime.stats.mood+mood);runtime.stats.arousal=wwClamp(runtime.stats.arousal+arousal);worker.stats={...runtime.stats};wwPersistConfig();
  }
  function wwHireTier(worker){return WW_HIRE_TIERS.find(item=>item.id===worker?.hireTier)??WW_HIRE_TIERS[0]}
  function wwWageLedger(worker,state){
    const raw=worker.wageLedger??{},day=Math.max(1,Math.floor(Number(raw.day)||Number(state?.day)||1));
    return worker.wageLedger={day,serviceWages:Math.max(0,Math.floor(Number(raw.serviceWages)||0)),worked:raw.worked===true,unpaid:Math.max(0,Math.floor(Number(raw.unpaid)||0)),lastSettledDay:Math.max(0,Math.floor(Number(raw.lastSettledDay)||day-1)),blockedNotified:raw.blockedNotified===true};
  }
  const wwUnpaidWages=(state,worker)=>Brothel_자료읽기(state).payroll?.[worker.id]?.unpaid??wwWageLedger(worker,state).unpaid;
  function wwRecordServiceWage(worker,state,wage){const ledger=wwWageLedger(worker,state);if(ledger.day!==state.day){ledger.day=state.day;ledger.serviceWages=0;ledger.worked=false}ledger.worked=true;ledger.serviceWages+=Math.max(0,Math.floor(Number(wage)||0))}
  function wwPayDailyWages(state,config){
    let next=state,changed=false;
    const payroll={...Brothel_자료읽기(state).payroll};
    for(const worker of wwActiveWorkers(config)){
      const saved=payroll[worker.id];
      const ledger={unpaid:wwUnpaidWages(next,worker),blockedNotified:saved?.blockedNotified===true};
      let chargedDay=saved?.chargedDay;
      if(next.phase==='prep'&&chargedDay!==next.day){
        ledger.unpaid+=wwHireTier(worker).minWage;
        chargedDay=next.day;
        changed=true;
      }
      if(ledger.unpaid>0){
        const gold=Math.max(0,Number(next.economy?.gold)||0),available=Math.floor(gold),paid=Math.min(available,ledger.unpaid);
        if(paid>0){next={...next,economy:{...next.economy,gold:gold-paid}};ledger.unpaid-=paid;WBE.recordWageTopup(config,next,worker,paid);changed=true;
          next=wwLog(next,`${worker.name}에게 고정 일당 ${paid}골드를 지급했습니다.`,worker.id)}
        if(ledger.unpaid>0&&!ledger.blockedNotified){ledger.blockedNotified=true;changed=true;next=wwLog(next,`${worker.name}의 미지급 급료 ${ledger.unpaid}골드를 완납할 때까지 근무를 보류합니다.`,worker.id)}
        if(ledger.unpaid===0)ledger.blockedNotified=false;
      }
      if(chargedDay!=null||ledger.unpaid>0||saved)payroll[worker.id]={chargedDay,unpaid:ledger.unpaid,blockedNotified:ledger.blockedNotified};
    }
    if(!changed)return next;
    wwPersistConfig();
    return Brothel_자료쓰기(next,{payroll});
  }
  const wwOnBirthLeave=(state,id)=>Brothel_자료읽기(state).birthLeave?.[id]===state.day;
  function wwWorkerHasService(state,id){
    const data=Brothel_자료읽기(state);
    return !!(wwRuntime.get(id)?.interaction||data.assignments[id]||data.playerSession?.workerId===id);
  }
  function wwWorkCustomer(state,customer,claimed){
    if(!customer||claimed.has(customer.id)||['leaving','gone'].includes(customer.status)||wwCustomerRoom(state,customer)!=='taproom')return false;
    return true;
  }
  function wwInteractionScore(worker,customer,state){
    const record=Brothel_손님관계기능.record(state,worker,customer.name),a=worker.attributes,t=worker.tendencies,tr=worker.traits,lt=worker.latentTraits,af=worker.affinities;
    let score=68+a.openness*.05+a.confidence*.04+a.charm*.05+t.flirtation*.08+t.daring*.07+t.intimacy*.10+(record?.sexual??0)*.06+(customer.charm??40)*.05+(customer.boldness??30)*.08;
    tr.flirtatious&&(score+=5);tr.bold&&(score+=5);tr.cautious&&(score-=3);tr.exhibitionist&&(score+=4);tr.pragmatic&&(score+=4);
    score+=af.oral*2+af.vaginal*2+af.prostitution*4+af.taboo*2;lt.self_protective&&(score-=4);lt.cold_pragmatist&&(score+=6);lt.latent_exhibitionist&&(score+=5);lt.public_thrill_seeker&&(score+=5);lt.wants_to_be_corrupted&&(score+=5);
    if(customer.intent==='interested'||customer.intent==='predatory')score+=7;if(customer.tacticStyle==='transactional')score+=8;
    return wwClamp(score);
  }
  function wwWorkerSexAcceptance(worker,customer,state){
    const record=Brothel_손님관계기능.record(state,worker,customer.name),a=worker.attributes,t=worker.tendencies,tr=worker.traits,lt=worker.latentTraits,af=worker.affinities;
    let score=30+a.openness*.12+a.confidence*.08+t.intimacy*.16+t.libido*.12+t.daring*.08+(record?.sexual??0)*.04+af.vaginal*7+af.prostitution*4;
    tr.flirtatious&&(score+=5);tr.bold&&(score+=6);tr.cautious&&(score-=8);tr.pragmatic&&(score+=4);lt.true_prude&&(score-=32);lt.self_protective&&(score-=12);lt.cold_pragmatist&&(score+=7);lt.wants_to_be_corrupted&&(score+=5);lt.romance_starved&&(score+=3);
    if(customer.intent==='predatory')score-=12;if(customer.tacticStyle==='transactional')score+=4;
    return{accepted:score>=55,score:wwClamp(score)};
  }
  function wwWorkerServiceAcceptance(worker,customer,state,stage){
    if(stage==='sex_patron')return wwWorkerSexAcceptance(worker,customer,state);
    if(!WW_PAID_STAGES.has(stage))return{accepted:true,score:100};
    const record=Brothel_손님관계기능.record(state,worker,customer?.name??"당신"),a=worker.attributes,t=worker.tendencies,tr=worker.traits,lt=worker.latentTraits,af=worker.affinities;
    let score=38+a.openness*.12+a.confidence*.07+t.intimacy*.14+t.libido*.08+t.daring*.06+(record?.sexual??0)*.04+af.prostitution*4;
    if(stage==='groping')score+=af.romantic*4;
    else if(stage==='intimate')score+=af.romantic*3+af.submission+af.dominance;
    else if(stage==='handjob_patron')score+=af.oral*2+af.dominance;
    else if(stage==='blowjob_patron')score+=af.oral*7;
    else if(stage==='titfuck_patron')score+=af.breast*6+af.exhibition*2;
    tr.flirtatious&&(score+=5);tr.bold&&(score+=5);tr.cautious&&(score-=7);tr.pragmatic&&(score+=4);
    lt.true_prude&&(score-=26);lt.self_protective&&(score-=10);lt.cold_pragmatist&&(score+=6);lt.wants_to_be_corrupted&&(score+=4);
    const threshold=stage==='groping'?42:stage==='intimate'?46:50;
    return{accepted:score>=threshold,score:wwClamp(score)};
  }
  function wwSexRequestDecision(worker,customer,state,roll=Math.random()){
    const acceptance=wwWorkerSexAcceptance(worker,customer,state),tier=wwHireTier(worker),minimum=WBE.minimumPrice(wwEnsureConfig(state),'sex_patron',customer),wallet=Math.max(0,Number(customer?.walletGold)||0),runtime=wwGetRuntime(worker,state),room=wwCustomerRoom(state,customer);
    const energyNeeded=wwServiceEnergyCost(worker,'sex_patron')+10,roomAvailable=room!=='taproom'||wwEnsureConfig(state).allowTaproomSex||!!wwChoosePrivateRoom(state,customer.id);
    const eligible=acceptance.accepted&&wallet>=minimum&&runtime.stats.energy>=energyNeeded&&roomAvailable,requested=eligible&&roll<tier.sexRequestChance;
    return{requested,eligible,acceptanceScore:acceptance.score,accepted:acceptance.accepted,minimum,wallet,energyNeeded,roomAvailable,chance:tier.sexRequestChance,tier:tier.id};
  }
  function wwInteractionStages(worker,customer,state,roll){
    const af=worker.affinities,score=wwInteractionScore(worker,customer,state),stages=['flirting','light_touch','bold_touch','groping','intimate'];
    if(score>=70)stages.push(af.exhibition>=Math.max(af.oral,af.vaginal)?'titfuck_patron':af.oral>=af.vaginal?'blowjob_patron':'handjob_patron');
    if(wwSexRequestDecision(worker,customer,state,roll??Math.random()).requested)stages.push('sex_patron');
    return stages;
  }
  function wwStageText(worker,customer,stage){
    const w=worker.name,p=customer.name,text={chatting:`${w}이(가) 잠시 ${p}의 탁자에 머물러 이야기를 나눈다.`,flirting:`${w}이(가) 먼저 ${p}의 곁에 바짝 앉아 은밀한 농담을 건넨다.`,light_touch:`${w}이(가) 이야기하며 ${p}의 팔과 무릎을 자연스럽게 어루만진다.`,bold_touch:`${w}이(가) ${p}의 손을 잡아 자신의 허리로 이끌고 그의 반응을 살핀다.`,groping:`${w}이(가) ${p}의 손길을 더 깊은 곳으로 이끌며 적극적으로 유혹한다.`,intimate:`${w}이(가) ${p}에게 몸을 밀착하고 농밀한 서비스를 시작한다.`,handjob_patron:`${w}은(는) ${p}의 몸을 손으로 능숙하게 자극해 준다.`,blowjob_patron:`${w}은(는) 먼저 ${p} 앞에 몸을 낮추고 입으로 그를 자극한다.`,titfuck_patron:`${w}은(는) ${p}을(를) 가슴 사이에 끼우고 능숙하게 자극해 준다.`,sex_patron:`${w}이(가) ${p}을(를) 끌어안고 주도적으로 관계를 갖는다.`};return text[stage]??`${w}이(가) 먼저 ${p}에게 다가가 함께 시간을 보내고 있다.`
  }
  function wwStartInteraction(state,worker,runtime,customer){
    const stages=wwInteractionStages(worker,customer,state),sharedWithWife=B(state)?.customerId===customer.id;runtime.interaction={customerId:customer.id,customerName:customer.name,customerSnapshot:wwClone(customer),stages,index:0,stage:stages[0],comfort:wwInteractionScore(worker,customer,state),sharedWithWife,grossEarned:0,wagesEarned:0};runtime.task='interaction';runtime.taskTarget=customer.id;runtime.location=wwCustomerRoom(state,customer);runtime.busyUntil=state.slot+4;runtime.situation=`${customer.name}에게 먼저 다가가 ${WW_STAGE_LABEL[stages[0]]} 중입니다.`;runtime.pendingInteractId=null;wwSpend(worker,runtime,wwServiceEnergyCost(worker,stages[0]),1,2);
    const customers=state.customers.map(item=>item.id===customer.id?{...item,stayTimer:Math.max(item.stayTimer??0,18)}:item);return wwLog(Brothel_손님관계기능.recordStage({...state,customers},worker,customer,stages[0]),wwStageText(worker,customer,stages[0]),worker.id);
  }
  function wwServiceFee(stage,customer){
    const minimum=WBE.minimumPrice(wwConfig,stage,customer),premium=2*Math.floor(Math.max(0,Number(customer?.walletGold)||0)/40);
    return minimum+premium;
  }
  function wwApplyPaidService(state,worker,runtime,customer,stage){
    if(!WW_PAID_STAGES.has(stage))return state;
    const fee=Math.min(wwServiceFee(stage,customer),Math.max(0,Number(customer.walletGold)||0));
    WBE.recordExperience(worker,state,runtime,customer,stage,fee);if(!fee){wwPersistConfig();return state}
    const wage=Math.ceil(fee/2),house=fee-wage,privateRoom=WW_PRIVATE_ROOMS.has(runtime.location);
    const customers=state.customers.map(item=>item.id===customer.id?{...item,tab:(Number(item.tab)||0)+fee,walletGold:Math.max(0,(Number(item.walletGold)||0)-fee),stayTimer:Math.max(Number(item.stayTimer)||0,24)}:item);
    let next={...state,customers};
    if(typeof Mt==='function')next=Mt(next,'paid_offers',house);else next={...next,economy:{...next.economy,gold:(Number(next.economy?.gold)||0)+house}};
    runtime.wagesEarned=(runtime.wagesEarned??0)+wage;if(runtime.interaction){runtime.interaction.grossEarned=(runtime.interaction.grossEarned??0)+fee;runtime.interaction.wagesEarned=(runtime.interaction.wagesEarned??0)+wage}WBE.recordIncome(wwEnsureConfig(next),next,worker,customer,{kind:'service',stage,gross:fee,house,wage});wwRecordServiceWage(worker,next,wage);wwPersistConfig();
    if(WW_EXPOSED_STAGES.has(stage)){
      const rep=next.tavernReputation??{},delta=1,multiplier=wwEnsureConfig(next).serviceRenownGainMultiplier,scaled=delta*multiplier;
      next={...next,tavernReputation:{...rep,service:wwClamp(Math.round(((Number(rep.service)||0)+scaled)*10)/10),renown:wwClamp(Math.round(((Number(rep.renown)||0)+scaled)*10)/10),notoriety:wwClamp((Number(rep.notoriety)||0)+(privateRoom?0:delta))}};
    }
    return wwLog(next,`${customer.name}이(가) ${worker.name}의 서비스 이용료 ${fee}골드를 냅니다. ${wage}골드는 그녀의 급료, ${house}골드는 장소료와 보호료입니다.${privateRoom?' 은밀한 방에서 이루어진 일이라 악명은 오르지 않습니다.':''}`,worker.id);
  }
  function wwMaybeArrangeStay(state,worker,runtime,customer){
    if(runtime.interaction?.stage!=='sex_patron'||customer.isResident||Math.random()>=.45)return state;
    const tavern=state.tavern??{},rooms=WW_SERVICE_ROOMS.filter(room=>room.renterField).sort((a,b)=>Number(b.id===runtime.location)-Number(a.id===runtime.location)),field=rooms.find(room=>!tavern[room.renterField]&&wwRoomFree(state,room.id,customer.id))?.renterField;
    if(!field)return state;
    const rent=10+Math.floor(Math.random()*13),renter={name:customer.name,personaTag:customer.personaTags?.[0],rentPaid:rent,nightsRemaining:1,visitCount:1,customerId:customer.id,proposedTonight:true,upstairsEncounter:true,upstairsWasIntimate:true};
    if((Number(customer.walletGold)||0)<rent)return state;
    let next={...state,tavern:{...tavern,[field]:renter},customers:state.customers.map(item=>item.id===customer.id?{...item,isResident:true,status:'drinking',walletGold:Math.max(0,(Number(item.walletGold)||0)-rent),stayTimer:Math.max(Number(item.stayTimer)||0,60)}:item)};
    if(typeof Mt==='function')next=Mt(next,'room_rent',rent);else next={...next,economy:{...next.economy,gold:(Number(next.economy?.gold)||0)+rent}};WBE.recordIncome(wwEnsureConfig(next),next,worker,customer,{kind:'stay',gross:rent,house:rent,wage:0});wwPersistConfig();
    return wwLog(next,`${worker.name}의 권유로 ${customer.name}이(가) 위층 객실에서 묵기로 하고 숙박료 ${rent}골드를 선불로 냅니다.`,worker.id);
  }
  function wwAftercareLocation(state,room){
    if(wwRoomBuilt(state,'bathhouse'))return'bathhouse';
    if(wwRoomBuilt(state,'bathroom'))return'bathroom';
    if(room&&room!=='taproom')return room;
    if(state.tavern?.[WW_BREAK_ROOM.field])return WW_BREAK_ROOM.id;
    return state.locations?.kitchen?'kitchen':'taproom';
  }
  function wwBeginAftercare(state,worker,runtime,stage,options={}){
    const duration=WW_AFTERCARE_MINUTES[stage]??0;if(!duration||!worker||!runtime)return state;
    const location=options.location??wwAftercareLocation(state,runtime.location),washing=['bathhouse','bathroom'].includes(location);
    runtime.interaction=null;runtime.task='aftercare';runtime.taskTarget=null;runtime.location=location;runtime.busyUntil=state.slot+duration;runtime.aftercareStage=stage;
    runtime.situation=washing?`서비스를 마치고 ${WW_LOCATION_LABEL[location]??location}에서 몸을 씻고 정리하고 있습니다. ${duration}분 남음.`:`서비스를 마치고 ${WW_LOCATION_LABEL[location]??location}에서 옷매무새와 주변을 정리하고 있습니다. ${duration}분 남음.`;
    return options.silent?state:wwLog(state,`${worker.name}이(가) 서비스를 마치고 ${duration}분 동안 ${washing?'몸을 씻고':'옷매무새와 주변을'} 정리합니다.`,worker.id);
  }
  function wwAftercareRemaining(state,id){
    const worker=Brothel_직원읽기(state,id);if(!worker)return 0;const runtime=wwGetRuntime(worker,state);
    return runtime.task==='aftercare'?Math.max(0,Math.ceil(runtime.busyUntil-state.slot)):0;
  }
  function wwFinishInteraction(state,worker,runtime,reason,allowStay=true){
    const interaction=runtime.interaction,name=interaction?.customerName,customer=state.customers.find(item=>item.id===interaction?.customerId);let next=state;
    if(interaction)next=Brothel_손님관계기능.finishInteraction(next,worker,customer??interaction.customerSnapshot,{...interaction,pleasure:Math.min(60,(interaction.index??0)*8)});
    if(customer&&allowStay)next=wwMaybeArrangeStay(next,worker,runtime,customer);
    const room=runtime.location,sceneId=B(next)?.customerId;next=wwClearReservation(next,room,interaction?.customerId);
    if(customer&&WW_PRIVATE_ROOMS.has(room)&&wwCustomerRoom(next,customer)===room&&sceneId!==customer.id&&!api.brothel?.customerBusy?.(next,customer.id))next=wwMoveCustomer(next,customer.id,'taproom');
    const earned=Math.floor(Number(interaction?.grossEarned)||0),payout=name&&earned>0?`${name}에게서 받은 ${earned}G를 챙겼습니다.`:'';runtime.interaction=null;runtime.task='idle';runtime.taskTarget=null;runtime.location='taproom';runtime.busyUntil=state.slot+2;runtime.situation=reason?`${payout}${payout?' ':''}${reason}`:(name?`${name}에게서 받은 ${earned}G를 챙기고 다음 손님을 찾고 있습니다.`:'다음 손님을 찾고 있습니다.');runtime.stats.arousal=wwClamp(runtime.stats.arousal-5);worker.stats={...runtime.stats};wwPersistConfig();if(interaction&&name){const label=(WW_STAGE_LABEL[interaction.stage]??interaction.stage??'접객').replace(/ 중$/,'');next=wwLog(next,`${worker.name}이(가) ${name}과(와)의 ${label} 서비스를 마쳤습니다. ${runtime.situation}`,worker.id)}return interaction&&WW_PAID_STAGES.has(interaction.stage)?wwBeginAftercare(next,worker,runtime,interaction.stage,{location:wwAftercareLocation(next,room)}):next;
  }
  function wwAdvanceInteraction(state,worker,runtime){
    const interaction=runtime.interaction;if(!interaction)return state;
    const customer=state.customers.find(item=>item.id===interaction.customerId);
    if(!customer||['leaving','gone'].includes(customer.status))return wwFinishInteraction(state,worker,runtime,'손님이 떠난 뒤 옷매무새를 정돈하고 있습니다.');
    if(interaction.index>=interaction.stages.length-1){
      const completed=interaction.stage==='sex_patron'?globalThis.__waywardBrothelPregnancy?.recordService?.(state,worker,customer)??state:state;
      return wwFinishInteraction(completed,worker,runtime);
    }
    const nextStage=interaction.stages[interaction.index+1],minimum=WBE.minimumPrice(wwEnsureConfig(state),nextStage,customer),available=Math.max(0,Number(customer.walletGold)||0);if(WW_PAID_STAGES.has(nextStage)&&available<minimum){const label=(WW_STAGE_LABEL[nextStage]??nextStage).replace(/ 중$/,'');return wwFinishInteraction(wwLog(state,`${customer.name}이(가) ${label} 최소 요금 ${minimum}G를 낼 수 없어 서비스를 시작하지 않습니다.`,worker.id),worker,runtime,`${customer.name}의 소지금이 최소 요금보다 부족해 접객을 마쳤습니다.`,false)}interaction.index++;interaction.stage=nextStage;let next=state;
    if(interaction.stage==='groping'&&wwCustomerRoom(next,customer)==='taproom'){
      const room=wwChoosePrivateRoom(next,customer.id);if(room)next=wwMoveInteractionToRoom(next,worker,runtime,customer,room);
    }else runtime.location=wwCustomerRoom(next,customer);
    if(WW_EXPOSED_STAGES.has(interaction.stage)&&runtime.location==='taproom'&&!wwEnsureConfig(next).allowTaproomSex){
      const room=wwChoosePrivateRoom(next,customer.id);
      if(room)next=wwMoveInteractionToRoom(next,worker,runtime,customer,room);
      else{return wwFinishInteraction(wwLog(next,`${worker.name}이(가) ${customer.name}의 요구를 받았지만 사용할 수 있는 빈 방이 없어 홀에서의 성적 서비스를 중단합니다.`,worker.id),worker,runtime,'빈 방이 생기기를 기다리며 다음 손님을 찾고 있습니다.',false)}
    }
    runtime.busyUntil=state.slot+(interaction.index>=4?6:4);runtime.situation=`${WW_LOCATION_LABEL[runtime.location]??runtime.location}에서 ${customer.name}과(와) ${WW_STAGE_LABEL[interaction.stage]} 중입니다.`;wwSpend(worker,runtime,wwServiceEnergyCost(worker,interaction.stage),interaction.index>=2?1:0,interaction.index>=1?4:2);
    const customers=next.customers.map(item=>item.id===customer.id?{...item,stayTimer:Math.max(item.stayTimer??0,24)}:item);next=Brothel_손님관계기능.recordStage({...next,customers},worker,customer,interaction.stage);next=wwApplyPaidService(next,worker,runtime,next.customers.find(item=>item.id===customer.id),interaction.stage);next=wwLog(next,wwStageText(worker,customer,interaction.stage),worker.id);return runtime.stats.energy<10?wwFinishInteraction(next,worker,runtime,'서비스를 마친 뒤 기력이 떨어져 휴식이 필요합니다.'):next;
  }
  function wwMaybeInteraction(state,worker,runtime,claimed,preferredId){
    const wifeTarget=B(state)?.customerId;
    const available=state.customers.filter(customer=>!customer.isCollector&&!claimed.has(customer.id)&&!api.brothel?.customerBusy?.(state,customer.id)&&!['leaving','gone'].includes(customer.status)&&(
      customer.id===wifeTarget||(customer.status==='drinking'||customer.status==='wants_more')&&wwWorkCustomer(state,customer,claimed)
    ));
    if(available.length===0)return null;
    const preferred=available.find(customer=>customer.id===(wifeTarget??preferredId)),customer=preferred??available[Math.floor(Math.random()*available.length)];
    const chance=.20+worker.tendencies.sociability*.0015+worker.tendencies.flirtation*.0015;
    if(Math.random()>(preferred?Math.max(.55,chance):chance))return null;
    claimed.add(customer.id);return wwStartInteraction(state,worker,runtime,customer);
  }
  function wwRecoverWorker(worker,runtime,full=false){
    runtime.stats.energy=full?100:wwClamp(runtime.stats.energy+35);
    if(full){runtime.stats.mood=wwClamp(runtime.stats.mood+(65-runtime.stats.mood)*.5,30,90);runtime.stats.arousal=wwClamp(runtime.stats.arousal*.3)}
    worker.stats={...runtime.stats};wwPersistConfig();
  }
  function wwSendWorkersToNightRest(state,config){
    let next=state;
    const claimed=new Set();
    for(const worker of wwActiveWorkers(config)){
      const runtime=wwGetRuntime(worker,next);
      if(runtime.externalOwner||runtime.task==='night_rest')continue;
      if(runtime.task==='aftercare'&&next.slot<runtime.busyUntil)continue;
      if(runtime.interaction){
        if(!next.pendingEvent)next=wwRunWorker(next,worker,runtime,claimed);
        if(runtime.interaction)continue;
      }
      runtime.task='night_rest';runtime.taskTarget=null;runtime.busyUntil=Number.POSITIVE_INFINITY;
      runtime.location=next.tavern?.[WW_BREAK_ROOM.field]?WW_BREAK_ROOM.id:'bedroom';
      runtime.situation=`${WW_LOCATION_LABEL[runtime.location]}에서 밤새 쉬고 있습니다.`;
      next=wwLog(next,`${worker.name}이(가) 오늘 일을 마치고 ${WW_LOCATION_LABEL[runtime.location]}에서 쉬기 시작합니다.`,worker.id);
    }
    return next;
  }
  function wwWakeWorkersForDay(state,config){
    let changed=false;for(const worker of wwActiveWorkers(config)){if(worker.lastFullRestDay===state.day||wwOnBirthLeave(state,worker.id))continue;const runtime=wwGetRuntime(worker,state);if(runtime.externalOwner||runtime.interaction)continue;wwRecoverWorker(worker,runtime,true);worker.lastFullRestDay=state.day;runtime.wagesEarned=0;runtime.task='idle';runtime.taskTarget=null;runtime.busyUntil=state.slot;runtime.location='taproom';runtime.situation='밤새 충분히 쉬고 기력을 회복해 새로운 손님을 기다리고 있습니다.';changed=true}if(changed)wwPersistConfig();return state;
  }
  function wwRunWorker(state,worker,runtime,claimed){
    if(runtime.externalOwner)return state;
    if(runtime.interaction){
      const customer=state.customers.find(item=>item.id===runtime.interaction.customerId),room=customer?wwCustomerRoom(state,customer):null;
      if(!customer||api.brothel?.customerBusy?.(state,customer.id)||room!==runtime.location||room!=='taproom'&&!runtime.interaction.sharedWithWife&&!wwRoomFree(state,room,customer.id))return wwFinishInteraction(state,worker,runtime,'손님이나 방의 상황이 바뀌어 서비스를 마쳤습니다.',false);
      claimed.add(runtime.interaction.customerId);return state.slot>=runtime.busyUntil?wwAdvanceInteraction(state,worker,runtime):state;
    }
    if(wwOnBirthLeave(state,worker.id)){
      runtime.task='rest';runtime.taskTarget=null;
      runtime.location=state.tavern?.[WW_BREAK_ROOM.field]?WW_BREAK_ROOM.id:'bedroom';
      runtime.situation='출산 휴가 중 · 다음 날 아침 복귀';
      return state;
    }
    const unpaid=wwUnpaidWages(state,worker);
    if(unpaid>0){runtime.task='idle';runtime.taskTarget=null;runtime.location='taproom';runtime.situation=`미지급 급료 ${unpaid}골드를 기다리고 있습니다.`;return state;}
    if(runtime.task==='rest'){
      if(state.slot<runtime.busyUntil)return state;
      wwRecoverWorker(worker,runtime,false);runtime.task='idle';runtime.taskTarget=null;runtime.location='taproom';runtime.situation='휴식을 마치고 기력을 회복해 다시 손님을 찾고 있습니다.';return wwLog(state,`${worker.name}이(가) 30분 동안 쉬어 기력을 35 회복하고 홀로 돌아옵니다.`,worker.id);
    }
    if(runtime.task==='aftercare'){
      const remaining=Math.max(0,Math.ceil(runtime.busyUntil-state.slot));
      if(remaining>0){runtime.situation=`서비스를 마치고 ${WW_LOCATION_LABEL[runtime.location]??runtime.location}에서 정리하고 있습니다. ${remaining}분 남음.`;return state}
      runtime.aftercareStage=null;runtime.task='idle';runtime.taskTarget=null;runtime.location='taproom';runtime.busyUntil=state.slot;runtime.situation='정리를 마치고 홀로 돌아와 다음 손님을 찾고 있습니다.';
      return wwLog(state,`${worker.name}이(가) 서비스 뒤 정리를 마치고 홀로 돌아옵니다.`,worker.id);
    }
    if(state.slot<runtime.busyUntil)return state;
    runtime.task='idle';runtime.taskTarget=null;runtime.location='taproom';runtime.situation='홀을 돌며 함께 시간을 보낼 손님을 적극적으로 찾고 있습니다.';
    if(runtime.stats.energy<10){const hasBreakRoom=state.tavern?.[WW_BREAK_ROOM.field]===true;wwBegin(worker,runtime,state,'rest',WW_TASK_TIME.rest,null,hasBreakRoom?'휴게실에서 30분 동안 쉬며 기력을 회복하고 있습니다.':'부엌 옆 의자에서 30분 동안 쉬며 기력을 회복하고 있습니다.');runtime.location=hasBreakRoom?WW_BREAK_ROOM.id:(state.locations?.kitchen?'kitchen':'taproom');return wwLog(state,`${worker.name}이(가) 기력이 떨어져 ${hasBreakRoom?'휴게실로 가서':'부엌 옆에 앉아'} 쉬기 시작합니다.`,worker.id)}
    const social=wwMaybeInteraction(state,worker,runtime,claimed);if(social)return social;
    if(state.slot%10===0){runtime.stats.arousal=wwClamp(runtime.stats.arousal-1);worker.stats={...runtime.stats};wwPersistConfig()}
    return state;
  }
  function wwTick(state){
    if(!state||state.gameOver)return state;state=wwInitializeCampaign(state);state=wwNormalizeOrphanedCustomers(wwEnsureRooms(state));const config=wwEnsureConfig(state),dayChanged=wwLastDay!=null&&state.day!==wwLastDay;
    state=Brothel_손님관계기능.checkRequests(state);
    state=wwPayDailyWages(state,config);
    if(wwLastSlot!=null&&(state.slot<wwLastSlot||!dayChanged&&state.slot-wwLastSlot>60))wwResetRuntime(state);
    if(wwLastSlot===state.slot&&!dayChanged)return state;wwLastSlot=state.slot;wwLastDay=state.day;
    if(state.phase==='prep'&&(dayChanged||wwActiveWorkers(config).some(worker=>worker.lastFullRestDay!==state.day)))state=wwWakeWorkersForDay(state,config);
    if(state.phase==='prep'&&!state.pendingEvent){
      const claimed=new Set();
      for(const worker of wwActiveWorkers(config)){
        const runtime=wwGetRuntime(worker,state);
        if(runtime.interaction&&!runtime.externalOwner)state=wwRunWorker(state,worker,runtime,claimed);
      }
    }
    if(state.phase==='closed'||state.phase==='bedroom')return wwSendWorkersToNightRest(state,config);
    if(!config.enabled||state.pendingEvent||(state.phase!=='service'&&state.phase!=='last_call'))return state;
    let next=state;const claimed=new Set([...wwRuntime.values()].filter(runtime=>runtime.interaction).map(runtime=>runtime.interaction.customerId));
    for(const worker of wwActiveWorkers(config)){const runtime=wwGetRuntime(worker,next);next=wwRunWorker(next,worker,runtime,claimed)}
    return next;
  }
  function wwInstallEngine(){if(wwOriginalOl||typeof Ol!=='function')return;wwOriginalOl=Ol;Ol=function(state,context){return wwTick(wwOriginalOl(state,context))}}
  function wwInstallNewGameReset(){
    if(!api.brothel)return;
    const replacements={};
    for(const key of ['newGame','startGameWithWifeArchetype','startGameWithPicks']){
      const original=ue.getState()[key];if(typeof original!=='function')continue;
      replacements[key]=function(...args){wwEnsureConfig(ue.getState().state);wwResetRoster();wwLastSlot=null;wwLastDay=null;return original.apply(this,args)};
    }
    ue.setState(replacements);
  }

  function wwEl(tag,className,text){const node=document.createElement(tag);if(className)node.className=className;if(text!=null)node.textContent=text;return node}
  function Brothel_초상화목록그리기(select,worker){
    select.replaceChildren();select.dataset.brothelPortrait=worker.id;
    if(!WW_CANDIDATES.some(candidate=>candidate.id===worker.portrait)){
      const option=wwEl('option','',`미인식 캐릭터: ${worker.portrait} (선택 유지)`);option.value=worker.portrait;option.selected=true;select.append(option);
    }
    for(const candidate of WW_CANDIDATES){const option=wwEl('option','',candidate.name);option.value=candidate.id;option.selected=candidate.id===worker.portrait;select.append(option)}
  }
  function wwCheckRow(label,desc,checked,onChange){const row=wwEl('label','ww-check'),copy=wwEl('span','ww-check-copy'),title=wwEl('span','ww-label',label),small=wwEl('span','ww-help',desc),input=wwEl('input');input.type='checkbox';input.checked=checked;input.addEventListener('change',()=>onChange(input.checked));copy.append(title,small);row.append(copy,input);return row}
  function wwNumberRow(worker,group,key,label){
    const value=group==='stats'?(wwRuntime.get(worker.id)?.stats?.[key]??worker[group][key]):worker[group][key],row=wwEl('div','ww-number-row ww-readonly'),name=wwEl('span','',label),range=wwEl('input'),number=wwEl('output','',String(Math.round(value)));range.type='range';range.min='0';range.max='100';range.value=String(value);range.disabled=true;row.append(name,range,number,wwEl('span','ww-locked','조절 불가'));return row;
  }
  function wwDisplaySizeRow(config,key,label,min,max,suffix){
    const row=wwEl('label','ww-display-row'),name=wwEl('span','',label),range=wwEl('input'),number=wwEl('input'),unit=wwEl('span','ww-display-unit',suffix);range.type='range';range.min=number.min=String(min);range.max=number.max=String(max);range.step=number.step='1';range.value=number.value=String(config[key]);number.type='number';const set=value=>{const next=Math.round(wwClamp(value,min,max));config[key]=next;range.value=number.value=String(next);wwSave()};range.addEventListener('input',()=>set(range.value));number.addEventListener('change',()=>set(number.value));row.append(name,range,number,unit);return row;
  }
  function wwGainMultiplierRow(config){
    const row=wwEl('label','ww-display-row'),name=wwEl('span','', '상승 배율'),range=wwEl('input'),number=wwEl('input'),unit=wwEl('span','ww-display-unit','배');range.type='range';number.type='number';range.min=number.min='0';range.max=number.max='1';range.step=number.step='.1';range.value=number.value=Number(config.serviceRenownGainMultiplier).toFixed(1);const set=value=>{const next=Math.round(wwClamp(value,0,1)*10)/10;config.serviceRenownGainMultiplier=next;range.value=number.value=next.toFixed(1);wwSave()};range.addEventListener('input',()=>set(range.value));number.addEventListener('change',()=>set(number.value));row.append(name,range,number,unit);return row;
  }
  function wwAffinityRow(worker,key,label,desc){
    const row=wwEl('div','ww-affinity-row ww-readonly'),copy=wwEl('div','ww-affinity-copy'),title=wwEl('span','ww-affinity-title',label),help=wwEl('span','ww-help',desc),range=wwEl('input'),number=wwEl('output','',Number(worker.affinities[key]).toFixed(1));range.type='range';range.min='-2';range.max='2';range.step='.1';range.value=String(worker.affinities[key]);range.disabled=true;copy.append(title,help);row.append(copy,range,number,wwEl('span','ww-locked','조절 불가'));return row;
  }
  function wwDetailedTrait(worker,key,label,desc){
    const item=wwEl('div','ww-detail-trait ww-readonly'),check=wwEl('input'),copy=wwEl('span','ww-check-copy'),title=wwEl('span','ww-label',label),help=wwEl('span','ww-help',desc);check.type='checkbox';check.checked=!!worker.latentTraits[key];check.disabled=true;copy.append(title,help);item.append(check,copy,wwEl('span','ww-locked','조절 불가'));return item;
  }
  function wwResetHireTemplate(){wwHireDraft.template=null;wwHireDraft.templateKey='';wwHireDraft.attributes={};wwHireDraft.traits={};wwHireDraft.latentTraits={}}
  function wwEnsureHireTemplate(state){
    if(!WW_CANDIDATES.some(candidate=>candidate.id===wwHireDraft.candidateId))wwHireDraft.candidateId=WW_CANDIDATES[0]?.id??'elena';
    const key=`${wwHireDraft.candidateId}|${wwHireDraft.personality}`;if(wwHireDraft.template&&wwHireDraft.templateKey===key)return wwHireDraft.template;
    const template=wwHireTemplate(state,wwHireDraft);wwHireDraft.template=template;wwHireDraft.templateKey=key;wwHireDraft.attributes={...template.baseAttributes};wwHireDraft.traits={...template.baseTraits};wwHireDraft.latentTraits={...template.baseLatentTraits};return template;
  }
  function wwHireWorker(mode){
    const state=ue.getState()?.state;if(!state)return{error:'게임을 시작한 뒤 고용할 수 있습니다.'};
    const config=wwEnsureConfig(state),tier=WW_HIRE_TIERS.find(item=>item.id===wwHireDraft.tierId),index=config.workers.findIndex(worker=>!worker.enabled);
    if(!tier)return{error:'고용 등급을 확인해 주세요.'};
    if(index<0)return{error:'고용 정원 4명에 도달했습니다.'};
    if((state.economy?.gold??0)<tier.cost)return{error:'고용 비용이 부족합니다.'};
    let worker;try{worker=wwCreateHiredWorker(index,tier,state,{...wwHireDraft,mode,template:wwEnsureHireTemplate(state),attributes:{...wwHireDraft.attributes},traits:{...wwHireDraft.traits},latentTraits:{...wwHireDraft.latentTraits}})}catch(error){return{error:error?.message||'고용 설정을 확인해 주세요.'}}
    config.workers[index]=worker;wwRuntime.delete(worker.id);wwGetRuntime(worker,state);
    const data=Brothel_자료읽기(state);
    const payroll={...data.payroll,[worker.id]:{chargedDay:state.day,unpaid:0}};
    const birthLeave={...data.birthLeave};
    delete birthLeave[worker.id];
    const hired=Brothel_자료쓰기(state,{payroll,birthLeave});
    const next=wwLog({...hired,economy:{...hired.economy,gold:hired.economy.gold-tier.cost}},`${tier.label} ${worker.name}을(를) ${tier.cost}골드에 고용했습니다. 다음 날 아침부터 고정 일당 ${tier.minWage}골드를 지급합니다.`,worker.id);
    wwCommitState(next);wwSave();return{worker};
  }
  function wwDismissWorker(index){
    const config=wwConfig,worker=config?.workers?.[index],state=ue.getState()?.state;if(!worker?.enabled||!state)return;
    if(typeof confirm==='function'&&!confirm(`${worker.name}을(를) 해고하시겠습니까? 이 매춘부의 기존 기록은 사라집니다.`))return;
    if(Brothel_자료읽기(state).assignments?.[worker.id]){wwCommitState(wwLog(state,'대화·서비스·출장을 마친 뒤 해고할 수 있습니다.',worker.id));return}const runtime=wwRuntime.get(worker.id);let next=runtime?.interaction?wwFinishInteraction(state,worker,runtime,'해고되어 창관을 떠났습니다.',false):state;
    next=globalThis.__waywardBrothelPregnancy?.dismissWorker?.(next,worker.id)??next;
    next={...next,log:(next.log??[]).filter(entry=>entry?.wwWorkerId!==worker.id)};
    const candidate=WW_CANDIDATES[index%WW_CANDIDATES.length]??WW_CANDIDATES[0],empty=wwPreset(candidate.id,`매춘부 ${index+1}`,state);empty.id=worker.id;config.workers[index]=empty;wwRuntime.delete(worker.id);
    wwCommitState(next);wwSave();wwRenderSettings();
  }

  function wwOpenHire(){
    if(wwHireWindow){document.body.append(wwHireWindow.el);wwHireWindow.focus();return;}
    Brothel_캐릭터탐색하기();
    wwHireWindow=wmlApi.ui.window({id:'brothel-hire',title:'매춘부 고용',width:850,height:720,render:wwRenderHire,
      onClose(){wwHireWindow=null;wwHireView=null;}});
  }
  function wwRenderHire(body,handle){
    handle.el.id='ww-hire-window';handle.el.dataset.brothelWindow='hire';handle.el.style.setProperty('z-index','2147483647','important');
    const content=wwEl('div','ww-hire-content'),notice=wwEl('p','ww-note',WW_HIRE_NOTICE),choices=wwEl('div','ww-hire-choices');
    const field=(label,input)=>{const row=wwEl('label','ww-hire-field');row.append(wwEl('span','',label),input);choices.append(row);return input;};
    const select=(label,value,rows)=>{const node=wwEl('select');node.setAttribute('aria-label',label);for(const [id,title]of rows){const option=wwEl('option','',title);option.value=id;node.append(option);}node.value=value;return node;};
    const tier=field('고용 등급',select('창관 고용 등급',wwHireDraft.tierId,WW_HIRE_TIERS.map(t=>[t.id,t.label+' · '+t.cost+'g / 고정 일당 '+t.minWage+'g'])));
    const candidate=field('기반 외형',select('창관 기반 외형',wwHireDraft.candidateId,WW_CANDIDATES.map(c=>[c.id,c.name])));
    const personality=field('성격',select('창관 성격',wwHireDraft.personality,WW_PERSONALITIES));
    const name=wwEl('input');name.type='text';name.maxLength=24;name.value=wwHireDraft.name;name.placeholder='비우면 이름 무작위';name.setAttribute('aria-label','창관 직원 이름');field('이름',name);
    const modes=wwEl('div','ww-hire-actions'),random=wwEl('button','ww-hire-button','아무나 고용'),specified=wwEl('button','ww-hire-button','지정 고용');random.type=specified.type='button';random.dataset.brothelHireMode='random';specified.dataset.brothelHireMode='specified';modes.setAttribute('aria-label','고용 방식');modes.append(random,specified);
    const allocationHost=wwEl('div','ww-hire-allocation-host'),status=wwEl('p','ww-help'),cost=wwEl('p','ww-note'),footer=wwEl('div','ww-hire-footer'),message=wwEl('p','ww-hire-message'),actions=wwEl('div','ww-hire-actions'),hire=wwEl('button','ww-hire-button primary','고용'),cancel=wwEl('button','ww-hire-button','취소');
    hire.type=cancel.type='button';hire.dataset.brothelHireConfirm='';cancel.dataset.brothelHireCancel='';message.setAttribute('role','status');actions.append(hire,cancel);footer.append(message,actions);content.append(notice,choices,modes,status,cost,allocationHost,footer);body.append(content);
    let budgetNote=null,allocationStatus=null,busy=false;
    function metrics(){const state=ue.getState().state,config=wwEnsureConfig(state),template=wwEnsureHireTemplate(state),tier=WW_HIRE_TIERS.find(t=>t.id===wwHireDraft.tierId)||WW_HIRE_TIERS[0];
      const baseTotal=Math.round(Object.values(template.baseAttributes).reduce((sum,n)=>sum+n,0)),budget=Math.min(WW_NUMERIC.attributes.length*100,Math.round(baseTotal*tier.budgetMultiplier)),total=WW_NUMERIC.attributes.reduce((sum,[key])=>sum+Number(wwHireDraft.attributes[key]||0),0);
      const changes=WW_TRAITS.filter(([key])=>!!wwHireDraft.traits[key]!==!!template.baseTraits[key]).length+WW_LATENT_TRAITS.filter(([key])=>!!wwHireDraft.latentTraits[key]!==!!template.baseLatentTraits[key]).length;
      const invalid=WW_NUMERIC.attributes.some(([key])=>String(wwHireDraft.attributes[key]??'').trim()===''||!Number.isInteger(Number(wwHireDraft.attributes[key]))||Number(wwHireDraft.attributes[key])<0||Number(wwHireDraft.attributes[key])>100);
      return{state,config,template,tier,baseTotal,budget,total,changes,invalid};
    }
    function refresh(){const m=metrics(),excess=m.total>m.budget||m.changes>m.tier.traitEdits||m.invalid;
      status.textContent='고용 인원 '+wwActiveWorkers(m.config).length+'/4명';cost.textContent='고용 비용 '+m.tier.cost+'g · 고정 일당 '+m.tier.minWage+'g · 보유 '+Math.floor(m.state.economy.gold)+'g';
      if(budgetNote)budgetNote.textContent='개별 상한 100 · 기반 총점 '+m.baseTotal+' · 이 등급의 총 배분 예산 '+m.budget;
      if(allocationStatus){allocationStatus.textContent='현재 총점 '+m.total+' · 남은 배분 '+(m.budget-m.total)+' · 특성 변경 '+m.changes+'/'+m.tier.traitEdits+(m.invalid?' · 능력치는 0~100 정수로 입력하세요.':'');allocationStatus.style.color=excess?'#fca5a5':'';}
      hire.disabled=busy||(wwHireDraft.mode==='specified'&&excess);random.setAttribute('aria-pressed',String(wwHireDraft.mode==='random'));specified.setAttribute('aria-pressed',String(wwHireDraft.mode==='specified'));
    }
    function buildAllocation(){allocationHost.replaceChildren();budgetNote=null;allocationStatus=null;
      if(wwHireDraft.mode==='specified'){
        const allocation=wwEl('div','ww-hire-allocation');allocation.append(wwEl('h4','','지정 고용 능력치'));budgetNote=wwEl('p','ww-help');allocationStatus=wwEl('p','ww-help');allocationStatus.dataset.brothelAllocationStatus='';allocation.append(budgetNote);
        const grid=wwEl('div','ww-hire-stat-grid');for(const [key,label]of WW_NUMERIC.attributes){const row=wwEl('label','ww-hire-stat'),input=wwEl('input');input.type='number';input.min='0';input.max='100';input.step='1';input.value=wwHireDraft.attributes[key]??'';input.setAttribute('aria-label','창관 지정 능력치 '+label);input.oninput=()=>{wwHireDraft.attributes[key]=input.value;refresh();};row.append(wwEl('span','',label),input);grid.append(row);}allocation.append(grid,allocationStatus);
        for(const [group,title,defs,prefix]of [['traits','체크형 기본 성격 특성',WW_TRAITS,'창관 지정 특성 '],['latentTraits','체크형 숨은 특성',WW_LATENT_TRAITS,'창관 지정 숨은 특성 ']]){const traits=wwEl('div','ww-hire-traits');for(const [key,label,desc]of defs){const row=wwEl('label'),input=wwEl('input');input.type='checkbox';input.checked=!!wwHireDraft[group][key];input.setAttribute('aria-label',prefix+label);if(desc)input.title=desc;input.onchange=()=>{wwHireDraft[group][key]=input.checked;refresh();};row.append(input,document.createTextNode(' '+label));traits.append(row);}allocation.append(wwEl('h4','',title),traits);}allocationHost.append(allocation);
      }refresh();
    }
    function resetTemplate(){wwResetHireTemplate();wwEnsureHireTemplate(ue.getState().state);buildAllocation();message.textContent='외형·성격에 맞춰 기본 능력치와 특성을 갱신했습니다.';}
    function mode(value){wwHireDraft.mode=value;buildAllocation();message.textContent='';}
    tier.onchange=()=>{wwHireDraft.tierId=tier.value;refresh();};candidate.onchange=()=>{wwHireDraft.candidateId=candidate.value;resetTemplate();};personality.onchange=()=>{wwHireDraft.personality=personality.value;resetTemplate();};name.oninput=()=>{wwHireDraft.name=name.value;};random.onclick=()=>mode('random');specified.onclick=()=>mode('specified');cancel.onclick=()=>handle.close();
    hire.onclick=()=>{if(busy||wwHireWindow?.el!==handle.el)return;busy=true;refresh();let result;try{result=wwHireWorker(wwHireDraft.mode);}catch(error){result={error:error.message};}if(!result.worker){busy=false;refresh();message.textContent=result.error;return;}wwHireDraft=wwNewHireDraft();handle.close();wwRenderSettings();};
    buildAllocation();wwHireView={refresh};
  }
  function wwWorkerEditor(worker,index){
    const card=wwEl('details','ww-editor-card'),head=wwEl('summary','ww-editor-head'),title=wwEl('h3','',`매춘부 ${index+1} · ${worker.name} · 상세보기`),fold=wwEl('span','ww-fold-label','펼치기');head.append(title,fold);card.append(head);card.addEventListener('toggle',()=>{fold.textContent=card.open?'접기':'펼치기'});
    const content=wwEl('div','ww-editor-content'),employment=wwEl('div','ww-employment-row'),tier=WW_HIRE_TIERS.find(item=>item.id===worker.hireTier),ledger=wwWageLedger(worker,ue.getState().state),employmentText=wwEl('span','ww-help',`${tier?.label??'기존 고용인'} · 고정 일당 ${tier?.minWage??10}골드 · 오늘 서비스 급료 ${ledger.serviceWages}골드${ledger.unpaid?` · 미지급 ${ledger.unpaid}골드 / 근무 보류`:''}`),dismiss=wwEl('button','ww-dismiss','해고');dismiss.type='button';dismiss.addEventListener('click',()=>wwDismissWorker(index));employment.append(employmentText,dismiss);content.append(employment);const toggles=wwEl('div','ww-two');toggles.append(wwCheckRow('실시간 창에 표시','그리드의 빈 자리에 이 직원을 표시합니다.',worker.showPanel,value=>{worker.showPanel=value;wwSave()}));content.append(toggles);
    content.append(wwEl('p','ww-note',`당신과의 관계 · ${Brothel_대화기능.relationshipText(ue.getState().state,worker.id)}`));
    const patronData=Brothel_손님관계기능.employee(ue.getState().state,worker),patronPanel=wwEl('details','ww-patron-relationships');
    patronPanel.dataset.brothelPatronRelationships=worker.id;patronPanel.append(wwEl('summary','ww-section-title','이 직원과 손님의 관계'));
    patronPanel.append(wwEl('p','ww-help',"그녀와 다른 직원의 관계와 독립적으로 계산합니다. 우호도가 100을 넘으면 직원별로 처음 한 손님만 결혼 요청을 전합니다."));
    if(patronData.marriageRequest)patronPanel.append(wwEl('p','ww-note',`결혼 요청: ${patronData.marriageRequest.customerName}`));
    if(!patronData.records.length)patronPanel.append(wwEl('p','ww-help','아직 이 직원과 관계가 쌓인 손님이 없습니다.'));
    for(const record of patronData.records.slice().sort((a,b)=>(b.platonic??0)-(a.platonic??0))){
      patronPanel.append(wwEl('p','ww-help',`${record.name} · 우호 ${Number(record.platonic??0).toFixed(1)} · 연애 ${Number(record.romantic??0).toFixed(1)} · 성적 호감 ${Number(record.sexual??0).toFixed(1)} · 접객 ${record.visitCount??0}회`));
    }
    content.append(patronPanel);
    const identity=wwEl('div','ww-identity'),nameLabel=wwEl('label','', '이름'),nameInput=wwEl('input');nameInput.type='text';nameInput.maxLength=24;nameInput.value=worker.name;nameInput.addEventListener('input',()=>{worker.name=nameInput.value.trim().slice(0,24)||`매춘부 ${index+1}`;title.textContent=`매춘부 ${index+1} · ${worker.name} · 상세보기`;wwSave()});const portraitLabel=wwEl('label','', '초상화'),portrait=wwEl('select');Brothel_초상화목록그리기(portrait,worker);portrait.addEventListener('change',()=>{worker.portrait=portrait.value;wwInvalidateLook(worker);wwSave()});identity.append(nameLabel,nameInput,portraitLabel,portrait);content.append(identity);
    const outfitRow=wwEl('div','ww-outfit-row'),outfitLabel=wwEl('label','', '복장'),outfit=wwEl('select'),autoOption=wwEl('option','', '자신들이 선택해서 입기 (Default)');autoOption.value='auto';autoOption.selected=worker.outfitMode==='auto';outfit.append(autoOption);for(const[id,label]of WW_OUTFITS){const option=wwEl('option','',label);option.value=id;option.selected=worker.outfitMode===id;outfit.append(option)}outfit.addEventListener('change',()=>{worker.outfitMode=outfit.value;wwInvalidateLook(worker);wwSave()});outfitRow.append(outfitLabel,outfit,wwEl('span','ww-help','자동 선택은 능력치·Trait·Affinity와 현재 상태를 반영해 하루 단위로 결정됩니다.'));
    content.append(outfitRow,WBE.experiencePanel(worker,WW_STAGE_LABEL,WW_LOCATION_LABEL,wwStoryTime));
    for(const[group,defs]of Object.entries(WW_NUMERIC)){content.append(wwEl('h4','ww-section-title',group==='stats'?'현재 상태':group==='attributes'?'능력치':'행동 성향'));const grid=wwEl('div','ww-number-grid');for(const[key,label]of defs)grid.append(wwNumberRow(worker,group,key,label));content.append(grid)}
    content.append(wwEl('h4','ww-section-title','기본 성격 특성'));const traits=wwEl('div','ww-traits');for(const[key,label]of WW_TRAITS){const item=wwEl('div','ww-trait ww-readonly'),check=wwEl('input');check.type='checkbox';check.checked=!!worker.traits[key];check.disabled=true;item.append(check,wwEl('span','',label),wwEl('span','ww-locked','조절 불가'));traits.append(item)}content.append(traits);
    content.append(wwEl('h4','ww-section-title','세부 Trait'));const detailed=wwEl('div','ww-detail-traits');for(const[key,label,desc]of WW_LATENT_TRAITS)detailed.append(wwDetailedTrait(worker,key,label,desc));content.append(detailed);
    content.append(wwEl('h4','ww-section-title','행동 선호도 (Affinities · -2.0 ~ +2.0)'));const affinities=wwEl('div','ww-affinities');for(const[key,label,desc]of WW_AFFINITIES)affinities.append(wwAffinityRow(worker,key,label,desc));content.append(affinities);card.append(content);return card;
  }
  function wwRenderSettings(){
    if(!wwUi?.settings||wwUi.settings.hidden)return;const state=ue.getState().state,config=wwEnsureConfig(state),body=wwUi.settings.querySelector('.ww-settings-body');body.innerHTML='';
    const discovery=Brothel_캐릭터탐색하기();
    const notice=wwEl('details','ww-notice'),noticeSummary=wwEl('summary','', '안내문 · 펼치기'),noticeText=wwEl('p','',WW_NOTICE);notice.append(noticeSummary,noticeText);notice.addEventListener('toggle',()=>{noticeSummary.textContent=`안내문 · ${notice.open?'접기':'펼치기'}`});body.append(notice);
    const global=wwEl('section','ww-global'),heading=wwEl('h3','', '공통 설정');global.append(heading,wwCheckRow('창관 운영하기','고용한 매춘부들의 자동 행동을 사용합니다.',config.enabled,value=>{config.enabled=value;if(!value)for(const worker of wwActiveWorkers(config))wwStopWorker(worker,'오늘 창관 영업을 마치고 홀로 돌아왔습니다.');wwSave()}),wwCheckRow('홀에서 성적 서비스 허용','홀에서의 성적 서비스를 금지하여 악명이 오르는 것을 방지합니다. 체크하지 않으면 손님을 빈 방으로 안내하며, 빈 방이 없을 때는 행위를 중단합니다.',config.allowTaproomSex,value=>{config.allowTaproomSex=value;wwSave()}),wwCheckRow('실시간 인물 창',"그녀와 매춘부의 초상화·현재 상황을 표시합니다.",config.showLivePanel,value=>{config.showLivePanel=value;wwSave()}),wwCheckRow("그리드에 그녀 포함","실시간 인물 창의 첫 칸에 그녀를 표시합니다.",config.showWifePanel,value=>{config.showWifePanel=value;wwSave()}));
    const gains=wwEl('div','ww-display-settings'),gainHead=wwEl('div','ww-display-head'),gainTitle=wwEl('h4','', '창관 서비스·평판 상승 속도'),gainHelp=wwEl('p','ww-help','창관의 성적 서비스로 얻는 서비스와 명성 증가량에 적용됩니다. 0.0이면 오르지 않고, 1.0이면 기존 속도입니다. 악명·골드·급료에는 적용되지 않습니다.'),gainGrid=wwEl('div','ww-display-grid');gainHead.append(gainTitle);gainGrid.append(wwGainMultiplierRow(config));gains.append(gainHead,gainHelp,gainGrid);global.append(gains);
    const layoutRow=wwEl('div','ww-side-row'),layoutText=wwEl('span','', '실시간 창 그리드');layoutRow.style.flexWrap='wrap';layoutRow.append(layoutText);
    for(const [index,label]of ['가로 칸','세로 칸'].entries()){const field=wwEl('label'),input=wwEl('input');input.type='number';input.min='1';input.step='1';input.style.width='76px';input.setAttribute('aria-label',label);input.value=config.panelLayout.split('x')[index];input.addEventListener('change',()=>{const parts=config.panelLayout.split('x');parts[index]=input.value;const next=parts.join('x');if(!input.value.trim()||!wwPanelLayout(next)){input.value=config.panelLayout.split('x')[index];return;}config.panelLayout=next;wwSave()});field.append(label+' ',input);if(index)layoutRow.append(' × ');layoutRow.append(field);}
    const resetRow=wwEl('div','ww-side-row'),resetText=wwEl('span','', '창 위치·크기'),reset=wwEl('button','ww-random-all','초기화');reset.type='button';reset.addEventListener('click',()=>{config.panelRect=null;wwSave()});resetRow.append(resetText,reset);
    const display=wwEl('div','ww-display-settings'),displayHead=wwEl('div','ww-display-head'),displayTitle=wwEl('h4','', '실시간 창 표시 크기'),displayReset=wwEl('button','ww-random-all','표시 크기 초기화');displayReset.type='button';displayReset.addEventListener('click',()=>{config.liveImageHeight=145;config.liveStatusHeight=62;config.liveStoryHeight=135;wwSave();wwRenderSettings()});displayHead.append(displayTitle,displayReset);const displayGrid=wwEl('div','ww-display-grid');displayGrid.append(wwDisplaySizeRow(config,'liveImageHeight','이미지 높이',70,1080,'px'),wwDisplaySizeRow(config,'liveStatusHeight','상태 높이',40,220,'px'),wwDisplaySizeRow(config,'liveStoryHeight','이야기 높이',60,360,'px'));display.append(displayHead,displayGrid);
    global.append(layoutRow,display,resetRow,wwEl('p','ww-note','창 위쪽 제목 막대를 끌어 위치를 옮기고, 오른쪽 아래 모서리를 끌어 전체 크기를 조절할 수 있습니다. 기존 직원의 능력치·성향 치트 편집은 게임 에디터에서 합니다. 매력과 체크형 특성에는 별도의 강제 제한이 없습니다.'));global.append(WBE.pricingPanel(config,wwSave));body.append(global,WBE.incomePanel(config,state,WW_STAGE_LABEL,wwStoryTime));
    if(api.brothel)body.append(wwRoomSettings(state));
    const hireButton=wwEl('button','ww-random-all','매춘부 고용');hireButton.type='button';hireButton.dataset.brothelHireOpen='';hireButton.addEventListener('click',wwOpenHire);body.append(hireButton);
    const characterPanel=wwEl('section','ww-display-settings'),characterHead=wwEl('div','ww-display-head'),discover=wwEl('button','ww-random-all','새로운 캐릭터 찾기'),characterStatus=wwEl('p','ww-help',`인식된 캐릭터 ${discovery.characters.length}명`);
    discover.type='button';discover.dataset.brothelDiscoverCharacters='';characterStatus.setAttribute('role','status');
    discover.addEventListener('click',()=>{const result=Brothel_캐릭터탐색하기();for(const worker of config.workers){const select=body.querySelector(`[data-brothel-portrait="${worker.id}"]`);if(select)Brothel_초상화목록그리기(select,worker)}characterStatus.textContent=`새로 인식 ${result.added}명 · 전체 ${result.characters.length}명`;wwRenderLive()});
    characterHead.append(wwEl('h3','','캐릭터 · 초상화'),discover);characterPanel.append(characterHead,characterStatus,wwEl('p','ww-help','설치된 캐릭터 모드를 다시 확인해 초상화 선택 목록에 반영합니다. 이미지 생성이나 재고용은 하지 않으며 기존 직원의 설정·기록은 유지합니다. 이미지는 해당 캐릭터의 이미지팩이나 기존 이미지를 별도로 준비해야 합니다.'));body.append(characterPanel);
    const pregnancySection=globalThis.__waywardBrothelPregnancy?.renderSettings?.(state,config);if(pregnancySection)body.append(pregnancySection);
    config.workers.forEach((worker,index)=>{if(worker.enabled)body.append(wwWorkerEditor(worker,index))});
  }
  function wwOpenSettings(){
    let state=ue.getState().state;const initialized=wwInitializeCampaign(state);if(initialized!==state){state=initialized;wwCommitState(state)}wwEnsureConfig(state);wwUi.settings.hidden=false;wwRenderSettings();
  }
  function wwCloseSettings(){if(wwUi?.settings)wwUi.settings.hidden=true}
  function wwStopWorker(worker,message='고용이 끝나 홀로 돌아왔습니다.'){
    const runtime=wwRuntime.get(worker.id),state=ue.getState()?.state;if(!runtime||!state||Brothel_자료읽기(state).assignments?.[worker.id])return;
    const next=runtime.interaction?wwFinishInteraction(state,worker,runtime,message,false):state;runtime.interaction=null;runtime.task='idle';runtime.taskTarget=null;runtime.location='taproom';runtime.situation=message;if(next!==state)wwCommitState(next);
  }
  function wwTaskForImage(runtime){return({greet:'greeting',order:'taking_order',serve:'serving',cook:'cooking',clean:'cleaning',aftercare:['bathhouse','bathroom'].includes(runtime.location)?'bathing':'cleaning',rest:'sleeping',night_rest:'sleeping',idle:'idle',apologize:'taking_order'})[runtime.task]??'idle'}
  function wwImageRoom(room){
    if(room==='festival_brothel')return'taproom';
    if(room===WW_BREAK_ROOM.id||room==='elena_room'||room==='upstairs_hall'||room==='upstairs_room_2'||WW_CELLARS.some(cellar=>cellar.id===room))return'bedroom';
    if(room==='bathroom')return'bathhouse';
    return api.brothel?.imageRoom?api.brothel.imageRoom(room):room;
  }
  function wwTalentKey(worker,runtime,state){
    const candidate=wwCandidate(worker.portrait);if(!candidate)return null;
    const scene=runtime.interaction?WW_SCENE[runtime.interaction.stage]:undefined,pseudo={id:'wife',archetypeId:candidate.archetypeId,outfit:wwResolveOutfit(worker,runtime,state),currentTask:wwTaskForImage(runtime),sceneOverride:scene,sceneVariant:0,stats:{mood:runtime.stats.mood},exposure:scene&&runtime.interaction.index>=3?{bodiceUnlaced:true,skirtUp:runtime.interaction.index>=5}:undefined},imageRoom=wwImageRoom(runtime.location);
    try{return Cj(Nj(pseudo,imageRoom,runtime.stats.mood<42?'worried':undefined,undefined,runtime.interaction?{stage:runtime.interaction.stage,joinedPatronIds:[],joinedPatronSlots:{}}:undefined))}catch{return null}
  }
  async function wwLoadPortraitKey(key,img,placeholder){
    if(!key){img.hidden=true;placeholder.hidden=false;placeholder.textContent='초상화를 준비할 수 없습니다.';return}if(img.dataset.portraitKey===key&&img.dataset.loaded==='1')return;img.dataset.portraitKey=key;img.dataset.loaded='0';const token=key;placeholder.hidden=false;placeholder.textContent='초상화 불러오는 중…';
    try{let url=wwPortraitCache.get(key);if(!url){const entry=await pp(key);if(entry)url=R0(entry);if(url)wwPortraitCache.set(key,url)}if(img.dataset.portraitKey!==token)return;if(url){img.onload=()=>{if(img.dataset.portraitKey!==token)return;img.dataset.loaded='1';img.hidden=false;placeholder.hidden=true};img.onerror=()=>{img.hidden=true;placeholder.hidden=false;placeholder.textContent='설치된 초상화를 찾지 못했습니다.'};if(img.src!==url)img.src=url;else img.onload()}else{img.hidden=true;placeholder.hidden=false;placeholder.textContent='설치된 초상화를 찾지 못했습니다.'}}catch{img.hidden=true;placeholder.hidden=false;placeholder.textContent='초상화를 불러오지 못했습니다.'}
  }
  function wwWifeTalentKey(state,wife){try{const mood=wife.stats?.mood??50,imageRoom=wwImageRoom(Oe(state));return Cj(Nj(wife,imageRoom,mood<42?'worried':undefined,undefined,B(state)?.interaction))}catch{return null}}
  function wwStoryEntries(state,name,workerId,targetName){
    const logs=(state.log??[]).slice(-200),story=[];
    for(let index=logs.length-1;index>=0&&story.length<6;index--){const entry=logs[index],text=String(entry?.text??'').trim();if(!text)continue;const tagged=entry?.wwWorkerId;let belongs=false;if(workerId)belongs=tagged===workerId||(!tagged&&!!name&&text.includes(name));else belongs=!tagged&&((!!name&&text.includes(name))||(!!targetName&&text.includes(targetName)));if(!belongs)continue;if(story.at(-1)?.text===text)continue;story.push({slot:entry.slot,text,important:!!entry.important})}
    return story;
  }
  function wwStoryTime(slot){try{return Ji(slot)}catch{return''}}
  function wwWifeLiveState(state){
    const wife=g(state),scene=B(state),targetId=scene?.customerId??wife.taskTarget,target=state.customers.find(customer=>customer.id===targetId),stage=scene?.interaction?.stage??scene?.stage,taskMap={idle:'대기 중',greeting:'손님을 맞이하는 중',taking_order:'주문받는 중',serving:'서빙 중',cooking:'요리 중',cleaning:'청소 중',bathing:'목욕 중',sleeping:'수면 중',passed_out:'쓰러져 있음'},task=stage?WW_STAGE_LABEL[stage]??'손님과 함께 있음':taskMap[wife.currentTask]??wife.currentTask??'대기 중',location=Oe(state),situation=target?`${target.name}과(와) ${task}입니다.`:`${WW_LOCATION_LABEL[location]??location}에서 ${task}입니다.`;
    const name=wife.name??"그녀";return{name,task,location,situation,outfit:wwOutfitName(wife.outfit??'modest'),story:wwStoryEntries(state,name,null,target?.name),portraitKey:wwWifeTalentKey(state,wife)};
  }
  function wwSectionResizer(key,min,max,label){
    const handle=wwEl('div','ww-section-resizer');handle.dataset.sizeKey=key;handle.title=`드래그하여 모든 카드의 ${label}를 조절합니다.`;handle.setAttribute('role','separator');handle.setAttribute('aria-label',`${label} 조절`);handle.addEventListener('pointerdown',event=>{if(event.button!==0)return;event.preventDefault();event.stopPropagation();const config=wwEnsureConfig(ue.getState().state),startY=event.clientY,startValue=config[key],pointerId=event.pointerId;handle.classList.add('dragging');try{handle.setPointerCapture(pointerId)}catch{}document.body.style.userSelect='none';document.body.style.cursor='ns-resize';const move=next=>{config[key]=Math.round(wwClamp(startValue+next.clientY-startY,min,max));wwApplyPanelGeometry(config);handle.title=`${label}: ${config[key]}px`},finish=()=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',finish);window.removeEventListener('pointercancel',finish);try{handle.releasePointerCapture(pointerId)}catch{}handle.classList.remove('dragging');document.body.style.userSelect='';document.body.style.cursor='';wwSave()};window.addEventListener('pointermove',move);window.addEventListener('pointerup',finish);window.addEventListener('pointercancel',finish)});return handle;
  }
  function wwLiveCard(grid,id){
    let card=[...grid.children].find(node=>node.dataset.entityId===id);if(card)return card;card=wwEl('article','ww-live-card');card.dataset.entityId=id;const image=wwEl('div','ww-live-image'),img=wwEl('img'),placeholder=wwEl('div','ww-live-placeholder','초상화 준비 중…'),imageResize=wwSectionResizer('liveImageHeight',70,1080,'이미지 높이'),meta=wwEl('div','ww-live-meta'),status=wwEl('div','ww-live-status'),statusResize=wwSectionResizer('liveStatusHeight',40,220,'상태 높이'),line=wwEl('div','ww-live-meta-line'),name=wwEl('span','ww-live-name'),task=wwEl('span','ww-live-task'),outfit=wwEl('span','ww-live-outfit'),place=wwEl('span','ww-live-place'),situation=wwEl('div','ww-live-situation'),story=wwEl('div','ww-live-story'),storyResize=wwSectionResizer('liveStoryHeight',60,360,'이야기 높이');img.hidden=true;image.append(img,placeholder);line.append(name,task,outfit,place);status.append(line,situation);meta.append(status,statusResize,story,storyResize);card.append(image,imageResize,meta);return card;
  }
  function wwUpdateLiveCard(card,view,key,isWife=false){
    card.classList.toggle('ww-wife-card',isWife);card.querySelector('.ww-live-name').textContent=view.name;card.querySelector('.ww-live-task').textContent=view.task;card.querySelector('.ww-live-outfit').textContent=view.outfit??'';card.querySelector('.ww-live-outfit').title=`복장: ${view.outfit??''}`;card.querySelector('.ww-live-place').textContent=WW_LOCATION_LABEL[view.location]??view.location;card.querySelector('.ww-live-situation').textContent=view.situation;const story=card.querySelector('.ww-live-story');story.innerHTML='';story.append(wwEl('div','ww-live-story-title','이야기'));if(view.story?.length){for(const entry of view.story){const row=wwEl('div',`ww-live-story-row${entry.important?' important':''}`),time=wwEl('span','ww-live-story-time',wwStoryTime(entry.slot)),text=wwEl('span','ww-live-story-text',entry.text);row.append(time,text);story.append(row)}}else story.append(wwEl('div','ww-live-story-empty','아직 이 인물에 해당하는 이야기 기록이 없습니다.'));wwLoadPortraitKey(key,card.querySelector('img'),card.querySelector('.ww-live-placeholder'));
  }
  function wwApplyPanelGeometry(config){
    const live=wwUi?.live;if(!live||live.dataset.dragging==='1')return;live.style.setProperty('--ww-live-image-height',`${Math.round(wwClamp(config.liveImageHeight,70,1080))}px`);live.style.setProperty('--ww-live-status-height',`${Math.round(wwClamp(config.liveStatusHeight,40,220))}px`);live.style.setProperty('--ww-live-story-height',`${Math.round(wwClamp(config.liveStoryHeight,60,360))}px`);const layout=wwPanelLayout(config.panelLayout)??wwPanelLayout('3x2'),saved=config.panelRect;if(saved&&Number.isFinite(saved.x)){const width=wwClamp(saved.width,240,Math.max(240,window.innerWidth-16)),height=wwClamp(saved.height,240,Math.max(240,window.innerHeight-16)),x=wwClamp(saved.x,0,Math.max(0,window.innerWidth-width)),y=wwClamp(saved.y,0,Math.max(0,window.innerHeight-height));Object.assign(live.style,{left:`${x}px`,top:`${y}px`,right:'auto',bottom:'auto',width:`${width}px`,height:`${height}px`})}else{const width=Math.min(layout.width,Math.max(240,window.innerWidth-20)),height=Math.min(layout.height,Math.max(240,window.innerHeight-90));Object.assign(live.style,{left:'auto',right:'10px',top:'72px',bottom:'auto',width:`${width}px`,height:`${height}px`})}
  }
  function wwCapturePanelGeometry(){const live=wwUi?.live;if(!live||live.hidden||!wwConfig)return;const rect=live.getBoundingClientRect();wwConfig.panelRect={x:Math.round(rect.left),y:Math.round(rect.top),width:Math.round(rect.width),height:Math.round(rect.height)};try{localStorage.setItem(WW_KEY,JSON.stringify(wwConfig))}catch{}}
  function wwInstallPanelInteraction(live,head){
    head.addEventListener('pointerdown',event=>{if(event.button!==0||event.target.closest('button'))return;event.preventDefault();const rect=live.getBoundingClientRect(),dx=event.clientX-rect.left,dy=event.clientY-rect.top;live.dataset.dragging='1';document.body.style.userSelect='none';document.body.style.cursor='grabbing';const move=next=>{const x=wwClamp(next.clientX-dx,0,Math.max(0,window.innerWidth-rect.width)),y=wwClamp(next.clientY-dy,0,Math.max(0,window.innerHeight-rect.height));Object.assign(live.style,{left:`${x}px`,top:`${y}px`,right:'auto',bottom:'auto'})},up=()=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',up);delete live.dataset.dragging;document.body.style.userSelect='';document.body.style.cursor='';wwCapturePanelGeometry()};window.addEventListener('pointermove',move);window.addEventListener('pointerup',up,{once:true})});
    let resizeTimer=null;if(typeof ResizeObserver==='function')new ResizeObserver(()=>{if(live.hidden||live.dataset.dragging==='1')return;clearTimeout(resizeTimer);resizeTimer=setTimeout(wwCapturePanelGeometry,180)}).observe(live);window.addEventListener('resize',()=>{if(wwConfig){wwApplyPanelGeometry(wwConfig);wwCapturePanelGeometry()}});
  }
  function wwLiveActors(state){const config=wwEnsureConfig(state);return [{kind:'wife',id:'wife'},...wwActiveWorkers(config).map(worker=>({kind:'worker',id:worker.id,worker}))];}
  function wwPaintActor(card,actor,state){
    if(actor.kind==='wife'){const view=wwWifeLiveState(state);wwUpdateLiveCard(card,view,view.portraitKey,true);return;}
    const runtime=wwGetRuntime(actor.worker,state),outfit=wwResolveOutfit(actor.worker,runtime,state),view={name:actor.worker.name,task:runtime.interaction?WW_STAGE_LABEL[runtime.interaction.stage]:WW_TASK_LABEL[runtime.task]??runtime.task,location:runtime.location,situation:runtime.situation,outfit:wwOutfitName(outfit),story:wwStoryEntries(state,actor.worker.name,actor.worker.id,runtime.interaction?.customerName)};
    wwUpdateLiveCard(card,view,wwTalentKey(actor.worker,runtime,state));
  }
  function wwRenderLive(){
    if(!wwUi?.live)return;const root=ue.getState(),state=root.state,config=wwEnsureConfig(state),layout=wwPanelLayout(config.panelLayout)??wwPanelLayout('3x2');
    const actors=wwLiveActors(state).filter(actor=>actor.kind==='wife'?config.showWifePanel:actor.worker.showPanel),visible=actors.slice(0,layout.capacity);
    wwUi.live.hidden=!root.started||!config.showLivePanel||visible.length===0;wwUi.live.dataset.layout=config.panelLayout;wwApplyPanelGeometry(config);
    const grid=wwUi.live.querySelector('.ww-live-grid'),usedColumns=Math.min(layout.columns,Math.max(1,visible.length)),usedRows=Math.min(layout.rows,Math.max(1,Math.ceil(visible.length/layout.columns)));
    // Empty trailing tracks occupy space without creating thousands of DOM cards or CSS tracks.
    grid.style.gridTemplateColumns='repeat('+usedColumns+',minmax(145px,1fr))'+(layout.columns>usedColumns?' '+((layout.columns-usedColumns)*152-7)+'px':'');
    grid.style.gridTemplateRows='repeat('+usedRows+',minmax(240px,1fr))'+(layout.rows>usedRows?' '+((layout.rows-usedRows)*247-7)+'px':'');
    wwUi.live.querySelector('.ww-live-count').textContent=visible.length+'/'+actors.length;
    const keep=new Set(wwUi.live.hidden?[]:visible.map(actor=>actor.id));for(const old of [...grid.children])if(!keep.has(old.dataset.entityId))old.remove();
    if(!wwUi.live.hidden)for(const actor of visible){const card=wwLiveCard(grid,actor.id);grid.append(card);wwPaintActor(card,actor,state);}
    window.dispatchEvent(new Event('brothel-live-change'));
  }
  function wwCoreEnsureLayout(){
    if(wwCoreLayout)return wwCoreLayout;let raw=null;try{raw=JSON.parse(localStorage.getItem(WW_CORE_WINDOW_KEY)||'null')}catch{}wwCoreLayout={version:1,rects:raw?.rects&&typeof raw.rects==='object'?raw.rects:{},blocks:raw?.blocks&&typeof raw.blocks==='object'?raw.blocks:{}};return wwCoreLayout;
  }
  function wwCoreSaveLayout(){try{localStorage.setItem(WW_CORE_WINDOW_KEY,JSON.stringify(wwCoreEnsureLayout()))}catch{}}
  function wwNextWindowZ(){wwCoreZ+=4;return wwCoreZ}
  function wwRaiseStandaloneWindow(node){if(!node)return;node.style.setProperty('z-index',String(wwNextWindowZ()+1),'important')}
  function wwSetImportantStyle(node,property,value){if(node&&(node.style.getPropertyValue(property)!==String(value)||node.style.getPropertyPriority(property)!=='important'))node.style.setProperty(property,String(value),'important')}
  function wwCoreSyncStack(item){
    if(!item?.pane)return;const modalActive=!!item.pane.querySelector('.fixed.inset-0[data-ww-game-modal-front="1"]'),paneZ=modalActive?item.z+1:item.z,frameZ=modalActive?item.z:item.z+1;wwSetImportantStyle(item.pane,'z-index',paneZ);wwSetImportantStyle(item.frame,'z-index',frameZ);if(modalActive){item.pane.dataset.wwModalHost='1';wwSetImportantStyle(item.pane,'overflow','visible')}else if(item.pane.dataset.wwModalHost==='1'){delete item.pane.dataset.wwModalHost;item.pane.style.removeProperty('overflow')}
  }
  function wwCoreDefaultRects(){
    const width=Math.max(320,window.innerWidth),height=Math.max(420,window.innerHeight),top=62,gap=8,rects={};if(width>=1440){const usable=width-12-gap*3,ratios={story:.34,house:.23,focus:.26,actions:.17};let x=6,remaining=usable;WW_CORE_PANES.forEach((key,index)=>{const paneWidth=index===WW_CORE_PANES.length-1?remaining:Math.round(usable*ratios[key]);rects[key]={x,y:top,width:paneWidth,height:Math.max(260,height-top-10)};x+=paneWidth+gap;remaining-=paneWidth})}else{const cellWidth=Math.max(230,Math.floor((width-gap*3)/2)),cellHeight=Math.max(220,Math.floor((height-top-gap*3)/2));WW_CORE_PANES.forEach((key,index)=>{const column=index%2,row=Math.floor(index/2);rects[key]={x:gap+column*(cellWidth+gap),y:top+row*(cellHeight+gap),width:cellWidth,height:cellHeight}})}return rects;
  }
  function wwCoreSafeRect(rect){
    const maxWidth=Math.max(220,window.innerWidth-4),maxHeight=Math.max(180,window.innerHeight-4),width=Math.round(wwClamp(rect?.width??320,220,maxWidth)),height=Math.round(wwClamp(rect?.height??420,180,maxHeight)),x=Math.round(wwClamp(rect?.x??6,0,Math.max(0,window.innerWidth-80))),y=Math.round(wwClamp(rect?.y??62,0,Math.max(0,window.innerHeight-32)));return{x,y,width,height};
  }
  function wwCoreRaise(key){const item=wwCoreWindows.get(key);if(!item)return;item.z=wwNextWindowZ();wwCoreSyncStack(item)}
  function wwCoreCurrentRect(key){const layout=wwCoreEnsureLayout(),defaults=wwCoreDefaultRects();return wwCoreSafeRect(layout.rects[key]??defaults[key])}
  function wwCoreApplyWindow(key){
    const item=wwCoreWindows.get(key);if(!item?.pane)return;const rect=wwCoreCurrentRect(key),paneHeight=Math.max(140,rect.height-WW_CORE_HEADER);Object.assign(item.frame.style,{left:`${rect.x}px`,top:`${rect.y}px`,width:`${rect.width}px`,height:`${rect.height}px`});item.pane.style.setProperty('left',`${rect.x+1}px`,'important');item.pane.style.setProperty('top',`${rect.y+WW_CORE_HEADER}px`,'important');item.pane.style.setProperty('width',`${Math.max(218,rect.width-2)}px`,'important');item.pane.style.setProperty('height',`${paneHeight-1}px`,'important');wwCoreSyncStack(item);
  }
  function wwCorePointer(event,key,mode){
    if(event.button!==0)return;event.preventDefault();event.stopPropagation();wwCoreRaise(key);const layout=wwCoreEnsureLayout(),start=wwCoreCurrentRect(key),startX=event.clientX,startY=event.clientY;layout.rects[key]={...start};document.body.style.userSelect='none';document.body.style.cursor=mode==='move'?'grabbing':'nwse-resize';const move=next=>{const dx=next.clientX-startX,dy=next.clientY-startY;if(mode==='move')layout.rects[key]=wwCoreSafeRect({...start,x:start.x+dx,y:start.y+dy});else layout.rects[key]=wwCoreSafeRect({...start,width:start.width+dx,height:start.height+dy});wwCoreApplyWindow(key)},finish=()=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',finish);window.removeEventListener('pointercancel',finish);document.body.style.userSelect='';document.body.style.cursor='';wwCoreSaveLayout()};window.addEventListener('pointermove',move);window.addEventListener('pointerup',finish);window.addEventListener('pointercancel',finish);
  }
  function wwCoreReset(key){
    const layout=wwCoreEnsureLayout();delete layout.rects[key];for(const blockKey of Object.keys(layout.blocks))if(blockKey.startsWith(`${key}:`))delete layout.blocks[blockKey];const item=wwCoreWindows.get(key);for(const block of item?.pane?.querySelectorAll('.ww-core-resizable-block')??[]){block.style.removeProperty('width');block.style.removeProperty('height')}globalThis.__waywardEditor?.resetCorePaneSizes?.(key);wwCoreSaveLayout();wwCoreApplyWindow(key);
  }
  function wwCoreCreateWindow(key){
    let item=wwCoreWindows.get(key);if(item)return item;const frame=wwEl('aside','ww-core-window'),head=wwEl('div','ww-core-window-head'),title=wwEl('strong','',WW_CORE_LABELS[key]),hint=wwEl('span','ww-core-window-hint','제목: 이동 · 모서리: 크기'),reset=wwEl('button','ww-core-window-reset','↺'),grip=wwEl('div','ww-core-window-grip');frame.dataset.pane=key;reset.type='button';reset.title=`${WW_CORE_LABELS[key]} 창과 내부 블록 크기 초기화`;grip.title='드래그하여 창 크기 조절';head.append(title,hint,reset);frame.append(head,grip);document.body.append(frame);item={frame,head,grip,pane:null,z:wwNextWindowZ()};wwCoreWindows.set(key,item);head.addEventListener('pointerdown',event=>{if(!event.target.closest('button'))wwCorePointer(event,key,'move')});grip.addEventListener('pointerdown',event=>wwCorePointer(event,key,'resize'));reset.addEventListener('click',event=>{event.stopPropagation();wwCoreReset(key)});return item;
  }
  function wwCoreFindPaneRow(){
    for(const host of document.querySelectorAll('div.hidden')){if(!host.classList.contains('lg:flex'))continue;const row=host.firstElementChild;if(!row)continue;const separators=[...row.children].filter(child=>child.getAttribute?.('role')==='separator');if(separators.length>=3)return{host,row,mobile:host.nextElementSibling}}return null;
  }
  function wwCorePaneOrder(){try{const raw=vt.getState().paneOrder,valid=(Array.isArray(raw)?raw:[]).filter((key,index,array)=>WW_CORE_PANES.includes(key)&&array.indexOf(key)===index);return[...valid,...WW_CORE_PANES.filter(key=>!valid.includes(key))]}catch{return[...WW_CORE_PANES]}}
  function wwCoreBlockPath(node,root){const path=[];let current=node;while(current&&current!==root){const parent=current.parentElement;if(!parent)break;path.unshift([...parent.children].indexOf(current));current=parent}return path.join('.')}
  function wwDecorateCoreBlocks(pane,paneKey){
    if(globalThis.__WAYWARD_EDITOR_ADDON_LOADED__)return;
    const root=pane.firstElementChild;if(!root)return;const paneRect=pane.getBoundingClientRect(),all=[...root.querySelectorAll('div,section,article')],candidates=[];for(const node of all){if(node===root||node.classList.contains('ww-core-resizable-block')||node.closest('.ww-core-resizable-block')||node.closest('#ww-live-panel,#ww-settings'))continue;let depth=0,parent=node;while(parent&&parent!==root){depth++;parent=parent.parentElement}if(depth<1||depth>6||node.childElementCount===0)continue;const classes=typeof node.className==='string'?node.className:'';if(/fixed|absolute/.test(classes))continue;const rect=node.getBoundingClientRect();if(rect.width<150||rect.height<28)continue;const structural=node.parentElement===root||node.parentElement?.parentElement===root,visual=/rounded|border|bg-stone-8|shadow/.test(classes);if(!structural&&!visual||rect.height>paneRect.height*.86&&structural&&!visual)continue;if(candidates.some(outer=>outer.contains(node)))continue;candidates.push(node);if(candidates.length>=24)break}
    for(const node of candidates){const blockKey=`${paneKey}:${wwCoreBlockPath(node,root)}`,saved=wwCoreEnsureLayout().blocks[blockKey];node.classList.add('ww-core-resizable-block');node.dataset.wwCoreBlockKey=blockKey;if(saved){node.style.width=`${Math.min(saved.width,pane.clientWidth||saved.width)}px`;node.style.height=`${saved.height}px`}if(node.dataset.wwCoreBlockBound==='1')continue;node.dataset.wwCoreBlockBound='1';node.addEventListener('pointerdown',event=>{const rect=node.getBoundingClientRect();if(event.clientX<rect.right-24||event.clientY<rect.bottom-24)return;event.stopPropagation();const finish=()=>{window.removeEventListener('pointerup',finish);const current=node.getBoundingClientRect(),key=node.dataset.wwCoreBlockKey;if(key){wwCoreEnsureLayout().blocks[key]={width:Math.round(current.width),height:Math.round(current.height)};wwCoreSaveLayout()}};window.addEventListener('pointerup',finish,{once:true})},true)}
  }
  function wwHideCoreWindows(){for(const item of wwCoreWindows.values()){item.frame.hidden=true;if(item.pane){item.pane.classList.remove('ww-core-pane');delete item.pane.dataset.wwModalHost;for(const property of['left','top','width','height','z-index','overflow'])item.pane.style.removeProperty(property);item.pane=null}}}
  function wwDecorateCoreWindows(){
    let started=false;try{started=!!ue.getState().started}catch{}const found=wwCoreFindPaneRow();if(!started||!found){wwHideCoreWindows();return}found.host.classList.add('ww-core-source-host');found.row.classList.add('ww-core-source-row');found.mobile?.classList.add('ww-core-mobile-source');const panes=[...found.row.children].filter(child=>child.getAttribute?.('role')!=='separator'&&child.classList.contains('relative'));if(panes.length<4){wwHideCoreWindows();return}const order=wwCorePaneOrder();for(let index=0;index<4;index++){const key=order[index],pane=panes[index],item=wwCoreCreateWindow(key);item.frame.hidden=false;item.pane=pane;pane.dataset.wwCorePane=key;pane.classList.add('ww-core-pane');if(pane.dataset.wwCoreWindowBound!=='1'){pane.dataset.wwCoreWindowBound='1';pane.addEventListener('pointerdown',()=>wwCoreRaise(pane.dataset.wwCorePane))}wwCoreApplyWindow(key);wwDecorateCoreBlocks(pane,key)}
  }
  function wwScheduleDecorate(){if(wwDecorateQueued)return;wwDecorateQueued=true;requestAnimationFrame(()=>{wwDecorateQueued=false;wwDecorateGame()})}
  let wwModalStackQueued=false;
  function wwBringGameModalsToFront(){
    const modals=[...document.querySelectorAll('#root .fixed.inset-0')],pause=wwFindPauseModal();
    for(const modal of modals){
      modal.dataset.wwGameModalFront='1';
      const pane=modal.closest('.ww-core-pane'),key=pane?.dataset.wwCorePane;
      if(key&&wwCoreWindows.has(key)&&modal.dataset.wwCoreHostRaised!==key){
        modal.dataset.wwCoreHostRaised=key;wwCoreRaise(key);
      }
    }
    // 메인 패널과 WML 버튼줄은 메뉴 뒤에, 그 줄에서 연 설정창은 메뉴 앞에 둡니다.
    // 메뉴 안쪽의 기본 설정·저장창은 메뉴의 표시 계층 안에서 기존 순서를 유지합니다.
    const dock=document.querySelector('.wml-dock'),dockZ=dock?Number(getComputedStyle(dock).zIndex)||0:0;
    const pauseZ=Math.max(wwCoreZ,dockZ)+2;
    for(const modal of modals)wwSetImportantStyle(modal,'z-index',modal===pause?pauseZ:2147483646);
    for(const item of wwCoreWindows.values())wwCoreSyncStack(item);
    return modals;
  }
  function wwFindPauseModal(){
    const heading=[...document.querySelectorAll('h2')].find(node=>['일시 정지','Paused'].includes(node.textContent.trim()));return heading?.closest('div.fixed.inset-0')??heading?.closest('div.fixed')??null;
  }
  function wwBringPauseMenuToFront(){
    wwBringGameModalsToFront();const modal=wwFindPauseModal();if(!modal)return null;modal.dataset.wwPauseFront='1';return modal;
  }
  function wwScheduleModalStacking(){if(wwModalStackQueued)return;wwModalStackQueued=true;queueMicrotask(()=>{wwModalStackQueued=false;wwBringPauseMenuToFront()})}
  function wwDecorateShop(state){
    if(api.brothel){
      const first=document.querySelector('[data-wayward-room-section]'),list=first?.parentElement;if(!list)return;
      for(const worker of wwActiveWorkers()){
        const runtime=wwGetRuntime(worker,state);let section=[...list.children].find(node=>node.dataset.waywardRoomSection===runtime.location);
        if(!section){section=wwEl('div','mb-2 ww-shop-created');section.dataset.waywardRoomSection=runtime.location;section.append(wwEl('div','ww-shop-room-head',WW_LOCATION_LABEL[runtime.location]??runtime.location));list.append(section)}
        const row=wwEl('div','ww-shop-activity');row.append(wwEl('strong','ww-shop-worker',worker.name),wwEl('div','ww-shop-detail',runtime.situation));section.append(row);
      }
      return;
    }
    const shopTitle=[...document.querySelectorAll('span')].find(node=>node.textContent.trim()==='가게 안');if(!shopTitle)return;const scroll=shopTitle.parentElement?.nextElementSibling,list=scroll?.firstElementChild;if(!list)return;const active=wwActiveWorkers();
    for(const worker of active){const runtime=wwRuntime.get(worker.id);if(!runtime)continue;const roomLabel=WW_LOCATION_LABEL[runtime.location]??runtime.location;let section=[...list.children].find(node=>node.firstElementChild&&[...node.firstElementChild.querySelectorAll('span')].some(span=>span.textContent.trim()===roomLabel));if(!section){section=wwEl('div','mb-2 ww-shop-created');const heading=wwEl('div','ww-shop-room-head'),label=wwEl('span','',roomLabel),line=wwEl('span','ww-shop-line');heading.append(label,line);section.append(heading);list.append(section)}const customerName=runtime.interaction?.customerName??state.customers.find(customer=>customer.id===runtime.taskTarget)?.name,task=runtime.interaction?WW_STAGE_LABEL[runtime.interaction.stage]:WW_TASK_LABEL[runtime.task]??runtime.task,row=wwEl('div','ww-shop-activity'),top=wwEl('div','ww-shop-activity-top'),name=wwEl('span','ww-shop-worker',worker.name),action=wwEl('span','ww-shop-action',customerName?`${customerName} · ${task}`:task),detail=wwEl('div','ww-shop-detail',runtime.situation);top.append(name,action);row.append(top,detail);section.append(row)}
  }
  function wwExactText(root,text){return[...root.querySelectorAll('div,span,h1,h2,h3,button')].find(node=>node.textContent.trim()===text)}
  function wwCommitState(next){if(!next)return;try{ue.setState(root=>({...root,state:next}))}catch(error){console.error('[Brothel Addon] 상태 변경 실패',error)}}
  function wwCellarPrerequisite(state,room){
    if(room.id==='brothel_cellar_1')return state.tavern?.backRoomReady===true?null:'뒷방을 먼저 건설해야 합니다.';
    if(room.id==='brothel_cellar_2')return state.tavern?.hasBrothelCellar1===true?null:'지하방1을 먼저 건설해야 합니다.';
    return null;
  }
  function wwRoomSettings(state){
    const section=wwEl('section','ww-global');section.append(wwEl('h3','','방과 시설'));
    section.append(wwEl('p','ww-help','자동 배정: 지하방 → 객실 → 뒷방 → 욕실 → 목욕탕. 예약·점유된 방은 제외합니다. 침실·그녀의 방·부엌·외출 장소·휴게실에서는 영업하지 않습니다.'));
    for(const room of WW_SERVICE_ROOMS){const built=wwRoomBuilt(state,room.id),renter=state.tavern?.[room.renterField],status=!built?'미건설':renter?'숙박 예약 중':wwRoomFree(state,room.id)?'사용 가능':'사용 중';section.append(wwEl('p','ww-help',`${WW_LOCATION_LABEL[room.id]} · ${status}`))}
    for(const room of WW_CUSTOM_ROOMS){
      const built=wwRoomBuilt(state,room.id),cost=room===WW_BREAK_ROOM?WW_BREAK_ROOM_COST:WW_CELLAR_COST,prerequisite=wwCellarPrerequisite(state,room),button=wwEl('button','ww-random-all',built?`${room.label}로 이동`:`${room.label} 건설 · ${cost}골드 · 30분`);
      button.type='button';button.dataset.brothelFacility=room.id;button.disabled=built?state.phase==='bedroom'||!!state.errandSession:state.phase!=='prep'||!!prerequisite||(state.economy?.gold??0)<cost;button.title=prerequisite??(room===WW_BREAK_ROOM?WW_BREAK_ROOM_DESCRIPTION:`${WW_CELLAR_DESCRIPTION} 유지비 ${WW_CELLAR_MAINTENANCE}골드/주`);
      button.addEventListener('click',()=>{if(built)wwEnterCellar(room);else if(room===WW_BREAK_ROOM)wwPurchaseBreakRoom();else wwPurchaseCellar(room);wwRenderSettings()});section.append(button);
    }
    return section;
  }
  function wwPurchaseCellar(room){
    let state=wwEnsureRooms(ue.getState()?.state);if(!state)return;
    if(state.phase!=='prep'){wwCommitState(wwLog(state,'지하방 공사는 영업 준비 시간에만 할 수 있습니다.'));return}
    if(state.tavern?.[room.field])return;
    const prerequisite=wwCellarPrerequisite(state,room);if(prerequisite){wwCommitState(wwLog(state,prerequisite));return}
    if((state.economy?.gold??0)<WW_CELLAR_COST){wwCommitState(wwLog(state,`${room.label} 공사에는 ${WW_CELLAR_COST}골드가 필요합니다.`));return}
    state={...state,economy:{...state.economy,gold:state.economy.gold-WW_CELLAR_COST},tavern:{...(state.tavern??{}),[room.field]:true}};
    for(let minute=0;minute<30&&!state.gameOver;minute++)state=api.Ol(state,{playerPresent:true});
    wwCommitState(wwLog(state,`지하 창고를 정리하고 침구와 가림막을 들여 ${room.label}을 완성했습니다. ${WW_CELLAR_COST}골드와 30분이 들었습니다.`));
  }
  function wwPurchaseBreakRoom(){
    let state=wwEnsureRooms(ue.getState()?.state);if(!state)return;
    if(state.phase!=='prep'){wwCommitState(wwLog(state,'휴게실 공사는 영업 준비 시간에만 할 수 있습니다.'));return}
    if(state.tavern?.[WW_BREAK_ROOM.field])return;
    if((state.economy?.gold??0)<WW_BREAK_ROOM_COST){wwCommitState(wwLog(state,`휴게실 공사에는 ${WW_BREAK_ROOM_COST}골드가 필요합니다.`));return}
    state={...state,economy:{...state.economy,gold:state.economy.gold-WW_BREAK_ROOM_COST},tavern:{...(state.tavern??{}),[WW_BREAK_ROOM.field]:true}};
    for(let minute=0;minute<30&&!state.gameOver;minute++)state=api.Ol(state,{playerPresent:true});
    wwCommitState(wwLog(state,`지하실 한쪽을 정리해 종업원들이 쉴 수 있는 휴게실을 완성했습니다. ${WW_BREAK_ROOM_COST}골드와 30분이 들었습니다.`));
  }
  function wwEnterCellar(room){
    let state=wwEnsureRooms(ue.getState()?.state);if(!state?.tavern?.[room.field]||typeof Ot!=='function')return;
    if(state.phase==='bedroom'||state.errandSession)return;
    try{state=Ot(state,'player',room.id);wwCommitState(wwLog(state,`당신은 ${room.label}(으)로 들어갑니다.`))}catch{}
  }
  function wwDecorateUpgrades(state){
    const title=wwExactText(document,'시설 업그레이드');if(!title)return;let section=title;
    for(let index=0;index<6&&section;index++,section=section.parentElement)if(section.querySelector?.('button')&&section.textContent.includes('선술집 품질'))break;
    if(!section)return;const buttons=[...section.querySelectorAll('button')],content=[...section.querySelectorAll('div')].find(node=>node.classList.contains('px-3')&&node.classList.contains('pb-3'));
    let anchor=buttons.find(button=>button.textContent.includes('목욕탕 짓기'))??buttons.find(button=>button.textContent.includes('두 번째 객실'))??null;
    for(const room of WW_CELLARS){
      if(state.tavern?.[room.field]){section.querySelector(`[data-brothel-upgrade="${room.id}"]`)?.remove();continue}
      let button=section.querySelector(`[data-brothel-upgrade="${room.id}"]`),created=false;if(!button){button=wwEl('button','w-full text-left p-2 mb-2 bg-stone-700 hover:bg-stone-600 disabled:bg-stone-800 disabled:text-stone-500 disabled:cursor-not-allowed rounded transition-colors');button.type='button';button.dataset.brothelUpgrade=room.id;button.addEventListener('click',()=>wwPurchaseCellar(room));created=true}
      const prerequisite=wwCellarPrerequisite(state,room);button.disabled=!!prerequisite||(state.economy?.gold??0)<WW_CELLAR_COST;button.replaceChildren(wwEl('div','text-sm font-medium text-stone-100',room.label),wwEl('div','text-xs text-stone-400',`${WW_CELLAR_COST}골드 · 30분 · ${WW_CELLAR_DESCRIPTION}${prerequisite?` · ${prerequisite}`:''}`));
      if(created){if(anchor){anchor.insertAdjacentElement('afterend',button);anchor=button}else content?.append(button)}else anchor=button;
    }
    let breakButton=section.querySelector('[data-brothel-upgrade="brothel_break_room"]');if(state.tavern?.[WW_BREAK_ROOM.field])breakButton?.remove();else{const created=!breakButton;if(!breakButton){breakButton=wwEl('button','w-full text-left p-2 mb-2 bg-stone-700 hover:bg-stone-600 disabled:bg-stone-800 disabled:text-stone-500 disabled:cursor-not-allowed rounded transition-colors');breakButton.type='button';breakButton.dataset.brothelUpgrade=WW_BREAK_ROOM.id;breakButton.addEventListener('click',wwPurchaseBreakRoom)}breakButton.disabled=(state.economy?.gold??0)<WW_BREAK_ROOM_COST;breakButton.replaceChildren(wwEl('div','text-sm font-medium text-stone-100',WW_BREAK_ROOM.label),wwEl('div','text-xs text-stone-400',`${WW_BREAK_ROOM_COST}골드 · 30분 · ${WW_BREAK_ROOM_DESCRIPTION}`));if(created){if(anchor)anchor.insertAdjacentElement('afterend',breakButton);else content?.append(breakButton)}}
    const built=WW_CELLARS.filter(room=>state.tavern?.[room.field]).map(room=>room.label).join(', '),parts=[];if(built)parts.push(`${built} 운영 중 · 방마다 유지비 ${WW_CELLAR_MAINTENANCE}골드/주 · ${WW_CELLAR_DESCRIPTION}`);if(state.tavern?.[WW_BREAK_ROOM.field])parts.push(`휴게실 운영 중 · ${WW_BREAK_ROOM_DESCRIPTION}`);const builtText=parts.join(' / ');let note=section.querySelector('[data-brothel-built]');if(builtText){if(!note){note=wwEl('p','text-xs text-amber-300/80 mt-2');note.dataset.brothelBuilt='';(content??section).append(note)}note.textContent=builtText}else note?.remove();
  }
  function wwBelowFloorRow(middleRow){
    const host=middleRow?.parentElement;if(!host)return null;
    let floor=host.querySelector(':scope > [data-brothel-floor="below"]');
    if(!floor){
      floor=wwEl('section','mt-1.5 pt-1.5 border-t border-rose-950/70');floor.dataset.brothelFloor='below';
      floor.append(wwEl('div','mb-1 text-[0.65rem] uppercase tracking-wider text-rose-400','아래층'));
      const row=wwEl('div','flex flex-wrap gap-1.5');row.dataset.brothelFloorRow='below';floor.append(row);
    }
    if(floor.previousElementSibling!==middleRow)middleRow.insertAdjacentElement('afterend',floor);
    return floor.querySelector('[data-brothel-floor-row="below"]');
  }
  function wwDecorateCellarCards(state){
    let hall=document.querySelector('[data-wayward-room="taproom"]');
    if(!hall){
      const title=wwExactText(document,'모두의 현재 위치');if(!title)return;let panel=title.parentElement;
      for(let index=0;index<5&&panel;index++,panel=panel.parentElement)if(panel.querySelectorAll?.('div[class*="rounded"][class*="border"]').length>=2)break;
      const cards=panel?[...panel.querySelectorAll('div[class*="rounded"][class*="border"]')]:[];hall=cards.find(card=>card.firstElementChild?.textContent?.trim()==='홀');
    }
    const middleRow=hall?.parentElement?.parentElement,row=wwBelowFloorRow(middleRow);if(!row)return;
    for(const room of WW_CUSTOM_ROOMS){
      let slot=row.querySelector(`[data-brothel-room-slot="${room.id}"]`);
      if(!wwRoomBuilt(state,room.id)){slot?.remove();continue}
      if(!slot){slot=wwEl('div','flex-1 min-w-[5.5rem]');slot.dataset.brothelRoomSlot=room.id}
      let card=slot.querySelector(`[data-brothel-room="${room.id}"]`);
      if(!card){
        card=wwEl('div','p-1.5 rounded border text-xs leading-tight min-w-0 cursor-pointer hover:brightness-125 hover:ring-1 hover:ring-rose-700/70 transition border-rose-900/60 bg-stone-900/40');
        card.dataset.brothelRoom=room.id;card.tabIndex=0;card.setAttribute('role','button');card.title=`${room.label}(으)로 이동`;
        card.addEventListener('click',()=>wwEnterCellar(room));card.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();wwEnterCellar(room)}});slot.append(card);
      }
      row.append(slot);
      const occupants=state.locations?.[room.id]?.occupants??[],workers=wwActiveWorkers().filter(worker=>wwRuntime.get(worker.id)?.location===room.id);
      const head=wwEl('div','text-[0.65rem] uppercase tracking-wider text-rose-400 mb-0.5',room.label),body=wwEl('div','flex flex-wrap gap-1');
      if(occupants.length===0&&workers.length===0)body.append(wwEl('span','text-[0.7rem] text-stone-600 italic','비어 있음'));
      if(occupants.includes('player'))body.append(wwEl('span','px-1 py-0 rounded bg-blue-900/60 border border-blue-700 text-blue-200 text-[0.65rem]','당신'));
      if(occupants.includes('wife'))body.append(wwEl('span','px-1 py-0 rounded bg-purple-950/60 border border-purple-900/70 text-purple-200 text-[0.65rem]',g(state).name??"그녀"));
      for(const worker of workers)body.append(wwEl('span','px-1 py-0 rounded bg-rose-950/60 border border-rose-900/70 text-rose-200 text-[0.65rem]',worker.name));
      for(const id of occupants){const customer=state.customers.find(item=>item.id===id);if(customer)body.append(wwEl('span','px-1 py-0 rounded bg-amber-950/60 border border-amber-900/70 text-amber-200 text-[0.65rem]',customer.name))}
      card.classList.toggle('pointer-events-none',state.phase==='bedroom'||!!state.errandSession);card.setAttribute('aria-disabled',String(state.phase==='bedroom'||!!state.errandSession));card.replaceChildren(head,body);
    }
    if(!row.children.length)row.parentElement?.remove();
  }
  const WW_ITEM_ATTRIBUTES=[['strength','힘'],['deftness','손재주'],['vigor','활력'],['wit','재치'],['composure','침착성'],['charm','매력'],['openness','개방성'],['confidence','자신감'],['honesty','정직성']];
  const WW_ITEM_TRAITS=WW_LATENT_TRAITS.map(([id,label])=>[id,label]);
  const WW_ITEM_NAMES=Object.fromEntries([...WW_ITEM_ATTRIBUTES.flatMap(([id,label])=>[[`plus:${id}`,`${label}의 비약`],[`minus:${id}`,`${label}의 독약`]]),['energy','기력 음료'],['fatigue','피로 회복제'],...WW_ITEM_TRAITS.map(([id,label])=>[`trait:${id}`,`${label} 성격개변최면제`])]);
  function wwItemIdFromText(text){return Object.entries(WW_ITEM_NAMES).find(([,label])=>String(text).startsWith(`${label} `))?.[0]??null}
  function wwUseItemOnWorker(itemId,workerId){
    const root=ue.getState(),state=root.state,config=wwEnsureConfig(state),worker=config.workers.find(item=>item.id===workerId),stock=Number(root.modData?.inventory?.[itemId]??0);if(!worker||stock<=0)return{ok:false,message:'아이템이나 매춘부 정보를 확인할 수 없습니다.'};
    if(itemId==='energy'){const old=Number(worker.stats.energy)||0;if(old>=100)return{ok:false,message:'기력이 이미 최대입니다.'};worker.stats.energy=Math.min(100,old+10);const runtime=wwRuntime.get(worker.id);if(runtime)runtime.stats.energy=worker.stats.energy}
    else if(itemId.startsWith('trait:')){const trait=itemId.slice(6);worker.latentTraits[trait]=true}
    else if(itemId.startsWith('plus:')||itemId.startsWith('minus:')){const[sign,key]=itemId.split(':'),old=Number(worker.attributes[key]);if(!Number.isFinite(old))return{ok:false,message:'해당 능력치를 적용할 수 없습니다.'};const next=old+(sign==='plus'?1:-1);if(next<0||next>100)return{ok:false,message:'능력치가 이미 한계치입니다.'};worker.attributes[key]=next}
    else return{ok:false,message:'이 아이템은 매춘부에게 사용할 수 없습니다.'};
    const inventory={...(root.modData?.inventory??{})};inventory[itemId]=stock-1;if(inventory[itemId]<=0)delete inventory[itemId];wwInvalidateLook(worker);wwSave();
    const nextState=wwLog(state,`${worker.name}에게 ${WW_ITEM_NAMES[itemId]}을(를) 사용했습니다.`,worker.id);ue.setState(previous=>({...previous,state:nextState,modData:{...previous.modData,inventory}}));return{ok:true,message:`${worker.name}에게 아이템을 사용했습니다.`,remaining:stock-1};
  }
  function wwDecorateInventory(){
    const modal=document.getElementById('ko299-modal');if(!modal||!modal.querySelector('.title')?.textContent.includes('인벤토리'))return;
    const config=wwEnsureConfig(ue.getState().state);
    for(const row of modal.querySelectorAll('.row.field')){const strong=row.querySelector('strong'),select=row.querySelector('select'),button=row.querySelector('button');if(!strong||!select||!button)continue;const itemId=wwItemIdFromText(strong.textContent);if(!itemId)continue;
      const allowed=itemId!=='fatigue'&&(itemId==='energy'||itemId.startsWith('plus:')||itemId.startsWith('minus:')||itemId.startsWith('trait:'));
      if(allowed)for(const worker of wwActiveWorkers(config)){const index=config.workers.indexOf(worker);if(!select.querySelector(`option[value="brothel:${worker.id}"]`)){const option=wwEl('option','',`매춘부${index+1} · ${worker.name}`);option.value=`brothel:${worker.id}`;select.append(option)}}
      row.dataset.brothelItemId=itemId;if(button.dataset.brothelBound==='1')continue;button.dataset.brothelBound='1';button.addEventListener('click',event=>{if(!select.value.startsWith('brothel:'))return;event.preventDefault();event.stopImmediatePropagation();const result=wwUseItemOnWorker(row.dataset.brothelItemId,select.value.slice(8)),notice=modal.querySelector('.notice');if(notice){notice.textContent=result.message;notice.style.color=result.ok?'var(--wm-notice-ok, #86efac)':'var(--wm-notice-error, #fca5a5)'}if(result.ok){if(result.remaining<=0)row.remove();else strong.textContent=`${WW_ITEM_NAMES[row.dataset.brothelItemId]} ${result.remaining}`}},true)
    }
  }
  function wwInstallHeaderButton(){
    const modal=wwFindPauseModal();
    const settings=modal&&[...modal.querySelectorAll('button')].find(button=>['설정','Settings'].includes(button.textContent.trim()));
    if(settings&&!modal.querySelector('[data-wayward-native-settings="brothel"]')&&!modal.querySelector('[data-wml-pause-entry="brothel"]')){
      let button=modal.querySelector('.ww-brothel-menu-button');
      if(!button){button=wwEl('button','','창관 운영');button.type='button';button.addEventListener('click',wwOpenSettings)}
      button.className=`${settings.className} ww-brothel-menu-button`;
      if(button.previousElementSibling!==settings)settings.after(button);
    }
    for(const shop of [...document.querySelectorAll('button')].filter(button=>button.textContent.trim()==='상점')){const parent=shop.parentElement;if(!parent||parent.querySelector(':scope > .ww-brothel-header-button'))continue;const button=wwEl('button',`${shop.className} ww-brothel-header-button`,'창관');button.type='button';button.title='창관 운영 설정';button.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();wwOpenSettings()});shop.after(button)}
  }
  function wwDecorateGame(){
    if(!wwUi)return;
    if(!api.brothel)wwDecorateCoreWindows();
    wwBringPauseMenuToFront();wwInstallHeaderButton();wwDecorateInventory();
    document.querySelectorAll('.ww-location-row,.ww-shop-activity,.ww-shop-created').forEach(node=>node.remove());const root=ue.getState();if(!root.started)return;const state=root.state;wwEnsureConfig(state);const locationTitle=[...document.querySelectorAll('span')].find(node=>['모두의 현재 위치','Everyone’s whereabouts',"Everyone's whereabouts"].includes(node.textContent.trim()));
    if(locationTitle&&!api.brothel){let container=locationTitle.parentElement;for(let i=0;i<4&&container;i++,container=container.parentElement){if(container.querySelectorAll?.('div[class*="rounded"][class*="border"]').length>=2)break}if(container){const byRoom={};for(const worker of wwActiveWorkers()){const runtime=wwRuntime.get(worker.id);if(!runtime)continue;(byRoom[runtime.location]??=[]).push(worker)}for(const card of container.querySelectorAll('div[class*="rounded"][class*="border"]')){const first=card.firstElementChild?.textContent?.trim();const room=Object.keys(WW_LOCATION_LABEL).find(key=>WW_LOCATION_LABEL[key]===first);if(!room||!byRoom[room]?.length)continue;const row=wwEl('div','ww-location-row');for(const worker of byRoom[room])row.append(wwEl('span','ww-location-chip',worker.name));card.append(row)}}}
    wwDecorateShop(state);
    if(api.brothel)for(const card of document.querySelectorAll('[data-wayward-room]')){
      const workers=wwActiveWorkers().filter(worker=>wwRuntime.get(worker.id)?.location===card.dataset.waywardRoom);if(!workers.length)continue;
      const row=wwEl('div','ww-location-row');for(const worker of workers)row.append(wwEl('span','ww-location-chip',worker.name));card.append(row);
    }
    wwDecorateUpgrades(state);wwDecorateCellarCards(state);
  }
  function wwInstallUI(){
    const style=wwEl('style');style.textContent=`#ww-settings,#ww-live-panel{font-family:"Malgun Gothic","Apple SD Gothic Neo",sans-serif}#ww-settings[hidden],#ww-live-panel[hidden]{display:none!important}#ww-settings{position:fixed;inset:0;z-index:2147483647;background:#000c;display:flex;align-items:center;justify-content:center;padding:18px}#ww-settings .ww-dialog{width:min(960px,96vw);max-height:92vh;overflow:auto;background:#1c1917;border:1px solid #57534e;border-radius:12px;box-shadow:0 24px 70px #000;padding:18px;color:#e7e5e4}#ww-settings .ww-dialog-head{position:sticky;top:-18px;z-index:2;background:#1c1917;border-bottom:1px solid #44403c;margin:-18px -18px 14px;padding:16px 18px;display:flex;justify-content:space-between;align-items:center}#ww-settings h2{font-size:20px;color:#fcd34d;font-weight:700}#ww-settings h3{font-size:15px;color:#fbbf24;font-weight:700;margin:0}#ww-settings h4{font-size:11px;color:#a8a29e;text-transform:uppercase;letter-spacing:.12em;margin:12px 0 6px}#ww-settings button,#ww-settings input,#ww-settings select{font:inherit}#ww-settings button{cursor:pointer}#ww-settings .ww-close{border:0;background:transparent;color:#a8a29e;font-size:20px}#ww-settings .ww-global,#ww-settings .ww-editor-card,#ww-settings .ww-notice,:is(#ww-settings,#ww-hire-window) .ww-hire-shop{border:1px solid #44403c;background:#0c0a09aa;border-radius:9px;padding:13px;margin-bottom:12px}#ww-settings .ww-notice summary,#ww-settings .ww-editor-head{cursor:pointer;color:#fbbf24;font-weight:700}#ww-settings .ww-notice p{margin:10px 0 0;color:#d6d3d1;font-size:12px;line-height:1.65}#ww-settings .ww-editor-head{display:flex;align-items:center;justify-content:space-between;gap:8px;list-style:none}#ww-settings .ww-editor-head::-webkit-details-marker{display:none}#ww-settings .ww-editor-content{padding-top:10px}#ww-settings .ww-fold-label{font-size:11px;color:#a8a29e;font-weight:400}#ww-settings .ww-check{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:8px;border-bottom:1px solid #292524;cursor:pointer}#ww-settings .ww-check-copy{display:flex;flex-direction:column}.ww-label{font-size:13px;color:#e7e5e4}.ww-help{font-size:11px;color:#78716c;margin-top:2px}#ww-settings .ww-two{display:grid;grid-template-columns:1fr 1fr;gap:8px}#ww-settings .ww-identity{display:grid;grid-template-columns:auto 1fr auto 1fr;gap:7px;align-items:center;margin-top:10px}#ww-settings input[type=text],#ww-settings input[type=number],#ww-settings select{background:#0c0a09;border:1px solid #57534e;border-radius:5px;color:#e7e5e4;padding:6px}#ww-settings .ww-number-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px 12px}#ww-settings .ww-number-row{display:grid;grid-template-columns:86px 1fr 54px 58px;gap:6px;align-items:center;font-size:12px}#ww-settings input[type=range]{width:100%;accent-color:#f59e0b}#ww-settings .ww-random,#ww-settings .ww-random-all{border:1px solid #57534e;background:#292524;color:#d6d3d1;border-radius:5px;padding:5px;font-size:11px}#ww-settings .ww-traits{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}#ww-settings .ww-trait{display:grid;grid-template-columns:auto 1fr auto;gap:6px;align-items:center;border:1px solid #292524;border-radius:5px;padding:6px;font-size:12px}#ww-settings .ww-readonly input:disabled{opacity:.72;cursor:not-allowed}#ww-settings .ww-locked{color:#78716c;font-size:10px;text-align:right}#ww-settings .ww-side-row{display:flex;align-items:center;justify-content:space-between;padding:9px}.ww-note{font-size:11px;color:#a8a29e;background:#29252480;border-left:2px solid #d97706;padding:8px;margin-top:9px}:is(#ww-settings,#ww-hire-window) .ww-hire-content{padding-top:10px}:is(#ww-settings,#ww-hire-window) .ww-hire-offers{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px}:is(#ww-settings,#ww-hire-window) .ww-hire-offer{display:flex;align-items:center;justify-content:space-between;gap:10px;text-align:left;border:1px solid #57534e;border-radius:7px;background:#292524;color:#e7e5e4;padding:10px}:is(#ww-settings,#ww-hire-window) .ww-hire-offer:hover:not(:disabled){border-color:#d97706;background:#451a03}:is(#ww-settings,#ww-hire-window) .ww-hire-offer:disabled{opacity:.48;cursor:not-allowed}:is(#ww-settings,#ww-hire-window) .ww-hire-copy{display:flex;flex-direction:column}:is(#ww-settings,#ww-hire-window) .ww-hire-copy strong{color:#fbbf24;font-size:13px}:is(#ww-settings,#ww-hire-window) .ww-hire-action{flex:0 0 auto;color:#fcd34d;font-size:11px}#ww-settings .ww-employment-row{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px;padding-bottom:8px;border-bottom:1px solid #292524}#ww-settings .ww-dismiss{border:1px solid #7f1d1d;border-radius:5px;background:#450a0a;color:#fecaca;padding:5px 9px;font-size:11px}#ww-live-panel{position:fixed;z-index:35;top:72px;width:286px;max-height:calc(100vh - 90px);overflow:auto;background:#1c1917f2;border:1px solid #57534e;border-radius:10px;box-shadow:0 14px 40px #000a;color:#e7e5e4}#ww-live-panel[data-side=right]{right:10px}#ww-live-panel[data-side=left]{left:10px}#ww-live-panel .ww-live-head{display:flex;align-items:center;gap:8px;padding:8px 10px;border-bottom:1px solid #44403c}.ww-live-head strong{color:#fcd34d;font-size:0.8125rem}.ww-gear{margin-left:auto;border:0;background:transparent;color:#a8a29e;cursor:pointer}.ww-live-tabs{display:flex;border-bottom:1px solid #44403c}.ww-live-tabs button{flex:1;border:0;border-right:1px solid #292524;background:#0c0a09;color:#78716c;padding:7px 3px;font-size:0.6875rem;cursor:pointer}.ww-live-tabs button.active{background:#451a03;color:#fcd34d}.ww-live-image{height:260px;background:#0c0a09;display:flex;align-items:center;justify-content:center;overflow:hidden}.ww-live-image img{width:100%;height:100%;object-fit:cover}.ww-live-placeholder{color:#57534e;font-size:0.6875rem;padding:15px;text-align:center}.ww-live-meta{padding:9px 10px}.ww-live-meta-line{display:flex;align-items:center;gap:6px}.ww-live-name{font-weight:700;color:#f5f5f4}.ww-live-task{font-size:0.6875rem;color:#fbbf24}.ww-live-place{margin-left:auto;font-size:0.625rem;color:#a8a29e;border:1px solid #57534e;border-radius:999px;padding:2px 6px}.ww-live-situation{font-size:0.75rem;color:#d6d3d1;line-height:1.45;margin:7px 0}.ww-bar{margin-top:5px}.ww-bar-top{display:flex;justify-content:space-between;font-size:10px;color:#a8a29e}.ww-bar-track{height:5px;background:#292524;border-radius:99px;overflow:hidden}.ww-bar-fill{display:block;height:100%;border-radius:99px}.ww-location-row{display:flex;flex-wrap:wrap;gap:4px;margin-top:4px}.ww-location-chip{font-size:10px;color:#bbf7d0;background:#052e16;border:1px solid #15803d;border-radius:3px;padding:1px 4px}@media(max-width:900px){#ww-live-panel{top:auto;bottom:8px;width:230px;max-height:48vh}.ww-live-image{height:165px}#ww-settings .ww-number-grid,#ww-settings .ww-two,:is(#ww-settings,#ww-hire-window) .ww-hire-offers{grid-template-columns:1fr}#ww-settings .ww-traits{grid-template-columns:1fr 1fr}#ww-settings .ww-identity{grid-template-columns:auto 1fr}#ww-settings .ww-number-row{grid-template-columns:76px 1fr 48px 54px}}`;
    style.textContent+=`#ww-live-panel{min-width:240px;min-height:240px;max-width:calc(100vw - 8px);max-height:calc(100vh - 8px);overflow:hidden;resize:both;display:flex;flex-direction:column}#ww-live-panel .ww-live-head{flex:0 0 auto;cursor:move;user-select:none;background:#1c1917;touch-action:none}.ww-live-count{font-size:0.625rem;color:#78716c}.ww-live-grid{flex:1;min-height:0;display:grid;gap:7px;padding:7px;overflow:auto;background:#0c0a09}.ww-live-grid[data-layout="1x1"]{}#ww-live-panel[data-layout="1x1"] .ww-live-grid,#ww-live-panel[data-layout="1x2"] .ww-live-grid{grid-template-columns:minmax(0,1fr)}#ww-live-panel[data-layout="2x1"] .ww-live-grid,#ww-live-panel[data-layout="2x2"] .ww-live-grid{grid-template-columns:repeat(2,minmax(0,1fr))}#ww-live-panel[data-layout="1x1"] .ww-live-grid,#ww-live-panel[data-layout="2x1"] .ww-live-grid{grid-template-rows:minmax(0,1fr)}#ww-live-panel[data-layout="1x2"] .ww-live-grid,#ww-live-panel[data-layout="2x2"] .ww-live-grid{grid-template-rows:repeat(2,minmax(0,1fr))}.ww-live-card{min-width:0;min-height:0;overflow:auto;display:flex;flex-direction:column;border:1px solid #44403c;border-radius:7px;background:#1c1917}.ww-live-card.ww-wife-card{border-color:#a16207}.ww-live-card .ww-live-image{height:auto;min-height:105px;flex:1}.ww-live-card .ww-live-meta{flex:0 0 auto;padding:7px}.ww-live-card .ww-live-name{font-size:0.75rem}.ww-live-card .ww-live-task{font-size:0.625rem}.ww-live-card .ww-live-place{color:#f9a8d4;border-color:#9d174d;background:#500724}.ww-live-card .ww-live-situation{font-size:0.6875rem;margin:5px 0}.ww-live-card .ww-bar{margin-top:3px}.ww-location-chip{color:#fbcfe8!important;background:#500724!important;border-color:#be185d!important}.ww-shop-activity{margin:3px 2px;padding:5px 7px;border:1px solid #831843;border-left:3px solid #ec4899;border-radius:4px;background:#50072433}.ww-shop-activity-top{display:flex;gap:6px;align-items:center;font-size:11px}.ww-shop-worker{font-weight:700;color:#f9a8d4}.ww-shop-action{margin-left:auto;color:#fbcfe8;font-size:10px}.ww-shop-detail{margin-top:2px;color:#a8a29e;font-size:10px;line-height:1.35}.ww-shop-room-head{display:flex;align-items:center;gap:8px;margin:0 0 2px;color:#78716c;font-size:10px;text-transform:uppercase;letter-spacing:.08em}.ww-shop-line{height:1px;flex:1;background:#292524}@media(max-width:900px){#ww-live-panel{max-height:calc(100vh - 8px)}.ww-live-card .ww-live-image{min-height:90px}}`;
    style.textContent+=`#ww-live-panel[data-layout="3x1"] .ww-live-grid,#ww-live-panel[data-layout="3x2"] .ww-live-grid{grid-template-columns:repeat(3,minmax(0,1fr))}#ww-live-panel[data-layout="3x1"] .ww-live-grid{grid-template-rows:minmax(0,1fr)}#ww-live-panel[data-layout="3x2"] .ww-live-grid{grid-template-rows:repeat(2,minmax(0,1fr))}.ww-live-story{margin-top:6px;padding-top:5px;border-top:1px solid #292524;max-height:170px;overflow:auto}.ww-live-story-title{position:sticky;top:0;z-index:1;padding:2px 0 5px;background:#1c1917;color:#a8a29e;font-size:0.5625rem;font-weight:700;letter-spacing:.12em}.ww-live-story-row{display:grid;grid-template-columns:46px minmax(0,1fr);gap:5px;padding:5px 0;border-bottom:1px solid #29252480}.ww-live-story-row.important{border-left:2px solid #f59e0b;padding-left:5px;background:#451a032b}.ww-live-story-time{color:#78716c;font-size:0.5625rem;white-space:nowrap}.ww-live-story-text{color:#d6d3d1;font-size:0.625rem;line-height:1.4;overflow-wrap:anywhere}.ww-live-story-empty{padding:5px 0;color:#78716c;font-size:0.625rem;font-style:italic;line-height:1.4}@media(max-width:900px){#ww-live-panel[data-layout="3x1"],#ww-live-panel[data-layout="3x2"]{min-width:700px}.ww-live-story{max-height:135px}}`;
    style.textContent+=`#ww-live-panel{font-size:1rem}.ww-live-head strong{font-size:.8125rem!important}.ww-live-head .ww-live-count{font-size:.625rem!important}#ww-live-panel .ww-gear{font-size:.875rem}.ww-live-card .ww-live-image{flex:0 0 var(--ww-live-image-height,145px)!important;height:var(--ww-live-image-height,145px)!important;min-height:0!important}.ww-live-card .ww-live-meta{flex:0 0 auto;min-height:0}.ww-live-status{box-sizing:border-box;flex:0 0 var(--ww-live-status-height,62px);height:var(--ww-live-status-height,62px);min-height:0;overflow:auto}.ww-live-story{box-sizing:border-box;flex:0 0 var(--ww-live-story-height,135px);height:var(--ww-live-story-height,135px);max-height:none!important}.ww-live-card .ww-live-name{font-size:.75rem!important}.ww-live-card .ww-live-task{font-size:.625rem!important}.ww-live-card .ww-live-outfit{font-size:.5625rem!important}.ww-live-card .ww-live-place{font-size:.625rem!important}.ww-live-card .ww-live-situation{font-size:.6875rem!important}.ww-live-placeholder{font-size:.6875rem!important}.ww-live-story-title,.ww-live-story-time{font-size:.5625rem!important}.ww-live-story-text,.ww-live-story-empty{font-size:.625rem!important}#ww-settings .ww-display-settings{margin:8px 0;border:1px solid #44403c;border-radius:7px;padding:9px;background:#1c191755}#ww-settings .ww-display-head{display:flex;align-items:center;justify-content:space-between;gap:8px}#ww-settings .ww-display-head h4{margin:0}#ww-settings .ww-display-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px 14px;margin-top:8px}#ww-settings .ww-display-row{display:grid;grid-template-columns:82px minmax(80px,1fr) 58px 24px;gap:6px;align-items:center;color:#d6d3d1;font-size:12px}#ww-settings .ww-display-row input[type=number]{width:100%;box-sizing:border-box}#ww-settings .ww-display-unit{color:#78716c;font-size:10px}@media(max-width:900px){#ww-settings .ww-display-grid{grid-template-columns:1fr}#ww-live-panel[data-layout="3x1"]{min-width:240px}#ww-live-panel[data-layout="3x1"] .ww-live-grid{grid-template-columns:repeat(3,minmax(210px,1fr))}}`;
    style.textContent+=`#ww-live-panel .ww-font-step{flex:0 0 auto;border:1px solid #57534e;border-radius:4px;background:#292524;color:#d6d3d1;padding:2px 5px;font-size:.625rem;line-height:1.25;cursor:pointer}#ww-live-panel .ww-font-step:hover{border-color:#d97706;color:#fcd34d}#ww-live-panel .ww-font-down{margin-left:auto}#ww-live-panel .ww-gear{margin-left:0!important}.ww-section-resizer{position:relative;box-sizing:border-box;flex:0 0 8px;height:8px;min-height:8px;cursor:ns-resize;touch-action:none;background:#0c0a09}.ww-live-meta>.ww-section-resizer{margin-left:-7px;margin-right:-7px}.ww-section-resizer::before{content:"";position:absolute;left:18%;right:18%;top:3px;height:2px;border-radius:99px;background:#57534e}.ww-section-resizer:hover::before,.ww-section-resizer.dragging::before{background:#ec4899;box-shadow:0 0 5px #ec489988}.ww-section-resizer.dragging{background:#50072455}`;
    style.textContent+=`.ww-section-resizer{flex:0 0 1px;height:1px;min-height:1px;background:#44403c}.ww-section-resizer::before{left:0;right:0;top:-4px;height:9px;border-radius:0;background:transparent}.ww-section-resizer:hover::before,.ww-section-resizer.dragging::before{background:#78716c44;box-shadow:none}`;
    style.textContent+=`:is(#ww-settings,#ww-hire-window) .ww-hire-choices{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin:10px 0}:is(#ww-settings,#ww-hire-window) .ww-hire-field{display:flex;flex-direction:column;gap:4px;color:#d6d3d1;font-size:12px}:is(#ww-settings,#ww-hire-window) .ww-hire-allocation{border:1px solid #44403c;border-radius:7px;padding:10px;background:#1c191755}:is(#ww-settings,#ww-hire-window) .ww-hire-allocation-head{display:flex;align-items:center;justify-content:space-between;gap:8px}:is(#ww-settings,#ww-hire-window) .ww-hire-stat-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px}:is(#ww-settings,#ww-hire-window) .ww-hire-stat{display:grid;grid-template-columns:minmax(0,1fr) 64px;gap:6px;align-items:center;font-size:12px}:is(#ww-settings,#ww-hire-window) .ww-hire-stat input{width:100%;box-sizing:border-box}:is(#ww-settings,#ww-hire-window) .ww-hire-traits{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;font-size:11px}:is(#ww-settings,#ww-hire-window) .ww-hire-traits label{border:1px solid #292524;border-radius:5px;padding:6px}:is(#ww-settings,#ww-hire-window) .ww-hire-actions{display:flex;gap:8px;margin-top:10px}:is(#ww-settings,#ww-hire-window) .ww-hire-button{flex:1;border:1px solid #57534e;border-radius:7px;background:#292524;color:#e7e5e4;padding:9px}:is(#ww-settings,#ww-hire-window) .ww-hire-button.primary{border-color:#d97706;background:#78350f;color:#fef3c7}:is(#ww-settings,#ww-hire-window) .ww-hire-button:disabled{opacity:.45;cursor:not-allowed}@media(max-width:700px){:is(#ww-settings,#ww-hire-window) .ww-hire-choices,:is(#ww-settings,#ww-hire-window) .ww-hire-stat-grid,:is(#ww-settings,#ww-hire-window) .ww-hire-traits{grid-template-columns:1fr}}`;
    style.textContent+=`.ww-core-source-host{display:flex!important}.ww-core-mobile-source{display:none!important}.ww-core-source-row>[role="separator"]{display:none!important}.ww-core-pane{position:fixed!important;min-width:0!important;max-width:none!important;box-sizing:border-box!important;overflow:hidden!important;background:#1c1917!important;border:1px solid #57534e!important;border-top:0!important;border-radius:0 0 8px 8px!important;box-shadow:0 14px 38px #000a!important;pointer-events:auto}.ww-core-window[hidden]{display:none!important}.ww-core-window{position:fixed;box-sizing:border-box;border:1px solid #57534e;border-radius:8px;background:transparent;box-shadow:0 14px 38px #000a;pointer-events:none}.ww-core-window-head{height:${WW_CORE_HEADER}px;box-sizing:border-box;display:flex;align-items:center;gap:7px;padding:5px 8px;border-bottom:1px solid #44403c;border-radius:7px 7px 0 0;background:#1c1917;color:#e7e5e4;cursor:move;user-select:none;touch-action:none;pointer-events:auto}.ww-core-window-head strong{color:#fcd34d;font-size:12px}.ww-core-window-hint{color:#78716c;font-size:9px}.ww-core-window-reset{margin-left:auto;border:0;background:transparent;color:#78716c;font-size:14px;line-height:1;cursor:pointer}.ww-core-window-reset:hover{color:#fcd34d}.ww-core-window-grip{position:absolute;right:-1px;bottom:-1px;width:18px;height:18px;border-right:3px solid #ec4899;border-bottom:3px solid #ec4899;border-radius:0 0 7px 0;cursor:nwse-resize;pointer-events:auto;touch-action:none}.ww-core-resizable-block{box-sizing:border-box!important;resize:both!important;overflow:auto!important;min-width:120px!important;min-height:42px!important;max-width:100%!important;outline:1px solid transparent;outline-offset:-1px}.ww-core-resizable-block:hover{outline-color:#9d174d}.ww-core-resizable-block:focus-within{outline-color:#ec4899}`;
    style.textContent+=`.ww-core-resizable-block::-webkit-resizer{background:linear-gradient(135deg,transparent 0 45%,#9d174d 46% 62%,#ec4899 63% 78%,transparent 79%);border-radius:0 0 3px 0}`;
    style.textContent+=`#ww-settings .ww-outfit-row{display:grid;grid-template-columns:70px minmax(220px,1fr);gap:7px;align-items:center;margin-top:9px;padding:9px;border:1px solid #292524;border-radius:7px;background:#0c0a09}#ww-settings .ww-outfit-row .ww-help{grid-column:2}.ww-detail-traits{display:grid;grid-template-columns:1fr 1fr;gap:6px}.ww-detail-trait{display:grid;grid-template-columns:auto minmax(0,1fr) 58px;gap:7px;align-items:start;border:1px solid #292524;border-radius:6px;padding:7px;background:#0c0a0980}.ww-detail-trait input{margin-top:3px}.ww-affinities{display:grid;grid-template-columns:1fr 1fr;gap:7px 12px}.ww-affinity-row{display:grid;grid-template-columns:minmax(115px,1fr) minmax(90px,1fr) 52px 58px;gap:6px;align-items:center;border-bottom:1px solid #292524;padding:6px 0}.ww-affinity-copy{display:flex;flex-direction:column}.ww-affinity-title{font-size:12px;color:#e7e5e4;font-weight:700}.ww-affinity-row input[type=range]{width:100%;accent-color:#ec4899}.ww-affinity-row input[type=number]{width:100%;box-sizing:border-box}.ww-live-outfit{max-width:82px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:0.5625rem;color:#d6d3d1;border:1px solid #44403c;border-radius:999px;padding:1px 5px}@media(max-width:900px){.ww-detail-traits,.ww-affinities{grid-template-columns:1fr}#ww-settings .ww-outfit-row{grid-template-columns:58px minmax(0,1fr)}.ww-affinity-row{grid-template-columns:minmax(105px,1fr) minmax(80px,1fr) 48px 54px}}`;
    const settings=wwEl('div');settings.id='ww-settings';settings.hidden=true;const dialog=wwEl('div','ww-dialog'),head=wwEl('div','ww-dialog-head'),title=wwEl('h2','', '창관 운영'),close=wwEl('button','ww-close','✕');close.type='button';close.addEventListener('click',wwCloseSettings);head.append(title,close);dialog.append(head,wwEl('div','ww-settings-body'));settings.append(dialog);settings.addEventListener('click',event=>{if(event.target===settings)wwCloseSettings()});
    const live=wwEl('aside');live.id='ww-live-panel';live.hidden=true;const liveHead=wwEl('div','ww-live-head'),liveTitle=wwEl('strong','', '창관 인물 실시간'),liveCount=wwEl('span','ww-live-count'),closeLive=wwEl('button','ww-live-close','닫기');closeLive.type='button';closeLive.title='실시간 창 닫기';closeLive.addEventListener('click',()=>{const config=wwEnsureConfig(ue.getState().state);config.showLivePanel=false;wwSave();if(wwUi?.settings&&!wwUi.settings.hidden)wwRenderSettings()});liveHead.append(liveTitle,liveCount,closeLive);const grid=wwEl('div','ww-live-grid');live.append(liveHead,grid);live.addEventListener('pointerdown',()=>wwRaiseStandaloneWindow(live));wwRaiseStandaloneWindow(live);wwInstallPanelInteraction(live,liveHead);
    style.textContent+=`.ww-live-card,.ww-live-head{font-size:1rem}.ww-live-card button{font:inherit}.ww-live-close{margin-left:auto;font:inherit;font-size:.75rem;border:1px solid #57534e;border-radius:4px;background:#292524;color:#e7e5e4;padding:3px 8px;cursor:pointer}.ww-live-card .ww-bar-top{font-size:.625rem}`;
    style.textContent+=`#ww-hire-window{color:#e7e5e4;z-index:2147483647!important}#ww-hire-window input,#ww-hire-window select,#ww-hire-window button{font:inherit}#ww-hire-window input,#ww-hire-window select{background:#0c0a09;border:1px solid #57534e;border-radius:5px;color:#e7e5e4;padding:6px;max-width:100%;box-sizing:border-box}#ww-hire-window h4{font-size:.8rem;margin:12px 0 6px;color:#d6d3d1}#ww-hire-window .ww-note{font-size:.75rem;color:#a8a29e}#ww-hire-window [aria-pressed=true]{outline:1px solid #c4b5fd}#ww-hire-window .ww-hire-footer{position:sticky;bottom:0;background:#1c1917;padding:8px 0;border-top:1px solid #57534e}#ww-hire-window .ww-hire-message{margin:0;white-space:pre-wrap;color:#fca5a5;font-size:.75rem}#ww-hire-window .ww-hire-message:empty{display:none}`;
    style.textContent+=WBE.css;document.head.append(style);document.body.append(settings,live);wwUi={settings,live};globalThis.__waywardBrothelOpenSettings=wwOpenSettings;
    document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!settings.hidden)wwCloseSettings()});const modalObserver=new MutationObserver(wwScheduleModalStacking);modalObserver.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['class','style','hidden']});setInterval(wwDecorateGame,1000);wwRenderLive();wwDecorateGame();
    try{ue.subscribe(()=>{wwRenderLive();wwScheduleDecorate();wwHireView?.refresh()})}catch{}
  }
  // 배달·축제·남편 이용은 같은 배정표를 사용하며 세이브에 보존합니다.
  function Brothel_자료읽기(state){return{assignments:{},playerSession:null,relationships:{},playerHistory:[],...state?.mods?.brothel}}
  function Brothel_자료쓰기(state,patch){return{...state,mods:{...state.mods,brothel:{...Brothel_자료읽기(state),...patch}}}}
  function Brothel_직원읽기(state,id){return wwEnsureConfig(state).workers.find(worker=>worker.id===id&&worker.enabled)}
  function Brothel_불가이유읽기(state,id){
    const worker=Brothel_직원읽기(state,id);if(!worker)return'고용 중인 매춘부가 아닙니다.';
    if(wwOnBirthLeave(state,id))return'출산 휴가 중입니다. 다음 날 아침 복귀합니다.';
    const unpaid=wwUnpaidWages(state,worker);
    if(unpaid>0)return`미지급 급료 ${unpaid}골드를 완납할 때까지 근무를 보류합니다.`;
    if(Brothel_자료읽기(state).assignments?.[id])return'다른 대화·서비스·출장에 배정되어 있습니다.';
    const runtime=wwGetRuntime(worker,state);
    if(runtime.interaction)return'손님을 응대하고 있습니다.';
    if(['rest','night_rest'].includes(runtime.task)||runtime.stats.energy<10)return'휴식이 필요합니다.';
    return'';
  }
  function Brothel_직원배정하기(state,ids,options){
    if(!ids.length||new Set(ids).size!==ids.length||ids.some(id=>Brothel_불가이유읽기(state,id)))return state;
    const assignments={...Brothel_자료읽기(state).assignments};
    for(const id of ids)assignments[id]={owner:options.owner,location:options.location,task:options.task??'출장 근무',situation:options.situation??'출장 작업을 진행하고 있습니다.',baseLocation:options.location,baseTask:options.task??'출장 근무',baseSituation:options.situation??'출장 작업을 진행하고 있습니다.'};
    const next=Brothel_자료쓰기(state,{assignments});
    for(const id of ids)wwGetRuntime(Brothel_직원읽기(next,id),next);
    return next;
  }
  function Brothel_직원복귀시키기(state,owner,workerId=null){
    const assignments=Brothel_자료읽기(state).assignments??{},ids=Object.keys(assignments).filter(id=>assignments[id].owner===owner&&(!workerId||id===workerId));
    if(!ids.length)return state;
    const next=Brothel_자료쓰기(state,{assignments:Object.fromEntries(Object.entries(assignments).filter(([id,item])=>item.owner!==owner||workerId&&id!==workerId))});
    for(const id of ids){const worker=Brothel_직원읽기(next,id);if(worker)wwGetRuntime(worker,next)}
    return next;
  }
  function Brothel_출장활동지정하기(state,id,customer,stage,options={}){
    const worker=Brothel_직원읽기(state,id),assignment=Brothel_자료읽기(state).assignments?.[id];
    if(!worker||!assignment||assignment.owner!==options.owner||!customer)return state;
    const room=options.location??assignment.location,untilSlot=Number.isFinite(options.untilSlot)?options.untilSlot:state.slot+6;
    let next=room&&customer.id?wwMoveCustomer(state,customer.id,room):state;
    const interaction=stage?{customerId:customer.id,customerName:customer.name,customerSnapshot:wwClone(customer),stages:[stage],index:0,stage,
      comfort:wwInteractionScore(worker,customer,next),sharedWithWife:false,grossEarned:0,wagesEarned:0,externalOwner:options.owner}:null;
    const assignments={...Brothel_자료읽기(next).assignments,[id]:{...assignment,location:room,task:interaction?'interaction':assignment.baseTask,
      situation:options.situation??(interaction?`${customer.name}과(와) ${WW_STAGE_LABEL[stage]??stage} 중입니다.`:assignment.baseSituation),busyUntil:untilSlot,interaction}};
    next=Brothel_자료쓰기(next,{assignments});wwGetRuntime(worker,next);return next;
  }
  function Brothel_출장활동끝내기(state,id,options={}){
    const worker=Brothel_직원읽기(state,id),assignment=Brothel_자료읽기(state).assignments?.[id];
    if(!worker||!assignment||assignment.owner!==options.owner)return state;
    let next=state;const customerId=assignment.interaction?.customerId;
    if(customerId&&options.returnLocation)next=wwMoveCustomer(next,customerId,options.returnLocation);
    const current=Brothel_자료읽기(next).assignments?.[id]??assignment;
    const assignments={...Brothel_자료읽기(next).assignments,[id]:{...current,location:options.location??current.baseLocation,task:current.baseTask,
      situation:options.situation??current.baseSituation,busyUntil:Number.POSITIVE_INFINITY,interaction:null}};
    next=Brothel_자료쓰기(next,{assignments});wwGetRuntime(worker,next);return next;
  }
  function Brothel_출장서비스시작하기(state,id,customer,stage,options={}){
    const worker=Brothel_직원읽기(state,id),assignment=Brothel_자료읽기(state).assignments?.[id];
    if(!worker||!WW_PAID_STAGES.has(stage)||!assignment||assignment.owner!==options.owner)return state;
    const runtime=wwGetRuntime(worker,state),fee=Math.max(1,Math.floor(Number(options.fee)||wwServiceFee(stage,customer)));
    if(runtime.stats.energy<wwServiceEnergyCost(worker,stage)||(Number(customer?.walletGold)||0)<fee||!wwWorkerServiceAcceptance(worker,customer,state,stage).accepted)return state;
    const wage=Math.ceil(fee/2),house=fee-wage;
    let next=typeof Mt==='function'?Mt(state,'paid_offers',house):{...state,economy:{...state.economy,gold:state.economy.gold+house}};
    WBE.recordIncome(wwEnsureConfig(next),next,worker,customer,{kind:'service',stage,gross:fee,house,wage});
    wwRecordServiceWage(worker,next,wage);runtime.wagesEarned=(runtime.wagesEarned??0)+wage;wwSpend(worker,runtime,wwServiceEnergyCost(worker,stage),1,2);
    next={...next,customers:(next.customers??[]).map(item=>item.id===customer.id?{...item,walletGold:Math.max(0,(Number(item.walletGold)||0)-fee),tab:(Number(item.tab)||0)+fee}:item)};
    if(WW_EXPOSED_STAGES.has(stage)){
      const rep=next.tavernReputation??{},gain=wwEnsureConfig(next).serviceRenownGainMultiplier;
      next={...next,tavernReputation:{...rep,renown:wwClamp(Math.round(((rep.renown??0)+gain)*10)/10),service:wwClamp(Math.round(((rep.service??0)+gain)*10)/10),notoriety:rep.notoriety??0}};
    }
    return wwLog(next,`${customer.name}이(가) ${worker.name}의 출장 서비스 요금 ${fee}골드를 냅니다. 급료 ${wage}골드 · 업소 수입 ${house}골드. 악명은 오르지 않습니다.`,worker.id);
  }
  function Brothel_출장서비스완료하기(state,id,customer,stage,options={}){
    const worker=Brothel_직원읽기(state,id),assignment=Brothel_자료읽기(state).assignments?.[id];
    if(!worker||!WW_PAID_STAGES.has(stage)||!assignment||assignment.owner!==options.owner)return state;
    const runtime=wwGetRuntime(worker,state),fee=Math.max(1,Math.floor(Number(options.fee)||Brothel_요금읽기(state,stage)));
    WBE.recordExperience(worker,state,runtime,customer,stage,fee);
    let next=state;
    if(stage==='sex_patron')next=globalThis.__waywardBrothelPregnancy?.recordService?.(next,worker,customer)??next;
    next=Brothel_손님관계기능.recordStage(next,worker,customer,stage);
    next=Brothel_손님관계기능.finishInteraction(next,worker,customer,{stage,comfort:wwInteractionScore(worker,customer,next),pleasure:runtime.stats.arousal});
    wwPersistConfig();return wwLog(next,`${worker.name}이(가) ${customer.name}과(와)의 ${(WW_STAGE_LABEL[stage]??stage).replace(/ 중$/,'')} 출장 서비스를 마쳤습니다.`,worker.id);
  }
  function Brothel_출장서비스처리하기(state,id,customer,stage,options={}){
    const fee=Math.max(1,Math.floor(Number(options.fee)||wwServiceFee(stage,customer))),started=Brothel_출장서비스시작하기(state,id,customer,stage,{...options,fee});
    return started===state?state:Brothel_출장서비스완료하기(started,id,customer,stage,{...options,fee});
  }
  function Brothel_남편이용불가이유읽기(state,id,stage){
    if(!state||state.gameOver)return'게임 진행 중에 이용하세요.';
    if(Brothel_자료읽기(state).playerSession)return'진행 중인 대화·서비스를 먼저 마무리하세요.';
    const worker=Brothel_직원읽기(state,id),runtime=worker?wwGetRuntime(worker,state):null,aftercare=wwAftercareRemaining(state,id);
    if(aftercare>0)return`서비스를 마친 뒤 정리 중입니다. ${aftercare}분 후 말을 걸 수 있습니다.`;
    const reason=Brothel_불가이유읽기(state,id);if(reason)return reason;
    if(!['prep','service','last_call'].includes(state.phase)||state.pendingEvent||state.activeScene?.sex||state.activeScene?.patron||state.activeScene?.situation||state.activeScene?.table)return'진행 중인 사건이나 장면을 먼저 마무리하세요.';
    if(state.errandSession||state.activeShoppingSession||state.deliveryAddon?.activeDelivery?.who==='player'||state.mods?.festival?.stall||state.mods?.festival?.labor?.who==='player')return"당신이 외출 중입니다.";
    if(wmlApi.fn('playerLocation')(state)!==runtime.location)return'매춘부가 있는 장소로 이동하세요.';
    if(stage!=='chatting'&&!WW_PAID_STAGES.has(stage))return'서비스를 선택하세요.';
    if(stage!=='chatting'&&state.economy.gold<Brothel_요금읽기(state,stage))return'서비스 요금을 낼 골드가 부족합니다.';
    if(stage!=='chatting'&&runtime.stats.energy<wwServiceEnergyCost(worker,stage))return'이 서비스를 진행할 기력이 부족합니다.';
    if(stage!=='chatting'&&!wwWorkerServiceAcceptance(worker,{name:"당신",boldness:0,intent:'interested',tacticStyle:'transactional'},state,stage).accepted)return'이 직원이 현재 해당 서비스를 원하지 않습니다.';
    if(WW_EXPOSED_STAGES.has(stage)&&runtime.location==='taproom'&&!wwEnsureConfig(state).allowTaproomSex&&!wwChoosePrivateRoom(state,'player'))return'홀 서비스 허용을 켜거나 함께 사용할 빈 방을 마련하세요.';
    return'';
  }
  function Brothel_요금읽기(state,stage){return WBE.minimumPrice(wwEnsureConfig(state),stage,{boldness:0})}
  function Brothel_사후정리기다리기(state,action){
    const id=action.workerId,worker=Brothel_직원읽기(state,id),remaining=wwAftercareRemaining(state,id);if(!worker||remaining<=0)return state;
    let next=wwLog(state,`${worker.name}: “잠시만 기다려 주세요. 정리를 마치고 바로 이야기할게요.”`,id);
    for(let minute=0;minute<remaining&&!next.pendingEvent&&!next.gameOver&&wwAftercareRemaining(next,id)>0;minute++){
      const before=next.slot;next=wmlApi.fn('worldTick')(next,{playerPresent:true});if(next.slot<=before)break;
      if(Brothel_자료읽기(next).assignments?.[id]?.owner)break;
    }
    if(!next.pendingEvent&&!next.gameOver&&wwAftercareRemaining(next,id)<=0)next=wwLog(next,`${worker.name}이(가) 정리를 마치고 당신에게 돌아옵니다.`,id);
    return next;
  }
  function Brothel_남편이용하기(state,action){
    const id=action.workerId,stage=action.stage??'chatting';let reason=Brothel_남편이용불가이유읽기(state,id,stage);
    // 홀에서 금지된 서비스는 예약 가능한 빈 방으로 함께 이동합니다.
    const room=!reason&&WW_EXPOSED_STAGES.has(stage)&&wmlApi.fn('playerLocation')(state)==='taproom'&&!wwEnsureConfig(state).allowTaproomSex?wwChoosePrivateRoom(state,'player'):null;
    if(reason)return wwLog(state,reason,id);
    const worker=Brothel_직원읽기(state,id),runtime=wwGetRuntime(worker,state),originalLocation=wmlApi.fn('playerLocation')(state);
    let next=room?wmlApi.fn('moveOccupant')(state,'player',room):state;
    const fee=stage==='chatting'?0:Brothel_요금읽기(next,stage);
    next=Brothel_직원배정하기(next,[id],{owner:'brothel-player',location:room??originalLocation,task:stage==='chatting'?"당신과 대화":"당신에게 유료 서비스",situation:`당신과 ${stage==='chatting'?'대화':'유료 서비스'} 중입니다. 이용료 ${fee}골드.`});
    if(fee){
      next={...next,economy:{...next.economy,gold:next.economy.gold-fee}};
      WBE.recordIncome(wwEnsureConfig(next),next,worker,{name:"당신"},{kind:'service',stage,gross:fee,house:0,wage:fee});
      wwRecordServiceWage(worker,next,fee);runtime.wagesEarned=(runtime.wagesEarned??0)+fee;
    }
    wwPersistConfig();next=wwLog(next,fee?`${worker.name}에게 서비스 요금 ${fee}골드를 지불했습니다. 당신도 요금을 내야 하며 전액 그녀에게 지급됩니다.`:`${worker.name}과(와) 대화를 시작했습니다. 대화는 무료이며 성적 서비스는 별도 요금을 내야 합니다.`,id);
    return Brothel_대화기능.start(next,{workerId:id,stage,fee,originalLocation});
  }
  function Brothel_남편이용정리하기(state){
    return Brothel_대화기능.progress(state);
  }
  function Brothel_남편서비스기록하기(state,session){
    const worker=Brothel_직원읽기(state,session.workerId);if(!worker)return state;
    const runtime=wwGetRuntime(worker,state);
    WBE.recordExperience(worker,state,runtime,{name:"당신"},session.stage,session.fee);
    wwSpend(worker,runtime,wwServiceEnergyCost(worker,session.stage),1,2);wwPersistConfig();return state;
  }
  function Brothel_남편장소복원하기(state,room){
    return room&&state.locations?.[room]&&wmlApi.fn('playerLocation')(state)!==room?wmlApi.fn('moveOccupant')(state,'player',room):state;
  }
  function Brothel_사후정리시작하기(state,id,stage,options={}){
    const worker=Brothel_직원읽기(state,id);return worker?wwBeginAftercare(state,worker,wwGetRuntime(worker,state),stage,options):state;
  }
  function Brothel_남편행동그리기(){
    const state=wmlApi.fn('store')(root=>root.state),React=wmlApi.fn('React'),jsx=wmlApi.fn('jsx');
    const [id,setId]=React.useState(''),[stage,setStage]=React.useState('sex_patron');
    if(!state)return null;
    const workers=wwActiveWorkers(wwEnsureConfig(state)).filter(worker=>wwGetRuntime(worker,state).location===wmlApi.fn('playerLocation')(state)),
      chosen=workers.some(worker=>worker.id===id)?id:'';
    if(!workers.length&&!Brothel_자료읽기(state).playerSession)return null;
    return Brothel_대화기능.render(state,{workers,chosen,stage,setId,setStage,unavailable:(workerId,kind)=>Brothel_남편이용불가이유읽기(state,workerId,kind),fee:kind=>Brothel_요금읽기(state,kind)});
  }
  function Brothel_독립대화불가이유읽기(state,id){
    const session=Brothel_자료읽기(state).playerSession;
    if(session?.workerId===id&&session.stage==='chatting'){
      if(state.pendingEvent)return'진행 중인 사건을 먼저 해결하세요.';
      if(session.waitingUntil!=null)return'현재 대화 단계를 마친 뒤 독립 이야기를 꺼내세요.';
      if(Brothel_자료읽기(state).assignments?.[id]?.owner!=='brothel-player')return'대화 중인 직원의 배정이 바뀌었습니다.';
      return'';
    }
    return Brothel_남편이용불가이유읽기(state,id,'chatting');
  }
  function Brothel_고용비용읽기(worker){
    return Math.max(1,Math.round(Number(worker.hireCost)||WW_HIRE_TIERS.find(tier=>tier.id===worker.hireTier)?.cost||WW_HIRE_TIERS[0].cost));
  }
  function Brothel_독립퇴사시키기(state,worker){
    let next=globalThis.__waywardBrothelPregnancy?.dismissWorker?.(state,worker.id)??state;
    const index=wwEnsureConfig(next).workers.findIndex(item=>item.id===worker.id);
    if(index<0)return next;
    const candidate=WW_CANDIDATES[index%WW_CANDIDATES.length]??WW_CANDIDATES[0],empty=wwPreset(candidate.id,`매춘부 ${index+1}`,next);
    empty.id=worker.id;wwConfig.workers[index]=empty;wwRuntime.delete(worker.id);wwPersistConfig();
    const assignments={...Brothel_자료읽기(next).assignments};delete assignments[worker.id];
    return Brothel_자료쓰기(next,{assignments});
  }
  const Brothel_손님관계기능=globalThis.__waywardBrothelPatronLifeFactory({
    readData:Brothel_자료읽기,writeData:Brothel_자료쓰기,workers:state=>wwActiveWorkers(wwEnsureConfig(state)),readWorker:Brothel_직원읽기,
    makeCharacter(state,worker,previous){
      const candidate=wwCandidate(worker.portrait),archetype=candidate?.archetype??wmlApi.fn('wifeById')(candidate?.archetypeId)
        ??wmlApi.fn('wifeById')('elena_farmgirl');
      const base=previous??wmlApi.fn('brothelCharacterFromArchetype')(archetype,{id:worker.id,name:worker.name,day:state.day});
      return{...base,id:worker.id,name:worker.name,stats:{...worker.stats},
        attributes:{...base.attributes,...worker.attributes,libido:worker.tendencies.libido},
        latentTraits:Object.keys(worker.latentTraits).filter(key=>worker.latentTraits[key]),affinities:{...worker.affinities},
        feelings:[],relationship:{trust:50,patronInteractionsEncouraged:0}};
    },
    recordInteraction:(...args)=>wmlApi.fn('brothelRecordPatronInteraction')(...args),
    notify:(state,notice)=>wmlApi.events.alert(state,notice),log:wwLog,hireCost:Brothel_고용비용읽기,
    canDiscuss:Brothel_독립대화불가이유읽기,
    finishDialogue:(state,id)=>Brothel_자료읽기(state).playerSession?.workerId===id
      ?Brothel_대화기능.cancel(state,{sessionId:Brothel_자료읽기(state).playerSession.id}):state,
    depart:Brothel_독립퇴사시키기,randomInt:wwRandomInt
  });
  wmlApi.events.onAlert('marriage-request',state=>state);
  wmlApi.events.onAlert('independence',Brothel_손님관계기능.resolveIndependence);
  wmlApi.events.onAlert('independence-letter',Brothel_손님관계기능.receiveLetter);
  const Brothel_대화기능=globalThis.__waywardBrothelDialogueFactory({api:wmlApi,readData:Brothel_자료읽기,writeData:Brothel_자료쓰기,readWorker:Brothel_직원읽기,
    log:wwLog,release:Brothel_직원복귀시키기,recordService:Brothel_남편서비스기록하기,beginAftercare:Brothel_사후정리시작하기,restoreLocation:Brothel_남편장소복원하기,stageLabels:WW_STAGE_LABEL,paidStages:WW_PAID_STAGES,aftercareRemaining:wwAftercareRemaining,
    independence:{request:Brothel_손님관계기능.request,cost:Brothel_고용비용읽기,blocked:Brothel_독립대화불가이유읽기}});
  wwRegisterRooms();wwInstallMaintenance();wwSavedRaw=wwReadSaved();wwInstallEngine();api.Ol=Ol;wwInstallNewGameReset();
  wmlApi.actions.register('brothel/player-service',Brothel_남편이용하기,{label:'매춘부와 대화·유료 서비스'});
  wmlApi.actions.register('brothel/player-wait-aftercare',Brothel_사후정리기다리기,{label:'직원의 정리를 잠시 기다리기'});
  wmlApi.actions.register('brothel/player-choice',Brothel_대화기능.choose,{label:'직원과 이야기 이어가기'});
  wmlApi.actions.register('brothel/player-continue',Brothel_대화기능.continue,{label:'진행 중인 단계 이어가기'});
  wmlApi.actions.register('brothel/player-cancel',Brothel_대화기능.cancel,{label:'직원과의 이용 중단하기'});
  wmlApi.actions.register('brothel/independence',Brothel_손님관계기능.openIndependence,{label:'직원에게 독립 권유하기'});
  wmlApi.hook('worldTick',{priority:-250,after:Brothel_남편이용정리하기});
  wmlApi.hook('wakeUp',{priority:-500,after:Brothel_손님관계기능.morning});
  wmlApi.hook('wakeUp',{priority:-600,after:state=>wwPayDailyWages(state,wwEnsureConfig(state))});
  wmlApi.hook('reduceGameAction',{priority:-600,around(next,state,action,...args){
    if(Brothel_자료읽기(state).playerSession&&!['wait','resolve_event','brothel/player-choice','brothel/player-continue','brothel/player-cancel','brothel/player-wait-aftercare','brothel/independence'].includes(action.type))return wwLog(state,'매춘부와의 대화·서비스를 먼저 마무리하세요.');
    return next(state,action,...args);
  }});
  const Brothel_방별대화자리={taproom:'brothelHallActions',bedroom:'brothelBedroomActions',bathhouse:'brothelBathhouseActions',
    bathroom:'brothelBathroomActions',back_room:'brothelBackRoomActions',kitchen:'brothelKitchenActions',
    upstairs_hall:'brothelGuestRoomActions',upstairs_room_2:'brothelGuestRoomActions',elena_room:'brothelPrivateRoomActions'};
  function Brothel_대화자리배치(tree,room){
    const state=wmlApi.store.game(),React=wmlApi.fn('React'),jsx=wmlApi.fn('jsx').jsx,
      wifeName=state&&wmlApi.fn('wife')(state)?.name,button=wmlApi.fn('ActionButton');
    const extra=jsx('div',{'data-brothel-talk-slot':room,children:jsx(Brothel_남편행동그리기,{})},'brothel-talk');
    let inserted=false;
    const visit=node=>{
      if(Array.isArray(node))return node.map(visit);
      if(!React.isValidElement(node))return node;
      if(!inserted&&node.type===button&&wifeName&&node.props.label===wifeName){
        inserted=true;return jsx(React.Fragment,{children:[node,extra]},node.key);
      }
      return node.props.children==null?node:React.cloneElement(node,{},visit(node.props.children));
    };
    const result=visit(tree);if(inserted)return result;
    if(React.isValidElement(result)&&Array.isArray(result.props.children)){
      const children=[...result.props.children],index=room==='taproom'?(state.phase==='prep'?4:3):1;
      children.splice(Math.min(index,children.length),0,extra);return React.cloneElement(result,{},children);
    }
    return jsx(React.Fragment,{children:[extra,result]});
  }
  for(const symbol of new Set(Object.values(Brothel_방별대화자리)))wmlApi.hook(symbol,{priority:-250,after(tree){
    const state=wmlApi.store.game();return state?Brothel_대화자리배치(tree,wmlApi.fn('playerLocation')(state)):tree;
  }});
  wmlApi.hook('ActionPanel',{priority:-30000,after(result){
    const state=wmlApi.store.game();if(!state)return result;
    // 사건 응답창은 기존 순서로 두고 진행 중 대화가 있으면 그 아래에서 이어갑니다.
    if(state.pendingEvent)return Brothel_자료읽기(state).playerSession?wmlApi.fn('jsx').jsxs(wmlApi.fn('React').Fragment,
      {children:[result,wmlApi.fn('jsx').jsx(Brothel_남편행동그리기,{})]}):result;
    if(Brothel_방별대화자리[wmlApi.fn('playerLocation')(state)]&&state.phase!=='bedroom')return result;
    return Brothel_대화자리배치(result,wmlApi.fn('playerLocation')(state));
  }});
  function Brothel_편집직원자료(worker){return{id:worker.id,name:worker.name,personality:worker.personality,hireTier:worker.hireTier,stats:{...worker.stats},attributes:{...worker.attributes},tendencies:{...worker.tendencies},traits:{...worker.traits},latentTraits:{...worker.latentTraits},affinities:{...worker.affinities},wageLedger:{...worker.wageLedger}}}
  function Brothel_편집자료읽기(){const state=ue.getState()?.state,config=state&&wwEnsureConfig(state);return{version:1,revision:wwEditorRevision,
    schema:{numeric:wwClone(WW_NUMERIC),traits:wwClone(WW_TRAITS),latentTraits:wwClone(WW_LATENT_TRAITS),affinities:wwClone(WW_AFFINITIES),personalities:wwClone(WW_PERSONALITIES)},
    workers:config?wwActiveWorkers(config).map(Brothel_편집직원자료):[]}}
  function Brothel_편집패치적용(worker,patch={}){
    const numberGroup=(group,defs,min,max)=>{if(patch[group]==null)return;for(const[key]of defs){if(patch[group][key]==null)continue;const value=Number(patch[group][key]);if(!Number.isFinite(value)||value<min||value>max)throw Error(`${key} 값이 ${min}~${max} 범위를 벗어났습니다.`);worker[group][key]=Math.round(value*10)/10}};
    numberGroup('stats',WW_NUMERIC.stats,0,100);numberGroup('attributes',WW_NUMERIC.attributes,0,100);numberGroup('tendencies',WW_NUMERIC.tendencies,0,100);numberGroup('affinities',WW_AFFINITIES,-2,2);
    if(patch.traits!=null)for(const[key]of WW_TRAITS)if(patch.traits[key]!=null)worker.traits[key]=!!patch.traits[key];
    if(patch.latentTraits!=null)for(const[key]of WW_LATENT_TRAITS)if(patch.latentTraits[key]!=null)worker.latentTraits[key]=!!patch.latentTraits[key];
    if(patch.personality!=null){if(!WW_PERSONALITIES.some(([id])=>id===patch.personality))throw Error('성격 선택을 확인해 주세요.');worker.personality=patch.personality}
    wwSyncConfiguredStats(worker);wwInvalidateLook(worker);
  }
  function Brothel_편집적용(changes,expectedRevision){
    if(expectedRevision!==wwEditorRevision)throw Error('창관 직원 자료가 편집 중 바뀌었습니다. 에디터를 다시 열어 주세요.');
    const state=ue.getState()?.state,config=wwEnsureConfig(state),before=Brothel_편집자료읽기();
    for(const change of changes||[]){const worker=config.workers.find(item=>item.enabled&&item.id===change.id);if(!worker)throw Error('편집할 창관 직원을 찾지 못했습니다.');Brothel_편집패치적용(worker,change.patch)}
    wwSave();return{snapshot:before,afterRevision:wwEditorRevision};
  }
  function Brothel_편집복원(snapshot,expectedRevision){
    if(expectedRevision!==wwEditorRevision)return false;const state=ue.getState()?.state,config=wwEnsureConfig(state);
    for(const saved of snapshot?.workers||[]){const worker=config.workers.find(item=>item.enabled&&item.id===saved.id);if(worker)Brothel_편집패치적용(worker,saved)}wwSave();return true;
  }
  globalThis.__waywardBrothelPublic={atRoom:room=>wwActiveWorkers().filter(worker=>wwRuntime.get(worker.id)?.location===room).map(worker=>({id:worker.id,name:worker.name})),openSettings:wwOpenSettings,refreshSettings:wwRenderSettings,saveConfig:wwSave,getConfig:()=>wwConfig,getRuntime:()=>wwRuntime,tick:wwTick,purchaseCellar:id=>{const room=WW_CELLARS.find(item=>item.id===id);if(room)wwPurchaseCellar(room)},purchaseBreakRoom:wwPurchaseBreakRoom};
  Object.assign(globalThis.__waywardBrothelPublic,{
    liveActors:()=>ue.getState().started?wwLiveActors(ue.getState().state).map(actor=>({id:actor.id,name:actor.kind==='wife'?wwWifeLiveState(ue.getState().state).name:actor.worker.name})):[],
    createLiveCard:id=>wwLiveCard(document.createElement('div'),id),
    updateLiveCard:(card,id)=>{const state=ue.getState().state,actor=wwLiveActors(state).find(actor=>actor.id===id);if(actor)wwPaintActor(card,actor,state);return !!actor;},
    discoverCharacters:Brothel_캐릭터탐색하기,
    workers:state=>wwActiveWorkers(wwEnsureConfig(state)).map(worker=>{const runtime=wwGetRuntime(worker,state);return{id:worker.id,name:worker.name,energy:runtime.stats.energy,location:runtime.location,task:runtime.task,situation:runtime.situation}}),
    unavailable:Brothel_불가이유읽기,assign:Brothel_직원배정하기,release:Brothel_직원복귀시키기,releaseOne:(state,owner,id)=>Brothel_직원복귀시키기(state,owner,id),service:Brothel_출장서비스처리하기,beginService:Brothel_출장서비스시작하기,finishService:Brothel_출장서비스완료하기,
    externalActivity:Brothel_출장활동지정하기,endExternalActivity:Brothel_출장활동끝내기,
    fee:Brothel_요금읽기,quote:(state,stage,customer)=>wwServiceFee(stage,customer),playerService:Brothel_남편이용하기,portrait:(state,id)=>{const worker=Brothel_직원읽기(state,id);return worker?wwTalentKey(worker,wwGetRuntime(worker,state),state):null},
    playerChoices:Brothel_대화기능.choices,playerRelationship:Brothel_대화기능.relationship,
    patronRelationship:(state,id,name)=>{const worker=Brothel_직원읽기(state,id);return worker?Brothel_손님관계기능.record(state,worker,name):null},
    patronRelationships:(state,id)=>{const worker=Brothel_직원읽기(state,id);return worker?wwClone(Brothel_손님관계기능.employee(state,worker)):null},
    imageRoom:wwImageRoom,loadPortrait:wwLoadPortraitKey,
    editorRead:Brothel_편집자료읽기,editorApply:Brothel_편집적용,editorRestore:Brothel_편집복원,
    hireTiers:()=>wwClone(WW_HIRE_TIERS),hireTemplate:(state,options)=>wwClone(wwHireTemplate(state,options)),workerAcceptance:wwWorkerSexAcceptance,serviceAcceptance:(state,id,stage,customer)=>{const worker=Brothel_직원읽기(state,id);return worker?wwWorkerServiceAcceptance(worker,customer,state,stage):{accepted:false,score:0}},sexRequestDecision:wwSexRequestDecision,interactionStages:wwInteractionStages,settleWages:wwPayDailyWages,
    aftercare:Brothel_사후정리시작하기,aftercareRemaining:wwAftercareRemaining,
    workerHasService:wwWorkerHasService,
    setBirthLeave:(state,id)=>Brothel_자료쓰기(state,{birthLeave:{...Brothel_자료읽기(state).birthLeave,[id]:state.day}})
  });
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',wwInstallUI,{once:true});else wwInstallUI();
})();
/* --- End brothel system --- */

  },
});
