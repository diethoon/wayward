// 실행: node wml/mods/<모드>/source/build.mjs
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
const dir=path.dirname(fileURLToPath(import.meta.url));
const text='// 생성 파일. 수정: source/mod.wml.js, source/native-ui.js, source/player-dialogue.js, source/patron-life.js — 재생성: node '+path.relative(process.cwd(),path.join(dir,'build.mjs')).replaceAll('\\','/')+'\n'+['native-ui.js','player-dialogue.js','patron-life.js','mod.wml.js'].map(file=>fs.readFileSync(path.join(dir,file),'utf8')).join('\n');
new vm.Script(text);
fs.writeFileSync(path.join(dir,'../mod.js'),Pre7_lazySetup(text));
console.log('Generated '+path.join(dir,'../mod.js'));

// pre7: loading a disabled mod must not initialize globals or change settings.
function Pre7_lazySetup(source){
  const at=source.indexOf('WML.define({');if(at<0)throw Error('WML definition missing');
  const prefix=source.slice(0,at);if(!prefix.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*/g,'').trim())return source;
  const header=prefix.match(/^(?:\s|\/\*[\s\S]*?\*\/|\/\/[^\n]*(?:\n|$))*/)[0];
  let found=false;
  const result=header+source.slice(at).replace(/((?:async\s+)?setup\([^)]*\)\s*\{)/,match=>{found=true;return match+'\n'+prefix+'\nObject.assign(globalThis,{Brothel_대화엔진만들기,Brothel_손님관계엔진만들기});\n';});
  if(!found)throw Error('setup declaration missing');return result;
}
