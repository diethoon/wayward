// 창관 직원과 남편의 대화·관계·단계 진행. source/build.mjs가 mod.js에 포함합니다.
function Brothel_대화엔진만들기(context) {
  const { api, readData, writeData, readWorker, log, release, recordService, beginAftercare, restoreLocation, stageLabels, paidStages, aftercareRemaining, independence } = context;
  const jsx = api.fn('jsx');
  const ActionButton = api.fn('ActionButton');
  const inputStyle = { backgroundColor: '#000', color: '#fff', colorScheme: 'dark', border: '1px solid #78716c', borderRadius: '4px', padding: '5px', maxWidth: '100%' };
  const optionStyle = { backgroundColor: '#000', color: '#fff' };
  const buttonStyle = { background: '#292524', color: '#fafaf9', border: '1px solid #78716c', borderRadius: '5px', padding: '8px', textAlign: 'left', width: '100%' };
  const topics = { work: '오늘 근무', mood: '기분과 휴식', thanks: '수고에 대한 감사', personal: '일 밖의 취미', feelings: '서로의 마음' };
  const chatSteps = ['주제 고르기', '이야기 이어가기', '인사 나누기'];
  const serviceSteps = ['의사·범위 확인', '함께 시간 보내기', '정리와 인사'];
  const serviceOrder = ['groping', 'intimate', 'handjob_patron', 'blowjob_patron', 'titfuck_patron', 'sex_patron'];
  const serviceLabels = { groping: '짙은 스킨십', intimate: '은밀한 애무', handjob_patron: '손 서비스', blowjob_patron: '구강 서비스', titfuck_patron: '가슴 서비스', sex_patron: '성관계' };

  function Brothel_관계값정리하기(value, fallback = 0) {
    return Number.isFinite(Number(value)) ? Math.max(0, Math.min(100, Math.round(Number(value)))) : fallback;
  }
  function Brothel_관계읽기(state, id) {
    if (!state) return null;
    const worker = readWorker(state, id); if (!worker) return null;
    const employeeKey = worker.relationshipId || `legacy:${id}`;
    const stored = readData(state).relationships?.[id];
    const raw = stored && stored.employeeKey === employeeKey ? stored : {};
    return { ...raw, employeeKey, affinity: Brothel_관계값정리하기(raw.affinity, 20), affection: Brothel_관계값정리하기(raw.affection),
      trust: Brothel_관계값정리하기(raw.trust, 30), familiarity: Brothel_관계값정리하기(raw.familiarity),
      conversations: Math.max(0, Math.floor(Number(raw.conversations) || 0)), services: Math.max(0, Math.floor(Number(raw.services) || 0)),
      daily: raw.daily?.day === state.day ? raw.daily : { day: state.day, topics: {} } };
  }
  function Brothel_관계쓰기(state, id, relationship) {
    return writeData(state, { relationships: { ...readData(state).relationships, [id]: relationship } });
  }
  function Brothel_관계이름읽기(relationship) {
    if (relationship.affection >= 40 && relationship.trust >= 65) return '서로 마음을 나누는 사이';
    if (relationship.affection >= 10) return '개인적인 호감을 알아 가는 사이';
    if (relationship.affinity >= 60 && relationship.trust >= 55) return '믿고 이야기하는 사이';
    if (relationship.affinity >= 35) return '조금씩 편해지는 사이';
    return '고용주와 직원으로 알아 가는 사이';
  }
  function Brothel_관계표시읽기(state, id) {
    const relation = Brothel_관계읽기(state, id);
    return relation ? `호감 ${relation.affinity} · 애정 ${relation.affection} · 신뢰 ${relation.trust} · 친밀 ${relation.familiarity} / 100` : '';
  }
  function Brothel_성격읽기(worker) {
    if (worker.traits?.pragmatic || worker.latentTraits?.cold_pragmatist) return 'practical';
    return (worker.tendencies?.sociability ?? 50) >= 60 ? 'warm' : 'reserved';
  }
  function Brothel_대사고르기(worker, variants) { return variants[Brothel_성격읽기(worker)] || variants.reserved; }
  function Brothel_대사추가하기(state, entries) {
    let next = state; let session = readData(next).playerSession; if (!session) return state;
    const worker = readWorker(state, session.workerId);
    const lines = [...(session.lines || [])];
    for (const [speaker, text] of entries) {
      const name = speaker === 'player' ? "당신" : speaker === 'worker' ? worker?.name || session.workerName : '';
      lines.push({ speaker, name, text, slot: state.slot });
      next = log(next, name ? `${name}: “${text}”` : text, session.workerId);
    }
    return writeData(next, { playerSession: { ...session, lines: lines.slice(-24) } });
  }
  function Brothel_마음변경하기(state, changes) {
    const session = readData(state).playerSession, relation = Brothel_관계읽기(state, session.workerId);
    if (!relation) return state;
    const nextRelation = { ...relation }, deltas = {};
    for (const key of ['affinity', 'affection', 'trust']) {
      const amount = Number(changes[key]) || 0;
      const allowed = amount <= 0 || session.rewardAllowed !== false ? amount : 0;
      nextRelation[key] = Brothel_관계값정리하기(relation[key] + allowed);
      deltas[key] = nextRelation[key] - relation[key];
    }
    const next = Brothel_관계쓰기(state, session.workerId, nextRelation);
    return writeData(next, { playerSession: { ...session, changes: deltas } });
  }
  function Brothel_대화시작하기(state, details) {
    const worker = readWorker(state, details.workerId), relation = Brothel_관계읽기(state, details.workerId);
    const sequence = (Number(readData(state).interactionSequence) || 0) + 1;
    let next = writeData(state, { interactionSequence: sequence, playerSession: { ...details, version: 2,
      id: `brothel-player:${state.slot}:${sequence}`, employeeKey: relation.employeeKey, workerName: worker.name, startedAt: state.slot, turn: 0,
      topic: null, rewardAllowed: true, waitingUntil: null, finished: false, serviceRecorded: false, lines: [], changes: {} } });
    const opening = details.stage === 'chatting'
      ? relation.affinity >= 60 ? '사장님, 오늘은 일 이야기 말고도 조금 이야기해도 좋겠네요. 어떤 얘기를 하고 싶으세요?'
        : Brothel_대사고르기(worker, { practical: '사장님, 잠깐 앉으세요. 오늘 일이나 제 근황 중 어떤 이야기를 하실 건가요?',
          warm: '사장님, 마침 한숨 돌리던 참이에요. 제 이야기도 궁금하셨어요?', reserved: '네, 사장님. 잠깐이면 괜찮아요. 무슨 이야기를 하고 싶으세요?' })
      : `사장님도 ${serviceLabels[details.stage] || stageLabels[details.stage] || '서비스'} 요금 ${details.fee}골드가 적용돼요. 서로 편한 범위를 먼저 확인하고, 서두르지 말아 주세요.`;
    next = Brothel_대사추가하기(next, [['narrator', `${worker.name}이(가) 하던 일을 잠시 멈추고 당신을 바라봅니다.`], ['worker', opening]]);
    return next;
  }
  function Brothel_선택지읽기(state) {
    const session = readData(state).playerSession;
    if (!session || session.version !== 2 || session.finished || session.waitingUntil != null) return [];
    if (session.stage !== 'chatting') return session.turn === 0
      ? [{ id: 'confirm', label: '요금과 서로의 뜻을 확인하고 준비하기' }, { id: 'reassure', label: '불편하면 바로 말해 달라고 하기' }]
      : session.turn === 1 ? [{ id: 'continue', label: '서두르지 않고 이어가기' }, { id: 'check', label: '괜찮은지 확인하며 이어가기' }]
      : [{ id: 'finish', label: '감사 인사하고 마무리하기' }, { id: 'compliment', label: '배려해 준 점을 칭찬하기' }];
    if (session.turn === 0) return Object.entries(topics).map(([id, label]) => ({ id, label }));
    if (session.turn === 1) return [{ id: 'listen', label: '말을 끊지 않고 더 들어 주기' }, { id: 'encourage', label: '그 생각을 존중하고 응원하기' },
      { id: 'share', label: '내 생각도 솔직하게 이야기하기' }, { id: 'press', label: '내 뜻을 따라 주길 요구하기' }];
    return [{ id: 'thanks', label: '이야기해 줘서 고맙다고 하기' }, { id: 'respect', label: '그녀의 시간과 선택을 존중하기' },
      { id: 'invite', label: '다음에는 근무 밖에서 차를 마시자고 제안하기' }];
  }
  function Brothel_주제대답하기(state, topic) {
    const session = readData(state).playerSession, worker = readWorker(state, session.workerId), relation = Brothel_관계읽기(state, worker.id);
    const used = Number(relation.daily.topics?.[topic]) || 0;
    let next = Brothel_관계쓰기(state, worker.id, { ...relation, daily: { day: state.day, topics: { ...relation.daily.topics, [topic]: used + 1 } } });
    next = writeData(next, { playerSession: { ...session, topic, rewardAllowed: used < 2 } });
    const prompts = { work: '오늘 일하면서 불편한 점은 없었어?', mood: '오늘 기분은 어때? 쉴 시간은 충분했어?',
      thanks: '손님들 신경 써 줘서 고마워. 네 수고를 알고 있어.', personal: '일하지 않을 때는 뭘 하며 쉬는 걸 좋아해?',
      feelings: '고용주와 직원이라는 관계를 떠나, 서로 조금 더 알아 가고 싶어.' };
    let reply, changes = { affinity: 2, trust: 2 };
    if (used >= 2) { reply = '사장님, 그 이야기는 오늘 이미 몇 번 나눴잖아요. 같은 말보다는 서로 생각할 시간을 조금 두면 좋겠어요.'; changes = {}; }
    else if (topic === 'work') reply = Brothel_대사고르기(worker, {
      practical: '손님이 몰릴 때 동선이 겹쳐요. 누가 어느 자리를 맡는지 정해 주시면 일이 훨씬 수월하겠어요.',
      warm: '손님들이 이름을 기억해 주면 기분이 좋아요. 그래도 일이 몰릴 때는 서로 도울 사람이 있으면 든든하겠어요.',
      reserved: '아직 익숙해지는 중이에요. 모르는 걸 물었을 때 재촉하지 않고 알려 주시면 좋겠어요.' });
    else if (topic === 'mood') reply = worker.stats?.energy < 35
      ? '조금 지쳤어요. 일을 그만두겠다는 뜻은 아니지만, 잠깐 제 속도로 쉬고 싶어요.'
      : Brothel_대사고르기(worker, { practical: '괜찮아요. 일을 잘하려면 쉴 때도 확실히 쉬어야 하니, 그 시간은 지켜 주시면 좋겠어요.',
        warm: '이렇게 물어봐 주시니 한결 편하네요. 일하는 사람으로만 보지 않는 것 같아서요.', reserved: '괜찮은 편이에요. 조금씩 여기가 익숙해지고 있어요. 물어봐 주셔서 고마워요.' });
    else if (topic === 'thanks') { reply = Brothel_대사고르기(worker, {
      practical: '말뿐 아니라 제 몫과 쉴 시간을 지켜 주시면 더 고맙겠어요. 그래도 알아봐 주신 건 기쁘네요.',
      warm: '그렇게 말씀해 주시면 힘이 나요. 내일도 잘해 보자는 마음이 드네요.',
      reserved: '제가 한 일을 알아봐 주시는군요. 크게 티 내지는 못해도, 그런 말은 기억해요.' }); changes = { affinity: 3, trust: 2 }; }
    else if (topic === 'personal') reply = Brothel_대사고르기(worker, {
      practical: '쉬는 날에는 장을 보거나 옷을 손질해요. 제 생활이 정돈되어 있으면 마음도 편하거든요.',
      warm: '시장을 천천히 돌아보는 걸 좋아해요. 꽃이나 처음 보는 물건을 구경하면 이야깃거리가 생기잖아요.',
      reserved: '조용한 곳에서 차를 마시거나 바느질을 해요. 그때는 다른 사람에게 맞추지 않고 제 생각을 할 수 있어요.' });
    else if (topic === 'feelings') {
      const ready = relation.affinity >= 50 && relation.trust >= 50 && relation.familiarity >= 3;
      reply = ready ? '요즘은 사장님과 이야기하는 시간이 기다려질 때도 있어요. 다만 제 마음은 제가 정하고 싶어요. 천천히 알아 가요.'
        : '지금은 사장님을 조금씩 알아 가는 중이에요. 고용됐다고 개인적인 마음까지 약속한 건 아니니까, 서두르지 않아 주시면 좋겠어요.';
      changes = ready ? { affinity: 2, affection: 2, trust: 1 } : {};
    }
    next = Brothel_대사추가하기(next, [['player', prompts[topic]], ['worker', reply]]);
    return Brothel_마음변경하기(next, changes);
  }
  function Brothel_후속대답하기(state, choice) {
    const session = readData(state).playerSession, relation = Brothel_관계읽기(state, session.workerId);
    if (session.turn === 1) {
      const replies = {
        listen: ['천천히 이야기해. 네 생각을 더 듣고 싶어.', '제 말을 끝까지 들어 주시는군요. 앞으로도 불편한 일이 있으면 숨기지 않고 이야기해 볼게요.', { affinity: 2, trust: 3 }],
        encourage: ['네 생각을 존중해. 네 방식대로 해 봐도 좋아.', '제가 선택할 여지를 주셔서 고마워요. 사장님과 일하는 게 조금 더 편해졌어요.', { affinity: 2, trust: 3 }],
        share: ['나도 가게를 꾸려 가면서 생각이 많아. 서로 솔직했으면 좋겠어.', '사장님도 고민이 있으시군요. 제가 다 해결할 수는 없어도, 서로 말할 수 있는 사이는 좋겠네요.', { affinity: 3, trust: 1 }],
        press: ['그래도 내가 원하는 대로 해 줬으면 좋겠어.', '근무에 필요한 부탁과 제 개인적인 선택은 구분해 주세요. 그렇게 말씀하시면 편하게 이야기하기 어려워요.', { affinity: -3, trust: -5, affection: -1 }] };
      const [player, worker, changes] = replies[choice];
      return Brothel_마음변경하기(Brothel_대사추가하기(state, [['player', player], ['worker', worker]]), changes);
    }
    let player, reply, changes;
    if (choice === 'thanks') { player = '이야기해 줘서 고마워. 다음에도 편하게 말해 줘.'; reply = '네, 사장님. 오늘 나눈 이야기는 기억해 둘게요. 이제 제 일로 돌아가 볼게요.'; changes = { affinity: 1, trust: 1 }; }
    else if (choice === 'respect') { player = '일 밖의 시간과 마음은 네가 정하는 거야. 나는 그걸 존중할게.';
      reply = '그렇게 분명히 말해 주시니 마음이 놓여요. 고용주에게도 제 생각을 말할 수 있다는 게 중요하거든요.'; changes = { affinity: 1, trust: 3 }; }
    else {
      player = '다음에 근무가 아닐 때, 네가 괜찮다면 함께 차를 마시고 싶어.';
      const ready = relation.affinity >= 55 && relation.trust >= 50 && relation.familiarity >= 3;
      reply = ready ? '좋아요. 그때는 일 때문에 부르는 게 아니라 서로 이야기하러 만나는 거예요. 날짜는 제가 쉬는 날로 정해 봐요.'
        : '아직은 일터에서 조금 더 알아 가고 싶어요. 제가 편해지면 그때 다시 이야기해요.';
      changes = ready ? { affinity: 2, affection: 2, trust: 1 } : {};
    }
    return Brothel_마음변경하기(Brothel_대사추가하기(state, [['player', player], ['worker', reply]]), changes);
  }
  function Brothel_서비스대답하기(state, choice) {
    const session = readData(state).playerSession;
    let next = state, entries, changes = {};
    if (session.turn === 0) {
      entries = choice === 'reassure' ? [['player', '불편한 점이 있으면 바로 말해 줘. 서로 괜찮은 범위에서만 하자.'],
        ['worker', '그렇게 말씀해 주시면 편해요. 저도 제 뜻을 분명히 말씀드릴게요.']]
        : [['player', '정해진 요금과 서로의 뜻을 확인했어. 준비되면 말해 줘.'], ['worker', '네, 준비됐어요. 사장님도 제 속도를 살펴 주세요.']];
      if (choice === 'reassure') changes = { trust: 1 };
    } else if (session.turn === 1) {
      entries = choice === 'check' ? [['player', '괜찮아? 잠깐 쉬거나 여기서 멈춰도 돼.'], ['worker', '괜찮아요. 제 말을 들어 주셔서 고마워요. 천천히 이어가요.']]
        : [['player', '서두르지 말고 함께 시간을 보내자.'], ['worker', '네. 지금은 다른 일보다 서로의 반응을 살피면 좋겠어요.']];
      entries.push(['narrator', '두 사람은 다른 일에서 벗어나, 서로 합의한 개인적인 시간을 조용히 함께 보냅니다.']);
      if (!session.serviceRecorded) {
        next = recordService(next, session);
        next = writeData(next, { playerSession: { ...readData(next).playerSession, serviceRecorded: true } });
      }
      if (choice === 'check') changes = { trust: 1 };
    } else {
      entries = choice === 'compliment' ? [['player', '내 말을 살펴 주고 배려해 줘서 고마워.'], ['worker', '그렇게 알아봐 주시니 좋네요. 다음에도 서로 편하게 이야기해요.']]
        : [['player', '함께 시간 보내 줘서 고마워. 이제 편하게 쉬거나 돌아가도 돼.'], ['worker', '네, 사장님. 오늘 이용은 여기까지예요. 저는 제 일로 돌아갈게요.']];
      if (choice === 'compliment') changes = { affinity: 1 };
    }
    return Brothel_마음변경하기(Brothel_대사추가하기(next, entries), changes);
  }
  function Brothel_단계시간보내기(state) {
    let next = state, session = readData(next).playerSession;
    for (let minute = 0; minute < 2 && session?.waitingUntil > next.slot && !next.pendingEvent && !next.gameOver; minute++) {
      const before = next.slot; next = api.fn('worldTick')(next, { playerPresent: true });
      if (next.slot === before) break;
      session = readData(next).playerSession;
    }
    return Brothel_진행갱신하기(next);
  }
  function Brothel_선택처리하기(state, action) {
    const session = readData(state).playerSession;
    if (!session || session.version !== 2 || session.id !== action.sessionId || session.turn !== action.turn || state.pendingEvent) return state;
    if (!readWorker(state, session.workerId) || readData(state).assignments?.[session.workerId]?.owner !== 'brothel-player') return Brothel_진행갱신하기(state);
    if (!Brothel_선택지읽기(state).some(choice => choice.id === action.choiceId)) return state;
    let next = session.stage === 'chatting' ? session.turn === 0 ? Brothel_주제대답하기(state, action.choiceId) : Brothel_후속대답하기(state, action.choiceId)
      : Brothel_서비스대답하기(state, action.choiceId);
    const current = readData(next).playerSession;
    const turn = current.turn + 1;
    const assignments = readData(next).assignments;
    const lastReply = current.lines.filter(line => line.speaker === 'worker').at(-1)?.text || '';
    next = writeData(next, { playerSession: { ...current, turn, finished: turn >= 3, waitingUntil: state.slot + 2 },
      assignments: { ...assignments, [current.workerId]: { ...assignments[current.workerId], situation: `당신과 ${current.stage === 'chatting' ? '대화' : '유료 서비스'} · ${turn}/3단계 · ${lastReply}` } } });
    return Brothel_단계시간보내기(next);
  }
  function Brothel_시간이어가기(state, action) {
    const session = readData(state).playerSession;
    if (!session || session.version !== 2 || session.id !== action.sessionId || session.turn !== action.turn || state.pendingEvent || session.waitingUntil == null) return state;
    return Brothel_단계시간보내기(state);
  }
  function Brothel_이용끝내기(state, { cancelled = false, reason = '', moveBack = true } = {}) {
    const session = readData(state).playerSession; if (!session) return state;
    let next = state;
    if (session.version === 2) {
      next = Brothel_대사추가하기(next, [['narrator', reason || `${session.workerName}과(와) ${session.stage === 'chatting' ? '이야기를 마치고 각자의 일로 돌아갑니다.' : '함께한 시간을 마무리하고 인사를 나눕니다.'}`]]);
      const relation = Brothel_관계읽기(next, session.workerId);
      if (relation && !cancelled) next = Brothel_관계쓰기(next, session.workerId, { ...relation,
        familiarity: session.stage === 'chatting' && session.rewardAllowed ? Brothel_관계값정리하기(relation.familiarity + 1) : relation.familiarity,
        conversations: relation.conversations + (session.stage === 'chatting' ? 1 : 0), services: relation.services + (session.serviceRecorded ? 1 : 0) });
    } else next = log(next, `${session.workerName || readWorker(next, session.workerId)?.name || '직원'}과(와) 이전 이용을 마쳤습니다.`, session.workerId);
    const completed = { ...readData(next).playerSession, cancelled, endedAt: next.slot };
    next = release(next, 'brothel-player');
    if (session.stage !== 'chatting' && session.serviceRecorded) next = beginAftercare(next, session.workerId, session.stage);
    next = writeData(next, { playerSession: null, lastPlayerInteraction: completed,
      playerHistory: [...(readData(next).playerHistory || []), completed].slice(-12) });
    return moveBack && !state.gameOver ? restoreLocation(next, session.originalLocation) : next;
  }
  function Brothel_진행갱신하기(state) {
    const session = readData(state).playerSession; if (!session) return state;
    if (state.gameOver || !['prep', 'service', 'last_call'].includes(state.phase) || !readWorker(state, session.workerId)
      || readData(state).assignments?.[session.workerId]?.owner !== 'brothel-player') {
      return Brothel_이용끝내기(state, { cancelled: true, moveBack: false, reason: '일을 마치거나 주변 상황이 바뀌어 이야기를 여기서 멈춥니다.' });
    }
    if (session.version !== 2) return state.slot >= session.endSlot ? Brothel_이용끝내기(state) : state;
    if (session.waitingUntil == null || state.slot < session.waitingUntil || state.pendingEvent) return state;
    if (session.finished) return Brothel_이용끝내기(state);
    return writeData(state, { playerSession: { ...session, waitingUntil: null } });
  }
  function Brothel_중단처리하기(state, action) {
    const session = readData(state).playerSession;
    if (!session || session.id !== action.sessionId || state.pendingEvent) return state;
    return Brothel_이용끝내기(state, { cancelled: true, reason: `${session.workerName}에게 지금은 여기까지 하자고 말합니다. 그녀는 고개를 끄덕이고 자신의 일로 돌아갑니다.` });
  }
  function Brothel_대화기록그리기(session) {
    return jsx.jsx('div', { 'data-brothel-player-transcript': session.id, ref: node => { if (node) node.scrollTop = node.scrollHeight; },
      style: { background: '#0c0a09', padding: '10px', borderRadius: '6px', display: 'grid', gap: '8px', maxHeight: 'min(32vh, 260px)', overflowY: 'auto' },
      children: (session.lines || []).map((line, index) => jsx.jsxs('p', { style: { margin: 0, whiteSpace: 'pre-wrap', overflowWrap: 'anywhere', color: line.speaker === 'worker' ? '#fce7f3' : line.speaker === 'player' ? '#fef3c7' : '#a8a29e' },
        children: [line.name && jsx.jsx('strong', { children: `${line.name}: ` }), line.text] }, `${session.id}:${index}`)) });
  }
  function Brothel_관계그리기(state, id) {
    const relation = Brothel_관계읽기(state, id); if (!relation) return null;
    return jsx.jsxs('div', { 'data-brothel-player-relationship': id, style: { padding: '8px 0', color: '#d6d3d1', fontSize: '12px' }, children: [
      jsx.jsx('p', { style: { margin: '3px 0' }, children: Brothel_관계표시읽기(state, id) }),
      jsx.jsx('p', { style: { margin: '3px 0', color: '#a8a29e' }, children: Brothel_관계이름읽기(relation) })] });
  }
  function Brothel_독립권유그리기(state, id) {
    const worker = readWorker(state, id);
    if (!worker || !independence) return null;
    const request = independence.request(state, id), reason = independence.blocked(state, id);
    if (!request || reason) return null;
    return jsx.jsxs('div', { 'data-brothel-independence': id, style: { marginTop: '10px', padding: '10px', border: '1px solid #92400e', borderRadius: '5px' }, children: [
      jsx.jsx('strong', { children: '독립 권유' }),
      jsx.jsx('p', { style: { color: '#d6d3d1', fontSize: '12px', margin: '6px 0' },
        children: request ? `${request.customerName}이(가) ${worker.name}과(와) 결혼하고 싶다는 뜻을 전했습니다.` : '직원에게 일을 그만두고 새로운 삶을 시작할지 물어봅니다.' }),
      jsx.jsx('button', { type: 'button', 'data-brothel-independence-open': id, style: buttonStyle, disabled: !!reason,
        onClick: () => api.store.dispatch({ type: 'brothel/independence', workerId: id }), children: `독립 권유 · 필요 자금 ${independence.cost(worker)}골드` }),
    ] });
  }
  function Brothel_행동창그리기(state, { workers, chosen, stage, setId, setStage, unavailable, fee }) {
    const session = readData(state).playerSession;
    if (!session && !chosen) return jsx.jsx('div', { 'data-brothel-player-actions': true, style: { display: 'block' },
      children: workers.map(worker => { const waiting = aftercareRemaining(state, worker.id), reason = unavailable(worker.id, 'chatting');
        return jsx.jsx('div', { 'data-brothel-talk-to': worker.id, children: jsx.jsx(ActionButton, {
          label: worker.name, description: waiting ? `서비스 뒤 정리 중 · 말을 걸면 ${waiting}분 기다립니다.` : reason || '말을 걸거나 유료 서비스를 요청합니다.', disabled: !!reason && !waiting,
          onClick: () => { if (waiting) api.store.dispatch({ type: 'brothel/player-wait-aftercare', workerId: worker.id }); setId(worker.id); } }) }, worker.id);
      }) });
    const children = [jsx.jsx('h4', { style: { color: '#fce7f3', marginBottom: '6px' }, children: '매춘부와 대화 · 유료 서비스' }),
      jsx.jsx('p', { style: { color: '#a8a29e', fontSize: '12px' }, children: "대화는 무료입니다. 유료 서비스는 당신도 요금을 내며 전액 직원에게 지급합니다. 대화와 서비스는 선택할 때마다 2분씩, 세 단계로 진행합니다." })];
    if (session) {
      const workerId = session.workerId;
      children.push(jsx.jsx('p', { style: { color: '#f9a8d4', marginTop: '10px' }, children: `${session.workerName || readWorker(state, workerId)?.name || '직원'} · ${session.stage === 'chatting' ? '대화 중' : '유료 서비스 중'}` }), Brothel_관계그리기(state, workerId));
      if (session.version === 2) {
        const steps = session.stage === 'chatting' ? chatSteps : serviceSteps;
        children.push(jsx.jsx('div', { 'data-brothel-player-progress': session.turn, style: { display: 'flex', flexWrap: 'wrap', gap: '5px', marginBottom: '10px' },
          children: steps.map((label, index) => jsx.jsx('span', { style: { padding: '4px 7px', borderRadius: '4px', background: index < session.turn ? '#164e3b' : index === session.turn ? '#831843' : '#292524', color: '#fafaf9', fontSize: '12px' }, children: `${index + 1}. ${label}` }, label)) }),
          Brothel_대화기록그리기(session));
        if (state.pendingEvent) children.push(jsx.jsx('p', { style: { color: '#fde68a', margin: '10px 0' }, children: '진행 중인 사건을 먼저 해결하면 이 단계에서 이어집니다.' }));
        else if (session.waitingUntil != null) children.push(jsx.jsx('button', { type: 'button', 'data-brothel-player-continue': true, style: buttonStyle,
          onClick: () => api.store.dispatch({ type: 'brothel/player-continue', sessionId: session.id, turn: session.turn }), children: `현재 단계 이어가기 · 남은 ${Math.max(0, session.waitingUntil - state.slot)}분` }));
        else children.push(jsx.jsx('div', { style: { display: 'grid', gap: '6px', marginTop: '10px' }, children: Brothel_선택지읽기(state).map(choice => jsx.jsx('button', {
          type: 'button', 'data-brothel-player-choice': choice.id, style: buttonStyle, onClick: () => api.store.dispatch({ type: 'brothel/player-choice', sessionId: session.id, turn: session.turn, choiceId: choice.id }), children: `${choice.label} · 2분` }, choice.id)) }));
        const delta = session.changes || {}, labels = { affinity: '호감', affection: '애정', trust: '신뢰' };
        const feedback = Object.entries(labels).filter(([key]) => delta[key]).map(([key, label]) => `${label} ${delta[key] > 0 ? '+' : ''}${delta[key]}`).join(' · ');
        if (feedback) children.push(jsx.jsx('p', { 'data-brothel-player-change': true, style: { color: '#bbf7d0', fontSize: '12px', marginTop: '8px' }, children: feedback }));
        children.push(jsx.jsx('button', { type: 'button', 'data-brothel-player-cancel': true, disabled: !!state.pendingEvent, style: { ...buttonStyle, marginTop: '8px' },
          onClick: () => api.store.dispatch({ type: 'brothel/player-cancel', sessionId: session.id }), children: '지금은 여기까지 하기' }));
        if (session.stage !== 'chatting') children.push(jsx.jsx('p', { style: { color: '#a8a29e', fontSize: '12px' }, children: '이미 지불한 서비스 요금은 중간에 끝내도 반환되지 않습니다.' }));
      } else children.push(jsx.jsx('button', { type: 'button', style: buttonStyle, onClick: () => api.store.dispatch({ type: 'wait', minutes: Math.max(1, session.endSlot - state.slot) }), children: '이전 저장의 이용 마무리하기' }));
      if (session.stage === 'chatting') children.push(Brothel_독립권유그리기(state, workerId));
    } else {
      const worker = workers.find(item => item.id === chosen);
      if (worker) {
        const chatReason = unavailable(chosen, 'chatting');
        const request = independence?.request(state, chosen), independenceReason = request ? independence.blocked(state, chosen) : '';
        children.push(jsx.jsx('h4', { style: { color: '#f9a8d4', margin: '8px 0' }, children: worker.name }), Brothel_관계그리기(state, chosen),
          jsx.jsx(ActionButton, { label: '대화하기', description: chatReason || '무료 · 세 단계로 이야기를 나눕니다.', disabled: !!chatReason,
            onClick: () => api.store.dispatch({ type: 'brothel/player-service', workerId: chosen, stage: 'chatting' }), 'data-brothel-worker-choice': 'chat' }));
        for (const serviceStage of serviceOrder.filter(item => paidStages.has(item))) {
          const reason = unavailable(chosen, serviceStage), price = fee(serviceStage);
          children.push(jsx.jsx(ActionButton, { label: serviceLabels[serviceStage] || stageLabels[serviceStage] || serviceStage,
            description: reason || `서비스 요금 ${price}골드 · 서로의 의사와 범위를 확인합니다.`, disabled: !!reason,
            onClick: () => api.store.dispatch({ type: 'brothel/player-service', workerId: chosen, stage: serviceStage }), 'data-brothel-worker-choice': serviceStage }, serviceStage));
        }
        if (request && !independenceReason) children.push(jsx.jsx(ActionButton, { label: '독립 권유하기',
          description: `${request.customerName}의 요청을 전하고 독립자금 이야기를 꺼냅니다.`,
          onClick: () => api.store.dispatch({ type: 'brothel/independence', workerId: chosen }), 'data-brothel-worker-choice': 'independence' }));
        children.push(jsx.jsx('button', { type: 'button', style: { ...buttonStyle, marginTop: '8px' }, onClick: () => setId(''), children: '다른 직원 선택하기' }));
        const previous = readData(state).lastPlayerInteraction;
        if (previous?.workerId === chosen && previous.employeeKey === Brothel_관계읽기(state, chosen)?.employeeKey && previous.lines?.length) children.push(jsx.jsxs('details', { 'data-brothel-player-previous': true, open: true, style: { marginTop: '10px' }, children: [
          jsx.jsx('summary', { style: { cursor: 'pointer', color: '#f9a8d4' }, children: previous.cancelled ? '방금 나눈 이야기 · 중단' : '방금 나눈 이야기 · 마무리' }), Brothel_대화기록그리기(previous)] }));
      }
    }
    return jsx.jsx('div', { 'data-brothel-player-actions': true, style: { background: '#1c1917', color: '#fafaf9', padding: '12px', border: '1px solid #881337', borderRadius: '6px', marginTop: '12px', fontSize: '14px', maxWidth: '100%', boxSizing: 'border-box' }, children });
  }
  return { start: Brothel_대화시작하기, choose: Brothel_선택처리하기, continue: Brothel_시간이어가기, cancel: Brothel_중단처리하기,
    progress: Brothel_진행갱신하기, choices: Brothel_선택지읽기, relationship: Brothel_관계읽기, relationshipText: Brothel_관계표시읽기, render: Brothel_행동창그리기 };
}
globalThis.__waywardBrothelDialogueFactory = Brothel_대화엔진만들기;
