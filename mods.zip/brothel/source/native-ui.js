// 각 모드에 포함되는 설정 UI. 게임 HTML의 메뉴와 DOM만 사용합니다.
(() => {
  if (globalThis.__waywardPauseSettingsUiFactory?.version === 1) return;
  const entries = new Map(), windows = new Map();
  const legacyButtons = '[data-wc2-preg-menu],[data-wc2-customer-menu],.ww-brothel-menu-button,[data-bad-guest-settings-launch],[data-ww-image-studio-menu]';
  let queued = false, theme = null;
  const cssValues = new Map(), cssProbe = document.createElement('div').style;

  function ModNativeUI_요소만들기(tag, props, ...children) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(props || {})) {
      if (value == null || value === false) continue;
      if (key === 'class') node.className = value;
      else if (key === 'style') node.style.cssText = value;
      else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2).toLowerCase(), value);
      else if (key in node && key !== 'list') node[key] = value;
      else node.setAttribute(key, value === true ? '' : String(value));
    }
    for (const child of children.flat()) if (child != null && child !== false) node.append(child.nodeType ? child : String(child));
    return node;
  }
  // WML 0.9.5 owns pause-menu placement through api.ui.pauseSettings.
  function ModNativeUI_메뉴찾기() { return []; }
  function ModNativeUI_스타일지정하기(node, property, value) {
    const key = property + ':' + value;
    if (!cssValues.has(key)) { cssProbe.setProperty(property, value); cssValues.set(key, cssProbe.getPropertyValue(property)); }
    if (node.style.getPropertyValue(property) !== cssValues.get(key) || node.style.getPropertyPriority(property) !== 'important') node.style.setProperty(property, value, 'important');
  }
  function ModNativeUI_테마읽기(button) {
    const native = getComputedStyle(button || document.getElementById('root') || document.body);
    const channels = (native.backgroundColor.match(/[\d.]+/g) || [28, 25, 23]).slice(0, 3).map(Number);
    const luminance = Math.max(.09, Math.min(.22, (Math.max(...channels) + Math.min(...channels)) / 510));
    return { font: native.fontFamily || 'sans-serif', background: `hsl(32 52% ${Math.round(luminance * 100 + 4)}%)`,
      foreground: 'hsl(40 78% 88%)', border: 'hsl(32 55% 34%)', radius: native.borderRadius || '6px' };
  }
  function ModNativeUI_버튼색칠하기(button, settings) {
    const colors = theme = ModNativeUI_테마읽기(settings);
    for (const [key, value] of Object.entries({ background: colors.background, color: colors.foreground,
      'border-color': colors.border, 'border-width': '1px', 'border-style': 'solid', 'border-radius': colors.radius,
      width: '100%', padding: '8px 16px', 'font-family': colors.font, 'font-size': '14px', cursor: 'pointer' })) ModNativeUI_스타일지정하기(button, key, value);
  }
  function ModNativeUI_앞으로올리기(node) {
    ModNativeUI_스타일지정하기(node, 'z-index', '2147483647');
    if (node.parentElement === document.body && node.nextElementSibling) document.body.append(node);
  }
  function ModNativeUI_정리하기() {
    for (const { list, settings } of ModNativeUI_메뉴찾기()) {
      let anchor = settings;
      for (const [owner, entry] of entries) {
        const official = [...list.querySelectorAll('[data-wml-pause-entry]')].find(node => node.dataset.wmlPauseEntry === owner);
        if (official) {
          for (const old of [...list.children]) if (old !== official &&
            (old.dataset.waywardNativeSettings === owner || entry.legacyButton && old.matches(entry.legacyButton))) old.remove();
          anchor = official;
          continue;
        }
        let button = [...list.children].find(node => node.dataset.waywardNativeSettings === owner);
        if (!button && entry.legacyButton) button = list.querySelector(entry.legacyButton);
        if (!button) {
          button = ModNativeUI_요소만들기('button', { type: 'button', class: settings.className,
            'data-wayward-native-settings': owner, ...entry.attributes,
            class: `${settings.className} ${entry.attributes?.class || ''}`.trim() }, entry.label);
          button.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); entry.onClick?.();
            queueMicrotask(() => entry.windowSelector && document.querySelectorAll(entry.windowSelector).forEach(ModNativeUI_앞으로올리기)); });
          list.append(button);
        }
        button.dataset.waywardNativeSettings = owner;
        // 이 표시는 새 로더의 기존 버튼 정렬과도 같은 순서를 유지하게 합니다.
        // 구형 로더에서는 사용하지 않아도 HTML 메뉴가 직접 처리됩니다.
        button.dataset.wmlModSettings = owner;
        ModNativeUI_버튼색칠하기(button, settings);
        if (button.textContent !== entry.label) button.textContent = entry.label;
        if (anchor.nextElementSibling !== button) anchor.after(button);
        anchor = button;
      }
      const panel = list.parentElement;
      if (panel.style.maxHeight !== 'calc(100dvh - 32px)') panel.style.maxHeight = 'calc(100dvh - 32px)';
      if (panel.style.overflowY !== 'auto') panel.style.overflowY = 'auto';
    }
    for (const entry of entries.values()) if (entry.windowSelector) {
      for (const panel of document.querySelectorAll(entry.windowSelector)) {
        ModNativeUI_스타일지정하기(panel, 'z-index', '2147483647');
      }
    }
  }
  function ModNativeUI_정리예약하기() {
    if (queued) return;
    queued = true;
    queueMicrotask(() => { queued = false; ModNativeUI_정리하기(); });
  }
  function ModNativeUI_버튼만들기(label, onClick, options = {}) {
    return ModNativeUI_요소만들기('button', { type: 'button', class: 'wayward-native-button',
      title: options.title, disabled: options.disabled, onclick: onClick,
      style: options.primary ? 'background:#78350f;color:#fef3c7' : '' }, label);
  }
  function ModNativeUI_창열기(owner, options) {
    const id = `${owner}:${options.id || 'settings'}`;
    if (windows.has(id)) { const prior = windows.get(id); prior.focus(); return prior; }
    const colors = theme || ModNativeUI_테마읽기();
    const width = Math.min(options.width || 520, Math.max(280, innerWidth - 16));
    const height = Math.min(options.height || 440, Math.max(160, innerHeight - 16));
    const title = ModNativeUI_요소만들기('strong', {}, options.title || owner);
    const body = ModNativeUI_요소만들기('div', { class: 'wayward-native-window-body' });
    const node = ModNativeUI_요소만들기('section', { class: 'wayward-native-window', role: 'region',
      'aria-label': options.title || owner, 'data-wml-ui': owner, 'data-wayward-native-window': id,
      style: `left:${Math.max(8, (innerWidth - width) / 2)}px;top:${Math.max(8, (innerHeight - height) / 3)}px;width:${width}px;height:${height}px;font-family:${colors.font}` });
    let removeBack = null;
    function ModNativeUI_창닫기() { node.remove(); windows.delete(id); removeBack?.(); options.onClose?.(); }
    const bar = ModNativeUI_요소만들기('header', { class: 'wayward-native-window-title' }, title,
      ModNativeUI_버튼만들기('✕', ModNativeUI_창닫기, { title: '닫기' }));
    node.append(bar, body);
    const handle = { el: node, body, owner, close: ModNativeUI_창닫기,
      focus: () => {
        ModNativeUI_앞으로올리기(node); windows.delete(id); windows.set(id, handle);
        if (typeof options.onBack === 'function') {
          removeBack?.(); removeBack = options.onBack(() => { handle.close(); return true; });
        }
      }, setTitle: value => { title.textContent = value; },
      refresh: () => { body.replaceChildren(); options.render?.(body, handle); } };
    node.addEventListener('pointerdown', handle.focus);
    bar.addEventListener('pointerdown', event => {
      if (event.button !== 0 || event.target.closest('button')) return;
      event.preventDefault();
      const x = event.clientX - node.offsetLeft, y = event.clientY - node.offsetTop;
      const move = next => { node.style.left = Math.max(0, Math.min(innerWidth - 80, next.clientX - x)) + 'px'; node.style.top = Math.max(0, Math.min(innerHeight - 40, next.clientY - y)) + 'px'; };
      const stop = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', stop); };
      window.addEventListener('pointermove', move); window.addEventListener('pointerup', stop, { once: true });
    });
    windows.set(id, handle); document.body.append(node); handle.focus(); handle.refresh();
    return handle;
  }
  const style = ModNativeUI_요소만들기('style', { 'data-wayward-native-ui': '1' });
  style.textContent = `
    .wayward-native-window{position:fixed;display:flex;flex-direction:column;font-size:14px;max-width:calc(100vw - 16px);max-height:calc(100dvh - 16px);min-width:280px;min-height:160px;resize:both;overflow:hidden;background:#1c1917;color:#e7e5e4;border:1px solid #92400e;border-radius:9px;box-shadow:0 14px 44px #000c}
    .wayward-native-window-title{display:flex;align-items:center;gap:8px;padding:8px 10px;background:#292524;border-bottom:1px solid #44403c;cursor:move;touch-action:none}.wayward-native-window-title strong{flex:1;font-size:14px}.wayward-native-window-body{flex:1;overflow:auto;padding:12px}
    .wayward-native-button{border:1px solid #57534e;border-radius:6px;padding:6px 10px;background:#292524;color:#e7e5e4;cursor:pointer;font:inherit}.wayward-native-button:disabled{opacity:.45;cursor:default}
    .wayward-native-window .wml-muted{color:#a8a29e}.wayward-native-window .wml-note{color:#fde68a}.wayward-native-window .wml-small{font-size:12px}
    @media(max-width:640px){.wayward-native-window{left:8px!important;top:8px!important;width:calc(100vw - 16px)!important;height:calc(100dvh - 16px)!important;resize:none}}
  `;
  document.head.append(style);
  const observer = new MutationObserver(ModNativeUI_정리예약하기);
  observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'hidden', 'class'] });
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape' || !windows.size) return;
    [...windows.values()].at(-1).close(); event.preventDefault(); event.stopImmediatePropagation();
  }, true);
  window.addEventListener('pagehide', () => observer.disconnect(), { once: true });
  function ModNativeUI_연결하기(base, config) {
    const owner = config.id, raw = name => config.bindings?.[base.game]?.[name] || name;
    const resolve = name => {
      const candidate = raw(name);
      if (base.engine && candidate in base.engine) return candidate;
      return base.sym(name);
    };
    const registerMenu = options => { entries.set(owner, options); return base.ui.pauseSettings({ ...options, attributes: { ...options.attributes, 'data-wayward-native-settings': owner }, onClick: () => { options.onClick?.(); queueMicrotask(() => options.windowSelector && document.querySelectorAll(options.windowSelector).forEach(ModNativeUI_앞으로올리기)); } }); };
    const ui = { ...base.ui,
      h: ModNativeUI_요소만들기, button: ModNativeUI_버튼만들기,
      window: options => ModNativeUI_창열기(owner, { ...options, onBack: base.onBack }),
      settings: render => {
        base.ui.settings(render);
        registerMenu({ label: config.label, onClick: () => ModNativeUI_창열기(owner,
          { id: 'settings', title: config.label, render, onBack: base.onBack }) }); ModNativeUI_정리예약하기();
      },
      menuSettings: registerMenu,
    };
    const facade = { ...base, ui,
      fn: name => base.engine?.[resolve(name)], sym: resolve,
      has: name => { try { return !!resolve(name); } catch { return false; } },
      hook: (name, options) => base.hook(resolve(name), options),
      onBack: typeof base.onBack === 'function' ? base.onBack : () => () => {},
    };
    if (config.legacy) ui.menuSettings(config.legacy);
    return facade;
  }
  globalThis.__waywardPauseSettingsUiFactory = { version: 1, connect: ModNativeUI_연결하기 };
})();
