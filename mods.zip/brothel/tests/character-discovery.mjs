// 실행: node --import ./wml/mods/brothel/tests/mcp-runtime.mjs wml/mods/brothel/tests/character-discovery.mjs [--zip] [--mobile] [--newwives]
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { parseMod, readModsJs } from '../../../../MCP/lib/mods.mjs';
import { checkMod } from '../../../../MCP/lib/check.mjs';
import { playStart, playEval, playReload, playStatus, playScreenshot, shutdown } from '../../../../MCP/lib/play.mjs';

const mobile = process.argv.includes('--mobile');
const version=fs.readFileSync('wml/mods/brothel/source/mod.wml.js','utf8').match(/\bversion:\s*['"]([^'"]+)['"]/)?.[1];
// 폴더의 (Edit_HL) 접미사와 내부 ID가 달라도 모든 모드를 명시적으로 끄고 시험합니다.
const installed = fs.readdirSync('wml/mods', { withFileTypes: true }).filter(entry => entry.isDirectory()).flatMap(entry => {
  const path = `wml/mods/${entry.name}/mod.js`;
  return fs.existsSync(path) ? [parseMod(fs.readFileSync(path, 'utf8')).meta?.id].filter(Boolean) : [];
});
const characterMods = process.argv.includes('--newwives')
  ? ['newwife-hina', 'newwife-mika', 'newwife-ichika', 'newwife-ryza', 'newwife-mari'].filter(id => installed.includes(id)) : [];
const disabled = Object.fromEntries([...installed, ...readModsJs().entries.map(entry => entry.id)].map(id => [id, false]));
async function BrothelDiscoveryTest_평가하기(code) {
  const result = await playEval({ code });
  assert.ok(!result.error, result.error);
  assert.equal(result.pageErrorsSoFar, 0, JSON.stringify(result));
  return result.result;
}
try {
  const checked = checkMod('brothel');
  assert.equal(checked.ok, true, JSON.stringify(checked.errors));
  const started = await playStart({ mods: { ...disabled, 'addon-compat': true, brothel: true, ...Object.fromEntries(characterMods.map(id => [id, true])) }, ...(mobile ? { viewport: { width: 390, height: 844 } } : {}) });
  assert.deepEqual(started.failed, []);
  if (characterMods.length) {
    await BrothelDiscoveryTest_평가하기(`localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify(['addon-compat', 'brothel', ...characterMods])}));return true;`);
    const loaded = await playReload({});
    assert.deepEqual(loaded.failed, []);
    for (const id of characterMods) assert.ok(loaded.loaded.includes(id), id);
  }
  if (process.argv.includes('--zip')) {
    const installed = await BrothelDiscoveryTest_평가하기(`return WML.install([{path:'brothel-${version}-20261101.zip',blob:await(await fetch('wml/mods/brothel/brothel-${version}-20261101.zip')).blob()}]);`);
    assert.equal(installed[0].version, version);
    assert.deepEqual((await playReload({})).failed, []);
  }
  const discovered = await BrothelDiscoveryTest_평가하기(`
    for(let step=0;step<30;step++){
      if(document.querySelector('button[title="메뉴"]'))break;
      const buttons=[...document.querySelectorAll('button')].filter(button=>button.offsetParent);
      const button=buttons.find(item=>!item.disabled&&/^(예$|이해하고 동의합니다$|새 게임$|계속하기 —|시작 —|시작하기$|건너뛰기$)/.test(item.innerText.trim()))||buttons.find(item=>item.innerText.trim().startsWith('마라'));
      if(!button)throw Error('새 게임 버튼 없음');button.click();await new Promise(resolve=>setTimeout(resolve,80));
    }
    let seed=1138;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
    const api=WML.dev(),b=__waywardBrothelPublic,registry=__WAYWARD_ADDON_API__.wives;
    globalThis.BrothelDiscoveryTest_register=function(id='discovery_test',name='새 캐릭터'){
      const wife=Object.assign(Object.create(registry.find(item=>item.id==='elena_farmgirl')),{id:id+'_archetype',shortname:id,name});
      registry.push(wife);return wife;
    };
    api.store.update(state=>({...state,day:10,slot:9*1440+1020,phase:'service',pendingEvent:undefined,alertQueue:[],brothelAddonCampaignVersion:1}));
    const config=b.getConfig();config.enabled=false;config.workers.forEach((worker,index)=>{worker.enabled=index<2;worker.relationshipId='discovery-employee-'+index});
    b.saveConfig();b.openSettings();
    const before=JSON.stringify(config),wife=BrothelDiscoveryTest_register();
    const template=registry.find(item=>item.id==='elena_farmgirl');
    const invalid=[null,{},Object.assign(Object.create(template),{id:'patron_test',shortname:'patron'}),Object.assign(Object.create(template),{id:'bad_test',shortname:'bad/id'}),Object.assign(Object.create(template),{id:'duplicate_test',shortname:'discovery_test',name:'중복 이름'}),Object.assign(Object.create(template),{id:'underage_test',shortname:'underage_test',age:16}),Object.assign(Object.create(template),{id:'child_test',shortname:'child_test',tagline:'초등부 학생'})];
    registry.push(...invalid);
    const wasLegacy=(globalThis.__WAYWARD_WIFE_ADDONS__||[]).some(item=>item.id===wife.id);
    const button=document.querySelector('[data-brothel-discover-characters]');
    if(button.textContent!=='새로운 캐릭터 찾기')throw Error('캐릭터 탐색 버튼 명칭');
    button.click();
    const result=b.discoverCharacters(),selects=[...document.querySelectorAll('[data-brothel-portrait]')];
    registry.splice(registry.length-invalid.length,invalid.length);
    const after=JSON.stringify(config),status=button.closest('section').querySelector('[role="status"]').textContent;
    const options=selects.map(select=>[...select.options].map(option=>({id:option.value,name:option.textContent})));
    const repeat=b.discoverCharacters();
    return{before,after,wasLegacy,status,options,result,repeat,selected:selects.map(select=>select.value),portraits:config.workers.filter(worker=>worker.enabled).map(worker=>worker.portrait)};
  `);
  assert.equal(discovered.wasLegacy, false);
  assert.equal(discovered.before, discovered.after);
  assert.equal(discovered.options.length, 2);
  for (const options of discovered.options) {
    assert.equal(options.filter(option => option.id === 'discovery_test').length, 1);
    assert.equal(options.find(option => option.id === 'discovery_test').name, '새 캐릭터');
    assert.ok(options.some(option => option.id === 'elena'));
    assert.ok(options.every(option => !['patron', 'bad/id', 'undefined', 'underage_test', 'child_test'].includes(option.id)));
  }
  assert.deepEqual(discovered.selected, discovered.portraits);
  assert.match(discovered.status, /새로 인식 1명/);
  assert.equal(discovered.repeat.added, 0);
  if (characterMods.length) {
    for (const id of characterMods) assert.ok(discovered.result.characters.some(character => character.id === id.slice('newwife-'.length)), id);
    console.log('PASS installed character mods: ' + characterMods.join(', '));
  }
  console.log('PASS late direct registry, inherited fields, deduplication, invalid exclusions, idempotent button and unchanged workers');

  const selection = await BrothelDiscoveryTest_평가하기(`
    const api=WML.dev(),b=__waywardBrothelPublic,worker=b.getConfig().workers[0];
    const select=document.querySelector('[data-brothel-portrait="'+worker.id+'"]');
    select.value='discovery_test';select.dispatchEvent(new Event('change'));
    const state=api.store.game(),key=b.portrait(state,worker.id);
    const guest={id:'discovery-guest',name:'시험 손님',patronType:'regular',status:'drinking',intent:'interested',tacticStyle:'warm_builder',charm:50,boldness:40,attributes:{strength:50,deftness:50,wit:50},walletGold:200,stayTimer:200};
    let next={...state,slot:state.slot+1,customers:[guest],mods:{...state.mods,brothel:{...state.mods?.brothel,patronRelationships:{}}}};
    b.getConfig().enabled=true;b.getConfig().allowTaproomSex=true;
    b.getConfig().workers[1].enabled=false;
    b.getRuntime().set(worker.id,{id:worker.id,task:'interaction',location:'taproom',busyUntil:next.slot,stats:{...worker.stats},interaction:{customerId:guest.id,customerName:guest.name,customerSnapshot:guest,stages:['chatting'],index:0,stage:'chatting',comfort:80}});
    next=b.tick(next);b.getConfig().enabled=false;api.store.update(()=>next);
    const character=b.patronRelationships(next,worker.id).character;
    BrothelDiscoveryTest_register('discovery_auto','자동 탐색 캐릭터');b.refreshSettings();
    const auto=!!document.querySelector('[data-brothel-portrait] option[value="discovery_auto"]');
    b.saveConfig();api.store.get().saveToSlot(0);
    return{key,portrait:worker.portrait,character:character?.archetypeId,auto,saved:JSON.parse(localStorage.getItem('wayward-brothel-v3')).workers[0].portrait};
  `);
  assert.equal(selection.portrait, 'discovery_test');
  assert.match(selection.key, /^discovery_test__/);
  assert.equal(selection.character, 'discovery_test_archetype');
  assert.equal(selection.auto, true);
  assert.equal(selection.saved, 'discovery_test');
  console.log('PASS selected custom image key, native employee character, automatic settings refresh and persistence');

  assert.deepEqual((await playReload({})).failed, []);
  const restored = await BrothelDiscoveryTest_평가하기(`
    const api=WML.dev(),b=__waywardBrothelPublic;api.store.get().loadFromSlot(0);b.openSettings();
    const worker=b.getConfig().workers[0],select=document.querySelector('[data-brothel-portrait="'+worker.id+'"]');
    const missing={portrait:worker.portrait,value:select.value,label:select.selectedOptions[0].textContent,key:b.portrait(api.store.game(),worker.id)};
    const registry=__WAYWARD_ADDON_API__.wives,base=registry.find(item=>item.id==='elena_farmgirl');
    registry.push(Object.assign(Object.create(base),{id:'discovery_test_archetype',shortname:'discovery_test',name:'복구된 캐릭터'}));
    const before=JSON.stringify(b.getConfig());document.querySelector('[data-brothel-discover-characters]').click();
    const after=JSON.stringify(b.getConfig());
    return{missing,before,after,value:select.value,label:select.selectedOptions[0].textContent,key:b.portrait(api.store.game(),worker.id),enabled:worker.enabled};
  `);
  assert.equal(restored.missing.portrait, 'discovery_test');
  assert.equal(restored.missing.value, 'discovery_test');
  assert.match(restored.missing.label, /미인식 캐릭터/);
  assert.equal(restored.missing.key, null);
  assert.equal(restored.before, restored.after);
  assert.equal(restored.enabled, true);
  assert.equal(restored.value, 'discovery_test');
  assert.equal(restored.label, '복구된 캐릭터');
  assert.match(restored.key, /^discovery_test__/);
  console.log('PASS absent mod preserves selected portrait through reload and restores without rehiring or stat changes');
  const status = await playStatus({});
  assert.deepEqual(status.pageErrors, []);
  await BrothelDiscoveryTest_평가하기(`document.querySelector('[data-brothel-discover-characters]').closest('section').scrollIntoView({block:'center'});return true;`);
  fs.writeFileSync(`wml/mods/brothel/tests/shots/${mobile ? 'mobile' : 'desktop'}-character-discovery.jpg`, Buffer.from(await playScreenshot({}), 'base64'));
  console.log(`PASS ${mobile ? 'mobile' : 'desktop'}${process.argv.includes('--zip') ? ' ZIP' : ' source'}, no browser errors`);
} finally { await shutdown(); }
