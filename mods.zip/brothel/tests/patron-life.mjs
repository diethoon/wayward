// 실행: node --import ./wml/mods/brothel/tests/mcp-runtime.mjs wml/mods/brothel/tests/patron-life.mjs [--zip] [--mobile]
// 실제 세이브 대신 MCP의 격리 브라우저에서 관계 분리와 독립·편지를 시험합니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { checkMod } from '../../../../MCP/lib/check.mjs';
import { playStart, playEval, playReload, playStatus, playScreenshot, shutdown } from '../../../../MCP/lib/play.mjs';

const mobile = process.argv.includes('--mobile');
const version=fs.readFileSync('wml/mods/brothel/source/mod.wml.js','utf8').match(/\bversion:\s*['"]([^'"]+)['"]/)?.[1];
const evaluate = async code => (await playEval({ code })).result;
const disabled = Object.fromEntries(fs.readdirSync('wml/mods', { withFileTypes: true }).filter(entry => entry.isDirectory()).map(entry => [entry.name, false]));
try {
  const checked = checkMod('brothel'); assert.equal(checked.ok, true, JSON.stringify(checked.errors));
  await playStart({ mods: { ...disabled, 'addon-compat': true, brothel: true }, ...(mobile ? { viewport: { width: 390, height: 844 } } : {}) });
  if (process.argv.includes('--zip')) {
    const installed = await evaluate(`return WML.install([{path:'brothel-${version}-20261101.zip',blob:await(await fetch('wml/mods/brothel/brothel-${version}-20261101.zip')).blob()}]);`);
    assert.equal(installed[0].version, version);
    assert.deepEqual((await playReload({})).failed, []);
  }
  await evaluate(`
    for(let step=0;step<30;step++){
      if(document.querySelector('button[title="메뉴"]'))break;
      const buttons=[...document.querySelectorAll('button')].filter(button=>button.offsetParent);
      const button=buttons.find(item=>!item.disabled&&/^(예$|이해하고 동의합니다$|새 게임$|계속하기 —|시작 —|시작하기$|건너뛰기$)/.test(item.innerText.trim()))||buttons.find(item=>item.innerText.trim().startsWith('마라'));
      if(!button)throw Error('새 게임 버튼 없음');button.click();await new Promise(resolve=>setTimeout(resolve,80));
    }
    globalThis.patronLifeBase=structuredClone(WML.dev().store.game());
    globalThis.PatronLifeTest_reset=function(){
      const api=WML.dev(),b=__waywardBrothelPublic,state=structuredClone(patronLifeBase);
      state.day=10;state.slot=9*1440+1020;state.phase='service';state.brothelAddonCampaignVersion=1;
      state.pendingEvent=undefined;state.alertQueue=[];state.activeScene={};state.customers=[];state.patronRecords=[{name:'관계 시험 손님',platonic:95,romantic:70,sexual:90,visitCount:20}];
      state.economy.gold=5000;state.economy.debt=0;state.errandSession=undefined;state.activeShoppingSession=undefined;
      state.mods={...state.mods,brothel:{assignments:{},playerSession:null}};
      for(const room of Object.values(state.locations))room.occupants=[];
      state.locations.taproom.occupants=['player',state.primaryCharacterId];
      const c=b.getConfig();c.enabled=false;c.allowTaproomSex=true;
      c.workers.forEach((worker,index)=>{worker.enabled=index<2;worker.relationshipId='patron-life-employee-'+index;worker.hireCost=index===0?300:1000;worker.name=index===0?'독립 시험 직원':'두 번째 직원';worker.stats={energy:100,mood:70,arousal:10};worker.lastFullRestDay=state.day;});
      b.getRuntime().clear();b.saveConfig();api.store.update(()=>state);
      return state;
    };
    globalThis.PatronLifeTest_guest=function(id='patron-life-guest',name='관계 시험 손님'){
      return{id,name,patronType:'regular',status:'drinking',intent:'interested',tacticStyle:'warm_builder',charm:65,boldness:40,
        attributes:{strength:50,deftness:50,wit:50},walletGold:200,stayTimer:200,roundsOrdered:1,maxRounds:5};
    };
    return true;
  `);
  const isolated = await evaluate(`
    const api=WML.dev(),b=__waywardBrothelPublic;PatronLifeTest_reset();
    const c=b.getConfig(),guest=PatronLifeTest_guest();
    c.workers[0].latentTraits.romance_starved=true;c.workers[0].latentTraits.cold_pragmatist=false;
    c.workers[1].latentTraits.romance_starved=false;c.workers[1].latentTraits.cold_pragmatist=true;
    api.store.update(state=>b.tick(state));c.enabled=true;
    const before=structuredClone(api.store.game());
    let state={...before,slot:before.slot+1,customers:[guest]};state.locations.taproom.occupants.push(guest.id);
    for(const worker of c.workers.slice(0,2))b.getRuntime().set(worker.id,{id:worker.id,task:'interaction',location:'taproom',busyUntil:state.slot,stats:{...worker.stats},
      interaction:{customerId:guest.id,customerName:guest.name,customerSnapshot:guest,stages:['flirting'],index:0,stage:'flirting',comfort:80}});
    state=b.tick(state);c.enabled=false;api.store.update(()=>state);
    const first=b.patronRelationship(state,c.workers[0].id,guest.name),second=b.patronRelationship(state,c.workers[1].id,guest.name);
    return{before:before.patronRecords,after:state.patronRecords,charactersBefore:before.characters,charactersAfter:state.characters,first,second};
  `);
  assert.deepEqual(isolated.after, isolated.before);
  assert.deepEqual(isolated.charactersAfter, isolated.charactersBefore);
  assert.ok(isolated.first.platonic > 0 && isolated.first.platonic < 20);
  assert.ok(isolated.first.romantic > isolated.second.romantic);
  assert.equal(isolated.first.visitCount, 1); assert.equal(isolated.second.visitCount, 1);
  console.log('PASS isolated patron records and native character-specific relationship calculation');

  const automatic = await evaluate(`
    const api=WML.dev(),b=__waywardBrothelPublic;PatronLifeTest_reset();const c=b.getConfig(),worker=c.workers[0];
    c.workers[1].enabled=false;api.store.update(state=>b.tick(state));
    Object.assign(worker.attributes,{openness:0,confidence:50,charm:50});
    Object.assign(worker.tendencies,{sociability:100,flirtation:0,daring:0,intimacy:0});
    for(const key of Object.keys(worker.traits))worker.traits[key]=false;
    for(const key of Object.keys(worker.latentTraits))worker.latentTraits[key]=false;
    for(const key of Object.keys(worker.affinities))worker.affinities[key]=0;
    const guest={...PatronLifeTest_guest(),intent:'drink_only',tacticStyle:'none',charm:40,boldness:30};
    let state=structuredClone(api.store.game());state.customers=[guest];state.locations.taproom.occupants.push(guest.id);state.slot++;
    state.patronRecords[0].sexual=100;c.enabled=true;const savedRandom=Math.random;Math.random=()=>0;
    state=b.tick(state);const first=[...b.getRuntime().get(worker.id).interaction.stages],own=b.patronRelationship(state,worker.id,guest.name);
    b.getRuntime().clear();state={...state,slot:state.slot+1,patronRecords:[{...state.patronRecords[0],sexual:-100}]};
    state=b.tick(state);Math.random=savedRandom;c.enabled=false;api.store.update(()=>state);
    return{first,second:b.getRuntime().get(worker.id).interaction.stages,own,wifeSexual:state.patronRecords[0].sexual};
  `);
  assert.deepEqual(automatic.first, automatic.second);
  assert.ok(!automatic.first.includes('sex_patron'));
  assert.ok(automatic.own.platonic > 0); assert.equal(automatic.wifeSexual, -100);
  console.log('PASS automatic stage entry updates employee records and ignores wife patron parameters');

  const proposal = await evaluate(`
    const api=WML.dev(),b=__waywardBrothelPublic;PatronLifeTest_reset();const worker=b.getConfig().workers[0],guest=PatronLifeTest_guest();
    let state=api.store.game();state={...state,slot:state.slot+2,customers:[guest],mods:{...state.mods,brothel:{...state.mods.brothel,
      patronRelationships:{[worker.id]:{employeeKey:worker.relationshipId,records:[{name:guest.name,platonic:100,romantic:0,sexual:0,visitCount:1}],marriageRequest:null}}}}};
    state=b.tick(state);const at100=!!state.pendingEvent;
    state=structuredClone(state);state.slot++;state.mods.brothel.patronRelationships[worker.id].records[0].platonic=100.01;
    state=b.tick(state);api.store.update(()=>state);const event=structuredClone(state.pendingEvent);
    api.store.dispatch({type:'resolve_event',choiceId:'acknowledge'});
    state=structuredClone(api.store.game());const other=PatronLifeTest_guest('second-guest','다른 손님');state.customers.push(other);state.slot++;
    state.mods.brothel.patronRelationships[worker.id].records.push({name:other.name,platonic:200});
    state=b.tick(state);api.store.update(()=>state);
    b.openSettings();const panel=document.querySelector('[data-brothel-patron-relationships="'+worker.id+'"]');
    const shown=panel?.textContent;document.querySelector('#ww-settings .ww-close').click();
    return{at100,event,again:state.pendingEvent,request:b.patronRelationships(state,worker.id).marriageRequest,shown};
  `);
  assert.equal(proposal.at100, false);
  assert.equal(proposal.event.alert.kind, 'brothel:marriage-request');
  assert.match(proposal.event.text, /아내로 맞이하고/);
  assert.equal(proposal.again, undefined);
  assert.equal(proposal.request.customerName, '관계 시험 손님');
  assert.match(proposal.shown, /다른 손님/);
  console.log('PASS strict >100 threshold, first suitor only and separate patron relationship panel');

  const loan = await evaluate(`
    const api=WML.dev(),b=__waywardBrothelPublic;const c=b.getConfig();c.enabled=false;
    b.getRuntime().clear();api.store.update(state=>({...state,pendingEvent:undefined,alertQueue:[]}));
    api.store.dispatch({type:'brothel/player-service',workerId:c.workers[0].id,stage:'chatting'});
    await new Promise(resolve=>setTimeout(resolve,100));
    const button=[...document.querySelectorAll('[data-brothel-independence-open]')].find(node=>node.offsetParent);
    const visible=!!button;button.click();const offer=structuredClone(api.store.game().pendingEvent);
    api.store.dispatch({type:'resolve_event',choiceId:'keep'});const stayed=b.getConfig().workers[0].enabled;
    api.store.dispatch({type:'brothel/independence',workerId:c.workers[0].id});api.store.update(state=>({...state,economy:{...state.economy,gold:299}}));
    api.store.dispatch({type:'resolve_event',choiceId:'lend'});const insufficient=api.store.game().log.at(-1).text;
    api.store.update(state=>({...state,economy:{...state.economy,gold:5000}}));
    api.store.dispatch({type:'brothel/independence',workerId:c.workers[0].id});const before=api.store.game().economy.gold;
    api.store.dispatch({type:'resolve_event',choiceId:'lend'});const after=api.store.game();
    const departure=after.mods.brothel.departures?.[0];if(!departure)throw Error('독립 기록 없음: '+after.log.at(-1)?.text);
    globalThis.patronLifeDeparture=structuredClone(departure);
    api.store.get().saveToSlot(0);api.store.get().loadFromSlot(0);
    return{visible,offer,stayed,insufficient,cost:before-after.economy.gold,enabled:b.getConfig().workers[0].enabled,
      session:after.mods.brothel.playerSession,assignments:after.mods.brothel.assignments,departure,restored:api.store.game().mods.brothel.departures[0]};
  `);
  assert.ok(loan.visible); assert.match(loan.offer.text, /300골드/); assert.equal(loan.stayed, true);
  assert.match(loan.insufficient, /부족/); assert.equal(loan.cost, 300); assert.equal(loan.enabled, false);
  assert.equal(loan.session, null); assert.deepEqual(loan.assignments, {});
  assert.ok(loan.departure.dueDay >= loan.departure.departureDay + 5 && loan.departure.dueDay <= loan.departure.departureDay + 10);
  assert.deepEqual(loan.restored, loan.departure);
  console.log('PASS dialogue independence, refusal, insufficient funds, original hire cost, departure and saved 5–10 day due date');

  assert.deepEqual((await playReload({})).failed, []);
  const letter = await evaluate(`
    const api=WML.dev(),b=__waywardBrothelPublic;api.store.get().loadFromSlot(0);
    let state=api.store.game(),dep=state.mods.brothel.departures[0];
    const remainedGone=!b.getConfig().workers[0].enabled;
    const replacement=b.getConfig().workers[0];replacement.enabled=true;replacement.name='새 직원';replacement.relationshipId='new-employee-after-departure';b.saveConfig();
    const replacementRelation=b.patronRelationship(state,replacement.id,'관계 시험 손님');
    function wakeAt(day){
      const now=api.store.game(),start={...now,day:day-1,slot:(day-1)*1440-30,phase:'bedroom',pendingEvent:undefined,alertQueue:[]};
      const result=api.fn('wakeUp')(start,{lampsOutSlot:start.slot,wakeSlot:(day-1)*1440+8*60});api.store.update(()=>result);return result;
    }
    let early=wakeAt(dep.dueDay-1);const beforeDay=early.mods.brothel.departures[0].status;
    state=wakeAt(dep.dueDay);const goldBefore=state.economy.gold;
    const queued=[state.pendingEvent?.alert,...(state.alertQueue||[])].filter(Boolean).filter(alert=>alert.kind==='brothel:independence-letter');
    for(let attempt=0;attempt<30;attempt++){
      const live=api.store.game();if(live.pendingEvent?.alert?.kind==='brothel:independence-letter')break;
      if(live.pendingEvent)api.store.dispatch({type:'resolve_event',choiceId:live.pendingEvent.choices[0].id});
      else api.store.update(current=>api.fn('drainAlerts')(current));
    }
    const event=api.store.game().pendingEvent;if(event?.alert?.kind!=='brothel:independence-letter')throw Error('편지 알림 없음');const letterGoldBefore=api.store.game().economy.gold;
    api.store.dispatch({type:'resolve_event',choiceId:event.choices[0].id});const paid=api.store.game();
    api.store.dispatch({type:'resolve_event',choiceId:event.choices[0].id});const replayGold=api.store.game().economy.gold;
    api.store.get().saveToSlot(1);api.store.get().loadFromSlot(1);
    return{remainedGone,replacementRelation,beforeDay,queued:queued.length,event,delta:paid.economy.gold-letterGoldBefore,dayDelta:paid.economy.gold-goldBefore,replayGold,paidGold:paid.economy.gold,
      status:paid.mods.brothel.departures[0].status,restoredStatus:api.store.game().mods.brothel.departures[0].status,
      replacementName:b.getConfig().workers[0].name};
  `);
  assert.equal(letter.remainedGone, true); assert.equal(letter.replacementRelation, null);
  assert.equal(letter.beforeDay, 'waiting'); assert.equal(letter.queued, 1);
  assert.match(letter.event.text, /독립 시험 직원/); assert.match(letter.event.text, /감사/);
  assert.equal(letter.delta, 600); assert.equal(letter.replayGold, letter.paidGold);
  assert.equal(letter.status, 'paid'); assert.equal(letter.restoredStatus, 'paid'); assert.equal(letter.replacementName, '새 직원');
  console.log('PASS morning letter after reload, correct departed employee, double repayment and duplicate collection prevention');
  const status = await playStatus({}); assert.deepEqual(status.pageErrors, []);
  fs.writeFileSync(`wml/mods/brothel/tests/shots/${mobile ? 'mobile' : 'desktop'}-patron-life.jpg`, Buffer.from(await playScreenshot({}), 'base64'));
  console.log(`PASS ${mobile ? 'mobile' : 'desktop'}${process.argv.includes('--zip') ? ' ZIP' : ' source'}, no browser errors`);
} finally { await shutdown(); }
