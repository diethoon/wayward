// 실행: node --import ./wml/mods/brothel/tests/mcp-runtime.mjs wml/mods/brothel/tests/character-labels.mjs [--mobile]
// 격리 브라우저와 모의 설정 API로 세 모드의 탐색 명칭을 확인합니다. 실제 서버로 요청하지 않습니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { parseMod, readModsJs } from '../../../../MCP/lib/mods.mjs';
import { playStart, playEval, shutdown } from '../../../../MCP/lib/play.mjs';

const mobile = process.argv.includes('--mobile');
const installed = fs.readdirSync('wml/mods', { withFileTypes: true }).filter(entry => entry.isDirectory()).flatMap(entry => {
  const path = `wml/mods/${entry.name}/mod.js`;
  return fs.existsSync(path) ? [parseMod(fs.readFileSync(path, 'utf8')).meta?.id].filter(Boolean) : [];
});
const disabled = Object.fromEntries([...installed, ...readModsJs().entries.map(entry => entry.id)].map(id => [id, false]));

try {
  const start = await playStart({ mods: { ...disabled, 'addon-compat': true, brothel: true, imagestudio: true, 'h-status': true },
    ...(mobile ? { viewport: { width: 390, height: 844 } } : {}) });
  assert.deepEqual(start.failed, []);
  const result = await playEval({ code: `
    const expect=(value,message)=>{if(!value)throw Error(message);};
    const title='새로운 캐릭터 찾기';
    WW_ImageStudio.open();
    const studio=document.querySelector('#wwis-discover-wives');
    expect(studio?.textContent===title,'ImageStudio 인물 선택 명칭');
    const registry=__WAYWARD_ADDON_API__.wives;
    const base=registry.find(item=>item.shortname==='elena');
    registry.push(Object.assign(Object.create(base),{id:'labels_test_archetype',shortname:'labels_test',name:'발견 시험 캐릭터'}));
    expect(WW_ImageStudioBridge.characters().characters.some(item=>item.id==='labels_test'),'실제 등록부 추가 캐릭터 탐색');
    const originalFetch=fetch,requests=[];
    WW_ImageStudioBridge.connection=()=>({baseUrl:location.origin,comfyui:true});
    globalThis.fetch=async(input,options={})=>{
      const url=String(input);requests.push({url,method:options.method||'GET'});
      if(url.endsWith('/api/generation/settings'))return Response.json({imageProvider:'nai',characters:[],loras:[],naiTokenConfigured:false});
      if(url.includes('/api/generation/characters/discover-batch')){
        const characters=JSON.parse(options.body).characters;
        return Response.json({results:characters.map(character=>({added:true,character}))});
      }
      if(url.includes('/api/'))return Response.json({entries:{},counts:{},queue:[]});
      return originalFetch(input,options);
    };
    await WW_ImageStudioBridge.discoverWives();
    expect(requests.some(item=>item.url.endsWith('/api/generation/characters/discover-batch')),'기존 discoverWives API 유지');
    document.querySelector('#wwis-generation-settings').click();
    for(let i=0;i<100&&!document.querySelector('#wwis-save-generation');i++)await new Promise(resolve=>setTimeout(resolve,10));
    expect(document.querySelector('#wwis-save-generation'),'모의 설정 화면 열기');
    expect(document.querySelector('#wwis-discover-wives')?.textContent===title,'ImageStudio 생성 방식 설정 명칭');
    __waywardSituationEventMod.openSettings();
    expect([...document.querySelectorAll('button')].some(button=>button.textContent===title&&button.closest('[data-wayward-native-window],.wml-win')),'H_Status 탐색 명칭');
    __waywardBrothelPublic.openSettings();
    expect(document.querySelector('[data-brothel-discover-characters]')?.textContent===title,'Brothel 탐색 명칭');
    expect(!requests.some(item=>/generate|enqueue/.test(item.url)),'생성 요청 없음');
    return {failed:WML.status().failed,requests:requests.length};
  ` });
  assert.ok(!result.error, result.error);
  assert.equal(result.pageErrorsSoFar, 0, JSON.stringify(result));
  assert.deepEqual(result.result.failed, []);
  console.log(`PASS Brothel / ImageStudio two screens / H_Status labels, late registry and legacy discovery API (${mobile ? 'mobile' : 'desktop'})`);
} finally { await shutdown(); }
