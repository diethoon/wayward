// 실행: node --import ./wml/mods/brothel/tests/mcp-runtime.mjs wml/mods/brothel/tests/pause-layer.mjs [--mobile] [--all-mods] [--no-editor] [--zip] [--old-patch]
// MCP의 격리 저장소에서 실제 창의 가림·클릭·재열기·기본 하위창을 검사합니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { parseMod, readModsJs } from '../../../../MCP/lib/mods.mjs';
import { playStart, playEval, playReload, playStatus, playScreenshot, shutdown } from '../../../../MCP/lib/play.mjs';

const mobile=process.argv.includes('--mobile'),all=process.argv.includes('--all-mods');
const editor=!process.argv.includes('--no-editor'),oldPatch=process.argv.includes('--old-patch');
const meta=parseMod(fs.readFileSync('wml/mods/brothel/mod.js','utf8')).meta;
const installed=fs.readdirSync('wml/mods',{withFileTypes:true}).filter(e=>e.isDirectory()).flatMap(e=>{
  const file=`wml/mods/${e.name}/mod.js`;
  return fs.existsSync(file)?[parseMod(fs.readFileSync(file,'utf8')).meta?.id].filter(Boolean):[];
});
const disabled=Object.fromEntries([...installed,...readModsJs().entries.map(e=>e.id)].map(id=>[id,false]));
async function evaluate(code){
  const result=await playEval({code});
  assert.equal(result.pageErrorsSoFar,0,JSON.stringify(result));
  return result.result;
}
try{
  const started=await playStart({mods:{...(all?{}:disabled),'addon-compat':true,brothel:true,servant:true,editor,
    'servant-compatible-brothel':oldPatch},viewport:mobile?{width:390,height:844}:{width:1500,height:950}});
  assert.deepEqual(started.failed,[]);
  if(oldPatch){
    await evaluate(`localStorage.setItem('wml.folders',JSON.stringify([...new Set([...JSON.parse(localStorage.getItem('wml.folders')||'[]'),'servant-compatible-brothel'])]));return true;`);
    assert.deepEqual((await playReload({})).failed,[]);
  }
  if(process.argv.includes('--zip')){
    const result=await evaluate(`return WML.install([{path:'brothel-${meta.version}-20261101.zip',blob:await(await fetch('wml/mods/brothel/brothel-${meta.version}-20261101.zip')).blob()}]);`);
    assert.equal(result[0].version,meta.version);
    assert.deepEqual((await playReload({})).failed,[]);
  }
  await evaluate(`
    const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
    for(let step=0;step<30;step++){
      if(document.querySelector('button[title="메뉴"]'))break;
      const buttons=[...document.querySelectorAll('#root button')].filter(b=>b.offsetParent&&!b.disabled);
      const button=buttons.find(b=>/^(예|이해하고 동의합니다|건너뛰기)$/.test(b.innerText.trim()));
      if(button)button.click();else WML.dev().store.get().newGame();await sleep(100);
    }
    const check=(value,label)=>{if(!value)throw Error(label)};
    const pause=()=>[...document.querySelectorAll('#root h2')].find(e=>e.textContent.trim()==='일시 정지')?.closest('.fixed.inset-0');
    const front=node=>{const r=node.getBoundingClientRect();return r.width>0&&r.height>0&&node.contains(document.elementFromPoint(r.left+r.width/2,r.top+r.height/2))};
    const hit=node=>{check(node,'요소 없음');node.scrollIntoView({block:'nearest'});const r=node.getBoundingClientRect(),cover=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);check(front(node),'다른 창이 클릭을 가림: '+node.textContent.trim().slice(0,40)+' / '+cover?.outerHTML.slice(0,300));node.click()};
    const open=async()=>{if(!pause()){const menu=[...document.querySelectorAll('button[title="메뉴"]')].find(b=>b.getBoundingClientRect().width>0);if(menu)hit(menu);else document.body.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true,cancelable:true}));await sleep(120)}check(pause(),'일시정지 메뉴 없음')};
    globalThis.BrothelLayerTest={sleep,check,pause,front,hit,open};
    await open();return true;
  `);
  const result=await evaluate(`
    const {sleep,check,pause,front,hit,open}=BrothelLayerTest,api=WML.dev(),passed=[];
    const snapshot=()=>{const s=api.store.game();return JSON.stringify({day:s.day,slot:s.slot,phase:s.phase,economy:s.economy})};
    const before=snapshot();
    const main=[...document.querySelectorAll('.ww-core-pane,.ww-core-window')].filter(e=>!e.hidden);
    const pauseZ=Number(getComputedStyle(pause()).zIndex);
    check(main.every(e=>(Number(getComputedStyle(e).zIndex)||0)<pauseZ),'메인 패널이 메뉴보다 앞에 있음');
    const mainButtons=[...document.querySelectorAll('#root button')].filter(b=>!pause().contains(b)&&b.getBoundingClientRect().width>0).slice(0,5);
    check(mainButtons.length>0,'메인 화면 검사 대상 없음');
    for(const button of mainButtons){const r=button.getBoundingClientRect();if(r.left+r.width/2<innerWidth&&r.top+r.height/2<innerHeight)check(pause().contains(document.elementFromPoint(r.left+r.width/2,r.top+r.height/2)),'메인 화면 클릭이 메뉴를 통과함')}
    passed.push('pause covers main screen controls');
    const dock=document.querySelector('.wml-dock');
    if(dock){check(Number(getComputedStyle(dock).zIndex)<pauseZ,'WML 버튼줄이 메뉴보다 앞에 있음');passed.push('WML dock behind pause')}

    const win=api.ui.window({id:'brothel-layer-test',title:'표시 순서 검사',width:420,height:240,render(body){body.append(api.ui.h('input',{'aria-label':'레이어 입력'}))}});
    const input=win.body.querySelector('input');await sleep(100);
    check(front(input),'일반 WML 창 가림');input.focus();input.value='layer-test';
    input.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));await sleep(1200);
    check(front(input)&&input.value==='layer-test'&&pause(),'포커스 또는 주기 갱신 후 가림');
    check(WML.back(),'일반 창 뒤로가기');check(!win.el.isConnected&&pause(),'일반 창 닫기 후 메뉴 소실');
    passed.push('ordinary WML input/focus, periodic update and Back');

    for(let repeat=0;repeat<2;repeat++){
      hit(pause().querySelector('[data-wml-pause-entry="servant"]'));await sleep(100);
      const servant=document.querySelector('.wml-win[data-servant-window]');
      check(servant,'고용인 창 없음');check(front(servant.querySelector('.wml-win-close')),'고용인 창 가림');
      if(repeat===0)hit(servant.querySelector('.wml-win-close'));else check(WML.back(),'고용인 뒤로가기');
      check(!servant.isConnected&&pause(),'고용인 닫기/재열기 후 메뉴 소실');
    }
    passed.push('Servant menu open, close, reopen and Back');

    hit(pause().querySelector('[data-wml-pause-entry="brothel"]'));await sleep(100);
    const brothel=document.querySelector('#ww-settings');check(!brothel.hidden&&front(brothel.querySelector('.ww-close')),'창관 설정 가림');
    hit(brothel.querySelector('.ww-close'));check(brothel.hidden&&pause(),'창관 설정 닫기');
    passed.push('Brothel settings');

    if(${editor}){
      hit(pause().querySelector('[data-wml-pause-entry="editor"]'));await sleep(100);
      const panel=document.querySelector('#wc2-customer-editor');check(panel&&front(panel.querySelector('.wce-close')),'에디터 가림');
      hit(panel.querySelector('.wce-close'));await sleep(100);check(pause(),'에디터 닫기 후 메뉴 소실');
      passed.push('unchanged Editor settings');
    }
    if(WML.use('brothel-house')){
      WML.use('brothel-house').open();await sleep(100);
      const body=document.querySelector('[data-brothel-house]'),house=body?.closest('.wml-win');
      check(house&&front(house.querySelector('.wml-win-close')),'독립 창관 가림');
      hit(house.querySelector('.wml-win-close'));check(!house.isConnected&&pause(),'독립 창관 닫기');
      passed.push('unchanged Brothel House');
    }
    for(const label of ['설정','게임 저장','불러오기','업데이트 내역']){
      hit([...pause().querySelectorAll('button')].find(b=>b.textContent.trim()===label));await sleep(150);
      const modal=pause()?.querySelector('.fixed.inset-0');
      check(modal&&front(modal),'기본 하위창 가림: '+label);
      const close=[...modal.querySelectorAll('button')].find(b=>b.textContent.trim()==='닫기'||b.textContent.trim()==='✕'||b.title==='닫기'||b.getAttribute('aria-label')==='닫기');
      if(close){hit(close);await sleep(150)}
      else{document.activeElement.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true,cancelable:true}));await sleep(150)}
      check(!modal.isConnected,'기본 하위창 닫기 실패: '+label);await open();
      passed.push('native '+label+' above menu and closes');
    }
    check(snapshot()===before,'창 표시 중 게임 시간/경제 변경');
    passed.push('game time and economy unchanged');
    hit([...pause().querySelectorAll('button')].find(b=>b.textContent.trim()==='재개하기'));await sleep(150);
    check(!pause(),'재개하기 실패');await open();
    document.activeElement.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true,cancelable:true}));await sleep(150);
    check(!pause(),'일시정지 메뉴 Esc 닫기 실패');await open();
    passed.push('resume, reopen and Escape');
    return{passed,pauseZ,main:main.length,loaded:WML.status().loaded.length,oldPatch:WML.status().loaded.includes('servant-compatible-brothel')};
  `);
  const status=await playStatus({});assert.deepEqual(status.failed,[]);assert.deepEqual(status.pageErrors,[]);
  assert.equal(result.oldPatch,oldPatch);
  const profile=`${mobile?'mobile':'desktop'}-${all?'all':'minimal'}-${editor?'editor':'no-editor'}${oldPatch?'-old-patch':''}`;
  fs.writeFileSync(`wml/mods/brothel/tests/shots/${profile}-pause-layer.jpg`,Buffer.from(await playScreenshot({}),'base64'));
  console.log(JSON.stringify({profile,version:meta.version,zip:process.argv.includes('--zip'),...result}));
}catch(error){
  try{console.error(JSON.stringify(await evaluate(`return {headings:[...document.querySelectorAll('h1,h2,h3')].map(e=>e.textContent.trim()).slice(0,15),buttons:[...document.querySelectorAll('button')].filter(b=>b.getBoundingClientRect().width>0).slice(0,12).map(b=>({text:b.textContent.trim(),title:b.title,aria:b.getAttribute('aria-label')})),modals:[...document.querySelectorAll('#root .fixed.inset-0')].map(e=>({classes:e.className,text:e.innerText.slice(0,250)}))};`)))}catch{}
  throw error;
}finally{await shutdown()}
