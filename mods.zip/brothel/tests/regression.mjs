// 실행: node wml/mods/brothel/tests/regression.mjs [--mobile] [--wife-view] [--brothel-only] [--zip]
// seed 1138. MCP의 격리 브라우저만 사용하며 공통 모드 목록과 사용자 저장은 수정하지 않습니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {playStart,playEval,playReload,playStatus,playStop,playScreenshot,shutdown} from '../../../../MCP/lib/play.mjs';
import {checkMod} from '../../../../MCP/lib/check.mjs';
import {readModsJs} from '../../../../MCP/lib/mods.mjs';
const mobile=process.argv.includes('--mobile'),wifeView=process.argv.includes('--wife-view'),brothelOnly=process.argv.includes('--brothel-only');
const brothelVersion=fs.readFileSync('wml/mods/brothel/source/mod.wml.js','utf8').match(/\bversion:\s*['"]([^'"]+)['"]/)?.[1];
const ids=['brothel','festival','delivery-compatible-brothel','brothel-compatible-festival'];
async function BrothelTest_평가하기(code){return(await playEval({code})).result}
try{
  for(const id of ids)assert.ok(checkMod(id).ok,id);
  await playStart({mods:{...Object.fromEntries(readModsJs().entries.map(entry=>[entry.id,false])),
    'addon-compat':true,brothel:true,festival:!brothelOnly,delivery:!brothelOnly,'wife-view-mode':wifeView,
    'delivery-compatible-wife-view-mode':wifeView&&!brothelOnly,'delivery-compatible-brothel':!brothelOnly,'brothel-compatible-festival':!brothelOnly},
    ...(mobile?{viewport:{width:390,height:844}}:{})});
  await BrothelTest_평가하기(`localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify([...ids,'addon-compat','delivery','wife-view-mode','delivery-compatible-wife-view-mode'])}));return true;`);
  if(process.argv.includes('--zip')){
    const installIds=['brothel']; // Only the current release is installed; unchanged dependencies use their folders.
    const installed=await BrothelTest_평가하기(`return WML.install(await Promise.all(${JSON.stringify(installIds)}.map(async id=>{const path=id==='brothel'?'brothel-${brothelVersion}-20261101.zip':id+'.zip';return{path,blob:await(await fetch('wml/mods/'+id+'/'+path)).blob()}})));`);
    assert.deepEqual(installed.map(mod=>mod.id).sort(),[...installIds].sort());console.log('PASS install ZIP files without mods.js changes');
  }
  const started=await playReload({});assert.deepEqual(started.failed,[]);for(const id of brothelOnly?['brothel']:ids)assert.ok(started.loaded.includes(id),id);
  console.log('START '+(mobile?'mobile':'desktop')+' wife-view='+wifeView);
  await BrothelTest_평가하기(`
    for(let step=0;step<30;step++){
      if(document.querySelector('button[title="메뉴"]'))break;
      const buttons=[...document.querySelectorAll('button')].filter(button=>button.offsetParent);
      const button=buttons.find(item=>!item.disabled&&/^(예$|이해하고 동의합니다$|새 게임$|계속하기 —|시작 —|시작하기$|건너뛰기$)/.test(item.innerText.trim()))||buttons.find(item=>item.innerText.trim().startsWith('마라'));
      if(!button)throw Error('새 게임 버튼 없음');button.click();await new Promise(resolve=>setTimeout(resolve,150));
    }
    globalThis.brothelTestSeed=1138;Math.random=function BrothelTest_난수만들기(){brothelTestSeed=(Math.imul(brothelTestSeed,1664525)+1013904223)>>>0;return brothelTestSeed/4294967296;};
    globalThis.brothelTestBase=structuredClone(WML.dev().store.game());
    const api=WML.dev();globalThis.brothelTestArrival=false;api.hook('normalVisitRoll',{replace:()=>brothelTestArrival});
    globalThis.BrothelTest_초기화하기=function(day=10,hour=17){
      const state=structuredClone(brothelTestBase);state.day=day;state.slot=(day-1)*1440+hour*60;state.phase='service';
      state.pendingEvent=undefined;state.alertQueue=[];state.activeScene={};state.customers=[];state.awayEvents=[];state.errandSession=undefined;state.deliveryAddon={};state.activeShoppingSession=undefined;
      state.economy.gold=5000;state.economy.debt=0;state.pendingCollectorVisit=false;state.readyFood=100;state.supplies={...state.supplies,food:100,beer:100,wine:100};state.tavern.backRoomReady=true;
      state.mods={...state.mods,brothel:{assignments:{},playerSession:null},'wife-view-mode':{...state.mods?.['wife-view-mode'],active:${wifeView}},festival:{version:1,current:{id:'festival:10',festivalDay:10,participation:'accepted',invitationQueued:true,
        requests:[8,9].map(day=>({day,dueSlot:(day-1)*1440+1020,queued:false,completed:true,who:null})),stallRevenue:0,stallVisitors:0},labor:null,stall:null,history:[],totalStallRevenue:0,totalStallVisitors:0},'brothel-compatible-festival':{workerIds:['brothel_worker_1'],stock:{},active:null}};
      for(const location of Object.values(state.locations))location.occupants=[];state.locations.taproom.occupants=['player',state.primaryCharacterId];
      Object.assign(state.characters[state.primaryCharacterId],{currentTask:'idle',busyUntilSlot:0,taskTarget:undefined,locationUntilSlot:undefined});state.characters[state.primaryCharacterId].stats.energy=100;
      api.store.update(()=>state);const b=__waywardBrothelPublic,c=b.getConfig();c.enabled=false;c.allowTaproomSex=true;c.serviceRenownGainMultiplier=.3;c.incomeStats={};
      c.workers.forEach((worker,index)=>{worker.enabled=index<2;worker.lastFullRestDay=day;worker.stats.energy=100;
        Object.assign(worker.attributes,{openness:100,confidence:100});Object.assign(worker.tendencies,{intimacy:100,libido:100,daring:100});Object.assign(worker.affinities,{vaginal:2,prostitution:2});worker.traits.cautious=false;worker.latentTraits.true_prude=false;worker.latentTraits.self_protective=false;
        const runtime=b.getRuntime().get(worker.id);if(runtime)Object.assign(runtime,{task:'idle',externalOwner:null,location:'taproom',interaction:null,busyUntil:state.slot,stats:{...worker.stats}})});b.saveConfig();
      globalThis.__waywardDeliveryAddon?.setSettings({eventWeight:0,hotelSexWeight:2});brothelTestArrival=false;return api.store.game();
    };
    globalThis.BrothelTest_분진행하기=function(minutes){const api=WML.dev(),target=api.store.game().slot+minutes;for(let i=0;i<minutes*3&&api.store.game().slot<target;i++){if(api.store.game().pendingEvent)api.store.update(state=>({...state,pendingEvent:undefined,alertQueue:[]}));api.store.update(state=>api.fn('worldTick')(state,{playerPresent:true}));if(api.store.game().pendingEvent)api.store.update(state=>({...state,pendingEvent:undefined,alertQueue:[]}));}return api.store.game();};
    globalThis.BrothelTest_남편대화진행하기=function(){
      const api=WML.dev();
      for(let turn=0;turn<10&&api.store.game().mods.brothel.playerSession;turn++){
        if(api.store.game().pendingEvent)api.store.update(state=>({...state,pendingEvent:undefined,alertQueue:[]}));
        const session=api.store.game().mods.brothel.playerSession;
        if(session.waitingUntil!=null){api.store.dispatch({type:'brothel/player-continue',sessionId:session.id,turn:session.turn});continue}
        const choice=__waywardBrothelPublic.playerChoices(api.store.game())[0];if(!choice)throw Error('직원 대화 선택지 없음');
        api.store.dispatch({type:'brothel/player-choice',sessionId:session.id,turn:session.turn,choiceId:choice.id});
      }
      return api.store.game();
    };
    return BrothelTest_초기화하기().slot;
  `);
  const tieredHire=await BrothelTest_평가하기(`
    const api=WML.dev(),b=__waywardBrothelPublic;BrothelTest_초기화하기();const beforeState=structuredClone(api.store.game()),config=b.getConfig(),beforeConfig=structuredClone(config);
    config.workers.forEach(worker=>worker.enabled=false);b.getRuntime().clear();b.saveConfig();b.openSettings();b.refreshSettings();document.querySelector('[data-brothel-hire-open]').click();let root=document.querySelector('#ww-hire-window');root.querySelector('[data-brothel-hire-mode=specified]').click();
    const tier=root.querySelector('[aria-label="창관 고용 등급"]'),personality=root.querySelector('[aria-label="창관 성격"]'),base=root.querySelector('[aria-label="창관 기반 외형"]'),buttons=[...root.querySelectorAll('[data-brothel-hire-mode]')],attributes=[...root.querySelectorAll('[aria-label^="창관 지정 능력치 "]')],traits=[...root.querySelectorAll('[aria-label^="창관 지정 특성 "],[aria-label^="창관 지정 숨은 특성 "]')],name=root.querySelector('[aria-label="창관 직원 이름"]'),charm=attributes.find(input=>input.getAttribute('aria-label').endsWith('매력')),trait=root.querySelector('[aria-label^="창관 지정 특성 "]');
    const ui=tier.options.length===3&&personality.options.length===15&&base.options.length>0&&buttons.map(x=>x.textContent.trim()).join(',')==='아무나 고용,지정 고용'&&attributes.length===9&&traits.length===26;
    name.value='지정 직원';name.dispatchEvent(new Event('input'));charm.value='7';charm.dispatchEvent(new Event('input'));trait.checked=!trait.checked;trait.dispatchEvent(new Event('change'));const gold0=api.store.game().economy.gold;root.querySelector('[data-brothel-hire-confirm]').click();await new Promise(resolve=>setTimeout(resolve,30));let active=b.getConfig().workers.filter(worker=>worker.enabled),specified=active[0],specifiedOk=api.store.game().economy.gold===gold0-300&&specified.attributes.charm===7&&specified.hireAllocation.mode==='specified'&&specified.hireAllocation.traitChanges===1&&specified.wageLedger.unpaid===0;
    document.querySelector('[data-brothel-hire-open]').click();root=document.querySelector('#ww-hire-window');const nextTier=root.querySelector('[aria-label="창관 고용 등급"]');nextTier.value='skilled';nextTier.dispatchEvent(new Event('change'));await new Promise(resolve=>setTimeout(resolve,20));root=document.querySelector('#ww-hire-window');const nextName=root.querySelector('[aria-label="창관 직원 이름"]');nextName.value='무작위 직원';nextName.dispatchEvent(new Event('input'));const gold1=api.store.game().economy.gold;[...root.querySelectorAll('.ww-hire-button')].find(x=>x.textContent.trim()==='아무나 고용').click();root.querySelector('[data-brothel-hire-confirm]').click();await new Promise(resolve=>setTimeout(resolve,30));active=b.getConfig().workers.filter(worker=>worker.enabled);const random=active[1],sum=Object.values(random.attributes).reduce((total,value)=>total+Number(value||0),0),randomOk=api.store.game().economy.gold===gold1-600&&random.hireAllocation.mode==='random'&&sum===random.hireAllocation.budget;
    Object.assign(config,beforeConfig);b.getRuntime().clear();b.saveConfig();api.store.update(()=>beforeState);document.querySelector('#ww-settings .ww-close')?.click();return{ui,specifiedOk,randomOk,wages:b.hireTiers().map(x=>x.minWage).join(',')==='10,15,20',chances:b.hireTiers().map(x=>x.sexRequestChance).join(',')==='0.35,0.6,0.85'};
  `);
  assert.ok(Object.values(tieredHire).every(Boolean));
  console.log('PASS tiered random/specified hiring, low charm, fixed daily wage floor and request rates');
  const wageAndRequest=await BrothelTest_평가하기(`
    const api=WML.dev(),b=__waywardBrothelPublic;BrothelTest_초기화하기();const beforeState=structuredClone(api.store.game()),config=b.getConfig(),beforeConfig=structuredClone(config),worker=config.workers[0];config.workers.forEach(item=>item.enabled=item===worker);worker.hireTier='ordinary';worker.wageLedger={day:beforeState.day,worked:true,serviceWages:4,unpaid:0,lastSettledDay:beforeState.day-1,blockedNotified:false};let settled=b.settleWages({...beforeState,day:beforeState.day+1,phase:'prep',economy:{...beforeState.economy,gold:3}},config),blocked=settled.mods.brothel.payroll[worker.id].unpaid===7&&b.unavailable(settled,worker.id).includes('미지급');settled=b.settleWages({...settled,economy:{...settled.economy,gold:10}},config);const payroll=settled.mods.brothel.payroll[worker.id],unavailable=b.unavailable(settled,worker.id),paid=payroll.unpaid===0&&settled.economy.gold===3&&config.incomeStats.wageTopups===10&&!unavailable.includes('미지급');Object.assign(worker,{attributes:{...worker.attributes,openness:100,confidence:100},tendencies:{...worker.tendencies,intimacy:100,libido:100,daring:100},traits:{...worker.traits,bold:true,cautious:false},latentTraits:{...worker.latentTraits,true_prude:false,self_protective:false},affinities:{...worker.affinities,vaginal:2,prostitution:2}});config.allowTaproomSex=true;const runtime=b.getRuntime().get(worker.id);Object.assign(runtime.stats,{energy:100});const customer={id:'request-test',name:'요청 시험',walletGold:1000,location:'taproom',boldness:50,charm:50,intent:'interested',tacticStyle:'transactional'};let rates=true;for(const [tier,chance]of [['ordinary',.35],['skilled',.6],['beautiful',.85]]){worker.hireTier=tier;rates&&=b.sexRequestDecision(worker,customer,settled,chance-.001).requested===true&&b.sexRequestDecision(worker,customer,settled,chance).requested===false;}const accepted=b.sexRequestDecision(worker,customer,settled,0).accepted===true;Object.assign(config,beforeConfig);b.getRuntime().clear();b.saveConfig();api.store.update(()=>beforeState);return{blocked,paid,rates,accepted};
  `);
  assert.ok(['blocked','paid','rates','accepted'].every(key=>wageAndRequest[key]),JSON.stringify(wageAndRequest));
  console.log('PASS next-day fixed wage, arrears work block, repayment and separate sex-request probability');
  const player=await BrothelTest_평가하기(`
    const api=WML.dev(),b=__waywardBrothelPublic;BrothelTest_초기화하기();let before=api.store.game();
    api.store.dispatch({type:'brothel/player-service',workerId:'brothel_worker_1',stage:'chatting'});BrothelTest_남편대화진행하기();const chat=structuredClone(api.store.game());
    BrothelTest_초기화하기();before=api.store.game();const fee=b.fee(before,'sex_patron'),count=b.getConfig().workers[0].sexualExperience.sex_patron;
    api.store.dispatch({type:'brothel/player-service',workerId:'brothel_worker_1',stage:'sex_patron'});BrothelTest_남편대화진행하기();const paid=api.store.game();
    return{chatCost:5000-chat.economy.gold,chatDuration:chat.slot-before.slot,paidCost:before.economy.gold-paid.economy.gold,fee,
      paidDuration:paid.slot-before.slot,session:paid.mods.brothel.playerSession,assignment:paid.mods.brothel.assignments,
      history:b.getConfig().workers[0].sexualHistory.at(-1),countDelta:b.getConfig().workers[0].sexualExperience.sex_patron-count,
      text:paid.log.at(-2)?.text,gold:paid.economy.gold};
  `);
  assert.equal(player.chatCost,0);assert.equal(player.chatDuration,6);assert.equal(player.paidCost,player.fee);assert.equal(player.paidDuration,6);
  assert.equal(player.session,null);assert.deepEqual(player.assignment,{});assert.equal(player.countDelta,1);assert.equal(player.history.partner,'당신');assert.equal(player.history.fee,player.fee);
  console.log('PASS free conversation; full player service fee, history, six-minute reservation and release');
  const blocked=await BrothelTest_평가하기(`
    BrothelTest_초기화하기();const api=WML.dev(),b=__waywardBrothelPublic;api.store.update(state=>({...state,economy:{...state.economy,gold:0}}));
    const before=api.store.game();api.store.dispatch({type:'brothel/player-service',workerId:'brothel_worker_1',stage:'sex_patron'});const after=api.store.game();
    api.store.update(state=>b.assign(state,['brothel_worker_1'],{owner:'test-owner',location:'delivery_site'}));
    api.store.dispatch({type:'brothel/player-service',workerId:'brothel_worker_1',stage:'chatting'});
    return{gold:after.economy.gold,slotDelta:after.slot-before.slot,reason:after.log.at(-1).text,owner:api.store.game().mods.brothel.assignments.brothel_worker_1.owner};
  `);
  assert.equal(blocked.gold,0);assert.equal(blocked.slotDelta,0);assert.match(blocked.reason,/부족/);assert.equal(blocked.owner,'test-owner');
  console.log('PASS insufficient funds and duplicate assignment rejection');
  if(!brothelOnly){
  const dispatch=await BrothelTest_평가하기(`
    BrothelTest_초기화하기();const api=WML.dev(),d=__waywardDeliveryAddon,b=__waywardBrothelPublic;d.forceOffer(40);await new Promise(resolve=>setTimeout(resolve,200));
    const ui=!!document.querySelector('[data-delivery-brothel-choice]'),offer=structuredClone(d.getOffer()),before=structuredClone(api.store.game());
    __waywardDeliveryBrothel.send('brothel_worker_1');const start=structuredClone(api.store.game()),reason=__waywardBrothelFestival.unavailable(start,['brothel_worker_1'],{food:1});
    BrothelTest_분진행하기(14);const wait=structuredClone(api.store.game());BrothelTest_분진행하기(1);const served=structuredClone(api.store.game());
    globalThis.brothelTestSavedDelivery=structuredClone(served);api.store.update(()=>structuredClone(brothelTestSavedDelivery));
    BrothelTest_분진행하기(15);const end=structuredClone(api.store.game()),gold=end.economy.gold;BrothelTest_분진행하기(3);
    return{ui,offer,before,start,waitSession:wait.deliveryAddon.activeDelivery,serviceDone:served.deliveryAddon.activeDelivery?.serviceDone,end,
      repeatedGold:api.store.game().economy.gold,gold,reason,workerLocation:b.getRuntime().get('brothel_worker_1').location};
  `);
  assert.ok(dispatch.ui);assert.equal(dispatch.start.deliveryAddon.activeDelivery.who,'brothel');assert.equal(dispatch.start.mods.brothel.assignments.brothel_worker_1.owner,'delivery-compatible-brothel');
  assert.equal(dispatch.start.readyFood,dispatch.before.readyFood-dispatch.offer.order.food);assert.equal(dispatch.start.supplies.beer,dispatch.before.supplies.beer-dispatch.offer.order.beer);
  assert.equal(dispatch.waitSession.serviceDone,false);assert.equal(dispatch.serviceDone,true);assert.equal(dispatch.end.deliveryAddon.lastReceipt.who,'brothel');
  assert.equal(dispatch.end.deliveryAddon.lastReceipt.totalPayment,dispatch.offer.totalPrice);assert.equal(dispatch.end.deliveryAddon.activeDelivery,undefined);assert.deepEqual(dispatch.end.mods.brothel.assignments,{});
  assert.equal(dispatch.gold,dispatch.repeatedGold);assert.equal(dispatch.workerLocation,'taproom');
  assert.equal(dispatch.start.primaryCharacterId,dispatch.before.primaryCharacterId);assert.deepEqual(dispatch.start.characters,dispatch.before.characters);
  console.log('PASS delivery choice, inventory, external service, restored session, one-time payment and unchanged wife');
  const outlet=await BrothelTest_평가하기(`
    BrothelTest_초기화하기();const api=WML.dev(),b=__waywardBrothelPublic,f=__waywardBrothelFestival;
    const before=structuredClone(api.store.game());f.open(['brothel_worker_1'],{food:2,beer:2,wine:1});
    const opened=structuredClone(api.store.game());globalThis.brothelTestSavedOutlet=structuredClone(opened);api.store.update(()=>structuredClone(brothelTestSavedOutlet));
    const repBefore=structuredClone(api.store.game().tavernReputation);brothelTestArrival=true;BrothelTest_분진행하기(1);brothelTestArrival=false;
    const sold=structuredClone(api.store.game()),portraitRoom=b.imageRoom(f.site),serviceCount=f.getData().active.serviceCount;
    await new Promise(resolve=>setTimeout(resolve,200));const card=document.querySelector('[data-brothel-festival-site]'),portrait=card?.querySelector('[data-brothel-festival-portrait]');
    const ui=!!card,roomAttribute=portrait?.dataset.brothelImageRoom,belowVillage=card?.previousElementSibling?.dataset.waywardRoom==='village';
    api.store.dispatch({type:'festival/return'});const end=structuredClone(api.store.game());api.store.dispatch({type:'festival/return'});
    return{before,opened,sold,end,afterAgain:api.store.game().supplies,repBefore,portraitRoom,ui,roomAttribute,belowVillage,serviceCount,runtime:b.getRuntime().get('brothel_worker_1').location};
  `);
  assert.equal(outlet.opened.slot-outlet.before.slot,30);assert.equal(outlet.opened.mods.festival.stall.stage,'open');assert.equal(outlet.opened.mods.brothel.assignments.brothel_worker_1.location,'festival_brothel');
  assert.equal(outlet.serviceCount,1);assert.equal(outlet.sold.tavernReputation.notoriety,outlet.repBefore.notoriety);
  assert.equal(outlet.sold.tavernReputation.service,Math.min(100,Math.round((outlet.repBefore.service+.3)*10)/10));
  assert.equal(outlet.sold.tavernReputation.renown,Math.min(100,Math.round((outlet.repBefore.renown+.3)*10)/10));
  assert.equal(outlet.portraitRoom,'taproom');assert.ok(outlet.ui);assert.equal(outlet.roomAttribute,'taproom');assert.ok(outlet.belowVillage);assert.equal(outlet.end.mods.festival.stall,null);
  assert.deepEqual(outlet.end.mods.brothel.assignments,{});assert.equal(outlet.runtime,'taproom');assert.deepEqual(outlet.afterAgain,outlet.end.supplies);
  const soldStock=outlet.sold.mods.festival.stall.stock;
  for(const key of ['food','beer','wine'])assert.equal(outlet.end.supplies[key],outlet.opened.supplies[key]+soldStock[key]);
  console.log('PASS outlet inventory, restored roster, service fees, .3 reputation multiplier, zero infamy, hall portrait and return');
  const labor=await BrothelTest_평가하기(`
    BrothelTest_초기화하기(8,17);const api=WML.dev();api.store.update(state=>({...state,mods:{...state.mods,festival:{...state.mods.festival,current:{...state.mods.festival.current,
      requests:state.mods.festival.current.requests.map(request=>({...request,completed:false,queued:false}))}}}}));
    api.store.dispatch({type:'resolve_event',choiceId:'player'});const start=structuredClone(api.store.game());
    api.store.dispatch({type:'festival/advance',minutes:60});const end=api.store.game();
    return{start,end,location:__waywardBrothelPublic.getRuntime().get('brothel_worker_1').location};
  `);
  assert.equal(labor.start.mods.festival.labor.who,'player');assert.equal(labor.start.mods.brothel.assignments.brothel_worker_1.location,'festival_brothel');
  assert.equal(labor.end.slot-labor.start.slot,60);assert.equal(labor.end.mods.festival.labor,null);assert.deepEqual(labor.end.mods.brothel.assignments,{});assert.equal(labor.location,'taproom');
  console.log('PASS selected workers accompany husband on festival labor and return after 60 minutes');
  await BrothelTest_평가하기(`BrothelTest_초기화하기();__waywardBrothelFestival.openSettings();return true;`);
  fs.mkdirSync('wml/mods/brothel/tests/shots',{recursive:true});
  const shot=await playScreenshot({});fs.writeFileSync('wml/mods/brothel/tests/shots/'+(mobile?'mobile':'desktop')+'-outlet.jpg',Buffer.from(shot,'base64'));
  const save=await BrothelTest_평가하기(`
    BrothelTest_초기화하기();const api=WML.dev();__waywardDeliveryAddon.forceOffer(40);__waywardDeliveryBrothel.send('brothel_worker_1');BrothelTest_분진행하기(15);
    api.store.get().saveToSlot(0);const before=structuredClone(api.store.game());BrothelTest_분진행하기(15);api.store.get().loadFromSlot(0);
    return{session:before.deliveryAddon.activeDelivery,restored:api.store.game().deliveryAddon.activeDelivery,gold:before.economy.gold,afterGold:api.store.game().economy.gold,
      stock:before.supplies,afterStock:api.store.game().supplies};
  `);
  assert.deepEqual(save.session,save.restored);assert.equal(save.gold,save.afterGold);assert.deepEqual(save.stock,save.afterStock);
  const reloaded=await playReload({});assert.deepEqual(reloaded.failed,[]);
  const resumed=await BrothelTest_평가하기(`
    const api=WML.dev(),state=api.store.game(),session=structuredClone(state.deliveryAddon.activeDelivery),before=state.economy.gold;
    const count=__waywardBrothelPublic.getConfig().workers[0].sexualExperience.sex_patron;
    for(let step=0;step<20;step++){if(api.store.game().pendingEvent)api.store.update(current=>({...current,pendingEvent:undefined,alertQueue:[]}));api.store.update(current=>api.fn('worldTick')(current,{playerPresent:true}));}
    const end=api.store.game();return{session,delta:end.economy.gold-before,receipt:end.deliveryAddon.lastReceipt,active:end.deliveryAddon.activeDelivery,
      countDelta:__waywardBrothelPublic.getConfig().workers[0].sexualExperience.sex_patron-count,assignments:end.mods.brothel.assignments};
  `);
  assert.deepEqual(resumed.session,save.session);assert.equal(resumed.delta,save.session.offer.totalPrice);assert.equal(resumed.active,undefined);
  assert.equal(resumed.countDelta,0);assert.deepEqual(resumed.assignments,{});assert.equal(resumed.receipt.id,save.session.id);
  console.log('PASS actual save-slot load and browser reload; paid service not repeated and outstanding delivery settled once');
  }
  const status=await playStatus({});assert.deepEqual(status.pageErrors,[]);console.log('PASS browser errors = 0');
}finally{await playStop({all:true});await shutdown();setTimeout(()=>process.exit(process.exitCode||0),30);}
