// 실행: node wml/mods/brothel/tests/player-dialogue.mjs [--mobile] [--all-mods] [--zip] [--save <게임 저장 JSON 경로>]
// seed 1138. MCP의 격리 브라우저만 사용합니다. 사용자 JSON과 공통 모드 목록을 수정하지 않습니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { playStart, playEval, playReload, playStop, playStatus, playScreenshot, shutdown } from '../../../../MCP/lib/play.mjs';
import { checkMod } from '../../../../MCP/lib/check.mjs';
const version=fs.readFileSync('wml/mods/brothel/source/mod.wml.js','utf8').match(/\bversion:\s*['"]([^'"]+)['"]/)?.[1];
const mobile = process.argv.includes('--mobile'), all = process.argv.includes('--all-mods');
const saveArg = process.argv.indexOf('--save'), savePath = saveArg >= 0 ? process.argv[saveArg + 1] : null;
const ids = all ? fs.readdirSync('wml/mods', { withFileTypes: true }).filter(item => item.isDirectory() && fs.existsSync(`wml/mods/${item.name}/mod.js`)).map(item => item.name)
  : ['addon-compat', 'brothel', 'delivery', 'festival', 'delivery-compatible-brothel', 'brothel-compatible-festival'];
const input = savePath ? JSON.parse(fs.readFileSync(savePath, 'utf8').replace(/^\uFEFF/, '')).state : null;
async function BrothelDialogueTest_평가하기(code) { return (await playEval({ code })).result; }
let fixture;
async function BrothelDialogueTest_도우미넣기() {
  await BrothelDialogueTest_평가하기(`
    globalThis.brothelDialogueBase=${JSON.stringify(fixture)};
    globalThis.brothelDialogueSeed=1138;
    Math.random=function BrothelDialogueTest_난수만들기(){brothelDialogueSeed=(Math.imul(brothelDialogueSeed,1664525)+1013904223)>>>0;return brothelDialogueSeed/4294967296;};
    globalThis.BrothelDialogueTest_초기화하기=function(){
      const api=WML.dev(),b=__waywardBrothelPublic,state=structuredClone(brothelDialogueBase);
      ${input ? '' : "state.day=10;state.slot=9*1440+17*60;state.phase='service';state.pendingEvent=undefined;state.alertQueue=[];state.activeScene={};state.customers=[];state.awayEvents=[];state.errandSession=undefined;state.activeShoppingSession=undefined;state.deliveryAddon={};state.economy.gold=5000;state.economy.debt=0;state.pendingCollectorVisit=false;"}
      state.mods={...state.mods,brothel:{assignments:{},playerSession:null,relationships:{},playerHistory:[]}};
      ${input ? '' : "state.mods.festival={version:1,current:{id:'dialogue-fixture',festivalDay:20,participation:'accepted',invitationQueued:true,requests:[18,19].map(day=>({day,dueSlot:(day-1)*1440+1020,queued:false,completed:true,who:null})),stallRevenue:0,stallVisitors:0},labor:null,stall:null,history:[]};"}
      state.tavern.backRoomReady=true;
      ${input ? '' : "for(const room of Object.values(state.locations))room.occupants=[];state.locations.taproom.occupants=['player',state.primaryCharacterId];"}
      api.store.update(()=>state);
      const config=b.getConfig();config.enabled=false;config.allowTaproomSex=true;
      config.workers.forEach((worker,index)=>{worker.enabled=index<2;worker.stats.energy=100;worker.lastFullRestDay=state.day;
        Object.assign(worker.attributes,{openness:100,confidence:100});Object.assign(worker.tendencies,{intimacy:100,libido:100,daring:100});Object.assign(worker.affinities,{vaginal:2,prostitution:2});
        worker.traits.cautious=false;worker.latentTraits.true_prude=false;worker.latentTraits.self_protective=false;});b.getRuntime().clear();b.saveConfig();
      api.store.update(current=>({...current}));return api.store.game();
    };
    globalThis.BrothelDialogueTest_시작하기=function(stage='chatting',workerId='brothel_worker_1'){
      const api=WML.dev();api.store.dispatch({type:'brothel/player-service',workerId,stage});return api.store.game();
    };
    globalThis.BrothelDialogueTest_선택하기=function(choiceId){
      const api=WML.dev(),session=api.store.game().mods.brothel.playerSession;
      if(!session)throw Error('진행 중인 대화 없음');
      api.store.dispatch({type:'brothel/player-choice',sessionId:session.id,turn:session.turn,choiceId});
      for(let count=0;count<6&&api.store.game().mods.brothel.playerSession?.waitingUntil!=null;count++){
        if(api.store.game().pendingEvent){
          if(globalThis.brothelDialogueExpectInterruption)throw Error('시험 도중 선택 사건 발생');
          api.store.update(state=>({...state,pendingEvent:undefined}));
        }
        const current=api.store.game().mods.brothel.playerSession;
        api.store.dispatch({type:'brothel/player-continue',sessionId:current.id,turn:current.turn});
      }
      return api.store.game();
    };
    globalThis.BrothelDialogueTest_한번대화하기=function(topic='work',follow='listen',closing='thanks'){
      BrothelDialogueTest_시작하기();BrothelDialogueTest_선택하기(topic);BrothelDialogueTest_선택하기(follow);return BrothelDialogueTest_선택하기(closing);
    };return true;
  `);
}
try {
  assert.ok(checkMod('brothel').ok);
  await playStart({ mods: Object.fromEntries(ids.map(id => [id, true])), ...(mobile ? { viewport: { width: 390, height: 844 } } : {}) });
  await BrothelDialogueTest_평가하기(`localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify(ids)}));
    if(!${all})localStorage.setItem('wml.toggles',JSON.stringify(Object.fromEntries(WML.status().listed.map(id=>[id,${JSON.stringify(ids)}.includes(id)]))));return true;`);
  if (process.argv.includes('--zip')) {
    const installed = await BrothelDialogueTest_평가하기(`return WML.install([{path:'brothel-${version}-20261101.zip',blob:await(await fetch('wml/mods/brothel/brothel-${version}-20261101.zip')).blob()}]);`);
    assert.equal(installed[0].version, version);
  }
  const loaded = await playReload({}); assert.deepEqual(loaded.failed, []); for (const id of ids) assert.ok(loaded.loaded.includes(id), id);
  fixture = input || await BrothelDialogueTest_평가하기(`
    for(let step=0;step<30;step++){
      if(document.querySelector('button[title="메뉴"]'))break;
      const buttons=[...document.querySelectorAll('button')].filter(button=>button.offsetParent);
      const button=buttons.find(item=>!item.disabled&&/^(예$|이해하고 동의합니다$|새 게임$|계속하기 —|시작 —|시작하기$|건너뛰기$)/.test(item.innerText.trim()))||buttons.find(item=>item.innerText.trim().startsWith('마라'));
      if(!button)throw Error('새 게임 버튼 없음');button.click();await new Promise(resolve=>setTimeout(resolve,100));
    }return structuredClone(WML.dev().store.game());
  `);
  // JSON 입력도 실제 플레이 화면에서 불러옵니다.
  if (input) await BrothelDialogueTest_평가하기(`
    for(let step=0;step<30;step++){
      if(document.querySelector('button[title="메뉴"]'))break;
      const buttons=[...document.querySelectorAll('button')].filter(button=>button.offsetParent);
      const button=buttons.find(item=>!item.disabled&&/^(예$|이해하고 동의합니다$|새 게임$|계속하기 —|시작 —|시작하기$|건너뛰기$)/.test(item.innerText.trim()))||buttons.find(item=>item.innerText.trim().startsWith('마라'));
      if(!button)throw Error('새 게임 버튼 없음');button.click();await new Promise(resolve=>setTimeout(resolve,100));
    }return true;
  `);
  await BrothelDialogueTest_도우미넣기();
  const approach = await BrothelDialogueTest_평가하기(`
    BrothelDialogueTest_초기화하기();await new Promise(resolve=>setTimeout(resolve,120));
    const panel=[...document.querySelectorAll('[data-brothel-player-actions]')].find(node=>node.offsetParent);
    const buttons=[...panel.querySelectorAll('button')].filter(node=>node.offsetParent&&node.closest('[data-brothel-talk-to]'));
    const selects=panel.querySelectorAll('select').length;
    buttons[0].click();await new Promise(resolve=>setTimeout(resolve,80));
    const choices=[...panel.querySelectorAll('button')].filter(node=>node.offsetParent).map(node=>node.textContent.trim());
    return{buttons:buttons.map(node=>node.textContent.trim()),disabled:buttons.map(node=>node.disabled),selects,choices};
  `);
  assert.equal(approach.buttons.length,2);assert.deepEqual(approach.disabled,[false,false]);assert.equal(approach.selects,0);
  assert.ok(approach.choices.some(text=>text.includes('대화하기')));
  for(const label of ['짙은 스킨십','은밀한 애무','손 서비스','구강 서비스','가슴 서비스','성관계'])assert.ok(approach.choices.some(text=>text.includes(label)),label);
  assert.ok(!approach.choices.some(text=>text.includes('독립 권유하기')));
  console.log('PASS wife-style approach buttons, talk/sex choices and hidden unmet independence choice');
  const opening = await BrothelDialogueTest_평가하기(`
    BrothelDialogueTest_초기화하기();const api=WML.dev(),before=structuredClone(api.store.game());
    BrothelDialogueTest_시작하기();await new Promise(resolve=>setTimeout(resolve,100));
    const state=api.store.game(),panel=[...document.querySelectorAll('[data-brothel-player-actions]')].find(node=>node.offsetParent);
    return{slotBefore:before.slot,slot:state.slot,goldBefore:before.economy.gold,gold:state.economy.gold,session:state.mods.brothel.playerSession,
      owner:state.mods.brothel.assignments.brothel_worker_1?.owner,choices:panel?.querySelectorAll('[data-brothel-player-choice]').length,
      reason:state.log.at(-1)?.text,location:api.fn('playerLocation')(state),relation:__waywardBrothelPublic.playerRelationship(state,'brothel_worker_1')};
  `);
  assert.ok(opening.session,opening.reason);
  assert.equal(opening.slot, opening.slotBefore); assert.equal(opening.gold, opening.goldBefore); assert.equal(opening.owner, 'brothel-player');
  assert.equal(opening.session.turn, 0); assert.equal(opening.choices, 5); assert.ok(opening.session.lines.some(line => /사장님/.test(line.text)));
  const steps = await BrothelDialogueTest_평가하기(`
    const api=WML.dev(),b=__waywardBrothelPublic,start=api.store.game().slot;
    const first=structuredClone(BrothelDialogueTest_선택하기('work'));
    const old={type:'brothel/player-choice',sessionId:first.mods.brothel.playerSession.id,turn:0,choiceId:'work'};api.store.dispatch(old);
    const replay=structuredClone(api.store.game());const second=structuredClone(BrothelDialogueTest_선택하기('listen'));
    const final=BrothelDialogueTest_선택하기('respect');
    return{firstTurn:first.mods.brothel.playerSession.turn,firstDelta:first.slot-start,replayDelta:replay.slot-first.slot,
      secondTurn:second.mods.brothel.playerSession.turn,total:final.slot-start,session:final.mods.brothel.playerSession,
      assignments:final.mods.brothel.assignments,history:final.mods.brothel.lastPlayerInteraction,
      relation:b.playerRelationship(final,'brothel_worker_1'),other:b.playerRelationship(final,'brothel_worker_2')};
  `);
  assert.equal(steps.firstTurn, 1); assert.equal(steps.firstDelta, 2); assert.equal(steps.replayDelta, 0); assert.equal(steps.secondTurn, 2); assert.equal(steps.total, 6);
  assert.equal(steps.session, null); assert.deepEqual(steps.assignments, {}); assert.ok(steps.history.lines.length >= 8);
  assert.ok(steps.relation.affinity > opening.relation.affinity); assert.ok(steps.relation.trust > opening.relation.trust); assert.equal(steps.relation.conversations, 1);
  assert.equal(steps.relation.affection, 0); assert.equal(steps.other.affinity, 20); assert.equal(steps.other.trust, 30);
  console.log('PASS visible staff dialogue, manual three-step progression, stale-click guard, six minutes, individual rapport and final transcript');
  const boundaries = await BrothelDialogueTest_평가하기(`
    const b=__waywardBrothelPublic;BrothelDialogueTest_초기화하기();let state=BrothelDialogueTest_한번대화하기('feelings','listen','invite');
    const early=b.playerRelationship(state,'brothel_worker_1'),reply=state.mods.brothel.lastPlayerInteraction.lines;
    BrothelDialogueTest_초기화하기();BrothelDialogueTest_한번대화하기();BrothelDialogueTest_한번대화하기();
    const before=b.playerRelationship(WML.dev().store.game(),'brothel_worker_1');state=BrothelDialogueTest_한번대화하기();
    const after=b.playerRelationship(state,'brothel_worker_1');
    BrothelDialogueTest_초기화하기();BrothelDialogueTest_시작하기();state=BrothelDialogueTest_선택하기('work');const trust=b.playerRelationship(state,'brothel_worker_1').trust;
    state=BrothelDialogueTest_선택하기('press');const pressed=b.playerRelationship(state,'brothel_worker_1').trust;
    WML.dev().store.dispatch({type:'brothel/player-cancel',sessionId:state.mods.brothel.playerSession.id});
    const cancelled=WML.dev().store.game();
    BrothelDialogueTest_초기화하기();WML.dev().store.update(state=>({...state,mods:{...state.mods,brothel:{...state.mods.brothel,relationships:{brothel_worker_1:{...b.playerRelationship(state,'brothel_worker_1'),affinity:60,trust:65,familiarity:5}}}}}));
    state=BrothelDialogueTest_한번대화하기('feelings','listen','invite');
    return{early,reply,before,after,trust,pressed,cancelSession:cancelled.mods.brothel.playerSession,cancelled:cancelled.mods.brothel.lastPlayerInteraction.cancelled,
      mature:b.playerRelationship(state,'brothel_worker_1')};
  `);
  assert.equal(boundaries.early.affection, 0); assert.ok(boundaries.reply.some(line => /서두르지|아직은/.test(line.text)));
  for (const key of ['affinity', 'trust', 'affection', 'familiarity']) assert.equal(boundaries.before[key], boundaries.after[key]);
  assert.ok(boundaries.pressed < boundaries.trust); assert.equal(boundaries.cancelSession, null); assert.equal(boundaries.cancelled, true); assert.ok(boundaries.mature.affection > 0);
  console.log('PASS professional boundaries, reciprocal affection after familiarity, limited repeated rewards, pressure lowers trust and cancellation releases reservation');
  const paid = await BrothelDialogueTest_평가하기(`
    const api=WML.dev(),b=__waywardBrothelPublic;BrothelDialogueTest_초기화하기();const before=api.store.game(),count=b.getConfig().workers[0].sexualExperience.sex_patron;
    BrothelDialogueTest_시작하기('sex_patron');const first=api.store.game(),fee=first.mods.brothel.playerSession.fee;
    const countAtStart=b.getConfig().workers[0].sexualExperience.sex_patron;
    BrothelDialogueTest_선택하기('reassure');BrothelDialogueTest_선택하기('check');
    const middle=structuredClone(api.store.game());api.store.get().saveToSlot(0);api.store.get().loadFromSlot(0);
    return{goldBefore:before.economy.gold,paid:before.economy.gold-first.economy.gold,fee,startSlot:first.slot,beforeSlot:before.slot,count,countAtStart,
      countAtMiddle:b.getConfig().workers[0].sexualExperience.sex_patron,session:middle.mods.brothel.playerSession,restored:api.store.game().mods.brothel.playerSession};
  `);
  assert.equal(paid.startSlot, paid.beforeSlot); assert.equal(paid.paid, paid.fee); assert.equal(paid.countAtStart, paid.count); assert.equal(paid.countAtMiddle, paid.count + 1);
  assert.deepEqual(paid.session, paid.restored); assert.equal(paid.session.turn, 2); assert.equal(paid.session.serviceRecorded, true);
  const reloaded = await playReload({}); assert.deepEqual(reloaded.failed, []); await BrothelDialogueTest_도우미넣기();
  const resumed = await BrothelDialogueTest_평가하기(`
    const api=WML.dev(),b=__waywardBrothelPublic,before=api.store.game(),session=before.mods.brothel.playerSession;
    const lines=session.lines.length,count=b.getConfig().workers[0].sexualExperience.sex_patron,gold=before.economy.gold;
    const final=BrothelDialogueTest_선택하기('finish'),aftercare=b.aftercareRemaining(final,'brothel_worker_1'),waitStart=final.slot;
    api.store.dispatch({type:'brothel/player-wait-aftercare',workerId:'brothel_worker_1'});const waited=api.store.game();
    return{oldLines:lines,lines:final.mods.brothel.lastPlayerInteraction.lines.length,deltaCount:b.getConfig().workers[0].sexualExperience.sex_patron-count,
      goldDelta:final.economy.gold-gold,session:final.mods.brothel.playerSession,assignments:final.mods.brothel.assignments,
      relation:b.playerRelationship(final,'brothel_worker_1'),aftercare,waited:waited.slot-waitStart,remaining:b.aftercareRemaining(waited,'brothel_worker_1')};
  `);
  assert.ok(resumed.lines > resumed.oldLines); assert.equal(resumed.deltaCount, 0); assert.equal(resumed.goldDelta, 0); assert.equal(resumed.session, null);
  assert.deepEqual(resumed.assignments, {}); assert.equal(resumed.relation.services, 1); assert.equal(resumed.relation.affection, 0);
  assert.equal(resumed.aftercare,6);assert.equal(resumed.waited,6);assert.equal(resumed.remaining,0);
  console.log('PASS one upfront fee, service recorded during progression once, slot save and browser reload resume transcript and stage without duplicate charge or history');
  const interruptions = await BrothelDialogueTest_평가하기(`
    const api=WML.dev();BrothelDialogueTest_초기화하기();BrothelDialogueTest_시작하기();
    const unhook=api.hook('worldTick',{priority:-1000,after(state){return{...state,pendingEvent:{type:'alert',text:'대화 시험용 사건',alert:{severity:'info',title:'대화 시험용 사건'},choices:[{id:'ok',label:'확인'}]}}}});
    globalThis.brothelDialogueExpectInterruption=true;
    let pause;try{BrothelDialogueTest_선택하기('mood')}catch{pause=structuredClone(api.store.game())}finally{globalThis.brothelDialogueExpectInterruption=false;unhook()}
    api.store.update(state=>({...state,pendingEvent:undefined}));let current=api.store.game().mods.brothel.playerSession;
    api.store.dispatch({type:'brothel/player-continue',sessionId:current.id,turn:current.turn});const continued=api.store.game().mods.brothel.playerSession;
    api.store.dispatch({type:'brothel/player-cancel',sessionId:continued.id});
    BrothelDialogueTest_초기화하기();BrothelDialogueTest_시작하기();api.store.update(state=>api.fn('worldTick')({...state,phase:'closed'},{playerPresent:true}));
    const closed=api.store.game();
    BrothelDialogueTest_초기화하기();const b=__waywardBrothelPublic;BrothelDialogueTest_한번대화하기();
    b.getConfig().workers[0].relationshipId='replacement-employee';api.store.update(state=>({...state}));
    const replacement=b.playerRelationship(api.store.game(),'brothel_worker_1');
    BrothelDialogueTest_초기화하기();BrothelDialogueTest_시작하기();
    const legacyStart=api.store.game(),legacyGold=legacyStart.economy.gold;
    api.store.update(state=>({...state,mods:{...state.mods,brothel:{...state.mods.brothel,playerSession:{workerId:'brothel_worker_1',stage:'chatting',fee:0,endSlot:state.slot+2,originalLocation:'taproom'}}}}));
    for(let minute=0;minute<2;minute++)api.store.update(state=>api.fn('worldTick')(state,{playerPresent:true}));
    const legacy=api.store.game();
    return{paused:pause?.mods.brothel.playerSession?.waitingUntil,pauseSlot:pause?.slot,continued:continued?.waitingUntil,closeSession:closed.mods.brothel.playerSession,
      closeAssignments:closed.mods.brothel.assignments,replacement,legacySession:legacy.mods.brothel.playerSession,legacyAssignments:legacy.mods.brothel.assignments,legacyGold:legacy.economy.gold-legacyGold};
  `);
  assert.ok(interruptions.paused > interruptions.pauseSlot); assert.equal(interruptions.continued, null); assert.equal(interruptions.closeSession, null); assert.deepEqual(interruptions.closeAssignments, {});
  assert.equal(interruptions.replacement.affinity, 20); assert.equal(interruptions.replacement.conversations, 0);
  assert.equal(interruptions.legacySession,null);assert.deepEqual(interruptions.legacyAssignments,{});assert.equal(interruptions.legacyGold,0);
  console.log('PASS event interruption resumes remaining step, closing clears reservation, replacement employee has a separate relationship and legacy session settles unchanged');
  await BrothelDialogueTest_평가하기(`BrothelDialogueTest_초기화하기();BrothelDialogueTest_시작하기();BrothelDialogueTest_선택하기('personal');await new Promise(resolve=>setTimeout(resolve,150));return true;`);
  fs.mkdirSync('wml/mods/brothel/tests/shots', { recursive: true });
  fs.writeFileSync(`wml/mods/brothel/tests/shots/${mobile ? 'mobile' : 'desktop'}-player-dialogue.jpg`, Buffer.from(await playScreenshot({}), 'base64'));
  const status = await playStatus({}); assert.deepEqual(status.pageErrors, []);
  console.log(`PASS ${mobile ? 'mobile' : 'desktop'}, ${ids.length} mods, ${input ? 'provided save day ' + input.day : 'fresh fixture'}, no browser errors`);
} finally { await playStop({}); await shutdown(); setTimeout(()=>process.exit(process.exitCode||0),30); }
