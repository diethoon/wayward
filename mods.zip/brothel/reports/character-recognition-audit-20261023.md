# 캐릭터 고정 목록 점검 — 2026-10-23

## 결론

현재 로컬의 mod.js가 있는 모드 61개와 별도 런타임 JS를 정적으로 검색한 뒤, 캐릭터 키·등록부·선택 목록을 사용하는 경로를 추적했습니다. 이미지팩의 콘텐츠·과거 ZIP·node_modules·보존 원본은 현행 코드의 인식 제한과 구분했습니다. 고정 배열이 있다는 사실만으로 새 캐릭터를 거부한다고 판정하지 않았습니다.

Brothel은 작업 시작 시 이미 3.10.0이었고, 실제 게임 캐릭터 등록부와 옛 애드온 목록을 합치는 탐색이 구현돼 있었습니다. 기본 elena/mara/pippa 배열은 대체 기본값이며 히나까지 네 명으로 제한하는 허용 목록이 아닙니다. 3.10.1에서는 이 동작을 보존하면서 버튼 명칭을 요청한 **새로운 캐릭터 찾기**로 맞췄습니다. 다른 채팅·이전 설치본의 상태는 이번 점검으로 판정하지 않았습니다.

## 기능별로 실제 제한이 있는 곳

| 모드 | 고정 목록의 사용 | 실제 영향 | 이번 처리 |
|---|---|---|---|
| H_Status(Edit_HL) | `koSEThugCharacterKey`는 elena/mara/pippa 외 인물을 pippa로 분류 | 해당 불량배 대사의 캐릭터별 성격·문구가 피파형으로 대체됨. 모드 전체나 신규 캐릭터 이미지 인식을 거부하는 제한은 아님 | 기능은 변경하지 않고 보고 |
| H_Status(Edit_HL) | `H_STATUS_SHIPPED_PACK_CHARACTERS`에 9명 | 초기 상황 이미지팩 후보 목록. 저장된 `h-status-image-pack-characters-v1`로 늘릴 수 있지만, 새로운 캐릭터 파일이 있기만 하면 전체를 자동 탐색하는 구조는 아님 | 기능은 변경하지 않고 보고 |
| H_Status(Edit_HL) | `koSEKnownCharacterKey`가 `[a-z][a-z0-9_-]` 2~32자만 허용 | 등록돼 있어도 한 글자 또는 33자 이상 키는 일부 상황 이미지 경로에서 제외될 수 있음. 고정 캐릭터 목록과 별개인 ID 형식 제한 | 기능은 변경하지 않고 보고 |
| attention-image-prompt(Edit_HL) | `EXTRA_LINES_DIALOGUE_SOURCES`에 기본 3명 | 추가 대사의 원본 캐릭터 선택이 기본 3명에 한정됨. 사용자 캐릭터 편집·현재 캐릭터의 프롬프트 적용 자체는 동적 | 기능은 변경하지 않고 보고 |
| ImageStudio 공통 프롬프트 편집기 | 위 대사 원본 3종과 H_Status 부위별 img2img의 elena/mara/pippa 참조 선택 | 새 캐릭터 생성은 가능하지만, 자동 기준 이미지는 기본 캐릭터로 대체됨. 직접 지정 기준 키 경로는 별도 | 기능은 변경하지 않고 보고 |
| WOW | `heroKey`가 이름/id를 elena/mara/pippa/other로 분류 | 새로운 인물은 일반 `other` 대사·전투 기본값 사용. 기본 3명에 배정한 채집·사냥·흥정 등의 고유 보너스가 새 인물의 별도 유형으로 생기지는 않음 | WOW_SDK의 hero/other 규격 확인. 원본 수정 없음 |

## 고정 목록처럼 보이지만 전체 인식을 막지 않는 곳

| 모드 | 확인 결과 |
|---|---|
| Brothel | 기본 3명에 실제 게임 등록부·옛 애드온 캐릭터를 추가. 설정 열기·고용 시 자동 갱신, 버튼 수동 갱신. 기존 직원의 미인식 선택은 보존 |
| ImageStudio | 실제 등록부의 `shortname`, 이름, 외형·Negative를 읽음. 서버 기본 3명·캐릭터 폴더 기본값은 시작 자료이며 discover/discover-batch로 추가 가능 |
| H_Status | 일반 상황 캐릭터 키와 생성 대상은 실제 등록부·프롬프트 프로필·ImageStudio 목록을 참조. 기본 3명 배열만으로 전체를 제한하지 않음 |
| attention-image-prompt / 공통 편집기 | 기본 프롬프트 원본 3종 외에 사용자 캐릭터와 현재 캐릭터 자료 경로가 있음. 기본 템플릿 선택과 캐릭터 인식은 서로 다른 기능 |
| sound-mod | 엘레나/마라/피파/히나 이름 별칭은 우선 매핑. 사용자 매핑, 실제 음성 폴더와 character/template/archetype ID 후보, 공통 음성을 함께 사용하므로 4명만 허용하는 목록이 아님 |
| newwife-* | 각 모드가 자기 캐릭터 1명을 등록하는 정의. 다른 모드가 인식할 수 있는 인물을 제한하는 허용 목록이 아님 |
| 나머지 모드 | 이번 검색·호출 경로 확인에서 캐릭터 인식 전체를 기본 3~4명으로 거부하는 목록을 확인하지 못함. 미래 게임 버전이나 실행 중 내려받는 외부 자료까지 지원한다고 보장하지는 않음 |

### 목록 외 제외 조건

Brothel의 기존 탐색은 ID 형식·중복·손님 전용 항목·명시된 나이/아동 설정도 검사합니다. 예를 들어 로컬 newwife-ibuki의 태그라인에는 초등부·나이 표현, 외형 프롬프트에는 `loli`가 남아 있어 이 기존 제외 조건에 해당합니다. 이는 고정 목록 제한과 다른 원인입니다. 이 캐릭터 파일과 제외 로직은 수정하지 않았습니다.

## 코드 근거

- `brothel/source/mod.wml.js:375` — `function Brothel_캐릭터탐색하기`
- `brothel/source/mod.wml.js:30` — `const Brothel_등록캐릭터읽기`
- `brothel/source/mod.wml.js:737` — `function Brothel_초상화목록그리기`
- `imagestudio/source/mod.wml.js:304` — `function imageStudio_collectWives`
- `imagestudio/source/mod.wml.js:1315` — `async function imageStudio_discoverWives`
- `h-status(Edit_HL)/source/mod.wml.js:6262` — `function koSEThugCharacterKey`
- `h-status(Edit_HL)/source/mod.wml.js:716` — `function koSEKnownCharacterKey`
- `h-status(Edit_HL)/source/features.js:55` — `const H_STATUS_SHIPPED_PACK_CHARACTERS`
- `attention-image-prompt(Edit_HL)/source/mod.wml.js:300` — `const EXTRA_LINES_DIALOGUE_SOURCES`
- `attention-image-prompt(Edit_HL)/source/mod.wml.js:984` — `function wifePromptSources`
- `imagestudio-compatible-attention-image-prompt/source/attention-upgrades.js:321` — `if (!['elena','mara','pippa'].includes(pieces[1]))`
- `wow/mod.js:337` — `function heroKey(s)`
- `sound-mod/tools/audio-adapter.js:18` — `function voiceFolder(event)`

## 이번 변경과 검증

- Brothel 3.10.1·ImageStudio 1.31.5·H_Status 1.7.7의 탐색 버튼을 **새로운 캐릭터 찾기**로 통일했습니다.
- ImageStudio의 인물 선택·생성 방식 설정 두 화면과 H_Status의 이미지 일괄 생성 화면을 확인했습니다.
- 기존 `discoverWives` 공개 API·DOM ID·저장 키는 유지했습니다. 미래 버전의 미정인 캐릭터 데이터 형식까지 지원한 변경은 아닙니다.
- Brothel은 히나·미카·이치카·라이자·마리 모드와, 등록부에 뒤늦게 직접 추가한 시험 캐릭터를 검증했습니다.
- 중복 제외·미인식 선택 유지·다시 등록했을 때 복원·캐릭터별 이미지 키와 직원 상태·저장/재로드를 PC·모바일의 격리 브라우저에서 확인했습니다.
- 실제 이미지 생성·사용자 저장·실행 중 생성 서버는 변경하지 않았습니다.

실행: `node --import ./wml/mods/brothel/tests/mcp-runtime.mjs wml/mods/brothel/tests/character-discovery.mjs --newwives` (`--mobile`, `--zip` 지원), 같은 방식으로 `character-labels.mjs` (`--mobile` 지원).
