// 호환성 패치 기준: brothel 3.10.0 / festival 1.2.1 (개정 기준, 버전 번호에 따른 실행 제한 없음)
WML.define({
  tags: ["content"],
  id:'brothel-compatible-festival',
  author: "Hina_Lover",name:"창관 - 축제 호환 패치",version: "1.0.9",lang:'ko',game:"2026-11-01",
  requires:['brothel','festival'],loadAfter:['delivery-compatible-brothel'],
  description:"창부들이 축제에서 음식·주류·매춘부를 지정하는 출장 매춘소를 운영할 수 있게 됩니다. 남편의 축제 준비·판매에 매춘부가 동행하며 홀 초상화와 창관 평판 설정을 사용합니다.",
  symbols:{
    "DeliveryLocations": {"raw":{"2026-11-01":"Za"}},
    "DeliveryLocationNames": {"raw":{"2026-11-01":"YZ"}},
    "DeliveryLocationCardNames": {"raw":{"2026-11-01":"LB"}},
    "DeliveryLocationPanel": {"raw":{"2026-11-01":"hat"}},
    "FestivalVillageActions": {"raw":{"2026-11-01":"wB"},"doc":"마을 둘러보기 행동 패널"},
    "FestivalTavernDay": {"raw":{"2026-11-01":"pt"},"doc":"자정 이후에도 유지되는 주점 영업일"}
  },
  setup(api){
    const brothel=globalThis.__waywardBrothelPublic,festival=globalThis.__waywardFestival;
    if(!brothel?.assign||!brothel?.service||!festival)throw Error('Brothel 3.6.0과 Festival 1.0.0을 함께 설치하세요.');
    const OWNER=api.id,SITE='festival_brothel',React=api.fn('React'),JSX=api.fn('jsx');
    const ITEMS={food:'식재료',readyFood:'조리된 음식',beer:'맥주',wine:'와인'};
    let panel=null,writing=false;
    api.fn('DeliveryLocationNames')[SITE]='출장 매춘소';api.fn('DeliveryLocationCardNames')[SITE]='출장 매춘소';
    const rooms=api.fn('DeliveryLocations');if(!rooms.includes(SITE))rooms.splice(rooms.indexOf('village')+1,0,SITE);
    function BrothelFestival_자료읽기(state){return state?.mods?.[OWNER]??{workerIds:null,stock:{},active:null}}
    function BrothelFestival_자료쓰기(state,patch){return{...state,mods:{...state.mods,[OWNER]:{...BrothelFestival_자료읽기(state),...patch}}}}
    function BrothelFestival_지정직원읽기(state){return BrothelFestival_자료읽기(state).workerIds??brothel.workers(state).map(worker=>worker.id)}
    function BrothelFestival_재고읽기(state){return{food:state.supplies?.food??0,readyFood:state.readyFood??0,beer:state.supplies?.beer??0,wine:state.supplies?.wine??0}}
    function BrothelFestival_축제기간확인하기(state){
      const round=state?.mods?.festival?.current;if(!round)return false;
      const day=api.fn('FestivalTavernDay')(state.slot);
      return day>=round.festivalDay&&day<=round.festivalDay+1;
    }
    function BrothelFestival_개점불가이유읽기(state,ids,stock){
      if(!state||state.gameOver)return'게임 진행 중에 지정하세요.';
      const round=state.mods?.festival?.current,day=api.fn('FestivalTavernDay')(state.slot);
      if(round?.participation!=='accepted'||day<round.festivalDay||day>round.festivalDay+1)return'참여한 축제의 이틀 동안 개점할 수 있습니다.';
      if(state.mods.festival.stall||state.mods.festival.labor||state.pendingEvent||state.errandSession||state.activeShoppingSession||state.deliveryAddon?.activeDelivery||state.activeScene?.sex||state.activeScene?.patron||state.activeScene?.situation||state.activeScene?.table)return'진행 중인 사건·배달·축제 일을 먼저 마무리하세요.';
      if(!['taproom','kitchen','bedroom','back_room','upstairs_hall','elena_room','upstairs_room_2','bathroom','bathhouse'].includes(api.fn('playerLocation')(state)))return"당신이 주점에 있어야 합니다.";
      if(!ids.length||new Set(ids).size!==ids.length)return'매춘부를 한 명 이상 지정하세요.';
      for(const id of ids){const reason=brothel.unavailable(state,id);if(reason)return`${brothel.workers(state).find(worker=>worker.id===id)?.name??id}: ${reason}`}
      const available=BrothelFestival_재고읽기(state);
      if(Object.keys(ITEMS).some(key=>!Number.isSafeInteger(stock[key]??0)||(stock[key]??0)<0||(stock[key]??0)>available[key]))return'가져갈 재고 수량을 확인하세요.';
      if(!Object.values(stock).some(count=>count>0))return'음식이나 주류 재고를 한 개 이상 지정하세요.';
      return'';
    }
    function BrothelFestival_출발하기(ids,stock){
      const state=api.store.game(),reason=BrothelFestival_개점불가이유읽기(state,ids,stock);
      if(reason){api.log(`[출장 매춘소] ${reason}`);return false}
      api.store.update(current=>BrothelFestival_자료쓰기(current,{workerIds:[...ids],stock:{...stock}}));
      api.store.dispatch({type:'festival/open-stall',stock});
      return!!api.store.game().mods?.festival?.stall;
    }
    function BrothelFestival_동기화하기(state){
      if(!state)return state;
      let next=state;if(!next.locations?.[SITE])next={...next,locations:{...next.locations,[SITE]:{occupants:[]}}};
      const data=BrothelFestival_자료읽기(next),task=next.mods?.festival?.stall??(next.mods?.festival?.labor?.who==='player'?next.mods.festival.labor:null);
      const key=task?`${next.mods.festival.stall?'stall':'labor'}:${task.startSlot}`:null;
      if(!task){if(!data.active)return next;next=brothel.release(next,OWNER);return BrothelFestival_자료쓰기(next,{active:null})}
      if(data.active?.key===key){
        // 저장을 불러와 런타임이 초기화되어도 배정표로 초상화·위치를 복원합니다.
        for(const id of data.active.workerIds){const worker=brothel.getConfig()?.workers.find(worker=>worker.id===id);if(worker)brothel.portrait(next,id)}
        return next;
      }
      next=brothel.release(next,OWNER);
      const ids=BrothelFestival_지정직원읽기(next).filter(id=>!brothel.unavailable(next,id));
      if(ids.length)next=brothel.assign(next,ids,{owner:OWNER,location:SITE,task:next.mods.festival.stall?'출장 매춘소 근무':'축제 출장소 준비',
        situation:next.mods.festival.stall?"당신과 축제 출장 매춘소를 운영합니다. 손님에게 별도 서비스 요금을 받습니다.":"당신과 함께 축제 출장소의 설치·준비 작업을 합니다."});
      next=BrothelFestival_자료쓰기(next,{active:{key,workerIds:ids,lastVisitors:task.visitors??0,serviceCount:0}});
      return api.fn('log')(next,`[출장 매춘소] 당신의 축제 ${next.mods.festival.stall?'출장 판매':'준비 동원'}에 ${ids.length?ids.map(id=>brothel.workers(next).find(worker=>worker.id===id)?.name).join(', '):'현재 동행 가능한 매춘부 없음'}. 매춘부들은 출장소 작업을 맡습니다.`);
    }
    function BrothelFestival_서비스진행하기(state){
      const data=BrothelFestival_자료읽기(state),stall=state.mods?.festival?.stall,active=data.active;
      if(!active||stall?.stage!=='open'||active.lastVisitors>=stall.visitors)return state;
      let next=state,count=active.serviceCount;
      for(let visitor=active.lastVisitors+1;visitor<=stall.visitors;visitor++){
        const ids=active.workerIds.filter(id=>brothel.workers(next).some(worker=>worker.id===id&&worker.energy>=10));
        if(!ids.length)break;
        const id=ids[count%ids.length],fee=brothel.fee(next,'sex_patron');
        const customer={id:`festival:${stall.startSlot}:client:${visitor}`,name:`축제 손님 ${visitor}`,boldness:40,walletGold:fee};
        const served=brothel.service(next,id,customer,'sex_patron',{owner:OWNER});if(served!==next){next=served;count++}
      }
      return BrothelFestival_자료쓰기(next,{active:{...active,lastVisitors:stall.visitors,serviceCount:count}});
    }
    api.hook('worldTick',{priority:-500,around(next,state,...args){return BrothelFestival_서비스진행하기(BrothelFestival_동기화하기(next(BrothelFestival_동기화하기(state),...args)))}});
    api.hook('reduceGameAction',{priority:-500,after:BrothelFestival_동기화하기});
    api.hook('imageRoom',{around(next,room,...args){return room===SITE?'taproom':next(room,...args)}});
    function BrothelFestival_초상화그리기({id,state}){
      const img=React.useRef(null),placeholder=React.useRef(null),key=brothel.portrait(state,id),worker=brothel.workers(state).find(item=>item.id===id);
      React.useEffect(()=>{if(img.current&&placeholder.current)brothel.loadPortrait(key,img.current,placeholder.current)},[key]);
      return JSX.jsxs('div',{className:'min-w-0',children:[JSX.jsx('img',{ref:img,hidden:true,alt:worker?.name??'매춘부',className:'w-full h-24 object-contain','data-brothel-festival-portrait':id,'data-brothel-image-room':'taproom'}),
        JSX.jsx('span',{ref:placeholder,className:'text-xs text-stone-500',children:'홀 초상화 불러오는 중'}),JSX.jsx('p',{className:'text-xs text-rose-200',children:worker?.name??id})]});
    }
    function BrothelFestival_개점버튼그리기(){
      if(!BrothelFestival_축제기간확인하기(api.store.game()))return null;
      const disabled=false;
      const label='축제 출장 매춘소 개점',description="음식·주류·매춘부 지정 · 당신과 함께 운영 · 개점 30분 · 복귀 30분";
      const button=typeof festival.renderActionButton==='function'
        ?festival.renderActionButton(label,description,BrothelFestival_지정창열기,disabled,'brothel-open-stall')
        :JSX.jsxs('button',{type:'button',onClick:BrothelFestival_지정창열기,disabled,
          className:'text-left w-full p-3 rounded-lg border border-amber-700 bg-stone-800 hover:bg-stone-700 disabled:opacity-50 text-stone-100',
          children:[JSX.jsx('div',{className:'font-medium text-sm text-amber-200',children:label}),
            JSX.jsx('div',{className:'text-xs text-stone-400 mt-1',children:description})]},'brothel-open-stall');
      return React.cloneElement(button,{'data-brothel-festival-configure':true});
    }
    function BrothelFestival_장소그리기(state){
      const data=BrothelFestival_자료읽기(state),active=data.active,stall=state.mods?.festival?.stall;
      return JSX.jsxs('section',{'data-wayward-room':SITE,'data-brothel-festival-site':true,className:'mt-1.5 p-2 rounded border border-rose-900 text-xs',children:[
        JSX.jsx('h4',{className:'text-rose-200',children:'출장 매춘소'}),
        JSX.jsx('p',{children:active?`${stall?({opening:'개점 준비 중',open:'영업 중',returning:'주점으로 복귀 중'})[stall.stage]:"당신과 축제 준비 작업 중"} · 매춘부 ${active.workerIds.length}명 · 서비스 ${active.serviceCount}건`:"음식·주류·매춘부를 지정하면 당신과 함께 축제 출장소를 운영합니다."}),
        JSX.jsx('p',{className:'text-stone-400',children:'초상화: 홀 연동 · 명성·서비스 평판: 창관 설정 배율 · 악명 증가 없음'}),
        active&&JSX.jsx('div',{className:'grid grid-cols-2 gap-2',children:active.workerIds.map(id=>JSX.jsx(BrothelFestival_초상화그리기,{id,state},id))}),
        BrothelFestival_개점버튼그리기()]});
    }
    // 마을 카드와 같은 칸에 세로로 붙여 다른 외출 카드와 사이가 벌어지지 않게 합니다.
    api.hook('DeliveryLocationPanel',{priority:-500,after(result){
      const state=api.store.game();if(!BrothelFestival_축제기간확인하기(state)||!React.isValidElement(result))return result;
      let inserted=false;
      function BrothelFestival_마을밑에넣기(element){
        if(!React.isValidElement(element))return element;
        if(/(?:^|\$)village$/.test(String(element.key))){inserted=true;return React.cloneElement(element,{},element.props.children,BrothelFestival_장소그리기(state))}
        if(!element.props.children)return element;
        return React.cloneElement(element,{},...React.Children.toArray(element.props.children).map(BrothelFestival_마을밑에넣기));
      }
      const modified=BrothelFestival_마을밑에넣기(result);
      if(inserted)return modified;
      const children=React.Children.toArray(result.props.children);children.splice(3,0,BrothelFestival_장소그리기(state));
      return React.cloneElement(result,{},...children);
    }});
    api.hook('FestivalVillageActions',{priority:-500,after(result){
      const button=BrothelFestival_개점버튼그리기();if(!button||!React.isValidElement(result))return result;
      const children=React.Children.toArray(result.props.children),index=children.length-1,village=children[index];
      if(React.isValidElement(village))children[index]=React.cloneElement(village,{},...React.Children.toArray(village.props.children),button);
      return React.cloneElement(result,{},...children);
    }});
    function BrothelFestival_지정창그리기(body){
      const state=api.store.game();if(!state){body.textContent='게임 진행 중에 지정하세요.';return}
      const data=BrothelFestival_자료읽기(state),available=BrothelFestival_재고읽기(state),selected=new Set(BrothelFestival_지정직원읽기(state)),inputs={},checks=[];
      body.replaceChildren();const note=document.createElement('p');note.textContent="당신과 매춘부가 함께 운영합니다. 재고는 출발할 때 차감하고 복귀 때 미판매분을 반환합니다. 지정한 매춘부는 당신의 축제 준비 동원에도 동행합니다. 성적 서비스에는 별도 요금이 적용됩니다.";body.append(note);
      for(const[key,label]of Object.entries(ITEMS)){
        const row=document.createElement('label');row.style.cssText='display:flex;justify-content:space-between;margin:10px 0;gap:10px';
        const input=document.createElement('input');input.type='number';input.min=0;input.max=available[key];input.step=1;input.value=data.stock[key]??0;input.dataset.brothelFestivalStock=key;input.style.cssText='width:80px;background:#292524;color:#fafaf9;border:1px solid #78716c;padding:5px';row.append(document.createTextNode(`${label} · 재고 ${available[key]}`),input);body.append(row);inputs[key]=input;
      }
      for(const worker of brothel.workers(state)){
        const row=document.createElement('label'),check=document.createElement('input');check.type='checkbox';check.value=worker.id;check.checked=selected.has(worker.id);check.dataset.brothelFestivalWorker=worker.id;row.style.cssText='display:block;margin:10px 0';
        row.append(check,document.createTextNode(` ${worker.name}${brothel.unavailable(state,worker.id)?' · '+brothel.unavailable(state,worker.id):''}`));body.append(row);checks.push(check);
      }
      const feedback=document.createElement('p');feedback.dataset.brothelFestivalFeedback='';body.append(feedback);
      function BrothelFestival_입력읽기(){return{ids:checks.filter(check=>check.checked).map(check=>check.value),stock:Object.fromEntries(Object.entries(inputs).map(([key,input])=>[key,Number(input.value)]))}}
      body.append(api.ui.button('지정 저장 · 축제 준비 동행에 적용',()=>{const{ids,stock}=BrothelFestival_입력읽기();if(!ids.length||Object.values(stock).some(value=>!Number.isSafeInteger(value)||value<0)){feedback.textContent='매춘부를 지정하고 재고 수량을 확인하세요.';return}api.store.update(current=>BrothelFestival_자료쓰기(current,{workerIds:ids,stock}));feedback.textContent="지정을 저장했습니다. 준비 동원은 당신을 선택할 때 적용됩니다."}));
      const openButton=api.ui.button('출장 매춘소 개점 · 30분',()=>{const{ids,stock}=BrothelFestival_입력읽기();const reason=BrothelFestival_개점불가이유읽기(api.store.game(),ids,stock);if(reason){feedback.textContent=reason;return}if(BrothelFestival_출발하기(ids,stock))panel?.close()},{disabled:!BrothelFestival_축제기간확인하기(state)});
      openButton.dataset.brothelFestivalOpen='';body.append(openButton);
    }
    function BrothelFestival_지정창열기(){panel=api.ui.window({id:'outlet',title:'출장 매춘소 · 음식·주류·매춘부 지정',width:480,height:640,render:BrothelFestival_지정창그리기,onClose:()=>{panel=null}})}
    api.ui.settings(BrothelFestival_지정창그리기);
    api.onBack(()=>{if(!panel)return false;panel.close();return true});
    api.store.subscribe(()=>{if(writing||!api.store.get().started)return;const state=api.store.game();for(const button of document.querySelectorAll('[data-brothel-festival-open]'))button.disabled=!BrothelFestival_축제기간확인하기(state);const next=BrothelFestival_동기화하기(state);if(next!==state){writing=true;try{api.store.update(current=>current===state?next:current)}finally{writing=false}}});
    globalThis.__waywardBrothelFestival={open:BrothelFestival_출발하기,openSettings:BrothelFestival_지정창열기,unavailable:BrothelFestival_개점불가이유읽기,
      configure:(ids,stock={})=>api.store.update(state=>BrothelFestival_자료쓰기(state,{workerIds:[...ids],stock:{...stock}})),getData:()=>structuredClone(BrothelFestival_자료읽기(api.store.game())),site:SITE};
  }
});
