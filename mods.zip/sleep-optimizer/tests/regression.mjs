// 실행: node wml/mods/sleep-optimizer/tests/regression.mjs [--mobile] [--zip]
// MCP 격리 저장소만 사용합니다. 외부 이미지 서버와 사용자 저장소는 사용하지 않습니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {playStart,playEval,playReload,playStatus,playScreenshot,shutdown} from '../../../../MCP/lib/play.mjs';
const mobile=process.argv.includes('--mobile'),results=[];
async function evaluate(code){const r=await playEval({code,timeoutMs:45000});assert.equal(r.pageErrorsSoFar,0,JSON.stringify(r));return r.result;}
async function check(name,code){const value=await evaluate(code);assert.ok(Object.values(value).every(v=>v===true),name+': '+JSON.stringify(value));results.push({name,value});console.log('PASS',name);}
try{
  assert.deepEqual((await playStart({viewport:mobile?{width:390,height:844}:{width:1280,height:900}})).failed,[]);
  if(process.argv.includes('--zip'))await evaluate(`const out=await WML.install([{path:'sleep-optimizer-1.0.0.zip',blob:await(await fetch('wml/mods/sleep-optimizer/sleep-optimizer-1.0.0.zip')).blob()}]);if(out[0].version!=='1.0.0')throw Error('ZIP 설치 실패');return true;`);
  else await evaluate(`localStorage.setItem('wml.folders',JSON.stringify([...WML.status().loaded,'sleep-optimizer']));localStorage.setItem('wml.toggles',JSON.stringify({...JSON.parse(localStorage.getItem('wml.toggles')||'{}'),'sleep-optimizer':true}));return true;`);
  const loaded=await playReload({});assert.deepEqual(loaded.failed,[]);assert.ok(loaded.loaded.includes('sleep-optimizer'));
  await evaluate(`
    const d=WML.dev();d.store.get().newGame();let s=d.store.game();
    s={...s,slot:1529,day:1,phase:'bedroom',pendingEvent:undefined,activeScene:{},errandSession:undefined,customers:[]};
    s=d.fn('moveOccupant')(s,'player','bedroom');d.store.update(()=>s);s=d.fn('worldTick')(s,{playerPresent:false});d.store.update(()=>s);
    await new Promise(r=>setTimeout(r,100));
    const night=WML.use('sleep-optimizer');
    globalThis.SleepTest={d,night,base:structuredClone(d.store.game()),config:structuredClone(__waywardBrothelPublic.getConfig()),passed:[]};
    const p=SleepTest;p.seed=()=>{Date.now=()=>1793100000000;let seed=1138,uuid=0;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};crypto.randomUUID=()=>('00000000-0000-4000-8000-'+String(++uuid).padStart(12,'0'));d.fn('Ju')(1138);};
    p.restore=async(state=p.base)=>{Object.assign(__waywardBrothelPublic.getConfig(),structuredClone(p.config));__waywardBrothelPublic.getRuntime().clear();
      d.fn('store').setState({state:{...structuredClone(state),rngState:1138},undoStack:[],lastTurnSeq:0});night.invalidate();await new Promise(r=>setTimeout(r,100));p.seed();};
    p.enabled=enabled=>localStorage.setItem('wml.mod.sleep-optimizer',JSON.stringify({enabled}));
    p.equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);return true;
  `);
  console.log('PASS setup',loaded.loaded.length,'mods');
  const timing=await evaluate(`
    const p=SleepTest,d=p.d;
    await p.restore();p.enabled(false);d.store.dispatch({type:'sleep',underway:true});await new Promise(r=>setTimeout(r,100));
    p.underway=structuredClone(d.store.game());p.config=structuredClone(__waywardBrothelPublic.getConfig());
    p.seed();let t=performance.now();d.store.dispatch({type:'wait',until:'done'});p.before={state:structuredClone(d.store.game()),seed:d.fn('rN')(),ms:Math.round(performance.now()-t)};
    await p.restore(p.underway);p.enabled(true);let beats=0,heartbeat=setInterval(()=>beats++,16);t=performance.now();
    const pending=d.store.dispatch({type:'wait',until:'done'}),busy=p.night.busy();const done=await pending;clearInterval(heartbeat);
    p.after={state:structuredClone(d.store.game()),seed:d.fn('rN')(),ms:Math.round(performance.now()-t)};
    const differences=[];function diff(a,b,path){if(differences.length>5||p.equal(a,b))return;if(!a||!b||typeof a!=='object'||typeof b!=='object'){differences.push({path,before:a,after:b});return;}for(const key of new Set([...Object.keys(a),...Object.keys(b)]))diff(a[key],b[key],path+'.'+key);}diff(p.before.state,p.after.state,'state');
    return {before:p.before.ms,after:p.after.ms,busy,beats,undo:d.store.get().undoStack.length,same:p.equal(p.before.state,p.after.state),seed:p.before.seed===p.after.seed,differences,done:done?.reason,stats:p.night.stats()};
  `);
  console.log('TIMING',JSON.stringify(timing));assert.equal(timing.same,true);assert.equal(timing.seed,true);assert.equal(timing.undo,1);assert.equal(timing.busy,true);assert.ok(timing.beats>0);assert.equal(timing.done,'morning');
  results.push({name:'full night parity, one undo and responsive frames',value:timing});
  await check('one undo restores the full night start',`
    const p=SleepTest,d=p.d;d.store.get().undo();return {restored:p.equal(d.store.game(),{...p.underway,rngState:1138}),empty:d.store.get().undoStack.length===0,busy:!p.night.busy()};
  `);
  await check('direct sleep and partial wait preserve native results',`
    const p=SleepTest,d=p.d;await p.restore();p.enabled(false);let before=d.fn('reduceGameAction')(structuredClone(p.base),{type:'sleep'}),seed=d.fn('rN')();
    await p.restore();p.enabled(true);let after=d.fn('reduceGameAction')(structuredClone(p.base),{type:'sleep'});const direct=p.equal(before,after)&&seed===d.fn('rN')();
    await p.restore(p.underway);p.enabled(false);before=d.fn('reduceGameAction')(d.store.game(),{type:'wait',minutes:15});seed=d.fn('rN')();
    await p.restore(p.underway);p.enabled(true);after=d.fn('reduceGameAction')(d.store.game(),{type:'wait',minutes:15});
    return {direct,partial:p.equal(before,after),seed:seed===d.fn('rN')(),stillNight:after.errandSession?.reason==='night'};
  `);
  await check('pause, save and reload retain elapsed time and remaining sleep',`
    const p=SleepTest,d=p.d;await p.restore(p.underway);const promise=d.store.dispatch({type:'wait',until:'done'});
    setTimeout(()=>d.store.get().saveToSlot(2),50);const done=await promise,saved=structuredClone(d.store.game());
    const elapsed=saved.slot>p.underway.slot&&saved.slot<saved.errandSession.returnAtSlot;
    d.store.get().loadFromSlot(2);
    // 본편 저장기는 기본값을 생략하고 읽을 때 보완하므로 원래 슬롯 판독 결과와 비교합니다.
    const expected=d.fn('zet')(2);
    // NPC 재실 표시는 저장된 인물 위치를 읽어 다시 구성하는 파생 자료입니다.
    const persisted=value=>{const s=structuredClone(value);for(const room of Object.values(s.locations??{}))if(room.occupants)room.occupants=room.occupants.filter(id=>!String(id).startsWith('npc:['));return s;};
    const restored=p.equal(persisted(expected),persisted(d.store.game()));
    await d.store.dispatch({type:'wait',until:'done'});
    return {paused:done.reason==='paused',elapsed,restored,morning:d.store.game().phase==='prep',oneFinish:!d.store.game().errandSession&&d.store.game().slot===p.underway.errandSession.returnAtSlot};
  `);
  await check('undo during calculation commits once then restores the start',`
    const p=SleepTest,d=p.d;await p.restore(p.underway);const initial=structuredClone(d.store.game());const pending=d.store.dispatch({type:'wait',until:'done'});
    setTimeout(()=>d.store.get().undo(),50);await pending;return {restored:p.equal(initial,d.store.game()),empty:d.store.get().undoStack.length===0,stopped:!p.night.busy()};
  `);
  await evaluate(`
    const p=SleepTest,d=p.d;
    d.events.onAlert('sleep-test:wake',(state)=>({...state,mods:{...state.mods,sleepTest:{handled:(state.mods.sleepTest?.handled??0)+1}}}));
    p.inject=(kind,at=d.store.game().slot+3)=>{return d.hook('worldTick',{priority:-1900000,after(state){
      if(state.pmCore||state.__rivalTavernContext||state.slot!==at)return state;
      if(kind==='game-over')return {...state,gameOver:{reason:'test'}};
      return d.fn('queueAlert')(state,{id:'sleep-test:'+kind,kind:'sleep-test:wake',slot:state.slot,title:'수면 시험',body:'밤사이 확인할 일이 있습니다.',severity:kind==='info'?'info':'critical',pause:kind!=='info',choices:[{id:'ok',label:'확인'}]});
    }});};return true;
  `);
  await check('mandatory event pauses at its exact minute and resolves once',`
    const p=SleepTest,d=p.d;await p.restore(p.underway);const unhook=p.inject('mandatory'),start=d.store.game().slot;
    await d.store.dispatch({type:'wait',until:'done'});unhook();const stopped=d.store.game();
    const exact=stopped.slot===start+3,event=stopped.pendingEvent?.alert?.kind==='sleep-test:wake',retained=!!stopped.mods?.['sleep-optimizer']?.pendingNight?.session?.interrupted;
    d.store.get().saveToSlot(3);
    await new Promise(r=>setTimeout(r,50));
    const confirm=[...document.querySelectorAll('button')].find(b=>b.textContent.replaceAll('↵','').trim()==='확인'&&b.getClientRects().length);
    if(!confirm)throw Error('수면 사건 확인 버튼 없음: '+JSON.stringify({pending:d.store.game().pendingEvent,session:d.store.game().errandSession,visible:[...document.querySelectorAll('button')].filter(b=>b.getClientRects().length).map(b=>b.textContent.trim()).slice(-15)}));
    confirm.click();d.store.dispatch({type:'resolve_event',choiceId:'ok'});
    const once=d.store.game().mods.sleepTest.handled===1;d.store.dispatch({type:'errand_interrupt_continue'});await new Promise(r=>setTimeout(r,50));
    await d.store.dispatch({type:'wait',until:'done'});return {exact,event,retained,once,morning:d.store.game().phase==='prep'};
  `);
  await check('direct sleep preserves a wake event instead of clearing it',`
    const p=SleepTest,d=p.d;await p.restore();const unhook=p.inject('direct');d.store.dispatch({type:'sleep'});unhook();const s=d.store.game();
    const paused=s.mods?.['sleep-optimizer']?.pendingNight?.session;
    return {event:s.pendingEvent?.alert?.kind==='sleep-test:wake',exact:s.slot===p.base.slot+3,night:paused?.reason==='night',paused:!!paused?.interrupted};
  `);
  await check('event at the wake boundary is answered before morning settlement',`
    const p=SleepTest,d=p.d;await p.restore(p.underway);const target=d.store.game().errandSession.returnAtSlot,unhook=p.inject('wake-boundary',target);
    await d.store.dispatch({type:'wait',until:'done'});unhook();const held=d.store.game().slot===target&&!!d.store.game().pendingEvent&&d.store.game().phase==='bedroom';
    const eventId=d.store.game().pendingEvent.alert.id;d.store.dispatch({type:'wait',minutes:5});const protectedEvent=d.store.game().pendingEvent?.alert?.id===eventId;
    d.store.dispatch({type:'resolve_event',choiceId:'ok'});d.store.dispatch({type:'errand_interrupt_continue'});await new Promise(r=>setTimeout(r,50));await d.store.dispatch({type:'wait',until:'done'});
    return {held,protectedEvent,once:d.store.game().mods.sleepTest.handled===1,morning:d.store.game().phase==='prep',sameTime:d.store.game().slot===target};
  `);
  await check('informational alert does not pause and game over stops immediately',`
    const p=SleepTest,d=p.d;await p.restore(p.underway);let unhook=p.inject('info');await d.store.dispatch({type:'wait',until:'done'});unhook();const morning=d.store.game().phase==='prep';
    await p.restore(p.underway);unhook=p.inject('game-over');await d.store.dispatch({type:'wait',until:'done'});unhook();
    return {morning,over:!!d.store.game().gameOver,exact:d.store.game().slot===p.underway.slot+3,stopped:!p.night.busy()};
  `);
  await check('new game during calculation cancels the remaining job',`
    const p=SleepTest,d=p.d;await p.restore(p.underway);const pending=d.store.dispatch({type:'wait',until:'done'});setTimeout(()=>d.store.get().newGame(),50);await pending;
    await new Promise(r=>setTimeout(r,80));return {newDay:d.store.game().day===1,awake:!d.store.game().errandSession,stopped:!p.night.busy()};
  `);
  await check('night booking settles once with the same ledger and funds',`
    const p=SleepTest,d=p.d,house=WML.use('brothel-house'),estate=WML.use('real-estate');await p.restore();
    d.store.update(s=>({...s,phase:'prep',pendingEvent:undefined,activeScene:{},economy:{...s.economy,gold:30000,debt:0}}));
    d.store.dispatch({type:'brothel-house/debug-unlock',enabled:true});d.store.dispatch({type:'real-estate/buy',lot:'north'});
    d.store.dispatch({type:'real-estate/build',lot:'north',building:'brothel'});
    for(let i=0;i<4;i++)d.store.update(s=>estate.advanceProjects({...s,day:s.day+1}));await new Promise(r=>setTimeout(r,80));
    d.store.dispatch({type:'brothel-house/hire',tier:'ordinary',name:'수면 정산 확인 직원'});
    const workerId=house.residents(d.store.game())[0]?.[0];if(!workerId)throw Error('시험 창관 고용 실패');
    d.store.update(s=>house.write({...s,day:p.base.day,slot:p.base.slot,phase:'service',pendingEvent:undefined,activeScene:{}},
      {operation:{enabled:true,hours:[0,24],closedWeekdays:[]},patrons:[{id:'sleep-guest',name:'예약 손님',walletGold:100,charm:50,boldness:40,patronType:'regular',attributes:{strength:50,deftness:50,wit:50}}]}));
    d.store.dispatch({type:'brothel-house/start',workerId,customerId:'sleep-guest',service:'manual'});
    if(house.read(d.store.game()).sessions.length!==1)throw Error('시험 예약 시작 실패');
    d.store.update(s=>house.write({...s,phase:'bedroom'},{operation:{enabled:false,hours:[0,24],closedWeekdays:[]}}));
    d.store.dispatch({type:'sleep',underway:true});await new Promise(r=>setTimeout(r,100));
    const booked=structuredClone(d.store.game());p.config=structuredClone(__waywardBrothelPublic.getConfig());
    await p.restore(booked);p.enabled(false);d.store.dispatch({type:'wait',until:'done'});const before=d.store.game(),ledger=house.read(before).ledger,gold=before.economy.gold;
    await p.restore(booked);p.enabled(true);await d.store.dispatch({type:'wait',until:'done'});const after=d.store.game(),data=house.read(after);
    return {once:data.ledger.transactions===1,sameLedger:p.equal(ledger,data.ledger),sameGold:gold===after.economy.gold,finished:data.sessions.length===0,resident:house.residents(after).length===1};
  `);
  await evaluate(`const p=SleepTest;await p.restore(p.underway);p.enabled(true);p.visual=p.d.store.dispatch({type:'wait',until:'done'});return true;`);
  const profile=mobile?'mobile':'desktop';fs.writeFileSync('wml/mods/sleep-optimizer/tests/'+profile+'.jpg',Buffer.from(await playScreenshot({}),'base64'));
  await evaluate(`await SleepTest.visual;return true;`);
  assert.deepEqual((await playReload({})).failed,[]);
  await check('browser reload preserves a pending wake event and remaining night',`
    const d=WML.dev();d.events.onAlert('sleep-test:wake',state=>({...state,mods:{...state.mods,sleepTest:{handled:(state.mods.sleepTest?.handled??0)+1}}}));
    d.store.get().loadFromSlot(3);await new Promise(r=>setTimeout(r,100));
    const s=d.store.game(),target=s.mods?.['sleep-optimizer']?.pendingNight?.session?.returnAtSlot,retained=s.pendingEvent?.alert?.kind==='sleep-test:wake'&&target>s.slot;
    const button=[...document.querySelectorAll('button')].find(b=>b.textContent.replaceAll('↵','').trim()==='확인'&&b.getClientRects().length);
    if(!button)throw Error('복원한 사건의 선택지가 보이지 않습니다.');d.store.dispatch({type:'resolve_event',choiceId:s.pendingEvent.choices[0].id});const answered=d.store.game().mods.sleepTest.handled===1;
    d.store.dispatch({type:'errand_interrupt_continue'});await new Promise(r=>setTimeout(r,50));await d.store.dispatch({type:'wait',until:'done'});
    return {retained,answered,morning:d.store.game().phase==='prep',target:d.store.game().slot===target};
  `);
  await check('browser reload restores a saved partial night and completes it',`
    const d=WML.dev(),night=WML.use('sleep-optimizer');d.store.get().loadFromSlot(2);await new Promise(r=>setTimeout(r,100));
    const initial=d.store.game(),target=initial.errandSession?.returnAtSlot,remaining=initial.slot<target;
    await d.store.dispatch({type:'wait',until:'done'});return {remaining,morning:d.store.game().phase==='prep',target:d.store.game().slot===target,stopped:!night.busy()};
  `);
  const status=await playStatus({});assert.deepEqual(status.failed,[]);assert.deepEqual(status.pageErrors,[]);
  fs.writeFileSync('wml/mods/sleep-optimizer/tests/'+profile+'.json',JSON.stringify({profile,zip:process.argv.includes('--zip'),mods:loaded.loaded.length,results},null,2));
  console.log('PASS',profile,results.length,'scenarios');
}finally{await shutdown()}
process.exit(0);
