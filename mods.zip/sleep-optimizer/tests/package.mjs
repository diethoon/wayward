// Stable ID folders, numeric mod versions, and a separate pre7 package label.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import zlib from 'node:zlib';import assert from 'node:assert/strict';import {writeZip,checkZip} from '../../../tools/zip.mjs';
const readzip=file=>{var b=fs.readFileSync(file),out=[],i=0;while(i<b.length-30){if(b.readUInt32LE(i)!==0x04034b50)break;var method=b.readUInt16LE(i+8),size=b.readUInt32LE(i+18),nl=b.readUInt16LE(i+26),xl=b.readUInt16LE(i+28),name=b.subarray(i+30,i+30+nl).toString('utf8'),start=i+30+nl+xl,data=b.subarray(start,start+size);out.push({name,data:method===8?zlib.inflateRawSync(data):data});i=start+size;}if(!out.length)throw Error('No local entries '+file);return out;};
const definitions=[
  {
    "id": "sleep-optimizer",
    "files": [
      "files/controller.js",
      "files/night.js",
      "mod.js",
      "README.md"
    ]
  }
];
const hash=data=>crypto.createHash('sha256').update(data).digest('hex');
const results=[];for(const def of definitions){
 const dir=path.resolve('wml/mods',def.id),text=fs.readFileSync(path.join(dir,'mod.js'),'utf8').slice(fs.readFileSync(path.join(dir,'mod.js'),'utf8').indexOf('WML.define'));
 const version=text.match(/\bversion\s*:\s*['"]([^'"]+)/)[1],id=text.match(/\bid\s*:\s*['"]([^'"]+)/)[1];assert.equal(id,def.id);assert.match(version,/^\d+\.\d+\.\d+$/);
 const files=def.files.map(name=>({name:id+'/'+name,data:fs.readFileSync(path.join(dir,name))})),zip=path.join(dir,id+'-'+version+'-20261101.zip');
 if(fs.existsSync(zip)){const actual=readzip(zip);assert.equal(actual.length,files.length);for(const f of files)assert.deepEqual(actual.find(e=>e.name===f.name)?.data,f.data,'Existing release differs; increase mod version');}else writeZip(zip,files);
 assert.equal(checkZip(zip),files.length);const actual=readzip(zip);for(const f of files)assert.deepEqual(actual.find(e=>e.name===f.name)?.data,f.data);
 results.push({id,version,game:'2026-11-01',zip:path.basename(zip),bytes:fs.statSync(zip).size,sha256:hash(fs.readFileSync(zip)),files:files.map(f=>({name:f.name,sha256:hash(f.data)}))});
}

console.log(JSON.stringify(results,null,2));
