// 수면 최적화
// 이 파일은 WML MCP 의 mod_create 로 만든 뼈대예요. 설명서: wml/docs/SDK.md
WML.define({
  tags: ["util"],
  id: "sleep-optimizer",
  author: "Hina_Lover",
  name: "수면 최적화",
  version: "1.0.3",
  game: "2026-11-01",
  lang: "ko",
  description: "수면 중 불필요한 이미지 계산을 줄이고 밤 진행을 나눠 처리합니다.",
  loadAfter: ["imagestudio-compatible-attention-image-prompt","npc-simulator","rival_tavern","brothel-house-compatible-brothel","servant"],

  symbols: {
    "sleepImageLog": {"raw":{"2026-11-01":"kee"}},
    "sleepImageKey": {"raw":{"2026-11-01":"bee"}},
    "sleepNightPrepare": {"raw":{"2026-11-01":"Vee"}},
    "sleepBegin": {"raw":{"2026-11-01":"Kee"}},
    "sleepClear": {"raw":{"2026-11-01":"zee"}},
    "sleepDirect": {"raw":{"2026-11-01":"VS"}},
    "sleepAdvance": {"raw":{"2026-11-01":"dXe"}},
    "sleepWaitAll": {"raw":{"2026-11-01":"yW"}},
    "sleepWaitPart": {"raw":{"2026-11-01":"kXe"}},
    "sleepPartialMinutes": {"raw":{"2026-11-01":"G0"}},
    "sleepFinish": {"raw":{"2026-11-01":"c5"}},
    "sleepAppendAway": {"raw":{"2026-11-01":"XC"}},
    "sleepGetSeed": {"raw":{"2026-11-01":"rN"}},
    "sleepSetSeed": {"raw":{"2026-11-01":"Zf"}},
    "sleepNeedsChoice": {"raw":{"2026-11-01":"P_e"}},
    "sleepAlertValid": {"raw":{"2026-11-01":"O_e"}},
    "sleepGameAction": {"raw":{"2026-11-01":"gte"}}
  },
  async setup(api) {
    await api.loadScript('files/night.js');
    const night=globalThis.SleepOptimizer_create(api);
    await api.loadScript('files/controller.js');
    globalThis.SleepOptimizer_connect(api,night);
    api.provide(night);
  },
});
