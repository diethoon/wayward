// 긴 밤 진행은 원래 디스패치의 한 행동으로 확정하고, 계산 사이에는 브라우저에 제어를 돌려줍니다.
globalThis.SleepOptimizer_connect=function SleepOptimizer_connect(api,night){
  'use strict';
  const store=api.fn('store');
  let job=null,committing=false,windowHandle=null;
  function closeWindow(){const handle=windowHandle;windowHandle=null;handle?.close();}
  function eligible(action,state){return night.enabled()&&action?.type==='wait'&&action.until==='done'&&
    state?.errandSession?.reason==='night'&&!state.errandSession.interrupted&&!state.pendingEvent&&!state.gameOver&&
    Number.isSafeInteger(state.slot)&&Number.isSafeInteger(state.errandSession.returnAtSlot)&&
    !state.pendingRentNotice&&!state.pendingCollectorVisit&&state.collectorArrivalSlot==null;}
  function show(){
    if(!windowHandle)windowHandle=api.ui.window({id:'progress',title:'아침까지 자기',width:390,height:180,
      render(body){body.replaceChildren();if(!job)return;const h=api.ui.h;
        const elapsed=Math.max(0,job.run.state.slot-job.run.start),total=Math.max(1,job.run.target-job.run.start);
        body.append(h('p',null,'잠을 자는 중입니다…'),h('progress',{max:total,value:elapsed,style:'width:100%'}),
          api.ui.button('여기까지 자고 잠시 멈추기',()=>commit('paused')));},onClose(){windowHandle=null;if(job)commit('paused');}});
    else windowHandle.refresh();
  }
  function commit(reason){
    const current=job;if(!current)return;
    clearTimeout(current.timer);job=null;
    let result;
    try{
      if(reason==='paused'&&!current.run.stopped&&current.run.state.slot<current.run.target){current.run.stopped=true;current.run.reason='paused';}
      result=night.scope(()=>night.finish(current.run));const seed=night.seed();
      committing=true;night.setSeed(current.seed);
      night.setReplay({state:result,seed});current.dispatch(current.action);
      current.resolve({reason:current.run.reason??'morning',state:api.store.game(),stats:night.stats()});
    }catch(error){night.clearReplay();current.reject(error);throw error;}
    finally{committing=false;night.clearReplay();night.invalidate();closeWindow();}
  }
  function batch(){
    const current=job;if(!current)return;
    const start=performance.now(),boundary=night.nextBoundary(current.run);
    try{
      night.scope(()=>{let count=0;while(count++<24&&performance.now()-start<12&&current.run.state.slot<boundary&&night.step(current.run)){};});
      if(current.run.stopped||current.run.state.slot>=current.run.target){commit();return;}
      show();current.timer=setTimeout(batch,0);
    }catch(error){current.run.stopped=true;current.run.reason='error';try{commit('paused');}finally{console.error('[수면 최적화] 밤 진행 중단',error);}}
  }
  const previous=api.store.get().dispatch;
  function dispatch(action){
    if(committing)return previous(action);
    if(job)return;
    const state=api.store.game();if(!eligible(action,state))return previous(action);
    let resolve,reject;const done=new Promise((yes,no)=>{resolve=yes;reject=no;});done.catch(error=>console.error('[수면 최적화]',error));
    const proximityMode=api.fn('settingsStore').getState().proximityMode??false;
    job={action,state,dispatch:previous,seed:night.seed(),resolve,reject,done,run:night.createRun({...state,proximityMode}),timer:null};
    show();job.timer=setTimeout(batch,0);return done;
  }
  for(const key of Object.getOwnPropertyNames(previous))if(!['name','length','prototype','caller','arguments'].includes(key))
    Object.defineProperty(dispatch,key,Object.getOwnPropertyDescriptor(previous,key));
  api.store.set(root=>({...root,dispatch}));
  // 슬롯·불러오기·되돌리기 앞에서는 끝난 분까지 확정합니다. 중간 계산을 저장 자료에 숨기지 않습니다.
  for(const name of ['saveToSlot','loadFromSlot','undo','newGame','returnToTitle','importSaveFromJSON','exportSaveToFile','loadDayAutosave','resetAutosave']){
    const original=api.store.get()[name];if(typeof original!=='function')continue;
    api.store.set(root=>({...root,[name](...args){if(job)commit('paused');night.invalidate();return original.apply(this,args);}}));
  }
  const setState=store.setState;
  store.setState=function(...args){
    if(job&&!committing&&job.run.steps>0)commit('paused');
    const out=setState.apply(this,args);
    if(job&&!committing&&job.run.steps===0){
      const state=api.store.game();
      if(eligible(job.action,state)){const proximityMode=api.fn('settingsStore').getState().proximityMode??false;job.state=state;job.seed=night.seed();job.run=night.createRun({...state,proximityMode});}
      else {const current=job;job=null;clearTimeout(current.timer);current.resolve({reason:'state-changed',state});closeWindow();}
    }
    return out;
  };
  window.addEventListener('beforeunload',()=>{if(job)commit('paused');});
  api.onBack?.(()=>{if(!job)return false;commit('paused');return true;});
  night.pending=()=>job?.done??Promise.resolve(null);
  night.busy=()=>!!job;
  night.pause=()=>{if(job)commit('paused');};
  api.ui.settings(body=>{
    const input=api.ui.h('input',{type:'checkbox'});input.checked=night.enabled();
    input.onchange=()=>{if(job)commit('paused');api.settings.set({enabled:input.checked});night.invalidate();};
    body.append(api.ui.h('label',null,input,' 수면 최적화 사용'),api.ui.h('p',{class:'wml-note'},
      '밤사이 사건과 세계 진행을 유지하며, 불필요한 이미지 계산을 줄입니다. 아침까지 자기 도중에는 잠시 멈출 수 있습니다.'));
  });
};
