// 수면 중 표시 계산은 필요한 기록에만 적용하고, 실제 세계의 분 진행·난수 소비는 보존합니다.
globalThis.SleepOptimizer_create=function SleepOptimizer_create(api){
  'use strict';
  const fn=name=>api.fn(name),settings=()=>api.settings.get({enabled:true});
  const sleeping=s=>s?.player?.asleepSinceSlot!=null||s?.errandSession?.reason==='night';
  let depth=0,logDepth=0,display=null,last=null,replay=null;
  const stats=()=>last||(last={minutes:0,imageLogsSkipped:0});
  function scope(run){
    depth++;try{return run();}finally{depth--;}
  }
  function hasRecord(before,after){
    const start=before.logSeq??0;
    return [after.log,after.awayEvents].some(rows=>{
      for(let i=(rows?.length??0)-1;i>=0;i--){const seq=rows[i].seq;
        if(seq!=null&&seq<start)break;
        if(seq!=null)return true;
      }return false;
    });
  }
  api.hook('sleepImageLog',{priority:-2000000,around(next,before,after){
    if(!settings().enabled||!(depth||sleeping(after)))return next(before,after);
    if(!hasRecord(before,after)){stats().imageLogsSkipped++;return after;}
    logDepth++;try{return next(before,after);}finally{logDepth--;}
  }});
  api.hook('sleepImageKey',{priority:-2000000,around(next,state){
    if(!settings().enabled||!sleeping(state)||state.pendingEvent){display=null;return next(state);}
    if(logDepth)return next(state);
    const key=[state.primaryCharacterId,state.errandSession?.startSlot??state.player.asleepSinceSlot].join(':');
    if(display?.id===key)return display.value;
    const value=next(state);display={id:key,value};return value;
  }});
  function actionable(state){
    return (state.alertQueue??[]).some(alert=>fn('sleepNeedsChoice')(alert)&&fn('sleepAlertValid')(state,alert));
  }
  function interruption(state,run){
    if(state.gameOver)return state;
    if(!state.pendingEvent&&!actionable(state))return null;
    const session=state.errandSession??{reason:'night',startSlot:run.start,returnAtSlot:run.target};
    let next=state;
    if(!next.pendingEvent)next=fn('drainAlerts')({...next,errandSession:undefined});
    if(!next.pendingEvent)return null;
    const interrupted=session.interrupted??{text:'확인할 일을 마쳤습니다. 원하면 남은 잠을 이어갈 수 있습니다.',slot:next.slot};
    return {...next,errandSession:undefined,mods:{...next.mods,'sleep-optimizer':{...next.mods?.['sleep-optimizer'],
      pendingNight:{phase:next.phase,session:{...session,interrupted}}}}};
  }
  function createRun(state,{direct=false,options={},target,prepared,maxMinutes}={}){
    last={minutes:0,imageLogsSkipped:0};
    let current=state;
    if(direct){prepared=fn('sleepNightPrepare')(state,options);current=fn('sleepBegin')(prepared.state);target=prepared.wakeSlot;}
    else target=state.errandSession.returnAtSlot;
    if(!direct&&current.activeScene?.patron?.playerEngaged)current={...current,activeScene:{...current.activeScene,patron:{...current.activeScene.patron,playerEngaged:false}}};
    const limit=maxMinutes==null?target:Math.min(target,current.slot+maxMinutes);
    const run={state:current,start:current.slot,target,limit,direct,prepared,options,awayStart:current.awayEvents.length,
      steps:0,stopped:false,finished:false,reason:null,original:state};
    const stop=interruption(current,run);
    if(stop){run.state=stop;run.stopped=true;run.reason='event';}
    return run;
  }
  function nextBoundary(run){
    // 기존 모드의 확률 추첨을 보존하므로 경계까지의 내부 진행에는 원래 worldTick을 씁니다.
    const s=run.state,candidates=[run.target,Math.floor(s.slot/60+1)*60];
    for(const data of Object.values(s.mods??{}))if(data&&typeof data==='object'){
      for(const item of Array.isArray(data.sessions)?data.sessions:[])if(Number.isSafeInteger(item.dueSlot)&&item.dueSlot>s.slot)candidates.push(item.dueSlot);
    }
    return Math.min(...candidates.filter(value=>value>s.slot));
  }
  function step(run){
    if(run.stopped||run.finished||run.state.slot>=run.limit)return false;
    const before=run.state;
    const ctx=run.direct?{playerPresent:false}:{playerPresent:false,errandSession:before.errandSession};
    let s=fn('worldTick')(before,ctx);run.steps++;stats().minutes++;
    const stop=interruption(s,run);
    if(stop){run.state=stop;run.stopped=true;run.reason=s.gameOver?'game-over':'event';return false;}
    if(s.errandSession?.interrupted){run.state=s;run.stopped=true;run.reason='interrupted';return false;}
    if(s.slot<=before.slot){run.state=s;run.stopped=true;run.reason='no-progress';return false;}
    if(!run.direct&&!s.errandSession){run.state=s;run.stopped=true;run.reason='session-ended';return false;}
    run.state=s;return true;
  }
  function finish(run){
    if(run.finished)return run.result;
    let s=run.state;
    if(!run.direct)s=fn('sleepAppendAway')(s,run.awayStart);
    if(!run.stopped&&s.slot>=run.target){
      if(run.direct){s=fn('sleepClear')(s);s=fn('wakeUp')(s,run.prepared,run.options);}
      else if(s.errandSession)s=fn('sleepFinish')(s);
    }
    run.finished=true;run.result=s;return s;
  }
  function complete(run){return scope(()=>{while(step(run)){}return finish(run);});}
  api.hook('sleepDirect',{priority:-2000000,around(next,state,options={}){
    if(!settings().enabled||state.phase!=='bedroom'||options.awayOvernight)return next(state,options);
    return complete(createRun(state,{direct:true,options}));
  }});
  api.hook('sleepWaitAll',{priority:-2000000,around(next,state,options={}){
    if(replay){const result=replay;replay=null;fn('sleepSetSeed')(result.seed);return result.state;}
    if(!settings().enabled||state.errandSession?.reason!=='night'||state.errandSession.interrupted)return next(state,options);
    return complete(createRun(state,{options}));
  }});
  api.hook('sleepWaitPart',{priority:-2000000,around(next,state,options={}){
    if(!settings().enabled||state.errandSession?.reason!=='night'||state.errandSession.interrupted)return next(state,options);
    return complete(createRun(state,{options,maxMinutes:Math.max(1,Math.round(options.minutes??fn('sleepPartialMinutes')))}));
  }});
  // 사건 응답 중에는 본편의 선택지/단축키를 그대로 사용합니다.
  // 마지막 응답이 끝난 뒤에만 남은 밤을 원래 '계속하기' 세션으로 되돌립니다.
  api.hook('sleepGameAction',{priority:2000000,around(next,state,action,...args){
    const paused=state.mods?.['sleep-optimizer']?.pendingNight;
    if(!paused)return next(state,action,...args);
    if(state.pendingEvent&&!['resolve_event','wife_topic','scene_action','patron_interaction_choice','set_demeanor','set_dare_reason'].includes(action.type))return state;
    let result=next(state,action,...args);
    const scene=result.activeScene??{};
    if(result.pendingEvent||scene.sex||scene.patron?.playerEngaged||scene.npcSimulatorConversation)return result;
    const own={...result.mods?.['sleep-optimizer']};delete own.pendingNight;
    result={...result,mods:{...result.mods,'sleep-optimizer':own}};
    return !result.errandSession&&!result.gameOver&&result.phase===paused.phase&&result.player.asleepSinceSlot!=null
      ?{...result,errandSession:paused.session}:result;
  }});
  return {version:1,enabled:()=>settings().enabled!==false,sleeping,scope,createRun,step,finish,complete,nextBoundary,
    stats:()=>({...stats()}),setReplay:value=>{replay=value;},clearReplay:()=>{replay=null;},
    seed:()=>fn('sleepGetSeed')(),setSeed:value=>fn('sleepSetSeed')(value),invalidate:()=>{display=null;}};
};
