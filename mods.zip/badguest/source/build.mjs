// 실행: node wml/mods/<모드>/source/build.mjs
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
const dir=path.dirname(fileURLToPath(import.meta.url));
const text='// 생성 파일. 수정: source/mod.wml.js, source/native-ui.js — 재생성: node '+path.relative(process.cwd(),path.join(dir,'build.mjs')).replaceAll('\\','/')+'\n'+fs.readFileSync(path.join(dir,'native-ui.js'),'utf8')+'\n'+fs.readFileSync(path.join(dir,'mod.wml.js'),'utf8');
new vm.Script(text);
fs.writeFileSync(path.join(dir,'../mod.js'),text);
console.log('Generated '+path.join(dir,'../mod.js'));
