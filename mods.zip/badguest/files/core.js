(() => {
  'use strict';

  const MOD_ID = 'BadGuest';
  const VERSION = '1.4.1';
  const PUBLIC_API_VERSION = 5;
  const LOADED = '__WAYWARD_BAD_GUEST_LOADED__';
  const DATA_KEY = 'BadGuest';
  const WML_DATA_KEY = 'badguest';
  const APPROACH_ID = 'calculated_coercion';
  const BASE_BAD_GUEST_CUNNING = 74.8;
  const CONFUSION_MEMORY_LIMIT = 200;
  const CONFUSION_RECOVERY_LIMIT = 200;
  const APHRODISIAC_MEMORY_LIMIT = 200;
  const CONFUSION_TRUST_BONUS_PERCENT = 20;
  const EQUIPMENT_FEAR_INTENSITY = Object.freeze({ restraint: 58, blindfold: 22, gag: 26 });
  const SLEEP_ACTIONS_OWNER_ID = 'badguest';
  const SLEEP_ACTIONS_WAKE_OBSERVER_ID = 'badguest:wake-refusal';
  const SLEEP_ACTIONS_SEARCH_RESOLVER_ID = 'badguest:shared-sighting';
  const BAD_GUEST_PATTERNS = Object.freeze({
    enforcer: Object.freeze({
      id: 'enforcer',
      label: '\uC81C\uC555\uD615',
      drugAction: 'drug',
      handcuffAttemptMultiplier: 1,
      blindfoldWeight: 4,
      backRoomWeight: 8,
      doorLockWeight: 5
    }),
    lurer: Object.freeze({
      id: 'lurer',
      label: '\uC720\uC778\uD615',
      drugAction: 'intoxication_drug',
      handcuffAttemptMultiplier: 0.7,
      blindfoldWeight: 2,
      backRoomWeight: 10,
      doorLockWeight: 6
    }),
    infiltrator: Object.freeze({
      id: 'infiltrator',
      label: '\uC7A0\uC785\uD615',
      drugAction: 'sleep_drug',
      handcuffAttemptMultiplier: 0.7,
      blindfoldWeight: 2,
      backRoomWeight: 7,
      doorLockWeight: 7
    }),
    impostor: Object.freeze({
      id: 'impostor',
      label: '\uAC00\uC7A5\uD615',
      drugAction: 'confusion_drug',
      handcuffAttemptMultiplier: 0.7,
      blindfoldWeight: 7,
      backRoomWeight: 10,
      doorLockWeight: 4
    })
  });
  const CONFUSION_FIRST_CATEGORY = Object.freeze({
    groping: 'groping',
    intimate: 'under_her_clothes',
    handjob_patron: 'her_hand',
    blowjob_patron: 'her_mouth',
    sex_patron: 'sex'
  });
  const CONFUSION_ACT_CATEGORY = Object.freeze({
    groping: 'groping',
    intimate: 'intimate',
    fingering: 'intimate',
    handjob: 'handjob_patron',
    blowjob: 'blowjob_patron',
    rubbing: 'rubbing_patron',
    thigh_job: 'rubbing_patron',
    sex: 'sex_patron',
    riding: 'sex_patron',
    anal: 'sex_patron',
    breast_worship: 'touch_breasts',
    cum_on_body: 'cum_on_skin',
    cum_on_face: 'cum_on_face'
  });
  const CONFUSION_RECEPTION_KEYS = Object.freeze({
    eager: 'badguest_confused_eager',
    willing: 'badguest_confused_willing',
    hesitant: 'badguest_confused_hesitant',
    reluctant: 'badguest_confused_reluctant',
    paid: 'badguest_confused_paid',
    forced: 'badguest_confused_forced'
  });
  const APHRODISIAC_RECEPTION_KEYS = Object.freeze({
    eager: 'badguest_aphrodisiac_eager',
    willing: 'badguest_aphrodisiac_willing',
    hesitant: 'badguest_aphrodisiac_hesitant',
    reluctant: 'badguest_aphrodisiac_reluctant',
    paid: 'badguest_aphrodisiac_paid',
    forced: 'badguest_aphrodisiac_forced'
  });
  const CONFUSION_AFTERMATH_ACTION = Object.freeze({
    bold_touch: 'bold_touch',
    groping: 'groping',
    intimate: 'fingering',
    handjob_patron: 'handjob',
    blowjob_patron: 'blowjob',
    rubbing_patron: 'thigh_job',
    sex_patron: 'sex'
  });
  const CONFUSION_ACTION_AFFINITIES = Object.freeze({
    bold_touch: Object.freeze([]),
    groping: Object.freeze([]),
    fingering: Object.freeze(['vaginal']),
    handjob: Object.freeze(['submission']),
    blowjob: Object.freeze(['oral', 'submission']),
    thigh_job: Object.freeze(['submission']),
    sex: Object.freeze(['vaginal', 'romantic']),
    riding: Object.freeze(['vaginal', 'domination']),
    anal: Object.freeze(['anal', 'submission'])
  });
  const api = globalThis.__WAYWARD_ADDON_API__;

  const DEFAULT_SETTINGS = Object.freeze({
    schemaVersion: 13,
    sleepPotionDepartureDelayMin: 8,
    sleepPotionDepartureDelayMax: 24,
    sleepPotionGuestRoomChance: 25,
    drugMaxAcceptanceBonus: 150,
    drugRampMinutes: 30,
    drugPlateauMinutes: 120,
    drugFallMinutes: 30,
    checkBaseChances: Object.freeze({
      wifeDrugNotice: 45,
      wifeDrugRefusal: 70,
      husbandNotice: 50,
      wifeBackRoomNotice: 80,
      wifeBackRoomRefusal: 80,
      handcuffGuestSuccess: 75,
      handcuffEscapeSuccess: 25,
      groupDrugNotice: 50,
      groupPressureResistance: 50,
      groupStrengthResistance: 50,
      groupHandcuffGuestSuccess: 50,
      doorBreakAt50: 21.5
    }),
    checkPointIncrements: Object.freeze({
      wifeDrugNotice: 0.6,
      wifeDrugRefusal: 0.6,
      husbandNotice: 1.6667,
      wifeBackRoomNotice: 0.5,
      wifeBackRoomRefusal: 0.5,
      handcuffGuestSuccess: 0.5,
      handcuffEscapeSuccess: 0.5,
      groupDrugNotice: 1.6667,
      groupPressureResistance: 1.6667,
      groupStrengthResistance: 1.6667,
      groupHandcuffGuestSuccess: 0.5,
      doorBreakAt50: 0.23
    }),
    activeActionChance: 10,
    refusalHandcuffChance: 22,
    ambientDrugChancePerMinute: 1,
    ambientBackRoomChancePerMinute: 0.8,
    rehandcuffChancePerMinute: 16.75,
    selfLockMaxChancePerMinute: 33,
    actionCooldownMinutes: 8,
    drugActionCooldownMinutes: 30,
    backRoomActionCooldownMinutes: 30,
    specialActionWeights: Object.freeze({
      drug: 6,
      sleepDrug: 4,
      intoxicationDrug: 4,
      confusionDrug: 4,
      aggressiveDeception: 5,
      blindfold: 3,
      gag: 3,
      backRoomPretext: 6,
      doorLock: 5
    }),
    patternWeights: Object.freeze({
      enforcer: 30,
      lurer: 30,
      infiltrator: 20,
      impostor: 20
    }),
    nonEnforcerHandcuffMultiplierPercent: 70,
    intoxicationDurationMinutes: 120,
    lurerFinishDelayMinutes: 12,
    lurerFinishWeight: 3,
    lurerFinishMinRefusal: 75,
    lurerFinishMaxRefusal: 95,
    cooperativeIncidentMovementEnabled: true,
    sharedIncidentTrackingEnabled: true,
    sleepWakeRefusalHandcuffsEnabled: true,
    confusionExpiryRefusalHandcuffsEnabled: true,
    wealthyPartyDailyChance: 5,
    drinkingGameVisitChance: 30,
    spawnChance: 10,
    showBadGuestMarkers: false,
    debugProbabilityPanel: false
  });

  function settingNumber(value, fallback, min, max) {
    const parsed = Number(value);
    return Math.max(min, Math.min(max, Number.isFinite(parsed) ? parsed : fallback));
  }

  function normalizeSettings(raw = {}) {
    const source = { ...raw };
    if ((Number(source.schemaVersion) || 1) < 2) {
      if (source.activeActionChance === 30) source.activeActionChance = DEFAULT_SETTINGS.activeActionChance;
      if (source.ambientDrugChancePerMinute === 1.2) source.ambientDrugChancePerMinute = DEFAULT_SETTINGS.ambientDrugChancePerMinute;
      if (source.ambientBackRoomChancePerMinute === 1.2) source.ambientBackRoomChancePerMinute = DEFAULT_SETTINGS.ambientBackRoomChancePerMinute;
      if (source.rehandcuffChancePerMinute === 28) source.rehandcuffChancePerMinute = DEFAULT_SETTINGS.rehandcuffChancePerMinute;
    }
    const checks = { ...(source.checkBaseChances || {}) };
    if ((Number(source.schemaVersion) || 1) < 4) {
      if (checks.handcuffGuestSuccess === 50) checks.handcuffGuestSuccess = DEFAULT_SETTINGS.checkBaseChances.handcuffGuestSuccess;
      if (checks.handcuffEscapeSuccess === 50) checks.handcuffEscapeSuccess = DEFAULT_SETTINGS.checkBaseChances.handcuffEscapeSuccess;
    }
    if ((Number(source.schemaVersion) || 1) < 5
      && checks.handcuffGuestSuccess === 30) {
      checks.handcuffGuestSuccess = DEFAULT_SETTINGS.checkBaseChances.handcuffGuestSuccess;
    }
    if ((Number(source.schemaVersion) || 1) < 6) {
      if (checks.handcuffGuestSuccess === 70) checks.handcuffGuestSuccess = DEFAULT_SETTINGS.checkBaseChances.handcuffGuestSuccess;
      if (checks.handcuffEscapeSuccess === 30) checks.handcuffEscapeSuccess = DEFAULT_SETTINGS.checkBaseChances.handcuffEscapeSuccess;
    }
    if ((Number(source.schemaVersion) || 1) < 7) {
      if (checks.wifeDrugNotice === 50) checks.wifeDrugNotice = DEFAULT_SETTINGS.checkBaseChances.wifeDrugNotice;
      if (checks.wifeDrugRefusal === 85) checks.wifeDrugRefusal = DEFAULT_SETTINGS.checkBaseChances.wifeDrugRefusal;
      if (checks.wifeBackRoomNotice === 85) checks.wifeBackRoomNotice = DEFAULT_SETTINGS.checkBaseChances.wifeBackRoomNotice;
      if (checks.handcuffGuestSuccess === 80) checks.handcuffGuestSuccess = DEFAULT_SETTINGS.checkBaseChances.handcuffGuestSuccess;
      if (checks.handcuffEscapeSuccess === 20) checks.handcuffEscapeSuccess = DEFAULT_SETTINGS.checkBaseChances.handcuffEscapeSuccess;
      if (source.activeActionChance === 24) source.activeActionChance = DEFAULT_SETTINGS.activeActionChance;
      if (source.ambientDrugChancePerMinute === 4.5) source.ambientDrugChancePerMinute = DEFAULT_SETTINGS.ambientDrugChancePerMinute;
      if (source.ambientBackRoomChancePerMinute === 3.5) source.ambientBackRoomChancePerMinute = DEFAULT_SETTINGS.ambientBackRoomChancePerMinute;
    }
    const weights = source.specialActionWeights || {};
    const rawPatternWeights = source.patternWeights || {};
    const patternWeights = {
      enforcer: settingNumber(rawPatternWeights.enforcer, DEFAULT_SETTINGS.patternWeights.enforcer, 0, 100),
      lurer: settingNumber(rawPatternWeights.lurer, DEFAULT_SETTINGS.patternWeights.lurer, 0, 100),
      infiltrator: settingNumber(rawPatternWeights.infiltrator, DEFAULT_SETTINGS.patternWeights.infiltrator, 0, 100),
      impostor: settingNumber(rawPatternWeights.impostor, DEFAULT_SETTINGS.patternWeights.impostor, 0, 100)
    };
    if (Object.values(patternWeights).every(value => value <= 0)) {
      Object.assign(patternWeights, DEFAULT_SETTINGS.patternWeights);
    }
    const lurerFinishMinRefusal = settingNumber(
      source.lurerFinishMinRefusal,
      DEFAULT_SETTINGS.lurerFinishMinRefusal,
      0,
      100
    );
    const lurerFinishMaxRefusal = Math.max(
      lurerFinishMinRefusal,
      settingNumber(source.lurerFinishMaxRefusal, DEFAULT_SETTINGS.lurerFinishMaxRefusal, 0, 100)
    );
    const increments = source.checkPointIncrements || {};
    return {
      schemaVersion: DEFAULT_SETTINGS.schemaVersion,
      drugMaxAcceptanceBonus: settingNumber(source.drugMaxAcceptanceBonus, DEFAULT_SETTINGS.drugMaxAcceptanceBonus, 0, 500),
      drugRampMinutes: settingNumber(source.drugRampMinutes, DEFAULT_SETTINGS.drugRampMinutes, 1, 240),
      drugPlateauMinutes: settingNumber(source.drugPlateauMinutes, DEFAULT_SETTINGS.drugPlateauMinutes, 0, 480),
      drugFallMinutes: settingNumber(source.drugFallMinutes, DEFAULT_SETTINGS.drugFallMinutes, 1, 240),
      sleepPotionDepartureDelayMin: settingNumber(source.sleepPotionDepartureDelayMin, DEFAULT_SETTINGS.sleepPotionDepartureDelayMin, 0, 240),
      sleepPotionDepartureDelayMax: settingNumber(source.sleepPotionDepartureDelayMax, DEFAULT_SETTINGS.sleepPotionDepartureDelayMax, 0, 240),
      sleepPotionGuestRoomChance: settingNumber(source.sleepPotionGuestRoomChance, DEFAULT_SETTINGS.sleepPotionGuestRoomChance, 0, 100),
      checkBaseChances: {
        wifeDrugNotice: settingNumber(checks.wifeDrugNotice, DEFAULT_SETTINGS.checkBaseChances.wifeDrugNotice, 0, 100),
        wifeDrugRefusal: settingNumber(checks.wifeDrugRefusal, DEFAULT_SETTINGS.checkBaseChances.wifeDrugRefusal, 0, 100),
        husbandNotice: settingNumber(checks.husbandNotice, DEFAULT_SETTINGS.checkBaseChances.husbandNotice, 0, 100),
        wifeBackRoomNotice: settingNumber(checks.wifeBackRoomNotice, DEFAULT_SETTINGS.checkBaseChances.wifeBackRoomNotice, 0, 100),
        wifeBackRoomRefusal: settingNumber(checks.wifeBackRoomRefusal, DEFAULT_SETTINGS.checkBaseChances.wifeBackRoomRefusal, 0, 100),
        handcuffGuestSuccess: settingNumber(checks.handcuffGuestSuccess, DEFAULT_SETTINGS.checkBaseChances.handcuffGuestSuccess, 0, 100),
        handcuffEscapeSuccess: settingNumber(checks.handcuffEscapeSuccess, DEFAULT_SETTINGS.checkBaseChances.handcuffEscapeSuccess, 0, 100),
        groupDrugNotice: settingNumber(checks.groupDrugNotice, DEFAULT_SETTINGS.checkBaseChances.groupDrugNotice, 0, 100),
        groupPressureResistance: settingNumber(checks.groupPressureResistance, DEFAULT_SETTINGS.checkBaseChances.groupPressureResistance, 0, 100),
        groupStrengthResistance: settingNumber(checks.groupStrengthResistance, DEFAULT_SETTINGS.checkBaseChances.groupStrengthResistance, 0, 100),
        groupHandcuffGuestSuccess: settingNumber(checks.groupHandcuffGuestSuccess, DEFAULT_SETTINGS.checkBaseChances.groupHandcuffGuestSuccess, 0, 100),
        doorBreakAt50: settingNumber(checks.doorBreakAt50, DEFAULT_SETTINGS.checkBaseChances.doorBreakAt50, 0, 100)
      },
      checkPointIncrements: {
        wifeDrugNotice: settingNumber(increments.wifeDrugNotice, DEFAULT_SETTINGS.checkPointIncrements.wifeDrugNotice, 0, 5),
        wifeDrugRefusal: settingNumber(increments.wifeDrugRefusal, DEFAULT_SETTINGS.checkPointIncrements.wifeDrugRefusal, 0, 5),
        husbandNotice: settingNumber(increments.husbandNotice, DEFAULT_SETTINGS.checkPointIncrements.husbandNotice, 0, 5),
        wifeBackRoomNotice: settingNumber(increments.wifeBackRoomNotice, DEFAULT_SETTINGS.checkPointIncrements.wifeBackRoomNotice, 0, 5),
        wifeBackRoomRefusal: settingNumber(increments.wifeBackRoomRefusal, DEFAULT_SETTINGS.checkPointIncrements.wifeBackRoomRefusal, 0, 5),
        handcuffGuestSuccess: settingNumber(increments.handcuffGuestSuccess, DEFAULT_SETTINGS.checkPointIncrements.handcuffGuestSuccess, 0, 5),
        handcuffEscapeSuccess: settingNumber(increments.handcuffEscapeSuccess, DEFAULT_SETTINGS.checkPointIncrements.handcuffEscapeSuccess, 0, 5),
        groupDrugNotice: settingNumber(increments.groupDrugNotice, DEFAULT_SETTINGS.checkPointIncrements.groupDrugNotice, 0, 5),
        groupPressureResistance: settingNumber(increments.groupPressureResistance, DEFAULT_SETTINGS.checkPointIncrements.groupPressureResistance, 0, 5),
        groupStrengthResistance: settingNumber(increments.groupStrengthResistance, DEFAULT_SETTINGS.checkPointIncrements.groupStrengthResistance, 0, 5),
        groupHandcuffGuestSuccess: settingNumber(increments.groupHandcuffGuestSuccess, DEFAULT_SETTINGS.checkPointIncrements.groupHandcuffGuestSuccess, 0, 5),
        doorBreakAt50: settingNumber(increments.doorBreakAt50, DEFAULT_SETTINGS.checkPointIncrements.doorBreakAt50, 0, 5)
      },
      activeActionChance: settingNumber(source.activeActionChance, DEFAULT_SETTINGS.activeActionChance, 0, 100),
      refusalHandcuffChance: settingNumber(source.refusalHandcuffChance, DEFAULT_SETTINGS.refusalHandcuffChance, 0, 100),
      ambientDrugChancePerMinute: settingNumber(source.ambientDrugChancePerMinute, DEFAULT_SETTINGS.ambientDrugChancePerMinute, 0, 100),
      ambientBackRoomChancePerMinute: settingNumber(source.ambientBackRoomChancePerMinute, DEFAULT_SETTINGS.ambientBackRoomChancePerMinute, 0, 100),
      rehandcuffChancePerMinute: settingNumber(source.rehandcuffChancePerMinute, DEFAULT_SETTINGS.rehandcuffChancePerMinute, 0, 100),
      selfLockMaxChancePerMinute: settingNumber(source.selfLockMaxChancePerMinute, DEFAULT_SETTINGS.selfLockMaxChancePerMinute, 0, 100),
      actionCooldownMinutes: settingNumber(source.actionCooldownMinutes, DEFAULT_SETTINGS.actionCooldownMinutes, 0, 60),
      drugActionCooldownMinutes: settingNumber(source.drugActionCooldownMinutes, DEFAULT_SETTINGS.drugActionCooldownMinutes, 0, 240),
      backRoomActionCooldownMinutes: settingNumber(source.backRoomActionCooldownMinutes, DEFAULT_SETTINGS.backRoomActionCooldownMinutes, 0, 240),
      specialActionWeights: {
        drug: settingNumber(weights.drug, DEFAULT_SETTINGS.specialActionWeights.drug, 0, 100),
        sleepDrug: settingNumber(weights.sleepDrug, DEFAULT_SETTINGS.specialActionWeights.sleepDrug, 0, 100),
        intoxicationDrug: settingNumber(weights.intoxicationDrug, DEFAULT_SETTINGS.specialActionWeights.intoxicationDrug, 0, 100),
        confusionDrug: settingNumber(weights.confusionDrug, DEFAULT_SETTINGS.specialActionWeights.confusionDrug, 0, 100),
        aggressiveDeception: settingNumber(weights.aggressiveDeception, DEFAULT_SETTINGS.specialActionWeights.aggressiveDeception, 0, 100),
        blindfold: settingNumber(weights.blindfold, DEFAULT_SETTINGS.specialActionWeights.blindfold, 0, 100),
        gag: settingNumber(weights.gag, DEFAULT_SETTINGS.specialActionWeights.gag, 0, 100),
        backRoomPretext: settingNumber(weights.backRoomPretext, DEFAULT_SETTINGS.specialActionWeights.backRoomPretext, 0, 100),
        doorLock: settingNumber(weights.doorLock, DEFAULT_SETTINGS.specialActionWeights.doorLock, 0, 100)
      },
      patternWeights,
      nonEnforcerHandcuffMultiplierPercent: settingNumber(
        source.nonEnforcerHandcuffMultiplierPercent,
        DEFAULT_SETTINGS.nonEnforcerHandcuffMultiplierPercent,
        0,
        100
      ),
      intoxicationDurationMinutes: settingNumber(
        source.intoxicationDurationMinutes,
        DEFAULT_SETTINGS.intoxicationDurationMinutes,
        1,
        480
      ),
      lurerFinishDelayMinutes: settingNumber(
        source.lurerFinishDelayMinutes,
        DEFAULT_SETTINGS.lurerFinishDelayMinutes,
        0,
        240
      ),
      lurerFinishWeight: settingNumber(
        source.lurerFinishWeight,
        DEFAULT_SETTINGS.lurerFinishWeight,
        0,
        100
      ),
      lurerFinishMinRefusal,
      lurerFinishMaxRefusal,
      cooperativeIncidentMovementEnabled: source.cooperativeIncidentMovementEnabled !== false,
      sharedIncidentTrackingEnabled: source.sharedIncidentTrackingEnabled !== false,
      sleepWakeRefusalHandcuffsEnabled: source.sleepWakeRefusalHandcuffsEnabled !== false,
      confusionExpiryRefusalHandcuffsEnabled: source.confusionExpiryRefusalHandcuffsEnabled !== false,
      wealthyPartyDailyChance: settingNumber(source.wealthyPartyDailyChance, DEFAULT_SETTINGS.wealthyPartyDailyChance, 0, 100),
      drinkingGameVisitChance: settingNumber(source.drinkingGameVisitChance, DEFAULT_SETTINGS.drinkingGameVisitChance, 0, 100),
      spawnChance: settingNumber(source.spawnChance, DEFAULT_SETTINGS.spawnChance, 0, 100),
      showBadGuestMarkers: source.showBadGuestMarkers === true,
      debugProbabilityPanel: source.debugProbabilityPanel === true
    };
  }

  function loadGlobalSettings() {
    try {
      return normalizeSettings(api?.settings?.get?.({}) || {});
    } catch (error) {
      console.warn(`[${MOD_ID}] Failed to read global settings`, error);
      return normalizeSettings();
    }
  }

  let settings = loadGlobalSettings();

  if (globalThis[LOADED]) return;

  const store = api?.state?.gameStore;
  const getSleepActions = typeof api?.integrations?.getSleepActions === 'function'
    ? api.integrations.getSleepActions : () => null;
  const getHerDebtDebt = typeof api?.integrations?.getHerDebtDebt === 'function'
    ? api.integrations.getHerDebtDebt : () => null;
  const getQualifiedExperience = typeof api?.integrations?.getQualifiedExperience === 'function'
    ? api.integrations.getQualifiedExperience : () => null;

  function sleepActionsAvailable() {
    const service = getSleepActions();
    return Boolean(
      service
      && typeof service.session?.addDepth === 'function'
      && typeof service.patron?.scheduleApproach === 'function'
      && typeof service.patron?.registerFlowOwner === 'function'
      && typeof service.wake?.applyPatronResponse === 'function'
    );
  }

  function shortenBadGuestSleepCooldowns(state) {
    const patron = getSleepActions()?.patron;
    if (typeof patron?.cooldownStatus !== 'function'
      || typeof patron?.setCooldown !== 'function'
      || typeof patron?.setNextCooldown !== 'function') return state;
    let out = state;
    const activeSleepScene = Boolean(state.activeScene?.patron?.sleepActionsStage);
    for (const customer of state.customers || []) {
      if (!isBadGuest(out, customer)) continue;
      const status = patron.cooldownStatus(out, customer.id);
      if (status?.remainingMinutes > 15) {
        out = patron.setCooldown(out, { customerId: customer.id, minutes: 15 });
      }
      if (activeSleepScene && status?.nextMinutes !== 15) {
        out = patron.setNextCooldown(out, { customerId: customer.id, minutes: 15 });
      }
    }
    return out;
  }

  function effectivePatternWeights(source = settings.patternWeights) {
    const weights = {
      enforcer: Math.max(0, Number(source?.enforcer) || 0),
      lurer: Math.max(0, Number(source?.lurer) || 0),
      infiltrator: sleepActionsAvailable()
        ? Math.max(0, Number(source?.infiltrator) || 0)
        : 0,
      impostor: Math.max(0, Number(source?.impostor) || 0)
    };
    if (Object.values(weights).some(value => value > 0)) return weights;
    return {
      enforcer: DEFAULT_SETTINGS.patternWeights.enforcer,
      lurer: DEFAULT_SETTINGS.patternWeights.lurer,
      infiltrator: 0,
      impostor: DEFAULT_SETTINGS.patternWeights.impostor
    };
  }

  function effectiveSpecialActionWeights(source = settings.specialActionWeights) {
    return {
      ...source,
      sleepDrug: sleepActionsAvailable() ? Math.max(0, Number(source?.sleepDrug) || 0) : 0
    };
  }
  const required = {
    store,
    getWife: api?.character?.getWife,
    getWifeLocation: api?.character?.getLocation,
    getActiveScene: api?.character?.getActiveScene,
    getCustomerLocation: api?.character?.getCustomerLocation,
    getEffectiveAttributes: api?.character?.getEffectiveAttributes,
    getWifeSleepRoom: api?.character?.getWifeSleepRoom,
    badGuestPrivateRoomCandidates: api?.engine?.badGuestPrivateRoomCandidates,
    badGuestEnterPrivateRoom: api?.engine?.badGuestEnterPrivateRoom,
    reduceGameAction: api?.engine?.reduceGameAction,
    evaluateIntimacy: api?.engine?.evaluateIntimacy,
    acceptanceBreakdown: api?.engine?.acceptanceBreakdown,
    acceptanceCalculator: api?.engine?.acceptanceCalculator,
    selectPatronTactic: api?.engine?.selectPatronTactic,
    forceAttemptChance: api?.engine?.forceAttemptChance,
    buildPatronMoveCandidates: api?.engine?.buildPatronMoveCandidates,
    processPatronGroupJoin: api?.engine?.processPatronGroupJoin,
    processPatronGroupParticipants: api?.engine?.processPatronGroupParticipants,
    rotatePatronGroupAfterPrimary: api?.engine?.rotatePatronGroupAfterPrimary,
    patronJealousyAssessment: api?.engine?.patronJealousyAssessment,
    patronControlNaturalEnd: api?.engine?.patronControlNaturalEnd,
    patronControlBoundaryStop: api?.engine?.patronControlBoundaryStop,
    patronControlFatigueStop: api?.engine?.patronControlFatigueStop,
    patronControlClimax: api?.engine?.patronControlClimax,
    patronControlAfterglow: api?.engine?.patronControlAfterglow,
    patronControlPlayerReturnStop: api?.engine?.patronControlPlayerReturnStop,
    patronControlRecallReach: api?.engine?.patronControlRecallReach,
    patronControlShouldCheckWithHusband: api?.engine?.patronControlShouldCheckWithHusband,
    patronControlPrivateOffer: api?.engine?.patronControlPrivateOffer,
    patronControlResolvePrivateOffer: api?.engine?.patronControlResolvePrivateOffer,
    patronControlWifeClimax: api?.engine?.patronControlWifeClimax,
    patronControlAftermathFeeling: api?.engine?.patronControlAftermathFeeling,
    patronControlRecordFirsts: api?.engine?.patronControlRecordFirsts,
    patronControlCrossedLine: api?.engine?.patronControlCrossedLine,
    patronControlSelfConceptDrift: api?.engine?.patronControlSelfConceptDrift,
    patronControlAftercareFeeling: api?.engine?.patronControlAftercareFeeling,
    patronControlAftercareBond: api?.engine?.patronControlAftercareBond,
    patronControlRecordVisitOutcome: api?.engine?.patronControlRecordVisitOutcome,
    patronControlAdvanceNamedPatron: api?.engine?.patronControlAdvanceNamedPatron,
    patronControlOtherRelationshipReaction: api?.engine?.patronControlOtherRelationshipReaction,
    patronControlOpenReaction: api?.engine?.patronControlOpenReaction,
    patronControlResolveReaction: api?.engine?.patronControlResolveReaction,
    patronControlExpireReaction: api?.engine?.patronControlExpireReaction,
    patronControlNightAccount: api?.engine?.patronControlNightAccount,
    patronControlUnpromptedCandidates: api?.engine?.patronControlUnpromptedCandidates,
    patronControlCanConfess: api?.engine?.patronControlCanConfess,
    patronControlApplyNightAccount: api?.engine?.patronControlApplyNightAccount,
    patronControlRecordConfession: api?.engine?.patronControlRecordConfession,
    patronControlRecordConfessionReception: api?.engine?.patronControlRecordConfessionReception,
    patronControlConfessionSummary: api?.engine?.patronControlConfessionSummary,
    patronControlResolveConfession: api?.engine?.patronControlResolveConfession,
    patronControlIsUncommitted: api?.engine?.patronControlIsUncommitted,
    patronControlEnjoymentOpinion: api?.engine?.patronControlEnjoymentOpinion,
    patronControlInnerThought: api?.engine?.patronControlInnerThought,
    patronControlRecordMoment: api?.engine?.patronControlRecordMoment,
    patronControlMomentTitle: api?.engine?.patronControlMomentTitle,
    patronControlMomentCategory: api?.engine?.patronControlMomentCategory,
    approachClosedDoor: api?.engine?.approachClosedDoor,
    roomSideForOccupant: api?.engine?.roomSideForOccupant,
    patronControlCoercionEscape: api?.engine?.patronControlCoercionEscape,
    patronControlAcquaintanceStop: api?.engine?.patronControlAcquaintanceStop,
    patronControlShameStop: api?.engine?.patronControlShameStop,
    patronControlServiceInterrupt: api?.engine?.patronControlServiceInterrupt,
    patronControlExposureRedress: api?.engine?.patronControlExposureRedress,
    patronControlLineUp: api?.engine?.patronControlLineUp,
    patronControlPushIn: api?.engine?.patronControlPushIn,
    patronControlRelentChance: api?.engine?.patronControlRelentChance,
    recordIntimateHistory: api?.engine?.recordIntimateHistory,
    processPatronInteractionTick: api?.engine?.processPatronInteractionTick,
    resolvePatronEscalation: api?.engine?.resolvePatronEscalation,
    resolvePatronForce: api?.engine?.resolvePatronForce,
    transitionPatronStage: api?.engine?.transitionPatronStage,
    recordPatronReach: api?.engine?.recordPatronReach,
    startPatronInteraction: api?.engine?.startPatronInteraction,
    endPatronInteraction: api?.engine?.endPatronInteraction,
    finishBackRoomService: api?.engine?.finishBackRoomService,
    recordPlayerTone: api?.engine?.recordPlayerTone,
    ejectCustomer: api?.engine?.ejectCustomer,
    passOutWife: api?.engine?.passOutWife,
    applyWifeRestBreak: api?.engine?.applyWifeRestBreak,
    resolvePrivateSessionExit: api?.engine?.resolvePrivateSessionExit,
    advanceWorldMinute: api?.engine?.advanceWorldMinute,
    applyPotionCupEffects: api?.engine?.applyPotionCupEffects,
    applyPotionEffect: api?.engine?.applyPotionEffect,
    retireWife: api?.engine?.retireWife,
    movePlayer: api?.movement?.movePlayer,
    moveWife: api?.movement?.moveWife,
    minuteTick: api?.minuteTick,
    decreaseWifeIntoxication: api?.decreaseWifeIntoxication,
    relationshipInfluence: api?.relationship?.getRelationshipInfluence,
    maritalDrift: api?.relationship?.getMaritalDrift,
    patronAttachment: api?.relationship?.getPatronAttachment,
    patronComfort: api?.relationship?.getPatronComfort,
    recordPatronBoundary: api?.relationship?.recordPatronBoundary,
    recordLatitudeEncouragement: api?.relationship?.recordLatitudeEncouragement,
    recordLatitudeRestriction: api?.relationship?.recordLatitudeRestriction,
    recordPatronLatitude: api?.relationship?.recordPatronLatitude,
    nudgeRelationship: api?.relationship?.nudgeRelationship,
    recordAffection: api?.relationship?.recordAffection,
    recordPatronMistreatment: api?.engine?.recordPatronMistreatment,
    addFeeling: api?.character?.addFeeling,
    addIdentityStrainFromPatronAct: api?.character?.addIdentityStrainFromPatronAct
  };

  const OPTIONAL_REQUIRED_NAMES = new Set([
    'patronControlPlayerReturnStop',
    'patronJealousyAssessment',
    'patronControlRecallReach',
    'patronControlShouldCheckWithHusband',
    'patronControlPrivateOffer',
    'patronControlResolvePrivateOffer',
    'patronControlWifeClimax',
    'patronControlAftermathFeeling',
    'patronControlRecordFirsts',
    'patronControlCrossedLine',
    'patronControlSelfConceptDrift',
    'patronControlAftercareFeeling',
    'patronControlAftercareBond',
    'patronControlRecordVisitOutcome',
    'patronControlAdvanceNamedPatron',
    'patronControlOtherRelationshipReaction',
    'patronControlOpenReaction',
    'patronControlResolveReaction',
    'patronControlExpireReaction',
    'patronControlNightAccount',
    'patronControlApplyNightAccount',
    'patronControlRecordConfession',
    'patronControlRecordConfessionReception',
    'patronControlConfessionSummary',
    'patronControlResolveConfession',
    'patronControlIsUncommitted',
    'patronControlEnjoymentOpinion',
    'patronControlInnerThought',
    'patronControlRecordMoment',
    'resolvePrivateSessionExit'
  ]);
  const missing = Object.entries(required)
    .filter(([name, value]) => value == null && !OPTIONAL_REQUIRED_NAMES.has(name))
    .map(([key]) => key);
  if (missing.length || !store?.getState || !store?.setState || !store?.subscribe) {
    console.error(`[${MOD_ID}] Missing required API: ${missing.join(', ') || 'state.gameStore methods'}`);
    return;
  }

  const CONFIG = {
    spawnChance: settings.spawnChance / 100,
    activeActionChance: settings.activeActionChance / 100,
    refusalHandcuffChance: settings.refusalHandcuffChance / 100,
    specialActionWeights: { ...settings.specialActionWeights },
    ambientDrugChancePerMinute: settings.ambientDrugChancePerMinute / 100,
    ambientBackRoomChancePerMinute: settings.ambientBackRoomChancePerMinute / 100,
    backRoomConversationMinutes: 22,
    rehandcuffChancePerMinute: settings.rehandcuffChancePerMinute / 100,
    selfLockMaxChancePerMinute: settings.selfLockMaxChancePerMinute / 100,
    actionCooldownMinutes: settings.actionCooldownMinutes,
    drugActionCooldownMinutes: settings.drugActionCooldownMinutes,
    backRoomActionCooldownMinutes: settings.backRoomActionCooldownMinutes,
    drugDurationMinutes: settings.drugRampMinutes + settings.drugPlateauMinutes + settings.drugFallMinutes,
    drugRampMinutes: settings.drugRampMinutes,
    drugPlateauMinutes: settings.drugPlateauMinutes,
    drugFallMinutes: settings.drugFallMinutes,
    drugMaxAcceptanceBonus: settings.drugMaxAcceptanceBonus,
    handcuffAfterMinutes: 5,
    breakDoorMinutes: 5,
    breakDoorMinChance: 0.10,
    breakDoorMaxChance: 0.33,
    breakDoorRepairGold: 20,
    breakDoorRenownPenalty: 3,
    selfLockMinDrift: 30,
    wealthyPartyMinDay: 8,
    wealthyPartyDailyChance: settings.wealthyPartyDailyChance / 100,
    drinkingGameVisitChance: settings.drinkingGameVisitChance / 100,
    wealthyPartyRollWindowMinutes: 360,
    wealthyPartyCooldownDays: 6,
    wealthyPartySize: 5,
    wealthyPartyMinMinutes: 180,
    wealthyPartyMaxMinutes: 240,
    wealthyPartyRewardGold: 50,
    wealthyPartyNotoriety: 10,
    wealthyPartyWalletBonus: 50,
    cuffedForceAttemptChance: 0.75,
    badGuestGroupJoinAttemptsPerGuest: 3,
    badGuestPairGroupJoinAttemptsPerGuest: 8,
    debug: false
  };

  function applySettingsToConfig(nextSettings) {
    settings = normalizeSettings(nextSettings);
    CONFIG.spawnChance = settings.spawnChance / 100;
    CONFIG.activeActionChance = settings.activeActionChance / 100;
    CONFIG.refusalHandcuffChance = settings.refusalHandcuffChance / 100;
    CONFIG.ambientDrugChancePerMinute = settings.ambientDrugChancePerMinute / 100;
    CONFIG.ambientBackRoomChancePerMinute = settings.ambientBackRoomChancePerMinute / 100;
    CONFIG.rehandcuffChancePerMinute = settings.rehandcuffChancePerMinute / 100;
    CONFIG.selfLockMaxChancePerMinute = settings.selfLockMaxChancePerMinute / 100;
    CONFIG.specialActionWeights = { ...settings.specialActionWeights };
    CONFIG.actionCooldownMinutes = settings.actionCooldownMinutes;
    CONFIG.drugActionCooldownMinutes = settings.drugActionCooldownMinutes;
    CONFIG.backRoomActionCooldownMinutes = settings.backRoomActionCooldownMinutes;
    CONFIG.drugRampMinutes = settings.drugRampMinutes;
    CONFIG.drugPlateauMinutes = settings.drugPlateauMinutes;
    CONFIG.drugFallMinutes = settings.drugFallMinutes;
    CONFIG.drugDurationMinutes = settings.drugRampMinutes + settings.drugPlateauMinutes + settings.drugFallMinutes;
    CONFIG.drugMaxAcceptanceBonus = settings.drugMaxAcceptanceBonus;
    CONFIG.wealthyPartyDailyChance = settings.wealthyPartyDailyChance / 100;
    CONFIG.drinkingGameVisitChance = settings.drinkingGameVisitChance / 100;
    return settings;
  }

  function saveGlobalSettings(nextSettings) {
    const normalized = applySettingsToConfig(nextSettings);
    try {
      api?.settings?.set?.(normalized);
    } catch (error) {
      console.warn(`[${MOD_ID}] Failed to save global settings`, error);
    }
    return normalized;
  }

  function copySettings(value = settings) {
    return JSON.parse(JSON.stringify(value));
  }

  const original = {
    privateRoomCandidates: required.badGuestPrivateRoomCandidates,
    enterPrivateRoom: required.badGuestEnterPrivateRoom,
    reduceGameAction: required.reduceGameAction,
    evaluateIntimacy: required.evaluateIntimacy,
    acceptanceBreakdown: required.acceptanceBreakdown,
    acceptanceCalculator: required.acceptanceCalculator,
    selectPatronTactic: required.selectPatronTactic,
    forceAttemptChance: required.forceAttemptChance,
    buildPatronMoveCandidates: required.buildPatronMoveCandidates,
    processPatronGroupJoin: required.processPatronGroupJoin,
    processPatronGroupParticipants: required.processPatronGroupParticipants,
    rotatePatronGroupAfterPrimary: required.rotatePatronGroupAfterPrimary,
    patronJealousyAssessment: required.patronJealousyAssessment,
    recordIntimateHistory: required.recordIntimateHistory,
    recordPatronReach: required.recordPatronReach,
    patronControlNaturalEnd: required.patronControlNaturalEnd,
    patronControlBoundaryStop: required.patronControlBoundaryStop,
    patronControlFatigueStop: required.patronControlFatigueStop,
    patronControlClimax: required.patronControlClimax,
    patronControlAfterglow: required.patronControlAfterglow,
    patronControlPlayerReturnStop: required.patronControlPlayerReturnStop,
    patronControlRecallReach: required.patronControlRecallReach,
    patronControlShouldCheckWithHusband: required.patronControlShouldCheckWithHusband,
    patronControlPrivateOffer: required.patronControlPrivateOffer,
    patronControlResolvePrivateOffer: required.patronControlResolvePrivateOffer,
    patronControlWifeClimax: required.patronControlWifeClimax,
    patronControlAftermathFeeling: required.patronControlAftermathFeeling,
    patronControlRecordFirsts: required.patronControlRecordFirsts,
    patronControlCrossedLine: required.patronControlCrossedLine,
    patronControlSelfConceptDrift: required.patronControlSelfConceptDrift,
    patronControlAftercareFeeling: required.patronControlAftercareFeeling,
    patronControlAftercareBond: required.patronControlAftercareBond,
    patronControlRecordVisitOutcome: required.patronControlRecordVisitOutcome,
    patronControlAdvanceNamedPatron: required.patronControlAdvanceNamedPatron,
    patronControlOtherRelationshipReaction: required.patronControlOtherRelationshipReaction,
    patronControlOpenReaction: required.patronControlOpenReaction,
    patronControlResolveReaction: required.patronControlResolveReaction,
    patronControlExpireReaction: required.patronControlExpireReaction,
    patronControlNightAccount: required.patronControlNightAccount,
    patronControlUnpromptedCandidates: required.patronControlUnpromptedCandidates,
    patronControlApplyNightAccount: required.patronControlApplyNightAccount,
    patronControlEnjoymentOpinion: required.patronControlEnjoymentOpinion,
    patronControlInnerThought: required.patronControlInnerThought,
    patronControlRecordMoment: required.patronControlRecordMoment,
    patronControlCoercionEscape: required.patronControlCoercionEscape,
    patronControlAcquaintanceStop: required.patronControlAcquaintanceStop,
    patronControlShameStop: required.patronControlShameStop,
    patronControlServiceInterrupt: required.patronControlServiceInterrupt,
    patronControlExposureRedress: required.patronControlExposureRedress,
    patronControlLineUp: required.patronControlLineUp,
    patronControlPushIn: required.patronControlPushIn,
    patronControlRelentChance: required.patronControlRelentChance,
    startPatronInteraction: required.startPatronInteraction,
    processPatronInteractionTick: required.processPatronInteractionTick,
    resolvePatronEscalation: required.resolvePatronEscalation,
    resolvePatronForce: required.resolvePatronForce,
    endPatronInteraction: required.endPatronInteraction,
    passOutWife: required.passOutWife,
    applyWifeRestBreak: required.applyWifeRestBreak,
    resolvePrivateSessionExit: required.resolvePrivateSessionExit,
    advanceWorldMinute: required.advanceWorldMinute,
    applyPotionCupEffects: required.applyPotionCupEffects,
    applyPotionEffect: required.applyPotionEffect,
    retireWife: required.retireWife,
    movePlayer: required.movePlayer,
    moveWife: required.moveWife,
    minuteTick: required.minuteTick,
    decreaseWifeIntoxication: required.decreaseWifeIntoxication
  };
  original.approachClosedDoor = required.approachClosedDoor;
  original.addFeeling = required.addFeeling;
  original.addIdentityStrainFromPatronAct = required.addIdentityStrainFromPatronAct;

  const STAGES = [
    'chatting', 'flirting', 'light_touch', 'bold_touch', 'groping',
    'intimate', 'handjob_patron', 'blowjob_patron', 'rubbing_patron', 'sex_patron'
  ];
  const DRUG_TACTIC_STAGES = new Set(['chatting', 'flirting', 'light_touch', 'bold_touch']);
  const MONETARY_TACTICS = new Set(['offer_gold']);
  const COERCED_IDENTITY_STAGES = new Set([
    'handjob_patron', 'blowjob_patron', 'rubbing_patron', 'sex_patron'
  ]);
  const STAGE_CATEGORIES = {
    chatting: null,
    flirting: 'kiss_chaste',
    light_touch: 'kiss_chaste',
    bold_touch: 'touch_over_clothes',
    groping: 'touch_skin',
    intimate: 'manual_receiving',
    handjob_patron: 'manual_giving',
    blowjob_patron: 'oral_giving',
    rubbing_patron: 'genital_rubbing',
    sex_patron: 'sex_vaginal'
  };
  const STAGE_LABELS = {
    chatting: '대화',
    flirting: '유혹',
    light_touch: '가벼운 접촉',
    bold_touch: '대담한 접촉',
    groping: '몸 더듬기',
    intimate: '손가락으로 애무',
    handjob_patron: '손으로 자극',
    blowjob_patron: '입으로 해주기',
    rubbing_patron: '성기 비비기',
    sex_patron: '성관계'
  };

  function laterPatronStage(left, right) {
    const leftIndex = STAGES.indexOf(left);
    const rightIndex = STAGES.indexOf(right);
    if (leftIndex < 0) return rightIndex < 0 ? left : right;
    if (rightIndex < 0) return left;
    return rightIndex > leftIndex ? right : left;
  }

  function trackEligiblePatronMaxStage(before, after, restricted) {
    if (!after) return after;
    const wasRestricted = before?.badGuestMaxStageRestricted === true;
    if (!restricted && !wasRestricted) return after;
    const eligibleBefore = before?.badGuestEligibleMaxStage || before?.stage;
    return {
      ...after,
      badGuestMaxStageRestricted: true,
      badGuestEligibleMaxStage: restricted
        ? eligibleBefore
        : laterPatronStage(eligibleBefore, after.stage)
    };
  }
  const TOUCH_OR_SEX = new Set([
    'touch_over_clothes', 'touch_skin', 'touch_breasts', 'touch_under_skirt',
    'kiss_real', 'manual_receiving',
    'manual_giving', 'oral_receiving', 'oral_giving', 'genital_rubbing',
    'sex_vaginal', 'sex_public', 'sex_rough', 'sex_anal', 'cum_on_skin',
    'cum_on_face', 'cum_in_mouth', 'cum_swallow'
  ]);
  const DRUG_ACCEPTANCE_CATEGORIES = new Set([
    ...TOUCH_OR_SEX,
    'visual_modest', 'visual_thigh', 'visual_undergarments', 'visual_payment',
    'visual_explicit', 'visual_topless', 'visual_bottomless', 'visual_full_nude',
    'kiss_chaste', 'watch_him'
  ]);
  const AGGRESSIVE_DECEPTION_STAGES = new Set(['chatting', 'flirting']);
  const ACTIVE_CUSTOMER_STATUSES = new Set([
    'arrived', 'greeted', 'ordered', 'drinking', 'wants_more', 'seated'
  ]);
  const ELIGIBLE_TYPES = new Set([
    'regular', 'charmer', 'drunk_bold', 'rogue', 'nobleman', 'wealthy_pervert'
  ]);
  const BAD_GUEST_BLOCKED_END_REASONS = new Set([
    'patron_satisfied_chat', 'patron_satisfied', 'patron_gave_up'
  ]);
  const PUBLIC_PROCESS_NAMES = Object.freeze([
    'wealthyPartyOfferCheck',
    'wealthyPartyStart',
    'wealthyPartyServeVisit',
    'wealthyPartyDoorLock',
    'wealthyPartyHandcuffRound',
    'wealthyPartyFinish',
    'drugAttempt',
    'drugApply',
    'sleepDrugApply',
    'intoxicationDrugApply',
    'confusionDrugApply',
    'aggressiveDeceptionStart',
    'aggressiveDeceptionResolve',
    'equipmentAttempt',
    'drugRescue',
    'drinkingGameOffer',
    'drinkingGameResolve',
    'drugProtection',
    'backRoomPretext',
    'backRoomEnter',
    'backRoomStop',
    'handcuffAttempt',
    'handcuffEscape',
    'handcuffRefusalResponse',
    'handcuffReentry',
    'doorLock',
    'doorBreak',
    'restraintRescue',
    'compatibilityEnd',
    'specialActionExecute',
    'forcedGroupJoin',
    'wifeSelfLock'
  ]);
  const PUBLIC_PROCESS_NAME_SET = new Set(PUBLIC_PROCESS_NAMES);
  const ORIGINAL_PRETEXT_IDS = [
    'inspect_concern', 'help_with_ache', 'warm_her_hands', 'straighten_strap',
    'loosen_the_belt', 'tend_a_wound', 'just_a_taste', 'measure_for_dress',
    'sit_on_my_knee', 'spilled_on_her', 'dance_lesson', 'under_her_skirt',
    'dropped_ring'
  ];

  let tacticTickContext = null;
  let forceAttemptContext = null;
  let patronEscalationContext = null;
  let groupJoinContext = null;
  let acceptanceProjectionContext = null;
  let calculatingActualConfusionAcceptance = false;
  let calculatingUnassistedAphrodisiacAcceptance = false;
  let latestConfusionActualAcceptance = null;
  let latestConfusionPerceivedAcceptance = null;
  let latestAphrodisiacAcceptance = null;
  let authorizedRestraintEndContext = null;
  let confusionSubjectiveContext = null;
  let aphrodisiacSubjectiveContext = null;
  let endingPatronIncidentContext = null;
  let confusionClimaxEmotionProjection = null;
  let bypassMoveWife = false;
  let normalizing = false;
  let unregisterSleepActionsFlowOwner = null;
  let unregisterSleepActionsWakeObserver = null;
  let unregisterSleepActionsSearchResolver = null;
  let inspectorRenderQueued = false;
  let uiEventHandler = null;
  let drugMoodObserver = null;
  let lastUiStateSignature = null;
  let processHookSequence = 0;
  const processHooks = {
    before: new Map(),
    after: new Map()
  };
  function debug(...args) {
    if (CONFIG.debug) console.debug(`[${MOD_ID}]`, ...args);
  }

  function processHookList(phase, name, create = false) {
    const registry = processHooks[phase];
    let list = registry.get(name);
    if (!list && create) {
      list = [];
      registry.set(name, list);
    }
    return list || [];
  }

  function orderedProcessHooks(phase, name) {
    return [
      ...processHookList(phase, '*'),
      ...processHookList(phase, name)
    ].sort((left, right) => right.priority - left.priority || left.sequence - right.sequence);
  }

  function registerProcessHook(phase, name, handler, options = {}) {
    if (phase !== 'before' && phase !== 'after') {
      throw new TypeError(`알 수 없는 나쁜 손님 처리 훅 단계입니다: ${phase}`);
    }
    if (name !== '*' && !PUBLIC_PROCESS_NAME_SET.has(name)) {
      throw new RangeError(`알 수 없는 나쁜 손님 처리 이름입니다: ${name}`);
    }
    if (typeof handler !== 'function') {
      throw new TypeError(`${name}.${phase} 처리기는 함수여야 합니다.`);
    }
    const entry = {
      handler,
      priority: Number.isFinite(Number(options.priority)) ? Number(options.priority) : 0,
      sequence: processHookSequence += 1
    };
    const list = processHookList(phase, name, true);
    list.push(entry);
    let active = true;
    return () => {
      if (!active) return;
      active = false;
      const index = list.indexOf(entry);
      if (index >= 0) list.splice(index, 1);
      if (!list.length) processHooks[phase].delete(name);
    };
  }

  function runProcessBefore(name, initialArgs) {
    let args = initialArgs;
    for (const entry of orderedProcessHooks('before', name)) {
      try {
        const next = entry.handler(args, { name, phase: 'before' });
        if (Array.isArray(next)) args = next;
        else if (next?.cancel === true) {
          return { args, cancelled: true, value: next.value };
        }
      } catch (error) {
        console.error(`[${MOD_ID}] before:${name} 처리기가 실패했습니다.`, error);
      }
    }
    return { args, cancelled: false, value: undefined };
  }

  function runProcessAfter(name, initialResult, args) {
    let result = initialResult;
    for (const entry of orderedProcessHooks('after', name)) {
      try {
        const next = entry.handler(result, args, { name, phase: 'after' });
        if (next !== undefined) result = next;
      } catch (error) {
        console.error(`[${MOD_ID}] after:${name} 처리기가 실패했습니다.`, error);
      }
    }
    return result;
  }

  function runPublicProcess(name, handler, initialArgs) {
    const before = runProcessBefore(name, initialArgs);
    const result = before.cancelled ? before.value : handler(...before.args);
    return runProcessAfter(name, result, before.args);
  }

  function clearProcessHooks() {
    processHooks.before.clear();
    processHooks.after.clear();
  }

  const publicProcessHooks = Object.freeze({
    names: PUBLIC_PROCESS_NAMES,
    before(name, handler, options) {
      return registerProcessHook('before', name, handler, options);
    },
    after(name, handler, options) {
      return registerProcessHook('after', name, handler, options);
    }
  });

  function clamp(value, min = 0, max = 100) {
    return Math.max(min, Math.min(max, Number(value) || 0));
  }

  function opposedChance(attacker, defender, spread = 12) {
    return clamp((attacker - defender + spread) / (spread * 2), 0, 1);
  }

  function calibratedOpposedChance(attacker, defender, spread, configuredBasePercent, nativeBasePercent, winCeiling = 1) {
    const adjusted = opposedChance(attacker, defender, spread)
      + (configuredBasePercent - nativeBasePercent) / 100;
    return Math.min(clamp(adjusted, 0, 1), winCeiling);
  }

  function rollCalibratedOpposed(attacker, defender, spread, configuredBasePercent, nativeBasePercent, winCeiling = 1, sample = true, sampleFromHigh = false) {
    const margin = attacker - defender;
    const chance = calibratedOpposedChance(
      attacker,
      defender,
      spread,
      configuredBasePercent,
      nativeBasePercent,
      winCeiling
    );
    return {
      attackerWins: sample
        ? (sampleFromHigh ? Math.random() > 1 - chance : Math.random() < chance)
        : chance >= 0.5,
      margin,
      chance
    };
  }

  function rollLinearOpposed(attacker, defender, configuredBasePercent, percentPerPoint, minChance = 0.05, maxChance = 0.95, sample = true) {
    const margin = attacker - defender;
    const chance = clamp(
      configuredBasePercent / 100 + margin * percentPerPoint / 100,
      minChance,
      maxChance
    );
    return {
      attackerWins: sample ? Math.random() < chance : chance >= 0.5,
      margin,
      chance
    };
  }

  function rollGroupOpposed(attacker, defender, configuredBasePercent, percentPerPoint, sample = true) {
    return rollLinearOpposed(
      attacker,
      defender,
      configuredBasePercent,
      percentPerPoint,
      0.05,
      0.90,
      sample
    );
  }

  function handcuffStrengthCheck(state, customer, sample = true) {
    const wife = getWife(state);
    const patronAttributes = effectiveAttributes(customer);
    const wifeAttributes = effectiveAttributes(wife);
    const patronStrength = patronAttributes.strength ?? 50;
    const patronDeftness = patronAttributes.deftness ?? 50;
    const wifeStrength = wifeAttributes.strength ?? 50;
    const wifeDeftness = wifeAttributes.deftness ?? 50;
    const patronScore = (patronStrength + patronDeftness) / 2;
    const wifeScore = (wifeStrength + wifeDeftness) / 2;
    const confusionRelationshipBonus = confusionEquipmentBonus(state, customer);
    const chance = clamp(
      settings.checkBaseChances.handcuffGuestSuccess / 100
        + (patronScore - wifeScore) * settings.checkPointIncrements.handcuffGuestSuccess / 100
        + confusionRelationshipBonus,
      0.05,
      0.95
    );
    const attackerWins = sample ? Math.random() > 1 - chance : chance >= 0.5;
    return {
      patronStrength,
      patronDeftness,
      wifeStrength,
      wifeDeftness,
      patronScore,
      wifeScore,
      margin: patronScore - wifeScore,
      chance,
      confusionRelationshipBonus,
      naturalAttackerWins: attackerWins,
      success: attackerWins
    };
  }

  function handcuffEscapeCheck(state, customer, sample = true) {
    const wife = getWife(state);
    const patronAttributes = effectiveAttributes(customer);
    const wifeAttributes = effectiveAttributes(wife);
    const patronStrength = patronAttributes.strength ?? 50;
    const patronDeftness = patronAttributes.deftness ?? 50;
    const wifeStrength = wifeAttributes.strength ?? 50;
    const wifeDeftness = wifeAttributes.deftness ?? 50;
    const patronScore = (patronStrength + patronDeftness) / 2;
    const wifeScore = (wifeStrength + wifeDeftness) / 2;
    const chance = clamp(
      settings.checkBaseChances.handcuffEscapeSuccess / 100
        + (wifeScore - patronScore) * settings.checkPointIncrements.handcuffEscapeSuccess / 100,
      0.05,
      0.95
    );
    const success = sample ? Math.random() < chance : chance >= 0.5;
    return {
      patronStrength,
      patronDeftness,
      wifeStrength,
      wifeDeftness,
      patronScore,
      wifeScore,
      margin: wifeScore - patronScore,
      chance,
      success
    };
  }

  function groupHandcuffStrengthCheck(state, customer, sample = true) {
    const wife = getWife(state);
    const patronAttributes = effectiveAttributes(customer);
    const wifeAttributes = effectiveAttributes(wife);
    const patronStrength = patronAttributes.strength ?? 50;
    const patronDeftness = patronAttributes.deftness ?? 50;
    const wifeStrength = wifeAttributes.strength ?? 50;
    const wifeDeftness = wifeAttributes.deftness ?? 50;
    const patronScore = (patronStrength + patronDeftness) / 2;
    const wifeScore = (wifeStrength + wifeDeftness) / 2;
    const confusionRelationshipBonus = confusionEquipmentBonus(state, customer);
    const chance = clamp(
      settings.checkBaseChances.groupHandcuffGuestSuccess / 100
        + (patronScore - wifeScore) * settings.checkPointIncrements.groupHandcuffGuestSuccess / 100
        + confusionRelationshipBonus,
      0.05,
      0.95
    );
    const success = sample ? Math.random() < chance : chance >= 0.5;
    return {
      patronStrength,
      patronDeftness,
      wifeStrength,
      wifeDeftness,
      patronScore,
      wifeScore,
      margin: patronScore - wifeScore,
      chance,
      confusionRelationshipBonus,
      naturalAttackerWins: success,
      success
    };
  }

  function applyFailedHandcuffPenalty(state, customer, check) {
    const kind = check.margin <= -20 ? 'ejected' : 'held_off';
    let out = required.recordPatronMistreatment(state, customer);
    out = {
      ...out,
      customers: (out.customers || []).map(entry => entry.id === customer.id
        ? { ...entry, forceDecidedTonight: kind }
        : entry)
    };
    if (equipmentFearApplies(state, customer)) {
      out = wrappedAddFeeling(out, 'fear', {
        intensity: kind === 'ejected' ? 30 : 22,
        source: `patron:${customer.name.toLowerCase()}:force_repelled`,
        durationSlots: 160,
        blurb: '그가 수갑으로 손목을 붙잡으려 했고, 그녀는 맞서서 그 손을 떼어 내야 했다'
      });
    }
    return {
      state: out,
      kind,
      endsInteraction: kind === 'ejected'
    };
  }

  function individualActionCooldown(kind) {
    if (['drug', 'sleep_drug', 'intoxication_drug', 'confusion_drug'].includes(kind)) {
      return CONFIG.drugActionCooldownMinutes;
    }
    if (kind === 'back_room_pretext') return CONFIG.backRoomActionCooldownMinutes;
    return 0;
  }

  function patternDrugKind(pattern) {
    if (pattern?.drugAction === 'sleep_drug') return 'sleep';
    if (pattern?.drugAction === 'intoxication_drug') return 'intoxication';
    if (pattern?.drugAction === 'confusion_drug') return 'confusion';
    return 'aphrodisiac';
  }

  function patternDrugAvailable(state, customer) {
    const action = badGuestPattern(customer).drugAction;
    if (!individualActionReady(state, customer, action)) return false;
    if (action === 'sleep_drug') return sleepPotionEligibility(state, customer).status === 'available';
    if (action === 'intoxication_drug') return !timedEffectActive(state, 'intoxicationFloor');
    if (action === 'confusion_drug') return !timedEffectActive(state, 'confusion');
    return drugLevelAt(state) <= 0;
  }

  function globalActionReady(state, customer) {
    return state.slot - (customer?.badGuestLastActionSlot ?? -9999) >= CONFIG.actionCooldownMinutes;
  }

  function individualActionReady(state, customer, kind) {
    const cooldown = individualActionCooldown(kind);
    const last = customer?.badGuestActionSlots?.[kind] ?? -9999;
    return state.slot - last >= cooldown;
  }

  function markCustomerAction(customer, slot, kind, label = kind) {
    const actionSlots = individualActionCooldown(kind) > 0
      ? { ...(customer.badGuestActionSlots || {}), [kind]: slot }
      : customer.badGuestActionSlots;
    return {
      ...customer,
      badGuestLastActionSlot: slot,
      badGuestLastAction: label,
      ...(actionSlots ? { badGuestActionSlots: actionSlots } : {})
    };
  }

  function getData(state) {
    const raw = state?.mods?.[WML_DATA_KEY] ?? state?.modData?.[DATA_KEY];
    const saved = { ...(raw || {}) };
    const effects = {
      aphrodisiac: raw?.effects?.aphrodisiac ?? raw?.drugEffect ?? null,
      intoxicationFloor: raw?.effects?.intoxicationFloor ?? null,
      confusion: raw?.effects?.confusion ?? null
    };
    const equipment = {
      restraint: raw?.equipment?.restraint ?? raw?.restraint ?? null,
      blindfold: raw?.equipment?.blindfold ?? null,
      gag: raw?.equipment?.gag ?? null,
      attempts: { ...(raw?.equipment?.attempts || {}) }
    };
    delete saved.groupCoercionHistory;
    delete saved.drugEffect;
    delete saved.restraint;
    delete saved.externalDrugRequests;
    return {
      version: 8,
      customerClassifications: {},
      effects,
      equipment,
      doorLock: null,
      pendingDrug: null,
      pendingBackRoomPretext: null,
      wealthyParty: null,
      wealthyPartyRoster: [],
      wealthyPartyOfferCheckedDay: null,
      wealthyPartyOfferScheduleDay: null,
      wealthyPartyOfferRollSlot: null,
      wealthyPartyOfferWonDay: null,
      wealthyPartyLastDay: null,
      drinkingGame: null,
      drinkingGameVisits: {},
      recoveryRest: null,
      deferredMovement: null,
      aggressiveDeception: { active: null, requests: {} },
      sleepPotion: { pending: null, incident: null, roomWatch: null, requests: [] },
      confusionMemories: { baselines: [], events: [], recoveries: [], recoveryBaselines: [] },
      pendingConfusionRecoveries: [],
      aphrodisiacMemories: { events: [] },
      phaseNotices: {},
      ...saved,
      version: 8,
      effects,
      equipment,
      customerClassifications: { ...(raw?.customerClassifications || {}) },
      wealthyPartyRoster: [...(raw?.wealthyPartyRoster || [])],
      drinkingGameVisits: { ...(raw?.drinkingGameVisits || {}) },
      aggressiveDeception: {
        active: raw?.aggressiveDeception?.active ?? null,
        requests: { ...(raw?.aggressiveDeception?.requests || {}) }
      },
      sleepPotion: {
        pending: raw?.sleepPotion?.pending ?? null,
        incident: raw?.sleepPotion?.incident ?? null,
        roomWatch: raw?.sleepPotion?.roomWatch ?? null,
        requests: Array.isArray(raw?.sleepPotion?.requests) ? raw.sleepPotion.requests.slice(-128) : []
      },
      confusionMemories: {
        baselines: Array.isArray(raw?.confusionMemories?.baselines)
          ? raw.confusionMemories.baselines.filter(entry => entry && typeof entry === 'object')
          : [],
        events: Array.isArray(raw?.confusionMemories?.events)
          ? raw.confusionMemories.events.filter(event => event && typeof event === 'object')
          : [],
        recoveries: Array.isArray(raw?.confusionMemories?.recoveries)
          ? raw.confusionMemories.recoveries.filter(event => event && typeof event === 'object')
            .slice(-CONFUSION_RECOVERY_LIMIT)
          : [],
        recoveryBaselines: Array.isArray(raw?.confusionMemories?.recoveryBaselines)
          ? raw.confusionMemories.recoveryBaselines.filter(event => event && typeof event === 'object')
          : []
      },
      pendingConfusionRecoveries: Array.isArray(raw?.pendingConfusionRecoveries)
        ? raw.pendingConfusionRecoveries.filter(effect => effect && typeof effect === 'object').slice(-16)
        : [],
      aphrodisiacMemories: {
        events: Array.isArray(raw?.aphrodisiacMemories?.events)
          ? raw.aphrodisiacMemories.events.filter(event => event && typeof event === 'object')
            .slice(-APHRODISIAC_MEMORY_LIMIT)
          : []
      },
      deferredMovement: raw?.deferredMovement ?? null,
      phaseNotices: { ...(raw?.phaseNotices || {}) }
    };
  }

  function readData(state) {
    return getData(state);
  }

  function effectOf(data, kind) {
    return data?.effects?.[kind] ?? null;
  }

  function setEffect(data, kind, value) {
    data.effects = { ...(data.effects || {}), [kind]: value };
    return data;
  }

  function equipmentOf(data, kind) {
    return data?.equipment?.[kind] ?? null;
  }

  function setEquipment(data, kind, value) {
    data.equipment = { ...(data.equipment || {}), [kind]: value };
    if (kind === 'restraint' && value == null) {
      data.equipment.blindfold = null;
      data.equipment.gag = null;
    }
    return data;
  }

  function putData(state, data) {
    // Temporary read-only mirror for adapters that predate equipment v1.
    // BadGuest itself never reads this alias after the one-time migration.
    const stored = {
      ...data,
      restraint: equipmentOf(data, 'restraint')
    };
    const next = {
      ...state,
      mods: {
        ...(state.mods || {}),
        [WML_DATA_KEY]: stored
      }
    };
    if (state.modData?.[DATA_KEY] !== undefined) {
      const legacyModData = { ...(state.modData || {}) };
      delete legacyModData[DATA_KEY];
      if (Object.keys(legacyModData).length) next.modData = legacyModData;
      else delete next.modData;
    }
    return next;
  }

  function getWife(state) {
    return required.getWife(state);
  }

  function wifeDisplayName(state) {
    return getWife(state)?.name || '그녀';
  }

  function withParticle(value, consonantForm, vowelForm) {
    const text = String(value || '');
    const code = text.charCodeAt(text.length - 1);
    const hasFinalConsonant = code >= 0xAC00 && code <= 0xD7A3
      ? (code - 0xAC00) % 28 !== 0
      : /[013678]$/.test(text);
    return `${text}${hasFinalConsonant ? consonantForm : vowelForm}`;
  }

  function getWifeId(state) {
    return state.primaryCharacterId || getWife(state)?.id || 'wife';
  }

  function storyVoice(state) {
    const id = String(getWifeId(state)).toLowerCase();
    const name = wifeDisplayName(state).toLowerCase();
    if (id.includes('pippa') || name === '피파' || name === 'pippa') return 'pippa';
    if (id.includes('mara') || name === '마라' || name === 'mara') return 'mara';
    if (id.includes('elena') || name === '엘레나' || name === 'elena') return 'elena';
    return 'other';
  }

  function storyLine(state, key, candidates) {
    const lines = candidates.filter(Boolean);
    if (lines.length === 1) return lines[0];
    if (!lines.length) return '';
    const seed = `${key}:${state.day ?? 0}:${state.slot ?? 0}:${state.logSeq ?? 0}`;
    let hash = 2166136261;
    for (let index = 0; index < seed.length; index += 1) {
      hash = Math.imul(hash ^ seed.charCodeAt(index), 16777619);
    }
    const start = (hash >>> 0) % lines.length;
    const recent = (state.log || []).slice(-24).map(entry => String(entry?.text || ''));
    for (let offset = 0; offset < lines.length; offset += 1) {
      const line = lines[(start + offset) % lines.length];
      if (!recent.some(text => text.includes(line))) return line;
    }
    return lines[start];
  }

  function updateWife(state, updater) {
    const id = getWifeId(state);
    const wife = state.characters?.[id] || getWife(state);
    if (!wife) return state;
    return {
      ...state,
      characters: {
        ...(state.characters || {}),
        [id]: updater(wife)
      }
    };
  }

  function appendLog(state, text) {
    const seq = state.logSeq ?? 0;
    return {
      ...state,
      logSeq: seq + 1,
      log: [
        ...(state.log || []),
        {
          slot: state.slot,
          seq,
          text
        }
      ]
    };
  }

  function appendToneLog(state, text, tone) {
    const seq = state.logSeq ?? 0;
    return {
      ...state,
      logSeq: seq + 1,
      log: [
        ...(state.log || []),
        {
          slot: state.slot,
          seq,
          text,
          tone
        }
      ]
    };
  }

  function appendDrugLog(state, text) {
    return appendToneLog(state, text, 'intimate');
  }

  function appendDistressLog(state, text) {
    return appendToneLog(state, text, 'distress');
  }

  function appendFlirtLog(state, text) {
    return appendToneLog(state, text, 'flirt');
  }

  function appendIntimateLog(state, text) {
    return appendToneLog(state, text, 'intimate');
  }

  function markLogsSinceAsTone(state, startIndex, tone) {
    if (!Array.isArray(state.log) || state.log.length <= startIndex) return state;
    return {
      ...state,
      log: state.log.map((entry, index) => index < startIndex
        ? entry
        : { ...entry, tone })
    };
  }

  function getLocationOf(state, occupantId) {
    for (const [roomId, room] of Object.entries(state.locations || {})) {
      if ((room?.occupants || []).includes(occupantId)) return roomId;
    }
    return null;
  }

  function wifeLocation(state) {
    return required.getWifeLocation(state);
  }

  function wifeSleepRoom(state) {
    return required.getWifeSleepRoom(state);
  }

  function customerLocation(state, customerId) {
    return required.getCustomerLocation(state, customerId);
  }

  function playerLocation(state) {
    return getLocationOf(state, 'player') || 'taproom';
  }

  function playerRoomSide(state, roomId) {
    if (!roomId || playerLocation(state) !== roomId) return 'elsewhere';
    return required.roomSideForOccupant(state, roomId, 'player');
  }

  function playerInsideRoom(state, roomId) {
    return playerRoomSide(state, roomId) === 'inside';
  }

  function playerObservesRoom(state, roomId) {
    const side = playerRoomSide(state, roomId);
    return side === 'inside' || side === 'peeking';
  }

  function stageAcceptanceCategory(scene) {
    if (!scene) return null;
    if (scene.stage !== 'groping') return STAGE_CATEGORIES[scene.stage] || null;
    if (scene.gropePlace === 'under_skirt') return 'touch_under_skirt';
    if (scene.gropePlace === 'breasts') return 'touch_breasts';
    return api.gameVersion >= '2026-10-22-pre6' ? 'touch_breasts' : 'touch_skin';
  }

  function effectiveAttributes(entity) {
    return required.getEffectiveAttributes(entity);
  }

  function guestCunning(customer) {
    if (!customer) return 50;
    const attrs = effectiveAttributes(customer);
    let value = (customer.charm ?? 50) * 0.55 + (customer.boldness ?? 50) * 0.35;
    if (customer.intent === 'predatory') value += 12;
    if (customer.tacticStyle === 'transactional') value += 8;
    if (customer.tacticStyle === 'smooth_charmer') value += 6;
    if (customer.tacticStyle === 'warm_builder' || customer.tacticStyle === 'drink_pusher') value -= 8;
    if (customer.tacticStyle === 'lap_grabber') value -= 4;
    value += ((attrs.wit ?? 50) - 50) * 0.3;
    return clamp(value);
  }

  function isBadGuest(state, customerOrId) {
    const id = typeof customerOrId === 'string' ? customerOrId : customerOrId?.id;
    if (!id) return false;
    const data = readData(state);
    const customer = typeof customerOrId === 'object'
      ? customerOrId
      : state.customers?.find(entry => entry.id === id);
    const key = customer?.name?.trim();
    const classifications = data.customerClassifications || {};
    if (key && Object.prototype.hasOwnProperty.call(classifications, key)) {
      return classifications[key] === 1;
    }
    return Boolean(data.markedCustomerIds?.[id] || customer?.badGuestApproach === APPROACH_ID);
  }

  function wrappedPatronJealousyAssessment(state, observer, ...rest) {
    const assessment = original.patronJealousyAssessment(state, observer, ...rest);
    if (!assessment || !isBadGuest(state, observer)) return assessment;
    const rivalId = assessment.sight?.kind === 'hands_on_her'
      && assessment.sight.rival?.kind === 'patron'
      ? assessment.sight.rival.customerId
      : null;
    if (rivalId == null) return assessment;
    const rival = state.customers?.find(customer => String(customer.id) === String(rivalId));
    return rival && isBadGuest(state, rival) ? null : assessment;
  }

  function stableCustomerPatternRoll(name) {
    let hash = 2166136261;
    const text = String(name || '').trim().toLowerCase();
    for (let index = 0; index < text.length; index += 1) {
      hash ^= text.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0) % 100;
  }

  function badGuestPattern(customerOrName) {
    const name = typeof customerOrName === 'string' ? customerOrName : customerOrName?.name;
    const weights = effectivePatternWeights(settings.patternWeights);
    const total = Object.values(weights).reduce((sum, value) => sum + Math.max(0, value), 0);
    const roll = stableCustomerPatternRoll(name) / 100 * total;
    const lurerBoundary = Math.max(0, weights.enforcer) + Math.max(0, weights.lurer);
    const infiltratorBoundary = lurerBoundary + Math.max(0, weights.infiltrator);
    let pattern = BAD_GUEST_PATTERNS.enforcer;
    if (roll >= Math.max(0, weights.enforcer)) {
      pattern = roll < lurerBoundary
        ? BAD_GUEST_PATTERNS.lurer
        : roll < infiltratorBoundary
          ? BAD_GUEST_PATTERNS.infiltrator
          : BAD_GUEST_PATTERNS.impostor;
    }
    if (pattern.id === 'enforcer') return pattern;
    return {
      ...pattern,
      handcuffAttemptMultiplier: settings.nonEnforcerHandcuffMultiplierPercent / 100
    };
  }

  function isCanonicalBadGuestActor(state, customer) {
    if (!customer?.id || !customer?.name) return false;
    const data = readData(state);
    return customerClassification(data, customer) === 1
      && customer.intent === 'predatory'
      && customer.tacticStyle === 'transactional';
  }

  function isEligibleCustomer(customer) {
    if (!customer?.id || !customer?.name) return false;
    if (!ELIGIBLE_TYPES.has(customer.patronType)) return false;
    if (customer.isResident || customer.isCollector || customer.isGuard || customer.groupId || customer.partyId) return false;
    if (customer.status === 'gone' || customer.status === 'leaving') return false;
    return true;
  }

  function fixedBadGuestCustomer(customer) {
    const fixed = {
      ...customer,
      intent: 'predatory',
      tacticStyle: 'transactional',
      boldness: Math.max(78, customer.boldness ?? 50)
    };
    delete fixed.badGuestApproach;
    delete fixed.badGuestApproachLabel;
    delete fixed.badGuestWealthyParty;
    return fixed;
  }

  function customerClassification(data, customerOrName) {
    const key = typeof customerOrName === 'string'
      ? customerOrName.trim()
      : customerOrName?.name?.trim();
    const classifications = data.customerClassifications || {};
    if (!key || !Object.prototype.hasOwnProperty.call(classifications, key)) return null;
    return classifications[key] === 1 ? 1 : 0;
  }

  function setCustomerClassification(data, customerOrName, bad) {
    const key = typeof customerOrName === 'string'
      ? customerOrName.trim()
      : customerOrName?.name?.trim();
    if (!key) return false;
    const value = bad ? 1 : 0;
    if (customerClassification(data, key) === value) return false;
    data.customerClassifications[key] = value;
    return true;
  }

  function migrateCustomerClassifications(state, data, legacySchema = false) {
    const legacyMigration = legacySchema
      || data.seenCustomerIds !== undefined
      || data.markedCustomerIds !== undefined;
    if (!legacyMigration) return false;
    let changed = legacyMigration;
    const classifications = { ...(data.customerClassifications || {}) };
    const remember = (name, bad) => {
      const key = name?.trim();
      if (!key) return;
      const value = bad ? 1 : 0;
      if (classifications[key] === 1 || classifications[key] === value) return;
      classifications[key] = value;
      changed = true;
    };

    for (const marker of Object.values(data.markedCustomerIds || {})) {
      remember(marker?.name, true);
    }
    for (const customer of state.customers || []) {
      const legacyBad = Boolean(
        data.markedCustomerIds?.[customer.id]
        || customer.badGuestApproach === APPROACH_ID
        || customer.badGuestWealthyParty
      );
      if (legacyBad) remember(customer.name, true);
      else if (data.seenCustomerIds?.[customer.id]) remember(customer.name, false);
    }
    for (const record of state.patronRecords || []) {
      const legacyBad = record?.badGuestApproach === APPROACH_ID
        || Boolean(record?.badGuestIdentityId);
      if (legacyBad || legacyMigration) remember(record?.name, legacyBad);
    }
    for (const customer of data.wealthyPartyRoster || []) {
      if (customer?.badGuestWealthyParty || String(customer?.id || '').startsWith('bad-wealthy-party-')) {
        remember(customer.name, true);
      }
    }

    if (data.seenCustomerIds !== undefined) {
      delete data.seenCustomerIds;
      changed = true;
    }
    if (data.markedCustomerIds !== undefined) {
      delete data.markedCustomerIds;
      changed = true;
    }
    data.customerClassifications = classifications;
    return changed;
  }

  function enforceBadGuestIdentities(state) {
    let data = readData(state);
    const currentStored = state?.mods?.[WML_DATA_KEY];
    const legacyStored = state?.modData?.[DATA_KEY];
    const stored = currentStored ?? legacyStored;
    const needsStorageMigration = currentStored === undefined && legacyStored !== undefined;
    const legacyClassificationSchema = (Number(stored?.version) || 1) < 2;
    const needsSchemaMigration = legacyClassificationSchema
      || stored?.seenCustomerIds !== undefined
      || stored?.markedCustomerIds !== undefined;
    let dataChanged = needsStorageMigration;
    if (needsStorageMigration || needsSchemaMigration) {
      data = getData(state);
      if (needsSchemaMigration) {
        dataChanged = migrateCustomerClassifications(state, data, legacyClassificationSchema) || dataChanged;
      }
    }
    let customers = state.customers || [];
    let customerChanged = false;
    const records = state.patronRecords || [];

    customers.forEach((customer, index) => {
      const bad = customerClassification(data, customer) === 1;
      const hasLegacyFields = customer.badGuestApproach !== undefined
        || customer.badGuestApproachLabel !== undefined
        || customer.badGuestWealthyParty !== undefined;
      const needsBadGuestFix = bad && (
        customer.intent !== 'predatory'
        || customer.tacticStyle !== 'transactional'
        || (customer.boldness ?? 50) < 78
        || hasLegacyFields
      );
      if (!needsBadGuestFix && (bad || !hasLegacyFields)) return;
      if (!customerChanged) customers = [...customers];
      const fixed = bad ? fixedBadGuestCustomer(customer) : { ...customer };
      if (!bad) {
        delete fixed.badGuestApproach;
        delete fixed.badGuestApproachLabel;
        delete fixed.badGuestWealthyParty;
      }
      customers[index] = fixed;
      customerChanged = true;
    });

    let recordChanged = false;
    let patronRecords = records;
    records.forEach((record, index) => {
      const hasLegacyFields = record.badGuestIdentityId !== undefined
        || record.badGuestApproach !== undefined
        || record.badGuestApproachLabel !== undefined;
      if (!hasLegacyFields) return;
      if (!recordChanged) patronRecords = [...records];
      const fixed = { ...record };
      delete fixed.badGuestIdentityId;
      delete fixed.badGuestApproach;
      delete fixed.badGuestApproachLabel;
      patronRecords[index] = fixed;
      recordChanged = true;
    });

    if (!dataChanged && !customerChanged && !recordChanged) return state;
    return putData({
      ...state,
      customers,
      patronRecords: recordChanged ? patronRecords : state.patronRecords
    }, data);
  }

  const BAD_GUEST_FIRST_ARRIVAL_LINES = [
    (name, wifeName) => `${withParticle(name, '은', '는')} 앉기 전에 ${withParticle(wifeName, '과', '와')} 주인, 가까운 손님들을 차례로 살핍니다.`,
    (name, wifeName) => `${withParticle(name, '은', '는')} 빈자리를 지나쳐 ${wifeName}부터 봅니다. 그러고는 주인과 홀의 다른 손님들을 번갈아 바라봅니다.`,
    (name, wifeName) => `${withParticle(name, '은', '는')} 외투를 벗으면서도 ${wifeName}에게서 눈을 떼지 않습니다. 그녀가 홀을 오갈 때마다 시선이 따라갑니다.`,
    (name, wifeName) => `${withParticle(name, '은', '는')} ${withParticle(wifeName, '과', '와')} 홀 전체가 보이는 자리를 고릅니다. 앉자마자 손님들이 오가는 길을 살핍니다.`,
    (name, wifeName) => `${withParticle(name, '은', '는')} 돈주머니를 탁자에 올리고 ${withParticle(wifeName, '을', '를')} 부릅니다. 그녀가 다가오는 동안 주인의 시선을 살핍니다.`,
    (name, wifeName) => `${withParticle(name, '은', '는')} 공손히 인사한 뒤 ${wifeName} 곁의 사람들과 홀 분위기를 살핍니다.`
  ];

  const BAD_GUEST_RETURN_ARRIVAL_LINES = [
    (name, wifeName) => `${withParticle(name, '은', '는')} 들어서자마자 ${withParticle(wifeName, '을', '를')} 찾고, 이어 주인이 있는 쪽을 봅니다.`,
    (name, wifeName) => `${withParticle(name, '은', '는')} 홀 안쪽으로 향하며 ${wifeName}의 움직임을 좇습니다.`,
    (name, wifeName) => `${withParticle(name, '은', '는')} 메뉴를 보지 않고 주문합니다. 시선은 ${withParticle(wifeName, '과', '와')} 주인, 주변 손님들 사이를 오갑니다.`,
    (name, wifeName) => `${withParticle(name, '은', '는')} 주인에게 고개를 숙인 뒤 곧바로 ${withParticle(wifeName, '을', '를')} 봅니다.`,
    (name, wifeName) => `${withParticle(name, '은', '는')} 문을 닫고 홀을 둘러봅니다. ${withParticle(wifeName, '이', '가')} 잘 보이는 자리에 외투를 벗어 둡니다.`,
    (name, wifeName) => `빈자리가 여럿인데도 ${withParticle(name, '은', '는')} ${withParticle(wifeName, '이', '가')} 잘 보이는 곳에 앉습니다.`,
    (name, wifeName) => `${withParticle(name, '은', '는')} 주인에게 손을 들어 인사하며 ${wifeName}의 반응을 살핍니다.`,
    (name, wifeName) => `${withParticle(name, '은', '는')} 외투를 걸고 ${wifeName}의 이름을 부릅니다. 대답을 기다리며 홀을 둘러봅니다.`
  ];

  const BAD_GUEST_PATTERN_ARRIVAL_LINES = {
    enforcer: [
      (name, wifeName) => `${withParticle(name, '은', '는')} ${wifeName}에게 말을 걸며 탁자 끝을 손가락으로 두드립니다. 대답이 늦어지자 손을 멈춥니다.`,
      (name, wifeName) => `${withParticle(name, '은', '는')} 의자를 뒤로 빼 앉습니다. ${wifeName}가 지나가자 어깨를 돌려 길을 좁힙니다.`
    ],
    lurer: [
      (name, wifeName) => `${withParticle(name, '은', '는')} 술을 한 잔 더 주문하며 ${wifeName}에게 가벼운 농담을 건넵니다. 그녀의 대답을 기다리는 동안 잔은 손대지 않습니다.`,
      (name, wifeName) => `${withParticle(name, '은', '는')} ${wifeName}가 가까워지자 의자를 옆으로 돌립니다. “잠깐 이야기나 하시죠.”`
    ],
    infiltrator: [
      (name, wifeName) => `${withParticle(name, '은', '는')} 구석 자리에 앉아 잔을 만지작거립니다. ${wifeName}가 홀을 오갈 때마다 고개만 듭니다.`,
      (name, wifeName) => `${withParticle(name, '은', '는')} 주문을 마친 뒤 말을 아낍니다. ${wifeName}가 자리를 비우면 비로소 홀을 둘러봅니다.`
    ],
    impostor: [
      (name, wifeName) => `${withParticle(name, '은', '는')} ${wifeName}의 이름을 부드럽게 부릅니다. 그녀가 돌아보자 아무렇지 않게 술을 주문합니다.`,
      (name, wifeName) => `${withParticle(name, '은', '는')} ${wifeName}에게 익숙한 손님처럼 웃어 보입니다. 그녀의 표정을 살피며 잔을 내려놓습니다.`
    ]
  };

  const BAD_GUEST_APART_ARRIVAL_LINES = [
    name => `${withParticle(name, '은', '는')} 홀에 자리를 잡고 잔을 굴립니다. 사람들이 오갈 때마다 고개를 듭니다.`,
    name => `${withParticle(name, '은', '는')} 주문을 마치고도 외투를 벗지 않습니다. 홀을 둘러보다가 잔을 집어 듭니다.`,
    name => `${withParticle(name, '은', '는')} 바 가까운 자리를 고릅니다. 술이 나오자 한 모금만 마시고 주위를 살핍니다.`
  ];

  function badGuestArrivalText(state, customer, returning, ordinal = 0) {
    const customerRoom = customerLocation(state, customer.id);
    const wifeHere = customerRoom != null && customerRoom === wifeLocation(state);
    const lines = wifeHere
      ? [
        ...(returning ? BAD_GUEST_RETURN_ARRIVAL_LINES : BAD_GUEST_FIRST_ARRIVAL_LINES),
        ...(BAD_GUEST_PATTERN_ARRIVAL_LINES[badGuestPattern(customer).id] || [])
      ]
      : BAD_GUEST_APART_ARRIVAL_LINES;
    const record = state.patronRecords?.find(entry => entry.name === customer.name);
    const seed = `${customer.name}:${state.day ?? 0}:${state.slot ?? 0}:${record?.visitCount ?? 0}:${ordinal}`;
    return storyLine(state, `arrival:${returning}:${seed}`,
      lines.map(line => line(customer.name, wifeDisplayName(state))));
  }

  function markNewCustomers(state, previousState = null) {
    let out = enforceBadGuestIdentities(state);
    const stored = readData(out);
    let customers = out.customers || [];
    const newlyBadIds = new Set();
    const hasUnclassified = customers.some(customer =>
      isEligibleCustomer(customer) && customerClassification(stored, customer) == null
    );

    if (hasUnclassified) {
      const data = getData(out);
      customers = customers.map(customer => {
        if (!isEligibleCustomer(customer) || customerClassification(data, customer) != null) return customer;
        const bad = Math.random() < CONFIG.spawnChance;
        setCustomerClassification(data, customer, bad);
        if (!bad) return customer;
        newlyBadIds.add(customer.id);
        return fixedBadGuestCustomer(customer);
      });
      out = putData({ ...out, customers }, data);
    }

    const previousCustomers = new Map(
      (previousState?.customers || []).map(customer => [customer.id, customer])
    );
    const previousRecords = new Map(
      (previousState?.patronRecords || []).map(record => [record.name, record])
    );
    const currentRecords = new Map(
      (out.patronRecords || []).map(record => [record.name, record])
    );
    const arrivals = customers.filter(customer => {
      if (!isEligibleCustomer(customer) || !isBadGuest(out, customer)) return false;
      if (newlyBadIds.has(customer.id)) return true;
      if (!previousState || !ACTIVE_CUSTOMER_STATUSES.has(customer.status)) return false;
      const previous = previousCustomers.get(customer.id);
      const previousVisits = previousRecords.get(customer.name)?.visitCount ?? 0;
      const currentVisits = currentRecords.get(customer.name)?.visitCount ?? 0;
      return !previous
        || !ACTIVE_CUSTOMER_STATUSES.has(previous.status)
        || currentVisits > previousVisits;
    });

    arrivals.forEach((customer, index) => {
      out = appendLog(out, badGuestArrivalText(out, customer, !newlyBadIds.has(customer.id), index));
    });
    if (arrivals.length) {
      const data = getData(out);
      const visits = { ...data.drinkingGameVisits };
      for (const customer of arrivals) {
        const visitCount = currentRecords.get(customer.name)?.visitCount
          ?? previousRecords.get(customer.name)?.visitCount ?? 0;
        const visitKey = `${out.day ?? 1}:${visitCount}:${customer.id}:${out.slot}`;
        if (visits[customer.id]?.visitKey === visitKey) continue;
        visits[customer.id] = {
          visitKey,
          eligible: Math.random() < CONFIG.drinkingGameVisitChance,
          offered: false
        };
      }
      const activeIds = new Set((out.customers || [])
        .filter(customer => ACTIVE_CUSTOMER_STATUSES.has(customer.status))
        .map(customer => String(customer.id)));
      for (const id of Object.keys(visits)) if (!activeIds.has(String(id))) delete visits[id];
      data.drinkingGameVisits = visits;
      out = putData(out, data);
    }
    return out;
  }

  const WEALTHY_PARTY_NAMES = [
    '알드렌 베일', '코르빈 러스크', '마티아스 크로우', '오스윈 펠', '루시안 바르트',
    '가렌 모르', '테오발트 케인', '세드릭 로언', '로데릭 베스', '에드윈 세이블'
  ];

  function backRoomParty(state) {
    return state.locations?.back_room?.meta?.party || null;
  }

  function wealthyPartyMemberIds(state, party = readData(state).wealthyParty) {
    return new Set(party?.memberIds || []);
  }

  function markCustomerAsBadGuest(data, customer, state, extra = {}) {
    setCustomerClassification(data, customer, true);
    return fixedBadGuestCustomer(customer);
  }

  function createWealthyPartyCustomer(saved, index) {
    const base = saved ? { ...saved } : {
      id: `bad-wealthy-party-${index + 1}`,
      name: WEALTHY_PARTY_NAMES[index] || `비단 외투의 사내 ${index + 1}`,
      patronType: 'wealthy_pervert',
      charm: 68 + index * 2,
      boldness: 80 + index * 2,
      attributes: {
        strength: 54 + index * 2,
        deftness: 56 + index,
        wit: 66 + index * 2
      },
      roundsOrdered: 2,
      maxRounds: 6,
      walletGold: 0
    };
    delete base.groupId;
    delete base.partyId;
    delete base.isGuestModePlayer;
    delete base.isCollector;
    delete base.isGuard;
    return {
      ...base,
      id: `bad-wealthy-party-${index + 1}`,
      name: WEALTHY_PARTY_NAMES[index] || base.name || `비단 외투의 사내 ${index + 1}`,
      patronType: 'wealthy_pervert',
      status: 'drinking',
      order: null,
      isResident: true,
      stayTimer: 999,
      maxRounds: Math.max(6, base.maxRounds ?? 0),
      walletGold: CONFIG.wealthyPartyWalletBonus,
      hadInteractionThisVisit: false,
      forceDecidedTonight: undefined
    };
  }

  function wealthyPartyProfile(customer, index) {
    return {
      id: customer.id || `bad-wealthy-party-${index + 1}`,
      name: customer.name || WEALTHY_PARTY_NAMES[index] || `비단 외투의 사내 ${index + 1}`,
      patronType: 'wealthy_pervert',
      charm: customer.charm ?? 50,
      boldness: customer.boldness ?? 50,
      attributes: { ...(customer.attributes || {}) }
    };
  }

  function wealthyPartyOfferImpl(state, force = false) {
    let data = readData(state);
    if (!force) {
      if (state.phase !== 'service' || (state.day ?? 1) < CONFIG.wealthyPartyMinDay) return state;
      if ((state.tavernReputation?.notoriety ?? 0) < 5) return state;
      if (data.wealthyPartyLastDay != null
        && state.day - data.wealthyPartyLastDay < CONFIG.wealthyPartyCooldownDays) return state;

      if (data.wealthyPartyOfferScheduleDay !== state.day) {
        data = getData(state);
        data.wealthyPartyOfferScheduleDay = state.day;
        data.wealthyPartyOfferRollSlot = state.slot
          + Math.floor(Math.random() * CONFIG.wealthyPartyRollWindowMinutes);
        data.wealthyPartyOfferWonDay = null;
        state = putData(state, data);
        data = readData(state);
      }

      if (data.wealthyPartyOfferCheckedDay !== state.day) {
        if (state.slot < data.wealthyPartyOfferRollSlot) return state;
        data = getData(state);
        data.wealthyPartyOfferCheckedDay = state.day;
        data.wealthyPartyOfferWonDay = Math.random() < CONFIG.wealthyPartyDailyChance
          ? state.day
          : null;
        state = putData(state, data);
        data = readData(state);
      }
      if (data.wealthyPartyOfferWonDay !== state.day) return state;
    }

    if (state.pendingEvent || required.getActiveScene(state) || backRoomParty(state)) return state;
    if (state.tavern?.backRoomReady === false) return state;
    const backOccupants = (state.locations?.back_room?.occupants || [])
      .filter(id => id !== 'player' && id !== getWifeId(state));
    if (backOccupants.length > 0 || state.locations?.back_room?.meta?.privatePatron) return state;
    return {
      ...state,
      pendingEvent: {
        type: 'bad_guest_wealthy_party_offer',
        customerId: 'bad_guest_wealthy_party',
        customerName: '비단 외투의 사내들',
        category: 'scenario',
        text: `해가 기울 무렵, 비단 외투를 입은 사내 다섯이 들어옵니다. 맏이로 보이는 사내가 뒷방 문과 ${withParticle(wifeDisplayName(state), '을', '를')} 훑어본 뒤 바 위에 금화 쉰 개를 쌓습니다. “세 시간, 길면 네 시간이오. 술은 부르면 가져오시오. 문을 닫으면 방해하지 말고.” 나머지 네 사람도 ${wifeDisplayName(state)}에게 시선을 둡니다.`,
        choices: [
          { id: 'bad_guest_wealthy_party_accept', label: '50골드를 받고 뒷방을 내어주기', description: '서너 시간 동안 뒷방을 빌려 줍니다. 이 거래는 여관의 평판을 해칩니다.' },
          { id: 'bad_guest_wealthy_party_refuse', label: '“그런 모임은 받지 않습니다.”', description: '돈을 받지 않고 다섯 사람을 돌려보냅니다.' }
        ]
      }
    };
  }

  function wealthyPartyOffer(...args) {
    return runPublicProcess('wealthyPartyOfferCheck', wealthyPartyOfferImpl, args);
  }

  function startWealthyPartyImpl(state) {
    let out = { ...state, pendingEvent: undefined };
    let data = getData(out);
    const duration = CONFIG.wealthyPartyMinMinutes
      + Math.floor(Math.random() * (CONFIG.wealthyPartyMaxMinutes - CONFIG.wealthyPartyMinMinutes + 1));
    const savedRoster = data.wealthyPartyRoster || [];
    const reusedCount = Math.min(savedRoster.length, CONFIG.wealthyPartySize);
    const partyCustomers = [];
    for (let index = 0; index < CONFIG.wealthyPartySize; index += 1) {
      const prepared = createWealthyPartyCustomer(savedRoster[index], index);
      partyCustomers.push(markCustomerAsBadGuest(
        data,
        prepared,
        out,
        savedRoster[index] ? { dedicatedReturn: true } : { dedicatedCreated: true }
      ));
    }
    const memberIds = partyCustomers.map(customer => customer.id);
    const memberNames = partyCustomers.map(customer => customer.name);
    const memberIdSet = new Set(memberIds);
    const customers = [
      ...(out.customers || []).filter(customer => !memberIdSet.has(customer.id)),
      ...partyCustomers
    ];
    data.wealthyPartyRoster = partyCustomers.map(wealthyPartyProfile);

    out = { ...out, customers };
    for (const memberId of memberIds) out = putOccupantInRoom(out, memberId, 'back_room');
    const backRoom = out.locations?.back_room || { occupants: [] };
    out = {
      ...out,
      economy: {
        ...(out.economy || {}),
        gold: (out.economy?.gold ?? 0) + CONFIG.wealthyPartyRewardGold
      },
      goldEarnedToday: (out.goldEarnedToday ?? 0) + CONFIG.wealthyPartyRewardGold,
      incomeBreakdownToday: {
        ...(out.incomeBreakdownToday || {}),
        scenarios: (out.incomeBreakdownToday?.scenarios ?? 0) + CONFIG.wealthyPartyRewardGold
      },
      tavernReputation: {
        ...(out.tavernReputation || {}),
        notoriety: clamp((out.tavernReputation?.notoriety ?? 0) + CONFIG.wealthyPartyNotoriety)
      },
      locations: {
        ...(out.locations || {}),
        back_room: {
          ...backRoom,
          meta: {
            ...(backRoom.meta || {}),
            party: {
              occupiedBy: 'smugglers',
              startedAtSlot: out.slot,
              endSlot: out.slot + duration,
              mood: 30,
              drinksServed: 0
            }
          }
        }
      }
    };
    data.wealthyParty = {
      active: true,
      startedAtSlot: out.slot,
      endSlot: out.slot + duration,
      durationMinutes: duration,
      memberIds,
      memberNames,
      reusedCount,
      generatedCount: CONFIG.wealthyPartySize - reusedCount,
      cuffAttemptedIds: [],
      drugAttempts: 0,
      wifeVisits: 0,
      serveLocked: false,
      noMoreDrinkRequests: false,
      wifeVisitInProgress: false
    };
    data.wealthyPartyLastDay = out.day;
    out = putData(out, data);
    return appendLog(
      out,
      `금화 ${CONFIG.wealthyPartyRewardGold}개를 챙깁니다. 사내 다섯이 뒷방으로 향합니다. 그중 한 사내가 돌아보며 “${duration <= 210 ? '세 시간쯤 쓰겠소' : '네 시간은 넘기지 않겠소'}.”라고 말한 뒤 문을 닫습니다.`,
      { important: true, tone: 'distress' }
    );
  }


  function startWealthyParty(...args) {
    return runPublicProcess('wealthyPartyStart', startWealthyPartyImpl, args);
  }

  function drugLevelAt(state, effect = effectOf(readData(state), 'aphrodisiac')) {
    if (effect?.startedAtSlot == null) return 0;
    const elapsed = Math.max(0, state.slot - effect.startedAtSlot);
    const ramp = CONFIG.drugRampMinutes;
    const fall = CONFIG.drugFallMinutes;
    const end = effect.endsAtSlot ?? effect.startedAtSlot + CONFIG.drugDurationMinutes;
    const fallStart = end - fall;
    if (elapsed < ramp) return clamp((elapsed / ramp) * 100);
    if (state.slot >= end) return 0;
    const heldLevel = effect.heldLevel ?? 100;
    if (state.slot < fallStart) return heldLevel;
    return clamp(((end - state.slot) / fall) * heldLevel);
  }

  function drugPhase(state, effect) {
    if (!effect) return 'none';
    const elapsed = Math.max(0, state.slot - effect.startedAtSlot);
    if (elapsed < CONFIG.drugRampMinutes) return 'rising';
    const end = effect.endsAtSlot ?? effect.startedAtSlot + CONFIG.drugDurationMinutes;
    if (state.slot >= end) return 'ended';
    if (effect.heldLevel != null || state.slot >= end - CONFIG.drugFallMinutes) return 'falling';
    return 'plateau';
  }

  function timedEffectActive(state, kind) {
    const effect = effectOf(readData(state), kind);
    return Boolean(effect && (effect.endsAtSlot == null || state.slot < effect.endsAtSlot));
  }

  function equipmentOwnsCustomer(state, item, customerId) {
    if (!item || customerId == null) return false;
    if (String(item.patronId) === String(customerId)) return true;
    const data = readData(state);
    const wealthyParty = data.wealthyParty;
    if (wealthyParty?.active
      && wealthyParty.memberIds?.some(id => String(id) === String(item.patronId))
      && wealthyParty.memberIds?.some(id => String(id) === String(customerId))) {
      return true;
    }
    const drinkingGame = data.drinkingGame;
    return Boolean(
      drinkingGame?.active
      && drinkingGame.participantIds?.some(id => String(id) === String(item.patronId))
      && drinkingGame.participantIds?.some(id => String(id) === String(customerId))
    );
  }

  function equipmentApplies(state, kind, customerId = null) {
    const item = equipmentOf(readData(state), kind);
    if (!item) return false;
    if (customerId && !equipmentOwnsCustomer(state, item, customerId)) return false;
    return item.active === true || item.afterUntilSlot != null && state.slot < item.afterUntilSlot;
  }

  function imageEquipment(state, characterId) {
    if (!state || String(characterId) !== String(getWifeId(state))) return { blindfold: false, gag: false };
    const room = wifeLocation(state);
    const data = readData(state);
    const worn = kind => equipmentOf(data, kind)?.roomId === room && equipmentApplies(state, kind);
    return { blindfold: worn('blindfold'), gag: worn('gag') };
  }

  function confusionTarget(state) {
    if (unresponsiveDrugTarget(state)) return null;
    const effect = effectOf(readData(state), 'confusion');
    if (!effect || state.slot >= effect.endsAtSlot) return null;
    if (effect.mistakenForId === 'player') return 'player';
    const exists = (state.customers || []).some(customer => customer.id === effect.mistakenForId)
      || Boolean(state.characters?.[effect.mistakenForId]);
    return exists ? effect.mistakenForId : 'player';
  }

  function confusionPerceptionForPatron(state, patronReference) {
    if (api.gameVersion !== '2026-11-01') return null;
    const targetId = confusionTarget(state);
    if (!targetId) return null;
    const actualCustomer = typeof patronReference === 'object' && patronReference
      ? patronReference
      : (state.customers || []).find(customer => (
        String(customer.id) === String(patronReference)
        || customer.name === patronReference
      ));
    if (!actualCustomer?.id || String(actualCustomer.id) === String(targetId)) return null;
    if (targetId === 'player') {
      return {
        actualCustomer,
        perceivedId: 'player',
        perceivedName: '당신',
        perceivedPartner: 'player',
        perceivedPartnerType: 'player'
      };
    }
    const perceivedCustomer = (state.customers || []).find(customer => String(customer.id) === String(targetId));
    if (!perceivedCustomer?.name) return null;
    return {
      actualCustomer,
      perceivedId: perceivedCustomer.id,
      perceivedName: perceivedCustomer.name,
      perceivedPartner: perceivedCustomer.name,
      perceivedPartnerType: 'patron'
    };
  }

  function confusionPlayerDeceptionApplies(state, patronReference) {
    return confusionPerceptionForPatron(state, patronReference)?.perceivedPartnerType === 'player';
  }

  function wifePatronRelationshipPairKey(state, patronName) {
    const wifeKey = `char:${getWifeId(state)}`;
    const patronKey = `patron:${patronName}`;
    return wifeKey <= patronKey ? `${wifeKey}|${patronKey}` : `${patronKey}|${wifeKey}`;
  }

  function wifeTreatsPatronAsLover(state, customer) {
    if (!customer?.name) return false;
    const pairKey = wifePatronRelationshipPairKey(state, customer.name);
    return (state.relationships || []).some(relationship => (
      relationship?.pairKey === pairKey
      && relationship.romantic === 'lover'
    ));
  }

  function confusionLoverTargetContext(state, patronReference) {
    const targetId = confusionTarget(state);
    if (!targetId || targetId === 'player') return null;
    const perceivedCustomer = (state.customers || []).find(customer => String(customer.id) === String(targetId));
    if (!perceivedCustomer || !wifeTreatsPatronAsLover(state, perceivedCustomer)) return null;
    const actualCustomer = typeof patronReference === 'object' && patronReference
      ? patronReference
      : (state.customers || []).find(customer => (
        String(customer.id) === String(patronReference)
        || customer.name === patronReference
      ));
    if (!actualCustomer?.id) return null;
    return {
      actualCustomer,
      perceivedCustomer,
      samePerson: String(actualCustomer.id) === String(perceivedCustomer.id)
    };
  }

  function confusionTrustedTargetApplies(state, patronReference) {
    return confusionPlayerDeceptionApplies(state, patronReference)
      || Boolean(confusionLoverTargetContext(state, patronReference));
  }

  function equipmentFearApplies(state, customer) {
    return !wifeTreatsPatronAsLover(state, customer)
      && !confusionTrustedTargetApplies(state, customer);
  }

  function addEquipmentFear(state, customer, kind) {
    if (!equipmentFearApplies(state, customer)) return state;
    const blurb = kind === 'restraint'
      ? `${withParticle(customer.name, '이', '가')} 수갑으로 손목을 묶었다`
      : kind === 'blindfold'
        ? `${withParticle(customer.name, '이', '가')} 눈을 가리고 묶었다`
        : `${withParticle(customer.name, '이', '가')} 입을 막고 묶었다`;
    return wrappedAddFeeling(state, 'fear', {
      intensity: EQUIPMENT_FEAR_INTENSITY[kind],
      source: `patron:${customer.name.toLowerCase()}:${kind}`,
      target: { kind: 'patron', id: customer.name.toLowerCase() },
      durationSlots: kind === 'restraint' ? 300 : 180,
      blurb
    });
  }

  function confusionEquipmentBonus(state, patronReference) {
    return confusionTrustedTargetApplies(state, patronReference)
      ? CONFUSION_TRUST_BONUS_PERCENT / 100
      : 0;
  }

  function confusionAdjustedDrugDefenseBase(state, patronReference, basePercent) {
    return basePercent - (confusionTrustedTargetApplies(state, patronReference)
      ? CONFUSION_TRUST_BONUS_PERCENT
      : 0);
  }

  function confusionAdjustedPlayerDefenseBase(state, patronReference, basePercent) {
    return basePercent - (confusionPlayerDeceptionApplies(state, patronReference)
      ? CONFUSION_TRUST_BONUS_PERCENT
      : 0);
  }

  function intoxicationNoticePenalty(character) {
    const intoxication = Math.max(0, Number(character?.intoxication?.level) || 0);
    return Math.min(20, intoxication * 0.25);
  }

  function withConfusionSubjectiveContext(state, patronReference, callback) {
    const perception = confusionPerceptionForPatron(state, patronReference);
    if (!perception) return callback(null);
    const previous = confusionSubjectiveContext;
    confusionSubjectiveContext = { state, perception };
    try {
      return callback(perception);
    } finally {
      confusionSubjectiveContext = previous;
    }
  }

  function activeAphrodisiacEffect(state) {
    const effect = effectOf(readData(state), 'aphrodisiac');
    return effect && drugLevelAt(state, effect) > 0 ? effect : null;
  }

  function aphrodisiacEventForScene(state, patronReference) {
    const scene = required.getActiveScene(state);
    if (!scene || !Number.isFinite(Number(scene.startedAtSlot))) return null;
    const patronId = typeof patronReference === 'object'
      ? patronReference?.id
      : (state.customers || []).find(customer => (
        String(customer.id) === String(patronReference)
        || customer.name === patronReference
      ))?.id ?? scene.customerId;
    const categories = scene?.stage ? [scene.stage, STAGE_CATEGORIES[scene.stage]].filter(Boolean) : [];
    const events = [...(readData(state).aphrodisiacMemories?.events || [])].reverse().filter(event => (
      event.answer === 'yes'
      && String(event.patronId) === String(patronId)
      && Number(event.slot) >= Number(scene.startedAtSlot)
      && Number(event.slot) <= Number(state.slot)
    ));
    return events.find(event => categories.includes(event.category)) || events[0] || null;
  }

  const PRIMARY_PATRON_HISTORY_ACTS = new Set([
    'bold_touch', 'groping', 'fingering', 'handjob', 'blowjob',
    'thigh_job', 'sex', 'riding', 'anal'
  ]);

  function historyMemoryMatchesAct(memory, event, category) {
    if (memory.category !== category) return false;
    if (category !== 'sex_patron') return true;
    if (event.actId === 'anal') {
      return memory.decisionCategory === 'sex_anal'
        || memory.historySlot === 'inside_anal';
    }
    if (event.actId === 'sex' || event.actId === 'riding') {
      return memory.decisionCategory !== 'sex_anal'
        && memory.historySlot !== 'inside_anal';
    }
    return true;
  }

  function patronHistoryScene(state, event) {
    const scene = required.getActiveScene(state);
    if (!scene || !Number.isFinite(Number(scene.startedAtSlot))) {
      const ending = endingPatronIncidentContext;
      if (ending?.patronName !== event.partner
        || !Number.isFinite(Number(ending.startedAtSlot))) return null;
      return { scene: ending, patronId: ending.patronId, primary: true };
    }
    const primary = scene.customerName === event.partner;
    const joinedIds = primary ? [] : (scene.joinedPatronIds || []).filter(id => (
      state.customers?.some(customer => String(customer.id) === String(id)
        && customer.name === event.partner)
    ));
    if (!primary && joinedIds.length !== 1) return null;
    return { scene, patronId: primary ? scene.customerId : joinedIds[0], primary };
  }

  function aphrodisiacHistoryMemory(state, event, category) {
    const owner = patronHistoryScene(state, event);
    const startedAt = owner ? Number(owner.scene.startedAtSlot) : Number(state.slot);
    const endedAt = Number(state.slot);
    const patron = owner?.patronId == null
      ? (state.customers || []).find(customer => customer.name === event.partner)
      : null;
    const patronId = owner?.patronId ?? patron?.id;
    if (patronId == null) return null;
    const matches = [...(readData(state).aphrodisiacMemories?.events || [])].reverse().filter(memory => (
      memory.answer === 'yes'
      && String(memory.patronId) === String(patronId)
      && memory.patronName === event.partner
      && Number(memory.slot) >= startedAt
      && Number(memory.slot) <= endedAt
    ));
    const exact = matches.find(memory => historyMemoryMatchesAct(memory, event, category));
    if (exact) return exact;
    if (owner?.primary && PRIMARY_PATRON_HISTORY_ACTS.has(event.actId)) {
      const assisted = matches.find(memory => memory.drugChangedOutcome === true);
      if (assisted) return assisted;
    }
    const recent = latestAphrodisiacAcceptance;
    const effect = activeAphrodisiacEffect(state);
    if (!recent || !effect || recent.episodeId !== effect.episodeId
      || recent.slot !== endedAt || String(recent.customerId) !== String(patronId)) return null;
    const decisionCategories = [category, STAGE_CATEGORIES[category]];
    if (event.actId === 'anal') decisionCategories.push('sex_anal');
    if (event.actId === 'cum_on_body') decisionCategories.push('cum_on_skin');
    if (!decisionCategories.includes(recent.category)
      || acceptanceAnswer(recent.decision) !== 'yes') return null;
    const unassistedAnswer = acceptanceAnswer(recent.unassistedDecision);
    return {
      episodeId: effect.episodeId,
      fromCurrentDecision: true,
      slot: endedAt,
      patronId,
      patronName: event.partner,
      category,
      decisionCategory: recent.category,
      answer: 'yes',
      unassistedAnswer,
      unassistedOutcome: recent.unassistedDecision?.outcome ?? null,
      drugChangedOutcome: unassistedAnswer === 'no',
      given: unassistedAnswer === 'yes'
    };
  }

  function withAphrodisiacSubjectiveContext(state, patronReference, callback) {
    const event = aphrodisiacEventForScene(state, patronReference);
    if (!event) return callback(null);
    const previous = aphrodisiacSubjectiveContext;
    aphrodisiacSubjectiveContext = { state, event, pendingAftermathFeeling: false };
    try {
      return callback(event);
    } finally {
      aphrodisiacSubjectiveContext = previous;
    }
  }

  function perceivedCustomer(state, perception) {
    if (!perception || perception.perceivedPartnerType !== 'patron') return null;
    return (state.customers || []).find(customer => (
      String(customer.id) === String(perception.perceivedId)
      || customer.name === perception.perceivedName
    )) || null;
  }

  function subjectiveOtherWitnessCount(state, actualCustomerId) {
    const roomId = wifeLocation(state);
    const occupants = state.locations?.[roomId]?.occupants || [];
    const wifeId = getWifeId(state);
    return occupants.filter(id => (
      String(id) !== String(wifeId)
      && String(id) !== 'player'
      && String(id) !== String(actualCustomerId)
    )).length;
  }

  function confusionAftermathAction(scene) {
    if (!scene?.stage) return null;
    if (scene.stage === 'sex_patron') {
      if (scene.primarySlot === 'inside_anal') return 'anal';
      if (scene.primarySlot === 'astride') return 'riding';
    }
    return CONFUSION_AFTERMATH_ACTION[scene.stage] || null;
  }

  function confusionAffinityValue(affinities, tag) {
    if (tag === 'submission') return -Number(affinities?.dominance || 0);
    if (tag === 'domination') return Number(affinities?.dominance || 0);
    return Number(affinities?.[tag] || 0);
  }

  function confusionPlayerAftermathAlignment(state) {
    const action = confusionAftermathAction(required.getActiveScene(state));
    const tags = CONFUSION_ACTION_AFFINITIES[action] || [];
    if (!tags.length) return 0;
    const affinities = getWife(state)?.affinities || {};
    return tags.reduce((sum, tag) => sum + confusionAffinityValue(affinities, tag), 0) / tags.length;
  }

  function recentConfusionSubjectiveContext(state, patronReference, allowLastPatronContext = false) {
    if (confusionSubjectiveContext?.perception) return confusionSubjectiveContext;
    const liveReference = patronReference ?? required.getActiveScene(state)?.customerId;
    const livePerception = confusionPerceptionForPatron(state, liveReference);
    if (livePerception) return { state, perception: livePerception };
    if (!allowLastPatronContext) return null;
    const lpc = getWife(state)?.lastPatronContext;
    if (!lpc || lpc.createdAtSlot !== state.slot || !lpc.badGuestPerceivedPartnerType) return null;
    const actualCustomer = (state.customers || []).find(customer => (
      String(customer.id) === String(lpc.badGuestActualPatronId)
      || customer.name === lpc.badGuestActualPatronName
    ));
    if (!actualCustomer) return null;
    return {
      state,
      perception: {
        actualCustomer,
        perceivedId: lpc.badGuestPerceivedPartnerId,
        perceivedName: lpc.badGuestPerceivedPartnerName,
        perceivedPartner: lpc.badGuestPerceivedPartnerName,
        perceivedPartnerType: lpc.badGuestPerceivedPartnerType
      }
    };
  }

  function wrappedAddFeeling(state, emotion, details = {}) {
    const source = String(details?.source || '');
    const aphrodisiacContext = aphrodisiacSubjectiveContext;
    if (aphrodisiacContext?.event?.drugChangedOutcome) {
      const event = aphrodisiacContext.event;
      const patronPrefix = `patron:${String(event.patronName || '').toLowerCase()}:`;
      const belongsToPatron = source.toLowerCase().startsWith(patronPrefix);
      if (aphrodisiacContext.pendingAftermathFeeling && belongsToPatron) {
        aphrodisiacContext.pendingAftermathFeeling = false;
        const action = source.slice(patronPrefix.length) || event.category || 'intimacy';
        return original.addFeeling(state, 'regret', {
          ...details,
          source: `patron:${String(event.patronName || '').toLowerCase()}:aphrodisiac_assisted:${action}`,
          blurb: '낯선 열기를 이기지 못해 평소라면 거절했을 일을 받아들였다',
          badGuestAphrodisiacEpisodeId: event.episodeId,
          badGuestAphrodisiacAssisted: true,
          badGuestUnassistedAccepted: false
        });
      }
      if (belongsToPatron) {
        const action = source.slice(patronPrefix.length) || event.category || 'intimacy';
        return original.addFeeling(state, emotion, {
          ...details,
          source: `patron:${String(event.patronName || '').toLowerCase()}:aphrodisiac:${action}`,
          badGuestAphrodisiacEpisodeId: event.episodeId,
          badGuestAphrodisiacAssisted: true,
          badGuestUnassistedAccepted: false
        });
      }
    }
    const caughtFollowup = source === 'caught_in_act' || source === 'caught_brazen';
    const context = recentConfusionSubjectiveContext(state, null, caughtFollowup);
    const perception = context?.perception;
    if (!perception) return original.addFeeling(state, emotion, details);
    const effect = effectOf(readData(context.state || state), 'confusion');
    const acceptance = confusionCounterfactualAcceptance(
      context.state || state,
      perception,
      required.getActiveScene(context.state || state)?.stage
    );
    const taggedDetails = {
      ...details,
      badGuestConfusionEpisodeId: effect?.episodeId ?? null,
      badGuestActualPatronId: perception.actualCustomer.id,
      badGuestActualPatronName: perception.actualCustomer.name,
      badGuestPerceivedPartnerId: perception.perceivedId,
      badGuestPerceivedPartnerName: perception.perceivedName,
      badGuestPerceivedPartnerType: perception.perceivedPartnerType,
      badGuestCounterfactualAccepted: acceptance?.actualAnswer === 'yes'
    };
    const actualPrefix = `patron:${perception.actualCustomer.name.toLowerCase()}:`;
    const perceivedPrefix = `patron:${perception.perceivedName.toLowerCase()}:`;
    const sourceLower = source.toLowerCase();
    if (confusionClimaxEmotionProjection?.perceivedPartnerType === 'player'
      && String(confusionClimaxEmotionProjection.actualPatronId) === String(perception.actualCustomer.id)
      && (sourceLower.startsWith(actualPrefix) || sourceLower.startsWith(perceivedPrefix))) {
      const climaxPrefix = sourceLower.startsWith(actualPrefix) ? actualPrefix : perceivedPrefix;
      const climaxSuffix = sourceLower.slice(climaxPrefix.length);
      if (climaxSuffix.startsWith('climax:') || climaxSuffix.startsWith('she_came_anyway:')) {
        return state;
      }
    }
    if (perception.perceivedPartnerType === 'player'
      && (source === 'caught_in_act' || source === 'caught_brazen')) return state;
    const matchedPrefix = sourceLower.startsWith(actualPrefix)
      ? actualPrefix
      : sourceLower.startsWith(perceivedPrefix) ? perceivedPrefix : null;
    const belongsToActualPatron = matchedPrefix != null;
    if (!belongsToActualPatron) return original.addFeeling(state, emotion, taggedDetails);

    const suffix = source.slice(matchedPrefix.length);
    if (perception.perceivedPartnerType === 'player') {
      if (suffix === 'betrayal' || suffix === 'while_he_watched') return state;
      if (suffix.includes('she_came_anyway')
        && (emotion === 'guilt' || emotion === 'shame')) return state;
      if (suffix === 'witnessed'
        && subjectiveOtherWitnessCount(context.state, perception.actualCustomer.id) === 0) return state;
    }

    let subjectiveDetails = taggedDetails;
    if (perception.perceivedPartnerType === 'player' && details.target?.kind === 'patron') {
      const { target: _actualPatronTarget, ...withoutPatronTarget } = taggedDetails;
      subjectiveDetails = withoutPatronTarget;
    }
    const actualName = perception.actualCustomer.name;
    const blurb = typeof details.blurb === 'string'
      ? details.blurb.split(actualName).join(perception.perceivedName)
      : details.blurb;
    const subjectiveSuffix = perception.perceivedPartnerType === 'player'
      && emotion === 'guilt'
      && Object.prototype.hasOwnProperty.call(STAGE_LABELS, suffix)
      ? `${suffix}:conflicted_climax`
      : suffix;
    const subjectiveBlurb = perception.perceivedPartnerType === 'player'
      && emotion === 'guilt'
      && Object.prototype.hasOwnProperty.call(STAGE_LABELS, suffix)
      && blurb === undefined
      ? '행위와 가치관의 충돌'
      : blurb;
    return original.addFeeling(state, emotion, {
      ...subjectiveDetails,
      source: perception.perceivedPartnerType === 'player'
        ? `player:confusion:${subjectiveSuffix}`
        : `patron:${perception.perceivedName.toLowerCase()}:${suffix}`,
      ...(details.target?.kind === 'patron' && perception.perceivedPartnerType === 'patron'
        ? { target: { kind: 'patron', id: perception.perceivedName.toLowerCase() } }
        : {}),
      ...(suffix === 'witnessed' && perception.perceivedPartnerType === 'player'
        ? { blurb: 'other people saw what happened' }
        : subjectiveBlurb !== undefined ? { blurb: subjectiveBlurb } : {})
    });
  }

  function wrappedAddIdentityStrainFromPatronAct(state, details) {
    if (aphrodisiacSubjectiveContext?.event?.drugChangedOutcome) return state;
    const active = recentConfusionSubjectiveContext(state);
    if (active?.perception?.perceivedPartnerType === 'player') return state;
    if (active?.perception) {
      const acceptance = confusionCounterfactualAcceptance(state, active.perception, details?.stage);
      if (acceptance?.actualAnswer !== 'yes') return state;
    }
    const lpc = getWife(state)?.lastPatronContext;
    if (lpc?.badGuestSuppressCaughtIdentity === true
      && lpc.createdAtSlot === state.slot
      && lpc.maxStage === details?.stage) {
      return updateWife(state, wife => {
        const nextContext = { ...(wife.lastPatronContext || {}) };
        delete nextContext.badGuestSuppressCaughtIdentity;
        return { ...wife, lastPatronContext: nextContext };
      });
    }
    return original.addIdentityStrainFromPatronAct(state, details);
  }

  function wrappedPatronAftermathFeeling(input) {
    if (aphrodisiacSubjectiveContext?.event?.drugChangedOutcome) {
      aphrodisiacSubjectiveContext.pendingAftermathFeeling = true;
      return { emotion: 'regret', intensity: 50 };
    }
    const context = confusionSubjectiveContext;
    const perception = context?.perception;
    if (!perception) return original.patronControlAftermathFeeling(input);
    if (perception.perceivedPartnerType === 'player') {
      return original.patronControlAftermathFeeling({
        ...input,
        alignmentScore: confusionPlayerAftermathAlignment(context.state),
        isWithPlayer: true,
        hasRomanticContext: true,
        isPaid: false,
        patronBondAdjustment: 0
      });
    }
    const record = (context.state.patronRecords || [])
      .find(entry => entry.name === perception.perceivedName);
    const patronBondAdjustment = record
      ? ((record.romantic || 0) + (record.sexual || 0)) / 200 * 0.6
      : 0;
    return original.patronControlAftermathFeeling({ ...input, patronBondAdjustment });
  }

  function wrappedPatronRecordFirsts(state, interaction, witnessed) {
    const perception = confusionPerceptionForPatron(state, interaction?.customerId);
    if (!perception) {
      const event = aphrodisiacSubjectiveContext?.event
        || aphrodisiacEventForScene(state, interaction?.customerId);
      if (!event) return original.patronControlRecordFirsts(state, interaction, witnessed);
      const before = getWife(state)?.firstsWithOthers;
      const recorded = original.patronControlRecordFirsts(state, interaction, witnessed);
      if (!event.drugChangedOutcome) return recorded;
      return updateWife(recorded, wife => {
        const after = wife.firstsWithOthers;
        if (Array.isArray(after)) {
          const start = Array.isArray(before) ? before.length : 0;
          return {
            ...wife,
            firstsWithOthers: after.map((entry, index) => index < start ? entry : {
              ...entry,
              given: false,
              badGuestAphrodisiacEpisodeId: event.episodeId,
              badGuestAphrodisiacAssisted: true
            })
          };
        }
        const next = { ...(after || {}) };
        for (const [key, value] of Object.entries(next)) {
          if (before?.[key] || !value) continue;
          next[key] = {
            ...value,
            given: false,
            badGuestAphrodisiacEpisodeId: event.episodeId,
            badGuestAphrodisiacAssisted: true
          };
        }
        return { ...wife, firstsWithOthers: next };
      });
    }
    const beforeWife = getWife(state);
    const beforeFirsts = beforeWife?.firstsWithOthers;
    const recorded = perception.perceivedPartnerType === 'player'
      ? state
      : original.patronControlRecordFirsts(state, {
        ...interaction,
        customerName: perception.perceivedName
      }, witnessed);
    return markConfusionFirsts(
      recorded,
      beforeFirsts,
      interaction,
      witnessed,
      perception,
      beforeWife?.mood
    );
  }

  function wrappedPatronCrossedLine(state, category, source, options) {
    if (aphrodisiacSubjectiveContext?.event?.drugChangedOutcome) return state;
    const perception = confusionSubjectiveContext?.perception
      || confusionPerceptionForPatron(state, required.getActiveScene(state)?.customerId);
    if (!perception) return original.patronControlCrossedLine(state, category, source, options);
    if (perception.perceivedPartnerType === 'player') return state;
    if (confusionCounterfactualAcceptance(state, perception, category)?.actualAnswer !== 'yes') return state;
    const actualName = perception.actualCustomer.name;
    const perceivedSource = typeof source === 'string'
      ? source.split(actualName).join(perception.perceivedName)
      : source;
    return original.patronControlCrossedLine(state, category, perceivedSource, options);
  }

  function wrappedPatronSelfConceptDrift(state, stage, connection) {
    if (aphrodisiacSubjectiveContext?.event?.drugChangedOutcome) return state;
    const perception = confusionSubjectiveContext?.perception
      || confusionPerceptionForPatron(state, required.getActiveScene(state)?.customerId);
    if (perception?.perceivedPartnerType === 'player') return state;
    if (perception
      && confusionCounterfactualAcceptance(state, perception, stage)?.actualAnswer !== 'yes') return state;
    return original.patronControlSelfConceptDrift(state, stage, connection);
  }

  function wrappedPatronAftercareFeeling(state, interaction, connection) {
    if (aphrodisiacSubjectiveContext?.event?.drugChangedOutcome) return state;
    const perception = confusionPerceptionForPatron(state, interaction?.customerId);
    if (!perception) return original.patronControlAftercareFeeling(state, interaction, connection);
    return withConfusionSubjectiveContext(state, interaction.customerId, () => (
      original.patronControlAftercareFeeling(state, {
        ...interaction,
        customerName: perception.perceivedPartnerType === 'player'
          ? perception.actualCustomer.name
          : perception.perceivedName
      }, connection)
    ));
  }

  function wrappedPatronAftercareBond(state, interaction, connection) {
    if (aphrodisiacSubjectiveContext?.event?.drugChangedOutcome) return state;
    const perception = confusionPerceptionForPatron(state, interaction?.customerId);
    if (!perception) return original.patronControlAftercareBond(state, interaction, connection);
    return state;
  }

  const SUBJECTIVE_PATRON_RECORD_FIELDS = ['platonic', 'romantic', 'sexual', 'kindnessCount'];

  function copyPatronRecordFields(state, sourceState, patronName, fields) {
    const source = (sourceState.patronRecords || []).find(record => record.name === patronName);
    return {
      ...state,
      patronRecords: (state.patronRecords || []).map(record => {
        if (record.name !== patronName) return record;
        const next = { ...record };
        for (const field of fields) {
          if (source && Object.prototype.hasOwnProperty.call(source, field)) next[field] = source[field];
          else next[field] = 0;
        }
        return next;
      })
    };
  }

  function preserveEligiblePatronMaxStage(state, sourceState, patronName, interaction) {
    if (interaction?.badGuestMaxStageRestricted !== true) return state;
    const previous = (sourceState.patronRecords || []).find(record => record.name === patronName);
    const eligibleMaxStage = laterPatronStage(
      previous?.maxStageReached,
      interaction.badGuestEligibleMaxStage
    );
    return {
      ...state,
      patronRecords: (state.patronRecords || []).map(record => (
        record.name === patronName
          ? { ...record, maxStageReached: eligibleMaxStage }
          : record
      ))
    };
  }

  function wrappedPatronRecordVisitOutcome(state, interaction, tipGold) {
    const perception = confusionPerceptionForPatron(state, interaction?.customerId);
    const patronName = perception?.actualCustomer?.name || interaction.customerName;
    const factual = preserveEligiblePatronMaxStage(
      original.patronControlRecordVisitOutcome(state, interaction, tipGold),
      state,
      patronName,
      interaction
    );
    if (!perception && aphrodisiacSubjectiveContext?.event?.drugChangedOutcome) {
      const out = copyPatronRecordFields(
        factual,
        state,
        interaction.customerName,
        SUBJECTIVE_PATRON_RECORD_FIELDS
      );
      const wifeBefore = getWife(state);
      return updateWife(out, wife => ({
        ...wife,
        feelings: wifeBefore?.feelings,
        notedMoments: wifeBefore?.notedMoments
      }));
    }
    if (!perception) return factual;

    let out = copyPatronRecordFields(
      factual,
      state,
      perception.actualCustomer.name,
      SUBJECTIVE_PATRON_RECORD_FIELDS
    );
    const wifeBefore = getWife(state);
    return updateWife(out, wife => ({
      ...wife,
      feelings: wifeBefore?.feelings,
      notedMoments: wifeBefore?.notedMoments
    }));
  }

  function wrappedPatronAdvanceNamedPatron(state, patronName) {
    if (aphrodisiacSubjectiveContext?.event?.drugChangedOutcome) return state;
    const perception = confusionSubjectiveContext?.perception
      || confusionPerceptionForPatron(state, patronName);
    if (!perception) return original.patronControlAdvanceNamedPatron(state, patronName);
    return state;
  }

  function wrappedPatronOtherRelationshipReaction(state, interaction, location, patronName) {
    if (aphrodisiacSubjectiveContext?.event?.drugChangedOutcome) return state;
    const perception = confusionSubjectiveContext?.perception
      || confusionPerceptionForPatron(state, interaction?.customerId);
    if (!perception) {
      return original.patronControlOtherRelationshipReaction(state, interaction, location, patronName);
    }
    return state;
  }

  function subjectivePatronContext(context, perception) {
    const episodeId = effectOf(readData(confusionSubjectiveContext?.state), 'confusion')?.episodeId ?? null;
    return {
      ...context,
      patronName: perception.perceivedName,
      badGuestActualPatronId: perception.actualCustomer.id,
      badGuestActualPatronName: perception.actualCustomer.name,
      badGuestPerceivedPartnerId: perception.perceivedId,
      badGuestPerceivedPartnerName: perception.perceivedName,
      badGuestPerceivedPartnerType: perception.perceivedPartnerType,
      badGuestConfusionEpisodeId: episodeId
    };
  }

  function latestConfusionEventForScene(state, interaction) {
    if (!interaction?.customerId) return null;
    const startedAt = Number(interaction.startedAtSlot ?? -Infinity);
    return [...(readData(state).confusionMemories?.events || [])].reverse().find(event => (
      String(event?.actualPatronId) === String(interaction.customerId)
      && Boolean(event?.episodeId)
      && (event.perceivedType === 'player'
        || String(event.perceivedId) !== String(interaction.customerId))
      && event?.answer === 'yes'
      && Number(event?.slot ?? -Infinity) >= startedAt
      && Number(event?.slot ?? Infinity) <= Number(state.slot ?? Infinity)
    )) || null;
  }

  function patronIncidentForEnd(state, interaction, aphrodisiacEvent, perception) {
    if (!interaction?.customerId) return null;
    const startedAt = Number(interaction.startedAtSlot ?? -Infinity);
    const sceneAphrodisiacEvents = [...(readData(state).aphrodisiacMemories?.events || [])].reverse()
      .filter(event => event.answer === 'yes'
        && String(event.patronId) === String(interaction.customerId)
        && Number(event.slot) >= startedAt
        && Number(event.slot) <= Number(state.slot));
    const assistedAphrodisiacEvent = sceneAphrodisiacEvents.find(event => event.drugChangedOutcome === true);
    const incidentAphrodisiacEvent = assistedAphrodisiacEvent || aphrodisiacEvent;
    const aphrodisiac = incidentAphrodisiacEvent
      && Number(incidentAphrodisiacEvent.slot ?? -Infinity) >= startedAt
      ? {
        episodeId: incidentAphrodisiacEvent.episodeId ?? null,
        assisted: assistedAphrodisiacEvent != null,
        unassistedAccepted: assistedAphrodisiacEvent == null
          && incidentAphrodisiacEvent.unassistedAnswer === 'yes'
      }
      : null;
    const rememberedConfusion = latestConfusionEventForScene(state, interaction);
    const confusion = perception ? {
      episodeId: effectOf(readData(state), 'confusion')?.episodeId ?? null,
      perceivedId: perception.perceivedId,
      perceivedName: perception.perceivedName,
      perceivedType: perception.perceivedPartnerType,
      actualAccepted: rememberedConfusion?.actualAnswer === 'yes'
        ? true
        : rememberedConfusion?.actualAnswer === 'no' ? false : null
    } : rememberedConfusion ? {
      episodeId: rememberedConfusion.episodeId ?? null,
      perceivedId: rememberedConfusion.perceivedId,
      perceivedName: rememberedConfusion.perceivedName,
      perceivedType: rememberedConfusion.perceivedType,
      actualAccepted: rememberedConfusion.actualAnswer === 'yes'
        ? true
        : rememberedConfusion.actualAnswer === 'no' ? false : null
    } : null;
    const restraint = equipmentOf(readData(state), 'restraint');
    const coerced = interaction.coercedSinceSlot != null
      || interaction.wasPressuredIntoStage === true;
    const coercion = coerced ? {
      kind: restraintOwnsCustomer(state, interaction.customerId, restraint)
        ? 'restraint'
        : 'pressure',
      sinceSlot: interaction.coercedSinceSlot ?? null
    } : null;
    if (!aphrodisiac && !confusion && !coercion) return null;
    return {
      patronId: interaction.customerId,
      patronName: interaction.customerName,
      startedAtSlot: interaction.startedAtSlot,
      stage: interaction.stage,
      primarySlot: interaction.primarySlot,
      gropePlace: interaction.gropePlace,
      walkIn: interaction.walkIn === true,
      slot: state.slot,
      aphrodisiac,
      confusion,
      coercion
    };
  }

  function joinInBlocked(state) {
    const scene = required.getActiveScene(state);
    if (!scene) return false;
    const data = readData(state);
    if (['restraint', 'blindfold', 'gag'].some(kind => equipmentApplies(state, kind))) return true;
    if (timedEffectActive(state, 'aphrodisiac')
      || timedEffectActive(state, 'confusion')
      || timedEffectActive(state, 'intoxicationFloor')
      || data.pendingDrug
      || data.sleepPotion?.pending
      || data.sleepPotion?.incident
      || data.sleepPotion?.roomWatch) return true;
    if (!Number.isFinite(Number(scene.startedAtSlot))) return false;
    return Boolean(
      aphrodisiacEventForScene(state, scene.customerId)
      || latestConfusionEventForScene(state, scene)
    );
  }

  function confusionIncidentRecovered(state, incident) {
    const episodeId = incident?.confusion?.episodeId;
    if (!episodeId) return false;
    return (readData(state).confusionMemories?.recoveries || []).some(entry => (
      entry?.kind === 'episode_result'
      && entry.episodeId === episodeId
      && entry.success === true
    ));
  }

  function incidentExplanationParts(state, incident) {
    const patronName = incident?.patronName || '그 손님';
    const voice = storyVoice(state);
    const speech = (elena, mara, pippa, other = mara) => `“${
      voice === 'elena' ? elena : voice === 'mara' ? mara : voice === 'pippa' ? pippa : other
    }”`;
    const parts = [];
    if (incident?.coercion) {
      parts.push(incident.coercion.kind === 'restraint'
        ? speech('분명히 거절했어요. 묶여 있어서 밀어낼 수가 없었어요.',
          '싫다고 했어. 묶인 채로는 밀어낼 수 없었지.',
          '싫다고 말했어. 묶여 있어서 손도 못 밀어냈어.')
        : speech('분명히 거절했어요. 그런데도 그 사람은 멈추지 않았어요.',
          '싫다고 했어. 그런데도 그는 멈추지 않았어.',
          '싫다고 했는데도 그 사람이 멈추지 않았어.'));
    }
    if (incident?.confusion) {
      const recovered = confusionIncidentRecovered(state, incident);
      if (incident.confusion.perceivedType === 'player') {
        parts.push(recovered
          ? speech(`그땐 당신이 제 곁에 있는 줄 알았어요. 지금은 ${withParticle(patronName, '이었다는', '였다는')} 걸 알아요.`,
            `그땐 네가 내 곁에 있는 줄 알았어. 지금은 ${withParticle(patronName, '이었다는', '였다는')} 걸 알아.`,
            `그때는 네가 내 곁에 있는 줄만 알았어. 이제야 ${withParticle(patronName, '이었다는', '였다는')} 걸 알아.`)
          : speech('그때 당신이 제 곁에 있었잖아요. 저는 그렇게 기억해요.',
            '그때 네가 내 곁에 있었잖아. 난 분명히 기억해.',
            '그때 네가 내 옆에 있었잖아. 난 분명히 기억해.'));
      } else {
        const perceived = incident.confusion.perceivedName || '다른 사람';
        parts.push(recovered
          ? speech(`그때는 ${withParticle(perceived, '이라고', '라고')} 믿었어요. 지금은 ${withParticle(patronName, '이었다는', '였다는')} 걸 알아요.`,
            `그때는 ${withParticle(perceived, '이라고', '라고')} 믿었어. 지금은 ${withParticle(patronName, '이었다는', '였다는')} 걸 알아.`,
            `그때는 ${perceived}인 줄 알았어. 이제는 ${withParticle(patronName, '이었다는', '였다는')} 걸 알아.`)
          : speech(`무슨 말이에요? 그때 제 곁에 있던 건 ${withParticle(perceived, '이었어요', '였어요')}.`,
            `무슨 말이야? 그때 내 곁에 있던 건 ${withParticle(perceived, '이었어', '였어')}.`,
            `아니야. 그때 내 곁에 있던 건 ${withParticle(perceived, '이었어', '였어')}.`));
      }
    }
    if (incident?.aphrodisiac) {
      parts.push(incident.aphrodisiac.assisted
        ? speech('그땐 몸이 달아올라서 멈출 수가 없었어요. 맨정신이었다면 거절했을 거예요.',
          '그땐 몸이 달아올라서 멈출 수 없었어. 맨정신이었다면 거절했을 거야.',
          '그땐 몸이 너무 달아올라서 멈출 수가 없었어. 맨정신이었다면 거절했을 거야.')
        : incident.aphrodisiac.unassistedAccepted
          ? speech('몸이 달아오른 건 맞아요. 하지만 맨정신이었다 해도 거절하진 않았을 거예요.',
            '몸이 달아오른 건 맞아. 하지만 맨정신이어도 거절하진 않았을 거야.',
            '몸이 달아오르긴 했어. 하지만 맨정신이어도 거절하진 않았을 거야.')
          : speech('몸이 달아올랐어요. 평소의 저 같지 않았어요.',
            '몸이 달아올랐어. 평소의 나 같지 않았어.',
            '몸이 이상하게 달아올랐어. 평소의 내가 아니었어.'));
    }
    return parts;
  }

  function incidentExplanation(state, incident, purpose = 'account') {
    const wifeName = wifeDisplayName(state);
    const words = incidentExplanationParts(state, incident).join(' ');
    const voice = storyVoice(state);
    const key = `incident-account:${purpose}:${incident?.patronName || ''}:${incident?.confusion?.perceivedType || ''}`;
    if (purpose === 'enjoyment') {
      if (incident?.coercion) {
        const reply = voice === 'mara' ? '“그런 걸 왜 묻는데?”'
          : voice === 'pippa' ? '“그건… 묻지 마.”' : '“좋았냐고 묻지 마.”';
        return `${storyLine(state, key, [
          `${wifeName}의 표정이 굳습니다. ${reply}`,
          `${withParticle(wifeName, '은', '는')} 두 팔을 감싸 안고 한 걸음 물러섭니다. “그 질문은 하지 마.”`,
          `${withParticle(wifeName, '은', '는')} 당신을 바라보다 시선을 거둡니다. 『말은 했어. 분명히.』`
        ])} ${words}`;
      }
      if (incident?.aphrodisiac?.assisted) return `${storyLine(state, key, [
        `${withParticle(wifeName, '은', '는')} 입을 다물었다가 말합니다.`,
        `${withParticle(wifeName, '은', '는')} 입술을 깨물고 깍지 낀 손을 풉니다.`,
        `${withParticle(wifeName, '은', '는')} 대답하려다 숨을 고르고 다시 입을 엽니다.`
      ])} ${words}`;
      if (incident?.confusion) return `${storyLine(state, key, [
        `${withParticle(wifeName, '은', '는')} 미간을 좁힙니다.`,
        `${withParticle(wifeName, '은', '는')} 고개를 저으며 당신 얼굴을 다시 봅니다.`,
        `${withParticle(wifeName, '은', '는')} 손가락으로 관자놀이를 누릅니다.`
      ])} ${words}`;
      if (incident?.aphrodisiac?.unassistedAccepted) return `${storyLine(state, key, [
        `${withParticle(wifeName, '은', '는')} 잠시 생각합니다.`,
        `${withParticle(wifeName, '은', '는')} 손가락을 맞비비다가 당신을 봅니다.`,
        `${withParticle(wifeName, '은', '는')} 말을 고르듯 잠시 입술을 다뭅니다.`
      ])} ${words}`;
      if (incident?.aphrodisiac) return `${storyLine(state, key, [
        `${withParticle(wifeName, '은', '는')} 고개를 젓습니다.`,
        `${withParticle(wifeName, '은', '는')} 두 손을 맞잡고 시선을 내립니다.`,
        `${withParticle(wifeName, '은', '는')} 당신의 질문에 한참 뒤 입을 엽니다.`
      ])} ${words}`;
    }
    return `${storyLine(state, key, [
      `${withParticle(wifeName, '은', '는')} 당신을 봅니다.`,
      `${withParticle(wifeName, '은', '는')} 손을 멈추고 당신 쪽으로 몸을 돌립니다.`,
      `${withParticle(wifeName, '은', '는')} 말을 꺼내기 전에 숨을 고릅니다.`
    ])} ${words}`;
  }

  function incidentOpeningText(state, incident) {
    const wifeName = wifeDisplayName(state);
    const voice = storyVoice(state);
    const key = `incident-opening:${incident?.patronName || ''}:${incident?.confusion?.perceivedType || ''}`;
    if (incident?.coercion) {
      const reply = voice === 'mara' ? '“싫다고 했어.”'
        : voice === 'pippa' ? '“싫다고 했잖아…”' : '“난 거절했어.”';
      return storyLine(state, key, [
        `${withParticle(wifeName, '은', '는')} 두 손을 꽉 쥐고 당신을 봅니다. ${reply}`,
        `${withParticle(wifeName, '은', '는')} 손을 감싸 쥐다 당신의 발소리에 멈춥니다. “그 사람한테 싫다고 했어.”`,
        `${withParticle(wifeName, '은', '는')} 당신을 보자 한 걸음 물러섭니다. “난 거절했어.”`
      ]);
    }
    if (incident?.confusion) {
      if (incident.confusion.perceivedType === 'player') {
        return storyLine(state, key, [
          `${withParticle(wifeName, '은', '는')} 초점이 흐린 눈으로 당신을 찾듯 주위를 살핍니다. “어디 있는 거야…?”`,
          `${withParticle(wifeName, '은', '는')} 당신 쪽으로 손을 뻗다가 허공을 더듬습니다. “잠깐만…”`,
          `${withParticle(wifeName, '은', '는')} 입술을 움직이다가 주위를 다시 살핍니다.`
        ]);
      }
      const perceived = incident.confusion.perceivedName || '다른 사람';
      return storyLine(state, key, [
        `${withParticle(wifeName, '은', '는')} 초점이 흐린 눈으로 주위를 살피며 중얼거립니다. “${perceived}?”`,
        `${withParticle(wifeName, '은', '는')} 당신을 지나쳐 다른 쪽을 봅니다. “${perceived}, 어디 있어?”`,
        `${withParticle(wifeName, '은', '는')} 입술만 움직이다가 조용히 ${withParticle(perceived, '을', '를')} 부릅니다.`
      ]);
    }
    const reply = voice === 'mara' ? '“잠깐. 생각 좀 하자.”'
      : '“잠깐만.”';
    const consideredReply = voice === 'elena'
      ? '“아직 무슨 말을 해야 할지 모르겠어요. 조금만 기다려 주세요.”'
      : voice === 'mara'
        ? '“뭐라고 해야 할지 아직 모르겠어. 잠깐만 기다려.”'
        : '“아직 무슨 말을 해야 할지 모르겠어. 조금만 기다려 줘.”';
    return storyLine(state, key, [
      `${withParticle(wifeName, '은', '는')} 숨을 고르며 당신을 봅니다. ${reply}`,
      `${withParticle(wifeName, '은', '는')} 대답 대신 손을 들어 당신을 멈춰 세웁니다. ${reply}`,
      `${withParticle(wifeName, '은', '는')} 당신을 마주 봅니다. 한참 말을 고르다가 입을 엽니다. ${consideredReply}`
    ]);
  }

  function incidentContextFields(incident) {
    return {
      badGuestIncident: incident,
      ...(incident?.confusion ? {
        badGuestConfusionEpisodeId: incident.confusion.episodeId,
        badGuestActualPatronId: incident.patronId,
        badGuestActualPatronName: incident.patronName,
        badGuestPerceivedPartnerId: incident.confusion.perceivedId,
        badGuestPerceivedPartnerName: incident.confusion.perceivedName,
        badGuestPerceivedPartnerType: incident.confusion.perceivedType
      } : {}),
      ...(incident?.aphrodisiac ? {
        badGuestAphrodisiacEpisodeId: incident.aphrodisiac.episodeId,
        badGuestAphrodisiacAssisted: incident.aphrodisiac.assisted,
        badGuestUnassistedAccepted: incident.aphrodisiac.unassistedAccepted
      } : {})
    };
  }

  function openBadGuestIncidentReaction(state, options, incident) {
    const context = getWife(state)?.lastPatronContext;
    if (!context || !incident) return state;
    const factualContext = {
      ...context,
      ...incidentContextFields(incident)
    };
    const reactionContext = incident.confusion?.perceivedType === 'patron'
      ? { ...factualContext, patronName: incident.confusion.perceivedName }
      : factualContext;
    const factualState = updateWife(state, wife => ({
      ...wife,
      lastPatronContext: factualContext
    }));
    if (context.playerWitnessed === false || getWife(factualState)?.pendingReaction) return factualState;
    const annotated = updateWife(factualState, wife => ({
      ...wife,
      lastPatronContext: reactionContext
    }));
    const probed = original.patronControlOpenReaction(annotated, { ...(options || {}), silent: true });
    const pending = getWife(probed)?.pendingReaction;
    const remarks = getWife(probed)?.lastPatronContext?.remarksUsedThisContext;
    const restored = updateWife(probed, wife => ({
      ...wife,
      lastPatronContext: {
        ...factualContext,
        ...(remarks ? { remarksUsedThisContext: remarks } : {})
      }
    }));
    if (!pending || pending.resolved) return restored;
    return appendIntimateLog(restored, incidentOpeningText(restored, incident));
  }

  function wrappedPatronOpenReaction(state, options) {
    if (endingPatronIncidentContext) {
      return openBadGuestIncidentReaction(state, options, endingPatronIncidentContext);
    }
    if (aphrodisiacSubjectiveContext?.event?.drugChangedOutcome) return state;
    const perception = confusionSubjectiveContext?.perception;
    if (!perception) return original.patronControlOpenReaction(state, options);
    if (perception.perceivedPartnerType === 'player') return state;
    const actualContext = getWife(state)?.lastPatronContext;
    if (!actualContext) return original.patronControlOpenReaction(state, options);
    const projectedContext = subjectivePatronContext(actualContext, perception);
    const projectedState = updateWife(state, wife => ({
      ...wife,
      lastPatronContext: projectedContext
    }));
    const projectedOut = original.patronControlOpenReaction(projectedState, options);
    const projectedWife = getWife(projectedOut);
    const projectedRemarks = projectedWife?.lastPatronContext?.remarksUsedThisContext;
    return updateWife(projectedOut, wife => ({
      ...wife,
      lastPatronContext: {
        ...actualContext,
        ...(projectedRemarks ? { remarksUsedThisContext: projectedRemarks } : {}),
        badGuestActualPatronId: perception.actualCustomer.id,
        badGuestActualPatronName: perception.actualCustomer.name,
        badGuestPerceivedPartnerId: perception.perceivedId,
        badGuestPerceivedPartnerName: perception.perceivedName,
        badGuestPerceivedPartnerType: perception.perceivedPartnerType
      }
    }));
  }

  function wrappedPatronResolveReaction(state, choice) {
    const pending = getWife(state)?.pendingReaction;
    const incident = pending?.lpc?.badGuestIncident;
    if (!incident) return original.patronControlResolveReaction(state, choice);
    const lead = choice === 'confront'
      ? '당신이 방금 일을 따져 묻자'
      : choice === 'cold'
        ? '당신이 말없이 거리를 두자'
        : choice === 'eject'
          ? '당신이 그 손님을 내보내자'
          : '당신이 다그치지 않고 곁에 서자';
    const text = `${lead}, ${incidentExplanation(state, incident)}`;
    return updateWife(appendIntimateLog(state, text), wife => ({
      ...wife,
      pendingReaction: wife.pendingReaction
        ? { ...wife.pendingReaction, resolved: true }
        : wife.pendingReaction,
      lastResponse: text,
      lastResponseType: choice === 'peace' ? 'neutral' : 'hesitant',
      lastResponseSlot: state.slot
    }));
  }

  function wrappedPatronExpireReaction(state) {
    const pending = getWife(state)?.pendingReaction;
    if (!pending?.lpc?.badGuestIncident) return original.patronControlExpireReaction(state);
    if (pending.resolved || state.slot < (pending.expiresAtSlot ?? Infinity)) return state;
    return updateWife(state, wife => {
      const { pendingReaction, ...rest } = wife;
      return rest;
    });
  }

  function witnessedIncidentMoments(state) {
    return (getWife(state)?.moments || []).filter(moment => (
      moment?.knowledge === 'saw'
      && moment.badGuestIncident
    ));
  }

  function incidentMoments(state) {
    return (getWife(state)?.moments || []).filter(moment => moment?.badGuestIncident);
  }

  function wrappedPatronUnpromptedCandidates(state, day) {
    const candidates = original.patronControlUnpromptedCandidates(state, day);
    if (!Array.isArray(candidates)
      || typeof required.patronControlCanConfess !== 'function'
      || !required.patronControlCanConfess(state)) return candidates;
    const existingIds = new Set(candidates.map(moment => moment?.id));
    const today = Number(day ?? state.day ?? 1);
    const added = incidentMoments(state).filter(moment => (
      moment.id && !existingIds.has(moment.id)
      && moment.knowledge === 'none'
      && STAGES.indexOf(moment.stage) >= STAGES.indexOf('groping')
      && (!moment.raised || moment.raised.voice === 'partial' && moment.reply !== 'tell_me')
      && (!moment.raised || today - Number(moment.raised.day) >= 7)
    ));
    return added.length ? [...candidates, ...added] : candidates;
  }

  function latestUndiscussedIncidentMoment(state) {
    return [...witnessedIncidentMoments(state)]
      .filter(moment => !moment.raised)
      .sort((left, right) => Number(right.slot || 0) - Number(left.slot || 0))[0] || null;
  }

  function latestIncidentMomentFrom(state, moments, options = {}) {
    const supplied = Array.isArray(moments);
    let candidates = supplied
      ? moments.filter(moment => moment?.badGuestIncident)
      : incidentMoments(state).filter(moment => !moment.raised);
    if (options.unprompted === true) {
      const hiddenIncidents = incidentMoments(state).filter(moment => (
        moment.knowledge === 'none' && !moment.raised
      ));
      const knownIds = new Set(candidates.map(moment => moment.id));
      candidates = [...candidates, ...hiddenIncidents.filter(moment => !knownIds.has(moment.id))];
    }
    if (!supplied && options.unprompted !== true) {
      const hidden = candidates.filter(moment => moment.knowledge === 'none');
      candidates = hidden.length ? hidden : candidates.filter(moment => moment.knowledge === 'saw');
    }
    return [...candidates]
      .sort((left, right) => Number(right.slot || 0) - Number(left.slot || 0))[0] || null;
  }

  function conversationOutcome(logText, response = 'hesitant', mood = -1, trustDelta = 1) {
    return {
      response,
      logText,
      playerStatDeltas: {},
      wifeStatDeltas: { mood },
      wifeTraitDeltas: {},
      trustDelta,
      important: true
    };
  }

  const EMPTY_CONFESSION_SUMMARY = Object.freeze({
    priorCount: 0,
    answered: 0,
    warmth: 0,
    everWantedIt: false,
    sanctioned: false,
    counts: Object.freeze({}),
    ceremony: 'raw'
  });

  function incidentConfessionSummary(state) {
    if (typeof required.patronControlConfessionSummary !== 'function') {
      return EMPTY_CONFESSION_SUMMARY;
    }
    return required.patronControlConfessionSummary(state, { excludeUnanswered: true })
      || EMPTY_CONFESSION_SUMMARY;
  }

  function recordIncidentConfession(state, moment) {
    if (typeof required.patronControlRecordConfession !== 'function') return state;
    const history = getWife(state)?.confessionHistory || [];
    if (history.some(entry => entry?.badGuestMomentId === moment.id)) return state;
    return required.patronControlRecordConfession(state, {
      stage: moment.stage,
      category: required.patronControlMomentCategory(moment) || undefined,
      patron: moment.patronName,
      badGuestIncident: true,
      badGuestMomentId: moment.id
    });
  }

  function wrappedPatronNightAccount(state, moments, options = {}) {
    const moment = latestIncidentMomentFrom(state, moments, options)
      || (options?.unprompted === true ? null : latestUndiscussedIncidentMoment(state));
    if (!moment) return original.patronControlNightAccount(state, moments, options);
    const unprompted = options?.unprompted === true;
    if (unprompted && incidentConfessionSummary(state).sanctioned) {
      const quietAccount = original.patronControlNightAccount(state, [], options);
      return {
        ...quietAccount,
        decision: 'no_events',
        askedIds: [],
        confessedIds: [],
        badGuestIncidentAccount: {
          momentIds: [moment.id].filter(Boolean),
          unprompted: true,
          suppressed: true
        }
      };
    }
    return {
      outcome: conversationOutcome(incidentExplanation(state, moment.badGuestIncident)),
      decision: unprompted ? 'confess' : 'partial',
      read: null,
      deception: 'clean',
      secret: null,
      askedIds: [moment.id].filter(Boolean),
      confessedIds: unprompted ? [moment.id].filter(Boolean) : [],
      badGuestIncidentAccount: {
        momentIds: [moment.id].filter(Boolean),
        unprompted,
        suppressed: false
      }
    };
  }

  function wrappedPatronApplyNightAccount(state, result, by) {
    const account = result?.badGuestIncidentAccount;
    if (!account) return original.patronControlApplyNightAccount(state, result, by);
    let out = original.patronControlApplyNightAccount(state, {
      ...result,
      decision: 'no_events',
      read: null,
      deception: 'clean',
      secret: null,
      confessed: null,
      askedIds: [],
      confessedIds: []
    }, by);
    const ids = new Set(account.momentIds || []);
    if (!ids.size) return out;
    out = updateWife(out, wife => ({
      ...wife,
      moments: (wife.moments || []).map(moment => {
        if (!ids.has(moment.id)) return moment;
        return {
          ...moment,
          raised: {
            by,
            day: out.day ?? 1,
            voice: account.unprompted ? 'confessed' : 'partial'
          },
          ...(account.unprompted ? {
            told: moment.told || { day: out.day ?? 1, heldBack: [] }
          } : {})
        };
      })
    }));
    if (!account.unprompted) return out;
    const moment = incidentMoments(out).find(entry => ids.has(entry.id));
    if (!moment) return out;
    out = recordIncidentConfession(out, moment);
    if (account.suppressed) return out;
    return {
      ...out,
      pendingEvent: incidentConfessionEvent(out, moment)
    };
  }

  function incidentMomentForEvent(state) {
    const event = state.pendingEvent;
    const alert = event?.alert || event;
    if (!event || isIncidentMomentEvent(event)) return null;
    const eventIds = [event.id, alert?.id].filter(value => typeof value === 'string');
    const isMomentEvent = alert?.kind === 'moment'
      || alert?.tags?.includes?.('moment')
      || eventIds.some(id => id.startsWith('moment:'));
    if (!isMomentEvent) return null;
    return incidentMoments(state).find(moment => (
      eventIds.some(id => id.endsWith(`:${moment.id}`) || id.includes(moment.id))
    )) || null;
  }

  function wifeConversationChoiceId(state, action) {
    if (state.pendingEvent?.type !== 'wife_conversation') return null;
    if (action?.type === 'wife_topic') return action.topicId;
    if (action?.type === 'resolve_event') return action.choiceId;
    return null;
  }

  function incidentMomentFromConversationChoice(state, action) {
    const event = state.pendingEvent;
    const choiceId = wifeConversationChoiceId(state, action);
    if (!choiceId || !(event.choices || []).some(choice => choice.id === choiceId)) return null;
    return incidentMoments(state).find(moment => (
      choiceId.endsWith(moment.id) || choiceId.includes(moment.id)
    )) || null;
  }

  function incidentMomentReference(state, moment) {
    const wifeName = wifeDisplayName(state);
    const patronName = moment?.patronName || moment?.badGuestIncident?.patronName || '그 손님';
    let reference;
    switch (moment?.stage) {
      case 'chatting': reference = `${withParticle(patronName, '과', '와')} 대화를 나누던`; break;
      case 'flirting': reference = `${patronName}의 추파를 받던`; break;
      case 'light_touch': reference = `${withParticle(patronName, '이', '가')} 가까이 다가왔던`; break;
      case 'bold_touch': reference = `${withParticle(patronName, '이', '가')} 자신의 몸에 손을 댔던`; break;
      case 'groping': reference = `${withParticle(patronName, '이', '가')} 옷 안으로 손을 넣었던`; break;
      case 'intimate': reference = `${patronName}의 손가락이 자신 안에 들어왔던`; break;
      case 'handjob_patron': reference = `${withParticle(patronName, '을', '를')} 손으로 애무했던`; break;
      case 'blowjob_patron': reference = `${withParticle(patronName, '을', '를')} 입으로 애무했던`; break;
      case 'rubbing_patron': reference = `${withParticle(patronName, '이', '가')} 자신의 몸에 성기를 비볐던`; break;
      case 'sex_patron': reference = `${withParticle(patronName, '과', '와')} 성관계를 가졌던`; break;
      default: reference = `${withParticle(patronName, '과', '와')} 있었던`; break;
    }
    return `${withParticle(wifeName, '은', '는')} ${reference} 일을 꺼냅니다.`;
  }

  function incidentMomentPrompt(state, moment) {
    const explanation = incidentExplanationParts(state, moment.badGuestIncident).join(' ');
    const profile = incidentResponseProfile(moment.badGuestIncident);
    const question = profile === 'coercion'
      ? '“내가 거절했다는 말, 믿어?”'
      : profile.startsWith('confusion')
        ? '“그때의 나를 믿어 줄 수 있어?”'
        : profile === 'aphrodisiac_accepted'
          ? '“그게 열기 때문만은 아니었다고 하면, 화낼 거야?”'
          : '“그걸 내 뜻이었다고 생각해?”';
    return `${incidentMomentReference(state, moment)} ${explanation} ${question}`;
  }

  function incidentMomentCauseWeight(state, incident) {
    let weight = 0;
    if (incident?.coercion) weight += 1;
    if (incident?.aphrodisiac) {
      weight += incident.aphrodisiac.assisted
        ? 0.75
        : incident.aphrodisiac.unassistedAccepted ? 0.15 : 0.4;
    }
    if (incident?.confusion) {
      let confusionWeight = incident.confusion.actualAccepted === false
        ? 0.75
        : incident.confusion.actualAccepted === true ? 0.35 : 0.5;
      if (!confusionIncidentRecovered(state, incident)) confusionWeight *= 0.9;
      weight += confusionWeight;
    }
    return clamp(weight, 0, 1.5);
  }

  function roundedTenth(value) {
    return Math.round(value * 10) / 10;
  }

  function incidentResponseProfile(incident) {
    if (incident?.coercion) return 'coercion';
    if (incident?.confusion?.actualAccepted === false) return 'confusion_rejected';
    if (incident?.aphrodisiac?.assisted) return 'aphrodisiac_assisted';
    if (incident?.confusion) return 'confusion';
    if (incident?.aphrodisiac?.unassistedAccepted) return 'aphrodisiac_accepted';
    if (incident?.aphrodisiac) return 'aphrodisiac_uncertain';
    return 'general';
  }

  function incidentChoiceTemplates(incident, context) {
    const profile = incidentResponseProfile(incident);
    if (profile === 'coercion') {
      return [
        {
          intent: 'support',
          label: context === 'moment'
            ? '“네 잘못이 아니야. 내가 더 일찍 막았어야 했어.”'
            : '“네 잘못이 아니야. 그 사람 잘못이야.”',
          description: context === 'moment'
            ? '그녀의 거절을 믿고, 막지 못한 일을 사과합니다.'
            : '그녀의 거절을 믿고, 강행한 손님에게 책임을 묻습니다.',
          boundary: { side: 'restrict', signal: 4, clarity: 32 }
        },
        {
          intent: 'protect',
          label: '“그 사람은 다시 못 오게 할게.”',
          description: '그 손님과 같은 행위에 분명한 선을 긋습니다.',
          boundary: { side: 'restrict', signal: 18, clarity: 78, patronSpecific: true }
        },
        {
          intent: 'clarify',
          label: '“어디서부터 싫었는지 말해 줘.”',
          description: '그녀가 거절한 지점과 벌어진 일을 차분히 듣습니다.'
        },
        {
          intent: 'wounded',
          label: '“네 탓은 아니야. 그래도 마음은 아파.”',
          description: '그녀를 탓하지 않으면서 당신이 받은 상처를 말합니다.',
          boundary: { side: 'restrict', signal: 6, clarity: 38 }
        },
        {
          intent: 'doubt',
          label: '“정말 끝까지 거절했어?”',
          description: '그녀의 말을 의심하며 다시 확인합니다.',
          boundary: { side: 'encourage', signal: 3, clarity: 16 }
        }
      ];
    }
    if (profile.startsWith('confusion')) {
      const perceived = incident?.confusion?.perceivedType === 'player'
        ? '나'
        : incident?.confusion?.perceivedName || '다른 사람';
      return [
        {
          intent: 'support',
          label: '“네가 그렇게 믿었다면 네 잘못은 아니야.”',
          description: '그녀가 함께 있다고 믿은 상대와 실제 상대가 달랐음을 받아들입니다.',
          boundary: { side: 'restrict', signal: 4, clarity: 30 }
        },
        {
          intent: 'protect',
          label: '“다시는 그 사람이 널 속이지 못하게 할게.”',
          description: '실제 손님과 같은 행위에 분명한 선을 긋습니다.',
          boundary: { side: 'restrict', signal: 17, clarity: 75, patronSpecific: true }
        },
        {
          intent: 'clarify',
          label: '“그때 누구라고 믿었는지 말해 줘.”',
          description: '그녀가 기억하는 상대와 당시 상황을 차분히 확인합니다.'
        },
        {
          intent: 'wounded',
          label: `“${withParticle(perceived, '이라고', '라고')} 믿었다 해도 마음은 아파.”`,
          description: '착각을 탓하지 않으면서 당신이 받은 상처를 말합니다.',
          boundary: { side: 'restrict', signal: 6, clarity: 36 }
        },
        {
          intent: 'doubt',
          label: `“정말 그 사람을 ${withParticle(perceived, '이라고', '라고')} 믿었어?”`,
          description: '그녀가 기억하는 상대를 의심하며 다시 확인합니다.',
          boundary: { side: 'encourage', signal: 3, clarity: 15 }
        }
      ];
    }
    if (profile === 'aphrodisiac_accepted') {
      return [
        {
          intent: 'accept',
          label: '“그 열기 때문만은 아니었단 말이지.”',
          description: '그녀가 맨정신이어도 받아들였을 마음을 인정합니다.',
          boundary: { side: 'encourage', signal: 12, clarity: 62, patronSpecific: true }
        },
        {
          intent: 'protect',
          label: '“그래도 그런 식은 다시 안 돼.”',
          description: '그녀의 마음과 별개로 수상한 술과 같은 행위에는 선을 긋습니다.',
          boundary: { side: 'restrict', signal: 12, clarity: 62, patronSpecific: true }
        },
        {
          intent: 'clarify',
          label: '“맨정신이었다면 어떻게 했을지 말해 줘.”',
          description: '약효와 별개였던 그녀의 뜻을 직접 묻습니다.'
        },
        {
          intent: 'wounded',
          label: '“네 마음은 알겠어. 그래도 마음은 아파.”',
          description: '그녀의 뜻은 인정하면서 당신이 받은 상처를 말합니다.',
          boundary: { side: 'restrict', signal: 5, clarity: 32 }
        },
        {
          intent: 'defer',
          label: '“지금은 더 말하지 말자.”',
          description: '판단을 미루고 대화를 끝냅니다.',
          boundary: { side: 'encourage', signal: 3, clarity: 8, source: 'walked_past' }
        }
      ];
    }
    const certain = profile === 'aphrodisiac_assisted';
    return [
      {
        intent: 'support',
        label: certain
          ? '“그때의 일을 네 뜻으로 보지 않을게.”'
          : '“그때의 일을 네 뜻이라고 단정하지 않을게.”',
        description: '그때 그녀가 받아들인 일을 맨정신의 뜻으로 단정하지 않습니다.',
        boundary: { side: 'restrict', signal: certain ? 5 : 3, clarity: certain ? 36 : 24 }
      },
      {
        intent: 'protect',
        label: '“다시는 그 사람이 네 잔에 손대지 못하게 할게.”',
        description: '그 손님과 같은 행위에 분명한 선을 긋습니다.',
        boundary: { side: 'restrict', signal: 17, clarity: 75, patronSpecific: true }
      },
      {
        intent: 'clarify',
        label: '“맨정신이었다면 어떻게 했을지 말해 줘.”',
        description: '달아오른 감각과 별개였던 그녀의 뜻을 직접 묻습니다.'
      },
      {
        intent: 'wounded',
        label: '“네 탓은 아니야. 그래도 마음은 아파.”',
        description: '그녀를 탓하지 않으면서 당신이 받은 상처를 말합니다.',
        boundary: { side: 'restrict', signal: 6, clarity: 36 }
      },
      {
        intent: certain ? 'doubt' : 'defer',
        label: certain ? '“정말 그 열기 때문뿐이었어?”' : '“지금은 더 말하지 말자.”',
        description: certain
          ? '그녀가 평소에는 거절했을 것이라는 말을 의심합니다.'
          : '판단을 미루고 대화를 끝냅니다.',
        boundary: certain
          ? { side: 'encourage', signal: 3, clarity: 15 }
          : { side: 'encourage', signal: 3, clarity: 8, source: 'walked_past' }
      }
    ];
  }

  function incidentResponseChoices(incident, context) {
    return incidentChoiceTemplates(incident, context).map(choice => ({
      ...choice,
      id: `bad_guest_incident_${context}_${choice.intent}`
    }));
  }

  function adjustedIncidentBoundary(definition, weight) {
    if (definition.side === 'encourage') {
      const scale = Math.max(0.25, 1 - weight * 0.45);
      return {
        ...definition,
        signal: roundedTenth(definition.signal * scale),
        clarity: Math.round(definition.clarity * Math.max(0.6, 1 - weight * 0.15))
      };
    }
    return {
      ...definition,
      signal: roundedTenth(definition.signal * (1 + weight * 0.25)),
      clarity: Math.min(100, Math.round(definition.clarity + weight * 10))
    };
  }

  function recordIncidentBoundary(state, moment, choice) {
    const definition = choice?.boundary;
    if (!definition) return state;
    const category = required.patronControlMomentCategory(moment);
    if (!category) return state;
    const weight = incidentMomentCauseWeight(state, moment.badGuestIncident);
    const adjusted = adjustedIncidentBoundary(definition, weight);
    const signal = {
      signal: adjusted.signal,
      clarity: adjusted.clarity,
      source: adjusted.source || (adjusted.side === 'encourage' ? 'verbal_post_act' : 'restricted_post_act'),
      ...(choice.intent === 'defer' ? {} : { contradicts: true })
    };
    let out = adjusted.side === 'encourage'
      ? required.recordLatitudeEncouragement(state, category, signal)
      : required.recordLatitudeRestriction(state, category, signal);
    if (!definition.patronSpecific || !moment.patronName) return out;
    const patronSignal = Math.round(adjusted.signal * 0.6);
    return required.recordPatronLatitude(out, moment.patronName, {
      ...(adjusted.side === 'encourage'
        ? { encouragement: patronSignal }
        : { restriction: patronSignal }),
      source: signal.source
    });
  }

  function incidentResponseReaction(state, moment, choice, context) {
    const wife = getWife(state);
    const incident = moment?.badGuestIncident;
    const weight = incidentMomentCauseWeight(state, incident);
    const traits = new Set(wife?.latentTraits || []);
    const intensity = Number(moment?.feeling?.intensity ?? 20) / 100;
    const contradicted = ['sent', 'encouraged'].includes(moment?.answer)
      && ['protect'].includes(choice.intent);
    if (context === 'moment' && contradicted) {
      return {
        trust: roundedTenth(-(2 + 3 * intensity + weight * 2)),
        resentment: roundedTenth(6 + 10 * intensity + weight * 2),
        tone: null
      };
    }
    if (choice.intent === 'support') {
      let trustDelta = context === 'confession'
        ? 3 + (1 - Number(wife?.relationship?.trust ?? 50) / 100) * 4
        : 3;
      if (context === 'confession'
        && (traits.has('breaks_under_pressure') || traits.has('true_prude'))) trustDelta *= 1.4;
      if (context === 'confession'
        && (traits.has('likes_cheating') || traits.has('enjoys_making_him_jealous'))) trustDelta *= 0.6;
      return {
        trust: roundedTenth(trustDelta * (1 + weight * 0.2)),
        resentment: roundedTenth(-2 - weight),
        mood: 1 + Math.round(weight),
        tone: 'warm'
      };
    }
    if (choice.intent === 'protect') {
      return {
        trust: roundedTenth(2 + weight * 1.5),
        resentment: roundedTenth(-1 - weight * 1.5),
        tone: 'protective'
      };
    }
    if (choice.intent === 'clarify') {
      const welcomesDetails = traits.has('guilt_eroticizer')
        || traits.has('enjoys_making_him_jealous')
        || traits.has('wants_to_be_corrupted')
        || traits.has('likes_cheating');
      const guardsDetails = traits.has('true_prude') || traits.has('self_protective');
      return {
        trust: roundedTenth(welcomesDetails ? 1.5 : guardsDetails ? -0.5 : 0.5),
        resentment: roundedTenth(guardsDetails ? 0.5 : 0),
        mood: 0,
        tone: null
      };
    }
    if (choice.intent === 'wounded') {
      return {
        trust: roundedTenth(1 + weight * 0.5),
        resentment: 0,
        mood: weight >= 1 ? -2 : -1,
        tone: 'warm'
      };
    }
    if (choice.intent === 'doubt') {
      return {
        trust: roundedTenth(-(2 + weight * 2)),
        resentment: roundedTenth(4 + weight * 4),
        mood: -(1 + Math.round(weight)),
        tone: 'cold'
      };
    }
    if (choice.intent === 'accept') {
      return {
        trust: roundedTenth(2 - weight * 0.5),
        resentment: roundedTenth(weight * 0.5),
        mood: 0,
        tone: 'permissive'
      };
    }
    return {
      trust: roundedTenth(-weight * 0.5),
      resentment: roundedTenth(weight * 0.3),
      mood: 0,
      tone: null
    };
  }

  function incidentMomentChoices(state, moment) {
    return incidentResponseChoices(moment.badGuestIncident, 'moment');
  }

  function incidentConfessionChoices(state, moment) {
    const choices = incidentResponseChoices(moment.badGuestIncident, 'confession');
    if (typeof required.patronControlIsUncommitted === 'function'
      && required.patronControlIsUncommitted(state)) return choices;
    const summary = incidentConfessionSummary(state);
    if (summary.ceremony === 'braced' && (summary.counts?.angry ?? 0) >= 2) {
      choices.push({
        id: 'bad_guest_incident_confession_repair',
        intent: 'repair',
        originalChoiceId: 'repair',
        label: '진실을 말해준 너를 내가 탓하고 벌주었구나.',
        description: '지난 고백에 상처 주는 말로 답했던 일을 인정하고 사과합니다.'
      });
    }
    if (!summary.sanctioned
      && (summary.ceremony === 'routine' || summary.ceremony === 'unashamed')) {
      choices.push({
        id: 'bad_guest_incident_confession_sanction',
        intent: 'sanction',
        originalChoiceId: 'sanction',
        label: '굳이 일일이 말해줄 필요는 없어.',
        description: '앞으로 같은 일이 있어도 일일이 말하지 않아도 된다고 전합니다.'
      });
    }
    return choices;
  }

  function incidentMomentEvent(state, moment, text = incidentMomentPrompt(state, moment)) {
    const title = required.patronControlMomentTitle(moment, state.slot);
    const choices = incidentMomentChoices(state, moment)
      .map(({ id, label, description }) => ({ id, label, description }));
    const alert = {
      id: `bad_guest_incident_moment:${moment.id}`,
      kind: 'moment',
      severity: 'warn',
      pause: true,
      title,
      body: text,
      choices,
      tags: ['moment', 'requires_decision', 'bad_guest_incident', 'bad_guest_incident_moment']
    };
    return {
      type: 'alert',
      alert,
      customerId: '',
      customerName: title,
      category: 'relationship',
      momentId: moment.id,
      title,
      text,
      choices
    };
  }

  function isIncidentMomentEvent(event) {
    return event?.type === 'bad_guest_incident_moment'
      || (event?.type === 'alert'
        && (event?.alert?.tags?.includes?.('bad_guest_incident_moment')
          || event?.alert?.id?.startsWith?.('bad_guest_incident_moment:')));
  }

  function incidentConfessionEvent(state, moment) {
    const title = required.patronControlMomentTitle(moment, state.slot);
    const text = incidentExplanation(state, moment.badGuestIncident);
    const choices = incidentConfessionChoices(state, moment)
      .map(({ id, label, description }) => ({ id, label, description }));
    const alert = {
      id: `bad_guest_incident_confession:${moment.id}`,
      kind: 'reckoning',
      severity: 'critical',
      pause: true,
      title,
      body: text,
      choices,
      tags: ['confession', 'reckoning', 'requires_decision', 'bad_guest_incident', 'bad_guest_incident_confession']
    };
    return {
      type: 'alert',
      alert,
      customerId: '',
      customerName: title,
      category: 'relationship',
      momentId: moment.id,
      title,
      text,
      choices
    };
  }

  function isIncidentConfessionEvent(event) {
    return event?.type === 'alert'
      && (event?.alert?.tags?.includes?.('bad_guest_incident_confession')
        || event?.alert?.id?.startsWith?.('bad_guest_incident_confession:'));
  }

  function openIncidentMomentConversation(state, moment) {
    const text = incidentMomentPrompt(state, moment);
    let out = updateWife({ ...state, pendingEvent: undefined }, wife => ({
      ...wife,
      moments: (wife.moments || []).map(entry => entry.id === moment.id
        ? {
          ...entry,
          raised: entry.raised || { by: 'him', day: state.day ?? 1, voice: 'told' }
        }
        : entry),
      lastResponse: text,
      lastResponseType: 'hesitant',
      lastResponseSlot: state.slot
    }));
    out = appendIntimateLog(out, text);
    return { ...out, pendingEvent: incidentMomentEvent(out, moment, text) };
  }

  function rewriteIncidentMomentEvent(state) {
    const openIncidentEvent = isIncidentMomentEvent(state.pendingEvent)
      || isIncidentConfessionEvent(state.pendingEvent);
    if (openIncidentEvent) {
      const openMoment = incidentMoments(state)
        .find(entry => entry.id === state.pendingEvent.momentId);
      if (!openMoment) return state;
      const confession = isIncidentConfessionEvent(state.pendingEvent);
      const working = confession ? recordIncidentConfession(state, openMoment) : state;
      const desired = confession
        ? incidentConfessionEvent(working, openMoment)
        : incidentMomentEvent(working, openMoment, incidentMomentPrompt(working, openMoment));
      const currentIds = (working.pendingEvent.choices || working.pendingEvent.alert?.choices || [])
        .map(choice => choice.id);
      const desiredIds = desired.choices.map(choice => choice.id);
      const currentText = working.pendingEvent.text || working.pendingEvent.alert?.body || '';
      if (working.pendingEvent.type === 'alert'
        && currentText === desired.text
        && currentIds.length === desiredIds.length
        && currentIds.every((id, index) => id === desiredIds[index])) return working;
      if (confession) return { ...working, pendingEvent: desired };
      const log = [...(working.log || [])];
      for (let index = log.length - 1; index >= 0; index -= 1) {
        if (!currentText || log[index]?.text !== currentText) continue;
        log[index] = { ...log[index], text: desired.text };
        break;
      }
      return updateWife({ ...working, log, pendingEvent: desired }, wife => ({
        ...wife,
        lastResponse: desired.text,
        lastResponseType: 'hesitant',
        lastResponseSlot: working.slot
      }));
    }
    const moment = incidentMomentForEvent(state);
    if (!moment) return state;
    const priorEvent = state.pendingEvent;
    const priorText = priorEvent?.text || priorEvent?.alert?.body || '';
    const text = incidentMomentPrompt(state, moment);
    let replaced = false;
    const log = [...(state.log || [])];
    for (let index = log.length - 1; index >= 0; index -= 1) {
      if (!priorText || log[index]?.text !== priorText) continue;
      log[index] = { ...log[index], text };
      replaced = true;
      break;
    }
    let out = {
      ...state,
      ...(replaced ? { log } : {}),
      pendingEvent: incidentMomentEvent(state, moment, text)
    };
    out = updateWife(out, wife => ({
      ...wife,
      lastResponse: text,
      lastResponseType: 'hesitant',
      lastResponseSlot: state.slot
    }));
    return out;
  }

  function incidentResponseText(state, choice) {
    const wifeName = wifeDisplayName(state);
    if (choice.intent === 'support') {
      return `당신은 ${wifeName}의 손을 잡습니다. ${choice.label} ${withParticle(wifeName, '은', '는')} 굳었던 손에 천천히 힘을 뺍니다.`;
    }
    if (choice.intent === 'protect' || choice.intent === 'accept') {
      return `당신은 분명히 말합니다. ${choice.label} ${withParticle(wifeName, '은', '는')} 당신의 말을 가만히 받아들입니다.`;
    }
    if (choice.intent === 'clarify') {
      return `당신은 목소리를 낮춥니다. ${choice.label} ${withParticle(wifeName, '은', '는')} 잠시 생각한 뒤 입을 엽니다.`;
    }
    if (choice.intent === 'wounded') {
      return `당신은 고개를 젓습니다. ${choice.label} ${withParticle(wifeName, '은', '는')} 입술을 깨물고 당신을 봅니다.`;
    }
    if (choice.intent === 'doubt') {
      return `당신은 그녀의 눈을 바라봅니다. ${choice.label} ${wifeName}의 얼굴이 굳습니다.`;
    }
    return `당신은 시선을 떨굽니다. ${choice.label} ${withParticle(wifeName, '은', '는')} 더 묻지 않습니다.`;
  }

  function resolveIncidentResponseChoice(state, choiceId, context) {
    const momentId = state.pendingEvent?.momentId;
    const moment = incidentMoments(state).find(entry => entry.id === momentId);
    if (!moment) return { ...state, pendingEvent: undefined };
    const choices = context === 'confession'
      ? incidentConfessionChoices(state, moment)
      : incidentMomentChoices(state, moment);
    const choice = choices.find(entry => entry.id === choiceId);
    if (!choice) return state;
    if (context === 'confession' && choice.originalChoiceId
      && typeof required.patronControlResolveConfession === 'function') {
      const out = required.patronControlResolveConfession(
        { ...state, pendingEvent: undefined },
        choice.originalChoiceId
      );
      return updateWife(out, wife => ({
        ...wife,
        moments: (wife.moments || []).map(entry => entry.id === moment.id
          ? { ...entry, reply: choiceId }
          : entry)
      }));
    }
    let out = { ...state, pendingEvent: undefined };
    const text = incidentResponseText(out, choice);
    const reaction = incidentResponseReaction(out, moment, choice, context);
    out = recordIncidentBoundary(out, moment, choice);
    out = required.nudgeRelationship(out, {
      trust: reaction.trust,
      resentment: reaction.resentment
    });
    if (reaction.tone) out = required.recordPlayerTone(out, reaction.tone);
    if (reaction.mood) {
      out = updateWife(out, wife => ({
        ...wife,
        stats: {
          ...wife.stats,
          mood: clamp((wife.stats?.mood ?? 50) + reaction.mood, 0, 100)
        }
      }));
    }
    out = appendIntimateLog(out, text);
    if (context === 'confession'
      && typeof required.patronControlRecordConfessionReception === 'function') {
      const reception = {
        support: 'comfort',
        protect: 'comfort',
        accept: 'comfort',
        clarify: 'tell_me',
        wounded: 'wounded',
        doubt: 'angry',
        defer: 'wounded'
      }[choice.intent];
      if (reception) out = required.patronControlRecordConfessionReception(out, reception);
    }
    return updateWife(out, wife => ({
      ...wife,
      moments: (wife.moments || []).map(entry => entry.id === moment.id
        ? { ...entry, reply: choiceId }
        : entry),
      lastResponse: text,
      lastResponseType: choice.intent === 'support' || choice.intent === 'accept'
        ? 'neutral' : choice.intent === 'doubt' ? 'angry' : 'hesitant',
      lastResponseSlot: state.slot
    }));
  }

  function resolveIncidentMomentChoice(state, choiceId) {
    return resolveIncidentResponseChoice(state, choiceId, 'moment');
  }

  function resolveIncidentConfessionChoice(state, choiceId) {
    return resolveIncidentResponseChoice(state, choiceId, 'confession');
  }

  function wrappedPatronEnjoymentOpinion(wifeName, state) {
    const incidents = witnessedIncidentMoments(state)
      .filter(moment => Number(state.slot || 0) - Number(moment.slot || 0) <= 10080)
      .sort((left, right) => Number(right.slot || 0) - Number(left.slot || 0));
    const latest = incidents[0];
    const latestHistorySlot = Math.max(
      -Infinity,
      ...(getWife(state)?.intimateHistory || []).map(entry => Number(entry?.slot ?? -Infinity))
    );
    if (!latest || Number(latest.slot || 0) < latestHistorySlot) {
      return original.patronControlEnjoymentOpinion(wifeName, state);
    }
    return conversationOutcome(
      incidentExplanation(state, latest.badGuestIncident, 'enjoyment'),
      'hesitant',
      latest.badGuestIncident?.coercion ? -2 : -1,
      1
    );
  }

  function wrappedPatronInnerThought(state, trigger, options) {
    if (aphrodisiacSubjectiveContext?.event?.drugChangedOutcome) return state;
    const perception = confusionSubjectiveContext?.perception;
    const actualContext = getWife(state)?.lastPatronContext;
    if (!perception || !actualContext) {
      return original.patronControlInnerThought(state, trigger, options);
    }
    const projectedState = updateWife(state, wife => ({
      ...wife,
      lastPatronContext: subjectivePatronContext(actualContext, perception)
    }));
    const out = original.patronControlInnerThought(projectedState, trigger, options);
    return updateWife(out, wife => ({ ...wife, lastPatronContext: actualContext }));
  }

  function reportQualifiedMoments(before, after, interaction) {
    const service = getQualifiedExperience();
    if (typeof service?.reportMoment !== 'function') return after;
    const previousIds = new Set((getWife(before)?.moments || []).map(moment => moment.id));
    const confusionActive = timedEffectActive(before, 'confusion')
      && !unresponsiveDrugTarget(before);
    let out = after;
    for (const moment of getWife(after)?.moments || []) {
      if (!moment?.id || previousIds.has(moment.id)
        || String(moment.patronId) !== String(interaction?.customerId)) continue;
      const incident = moment.badGuestIncident;
      const reasons = [
        confusionActive || incident?.confusion ? 'confusion' : null,
        incident?.coercion ? 'coercion' : null,
        incident?.aphrodisiac?.assisted === true || moment.badGuestAphrodisiacAssisted === true
          ? 'aphrodisiac_assisted' : null
      ].filter(Boolean);
      if (!reasons.length) continue;
      try {
        out = service.reportMoment(out, WML_DATA_KEY, {
          momentId: moment.id,
          relationship: false,
          payload: { reasons }
        }) || out;
      } catch {
        // The incident and its factual moment remain valid without the optional service.
      }
    }
    return out;
  }

  function wrappedPatronRecordMoment(state, interaction, ...rest) {
    const perception = confusionSubjectiveContext?.perception
      || confusionPerceptionForPatron(state, interaction?.customerId);
    let out = original.patronControlRecordMoment(state, interaction, ...rest);
    const aphrodisiacEvent = aphrodisiacSubjectiveContext?.event;
    if (aphrodisiacEvent) {
      out = updateWife(out, wife => ({
        ...wife,
        moments: (wife.moments || []).map(moment => (
          String(moment.patronId) === String(interaction?.customerId)
            && moment.slot === state.slot
            && moment.stage === interaction?.stage
            ? {
              ...moment,
              badGuestAphrodisiacEpisodeId: aphrodisiacEvent.episodeId,
              badGuestAphrodisiacAssisted: aphrodisiacEvent.drugChangedOutcome === true,
              badGuestUnassistedAnswer: aphrodisiacEvent.unassistedAnswer ?? null
            }
            : moment
        ))
      }));
    }
    if (endingPatronIncidentContext) {
      out = updateWife(out, wife => ({
        ...wife,
        moments: (wife.moments || []).map(moment => (
          String(moment.patronId) === String(interaction?.customerId)
            && moment.slot === state.slot
            && moment.stage === interaction?.stage
            ? { ...moment, ...incidentContextFields(endingPatronIncidentContext) }
            : moment
        ))
      }));
    }
    if (!perception) return reportQualifiedMoments(state, out, interaction);
    const moments = getWife(out)?.moments || [];
    let targetIndex = -1;
    for (let index = moments.length - 1; index >= 0; index -= 1) {
      const moment = moments[index];
      if (String(moment.patronId) === String(interaction?.customerId)
        && moment.slot === state.slot
        && moment.stage === interaction?.stage) {
        targetIndex = index;
        break;
      }
    }
    out = updateWife(out, wife => ({
      ...wife,
      moments: (wife.moments || []).map((moment, index) => (
        index !== targetIndex
          ? moment
          : {
            ...moment,
            badGuestActualPatronId: perception.actualCustomer.id,
            badGuestActualPatronName: perception.actualCustomer.name,
            badGuestPerceivedPartnerId: perception.perceivedId,
            badGuestPerceivedPartnerName: perception.perceivedName,
            badGuestPerceivedPartnerType: perception.perceivedPartnerType
          }
      ))
    }));
    return reportQualifiedMoments(state, out, interaction);
  }

  function wrappedPatronWifeClimax(state, interaction) {
    const perception = confusionPerceptionForPatron(state, interaction?.customerId);
    if (!perception) {
      return withAphrodisiacSubjectiveContext(state, interaction?.customerId, () => (
        original.patronControlWifeClimax(state, interaction)
      ));
    }
    const actualInteraction = interaction;
    const projectedInteraction = {
      ...interaction,
      customerName: perception.perceivedName,
      ...(perception.perceivedPartnerType === 'player' ? { goldEarned: 0 } : {})
    };
    let projectedState = state;
    const priorLatitude = getWife(state)?.latitude;
    if (perception.perceivedPartnerType === 'player') {
      projectedState = updateWife(projectedState, wife => ({
        ...wife,
        latitude: { ...(wife.latitude || {}), byCategory: {} }
      }));
    }
    const previousClimaxProjection = confusionClimaxEmotionProjection;
    if (perception.perceivedPartnerType === 'player'
      && interaction?.coercedSinceSlot == null
      && interaction?.wasPressuredIntoStage !== true) {
      confusionClimaxEmotionProjection = {
        actualPatronId: perception.actualCustomer.id,
        perceivedPartnerType: 'player'
      };
    }
    let out;
    try {
      out = withAphrodisiacSubjectiveContext(state, interaction.customerId, () => (
        withConfusionSubjectiveContext(state, interaction.customerId, () => (
          original.patronControlWifeClimax(projectedState, projectedInteraction)
        ))
      ));
    } finally {
      confusionClimaxEmotionProjection = previousClimaxProjection;
    }
    if (perception.perceivedPartnerType === 'player') {
      out = updateWife(out, wife => ({ ...wife, latitude: priorLatitude }));
      if (interaction?.coercedSinceSlot == null && interaction?.wasPressuredIntoStage !== true) {
        out = addConfusedPlayerClimaxFeelings(out, interaction, perception);
      }
    }
    const live = required.getActiveScene(out);
    if (live) {
      out = {
        ...out,
        activeScene: {
          ...(out.activeScene || {}),
          patron: {
            ...live,
            customerId: actualInteraction.customerId,
            customerName: actualInteraction.customerName,
            goldEarned: actualInteraction.goldEarned
          }
        }
      };
    }
    return out;
  }

  function addConfusedPlayerClimaxFeelings(state, interaction, perception) {
    const action = confusionAftermathAction(interaction);
    const tags = CONFUSION_ACTION_AFFINITIES[action] || [];
    const affinities = getWife(state)?.affinities || {};
    const alignmentScore = tags.length
      ? tags.reduce((sum, tag) => sum + confusionAffinityValue(affinities, tag), 0) / tags.length
      : 0;
    const effect = effectOf(readData(state), 'confusion');
    const acceptance = confusionCounterfactualAcceptance(state, perception, interaction?.stage);
    const metadata = {
      badGuestConfusionEpisodeId: effect?.episodeId ?? null,
      badGuestActualPatronId: perception.actualCustomer.id,
      badGuestActualPatronName: perception.actualCustomer.name,
      badGuestPerceivedPartnerId: 'player',
      badGuestPerceivedPartnerName: perception.perceivedName,
      badGuestPerceivedPartnerType: 'player',
      badGuestCounterfactualAccepted: acceptance?.actualAnswer === 'yes'
    };
    const sourceAction = action || interaction?.stage || 'intimacy';
    let out = state;
    if (alignmentScore > 0.5) {
      out = original.addFeeling(out, 'ecstasy', {
        ...metadata,
        intensity: Math.min(95, 65 + Math.round(alignmentScore * 12)),
        source: `player:confusion:${sourceAction}:climax`,
        durationSlots: 200
      });
    } else if (alignmentScore > -0.4) {
      out = original.addFeeling(out, 'elation', {
        ...metadata,
        intensity: 50 + Math.round(alignmentScore * 8),
        source: `player:confusion:${sourceAction}:climax`,
        durationSlots: 180
      });
    }
    const dislikedAnal = action === 'anal' && Number(affinities.anal || 0) < -0.5;
    const dislikedSubmission = action === 'sex_rough'
      && confusionAffinityValue(affinities, 'submission') < -0.5;
    if (dislikedAnal || dislikedSubmission || alignmentScore < -1) {
      out = original.addFeeling(out, 'shame', {
        ...metadata,
        intensity: 45,
        source: `player:confusion:${sourceAction}:she_came_anyway`,
        durationSlots: 240
      });
    }
    const romantic = Number(affinities.romantic || 0);
    if (romantic > 0.6 && alignmentScore > 0) {
      out = original.addFeeling(out, 'tenderness', {
        ...metadata,
        intensity: 35 + Math.round(romantic * 8),
        source: `player:confusion:${sourceAction}:climax_tender`,
        durationSlots: 200
      });
    }
    return out;
  }

  function badGuestOwnsHistoryCoercion(state, event) {
    const scene = required.getActiveScene(state);
    const partnerCustomer = (state.customers || []).find(customer => (
      customer.name === event?.partner
      || scene?.customerName === event?.partner && String(customer.id) === String(scene.customerId)
    ));
    if (!partnerCustomer || !isBadGuest(state, partnerCustomer)) return false;
    const sceneMatches = scene
      && (scene.customerName === event?.partner || String(scene.customerId) === String(partnerCustomer.id));
    const forcedJoin = scene?.badGuestForcedJoinIds?.some(id => String(id) === String(partnerCustomer.id));
    return event?.coerced === true
      || event?.reception === 'forced'
      || forcedJoin === true
      || Boolean(sceneMatches
        && (scene.coercedSinceSlot != null || scene.wasPressuredIntoStage === true))
      || Boolean(endingPatronIncidentContext?.coercion
        && endingPatronIncidentContext.patronName === event?.partner);
  }

  function qualifiedExperienceVerdict(state, event, details = {}) {
    if (badGuestOwnsHistoryCoercion(state, event)) {
      return { general: false, relationship: false };
    }
    const aphrodisiacMemory = details.aphrodisiacMemory;
    if (details.perception) {
      const withoutAphrodisiac = aphrodisiacMemory
        ? (aphrodisiacMemory.unassistedActualAnswer ?? aphrodisiacMemory.unassistedAnswer) === 'yes'
        : true;
      return {
        general: details.counterfactualAccepted === true && withoutAphrodisiac,
        relationship: false
      };
    }
    if (aphrodisiacMemory) {
      const acceptedWithoutAphrodisiac = aphrodisiacMemory.unassistedAnswer === 'yes';
      return {
        general: acceptedWithoutAphrodisiac,
        relationship: acceptedWithoutAphrodisiac
      };
    }
    return null;
  }

  function reportQualifiedExperience(state, event, verdict) {
    if (!verdict) return event;
    const service = getQualifiedExperience();
    if (!service) return event;
    try {
      const report = event.badGuestConfusionEpisodeId == null ? verdict : {
        ...verdict,
        payload: {
          confusionEpisodeId: event.badGuestConfusionEpisodeId,
          confusionRecovered: false,
          recordedReception: event.reception,
          actualReception: event.badGuestActualReception ?? null,
          counterfactualAccepted: event.badGuestCounterfactualAccepted === true
        }
      };
      return service.reportExperience(event, WML_DATA_KEY, report) || event;
    } catch {
      return event;
    }
  }

  function qualifiedPhysicalSessionId(state, event) {
    const scene = required.getActiveScene(state);
    const matchingScene = scene && (
      scene.customerName === event?.partner
      || (state.customers || []).some(customer => (
        String(customer.id) === String(scene.customerId) && customer.name === event?.partner
      ))
    ) ? scene : null;
    const ending = endingPatronIncidentContext?.patronName === event?.partner
      ? endingPatronIncidentContext : null;
    const patronId = matchingScene?.customerId ?? ending?.patronId ?? event?.partner;
    const startedAtSlot = matchingScene?.startedAtSlot
      ?? ending?.startedAtSlot
      ?? event?.slot
      ?? state?.slot;
    return JSON.stringify([
      'patron',
      Number(event?.day ?? state?.day ?? 1),
      String(patronId ?? ''),
      Number(startedAtSlot ?? 0)
    ]);
  }

  function qualifiedPhysicalCompletionOrdinal(state, event) {
    const wife = getWife(state);
    const partner = Object.values(wife?.intimateTally?.partners || {}).find(entry => (
      entry?.partner === event?.partner && entry?.partnerType === event?.partnerType
    ));
    const tallyCount = Number(partner?.acts?.[event?.actId]);
    if (Number.isFinite(tallyCount) && tallyCount > 0) return tallyCount;
    return (wife?.intimateHistory || []).filter(entry => (
      entry?.partner === event?.partner
      && entry?.partnerType === event?.partnerType
      && entry?.actId === event?.actId
    )).length;
  }

  function reportQualifiedPhysicalExperience(state, event, verdict) {
    if (verdict?.general !== false
      || event?.continues === true
      || event?.awareness === 'unaware'
      || event?.reception === 'unaware') return state;
    const service = getQualifiedExperience();
    if (!service) return state;
    const sessionId = qualifiedPhysicalSessionId(state, event);
    const completionOrdinal = qualifiedPhysicalCompletionOrdinal(state, event);
    const eventId = JSON.stringify([
      sessionId,
      String(event?.partner ?? ''),
      String(event?.actId ?? ''),
      completionOrdinal,
      Number(event?.day ?? state?.day ?? 1),
      Number(event?.slot ?? state?.slot ?? 0),
      Number(state?.logSeq ?? 0)
    ]);
    try {
      return service.reportPhysicalExperience(state, WML_DATA_KEY, {
        characterId: state.primaryCharacterId,
        actionId: event.actId,
        sessionId,
        eventId,
        general: false
      }) || state;
    } catch {
      return state;
    }
  }

  function recordQualifiedIntimateHistory(state, event, verdict) {
    const reportedEvent = reportQualifiedExperience(state, event, verdict);
    const recorded = original.recordIntimateHistory(state, reportedEvent);
    return reportQualifiedPhysicalExperience(recorded, reportedEvent, verdict);
  }

  function wrappedRecordIntimateHistory(state, event) {
    if (event?.awareness === 'unaware' || event?.reception === 'unaware') {
      return original.recordIntimateHistory(state, event);
    }
    if (event?.partnerType !== 'patron') return original.recordIntimateHistory(state, event);
    const category = CONFUSION_ACT_CATEGORY[event.actId] || event.actId;
    const aphrodisiacMemory = aphrodisiacHistoryMemory(state, event, category);
    if (aphrodisiacMemory?.fromCurrentDecision) latestAphrodisiacAcceptance = null;
    const scene = required.getActiveScene(state);
    const perception = confusionPerceptionForPatron(state, event.partner);
    if (!perception) {
      if (!aphrodisiacMemory) {
        return recordQualifiedIntimateHistory(state, event, qualifiedExperienceVerdict(state, event));
      }
      const recordedEvent = {
        ...event,
        reception: APHRODISIAC_RECEPTION_KEYS[event.reception] || event.reception,
        badGuestAphrodisiacEpisodeId: aphrodisiacMemory.episodeId,
        badGuestBaseReception: event.reception,
        badGuestAphrodisiacAssisted: aphrodisiacMemory.drugChangedOutcome === true,
        badGuestUnassistedAccepted: aphrodisiacMemory.unassistedAnswer === 'yes',
        badGuestUnassistedOutcome: aphrodisiacMemory.unassistedOutcome ?? null,
        badGuestGivenWithoutAphrodisiac: aphrodisiacMemory.given === true
      };
      return recordQualifiedIntimateHistory(
        state,
        recordedEvent,
        qualifiedExperienceVerdict(state, recordedEvent, { aphrodisiacMemory })
      );
    }
    const data = readData(state);
    const episodeId = effectOf(data, 'confusion')?.episodeId ?? null;
    const historyScene = patronHistoryScene(state, event);
    const startedAt = historyScene
      ? Number(historyScene.scene.startedAtSlot)
      : Number(event.slot ?? state.slot);
    const sceneMemories = [...(data.confusionMemories?.events || [])].reverse().filter(entry => (
      entry.episodeId === episodeId
      && entry.actualPatronName === event.partner
      && String(entry.actualPatronId) === String(perception.actualCustomer.id)
      && entry.answer === 'yes'
      && Number(entry.slot) >= startedAt
      && Number(entry.slot) <= Number(event.slot ?? state.slot)
    ));
    const memory = sceneMemories.find(entry => historyMemoryMatchesAct(entry, event, category))
      || (historyScene?.primary && PRIMARY_PATRON_HISTORY_ACTS.has(event.actId)
        ? sceneMemories.find(entry => entry.actualAnswer === 'no')
        : null);
    const directDecisionCategory = event.actId === 'anal'
      ? 'sex_anal' : STAGE_CATEGORIES[category] || category;
    const fallbackDecision = memory ? null : (
      confusionActualAcceptance(
        state,
        patronMemorySubject(state, event.partner),
        directDecisionCategory
      ) || confusionActualAcceptance(
        state,
        patronMemorySubject(state, event.partner),
        category
      )
    );
    const actualOutcome = memory?.actualOutcome ?? fallbackDecision?.outcome ?? null;
    const counterfactualAccepted = memory?.actualAnswer === 'yes'
      || (!memory && acceptanceAnswer(fallbackDecision) === 'yes');
    const perceivedOutcome = memory?.perceivedOutcome ?? null;
    const perceivedReception = perception.perceivedPartnerType === 'player'
      && event.reception === 'paid'
      ? (perceivedOutcome === 'eager'
        ? 'eager'
        : perceivedOutcome === 'hesitant' ? 'hesitant' : 'willing')
      : event.reception;
    const recordedReception = CONFUSION_RECEPTION_KEYS[perceivedReception] || perceivedReception;
    const recordedEvent = {
      ...event,
      reception: recordedReception,
      badGuestActualPartner: event.partner,
      badGuestActualPartnerType: event.partnerType,
      badGuestActualPatronId: perception.actualCustomer.id,
      badGuestActualReception: event.reception,
      badGuestActualPaid: event.reception === 'paid',
      badGuestConfusionTargetId: perception.perceivedId,
      badGuestConfusionTargetName: perception.perceivedName,
      badGuestConfusionTargetType: perception.perceivedPartnerType,
      badGuestConfusionEpisodeId: episodeId,
      badGuestPerceivedReception: perceivedReception,
      badGuestActualOutcome: actualOutcome,
      badGuestCounterfactualAccepted: counterfactualAccepted,
      badGuestDeceived: true,
      badGuestSceneStartedAtSlot: historyScene?.scene.startedAtSlot ?? null,
      badGuestConfusionSourceSlot: memory?.slot ?? (!historyScene && fallbackDecision ? state.slot : null),
      badGuestConfusionSourceCategory: memory?.category ?? (!historyScene && fallbackDecision ? category : null),
      ...(aphrodisiacMemory ? {
        badGuestAphrodisiacEpisodeId: aphrodisiacMemory.episodeId,
        badGuestAphrodisiacAssisted: aphrodisiacMemory.drugChangedOutcome === true,
        badGuestUnassistedAccepted: aphrodisiacMemory.unassistedAnswer === 'yes',
        badGuestUnassistedOutcome: aphrodisiacMemory.unassistedOutcome ?? null,
        badGuestGivenWithoutAphrodisiac: aphrodisiacMemory.given === true
      } : {})
    };
    let recordInput = state;
    if (!memory && !historyScene && fallbackDecision) {
      const data = getData(state);
      const actualSubject = patronMemorySubject(state, event.partner);
      const perceivedSubject = {
        id: perception.perceivedId,
        name: perception.perceivedName,
        type: perception.perceivedPartnerType
      };
      ensureConfusionMemoryBaseline(data, state, actualSubject, category);
      ensureConfusionMemoryBaseline(data, state, perceivedSubject, category);
      appendConfusionMemoryEvent(data, state, actualSubject, perceivedSubject, category, 'yes', {
        decisionCategory: directDecisionCategory,
        actualAnswer: acceptanceAnswer(fallbackDecision),
        actualOutcome: fallbackDecision.outcome ?? null,
        perceivedOutcome: confusionPerceivedAcceptance(state, actualSubject, directDecisionCategory)?.outcome ?? null,
        counterfactualGiven: acceptanceAnswer(fallbackDecision) === 'yes'
      });
      latestConfusionActualAcceptance = null;
      latestConfusionPerceivedAcceptance = null;
      recordInput = putData(state, data);
    }
    return recordQualifiedIntimateHistory(
      recordInput,
      recordedEvent,
      qualifiedExperienceVerdict(state, recordedEvent, {
        perception,
        aphrodisiacMemory,
        counterfactualAccepted
      })
    );
  }

  function patronMemorySubject(state, patronName) {
    const customer = (state.customers || []).find(entry => entry.name === patronName);
    return {
      id: customer?.id ?? null,
      name: patronName,
      type: 'patron',
      active: false
    };
  }

  function matchesConfusionMemorySubject(event, subject) {
    const type = event?.perceivedType ?? event?.type;
    const id = event?.perceivedId ?? event?.id;
    const name = event?.perceivedName ?? event?.name;
    if (!event || type !== subject.type) return false;
    if (subject.type === 'player') return id === 'player';
    if (subject.id != null && id != null) return String(id) === String(subject.id);
    return name === subject.name;
  }

  function confusionMemoryBaseline(data, subject, category) {
    return (data.confusionMemories?.baselines || []).find(entry => (
      entry.category === category && matchesConfusionMemorySubject(entry, subject)
    ));
  }

  function snapshotPatronReach(state, subject, category) {
    if (subject.type === 'player') return null;
    const reach = (state.patronRecords || [])
      .find(record => record.name === subject.name)?.reaches?.[category];
    return reach ? { ...reach, recent: [...(reach.recent || [])] } : null;
  }

  function ensureConfusionMemoryBaseline(data, state, subject, category) {
    if (confusionMemoryBaseline(data, subject, category)) return;
    const baselines = data.confusionMemories?.baselines || [];
    data.confusionMemories = {
      baselines: [...baselines, {
        id: subject.id,
        name: subject.name,
        type: subject.type,
        category,
        reach: snapshotPatronReach(state, subject, category)
      }],
      events: [...(data.confusionMemories?.events || [])],
      recoveries: [...(data.confusionMemories?.recoveries || [])],
      recoveryBaselines: [...(data.confusionMemories?.recoveryBaselines || [])]
    };
  }

  function refreshConfusionMemoryBaseline(data, state, subject, category) {
    const baselines = [...(data.confusionMemories?.baselines || [])];
    const index = baselines.findIndex(entry => (
      entry.category === category && matchesConfusionMemorySubject(entry, subject)
    ));
    if (index < 0) return;
    baselines[index] = {
      ...baselines[index],
      reach: snapshotPatronReach(state, subject, category)
    };
    data.confusionMemories = {
      baselines,
      events: [...(data.confusionMemories?.events || [])],
      recoveries: [...(data.confusionMemories?.recoveries || [])],
      recoveryBaselines: [...(data.confusionMemories?.recoveryBaselines || [])]
    };
  }

  function compactConfusionMemoryEvents(data) {
    const events = data.confusionMemories?.events || [];
    if (events.length <= CONFUSION_MEMORY_LIMIT) return;
    data.confusionMemories = {
      baselines: [...(data.confusionMemories?.baselines || [])],
      events: events.slice(-CONFUSION_MEMORY_LIMIT),
      recoveries: [...(data.confusionMemories?.recoveries || [])],
      recoveryBaselines: [...(data.confusionMemories?.recoveryBaselines || [])]
    };
  }

  function appendConfusionMemoryEvent(data, state, actualSubject, perceivedSubject, category, answer, details = {}) {
    const events = data.confusionMemories?.events || [];
    data.confusionMemories = {
      baselines: [...(data.confusionMemories?.baselines || [])],
      events: [...events, {
        slot: state.slot,
        day: state.day ?? null,
        actualPatronId: actualSubject.id,
        actualPatronName: actualSubject.name,
        perceivedId: perceivedSubject.id,
        perceivedName: perceivedSubject.name,
        perceivedType: perceivedSubject.type,
        category,
        answer,
        episodeId: effectOf(data, 'confusion')?.episodeId ?? null,
        ...details
      }],
      recoveries: [...(data.confusionMemories?.recoveries || [])],
      recoveryBaselines: [...(data.confusionMemories?.recoveryBaselines || [])]
    };
    compactConfusionMemoryEvents(data);
  }

  function confusionActualAcceptance(state, actualSubject, category) {
    const scoped = patronEscalationContext?.actualIntimacyDecision;
    if (scoped?.category === category
      && String(patronEscalationContext?.customerId) === String(actualSubject.id)) return scoped;
    const recent = latestConfusionActualAcceptance;
    const episodeId = effectOf(readData(state), 'confusion')?.episodeId ?? null;
    if (recent
      && recent.episodeId === episodeId
      && recent.slot === state.slot
      && recent.category === category
      && String(recent.customerId) === String(actualSubject.id)) return recent.decision;
    return null;
  }

  function confusionPerceivedAcceptance(state, actualSubject, category) {
    const scoped = patronEscalationContext?.intimacyDecision;
    if (scoped?.category === category
      && String(patronEscalationContext?.customerId) === String(actualSubject.id)) return scoped;
    const recent = latestConfusionPerceivedAcceptance;
    const episodeId = effectOf(readData(state), 'confusion')?.episodeId ?? null;
    if (recent
      && recent.episodeId === episodeId
      && recent.slot === state.slot
      && recent.category === category
      && String(recent.customerId) === String(actualSubject.id)) return recent.decision;
    return null;
  }

  function acceptanceAnswer(decision) {
    if (!decision?.outcome) return null;
    return decision.outcome === 'refuse' || decision.outcome === 'offended' ? 'no' : 'yes';
  }

  function noteConfusionRecoveryEvidence(data, state, perception, category) {
    const effect = effectOf(data, 'confusion');
    if (!effect || state.slot >= effect.endsAtSlot || !perception?.actualCustomer?.id) return;
    const room = wifeLocation(state);
    const actualPresent = customerLocation(state, perception.actualCustomer.id) === room;
    const perceivedPresent = perception.perceivedPartnerType === 'player'
      ? playerInsideRoom(state, room)
      : customerLocation(state, perception.perceivedId) === room;
    const blindfolded = equipmentApplies(state, 'blindfold', perception.actualCustomer.id);
    const heavilyIntoxicated = (getWife(state)?.intoxication?.level ?? 0) >= 80;
    const current = effect.recoveryEvidence || {};
    setEffect(data, 'confusion', {
      ...effect,
      recoveryEvidence: {
        eventCount: Number(current.eventCount || 0) + 1,
        perceivedAbsentCount: Number(current.perceivedAbsentCount || 0) + (perceivedPresent ? 0 : 1),
        concurrentTargetCount: Number(current.concurrentTargetCount || 0)
          + (actualPresent && perceivedPresent && !blindfolded ? 1 : 0),
        visibleMismatchCount: Number(current.visibleMismatchCount || 0)
          + (actualPresent && !blindfolded ? 1 : 0),
        blindfoldedCount: Number(current.blindfoldedCount || 0) + (blindfolded ? 1 : 0),
        heavilyIntoxicatedCount: Number(current.heavilyIntoxicatedCount || 0)
          + (heavilyIntoxicated ? 1 : 0),
        categories: [...new Set([...(current.categories || []), category].filter(Boolean))].slice(-16),
        actualPatronIds: [...new Set([
          ...(current.actualPatronIds || []),
          String(perception.actualCustomer.id)
        ])].slice(-16)
      }
    });
  }

  function confusionRecoveryEpisodeEvents(data, effect) {
    const episodeId = effect?.episodeId;
    if (!episodeId) return [];
    return (data.confusionMemories?.events || []).filter(event => event?.episodeId === episodeId);
  }

  function confusionRecoveryCheck(state, effect, episodeEvents, sample = Math.random()) {
    const evidence = effect?.recoveryEvidence || {};
    const eventCount = Math.max(Number(evidence.eventCount || 0), episodeEvents?.length || 0);
    const wit = clamp(Number(effectiveAttributes(getWife(state))?.wit ?? 50));
    let score = Math.round(wit * 0.55);
    if (Number(evidence.perceivedAbsentCount || 0) > 0) score += 25;
    const concurrentTargetCount = Math.max(0, Number(evidence.concurrentTargetCount || 0));
    const visibleMismatchCount = Math.max(0, Number(evidence.visibleMismatchCount || 0));
    if (concurrentTargetCount > 1) score += Math.min(15, (concurrentTargetCount - 1) * 5);
    score += Math.min(10, visibleMismatchCount * 4);
    score += Math.min(10, Math.max(0, (evidence.categories?.length || 0) - 1) * 5);
    if ((evidence.actualPatronIds?.length || 0) > 1) score += 10;
    score += Math.min(5, Math.max(0, eventCount - 1));
    if (eventCount > 0 && Number(evidence.blindfoldedCount || 0) >= eventCount) score -= 20;
    if (eventCount > 0
      && Number(evidence.heavilyIntoxicatedCount || 0) >= Math.ceil(eventCount / 2)) score -= 10;
    score = clamp(score, 5, 95);
    const chance = score / 100;
    const roll = clamp(Number(sample), 0, 0.999999);
    return { wit, score, chance, roll, success: roll < chance };
  }

  function confusionStageRank(stage) {
    return Math.max(0, STAGES.indexOf(stage));
  }

  function latestEpisodeAcceptance(data, episodeId, actualPatronId, category = null) {
    const categories = Array.isArray(category) ? category.filter(Boolean) : category ? [category] : [];
    return [...(data.confusionMemories?.events || [])].reverse().find(event => (
      event.episodeId === episodeId
      && String(event.actualPatronId) === String(actualPatronId)
      && (!categories.length || categories.includes(event.category))
    )) || null;
  }

  function confusionCounterfactualAcceptance(state, perception, category = null) {
    const data = readData(state);
    const effect = effectOf(data, 'confusion');
    if (!effect?.episodeId || !perception?.actualCustomer?.id) return null;
    return latestEpisodeAcceptance(data, effect.episodeId, perception.actualCustomer.id, category)
      || latestEpisodeAcceptance(data, effect.episodeId, perception.actualCustomer.id);
  }

  function confusionFirstCategories(interaction) {
    const stages = [
      ...(interaction?.actsHad || []).map(entry => entry?.stage),
      interaction?.stage
    ];
    return [...new Set(stages.map(stage => CONFUSION_FIRST_CATEGORY[stage]).filter(Boolean))];
  }

  function appendConfusionEffectJournal(state, field, entry) {
    const data = getData(state);
    const effect = effectOf(data, 'confusion');
    if (!effect?.episodeId || state.slot >= effect.endsAtSlot) return state;
    setEffect(data, 'confusion', {
      ...effect,
      [field]: [...(effect[field] || []), entry]
    });
    return putData(state, data);
  }

  function markConfusionFirsts(state, beforeFirsts, interaction, witnessed, perception, beforeMood = null) {
    const data = readData(state);
    const effect = effectOf(data, 'confusion');
    if (!effect?.episodeId) return state;
    const categories = confusionFirstCategories(interaction);
    const before = beforeFirsts && typeof beforeFirsts === 'object' && !Array.isArray(beforeFirsts)
      ? beforeFirsts
      : {};
    const after = getWife(state)?.firstsWithOthers;
    const existingJournal = effect.firstJournal || [];
    const journal = [...existingJournal];
    let out = state;

    if (Array.isArray(after)) {
      const start = Array.isArray(beforeFirsts) ? beforeFirsts.length : 0;
      const added = after.slice(start);
      if (added.length) {
        out = updateWife(out, wife => ({
          ...wife,
          firstsWithOthers: (wife.firstsWithOthers || []).map((entry, index) => (
            index < start ? entry : { ...entry, badGuestConfusionEpisodeId: effect.episodeId }
          ))
        }));
      }
    } else {
      const additions = {};
      for (const category of categories) {
        const value = after?.[category];
        if (!before[category] && value) {
          additions[category] = { ...value, badGuestConfusionEpisodeId: effect.episodeId };
        }
      }
      if (Object.keys(additions).length) {
        out = updateWife(out, wife => ({
          ...wife,
          firstsWithOthers: { ...(wife.firstsWithOthers || {}), ...additions }
        }));
      }
    }

    for (const category of categories) {
      if (before?.[category]) continue;
      if (journal.some(entry => entry.category === category
        && String(entry.actualPatronId) === String(perception.actualCustomer.id))) continue;
      const memoryCategory = Object.entries(CONFUSION_FIRST_CATEGORY)
        .find(([, firstCategory]) => firstCategory === category)?.[0] || null;
      const acceptance = latestEpisodeAcceptance(
        data,
        effect.episodeId,
        perception.actualCustomer.id,
        memoryCategory
      ) || latestEpisodeAcceptance(data, effect.episodeId, perception.actualCustomer.id);
      journal.push({
        episodeId: effect.episodeId,
        category,
        actualPatronId: perception.actualCustomer.id,
        actualPatronName: perception.actualCustomer.name,
        perceivedId: perception.perceivedId,
        perceivedName: perception.perceivedName,
        perceivedType: perception.perceivedPartnerType,
        day: state.day ?? 1,
        slot: state.slot,
        seen: witnessed,
        counterfactualAccepted: acceptance?.actualAnswer === 'yes',
        counterfactualGiven: acceptance?.actualAnswer === 'yes'
          && interaction?.coercedSinceSlot == null
          && interaction?.wasPressuredIntoStage !== true
      });
    }
    const outData = getData(out);
    const outEffect = effectOf(outData, 'confusion');
    const acceptance = latestEpisodeAcceptance(
      outData,
      outEffect.episodeId,
      perception.actualCustomer.id
    );
    const afterMood = getWife(out)?.mood;
    const moodDelta = Number.isFinite(Number(beforeMood)) && Number.isFinite(Number(afterMood))
      ? Number(afterMood) - Number(beforeMood)
      : 0;
    const firstMoodRollbacks = moodDelta === 0 ? [...(outEffect.firstMoodRollbacks || [])] : [
      ...(outEffect.firstMoodRollbacks || []),
      {
        actualPatronId: perception.actualCustomer.id,
        counterfactualAccepted: acceptance?.actualAnswer === 'yes',
        moodDelta
      }
    ];
    setEffect(outData, 'confusion', { ...outEffect, firstJournal: journal, firstMoodRollbacks });
    return putData(out, outData);
  }

  function numericObjectDelta(before, after) {
    const delta = {};
    const keys = new Set([...Object.keys(before || {}), ...Object.keys(after || {})]);
    for (const key of keys) {
      const prior = Number(before?.[key] || 0);
      const next = Number(after?.[key] || 0);
      if (Number.isFinite(prior) && Number.isFinite(next) && next !== prior) delta[key] = next - prior;
    }
    return delta;
  }

  function subtractNumericObject(value, delta) {
    const next = { ...(value || {}) };
    for (const [key, amount] of Object.entries(delta || {})) {
      const current = Number(next[key] || 0);
      if (Number.isFinite(current) && Number.isFinite(Number(amount))) next[key] = current - Number(amount);
    }
    return next;
  }

  function recordConfusionIncident(beforeState, afterState, interaction, perception, options = {}) {
    const data = getData(afterState);
    const effect = effectOf(data, 'confusion');
    if (!effect?.episodeId || afterState.slot >= effect.endsAtSlot) return afterState;
    const acceptance = latestEpisodeAcceptance(
      data,
      effect.episodeId,
      perception.actualCustomer.id,
      interaction?.stage
    ) || latestEpisodeAcceptance(data, effect.episodeId, perception.actualCustomer.id);
    const actualAccepted = acceptance?.actualAnswer === 'yes';
    const incidentId = `${effect.episodeId}:${perception.actualCustomer.id}:${interaction?.startedAtSlot ?? beforeState.slot}`;
    const incidents = [...(effect.incidents || [])];
    const beforeWife = getWife(beforeState) || {};
    const afterWife = getWife(afterState) || {};
    const incident = {
      id: incidentId,
      episodeId: effect.episodeId,
      actualPatronId: perception.actualCustomer.id,
      actualPatronName: perception.actualCustomer.name,
      perceivedId: perception.perceivedId,
      perceivedName: perception.perceivedName,
      perceivedType: perception.perceivedPartnerType,
      stage: interaction?.stage ?? null,
      day: afterState.day ?? null,
      slot: afterState.slot,
      witnessed: options?.playerWitnessed === true || options?.walkedIn === true,
      counterfactualAccepted: actualAccepted,
      counterfactualGiven: actualAccepted
        && interaction?.coercedSinceSlot == null
        && interaction?.wasPressuredIntoStage !== true,
      actualAnswer: acceptance?.actualAnswer ?? null,
      actualOutcome: acceptance?.actualOutcome ?? null,
      rollback: actualAccepted ? null : {
        identityStrain: Number(afterWife.identityStrain || 0) - Number(beforeWife.identityStrain || 0),
        crossedLineHistory: numericObjectDelta(beforeWife.crossedLineHistory, afterWife.crossedLineHistory),
        selfConcept: numericObjectDelta(beforeWife.selfConcept, afterWife.selfConcept)
      }
    };
    const index = incidents.findIndex(entry => entry.id === incidentId);
    if (index >= 0) incidents[index] = { ...incidents[index], ...incident };
    else incidents.push(incident);
    setEffect(data, 'confusion', { ...effect, incidents: incidents.slice(-64) });
    return putData(afterState, data);
  }

  function projectedUnassistedDecision(decision) {
    if (!decision?.badGuestUnderAphrodisiac || !decision.badGuestUnassistedOutcome) return null;
    return {
      ...decision,
      outcome: decision.badGuestUnassistedOutcome,
      score: decision.badGuestUnassistedScore,
      threshold: decision.badGuestUnassistedThreshold
    };
  }

  function aphrodisiacAcceptance(state, actualSubject, category) {
    const effect = activeAphrodisiacEffect(state);
    if (!effect?.episodeId) return null;
    const scoped = patronEscalationContext;
    if (scoped
      && String(scoped.customerId) === String(actualSubject.id)
      && [scoped.intimacyDecision?.category, scoped.unassistedIntimacyDecision?.category]
        .includes(category)) {
      return {
        decision: scoped.intimacyDecision,
        unassistedDecision: scoped.unassistedIntimacyDecision
          || projectedUnassistedDecision(scoped.intimacyDecision),
        actualDecision: scoped.actualIntimacyDecision,
        unassistedActualDecision: scoped.unassistedActualIntimacyDecision
          || projectedUnassistedDecision(scoped.actualIntimacyDecision)
      };
    }
    const recent = latestAphrodisiacAcceptance;
    if (!recent
      || recent.episodeId !== effect.episodeId
      || recent.slot !== state.slot
      || recent.category !== category
      || String(recent.customerId) !== String(actualSubject.id)) return null;
    return {
      decision: recent.decision,
      unassistedDecision: recent.unassistedDecision,
      actualDecision: recent.actualDecision,
      unassistedActualDecision: projectedUnassistedDecision(recent.actualDecision)
    };
  }

  function appendAphrodisiacMemoryEvent(data, state, subject, category, answer, details) {
    const effect = effectOf(data, 'aphrodisiac');
    if (!effect?.episodeId || state.slot >= effect.endsAtSlot) return null;
    const event = {
      episodeId: effect.episodeId,
      slot: state.slot,
      day: state.day ?? null,
      patronId: subject.id,
      patronName: subject.name,
      category,
      answer,
      ...details
    };
    data.aphrodisiacMemories = {
      events: [...(data.aphrodisiacMemories?.events || []), event]
        .slice(-APHRODISIAC_MEMORY_LIMIT)
    };
    return event;
  }

  function wrappedRecordPatronReach(state, patronName, category, answer) {
    if (unresponsiveDrugTarget(state)) return state;
    const perception = confusionPerceptionForPatron(state, patronName);
    const confusionActive = timedEffectActive(state, 'confusion');
    const aphrodisiacActive = Boolean(activeAphrodisiacEffect(state));
    const actualSubject = patronMemorySubject(state, patronName);
    const interaction = required.getActiveScene(state);
    const restraintCoercion = patronEscalationContext?.restraintCoercion;
    const restraintCoercedReach = answer === 'yes'
      && restraintCoercion
      && String(restraintCoercion.customerId) === String(actualSubject.id)
      && restraintCoercion.targetStage === category;
    const recordedAnswer = restraintCoercedReach ? 'no' : answer;
    let data = null;
    let perceivedSubject = null;
    let actualDecision = null;
    let perceivedDecision = null;
    let actualAnswer = null;
    const acceptanceCategory = STAGE_CATEGORIES[category] || category;
    const aphrodisiac = aphrodisiacAcceptance(state, actualSubject, acceptanceCategory)
      || aphrodisiacAcceptance(state, actualSubject, category);
    const unassistedDecision = aphrodisiac?.unassistedDecision || null;
    const unassistedActualDecision = aphrodisiac?.unassistedActualDecision || unassistedDecision;
    const unassistedAnswer = acceptanceAnswer(unassistedDecision);
    const unassistedActualAnswer = acceptanceAnswer(unassistedActualDecision);
    const aphrodisiacAssisted = recordedAnswer === 'yes' && unassistedAnswer === 'no';
    const factualAphrodisiacAssisted = recordedAnswer === 'yes' && unassistedActualAnswer === 'no';
    if (perception) {
      data = getData(state);
      perceivedSubject = {
        id: perception.perceivedId,
        name: perception.perceivedName,
        type: perception.perceivedPartnerType,
        active: true
      };
      ensureConfusionMemoryBaseline(data, state, actualSubject, category);
      ensureConfusionMemoryBaseline(data, state, perceivedSubject, category);
      actualDecision = confusionActualAcceptance(state, actualSubject, acceptanceCategory)
        || confusionActualAcceptance(state, actualSubject, category);
      perceivedDecision = confusionPerceivedAcceptance(state, actualSubject, acceptanceCategory)
        || confusionPerceivedAcceptance(state, actualSubject, category);
      actualAnswer = acceptanceAnswer(actualDecision);
      latestConfusionActualAcceptance = null;
      latestConfusionPerceivedAcceptance = null;
    } else if (confusionActive) {
      data = getData(state);
      ensureConfusionMemoryBaseline(data, state, actualSubject, category);
    } else {
      const stored = readData(state);
      if (confusionMemoryBaseline(stored, actualSubject, category)) data = stored;
    }
    if (aphrodisiac && recordedAnswer === 'yes') data = data || getData(state);
    const excludedFromReachMemory = confusionActive || aphrodisiacActive || restraintCoercedReach;
    const recorded = excludedFromReachMemory
      ? state
      : original.recordPatronReach(state, patronName, category, recordedAnswer);
    if (!data) return recorded;
    if (!excludedFromReachMemory) {
      refreshConfusionMemoryBaseline(data, recorded, actualSubject, category);
    }
    if (aphrodisiac && recordedAnswer === 'yes') {
      appendAphrodisiacMemoryEvent(data, state, actualSubject, category, recordedAnswer, {
        confusionEpisodeId: timedEffectActive(state, 'confusion')
          ? effectOf(data, 'confusion')?.episodeId ?? null
          : null,
        decisionCategory: aphrodisiac.decision?.category ?? acceptanceCategory,
        outcome: aphrodisiac.decision?.outcome ?? null,
        unassistedAnswer,
        unassistedOutcome: unassistedDecision?.outcome ?? null,
        unassistedActualAnswer,
        unassistedActualOutcome: unassistedActualDecision?.outcome ?? null,
        drugChangedOutcome: aphrodisiacAssisted,
        factualDrugChangedOutcome: factualAphrodisiacAssisted,
        given: !aphrodisiacAssisted
          && interaction?.coercedSinceSlot == null
          && interaction?.wasPressuredIntoStage !== true
      });
      latestAphrodisiacAcceptance = null;
    }
    if (confusionActive) {
      if (perception) noteConfusionRecoveryEvidence(data, state, perception, category);
      appendConfusionMemoryEvent(
        data,
        state,
        actualSubject,
        perceivedSubject || actualSubject,
        category,
        recordedAnswer,
        perception ? {
          decisionCategory: perceivedDecision?.category ?? acceptanceCategory,
          actualAnswer,
          actualOutcome: actualDecision?.outcome ?? null,
          perceivedOutcome: perceivedDecision?.outcome ?? null,
          actualScore: Number.isFinite(Number(actualDecision?.score)) ? Number(actualDecision.score) : null,
          actualThreshold: Number.isFinite(Number(actualDecision?.threshold)) ? Number(actualDecision.threshold) : null,
          counterfactualGiven: actualAnswer === 'yes'
            && interaction?.coercedSinceSlot == null
            && interaction?.wasPressuredIntoStage !== true
        } : {}
      );
    }
    const out = putData(recorded, data);
    return aphrodisiacAssisted && interaction
      && String(interaction.customerId) === String(actualSubject.id)
      ? reportQualifiedVisit(out, interaction)
      : out;
  }

  function confusionMemorySubject(state, patronName) {
    const active = confusionPerceptionForPatron(state, patronName);
    if (active) {
      return {
        id: active.perceivedId,
        name: active.perceivedName,
        type: active.perceivedPartnerType,
        active: true
      };
    }
    return patronMemorySubject(state, patronName);
  }

  function projectedConfusionMemoryState(state, subject, category) {
    const data = readData(state);
    const baseline = confusionMemoryBaseline(data, subject, category);
    const events = data.confusionMemories?.events || [];
    const matching = events.filter(event => (
      event.category === category
      && matchesConfusionMemorySubject(event, subject)
      && Number.isFinite(Number(event.slot))
      && (event.answer === 'yes' || event.answer === 'no')
    )).sort((left, right) => Number(left.slot) - Number(right.slot));
    if (!baseline && !matching.length) return { state, events: [], managed: false };

    let projected = state;
    const recordName = subject.type === 'player' ? '당신' : subject.name;
    const recordIndex = (projected.patronRecords || []).findIndex(record => record.name === recordName);
    const baseRecord = recordIndex >= 0 ? projected.patronRecords[recordIndex] : { name: recordName };
    const latestExcludedNight = matching.reduce((latest, event) => (
      Math.max(latest, Math.floor(Number(event.slot) / 1440))
    ), -Infinity);
    const liveReach = baseRecord.reaches?.[category];
    if (Number.isFinite(Number(liveReach?.lastNight))
      && Number(liveReach.lastNight) > latestExcludedNight) {
      return { state, events: matching, managed: false };
    }
    const memoryReaches = { ...(baseRecord.reaches || {}) };
    if (baseline?.reach) {
      memoryReaches[category] = {
        ...baseline.reach,
        recent: [...(baseline.reach.recent || [])]
      };
    } else delete memoryReaches[category];
    const memoryRecord = { ...baseRecord, reaches: memoryReaches };
    const patronRecords = [...(projected.patronRecords || [])];
    if (recordIndex >= 0) patronRecords[recordIndex] = memoryRecord;
    else patronRecords.push(memoryRecord);
    projected = { ...projected, patronRecords };
    return { state: { ...projected, slot: state.slot }, events: matching, managed: true };
  }

  function wrappedPatronRecallReach(state, patronName, category, wifeName, answer) {
    const subject = confusionMemorySubject(state, patronName);
    const recordName = subject.type === 'player' ? '당신' : subject.name;
    const projected = projectedConfusionMemoryState(state, subject, category);
    if (!projected.managed) {
      return original.patronControlRecallReach(
        state,
        subject.active ? recordName : patronName,
        category,
        wifeName,
        answer
      );
    }
    const recall = original.patronControlRecallReach(
      projected.state,
      recordName,
      category,
      wifeName,
      answer
    );
    return recall || null;
  }

  function wrappedPatronShouldCheckWithHusband(state, interaction, ...rest) {
    const perception = confusionPerceptionForPatron(state, interaction?.customerId);
    if (perception?.perceivedPartnerType === 'player') return false;
    return original.patronControlShouldCheckWithHusband(state, interaction, ...rest);
  }

  function wrappedPatronPrivateOffer(state, request, options) {
    const offered = original.patronControlPrivateOffer(state, request, options);
    if (!offered?.event || !['her', 'him'].includes(request?.by)) return offered;

    const preparedState = offered.state || state;
    const interaction = required.getActiveScene(preparedState);
    const perception = confusionPerceptionForPatron(preparedState, interaction?.customerId);
    if (perception?.perceivedPartnerType !== 'player') return offered;

    const stateWithProposal = options?.alreadySaid || !offered.event.text
      ? preparedState
      : appendLog(preparedState, offered.event.text);
    return {
      state: original.patronControlResolvePrivateOffer(
        stateWithProposal,
        'back_room_private_she_decides',
        { spoken: true }
      )
    };
  }

  function acceptanceScore(result) {
    return Number.isFinite(Number(result?.score)) ? Number(result.score) : -Infinity;
  }

  function strongestAttachmentCustomer(state) {
    const wife = getWife(state);
    let best = null;
    for (const record of state.patronRecords || []) {
      const customer = (state.customers || []).find(entry => entry.name === record.name);
      if (!customer?.id || customer.status === 'gone') continue;
      const attachment = Number(required.patronAttachment(record, wife)) || 0;
      if (!best || attachment > best.attachment) best = { customer, attachment };
    }
    return best?.customer || null;
  }

  function chooseConfusionTarget(state) {
    const candidate = strongestAttachmentCustomer(state);
    if (!candidate) return { id: 'player', name: '당신', playerScore: null, patronScore: null };
    const playerDecision = original.evaluateIntimacy(state, 'sex_vaginal', { kind: 'player_intimate' });
    const patronDecision = original.evaluateIntimacy(state, 'sex_vaginal', {
      kind: 'patron_request',
      comfortWithPatron: required.patronComfort(state, candidate),
      activeCustomerId: candidate.id,
      pressureLevel: 0,
      husbandPresent: false,
      otherWitnesses: 0,
      room: wifeLocation(state)
    });
    const patronWins = acceptanceScore(patronDecision) > acceptanceScore(playerDecision);
    return {
      id: patronWins ? candidate.id : 'player',
      name: patronWins ? candidate.name : '당신',
      playerScore: acceptanceScore(playerDecision),
      patronScore: acceptanceScore(patronDecision)
    };
  }

  function sleepPotionEligibility(state, customer) {
    if (!customer?.id) return { status: 'ineligible', reason: 'actor_missing' };
    if (!sleepActionsAvailable()) return { status: 'ineligible', reason: 'sleep_actions_unavailable' };
    return { status: 'available' };
  }

  function unresponsiveDrugTarget(state) {
    const task = getWife(state)?.currentTask;
    return task === 'passed_out' || task === 'sleeping' ? task : null;
  }

  function activeBackRoomIncident(state) {
    if (wifeLocation(state) !== 'back_room') return false;
    const data = readData(state);
    return Boolean((data.wealthyParty?.active && backRoomParty(state))
      || data.drinkingGame?.active);
  }

  function passOutWhereSheStands(state, kind = 'intoxication') {
    const previousLogCount = state.log?.length || 0;
    let out = original.passOutWife(state);
    if ((out.log?.length || 0) > previousLogCount) {
      const log = [...out.log];
      const last = log.length - 1;
      log[last] = {
        ...log[last],
        text: kind === 'sleep'
          ? wifeLocation(out) === 'back_room'
            ? `${withParticle(wifeDisplayName(out), '은', '는')} 뒷방의 탁자에 기대어 고개를 떨굽니다. 그대로 깊이 잠듭니다.`
            : `${withParticle(wifeDisplayName(out), '은', '는')} 그 자리에서 고개를 떨구고 깊이 잠듭니다.`
          : wifeLocation(out) === 'back_room'
            ? `${withParticle(wifeDisplayName(out), '은', '는')} 뒷방의 탁자에 기대어 고개를 떨굽니다. 몸에서 힘이 빠지고 눈을 뜨지 못합니다.`
            : `${withParticle(wifeDisplayName(out), '은', '는')} 그 자리에서 고개를 떨굽니다. 몸에서 힘이 빠지고 눈을 뜨지 못합니다.`
      };
      out = { ...out, log };
    }
    return out;
  }

  function unresponsiveDrugAttemptLead(kind, task, wifeName, customerName) {
    const condition = task === 'passed_out' ? '정신을 잃고 늘어진' : '깊이 잠든';
    const liquid = kind === 'sleep'
      ? '쓴맛이 밴 액체'
      : kind === 'intoxication'
        ? '매캐한 향이 나는 액체'
        : kind === 'confusion'
          ? '옅은 침전물이 도는 액체'
          : '달큰하고 낯선 향이 밴 액체';
    return `${withParticle(customerName, '은', '는')} ${condition} ${wifeName}의 턱을 받치고, 입술 사이로 ${liquid}를 조금씩 흘려 넣습니다. ${withParticle(wifeName, '은', '는')} 눈을 뜨지 못한 채 그것을 삼킵니다.`;
  }

  let activeSleepPotionApplication = null;

  function drugAttemptClue(kind) {
    if (kind === 'sleep') return '잔 밑바닥에 가라앉은 쓴 가루';
    if (kind === 'intoxication') return '술 냄새와 어울리지 않는 매캐한 향';
    if (kind === 'confusion') return '빛을 받을 때만 옅게 번지는 침전물';
    return '달큰하면서도 낯선 향과 잔 밑바닥의 고운 가루';
  }

  function drugAttemptLead(state, kind, outcome, wifeName, customerName) {
    const clue = drugAttemptClue(kind);
    const voice = storyVoice(state);
    const key = `drug:${customerName}:${kind}:${outcome}`;
    if (outcome === 'refused') {
      const spoken = voice === 'mara' ? '“이상한데요. 직접 마셔 보시겠어요?”'
        : voice === 'pippa' ? '“잔 바닥에 뭐가 있죠? 전 못 마셔요.”'
          : '“잠깐만요. 잔에 뭐가 있죠?”';
      return storyLine(state, key, [
        `${withParticle(wifeName, '은', '는')} ${withParticle(clue, '을', '를')} 알아채고 잔을 내려놓습니다. ${withParticle(customerName, '이', '가')} 재촉하자 잔을 밀어냅니다. “이게 뭔지 말해 줘요.”`,
        `${withParticle(wifeName, '은', '는')} 잔을 눈앞으로 들어 올립니다. ${withParticle(clue, '을', '를')} 알아차리고 ${customerName}에게 잔을 돌려줍니다. ${spoken}`,
        `${withParticle(customerName, '이', '가')} 잔을 더 가까이 밉니다. ${withParticle(wifeName, '은', '는')} ${withParticle(clue, '을', '를')} 알아채고 고개를 젓습니다. “안 마실게요.”`
      ]);
    }
    if (outcome === 'pressured') {
      const spoken = voice === 'mara' ? '“수상한데요.”'
        : voice === 'pippa' ? '“잠깐, 이거…”'
          : '“정말 괜찮은 거예요?”';
      return storyLine(state, key, [
        `${withParticle(wifeName, '은', '는')} ${withParticle(clue, '을', '를')} 알아차리고 손을 멈춥니다. ${withParticle(customerName, '은', '는')} 괜찮다며 잔을 다시 쥐여 줍니다. 그녀는 한참 버티다 마십니다.`,
        `${withParticle(wifeName, '은', '는')} ${withParticle(clue, '을', '를')} 알아채고 잔을 내려놓습니다. ${withParticle(customerName, '이', '가')} 다시 내밉니다. ${spoken} 그녀는 그를 바라보다 결국 잔을 비웁니다.`,
        `${withParticle(customerName, '은', '는')} 괜찮다며 잔을 그녀 손에 쥐여 줍니다. ${withParticle(wifeName, '은', '는')} ${withParticle(clue, '이', '가')} 마음에 걸리지만 더 거절하지 못하고 마십니다.`
      ]);
    }
    if (kind === 'sleep') {
      return storyLine(state, key, [
        `${withParticle(wifeName, '은', '는')} ${withParticle(customerName, '이', '가')} 건넨 잔을 비웁니다. 밑바닥에 쓴 가루가 남습니다.`,
        `${withParticle(wifeName, '은', '는')} 잔을 한 번에 비웁니다. ${withParticle(customerName, '은', '는')} 빈 잔을 받아 치우고, 밑바닥에는 쓴 가루가 조금 남습니다.`
      ]);
    }
    if (kind === 'intoxication') {
      return storyLine(state, key, [
        `${withParticle(wifeName, '은', '는')} ${withParticle(customerName, '이', '가')} 건넨 잔을 비웁니다. 매캐한 향이 술 냄새에 묻힙니다.`,
        `${withParticle(wifeName, '은', '는')} ${customerName}에게서 잔을 받아 마십니다. 빈 잔을 내려놓을 때 매캐한 향이 잠깐 올라왔다가 술 냄새에 가립니다.`
      ]);
    }
    if (kind === 'confusion') {
      return storyLine(state, key, [
        `${withParticle(wifeName, '은', '는')} ${withParticle(customerName, '이', '가')} 건넨 잔을 비웁니다. 잔에 옅은 침전물이 남습니다.`,
        `${withParticle(wifeName, '은', '는')} 건네받은 술을 마십니다. ${withParticle(customerName, '은', '는')} 빛을 피해 잔을 거두지만 옅은 침전물이 바닥에 남아 있습니다.`
      ]);
    }
    return storyLine(state, key, [
      `${withParticle(wifeName, '은', '는')} ${withParticle(customerName, '이', '가')} 건넨 잔을 비웁니다. 달큰한 향과 고운 가루가 잔에 남습니다.`,
      `${withParticle(wifeName, '은', '는')} 달큰한 술을 마시고 잔을 내려놓습니다. ${withParticle(customerName, '은', '는')} 잔을 먼저 집어 들지만 고운 가루가 바닥에 남습니다.`
    ]);
  }

  function confusionPlayerDrugAttemptLead(state, kind, outcome, wifeName, customerName) {
    const clue = drugAttemptClue(kind);
    const key = `confused-drug:${customerName}:${kind}:${outcome}`;
    if (outcome === 'refused') {
      return storyLine(state, key, [
        `${withParticle(wifeName, '은', '는')} ${withParticle(customerName, '을', '를')} 당신으로 알고 잔을 받습니다. 그러나 ${withParticle(clue, '을', '를')} 알아차리고 손을 멈춘 뒤 잔을 밀어냅니다.`,
        `${withParticle(wifeName, '은', '는')} ${customerName}에게서 눈을 떼지 않은 채 잔을 받으려다 ${withParticle(clue, '을', '를')} 알아차립니다. “이건 못 마시겠어.” 잔을 돌려줍니다.`
      ]);
    }
    if (outcome === 'pressured') {
      return storyLine(state, key, [
        `${withParticle(wifeName, '은', '는')} ${withParticle(customerName, '을', '를')} 당신으로 알고도 ${withParticle(clue, '을', '를')} 알아차리고 멈칫합니다. 그의 재촉에 밀려 마십니다.`,
        `${withParticle(wifeName, '은', '는')} ${customerName} 곁에서 잔을 들었다 놓습니다. ${withParticle(clue, '이', '가')} 마음에 걸리지만 그의 재촉 끝에 마십니다.`
      ]);
    }
    return storyLine(state, key, [
      `${withParticle(wifeName, '은', '는')} ${withParticle(customerName, '을', '를')} 당신으로 알고 잔을 비웁니다. ${withParticle(clue, '은', '는')} 알아차리지 못합니다.`,
      `${withParticle(wifeName, '은', '는')} ${withParticle(customerName, '이', '가')} 건넨 잔을 익숙한 듯 받아 비우지만 ${withParticle(clue, '은', '는')} 알아차리지 못합니다.`
    ]);
  }

  function confusionLoverDrugAttemptLead(state, kind, outcome, wifeName, customer) {
    const context = confusionLoverTargetContext(state, customer);
    if (!context) return drugAttemptLead(state, kind, outcome, wifeName, customer.name);
    const clue = drugAttemptClue(kind);
    const subject = withParticle(wifeName, '은', '는');
    const customerObject = withParticle(customer.name, '을', '를');
    const customerSubject = withParticle(customer.name, '이', '가');
    const perceivedName = context.perceivedCustomer.name;
    const key = `confused-lover-drug:${customer.id}:${context.perceivedCustomer.id}:${kind}:${outcome}`;
    if (context.samePerson) {
      if (outcome === 'refused') {
        return storyLine(state, key, [
          `${subject} ${customerObject} 알아보고 잔을 받다가 ${withParticle(clue, '을', '를')} 알아차리고 멈칫합니다. 잔을 돌려줍니다.`,
          `${subject} ${customer.name}의 이름을 부릅니다. 잔을 들었다가 ${withParticle(clue, '을', '를')} 알아차리고 탁자에 내려놓습니다.`
        ]);
      }
      if (outcome === 'pressured') {
        return storyLine(state, key, [
          `${subject} ${customerObject} 알아보고 잔을 받습니다. ${withParticle(clue, '을', '를')} 알아차리고 멈칫하지만 그의 재촉에 마십니다.`,
          `${subject} ${customer.name}의 이름을 부릅니다. 잔을 들었다가 ${withParticle(clue, '을', '를')} 알아차리고 내려놓습니다. 그가 다시 내밀고 재촉하자 마십니다.`
        ]);
      }
      return storyLine(state, key, [
        `${subject} ${customerObject} 알아보고 그가 건넨 잔을 받습니다. 그대로 비웁니다.`,
        `${subject} ${customer.name}의 이름을 부르며 잔을 입에 댑니다. 잔을 비울 때까지 내려놓지 않습니다.`
      ]);
    }
    if (outcome === 'refused') {
      return storyLine(state, key, [
        `${subject} ${customerObject} 보며 ${perceivedName}의 이름을 부르고 잔을 받다가 ${withParticle(clue, '을', '를')} 알아차리고 멈칫합니다. 잔을 돌려줍니다.`,
        `${subject} ${customerObject} 보며 ${perceivedName}의 이름을 부릅니다. 잔을 들었다가 ${withParticle(clue, '을', '를')} 알아차리고 탁자에 내려놓습니다.`
      ]);
    }
    if (outcome === 'pressured') {
      return storyLine(state, key, [
        `${subject} ${customerObject} 보며 ${perceivedName}의 이름을 부르고 잔을 받습니다. ${withParticle(clue, '을', '를')} 알아차리고 멈칫하지만 그의 재촉에 마십니다.`,
        `${subject} ${customerObject} 보며 ${perceivedName}의 이름을 부릅니다. 잔을 들었다가 ${withParticle(clue, '을', '를')} 알아차리고 내려놓습니다. 그가 다시 내밀고 재촉하자 마십니다.`
      ]);
    }
    return storyLine(state, key, [
      `${subject} ${customerObject} 보며 ${perceivedName}의 이름을 부르고 잔을 받습니다. 그대로 비웁니다.`,
      `${subject} ${perceivedName}의 이름을 부르며 ${customerSubject} 건넨 잔을 입에 댑니다. 잔을 비울 때까지 내려놓지 않습니다.`
    ]);
  }

  function sleepPotionRoom(state) {
    if (Math.random() * 100 >= settings.sleepPotionGuestRoomChance) return null;
    const currentRoom = wifeLocation(state);
    const rooms = [];
    if (state.tavern?.hasRoom && currentRoom !== 'upstairs_hall') rooms.push('upstairs_hall');
    if (state.tavern?.hasRoom2 && currentRoom !== 'upstairs_room_2') rooms.push('upstairs_room_2');
    return rooms.length ? rooms[Math.floor(Math.random() * rooms.length)] : null;
  }

  function wrappedApplyPotionEffect(state, effect, effectiveUnits, targetId, cupId, ...rest) {
    const context = activeSleepPotionApplication;
    if (!context
      || context.cupId !== cupId
      || context.targetCharacterId !== targetId
      || effect?.ride?.kind !== 'sleep'
      || !(Number(effectiveUnits) > 0)) {
      return original.applyPotionEffect(state, effect, effectiveUnits, targetId, cupId, ...rest);
    }
    const data = getData(state);
    if (data.sleepPotion.requests.includes(context.requestId)) return state;
    const delayMin = Math.min(settings.sleepPotionDepartureDelayMin, settings.sleepPotionDepartureDelayMax);
    const delayMax = Math.max(settings.sleepPotionDepartureDelayMin, settings.sleepPotionDepartureDelayMax);
    const delay = delayMin + Math.floor(Math.random() * (delayMax - delayMin + 1));
    const existing = data.sleepPotion.pending;
    data.sleepPotion.pending = existing ? {
      ...existing,
      stayInPlace: existing.stayInPlace || activeBackRoomIncident(state),
      effectiveUnits: Number(existing.effectiveUnits || 0) + Number(effectiveUnits),
      depth: Number(existing.depth || 0) + Number(effectiveUnits) * 100
    } : {
      requestId: context.requestId,
      customerId: context.customerId,
      targetCharacterId: targetId,
      cupId,
      effectiveUnits: Number(effectiveUnits),
      depth: Number(effectiveUnits) * 100,
      requestedAtSlot: state.slot,
      moveAtSlot: state.slot + delay,
      stayInPlace: activeBackRoomIncident(state)
    };
    data.sleepPotion.requests = [...data.sleepPotion.requests, context.requestId].slice(-128);
    return putData(state, data);
  }

  function applySleepDrugImpl(state, customer, text = '') {
    if (sleepPotionEligibility(state, customer).status !== 'available') return state;
    const unresponsive = unresponsiveDrugTarget(state);
    const requestId = `badguest:sleep-potion:${state.day ?? 0}:${state.slot}:${customer.id}`;
    if (readData(state).sleepPotion.requests.includes(requestId)) return state;
    const cupId = `${requestId}:cup`;
    activeSleepPotionApplication = {
      requestId,
      customerId: customer.id,
      targetCharacterId: getWifeId(state),
      cupId
    };
    let out;
    try {
      out = original.applyPotionCupEffects(state, {
        id: cupId,
        effects: [{ property: 'drowse', units: 1 }]
      }, activeSleepPotionApplication.targetCharacterId, false);
    } finally {
      activeSleepPotionApplication = null;
    }
    const lead = text || (unresponsive ? '' : `${withParticle(wifeDisplayName(out), '은', '는')} 건네받은 잔을 비웁니다.`);
    return appendDrugLog(out, unresponsive
      ? `${lead ? `${lead} ` : ''}숨결이 한층 느리고 깊어집니다.`
      : `${lead} 얼마 지나지 않아 눈꺼풀이 무겁게 내려앉고, 몇 번이나 고개를 떨구기 시작합니다.`);
  }

  function applySleepDrug(...args) {
    return runPublicProcess('sleepDrugApply', applySleepDrugImpl, args);
  }

  function applyIntoxicationDrugImpl(state, customer, text = '') {
    const unresponsive = unresponsiveDrugTarget(state);
    const inBackRoomIncident = activeBackRoomIncident(state);
    const beforeLevel = getWife(state)?.intoxication?.level ?? 0;
    let out = updateWife(state, wife => {
      const intoxication = wife.intoxication || { level: 0, drinksToday: 0, peakToday: 0 };
      const primed = beforeLevel >= 65 ? 95 : 90;
      return {
        ...wife,
        intoxication: {
          ...intoxication,
          level: primed,
          peakToday: Math.max(intoxication.peakToday ?? 0, primed)
        }
      };
    });
    if (beforeLevel >= 65 && !unresponsive) {
      out = inBackRoomIncident ? passOutWhereSheStands(out) : original.passOutWife(out);
    }
    out = updateWife(out, wife => ({
      ...wife,
      intoxication: { ...(wife.intoxication || {}), level: 90 }
    }));
    const data = getData(out);
    setEffect(data, 'intoxicationFloor', {
      sourceGuestId: customer?.id || null,
      sourceGuestName: customer?.name || null,
      startedAtSlot: state.slot,
      endsAtSlot: state.slot + settings.intoxicationDurationMinutes,
      floor: 90,
      passedOutOnApply: beforeLevel >= 65 && !unresponsive
    });
    out = putData(out, data);
    const lead = text || (unresponsive ? '' : `${withParticle(wifeDisplayName(out), '은', '는')} 건네받은 잔을 비웁니다.`);
    return appendDrugLog(out, unresponsive
      ? `${lead ? `${lead} ` : ''}뺨과 목덜미에 술기운이 짙게 번지지만, 축 늘어진 몸은 좀처럼 반응하지 않습니다.`
      : beforeLevel >= 65
        ? `${lead} 남아 있던 술기운이 한꺼번에 치솟자 몸에서 힘이 빠지고 그대로 정신을 잃습니다.`
        : `${lead} 눈이 빠르게 풀리고, 몇 모금 마시지 않았는데도 몸을 가누지 못합니다.`);
  }

  function applyIntoxicationDrug(...args) {
    return runPublicProcess('intoxicationDrugApply', applyIntoxicationDrugImpl, args);
  }

  function applyConfusionDrugImpl(state, customer, text = '', options = {}) {
    const unresponsive = unresponsiveDrugTarget(state);
    const data = getData(state);
    const activeEffect = effectOf(data, 'confusion');
    const refreshing = Boolean(activeEffect && state.slot < activeEffect.endsAtSlot);
    const target = refreshing
      ? {
          id: activeEffect.mistakenForId,
          name: activeEffect.mistakenForName,
          playerScore: activeEffect.playerScore,
          patronScore: activeEffect.patronScore
        }
      : options.target || chooseConfusionTarget(state);
    const episodeId = `confusion:${state.day ?? 0}:${state.slot}:${customer?.id || 'unknown'}:${target.id}`;
    setEffect(data, 'confusion', refreshing ? {
      ...activeEffect,
      endsAtSlot: state.slot + 60
    } : {
        episodeId,
        sourceGuestId: customer?.id || null,
        sourceGuestName: customer?.name || null,
        startedAtSlot: state.slot,
        endsAtSlot: state.slot + 60,
        mistakenForId: target.id,
        mistakenForName: target.name,
        playerScore: target.playerScore,
        patronScore: target.patronScore,
        recoveryEvidence: null,
        subjectiveRollbacks: [],
        incidents: [],
        firstJournal: [],
        firstMoodRollbacks: [],
        rollbackSequence: 0
      });
    let out = putData(state, data);
    out = reportQualifiedVisit(out, required.getActiveScene(out));
    const lead = text || (unresponsive
      ? ''
      : refreshing
        ? `${withParticle(wifeDisplayName(out), '은', '는')} 잔을 다시 비웁니다.`
        : `${withParticle(wifeDisplayName(out), '은', '는')} 건네받은 잔을 비웁니다.`);
    if (refreshing) {
      if (unresponsive) {
        return appendDrugLog(
          out,
          `${lead ? `${lead} ` : ''}${withParticle(wifeDisplayName(out), '의', '의')} 감긴 눈꺼풀이 한 번 떨립니다. 그녀는 눈을 뜨지 않습니다.`
        );
      }
      return appendDrugLog(
        out,
        `${lead || `${withParticle(wifeDisplayName(out), '은', '는')} 잔을 다시 비웁니다.`} 그녀의 눈빛은 여전히 흐립니다.`
      );
    }
    return appendDrugLog(out, unresponsive
      ? `${lead ? `${lead} ` : ''}감긴 눈꺼풀이 가볍게 떨리고, 흐릿한 신음이 입술 사이로 새어 나옵니다.`
      : `${lead} 시선이 흐려지고, 눈앞의 얼굴이 ${target.name}의 얼굴처럼 겹쳐 보이기 시작합니다.`);
  }

  function applyConfusionDrug(...args) {
    return runPublicProcess('confusionDrugApply', applyConfusionDrugImpl, args);
  }

  function applyDrugImpl(state, customer, text = '') {
    const unresponsive = unresponsiveDrugTarget(state);
    let data = getData(state);
    const activeEffect = effectOf(data, 'aphrodisiac');
    const refreshing = Boolean(activeEffect && state.slot < activeEffect.endsAtSlot);
    if (refreshing) {
      const level = drugLevelAt(state, activeEffect);
      const falling = drugPhase(state, activeEffect) === 'falling';
      const endsAtSlot = state.slot + CONFIG.drugDurationMinutes;
      setEffect(data, 'aphrodisiac', {
        ...activeEffect,
        endsAtSlot,
        ...(falling ? { heldLevel: level } : {})
      });
      data.pendingDrug = null;
      let out = putData(state, data);
      out = updateWife(out, wife => ({
        ...wife,
        feelings: (wife.feelings || []).map(feeling => feeling.emotion === 'arousal_buzz'
          && feeling.source === `bad_guest_drug:${activeEffect.sourceGuestId}`
          && feeling.triggeredAtSlot === activeEffect.startedAtSlot
          ? { ...feeling, expiresAtSlot: endsAtSlot }
          : feeling)
      }));
      const lead = text || (unresponsive ? '' : `${withParticle(wifeDisplayName(out), '은', '는')} 잔을 다시 비웁니다.`);
      return appendDrugLog(out, unresponsive
        ? `${lead ? `${lead} ` : ''}달아오른 피부의 열기가 가시지 않습니다.`
        : `${lead} 몸에 오른 열기는 그대로 남아 있습니다.`);
    }
    setEffect(data, 'aphrodisiac', {
      episodeId: `aphrodisiac:${state.day ?? 1}:${state.slot}:${customer.id}`,
      sourceGuestId: customer.id,
      sourceGuestName: customer.name,
      startedAtSlot: state.slot,
      endsAtSlot: state.slot + CONFIG.drugDurationMinutes
    });
    data.pendingDrug = null;
    data.phaseNotices = {};
    let out = putData(state, data);
    out = updateWife(out, wife => ({
      ...wife,
      badGuestDrugArousal: 0,
      feelings: [
        ...(wife.feelings || []),
        {
          emotion: 'arousal_buzz',
          intensity: 35,
          source: `bad_guest_drug:${customer.id}`,
          triggeredAtSlot: state.slot,
          expiresAtSlot: state.slot + CONFIG.drugDurationMinutes,
          blurb: '낯선 열기가 목덜미와 가슴 안쪽에서 계속 번지고 있다'
        }
      ]
    }));
    const lead = text || (unresponsive ? '' : `${withParticle(wifeDisplayName(out), '은', '는')} 건네받은 잔을 비웁니다.`);
    return appendDrugLog(out, unresponsive
      ? `${lead ? `${lead} ` : ''}잠시 뒤 피부가 붉게 달아오르고 호흡이 가늘게 흐트러집니다.`
      : `${lead} 잠시 뒤 낯선 열기가 목덜미와 가슴 안쪽부터 천천히 번지기 시작합니다.`);
  }


  function applyDrug(...args) {
    return runPublicProcess('drugApply', applyDrugImpl, args);
  }

  function applyDrugByKind(state, customer, kind, text) {
    if (kind === 'sleep') return applySleepDrug(state, customer, text);
    if (kind === 'intoxication') return applyIntoxicationDrug(state, customer, text);
    if (kind === 'confusion') return applyConfusionDrug(state, customer, text);
    return applyDrug(state, customer, text);
  }

  function applyDrugToUnresponsiveTarget(state, customer, kind, task) {
    const attempted = appendDrugLog(
      state,
      unresponsiveDrugAttemptLead(kind, task, wifeDisplayName(state), customer.name)
    );
    return applyDrugByKind(attempted, customer, kind, '');
  }

  function wifeNoticesDrug(state, customer, trustInAsker, sample = true) {
    const wife = getWife(state);
    const attrs = effectiveAttributes(wife);
    const traits = new Set(wife?.latentTraits || []);
    let observer = attrs.wit ?? 50;
    observer -= intoxicationNoticePenalty(wife);
    observer -= Math.max(0, trustInAsker - 50) * 0.2;
    if (traits.has('cold_pragmatist')) observer += 20;
    if (traits.has('true_prude')) observer += 6;
    if (traits.has('breaks_under_pressure')) observer -= 6;
    if (traits.has('wary_of_drinks')) observer += 20;
    const concealment = 50 + (guestCunning(customer) - BASE_BAD_GUEST_CUNNING) * 0.4;
    const hasProtectiveAwareness = traits.has('wary_of_drinks') || traits.has('self_protective');
    return rollLinearOpposed(
      observer,
      concealment,
      confusionAdjustedDrugDefenseBase(state, customer, settings.checkBaseChances.wifeDrugNotice),
      settings.checkPointIncrements.wifeDrugNotice,
      0.05,
      hasProtectiveAwareness ? 0.95 : 0.90,
      sample
    );
  }

  function wifeRefusesDrug(state, customer, sample = true) {
    const wife = getWife(state);
    const attrs = effectiveAttributes(wife);
    const traits = new Set(wife?.latentTraits || []);
    let resistance = (attrs.wit ?? 50) * 0.3
      + (attrs.composure ?? 50) * 0.35
      + (attrs.confidence ?? 50) * 0.35;
    if (traits.has('self_protective')) resistance += 16;
    if (traits.has('true_prude')) resistance += 8;
    if (traits.has('breaks_under_pressure')) resistance -= 12;
    if (traits.has('latent_submissive')) resistance -= 7;
    const pressure = 50
      + (guestCunning(customer) - BASE_BAD_GUEST_CUNNING) * 0.4
      + ((customer.boldness ?? 78) - 78) * 0.35
      + ((customer.charm ?? 50) - 50) * 0.25;
    return rollLinearOpposed(
      resistance,
      pressure,
      confusionAdjustedDrugDefenseBase(state, customer, settings.checkBaseChances.wifeDrugRefusal),
      settings.checkPointIncrements.wifeDrugRefusal,
      0.05,
      0.95,
      sample
    );
  }

  function lurerIntoxicationFinishEligible(state, customer) {
    if (!customer?.id || badGuestPattern(customer).id !== 'lurer') return false;
    const effect = effectOf(readData(state), 'intoxicationFloor');
    if (!effect || !timedEffectActive(state, 'intoxicationFloor')) return false;
    if (String(effect.sourceGuestId) !== String(customer.id)
      || effect.passedOutOnApply
      || effect.passedOutOnFollowup
      || effect.followupAttemptedAtSlot != null) return false;
    if (state.slot - Number(effect.startedAtSlot ?? state.slot) < settings.lurerFinishDelayMinutes) return false;
    if (unresponsiveDrugTarget(state)) return false;
    const room = wifeLocation(state);
    const interaction = required.getActiveScene(state);
    const supportingAnotherBadGuest = (state.customers || []).some(other =>
      other?.id
      && String(other.id) !== String(customer.id)
      && isBadGuest(state, other)
      && ACTIVE_CUSTOMER_STATUSES.has(other.status)
      && customerLocation(state, other.id) === room
    );
    return Boolean(
      room
      && room !== 'taproom'
      && interaction?.customerId === customer.id
      && customerLocation(state, customer.id) === room
      && !playerObservesRoom(state, room)
      && !supportingAnotherBadGuest
    );
  }

  function resolveLurerIntoxicationFinishImpl(state, customer, sample = Math.random()) {
    if (!lurerIntoxicationFinishEligible(state, customer)) return state;
    const data = getData(state);
    const effect = effectOf(data, 'intoxicationFloor');
    setEffect(data, 'intoxicationFloor', { ...effect, followupAttemptedAtSlot: state.slot });
    let out = putData(state, data);
    const baseRefusalChance = Number(wifeRefusesDrug(out, customer, false).chance) || 0;
    const refusalChance = clamp(
      baseRefusalChance,
      settings.lurerFinishMinRefusal / 100,
      settings.lurerFinishMaxRefusal / 100
    );
    if (clamp(Number(sample), 0, 0.999999) < refusalChance) {
      out = updateWife(out, wife => ({
        ...wife,
        stats: { ...(wife.stats || {}), mood: clamp((wife.stats?.mood ?? 50) - 1) }
      }));
      return appendDrugLog(
        out,
        `${withParticle(wifeDisplayName(out), '\uC740', '\uB294')} ${withParticle(customer.name, '\uC774', '\uAC00')} \uC794\uC5D0 \uB0A8\uC740 \uC220\uC744 \uB9C8\uC800 \uBE44\uC6B0\uB77C\uBA70 \uB0B4\uBC00\uC790, \uC190\uC73C\uB85C \uC794\uC744 \uB9C9\uC544 \uC138\uC6C1\uB2C8\uB2E4. \u201C\uC774\uC81C \uADF8\uB9CC \uB9C8\uC2E4\uB798\uC694.\u201D`
      );
    }

    out = updateWife(out, wife => ({
      ...wife,
      intoxication: {
        ...(wife.intoxication || {}),
        level: 95,
        peakToday: Math.max(wife.intoxication?.peakToday ?? 0, 95)
      }
    }));
    out = original.passOutWife(out);
    const passedOutData = getData(out);
    const liveEffect = effectOf(passedOutData, 'intoxicationFloor');
    if (liveEffect) {
      setEffect(passedOutData, 'intoxicationFloor', {
        ...liveEffect,
        followupAttemptedAtSlot: state.slot,
        passedOutOnFollowup: true
      });
      out = putData(out, passedOutData);
    }
    return appendDrugLog(
      out,
      `${withParticle(customer.name, '\uC740', '\uB294')} \uC794\uC744 \uCE58\uC6B0\uB294 \uCC99\uD558\uBA70 \uB0A8\uC740 \uC220\uC744 \uB9C8\uC800 \uBE44\uC6B0\uB77C\uACE0 \uAD8C\uD569\uB2C8\uB2E4. ${withParticle(wifeDisplayName(out), '\uC740', '\uB294')} \uC794\uC744 \uBE44\uC6B4 \uB4A4 \uBAB8\uC744 \uAC00\uB204\uC9C0 \uBABB\uD558\uACE0 \uADF8\uB300\uB85C \uC815\uC2E0\uC744 \uC783\uC2B5\uB2C8\uB2E4.`
    );
  }

  function resolveLurerIntoxicationFinish(...args) {
    return runPublicProcess('lurerIntoxicationFinish', resolveLurerIntoxicationFinishImpl, args);
  }

  function groupDrugNoticeCheck(state, customer, trustInAsker, sample = true) {
    const wife = getWife(state);
    const attrs = effectiveAttributes(wife);
    const traits = new Set(wife?.latentTraits || []);
    let observer = attrs.wit ?? 50;
    observer -= intoxicationNoticePenalty(wife);
    observer -= Math.max(0, trustInAsker - 50) * 0.2;
    if (traits.has('cold_pragmatist')) observer += 20;
    if (traits.has('true_prude')) observer += 6;
    if (traits.has('breaks_under_pressure')) observer -= 6;
    if (traits.has('wary_of_drinks')) observer += 20;
    const concealment = 50 + (guestCunning(customer) - BASE_BAD_GUEST_CUNNING) * 0.4;
    return rollGroupOpposed(
      observer,
      concealment,
      settings.checkBaseChances.groupDrugNotice,
      settings.checkPointIncrements.groupDrugNotice,
      sample
    );
  }

  function groupDrugPressureCheck(state, customer, sample = true) {
    const wife = getWife(state);
    const attrs = effectiveAttributes(wife);
    const traits = new Set(wife?.latentTraits || []);
    let resistance = ((attrs.wit ?? 50) + (attrs.composure ?? 50) + (attrs.confidence ?? 50)) / 3;
    if (traits.has('self_protective')) resistance += 16;
    if (traits.has('true_prude')) resistance += 8;
    if (traits.has('breaks_under_pressure')) resistance -= 12;
    if (traits.has('latent_submissive')) resistance -= 7;
    const pressure = 50
      + (guestCunning(customer) - BASE_BAD_GUEST_CUNNING) * 0.4
      + ((customer.boldness ?? 78) - 78) * 0.35
      + ((customer.charm ?? 50) - 50) * 0.25;
    return rollGroupOpposed(
      resistance,
      pressure,
      settings.checkBaseChances.groupPressureResistance,
      settings.checkPointIncrements.groupPressureResistance,
      sample
    );
  }

  function groupDrugStrengthCheck(state, customer, sample = true) {
    const wife = getWife(state);
    const wifeAttrs = effectiveAttributes(wife);
    const patronAttrs = effectiveAttributes(customer);
    const resistance = ((wifeAttrs.strength ?? 50) + (wifeAttrs.deftness ?? 50)) / 2;
    const force = ((patronAttrs.strength ?? 50) + (patronAttrs.deftness ?? 50)) / 2;
    return rollGroupOpposed(
      resistance,
      force,
      settings.checkBaseChances.groupStrengthResistance,
      settings.checkPointIncrements.groupStrengthResistance,
      sample
    );
  }

  function husbandNoticesDrug(state, customer, sample = true) {
    const player = state.player || {};
    const attrs = effectiveAttributes(player);
    const personality = player.personality || {};
    const energy = player.stats?.energy ?? 50;
    const observer = (attrs.wit ?? 50) * 0.65
      + (attrs.composure ?? 50) * 0.25
      + (personality.cunning ?? 50) * 0.1
      + (energy - 50) * 0.2;
    const concealment = 50 + (guestCunning(customer) - BASE_BAD_GUEST_CUNNING) * 0.5;
    return rollLinearOpposed(
      observer,
      concealment,
      settings.checkBaseChances.husbandNotice,
      settings.checkPointIncrements.husbandNotice,
      0,
      1,
      sample
    );
  }

  function resolveWifeDrugAttempt(state, customer, source, drugKind = 'aphrodisiac') {
    const unresponsive = unresponsiveDrugTarget(state);
    if (unresponsive) {
      return applyDrugToUnresponsiveTarget(state, customer, drugKind, unresponsive);
    }
    const interaction = required.getActiveScene(state);
    const trust = interaction?.customerId === customer.id ? interaction.elenaComfort ?? 35 : 25;
    const notice = wifeNoticesDrug(state, customer, trust);
    const wifeName = wifeDisplayName(state);
    const playerMistaken = confusionPlayerDeceptionApplies(state, customer);
    const loverMistaken = confusionLoverTargetContext(state, customer);
    const attemptLead = outcome => playerMistaken
      ? confusionPlayerDrugAttemptLead(state, drugKind, outcome, wifeName, customer.name)
      : loverMistaken
        ? confusionLoverDrugAttemptLead(state, drugKind, outcome, wifeName, customer)
        : drugAttemptLead(state, drugKind, outcome, wifeName, customer.name);
    if (!notice.attackerWins) {
      return applyDrugByKind(
        state,
        customer,
        drugKind,
        attemptLead('unnoticed')
      );
    }

    const refusal = wifeRefusesDrug(state, customer);
    if (refusal.attackerWins) {
      let out = updateWife(state, wife => ({
        ...wife,
        stats: { ...(wife.stats || {}), mood: clamp((wife.stats?.mood ?? 50) - 2) }
      }));
      return appendDrugLog(
        out,
        attemptLead('refused')
      );
    }

    return applyDrugByKind(
      state,
      customer,
      drugKind,
      attemptLead('pressured')
    );
  }

  function resolveWealthyPartyDrugAttempt(state, customer) {
    const wifeName = wifeDisplayName(state);
    const unresponsive = unresponsiveDrugTarget(state);
    if (unresponsive) {
      return applyDrugToUnresponsiveTarget(state, customer, 'aphrodisiac', unresponsive);
    }
    const interaction = required.getActiveScene(state);
    const trust = interaction?.customerId === customer.id ? interaction.elenaComfort ?? 35 : 25;
    const notice = groupDrugNoticeCheck(state, customer, trust);
    const pressure = groupDrugPressureCheck(state, customer);
    const strength = groupDrugStrengthCheck(state, customer);
    const resisted = notice.attackerWins && pressure.attackerWins && strength.attackerWins;

    if (resisted) {
      const data = getData(state);
      data.pendingDrug = null;
      const party = data.wealthyParty;
      const exhausted = party?.active
        && (party.drugAttempts || 0) >= Math.min(CONFIG.wealthyPartySize, party.memberIds?.length || CONFIG.wealthyPartySize);
      if (exhausted) {
        data.wealthyParty = {
          ...party,
          noMoreDrugAttempts: true,
          noMoreDrinkRequests: true
        };
      }
      let out = putData(state, data);
      out = updateWife(out, wife => ({
        ...wife,
        stats: { ...(wife.stats || {}), mood: clamp((wife.stats?.mood ?? 50) - 2) }
      }));
      return appendDrugLog(
        out,
        exhausted
          ? `${withParticle(wifeName, '은', '는')} 잔 밑바닥의 가루를 알아보고 손을 멈춥니다. 마지막 사내까지 잔을 밀어붙이고 손목을 붙잡지만, 끝까지 버텨 탁자 위에 쏟아 버립니다. 다섯 번 모두 뜻대로 되지 않자 사내들은 더는 술을 가져오라고 부르지 않습니다. “이런 건 마시지 않아요.”`
          : `${withParticle(wifeName, '은', '는')} 잔 밑바닥의 가루를 알아보고 손을 멈춥니다. 사내들이 대수롭지 않다며 잔을 밀어붙이고 손목까지 붙잡지만, 끝까지 버텨 잔을 탁자 위에 쏟아 버립니다. “이런 건 마시지 않아요.”`
      );
    }

    if (!notice.attackerWins) {
      return applyDrug(
        state,
        customer,
        `${withParticle(wifeName, '은', '는')} 사내들이 건넨 잔의 달큰한 낯선 향과 밑바닥의 고운 가루를 알아채지 못한 채 마십니다.`
      );
    }
    if (!pressure.attackerWins) {
      return applyDrug(
        state,
        customer,
        `${withParticle(wifeName, '은', '는')} 잔의 낯선 침전물을 알아보고 멈추지만, 다섯 사내가 웃으며 대수롭지 않은 것이라고 몰아붙입니다. 이어지는 압박을 끝내 떨쳐내지 못하고 잔을 비웁니다.`
      );
    }
    return applyDrug(
      state,
      customer,
      `${withParticle(wifeName, '은', '는')} 잔 밑바닥의 낯선 흔적을 알아보고 마시지 않겠다고 버팁니다. 그러나 사내들이 손목과 잔을 붙들어 저항을 누르고, 끝내 잔을 비우게 합니다.`
    );
  }

  function beginDrugAttemptImpl(state, customer, source, options = {}) {
    const drugKind = options.drugKind || patternDrugKind(badGuestPattern(customer));
    const room = wifeLocation(state);
    const unresponsive = unresponsiveDrugTarget(state);
    if (unresponsive) {
      return applyDrugToUnresponsiveTarget(state, customer, drugKind, unresponsive);
    }
    const husbandPresent = room != null && playerObservesRoom(state, room);
    if (husbandPresent) {
      const noticed = husbandNoticesDrug(state, customer);
      if (noticed.attackerWins) {
        const data = getData(state);
        const resolutionMode = options.wealthyParty ? 'wealthy_party_three_checks' : 'normal';
        data.pendingDrug = {
          customerId: customer.id,
          source,
          roomId: room,
          resolutionMode,
          drugKind
        };
        let out = putData(state, data);
        const condition = unresponsive === 'passed_out' ? '정신을 잃은' : '잠든';
        out = appendLog(
          out,
          unresponsive
            ? `${withParticle(customer.name, '이', '가')} ${condition} ${wifeDisplayName(state)}의 턱을 받치고 작은 병을 입술 쪽으로 가져갑니다. 당신은 그가 무언가를 흘려 넣기 전에 수상한 움직임을 알아챘습니다.`
            : `${withParticle(customer.name, '이', '가')} ${wifeDisplayName(state)}의 잔을 가리는 손놀림 사이로 고운 가루를 털어 넣습니다. 당신은 그가 손을 거두기 전에 수상한 움직임을 알아챘습니다.`
        );
        return {
          ...out,
          pendingEvent: {
            type: 'bad_guest_drug_husband',
            customerId: customer.id,
            customerName: customer.name,
            source,
            roomId: room,
            resolutionMode,
            drugKind,
            text: unresponsive
              ? `${withParticle(customer.name, '이', '가')} ${condition} ${wifeDisplayName(state)}의 입술에 작은 병을 기울입니다. 아직 액체는 닿지 않았습니다.`
              : `${withParticle(customer.name, '이', '가')} ${wifeDisplayName(state)}의 잔에 고운 가루를 털어 넣습니다. 손은 아직 잔 위에 있습니다.`,
            choices: [
              { id: 'bad_guest_stop_drug_eject', label: '막고 손님을 쫓아내기', description: `${withParticle(wifeDisplayName(state), '을', '를')} 보호하고 이 손님을 즉시 내보냅니다.` },
              { id: 'bad_guest_stop_drug_keep', label: '막고 손님을 자리에 두기', description: '수상한 시도는 막되 손님에게 경고하고 현재 자리에 남겨 둡니다.' },
              {
                id: 'bad_guest_allow_drug',
                label: '그대로 두기',
                description: unresponsive
                  ? '그가 하는 일을 막지 않습니다.'
                  : options.wealthyParty
                    ? `${withParticle(wifeDisplayName(state), '이', '가')} 깨어나기 전까지 손님을 막지 않습니다.`
                    : `${withParticle(wifeDisplayName(state), '이', '가')} 잔을 받을 때까지 지켜봅니다.`
              }
            ]
          }
        };
      }
    }
    return options.wealthyParty
      ? resolveWealthyPartyDrugAttempt(state, customer)
      : resolveWifeDrugAttempt(state, customer, source, drugKind);
  }


  function beginDrugAttempt(...args) {
    return runPublicProcess('drugAttempt', beginDrugAttemptImpl, args);
  }

  function aggressiveDeceptionRequestId(state, customer) {
    const visit = customer?.arrivedAtSlot ?? customer?.visitCount ?? customer?.visits ?? 0;
    return `badguest:aggressive-deception:${state.day ?? 0}:${customer?.id || 'missing'}:${visit}`;
  }

  function aggressiveDeceptionEligibility(state, customer, interaction = required.getActiveScene(state)) {
    const requestId = aggressiveDeceptionRequestId(state, customer);
    if (!customer || !isCanonicalBadGuestActor(state, customer)) {
      return { status: 'ineligible', reason: 'bad_guest_actor_required', requestId };
    }
    if (!ACTIVE_CUSTOMER_STATUSES.has(customer.status)) {
      return { status: 'ineligible', reason: 'customer_inactive', requestId };
    }
    if (customer.servedBy !== 'wife' || Number(customer.roundsOrdered || 0) < 1) {
      return { status: 'ineligible', reason: 'service_required', requestId };
    }
    const data = readData(state);
    if (data.aggressiveDeception?.requests?.[requestId]) {
      return { status: 'ineligible', reason: 'visit_consumed', requestId };
    }
    if (data.aggressiveDeception?.active || data.drinkingGame?.active || data.recoveryRest?.active
      || equipmentOf(data, 'restraint')?.active || data.doorLock?.active) {
      return { status: 'deferred', reason: 'badguest_flow_active', requestId };
    }
    if (state.pendingEvent) return { status: 'deferred', reason: 'pending_event', requestId };
    if (!interaction || interaction.customerId !== customer.id
      || !AGGRESSIVE_DECEPTION_STAGES.has(interaction.stage)) {
      return { status: 'ineligible', reason: 'scene_ineligible', requestId };
    }
    const room = wifeLocation(state);
    if (!room || customerLocation(state, customer.id) !== room) {
      return { status: 'deferred', reason: 'customer_not_with_target', requestId };
    }
    if (playerLocation(state) !== room) {
      return { status: 'deferred', reason: 'player_not_present', requestId };
    }
    return { status: 'available', reason: 'ready', requestId, customerId: customer.id, targetCharacterId: getWifeId(state) };
  }

  function aggressiveDeceptionClaim(customer, roll = Math.random()) {
    return Math.round(clamp(20 + guestCunning(customer) * 0.55 + clamp(roll, 0, 1) * 35, 20, 120) / 5) * 5;
  }

  function wifeNoticesAggressiveDeception(state, customer, sample = true) {
    const attrs = effectiveAttributes(getWife(state));
    const observer = ((attrs.wit ?? 50) + (attrs.composure ?? 50)) / 2;
    return rollLinearOpposed(observer, guestCunning(customer), 42, 0.65, 0.05, 0.90, sample);
  }

  function playerNoticesAggressiveDeception(state, customer, sample = Math.random()) {
    const attrs = effectiveAttributes(state.player || {});
    const observation = (attrs.wit ?? 50) * 0.55
      + (attrs.caution ?? 50) * 0.25
      + (attrs.cunning ?? state.player?.personality?.cunning ?? 50) * 0.20;
    const customerAttrs = effectiveAttributes(customer);
    const method = customer.tacticStyle || customer.method || customer.approach;
    const methodBonus = method === 'transactional' ? 8
      : method === 'smooth_charmer' ? 6
        : method === 'warm_builder' || method === 'drink_pusher' ? -8
          : method === 'lap_grabber' ? -4 : 0;
    const concealment = clamp((customerAttrs.charm ?? customer.charm ?? 50) * 0.55
      + (customer.boldness ?? customerAttrs.boldness ?? 50) * 0.35
      + (customer.intent === 'predatory' ? 12 : 0)
      + methodBonus + ((customerAttrs.wit ?? 50) - 50) * 0.30, 0, 100);
    const chance = clamp(50 + (observation - concealment) * 0.65 + 3 * 0.25, 10, 90);
    return sample * 100 < chance;
  }

  function aggressiveDeceptionChoices(state, record) {
    return [
      ...(getHerDebtDebt()
        ? [{ id: 'bad_guest_aggressive_cover', label: '가게에서 대신 물어주기', description: '당신이 손님과 계산을 끝내고, 그녀에게는 나중에 갚으라고 말합니다.' }]
        : []),
      { id: 'bad_guest_aggressive_leave', label: '그녀에게 맡기기', description: '그녀가 손님의 요구에 직접 답하게 합니다.' },
      ...(record.playerSpotted
        ? [{ id: 'bad_guest_aggressive_call_out', label: '거짓말을 지적하고 막는다', description: '당신이 직접 본 흔적을 짚으며 손님의 요구를 막습니다.' }]
        : [])
    ];
  }

  function aggressiveDeceptionClaimLine(state, record, customerName) {
    return record.claimType === 'spoiled_supper'
      ? `${withParticle(customerName, '은', '는')} 엎어진 식사를 가리키며 ${withParticle(wifeDisplayName(state), '이', '가')} 서빙하다 쏟았다고 주장합니다.`
      : `${withParticle(customerName, '은', '는')} 찢어진 가방 끈을 들고 ${wifeDisplayName(state)}의 쟁반에 걸렸다고 주장합니다.`;
  }

  function aggressiveDeceptionClueLine(record) {
    return record.claimType === 'spoiled_supper'
      ? '당신은 그가 손으로 접시를 밀어 엎는 것을 보았습니다.'
      : '당신은 그가 가방 끈을 일부러 당기는 것을 보았습니다.';
  }

  function aggressiveDeceptionEvent(state, record) {
    const customer = state.customers?.find(entry => entry.id === record.customerId);
    const customerName = customer?.name || record.customerName || '그 손님';
    return {
      type: 'bad_guest_aggressive_deception',
      requestId: record.requestId,
      customerId: record.customerId,
      customerName,
      claimGold: record.claimGold,
      text: `${aggressiveDeceptionClaimLine(state, record, customerName)} ${record.claimGold}골드를 요구하다가 “돈이 없으면 이 잔을 비워요.”라고 덧붙입니다.${record.playerSpotted ? `\n\n${aggressiveDeceptionClueLine(record)}` : ''}`,
      choices: aggressiveDeceptionChoices(state, record)
    };
  }

  function writeAggressiveDeceptionRecord(state, record, active = record) {
    const data = getData(state);
    data.aggressiveDeception = {
      active,
      requests: { ...(data.aggressiveDeception?.requests || {}), [record.requestId]: record }
    };
    return putData(state, data);
  }

  function finishAggressiveDeception(state, requestId, status, reason) {
    const data = getData(state);
    const current = data.aggressiveDeception?.requests?.[requestId]
      || (data.aggressiveDeception?.active?.requestId === requestId ? data.aggressiveDeception.active : null);
    if (!current) return state;
    const record = { ...current, status, reason, completedAtSlot: state.slot };
    data.aggressiveDeception = {
      active: data.aggressiveDeception?.active?.requestId === requestId ? null : data.aggressiveDeception?.active || null,
      requests: { ...(data.aggressiveDeception?.requests || {}), [requestId]: record }
    };
    return putData(state, data);
  }

  function beginAggressiveDeceptionImpl(state, customer, options = {}) {
    const eligibility = aggressiveDeceptionEligibility(state, customer, options.interaction);
    if (eligibility.status !== 'available') return state;
    const caught = options.caught ?? wifeNoticesAggressiveDeception(state, customer, options.sample !== false).attackerWins;
    const playerSpotted = !caught && playerLocation(state) === wifeLocation(state)
      && (options.playerSpotted ?? playerNoticesAggressiveDeception(state, customer));
    const claimGold = options.claimGold ?? aggressiveDeceptionClaim(customer, options.claimRoll);
    const record = {
      requestId: eligibility.requestId,
      customerId: customer.id,
      customerName: customer.name,
      targetCharacterId: getWifeId(state),
      roomId: wifeLocation(state),
      claimType: String(customer.order || '').includes('food') ? 'spoiled_supper' : 'damaged_satchel',
      claimGold,
      caught,
      playerSpotted,
      status: caught ? 'caught' : 'awaiting_choice',
      startedAtSlot: state.slot
    };
    let out = writeAggressiveDeceptionRecord(state, record);
    if (caught) {
      out = finishAggressiveDeception(out, record.requestId, 'detected', 'wife_caught_lie');
      return appendLog(out, record.claimType === 'spoiled_supper'
        ? `${aggressiveDeceptionClaimLine(out, record, customer.name)} ${withParticle(wifeDisplayName(out), '은', '는')} 그가 접시를 민 것을 짚습니다. 그는 더 따지지 못하고 물러납니다.`
        : `${aggressiveDeceptionClaimLine(out, record, customer.name)} ${withParticle(wifeDisplayName(out), '은', '는')} 그가 직접 끈을 잡아당긴 흔적을 짚습니다. 그는 더 따지지 못하고 가방을 거둡니다.`);
    }
    out = appendLog(out, aggressiveDeceptionClaimLine(out, record, customer.name));
    return { ...out, pendingEvent: aggressiveDeceptionEvent(out, record) };
  }

  function beginAggressiveDeception(...args) {
    return runPublicProcess('aggressiveDeceptionStart', beginAggressiveDeceptionImpl, args);
  }

  function resolveAggressiveDeceptionImpl(state, choiceId) {
    const record = readData(state).aggressiveDeception?.active;
    if (!record || state.pendingEvent?.type !== 'bad_guest_aggressive_deception'
      || state.pendingEvent.requestId !== record.requestId) return state;
    const customer = state.customers?.find(entry => entry.id === record.customerId);
    let out = { ...state, pendingEvent: undefined };
    if (!customer || !ACTIVE_CUSTOMER_STATUSES.has(customer.status)
      || customerLocation(state, customer.id) !== wifeLocation(state)) {
      out = finishAggressiveDeception(out, record.requestId, 'interrupted', 'actor_unavailable');
      return out;
    }
    if (choiceId === 'bad_guest_aggressive_call_out' && record.playerSpotted) {
      out = finishAggressiveDeception(out, record.requestId, 'detected', 'player_caught_lie');
      return appendLog(out, record.claimType === 'spoiled_supper'
        ? `당신은 ${customer.name}이 접시를 밀어 엎는 것을 봤다고 말합니다. 그는 더 따지지 못하고 물러납니다.`
        : `당신은 ${customer.name}이 가방 끈을 잡아당기는 것을 봤다고 말합니다. 그는 손을 멈추고 가방을 거둡니다.`);
    }
    if (choiceId === 'bad_guest_aggressive_cover') {
      const service = getHerDebtDebt();
      if (!service) return { ...state, pendingEvent: aggressiveDeceptionEvent(state, record) };
      let debtResult;
      try {
        debtResult = service.add(out, {
          transactionId: `${record.requestId}:cover`,
          source: 'badguest',
          amount: record.claimGold,
          kind: 'badguest_claim_cover',
          incidentId: record.requestId,
          actor: { kind: 'patron', id: customer.id, name: customer.name },
          note: '나쁜 손님의 꾸며 낸 손해 요구를 대신 지급',
          metadata: { customerId: customer.id, claimGold: record.claimGold }
        });
      } catch {
        return { ...state, pendingEvent: aggressiveDeceptionEvent(state, record) };
      }
      if (!debtResult?.state || !['applied', 'duplicate'].includes(debtResult.status)) {
        return { ...state, pendingEvent: aggressiveDeceptionEvent(state, record) };
      }
      out = debtResult.state;
      const availableGold = Math.max(0, Math.floor(Number(out.economy?.gold) || 0));
      const cashPaid = Math.min(availableGold, record.claimGold);
      out = {
        ...out,
        economy: {
          ...(out.economy || {}),
          gold: availableGold - cashPaid,
          debt: Math.max(0, Number(out.economy?.debt) || 0) + record.claimGold - cashPaid
        },
        customers: (out.customers || []).map(entry => entry.id === customer.id
          ? { ...entry, walletGold: Math.max(0, Number(entry.walletGold) || 0) + record.claimGold } : entry)
      };
      out = finishAggressiveDeception(out, record.requestId, 'covered', 'player_covered_claim');
      return appendLog(out, `당신이 ${customer.name}에게 ${record.claimGold}골드를 건네자 ${withParticle(wifeDisplayName(out), '은', '는')} 잠시 말을 멈춥니다. “대신 내준 돈은 꼭 갚을게요.”`);
    }
    if (choiceId === 'bad_guest_aggressive_leave') {
      const purse = Math.max(0, Math.floor(Number(getWife(out)?.purse) || 0));
      if (purse >= record.claimGold) {
        out = updateWife(out, wife => ({ ...wife, purse: purse - record.claimGold }));
        out = { ...out, customers: (out.customers || []).map(entry => entry.id === customer.id
          ? { ...entry, walletGold: Math.max(0, Number(entry.walletGold) || 0) + record.claimGold } : entry) };
        out = finishAggressiveDeception(out, record.requestId, 'paid', 'wife_paid_claim');
        return appendLog(out, `${withParticle(wifeDisplayName(out), '은', '는')} 돈주머니를 열어 동전을 세어 ${customer.name}에게 건넵니다. 그는 돈을 챙기고 물러섭니다.`);
      }
      out = appendLog(out, `${withParticle(wifeDisplayName(out), '은', '는')} 돈주머니를 열어 보지만 모자랍니다. ${withParticle(customer.name, '이', '가')} 내민 잔을 받아 비웁니다.`);
      out = applyDrug(out, customer, '');
      return finishAggressiveDeception(out, record.requestId, 'drugged', 'drink_consumed');
    }
    return { ...state, pendingEvent: aggressiveDeceptionEvent(state, record) };
  }

  function resolveAggressiveDeception(...args) {
    return runPublicProcess('aggressiveDeceptionResolve', resolveAggressiveDeceptionImpl, args);
  }

  function privateLureCandidates(state, customer) {
    if (!customer) return [];
    const stage = required.getActiveScene(state)?.stage || 'chatting';
    const rooms = original.privateRoomCandidates(state, customer.id, stage)
      .filter(entry => state.locations?.[entry.place?.room] && Number.isFinite(entry.score))
      .map(entry => ({ roomId: entry.place.room, score: entry.score }));
    const bathroom = state.locations?.bathroom;
    const patronRecord = state.patronRecords?.find(entry => entry.name === customer.name);
    if (bathroom && customer.privyAtSlot == null && (patronRecord?.visitCount ?? 0) < 2
      && !bathroom.meta?.privatePatron && !bathroom.meta?.party
      && playerLocation(state) !== 'bathroom'
      && (bathroom.occupants || []).every(id => id === customer.id || id === getWifeId(state))) {
      // The original bathroom guidance is a separate event, outside the private-room list.
      rooms.push({ roomId: 'bathroom', score: (rooms[0]?.score ?? 2) - 0.4 });
    }
    return rooms;
  }

  function choosePrivateLureRoom(state, customer) {
    const rooms = privateLureCandidates(state, customer);
    if (!rooms.length) return null;
    const best = Math.max(...rooms.map(entry => entry.score));
    const weights = rooms.map(entry => Math.exp((entry.score - best) * 2));
    let roll = Math.random() * weights.reduce((sum, weight) => sum + weight, 0);
    for (let index = 0; index < rooms.length; index++) {
      roll -= weights[index];
      if (roll < 0) return rooms[index].roomId;
    }
    return rooms.at(-1).roomId;
  }

  function privateLurePlace(state, roomId) {
    if (!roomId) return '뒷방';
    if (roomId === 'back_room') return '뒷방';
    if (roomId === 'bathroom') return '욕실';
    if (roomId === 'elena_room') return '그녀의 방';
    if (roomId === 'bedroom') return '침실';
    const renter = roomId === 'upstairs_hall' ? state.tavern?.tonightRenter
      : roomId === 'upstairs_room_2' ? state.tavern?.tonightRenter2 : null;
    const guest = state.customers?.find(entry => entry.id === renter?.customerId && entry.status !== 'gone');
    return guest ? `${guest.name}의 방` : '위층 빈방';
  }

  function privateLureRequest(roomId) {
    if (roomId === 'bathroom') return '“변소가 어디요? 문 앞까지 좀 안내해 주겠소?”';
    if (roomId === 'back_room') return '“홀은 시끄럽군. 잠깐 조용한 데서 얘기하겠소?”';
    return '“위층에서 잠깐 할 얘기가 있소. 같이 가 주겠소?”';
  }

  function privateLureDirection(state, roomId) {
    const place = privateLurePlace(state, roomId);
    return `${place}${roomId === 'bathroom' || roomId === 'bedroom' ? '로' : '으로'}`;
  }

  function canAttemptBackRoomPretext(state, customer) {
    if (!customer || state.pendingEvent) return false;
    if (!isBadGuest(state, customer) || !ACTIVE_CUSTOMER_STATUSES.has(customer.status)) return false;
    if (wifeLocation(state) !== 'taproom' || customerLocation(state, customer.id) !== 'taproom') return false;
    if (!privateLureCandidates(state, customer).length) return false;
    const scene = required.getActiveScene(state);
    if (scene?.customerId === customer.id && scene.badGuestBackRoomPretextTried) return false;
    const data = readData(state);
    if (data.wealthyParty?.active || equipmentOf(data, 'restraint')?.active || data.doorLock?.active) return false;
    return true;
  }

  function wifeNoticesBackRoomPretext(state, customer, trustInAsker, sample = true) {
    const wife = getWife(state);
    const attrs = effectiveAttributes(wife);
    const traits = new Set(wife?.latentTraits || []);
    let observer = attrs.wit ?? 50;
    observer -= intoxicationNoticePenalty(wife);
    observer -= Math.max(0, trustInAsker - 50) * 0.2;
    if (traits.has('cold_pragmatist')) observer += 20;
    if (traits.has('true_prude')) observer += 6;
    if (traits.has('breaks_under_pressure')) observer -= 6;
    const concealment = 50 + (guestCunning(customer) - BASE_BAD_GUEST_CUNNING) * 0.4;
    const hasProtectiveAwareness = traits.has('wary_of_drinks') || traits.has('self_protective');
    return rollLinearOpposed(
      observer,
      concealment,
      confusionAdjustedPlayerDefenseBase(state, customer, settings.checkBaseChances.wifeBackRoomNotice),
      settings.checkPointIncrements.wifeBackRoomNotice,
      0.05,
      hasProtectiveAwareness ? 0.95 : 0.90,
      sample
    );
  }

  function wifeRefusesBackRoomPretext(state, customer, sample = true) {
    const wife = getWife(state);
    const attrs = effectiveAttributes(wife);
    const traits = new Set(wife?.latentTraits || []);
    let resistance = (attrs.wit ?? 50) * 0.3
      + (attrs.composure ?? 50) * 0.35
      + (attrs.confidence ?? 50) * 0.35;
    if (traits.has('self_protective')) resistance += 16;
    if (traits.has('true_prude')) resistance += 8;
    if (traits.has('breaks_under_pressure')) resistance -= 12;
    if (traits.has('latent_submissive')) resistance -= 7;
    const pressure = 50
      + (guestCunning(customer) - BASE_BAD_GUEST_CUNNING) * 0.4
      + ((customer.boldness ?? 78) - 78) * 0.35
      + ((customer.charm ?? 50) - 50) * 0.25;
    return rollLinearOpposed(
      resistance,
      pressure,
      confusionAdjustedPlayerDefenseBase(state, customer, settings.checkBaseChances.wifeBackRoomRefusal),
      settings.checkPointIncrements.wifeBackRoomRefusal,
      0.05,
      0.95,
      sample
    );
  }

  function husbandNoticesBackRoomPretext(state, customer, sample = true) {
    // The same neutral 50% concealment contest used by the drug sleight of hand.
    return husbandNoticesDrug(state, customer, sample);
  }

  function refuseBackRoomPretext(state, customer, roomId) {
    const wifeName = wifeDisplayName(state);
    const scene = required.getActiveScene(state);
    let out = state;
    if (scene?.customerId === customer.id) {
      out = {
        ...out,
        activeScene: {
          ...(out.activeScene || {}),
          patron: {
            ...scene,
            hasBeenRefused: true,
            lastResponse: 'refuse',
            stalled: (scene.stalled || 0) + 1,
            badGuestBackRoomPretextTried: true
          }
        }
      };
    }
    const mistakenVoice = storyVoice(state);
    const mistakenReply = mistakenVoice === 'pippa' ? '“무슨 얘긴데? 여기서 해.”'
      : mistakenVoice === 'mara' ? '“할 얘기가 있으면 여기서 해.”'
        : mistakenVoice === 'elena' ? '“할 말이 있으면 여기서 해요.”'
          : '“할 얘기가 있으면 여기서 해.”';
    return appendFlirtLog(out, confusionPlayerDeceptionApplies(state, customer)
      ? `${withParticle(wifeName, '은', '는')} ${withParticle(customer.name, '을', '를')} 당신으로 알고 따라가다가 그의 낯선 말투에 멈춥니다. ${mistakenReply}`
      : roomId === 'bathroom'
        ? `${withParticle(customer.name, '은', '는')} ${privateLureRequest(roomId)} ${withParticle(wifeName, '은', '는')} 그가 홀을 훑는 것을 보고 계단 옆 문을 가리킵니다. “저쪽이에요.”`
        : `${withParticle(customer.name, '은', '는')} ${privateLureRequest(roomId)} ${withParticle(wifeName, '은', '는')} 그가 홀을 훑는 것을 보고 멈춥니다. “여기서 하세요.”`);
  }

  function enterBackRoomConversationImpl(state, customer, source, resolution = 'unnoticed', selectedRoomId) {
    if (!canAttemptBackRoomPretext(state, customer)) return state;
    const roomId = selectedRoomId || choosePrivateLureRoom(state, customer);
    if (!privateLureCandidates(state, customer).some(entry => entry.roomId === roomId)) return state;
    const wifeName = wifeDisplayName(state);
    const returnAtSlot = state.slot + CONFIG.backRoomConversationMinutes;
    let out = state;
    let scene = required.getActiveScene(out);
    if (!scene || scene.customerId !== customer.id) {
      const logStart = (out.log || []).length;
      out = wrappedStartPatronInteraction(
        out,
        customer.id,
        undefined,
        `${withParticle(customer.name, '은', '는')} 홀의 소음에 말을 묻히게 하며 ${wifeName}에게 가까이 붙습니다. ${privateLureRequest(roomId)}`,
        undefined
      );
      out = markLogsSinceAsTone(out, logStart, 'flirt');
      scene = required.getActiveScene(out);
    }
    if (!scene || scene.customerId !== customer.id) return state;

    if (roomId === 'bathroom') {
      // Original bathroom guidance moves both people to the door before private entry.
      out = original.moveWife(out, roomId, returnAtSlot, { skipModestyCheck: true });
      out = putOccupantInRoom(out, customer.id, roomId);
      out = {
        ...out,
        customers: (out.customers || []).map(entry => entry.id === customer.id
          ? { ...entry, privyAtSlot: out.slot }
          : entry)
      };
    }
    const entered = original.enterPrivateRoom(out, roomId, {
      returnSlots: CONFIG.backRoomConversationMinutes,
      isolate: true
    });
    if (entered.locations?.[roomId]?.meta?.privatePatron?.customerId !== customer.id) return state;
    out = entered;
    out = updateWife(out, wife => ({
      ...wife,
      currentTask: 'talking',
      taskTarget: customer.id,
      busyUntilSlot: returnAtSlot,
      locationUntilSlot: returnAtSlot
    }));
    out = {
      ...out,
      customers: (out.customers || []).map(entry => entry.id === customer.id
        ? { ...entry, status: 'drinking' }
        : entry),
      activeScene: {
        ...(out.activeScene || {}),
        patron: {
          ...required.getActiveScene(out),
          stage: 'chatting',
          stageFrom: scene.stage,
          stageBy: 'bad_guest_back_room_pretext',
          ticksAtStage: 0,
          ticksElapsed: 0,
          stalled: 0,
          hasBeenRefused: false,
          playerEngaged: false,
          crowdPatronIds: [],
          joinedPatronIds: [],
          joinedPatronSlots: {},
          badGuestBackRoomPretext: true,
          badGuestBackRoomPretextTried: true
        }
      }
    };
    let impostorBlindfoldApplied = false;
    if (badGuestPattern(customer).id === 'impostor'
      && !equipmentApplies(out, 'blindfold', customer.id)) {
      const equipped = attemptEquipmentImpl(out, customer, 'blindfold', {
        roll: 0,
        roomId,
        force: true,
        silent: true
      });
      out = equipped.state;
      impostorBlindfoldApplied = equipped.success;
    }
    if (impostorBlindfoldApplied) {
      out = appendDistressLog(
        out,
        `${withParticle(customer.name, '\uC740', '\uB294')} ${withParticle(wifeDisplayName(out), '\uC774', '\uAC00')} \uC790\uB9AC\uB97C \uC7A1\uAE30\uB3C4 \uC804\uC5D0 \uB4A4\uC5D0\uC11C \uB208\uC744 \uAC00\uB9AC\uACE0 \uCC9C\uC758 \uB9E4\uB4ED\uC744 \uC870\uC785\uB2C8\uB2E4.`
      );
    }
    const playerMistaken = confusionPlayerDeceptionApplies(state, customer);
    out = appendIntimateLog(out, playerMistaken
      ? (resolution === 'pressured'
          ? `${withParticle(wifeName, '은', '는')} 문 앞에서 멈칫하지만 ${withParticle(customer.name, '을', '를')} 당신으로 알고 그의 재촉에 따라 들어갑니다.`
          : `${withParticle(wifeName, '은', '는')} ${withParticle(customer.name, '을', '를')} 당신으로 알고 ${privateLureDirection(state, roomId)} 따라 들어갑니다. 그는 문 곁에 섭니다.`)
      : (resolution === 'pressured'
          ? `${withParticle(wifeName, '은', '는')} 홀에 남겠다고 하지만, ${withParticle(customer.name, '은', '는')} 잠깐이면 된다며 거듭 재촉합니다. 그녀는 더 버티지 못하고 따라 들어갑니다.`
          : `${withParticle(wifeName, '은', '는')} ${withParticle(customer.name, '과', '와')} 함께 홀을 나서 ${privateLurePlace(state, roomId)}에 들어갑니다. 그는 문 곁에 섭니다.`));
    return out;
  }


  function enterBackRoomConversation(...args) {
    return runPublicProcess('backRoomEnter', enterBackRoomConversationImpl, args);
  }

  function resolveWifeBackRoomPretext(state, customer, source, selectedRoomId) {
    const roomId = selectedRoomId || choosePrivateLureRoom(state, customer);
    if (!roomId) return state;
    const interaction = required.getActiveScene(state);
    const trust = interaction?.customerId === customer.id ? interaction.elenaComfort ?? 35 : 25;
    const noticed = wifeNoticesBackRoomPretext(state, customer, trust);
    if (!noticed.attackerWins) return enterBackRoomConversation(state, customer, source, 'unnoticed', roomId);
    const refusal = wifeRefusesBackRoomPretext(state, customer);
    return refusal.attackerWins
      ? refuseBackRoomPretext(state, customer, roomId)
      : enterBackRoomConversation(state, customer, source, 'pressured', roomId);
  }

  function beginBackRoomPretextImpl(state, customer, source) {
    if (!canAttemptBackRoomPretext(state, customer)) return state;
    const roomId = choosePrivateLureRoom(state, customer);
    if (!roomId) return state;
    if (playerLocation(state) === 'taproom') {
      const noticed = husbandNoticesBackRoomPretext(state, customer);
      if (noticed.attackerWins) {
        const wifeName = wifeDisplayName(state);
        const data = getData(state);
        data.pendingBackRoomPretext = { customerId: customer.id, source, roomId };
        const setup = appendDistressLog(
          putData(state, data),
          `홀의 소음 사이로 ${withParticle(customer.name, '이', '가')} ${wifeName}에게 말을 건네는 모습이 눈에 들어옵니다. 그는 ${privateLurePlace(state, roomId)} 쪽으로 걸음을 옮기며 그녀에게 함께 가자고 합니다.`
        );
        return {
          ...setup,
          pendingEvent: {
            type: 'bad_guest_back_room_husband',
            customerId: customer.id,
            customerName: customer.name,
            text: `${withParticle(customer.name, '이', '가')} ${withParticle(wifeName, '과', '와')} 함께 ${privateLureDirection(state, roomId)} 향하려 합니다. 어떻게 하시겠습니까?`,
            choices: [
              { id: 'bad_guest_back_room_ignore', label: '그냥 무시하기', description: `${withParticle(wifeName, '이', '가')} 스스로 속임수를 알아차리는지 지켜봅니다.` },
              { id: 'bad_guest_back_room_stop', label: '손님을 붙잡기', description: '손님의 팔을 붙잡아 세우고 둘이 홀을 나가지 못하게 합니다.' }
            ]
          }
        };
      }
    }
    return resolveWifeBackRoomPretext(state, customer, source, roomId);
  }


  function beginBackRoomPretext(...args) {
    return runPublicProcess('backRoomPretext', beginBackRoomPretextImpl, args);
  }

  function stopBackRoomPretextImpl(state, customerId) {
    const customer = state.customers?.find(entry => entry.id === customerId);
    const wifeName = wifeDisplayName(state);
    const data = getData(state);
    const roomId = data.pendingBackRoomPretext?.roomId;
    data.pendingBackRoomPretext = null;
    return appendFlirtLog(
      putData({ ...state, pendingEvent: undefined }, data),
      `당신은 ${customer?.name || '그 손님'}의 팔을 붙잡아 걸음을 멈춰 세웁니다. “할 말이 있으면 여기서 해.” ${withParticle(wifeName, '은', '는')} ${privateLurePlace(state, roomId)} 쪽으로 가려다 홀로 돌아섭니다.`
    );
  }


  function stopBackRoomPretext(...args) {
    return runPublicProcess('backRoomStop', stopBackRoomPretextImpl, args);
  }

  function drinkingGameReward(sample = Math.random()) {
    return 30 + Math.floor(clamp(sample, 0, 0.999999) * 171);
  }

  const DRINKING_GAME_TYPES = Object.freeze([
    '주사위 합 맞히기', '카드 높낮이', '동전 앞뒤 맞히기', '왕 게임식 벌주 뽑기'
  ]);

  function maybeOfferDrinkingGameImpl(state, options = {}) {
    if (state.pendingEvent || required.getActiveScene(state) || backRoomParty(state)) return state;
    const data = getData(state);
    if (data.drinkingGame?.active || data.drinkingGame?.wakeAtSlot > state.slot
      || data.wealthyParty?.active
      || equipmentOf(data, 'restraint')?.active) return state;
    if (!options.force && !['service', 'last_call'].includes(state.phase)) return state;
    if (playerLocation(state) !== 'taproom' || wifeLocation(state) !== 'taproom') return state;
    const room = state.locations?.back_room;
    if (!room || state.tavern?.backRoomReady === false
      || room.meta?.party || room.meta?.privatePatron
      || (room.occupants || []).length) return state;
    const guests = (state.customers || []).filter(customer =>
      isBadGuest(state, customer)
      && ACTIVE_CUSTOMER_STATUSES.has(customer.status)
      && customerLocation(state, customer.id) === 'taproom'
    );
    const lead = guests.find(customer => {
      const visit = data.drinkingGameVisits[customer.id];
      return !visit?.offered && (options.force || visit?.eligible);
    });
    if (!lead) return state;
    const members = [lead, ...guests.filter(customer => customer.id !== lead.id).slice(0, 4)];
    const wife = getWife(state);
    const gameType = DRINKING_GAME_TYPES[Math.floor(clamp(options.gameRoll ?? Math.random(), 0, 0.999999) * DRINKING_GAME_TYPES.length)];
    const stake = drinkingGameReward(options.rewardRoll ?? Math.random());
    data.drinkingGameVisits = {
      ...data.drinkingGameVisits,
      [lead.id]: { ...(data.drinkingGameVisits[lead.id] || {}), eligible: true, offered: true }
    };
    data.drinkingGame = {
      offeredAtSlot: state.slot,
      offered: true,
      active: false,
      leadId: lead.id,
      participantIds: members.map(customer => customer.id),
      gameType,
      stake,
      wifeResumeTask: wife?.currentTask,
      wifeResumeTaskTarget: wife?.taskTarget,
      wifeResumeBusyUntilSlot: wife?.busyUntilSlot,
      wifeResumeLocationUntilSlot: wife?.locationUntilSlot
    };
    let out = putData(state, data);
    out = original.moveWife(out, 'back_room', out.slot + 5, { skipModestyCheck: true });
    out = original.movePlayer(out, 'player', 'back_room');
    for (const member of members) out = putOccupantInRoom(out, member.id, 'back_room');
    out = updateWife(out, current => ({
      ...current,
      currentTask: 'talking',
      taskTarget: lead.id,
      busyUntilSlot: out.slot + 5,
      locationUntilSlot: out.slot + 5
    }));
    out = appendLog(out, `${withParticle(lead.name, '이', '가')} 일행과 함께 당신과 ${withParticle(wifeDisplayName(out), '을', '를')} 뒷방으로 부릅니다. 탁자에는 술잔과 돈주머니가 놓여 있습니다.`);
    return {
      ...out,
      pendingEvent: {
        type: 'bad_guest_drinking_game_offer',
        customerId: lead.id,
        customerName: lead.name,
        text: `${withParticle(lead.name, '은', '는')} ${gameType}를 제안하며 ${stake}골드를 꺼냅니다. “이기면 이 돈은 주인장 것이오. 지면 두 분이 벌주를 한 잔씩 마시는 거요.”`,
        choices: [
          { id: 'bad_guest_drinking_game_accept', label: `${gameType}를 받아들이기`, description: `이기면 ${stake}골드를 받고, 지면 두 분이 벌주를 마십니다.` },
          { id: 'bad_guest_drinking_game_refuse', label: '거절하고 나오기', description: '게임을 거절하고 홀로 돌아갑니다.' }
        ]
      }
    };
  }

  function maybeOfferDrinkingGame(...args) {
    return runPublicProcess('drinkingGameOffer', maybeOfferDrinkingGameImpl, args);
  }

  function leaveDrinkingGameRoom(state, message) {
    const game = readData(state).drinkingGame;
    if (!game) return { ...state, pendingEvent: undefined };
    let out = { ...state, pendingEvent: undefined };
    for (const customerId of game.participantIds || []) {
      const customer = out.customers?.find(entry => entry.id === customerId);
      if (customer && ACTIVE_CUSTOMER_STATUSES.has(customer.status)) {
        out = putOccupantInRoom(out, customerId, 'taproom');
      }
    }
    out = original.moveWife(out, 'taproom', game.wifeResumeLocationUntilSlot,
      { skipModestyCheck: true });
    out = original.movePlayer(out, 'player', 'taproom');
    out = updateWife(out, wife => ({
      ...wife,
      currentTask: game.wifeResumeTask || 'idle',
      taskTarget: game.wifeResumeTaskTarget,
      busyUntilSlot: game.wifeResumeBusyUntilSlot,
      locationUntilSlot: game.wifeResumeLocationUntilSlot
    }));
    const data = getData(out);
    data.drinkingGame = null;
    return appendLog(putData(out, data), message);
  }

  function drinkingGameWaitEvent(state, game) {
    const remaining = Math.max(0, game.wakeAtSlot - state.slot);
    return {
      type: 'bad_guest_drinking_game_wait',
      customerId: game.participantIds?.[game.cursor ?? 0] || '',
      customerName: '뒷방의 손님들',
      text: game.active
        ? `벌주를 마신 뒤 기억이 끊깁니다. 당신은 안대를 쓴 ${wifeDisplayName(state)} 곁에 쓰러져 있습니다. (${remaining}분 남음)`
        : `뒷방은 조용해졌지만 당신은 아직 눈을 뜨지 못합니다. (${remaining}분 남음)`,
      choices: [
        { id: 'bad_guest_drinking_game_wait_1', label: '1m', description: '1분 기다립니다.' },
        { id: 'bad_guest_drinking_game_wait_5', label: '5m', description: '5분 기다립니다.' },
        { id: 'bad_guest_drinking_game_wait_15', label: '15m', description: '15분 기다립니다.' }
      ]
    };
  }

  function drinkingGameWaitMinutes(choiceId) {
    if (choiceId === 'bad_guest_drinking_game_wait'
      || choiceId === 'bad_guest_drinking_game_wait_1') return 1;
    if (choiceId === 'bad_guest_drinking_game_wait_5') return 5;
    if (choiceId === 'bad_guest_drinking_game_wait_15') return 15;
    return 0;
  }

  function holdDrinkingGameService(state, game) {
    const endSlot = Number(game?.endSlot);
    if (!game?.active || !Number.isFinite(endSlot) || endSlot <= state.slot
      || wifeLocation(state) !== 'back_room') return state;
    return updateWife(state, wife => ({
      ...wife,
      locationUntilSlot: Math.max(Number(wife.locationUntilSlot) || 0, endSlot)
    }));
  }

  function ensureDrinkingGameScene(state) {
    const data = readData(state);
    const game = data.drinkingGame;
    if (!game?.active || required.getActiveScene(state) || unresponsiveDrugTarget(state)) return state;
    const valid = (game.participantIds || []).filter(id => {
      const customer = (state.customers || []).find(entry => entry.id === id);
      return customer && customer.status !== 'gone' && customer.status !== 'leaving'
        && customerLocation(state, id) === 'back_room';
    });
    if (!valid.length) return state;
    const cursor = (game.cursor ?? 0) % valid.length;
    const customerId = valid[cursor];
    const customer = state.customers.find(entry => entry.id === customerId);
    let out = wrappedStartPatronInteraction(
      state,
      customerId,
      'chatting',
      `${withParticle(customer.name, '은', '는')} 흐려진 ${wifeDisplayName(state)}의 시선을 붙잡고 자기 쪽으로 돌립니다.`,
      undefined
    );
    const nextData = getData(out);
    nextData.drinkingGame = { ...nextData.drinkingGame, cursor: cursor + 1 };
    return holdDrinkingGameService(putData(out, nextData), game);
  }

  function finishDrinkingGameScene(state) {
    let normalized = normalizeEffects(state);
    let data = getData(normalized);
    const game = data.drinkingGame;
    if (!game?.active) return normalized;
    const wifeUnresponsive = Boolean(unresponsiveDrugTarget(normalized));
    const scene = required.getActiveScene(normalized);
    if (scene && game.participantIds?.includes(scene.customerId)
      && !equipmentOf(data, 'restraint')?.active) {
      normalized = wrappedEndPatronInteraction(normalized, 'patron_gave_up');
      data = getData(normalized);
    }
    const endEvent = normalized.pendingEvent?.type === 'bad_guest_drinking_game_wait'
      ? null : normalized.pendingEvent;
    if (!required.getActiveScene(normalized)) {
      for (const customerId of game.participantIds || []) {
        const customer = normalized.customers?.find(entry => entry.id === customerId);
        if (customer && ACTIVE_CUSTOMER_STATUSES.has(customer.status)) {
          normalized = putOccupantInRoom(normalized, customerId, 'taproom');
        }
      }
      if (wifeLocation(normalized) === 'back_room' && !wifeUnresponsive) {
        normalized = original.moveWife(normalized, 'taproom', game.wifeResumeLocationUntilSlot,
          { skipModestyCheck: true });
        normalized = updateWife(normalized, wife => ({
          ...wife,
          currentTask: game.wifeResumeTask || 'idle',
          taskTarget: game.wifeResumeTaskTarget,
          busyUntilSlot: game.wifeResumeBusyUntilSlot,
          locationUntilSlot: game.wifeResumeLocationUntilSlot
        }));
      }
      data = getData(normalized);
    }
    const confusion = effectOf(data, 'confusion');
    if (!wifeUnresponsive && confusion
      && confusion.startedAtSlot <= (game.lostAtSlot ?? game.endSlot)) {
      const resolved = resolveConfusionMemoryRecovery(normalized, data, confusion);
      normalized = resolved.state;
      data = resolved.data;
      setEffect(data, 'confusion', null);
    }
    data.drinkingGame = {
      ...game,
      active: false,
      sceneCompletedAtSlot: normalized.slot,
      deferredEvent: game.deferredEvent || endEvent
    };
    let out = putData({ ...normalized, pendingEvent: undefined }, data);
    return appendLog(out, wifeUnresponsive
      ? `한 시간 뒤 뒷방은 조용해집니다. ${withParticle(wifeDisplayName(out), '은', '는')} 아직 눈을 뜨지 않습니다.`
      : `한 시간 뒤 ${withParticle(wifeDisplayName(out), '은', '는')} 천천히 초점을 되찾습니다.`);
  }

  function wakeFromDrinkingGame(state) {
    const data = getData(state);
    const game = data.drinkingGame;
    if (!game || state.slot < game.wakeAtSlot) return state;
    data.drinkingGame = null;
    return appendLog(putData({ ...state, pendingEvent: game.deferredEvent || undefined }, data),
      '조금 뒤 당신은 벌주에서 깨어나 몸을 일으킵니다.');
  }

  function advanceDrinkingGame(state, requestedMinutes = 1) {
    const game = readData(state).drinkingGame;
    if (!game?.wakeAtSlot || state.slot >= game.wakeAtSlot) return state;
    const remaining = Math.max(0, game.wakeAtSlot - state.slot);
    const minutes = Math.min(remaining, Math.max(1, Math.trunc(Number(requestedMinutes) || 1)));
    if (minutes <= 0) return wakeFromDrinkingGame(state);
    let out = state;
    for (let elapsed = 0; elapsed < minutes; elapsed += 1) {
      const beforeSlot = out.slot;
      let prepared = { ...out, pendingEvent: undefined };
      if (readData(prepared).drinkingGame?.active) {
        prepared = ensureDrinkingGameScene(prepared);
        prepared = holdDrinkingGameService(prepared, readData(prepared).drinkingGame);
      }
      out = original.advanceWorldMinute(prepared);
      const afterData = getData(out);
      const current = afterData.drinkingGame || game;
      if (out.pendingEvent && out.pendingEvent.type !== 'bad_guest_drinking_game_wait') {
        afterData.drinkingGame = { ...current, deferredEvent: current.deferredEvent || out.pendingEvent };
        out = putData({ ...out, pendingEvent: undefined }, afterData);
      }
      if (current.active && out.slot >= current.endSlot) out = finishDrinkingGameScene(out);
      if (out.slot >= current.wakeAtSlot) return wakeFromDrinkingGame(out);
      if (out.slot <= beforeSlot) break;
    }
    const current = readData(out).drinkingGame || game;
    return { ...out, pendingEvent: drinkingGameWaitEvent(out, current) };
  }

  function resolveDrinkingGameImpl(state, accept, options = {}) {
    const data = getData(state);
    const game = data.drinkingGame;
    if (!game?.offered) return state;
    if (!accept) {
      return leaveDrinkingGameRoom(state, `당신은 ${game.gameType}를 거절하고 홀로 돌아갑니다.`);
    }
    const leader = (state.customers || []).find(customer => customer.id === game.leadId);
    if (!leader || !ACTIVE_CUSTOMER_STATUSES.has(leader.status)
      || customerLocation(state, leader.id) !== 'back_room') {
      return leaveDrinkingGameRoom(state, '손님이 자리를 떠나 게임은 시작되지 않습니다.');
    }
    if ((options.winRoll ?? Math.random()) < 0.5) {
      const reward = game.stake;
      return leaveDrinkingGameRoom({
        ...state,
        economy: { ...(state.economy || {}), gold: (state.economy?.gold ?? 0) + reward },
        goldEarnedToday: (state.goldEarnedToday ?? 0) + reward,
        incomeBreakdownToday: {
          ...(state.incomeBreakdownToday || {}),
          scenarios: (state.incomeBreakdownToday?.scenarios ?? 0) + reward
        }
      }, `당신은 ${game.gameType}에서 이깁니다. 손님이 ${reward}골드를 건넵니다. 모두 홀로 돌아갑니다.`);
    }
    const endSlot = state.slot + 60;
    data.drinkingGame = { ...game, active: true, lostAtSlot: state.slot, endSlot,
      wakeAtSlot: state.slot + 65, cursor: 0 };
    let out = putData({ ...state, pendingEvent: undefined }, data);
    out = applyConfusionDrug(
      out,
      leader,
      `당신은 ${game.gameType}에서 지고 벌주를 마십니다. 눈앞이 어두워지는 동안 ${withParticle(leader?.name || '손님', '은', '는')} ${wifeDisplayName(out)}에게도 다른 잔을 마시게 하고 안대를 씌웁니다. 그녀는 그를 낯익은 사람처럼 부릅니다.`
    );
    out = attemptEquipmentImpl(out, leader, 'blindfold', {
      roomId: 'back_room',
      roll: 0,
      silent: true,
      allowPlayerPresent: true
    }).state;
    const party = backRoomParty(out);
    if (party && (party.endSlot ?? 0) < endSlot) {
      out = {
        ...out,
        locations: {
          ...(out.locations || {}),
          back_room: {
            ...(out.locations?.back_room || {}),
            meta: {
              ...(out.locations?.back_room?.meta || {}),
              party: { ...party, endSlot }
            }
          }
        }
      };
    }
    out = ensureDrinkingGameScene(out);
    out = holdDrinkingGameService(out, readData(out).drinkingGame);
    const liveGame = readData(out).drinkingGame;
    return { ...out, pendingEvent: drinkingGameWaitEvent(out, liveGame) };
  }

  function resolveDrinkingGame(...args) {
    return runPublicProcess('drinkingGameResolve', resolveDrinkingGameImpl, args);
  }

  function protectFromDrugImpl(state, customerId, eject) {
    const customer = state.customers?.find(entry => entry.id === customerId);
    const wifeName = wifeDisplayName(state);
    let out = { ...state, pendingEvent: undefined };
    if (eject) {
      out = required.ejectCustomer(out, customerId);
    }
    out = required.recordPlayerTone(out, 'protective');
    out = required.recordPatronBoundary(out, 'drinking', customerId, 'step_in');
    out = required.nudgeRelationship(out, { trust: 3, resentment: -2 });
    out = updateWife(out, wife => ({ ...wife, lastAffectionSlot: out.slot }));
    out = required.recordAffection(out, 'affection:protected', 2, { countsAgainstBudget: true });
    const data = getData(out);
    data.pendingDrug = null;
    out = putData(out, data);
    return appendLog(
      out,
      eject
        ? `${withParticle(wifeName, '은', '는')} 당신이 잔을 쳐내고 ${withParticle(customer?.name || '그 손님', '을', '를')} 문밖으로 몰아내는 동안 한 발 뒤로 물러서 있습니다. 문이 닫히자 안도한 듯 당신의 팔을 꼭 붙잡습니다.`
        : `당신은 ${wifeName}의 잔을 빼앗아 내용물을 버리고 ${customer?.name || '그 손님'}에게 다시는 그러지 말라고 경고합니다. 손님은 자리에 남지만, ${withParticle(wifeName, '은', '는')} 안도하며 당신의 팔을 붙잡습니다.`
    );
  }


  function protectFromDrug(...args) {
    return runPublicProcess('drugProtection', protectFromDrugImpl, args);
  }

  const DRUG_PATRON_INTERVENTION_CHOICES = new Set(['step_in', 'pull_away', 'stop']);
  const DRUG_DOOR_INTERVENE_ACTION = 'bad_guest_drug_door_intervene';
  const DRUG_DOOR_LEAVE_ACTION = 'bad_guest_drug_door_leave';

  function restraintPlayerInterventionRequested(state, action) {
    const scene = required.getActiveScene(state);
    if (!scene?.customerId || !restraintOwnsCustomer(state, scene.customerId)) return false;
    if (action?.type === DRUG_DOOR_INTERVENE_ACTION) return true;
    if (action?.type === 'patron_interaction_choice') {
      return DRUG_PATRON_INTERVENTION_CHOICES.has(action.choiceId);
    }
    return action?.type === 'resolve_event'
      && action.choiceId === 'force_intervene'
      && state.pendingEvent?.type === 'patron_interrupt_refused'
      && String(state.pendingEvent.customerId) === String(scene.customerId);
  }

  function acceptanceDecisionAccepted(decision) {
    return decision?.outcome === 'eager' || decision?.outcome === 'hesitant';
  }

  function drugPatronInterventionContext(state) {
    const scene = required.getActiveScene(state);
    if (!scene?.customerId || scene.afterglow || state.rescuePending?.patronId === scene.customerId) return null;
    const category = stageAcceptanceCategory(scene);
    if (!category) return null;
    const data = readData(state);
    if (!(timedEffectActive(state, 'aphrodisiac') || timedEffectActive(state, 'confusion'))) return null;
    if (restraintOwnsCustomer(state, scene.customerId, equipmentOf(data, 'restraint'))) return null;
    const customer = state.customers?.find(entry => entry.id === scene.customerId);
    if (!customer) return null;
    return { scene, customer, category };
  }

  function drugDoorSceneContext(state) {
    if (state.pendingEvent) return null;
    const context = drugPatronInterventionContext(state);
    const entry = context?.scene?.badGuestDrugDoorEntry;
    if (!context || !entry?.roomId || !playerInsideRoom(state, entry.roomId)) return null;
    return { ...context, entry };
  }

  function leaveDrugDoorScene(state) {
    const context = drugDoorSceneContext(state);
    if (!context) return state;
    const destination = context.entry.returnRoom;
    if (!destination || destination === context.entry.roomId || !state.locations?.[destination]) return state;
    let out = original.movePlayer(state, 'player', destination);
    return appendLog(out, '당신은 아무 말 없이 방에서 물러납니다.');
  }

  function drugPatronInterventionLead(state, customerName) {
    const confused = timedEffectActive(state, 'confusion');
    const aroused = drugLevelAt(state) > 0;
    const wifeName = wifeDisplayName(state);
    const key = `intervention-lead:${customerName}:${confused}:${aroused}`;
    if (confused && aroused) {
      return storyLine(state, key, [
        `${withParticle(wifeName, '은', '는')} 흐린 눈으로 숨을 가쁘게 몰아쉬며 ${customerName} 곁에 남습니다.`,
        `${withParticle(wifeName, '은', '는')} 숨을 고르려 하지만 자꾸 가빠집니다. ${customerName} 쪽에서 발을 떼지 않습니다.`,
        `${withParticle(wifeName, '은', '는')} 당신의 목소리에 돌아봅니다. 초점이 흔들리고 숨이 빠르지만 ${customerName} 곁에 머뭅니다.`
      ]);
    }
    if (confused) {
      return storyLine(state, key, [
        `${withParticle(wifeName, '은', '는')} 초점이 흐린 눈으로 ${customerName} 곁에 남습니다.`,
        `${withParticle(wifeName, '은', '는')} 당신을 바라보지만 곧 ${customerName} 쪽으로 고개를 돌립니다. 눈에 초점이 잡히지 않습니다.`,
        `${withParticle(wifeName, '은', '는')} 잠깐 눈을 깜빡입니다. ${customerName}에게서 떨어지지는 않습니다.`
      ]);
    }
    return storyLine(state, key, [
      `${withParticle(wifeName, '은', '는')} 달아오른 숨을 고르며 ${customerName} 곁에 남습니다.`,
      `${withParticle(wifeName, '은', '는')} 숨을 길게 내쉬지만 ${customerName} 쪽에서 물러서지 않습니다.`,
      `${withParticle(wifeName, '은', '는')} 당신을 향해 고개를 듭니다. 붉어진 얼굴로도 ${customerName} 곁을 지킵니다.`
    ]);
  }

  function interventionRefusalSpeech(state, key) {
    const voice = storyVoice(state);
    const candidates = voice === 'mara'
      ? ['“됐어. 내가 정할게.”', '“잠깐만. 내 얘기부터 들어.”']
      : ['“난 괜찮아. 내가 결정할게.”', '“잠깐만. 내 말도 들어 줘.”'];
    return storyLine(state, `intervention-speech:${key}:${voice}`, candidates);
  }

  function finishDrugPatronIntervention(state, mode, line) {
    const scene = required.getActiveScene(state);
    if (!scene) return state;
    const moodBefore = getWife(state)?.stats?.mood ?? 50;
    let out = { ...state, pendingEvent: undefined };
    const category = stageAcceptanceCategory(scene);
    if (category) out = required.recordPatronBoundary(out, category, scene.customerId, 'step_in');
    out = wrappedEndPatronInteraction(
      out,
      mode === 'neutral' ? 'elena_refused' : 'player_intervened',
      {
        playerWitnessed: true,
        suppressEndText: true,
        suppressReactionWindow: true,
        badGuestDrugIntervention: mode
      }
    );
    if (mode === 'aware') {
      out = updateWife(out, wife => ({
        ...wife,
        stats: { ...(wife.stats || {}), mood: clamp(moodBefore - 1) }
      }));
      out = required.nudgeRelationship(out, { trust: 1 });
    }
    out = required.recordPlayerTone(out, 'protective');
    out = updateWife(out, wife => ({
      ...wife,
      lastResponse: line,
      lastResponseType: mode === 'welcomed' ? 'hesitant' : 'neutral',
      lastResponseSlot: out.slot
    }));
    return appendLog(out, line);
  }

  function beginDrugPatronIntervention(state) {
    const context = drugPatronInterventionContext(state);
    if (!context) return null;
    const { scene, customer, category } = context;
    const current = original.evaluateIntimacy(state, category, {
      kind: 'patron_request',
      characterId: getWifeId(state),
      comfortWithPatron: Number(scene.elenaComfort) || 0,
      activeCustomerId: customer.id,
      isReturning: false,
      pressureLevel: 0
    });
    const intervention = original.evaluateIntimacy(state, 'interrupt_patron', {
      kind: 'player_interrupt'
    });
    const currentAccepted = acceptanceDecisionAccepted(current);
    const interventionAccepted = acceptanceDecisionAccepted(intervention);
    const wifeName = wifeDisplayName(state);
    if (!currentAccepted) {
      return finishDrugPatronIntervention(
        state,
        interventionAccepted ? 'welcomed' : 'neutral',
        storyLine(state, `intervention-end:unwilling:${interventionAccepted}:${customer.id}`, interventionAccepted
          ? [
            `${withParticle(wifeName, '은', '는')} 당신이 그만하라고 하자 ${customer.name}의 손을 떼어내고 당신 쪽으로 물러섭니다.`,
            `${withParticle(wifeName, '은', '는')} ${customer.name}에게서 몸을 빼고 당신 뒤로 물러납니다. “그만하라고 했어.”`,
            `${withParticle(wifeName, '은', '는')} 당신의 말이 끝나자 ${customer.name}을 밀어냅니다. 손을 떨며 당신 쪽으로 옵니다.`
          ] : [
            `${withParticle(wifeName, '은', '는')} ${customer.name}에게서 스스로 몸을 빼냅니다. 당신이 다가서자 손을 들어 멈추게 합니다.`,
            `${withParticle(wifeName, '은', '는')} ${customer.name}의 손을 떼어냅니다. 당신이 다가오자 다시 한 걸음 물러섭니다.`,
            `${withParticle(wifeName, '은', '는')} ${customer.name}에게서 떨어집니다. 당신에게도 손을 들어 가까이 오지 말라는 뜻을 보입니다.`
          ])
      );
    }
    if (interventionAccepted) {
      return finishDrugPatronIntervention(
        state,
        'welcomed',
        storyLine(state, `intervention-end:accepted:${customer.id}`, [
          `${withParticle(wifeName, '은', '는')} ${customer.name}에게서 바로 떨어지지는 않지만, 당신이 그만하라고 하자 잠시 망설인 끝에 물러섭니다.`,
          `${withParticle(wifeName, '은', '는')} 당신의 말을 듣고도 잠깐 ${customer.name} 곁에 섭니다. 그러다 눈을 감고 당신 쪽으로 걸어옵니다.`,
          `${withParticle(wifeName, '은', '는')} ${customer.name} 곁에서 바로 떨어지지 못하다가 당신의 목소리에 고개를 듭니다. 한 걸음 늦게 물러섭니다.`
        ])
      );
    }
    return {
      ...state,
      pendingEvent: {
        type: 'bad_guest_drug_patron_intervention_refused',
        customerId: customer.id,
        customerName: customer.name,
        category,
        interventionScore: Number.isFinite(Number(intervention?.score)) ? Number(intervention.score) : null,
        interventionThreshold: Number.isFinite(Number(intervention?.threshold)) ? Number(intervention.threshold) : null,
        text: `${drugPatronInterventionLead(state, customer.name)} 당신이 그만하라고 하자 고개를 젓습니다. ${interventionRefusalSpeech(state, `first:${customer.id}`)}`,
        choices: [
          { id: 'bad_guest_drug_intervention_back_off', label: '물러서기', description: '그녀의 뜻을 존중하고 더 개입하지 않습니다.' },
          { id: 'bad_guest_drug_intervention_insist', label: '“잠깐, 네 손을 봐.”', description: '그녀에게 잠시 멈추고 자기 몸과 곁의 손님을 살피자고 말합니다.' },
          { id: 'bad_guest_drug_intervention_force', label: '억지로 떼어놓기', description: '그녀의 뜻을 무시하고 두 사람을 억지로 떼어놓습니다.' }
        ]
      }
    };
  }

  function originalPatronInterventionEvent(state, event = state.pendingEvent) {
    return {
      ...state,
      pendingEvent: {
        type: 'patron_interrupt_refused',
        customerId: event.customerId,
        customerName: event.customerName,
        text: event.text,
        choices: [
          { id: 'back_off', label: '물러서기', description: '그녀의 뜻을 존중하여 계속되도록 둡니다.' },
          { id: 'force_intervene', label: '그녀를 억지로 떼어놓기', description: '그녀의 팔을 잡고 억지로 끌고 옵니다.' }
        ]
      }
    };
  }

  function drugPatronInterventionAwareness(state, score, threshold) {
    const requiredInfluence = clamp((threshold + 15 - score) / 30, 0, 1);
    const requiredAwareness = clamp(0.1 + requiredInfluence * 0.8, 0.05, 0.95);
    const awareness = drugRecoveryChance(state);
    return {
      accepted: awareness >= requiredAwareness,
      awareness,
      requiredAwareness,
      requiredInfluence
    };
  }

  function customEventChoice(state, action) {
    const event = state.pendingEvent;
    const conversationChoiceId = wifeConversationChoiceId(state, action);
    const recoveryChoice = conversationChoiceId === 'bad_guest_drug_recovery';
    const incidentChoice = isIncidentMomentEvent(event);
    const incidentConfessionChoice = isIncidentConfessionEvent(event);
    if (action.type !== 'resolve_event' && !recoveryChoice) return null;
    if (
      !event?.type?.startsWith('bad_guest_')
      && !recoveryChoice && !incidentChoice && !incidentConfessionChoice
    ) return null;

    if (event.type === 'bad_guest_wealthy_party_offer') {
      if (action.choiceId === 'bad_guest_wealthy_party_accept') return startWealthyParty(state);
      if (action.choiceId === 'bad_guest_wealthy_party_refuse') {
        const data = getData(state);
        data.wealthyPartyLastDay = state.day;
        let out = putData({ ...state, pendingEvent: undefined }, data);
        out = {
          ...out,
          tavernReputation: {
            ...(out.tavernReputation || {}),
            renown: clamp((out.tavernReputation?.renown ?? 5) + 2)
          }
        };
        return appendLog(
          out,
          `가장 나이 많은 사내가 금화를 천천히 다시 주머니에 담습니다. “주인장이 자기 가게에서 누구를 받을지는 알아서 할 일이지.” 다섯 사람은 언성을 높이지 않지만, 마지막까지 ${wifeDisplayName(state)}에게서 시선을 거두지 않은 채 나갑니다.`,
          { important: true }
        );
      }
    }

    if (event.type === 'bad_guest_drug_husband') {
      const data = getData(state);
      const pending = data.pendingDrug;
      const customerId = pending?.customerId || event.customerId;
      const customer = state.customers?.find(entry => entry.id === customerId)
        || state.customers?.find(entry => entry.name === event.customerName);
      if (action.choiceId === 'bad_guest_stop_drug' || action.choiceId === 'bad_guest_stop_drug_eject') {
        return protectFromDrug(state, customerId, true);
      }
      if (action.choiceId === 'bad_guest_stop_drug_keep') {
        return protectFromDrug(state, customerId, false);
      }
      if (action.choiceId === 'bad_guest_allow_drug') {
        let out = { ...state, pendingEvent: undefined };
        data.pendingDrug = null;
        out = putData(out, data);
        if (!customer) {
          return appendDrugLog(
            out,
            `${event.customerName || '그 손님'}의 수상한 손놀림을 그대로 지켜보려 했지만, 그는 이미 잔에서 손을 떼고 자리를 벗어났습니다. 그 시도는 더 이어지지 않습니다.`
          );
        }
        const resolutionMode = pending?.resolutionMode
          || event.resolutionMode
          || (data.wealthyParty?.active ? 'wealthy_party_three_checks' : 'normal');
        const resolved = resolutionMode === 'wealthy_party_three_checks'
          ? resolveWealthyPartyDrugAttempt(out, customer)
          : resolveWifeDrugAttempt(
            out,
            customer,
            pending?.source || event.source || '주인이 지켜봄',
            pending?.drugKind || event.drugKind || 'aphrodisiac'
          );
        return resolved;
      }
    }

    if (event.type === 'bad_guest_drug_patron_intervention_refused'
      || event.type === 'bad_guest_drug_patron_intervention_force') {
      if (action.choiceId === 'bad_guest_drug_intervention_back_off') {
        return original.reduceGameAction(
          originalPatronInterventionEvent(state, event),
          { type: 'resolve_event', choiceId: 'back_off' }
        );
      }
      if (action.choiceId === 'bad_guest_drug_intervention_force') {
        return original.reduceGameAction(
          originalPatronInterventionEvent(state, event),
          { type: 'resolve_event', choiceId: 'force_intervene' }
        );
      }
      if (action.choiceId === 'bad_guest_drug_intervention_insist'
        && event.type === 'bad_guest_drug_patron_intervention_refused') {
        const score = Number.isFinite(event.interventionScore) ? event.interventionScore : -Infinity;
        const threshold = Number.isFinite(event.interventionThreshold) ? event.interventionThreshold : Infinity;
        const awareness = drugPatronInterventionAwareness(state, score, threshold);
        if (awareness.accepted) {
          return finishDrugPatronIntervention(
            state,
            'aware',
            storyLine(state, `intervention-aware:${event.customerName}`, [
              `당신의 말을 듣고 ${withParticle(wifeDisplayName(state), '은', '는')} 제 몸을 살핍니다. 그녀는 ${event.customerName}에게서 떨어집니다.`,
              `${withParticle(wifeDisplayName(state), '은', '는')} 손을 내려다보더니 ${event.customerName} 쪽에서 물러납니다. “잠깐, 나…”`,
              `${withParticle(wifeDisplayName(state), '은', '는')} 숨을 고르고 당신의 말을 다시 듣습니다. 그녀는 ${event.customerName}에게서 떨어집니다.`
            ])
          );
        }
        return {
          ...state,
          pendingEvent: {
            ...event,
            type: 'bad_guest_drug_patron_intervention_force',
            text: storyLine(state, `intervention-still-refused:${event.customerName}`, [
              `${withParticle(wifeDisplayName(state), '은', '는')} 고개를 젓고 ${event.customerName} 곁에 남습니다. ${interventionRefusalSpeech(state, `second:${event.customerName}`)}`,
              `${withParticle(wifeDisplayName(state), '은', '는')} 당신의 손을 밀어내고 ${event.customerName} 곁에 섭니다. ${interventionRefusalSpeech(state, `second:${event.customerName}`)}`
            ]),
            choices: [
              { id: 'bad_guest_drug_intervention_back_off', label: '물러서기', description: '그녀의 뜻을 존중하고 더 개입하지 않습니다.' },
              { id: 'bad_guest_drug_intervention_force', label: '억지로 떼어놓기', description: '그녀의 뜻을 무시하고 두 사람을 억지로 떼어놓습니다.' }
            ],
            requiredInfluence: awareness.requiredInfluence,
            requiredAwareness: awareness.requiredAwareness,
            actualAwareness: awareness.awareness
          }
        };
      }
    }

    if (event.type === 'bad_guest_aggressive_deception') {
      return resolveAggressiveDeception(state, action.choiceId);
    }

    if (event.type === 'bad_guest_drinking_game_offer') {
      if (action.choiceId === 'bad_guest_drinking_game_accept') return resolveDrinkingGame(state, true);
      if (action.choiceId === 'bad_guest_drinking_game_refuse') return resolveDrinkingGame(state, false);
    }

    if (event.type === 'bad_guest_drinking_game_wait') {
      const minutes = drinkingGameWaitMinutes(action.choiceId);
      if (minutes) return advanceDrinkingGame(state, minutes);
    }

    if (isIncidentConfessionEvent(event)) {
      return resolveIncidentConfessionChoice(state, action.choiceId);
    }

    if (isIncidentMomentEvent(event)) {
      return resolveIncidentMomentChoice(state, action.choiceId);
    }

    if (recoveryChoice) {
      return resolveDrugRecovery(state);
    }

    if (event.type === 'bad_guest_drug_recovery_doubt') {
      if (action.choiceId === 'bad_guest_drug_recovery_respect') {
        return appendLog({ ...state, pendingEvent: undefined }, `당신은 ${wifeDisplayName(state)}의 손을 놓고 물러납니다. 그녀는 경계한 채 스스로 서 있습니다.`);
      }
      if (action.choiceId === 'bad_guest_drug_recovery_force') return startDrugRecoveryRest(state, true);
    }

    if (event.type === 'bad_guest_back_room_husband') {
      const data = readData(state);
      const pending = data.pendingBackRoomPretext;
      const customerId = pending?.customerId || event.customerId;
      const customer = state.customers?.find(entry => entry.id === customerId);
      if (action.choiceId === 'bad_guest_back_room_stop') {
        return stopBackRoomPretext(state, customerId);
      }
      if (action.choiceId === 'bad_guest_back_room_ignore') {
        let out = { ...state, pendingEvent: undefined };
        data.pendingBackRoomPretext = null;
        out = putData(out, data);
        return customer
          ? resolveWifeBackRoomPretext(out, customer, pending?.source || '주인이 무시함', pending?.roomId)
          : out;
      }
    }

    if (event.type === 'bad_guest_locked_door') {
      if (action.choiceId === 'bad_guest_leave_locked') {
        return appendLog({ ...state, pendingEvent: undefined }, '당신은 한 걸음 물러나 문 앞에 섭니다. 안쪽에서는 낮은 목소리와 가구가 스치는 소리가 이어집니다.');
      }
      if (action.choiceId === 'bad_guest_break_door') return attemptBreakDoor(state);
    }

    if (event.type === 'bad_guest_restraint_rescue') {
      if (action.choiceId === 'bad_guest_leave_restraint') {
        const data = getData(state);
        const restraint = equipmentOf(data, 'restraint');
        if (!restraint) return { ...state, pendingEvent: undefined };
        setEquipment(data, 'restraint', {
          ...restraint,
          rescueResponse: 'leave',
          rescueRespondedAtSlot: state.slot
        });
        return putData({ ...state, pendingEvent: undefined }, data);
      }
      if (action.choiceId === 'bad_guest_take_wife_away') return rescueWife(state);
    }

    return { ...state, pendingEvent: undefined };
  }

  function attemptBreakDoorImpl(state) {
    let out = { ...state, pendingEvent: undefined };
    const data = getData(out);
    const lock = data.doorLock;
    if (!lock?.active) return out;
    const playerAttrs = effectiveAttributes(out.player || {});
    const strength = clamp(playerAttrs.strength ?? 50);
    const chance = doorBreakChanceAtStrength(strength);
    const success = Math.random() < chance;
    for (let minute = 0; minute < CONFIG.breakDoorMinutes; minute += 1) {
      out = wrappedMinuteTick(out);
    }

    const currentLock = readData(out).doorLock;
    if (!currentLock?.active || currentLock.roomId !== lock.roomId) return out;

    if (!success) {
      return appendLog(
        out,
        `당신이 어깨로 들이받아도 걸쇠는 버팁니다. ${CONFIG.breakDoorMinutes}분 뒤에도 문은 잠겨 있습니다.`,
        { important: true, tone: 'distress' }
      );
    }

    const gold = out.economy?.gold ?? 0;
    const shortage = Math.max(0, CONFIG.breakDoorRepairGold - gold);
    const currentData = getData(out);
    currentData.doorLock = null;
    out = putData(out, currentData);
    out = {
      ...out,
      economy: {
        ...(out.economy || {}),
        gold: Math.max(0, gold - CONFIG.breakDoorRepairGold),
        debt: (out.economy?.debt ?? 0) + shortage
      },
      tavernReputation: {
        ...(out.tavernReputation || {}),
        renown: clamp((out.tavernReputation?.renown ?? 50) - CONFIG.breakDoorRenownPenalty)
      }
    };
    out = appendLog(
      out,
      `걸쇠가 나무와 함께 뜯겨 나갑니다. ${CONFIG.breakDoorMinutes}분이 걸렸습니다. 수리비는 ${CONFIG.breakDoorRepairGold}골드이고, 이 소란으로 여관의 평판도 상합니다.`,
      { important: true, tone: 'distress' }
    );
    out = enterDrugDoorWithoutJudgment(out, lock.roomId)
      || original.reduceGameAction(out, { type: 'open_the_door', room: lock.roomId });
    return maybeCreateRestraintRescue(out);
  }


  function attemptBreakDoor(...args) {
    return runPublicProcess('doorBreak', attemptBreakDoorImpl, args);
  }

  function rescueWifeImpl(state) {
    const wifeName = wifeDisplayName(state);
    const data = getData(state);
    const restraint = equipmentOf(data, 'restraint');
    let out = { ...state, pendingEvent: undefined };
    const scene = required.getActiveScene(out);
    if (scene && restraintOwnsCustomer(out, scene.customerId, restraint)) {
      const category = stageAcceptanceCategory(scene);
      if (category) {
        out = required.recordPatronBoundary(out, category, scene.customerId, 'step_in');
      }
      const coercion = restraint.lastCoercion;
      const rescuedFromForcedAct = coercion?.coerced === true
        && coercion.slot >= (restraint.appliedAtSlot ?? -Infinity);
      if (rescuedFromForcedAct) {
        out = {
          ...out,
          rescuePending: {
            sinceSlot: coercion.slot,
            patronId: scene.customerId,
            engineered: false
          }
        };
      }
      out = withAuthorizedRestraintEnd(scene.customerId, 'player_intervened', () => (
        wrappedEndPatronInteraction(out, 'player_intervened', { playerWitnessed: true })
      ));
      out = required.recordPlayerTone(out, 'protective');
    }
    setEquipment(data, 'restraint', null);
    data.deferredMovement = null;
    out = putData(out, data);
    const destination = wifeSleepRoom(out);
    bypassMoveWife = true;
    try {
      out = original.moveWife(out, destination, out.slot + 5, { skipModestyCheck: true });
      out = original.movePlayer(out, 'player', destination);
    } finally {
      bypassMoveWife = false;
    }
    return appendDistressLog(
      out,
      `당신은 ${withParticle(wifeName, '을', '를')} 그 손님에게서 떼어내 방으로 데려갑니다. ${withParticle(wifeName, '은', '는')} 당신 곁에서 숨을 고릅니다.`
    );
  }


  function rescueWife(...args) {
    return runPublicProcess('restraintRescue', rescueWifeImpl, args);
  }

  function maybeCreateRestraintRescue(state) {
    const data = getData(state);
    const restraint = equipmentOf(data, 'restraint');
    if (!restraint || state.pendingEvent) return state;
    if (data.drinkingGame?.active || restraint.rescueResponse === 'leave') return state;
    const room = restraint.roomId;
    if (!playerInsideRoom(state, room)) return state;
    const customer = state.customers?.find(entry => entry.id === restraint.patronId);
    return {
      ...appendDistressLog(
        state,
        `방에 들어선 당신은 ${customer?.name || '그 손님'} 곁에서 손이 묶인 채 움직이지 못하는 ${withParticle(wifeDisplayName(state), '을', '를')} 봅니다.`
      ),
      pendingEvent: {
        type: 'bad_guest_restraint_rescue',
        customerId: restraint.patronId,
        customerName: customer?.name,
        text: `${withParticle(wifeDisplayName(state), '은', '는')} 손을 비틀지만 수갑이 풀리지 않습니다. 손님은 곁에서 물러나지 않습니다.`,
        choices: [
          { id: 'bad_guest_take_wife_away', label: `${withParticle(wifeDisplayName(state), '을', '를')} 방으로 데려가기`, description: `손님에게서 떼어내 수갑을 풀고 방으로 데려갑니다.` },
          { id: 'bad_guest_leave_restraint', label: '당장은 지켜보기', description: '지금은 개입하지 않습니다.' }
        ]
      }
    };
  }

  function putOccupantInRoom(state, occupantId, roomId) {
    if (!occupantId || !roomId || !state.locations?.[roomId]) return state;
    const locations = {};
    for (const [id, room] of Object.entries(state.locations || {})) {
      const occupants = (room?.occupants || []).filter(value => value !== occupantId);
      locations[id] = { ...room, occupants };
    }
    if (!locations[roomId].occupants.includes(occupantId)) {
      locations[roomId] = {
        ...locations[roomId],
        occupants: [...locations[roomId].occupants, occupantId]
      };
    }
    return { ...state, locations };
  }

  function reportQualifiedVisit(state, interaction, options = {}) {
    if (!state || !interaction?.customerId) return state;
    const customer = (state.customers || []).find(entry => (
      String(entry.id) === String(interaction.customerId)
    ));
    if (!customer) return state;
    const confused = timedEffectActive(state, 'confusion')
      && !unresponsiveDrugTarget(state);
    const coerced = isBadGuest(state, customer) && (
      options.coerced === true
      || interaction.coercedSinceSlot != null
      || interaction.wasPressuredIntoStage === true
      || restraintOwnsCustomer(state, customer.id)
    );
    const startedAtSlot = interaction.startedAtSlot ?? options.startedAtSlot;
    if (!Number.isFinite(Number(startedAtSlot))) return state;
    const aphrodisiacAssisted = (readData(state).aphrodisiacMemories?.events || []).some(event => (
      event?.drugChangedOutcome === true
      && event.answer === 'yes'
      && String(event.patronId) === String(customer.id)
      && Number(event.slot) >= Number(startedAtSlot)
      && Number(event.slot) <= Number(state.slot)
    ));
    if (!confused && !coerced && !aphrodisiacAssisted) return state;
    const service = getQualifiedExperience();
    if (!service) return state;
    try {
      return service.reportVisit(state, WML_DATA_KEY, {
        customerId: customer.id,
        patronName: customer.name,
        startedAtSlot,
        relationship: false
      }) || state;
    } catch {
      return state;
    }
  }

  function wrappedStartPatronInteraction(state, customerId, ...args) {
    const party = readData(state).wealthyParty;
    if (party?.active
      && !party.serveLocked
      && state.slot < party.endSlot
      && backRoomParty(state)
      && party.memberIds?.some(id => String(id) === String(customerId))) {
      return state;
    }
    const customer = (state.customers || []).find(entry => String(entry.id) === String(customerId));
    const canStart = customer
      && !required.getActiveScene(state)
      && customer.forceDecidedTonight !== 'trouble'
      && wifeLocation(state) === customerLocation(state, customer.id);
    const interaction = canStart ? {
      customerId: customer.id,
      customerName: customer.name,
      startedAtSlot: state.slot
    } : null;
    const input = interaction
      ? reportQualifiedVisit(state, interaction, { startedAtSlot: state.slot })
      : state;
    return original.startPatronInteraction(input, customerId, ...args);
  }

  function wrappedEndPatronInteraction(state, reason, options) {
    const scene = required.getActiveScene(state);
    const confusionPerception = confusionPerceptionForPatron(state, scene?.customerId);
    const aphrodisiacEvent = aphrodisiacEventForScene(state, scene?.customerId);
    const incident = patronIncidentForEnd(state, scene, aphrodisiacEvent, confusionPerception);
    const restraint = equipmentOf(readData(state), 'restraint');
    const customerId = scene?.customerId;
    const scopedAuthorization = authorizedRestraintEndContext
      && authorizedRestraintEndContext.reason === reason;
    if (scopedAuthorization
      && (authorizedRestraintEndContext.used === true
        || String(authorizedRestraintEndContext.customerId) !== String(customerId))) {
      return state;
    }
    const explicitlyAuthorized = scopedAuthorization
      && String(authorizedRestraintEndContext.customerId) === String(customerId);
    const sameTickCustomer = tacticTickContext
      && String(tacticTickContext.customerId) === String(customerId);
    const allowedNaturalTimeout = sameTickCustomer
      && tacticTickContext.naturalTimeoutEndReason === reason;
    const blockedForRestraint = !explicitlyAuthorized
      && !allowedNaturalTimeout
      && restraintOwnsCustomer(state, customerId, restraint);
    if (blockedForRestraint) return state;
    if (explicitlyAuthorized) authorizedRestraintEndContext.used = true;
    if ((explicitlyAuthorized || allowedNaturalTimeout) && sameTickCustomer) {
      tacticTickContext.authorizedEndReason = reason;
    }
    const suppressConfusedPlayerReaction = confusionPerception?.perceivedPartnerType === 'player';
    let endInput = suppressConfusedPlayerReaction && scene
      ? replacePatronScene(state, {
        ...scene,
        pretextOblivious: true,
        playerEncouragements: Math.min(-Number.EPSILON, scene.playerEncouragements ?? 0)
      })
      : state;
    const identityStrainBefore = getWife(state)?.identityStrain;
    if (suppressConfusedPlayerReaction) {
      endInput = updateWife(endInput, wife => ({ ...wife, identityStrain: 0 }));
    }
    const previousIncidentContext = endingPatronIncidentContext;
    let out;
    endingPatronIncidentContext = incident;
    try {
      out = withAphrodisiacSubjectiveContext(state, customerId, () => (
        withConfusionSubjectiveContext(state, customerId, () => (
          original.endPatronInteraction(endInput, reason, suppressConfusedPlayerReaction
            ? { ...(options || {}), suppressReactionWindow: true }
            : options)
        ))
      ));
    } finally {
      endingPatronIncidentContext = previousIncidentContext;
    }
    if (suppressConfusedPlayerReaction) {
      out = updateWife(out, wife => ({ ...wife, identityStrain: identityStrainBefore }));
    }
    const wife = getWife(out);
    const context = wife?.lastPatronContext;
    if (incident && context && context.createdAtSlot === state.slot) {
      out = updateWife(out, current => ({
        ...current,
        lastPatronContext: {
          ...(current.lastPatronContext || context),
          ...incidentContextFields(incident)
        }
      }));
    }
    if (!confusionPerception || !context
      || context.createdAtSlot !== state.slot
      || context.patronName !== scene?.customerName) return out;

    const priorRemarks = context.remarksUsedThisContext || [];
    const updatedContext = {
      ...(getWife(out)?.lastPatronContext || context),
      badGuestActualPatronId: confusionPerception.actualCustomer.id,
      badGuestActualPatronName: confusionPerception.actualCustomer.name,
      badGuestPerceivedPartnerId: confusionPerception.perceivedId,
      badGuestPerceivedPartnerName: confusionPerception.perceivedName,
      badGuestPerceivedPartnerType: confusionPerception.perceivedPartnerType,
      badGuestConfusionEpisodeId: effectOf(readData(state), 'confusion')?.episodeId ?? null,
      ...(suppressConfusedPlayerReaction && options?.walkedIn === true
        ? { badGuestSuppressCaughtIdentity: true }
        : {}),
      ...(suppressConfusedPlayerReaction && !incident && !priorRemarks.includes('__confronted__')
        ? { remarksUsedThisContext: [...priorRemarks, '__confronted__'] }
        : {})
    };
    out = updateWife(out, current => ({ ...current, lastPatronContext: updatedContext }));

    const meaningfulAct = STAGES.indexOf(context.maxStage) >= STAGES.indexOf('bold_touch');
    if (meaningfulAct && !context.badGuestConfusionReactionLogged) {
      const text = confusionPerception.perceivedPartnerType === 'player'
        ? `${withParticle(wifeDisplayName(out), '은', '는')} 흐릿한 눈으로 방금의 일을 되짚으며, 곁에 있던 사람이 그 손님이 아니라 당신이었다고 믿는 듯합니다.`
        : `${withParticle(wifeDisplayName(out), '은', '는')} 흐릿한 눈으로 방금의 일을 되짚으며, 곁에 있던 사람이 ${confusionPerception.perceivedName}이었다고 믿는 듯합니다.`;
      out = appendIntimateLog(out, text);
      out = updateWife(out, current => ({
        ...current,
        lastPatronContext: {
          ...(current.lastPatronContext || updatedContext),
          badGuestConfusionReactionLogged: true
        }
      }));
    }
    out = recordConfusionIncident(state, out, scene, confusionPerception, options);
    return suppressConfusedPlayerReaction && incident
      ? openBadGuestIncidentReaction(out, options, incident)
      : out;
  }

  function withAuthorizedRestraintEnd(customerId, reason, callback) {
    const previous = authorizedRestraintEndContext;
    authorizedRestraintEndContext = { customerId, reason, used: false };
    try {
      return callback();
    } finally {
      authorizedRestraintEndContext = previous;
    }
  }

  function resolveCompatibilityEndImpl(state, request = {}) {
    const scene = required.getActiveScene(state);
    const expectedCustomerId = request?.expectedCustomerId;
    if (!scene || expectedCustomerId == null
      || String(scene.customerId) !== String(expectedCustomerId)) return state;

    const restraint = equipmentOf(readData(state), 'restraint');
    const matchingRestraint = restraintOwnsCustomer(state, scene.customerId, restraint);
    if (matchingRestraint && request.releaseRestraint !== true) return state;

    let out = state;
    if (matchingRestraint) {
      const data = getData(out);
      setEquipment(data, 'restraint', null);
      data.deferredMovement = null;
      out = putData(out, data);
      if (out.pendingEvent?.type === 'bad_guest_restraint_rescue'
        && String(out.pendingEvent.customerId) === String(scene.customerId)) {
        out = { ...out, pendingEvent: undefined };
      }
    }

    if (matchingRestraint && tacticTickContext) tacticTickContext.restraintEscaped = true;
    const reason = request.reason || 'elena_refused';
    return withAuthorizedRestraintEnd(scene.customerId, reason, () => (
      wrappedEndPatronInteraction(out, reason, {
        ...(request.options || {}),
        badGuestCompatibilitySource: String(request.source || 'external')
      })
    ));
  }

  function resolveCompatibilityEnd(...args) {
    return runPublicProcess('compatibilityEnd', resolveCompatibilityEndImpl, args);
  }

  function drugBlocksShameStop(state) {
    return drugLevelAt(state) >= 50;
  }

  function ignoredPatronStop(state) {
    return { state, handled: false };
  }

  function wrappedPatronNaturalEnd(state, interaction, intent, wife) {
    const reason = original.patronControlNaturalEnd(state, interaction, intent, wife);
    if (reason
      && isBadGuest(state, interaction?.customerId)
      && BAD_GUEST_BLOCKED_END_REASONS.has(reason)
      && (interaction?.ticksElapsed ?? 0) < 90) {
      if (tacticTickContext) tacticTickContext.blockedNaturalEnd = true;
      return null;
    }
    if (reason && (interaction?.ticksElapsed ?? 0) >= 90 && tacticTickContext) {
      tacticTickContext.naturalTimeoutEndReason = reason;
    }
    return reason;
  }

  function wrappedPatronBoundaryStop(state, interaction, ...rest) {
    if (restraintOwnsCustomer(state, interaction?.customerId)) return null;
    return original.patronControlBoundaryStop(state, interaction, ...rest);
  }

  function wrappedPatronFatigueStop(state, interaction, ...rest) {
    if (restraintOwnsCustomer(state, interaction?.customerId)) return null;
    return original.patronControlFatigueStop(state, interaction, ...rest);
  }

  function withAuthorizedPatronClimax(state, callback) {
    const scene = required.getActiveScene(state);
    if (!restraintOwnsCustomer(state, scene?.customerId)) return callback();
    return withAuthorizedRestraintEnd(scene.customerId, 'patron_climax', callback);
  }

  function wrappedPatronClimax(state, ...rest) {
    return withAuthorizedPatronClimax(
      state,
      () => original.patronControlClimax(state, ...rest)
    );
  }

  function wrappedPatronAfterglow(state, ...rest) {
    return withAuthorizedPatronClimax(
      state,
      () => original.patronControlAfterglow(state, ...rest)
    );
  }

  function wrappedPatronPlayerReturnStop(state, interaction, ...rest) {
    if (restraintOwnsCustomer(state, interaction?.customerId)) return null;
    return original.patronControlPlayerReturnStop?.(state, interaction, ...rest) ?? null;
  }

  function wrappedPatronCoercionEscape(state) {
    const scene = required.getActiveScene(state);
    if (restraintOwnsCustomer(state, scene?.customerId)) return ignoredPatronStop(state);
    return original.patronControlCoercionEscape(state);
  }

  function wrappedPatronAcquaintanceStop(state) {
    const scene = required.getActiveScene(state);
    if (restraintOwnsCustomer(state, scene?.customerId)
      || equipmentApplies(state, 'blindfold', scene?.customerId)) return ignoredPatronStop(state);
    return original.patronControlAcquaintanceStop(state);
  }

  function wrappedPatronShameStop(state) {
    const scene = required.getActiveScene(state);
    if (drugBlocksShameStop(state)
      || restraintOwnsCustomer(state, scene?.customerId)
      || equipmentApplies(state, 'blindfold', scene?.customerId)) {
      return ignoredPatronStop(state);
    }
    return original.patronControlShameStop(state);
  }

  function wrappedPatronServiceInterrupt(state) {
    const scene = required.getActiveScene(state);
    if (drinkingGameOwnsCustomer(state, scene?.customerId)
      || restraintOwnsCustomer(state, scene?.customerId)) return null;
    return original.patronControlServiceInterrupt(state);
  }

  function wrappedPatronExposureRedress(state, interaction) {
    if (restraintOwnsCustomer(state, interaction?.customerId)) {
      return { state, ended: false };
    }
    return original.patronControlExposureRedress(state, interaction);
  }

  function wrappedPatronLineUp(state, interaction, customer, wife) {
    const previousContext = patronEscalationContext;
    const context = {
      customerId: interaction?.customerId,
      intimacyDecision: null,
      unassistedIntimacyDecision: null,
      actualIntimacyDecision: null,
      unassistedActualIntimacyDecision: null
    };
    patronEscalationContext = context;
    let result;
    try {
      result = original.patronControlLineUp(state, interaction, customer, wife);
    } finally {
      patronEscalationContext = previousContext;
    }
    if (context.intimacyDecision?.badGuestGaggedRefusal === true
      && context.intimacyDecision.outcome === 'refuse'
      && equipmentApplies(state, 'gag', interaction?.customerId)
      && (result?.state?.log?.length || 0) > (state.log?.length || 0)) {
      const logs = [...result.state.log];
      const last = logs.length - 1;
      logs[last] = {
        ...logs[last],
        text: gaggedRefusalResponseText(state, customer, 'genital_rubbing')
      };
      result = {
        ...result,
        state: { ...result.state, log: logs },
        badGuestGaggedRefusal: true
      };
    }
    if ((!result?.refused && !result?.endsInteraction)
      || !restraintOwnsCustomer(state, interaction?.customerId)) return result;
    return { ...result, endsInteraction: false, refused: false, badGuestRestrainedEndSuppressed: true };
  }

  function wrappedPatronPushIn(state, interaction, customer, wife) {
    const result = original.patronControlPushIn(state, interaction, customer, wife);
    if (!result?.refused || !restraintOwnsCustomer(state, interaction?.customerId)) return result;
    return { ...result, endsInteraction: false, refused: false, badGuestRestrainedEndSuppressed: true };
  }

  function wrappedPatronRelentChance(customer, kindnessCount, wife, offended) {
    if (forceAttemptContext
      && restraintOwnsCustomer(forceAttemptContext.state, customer?.id)) {
      return 0;
    }
    return original.patronControlRelentChance(customer, kindnessCount, wife, offended);
  }

  function presentHandcuffAlert(state, customer) {
    const wifeName = wifeDisplayName(state);
    const scene = required.getActiveScene(state);
    const stageLabel = scene?.customerId === customer.id ? STAGE_LABELS[scene.stage] : null;
    const title = `${withParticle(customer.name, '이', '가')} ${wifeName}에게 수갑을 채웠습니다.`;
    const body = `${withParticle(customer.name, '은', '는')} 그녀를 놓아주지 않습니다.${stageLabel ? ` 이미 ${stageLabel}까지 밀어붙였습니다.` : ''}`;
    const alert = {
      id: `bad_guest_handcuff:${customer.id}:${state.slot}`,
      kind: 'bad_guest_handcuff',
      severity: 'critical',
      pause: true,
      title,
      body,
      slot: state.slot,
      choices: [{ id: 'dismiss', label: '알겠습니다' }],
      tags: ['patron', 'restraint', 'danger']
    };
    if (state.pendingEvent) {
      if ((state.alertQueue || []).some(entry => entry.id === alert.id)) return state;
      return { ...state, alertQueue: [...(state.alertQueue || []), alert] };
    }
    return {
      ...state,
      pendingEvent: {
        type: 'alert',
        alert,
        customerId: '',
        customerName: title,
        text: body,
        choices: alert.choices.map(choice => ({ ...choice, description: '' }))
      }
    };
  }

  function confusedPlayerHandcuffText(state, customer, options = {}) {
    const wifeName = wifeDisplayName(state);
    const patronName = customer.name || '그 손님';
    const patronObject = withParticle(patronName, '을', '를');
    const patronTopic = withParticle(patronName, '은', '는');
    const wifeTopic = withParticle(wifeName, '은', '는');
    if (options.success) {
      if (options.wake) {
        return storyLine(state, `confused-player-handcuff:wake:success:${customer.id}`, [
          `${wifeTopic} 눈을 뜨며 ${patronObject} 당신으로 잘못 알아보지만 그의 손을 밀어냅니다. ${patronTopic} 그 손목을 낚아채 수갑을 채웁니다.`,
          `${wifeTopic} 눈앞의 사람을 알아본 듯하다가 닿아 오는 손을 밀어냅니다. ${patronTopic} 그 손목을 붙잡아 수갑을 채웁니다.`
        ]);
      }
      const opening = `${wifeTopic} ${patronObject} 당신으로 알고도 그의 손을 밀어냅니다.`;
      const ending = options.entersGroping
        ? '사슬이 당겨지며 그녀가 그의 앞으로 끌려갑니다.'
        : '그녀가 물러서려 하자 그가 길을 막습니다.';
      return storyLine(state, `confused-player-handcuff:success:${customer.id}:${options.forceable ? 'force' : 'eject'}`, [
        `${opening} ${patronTopic} 그 틈에 손목을 낚아채 수갑을 채웁니다. ${ending}`,
        `${wifeTopic} 익숙한 사람을 보듯 ${patronName}에게 시선을 두지만 그의 손은 밀어냅니다. ${patronTopic} 그 손목을 낚아채 수갑을 채웁니다. ${ending}`
      ]);
    }

    const escape = options.ejected
      ? `팔을 거칠게 뿌리치고 ${patronObject} 밀어냅니다.`
      : '손을 빼내고 그와 거리를 벌립니다.';
    if (options.wake) {
      return storyLine(state, `confused-player-handcuff:wake:failure:${customer.id}`, [
        `${wifeTopic} 눈을 뜨며 ${patronObject} 당신으로 잘못 알아보지만, 손목을 잡히자 ${escape}`,
        `${wifeTopic} 눈앞의 사람을 알아본 듯하다가 그가 수갑을 채우려 들자 ${escape}`
      ]);
    }
    return storyLine(state, `confused-player-handcuff:failure:${customer.id}:${options.forceable ? 'force' : 'eject'}`, [
      `${wifeTopic} ${patronObject} 당신으로 잘못 알아보지만, 손목을 잡히자 ${escape}`,
      `${wifeTopic} 익숙한 사람을 보듯 ${patronName}에게 시선을 두다가 수갑이 닿자 ${escape}`
    ]);
  }

  function confusedLoverHandcuffText(state, customer, options = {}, context = confusionLoverTargetContext(state, customer)) {
    if (!context) return null;
    const wifeName = wifeDisplayName(state);
    const wifeTopic = withParticle(wifeName, '은', '는');
    const patronObject = withParticle(customer.name, '을', '를');
    const patronPossessive = `${customer.name}의`;
    const address = context.samePerson
      ? `${customer.name}의 이름을`
      : `${customer.name}에게 ${context.perceivedCustomer.name}의 이름을`;
    const escape = options.ejected
      ? `팔을 거칠게 뿌리치고 ${patronObject} 밀어냅니다.`
      : '팔을 빼고 물러섭니다.';
    if (options.success) {
      if (options.wake) {
        return `${wifeTopic} 눈을 뜨며 ${address} 부르지만 ${patronPossessive} 손을 밀어냅니다. 그가 손목을 낚아채 수갑을 채웁니다.`;
      }
      const ending = options.entersGroping
        ? '사슬이 당겨지며 그녀가 그의 앞으로 끌려갑니다.'
        : '그녀가 물러서려 하자 그가 길을 막습니다.';
      return `${wifeTopic} ${address} 부르면서도 ${patronPossessive} 손을 밀어냅니다. 그가 손목을 낚아채 수갑을 채웁니다. ${ending}`;
    }
    if (options.wake) {
      return `${wifeTopic} 눈을 뜨며 ${address} 부르지만, 손목을 잡히자 ${escape}`;
    }
    return `${wifeTopic} ${address} 부르다가 손목을 잡히자 ${escape}`;
  }

  function confusionHandcuffText(state, customer, options = {}) {
    if (confusionPlayerDeceptionApplies(state, customer)) {
      return confusedPlayerHandcuffText(state, customer, options);
    }
    return confusedLoverHandcuffText(state, customer, options);
  }

  function confusedLoverEquipmentText(state, customer, kind, success, context) {
    const wifeName = wifeDisplayName(state);
    const wifeTopic = withParticle(wifeName, '은', '는');
    const wifeSubject = withParticle(wifeName, '이', '가');
    const patronSubject = withParticle(customer.name, '이', '가');
    const address = context.samePerson
      ? `${customer.name}의 이름을`
      : `${customer.name}에게 ${context.perceivedCustomer.name}의 이름을`;
    if (kind === 'blindfold') {
      if (success) {
        return `${wifeSubject} ${address} 부르는 사이, ${patronSubject} 눈가리개를 씌우고 뒤에서 묶습니다.`;
      }
      return `${wifeTopic} ${address} 부르다가 ${patronSubject} 천을 들이대자 고개를 돌립니다.`;
    }
    if (success) {
      return `${wifeSubject} ${address} 부르는 사이, ${patronSubject} 입마개를 물리고 뒤에서 묶습니다.`;
    }
    return `${wifeTopic} ${address} 부르다가 ${patronSubject} 입마개를 들이대자 얼굴을 돌립니다.`;
  }

  function equipmentAttemptText(state, customer, kind, success) {
    const wifeName = wifeDisplayName(state);
    const patronName = customer.name || '그 손님';
    const patronObject = withParticle(patronName, '을', '를');
    const patronTopic = withParticle(patronName, '은', '는');
    const wifeTopic = withParticle(wifeName, '은', '는');
    const wifeSubject = withParticle(wifeName, '이', '가');
    const loverContext = confusionLoverTargetContext(state, customer);
    if (loverContext) {
      return confusedLoverEquipmentText(state, customer, kind, success, loverContext);
    }
    if (!confusionPlayerDeceptionApplies(state, customer)) {
      if (kind === 'blindfold') {
        return success
          ? `${patronTopic} ${wifeName}의 눈을 천으로 가리고 단단히 묶습니다.`
          : `${patronTopic} 눈을 가리려 하지만 ${withParticle(wifeName, '이', '가')} 고개를 돌려 피합니다.`;
      }
      return success
        ? `${patronTopic} ${wifeName}의 입을 막고 뒤에서 매듭을 조입니다.`
        : `${patronTopic} 입을 막으려 하지만 ${withParticle(wifeName, '이', '가')} 얼굴을 돌려 벗어납니다.`;
    }

    if (kind === 'blindfold') {
      return success
        ? storyLine(state, `confused-player-blindfold:success:${customer.id}`, [
          `${wifeSubject} ${patronObject} 당신으로 잘못 알아보는 사이, ${patronTopic} 눈가리개를 씌우고 뒤에서 묶습니다.`,
          `${wifeTopic} 흐린 눈으로 ${patronName}에게 시선을 둡니다. ${patronTopic} 그 틈에 천으로 눈을 가리고 뒤에서 묶습니다.`
        ])
        : storyLine(state, `confused-player-blindfold:failure:${customer.id}`, [
          `${wifeTopic} ${patronObject} 당신으로 잘못 알아보지만, 그가 천을 들이대자 고개를 돌려 피합니다.`,
          `${wifeTopic} 흐린 눈으로 ${patronName}에게 시선을 두다가 눈가리개가 다가오자 손을 쳐 냅니다.`
        ]);
    }
    return success
      ? storyLine(state, `confused-player-gag:success:${customer.id}`, [
        `${wifeSubject} ${patronObject} 당신으로 잘못 알아보는 사이, ${patronTopic} 입마개를 물리고 뒤에서 묶습니다.`,
        `${wifeTopic} 흐린 눈으로 ${patronName} 곁에 머뭅니다. ${patronTopic} 그 틈에 입을 막고 뒤에서 매듭을 조입니다.`
      ])
      : storyLine(state, `confused-player-gag:failure:${customer.id}`, [
        `${wifeTopic} ${patronObject} 당신으로 잘못 알아보지만, 그가 입마개를 들이대자 얼굴을 돌려 벗어납니다.`,
        `${wifeTopic} 흐린 눈으로 ${patronName}에게 시선을 두다가 입마개가 닿자 고개를 세게 젓습니다.`
      ]);
  }

  function attemptHandcuffImpl(state, customer, options = {}) {
    const roomId = options.roomId || wifeLocation(state);
    const check = options.check || handcuffStrengthCheck(state, customer);
    let out = {
      ...state,
      customers: (state.customers || []).map(entry => entry.id === customer.id
        ? markCustomerAction(entry, state.slot, 'handcuff')
        : entry)
    };
    if (!check.success) return { state: out, success: false, check };

    const data = getData(out);
    const wife = getWife(out);
    setEquipment(data, 'restraint', {
      patronId: customer.id,
      patronName: customer.name,
      roomId,
      appliedAtSlot: out.slot,
      applicationSource: options.source || 'tactic',
      active: true,
      afterUntilSlot: null,
      applicationCheck: check,
      resumeTask: wife?.currentTask,
      resumeTaskTarget: wife?.taskTarget,
      resumeBusyUntilSlot: wife?.busyUntilSlot,
      resumeLocationUntilSlot: wife?.locationUntilSlot
    });
    out = putData(out, data);
    out = addEquipmentFear(out, customer, 'restraint');

    const scene = required.getActiveScene(out);
    if (scene?.customerId === customer.id) {
      const currentIndex = STAGES.indexOf(scene.stage);
      const gropingIndex = STAGES.indexOf('groping');
      const shouldAdvance = !options.preserveStage && currentIndex >= 0 && currentIndex < gropingIndex;
      const advancedScene = shouldAdvance
        ? {
            ...scene,
            stage: 'groping',
            stageFrom: scene.stage,
            stageBy: 'bad_guest_handcuff',
            ticksAtStage: 0
          }
        : scene;
      out = {
        ...out,
        activeScene: {
          ...(out.activeScene || {}),
          patron: {
            ...trackEligiblePatronMaxStage(scene, advancedScene, shouldAdvance),
            stalled: 0
          }
        }
      };
    }
    if (!options.suppressAlert) out = presentHandcuffAlert(out, customer);
    return { state: out, success: true, check };
  }


  function attemptHandcuff(...args) {
    return runPublicProcess('handcuffAttempt', attemptHandcuffImpl, args);
  }

  function equipmentAttemptKey(state, customer, kind) {
    const scene = required.getActiveScene(state);
    const sceneKey = scene?.customerId === customer.id
      ? `${scene.startedAtSlot ?? scene.startSlot ?? state.slot}:${scene.stageFrom ?? 'scene'}`
      : `${state.day ?? 0}:${customer.visitStartedAtSlot ?? customer.arrivedAtSlot ?? 'visit'}`;
    return `${customer.id}:${sceneKey}:${kind}`;
  }

  function attemptEquipmentImpl(state, customer, kind, options = {}) {
    if (!['blindfold', 'gag'].includes(kind) || !customer?.id) return { state, success: false, reason: 'invalid_equipment' };
    if (kind === 'gag'
      && (!equipmentApplies(state, 'restraint', customer.id)
        || !equipmentApplies(state, 'blindfold', customer.id))) {
      return { state, success: false, reason: 'gag_requires_restraint_and_blindfold' };
    }
    const interaction = required.getActiveScene(state);
    if (kind === 'gag'
      && interaction?.customerId === customer.id
      && wifeMouthActActive(interaction)) {
      return { state, success: false, reason: 'wife_mouth_act_active' };
    }
    const roomId = options.roomId || wifeLocation(state);
    if (!roomId || customerLocation(state, customer.id) !== roomId) return { state, success: false, reason: 'not_co_located' };
    if (!options.force
      && !options.allowPlayerPresent
      && playerInsideRoom(state, roomId)
      && !equipmentApplies(state, 'restraint', customer.id)) {
      return { state, success: false, reason: 'player_present' };
    }
    const data = getData(state);
    const key = equipmentAttemptKey(state, customer, kind);
    if (!options.force && data.equipment.attempts?.[key]) {
      return { state, success: false, reason: 'already_attempted' };
    }
    data.equipment = {
      ...data.equipment,
      attempts: { ...(data.equipment.attempts || {}), [key]: { slot: state.slot, patronId: customer.id, kind } }
    };
    const confusionRelationshipBonus = confusionEquipmentBonus(state, customer);
    const chance = clamp(0.5 + confusionRelationshipBonus, 0.05, 0.95);
    const roll = options.roll ?? Math.random();
    const success = roll < chance;
    const check = { chance, roll, success, confusionRelationshipBonus };
    let out = putData(state, data);
    out = {
      ...out,
      customers: (out.customers || []).map(entry => entry.id === customer.id
        ? markCustomerAction(entry, state.slot, kind)
        : entry)
    };
    if (!success) {
      return {
        state: appendDistressLog(out, equipmentAttemptText(out, customer, kind, false)),
        success: false,
        reason: 'roll_failed',
        check
      };
    }
    const nextData = getData(out);
    setEquipment(nextData, kind, {
      patronId: customer.id,
      patronName: customer.name,
      roomId,
      appliedAtSlot: state.slot,
      active: true,
      afterUntilSlot: null
    });
    out = putData(out, nextData);
    out = addEquipmentFear(out, customer, kind);
    if (!options.silent) {
      out = appendDistressLog(out, equipmentAttemptText(out, customer, kind, true));
    }
    return { state: out, success: true, reason: 'applied', check };
  }

  function attemptEquipment(...args) {
    return runPublicProcess('equipmentAttempt', attemptEquipmentImpl, args);
  }

  function isBackRoundEvent(event) {
    const ids = new Set((event?.choices || []).map(choice => choice.id));
    return event?.type === 'patron_offer'
      && ids.has('back_round_send_wife')
      && ids.has('back_round_go_yourself');
  }

  function wealthyPartyMembers(state, party = readData(state).wealthyParty) {
    const ids = wealthyPartyMemberIds(state, party);
    return (state.customers || []).filter(customer => ids.has(customer.id)
      && ACTIVE_CUSTOMER_STATUSES.has(customer.status)
      && customerLocation(state, customer.id) === 'back_room');
  }

  function lockWealthyPartyDoorImpl(state, party, patron) {
    const data = getData(state);
    data.doorLock = {
      patronId: patron.id,
      patronName: patron.name,
      roomId: 'back_room',
      appliedAtSlot: state.slot,
      active: true,
      lockedBy: 'wealthy_party'
    };
    data.wealthyParty = {
      ...party,
      doorLocked: true,
      doorLockedAtSlot: state.slot
    };
    return putData(state, data);
  }


  function lockWealthyPartyDoor(...args) {
    return runPublicProcess('wealthyPartyDoorLock', lockWealthyPartyDoorImpl, args);
  }

  function extendWealthyPartyService(state, party) {
    let out = updateWife(state, wife => ({
      ...wife,
      currentTask: 'serving',
      taskTarget: undefined,
      busyUntilSlot: party.endSlot,
      locationUntilSlot: party.endSlot
    }));
    if (wifeLocation(out) !== 'back_room') {
      bypassMoveWife = true;
      try {
        out = original.moveWife(out, 'back_room', party.endSlot, { skipModestyCheck: true });
      } finally {
        bypassMoveWife = false;
      }
    }
    return out;
  }

  function isWealthyPartyRestraint(state, restraint = equipmentOf(readData(state), 'restraint')) {
    const party = readData(state).wealthyParty;
    return Boolean(
      restraint?.active
      && party?.active
      && party.serveLocked
      && party.cuffPatronId === restraint.patronId
      && party.memberIds?.includes(restraint.patronId)
      && backRoomParty(state)
    );
  }

  function restraintOwnsCustomer(state, customerId, restraint = equipmentOf(readData(state), 'restraint')) {
    if (!restraint?.active || customerId == null) return false;
    if (String(restraint.patronId) === String(customerId)) return true;
    const data = readData(state);
    const party = data.wealthyParty;
    if (
      party?.active
      && String(party.cuffPatronId) === String(restraint.patronId)
      && party.memberIds?.some(id => String(id) === String(restraint.patronId))
      && party.memberIds?.some(id => String(id) === String(customerId))
    ) return true;
    return false;
  }

  function drinkingGameOwnsCustomer(state, customerId) {
    const game = readData(state).drinkingGame;
    return Boolean(
      game?.active
      && customerId != null
      && game.participantIds?.some(id => String(id) === String(customerId))
    );
  }

  function equipmentSituationActive(state, item, scene = required.getActiveScene(state)) {
    if (!item?.patronId) return false;
    if (scene?.customerId != null && equipmentOwnsCustomer(state, item, scene.customerId)) return true;

    const data = readData(state);
    const wealthyParty = data.wealthyParty;
    if (item.roomId === 'back_room'
      && wealthyParty?.active
      && wealthyParty.memberIds?.some(id => String(id) === String(item.patronId))
      && backRoomParty(state)) {
      return true;
    }

    const drinkingGame = data.drinkingGame;
    return Boolean(
      item.roomId === 'back_room'
      && drinkingGame?.active
      && drinkingGame.participantIds?.some(id => String(id) === String(item.patronId))
      && backRoomParty(state)
    );
  }

  function attemptWealthyPartyHandcuffsImpl(state, party, members) {
    if ((party.cuffAttemptedIds || []).length > 0 || members.length === 0) return state;
    const checks = members.map(customer => ({ customer, check: groupHandcuffStrengthCheck(state, customer) }));
    const winner = checks.find(entry => entry.check.success);
    let out = state;
    const failureResults = new Map();
    for (const entry of checks) {
      if (entry.check.success) continue;
      const failure = applyFailedHandcuffPenalty(out, entry.customer, entry.check);
      out = failure.state;
      failureResults.set(entry.customer.id, failure);
    }
    if (winner) {
      out = attemptHandcuff(out, winner.customer, {
        roomId: 'back_room',
        preserveStage: true,
        source: 'wealthy_party',
        check: winner.check
      }).state;
    }
    const attemptedIds = new Set(checks.map(entry => entry.customer.id));
    out = {
      ...out,
      customers: (out.customers || []).map(customer => attemptedIds.has(customer.id) ? {
        ...customer,
        badGuestLastActionSlot: out.slot,
        badGuestLastAction: 'group_handcuff'
      } : customer)
    };
    let data = getData(out);
    const currentParty = data.wealthyParty || party;
    data.wealthyParty = {
      ...currentParty,
      cuffAttemptedIds: checks.map(entry => entry.customer.id),
      cuffChecks: checks.map(entry => ({
        patronId: entry.customer.id,
        patronName: entry.customer.name,
        patronScore: entry.check.patronScore,
        wifeScore: entry.check.wifeScore,
        success: entry.check.success,
        failureKind: failureResults.get(entry.customer.id)?.kind
      })),
      cuffSucceeded: Boolean(winner),
      cuffPatronId: winner?.customer.id,
      serveLocked: Boolean(winner),
      noMoreDrinkRequests: Boolean(winner)
    };
    const winnerRestraint = equipmentOf(data, 'restraint');
    if (winner && winnerRestraint?.patronId === winner.customer.id) {
      setEquipment(data, 'restraint', {
        ...winnerRestraint,
        heldUntilPartyEnd: true,
        afterUntilSlot: null
      });
    }
    out = putData(out, data);
    const wifeName = wifeDisplayName(out);
    const confusedGroupMember = members.find(member => confusionPlayerDeceptionApplies(out, member));
    const confusedLoverGroupMember = members.find(member => confusionLoverTargetContext(out, member));
    const confusedPlayerLine = winner && confusionPlayerDeceptionApplies(out, winner.customer)
      ? storyLine(out, `confused-player-group-handcuff:success:${winner.customer.id}`, [
        `${withParticle(wifeName, '은', '는')} 앞에 선 ${withParticle(winner.customer.name, '을', '를')} 당신으로 잘못 알아봅니다. 차가운 금속 고리가 손목에서 닫히고, 나머지는 문과 탁자 사이를 막아섭니다.`,
        `${withParticle(wifeName, '은', '는')} 익숙한 사람을 보듯 ${winner.customer.name}에게 시선을 둡니다. 그가 손목에 수갑을 채우자 나머지 사내들이 길을 막습니다.`
      ])
      : !winner && confusedGroupMember
        ? storyLine(out, 'confused-player-group-handcuff:failure', [
          `${withParticle(wifeName, '은', '는')} 앞에 선 ${withParticle(confusedGroupMember.name, '을', '를')} 당신으로 잘못 알아보지만, 손목을 잡으려는 손을 뿌리치고 뒤이어 뻗는 손도 피합니다.`,
          `${withParticle(wifeName, '은', '는')} 흐린 눈으로 ${confusedGroupMember.name}에게 시선을 두다가 수갑이 닿자 손을 빼냅니다. 뒤이은 사내의 손도 비틀어 피합니다.`
        ])
        : null;
    const loverWinnerContext = winner
      ? confusionLoverTargetContext(out, winner.customer)
      : null;
    const loverFailureContext = !winner && confusedLoverGroupMember
      ? confusionLoverTargetContext(out, confusedLoverGroupMember)
      : null;
    const confusedLoverLine = loverWinnerContext
      ? (loverWinnerContext.samePerson
          ? `${withParticle(wifeName, '은', '는')} 앞에 선 ${winner.customer.name}의 이름을 부릅니다. 수갑이 손목에서 닫히자 다른 사내들이 문과 탁자 사이를 막아섭니다.`
          : `${withParticle(wifeName, '은', '는')} 앞에 선 ${winner.customer.name}에게 ${loverWinnerContext.perceivedCustomer.name}의 이름을 부릅니다. 수갑이 손목에서 닫히자 다른 사내들이 문과 탁자 사이를 막아섭니다.`)
      : loverFailureContext
        ? (loverFailureContext.samePerson
            ? `${withParticle(wifeName, '은', '는')} 앞에 선 ${confusedLoverGroupMember.name}의 이름을 부르다 손목을 잡으려는 손을 뿌리칩니다. 뒤이어 뻗는 손도 피합니다.`
            : `${withParticle(wifeName, '은', '는')} 앞에 선 ${confusedLoverGroupMember.name}에게 ${loverFailureContext.perceivedCustomer.name}의 이름을 부르다 손목을 잡으려는 손을 뿌리칩니다. 뒤이어 뻗는 손도 피합니다.`)
        : null;
    out = appendDistressLog(
      out,
      confusedPlayerLine || confusedLoverLine || (winner
        ? `문이 잠기자 다섯 사내가 차례로 ${wifeName}의 손목을 노립니다. ${winner.customer.name}의 차례에 차가운 금속 고리가 닫히고, 나머지는 문과 탁자 사이를 막아섭니다.`
        : `문이 잠긴 뒤 다섯 사내가 한 번씩 수갑을 채우려 들지만, ${withParticle(wifeName, '은', '는')} 번번이 손을 비틀어 빠져나갑니다.`)
    );
    if (winner) out = extendWealthyPartyService(out, readData(out).wealthyParty);
    return out;
  }


  function attemptWealthyPartyHandcuffs(...args) {
    return runPublicProcess('wealthyPartyHandcuffRound', attemptWealthyPartyHandcuffsImpl, args);
  }

  function handleWealthyPartyWifeSent(state) {
    let data = getData(state);
    let party = data.wealthyParty;
    if (!party?.active || wifeLocation(state) !== 'back_room') return state;
    const members = wealthyPartyMembers(state, party);
    if (!members.length) return state;
    party = {
      ...party,
      wifeVisits: (party.wifeVisits || 0) + 1,
      wifeVisitInProgress: true
    };
    data.wealthyParty = party;
    let out = putData(state, data);

    if (drugLevelAt(out) <= 0) {
      if ((party.drugAttempts || 0) >= members.length) {
        data = getData(out);
        data.wealthyParty = {
          ...data.wealthyParty,
          noMoreDrugAttempts: true,
          noMoreDrinkRequests: true
        };
        return appendLog(
          putData(out, data),
          `다섯 사내는 이미 한 번씩 잔을 권해 보았지만 뜻대로 되지 않았습니다. 이번에는 ${wifeDisplayName(out)}에게 더 머물라고 하지 않고 빈 잔만 거두어들입니다.`
        );
      }
      const patron = members[(party.drugAttempts || 0) % members.length];
      data = getData(out);
      data.wealthyParty = {
        ...data.wealthyParty,
        drugAttempts: (data.wealthyParty?.drugAttempts || 0) + 1
      };
      out = putData(out, data);
      out = appendLog(
        out,
        `${withParticle(patron.name, '은', '는')} 쟁반에서 잔을 하나 집어 ${wifeDisplayName(out)}에게 건넵니다. “우리만 마시면 예의가 아니지.” 다른 사내들이 문 쪽을 가린 사이, 잔 가장자리에서 낯선 냄새가 스칩니다.`
      );
      return beginDrugAttempt(
        out,
        patron,
        '부유한 나쁜 손님 단체의 뒷방 술자리',
        { wealthyParty: true }
      );
    }

    const leader = members[0];
    out = lockWealthyPartyDoor(out, readData(out).wealthyParty, leader);
    out = appendDistressLog(
      out,
      `${withParticle(leader.name, '은', '는')} ${withParticle(wifeDisplayName(out), '이', '가')} 잔을 내려놓는 순간 문 안쪽의 빗장을 내립니다. “이번에는 서두르지 않아도 되겠군.” 다섯 사람이 서로 자리를 바꾸며 ${withParticle(wifeDisplayName(out), '과', '와')} 출구 사이를 채웁니다.`
    );
    return attemptWealthyPartyHandcuffs(out, readData(out).wealthyParty, members);
  }

  function processWealthyPartyServeVisitImpl(state) {
    const data = getData(state);
    const party = data.wealthyParty;
    if (!party?.active) return state;
    if (wifeLocation(state) !== 'back_room') {
      if (!party.wifeVisitInProgress) return state;
      data.wealthyParty = { ...party, wifeVisitInProgress: false };
      return putData(state, data);
    }
    if (party.wifeVisitInProgress) return state;
    const wife = getWife(state);
    const isServingVisit = wife?.currentTask === 'serving'
      || (wife?.locationUntilSlot != null && wife?.busyUntilSlot != null);
    return isServingVisit ? handleWealthyPartyWifeSent(state) : state;
  }


  function processWealthyPartyServeVisit(...args) {
    return runPublicProcess('wealthyPartyServeVisit', processWealthyPartyServeVisitImpl, args);
  }

  function isBackRoomDoorLocked(state) {
    const lock = readData(state).doorLock;
    return Boolean(lock?.active && lock.roomId === 'back_room');
  }

  function prepareWealthyPartyTick(state) {
    const data = readData(state);
    const party = data.wealthyParty;
    const suppressDrinkRequests = Boolean(party?.active && party.noMoreDrinkRequests)
      || isBackRoomDoorLocked(state);
    if (!suppressDrinkRequests) return state;
    const room = state.locations?.back_room;
    const originalParty = room?.meta?.party;
    if (!originalParty) return state;
    let out = {
      ...state,
      locations: {
        ...(state.locations || {}),
        back_room: {
          ...room,
          meta: {
            ...(room.meta || {}),
            party: { ...originalParty, lastBeatSlot: state.slot }
          }
        }
      }
    };
    if (party?.active && party.serveLocked && party.endSlot != null) {
      out = updateWife(out, wife => ({
        ...wife,
        locationUntilSlot: Math.max(wife.locationUntilSlot ?? 0, party.endSlot + 1),
        busyUntilSlot: Math.max(wife.busyUntilSlot ?? 0, party.endSlot + 1)
      }));
    }
    return out;
  }

  function customizeWealthyPartyPrompt(state) {
    const data = readData(state);
    const party = data.wealthyParty;
    if (!isBackRoundEvent(state.pendingEvent)) return state;
    if (isBackRoomDoorLocked(state) || party?.noMoreDrinkRequests) {
      return { ...state, pendingEvent: undefined };
    }
    if (!party?.active) return state;
    const event = state.pendingEvent;
    const elapsed = Math.max(0, state.slot - party.startedAtSlot);
    const text = elapsed < 60
      ? `뒷방 문을 두드리는 소리가 세 번 납니다. 비단 조끼를 입은 사내가 문을 반쯤 열고 빈 잔 다섯 개를 내밉니다. “가장 좋은 술로 채우시오. 가능하면 ${wifeDisplayName(state)}에게 들려 보내고.” 방 안에서는 낮은 웃음이 이어집니다.`
      : `뒷방 문이 열리고 금반지를 낀 손이 빈 병을 바깥으로 내밉니다. “한 차례 더. ${withParticle(wifeDisplayName(state), '이', '가')} 직접 가져오면 술값 말고도 사례하지.” 사내들의 시선이 바 너머의 ${wifeDisplayName(state)}에게 한꺼번에 향합니다.`;
    return {
      ...state,
      pendingEvent: {
        ...event,
        customerName: '비단 외투의 사내들',
        text
      }
    };
  }

  function removeOccupants(state, ids) {
    const locations = {};
    for (const [roomId, room] of Object.entries(state.locations || {})) {
      locations[roomId] = {
        ...room,
        occupants: (room.occupants || []).filter(id => !ids.has(id))
      };
    }
    return { ...state, locations };
  }

  function finishWealthyPartyImpl(state, party, reason = 'time') {
    if (!party?.active) return state;
    const memberIds = new Set(party.memberIds || []);
    let out = state;
    const scene = required.getActiveScene(out);
    const partySceneWasActive = Boolean(scene && memberIds.has(scene.customerId));
    if (partySceneWasActive) {
      out = withAuthorizedRestraintEnd(scene.customerId, 'patron_satisfied', () => (
        wrappedEndPatronInteraction(out, 'patron_satisfied', { playerWitnessed: playerObservesRoom(out, 'back_room') })
      ));
    }
    const wifeUnresponsive = Boolean(unresponsiveDrugTarget(out));
    if (!wifeUnresponsive && wifeLocation(out) === 'back_room' && backRoomParty(out)) {
      out = required.finishBackRoomService(out);
    }
    const roster = (out.customers || [])
      .filter(customer => memberIds.has(customer.id))
      .sort((a, b) => party.memberIds.indexOf(a.id) - party.memberIds.indexOf(b.id))
      .map(wealthyPartyProfile);
    out = removeOccupants(out, memberIds);
    out = { ...out, customers: (out.customers || []).filter(customer => !memberIds.has(customer.id)) };
    const room = out.locations?.back_room;
    if (room?.meta?.party) {
      const { party: ignored, ...meta } = room.meta;
      out = {
        ...out,
        locations: {
          ...(out.locations || {}),
          back_room: { ...room, meta }
        }
      };
    }
    const data = getData(out);
    if (roster.length === CONFIG.wealthyPartySize) data.wealthyPartyRoster = roster;
    data.wealthyParty = null;
    setEquipment(data, 'restraint', null);
    data.deferredMovement = null;
    data.doorLock = null;
    out = putData(out, data);
    out = updateWife(out, wife => wifeUnresponsive
      ? wife
      : ({
          ...wife,
          currentTask: wife.currentTask === 'serving' || wife.currentTask === 'cuffed_still' ? 'idle' : wife.currentTask,
          taskTarget: undefined,
          busyUntilSlot: undefined,
          locationUntilSlot: undefined
        }));
    return appendDistressLog(
      out,
      reason === 'time'
        ? wifeUnresponsive
          ? `약속한 시간이 끝나자 비단 외투의 사내들이 하나씩 자리에서 일어납니다. 마지막 사내가 안쪽 빗장을 풀고 수갑 열쇠를 탁자 위에 내려놓습니다. ${withParticle(wifeDisplayName(out), '은', '는')} 뒷방에서 아직 눈을 뜨지 못합니다. 다섯 사람은 남은 금화를 챙겨 밤거리로 사라집니다.`
          : `약속한 시간이 끝나자 비단 외투의 사내들이 하나씩 자리에서 일어납니다. 마지막 사내가 안쪽 빗장을 풀고 수갑 열쇠를 탁자 위에 내려놓습니다. ${withParticle(wifeDisplayName(out), '은', '는')} 손목을 문지르며 홀로 돌아오고, 다섯 사람은 남은 금화를 챙겨 밤거리로 사라집니다.`
        : `부유한 사내들의 모임이 끝납니다. 안쪽 빗장이 열리고 ${wifeDisplayName(out)}의 손목을 묶고 있던 수갑도 풀립니다.`
    );
  }


  function finishWealthyParty(...args) {
    return runPublicProcess('wealthyPartyFinish', finishWealthyPartyImpl, args);
  }

  function wrappedForceAttemptChance(customer, kindnessCount, targetStage) {
    const base = original.forceAttemptChance(customer, kindnessCount, targetStage);
    if (!forceAttemptContext) return base;
    if (restraintOwnsCustomer(
      forceAttemptContext.state,
      forceAttemptContext.customer?.id
    )) return CONFIG.cuffedForceAttemptChance;
    return base;
  }

  const BAD_GUEST_MOVE_SHARES = {
    groping: {
      intimate: 0.16,
      handjob_patron: 0.42,
      blowjob_patron: 0.42
    },
    intimate: {
      handjob_patron: 0.30,
      blowjob_patron: 0.315,
      rubbing_patron: 0.236,
      sex_patron: 0.149
    },
    handjob_patron: {
      blowjob_patron: 0.30,
      rubbing_patron: 0.395,
      sex_patron: 0.248,
      intimate: 0.057
    },
    blowjob_patron: {
      rubbing_patron: 0.585,
      sex_patron: 0.315,
      handjob_patron: 0.05,
      intimate: 0.05
    },
    rubbing_patron: {
      sex_patron: 0.735,
      anal: 0.175,
      blowjob_patron: 0.03,
      handjob_patron: 0.03,
      intimate: 0.03
    },
    sex_patron: {
      hold: 0.80,
      anal: 0.20
    }
  };

  const BAD_GUEST_SKIP_GATES = {
    intimate: [['groping']],
    handjob_patron: [['groping']],
    blowjob_patron: [['groping'], ['handjob_patron']],
    rubbing_patron: [['groping'], ['intimate', 'handjob_patron', 'blowjob_patron']],
    sex_patron: [['groping'], ['intimate', 'handjob_patron', 'blowjob_patron', 'rubbing_patron']]
  };

  function badGuestSkipDistance(interaction, target) {
    const currentIndex = STAGES.indexOf(interaction.stage);
    const alreadyReached = stage => STAGES.indexOf(stage) <= currentIndex
      || (stage === 'handjob_patron' && interaction.watchedHimStroke === true);
    return (BAD_GUEST_SKIP_GATES[target] || [])
      .filter(group => !group.some(alreadyReached))
      .length;
  }

  function restoreBadGuestPredictiveHold(candidate, interaction) {
    const move = candidate?.move;
    if (move?.kind !== 'hold' || !move.wanted || move.wanted === interaction.stage) return candidate;
    return {
      ...candidate,
      move: {
        kind: 'rung',
        target: move.wanted,
        skipDistance: badGuestSkipDistance(interaction, move.wanted)
      }
    };
  }

  function badGuestMoveKey(move, stage) {
    if (move?.kind === 'rung') return move.target;
    if (move?.kind === 'anal') return 'anal';
    if (stage === 'sex_patron' && move?.kind === 'hold' && move.wanted === 'sex_patron') return 'hold';
    return null;
  }

  function gagBlocksWifeMouthMove(move) {
    return (move?.kind === 'rung' && move.target === 'blowjob_patron')
      || (move?.kind === 'hold' && move.wanted === 'blowjob_patron');
  }

  function wifeMouthActActive(interaction) {
    if (interaction?.stage === 'blowjob_patron') return true;
    return Object.values(interaction?.joinedPatronSlots || {}).includes('mouth');
  }

  function filterGagBlockedPatronMoves(state, interaction, candidates) {
    if (!equipmentApplies(state, 'gag', interaction?.customerId)) return candidates;
    return candidates.filter(candidate => !gagBlocksWifeMouthMove(candidate?.move));
  }

  function wrappedBuildPatronMoveCandidates(state, interaction, customer, wife) {
    const nativeCandidates = filterGagBlockedPatronMoves(
      state,
      interaction,
      original.buildPatronMoveCandidates(state, interaction, customer, wife)
    );
    const shares = BAD_GUEST_MOVE_SHARES[interaction?.stage];
    if (!shares || !isBadGuest(state, customer)) return nativeCandidates;
    const candidates = nativeCandidates.map(candidate => restoreBadGuestPredictiveHold(candidate, interaction));

    if (interaction.stage === 'sex_patron') {
      const hold = candidates.find(candidate => badGuestMoveKey(candidate.move, interaction.stage) === 'hold');
      const stay = { move: hold?.move || { kind: 'hold', wanted: 'sex_patron' }, weight: shares.hold };
      if (interaction.primarySlot === 'inside_anal') return [stay];
      return [stay, { move: { kind: 'anal' }, weight: shares.anal }];
    }

    const configured = [];
    const preserved = [];
    for (const candidate of candidates) {
      const key = badGuestMoveKey(candidate.move, interaction.stage);
      if (key && shares[key] != null) configured.push({ ...candidate, key });
      else preserved.push(candidate);
    }
    if (!configured.length) return candidates;

    const availableShare = configured.reduce((sum, candidate) => sum + shares[candidate.key], 0);
    const originalConfiguredWeight = configured.reduce((sum, candidate) => sum + candidate.weight, 0);
    const reweighted = configured.map(candidate => ({
      move: candidate.move,
      weight: originalConfiguredWeight * shares[candidate.key] / availableShare
    }));
    return [...reweighted, ...preserved];
  }

  function clearCuffedForceDecision(state, customerId) {
    let changed = false;
    const customers = (state.customers || []).map(customer => {
      if (customer.id !== customerId || !customer.forceDecidedTonight || customer.forceDecidedTonight === 'yielded') {
        return customer;
      }
      changed = true;
      const clean = { ...customer };
      delete clean.forceDecidedTonight;
      return clean;
    });
    return changed ? { ...state, customers } : state;
  }

  function replacePatronScene(state, scene) {
    return {
      ...state,
      activeScene: { ...(state.activeScene || {}), patron: scene }
    };
  }

  const GROUP_SLOT_ACT_IDS = {
    hand: 'handjob',
    mouth: 'blowjob',
    breasts: 'breast_worship',
    behind: 'groping',
    rubbing: 'thigh_job',
    inside: 'sex',
    astride: 'riding',
    inside_anal: 'anal'
  };

  function groupSlotActId(slot) {
    return GROUP_SLOT_ACT_IDS[slot] || 'groping';
  }

  function forcedGroupJoinText(state, participant, sceneBefore, roleSlot, reason) {
    const wifeName = wifeDisplayName(state);
    const leadName = sceneBefore.customerName || '먼저 다가선 손님';
    const openings = {
      hand: `${withParticle(participant.name, '은', '는')} ${leadName}의 어깨 너머로 손을 뻗어 ${wifeName}의 손목을 자기 쪽으로 끌어당깁니다.`,
      mouth: `${withParticle(participant.name, '은', '는')} ${leadName} 곁으로 바짝 다가서더니 ${wifeName}의 턱을 붙잡아 자신을 보게 합니다.`,
      breasts: `${withParticle(participant.name, '은', '는')} 옆자리를 비집고 들어와 ${wifeName}의 옷깃 안으로 손을 밀어 넣습니다.`,
      behind: `${withParticle(participant.name, '은', '는')} 뒤로 돌아가 ${wifeName}의 허리와 어깨를 붙잡고 움직임을 막습니다.`,
      rubbing: `${withParticle(participant.name, '은', '는')} ${leadName} 옆에 자리를 잡고 ${wifeName}의 몸에 거칠게 허리를 밀착합니다.`,
      inside: `${withParticle(participant.name, '은', '는')} 기다렸다는 듯 앞으로 나서 ${withParticle(leadName, '과', '와')} 자리를 나눠 차지합니다.`,
      astride: `${withParticle(participant.name, '은', '는')} ${wifeName}의 몸을 돌려 자기 쪽으로 끌어당기며 ${leadName} 곁에 자리를 잡습니다.`,
      inside_anal: `${withParticle(participant.name, '은', '는')} ${wifeName}의 뒤쪽으로 파고들어 ${withParticle(leadName, '과', '와')} 함께 달아날 틈을 막습니다.`,
      watching: `${withParticle(participant.name, '은', '는')} 가까이 다가와 도망칠 길을 막은 채 두 사람을 지켜봅니다.`
    };
    const restraintText = reason === 'restraint'
      ? `${withParticle(wifeName, '은', '는')} 묶인 손을 빼내지 못한 채 두 사람 사이에 붙들립니다.`
      : `${withParticle(wifeName, '은', '는')} 앞선 몸싸움에 눌린 채 새로 끼어든 손님까지 밀어내지 못합니다.`;
    return `${openings[roleSlot] || openings.behind} ${restraintText}`;
  }

  function stripNativeGroupJoinLog(afterState, beforeState) {
    const beforeLength = beforeState.log?.length || 0;
    if ((afterState.log?.length || 0) <= beforeLength) return afterState;
    return {
      ...afterState,
      log: [...(beforeState.log || [])],
      logSeq: beforeState.logSeq ?? beforeLength
    };
  }

  function recordForcedGroupJoinImpl(state, sceneBefore, participantId, reason) {
    const participant = state.customers?.find(customer => customer.id === participantId);
    const scene = required.getActiveScene(state);
    if (!participant || !scene) return state;
    const roleSlot = scene.joinedPatronSlots?.[participantId] || 'behind';
    const record = {
      participantId,
      participantName: participant.name,
      primaryPatronId: sceneBefore.customerId,
      primaryPatronName: sceneBefore.customerName,
      joinedAtSlot: state.slot,
      day: state.day,
      stage: scene.stage,
      roleSlot,
      actId: groupSlotActId(roleSlot),
      reason,
      status: 'joined'
    };
    const forcedIds = [...new Set([...(scene.badGuestForcedJoinIds || []), participantId])];
    const forcedRecords = {
      ...(scene.badGuestForcedJoinRecords || {}),
      [participantId]: record
    };
    let out = replacePatronScene(state, {
      ...scene,
      badGuestForcedGroup: true,
      badGuestForcedJoinIds: forcedIds,
      badGuestForcedJoinRecords: forcedRecords
    });

    out = reportQualifiedVisit(out, {
      customerId: participant.id,
      customerName: participant.name,
      startedAtSlot: scene.startedAtSlot ?? state.slot,
      coercedSinceSlot: state.slot
    }, { coerced: true });

    out = wrappedRecordIntimateHistory(out, {
      actId: record.actId,
      partner: participant.name,
      partnerType: 'patron',
      day: state.day,
      slot: state.slot,
      reception: 'hesitant',
      orgasmed: false,
      husbandWitnessed: getLocationOf(state, 'player') === wifeLocation(state),
      coerced: true,
      group: true,
      groupRole: roleSlot
    });
    out = required.recordPatronMistreatment(out, participant);
    return appendDistressLog(
      out,
      forcedGroupJoinText(out, participant, sceneBefore, roleSlot, reason)
    );
  }


  function recordForcedGroupJoin(...args) {
    return runPublicProcess('forcedGroupJoin', recordForcedGroupJoinImpl, args);
  }

  function updateForcedGroupRecord(state, participantId, patch) {
    const scene = required.getActiveScene(state);
    let out = state;
    if (scene?.badGuestForcedJoinRecords?.[participantId]) {
      out = replacePatronScene(out, {
        ...scene,
        badGuestForcedJoinRecords: {
          ...scene.badGuestForcedJoinRecords,
          [participantId]: { ...scene.badGuestForcedJoinRecords[participantId], ...patch }
        }
      });
    }
    return out;
  }

  const GAG_BLOCKED_GROUP_MOUTH_ID = '__badguest_gag_blocked_mouth__';

  function reserveGagBlockedGroupMouth(state) {
    const scene = required.getActiveScene(state);
    if (!scene) return state;
    return replacePatronScene(state, {
      ...scene,
      joinedPatronIds: [...new Set([
        ...(scene.joinedPatronIds || []),
        GAG_BLOCKED_GROUP_MOUTH_ID
      ])],
      joinedPatronSlots: {
        ...(scene.joinedPatronSlots || {}),
        [GAG_BLOCKED_GROUP_MOUTH_ID]: 'mouth'
      }
    });
  }

  function releaseGagBlockedGroupMouth(state) {
    const scene = required.getActiveScene(state);
    if (!scene) return state;
    const joinedPatronIds = (scene.joinedPatronIds || [])
      .filter(id => id !== GAG_BLOCKED_GROUP_MOUTH_ID);
    const joinedPatronSlots = { ...(scene.joinedPatronSlots || {}) };
    delete joinedPatronSlots[GAG_BLOCKED_GROUP_MOUTH_ID];
    const cleaned = { ...scene };
    if (joinedPatronIds.length) cleaned.joinedPatronIds = joinedPatronIds;
    else delete cleaned.joinedPatronIds;
    if (Object.keys(joinedPatronSlots).length) cleaned.joinedPatronSlots = joinedPatronSlots;
    else delete cleaned.joinedPatronSlots;
    return replacePatronScene(state, cleaned);
  }

  const GROUP_HISTORY_CATEGORY = Object.freeze({
    hand: 'handjob_patron',
    mouth: 'blowjob_patron',
    breasts: 'touch_breasts',
    behind: 'groping',
    rubbing: 'rubbing_patron',
    inside: 'sex_patron',
    astride: 'sex_patron',
    inside_anal: 'sex_patron'
  });

  function recordJoinedAcceptance(before, after, customerId) {
    const scene = required.getActiveScene(after);
    const customer = after.customers?.find(entry => String(entry.id) === String(customerId));
    const category = GROUP_HISTORY_CATEGORY[scene?.joinedPatronSlots?.[customerId]];
    if (!customer || !category || scene?.badGuestForcedJoinIds?.includes(customerId)) return after;
    const aphrodisiac = activeAphrodisiacEffect(before);
    const aphroDecision = latestAphrodisiacAcceptance;
    const confusion = confusionPerceptionForPatron(before, customerId);
    const perceivedDecision = latestConfusionPerceivedAcceptance;
    const actualDecision = latestConfusionActualAcceptance;
    const aphroMatch = aphrodisiac && aphroDecision?.episodeId === aphrodisiac.episodeId
      && aphroDecision.slot === before.slot
      && String(aphroDecision.customerId) === String(customerId)
      && acceptanceAnswer(aphroDecision.decision) === 'yes';
    let aphrodisiacAssisted = false;
    const confusionMatch = confusion
      && perceivedDecision?.episodeId === effectOf(readData(before), 'confusion')?.episodeId
      && perceivedDecision?.slot === before.slot
      && String(perceivedDecision.customerId) === String(customerId)
      && acceptanceAnswer(perceivedDecision.decision) === 'yes';
    if (!aphroMatch && !confusionMatch) return after;
    const data = getData(after);
    if (aphroMatch) {
      const unassistedAnswer = acceptanceAnswer(aphroDecision.unassistedDecision);
      aphrodisiacAssisted = unassistedAnswer === 'no';
      const unassistedActualAnswer = acceptanceAnswer(
        projectedUnassistedDecision(aphroDecision.actualDecision)
          || aphroDecision.unassistedDecision
      );
      appendAphrodisiacMemoryEvent(data, before, customer, category, 'yes', {
        decisionCategory: aphroDecision.category,
        historySlot: scene.joinedPatronSlots[customerId],
        outcome: aphroDecision.decision?.outcome ?? null,
        unassistedAnswer,
        unassistedOutcome: aphroDecision.unassistedDecision?.outcome ?? null,
        unassistedActualAnswer,
        drugChangedOutcome: unassistedAnswer === 'no',
        factualDrugChangedOutcome: unassistedActualAnswer === 'no',
        given: unassistedAnswer === 'yes'
      });
      latestAphrodisiacAcceptance = null;
    }
    if (confusionMatch) {
      const actualSubject = { id: customer.id, name: customer.name, type: 'patron' };
      const perceivedSubject = {
        id: confusion.perceivedId,
        name: confusion.perceivedName,
        type: confusion.perceivedPartnerType
      };
      ensureConfusionMemoryBaseline(data, before, actualSubject, category);
      ensureConfusionMemoryBaseline(data, before, perceivedSubject, category);
      noteConfusionRecoveryEvidence(data, before, confusion, category);
      const actualAnswer = acceptanceAnswer(actualDecision?.decision);
      appendConfusionMemoryEvent(data, before, actualSubject, perceivedSubject, category, 'yes', {
        decisionCategory: perceivedDecision.category,
        historySlot: scene.joinedPatronSlots[customerId],
        actualAnswer,
        actualOutcome: actualDecision?.decision?.outcome ?? null,
        perceivedOutcome: perceivedDecision.decision?.outcome ?? null,
        counterfactualGiven: actualAnswer === 'yes'
      });
      latestConfusionActualAcceptance = null;
      latestConfusionPerceivedAcceptance = null;
    }
    const out = putData(after, data);
    return aphrodisiacAssisted || confusionMatch
      ? reportQualifiedVisit(out, {
          customerId: customer.id,
          customerName: customer.name,
          startedAtSlot: scene.startedAtSlot
        })
      : out;
  }

  function recordNewJoinedAcceptances(before, after) {
    const previous = new Set(required.getActiveScene(before)?.joinedPatronIds || []);
    const joined = required.getActiveScene(after)?.joinedPatronIds || [];
    let out = after;
    for (const id of joined) {
      if (!previous.has(id)) out = recordJoinedAcceptance(before, out, id);
    }
    return out;
  }

  function wrappedProcessPatronGroupJoin(state) {
    const initialScene = required.getActiveScene(state);
    if (!initialScene) return original.processPatronGroupJoin(state);
    const initialCrowd = initialScene.crowdPatronIds || [];
    const badCrowd = initialCrowd.filter(id => isBadGuest(state, id));
    const gagBlocksOralGiving = equipmentApplies(state, 'gag', initialScene.customerId);
    if (!badCrowd.length) {
      if (!gagBlocksOralGiving) return recordNewJoinedAcceptances(state, original.processPatronGroupJoin(state));
      return recordNewJoinedAcceptances(state, releaseGagBlockedGroupMouth(
        original.processPatronGroupJoin(reserveGagBlockedGroupMouth(state))
      ));
    }

    const recentCoercion = initialScene.coercedSinceSlot != null
      && state.slot - initialScene.coercedSinceSlot <= 15;
    const restraint = equipmentOf(readData(state), 'restraint');
    const restraintInRoom = restraint?.active && restraint.roomId === wifeLocation(state);
    const forceAcceptance = recentCoercion || restraintInRoom;
    const attemptsPerGuest = isBadGuest(state, initialScene.customerId)
      ? CONFIG.badGuestPairGroupJoinAttemptsPerGuest
      : CONFIG.badGuestGroupJoinAttemptsPerGuest;
    const maxAttempts = Math.max(
      1,
      badCrowd.length * attemptsPerGuest
    );
    let out = state;

    for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
      const beforeAttempt = out;
      const scene = required.getActiveScene(out);
      if (!scene) break;
      const joined = new Set(scene.joinedPatronIds || []);
      const finished = new Set(scene.finishedParticipantIds || []);
      const candidates = (scene.crowdPatronIds || []).filter(id =>
        isBadGuest(out, id)
        && !joined.has(id)
        && !finished.has(id)
      );
      if (!candidates.length) break;

      const temporaryScene = {
        ...scene,
        kind: 'solo',
        crowdPatronIds: candidates
      };
      delete temporaryScene.coercedSinceSlot;
      const temporaryState = gagBlocksOralGiving
        ? reserveGagBlockedGroupMouth(replacePatronScene(out, temporaryScene))
        : replacePatronScene(out, temporaryScene);
      const previousContext = groupJoinContext;
      groupJoinContext = {
        candidateIds: new Set(candidates),
        forceAcceptance
      };
      let next;
      try {
        next = original.processPatronGroupJoin(temporaryState);
      } finally {
        groupJoinContext = previousContext;
      }
      if (gagBlocksOralGiving) next = releaseGagBlockedGroupMouth(next);

      const nextScene = required.getActiveScene(next);
      if (!nextScene) break;
      const newlyJoined = (nextScene.joinedPatronIds || []).filter(id => !joined.has(id));
      if (forceAcceptance && newlyJoined.length) {
        next = stripNativeGroupJoinLog(next, out);
      }
      const restoredScene = {
        ...required.getActiveScene(next),
        kind: scene.kind,
        crowdPatronIds: [...new Set([
          ...(scene.crowdPatronIds || []),
          ...(required.getActiveScene(next).crowdPatronIds || [])
        ])]
      };
      if (scene.coercedSinceSlot == null) delete restoredScene.coercedSinceSlot;
      else restoredScene.coercedSinceSlot = scene.coercedSinceSlot;
      const joinedBefore = joined.size;
      out = replacePatronScene(next, restoredScene);
      if (!forceAcceptance) out = recordNewJoinedAcceptances(beforeAttempt, out);
      if (forceAcceptance) {
        const reason = restraintInRoom ? 'restraint' : 'recent_coercion';
        for (const participantId of newlyJoined) {
          out = recordForcedGroupJoin(out, scene, participantId, reason);
        }
      }
      const joinedAfter = (restoredScene.joinedPatronIds || []).length;
      if (joinedAfter > joinedBefore) continue;
    }
    return out;
  }

  function wrappedProcessPatronGroupParticipants(state) {
    const beforeScene = required.getActiveScene(state);
    const beforeJoined = new Set(beforeScene?.joinedPatronIds || []);
    const out = original.processPatronGroupParticipants(state);
    if (!beforeScene?.badGuestForcedGroup || !beforeJoined.size) return out;
    const afterScene = required.getActiveScene(out);
    const afterJoined = new Set(afterScene?.joinedPatronIds || []);
    const finished = [...beforeJoined].filter(id => !afterJoined.has(id));
    let next = out;
    for (const participantId of finished) {
      if (!beforeScene.badGuestForcedJoinIds?.includes(participantId)) continue;
      const participant = state.customers?.find(customer => customer.id === participantId);
      next = updateForcedGroupRecord(next, participantId, {
        status: 'finished_as_helper',
        finishedAtSlot: state.slot
      });
      next = appendDistressLog(
        next,
        `${withParticle(participant?.name || '뒤늦게 끼어든 손님', '은', '는')} 먼저 숨을 몰아쉬며 한 걸음 물러섭니다. 다른 손님은 아직 ${withParticle(wifeDisplayName(next), '을', '를')} 놓아주지 않습니다.`
      );
    }
    return next;
  }

  function wrappedRotatePatronGroupAfterPrimary(state, interaction, outcome) {
    const beforeScene = required.getActiveScene(state) || interaction;
    const out = original.rotatePatronGroupAfterPrimary(state, interaction, outcome);
    if (!out || !beforeScene?.badGuestForcedGroup) return out;
    const afterScene = required.getActiveScene(out);
    if (!afterScene || afterScene.customerId === beforeScene.customerId) return out;
    const nextCustomer = out.customers?.find(customer => customer.id === afterScene.customerId);
    if (!beforeScene.badGuestForcedJoinIds?.includes(afterScene.customerId)) return out;
    let next = updateForcedGroupRecord(out, afterScene.customerId, {
      status: 'promoted_to_primary',
      promotedAtSlot: state.slot,
      previousPrimaryId: beforeScene.customerId
    });
    const updatedScene = required.getActiveScene(next);
    next = replacePatronScene(next, {
      ...updatedScene,
      badGuestForcedTurnOrder: [
        ...(updatedScene.badGuestForcedTurnOrder || [beforeScene.customerId]),
        afterScene.customerId
      ]
    });
    return appendDistressLog(
      next,
      `${withParticle(beforeScene.customerName, '이', '가')} 거친 숨을 고르며 물러나자, ${withParticle(nextCustomer?.name || afterScene.customerName, '이', '가')} 기다렸다는 듯 그 자리를 차지합니다.`
    );
  }

  function tryEscapeCuffsAfterNegativeDecisionImpl(state, interaction, customer, targetStage, escalationContext = patronEscalationContext) {
    const decisionScore = Number(escalationContext?.intimacyDecision?.score);
    if (!escalationContext
      || escalationContext.customerId !== customer?.id
      || !Number.isFinite(decisionScore)
      || decisionScore >= 0
      || escalationContext.escapeChecked) {
      return null;
    }
    escalationContext.escapeChecked = true;
    const restraint = equipmentOf(readData(state), 'restraint');
    if (!restraintOwnsCustomer(state, customer.id, restraint)) return null;
    const check = handcuffEscapeCheck(state, customer, true);
    escalationContext.escapeCheck = check;
    if (!check.success) return null;

    const forcefullyEjected = check.margin >= 20;
    const kind = forcefullyEjected ? 'ejected' : 'trouble';
    const data = getData(state);
    setEquipment(data, 'restraint', null);
    let out = putData(state, data);
    if (out.pendingEvent?.type === 'bad_guest_restraint_rescue'
      && out.pendingEvent.customerId === customer.id) {
      out = { ...out, pendingEvent: undefined };
    }
    out = appendDistressLog(
      out,
      `${withParticle(wifeDisplayName(out), '은', '는')} 필사적으로 손목을 비틀어 수갑에서 손을 빼냅니다. 차가운 고리가 바닥에 떨어지며 짧은 쇳소리를 냅니다.`
    );
    if (tacticTickContext) tacticTickContext.restraintEscaped = true;
    out = required.recordPatronMistreatment(out, customer);
    out = {
      ...out,
      customers: (out.customers || []).map(entry => entry.id === customer.id
        ? { ...entry, forceDecidedTonight: kind }
        : entry)
    };
    if (!forcefullyEjected) {
      out = wrappedAddFeeling(out, 'anger', {
        intensity: 55,
        source: `patron:${customer.name.toLowerCase()}:cuff_escape_trouble`,
        target: { kind: 'patron', id: customer.name.toLowerCase() },
        durationSlots: 280
      });
    }
    const wifeName = wifeDisplayName(out);
    const gagged = equipmentApplies(state, 'gag', customer.id);
    const logOverride = forcefullyEjected
      ? (gagged
        ? `${withParticle(wifeName, '은', '는')} 곧바로 ${withParticle(customer.name, '을', '를')} 거칠게 밀어내고 문 쪽을 가리킵니다. 입마개 너머로 거친 숨이 샙니다.`
        : `${withParticle(wifeName, '은', '는')} 곧바로 ${withParticle(customer.name, '을', '를')} 거칠게 밀어냅니다. “당장 나가요. 다시는 가까이 오지 마요.”`)
      : (gagged
        ? `${withParticle(wifeName, '은', '는')} ${withParticle(customer.name, '을', '를')} 뿌리치고 방을 빠져나갑니다. 문틀을 세게 두드리자 사람들이 고개를 돌립니다.`
        : `${withParticle(wifeName, '은', '는')} ${withParticle(customer.name, '을', '를')} 뿌리치고 방을 빠져나가며 큰 소리로 도움을 청합니다.`);
    escalationContext.escapeSucceeded = true;
    return {
      state: out,
      kind,
      logOverride,
      endsInteraction: true,
      patronStays: !forcefullyEjected,
      coerced: false,
      badGuestRestraintBrokenByRefusal: true,
      targetStage
    };
  }


  function tryEscapeCuffsAfterNegativeDecision(...args) {
    return runPublicProcess('handcuffEscape', tryEscapeCuffsAfterNegativeDecisionImpl, args);
  }

  function wrappedResolvePatronForce(state, interaction, customer, wife, targetStage, offended) {
    const restraint = equipmentOf(readData(state), 'restraint');
    const matchingRestraint = interaction?.customerId === customer?.id
      && restraintOwnsCustomer(state, customer?.id, restraint);
    if (matchingRestraint) {
      state = reportQualifiedVisit(state, interaction, { coerced: true });
      if (patronEscalationContext
        && patronEscalationContext.customerId === customer.id) {
        patronEscalationContext.forceCalled = true;
      }
      const escape = tryEscapeCuffsAfterNegativeDecision(
        state,
        interaction,
        customer,
        targetStage
      );
      if (escape) {
        if (patronEscalationContext) patronEscalationContext.forceResultKind = escape.kind;
        return escape;
      }
      const retryState = clearCuffedForceDecision(state, customer.id);
      const retryCustomer = retryState.customers?.find(entry => entry.id === customer.id) || customer;
      const previousContext = forceAttemptContext;
      let originalResult;
      forceAttemptContext = { state: retryState, interaction, customer: retryCustomer, targetStage };
      try {
        originalResult = original.resolvePatronForce(retryState, interaction, retryCustomer, wife, targetStage, offended);
      } finally {
        forceAttemptContext = previousContext;
      }
      if (patronEscalationContext) patronEscalationContext.forceResultKind = originalResult?.kind || 'none';
      if (!originalResult || originalResult.kind === 'none') {
        const retryableState = clearCuffedForceDecision(originalResult?.state || retryState, customer.id);
        return originalResult
          ? { ...originalResult, state: retryableState }
          : { state: retryableState, kind: 'none', endsInteraction: false, coerced: false };
      }
      const data = getData(state);
      setEquipment(data, 'restraint', {
        ...restraint,
        lastCoercion: { slot: state.slot, targetStage, result: 'yielded', coerced: true }
      });
      let out = putData(state, data);
      out = required.recordPatronMistreatment(out, customer);
      out = {
        ...out,
        customers: (out.customers || []).map(entry => entry.id === customer.id
          ? { ...entry, forceDecidedTonight: 'yielded' }
          : entry)
      };
      const patronTarget = { kind: 'patron', id: interaction.customerName.toLowerCase() };
      out = wrappedAddFeeling(out, 'disgust', {
        intensity: 50,
        source: `patron:${interaction.customerName.toLowerCase()}:yielded`,
        target: patronTarget,
        durationSlots: 300,
        blurb: `${withParticle(interaction.customerName, '이', '가')} 거절을 무시하고 밀어붙였고, ${withParticle(wifeDisplayName(state), '은', '는')} 그와 싸우느니 그냥 내버려두었다`
      });
      out = wrappedAddFeeling(out, 'anger', {
        intensity: 34,
        source: `patron:${interaction.customerName.toLowerCase()}:yielded`,
        target: patronTarget,
        durationSlots: 260
      });
      if (COERCED_IDENTITY_STAGES.has(targetStage)) {
        out = wrappedAddIdentityStrainFromPatronAct(out, {
          stage: targetStage,
          connection: -1,
          witnessCount: 0,
          transactional: false
        });
      }
      if (patronEscalationContext) {
        patronEscalationContext.restraintCoercion = {
          customerId: customer.id,
          targetStage
        };
      }
      return {
        state: out,
        kind: 'yielded',
        logOverride: `${withParticle(customer.name, '은', '는')} 묶인 ${wifeDisplayName(state)}의 손목을 붙잡아 저항을 눌러 버리고, 거절에도 아랑곳하지 않은 채 행동을 이어갑니다.`,
        escalateTo: targetStage,
        endsInteraction: false,
        coerced: true,
        badGuestRestraintOverride: true
      };
    }

    const handcuffResponse = tryHandcuffAfterEscalationRefusal(
      state,
      interaction,
      customer,
      targetStage,
      restraint,
      'forceable'
    );
    if (handcuffResponse) return handcuffResponse;
    const result = original.resolvePatronForce(state, interaction, customer, wife, targetStage, offended);
    if (!result?.state || result.coerced !== true && result.kind !== 'yielded') return result;
    return {
      ...result,
      state: reportQualifiedVisit(result.state, interaction, { coerced: true })
    };
  }

  function attemptHandcuffAfterRefusalTrigger(state, interaction, customer, options = {}) {
    const restraint = options.restraint ?? equipmentOf(readData(state), 'restraint');
    const room = wifeLocation(state);
    const currentStage = STAGES.indexOf(interaction?.stage);
    const targetIndex = STAGES.indexOf(options.targetStage);
    const isEscalationRequest = targetIndex >= 0
      && (currentStage < 0 || targetIndex > currentStage);
    const canRespondWithHandcuffs = customer
      && isBadGuest(state, customer)
      && !restraint?.active
      && (options.requireEscalation !== true || isEscalationRequest)
      && room
      && customerLocation(state, customer.id) === room
      && !playerInsideRoom(state, room)
      && state.slot - (customer.badGuestLastActionSlot ?? -9999) >= CONFIG.actionCooldownMinutes
      && Math.random() < CONFIG.refusalHandcuffChance
        * badGuestPattern(customer).handcuffAttemptMultiplier;
    if (!canRespondWithHandcuffs) return null;

    const attempt = attemptHandcuff(state, customer, {
      roomId: room,
      preserveStage: options.preserveStage === true,
      source: options.source || 'refusal_response',
      suppressAlert: true
    });
    if (attempt.success) return { ...attempt, kind: 'handcuffed', endsInteraction: false };
    const failure = applyFailedHandcuffPenalty(attempt.state, customer, attempt.check);
    return { ...failure, success: false, check: attempt.check };
  }

  function tryHandcuffAfterEscalationRefusalImpl(
    state,
    interaction,
    customer,
    targetStage,
    restraint = equipmentOf(readData(state), 'restraint'),
    responseKind = 'forceable'
  ) {
    const currentStage = STAGES.indexOf(interaction?.stage);
    const gropingIndex = STAGES.indexOf('groping');
    const entersGroping = currentStage >= 0 && currentStage < gropingIndex;
    const forceableRefusal = responseKind === 'forceable';
    const wifeName = wifeDisplayName(state);
    const response = attemptHandcuffAfterRefusalTrigger(state, interaction, customer, {
      restraint,
      targetStage,
      requireEscalation: true,
      preserveStage: !entersGroping,
      source: 'refusal_response'
    });
    if (!response) return null;
    if (response.success) {
      const confusedPlayerText = confusionHandcuffText(state, customer, {
        success: true,
        forceable: forceableRefusal,
        entersGroping
      });
      return {
        state: presentHandcuffAlert(response.state, customer),
        kind: response.kind,
        logOverride: confusedPlayerText || (forceableRefusal
          ? (entersGroping
            ? `${withParticle(customer.name, '은', '는')} 거절이 끝나기도 전에 ${wifeName}의 손목을 낚아채 수갑을 채우고 자기 쪽으로 끌어당깁니다.`
            : `${withParticle(customer.name, '은', '는')} 거절이 끝나기도 전에 ${wifeName}의 손목을 낚아채 수갑을 채웁니다. 그녀가 물러서려 하자 길을 막습니다.`)
          : (entersGroping
            ? `${withParticle(customer.name, '은', '는')} 얼굴을 일그러뜨리고 ${wifeName}의 손목에 수갑을 채웁니다. 사슬을 당겨 그녀를 붙잡습니다.`
            : `${withParticle(customer.name, '은', '는')} 얼굴을 일그러뜨리고 ${wifeName}의 손목에 수갑을 채웁니다. 문에서 물러서지 않습니다.`)),
        endsInteraction: false,
        coerced: false,
        badGuestHandcuffResponse: true
      };
    }
    const confusedPlayerFailure = confusionHandcuffText(state, customer, {
      success: false,
      forceable: forceableRefusal,
      ejected: response.kind === 'ejected'
    });
    const failureText = confusedPlayerFailure || (forceableRefusal
      ? (response.kind === 'ejected'
        ? `${withParticle(customer.name, '은', '는')} 거절이 끝나기도 전에 ${wifeName}의 손목을 낚아채려 듭니다. 그러나 ${withParticle(wifeName, '은', '는')} 팔을 거칠게 뿌리치고 그를 밀어냅니다. “당장 나가요.”`
        : `${withParticle(customer.name, '은', '는')} 거절 직후 틈을 주지 않고 ${wifeName}의 손목에 수갑을 채우려 듭니다. ${withParticle(wifeName, '은', '는')} 재빨리 손을 빼내고 그와 거리를 벌립니다.`)
      : (response.kind === 'ejected'
        ? `${withParticle(customer.name, '은', '는')} 쫓겨날 것을 알아차리자 화를 내며 ${wifeName}의 손목을 붙잡으려 듭니다. ${withParticle(wifeName, '은', '는')} 거칠게 팔을 뿌리치고 그를 문 쪽으로 밀어냅니다. “당장 나가요.”`
        : `${withParticle(customer.name, '은', '는')} 쫓겨날 것을 알아차리자 얼굴을 일그러뜨리고 ${wifeName}의 손목에 수갑을 채우려 듭니다. ${withParticle(wifeName, '은', '는')} 손을 빼내고 단호하게 거리를 벌립니다.`));
    return {
      state: response.state,
      kind: response.kind,
      logOverride: failureText,
      endsInteraction: response.endsInteraction,
      coerced: false,
      badGuestHandcuffResponse: true
    };
  }


  function tryHandcuffAfterEscalationRefusal(...args) {
    return runPublicProcess('handcuffRefusalResponse', tryHandcuffAfterEscalationRefusalImpl, args);
  }

  function applyDoorLockImpl(state, customer, roomId) {
    const data = getData(state);
    data.doorLock = {
      patronId: customer.id,
      patronName: customer.name,
      roomId,
      appliedAtSlot: state.slot,
      active: true,
      lockedBy: 'patron'
    };
    const out = putData(state, data);
    return appendLog(
      out,
      `${withParticle(customer.name, '은', '는')} ${withParticle(wifeDisplayName(out), '이', '가')} 다른 쪽을 보는 동안 문 안쪽의 빗장을 조용히 내립니다. 걸쇠가 맞물리는 둔탁한 소리가 방 안에 울립니다.`,
      { important: true, tone: 'distress' }
    );
  }

  function applyDoorLock(...args) {
    return runPublicProcess('doorLock', applyDoorLockImpl, args);
  }

  function decisionMatchesEscalationStage(decision, stage) {
    const expectedCategory = STAGE_CATEGORIES[stage];
    return !decision?.category || !expectedCategory || decision.category === expectedCategory;
  }

  function gaggedRefusalResponseText(state, customer, category) {
    const wifeName = wifeDisplayName(state);
    const customerName = customer?.name || '손님';
    if (category === 'kiss_chaste' || category === 'kiss_real') {
      return `${withParticle(customerName, '이', '가')} 가까이 오자 ${withParticle(wifeName, '이', '가')} 얼굴을 돌리고 고개를 젓습니다. 입마개 너머로 짧은 소리가 샙니다.`;
    }
    if (category === 'touch_over_clothes'
      || category === 'touch_skin'
      || category === 'touch_breasts'
      || category === 'touch_under_skirt'
      || category === 'manual_receiving') {
      return `${withParticle(wifeName, '이', '가')} ${customerName}의 손목을 붙잡아 몸에서 떼어 내고 고개를 젓습니다.`;
    }
    if (category === 'manual_giving') {
      return `${withParticle(wifeName, '이', '가')} 고개를 젓고 손을 몸쪽으로 당깁니다. 입마개 너머로 막힌 소리가 납니다.`;
    }
    if (category === 'oral_giving') {
      return `${withParticle(wifeName, '이', '가')} 몸을 뒤로 빼고 고개를 젓습니다. 입마개 너머로 막힌 소리가 납니다.`;
    }
    if (category === 'oral_receiving') {
      return `${withParticle(wifeName, '이', '가')} 다리를 오므리고 ${withParticle(customerName, '을', '를')} 밀어냅니다. 입마개 너머로 짧은 소리가 샙니다.`;
    }
    if (category === 'watch_him') {
      return `${withParticle(customerName, '이', '가')} 바지끈에 손을 대자 ${withParticle(wifeName, '이', '가')} 그의 손목을 붙잡고 고개를 젓습니다.`;
    }
    if (category === 'genital_rubbing') {
      return `${withParticle(wifeName, '은', '는')} ${customerName}의 맨자지가 닿자 골반으로 그를 밀어내고 치마를 내려 가립니다.`;
    }
    if (category === 'sex_anal') {
      return `${withParticle(customerName, '이', '가')} ${wifeName}의 항문에 자지를 대자, ${withParticle(wifeName, '이', '가')} 뒤로 손을 뻗어 그를 아래로 밀어내고 고개를 젓습니다.`;
    }
    if (category === 'sex_vaginal' || category === 'sex_public' || category === 'sex_rough') {
      return `${withParticle(customerName, '이', '가')} 밀어 넣으려 하자 ${withParticle(wifeName, '이', '가')} 골반을 뒤로 빼고 고개를 젓습니다. 입마개 너머로 거친 숨이 샙니다.`;
    }
    if (category === 'cum_on_skin' || category === 'cum_on_face'
      || category === 'cum_in_mouth' || category === 'cum_swallow') {
      return `${withParticle(wifeName, '이', '가')} 얼굴을 돌리고 몸을 뒤로 뺍니다. 입마개 너머로 막힌 소리가 납니다.`;
    }
    return `${withParticle(wifeName, '이', '가')} 몸을 뒤로 빼고 고개를 젓습니다. 입마개 너머로 짧은 소리가 샙니다.`;
  }

  function gaggedRefusalLog(state, interaction, customer, result, context) {
    const decision = context?.intimacyDecision;
    if (decision?.badGuestGaggedRefusal !== true
      || result?.resisted !== true
      || result?.escalated === true
      || (context.forceCalled && context.forceResultKind && context.forceResultKind !== 'none')
      || !equipmentApplies(state, 'gag', context.customerId)) {
      return null;
    }
    const response = gaggedRefusalResponseText(state, customer, decision.category);
    const originalLog = result.log;
    if (typeof originalLog !== 'string') return response;
    const divider = originalLog.lastIndexOf('\n\n');
    return divider >= 0 ? `${originalLog.slice(0, divider)}\n\n${response}` : response;
  }

  function escalationMaxStageIsRestricted(context, result) {
    if (!result?.escalated || !result.inter) return false;
    const stage = result.reachedFor || result.inter.stage;
    const restraintCoercion = context.restraintCoercion;
    if (restraintCoercion
      && String(restraintCoercion.customerId) === String(result.inter.customerId)
      && restraintCoercion.targetStage === stage) return true;

    const accepted = context.intimacyDecision;
    if (!decisionMatchesEscalationStage(accepted, stage) || acceptanceAnswer(accepted) !== 'yes') {
      return false;
    }
    const counterfactuals = [
      context.actualIntimacyDecision,
      context.unassistedIntimacyDecision,
      context.unassistedActualIntimacyDecision
    ];
    return counterfactuals.some(decision => (
      decisionMatchesEscalationStage(decision, stage)
        && acceptanceAnswer(decision) === 'no'
    ));
  }

  function trackEscalationMaxStage(before, result, context) {
    if (!result?.escalated || !result.inter) return result;
    const restricted = escalationMaxStageIsRestricted(context, result);
    const tracked = trackEligiblePatronMaxStage(before, result.inter, restricted);
    if (tracked === result.inter) return result;
    const active = required.getActiveScene(result.state);
    const trackedState = active
      && String(active.customerId) === String(tracked.customerId)
      && active.stage === tracked.stage
      ? replacePatronScene(result.state, { ...active, ...tracked })
      : result.state;
    return { ...result, state: trackedState, inter: tracked };
  }

  function wrappedResolvePatronEscalation(state, interaction, customer, isReturning) {
    state = reportQualifiedVisit(state, interaction);
    const restrainedBefore = restraintOwnsCustomer(state, interaction?.customerId);
    const previousContext = patronEscalationContext;
    const context = {
      customerId: interaction?.customerId,
      forceCalled: false,
      forceResultKind: null,
      intimacyDecision: null,
      unassistedIntimacyDecision: null,
      actualIntimacyDecision: null,
      unassistedActualIntimacyDecision: null,
      escapeChecked: false,
      escapeSucceeded: false,
      escapeCheck: null,
      restraintCoercion: null
    };
    patronEscalationContext = context;
    let result;
    try {
      result = original.resolvePatronEscalation(state, interaction, customer, isReturning);
    } finally {
      patronEscalationContext = previousContext;
    }
    result = trackEscalationMaxStage(interaction, result, context);
    const gagRefusalLog = gaggedRefusalLog(state, interaction, customer, result, context);

    const negativeDecision = Number(context.intimacyDecision?.score) < 0;
    if (restrainedBefore
      && negativeDecision
      && !context.escapeChecked
      && result?.resisted === true
      && !result.escalated) {
      const liveCustomer = result.state?.customers?.find(entry => entry.id === result.inter?.customerId)
        || result.customer
        || customer;
      const escape = liveCustomer
        ? tryEscapeCuffsAfterNegativeDecision(result.state, result.inter, liveCustomer, result.reachedFor, context)
        : null;
      if (escape) {
        return {
          ...result,
          state: escape.state,
          log: escape.logOverride,
          endsInteraction: true,
          patronStays: escape.patronStays,
          escalated: false,
          resisted: true,
          badGuestRestraintBrokenByRefusal: true
        };
      }
    }
    if (context.escapeSucceeded) {
      return {
        ...result,
        badGuestRestraintBrokenByRefusal: true
      };
    }

    if (restrainedBefore
      && result?.resisted === true
      && !result.escalated
      && !context.forceCalled
      && !result.reachedFor) {
      return {
        ...result,
        state: result.state,
        inter: { ...result.inter, hasBeenRefused: true, stalled: 0 },
          log: gagRefusalLog,
        comfortDelta: 0,
        moodDelta: 0,
        resisted: false,
        endsInteraction: false,
        patronStays: false,
        awayEvent: false,
        recall: null,
        badGuestRestrainedRefusalSuppressed: true
      };
    }

    if (restrainedBefore
      && context.forceCalled
      && result?.resisted === true
      && !result.escalated
      && result.endsInteraction !== true) {
      return {
        ...result,
        inter: { ...interaction, hasBeenRefused: true, stalled: 0 },
        log: context.forceResultKind === 'none' ? gagRefusalLog : result.log,
        comfortDelta: 0,
        moodDelta: 0,
        resisted: false,
        endsInteraction: false,
        patronStays: false,
        reachedFor: null,
        awayEvent: false,
        recall: null,
        badGuestRestrainedRefusalHandled: true
      };
    }

    const refusedEscalation = !restrainedBefore
      && result?.resisted === true
      && !result.escalated
      && result.reachedFor
      && result.endsInteraction === true
      && !context.forceCalled;
    if (refusedEscalation) {
      const liveCustomer = result.state?.customers?.find(entry => entry.id === result.inter?.customerId)
        || result.customer
        || customer;
      const response = liveCustomer
        ? tryHandcuffAfterEscalationRefusal(
          result.state,
          result.inter,
          liveCustomer,
          result.reachedFor,
          undefined,
          'ejection'
        )
        : null;
      if (response) {
        const responseInteraction = required.getActiveScene(response.state);
        return {
          ...result,
          state: response.state,
          inter: responseInteraction?.customerId === result.inter?.customerId
            ? responseInteraction
            : result.inter,
          log: response.logOverride || result.log,
          endsInteraction: response.endsInteraction ?? result.endsInteraction,
          patronStays: response.patronStays ?? result.patronStays,
          badGuestHandcuffResponse: true
        };
      }
    }

    if (!result?.resisted
      || result.escalated
      || !result.reachedFor
      || context.forceCalled
      || !restrainedBefore) {
      return gagRefusalLog
        ? { ...result, log: gagRefusalLog, badGuestGaggedRefusal: true }
        : result;
    }

    const forceState = result.state;
    const liveCustomer = forceState.customers?.find(entry => entry.id === result.inter?.customerId)
      || result.customer
      || customer;
    if (!liveCustomer) return result;

    const force = wrappedResolvePatronForce(
      forceState,
      result.inter,
      liveCustomer,
      getWife(result.state),
      result.reachedFor,
      result.endsInteraction
    );
    const continuedInteraction = {
      ...interaction,
      hasBeenRefused: true,
      stalled: 0
    };
    if (!force || force.kind === 'none') {
      return {
        ...result,
        state: force?.state || result.state,
        inter: continuedInteraction,
        customer: (force?.state || result.state)?.customers?.find(entry => entry.id === interaction.customerId) || customer,
        log: gagRefusalLog,
        comfortDelta: 0,
        moodDelta: 0,
        resisted: false,
        endsInteraction: false,
        patronStays: false,
        reachedFor: null,
        awayEvent: false,
        recall: null,
        badGuestRestrainedRefusalSuppressed: true
      };
    }
    if (!force.escalateTo) {
      return {
        ...result,
        state: force.state || result.state,
        inter: force.endsInteraction === true ? result.inter : continuedInteraction,
        log: force.logOverride || gagRefusalLog || result.log,
        endsInteraction: force.endsInteraction ?? result.endsInteraction,
        resisted: force.endsInteraction === true,
        badGuestRestrainedRefusalHandled: true
      };
    }

    const transitionOptions = { by: 'override' };
    if (
      force.escalateTo === 'sex_patron'
      && result.inter?.stage === 'sex_patron'
      && ['inside', 'astride', 'inside_anal'].includes(result.inter.primarySlot)
    ) transitionOptions.slot = result.inter.primarySlot;
    const transitioned = trackEligiblePatronMaxStage(
      result.inter,
      required.transitionPatronStage(
        {
          ...result.inter,
          hasBeenRefused: true,
          coercedSinceSlot: result.state.slot
        },
        force.escalateTo,
        getWife(force.state),
        transitionOptions
      ),
      true
    );
    const recorded = wrappedRecordPatronReach(
      force.state,
      transitioned.customerName,
      force.escalateTo,
      'no'
    );
    return {
      ...result,
      state: recorded,
      inter: transitioned,
      customer: recorded.customers?.find(entry => entry.id === transitioned.customerId) || liveCustomer,
      log: force.logOverride || result.log,
      comfortDelta: 0,
      moodDelta: 0,
      escalated: true,
      resisted: true,
      endsInteraction: false,
      patronStays: false,
      reachedFor: force.escalateTo,
      awayEvent: false,
      recall: null,
      askCategory: null
    };
  }

  function applyCustomTacticImpl(state, plan, beforeState) {
    const customer = state.customers?.find(entry => entry.id === plan.customerId);
    if (!customer) return state;
    if (plan.kind === 'aggressive_deception') {
      const started = beginAggressiveDeception(state, customer, { interaction: required.getActiveScene(state) });
      if (started === state) return state;
      return {
        ...started,
        customers: (started.customers || []).map(entry => entry.id === customer.id
          ? markCustomerAction(entry, state.slot, plan.kind)
          : entry)
      };
    }
    let out = {
      ...state,
      customers: (state.customers || []).map(entry =>
        entry.id === customer.id
          ? markCustomerAction(entry, state.slot, plan.kind)
          : entry
      )
    };
    if (plan.kind === 'drug') return beginDrugAttempt(out, customer, '손님 응대 중', { drugKind: 'aphrodisiac' });
    if (plan.kind === 'sleep_drug') return beginDrugAttempt(out, customer, '손님 응대 중', { drugKind: 'sleep' });
    if (plan.kind === 'intoxication_drug') return beginDrugAttempt(out, customer, '손님 응대 중', { drugKind: 'intoxication' });
    if (plan.kind === 'confusion_drug') return beginDrugAttempt(out, customer, '손님 응대 중', { drugKind: 'confusion' });
    if (plan.kind === 'intoxication_finish') return resolveLurerIntoxicationFinish(out, customer);
    if (plan.kind === 'blindfold' || plan.kind === 'gag') return attemptEquipment(out, customer, plan.kind).state;
    if (plan.kind === 'back_room_pretext') return beginBackRoomPretext(out, customer, '손님 응대 중');
    if (plan.kind === 'door_lock') return applyDoorLock(out, customer, plan.roomId);

    return beforeState === state ? state : out;
  }


  function applyCustomTactic(...args) {
    return runPublicProcess('specialActionExecute', applyCustomTacticImpl, args);
  }

  function enforcerEquipmentChainCandidates(state, interaction, customer, room, data, pattern) {
    if (pattern.id !== 'enforcer') return null;
    const restraint = equipmentOf(data, 'restraint');
    if (!restraint?.active || String(restraint.patronId) !== String(customer.id)) return null;

    const attempts = data.equipment?.attempts || {};
    const blindfoldKey = equipmentAttemptKey(state, customer, 'blindfold');
    if (!equipmentApplies(state, 'blindfold', customer.id)) {
      if (attempts[blindfoldKey]) return null;
      const weight = CONFIG.specialActionWeights.blindfold * (pattern.blindfoldWeight / 3);
      if (weight <= 0) return null;
      return [{
        kind: 'blindfold',
        customerId: customer.id,
        roomId: room,
        weight,
        enforcerEquipmentChain: true
      }];
    }

    const gagKey = equipmentAttemptKey(state, customer, 'gag');
    if (equipmentApplies(state, 'gag', customer.id) || attempts[gagKey]) return null;
    if (CONFIG.specialActionWeights.gag <= 0) return null;
    if (wifeMouthActActive(interaction)) return [];
    return [{
      kind: 'gag',
      customerId: customer.id,
      roomId: room,
      weight: CONFIG.specialActionWeights.gag,
      enforcerEquipmentChain: true
    }];
  }

  function customTacticCandidates(state, interaction, customer) {
    if (!customer || !interaction || !isBadGuest(state, customer) || state.pendingEvent) return [];
    if (!globalActionReady(state, customer)) return [];
    const room = wifeLocation(state);
    if (!room || customerLocation(state, customer.id) !== room) return [];
    const husbandPresent = playerInsideRoom(state, room);
    const data = readData(state);
    const pattern = badGuestPattern(customer);
    const candidates = [];
    const enforcerEquipmentChain = enforcerEquipmentChainCandidates(
      state,
      interaction,
      customer,
      room,
      data,
      pattern
    );
    if (enforcerEquipmentChain) return enforcerEquipmentChain;

    if (!husbandPresent && room !== 'taproom' && !data.doorLock?.active) {
      candidates.push({
        kind: 'door_lock', customerId: customer.id, roomId: room,
        weight: CONFIG.specialActionWeights.doorLock * (pattern.doorLockWeight / 5)
      });
    }
    if (pattern.drugAction === 'drug'
      && DRUG_TACTIC_STAGES.has(interaction.stage)
      && drugLevelAt(state) <= 0
      && individualActionReady(state, customer, 'drug')) {
      candidates.push({
        kind: 'drug', customerId: customer.id, roomId: room,
        weight: CONFIG.specialActionWeights.drug
      });
    }
    if (pattern.drugAction === 'sleep_drug'
      && DRUG_TACTIC_STAGES.has(interaction.stage)
      && sleepPotionEligibility(state, customer).status === 'available'
      && individualActionReady(state, customer, 'sleep_drug')) {
      candidates.push({
        kind: 'sleep_drug', customerId: customer.id, roomId: room,
        weight: CONFIG.specialActionWeights.sleepDrug
      });
    }
    if (pattern.drugAction === 'intoxication_drug'
      && DRUG_TACTIC_STAGES.has(interaction.stage)
      && !timedEffectActive(state, 'intoxicationFloor')
      && individualActionReady(state, customer, 'intoxication_drug')) {
      candidates.push({
        kind: 'intoxication_drug', customerId: customer.id, roomId: room,
        weight: CONFIG.specialActionWeights.intoxicationDrug
      });
    }
    if (pattern.drugAction === 'confusion_drug'
      && DRUG_TACTIC_STAGES.has(interaction.stage)
      && !timedEffectActive(state, 'confusion')
      && individualActionReady(state, customer, 'confusion_drug')) {
      candidates.push({
        kind: 'confusion_drug', customerId: customer.id, roomId: room,
        weight: CONFIG.specialActionWeights.confusionDrug
      });
    }
    if (lurerIntoxicationFinishEligible(state, customer)) {
      candidates.push({
        kind: 'intoxication_finish', customerId: customer.id, roomId: room,
        weight: settings.lurerFinishWeight
      });
    }
    if (aggressiveDeceptionEligibility(state, customer, interaction).status === 'available') {
      candidates.push({
        kind: 'aggressive_deception', customerId: customer.id, roomId: room,
        weight: CONFIG.specialActionWeights.aggressiveDeception
      });
    }
    const attempts = data.equipment?.attempts || {};
    const blindfoldKey = equipmentAttemptKey(state, customer, 'blindfold');
    const gagKey = equipmentAttemptKey(state, customer, 'gag');
    const mayEquip = !husbandPresent || equipmentApplies(state, 'restraint', customer.id);
    const mayGag = mayEquip
      && equipmentApplies(state, 'restraint', customer.id)
      && equipmentApplies(state, 'blindfold', customer.id)
      && !wifeMouthActActive(interaction);
    if (mayEquip && !equipmentApplies(state, 'blindfold', customer.id) && !attempts[blindfoldKey]) {
      candidates.push({
        kind: 'blindfold', customerId: customer.id, roomId: room,
        weight: CONFIG.specialActionWeights.blindfold * (pattern.blindfoldWeight / 3)
      });
    } else if (mayGag
      && !equipmentApplies(state, 'gag', customer.id) && !attempts[gagKey]) {
      candidates.push({
        kind: 'gag', customerId: customer.id, roomId: room,
        weight: CONFIG.specialActionWeights.gag
      });
    }
    if (room === 'taproom'
      && (interaction.stage === 'chatting' || interaction.stage === 'flirting')
      && !restraintOwnsCustomer(state, customer.id)
      && individualActionReady(state, customer, 'back_room_pretext')
      && canAttemptBackRoomPretext(state, customer)) {
      candidates.push({
        kind: 'back_room_pretext', customerId: customer.id, roomId: room,
        weight: CONFIG.specialActionWeights.backRoomPretext * (pattern.backRoomWeight / 6)
      });
    }
    return candidates.filter(item => item.weight > 0);
  }

  function chooseCustomTactic(state, interaction, customer) {
    const candidates = customTacticCandidates(state, interaction, customer);
    const enforcerEquipmentChain = candidates.find(item => item.enforcerEquipmentChain === true);
    if (enforcerEquipmentChain) return enforcerEquipmentChain;
    if (Math.random() >= CONFIG.activeActionChance) return null;
    if (!candidates.length) return null;
    let cursor = Math.random() * candidates.reduce((sum, item) => sum + item.weight, 0);
    return candidates.find(item => (cursor -= item.weight) <= 0) || candidates[candidates.length - 1];
  }

  function customTacticResult(plan, state, interaction) {
    const wifeName = wifeDisplayName(state);
    const customerName = interaction.customerName || '손님';
    if (plan.kind === 'drug' || plan.kind === 'sleep_drug' || plan.kind === 'intoxication_drug' || plan.kind === 'confusion_drug') {
      return {
        tactic: `bad_guest_${plan.kind}`,
        result: {
          text: `${withParticle(customerName, '은', '는')} 새 잔을 ${wifeName} 쪽으로 밀며 함께 마시자고 권합니다. 잔을 건네는 손이 잠깐 입구를 가립니다.`,
          comfortGain: 0,
          moodDelta: 0
        }
      };
    }
    if (plan.kind === 'intoxication_finish') {
      return {
        tactic: 'bad_guest_intoxication_finish',
        result: {
          text: `${withParticle(customerName, '\uC740', '\uB294')} \uC794\uC744 \uCE58\uC6B0\uB294 \uCC99\uD558\uBA70 \uB0A8\uC740 \uC220\uC744 ${wifeName} \uC55E\uC5D0 \uB2E4\uC2DC \uBC00\uC5B4 \uB461\uB2C8\uB2E4.`,
          comfortGain: 0,
          moodDelta: 0
        }
      };
    }
    if (plan.kind === 'blindfold' || plan.kind === 'gag') {
      return {
        tactic: `bad_guest_${plan.kind}`,
        result: {
          text: plan.kind === 'blindfold'
            ? `${withParticle(customerName, '은', '는')} 손안에 감춰 둔 천을 펴며 ${wifeName}의 눈 뒤로 손을 뻗습니다.`
            : `${withParticle(customerName, '은', '는')} 다른 천을 꺼내 ${wifeName}의 입가로 가져갑니다.`,
          comfortGain: 0,
          moodDelta: 0
        }
      };
    }
    if (plan.kind === 'aggressive_deception') {
      return {
        tactic: 'bad_guest_aggressive_deception',
        result: {
          text: `${withParticle(customerName, '은', '는')} 방금 서빙된 것을 살펴보더니 ${withParticle(wifeName, '을', '를')} 불러 세웁니다.`,
          comfortGain: 0,
          moodDelta: -1
        }
      };
    }
    if (plan.kind === 'back_room_pretext') {
      return {
        tactic: 'bad_guest_back_room_pretext',
        result: {
          text: `${withParticle(customerName, '은', '는')} 홀의 소음에 말을 묻히게 하며 ${wifeName}에게 가까이 붙습니다. “잠깐 할 얘기가 있소.”`,
          comfortGain: 0,
          moodDelta: 0
        }
      };
    }
    return {
      tactic: 'bad_guest_door_lock',
      result: {
        text: `${withParticle(customerName, '은', '는')} 대화를 이어가면서 문 쪽으로 반걸음 물러섭니다. 손이 등 뒤로 움직입니다.`,
        comfortGain: 0,
        moodDelta: 0
      }
    };
  }

  function wrappedSelectPatronTactic(state, interaction, traits) {
    const customer = state.customers?.find(entry => entry.id === interaction?.customerId);
    const restraint = equipmentOf(readData(state), 'restraint');
    const restrainedScene = restraintOwnsCustomer(state, interaction?.customerId, restraint);
    if (tacticTickContext && customer && isBadGuest(state, customer)) {
      if (tacticTickContext.plan?.customerId === customer.id) {
        return restrainedScene && tacticTickContext.plan.kind === 'back_room_pretext'
          ? null
          : customTacticResult(tacticTickContext.plan, state, interaction);
      }
      const plan = chooseCustomTactic(state, interaction, customer);
      if (plan && !(restrainedScene && plan.kind === 'back_room_pretext')) {
        tacticTickContext.plan = plan;
        return customTacticResult(plan, state, interaction);
      }
    }
    let selectionState = state;
    if (customer && isBadGuest(state, customer)) {
      const recordIndex = (state.patronRecords || []).findIndex(record => record.name === interaction.customerName);
      const blockedPretexts = Object.fromEntries(ORIGINAL_PRETEXT_IDS.map(id => [id, Number.MAX_SAFE_INTEGER]));
      selectionState = {
        ...state,
        patronRecords: recordIndex >= 0
          ? state.patronRecords.map((record, index) => index === recordIndex
            ? { ...record, pretextsTold: { ...(record.pretextsTold || {}), ...blockedPretexts } }
            : record)
          : [...(state.patronRecords || []), {
              name: interaction.customerName,
              visitCount: 0,
              pretextsTold: blockedPretexts
            }]
      };
    }
    const selected = original.selectPatronTactic(selectionState, interaction, traits);
    if (restrainedScene) {
      const result = selected?.result;
      if (MONETARY_TACTICS.has(selected?.tactic)
        || selected?.tactic === 'take_to_back'
        || result?.endsInteraction
        || result?.startBackRoomPrivateSession
        || result?.asksForPrivate) {
        return null;
      }
    }
    return selected;
  }

  function wrappedPatronInteractionTick(state) {
    const tickInput = reportQualifiedVisit(state, required.getActiveScene(state));
    const beforeScene = required.getActiveScene(tickInput);
    const previousContext = tacticTickContext;
    const context = {
      customerId: beforeScene?.customerId,
      plan: null,
      blockedNaturalEnd: false,
      naturalTimeoutEndReason: null,
      restraintEscaped: false,
      authorizedEndReason: null
    };
    tacticTickContext = context;
    let out;
    try {
      out = withConfusionSubjectiveContext(tickInput, beforeScene?.customerId, () => (
        original.processPatronInteractionTick(tickInput)
      ));
    } finally {
      tacticTickContext = previousContext;
    }
    if (context.plan) {
      if (context.plan.kind === 'back_room_pretext') {
        out = markLogsSinceAsTone(out, (tickInput.log || []).length, 'flirt');
      }
      out = applyCustomTactic(out, context.plan, tickInput);
    }

    if (context.blockedNaturalEnd) {
      const liveScene = required.getActiveScene(out);
      if (liveScene?.customerId === beforeScene?.customerId && isBadGuest(out, liveScene.customerId)) {
        out = replacePatronScene(out, { ...liveScene, stalled: 0 });
      }
    }

    const afterScene = required.getActiveScene(out);
    const restraint = equipmentOf(readData(out), 'restraint');
    if ((context.authorizedEndReason || context.restraintEscaped)
      && restraint?.active
      && restraint.patronId === beforeScene?.customerId
      && afterScene?.customerId !== restraint.patronId
      && !isWealthyPartyRestraint(out, restraint)) {
      const data = getData(out);
      const wifeBeforeEnd = getWife(tickInput);
      setEquipment(data, 'restraint', {
        ...restraint,
        active: false,
        afterUntilSlot: out.slot + CONFIG.handcuffAfterMinutes,
        resumeTask: restraint.resumeTask ?? wifeBeforeEnd?.currentTask,
        resumeTaskTarget: restraint.resumeTaskTarget ?? wifeBeforeEnd?.taskTarget,
        resumeBusyUntilSlot: restraint.resumeBusyUntilSlot ?? wifeBeforeEnd?.busyUntilSlot,
        resumeLocationUntilSlot: restraint.resumeLocationUntilSlot ?? wifeBeforeEnd?.locationUntilSlot
      });
      out = putData(out, data);
      out = updateWife(out, wife => ({
        ...wife,
        currentTask: 'cuffed_still',
        locationUntilSlot: out.slot + CONFIG.handcuffAfterMinutes
      }));
      out = appendDistressLog(
        out,
        `${withParticle(wifeDisplayName(out), '은', '는')} 손목이 묶인 채 일어서려 합니다. 짧은 사슬이 당겨지자 다시 주저앉습니다.`
      );
    }
    return enforceBadGuestIdentities(out);
  }

  function wrappedAcceptanceBreakdown(character, slot, category) {
    const base = original.acceptanceBreakdown(character, slot, category);
    const state = acceptanceProjectionContext?.state;
    const aphrodisiacSatiationScale = !calculatingUnassistedAphrodisiacAcceptance
      && drugLevelAt(state) > 0;
    const confusionSatiationScale = !calculatingActualConfusionAcceptance
      && timedEffectActive(state, 'confusion');
    if (!state || acceptanceProjectionContext.breakdownApplied
      || !(aphrodisiacSatiationScale || confusionSatiationScale)) return base;
    acceptanceProjectionContext.breakdownApplied = true;
    const satisfied = (base.satisfied ?? 0) * 0.25;
    const spent = (base.spent ?? 0) * 0.25;
    const hurting = (base.hurting ?? 0) * 0.25;
    return {
      ...base,
      satisfied,
      spent,
      hurting,
      total: 1 - (1 - satisfied) * (1 - spent) * (1 - hurting),
      reasons: (base.reasons || []).map(reason => ({ ...reason, value: (reason.value ?? 0) * 0.25 })),
      badGuestDrugSatiationScale: 0.25
    };
  }

  function projectConfusionAcceptanceContext(state, context) {
    if (calculatingActualConfusionAcceptance) return context;
    if (context?.kind !== 'patron_request' && context?.kind !== 'paid_offer') return context;
    const targetId = confusionTarget(state);
    if (!targetId) return context;
    if (targetId !== 'player') {
      const target = (state.customers || []).find(customer => String(customer.id) === String(targetId));
      return {
        ...context,
        activeCustomerId: targetId,
        ...(target ? { comfortWithPatron: required.patronComfort(state, target) } : {})
      };
    }
    const { activeCustomerId: _actualCustomerId, ...playerContext } = context;
    return { ...playerContext, kind: 'player_intimate' };
  }

  function wrappedAcceptanceCalculator(state, category, context = { kind: 'player_intimate' }) {
    let projected = projectConfusionAcceptanceContext(state, context);
    const actualCustomerId = context?.activeCustomerId;
    if ((context?.kind === 'patron_request' || context?.kind === 'paid_offer')
      && equipmentApplies(state, 'blindfold', actualCustomerId)) {
      projected = { ...projected, husbandPresent: false, otherWitnesses: 0 };
    }
    return original.acceptanceCalculator(state, category, projected);
  }

  function wrappedEvaluateIntimacy(state, category, context = { kind: 'player_intimate' }) {
    let actualConfusionDecision = null;
    let unassistedAphrodisiacDecision = null;
    const actualCustomerId = context?.activeCustomerId;
    const activeConfusion = !calculatingActualConfusionAcceptance
      && (context?.kind === 'patron_request' || context?.kind === 'paid_offer')
      && confusionPerceptionForPatron(state, actualCustomerId);
    if (activeConfusion) {
      calculatingActualConfusionAcceptance = true;
      try {
        actualConfusionDecision = wrappedEvaluateIntimacy(state, category, context);
      } finally {
        calculatingActualConfusionAcceptance = false;
      }
      latestConfusionActualAcceptance = {
        episodeId: effectOf(readData(state), 'confusion')?.episodeId ?? null,
        slot: state.slot,
        customerId: activeConfusion.actualCustomer.id,
        category,
        decision: { ...actualConfusionDecision }
      };
    }
    const activeAphrodisiac = !calculatingUnassistedAphrodisiacAcceptance
      && (context?.kind === 'patron_request' || context?.kind === 'paid_offer')
      && DRUG_ACCEPTANCE_CATEGORIES.has(category)
      && drugLevelAt(state) > 0;
    if (activeAphrodisiac) {
      calculatingUnassistedAphrodisiacAcceptance = true;
      try {
        unassistedAphrodisiacDecision = wrappedEvaluateIntimacy(state, category, context);
      } finally {
        calculatingUnassistedAphrodisiacAcceptance = false;
      }
    }
    const previousProjection = acceptanceProjectionContext;
    acceptanceProjectionContext = { state, category, context, breakdownApplied: false };
    let base;
    try {
      base = original.evaluateIntimacy(state, category, context);
    } finally {
      acceptanceProjectionContext = previousProjection;
    }
    let result = base;
    if (!calculatingActualConfusionAcceptance
      && groupJoinContext?.forceAcceptance
      && context?.kind === 'patron_request'
      && groupJoinContext.candidateIds.has(context.activeCustomerId)
      && TOUCH_OR_SEX.has(category)) {
      const threshold = base.threshold ?? 0;
      result = {
        ...base,
        score: Math.max(base.score ?? 0, threshold),
        outcome: base.outcome === 'eager' ? 'eager' : 'hesitant',
        badGuestForcedGroupJoin: true
      };
    } else {
      const level = drugLevelAt(state);
      const relevantCategory = DRUG_ACCEPTANCE_CATEGORIES.has(category);
      if (!calculatingUnassistedAphrodisiacAcceptance && relevantCategory && level > 0) {
        const bonus = level * CONFIG.drugMaxAcceptanceBonus / 100;
        const score = (base.score ?? 0) + bonus;
        let outcome = base.outcome;
        if (score >= (base.threshold ?? 0) + 15) outcome = 'eager';
        else if (score >= (base.threshold ?? 0)) outcome = 'hesitant';
        result = {
          ...base,
          score,
          outcome,
          badGuestDrugArousal: level,
          badGuestDrugBonus: bonus
        };
      }
    }
    if (activeAphrodisiac && unassistedAphrodisiacDecision) {
      const unassistedAnswer = acceptanceAnswer(unassistedAphrodisiacDecision);
      result = {
        ...result,
        badGuestUnderAphrodisiac: true,
        badGuestAphrodisiacAssisted: acceptanceAnswer(result) === 'yes' && unassistedAnswer === 'no',
        badGuestUnassistedOutcome: unassistedAphrodisiacDecision.outcome ?? null,
        badGuestUnassistedScore: Number.isFinite(Number(unassistedAphrodisiacDecision.score))
          ? Number(unassistedAphrodisiacDecision.score) : null,
        badGuestUnassistedThreshold: Number.isFinite(Number(unassistedAphrodisiacDecision.threshold))
          ? Number(unassistedAphrodisiacDecision.threshold) : null
      };
    }
    if (!calculatingActualConfusionAcceptance
      && (context?.kind === 'patron_request' || context?.kind === 'paid_offer')
      && result.outcome === 'refuse'
      && equipmentApplies(state, 'gag', context.activeCustomerId)) {
      result = { ...result, badGuestGaggedRefusal: true };
    }
    if (patronEscalationContext
      && context?.kind === 'patron_request'
      && patronEscalationContext.customerId === context.activeCustomerId
      && !calculatingUnassistedAphrodisiacAcceptance) {
      if (calculatingActualConfusionAcceptance) {
        patronEscalationContext.actualIntimacyDecision = { ...result, category };
        if (unassistedAphrodisiacDecision) {
          patronEscalationContext.unassistedActualIntimacyDecision = {
            ...unassistedAphrodisiacDecision, category
          };
        }
      } else {
        patronEscalationContext.intimacyDecision = { ...result, category };
        if (unassistedAphrodisiacDecision) {
          patronEscalationContext.unassistedIntimacyDecision = {
            ...unassistedAphrodisiacDecision, category
          };
        }
        if (actualConfusionDecision) {
          patronEscalationContext.actualIntimacyDecision = { ...actualConfusionDecision, category };
        }
      }
    }
    if (activeConfusion) {
      latestConfusionActualAcceptance = {
        episodeId: effectOf(readData(state), 'confusion')?.episodeId ?? null,
        slot: state.slot,
        customerId: activeConfusion.actualCustomer.id,
        category,
        decision: { ...actualConfusionDecision }
      };
      latestConfusionPerceivedAcceptance = {
        episodeId: effectOf(readData(state), 'confusion')?.episodeId ?? null,
        slot: state.slot,
        customerId: activeConfusion.actualCustomer.id,
        category,
        decision: { ...result }
      };
    }
    if (activeAphrodisiac) {
      latestAphrodisiacAcceptance = {
        episodeId: effectOf(readData(state), 'aphrodisiac')?.episodeId ?? null,
        slot: state.slot,
        customerId: actualCustomerId,
        category,
        decision: { ...result },
        unassistedDecision: unassistedAphrodisiacDecision
          ? { ...unassistedAphrodisiacDecision }
          : null,
        actualDecision: actualConfusionDecision ? { ...actualConfusionDecision } : null
      };
    }
    return result;
  }

  function lockedDoorPrompt(state, lock) {
    if (!lock?.active || state.pendingEvent) return state;
    return {
      ...appendLog(
        state,
        `당신이 문을 밀자 안쪽 걸쇠가 버팁니다.`,
        { important: true, tone: 'distress' }
      ),
      pendingEvent: {
        type: 'bad_guest_locked_door',
        customerId: lock.patronId,
        customerName: lock.patronName,
        roomId: lock.roomId,
        text: `안쪽 걸쇠가 문을 붙잡고 있습니다. 부수려면 ${CONFIG.breakDoorMinutes}분이 걸립니다. 문이 부서지면 수리비 ${CONFIG.breakDoorRepairGold}골드를 내야 하고, 소란이 여관의 평판에도 남습니다.`,
        choices: [
          { id: 'bad_guest_break_door', label: '문을 부수고 들어가기', description: `${CONFIG.breakDoorMinutes}분 동안 문을 들이받습니다.` },
          { id: 'bad_guest_leave_locked', label: '물러나기', description: '문을 부수지 않고 문 앞에 남습니다.' }
        ]
      }
    };
  }

  function enterDrugDoorWithoutJudgment(state, roomId) {
    if (!roomId || !(timedEffectActive(state, 'aphrodisiac') || timedEffectActive(state, 'confusion'))) return null;
    const scene = required.getActiveScene(state);
    if (!scene?.customerId || wifeLocation(state) !== roomId
      || customerLocation(state, scene.customerId) !== roomId) return null;
    const room = state.locations?.[roomId];
    const privateSession = room?.meta?.privatePatron;
    const party = room?.meta?.party;
    const partyClosed = roomId === 'back_room' && party && !party.doorOpen
      && state.slot < (party.endSlot ?? Infinity);
    const privateClosed = privateSession && !privateSession.doorOpen
      && state.slot < (privateSession.returnAtSlot ?? Infinity);
    if (!partyClosed && !privateClosed) return null;

    const priorPlayerRoom = playerLocation(state);
    const returnRoom = priorPlayerRoom === roomId
      ? (state.locations?.taproom ? 'taproom' : null)
      : priorPlayerRoom;
    const approach = original.approachClosedDoor(state, roomId);
    if (!approach?.state) return state;
    if (approach.caught) return approach.state;
    const approachedRoom = approach.state.locations?.[roomId] || room;
    const approachedMeta = approachedRoom?.meta || {};
    const openedMeta = partyClosed
      ? { ...approachedMeta, party: { ...approachedMeta.party, doorOpen: true } }
      : { ...approachedMeta, privatePatron: { ...approachedMeta.privatePatron, doorOpen: true } };
    const liveScene = required.getActiveScene(approach.state);
    if (!liveScene || String(liveScene.customerId) !== String(scene.customerId)) return approach.state;
    let out = {
      ...approach.state,
      locations: {
        ...(approach.state.locations || {}),
        [roomId]: { ...approachedRoom, meta: openedMeta }
      },
      activeScene: {
        ...(approach.state.activeScene || {}),
        patron: {
          ...liveScene,
          keptGoingAtDoor: true,
          playerEngaged: false,
          badGuestDrugDoorEntry: { roomId, returnRoom }
        }
      }
    };
    const customer = (out.customers || []).find(entry => String(entry.id) === String(scene.customerId));
    out = appendLog(
      out,
      `당신은 문을 열고 방 안으로 들어섭니다. ${withParticle(wifeDisplayName(out), '과', '와')} ${withParticle(customer?.name || scene.customerName || '손님', '이', '가')} 당신을 돌아봅니다.`
    );
    return out;
  }

  function approachLockedDoor(state, lock) {
    if (!lock?.active) return state;
    const approach = original.approachClosedDoor(state, lock.roomId);
    if (!approach?.state) return state;
    if (approach.caught) return approach.state;
    const currentLock = readData(approach.state).doorLock;
    if (!currentLock?.active || currentLock.roomId !== lock.roomId) return approach.state;
    return lockedDoorPrompt(approach.state, currentLock);
  }

  function latestDrugEndSlot(state) {
    const data = readData(state);
    return Math.max(
      effectOf(data, 'aphrodisiac')?.endsAtSlot ?? -Infinity,
      effectOf(data, 'confusion')?.endsAtSlot ?? -Infinity
    );
  }

  function canOfferDrugRecovery(state) {
    if (!(drugLevelAt(state) > 0 || timedEffectActive(state, 'confusion'))) return false;
    if (!playerInsideRoom(state, wifeLocation(state))) return false;
    const wife = getWife(state);
    if (!wife || ['sleeping', 'passed_out', 'bathing', 'away'].includes(wife.currentTask)) return false;
    if (!['idle', 'resting', 'talking', undefined, null].includes(wife.currentTask)) return false;
    const data = readData(state);
    if (equipmentOf(data, 'restraint')?.active || data.doorLock?.active || required.getActiveScene(state)) return false;
    return true;
  }

  function addDrugRecoveryChoice(state) {
    const event = state.pendingEvent;
    if (event?.type !== 'wife_conversation' || event.category || !canOfferDrugRecovery(state)) return state;
    if ((event.choices || []).some(choice => choice.id === 'bad_guest_drug_recovery')) return state;
    return {
      ...state,
      pendingEvent: {
        ...event,
        choices: [
          ...(event.choices || []),
          {
            id: 'bad_guest_drug_recovery',
            label: '상태를 설명하고 위층으로 데려가기',
            description: `${wifeDisplayName(state)}에게 눈앞의 사람과 몸 상태를 다시 살피자고 말한 뒤 위층으로 데려갑니다.`
          }
        ]
      }
    };
  }

  function startDrugRecoveryRest(state, forced = false) {
    const endSlot = latestDrugEndSlot(state);
    if (!Number.isFinite(endSlot) || endSlot <= state.slot) return { ...state, pendingEvent: undefined };
    const room = wifeSleepRoom(state);
    let out = { ...state, pendingEvent: undefined };
    out = original.moveWife(out, room, endSlot, { skipModestyCheck: true });
    out = original.movePlayer(out, 'player', room);
    out = updateWife(out, wife => ({
      ...wife,
      currentTask: 'resting',
      taskTarget: 'bad_guest_drug_recovery',
      busyUntilSlot: endSlot,
      locationUntilSlot: endSlot
    }));
    const data = getData(out);
    data.recoveryRest = { active: true, roomId: room, startedAtSlot: state.slot, endsAtSlot: endSlot, forced };
    out = putData(out, data);
    if (forced) out = required.nudgeRelationship(out, { trust: -4, resentment: 6 });
    return appendLog(out, forced
      ? `당신은 ${withParticle(wifeDisplayName(out), '을', '를')} 붙들어 위층으로 데려갑니다. 그녀는 화가 난 채 침대 가장자리에 앉습니다.`
      : `${withParticle(wifeDisplayName(out), '은', '는')} 당신의 손을 잡고 위층으로 올라갑니다. 두 사람은 그녀가 가라앉을 때까지 함께 쉽니다.`);
  }

  function drugRecoveryChance(state) {
    const wife = getWife(state);
    const attrs = effectiveAttributes(wife);
    const mood = wife.stats?.mood ?? 50;
    const intox = wife.intoxication?.level ?? 0;
    const strength = Math.max(drugLevelAt(state), timedEffectActive(state, 'confusion') ? 70 : 0);
    const rawInfluence = Number(required.relationshipInfluence(state));
    const influence = clamp(Number.isFinite(rawInfluence) ? rawInfluence : 0, 0, 1);
    return clamp(0.1 + influence * 0.8 + ((attrs.wit ?? 50) - 50) * 0.006
      + (mood - 50) * 0.003 - intox * 0.002 - strength * 0.002, 0.05, 0.95);
  }

  function resolveDrugRecoveryImpl(state) {
    if (!canOfferDrugRecovery(state)) return { ...state, pendingEvent: undefined };
    const chance = drugRecoveryChance(state);
    if (Math.random() < chance) return startDrugRecoveryRest(state, false);
    return {
      ...state,
      pendingEvent: {
        type: 'bad_guest_drug_recovery_doubt',
        customerId: '',
        customerName: wifeDisplayName(state),
        text: `${withParticle(wifeDisplayName(state), '은', '는')} 손을 뺍니다. “내가 이상하다면서 마음대로 데려가려는 거야?”`,
        choices: [
          { id: 'bad_guest_drug_recovery_respect', label: '그녀의 뜻을 존중하기', description: '억지로 데려가지 않고 물러납니다.' },
          { id: 'bad_guest_drug_recovery_force', label: '억지로 위층에 데려가기', description: '그녀의 거절을 무시하고 붙들어 위층으로 데려갑니다.' }
        ]
      }
    };
  }

  function resolveDrugRecovery(...args) {
    return runPublicProcess('drugRescue', resolveDrugRecoveryImpl, args);
  }

  const DEFERRED_MOVEMENT_PRIORITY = Object.freeze({
    wife_move: 1,
    wife_occupant_move: 1,
    rest_break: 2,
    private_session_exit: 3
  });

  function restraintBlocksMovement(state) {
    const restraint = equipmentOf(readData(state), 'restraint');
    return Boolean(restraint && (restraint.active || restraint.afterUntilSlot != null));
  }

  function deferMovement(state, request) {
    const data = getData(state);
    const existing = data.deferredMovement;
    const existingPriority = DEFERRED_MOVEMENT_PRIORITY[existing?.kind] || 0;
    const requestPriority = DEFERRED_MOVEMENT_PRIORITY[request?.kind] || 0;
    if (existing && existingPriority >= requestPriority) return state;
    data.deferredMovement = {
      ...request,
      requestedAtSlot: state.slot
    };
    return putData(state, data);
  }

  function replayDeferredMovement(state) {
    if (restraintBlocksMovement(state)) return state;
    const deferred = readData(state).deferredMovement;
    if (!deferred) return state;
    const data = getData(state);
    data.deferredMovement = null;
    let out = putData(state, data);
    if (deferred.kind === 'private_session_exit'
      && typeof original.resolvePrivateSessionExit === 'function') {
      return original.resolvePrivateSessionExit(
        out,
        deferred.roomId,
        deferred.session,
        deferred.resolution
      );
    }
    if (deferred.kind === 'rest_break') {
      return original.applyWifeRestBreak(out, deferred.plan);
    }
    if (deferred.kind === 'wife_move' && out.locations?.[deferred.destination]) {
      return original.moveWife(out, deferred.destination, deferred.untilSlot, deferred.options);
    }
    if (deferred.kind === 'wife_occupant_move' && out.locations?.[deferred.destination]) {
      return original.movePlayer(out, deferred.occupantId, deferred.destination);
    }
    return out;
  }

  function wrappedApplyWifeRestBreak(state, plan) {
    if (!restraintBlocksMovement(state)) return original.applyWifeRestBreak(state, plan);
    return deferMovement(state, { kind: 'rest_break', plan });
  }

  function wrappedResolvePrivateSessionExit(state, roomId, session, resolution) {
    if (!restraintBlocksMovement(state)) {
      return original.resolvePrivateSessionExit(state, roomId, session, resolution);
    }
    return deferMovement(state, {
      kind: 'private_session_exit',
      roomId,
      session,
      resolution
    });
  }

  function wrappedMovePlayer(state, occupantId, destination) {
    const data = readData(state);
    const lock = data.doorLock;
    const wifeId = getWifeId(state);
    const restraint = equipmentOf(data, 'restraint');
    const wifeRestrained = restraint?.active || restraint?.afterUntilSlot != null;
    if (!bypassMoveWife && occupantId === wifeId && wifeRestrained) {
      return deferMovement(state, {
        kind: 'wife_occupant_move',
        occupantId,
        destination
      });
    }
    let out = original.movePlayer(state, occupantId, destination);
    if (occupantId === wifeId && lock?.active && destination !== lock.roomId) {
      const outData = getData(out);
      outData.doorLock = null;
      out = appendLog(putData(out, outData), `${withParticle(wifeDisplayName(out), '이', '가')} 방을 나서자 안쪽에서 잠갔던 문도 다시 열립니다.`);
    }
    if (occupantId === 'player') out = maybeCreateRestraintRescue(out);
    return out;
  }

  function wrappedMoveWife(state, destination, untilSlot, options) {
    const data = readData(state);
    const restraint = equipmentOf(data, 'restraint');
    const restrainedNow = restraint?.active || restraint?.afterUntilSlot != null;
    if (!bypassMoveWife && restrainedNow) {
      return deferMovement(state, {
        kind: 'wife_move',
        destination,
        untilSlot,
        options
      });
    }
    let out = original.moveWife(state, destination, untilSlot, options);
    const outData = getData(out);
    if (outData.doorLock?.active && destination !== outData.doorLock.roomId) {
      outData.doorLock = null;
      out = appendLog(putData(out, outData), `${withParticle(wifeDisplayName(out), '이', '가')} 방을 나서자 안쪽에서 잠갔던 문도 다시 열립니다.`);
    }
    return out;
  }

  function confusionRecoveryIncident(effect, actualPatronId, perceivedId = null) {
    return [...(effect?.incidents || [])].reverse().find(incident => (
      String(incident.actualPatronId) === String(actualPatronId)
      && (perceivedId == null || String(incident.perceivedId) === String(perceivedId))
    )) || null;
  }

  function correctConfusionFirsts(state, effect) {
    const journal = effect?.firstJournal || [];
    if (!journal.length) return state;
    return updateWife(state, wife => {
      const current = wife.firstsWithOthers;
      if (Array.isArray(current)) {
        const corrected = current.map(entry => {
          if (entry?.badGuestConfusionEpisodeId !== effect.episodeId) return entry;
          const item = journal.find(candidate => (
            candidate.episodeId === effect.episodeId
            && (candidate.perceivedName === entry.partner || candidate.actualPatronName === entry.partner)
          ));
          if (!item) return entry;
          return {
            ...entry,
            partner: item.actualPatronName,
            given: item.counterfactualGiven === true,
            badGuestDeceived: item.counterfactualAccepted !== true,
            badGuestConfusionRecovered: true
          };
        });
        for (const item of journal) {
          if (corrected.some(entry => entry?.badGuestConfusionEpisodeId === effect.episodeId
            && entry.partner === item.actualPatronName)) continue;
          corrected.push({
            partner: item.actualPatronName,
            witnessed: item.seen,
            given: item.counterfactualGiven === true,
            badGuestDeceived: item.counterfactualAccepted !== true,
            badGuestConfusionEpisodeId: effect.episodeId,
            badGuestConfusionRecovered: true
          });
        }
        return { ...wife, firstsWithOthers: corrected };
      }

      const corrected = { ...(current || {}) };
      for (const item of journal) {
        const existing = corrected[item.category];
        if (existing && existing.badGuestConfusionEpisodeId !== effect.episodeId) continue;
        corrected[item.category] = {
          ...(existing || {}),
          day: existing?.day ?? item.day,
          slot: existing?.slot ?? item.slot,
          seen: existing?.seen ?? item.seen,
          partner: item.actualPatronName,
          given: item.counterfactualGiven === true,
          badGuestDeceived: item.counterfactualAccepted !== true,
          badGuestConfusionEpisodeId: effect.episodeId,
          badGuestConfusionRecovered: true
        };
      }
      return { ...wife, firstsWithOthers: corrected };
    });
  }

  function correctConfusionIntimateHistory(state, effect, episodeEvents) {
    if (!effect?.episodeId || !(episodeEvents || []).length) return state;
    const service = getQualifiedExperience();
    return updateWife(state, wife => ({
      ...wife,
      intimateHistory: (wife.intimateHistory || []).map(entry => {
        if (entry?.badGuestConfusionEpisodeId !== effect.episodeId) return entry;
        const actualPartner = entry.badGuestActualPartner;
        const category = CONFUSION_ACT_CATEGORY[entry.actId] || entry.actId;
        const startedAt = entry.badGuestSceneStartedAtSlot == null
          ? -Infinity : Number(entry.badGuestSceneStartedAtSlot);
        const candidates = (episodeEvents || []).filter(event => (
          event.answer === 'yes'
          && (event.actualPatronName === actualPartner
            || String(event.actualPatronId) === String(entry.badGuestActualPatronId))
          && Number(event.slot) >= startedAt
          && Number(event.slot) <= Number(entry.slot)
        ));
        const memory = [...candidates].reverse().find(event => (
          entry.badGuestConfusionSourceSlot != null
          && Number(event.slot) === Number(entry.badGuestConfusionSourceSlot)
          && event.category === entry.badGuestConfusionSourceCategory
        )) || [...candidates].reverse().find(event => historyMemoryMatchesAct(event, entry, category))
          || (candidates.length === 1
            && historyMemoryMatchesAct(candidates[0], entry, category) ? candidates[0] : null);
        if (!memory) return entry;
        const accepted = memory.actualAnswer === 'yes';
        const reception = accepted
          ? (entry.badGuestActualPaid === true || entry.badGuestActualReception === 'paid'
            ? 'paid'
            : memory.actualOutcome === 'eager' ? 'eager' : 'hesitant')
          : 'reluctant';
        const corrected = {
          ...entry,
          reception,
          badGuestCounterfactualAccepted: accepted,
          badGuestConfusionRecovered: true,
          badGuestConfusionRecoveredAtSlot: state.slot
        };
        if (typeof service?.updateExperience !== 'function') return corrected;
        try {
          return service.updateExperience(corrected, WML_DATA_KEY, {
            payload: {
              confusionRecovered: true,
              confusionRecoveredAtSlot: state.slot,
              correctedReception: reception,
              counterfactualAccepted: accepted
            }
          }) || corrected;
        } catch {
          return corrected;
        }
      })
    }));
  }

  function correctConfusionFeelingsAndAgency(state, effect) {
    const incidents = effect?.incidents || [];
    if (!incidents.length) return state;
    let identityRollback = 0;
    const moodRollback = (effect?.firstMoodRollbacks || [])
      .filter(entry => entry.counterfactualAccepted !== true)
      .reduce((sum, entry) => sum + Number(entry.moodDelta || 0), 0);
    const crossedRollback = {};
    const selfConceptRollback = {};
    for (const incident of incidents) {
      if (incident.counterfactualAccepted === true || !incident.rollback) continue;
      identityRollback += Number(incident.rollback.identityStrain || 0);
      for (const [key, amount] of Object.entries(incident.rollback.crossedLineHistory || {})) {
        crossedRollback[key] = Number(crossedRollback[key] || 0) + Number(amount || 0);
      }
      for (const [key, amount] of Object.entries(incident.rollback.selfConcept || {})) {
        selfConceptRollback[key] = Number(selfConceptRollback[key] || 0) + Number(amount || 0);
      }
    }
    return updateWife(state, wife => {
      const feelings = (wife.feelings || []).flatMap(feeling => {
        const triggered = Number(feeling?.triggeredAtSlot ?? effect.startedAtSlot);
        if (triggered < effect.startedAtSlot || triggered > effect.endsAtSlot) return [feeling];
        const source = String(feeling?.source || '');
        const taggedIncident = feeling?.badGuestConfusionEpisodeId === effect.episodeId
          ? incidents.find(candidate => (
            String(candidate.actualPatronId) === String(feeling.badGuestActualPatronId)
          ))
          : null;
        const prefixMatches = incidents.filter(candidate => {
          const perceivedPrefix = candidate.perceivedType === 'player'
            ? 'player:confusion:'
            : `patron:${String(candidate.perceivedName).toLowerCase()}:`;
          return source.toLowerCase().startsWith(perceivedPrefix.toLowerCase());
        });
        const incident = taggedIncident || (prefixMatches.length === 1 ? prefixMatches[0] : null);
        if (!incident) return [feeling];
        if (incident.counterfactualAccepted !== true) return [];
        const perceivedPrefix = incident.perceivedType === 'player'
          ? 'player:confusion:'
          : `patron:${String(incident.perceivedName).toLowerCase()}:`;
        const hasPerceivedPrefix = source.toLowerCase().startsWith(perceivedPrefix.toLowerCase());
        const correctedSource = hasPerceivedPrefix
          ? `patron:${String(incident.actualPatronName).toLowerCase()}:${source.slice(perceivedPrefix.length)}`
          : source.split(incident.perceivedName).join(incident.actualPatronName);
        return [{
          ...feeling,
          source: correctedSource,
          ...(feeling.target?.kind === 'husband' || feeling.target?.kind === 'patron'
            ? { target: { kind: 'patron', id: String(incident.actualPatronName).toLowerCase() } }
            : {}),
          ...(typeof feeling.blurb === 'string'
            ? { blurb: feeling.blurb.split(incident.perceivedName).join(incident.actualPatronName) }
            : {})
        }];
      });
      const pending = wife.pendingReaction;
      const pendingIncident = incidents.find(incident => (
        pending?.lpc?.badGuestConfusionEpisodeId === effect.episodeId
        || pending?.lpc?.patronName === incident.perceivedName
        || pending?.patronName === incident.perceivedName
        || String(pending?.lpc?.patronId ?? pending?.patronId) === String(incident.perceivedId)
      ));
      const correctedPending = !pendingIncident
        ? pending
        : pendingIncident.counterfactualAccepted !== true
          ? undefined
          : {
            ...pending,
            lpc: {
              ...(pending.lpc || {}),
              patronName: pendingIncident.actualPatronName,
              patronId: pendingIncident.actualPatronId,
              badGuestConfusionRecovered: true
            }
          };
      const moments = (wife.moments || []).flatMap(moment => {
        if (moment?.badGuestPerceivedPartnerId == null) return [moment];
        const incident = incidents.find(candidate => (
          String(candidate.actualPatronId) === String(moment.badGuestActualPatronId)
          && String(candidate.perceivedId) === String(moment.badGuestPerceivedPartnerId)
        ));
        if (!incident) return [moment];
        return [{
          ...moment,
          badGuestPerceivedPartnerId: incident.actualPatronId,
          badGuestPerceivedPartnerName: incident.actualPatronName,
          badGuestPerceivedPartnerType: 'patron',
          badGuestConfusionRecovered: true,
          badGuestConfusionRecoveredAtSlot: state.slot,
          ...(incident.counterfactualAccepted !== true
            ? { badGuestDeceived: true }
            : {})
        }];
      });
      const agencyCorrection = {};
      if (identityRollback !== 0) {
        agencyCorrection.identityStrain = Math.max(0, Number(wife.identityStrain || 0) - identityRollback);
      }
      if (moodRollback !== 0 && Number.isFinite(Number(wife.mood))) {
        agencyCorrection.mood = clamp(Number(wife.mood) - moodRollback);
      }
      if (Object.keys(crossedRollback).length) {
        agencyCorrection.crossedLineHistory = subtractNumericObject(
          wife.crossedLineHistory,
          crossedRollback
        );
      }
      if (Object.keys(selfConceptRollback).length) {
        agencyCorrection.selfConcept = subtractNumericObject(
          wife.selfConcept,
          selfConceptRollback
        );
      }
      return {
        ...wife,
        feelings,
        moments,
        ...agencyCorrection,
        pendingReaction: correctedPending
      };
    });
  }

  function storeConfusionRecoveries(data, recoveries) {
    const overflow = recoveries.slice(0, Math.max(0, recoveries.length - CONFUSION_RECOVERY_LIMIT));
    const recoveryBaselines = [...(data.confusionMemories?.recoveryBaselines || [])];
    for (const entry of overflow) {
      if (entry?.kind !== 'deceived' || !entry.category) continue;
      const index = recoveryBaselines.findIndex(baseline => (
        baseline.category === entry.category
        && (String(baseline.actualPatronId) === String(entry.actualPatronId)
          || baseline.actualPatronName === entry.actualPatronName)
      ));
      if (index >= 0) recoveryBaselines[index] = entry;
      else recoveryBaselines.push(entry);
    }
    data.confusionMemories = {
      ...(data.confusionMemories || {}),
      recoveries: recoveries.slice(-CONFUSION_RECOVERY_LIMIT),
      recoveryBaselines
    };
  }

  function resolveConfusionMemoryRecovery(state, data, effect, sample = null) {
    const episodeEvents = confusionRecoveryEpisodeEvents(data, effect);
    const hasSubjectiveIncident = confusionHasSubjectiveIncident(data, effect);
    if (!hasSubjectiveIncident || !effect?.episodeId) return { state, data, result: null };

    const check = confusionRecoveryCheck(
      state,
      effect,
      episodeEvents,
      sample == null ? Math.random() : sample
    );
    const recoveries = [...(data.confusionMemories?.recoveries || [])];
    recoveries.push({
      kind: 'episode_result',
      episodeId: effect.episodeId,
      attemptedAtSlot: state.slot,
      success: check.success,
      score: check.score,
      roll: check.roll
    });
    const primary = (effect.incidents || [])[0]
      || episodeEvents[0]
      || (effect.firstJournal || [])[0];
    if (!check.success) {
      storeConfusionRecoveries(data, recoveries);
      const perceivedName = primary?.perceivedName || effect.mistakenForName || '누군가';
      debug('착란 기억 재인식 실패', {
        episodeId: effect.episodeId,
        score: check.score,
        roll: check.roll,
        perceivedName
      });
      return {
        state: appendIntimateLog(
          state,
          `${withParticle(wifeDisplayName(state), '은', '는')} 혼미에서 벗어나 흐릿한 기억을 더듬지만, 서로 맞지 않는 조각들을 끝내 이어 붙이지 못합니다. 그때의 기억 속에는 여전히 ${perceivedName}의 얼굴만 남아 있습니다.`
        ),
        data,
        result: check
      };
    }

    const retainedEvents = [];
    for (const event of data.confusionMemories?.events || []) {
      if (event.episodeId !== effect.episodeId || event.answer !== 'yes') {
        retainedEvents.push(event);
        continue;
      }
      const accepted = event.actualAnswer === 'yes';
      const incident = confusionRecoveryIncident(effect, event.actualPatronId, event.perceivedId);
      recoveries.push({
        kind: accepted ? 'accepted_misattribution' : 'deceived',
        episodeId: effect.episodeId,
        actualPatronId: event.actualPatronId,
        actualPatronName: event.actualPatronName,
        perceivedId: event.perceivedId,
        perceivedName: event.perceivedName,
        perceivedType: event.perceivedType,
        category: event.category,
        day: event.day,
        slot: event.slot,
        recoveredAtSlot: state.slot,
        counterfactualAccepted: accepted,
        answer: accepted ? 'yes' : null,
        reception: accepted
          ? (event.actualOutcome === 'eager' ? 'eager' : 'hesitant')
          : 'reluctant',
        given: accepted && (incident?.counterfactualGiven ?? event.counterfactualGiven ?? false),
        deceived: true
      });
      if (accepted) {
        retainedEvents.push({
          ...event,
          perceivedId: event.actualPatronId,
          perceivedName: event.actualPatronName,
          perceivedType: 'patron',
          recoveredAtSlot: state.slot,
          badGuestConfusionRecovered: true
        });
      }
    }
    data.confusionMemories = {
      ...(data.confusionMemories || {}),
      events: retainedEvents
    };
    storeConfusionRecoveries(data, recoveries);

    let out = correctConfusionIntimateHistory(state, effect, episodeEvents);
    out = correctConfusionFirsts(out, effect);
    out = correctConfusionFeelingsAndAgency(out, effect);
    const deceivedIncidents = (effect.incidents || []).filter(incident => !incident.counterfactualAccepted);
    if (deceivedIncidents.length) {
      const uniqueIncidents = [...new Map(deceivedIncidents.map(incident => [
        String(incident.actualPatronId),
        incident
      ])).values()];
      for (const incident of uniqueIncidents) {
        out = original.addFeeling(out, 'shame', {
          intensity: 55,
          source: `patron:${String(incident.actualPatronName).toLowerCase()}:confusion_deception`,
          durationSlots: 1200,
          target: { kind: 'patron', id: String(incident.actualPatronName).toLowerCase() },
          blurb: `${withParticle(incident.actualPatronName, '을', '를')} 다른 사람으로 착각한 채 원치 않았을 일을 겪었다`
        });
        out = appendIntimateLog(
          out,
          `${withParticle(wifeDisplayName(out), '은', '는')} 흐릿했던 기억 속 얼굴이 뒤바뀌어 있었다는 사실을 깨닫습니다. 그때 곁에 있던 사람은 ${incident.perceivedName}이 아니라 ${incident.actualPatronName}이었습니다.`
        );
      }
    } else {
      if (primary) {
        out = appendIntimateLog(
          out,
          `${withParticle(wifeDisplayName(out), '은', '는')} 흐릿했던 기억을 다시 맞춰 보며, 함께했던 사람이 ${primary.perceivedName}이 아니라 ${primary.actualPatronName}이었다는 사실을 알아차립니다.`
        );
      }
    }
    out = updateWife(out, wife => ({
      ...wife,
      lastPatronContext: wife.lastPatronContext?.badGuestConfusionEpisodeId === effect.episodeId
        ? { ...wife.lastPatronContext, badGuestConfusionRecoveredAtSlot: state.slot }
        : wife.lastPatronContext,
      innerThought: deceivedIncidents.length
        ? '그때 내가 보고 있다고 믿었던 얼굴은 진짜가 아니었어.'
        : wife.innerThought,
      ...(deceivedIncidents.length ? {
        innerThoughtType: 'uneasy',
        innerThoughtSlot: state.slot
      } : {})
    }));
    return { state: out, data, result: check };
  }

  function confusionHasSubjectiveIncident(data, effect) {
    return Boolean(
      confusionRecoveryEpisodeEvents(data, effect).length
      || (effect?.incidents || []).length
      || (effect?.firstJournal || []).length
    );
  }

  function confusionExpiryRefusal(data, state, effect) {
    const scene = required.getActiveScene(state);
    const category = stageAcceptanceCategory(scene);
    if (!scene?.customerId || !category || !effect?.episodeId) return null;
    const acceptance = latestEpisodeAcceptance(
      data,
      effect.episodeId,
      scene.customerId,
      [scene.stage, category]
    );
    if (acceptance?.answer !== 'yes' || acceptance.actualAnswer !== 'no') return null;
    return {
      customerId: scene.customerId,
      customerName: scene.customerName,
      stage: scene.stage,
      category
    };
  }

  function tryHandcuffAfterConfusionExpiryRefusal(state, data, scene, customer) {
    if (!settings.confusionExpiryRefusalHandcuffsEnabled) return null;
    if (!customer) return null;
    const response = attemptHandcuffAfterRefusalTrigger(state, scene, customer, {
      preserveStage: true,
      source: 'confusion_expiry_refusal'
    });
    if (!response) return null;
    const wifeName = wifeDisplayName(state);
    const customerName = scene.customerName || customer.name || '그 손님';
    if (response.success) {
      const currentScene = required.getActiveScene(response.state) || scene;
      let out = replacePatronScene(response.state, {
        ...currentScene,
        hasBeenRefused: true,
        stalled: 0,
        badGuestConfusionExpiredRefusalAtSlot: state.slot
      });
      out = appendDistressLog(
        out,
        `${withParticle(wifeName, '은', '는')} ${customerName}의 얼굴을 알아보고 손을 밀어냅니다. 그는 그녀의 손목을 낚아채 수갑을 채우고 물러서지 못하게 붙잡습니다.`
      );
      out = presentHandcuffAlert(out, customer);
      return { state: out, data: readData(out), attempted: true, success: true };
    }

    const resisted = response.kind === 'ejected'
      ? `${withParticle(wifeName, '은', '는')} 팔을 거칠게 뿌리치고 ${withParticle(customerName, '을', '를')} 밀어냅니다.`
      : `${withParticle(wifeName, '은', '는')} 재빨리 손을 빼내고 그와 거리를 벌립니다.`;
    let out = appendDistressLog(
      response.state,
      `${withParticle(wifeName, '은', '는')} 흐릿하던 시야가 걷히며 눈앞의 사람이 ${customerName}임을 알아차리고 몸을 떼어 냅니다. ${withParticle(customerName, '은', '는')} 그 손목을 붙잡아 수갑을 채우려 들지만, ${resisted}`
    );
    out = wrappedEndPatronInteraction(out, 'elena_refused', {
      suppressEndText: true,
      badGuestConfusionExpired: true,
      badGuestRefusalHandcuffFailed: true
    });
    return { state: out, data: readData(out), attempted: true, success: false };
  }

  function reconcileConfusionExpiryRefusal(state, data, refusal) {
    if (!refusal) return { state, data };
    const scene = required.getActiveScene(state);
    if (!scene
      || String(scene.customerId) !== String(refusal.customerId)
      || stageAcceptanceCategory(scene) !== refusal.category) {
      return { state, data };
    }
    const wifeName = wifeDisplayName(state);
    const customerName = scene.customerName || refusal.customerName || '그 손님';
    const restraint = equipmentOf(data, 'restraint');
    if (restraintOwnsCustomer(state, scene.customerId, restraint)) {
      const continuedScene = {
        ...scene,
        hasBeenRefused: true,
        stalled: 0,
        coercedSinceSlot: scene.coercedSinceSlot ?? state.slot,
        badGuestConfusionExpiredRefusalAtSlot: state.slot
      };
      setEquipment(data, 'restraint', {
        ...restraint,
        lastCoercion: {
          slot: state.slot,
          targetStage: scene.stage,
          result: 'continued_after_confusion',
          coerced: true
        }
      });
      let out = putData(replacePatronScene(state, continuedScene), data);
      out = appendDistressLog(
        out,
        `${withParticle(wifeName, '은', '는')} ${customerName}의 얼굴을 알아보고 묶인 손목을 비틀며 밀어냅니다. 수갑은 풀리지 않고, ${withParticle(customerName, '은', '는')} 거절에도 물러서지 않습니다.`
      );
      return { state: out, data: readData(out) };
    }
    const customer = state.customers?.find(entry => String(entry.id) === String(scene.customerId));
    const handcuffResponse = tryHandcuffAfterConfusionExpiryRefusal(
      state,
      data,
      scene,
      customer
    );
    if (handcuffResponse) return handcuffResponse;
    const refusedScene = {
      ...scene,
      hasBeenRefused: true,
      stalled: 0,
      badGuestConfusionExpiredRefusalAtSlot: state.slot
    };
    let out = appendDistressLog(
      replacePatronScene(state, refusedScene),
      `${withParticle(wifeName, '은', '는')} ${customerName}의 얼굴을 알아보고 몸을 떼며 그의 손을 밀어냅니다. 손님은 물러섭니다.`
    );
    out = wrappedEndPatronInteraction(out, 'elena_refused', {
      suppressEndText: true,
      badGuestConfusionExpired: true
    });
    return { state: out, data: readData(out) };
  }

  function normalizeEffects(state) {
    if (normalizing) return state;
    normalizing = true;
    try {
      let out = state;
      let data = readData(out);
      let changedData = false;
      const writableData = () => {
        if (!changedData) data = getData(out);
        changedData = true;
        return data;
      };

      const aggressive = data.aggressiveDeception?.active;
      if (aggressive) {
        const actor = out.customers?.find(entry => entry.id === aggressive.customerId);
        if (!actor || actor.status === 'gone' || actor.status === 'leaving'
          || !isCanonicalBadGuestActor(out, actor)) {
          const ended = { ...aggressive, status: 'interrupted', reason: 'actor_unavailable', completedAtSlot: out.slot };
          const target = writableData();
          target.aggressiveDeception = {
            active: null,
            requests: { ...(target.aggressiveDeception?.requests || {}), [aggressive.requestId]: ended }
          };
          if (out.pendingEvent?.requestId === aggressive.requestId) {
            out = { ...out, pendingEvent: undefined };
          }
        }
      }

      const aphrodisiac = effectOf(data, 'aphrodisiac');
      if (aphrodisiac) {
        const phase = drugPhase(out, aphrodisiac);
        const level = drugLevelAt(out, aphrodisiac);
        out = updateWife(out, wife => ({ ...wife, badGuestDrugArousal: Math.round(level * 10) / 10 }));
        if (phase === 'ended') {
          setEffect(writableData(), 'aphrodisiac', null);
          out = updateWife(out, wife => {
            const next = { ...wife };
            delete next.badGuestDrugArousal;
            return next;
          });
        }
      }

      const intoxicationFloor = effectOf(data, 'intoxicationFloor');
      if (intoxicationFloor?.endsAtSlot != null && out.slot >= intoxicationFloor.endsAtSlot) {
        setEffect(writableData(), 'intoxicationFloor', null);
      }

      if (!unresponsiveDrugTarget(out)
        && !timedEffectActive(out, 'confusion')
        && data.pendingConfusionRecoveries?.length) {
        const pending = [...data.pendingConfusionRecoveries];
        writableData().pendingConfusionRecoveries = [];
        out = putData(out, data);
        for (const expiredEffect of pending) {
          const resolved = resolveConfusionMemoryRecovery(out, getData(out), expiredEffect);
          out = resolved.state;
          data = resolved.data;
          out = putData(out, data);
        }
      }

      const confusion = effectOf(data, 'confusion');
      if (confusion?.endsAtSlot != null && out.slot >= confusion.endsAtSlot) {
        if (unresponsiveDrugTarget(out)) {
          const target = writableData();
          if (confusionHasSubjectiveIncident(target, confusion)) {
            target.pendingConfusionRecoveries = [
              ...(target.pendingConfusionRecoveries || []), confusion
            ].slice(-16);
          }
          setEffect(target, 'confusion', null);
          out = putData(out, target);
        } else {
          const expiryRefusal = confusionExpiryRefusal(data, out, confusion);
          const target = writableData();
          const resolved = resolveConfusionMemoryRecovery(out, target, confusion);
          out = resolved.state;
          data = resolved.data;
          setEffect(data, 'confusion', null);
          out = putData(out, data);
          const reconciled = reconcileConfusionExpiryRefusal(out, data, expiryRefusal);
          out = reconciled.state;
          data = reconciled.data;
        }
      }

      if (data.sleepPotion?.incident
        && !['sleeping', 'passed_out'].includes(getWife(out)?.currentTask)) {
        writableData().sleepPotion.incident = null;
      }

      if (data.recoveryRest?.active) {
        const rest = data.recoveryRest;
        if (out.slot >= rest.endsAtSlot || wifeLocation(out) !== rest.roomId) {
          writableData().recoveryRest = { ...rest, active: false, endedAtSlot: out.slot };
          out = updateWife(out, wife => wife.taskTarget === 'bad_guest_drug_recovery'
            ? { ...wife, currentTask: 'idle', taskTarget: undefined, busyUntilSlot: out.slot, locationUntilSlot: undefined }
            : wife);
        }
      }

      const restraint = equipmentOf(data, 'restraint');
      if (restraint?.afterUntilSlot != null && out.slot >= restraint.afterUntilSlot) {
        const released = restraint;
        setEquipment(writableData(), 'restraint', null);
        out = updateWife(out, wife => ({
          ...wife,
          currentTask: wife.currentTask === 'cuffed_still' ? released.resumeTask : wife.currentTask,
          taskTarget: wife.currentTask === 'cuffed_still' ? released.resumeTaskTarget : wife.taskTarget,
          busyUntilSlot: wife.currentTask === 'cuffed_still' ? released.resumeBusyUntilSlot : wife.busyUntilSlot,
          locationUntilSlot: wife.currentTask === 'cuffed_still'
            ? released.resumeLocationUntilSlot
            : wife.locationUntilSlot
        }));
        out = appendDistressLog(out, `${withParticle(wifeDisplayName(out), '은', '는')} 마침내 손을 비틀어 수갑의 구속에서 벗어납니다. 굳어 있던 손목을 천천히 문지릅니다.`);
      }

      if (restraint?.active) {
        const scene = required.getActiveScene(out);
        const heldForWealthyParty = isWealthyPartyRestraint(out, restraint);
        const drinkingGame = data.drinkingGame;
        const heldForDrinkingGame = drinkingGame?.active
          && drinkingGameOwnsCustomer(out, restraint.patronId)
          && wifeLocation(out) === restraint.roomId
          && customerLocation(out, restraint.patronId) === restraint.roomId;
        if (!heldForWealthyParty && !heldForDrinkingGame
          && scene?.customerId !== restraint.patronId) {
          const wifeBeforeWait = getWife(out);
          setEquipment(writableData(), 'restraint', {
            ...restraint,
            active: false,
            afterUntilSlot: out.slot + CONFIG.handcuffAfterMinutes,
            resumeTask: restraint.resumeTask ?? wifeBeforeWait?.currentTask,
            resumeTaskTarget: restraint.resumeTaskTarget ?? wifeBeforeWait?.taskTarget,
            resumeBusyUntilSlot: restraint.resumeBusyUntilSlot ?? wifeBeforeWait?.busyUntilSlot,
            resumeLocationUntilSlot: restraint.resumeLocationUntilSlot ?? wifeBeforeWait?.locationUntilSlot
          });
          out = updateWife(out, wife => ({
            ...wife,
            currentTask: unresponsiveDrugTarget(out) ? wife.currentTask : 'cuffed_still',
            locationUntilSlot: out.slot + CONFIG.handcuffAfterMinutes
          }));
          out = appendDistressLog(
            out,
            `${withParticle(wifeDisplayName(out), '은', '는')} 몸을 떼지만 수갑은 풀리지 않았습니다. 묶인 손목이 당겨져 그 자리에 남습니다.`
          );
        }
      }

      const liveScene = required.getActiveScene(out);
      for (const kind of ['blindfold', 'gag']) {
        const item = equipmentOf(data, kind);
        if (!item) continue;
        const wifeStillInside = wifeLocation(out) === item.roomId;
        const patronStillInside = customerLocation(out, item.patronId) === item.roomId;
        if (!wifeStillInside || !patronStillInside) {
          setEquipment(writableData(), kind, null);
          continue;
        }
        if (equipmentSituationActive(out, item, liveScene)) {
          if (!item.active || item.afterUntilSlot != null) {
            setEquipment(writableData(), kind, {
              ...item,
              active: true,
              afterUntilSlot: null
            });
          }
          continue;
        }
        if (item.afterUntilSlot != null && out.slot >= item.afterUntilSlot) {
          setEquipment(writableData(), kind, null);
          continue;
        }
        if (item.active && liveScene?.customerId !== item.patronId) {
          setEquipment(writableData(), kind, {
            ...item,
            active: false,
            afterUntilSlot: out.slot + CONFIG.handcuffAfterMinutes
          });
        }
      }

      if (data.wealthyParty?.active
        && data.wealthyParty.serveLocked
        && restraint?.active
        && backRoomParty(out)) {
        out = extendWealthyPartyService(out, data.wealthyParty);
      }

      if (data.doorLock?.active) {
        const lock = data.doorLock;
        const wifeStillInside = wifeLocation(out) === lock.roomId;
        const party = data.wealthyParty;
        const groupLock = lock.lockedBy === 'wealthy_party'
          && party?.active
          && party.memberIds?.some(id => String(id) === String(lock.patronId))
          && backRoomParty(out);
        const guestStillInside = groupLock
          ? party.memberIds.some(id => {
              const member = out.customers?.find(customer => String(customer.id) === String(id));
              return member
                && ACTIVE_CUSTOMER_STATUSES.has(member.status)
                && customerLocation(out, member.id) === lock.roomId;
            })
          : customerLocation(out, lock.patronId) === lock.roomId;
        if (!wifeStillInside || !guestStillInside) {
          writableData().doorLock = null;
          out = appendLog(out, wifeStillInside
            ? '문을 잠갔던 손님이 나가자 안쪽 빗장이 풀립니다.'
            : `${withParticle(wifeDisplayName(out), '이', '가')} 방을 나서자 안쪽에서 잠갔던 문도 다시 열립니다.`);
        }
      }

      if (changedData) out = putData(out, data);
      return replayDeferredMovement(out);
    } finally {
      normalizing = false;
    }
  }

  function tryAmbientBadGuestAction(state) {
    if (state.pendingEvent || required.getActiveScene(state)) return state;
    const room = wifeLocation(state);
    if (!room) return state;
    const party = readData(state).wealthyParty;
    if (room === 'back_room' && party?.active && !party.serveLocked) return state;
    const drugCandidates = (state.customers || []).filter(customer =>
      isBadGuest(state, customer)
      && ACTIVE_CUSTOMER_STATUSES.has(customer.status)
      && customerLocation(state, customer.id) === room
      && globalActionReady(state, customer)
      && patternDrugAvailable(state, customer)
    );
    const backRoomCandidates = room !== 'taproom' ? [] : (state.customers || []).filter(customer =>
      canAttemptBackRoomPretext(state, customer)
      && globalActionReady(state, customer)
      && individualActionReady(state, customer, 'back_room_pretext')
    );
    if (!drugCandidates.length && !backRoomCandidates.length) return state;

    const roll = Math.random();
    let kind = null;
    if (drugCandidates.length && roll < CONFIG.ambientDrugChancePerMinute) {
      kind = 'drug';
    } else {
      const backRoomFloor = drugCandidates.length ? CONFIG.ambientDrugChancePerMinute : 0;
      if (backRoomCandidates.length
        && roll >= backRoomFloor
        && roll < backRoomFloor + CONFIG.ambientBackRoomChancePerMinute) {
        kind = 'back_room_pretext';
      }
    }
    if (!kind) return state;

    const candidates = kind === 'drug' ? drugCandidates : backRoomCandidates;
    const customer = candidates[Math.floor(Math.random() * candidates.length)];
    const drugAction = badGuestPattern(customer).drugAction;
    let out = {
      ...state,
      customers: state.customers.map(entry => entry.id === customer.id
        ? markCustomerAction(
            entry,
            state.slot,
            kind === 'drug' ? drugAction : kind,
            `ambient_${kind === 'drug' ? drugAction : kind}`
          )
        : entry)
    };
    if (kind === 'back_room_pretext') return beginBackRoomPretext(out, customer, '일반 상황');
    out = appendLog(
      out,
      `${withParticle(customer.name, '은', '는')} ${withParticle(wifeDisplayName(out), '이', '가')} 일하러 지나가는 순간 새 잔을 내밀어 한 모금만 함께하자고 붙잡습니다.`
    );
    return beginDrugAttempt(out, customer, '일반 상황');
  }

  function badGuestIncidentKinds(state) {
    const data = readData(state);
    const kinds = [];
    if (timedEffectActive(state, 'intoxicationFloor')) kinds.push('intoxication');
    if (timedEffectActive(state, 'confusion')) kinds.push('confusion');
    if (timedEffectActive(state, 'aphrodisiac')) kinds.push('aphrodisiac');
    if (sleepActionsAvailable() && (data.sleepPotion?.pending
      || (data.sleepPotion?.incident
        && ['sleeping', 'passed_out'].includes(getWife(state)?.currentTask)))) {
      kinds.push('sleep');
    }
    const restraint = equipmentOf(data, 'restraint');
    if (restraint?.active
      || (restraint?.afterUntilSlot != null && state.slot < restraint.afterUntilSlot)) {
      kinds.push('restraint');
    }
    for (const kind of ['blindfold', 'gag']) {
      const item = equipmentOf(data, kind);
      if (item?.active
        || (item?.afterUntilSlot != null && state.slot < item.afterUntilSlot)) {
        kinds.push(kind);
      }
    }
    return kinds;
  }

  function badGuestIncidentContext(state) {
    if (readData(state).wealthyParty?.active || readData(state).drinkingGame?.active) return null;
    const roomId = wifeLocation(state);
    if (!roomId || !state.locations?.[roomId]) return null;
    const nativeParty = backRoomParty(state);
    const partyActive = !!nativeParty && state.slot < nativeParty.endSlot;
    if (partyActive && roomId === 'back_room') return null;
    const kinds = badGuestIncidentKinds(state);
    if (!kinds.length) return null;
    const scene = required.getActiveScene(state);
    const sceneIds = new Set([
      scene?.customerId,
      ...(scene?.joinedPatronIds || []),
      ...(scene?.crowdPatronIds || [])
    ].filter(Boolean).map(String));
    const anchors = (state.customers || []).filter(customer => (
      isBadGuest(state, customer)
      && ACTIVE_CUSTOMER_STATUSES.has(customer.status)
      && customerLocation(state, customer.id) === roomId
    ));
    if (!anchors.length) return null;
    const candidates = (state.customers || []).filter(customer => (
      isBadGuest(state, customer)
      && ACTIVE_CUSTOMER_STATUSES.has(customer.status)
      && customerLocation(state, customer.id)
      && customerLocation(state, customer.id) !== roomId
      && !(partyActive && customerLocation(state, customer.id) === 'back_room')
      && !sceneIds.has(String(customer.id))
    )).sort((left, right) => String(left.id).localeCompare(String(right.id)));
    return { roomId, kinds, scene, anchors, candidates };
  }

  function connectIncidentSeekerToScene(state, customerId) {
    const scene = required.getActiveScene(state);
    if (!scene || String(scene.customerId) === String(customerId)) return state;
    const joined = new Set((scene.joinedPatronIds || []).map(String));
    const crowd = new Set((scene.crowdPatronIds || []).map(String));
    if (joined.has(String(customerId)) || crowd.has(String(customerId))) return state;
    if (crowd.size >= 4) return state;
    const nextScene = {
      ...scene,
      crowdPatronIds: [...(scene.crowdPatronIds || []), customerId]
    };
    return {
      ...replacePatronScene(state, nextScene),
      customers: (state.customers || []).map(customer => (
        String(customer.id) === String(customerId)
          ? { ...customer, hadInteractionThisVisit: true }
          : customer
      ))
    };
  }

  function tryCoordinateBadGuestIncident(state) {
    if (!settings.cooperativeIncidentMovementEnabled) return state;
    if (state.pendingEvent) return state;
    const context = badGuestIncidentContext(state);
    if (!context?.candidates.length) return state;
    if (context.scene && (context.scene.crowdPatronIds || []).length >= 4) return state;
    const unresponsive = ['sleeping', 'passed_out'].includes(getWife(state)?.currentTask);
    const sleepScene = Boolean(context.scene?.sleepActionsStage);
    const candidates = unresponsive && (!context.scene || sleepScene)
      ? context.candidates
      : [context.candidates[Math.abs(Number(state.slot) || 0) % context.candidates.length]];
    let out = state;
    const arrivals = [];
    for (const candidate of candidates) {
      const sourceRoom = customerLocation(out, candidate.id);
      const moved = original.movePlayer(out, candidate.id, context.roomId);
      if (customerLocation(moved, candidate.id) !== context.roomId) continue;
      out = sleepScene ? moved : connectIncidentSeekerToScene(moved, candidate.id);
      arrivals.push(candidate);
      if (CONFIG.debug) {
        console.debug(`[${MOD_ID}] incident-seek`, {
          customerId: candidate.id,
          sourceRoom,
          targetRoom: context.roomId,
          kinds: context.kinds
        });
      }
    }
    if (!arrivals.length) return state;
    const scene = required.getActiveScene(out);
    const wifeName = wifeDisplayName(out);
    const names = arrivals.map(candidate => candidate.name).join(', ');
    const text = sleepScene
      ? `${withParticle(names, '은', '는')} 방 안으로 들어와 잠든 ${wifeName} 곁에 머뭅니다.`
      : scene
      ? `${withParticle(names, '은', '는')} 방 안의 기척을 알아차리고 들어와 ${wifeName} 곁에 자리를 잡습니다.`
      : unresponsive
        ? `${withParticle(names, '은', '는')} ${wifeName} 곁에 다른 손님이 남아 있는 것을 보고 방 안으로 들어옵니다.`
        : `${withParticle(names, '은', '는')} 다른 방에서 나와 ${withParticle(wifeName, '이', '가')} 있는 곳으로 들어옵니다.`;
    out = appendLog(out, text);
    return scene && !sleepScene ? wrappedProcessPatronGroupJoin(out) : out;
  }

  function tryRehandcuffImpl(state) {
    const data = readData(state);
    const restraint = equipmentOf(data, 'restraint');
    if (!restraint || restraint.active || restraint.afterUntilSlot == null || state.slot > restraint.afterUntilSlot) return state;
    if (state.pendingEvent || required.getActiveScene(state)) return state;
    if (playerInsideRoom(state, restraint.roomId)) return maybeCreateRestraintRescue(state);
    if (wifeLocation(state) !== restraint.roomId || customerLocation(state, restraint.patronId) !== restraint.roomId) return state;
    if (Math.random() >= CONFIG.rehandcuffChancePerMinute) return state;
    const customer = state.customers?.find(entry => entry.id === restraint.patronId);
    if (!customer || customer.status === 'gone' || customer.status === 'leaving') return state;
    const logStart = (state.log || []).length;
    let out = wrappedStartPatronInteraction(
      state,
      customer.id,
      undefined,
      `${withParticle(customer.name, '은', '는')} 아직 묶인 ${wifeDisplayName(state)}의 손목을 들어 올려 다시 자기 쪽으로 끌어당깁니다. ${withParticle(wifeDisplayName(state), '은', '는')} 균형을 잃고 그에게 붙들립니다.`,
      undefined
    );
    out = markLogsSinceAsTone(out, logStart, 'distress');
    const scene = required.getActiveScene(out);
    if (!scene || scene.customerId !== customer.id) return state;
    const writableData = getData(out);
    setEquipment(writableData, 'restraint', {
      ...restraint,
      active: true,
      appliedAtSlot: out.slot,
      applicationSource: 'rehandcuff',
      afterUntilSlot: null
    });
    for (const kind of ['blindfold', 'gag']) {
      const item = equipmentOf(writableData, kind);
      if (item?.patronId === customer.id && item.afterUntilSlot != null) {
        setEquipment(writableData, kind, { ...item, active: true, afterUntilSlot: null });
      }
    }
    out = putData(out, writableData);
    out = {
      ...out,
      activeScene: {
        ...(out.activeScene || {}),
        patron: {
          ...scene,
          stage: 'groping',
          stageFrom: 'chatting',
          stageBy: 'bad_guest_rehandcuff',
          ticksAtStage: 0,
          stalled: 0,
          hasBeenRefused: false
        }
      }
    };
    out = appendDistressLog(out, `${withParticle(customer.name, '은', '는')} 수갑의 짧은 사슬을 당겨 ${withParticle(wifeDisplayName(out), '을', '를')} 다시 자기 앞으로 끌어옵니다. 묶인 손목은 그를 밀어낼 힘을 내지 못합니다.`);
    return presentHandcuffAlert(out, customer);
  }


  function tryRehandcuff(...args) {
    return runPublicProcess('handcuffReentry', tryRehandcuffImpl, args);
  }

  function tryWifeSelfLockImpl(state) {
    const data = readData(state);
    if (data.doorLock?.active || state.pendingEvent) return state;
    const scene = required.getActiveScene(state);
    if (!scene || STAGES.indexOf(scene.stage) < STAGES.indexOf('bold_touch')) return state;
    const customer = state.customers?.find(entry => entry.id === scene.customerId);
    if (!customer) return state;
    const room = wifeLocation(state);
    if (!room || room === 'taproom' || customerLocation(state, customer.id) !== room || playerInsideRoom(state, room)) return state;
    const drift = required.maritalDrift(state);
    const record = state.patronRecords?.find(entry => entry.name === customer.name);
    const attachment = required.patronAttachment(record, getWife(state));
    if (drift < CONFIG.selfLockMinDrift) return state;
    const driftFactor = clamp((drift - CONFIG.selfLockMinDrift) / (100 - CONFIG.selfLockMinDrift), 0, 1);
    const attachmentFactor = clamp(attachment / 100, 0, 1);
    const chance = CONFIG.selfLockMaxChancePerMinute * driftFactor * attachmentFactor;
    if (chance <= 0 || Math.random() >= chance) return state;
    const writableData = getData(state);
    writableData.doorLock = {
      patronId: customer.id,
      patronName: customer.name,
      roomId: room,
      appliedAtSlot: state.slot,
      active: true,
      lockedBy: 'wife'
    };
    let out = putData(state, writableData);
    return appendLog(
      out,
      `${withParticle(wifeDisplayName(out), '은', '는')} 복도 쪽을 한 번 확인한 뒤 ${withParticle(customer.name, '과', '와')} 단둘이 남은 방의 문을 스스로 닫습니다. 문짝이 문틀에 맞물리는 소리가 난 뒤, 안쪽 빗장을 천천히 내려 잠급니다.`,
      { important: true }
    );
  }


  function tryWifeSelfLock(...args) {
    return runPublicProcess('wifeSelfLock', tryWifeSelfLockImpl, args);
  }

  function prepareRestraintReleaseTick(state) {
    const data = readData(state);
    const restraint = equipmentOf(data, 'restraint');
    if (!restraint || restraint.active || restraint.afterUntilSlot == null) return state;
    if (state.slot + 1 < restraint.afterUntilSlot) return state;
    const wife = getWife(state);
    if (wife?.currentTask !== 'cuffed_still') return state;
    const resumesPartyService = (restraint.resumeTask === 'serving' || restraint.resumeTask == null)
      && wifeLocation(state) === 'back_room'
      && Boolean(backRoomParty(state));
    if (!resumesPartyService) return state;
    return updateWife(state, current => ({
      ...current,
      currentTask: 'serving',
      taskTarget: restraint.resumeTaskTarget,
      busyUntilSlot: restraint.resumeBusyUntilSlot,
      locationUntilSlot: Math.min(
        restraint.resumeLocationUntilSlot ?? restraint.afterUntilSlot,
        restraint.afterUntilSlot
      )
    }));
  }

  function clearSleepPotionPending(state) {
    const data = getData(state);
    if (!data.sleepPotion?.pending) return state;
    data.sleepPotion.pending = null;
    return putData(state, data);
  }

  function sequenceNewOriginalLogs(before, after) {
    const firstNew = before.log?.length || 0;
    if ((after.log?.length || 0) <= firstNew) return after;
    let nextSeq = after.logSeq ?? before.logSeq ?? 0;
    let changed = false;
    const log = after.log.map((entry, index) => {
      if (index < firstNew) return entry;
      if (entry.seq != null) {
        nextSeq = Math.max(nextSeq, entry.seq + 1);
        return entry;
      }
      changed = true;
      return { ...entry, seq: nextSeq++ };
    });
    return changed ? { ...after, log, logSeq: nextSeq } : after;
  }

  function clearUnavailableSleepPotionState(state) {
    if (sleepActionsAvailable()) return state;
    const current = readData(state).sleepPotion;
    if (!current?.pending && !current?.incident && !current?.roomWatch) return state;
    const data = getData(state);
    data.sleepPotion = {
      ...data.sleepPotion,
      pending: null,
      incident: null,
      roomWatch: null
    };
    return putData(state, data);
  }

  function wrappedPassOutWife(state, ...rest) {
    return original.passOutWife(state, ...rest);
  }

  function sleepInterceptionRooms(state, customer) {
    const available = new Set(original.privateRoomCandidates(state, customer.id, 'chatting')
      .map(entry => entry.place?.room)
      .filter(room => room && state.locations?.[room]));
    const rooms = [];
    const assigned = state.tavern?.tonightRenter?.customerId === customer.id
      ? 'upstairs_hall'
      : state.tavern?.tonightRenter2?.customerId === customer.id
        ? 'upstairs_room_2' : null;
    if (assigned && available.has(assigned)) rooms.push(assigned);

    const empty = ['upstairs_hall', 'upstairs_room_2'].filter(room => {
      if (!available.has(room) || room === assigned) return false;
      const renter = room === 'upstairs_hall' ? state.tavern?.tonightRenter
        : room === 'upstairs_room_2' ? state.tavern?.tonightRenter2 : null;
      return !renter?.customerId && (state.locations[room].occupants || []).length === 0;
    });
    if (empty.length > 1) {
      const first = Math.floor(Math.random() * empty.length);
      rooms.push(...empty.slice(first), ...empty.slice(0, first));
    } else rooms.push(...empty);

    const bathroom = state.locations?.bathroom;
    const wifeId = getWifeId(state);
    if (bathroom && !bathroom.meta?.privatePatron
      && !(bathroom.meta?.party && state.slot < bathroom.meta.party.endSlot)
      && playerLocation(state) !== 'bathroom'
      && (bathroom.occupants || []).every(id => id === wifeId || id === customer.id)) {
      rooms.push('bathroom');
    }
    for (const room of ['upstairs_hall', 'upstairs_room_2']) {
      const renter = room === 'upstairs_hall' ? state.tavern?.tonightRenter
        : state.tavern?.tonightRenter2;
      const open = room === 'upstairs_hall' ? state.tavern?.hasRoom : state.tavern?.hasRoom2;
      const location = state.locations?.[room];
      if (!open || !renter?.customerId || renter.customerId === customer.id || !location
        || location.meta?.privatePatron
        || (location.meta?.party && state.slot < location.meta.party.endSlot)
        || playerLocation(state) === room
        || (location.occupants || []).length !== 0) continue;
      rooms.push(room);
    }
    for (const room of ['elena_room', 'bedroom']) {
      if (available.has(room) && !rooms.includes(room)) rooms.push(room);
    }
    return rooms;
  }

  function sleepInterceptionRoomName(state, customer, room) {
    if (room === 'bathroom') return '욕실';
    if (room === 'elena_room') return '그녀의 방';
    if (room === 'bedroom') return '침실';
    if ((room === 'upstairs_hall' && state.tavern?.tonightRenter?.customerId === customer.id)
      || (room === 'upstairs_room_2' && state.tavern?.tonightRenter2?.customerId === customer.id)) {
      return '자기 객실';
    }
    if ((room === 'upstairs_hall' && state.tavern?.tonightRenter?.customerId)
      || (room === 'upstairs_room_2' && state.tavern?.tonightRenter2?.customerId)) {
      return '다른 손님의 객실';
    }
    return '빈 객실';
  }

  function resolveSleepPotionDeparture(state) {
    if (!sleepActionsAvailable()) return clearUnavailableSleepPotionState(state);
    const pending = readData(state).sleepPotion?.pending;
    if (!pending || state.slot < pending.moveAtSlot) return state;
    if (pending.stayInPlace && wifeLocation(state)) {
      let out = clearSleepPotionPending(state);
      out = passOutWhereSheStands(out, 'sleep');
      const data = getData(out);
      data.sleepPotion.incident = {
        sourceGuestId: pending.customerId || null,
        startedAtSlot: pending.requestedAtSlot ?? state.slot,
        sleepingAtSlot: out.slot
      };
      out = putData(out, data);
      try {
        const execution = getSleepActions()?.session?.addDepth?.(out, {
          characterId: pending.targetCharacterId,
          amount: pending.depth
        });
        if (execution?.result?.status === 'applied' && execution.state) out = execution.state;
      } catch {
        // The in-place blackout remains valid if optional depth tracking fails.
      }
      const source = out.customers?.find(customer => String(customer.id) === String(pending.customerId));
      if (source && ACTIVE_CUSTOMER_STATUSES.has(source.status)
        && customerLocation(out, source.id) === wifeLocation(out)) {
        try {
          out = scheduleBadGuestSleepApproach(out, source.id, 'sleep_potion_in_place', true);
        } catch {
          // Leave the incident available to the regular Sleep Actions search.
        }
      }
      return out;
    }
    const activeScene = required.getActiveScene(state);
    if (activeScene && restraintOwnsCustomer(state, activeScene.customerId)) return state;
    const originalSleepRoom = wifeSleepRoom(state);
    const sourceStayedInSleepRoom = Boolean(pending.customerId)
      && wifeLocation(state) === originalSleepRoom
      && String(customerLocation(state, pending.customerId)) === originalSleepRoom
      && (state.customers || []).some(customer => (
        String(customer.id) === String(pending.customerId)
        && ACTIVE_CUSTOMER_STATUSES.has(customer.status)
      ));
    let out = clearSleepPotionPending(state);
    const scene = required.getActiveScene(out);
    if (scene && (!pending.customerId || scene.customerId === pending.customerId)) {
      out = sequenceNewOriginalLogs(out,
        wrappedEndPatronInteraction(out, 'elena_passed_out', {
          suppressEndText: true,
          suppressReactionWindow: true
        }));
    }
    const beforeRetirementLogCount = out.log?.length || 0;
    out = sequenceNewOriginalLogs(out, original.retireWife(out, 'spent'));
    if (sourceStayedInSleepRoom
      && wifeLocation(out) === originalSleepRoom
      && (out.log?.length || 0) > beforeRetirementLogCount) {
      const log = [...out.log];
      log[log.length - 1] = {
        ...log[log.length - 1],
        text: `${withParticle(wifeDisplayName(out), '은', '는')} 방 안에서 몇 번 고개를 떨구다가 침대에 누워 잠이 듭니다.`
      };
      out = { ...out, log };
    }
    out = updateWife(out, wife => ({
      ...wife,
      currentTask: 'sleeping',
      taskTarget: undefined,
      busyUntilSlot: 0,
      locationUntilSlot: undefined
    }));
    {
      const data = getData(out);
      data.sleepPotion.incident = {
        sourceGuestId: pending.customerId || null,
        startedAtSlot: pending.requestedAtSlot ?? state.slot,
        sleepingAtSlot: out.slot
      };
      out = putData(out, data);
    }
    const infiltrators = (out.customers || []).filter(customer => (
      isBadGuest(out, customer)
      && ACTIVE_CUSTOMER_STATUSES.has(customer.status)
      && badGuestPattern(customer).id === 'infiltrator'
      && customerLocation(out, customer.id)
    )).sort((left, right) => (
      Number(String(right.id) === String(pending.customerId))
      - Number(String(left.id) === String(pending.customerId))
      || String(left.id).localeCompare(String(right.id))
    ));
    let intercepted = false;
    const sleepRoom = wifeLocation(out);
    if (sourceStayedInSleepRoom
      && sleepRoom === originalSleepRoom
      && String(customerLocation(out, pending.customerId)) === sleepRoom) {
      let available = out;
      const room = out.locations?.[sleepRoom];
      if (String(room?.meta?.privatePatron?.customerId) === String(pending.customerId)) {
        available = {
          ...out,
          locations: {
            ...out.locations,
            [sleepRoom]: {
              ...room,
              meta: { ...room.meta, privatePatron: undefined }
            }
          }
        };
      }
      try {
        const scheduled = scheduleBadGuestSleepApproach(
          available, pending.customerId, 'sleep_potion_in_room', true
        );
        if (scheduled !== available) {
          out = scheduled;
          intercepted = true;
        }
      } catch {
        // Keep the native private session if Sleep Actions cannot accept it.
      }
    }
    for (const customer of intercepted ? [] : infiltrators) {
      for (const destination of sleepInterceptionRooms(out, customer)) {
        try {
          let positioned = wifeLocation(out) === destination
            ? out : original.movePlayer(out, pending.targetCharacterId, destination);
          if (customerLocation(positioned, customer.id) !== destination) {
            positioned = original.movePlayer(positioned, customer.id, destination);
          }
          if (wifeLocation(positioned) !== destination
            || customerLocation(positioned, customer.id) !== destination) continue;
          let scheduled = scheduleBadGuestSleepApproach(
            positioned, customer.id, 'sleep_potion_intercept', true
          );
          if (scheduled === positioned) continue;
          const renter = destination === 'upstairs_hall' ? out.tavern?.tonightRenter
            : destination === 'upstairs_room_2' ? out.tavern?.tonightRenter2 : null;
          if (renter?.customerId && renter.customerId !== customer.id) {
            const data = getData(scheduled);
            data.sleepPotion.roomWatch = {
              room: destination,
              renterId: renter.customerId,
              returnRoom: sleepRoom
            };
            scheduled = putData(scheduled, data);
          }
          const wifeName = wifeDisplayName(scheduled);
          const roomName = sleepInterceptionRoomName(out, customer, destination);
          out = appendLog(scheduled, destination === sleepRoom
            ? `${withParticle(customer.name, '은', '는')} 계단에서 비틀거리는 ${withParticle(wifeName, '을', '를')} 붙잡아 부축하는 척하며, 그대로 방 안까지 따라 들어갑니다.`
            : `${withParticle(customer.name, '은', '는')} 계단에서 비틀거리는 ${withParticle(wifeName, '을', '를')} 붙잡아 ${roomName}${roomName.endsWith('실') ? '로' : '으로'} 데려갑니다.`);
          intercepted = true;
          break;
        } catch {
          // Try the next available room without keeping a partial move.
        }
      }
      if (intercepted) break;
    }
    const room = intercepted ? null : sleepPotionRoom(out);
    const roomOpen = room === 'upstairs_hall'
      ? Boolean(out.tavern?.hasRoom)
      : room === 'upstairs_room_2' ? Boolean(out.tavern?.hasRoom2) : false;
    if (roomOpen) {
      out = original.movePlayer(out, pending.targetCharacterId, room);
      out = appendLog(out, `${withParticle(wifeDisplayName(out), '은', '는')} 비틀거리며 객실로 들어가 그대로 잠들었습니다.`);
      const assignment = room === 'upstairs_hall'
        ? out.tavern?.tonightRenter : out.tavern?.tonightRenter2;
      const renterId = typeof assignment?.customerId === 'string' ? assignment.customerId : null;
      if (renterId) {
        const data = getData(out);
        data.sleepPotion.roomWatch = { room, renterId, returnRoom: required.getWifeSleepRoom(out) };
        out = putData(out, data);
      }
    }
    try {
      const sleepActions = getSleepActions();
      const execution = sleepActions?.session?.addDepth?.(out, {
        characterId: pending.targetCharacterId,
        amount: pending.depth
      });
      if (execution?.result?.status === 'applied' && execution.state) out = execution.state;
    } catch {
      // Optional depth consumer; retirement remains BadGuest-owned.
    }
    return out;
  }

  function stripLogsAddedAfter(afterState, beforeState) {
    const beforeLength = beforeState.log?.length || 0;
    if ((afterState.log?.length || 0) <= beforeLength) return afterState;
    return {
      ...afterState,
      log: [...(beforeState.log || [])],
      logSeq: beforeState.logSeq ?? beforeLength
    };
  }

  function handleBadGuestSleepWakeRefusal(state, context = {}) {
    if (!settings.sleepWakeRefusalHandcuffsEnabled) return null;
    if (context.decision?.accepted) return null;
    const scene = required.getActiveScene(state) || context.interaction;
    const customer = context.customer
      || state.customers?.find(entry => String(entry.id) === String(scene?.customerId));
    if (!scene || !customer || !isBadGuest(state, customer)) return null;
    const response = attemptHandcuffAfterRefusalTrigger(state, scene, customer, {
      preserveStage: true,
      source: 'sleep_wake_refusal'
    });
    if (!response) return null;

    const wifeName = wifeDisplayName(state);
    if (response.success) {
      const currentScene = required.getActiveScene(response.state) || scene;
      const line = confusionHandcuffText(state, customer, { success: true, wake: true })
        || `${withParticle(wifeName, '은', '는')} 눈을 뜨자마자 ${customer.name}의 손을 밀어냅니다. 그는 그녀의 손목을 낚아채 수갑을 채우고 다시 끌어당깁니다.`;
      let out = replacePatronScene(response.state, {
        ...currentScene,
        hasBeenRefused: true,
        stalled: 0,
        badGuestSleepWakeRefusalAtSlot: state.slot
      });
      out = updateWife(out, wife => ({
        ...wife,
        lastResponse: line,
        lastResponseSlot: state.slot,
        lastResponseType: context.decision?.emphatic ? 'angry' : 'refuse'
      }));
      out = appendDistressLog(out, line);
      return presentHandcuffAlert(out, customer);
    }

    const service = getSleepActions();
    if (typeof service?.wake?.applyPatronResponse !== 'function') return null;
    const responded = service.wake.applyPatronResponse(
      response.state,
      customer,
      context.decision,
      context.participants || {},
      { returnToTaproom: context.reason === 'depth-depleted' }
    );
    let out = stripLogsAddedAfter(responded, response.state);
    const resisted = response.kind === 'ejected'
      ? `${withParticle(wifeName, '은', '는')} 팔을 거칠게 뿌리치고 그를 밀어냅니다.`
      : `${withParticle(wifeName, '은', '는')} 재빨리 손을 빼내고 그와 거리를 벌립니다.`;
    const line = confusionHandcuffText(state, customer, {
      success: false,
      wake: true,
      ejected: response.kind === 'ejected'
    }) || `${withParticle(wifeName, '은', '는')} 눈을 뜨자마자 ${customer.name}의 손을 밀어냅니다. ${withParticle(customer.name, '은', '는')} 물러나는 대신 수갑을 채우려 손목을 붙잡지만, ${resisted}`;
    out = updateWife(out, wife => ({
      ...wife,
      lastResponse: line,
      lastResponseSlot: state.slot,
      lastResponseType: context.decision?.emphatic ? 'angry' : 'refuse'
    }));
    return appendDistressLog(out, line);
  }

  function observeGeneralSleepWakeRefusal(state, context = {}) {
    if (context.sourceSession?.patronOwnerId === SLEEP_ACTIONS_OWNER_ID) return null;
    return handleBadGuestSleepWakeRefusal(state, context);
  }

  function settleBadGuestSleepPlayerIntervention(state) {
    const data = readData(state);
    if (!data.sleepPotion?.incident && !data.sleepPotion?.roomWatch) return null;
    return putData(state, {
      ...data,
      sleepPotion: {
        ...data.sleepPotion,
        incident: null,
        roomWatch: null
      }
    });
  }

  function resolveBadGuestSharedSearch(state, context = {}) {
    if (!settings.sharedIncidentTrackingEnabled) return null;
    const customer = context.customer;
    if (!customer || !isBadGuest(state, customer)) return null;
    const incident = badGuestIncidentContext(state);
    if (!incident || incident.roomId !== context.wifeRoom) return null;
    if (!incident.anchors.some(anchor => String(anchor.id) !== String(customer.id))) return null;
    if (!incident.candidates.some(candidate => String(candidate.id) === String(customer.id))) return null;
    return true;
  }

  function ensureSleepActionsFlowOwner() {
    const service = getSleepActions();
    if (!service?.patron) return false;
    if (!unregisterSleepActionsFlowOwner
      && typeof service.patron.registerFlowOwner === 'function'
      && typeof service?.wake?.applyPatronResponse === 'function') {
      const unregister = service.patron.registerFlowOwner(SLEEP_ACTIONS_OWNER_ID, {
        onWake: handleBadGuestSleepWakeRefusal,
        onFinish: scheduleNextBadGuestSleepApproach,
        onPlayerIntervention: settleBadGuestSleepPlayerIntervention
      });
      unregisterSleepActionsFlowOwner = typeof unregister === 'function' ? unregister : () => {};
    }
    if (!unregisterSleepActionsWakeObserver
      && typeof service.patron.registerWakeObserver === 'function') {
      const unregister = service.patron.registerWakeObserver(
        SLEEP_ACTIONS_WAKE_OBSERVER_ID,
        observeGeneralSleepWakeRefusal
      );
      unregisterSleepActionsWakeObserver = typeof unregister === 'function' ? unregister : () => {};
    }
    if (!unregisterSleepActionsSearchResolver
      && typeof service.patron.registerSearchResolver === 'function') {
      const unregister = service.patron.registerSearchResolver(
        SLEEP_ACTIONS_SEARCH_RESOLVER_ID,
        resolveBadGuestSharedSearch
      );
      unregisterSleepActionsSearchResolver = typeof unregister === 'function' ? unregister : () => {};
    }
    return Boolean(unregisterSleepActionsFlowOwner);
  }

  function scheduleBadGuestSleepApproach(state, customerId, reason, alreadyPrivate = true) {
    if (!customerId || !ensureSleepActionsFlowOwner()) return state;
    const service = getSleepActions();
    if (typeof service?.patron?.scheduleApproach !== 'function') return state;
    const scheduled = service.patron.scheduleApproach(state, {
      customerId,
      minimumIntent: 'flirt_curious',
      immediate: true,
      alreadyPrivate,
      ownerId: SLEEP_ACTIONS_OWNER_ID,
      reason
    });
    if (scheduled?.state?.characters && scheduled?.state?.locations) return scheduled.state;
    return scheduled?.characters && scheduled?.locations ? scheduled : state;
  }

  function scheduleNextBadGuestSleepApproach(state, context = {}) {
    if (!readData(state).sleepPotion?.incident
      || !['sleeping', 'passed_out'].includes(getWife(state)?.currentTask)) return null;
    const service = getSleepActions();
    if (typeof service?.patron?.clearFlow !== 'function') return null;
    const finishedIds = new Set(Object.keys(context.participants || {}).map(String));
    const cleared = service.patron.clearFlow(state, context.participants || {});
    if (!cleared?.characters || !cleared?.locations) return null;
    const room = wifeLocation(cleared);
    const candidates = (cleared.customers || []).filter(customer => (
      isBadGuest(cleared, customer)
      && ACTIVE_CUSTOMER_STATUSES.has(customer.status)
      && !finishedIds.has(String(customer.id))
      && customerLocation(cleared, customer.id) === room
    )).sort((left, right) => String(left.id).localeCompare(String(right.id)));
    for (const candidate of candidates) {
      try {
        const scheduled = scheduleBadGuestSleepApproach(
          cleared, candidate.id, 'sleep_potion_followup', true
        );
        if (scheduled !== cleared) return scheduled;
      } catch {
        // Other eligible BadGuests can still take the next opening.
      }
    }
    return null;
  }

  function resolveSleepPotionRoomWatch(state) {
    if (!sleepActionsAvailable()) return clearUnavailableSleepPotionState(state);
    const watch = readData(state).sleepPotion?.roomWatch;
    if (!watch) return state;
    if (getWife(state)?.currentTask !== 'sleeping' || wifeLocation(state) !== watch.room) {
      const data = getData(state); data.sleepPotion.roomWatch = null; return putData(state, data);
    }
    const assignment = watch.room === 'upstairs_hall'
      ? state.tavern?.tonightRenter : state.tavern?.tonightRenter2;
    if (assignment?.customerId !== watch.renterId) {
      const data = getData(state); data.sleepPotion.roomWatch = null; return putData(state, data);
    }
    if (customerLocation(state, watch.renterId) !== watch.room) return state;
    const data = getData(state); data.sleepPotion.roomWatch = null;
    let out = putData(state, data);
    const renter = out.customers?.find(customer => customer.id === watch.renterId);
    if (renter && !['drink_only', 'talk_only'].includes(renter.intent)) {
      try { out = scheduleBadGuestSleepApproach(out, renter.id, 'sleep_potion_room', true); } catch {}
      return appendLog(out, `${withParticle(renter.name || '투숙객', '은', '는')} 객실에서 잠든 ${withParticle(wifeDisplayName(out), '을', '를')} 발견합니다.`);
    }
    if (renter && required.getActiveScene(out)) {
      out = original.movePlayer(out, renter.id, 'taproom');
      return appendLog(out, `${withParticle(renter.name || '투숙객', '은', '는')} 자기 객실에서 잠든 ${withParticle(wifeDisplayName(out), '과', '와')} 곁의 손님을 보고 홀로 돌아갑니다.`);
    }
    out = original.movePlayer(out, getWifeId(out), watch.returnRoom || required.getWifeSleepRoom(out));
    return appendLog(out, `${withParticle(wifeDisplayName(out), '은', '는')} 투숙객이 돌아오기 전에 자기 잠자리로 옮겨집니다.`);
  }

  function wrappedMinuteTick(state) {
    ensureSleepActionsFlowOwner();
    const safeState = state;
    const startingParty = readData(safeState).wealthyParty;
    const releasePrepared = prepareRestraintReleaseTick(safeState);
    const prepared = prepareWealthyPartyTick(releasePrepared);
    let out = shortenBadGuestSleepCooldowns(original.minuteTick(prepared));
    out = clearUnavailableSleepPotionState(out);
    out = resolveSleepPotionDeparture(out);
    out = resolveSleepPotionRoomWatch(out);
    if (startingParty?.active
      && (out.slot >= startingParty.endSlot || !backRoomParty(out))) {
      out = finishWealthyParty(out, startingParty, 'time');
    }
    out = processWealthyPartyServeVisit(out);
    out = markNewCustomers(out, state);
    // Give the five-minute residual restraint five complete re-entry rolls.
    // On its final minute a successful re-entry reactivates the restraint;
    // otherwise normalizeEffects releases it immediately afterwards.
    out = tryRehandcuff(out);
    out = normalizeEffects(out);
    out = tryCoordinateBadGuestIncident(out);
    out = tryAmbientBadGuestAction(out);
    out = tryWifeSelfLock(out);
    out = maybeCreateRestraintRescue(out);
    out = wealthyPartyOffer(out);
    out = customizeWealthyPartyPrompt(out);
    out = maybeOfferDrinkingGame(out);
    out = addDrugRecoveryChoice(out);
    out = rewriteIncidentMomentEvent(out);
    return out;
  }

  function wrappedDecreaseWifeIntoxication(state) {
    const out = original.decreaseWifeIntoxication(state);
    const effect = effectOf(readData(out), 'intoxicationFloor');
    if (!effect || out.slot >= effect.endsAtSlot) return out;
    const floor = effect.floor ?? 90;
    const level = getWife(out)?.intoxication?.level ?? 0;
    if (level >= floor) return out;
    return updateWife(out, wife => ({
      ...wife,
      intoxication: { ...(wife.intoxication || {}), level: floor }
    }));
  }

  function wrappedReduceGameAction(state, action) {
    const rewrittenIncident = rewriteIncidentMomentEvent(state);
    if (rewrittenIncident !== state) return wrappedReduceGameAction(rewrittenIncident, action);
    const drinkingGame = readData(state).drinkingGame;
    if (drinkingGame?.wakeAtSlot > state.slot) {
      const minutes = action?.type === 'wait'
        ? ([1, 5, 15].includes(action.minutes) ? action.minutes : 1)
        : action?.type === 'resolve_event'
          ? drinkingGameWaitMinutes(action.choiceId) : 0;
      if (minutes) {
        return advanceDrinkingGame(state, minutes);
      }
      return { ...state, pendingEvent: drinkingGameWaitEvent(state, drinkingGame) };
    }
    const lock = readData(state).doorLock;
    if (action?.type === 'open_the_door' && lock?.active && action.room === lock.roomId) {
      return approachLockedDoor(state, lock);
    }
    if (action?.type === 'open_the_door') {
      const drugDoorEntry = enterDrugDoorWithoutJudgment(state, action.room);
      if (drugDoorEntry) return maybeCreateRestraintRescue(normalizeEffects(drugDoorEntry));
    }
    if (restraintPlayerInterventionRequested(state, action)) {
      return normalizeEffects(rescueWife(state));
    }
    if (action?.type === DRUG_DOOR_INTERVENE_ACTION) {
      if (!drugDoorSceneContext(state)) return normalizeEffects(state);
      return normalizeEffects(beginDrugPatronIntervention(state) || state);
    }
    if (action?.type === DRUG_DOOR_LEAVE_ACTION) {
      return normalizeEffects(leaveDrugDoorScene(state));
    }
    const incidentMoment = incidentMomentFromConversationChoice(state, action);
    if (incidentMoment) return normalizeEffects(openIncidentMomentConversation(state, incidentMoment));
    if (action?.type === 'patron_interaction_choice'
      && DRUG_PATRON_INTERVENTION_CHOICES.has(action.choiceId)) {
      const intervention = beginDrugPatronIntervention(state);
      if (intervention) return normalizeEffects(intervention);
    }
    const custom = customEventChoice(state, action);
    if (custom) return normalizeEffects(custom);
    let out = original.reduceGameAction(state, action);
    out = processWealthyPartyServeVisit(out);
    out = markNewCustomers(out, state);
    out = normalizeEffects(out);
    out = maybeCreateRestraintRescue(out);
    out = customizeWealthyPartyPrompt(out);
    out = maybeOfferDrinkingGame(out);
    out = addDrugRecoveryChoice(out);
    out = rewriteIncidentMomentEvent(out);
    return out;
  }

  function forceMarkCustomer(customerId) {
    const root = store.getState();
    const state = root?.state;
    const customer = state?.customers?.find(entry => entry.id === customerId);
    if (!state || !customer || customer.status === 'gone' || customer.status === 'leaving') return false;
    if (isBadGuest(state, customer)) return true;
    const data = getData(state);
    migrateCustomerClassifications(state, data);
    setCustomerClassification(data, customer, true);
    const next = {
      ...state,
      customers: state.customers.map(entry => entry.id === customer.id
        ? fixedBadGuestCustomer(entry)
        : entry)
    };
    store.setState({ state: enforceBadGuestIdentities(putData(next, data)) });
    return true;
  }

  function forceWealthyPartyOffer() {
    const root = store.getState();
    const state = root?.state;
    if (!state) return false;
    const next = wealthyPartyOffer(state, true);
    if (next === state || next.pendingEvent?.type !== 'bad_guest_wealthy_party_offer') return false;
    store.setState({ state: next });
    return true;
  }

  const DEBUG_COMMANDS = Object.freeze([
    { id: 'mark', group: '분류', label: '나쁜 손님으로 지정' },
    { id: 'wealthy-offer', group: '부유층 단체', label: '단체 제안 열기' },
    { id: 'wealthy-start', group: '부유층 단체', label: '단체 사건 즉시 시작' },
    { id: 'drug-attempt-aphrodisiac', group: '약물 시도', label: '미약 시도' },
    { id: 'drug-attempt-sleep', group: '약물 시도', label: '수면약 시도' },
    { id: 'drug-attempt-intoxication', group: '약물 시도', label: '만취약 시도' },
    { id: 'drug-attempt-confusion', group: '약물 시도', label: '착란약 시도' },
    { id: 'drug-aphrodisiac', group: '약물 즉시 효과', label: '미약 즉시 적용' },
    { id: 'drug-sleep', group: '약물 즉시 효과', label: '수면약 즉시 적용' },
    { id: 'drug-intoxication', group: '약물 즉시 효과', label: '만취약 즉시 적용' },
    { id: 'drug-confusion', group: '약물 즉시 효과', label: '착란약 즉시 적용' },
    { id: 'aggressive-caught', group: '공격적 기만', label: '공격적 기만: 들킴' },
    { id: 'aggressive-believed', group: '공격적 기만', label: '공격적 기만: 속임' },
    { id: 'handcuff', group: '구속 장비', label: '수갑 강제 성공' },
    { id: 'blindfold', group: '구속 장비', label: '안대 강제 성공' },
    { id: 'gag', group: '구속 장비', label: '입마개 강제 성공' },
    { id: 'door-lock', group: '문과 방', label: '현재 방 문 잠그기' },
    { id: 'door-break', group: '문과 방', label: '잠긴 문 부수기 시도' },
    { id: 'back-room-pretext', group: '사적 장소', label: '사적 장소 유도 시도' },
    { id: 'back-room-enter', group: '뒷방', label: '뒷방 대화 즉시 진입' },
    { id: 'drinking-game-offer', group: '뒷방 동전 맞히기', label: '동전 맞히기 제안 강제' },
    { id: 'drinking-game-win', group: '뒷방 동전 맞히기', label: '동전 맞히기 승리' },
    { id: 'drinking-game-loss', group: '뒷방 동전 맞히기', label: '동전 맞히기 패배' },
    { id: 'drinking-game-refuse', group: '뒷방 동전 맞히기', label: '동전 맞히기 거절' },
    { id: 'drinking-game-advance', group: '뒷방 동전 맞히기', label: '패배 장면 1분 진행' },
    { id: 'restraint-rescue', group: '구조·회복', label: '수갑 상태 구조' },
    { id: 'drug-recovery', group: '구조·회복', label: '약물 회복 대화 판정' },
    { id: 'rehandcuff', group: '후속 행동', label: '수갑 재구속 판정' },
    { id: 'wife-self-lock', group: '후속 행동', label: '대상의 자발적 문 잠금 판정' },
  ].map(command => Object.freeze(command)));

  function debugMarkState(state, customerId) {
    const customer = state?.customers?.find(entry => entry.id === customerId);
    if (!state || !customer || !ACTIVE_CUSTOMER_STATUSES.has(customer.status)) return state;
    if (isBadGuest(state, customer)) return state;
    const data = getData(state);
    migrateCustomerClassifications(state, data);
    setCustomerClassification(data, customer, true);
    const next = {
      ...state,
      customers: state.customers.map(entry => entry.id === customer.id
        ? fixedBadGuestCustomer(entry)
        : entry)
    };
    return enforceBadGuestIdentities(putData(next, data));
  }

  function debugExecute(state, request = {}) {
    const command = request.actionId || request.command;
    let next = state;
    if (!state || !DEBUG_COMMANDS.some(entry => entry.id === command)) {
      return { state, status: 'invalid', reason: !state ? 'state_missing' : 'command_unknown' };
    }
    if (command === 'wealthy-offer') next = wealthyPartyOffer(state, true);
    else if (command === 'wealthy-start') next = startWealthyParty(state);
    else if (command === 'door-break') next = attemptBreakDoor(state);
    else if (command === 'restraint-rescue') next = rescueWife(state);
    else if (command === 'drug-recovery') next = resolveDrugRecovery(state);
    else if (command === 'rehandcuff') next = tryRehandcuff(state);
    else if (command === 'wife-self-lock') next = tryWifeSelfLock(state);
    else if (command === 'drinking-game-win') next = resolveDrinkingGame(state, true, { winRoll: 0, rewardRoll: 0.5 });
    else if (command === 'drinking-game-loss') next = resolveDrinkingGame(state, true, { winRoll: 0.99 });
    else if (command === 'drinking-game-refuse') next = resolveDrinkingGame(state, false);
    else if (command === 'drinking-game-advance') next = advanceDrinkingGame(state);
    else {
      const customer = state.customers?.find(entry => entry.id === request.customerId);
      if (!customer) return { state, status: 'ineligible', reason: 'customer_missing' };
      if (command === 'mark') next = debugMarkState(state, request.customerId);
      else if (!isBadGuest(state, customer)) {
        return { state, status: 'ineligible', reason: 'not_bad_guest', command };
      }
      else if (command === 'drug-attempt-sleep' || command === 'drug-sleep') {
        const eligibility = sleepPotionEligibility(state, customer);
        if (eligibility.status !== 'available') {
          return { state, status: 'ineligible', reason: eligibility.reason, command };
        }
        next = command === 'drug-attempt-sleep'
          ? beginDrugAttempt(state, customer, 'debug', { drugKind: 'sleep' })
          : applySleepDrug(state, customer, '디버그 명령으로 약물 효과를 적용했습니다.');
      } else if (command.startsWith('drug-attempt-')) {
        next = beginDrugAttempt(state, customer, 'debug', {
          drugKind: command.slice('drug-attempt-'.length),
        });
      } else if (command.startsWith('drug-')) {
        next = applyDrugByKind(state, customer, command.slice('drug-'.length), '디버그 명령으로 약물 효과를 적용했습니다.');
      } else if (command === 'aggressive-caught' || command === 'aggressive-believed') {
        next = beginAggressiveDeception(state, customer, {
          interaction: { customerId: customer.id, stage: 'chatting' },
          caught: command === 'aggressive-caught',
          sample: false,
        });
      } else if (command === 'handcuff') {
        const result = attemptHandcuff(state, customer, {
          check: { success: true, chance: 1, roll: 0, attacker: 100, defender: 0 },
          roomId: wifeLocation(state),
          source: 'debug',
        });
        next = result?.state || state;
      } else if (command === 'blindfold' || command === 'gag') {
        const result = attemptEquipment(state, customer, command, { roll: 0, roomId: wifeLocation(state) });
        next = result?.state || state;
      } else if (command === 'door-lock') {
        const room = wifeLocation(state);
        next = room && customerLocation(state, customer.id) === room
          ? applyDoorLock(state, customer, room) : state;
      } else if (command === 'back-room-pretext') {
        next = beginBackRoomPretext(state, customer, 'debug');
      } else if (command === 'back-room-enter') {
        next = enterBackRoomConversation(state, customer, 'debug', 'debug');
      } else if (command === 'drinking-game-offer') {
        next = maybeOfferDrinkingGame(state, { force: true, gameRoll: 0, rewardRoll: 0 });
      }
    }
    return {
      state: next,
      status: next === state ? 'ineligible' : 'applied',
      reason: next === state ? 'conditions_not_met' : undefined,
      command,
    };
  }

  function actionCatalog(state, context = {}) {
    const customer = state?.customers?.find(entry => entry.id === context.customerId);
    const badGuest = customer ? isBadGuest(state, customer) : false;
    const sleepEligibility = customer
      ? sleepPotionEligibility(state, customer)
      : { status: 'ineligible', reason: 'actor_missing' };
    const sleepCommands = new Set(['drug-attempt-sleep', 'drug-sleep']);
    const globalCommands = new Set([
      'wealthy-offer', 'wealthy-start', 'door-break', 'restraint-rescue', 'drug-recovery',
      'rehandcuff', 'wife-self-lock', 'drinking-game-win', 'drinking-game-loss',
      'drinking-game-refuse', 'drinking-game-advance',
    ]);
    return DEBUG_COMMANDS.flatMap(command => {
      const sleepEligible = !sleepCommands.has(command.id)
        || sleepEligibility.status === 'available';
      return [Object.freeze({
        ...command,
        actionId: command.id,
        eligible: command.id === 'mark' ? Boolean(customer && !badGuest)
          : globalCommands.has(command.id) ? true : Boolean(customer && badGuest && sleepEligible),
        reason: command.id === 'mark'
          ? (!customer ? 'customer_missing' : badGuest ? 'already_bad_guest' : undefined)
          : globalCommands.has(command.id) ? undefined
            : !customer ? 'customer_missing' : !badGuest ? 'not_bad_guest'
              : sleepCommands.has(command.id) && !sleepEligible ? sleepEligibility.reason : undefined,
      })];
    });
  }

  const CHECK_SETTING_LABELS = {
    wifeDrugNotice: '대상 인물의 미약 간파',
    wifeDrugRefusal: '간파 후 압박 거절',
    husbandNotice: '주인의 기만 간파',
    wifeBackRoomNotice: '대상 인물의 사적 장소 유도 간파',
    wifeBackRoomRefusal: '간파 후 뒷방 압박 거절',
    handcuffGuestSuccess: '손님의 수갑 착용 성공',
    handcuffEscapeSuccess: '대상 인물의 수갑 탈출 성공',
    groupDrugNotice: '단체 미약 간파 저항',
    groupPressureResistance: '단체 미약 압박 저항',
    groupStrengthResistance: '단체 미약 힘 저항',
    groupHandcuffGuestSuccess: '단체 수갑 착용 성공',
    doorBreakAt50: '주인의 문 부수기 성공'
  };

  const SPECIAL_ACTION_LABELS = {
    drug: '미약',
    sleep_drug: '수면약',
    intoxication_drug: '만취약',
    confusion_drug: '착란약',
    aggressive_deception: '공격적 기만',
    blindfold: '안대',
    gag: '입마개',
    back_room_pretext: '사적 장소 유도',
    backRoomPretext: '사적 장소 유도',
    door_lock: '문 잠그기',
    doorLock: '문 잠그기',
    handcuff: '수갑'
  };

  function doorBreakChanceAtStrength(strength) {
    return clamp(
      settings.checkBaseChances.doorBreakAt50 / 100
        + (clamp(strength, 0, 100) - 50) * settings.checkPointIncrements.doorBreakAt50 / 100,
      0,
      1
    );
  }

  function probabilityTarget(state) {
    const scene = required.getActiveScene(state);
    const sceneCustomer = (state.customers || []).find(customer => customer.id === scene?.customerId);
    if (sceneCustomer && isBadGuest(state, sceneCustomer)) return sceneCustomer;
    const room = wifeLocation(state);
    const sameRoom = (state.customers || []).find(customer =>
      isBadGuest(state, customer)
      && customer.status !== 'gone'
      && customer.status !== 'leaving'
      && customerLocation(state, customer.id) === room
    );
    if (sameRoom) return sameRoom;
    return (state.customers || []).find(customer =>
      isBadGuest(state, customer) && customer.status !== 'gone' && customer.status !== 'leaving'
    ) || null;
  }

  function probabilitySnapshot(state, previewSettings = null) {
    if (!state) return null;
    const previous = previewSettings ? copySettings(settings) : null;
    if (previewSettings) applySettingsToConfig(previewSettings);
    try {
      const customer = probabilityTarget(state);
      const scene = required.getActiveScene(state);
      const trust = scene && scene.customerId === customer?.id ? scene.elenaComfort ?? 35 : 25;
      const playerStrength = effectiveAttributes(state.player || {}).strength ?? 50;
      const doorBreakChance = doorBreakChanceAtStrength(playerStrength);
      const checks = {
        wifeDrugNotice: customer ? wifeNoticesDrug(state, customer, trust, false).chance : null,
        wifeDrugRefusal: customer ? wifeRefusesDrug(state, customer, false).chance : null,
        husbandNotice: customer ? husbandNoticesDrug(state, customer, false).chance : null,
        wifeBackRoomNotice: customer ? wifeNoticesBackRoomPretext(state, customer, trust, false).chance : null,
        wifeBackRoomRefusal: customer ? wifeRefusesBackRoomPretext(state, customer, false).chance : null,
        handcuffGuestSuccess: customer ? handcuffStrengthCheck(state, customer, false).chance : null,
        handcuffEscapeSuccess: customer ? handcuffEscapeCheck(state, customer, false).chance : null,
        groupDrugNotice: customer ? groupDrugNoticeCheck(state, customer, trust, false).chance : null,
        groupPressureResistance: customer ? groupDrugPressureCheck(state, customer, false).chance : null,
        groupStrengthResistance: customer ? groupDrugStrengthCheck(state, customer, false).chance : null,
        groupHandcuffGuestSuccess: customer ? groupHandcuffStrengthCheck(state, customer, false).chance : null,
        doorBreakAt50: doorBreakChance
      };
      const candidates = customer && scene?.customerId === customer.id
        ? customTacticCandidates(state, scene, customer)
        : [];
      const totalWeight = candidates.reduce((sum, item) => sum + item.weight, 0);
      const specialActions = candidates.map(item => ({
        kind: item.kind,
        label: SPECIAL_ACTION_LABELS[item.kind] || item.kind,
        weight: item.weight,
        conditionalShare: totalWeight > 0 ? item.weight / totalWeight : 0,
        perMinuteChance: totalWeight > 0 ? CONFIG.activeActionChance * item.weight / totalWeight : 0
      }));
      return {
        targetId: customer?.id || null,
        targetName: customer?.name || null,
        sleepActionsAvailable: sleepActionsAvailable(),
        effectivePatternWeights: effectivePatternWeights(settings.patternWeights),
        effectiveSpecialActionWeights: effectiveSpecialActionWeights(CONFIG.specialActionWeights),
        checks,
        specialActions,
        activeActionChance: CONFIG.activeActionChance,
        cooldownRemaining: customer
          ? Math.max(0, CONFIG.actionCooldownMinutes - (state.slot - (customer.badGuestLastActionSlot ?? -9999)))
          : 0,
        doorBreakChance,
        drugLevel: drugLevelAt(state),
        drugAcceptanceBonus: drugLevelAt(state) * CONFIG.drugMaxAcceptanceBonus / 100
      };
    } finally {
      if (previous) applySettingsToConfig(previous);
    }
  }

  function percentText(value, digits = 1) {
    if (value == null || !Number.isFinite(value)) return '—';
    const percent = value * 100;
    return `${percent.toFixed(Number.isInteger(percent) ? 0 : digits)}%`;
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function readSettingsForm(modal) {
    const next = copySettings(settings);
    for (const input of Array.from(modal.querySelectorAll?.('[data-bad-guest-setting]') || [])) {
      const path = input.dataset.badGuestSetting.split('.');
      let target = next;
      while (path.length > 1) {
        const key = path.shift();
        target[key] ??= {};
        target = target[key];
      }
      target[path[0]] = input.type === 'checkbox' ? input.checked : Number(input.value);
    }
    return normalizeSettings(next);
  }

  function settingValueAt(source, pathText) {
    return pathText.split('.').reduce((value, key) => value?.[key], source);
  }

  function fillSettingsForm(modal, source) {
    const normalized = normalizeSettings(source);
    for (const input of Array.from(modal.querySelectorAll?.('[data-bad-guest-setting]') || [])) {
      const value = settingValueAt(normalized, input.dataset.badGuestSetting);
      if (input.type === 'checkbox') input.checked = value === true;
      else input.value = value;
    }
  }

  const SPECIAL_SETTING_TOOLTIPS = {
    ambientDrugChancePerMinute: '정식 대화·응대 장면 밖에서 같은 방의 나쁜 손님이 미약을 시도하는 분당 확률입니다. 미약 효과가 없고 재사용 대기시간이 끝났을 때만 판정합니다.',
    ambientBackRoomChancePerMinute: '정식 대화·응대 장면 밖에서 홀의 나쁜 손님이 이용 가능한 사적 장소로 유도하려는 분당 확률입니다. 미약과 같은 한 번의 난수 구간을 나눠 씁니다.',
    activeActionChance: '나쁜 손님과 대화·응대 중일 때 매분 특수행동 후보를 뽑을지 결정하는 전체 확률입니다. 성공하면 아래 가중치로 실제 행동 하나를 고릅니다.',
    'specialActionWeights.drug': '미약: 술잔에 약을 넣어 대상 인물의 간파와 압박 거절 판정을 거치게 하는 행동입니다. 현재 사용할 수 있는 후보들의 가중치 합으로 나눠 실제 확률을 정합니다.',
    'specialActionWeights.sleepDrug': '수면약: 원본 물약 잔 처리로 실제 수면 물약 한 단위를 먹이고, 약효에 따른 위층 이동을 기다리게 합니다.',
    'specialActionWeights.intoxicationDrug': '만취약: 취기를 90으로 만들고 설정된 시간 동안 하한을 유지합니다.',
    'specialActionWeights.confusionDrug': '착란약: 적용 순간 오인 기준 인물을 정해 60분 동안 수용 판정에 투영합니다.',
    'specialActionWeights.aggressiveDeception': '공격적 기만: 나쁜 손님이 꾸며 낸 손해를 내세워 돈이나 수상한 술을 요구하는 BadGuest 소유 행동입니다.',
    'specialActionWeights.blindfold': '안대: 시각적 공개 압박과 발견 중단만 가립니다. 착란 대상을 플레이어로 보는 동안 착용 성공률이 50%에서 70%로 올라갑니다.',
    'specialActionWeights.gag': '입마개: 거절은 그대로 남기되 말로 된 거절을 몸짓과 막힌 소리로 바꿉니다. 착란 대상을 플레이어로 보는 동안 착용 성공률이 50%에서 70%로 올라갑니다.',
    'specialActionWeights.backRoomPretext': '사적 장소 유도: 홀의 낮은 대화 단계에서 원본의 이용 가능한 방 후보와 욕실 안내 경로를 이용합니다. 방의 선호 점수가 선택에 반영됩니다.',
    'specialActionWeights.doorLock': '문 잠그기: 주인이 없는 홀 밖 방에서 안쪽 빗장을 잠그는 행동입니다. 모든 응대 단계에서 후보가 될 수 있습니다.',
    selfLockMaxChancePerMinute: '대상 인물이 스스로 문을 잠그는 자율 행동의 최대 분당 확률입니다. 실제 확률은 이 값 × 심적 이탈 보정 × 해당 손님 애착 보정입니다.',
    actionCooldownMinutes: '서로 다른 특수행동을 연달아 쓰기 전에 기다리는 공용 간격입니다.',
    drugActionCooldownMinutes: '같은 손님이 미약을 다시 시도하기 전에 기다리는 개별 재사용 시간입니다.',
    backRoomActionCooldownMinutes: '같은 손님이 사적 장소 유도를 다시 시도하기 전에 기다리는 개별 재사용 시간입니다.',
    refusalHandcuffChance: '대상 인물이 상위 단계 행동을 거절했을 때만 수갑을 시도할 확률입니다. 수갑은 일반 특수행동 후보에는 포함되지 않습니다.',
    rehandcuffChancePerMinute: '행동은 끝났지만 수갑이 남은 5분 동안 같은 손님이 다시 붙잡아 몸 더듬기 장면으로 돌아가는 분당 확률입니다. 다섯 번의 판정이 모두 실패하면 수갑이 풀립니다.',
    nonEnforcerHandcuffMultiplierPercent: '제압형이 아닌 유인형·잠입형·가장형의 거절 직후 수갑 시도율에 공통 수갑 확률의 몇 퍼센트를 적용할지 정합니다.',
    intoxicationDurationMinutes: '만취약이 취기 90 하한을 유지하는 시간입니다.',
    lurerFinishDelayMinutes: '유인형이 만취약을 쓴 뒤 남은 술을 다시 권하기까지 기다리는 시간입니다.',
    lurerFinishWeight: '유인형의 남은 술 권유가 다른 특수행동 후보와 경쟁할 때 사용하는 가중치입니다.',
    lurerFinishMinRefusal: '유인형의 남은 술 권유에서 원래 약술 거절률에 적용하는 하한입니다.',
    lurerFinishMaxRefusal: '유인형의 남은 술 권유에서 원래 약술 거절률에 적용하는 상한입니다.'
  };

  const CHECK_SETTING_TOOLTIPS = {
    wifeDrugNotice: '간파율 = 기준 확률 + (대상 인물 관찰 − 손님 은폐) × 점수 차이 1당 증분. 대상 인물 관찰은 취기 1당 0.25, 최대 20 낮아져 기본 증분에서는 간파율이 최대 12%p 낮아집니다. 착란 대상을 플레이어로 보는 동안에는 여기서 다시 20%p 낮아집니다. 하한 5%, 보호 성향 없음 상한 90%/있음 95%입니다.',
    wifeDrugRefusal: '거절률 = 기준 확률 + (대상 인물 저항 − 손님 압박) × 점수 차이 1당 증분. 착란 대상을 플레이어로 보는 동안 20%p 낮아집니다. 저항은 재치×0.3 + 침착×0.35 + 자신감×0.35입니다.',
    husbandNotice: '간파율 = 기준 확률 + (주인 관찰 − 손님 은폐) × 점수 차이 1당 증분. 관찰은 재치×0.65 + 침착×0.25 + 교활함×0.1 + 기력 보정입니다.',
    wifeBackRoomNotice: '간파율 = 기준 확률 + (대상 인물 관찰 − 손님 은폐) × 점수 차이 1당 증분. 대상 인물 관찰은 취기 1당 0.25, 최대 20 낮아져 기본 증분에서는 간파율이 최대 10%p 낮아집니다. 착란 대상을 플레이어로 보는 동안에는 여기서 다시 20%p 낮아집니다. 하한 5%, 보호 성향 없음 상한 90%/있음 95%입니다.',
    wifeBackRoomRefusal: '거절률 = 기준 확률 + (대상 인물 저항 − 손님 압박) × 점수 차이 1당 증분. 착란 대상을 플레이어로 보는 동안 20%p 낮아지며, 간파와 압박 거절을 모두 성공해야 홀에 남습니다.',
    handcuffGuestSuccess: '손님 성공률 = 기준 확률 + (손님 평균 − 대상 인물 평균) × 점수 차이 1당 증분. 평균은 유효 근력과 유효 손재주의 평균입니다. 착란 대상을 플레이어로 보는 동안 20%p 높아집니다.',
    handcuffEscapeSuccess: '대상 인물 탈출률 = 기준 확률 + (대상 인물 평균 − 손님 평균) × 점수 차이 1당 증분. 단계 상승 수용 점수가 0 미만일 때만 판정합니다.',
    groupDrugNotice: '단체 전용 간파 저항입니다. 기준 확률과 점수 차이 1당 증분을 사용하며 하한 5%·상한 90%입니다.',
    groupPressureResistance: '단체 전용 압박 저항입니다. 기준 확률과 점수 차이 1당 증분을 사용하며 하한 5%·상한 90%입니다.',
    groupStrengthResistance: '단체 전용 힘 저항입니다. 기준 확률과 점수 차이 1당 증분을 사용하며 하한 5%·상한 90%입니다.',
    groupHandcuffGuestSuccess: '단체 수갑 1인 성공률 = 기준 확률 + (손님 평균 − 대상 인물 평균) × 점수 차이 1당 증분. 착란 대상을 플레이어로 보는 동안 20%p 높아지며, 다섯 명이 한 번씩 시도합니다.',
    doorBreakAt50: '문 부수기 성공률 = 근력 50 기준 확률 + (유효 근력 − 50) × 능력치 1당 증분입니다.'
  };

  function settingInput(path, value, min, max, step = 1, label = '', options = {}) {
    const tooltip = options.tooltip || SPECIAL_SETTING_TOOLTIPS[path] || '';
    const live = options.liveKey
      ? `<span data-bad-guest-live="${options.liveKey}" style="min-width:0;text-align:right;color:#fbbf24;font-size:11px;line-height:1.25;white-space:normal">—</span>`
      : '';
    const columns = options.liveKey ? 'minmax(90px,1fr) 66px 82px' : 'minmax(150px,1fr) 92px';
    const title = tooltip ? ` title="${escapeHtml(tooltip)}"` : '';
    const hint = tooltip ? ' <span style="color:#78716c;font-size:10px">ⓘ</span>' : '';
    const fieldId = `badguest-legacy-setting-${path.replace(/[^a-zA-Z0-9_-]/g, '-')}`;
    return `<label${title} for="${fieldId}" style="display:grid;grid-template-columns:${columns};gap:8px;align-items:center;padding:5px 0;color:#d6d3d1;font-size:12px"><span style="cursor:${tooltip ? 'help' : 'default'}">${label}${hint}</span><input id="${fieldId}" name="${escapeHtml(path)}" data-bad-guest-setting="${path}" type="number" min="${min}" max="${max}" step="${step}" value="${value}" style="width:100%;border:1px solid #57534e;border-radius:4px;background:#1c1917;color:#fafaf9;padding:5px 7px;text-align:right">${live}</label>`;
  }

  function settingCheckbox(path, checked, label, tooltip = '') {
    const fieldId = `badguest-legacy-setting-${path.replace(/[^a-zA-Z0-9_-]/g, '-')}`;
    const title = tooltip ? ` title="${escapeHtml(tooltip)}"` : '';
    return `<label${title} for="${fieldId}" style="display:flex;align-items:center;gap:8px;padding:4px 0;font-size:12px;color:#d6d3d1;cursor:${tooltip ? 'help' : 'default'}"><input id="${fieldId}" name="${escapeHtml(path)}" data-bad-guest-setting="${path}" type="checkbox" ${checked ? 'checked' : ''}>${escapeHtml(label)}</label>`;
  }

  function checkSettingInputs(...keys) {
    return keys.map(key => {
      const label = CHECK_SETTING_LABELS[key];
      return [
        settingInput(`checkBaseChances.${key}`, settings.checkBaseChances[key], 0, 100, 0.1, `${label} 기본 확률(%)`, { liveKey: `check.${key}`, tooltip: CHECK_SETTING_TOOLTIPS[key] }),
        settingInput(`checkPointIncrements.${key}`, settings.checkPointIncrements[key], 0, 5, 0.05, `${label} 점수 차이 1당 증분(%p)`, { tooltip: CHECK_SETTING_TOOLTIPS[key] })
      ].join('');
    }).join('');
  }

  function setLiveSettingText(modal, key, text, title = '') {
    const node = modal.querySelector?.(`[data-bad-guest-live="${key}"]`);
    if (!node) return;
    if (node.textContent !== text) node.textContent = text;
    node.title = title;
  }

  function renderSettingsProbabilityPreview(modal) {
    const container = modal.querySelector?.('[data-bad-guest-probability-preview]');
    const state = store.getState()?.state;
    if (!container || !state) return;
    const draft = readSettingsForm(modal);
    const snapshot = probabilitySnapshot(state, draft);
    const cumulativeChance = (percent, minutes) => 1 - (1 - clamp(percent / 100, 0, 1)) ** minutes;
    setLiveSettingText(modal, 'ambientDrug30', `30분 ${percentText(cumulativeChance(draft.ambientDrugChancePerMinute, 30))}`, '이 행동이 30분 동안 단독으로 계속 판정될 때 한 번 이상 발생할 확률');
    setLiveSettingText(modal, 'ambientBack30', `30분 ${percentText(cumulativeChance(draft.ambientBackRoomChancePerMinute, 30))}`, '이 행동이 30분 동안 단독으로 계속 판정될 때 한 번 이상 발생할 확률');
    setLiveSettingText(modal, 'activeAction', `분당 ${percentText(draft.activeActionChance / 100)}`);
    setLiveSettingText(modal, 'rehandcuff5', `5분 ${percentText(cumulativeChance(draft.rehandcuffChancePerMinute, 5))}`, '수갑이 남은 다섯 번의 분 처리 중 한 번 이상 재진입할 확률');
    setLiveSettingText(modal, 'selfLockMax', `최대 ${percentText(draft.selfLockMaxChancePerMinute / 100)}`);
    setLiveSettingText(modal, 'refusalHandcuff', `${percentText(draft.refusalHandcuffChance / 100)}`);
    const activePatternWeights = effectivePatternWeights(draft.patternWeights);
    const patternWeightTotal = Object.values(activePatternWeights)
      .reduce((sum, weight) => sum + Math.max(0, weight), 0);
    for (const key of ['enforcer', 'lurer', 'infiltrator', 'impostor']) {
      setLiveSettingText(
        modal,
        `pattern.${key}`,
        patternWeightTotal > 0 ? `실효 ${percentText(activePatternWeights[key] / patternWeightTotal)}` : '—'
      );
    }
    for (const [key] of Object.entries(CHECK_SETTING_LABELS)) {
      setLiveSettingText(modal, `check.${key}`, `현재 ${percentText(snapshot?.checks?.[key])}`, CHECK_SETTING_TOOLTIPS[key]);
    }
    const actionBySettingKey = {
      drug: snapshot?.specialActions?.find(action => action.kind === 'drug'),
      sleepDrug: snapshot?.specialActions?.find(action => action.kind === 'sleep_drug'),
      intoxicationDrug: snapshot?.specialActions?.find(action => action.kind === 'intoxication_drug'),
      confusionDrug: snapshot?.specialActions?.find(action => action.kind === 'confusion_drug'),
      aggressiveDeception: snapshot?.specialActions?.find(action => action.kind === 'aggressive_deception'),
      blindfold: snapshot?.specialActions?.find(action => action.kind === 'blindfold'),
      gag: snapshot?.specialActions?.find(action => action.kind === 'gag'),
      backRoomPretext: snapshot?.specialActions?.find(action => action.kind === 'back_room_pretext'),
      doorLock: snapshot?.specialActions?.find(action => action.kind === 'door_lock')
    };
    const activeSpecialActionWeights = effectiveSpecialActionWeights(draft.specialActionWeights);
    const allWeightTotal = Object.values(activeSpecialActionWeights)
      .reduce((sum, weight) => sum + Math.max(0, weight), 0);
    for (const [key, action] of Object.entries(actionBySettingKey)) {
      const allCandidateChance = allWeightTotal > 0
        ? draft.activeActionChance / 100 * Math.max(0, activeSpecialActionWeights[key]) / allWeightTotal
        : 0;
      setLiveSettingText(
        modal,
        `weight.${key}`,
        key === 'sleepDrug' && !snapshot?.sleepActionsAvailable
          ? '비활성 · sleep-actions 필요'
          : action
          ? `전체 ${percentText(allCandidateChance)} · 현재 ${percentText(action.perMinuteChance)}`
          : `전체 ${percentText(allCandidateChance)} · 현재 후보 아님`,
        action
          ? '전체는 모든 특수행동이 후보일 때의 분당 확률이며, 현재는 실제 위치·단계·효과 조건의 후보만 반영한 분당 확률입니다.'
          : '전체는 모든 특수행동이 후보일 때의 분당 확률입니다. 현재 위치·단계·효과 조건에서는 이 행동이 후보에 포함되지 않습니다.'
      );
    }
    const actionRows = snapshot?.specialActions?.length
      ? snapshot.specialActions.map(action => `<div style="display:flex;justify-content:space-between;gap:12px;padding:2px 0"><span>${escapeHtml(action.label)} (가중치 ${action.weight})</span><span style="color:#fbbf24">분당 ${percentText(action.perMinuteChance)}</span></div>`).join('')
      : '<div style="color:#78716c">현재 대화 조건에서 사용할 수 있는 특수행동이 없습니다.</div>';
    const content = `
      <div style="color:#a8a29e">계산 대상: ${escapeHtml(snapshot?.targetName || '현재 나쁜 손님 없음')}</div>
      <div style="margin-top:6px">${actionRows}</div>
      <div style="margin-top:6px;color:#a8a29e">문 부수기 현재 성공률 ${percentText(snapshot?.doorBreakChance)} · 미약 수용 보정 ${snapshot?.drugAcceptanceBonus?.toFixed?.(1) ?? '0'}점</div>`;
    if (container.innerHTML !== content) container.innerHTML = content;
  }

  function closeSettingsModal() {
    document?.querySelector?.('[data-bad-guest-settings-modal="true"]')?.remove();
  }

  function openSettingsModal() {
    if (!document?.body || typeof document.createElement !== 'function') return;
    closeSettingsModal();
    const modal = document.createElement('div');
    modal.dataset.badGuestSettingsModal = 'true';
    modal.style.cssText = 'position:fixed;inset:0;z-index:2147483600;display:flex;align-items:center;justify-content:center;padding:18px;background:rgba(0,0,0,.72);font-family:inherit';
    modal.innerHTML = `
      <div role="dialog" aria-modal="true" aria-label="나쁜 손님 모드 설정" style="width:min(760px,96vw);max-height:92vh;overflow:auto;border:1px solid #57534e;border-radius:8px;background:#0c0a09;color:#e7e5e4;box-shadow:0 20px 60px rgba(0,0,0,.65)">
        <div style="position:sticky;top:0;z-index:1;display:flex;justify-content:space-between;align-items:center;padding:13px 16px;border-bottom:1px solid #44403c;background:#0c0a09"><div><div style="font-size:16px;font-weight:700;color:#f5f5f4">나쁜 손님 모드 설정</div><div style="margin-top:2px;font-size:11px;color:#78716c">모든 저장 파일에 공통으로 적용됩니다.</div></div><button type="button" data-bad-guest-settings-close style="border:0;background:transparent;color:#a8a29e;font-size:22px;cursor:pointer">×</button></div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;padding:14px">
          <section style="grid-column:1/-1;border:1px solid #292524;border-radius:6px;padding:10px 12px"><h3 style="margin:0 0 6px;color:#fda4af;font-size:13px">미약</h3>
            ${settingInput('drugMaxAcceptanceBonus', settings.drugMaxAcceptanceBonus, 0, 500, 10, '최대 수용도 보정')}
            ${settingInput('drugRampMinutes', settings.drugRampMinutes, 1, 240, 1, '열기가 차오르는 시간(분)')}
            ${settingInput('drugPlateauMinutes', settings.drugPlateauMinutes, 0, 480, 1, '최대 유지 시간(분)')}
            ${settingInput('drugFallMinutes', settings.drugFallMinutes, 1, 240, 1, '열기가 가라앉는 시간(분)')}
            ${settingInput('ambientDrugChancePerMinute', settings.ambientDrugChancePerMinute, 0, 100, 0.1, '응대 밖 미약 확률/분(%)', { liveKey: 'ambientDrug30' })}
            ${settingInput('drugActionCooldownMinutes', settings.drugActionCooldownMinutes, 0, 240, 1, '같은 손님의 미약 개별 쿨다운(분)')}
            ${checkSettingInputs('wifeDrugNotice', 'wifeDrugRefusal', 'husbandNotice')}
          </section>
          <section style="border:1px solid #292524;border-radius:6px;padding:10px 12px"><h3 style="margin:0 0 6px;color:#a5b4fc;font-size:13px">수면약</h3>
            ${settingInput('sleepPotionDepartureDelayMin', settings.sleepPotionDepartureDelayMin, 0, 240, 1, '이동 대기 최소(분)')}
            ${settingInput('sleepPotionDepartureDelayMax', settings.sleepPotionDepartureDelayMax, 0, 240, 1, '이동 대기 최대(분)')}
            ${settingInput('sleepPotionGuestRoomChance', settings.sleepPotionGuestRoomChance, 0, 100, 0.1, '가로채기 없을 때 열린 객실 확률(%)')}
          </section>
          <section style="border:1px solid #292524;border-radius:6px;padding:10px 12px"><h3 style="margin:0 0 6px;color:#fbbf24;font-size:13px">등장 확률</h3>
            ${settingInput('spawnChance', settings.spawnChance, 0, 100, 0.1, '새 손님의 나쁜 손님 확률(%)')}
            ${settingInput('wealthyPartyDailyChance', settings.wealthyPartyDailyChance, 0, 100, 0.1, '부유한 단체손님 일일 확률(%)')}
            ${settingInput('drinkingGameVisitChance', settings.drinkingGameVisitChance, 0, 100, 0.1, '나쁜 손님의 방문별 술게임 제안 확률(%)')}
          </section>
          <section style="grid-column:1/-1;border:1px solid #292524;border-radius:6px;padding:10px 12px"><h3 style="margin:0 0 6px;color:#fbbf24;font-size:13px">행동 유형</h3>
            ${settingInput('patternWeights.enforcer', settings.patternWeights.enforcer, 0, 100, 1, '제압형 분포 가중치', { liveKey: 'pattern.enforcer' })}
            ${settingInput('patternWeights.lurer', settings.patternWeights.lurer, 0, 100, 1, '유인형 분포 가중치', { liveKey: 'pattern.lurer' })}
            ${settingInput('patternWeights.infiltrator', settings.patternWeights.infiltrator, 0, 100, 1, '잠입형 분포 가중치', { liveKey: 'pattern.infiltrator' })}
            ${settingInput('patternWeights.impostor', settings.patternWeights.impostor, 0, 100, 1, '가장형 분포 가중치', { liveKey: 'pattern.impostor' })}
            ${settingInput('nonEnforcerHandcuffMultiplierPercent', settings.nonEnforcerHandcuffMultiplierPercent, 0, 100, 1, '제압형 외 수갑 시도율(공통 대비 %)')}
            ${settingInput('intoxicationDurationMinutes', settings.intoxicationDurationMinutes, 1, 480, 1, '만취약 유지 시간(분)')}
            ${settingInput('lurerFinishDelayMinutes', settings.lurerFinishDelayMinutes, 0, 240, 1, '유인형 후속 권유 대기(분)')}
            ${settingInput('lurerFinishWeight', settings.lurerFinishWeight, 0, 100, 0.1, '유인형 후속 권유 가중치')}
            ${settingInput('lurerFinishMinRefusal', settings.lurerFinishMinRefusal, 0, 100, 0.1, '유인형 후속 최소 거절률(%)')}
            ${settingInput('lurerFinishMaxRefusal', settings.lurerFinishMaxRefusal, 0, 100, 0.1, '유인형 후속 최대 거절률(%)')}
            <div style="margin-top:6px;color:#78716c;font-size:11px;line-height:1.5">네 분포값은 합계에 대한 상대 가중치입니다. 기본값 30/30/20/20은 그대로 30%/30%/20%/20%가 됩니다.</div>
          </section>
          <section style="grid-column:1/-1;border:1px solid #292524;border-radius:6px;padding:10px 12px"><h3 style="margin:0 0 6px;color:#facc15;font-size:13px">나쁜 손님 협력</h3>
            ${settingCheckbox('cooperativeIncidentMovementEnabled', settings.cooperativeIncidentMovementEnabled, '사고 현장으로 다른 나쁜 손님이 이동', 'BadGuest 약효·수면·구속구 사고를 같은 방에서 목격한 나쁜 손님이 있으면 다른 방의 나쁜 손님도 그 장소로 이동합니다.')}
            ${settingCheckbox('sharedIncidentTrackingEnabled', settings.sharedIncidentTrackingEnabled, '수면 행동의 목격 정보를 나쁜 손님끼리 공유', '기반 수면 행동의 원격 탐색 확률 대신 BadGuest 사고 현장을 확정해서 찾습니다. 기반의 침실·쿨다운·점유 제한은 유지됩니다.')}
          </section>
          <section style="grid-column:1/-1;border:1px solid #292524;border-radius:6px;padding:10px 12px"><h3 style="margin:0 0 6px;color:#fb923c;font-size:13px">사적 장소 유도</h3>
            ${settingInput('ambientBackRoomChancePerMinute', settings.ambientBackRoomChancePerMinute, 0, 100, 0.1, '응대 밖 장소 유도/분(%)', { liveKey: 'ambientBack30' })}
            ${settingInput('backRoomActionCooldownMinutes', settings.backRoomActionCooldownMinutes, 0, 240, 1, '같은 손님의 장소 유도 개별 쿨다운(분)')}
            ${checkSettingInputs('wifeBackRoomNotice', 'wifeBackRoomRefusal')}
          </section>
          <section style="border:1px solid #292524;border-radius:6px;padding:10px 12px"><h3 style="margin:0 0 6px;color:#fdba74;font-size:13px">문 잠그기·탈출</h3>
            ${settingInput('selfLockMaxChancePerMinute', settings.selfLockMaxChancePerMinute, 0, 100, 0.1, '대상 인물의 자발적 잠금 최대/분(%)', { liveKey: 'selfLockMax' })}
            ${checkSettingInputs('doorBreakAt50')}
          </section>
          <section style="border:1px solid #292524;border-radius:6px;padding:10px 12px"><h3 style="margin:0 0 6px;color:#fb923c;font-size:13px">특수행동 공통</h3>
            ${settingInput('activeActionChance', settings.activeActionChance, 0, 100, 0.1, '대화 중 특수행동 판정/분(%)', { liveKey: 'activeAction' })}
            ${settingInput('specialActionWeights.drug', settings.specialActionWeights.drug, 0, 100, 0.1, '미약 가중치', { liveKey: 'weight.drug' })}
            ${settingInput('specialActionWeights.sleepDrug', settings.specialActionWeights.sleepDrug, 0, 100, 0.1, '수면약 가중치', { liveKey: 'weight.sleepDrug' })}
            ${settingInput('specialActionWeights.intoxicationDrug', settings.specialActionWeights.intoxicationDrug, 0, 100, 0.1, '만취약 가중치', { liveKey: 'weight.intoxicationDrug' })}
            ${settingInput('specialActionWeights.confusionDrug', settings.specialActionWeights.confusionDrug, 0, 100, 0.1, '착란약 가중치', { liveKey: 'weight.confusionDrug' })}
            ${settingInput('specialActionWeights.aggressiveDeception', settings.specialActionWeights.aggressiveDeception, 0, 100, 0.1, '공격적 기만 가중치', { liveKey: 'weight.aggressiveDeception' })}
            ${settingInput('specialActionWeights.blindfold', settings.specialActionWeights.blindfold, 0, 100, 0.1, '안대 가중치', { liveKey: 'weight.blindfold' })}
            ${settingInput('specialActionWeights.gag', settings.specialActionWeights.gag, 0, 100, 0.1, '입마개 가중치', { liveKey: 'weight.gag' })}
            ${settingInput('specialActionWeights.backRoomPretext', settings.specialActionWeights.backRoomPretext, 0, 100, 0.1, '사적 장소 유도 가중치', { liveKey: 'weight.backRoomPretext' })}
            ${settingInput('specialActionWeights.doorLock', settings.specialActionWeights.doorLock, 0, 100, 0.1, '문 잠그기 가중치', { liveKey: 'weight.doorLock' })}
            ${settingInput('actionCooldownMinutes', settings.actionCooldownMinutes, 0, 60, 1, '서로 다른 행동 사이 간격(분)')}
            <div style="margin-top:6px;color:#78716c;font-size:11px;line-height:1.5">실제 분당 확률 = 사용 판정 확률 × 사용 가능한 행동의 가중치 ÷ 가중치 합계</div>
          </section>
          <section style="grid-column:1/-1;border:1px solid #292524;border-radius:6px;padding:10px 12px"><h3 style="margin:0 0 6px;color:#f87171;font-size:13px">수갑</h3>
            ${settingInput('refusalHandcuffChance', settings.refusalHandcuffChance, 0, 100, 0.1, '거절 직후 수갑 확률(%)', { liveKey: 'refusalHandcuff' })}
            ${settingInput('rehandcuffChancePerMinute', settings.rehandcuffChancePerMinute, 0, 100, 0.01, '수갑 재진입 확률/분(%)', { liveKey: 'rehandcuff5' })}
            ${settingCheckbox('sleepWakeRefusalHandcuffsEnabled', settings.sleepWakeRefusalHandcuffsEnabled, '잠에서 깬 뒤 거절에도 수갑 시도', 'BadGuest가 관여한 수면 장면에서 깨어난 뒤 실제 행위를 거절하면 위의 공통 수갑 확률과 힘겨루기를 사용합니다.')}
            ${settingCheckbox('confusionExpiryRefusalHandcuffsEnabled', settings.confusionExpiryRefusalHandcuffsEnabled, '착란이 끝난 뒤 현실 거절에도 수갑 시도', '착란 중에는 수용했지만 실제 손님이라면 거절했을 행위가 효과 만료 뒤 이어질 때 위의 공통 수갑 확률과 힘겨루기를 사용합니다.')}
            ${checkSettingInputs('handcuffGuestSuccess', 'handcuffEscapeSuccess')}
          </section>
          <section style="grid-column:1/-1;border:1px solid #292524;border-radius:6px;padding:10px 12px"><h3 style="margin:0 0 6px;color:#c4b5fd;font-size:13px">부유한 단체손님</h3>
            ${checkSettingInputs('groupDrugNotice', 'groupPressureResistance', 'groupStrengthResistance', 'groupHandcuffGuestSuccess')}
            <div style="margin-top:6px;color:#78716c;font-size:11px;line-height:1.5">단체 미약 저항 3종은 하한 5%·상한 90%, 단체 수갑은 하한 5%·상한 95%입니다. 각 기본 확률과 점수 차이 1당 증분을 따로 조절할 수 있습니다.</div>
          </section>
          <section style="grid-column:1/-1;border:1px solid #292524;border-radius:6px;padding:10px 12px"><h3 style="margin:0 0 7px;color:#fde68a;font-size:13px">확률 계산</h3><div data-bad-guest-probability-preview style="font-size:11px;line-height:1.45"></div></section>
          <section style="grid-column:1/-1;border:1px solid #292524;border-radius:6px;padding:10px 12px"><h3 style="margin:0 0 7px;color:#93c5fd;font-size:13px">화면 표시</h3><div style="display:grid;gap:7px">
            <label for="badguest-legacy-setting-showBadGuestMarkers" title="현재 주점 내부에 남아 있는 나쁜 손님은 손님 상태 목록의 이름 뒤에 작은 빨간 점으로 표시합니다." style="display:flex;align-items:center;gap:8px;font-size:12px;color:#d6d3d1;cursor:help"><input id="badguest-legacy-setting-showBadGuestMarkers" name="showBadGuestMarkers" data-bad-guest-setting="showBadGuestMarkers" type="checkbox" ${settings.showBadGuestMarkers ? 'checked' : ''}>주점 안의 나쁜 손님 표시</label>
            <label for="badguest-legacy-setting-debugProbabilityPanel" style="display:flex;align-items:center;gap:8px;font-size:12px;color:#d6d3d1"><input id="badguest-legacy-setting-debugProbabilityPanel" name="debugProbabilityPanel" data-bad-guest-setting="debugProbabilityPanel" type="checkbox" ${settings.debugProbabilityPanel ? 'checked' : ''}>게임 화면에 접을 수 있는 확률 계산창 표시</label>
          </div></section>
        </div>
        <div style="position:sticky;bottom:0;display:flex;justify-content:flex-end;gap:8px;padding:11px 14px;border-top:1px solid #44403c;background:#0c0a09"><button type="button" data-bad-guest-settings-reset style="padding:7px 11px;border:1px solid #57534e;border-radius:4px;background:#1c1917;color:#d6d3d1;cursor:pointer">기본값 복원</button><button type="button" data-bad-guest-settings-cancel style="padding:7px 11px;border:1px solid #57534e;border-radius:4px;background:#1c1917;color:#d6d3d1;cursor:pointer">취소</button><button type="button" data-bad-guest-settings-save style="padding:7px 13px;border:1px solid #b45309;border-radius:4px;background:#92400e;color:#fef3c7;font-weight:700;cursor:pointer">저장</button></div>
      </div>`;
    modal.addEventListener('click', event => {
      if (event.target === modal || event.target.closest?.('[data-bad-guest-settings-close],[data-bad-guest-settings-cancel]')) closeSettingsModal();
      if (event.target.closest?.('[data-bad-guest-settings-save]')) {
        saveGlobalSettings(readSettingsForm(modal));
        closeSettingsModal();
        scheduleAcceptanceInspectorRender();
      }
      if (event.target.closest?.('[data-bad-guest-settings-reset]')) {
        fillSettingsForm(modal, DEFAULT_SETTINGS);
        renderSettingsProbabilityPreview(modal);
      }
    });
    modal.addEventListener('input', () => renderSettingsProbabilityPreview(modal));
    document.body.appendChild(modal);
    renderSettingsProbabilityPreview(modal);
  }

  function renderSettingsLauncher() {
    if (typeof document?.querySelectorAll !== 'function') return;
    const nativeButtons = Array.from(document.querySelectorAll('button'))
      .filter(button => button.textContent?.trim() === '모드 설정'
        && button.classList?.contains('m33-pause-settings')
        && !button.closest?.('[data-bad-guest-settings-modal="true"]'));
    const activeParents = new Set(nativeButtons.map(button => button.parentElement).filter(Boolean));
    for (const existing of Array.from(document.querySelectorAll('[data-bad-guest-settings-launch="true"]'))) {
      if (!activeParents.has(existing.parentElement)) existing.remove();
    }
    for (const nativeButton of nativeButtons) {
      if (nativeButton.parentElement?.querySelector?.('[data-bad-guest-settings-launch="true"]')) continue;
      const button = document.createElement('button');
      button.type = 'button';
      button.dataset.badGuestSettingsLaunch = 'true';
      button.className = nativeButton.className;
      button.textContent = '나쁜 손님 모드 설정';
      button.addEventListener('click', openSettingsModal);
      nativeButton.insertAdjacentElement?.('afterend', button);
    }
  }

  function renderDebugProbabilityPanel(state) {
    if (!document?.body || typeof document.querySelector !== 'function') return;
    let panel = document.querySelector('[data-bad-guest-debug-probability="true"]');
    if (!settings.debugProbabilityPanel) {
      panel?.remove();
      return;
    }
    if (!panel) {
      panel = document.createElement('details');
      panel.dataset.badGuestDebugProbability = 'true';
      panel.style.cssText = 'position:fixed;right:12px;bottom:12px;z-index:2147483000;width:min(330px,calc(100vw - 24px));max-height:60vh;overflow:auto;border:1px solid #57534e;border-radius:6px;background:rgba(12,10,9,.96);color:#d6d3d1;box-shadow:0 8px 28px rgba(0,0,0,.5);font-family:inherit;font-size:11px';
      const summary = document.createElement('summary');
      summary.textContent = '나쁜 손님 확률';
      summary.style.cssText = 'cursor:pointer;padding:8px 10px;color:#fde68a;font-weight:700;user-select:none';
      const body = document.createElement('div');
      body.dataset.badGuestDebugProbabilityBody = 'true';
      body.style.cssText = 'padding:0 10px 9px;border-top:1px solid #292524';
      panel.appendChild(summary);
      panel.appendChild(body);
      document.body.appendChild(panel);
    }
    const body = panel.querySelector('[data-bad-guest-debug-probability-body="true"]');
    const snapshot = probabilitySnapshot(state);
    if (!body || !snapshot) return;
    const checks = snapshot.checks
      ? Object.entries(CHECK_SETTING_LABELS).map(([key, label]) => `<div style="display:flex;justify-content:space-between;gap:8px"><span>${label}</span><span style="color:#fbbf24">${percentText(snapshot.checks[key])}</span></div>`).join('')
      : '<div style="color:#78716c">계산할 나쁜 손님이 없습니다.</div>';
    const actions = snapshot.specialActions.length
      ? snapshot.specialActions.map(action => `<div style="display:flex;justify-content:space-between;gap:8px"><span>${escapeHtml(action.label)} · ${action.weight}</span><span style="color:#fbbf24">분당 ${percentText(action.perMinuteChance)}</span></div>`).join('')
      : '<div style="color:#78716c">현재 가능한 특수행동 없음</div>';
    const content = `<div style="padding:7px 0;color:#a8a29e">대상: ${escapeHtml(snapshot.targetName || '없음')}</div>${checks}<div style="margin-top:7px;padding-top:7px;border-top:1px solid #292524">${actions}</div><div style="margin-top:6px;color:#78716c">특수행동 판정 ${percentText(snapshot.activeActionChance)} · 문 부수기 ${percentText(snapshot.doorBreakChance)}</div>`;
    if (body.innerHTML !== content) body.innerHTML = content;
  }

  const ROOM_LABELS = {
    taproom: '홀',
    back_room: '뒷방',
    bedroom: '침실',
    elena_room: '그녀의 방',
    upstairs_hall: '객실',
    upstairs_room_1: '객실 1',
    upstairs_room_2: '객실 2',
    bathhouse: '목욕탕',
    bathroom: '욕실',
    kitchen: '부엌'
  };

  const TAVERN_ROOM_IDS = new Set([
    'taproom', 'kitchen', 'back_room', 'bathhouse', 'bathroom',
    'bedroom', 'elena_room', 'upstairs_hall', 'upstairs_room_1', 'upstairs_room_2'
  ]);

  function exactTextElements(selector, text) {
    if (typeof document?.querySelectorAll !== 'function') return [];
    try {
      return Array.from(document.querySelectorAll(selector))
        .filter(node => node.textContent?.trim() === text);
    } catch {
      return [];
    }
  }

  function drugHeatDescription(state) {
    const phase = drugPhase(state, effectOf(readData(state), 'aphrodisiac'));
    if (phase === 'rising') return '미약의 효과로 몸이 서서히 뜨거워지고 있습니다.';
    if (phase === 'plateau') return '미약의 열기가 온몸에 짙게 남아 있습니다.';
    if (phase === 'falling') return '미약의 효과가 가라앉으며 몸의 열기도 서서히 식고 있습니다.';
    return '';
  }

  function drugStatusRows(state) {
    const data = readData(state);
    const rows = [];
    const aphrodisiac = effectOf(data, 'aphrodisiac');
    if (aphrodisiac && drugPhase(state, aphrodisiac) !== 'ended') {
      rows.push({
        key: 'aphrodisiac',
        label: '미약의 열기',
        level: drugLevelAt(state, aphrodisiac),
        description: drugHeatDescription(state),
        tooltip: '미약의 영향으로 몸이 달아올라 있습니다. 흥분이 강할수록 친밀행위와 노출을 승낙할 가능성이 올라갑니다.',
        labelColor: '#f9a8d4',
        gradient: 'linear-gradient(90deg,rgba(244,114,182,.78),rgba(251,113,133,.95))',
        glow: '0 0 4px rgba(244,114,182,.45)'
      });
    }
    const sleep = data.sleepPotion?.pending;
    if (sleep) {
      const remaining = Math.max(0, Math.ceil((sleep.moveAtSlot ?? state.slot) - state.slot));
      rows.push({
        key: 'sleep',
        label: '수면약 기운',
        level: clamp(Number(sleep.depth) || 0),
        description: remaining > 0
          ? `수면약 기운이 번지고 있습니다. 잠들기까지 약 ${remaining}분 남았습니다.`
          : '수면약 기운에 눈을 뜨고 있기 어렵습니다.',
        tooltip: '수면약을 마셨습니다. 표시된 시간이 지나면 잠들 장소로 이동합니다.',
        labelColor: '#c4b5fd',
        gradient: 'linear-gradient(90deg,rgba(139,92,246,.72),rgba(99,102,241,.95))',
        glow: '0 0 4px rgba(139,92,246,.42)'
      });
    }
    const intoxication = effectOf(data, 'intoxicationFloor');
    if (intoxication && timedEffectActive(state, 'intoxicationFloor')) {
      const remaining = Math.max(0, Math.ceil((intoxication.endsAtSlot ?? state.slot) - state.slot));
      rows.push({
        key: 'intoxication',
        label: '만취약 취기',
        level: clamp(getWife(state)?.intoxication?.level ?? intoxication.floor ?? 90),
        description: `만취약이 취기를 강제로 붙들고 있습니다. 약 ${remaining}분 남았습니다.`,
        tooltip: '만취약이 지속되는 동안 취기가 일정 수준 아래로 내려가지 않습니다.',
        labelColor: '#fbbf24',
        gradient: 'linear-gradient(90deg,rgba(245,158,11,.75),rgba(249,115,22,.95))',
        glow: '0 0 4px rgba(245,158,11,.42)'
      });
    }
    const confusion = effectOf(data, 'confusion');
    if (confusion && timedEffectActive(state, 'confusion')) {
      const remaining = Math.max(0, Math.ceil((confusion.endsAtSlot ?? state.slot) - state.slot));
      rows.push({
        key: 'confusion',
        label: '착란약 혼미',
        level: clamp(remaining / 60 * 100),
        description: `눈앞의 상대를 ${confusion.mistakenForName || '다른 사람'}처럼 받아들이고 있습니다. 약 ${remaining}분 남았습니다.`,
        tooltip: '착란약이 지속되는 동안 수용 판정에서 상대를 다른 사람으로 오인합니다.',
        labelColor: '#67e8f9',
        gradient: 'linear-gradient(90deg,rgba(34,211,238,.72),rgba(59,130,246,.95))',
        glow: '0 0 4px rgba(34,211,238,.4)'
      });
    }
    return rows;
  }

  function renderDrugMoodStatus(state) {
    const statuses = drugStatusRows(state);
    const existing = typeof document?.querySelectorAll === 'function'
      ? Array.from(document.querySelectorAll('[data-bad-guest-drug-mood="true"]'))
      : [];
    const customLists = typeof document?.querySelectorAll === 'function'
      ? Array.from(document.querySelectorAll('[data-bad-guest-drug-mood-list="true"]'))
      : [];
    const hiddenStable = typeof document?.querySelectorAll === 'function'
      ? Array.from(document.querySelectorAll('[data-bad-guest-stable-hidden="true"]'))
      : [];
    // React reuses the "안정적" div for its feeling list. Clear any old inline
    // hiding and marker when that node starts showing native feelings.
    hiddenStable.filter(node => node.textContent?.trim() !== '안정적').forEach(node => {
      node.classList?.remove('hidden');
      node.style.display = '';
      delete node.dataset.badGuestStableHidden;
    });
    if (!statuses.length) {
      existing.forEach(node => node.remove());
      customLists.forEach(node => node.remove());
      hiddenStable.forEach(node => {
        node.classList?.remove('hidden');
        node.style.display = '';
        delete node.dataset.badGuestStableHidden;
      });
      return;
    }
    const inspectorPanels = exactTextElements('span', '수용도 검사기')
      .map(title => title.parentElement?.parentElement)
      .filter(Boolean);
    const isInsideInspector = node => inspectorPanels.some(panel => panel.contains?.(node));
    existing.filter(isInsideInspector).forEach(node => node.remove());
    customLists.filter(isInsideInspector).forEach(node => node.remove());
    hiddenStable.filter(isInsideInspector).forEach(node => {
      node.classList?.remove('hidden');
      node.style.display = '';
      delete node.dataset.badGuestStableHidden;
    });
    const headings = exactTextElements('div', '기분')
      .filter(heading => !isInsideInspector(heading));
    const live = new Set();
    for (const heading of headings) {
      const section = heading.parentElement;
      if (!section || section.dataset?.badGuestDrugMood === 'true') continue;
      const stable = Array.from(section.children || [])
        .find(node => node.textContent?.trim() === '안정적');
      if (stable && stable.dataset.badGuestStableHidden !== 'true') {
        stable.classList.add('hidden');
        stable.dataset.badGuestStableHidden = 'true';
      }
      let list = Array.from(section.children || [])
        .find(node => node.classList?.contains('space-y-1'));
      if (!list) {
        list = document.createElement('div');
        list.className = 'space-y-1';
        list.dataset.badGuestDrugMoodList = 'true';
        section.appendChild(list);
      }
      const desiredKeys = new Set(statuses.map(status => status.key));
      Array.from(list.querySelectorAll?.('[data-bad-guest-drug-mood="true"]') || [])
        .filter(node => !desiredKeys.has(node.dataset.badGuestDrugMoodKey))
        .forEach(node => node.remove());
      for (const status of statuses) {
        let row = Array.from(list.querySelectorAll?.('[data-bad-guest-drug-mood="true"]') || [])
          .find(node => node.dataset.badGuestDrugMoodKey === status.key);
        if (!row) {
          row = document.createElement('div');
          row.dataset.badGuestDrugMood = 'true';
          row.dataset.badGuestDrugMoodKey = status.key;
          const main = document.createElement('div');
          main.className = 'flex items-center gap-1.5';
          main.dataset.badGuestDrugMoodMain = 'true';
          const label = document.createElement('span');
          label.className = 'text-[0.7rem] w-16 flex-shrink-0 capitalize';
          label.dataset.badGuestDrugMoodLabel = 'true';
          const track = document.createElement('div');
          track.className = 'flex-1 h-1 bg-stone-800 rounded-full overflow-hidden';
          track.style.cssText = 'position:relative;height:0.25rem;overflow:hidden;border-radius:9999px;background:rgb(41 37 36);';
          const fill = document.createElement('div');
          fill.className = 'h-full rounded-full';
          fill.dataset.badGuestDrugMoodFill = 'true';
          track.appendChild(fill);
          main.appendChild(label);
          main.appendChild(track);
          const detail = document.createElement('div');
          detail.className = 'text-[0.62rem] text-stone-500 leading-snug pl-0.5';
          detail.dataset.badGuestDrugMoodDetail = 'true';
          row.appendChild(main);
          row.appendChild(detail);
          list.appendChild(row);
        }
        const main = row.querySelector?.('[data-bad-guest-drug-mood-main="true"]');
        if (main) main.title = status.tooltip;
        const label = row.querySelector?.('[data-bad-guest-drug-mood-label="true"]');
        if (label) {
          if (label.textContent !== status.label) label.textContent = status.label;
          label.style.color = status.labelColor;
        }
        const fill = row.querySelector?.('[data-bad-guest-drug-mood-fill="true"]');
        if (fill) {
          fill.style.cssText = `height:100%;width:${clamp(status.level)}%;border-radius:9999px;background:${status.gradient};box-shadow:${status.glow};transition:width 700ms ease-out;`;
        }
        const detail = row.querySelector?.('[data-bad-guest-drug-mood-detail="true"]');
        if (detail && detail.textContent !== status.description) detail.textContent = status.description;
        live.add(row);
      }
    }
    existing.filter(node => !live.has(node)).forEach(node => node.remove());
    customLists.filter(node => !node.querySelector?.('[data-bad-guest-drug-mood="true"]'))
      .forEach(node => node.remove());
  }

  const EQUIPMENT_ATTENTION_DEFINITIONS = Object.freeze([
    Object.freeze({ key: 'restraint', text: (patron, wife) => `${withParticle(patron, '이', '가')} ${wife}에게 수갑을 채웠음` }),
    Object.freeze({ key: 'blindfold', text: (patron, wife) => `${withParticle(patron, '이', '가')} ${wife}에게 안대를 씌웠음` }),
    Object.freeze({ key: 'gag', text: (patron, wife) => `${withParticle(patron, '이', '가')} ${wife}에게 입마개를 채웠음` })
  ]);

  function equipmentAttentionRows(state) {
    const data = readData(state);
    const wifeName = wifeDisplayName(state);
    return EQUIPMENT_ATTENTION_DEFINITIONS.flatMap(definition => {
      const equipment = equipmentOf(data, definition.key);
      const visible = equipment && (equipment.active
        || (equipment.afterUntilSlot != null && state.slot < equipment.afterUntilSlot));
      if (!visible) return [];
      const elapsed = Math.max(0, Math.floor(state.slot - (equipment.appliedAtSlot ?? state.slot)));
      const witnessed = playerObservesRoom(state, equipment.roomId);
      return [{
        key: definition.key,
        text: `${definition.text(equipment.patronName || '손님', wifeName)} · ${elapsed}분`,
        witnessed,
        tooltip: witnessed
          ? '당신이 직접 볼 수 있는 상황입니다'
          : '당신은 그 방에 없습니다. 추측할 수 있는 상황입니다'
      }];
    });
  }

  function renderEquipmentAttention(state) {
    const statuses = equipmentAttentionRows(state);
    const existingSections = typeof document?.querySelectorAll === 'function'
      ? Array.from(document.querySelectorAll('[data-bad-guest-equipment-section="true"],[data-bad-guest-restraint-section="true"]'))
      : [];
    const existingRows = typeof document?.querySelectorAll === 'function'
      ? Array.from(document.querySelectorAll('[data-bad-guest-equipment-alert="true"],[data-bad-guest-restraint-alert="true"]'))
      : [];
    if (!statuses.length) {
      existingRows.forEach(node => node.remove());
      existingSections.forEach(node => node.remove());
      return;
    }

    let list = null;
    const nativeHeading = exactTextElements('span', '당신의 대응이 필요한 상황')
      .find(node => !node.closest?.('[data-bad-guest-equipment-section="true"],[data-bad-guest-restraint-section="true"]'));
    if (nativeHeading) {
      list = nativeHeading.parentElement?.nextElementSibling || null;
      existingSections.forEach(node => node.remove());
    }
    if (!list) {
      let section = existingSections[0];
      if (!section) {
        const region = document.querySelector?.('[role="region"][aria-label="가게 안 패널"]');
        const shopHeading = exactTextElements('span', '가게 안')
          .find(node => !region || region.contains?.(node));
        const anchor = shopHeading?.parentElement;
        const parent = anchor?.parentElement || region;
        if (!parent || !anchor) return;
        section = document.createElement('div');
        section.dataset.badGuestEquipmentSection = 'true';
        section.className = 'shrink-0 mb-2';
        const heading = document.createElement('div');
        heading.className = 'flex items-baseline gap-2 mb-1 px-1';
        const title = document.createElement('span');
        title.textContent = '당신의 대응이 필요한 상황';
        title.className = 'text-[0.62rem] font-semibold uppercase tracking-widest text-amber-400/80';
        const divider = document.createElement('span');
        divider.className = 'flex-1 h-px bg-stone-800';
        list = document.createElement('div');
        list.className = 'space-y-0.5';
        heading.appendChild(title);
        heading.appendChild(divider);
        section.appendChild(heading);
        section.appendChild(list);
        parent.insertBefore(section, anchor);
      } else {
        list = section.lastElementChild;
      }
    }
    if (!list) return;
    const desiredKeys = new Set(statuses.map(status => status.key));
    existingRows
      .filter(node => node.parentElement === list && !desiredKeys.has(node.dataset.badGuestEquipmentKey))
      .forEach(node => node.remove());
    const live = new Set();
    for (const status of statuses) {
      let row = Array.from(list.querySelectorAll?.('[data-bad-guest-equipment-alert="true"]') || [])
        .find(node => node.dataset.badGuestEquipmentKey === status.key);
      if (!row) {
        row = document.createElement('button');
        row.type = 'button';
        row.dataset.badGuestEquipmentAlert = 'true';
        row.dataset.badGuestEquipmentKey = status.key;
        list.appendChild(row);
      }
      row.className = `w-full text-left px-2 py-1.5 desk:py-1 min-h-[26px] desk:min-h-0 rounded-sm bg-stone-900/70 border-l-2 text-[0.7rem] leading-snug hover:bg-stone-800 border-l-red-600 text-red-200${status.witnessed ? '' : ' italic'}`;
      if (row.textContent !== status.text) row.textContent = status.text;
      row.title = status.tooltip;
      live.add(row);
    }
    existingRows.filter(node => !live.has(node)).forEach(node => node.remove());
  }

  function renderLockedRoomStatus(state) {
    if (typeof document?.querySelectorAll !== 'function') return;
    const lock = readData(state).doorLock;
    const labelText = lock?.active ? ROOM_LABELS[lock.roomId] : null;
    const existing = Array.from(document.querySelectorAll('[data-bad-guest-locked-room="true"]'));
    let target = lock?.active
      ? existing.find(node => node.dataset.badGuestLockedRoomId === lock.roomId) || null
      : null;
    if (labelText && !target) {
      for (const heading of exactTextElements('span', '모두의 현재 위치')) {
        const panel = heading.parentElement?.parentElement;
        if (!panel) continue;
        target = Array.from(panel.querySelectorAll?.('div') || []).find(node => {
          const label = node.firstElementChild;
          if (!label || !node.classList?.contains('rounded') || !node.classList?.contains('border')) return false;
          const primaryText = label.firstElementChild?.textContent?.trim()
            || label.textContent?.trim();
          return primaryText === labelText;
        });
        if (target) break;
      }
    }
    for (const node of existing) {
      if (node === target) continue;
      node.querySelector?.('[data-bad-guest-lock-badge="true"]')?.remove();
      delete node.dataset.badGuestLockedRoom;
      delete node.dataset.badGuestLockedRoomId;
      if (node.dataset.badGuestOriginalTitle != null) {
        if (node.dataset.badGuestOriginalTitle) node.title = node.dataset.badGuestOriginalTitle;
        else node.removeAttribute?.('title');
        delete node.dataset.badGuestOriginalTitle;
      }
    }
    if (!target) return;
    if (target.dataset.badGuestLockedRoom !== 'true') {
      target.dataset.badGuestLockedRoom = 'true';
      target.dataset.badGuestLockedRoomId = lock.roomId;
      target.dataset.badGuestOriginalTitle = target.getAttribute?.('title') || '';
      target.title = `${target.dataset.badGuestOriginalTitle ? `${target.dataset.badGuestOriginalTitle} · ` : ''}안쪽에서 잠겨 있음`;
    }
    let badge = target.querySelector?.('[data-bad-guest-lock-badge="true"]');
    if (!badge) {
      badge = document.createElement('span');
      badge.dataset.badGuestLockBadge = 'true';
      badge.textContent = '잠김';
      badge.style.cssText = 'margin-left:4px;padding:1px 4px;border:1px solid rgba(248,113,113,.65);border-radius:3px;background:rgba(127,29,29,.28);color:#fecaca;font-size:0.58rem;font-weight:700';
      target.firstElementChild?.appendChild(badge);
    }
  }

  function renderBadGuestMarkers(state) {
    if (typeof document?.querySelectorAll !== 'function') return;
    const existing = Array.from(document.querySelectorAll('[data-bad-guest-patron-marker="true"]'));
    if (!settings.showBadGuestMarkers) {
      existing.forEach(node => node.remove());
      return;
    }
    const desired = new Map();
    for (const customer of state.customers || []) {
      if (!isBadGuest(state, customer) || customer.status === 'gone' || customer.status === 'leaving') continue;
      const roomId = customerLocation(state, customer.id);
      if (!TAVERN_ROOM_IDS.has(roomId)) continue;
      desired.set(String(customer.id), customer);
    }
    const live = new Set();
    for (const marker of existing) {
      const key = marker.dataset.badGuestMarkerKey;
      const customer = desired.get(key);
      const nameNode = marker.previousElementSibling;
      const row = marker.parentElement;
      const correctlyPlaced = customer
        && nameNode?.textContent?.trim() === customer.name
        && nameNode.classList?.contains('text-[0.8rem]')
        && nameNode.classList?.contains('font-medium')
        && row?.classList?.contains('group')
        && row?.classList?.contains('items-center');
      if (!correctlyPlaced) marker.remove();
      else live.add(key);
    }
    for (const [key, customer] of desired) {
      if (live.has(key)) continue;
      const nameNode = exactTextElements('span', customer.name).find(node => {
        const row = node.parentElement;
        return node.classList?.contains('text-[0.8rem]')
          && node.classList?.contains('font-medium')
          && row?.classList?.contains('group')
          && row?.classList?.contains('items-center');
      });
      if (!nameNode) continue;
      const marker = document.createElement('span');
      marker.dataset.badGuestPatronMarker = 'true';
      marker.dataset.badGuestMarkerKey = key;
      marker.title = '나쁜 손님';
      marker.setAttribute('aria-label', '나쁜 손님');
      marker.style.cssText = 'display:inline-block;width:5px;height:5px;margin-left:-2px;border:0;border-radius:9999px;background:#ef4444;box-shadow:none;flex:0 0 auto';
      nameNode.insertAdjacentElement('afterend', marker);
    }
  }

  function renderIntegratedStatus(state) {
    if (!document?.body) return;
    renderDrugMoodStatus(state);
    renderEquipmentAttention(state);
    renderLockedRoomStatus(state);
    renderBadGuestMarkers(state);
    renderDebugProbabilityPanel(state);
  }

  function signedInspectorValue(value) {
    const rounded = Math.round(value * 10) / 10;
    return `${rounded >= 0 ? '+' : ''}${rounded.toFixed(1)}`;
  }

  function renderAcceptanceInspectorContribution(state) {
    if (typeof document?.querySelectorAll !== 'function') return;
    const level = drugLevelAt(state);
    const titles = Array.from(document.querySelectorAll('span'))
      .filter(node => node.textContent?.trim() === '수용도 검사기');

    for (const title of titles) {
      const panel = title.parentElement?.parentElement;
      if (!panel || typeof panel.querySelectorAll !== 'function') continue;
      const selectedCategory = Array.from(panel.querySelectorAll('select'))[0]?.value;
      const applies = level > 0 && DRUG_ACCEPTANCE_CATEGORIES.has(selectedCategory);
      let row = panel.querySelector?.('[data-bad-guest-drug-contribution="true"]');
      const emptyNotice = Array.from(panel.querySelectorAll('div'))
        .find(node => node.textContent?.trim() === '(기여 없음)');

      if (!applies) {
        row?.remove();
        if (emptyNotice?.dataset?.badGuestHidden === 'true') {
          emptyNotice.style.display = '';
          delete emptyNotice.dataset.badGuestHidden;
        }
        continue;
      }

      const contributionHeading = Array.from(panel.querySelectorAll('div'))
        .find(node => node.textContent?.trim() === '기여도');
      const list = contributionHeading?.nextElementSibling;
      if (!list) continue;
      if (!row) {
        row = document.createElement('div');
        row.dataset.badGuestDrugContribution = 'true';
        row.className = 'flex justify-between items-start gap-2';

        const labelWrap = document.createElement('div');
        labelWrap.className = 'flex-1 min-w-0';
        const label = document.createElement('span');
        label.className = 'text-pink-400';
        label.dataset.badGuestDrugLabel = 'true';
        labelWrap.appendChild(label);

        const value = document.createElement('span');
        value.className = 'tabular-nums text-emerald-400';
        value.dataset.badGuestDrugValue = 'true';
        row.appendChild(labelWrap);
        row.appendChild(value);
        list.appendChild(row);
      }

      const bonus = level * CONFIG.drugMaxAcceptanceBonus / 100;
      const label = row.querySelector?.('[data-bad-guest-drug-label="true"]');
      const value = row.querySelector?.('[data-bad-guest-drug-value="true"]');
      const labelText = `미약성 흥분 (${Math.round(level * 10) / 10}/100 × ${CONFIG.drugMaxAcceptanceBonus}%)`;
      const valueText = signedInspectorValue(bonus);
      if (label && label.textContent !== labelText) label.textContent = labelText;
      if (value && value.textContent !== valueText) value.textContent = valueText;
      if (emptyNotice) {
        emptyNotice.style.display = 'none';
        emptyNotice.dataset.badGuestHidden = 'true';
      }
    }
  }

  function scheduleAcceptanceInspectorRender() {
    if (inspectorRenderQueued) return;
    inspectorRenderQueued = true;
    const render = () => {
      inspectorRenderQueued = false;
      const state = store.getState()?.state;
      if (state) {
        renderAcceptanceInspectorContribution(state);
        renderIntegratedStatus(state);
      }
    };
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(render);
    else Promise.resolve().then(render);
  }

  function drugMoodRowsMissing(state) {
    const statuses = drugStatusRows(state);
    if (!statuses.length) return false;
    const inspectorPanels = exactTextElements('span', '수용도 검사기')
      .map(title => title.parentElement?.parentElement)
      .filter(Boolean);
    const headings = exactTextElements('div', '기분')
      .filter(heading => !inspectorPanels.some(panel => panel.contains?.(heading)));
    return headings.some(heading => {
      const section = heading.parentElement;
      if (!section || section.dataset?.badGuestDrugMood === 'true') return false;
      if (Array.from(section.children || []).some(node =>
        node.dataset?.badGuestStableHidden === 'true'
        && node.textContent?.trim() !== '안정적')) return true;
      const rows = Array.from(section.querySelectorAll?.('[data-bad-guest-drug-mood="true"]') || []);
      return statuses.some(status => !rows.some(row => row.dataset.badGuestDrugMoodKey === status.key));
    });
  }

  function installDrugMoodObserver() {
    if (typeof MutationObserver !== 'function' || !document?.body) return;
    drugMoodObserver = new MutationObserver(() => {
      const state = store.getState()?.state;
      if (state && drugMoodRowsMissing(state)) scheduleAcceptanceInspectorRender();
    });
    drugMoodObserver.observe(document.body, { childList: true, subtree: true });
  }

  function uiStateSignature(state) {
    const data = readData(state);
    const visibleCustomers = (state.customers || [])
      .filter(customer => customer.status !== 'gone' && customer.status !== 'leaving')
      .map(customer => [
        customer.id,
        customer.name,
        customer.status,
        customerLocation(state, customer.id),
        customerClassification(data, customer)
      ]);
    return JSON.stringify([
      state.slot,
      state.phase,
      playerLocation(state),
      wifeLocation(state),
      state.pendingEvent?.type || null,
      data.effects || null,
      data.sleepPotion?.pending || null,
      data.equipment || null,
      data.doorLock || null,
      (getWife(state)?.feelings || []).map(feeling => [
        feeling.emotion, feeling.source, feeling.intensity, feeling.expiresAtSlot
      ]),
      settings.showBadGuestMarkers,
      settings.debugProbabilityPanel,
      visibleCustomers
    ]);
  }

  function installUiEventRefresh() {
    if (!document?.addEventListener) return;
    uiEventHandler = scheduleAcceptanceInspectorRender;
    document.addEventListener('click', uiEventHandler, true);
    document.addEventListener('change', uiEventHandler, true);
  }

  const installedProcesses = {
    reduceGameAction: wrappedReduceGameAction,
    evaluateIntimacy: wrappedEvaluateIntimacy,
    acceptanceBreakdown: wrappedAcceptanceBreakdown,
    acceptanceCalculator: wrappedAcceptanceCalculator,
    selectPatronTactic: wrappedSelectPatronTactic,
    forceAttemptChance: wrappedForceAttemptChance,
    buildPatronMoveCandidates: wrappedBuildPatronMoveCandidates,
    processPatronGroupJoin: wrappedProcessPatronGroupJoin,
    processPatronGroupParticipants: wrappedProcessPatronGroupParticipants,
    rotatePatronGroupAfterPrimary: wrappedRotatePatronGroupAfterPrimary,
    patronJealousyAssessment: wrappedPatronJealousyAssessment,
    recordIntimateHistory: wrappedRecordIntimateHistory,
    recordPatronReach: wrappedRecordPatronReach,
    addFeeling: wrappedAddFeeling,
    addIdentityStrainFromPatronAct: wrappedAddIdentityStrainFromPatronAct,
    patronControlNaturalEnd: wrappedPatronNaturalEnd,
    patronControlBoundaryStop: wrappedPatronBoundaryStop,
    patronControlFatigueStop: wrappedPatronFatigueStop,
    patronControlClimax: wrappedPatronClimax,
    patronControlAfterglow: wrappedPatronAfterglow,
    patronControlPlayerReturnStop: wrappedPatronPlayerReturnStop,
    patronControlRecallReach: wrappedPatronRecallReach,
    patronControlShouldCheckWithHusband: wrappedPatronShouldCheckWithHusband,
    patronControlPrivateOffer: wrappedPatronPrivateOffer,
    patronControlWifeClimax: wrappedPatronWifeClimax,
    patronControlAftermathFeeling: wrappedPatronAftermathFeeling,
    patronControlRecordFirsts: wrappedPatronRecordFirsts,
    patronControlCrossedLine: wrappedPatronCrossedLine,
    patronControlSelfConceptDrift: wrappedPatronSelfConceptDrift,
    patronControlAftercareFeeling: wrappedPatronAftercareFeeling,
    patronControlAftercareBond: wrappedPatronAftercareBond,
    patronControlRecordVisitOutcome: wrappedPatronRecordVisitOutcome,
    patronControlAdvanceNamedPatron: wrappedPatronAdvanceNamedPatron,
    patronControlOtherRelationshipReaction: wrappedPatronOtherRelationshipReaction,
    patronControlOpenReaction: wrappedPatronOpenReaction,
    patronControlResolveReaction: wrappedPatronResolveReaction,
    patronControlExpireReaction: wrappedPatronExpireReaction,
    patronControlNightAccount: wrappedPatronNightAccount,
    patronControlUnpromptedCandidates: wrappedPatronUnpromptedCandidates,
    patronControlApplyNightAccount: wrappedPatronApplyNightAccount,
    patronControlEnjoymentOpinion: wrappedPatronEnjoymentOpinion,
    patronControlInnerThought: wrappedPatronInnerThought,
    patronControlRecordMoment: wrappedPatronRecordMoment,
    patronControlCoercionEscape: wrappedPatronCoercionEscape,
    patronControlAcquaintanceStop: wrappedPatronAcquaintanceStop,
    patronControlShameStop: wrappedPatronShameStop,
    patronControlServiceInterrupt: wrappedPatronServiceInterrupt,
    patronControlExposureRedress: wrappedPatronExposureRedress,
    patronControlLineUp: wrappedPatronLineUp,
    patronControlPushIn: wrappedPatronPushIn,
    patronControlRelentChance: wrappedPatronRelentChance,
    startPatronInteraction: wrappedStartPatronInteraction,
    processPatronInteractionTick: wrappedPatronInteractionTick,
    resolvePatronEscalation: wrappedResolvePatronEscalation,
    resolvePatronForce: wrappedResolvePatronForce,
    endPatronInteraction: wrappedEndPatronInteraction,
    applyWifeRestBreak: wrappedApplyWifeRestBreak,
    resolvePrivateSessionExit: wrappedResolvePrivateSessionExit,
    applyPotionEffect: wrappedApplyPotionEffect,
    passOutWife: wrappedPassOutWife,
    movePlayer: wrappedMovePlayer,
    moveWife: wrappedMoveWife,
    minuteTick: wrappedMinuteTick,
    decreaseWifeIntoxication: wrappedDecreaseWifeIntoxication
  };

  function install() {
    api.engine.reduceGameAction = installedProcesses.reduceGameAction;
    api.engine.evaluateIntimacy = installedProcesses.evaluateIntimacy;
    api.engine.acceptanceBreakdown = installedProcesses.acceptanceBreakdown;
    api.engine.acceptanceCalculator = installedProcesses.acceptanceCalculator;
    api.engine.selectPatronTactic = installedProcesses.selectPatronTactic;
    api.engine.forceAttemptChance = installedProcesses.forceAttemptChance;
    api.engine.buildPatronMoveCandidates = installedProcesses.buildPatronMoveCandidates;
    api.engine.processPatronGroupJoin = installedProcesses.processPatronGroupJoin;
    api.engine.processPatronGroupParticipants = installedProcesses.processPatronGroupParticipants;
    api.engine.rotatePatronGroupAfterPrimary = installedProcesses.rotatePatronGroupAfterPrimary;
    if (typeof original.patronJealousyAssessment === 'function') {
      api.engine.patronJealousyAssessment = installedProcesses.patronJealousyAssessment;
    }
    api.engine.recordIntimateHistory = installedProcesses.recordIntimateHistory;
    api.engine.recordPatronReach = installedProcesses.recordPatronReach;
    api.character.addFeeling = installedProcesses.addFeeling;
    api.character.addIdentityStrainFromPatronAct = installedProcesses.addIdentityStrainFromPatronAct;
    api.engine.patronControlNaturalEnd = installedProcesses.patronControlNaturalEnd;
    api.engine.patronControlBoundaryStop = installedProcesses.patronControlBoundaryStop;
    api.engine.patronControlFatigueStop = installedProcesses.patronControlFatigueStop;
    api.engine.patronControlClimax = installedProcesses.patronControlClimax;
    api.engine.patronControlAfterglow = installedProcesses.patronControlAfterglow;
    if (typeof original.patronControlPlayerReturnStop === 'function') {
      api.engine.patronControlPlayerReturnStop = installedProcesses.patronControlPlayerReturnStop;
    }
    if (typeof original.patronControlRecallReach === 'function') {
      api.engine.patronControlRecallReach = installedProcesses.patronControlRecallReach;
    }
    if (typeof original.patronControlShouldCheckWithHusband === 'function') {
      api.engine.patronControlShouldCheckWithHusband = installedProcesses.patronControlShouldCheckWithHusband;
    }
    if (typeof original.patronControlPrivateOffer === 'function'
      && typeof original.patronControlResolvePrivateOffer === 'function') {
      api.engine.patronControlPrivateOffer = installedProcesses.patronControlPrivateOffer;
    }
    for (const name of [
      'patronControlWifeClimax',
      'patronControlAftermathFeeling',
      'patronControlRecordFirsts',
      'patronControlCrossedLine',
      'patronControlSelfConceptDrift',
      'patronControlAftercareFeeling',
      'patronControlAftercareBond',
      'patronControlRecordVisitOutcome',
      'patronControlAdvanceNamedPatron',
      'patronControlOtherRelationshipReaction',
      'patronControlOpenReaction',
      'patronControlResolveReaction',
      'patronControlExpireReaction',
      'patronControlNightAccount',
      'patronControlUnpromptedCandidates',
      'patronControlApplyNightAccount',
      'patronControlEnjoymentOpinion',
      'patronControlInnerThought',
      'patronControlRecordMoment'
    ]) {
      if (typeof original[name] === 'function') api.engine[name] = installedProcesses[name];
    }
    api.engine.patronControlCoercionEscape = installedProcesses.patronControlCoercionEscape;
    api.engine.patronControlAcquaintanceStop = installedProcesses.patronControlAcquaintanceStop;
    api.engine.patronControlShameStop = installedProcesses.patronControlShameStop;
    api.engine.patronControlServiceInterrupt = installedProcesses.patronControlServiceInterrupt;
    api.engine.patronControlExposureRedress = installedProcesses.patronControlExposureRedress;
    api.engine.patronControlLineUp = installedProcesses.patronControlLineUp;
    api.engine.patronControlPushIn = installedProcesses.patronControlPushIn;
    api.engine.patronControlRelentChance = installedProcesses.patronControlRelentChance;
    api.engine.startPatronInteraction = installedProcesses.startPatronInteraction;
    api.engine.processPatronInteractionTick = installedProcesses.processPatronInteractionTick;
    api.engine.resolvePatronEscalation = installedProcesses.resolvePatronEscalation;
    api.engine.resolvePatronForce = installedProcesses.resolvePatronForce;
    api.engine.endPatronInteraction = installedProcesses.endPatronInteraction;
    api.engine.applyWifeRestBreak = installedProcesses.applyWifeRestBreak;
    if (typeof original.resolvePrivateSessionExit === 'function') {
      api.engine.resolvePrivateSessionExit = installedProcesses.resolvePrivateSessionExit;
    }
    api.engine.applyPotionEffect = installedProcesses.applyPotionEffect;
    api.engine.passOutWife = installedProcesses.passOutWife;
    api.movement.movePlayer = installedProcesses.movePlayer;
    api.movement.moveWife = installedProcesses.moveWife;
    api.minuteTick = installedProcesses.minuteTick;
    api.decreaseWifeIntoxication = installedProcesses.decreaseWifeIntoxication;
    ensureSleepActionsFlowOwner();

    const currentRoot = store.getState();
    if (currentRoot?.state) {
      const seeded = normalizeEffects(markNewCustomers(currentRoot.state));
      if (seeded !== currentRoot.state) store.setState({ state: seeded });
      renderIntegratedStatus(seeded);
      renderAcceptanceInspectorContribution(seeded);
      lastUiStateSignature = uiStateSignature(seeded);
    }

    installUiEventRefresh();
    installDrugMoodObserver();

    const unsubscribe = store.subscribe(root => {
      if (root?.state) {
        const signature = uiStateSignature(root.state);
        if (signature !== lastUiStateSignature) {
          lastUiStateSignature = signature;
          scheduleAcceptanceInspectorRender();
        }
      }
    });

    globalThis[LOADED] = true;
    globalThis.__WAYWARD_MODS__ ??= {};
    globalThis.__WAYWARD_MODS__[MOD_ID] = {
      version: VERSION,
      apiVersion: PUBLIC_API_VERSION,
      config: CONFIG,
      hooks: publicProcessHooks,
      getSettings() {
        return copySettings(settings);
      },
      updateSettings(nextSettings) {
        const incoming = nextSettings || {};
        const saved = saveGlobalSettings({
          ...settings,
          ...incoming,
          checkBaseChances: {
            ...settings.checkBaseChances,
            ...(incoming.checkBaseChances || {})
          },
          checkPointIncrements: {
            ...settings.checkPointIncrements,
            ...(incoming.checkPointIncrements || {})
          },
          specialActionWeights: {
            ...settings.specialActionWeights,
            ...(incoming.specialActionWeights || {})
          },
          patternWeights: {
            ...settings.patternWeights,
            ...(incoming.patternWeights || {})
          }
        });
        scheduleAcceptanceInspectorRender();
        return copySettings(saved);
      },
      resetSettings() {
        const saved = saveGlobalSettings(DEFAULT_SETTINGS);
        scheduleAcceptanceInspectorRender();
        return copySettings(saved);
      },
      getProbabilitySnapshot(previewSettings = null) {
        return probabilitySnapshot(store.getState()?.state, previewSettings);
      },
      getState() {
        const state = store.getState()?.state;
        if (!state) return null;
        return {
          data: getData(state),
          drugLevel: drugLevelAt(state),
          badGuests: (state.customers || []).filter(customer => isBadGuest(state, customer))
        };
      },
      isBadGuest(state, customerOrId) {
        return isBadGuest(state, customerOrId);
      },
      joinInBlocked,
      imageEquipment,
      resolveCompatibilityEnd(state, request) {
        return resolveCompatibilityEnd(state, request);
      },
      forceMark(customerId) {
        return forceMarkCustomer(customerId);
      },
      forceWealthyPartyOffer() {
        return forceWealthyPartyOffer();
      },
      actions: Object.freeze({
        catalog: actionCatalog,
        execute: debugExecute,
      }),
      debug: Object.freeze({
        catalog: DEBUG_COMMANDS,
        execute: debugExecute,
      }),
      ...(globalThis.__WAYWARD_BAD_GUEST_TEST__ ? {
        test: Object.freeze({
          migrateState(state) {
            return putData(state, getData(state));
          },
          enforceBadGuestIdentities,
          badGuestPattern,
          storyLine,
          badGuestArrivalText,
          incidentOpeningText,
          incidentExplanationParts,
          drugAttemptLead,
          confusionPlayerDrugAttemptLead,
          confusionLoverDrugAttemptLead,
          sleepActionsAvailable,
          shortenBadGuestSleepCooldowns,
          uiStateSignature,
          effectivePatternWeights,
          effectiveSpecialActionWeights,
          probabilitySnapshot,
          sleepPotionEligibility,
          applySleepDrug: applySleepDrugImpl,
          aggressiveDeceptionEligibility,
          beginAggressiveDeception: beginAggressiveDeceptionImpl,
          resolveAggressiveDeception: resolveAggressiveDeceptionImpl,
          customTacticCandidates,
          chooseCustomTactic,
          applyCustomTactic: applyCustomTacticImpl,
          applyIntoxicationDrug: applyIntoxicationDrugImpl,
          applyConfusionDrug: applyConfusionDrugImpl,
          applyDrug: applyDrugImpl,
          wifeNoticesDrug,
          wifeRefusesDrug,
          lurerIntoxicationFinishEligible,
          resolveLurerIntoxicationFinish: resolveLurerIntoxicationFinishImpl,
          badGuestIncidentKinds,
          badGuestIncidentContext,
          tryCoordinateBadGuestIncident,
          handleBadGuestSleepWakeRefusal,
          observeGeneralSleepWakeRefusal,
          resolveBadGuestSharedSearch,
          scheduleBadGuestSleepApproach,
          confusionRecoveryCheck,
          wifeNoticesBackRoomPretext,
          wifeRefusesBackRoomPretext,
          beginBackRoomPretext: beginBackRoomPretextImpl,
          enterBackRoomConversation: enterBackRoomConversationImpl,
          drugStatusRows,
          equipmentAttentionRows,
          attemptHandcuff: attemptHandcuffImpl,
          applyFailedHandcuffPenalty,
          tryEscapeCuffsAfterNegativeDecision: tryEscapeCuffsAfterNegativeDecisionImpl,
          attemptEquipment: attemptEquipmentImpl,
          normalizeEffects,
          imageEquipment,
          maybeOfferDrinkingGame: maybeOfferDrinkingGameImpl,
          resolveDrinkingGame: resolveDrinkingGameImpl,
          addDrugRecoveryChoice,
          drugRecoveryChance,
          resolveDrugRecovery: resolveDrugRecoveryImpl,
          acceptanceBreakdown: wrappedAcceptanceBreakdown,
          acceptanceCalculator: wrappedAcceptanceCalculator,
          drinkingGameReward
        })
      } : {}),
      close() {
        unsubscribe();
        clearProcessHooks();
        if (unregisterSleepActionsFlowOwner) unregisterSleepActionsFlowOwner();
        unregisterSleepActionsFlowOwner = null;
        if (unregisterSleepActionsWakeObserver) unregisterSleepActionsWakeObserver();
        unregisterSleepActionsWakeObserver = null;
        if (unregisterSleepActionsSearchResolver) unregisterSleepActionsSearchResolver();
        unregisterSleepActionsSearchResolver = null;
        if (uiEventHandler && document?.removeEventListener) {
          document.removeEventListener('click', uiEventHandler, true);
          document.removeEventListener('change', uiEventHandler, true);
        }
        uiEventHandler = null;
        drugMoodObserver?.disconnect();
        drugMoodObserver = null;
        if (typeof document?.querySelectorAll === 'function') {
          document.querySelectorAll('[data-bad-guest-drug-contribution="true"]')
            .forEach(node => node.remove());
          document.querySelectorAll('[data-bad-guest-drug-mood="true"],[data-bad-guest-drug-mood-list="true"],[data-bad-guest-equipment-alert="true"],[data-bad-guest-equipment-section="true"],[data-bad-guest-restraint-alert="true"],[data-bad-guest-restraint-section="true"]')
            .forEach(node => node.remove());
          document.querySelectorAll('[data-bad-guest-settings-launch="true"],[data-bad-guest-settings-modal="true"],[data-bad-guest-debug-probability="true"],[data-bad-guest-patron-marker="true"]')
            .forEach(node => node.remove());
          document.querySelectorAll('[data-bad-guest-stable-hidden="true"]').forEach(node => {
            node.classList?.remove('hidden');
            node.style.display = '';
            delete node.dataset.badGuestStableHidden;
          });
          document.querySelectorAll('[data-bad-guest-locked-room="true"]').forEach(node => {
            node.querySelector?.('[data-bad-guest-lock-badge="true"]')?.remove();
            if (node.dataset.badGuestOriginalTitle) node.title = node.dataset.badGuestOriginalTitle;
            else node.removeAttribute?.('title');
            delete node.dataset.badGuestLockedRoom;
            delete node.dataset.badGuestLockedRoomId;
            delete node.dataset.badGuestOriginalTitle;
          });
        }
        if (api.engine.reduceGameAction === installedProcesses.reduceGameAction) api.engine.reduceGameAction = original.reduceGameAction;
        if (api.engine.evaluateIntimacy === installedProcesses.evaluateIntimacy) api.engine.evaluateIntimacy = original.evaluateIntimacy;
        if (api.engine.acceptanceBreakdown === installedProcesses.acceptanceBreakdown) api.engine.acceptanceBreakdown = original.acceptanceBreakdown;
        if (api.engine.acceptanceCalculator === installedProcesses.acceptanceCalculator) api.engine.acceptanceCalculator = original.acceptanceCalculator;
        if (api.engine.selectPatronTactic === installedProcesses.selectPatronTactic) api.engine.selectPatronTactic = original.selectPatronTactic;
        if (api.engine.forceAttemptChance === installedProcesses.forceAttemptChance) api.engine.forceAttemptChance = original.forceAttemptChance;
        if (api.engine.buildPatronMoveCandidates === installedProcesses.buildPatronMoveCandidates) api.engine.buildPatronMoveCandidates = original.buildPatronMoveCandidates;
        if (api.engine.processPatronGroupJoin === installedProcesses.processPatronGroupJoin) api.engine.processPatronGroupJoin = original.processPatronGroupJoin;
        if (api.engine.processPatronGroupParticipants === installedProcesses.processPatronGroupParticipants) api.engine.processPatronGroupParticipants = original.processPatronGroupParticipants;
        if (api.engine.rotatePatronGroupAfterPrimary === installedProcesses.rotatePatronGroupAfterPrimary) api.engine.rotatePatronGroupAfterPrimary = original.rotatePatronGroupAfterPrimary;
        if (api.engine.patronJealousyAssessment === installedProcesses.patronJealousyAssessment) api.engine.patronJealousyAssessment = original.patronJealousyAssessment;
        if (api.engine.recordIntimateHistory === installedProcesses.recordIntimateHistory) api.engine.recordIntimateHistory = original.recordIntimateHistory;
        if (api.engine.recordPatronReach === installedProcesses.recordPatronReach) api.engine.recordPatronReach = original.recordPatronReach;
        if (api.character.addFeeling === installedProcesses.addFeeling) api.character.addFeeling = original.addFeeling;
        if (api.character.addIdentityStrainFromPatronAct === installedProcesses.addIdentityStrainFromPatronAct) api.character.addIdentityStrainFromPatronAct = original.addIdentityStrainFromPatronAct;
        if (api.engine.patronControlNaturalEnd === installedProcesses.patronControlNaturalEnd) api.engine.patronControlNaturalEnd = original.patronControlNaturalEnd;
        if (api.engine.patronControlBoundaryStop === installedProcesses.patronControlBoundaryStop) api.engine.patronControlBoundaryStop = original.patronControlBoundaryStop;
        if (api.engine.patronControlFatigueStop === installedProcesses.patronControlFatigueStop) api.engine.patronControlFatigueStop = original.patronControlFatigueStop;
        if (api.engine.patronControlClimax === installedProcesses.patronControlClimax) api.engine.patronControlClimax = original.patronControlClimax;
        if (api.engine.patronControlAfterglow === installedProcesses.patronControlAfterglow) api.engine.patronControlAfterglow = original.patronControlAfterglow;
        if (api.engine.patronControlPlayerReturnStop === installedProcesses.patronControlPlayerReturnStop) api.engine.patronControlPlayerReturnStop = original.patronControlPlayerReturnStop;
        if (api.engine.patronControlRecallReach === installedProcesses.patronControlRecallReach) api.engine.patronControlRecallReach = original.patronControlRecallReach;
        if (api.engine.patronControlShouldCheckWithHusband === installedProcesses.patronControlShouldCheckWithHusband) api.engine.patronControlShouldCheckWithHusband = original.patronControlShouldCheckWithHusband;
        if (api.engine.patronControlPrivateOffer === installedProcesses.patronControlPrivateOffer) api.engine.patronControlPrivateOffer = original.patronControlPrivateOffer;
        for (const name of [
          'patronControlWifeClimax',
          'patronControlAftermathFeeling',
          'patronControlRecordFirsts',
          'patronControlCrossedLine',
          'patronControlSelfConceptDrift',
          'patronControlAftercareFeeling',
          'patronControlAftercareBond',
          'patronControlRecordVisitOutcome',
          'patronControlAdvanceNamedPatron',
          'patronControlOtherRelationshipReaction',
          'patronControlOpenReaction',
          'patronControlResolveReaction',
          'patronControlExpireReaction',
          'patronControlNightAccount',
          'patronControlUnpromptedCandidates',
          'patronControlApplyNightAccount',
          'patronControlEnjoymentOpinion',
          'patronControlInnerThought',
          'patronControlRecordMoment'
        ]) {
          if (api.engine[name] === installedProcesses[name]) api.engine[name] = original[name];
        }
        if (api.engine.patronControlCoercionEscape === installedProcesses.patronControlCoercionEscape) api.engine.patronControlCoercionEscape = original.patronControlCoercionEscape;
        if (api.engine.patronControlAcquaintanceStop === installedProcesses.patronControlAcquaintanceStop) api.engine.patronControlAcquaintanceStop = original.patronControlAcquaintanceStop;
        if (api.engine.patronControlShameStop === installedProcesses.patronControlShameStop) api.engine.patronControlShameStop = original.patronControlShameStop;
        if (api.engine.patronControlServiceInterrupt === installedProcesses.patronControlServiceInterrupt) api.engine.patronControlServiceInterrupt = original.patronControlServiceInterrupt;
        if (api.engine.patronControlExposureRedress === installedProcesses.patronControlExposureRedress) api.engine.patronControlExposureRedress = original.patronControlExposureRedress;
        if (api.engine.patronControlLineUp === installedProcesses.patronControlLineUp) api.engine.patronControlLineUp = original.patronControlLineUp;
        if (api.engine.patronControlPushIn === installedProcesses.patronControlPushIn) api.engine.patronControlPushIn = original.patronControlPushIn;
        if (api.engine.patronControlRelentChance === installedProcesses.patronControlRelentChance) api.engine.patronControlRelentChance = original.patronControlRelentChance;
        if (api.engine.startPatronInteraction === installedProcesses.startPatronInteraction) api.engine.startPatronInteraction = original.startPatronInteraction;
        if (api.engine.processPatronInteractionTick === installedProcesses.processPatronInteractionTick) api.engine.processPatronInteractionTick = original.processPatronInteractionTick;
        if (api.engine.resolvePatronEscalation === installedProcesses.resolvePatronEscalation) api.engine.resolvePatronEscalation = original.resolvePatronEscalation;
        if (api.engine.resolvePatronForce === installedProcesses.resolvePatronForce) api.engine.resolvePatronForce = original.resolvePatronForce;
        if (api.engine.endPatronInteraction === installedProcesses.endPatronInteraction) api.engine.endPatronInteraction = original.endPatronInteraction;
        if (api.engine.applyWifeRestBreak === installedProcesses.applyWifeRestBreak) api.engine.applyWifeRestBreak = original.applyWifeRestBreak;
        if (api.engine.resolvePrivateSessionExit === installedProcesses.resolvePrivateSessionExit) api.engine.resolvePrivateSessionExit = original.resolvePrivateSessionExit;
        if (api.engine.applyPotionEffect === installedProcesses.applyPotionEffect) api.engine.applyPotionEffect = original.applyPotionEffect;
        if (api.engine.passOutWife === installedProcesses.passOutWife) api.engine.passOutWife = original.passOutWife;
        if (api.movement.movePlayer === installedProcesses.movePlayer) api.movement.movePlayer = original.movePlayer;
        if (api.movement.moveWife === installedProcesses.moveWife) api.movement.moveWife = original.moveWife;
        if (api.minuteTick === installedProcesses.minuteTick) api.minuteTick = original.minuteTick;
        if (api.decreaseWifeIntoxication === installedProcesses.decreaseWifeIntoxication) api.decreaseWifeIntoxication = original.decreaseWifeIntoxication;
        delete globalThis[LOADED];
        delete globalThis.__WAYWARD_MODS__?.[MOD_ID];
      }
    };
    debug('installed', VERSION);
  }

  try {
    install();
  } catch (error) {
    console.error(`[${MOD_ID}] Failed to install`, error);
  }
})();
