// 생성 파일. 수정: source/mod.wml.js, source/native-ui.js — 재생성: node wml/mods/badguest/source/build.mjs
// 각 모드에 포함되는 설정 UI. 게임 HTML의 메뉴와 DOM만 사용합니다.
(() => {
  if (globalThis.__waywardModUiFactory?.version === 1) return;
  const entries = new Map(), windows = new Map();
  const legacyButtons = '[data-wc2-preg-menu],[data-wc2-customer-menu],.ww-brothel-menu-button,[data-bad-guest-settings-launch],[data-ww-image-studio-menu]';
  let queued = false, theme = null;
  const cssValues = new Map(), cssProbe = document.createElement('div').style;

  function ModNativeUI_요소만들기(tag, props, ...children) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(props || {})) {
      if (value == null || value === false) continue;
      if (key === 'class') node.className = value;
      else if (key === 'style') node.style.cssText = value;
      else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2).toLowerCase(), value);
      else if (key in node && key !== 'list') node[key] = value;
      else node.setAttribute(key, value === true ? '' : String(value));
    }
    for (const child of children.flat()) if (child != null && child !== false) node.append(child.nodeType ? child : String(child));
    return node;
  }
  // WML 0.9.5 owns pause-menu placement through api.ui.pauseSettings.
  function ModNativeUI_메뉴찾기() { return []; }
  function ModNativeUI_스타일지정하기(node, property, value) {
    const key = property + ':' + value;
    if (!cssValues.has(key)) { cssProbe.setProperty(property, value); cssValues.set(key, cssProbe.getPropertyValue(property)); }
    if (node.style.getPropertyValue(property) !== cssValues.get(key) || node.style.getPropertyPriority(property) !== 'important') node.style.setProperty(property, value, 'important');
  }
  function ModNativeUI_테마읽기(button) {
    const native = getComputedStyle(button || document.getElementById('root') || document.body);
    const channels = (native.backgroundColor.match(/[\d.]+/g) || [28, 25, 23]).slice(0, 3).map(Number);
    const luminance = Math.max(.09, Math.min(.22, (Math.max(...channels) + Math.min(...channels)) / 510));
    return { font: native.fontFamily || 'sans-serif', background: `hsl(32 52% ${Math.round(luminance * 100 + 4)}%)`,
      foreground: 'hsl(40 78% 88%)', border: 'hsl(32 55% 34%)', radius: native.borderRadius || '6px' };
  }
  function ModNativeUI_버튼색칠하기(button, settings) {
    const colors = theme = ModNativeUI_테마읽기(settings);
    for (const [key, value] of Object.entries({ background: colors.background, color: colors.foreground,
      'border-color': colors.border, 'border-width': '1px', 'border-style': 'solid', 'border-radius': colors.radius,
      width: '100%', padding: '8px 16px', 'font-family': colors.font, 'font-size': '14px', cursor: 'pointer' })) ModNativeUI_스타일지정하기(button, key, value);
  }
  function ModNativeUI_앞으로올리기(node) {
    ModNativeUI_스타일지정하기(node, 'z-index', '2147483647');
    if (node.parentElement === document.body && node.nextElementSibling) document.body.append(node);
  }
  function ModNativeUI_정리하기() {
    for (const { list, settings } of ModNativeUI_메뉴찾기()) {
      let anchor = settings;
      for (const [owner, entry] of entries) {
        let button = [...list.children].find(node => node.dataset.waywardNativeSettings === owner);
        if (!button && entry.legacyButton) button = list.querySelector(entry.legacyButton);
        if (!button) {
          button = ModNativeUI_요소만들기('button', { type: 'button', class: settings.className,
            'data-wayward-native-settings': owner, ...entry.attributes,
            class: `${settings.className} ${entry.attributes?.class || ''}`.trim() }, entry.label);
          button.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); entry.onClick?.();
            queueMicrotask(() => entry.windowSelector && document.querySelectorAll(entry.windowSelector).forEach(ModNativeUI_앞으로올리기)); });
          list.append(button);
        }
        button.dataset.waywardNativeSettings = owner;
        // 이 표시는 새 로더의 기존 버튼 정렬과도 같은 순서를 유지하게 합니다.
        // 구형 로더에서는 사용하지 않아도 HTML 메뉴가 직접 처리됩니다.
        button.dataset.wmlModSettings = owner;
        ModNativeUI_버튼색칠하기(button, settings);
        if (button.textContent !== entry.label) button.textContent = entry.label;
        if (anchor.nextElementSibling !== button) anchor.after(button);
        anchor = button;
      }
      const panel = list.parentElement;
      if (panel.style.maxHeight !== 'calc(100dvh - 32px)') panel.style.maxHeight = 'calc(100dvh - 32px)';
      if (panel.style.overflowY !== 'auto') panel.style.overflowY = 'auto';
    }
    for (const entry of entries.values()) if (entry.windowSelector) {
      for (const panel of document.querySelectorAll(entry.windowSelector)) {
        ModNativeUI_스타일지정하기(panel, 'z-index', '2147483647');
      }
    }
  }
  function ModNativeUI_정리예약하기() {
    if (queued) return;
    queued = true;
    queueMicrotask(() => { queued = false; ModNativeUI_정리하기(); });
  }
  function ModNativeUI_버튼만들기(label, onClick, options = {}) {
    return ModNativeUI_요소만들기('button', { type: 'button', class: 'wayward-native-button',
      title: options.title, disabled: options.disabled, onclick: onClick,
      style: options.primary ? 'background:#78350f;color:#fef3c7' : '' }, label);
  }
  function ModNativeUI_창열기(owner, options) {
    const id = `${owner}:${options.id || 'settings'}`;
    if (windows.has(id)) { const prior = windows.get(id); prior.focus(); return prior; }
    const colors = theme || ModNativeUI_테마읽기();
    const width = Math.min(options.width || 520, Math.max(280, innerWidth - 16));
    const height = Math.min(options.height || 440, Math.max(160, innerHeight - 16));
    const title = ModNativeUI_요소만들기('strong', {}, options.title || owner);
    const body = ModNativeUI_요소만들기('div', { class: 'wayward-native-window-body' });
    const node = ModNativeUI_요소만들기('section', { class: 'wayward-native-window', role: 'region',
      'aria-label': options.title || owner, 'data-wml-ui': owner, 'data-wayward-native-window': id,
      style: `left:${Math.max(8, (innerWidth - width) / 2)}px;top:${Math.max(8, (innerHeight - height) / 3)}px;width:${width}px;height:${height}px;font-family:${colors.font}` });
    let removeBack = null;
    function ModNativeUI_창닫기() { node.remove(); windows.delete(id); removeBack?.(); options.onClose?.(); }
    const bar = ModNativeUI_요소만들기('header', { class: 'wayward-native-window-title' }, title,
      ModNativeUI_버튼만들기('✕', ModNativeUI_창닫기, { title: '닫기' }));
    node.append(bar, body);
    const handle = { el: node, body, owner, close: ModNativeUI_창닫기,
      focus: () => {
        ModNativeUI_앞으로올리기(node); windows.delete(id); windows.set(id, handle);
        if (typeof options.onBack === 'function') {
          removeBack?.(); removeBack = options.onBack(() => { handle.close(); return true; });
        }
      }, setTitle: value => { title.textContent = value; },
      refresh: () => { body.replaceChildren(); options.render?.(body, handle); } };
    node.addEventListener('pointerdown', handle.focus);
    bar.addEventListener('pointerdown', event => {
      if (event.button !== 0 || event.target.closest('button')) return;
      event.preventDefault();
      const x = event.clientX - node.offsetLeft, y = event.clientY - node.offsetTop;
      const move = next => { node.style.left = Math.max(0, Math.min(innerWidth - 80, next.clientX - x)) + 'px'; node.style.top = Math.max(0, Math.min(innerHeight - 40, next.clientY - y)) + 'px'; };
      const stop = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', stop); };
      window.addEventListener('pointermove', move); window.addEventListener('pointerup', stop, { once: true });
    });
    windows.set(id, handle); document.body.append(node); handle.focus(); handle.refresh();
    return handle;
  }
  const style = ModNativeUI_요소만들기('style', { 'data-wayward-native-ui': '1' });
  style.textContent = `
    .wayward-native-window{position:fixed;display:flex;flex-direction:column;font-size:14px;max-width:calc(100vw - 16px);max-height:calc(100dvh - 16px);min-width:280px;min-height:160px;resize:both;overflow:hidden;background:#1c1917;color:#e7e5e4;border:1px solid #92400e;border-radius:9px;box-shadow:0 14px 44px #000c}
    .wayward-native-window-title{display:flex;align-items:center;gap:8px;padding:8px 10px;background:#292524;border-bottom:1px solid #44403c;cursor:move;touch-action:none}.wayward-native-window-title strong{flex:1;font-size:14px}.wayward-native-window-body{flex:1;overflow:auto;padding:12px}
    .wayward-native-button{border:1px solid #57534e;border-radius:6px;padding:6px 10px;background:#292524;color:#e7e5e4;cursor:pointer;font:inherit}.wayward-native-button:disabled{opacity:.45;cursor:default}
    .wayward-native-window .wml-muted{color:#a8a29e}.wayward-native-window .wml-note{color:#fde68a}.wayward-native-window .wml-small{font-size:12px}
    @media(max-width:640px){.wayward-native-window{left:8px!important;top:8px!important;width:calc(100vw - 16px)!important;height:calc(100dvh - 16px)!important;resize:none}}
  `;
  document.head.append(style);
  const observer = new MutationObserver(ModNativeUI_정리예약하기);
  observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'hidden', 'class'] });
  window.addEventListener('keydown', event => {
    if (event.key !== 'Escape' || !windows.size) return;
    [...windows.values()].at(-1).close(); event.preventDefault(); event.stopImmediatePropagation();
  }, true);
  window.addEventListener('pagehide', () => observer.disconnect(), { once: true });
  function ModNativeUI_연결하기(base, config) {
    const owner = config.id, raw = name => config.bindings?.[base.game]?.[name] || name;
    const resolve = name => {
      const candidate = raw(name);
      if (base.engine && candidate in base.engine) return candidate;
      return base.sym(name);
    };
    const registerMenu = options => { entries.set(owner, options); return base.ui.pauseSettings({ ...options, attributes: { ...options.attributes, 'data-wayward-native-settings': owner }, onClick: () => { options.onClick?.(); queueMicrotask(() => options.windowSelector && document.querySelectorAll(options.windowSelector).forEach(ModNativeUI_앞으로올리기)); } }); };
    const ui = { ...base.ui,
      h: ModNativeUI_요소만들기, button: ModNativeUI_버튼만들기,
      window: options => ModNativeUI_창열기(owner, { ...options, onBack: base.onBack }),
      settings: render => {
        registerMenu({ label: config.label, onClick: () => ModNativeUI_창열기(owner,
          { id: 'settings', title: config.label, render, onBack: base.onBack }) }); ModNativeUI_정리예약하기();
      },
      menuSettings: registerMenu,
    };
    const facade = { ...base, ui,
      fn: name => base.engine?.[resolve(name)], sym: resolve,
      has: name => { try { return !!resolve(name); } catch { return false; } },
      hook: (name, options) => base.hook(resolve(name), options),
      onBack: typeof base.onBack === 'function' ? base.onBack : () => () => {},
    };
    if (config.legacy) ui.menuSettings(config.legacy);
    return facade;
  }
  globalThis.__waywardModUiFactory = { version: 1, connect: ModNativeUI_연결하기 };
})();

WML.define({
  id: 'badguest',
  name: '나쁜 손님 모드',
  // mod symbols (tools/mod-symbols.mjs / MCP symbol_add keep this block; data only)
  symbols: {
    "badGuestPrivateRoomCandidates": {"raw":{"2026-11-01":"oy"},"doc":"Use original pre6 private-room candidates and scores for BadGuest lure"},
    "badGuestEnterPrivateRoom": {"raw":{"2026-11-01":"Qa"},"doc":"Enter a BadGuest lure destination through the original private-session transition"},
    "approachClosedDoor": {"raw":{"2026-11-01":"m$"},"doc":"Move the player to a closed room threshold while preserving the original travel interruption check"},
    "roomSideForOccupant": {"raw":{"2026-11-01":"nD"},"doc":"Classify an occupant as inside, outside, or peeking at a room door"},
    "addFeeling": {"raw":{"2026-11-01":"Se"},"doc":"Add a feeling or mood memory"},
    "addIdentityStrainFromPatronAct": {"raw":{"2026-11-01":"Cd"},"doc":"Apply identity strain from a patron act"},
    "applyPotionCupEffects": {"raw":{"2026-11-01":"c$"},"doc":"Resolve a consumed potion cup through the original dose and attenuation pipeline"},
    "applyPotionEffect": {"raw":{"2026-11-01":"uJe"},"doc":"Apply one already attenuated potion effect"},
    "applyWifeRestBreak": {"raw":{"2026-11-01":"iy"},"doc":"Apply a selected autonomous wife rest break, including movement and its departure log"},
    "acceptanceBreakdown": {"raw":{"2026-11-01":"ud"},"doc":"Calculate sexual satiation, fatigue, and soreness contributions for acceptance"},
    "acceptanceCalculator": {"raw":{"2026-11-01":"MS"},"doc":"Build the detailed intimacy acceptance decision"},
    "buildPatronMoveCandidates": {"raw":{"2026-11-01":"Zve"},"doc":"Build candidate patron escalation moves"},
    "decreaseWifeIntoxication": {"raw":{"2026-11-01":"dpe"},"doc":"Apply the normal per-minute intoxication decrease"},
    "ejectCustomer": {"raw":{"2026-11-01":"HR"},"doc":"Eject a customer from the tavern"},
    "endPatronInteraction": {"raw":{"2026-11-01":"Rt"},"doc":"End a patron interaction"},
    "evaluateIntimacy": {"raw":{"2026-11-01":"We"},"doc":"Evaluate acceptance of an intimate act"},
    "finishBackRoomService": {"raw":{"2026-11-01":"IV"},"doc":"Finish back-room service"},
    "forceAttemptChance": {"raw":{"2026-11-01":"iIe"},"doc":"Calculate the chance that a patron attempts coercion"},
    "getEffectiveAttributes": {"raw":{"2026-11-01":"B"},"doc":"Calculate complete effective character attributes, including body and effect deltas"},
    "getWifeSleepRoom": {"raw":{"2026-11-01":"ho"},"doc":"Get the wife's actual room for tonight"},
    "getMaritalDrift": {"raw":{"2026-11-01":"Z8"},"doc":"Get marital drift"},
    "getPatronAttachment": {"raw":{"2026-11-01":"Oo"},"doc":"Get the wife's attachment to a patron"},
    "patronJealousyAssessment": {"raw":{"2026-11-01":"LN"},"doc":"Build a patron's original jealousy assessment toward the active rival scene"},
    "relationshipInfluence": {"raw":{"2026-11-01":"fC"},"doc":"원본 pre7 최종 관계 영향력(Your say); 일반 지시와 손님 판단에 쓰는 역할·친밀도·감정 합성값"},
    "minuteTick": {"raw":{"2026-11-01":"ry"},"doc":"Advance base character and world state by one minute"},
    "moveWife": {"raw":{"2026-11-01":"Nt"},"doc":"Move the wife to a room"},
    "nudgeRelationship": {"raw":{"2026-11-01":"ko"},"doc":"Adjust relationship values"},
    "passOutWife": {"raw":{"2026-11-01":"qJe"},"doc":"Run the original wife blackout transition and scene cleanup"},
    "retireWife": {"raw":{"2026-11-01":"cm"},"doc":"Run the original wife retirement transition"},
    "patronControlAcquaintanceStop": {"raw":{"2026-11-01":"OUe"},"doc":"가족·지인 목격 시 장면 중단 여부를 처리"},
    "patronControlCoercionEscape": {"raw":{"2026-11-01":"YOe"},"doc":"강압 장면에서 아내가 빠져나오는 조건을 처리"},
    "patronControlBoundaryStop": {"raw":{"2026-11-01":"aZ"},"doc":"거절 뒤 성행위 경계 중단 문구를 결정"},
    "patronControlFatigueStop": {"raw":{"2026-11-01":"KGe"},"doc":"피로와 쓰라림 때문에 장면을 중단할지 결정"},
    "patronControlClimax": {"raw":{"2026-11-01":"KJ"},"doc":"손님 절정 완료 상태와 여운을 확정한 뒤 응대를 종료"},
    "patronControlAfterglow": {"raw":{"2026-11-01":"XPe"},"doc":"손님 절정 뒤 여운 시간을 진행하고 응대를 종료"},
    "patronControlPlayerReturnStop": {"raw":{"2026-11-01":"p7e"},"optional":true,"doc":"플레이어 귀환이 임박해 장면을 중단할지 결정"},
    "patronControlRecallReach": {"raw":{"2026-11-01":"Q7e"},"doc":"착란 인식에 따라 손님별 과거 행위 단계 회상 문구를 계산","optional":true},
    "patronControlShouldCheckWithHusband": {"raw":{"2026-11-01":"HC"},"doc":"착란 인식에 따라 행위 진행 전 남편에게 허락을 구하는 판정을 제어","optional":true},
    "patronControlNaturalEnd": {"raw":{"2026-11-01":"GC"},"doc":"손님 응대 장면의 자연 종료 사유를 계산"},
    "patronControlRelentChance": {"raw":{"2026-11-01":"mIe"},"doc":"손님이 강압을 멈출 확률을 계산"},
    "patronControlShameStop": {"raw":{"2026-11-01":"WOe"},"doc":"목격자 때문에 장면이 중단되는 조건을 처리"},
    "processPatronGroupJoin": {"raw":{"2026-11-01":"gN"},"doc":"Process patrons joining a group scene"},
    "processPatronGroupParticipants": {"raw":{"2026-11-01":"_N"},"doc":"Process participants in a patron group scene"},
    "processPatronInteractionTick": {"raw":{"2026-11-01":"cZ"},"doc":"Advance an active patron interaction by one tick"},
    "recordAffection": {"raw":{"2026-11-01":"$_"},"doc":"Record affection toward a patron"},
    "recordIntimateHistory": {"raw":{"2026-11-01":"Om"},"doc":"Record intimate history while preserving continued-scene accounting"},
    "recordPatronBoundary": {"raw":{"2026-11-01":"Ua"},"doc":"Record a patron boundary event"},
    "recordPatronMistreatment": {"raw":{"2026-11-01":"sl"},"doc":"Record patron mistreatment"},
    "recordPatronReach": {"raw":{"2026-11-01":"X7e"},"doc":"Record a patron reaching an interaction stage"},
    "recordPlayerTone": {"raw":{"2026-11-01":"St"},"doc":"Record the player's response tone"},
    "reduceGameAction": {"raw":{"2026-11-01":"p5"},"doc":"Reduce a dispatched game action"},
    "resolvePatronEscalation": {"raw":{"2026-11-01":"v0"},"doc":"Resolve a patron escalation attempt"},
    "resolvePatronForce": {"raw":{"2026-11-01":"Zq"},"doc":"Resolve patron coercion"},
    "resolvePrivateSessionExit": {"raw":{"2026-11-01":"hHe"},"doc":"Resolve a completed private patron session, including room exit movement and narration","optional":true},
    "rotatePatronGroupAfterPrimary": {"raw":{"2026-11-01":"S1e"},"doc":"Rotate group participants after the primary patron"},
    "selectPatronTactic": {"raw":{"2026-11-01":"MUe"},"doc":"Select a patron tactic"},
    "startPatronInteraction": {"raw":{"2026-11-01":"Xo"},"doc":"Start a patron interaction"},
    "transitionPatronStage": {"raw":{"2026-11-01":"js"},"doc":"Transition a patron interaction stage"},
    "patronControlServiceInterrupt": {"raw":{"2026-11-01":"UC"},"doc":"수갑 장면에서 홀 서비스 요구로 응대를 중단하는 판정을 제어"},
    "patronControlExposureRedress": {"raw":{"2026-11-01":"hZ"},"doc":"수갑 장면에서 노출을 바로잡다가 응대를 중단하는 판정을 제어"},
    "patronControlWifeClimax": {"raw":{"2026-11-01":"YG"},"doc":"Project the wife's patron-scene climax perception and emotional aftermath","optional":true},
    "patronControlAftermathFeeling": {"raw":{"2026-11-01":"M8"},"doc":"Calculate the primary emotional aftermath of an intimate act","optional":true},
    "patronControlRecordFirsts": {"raw":{"2026-11-01":"wG"},"doc":"Record subjective first experiences with a patron","optional":true},
    "patronControlCrossedLine": {"raw":{"2026-11-01":"mqe"},"doc":"Apply subjective consequences for crossing a husband boundary","optional":true},
    "patronControlSelfConceptDrift": {"raw":{"2026-11-01":"RX"},"doc":"Apply self-concept drift from a patron act","optional":true},
    "patronControlAftercareFeeling": {"raw":{"2026-11-01":"H1e"},"doc":"Apply the emotional memory of patron aftercare","optional":true},
    "patronControlAftercareBond": {"raw":{"2026-11-01":"L1e"},"doc":"Apply patron relationship changes from aftercare","optional":true},
    "patronControlRecordVisitOutcome": {"raw":{"2026-11-01":"IG"},"doc":"Record factual visit data and subjective patron relationship changes","optional":true},
    "patronControlAdvanceNamedPatron": {"raw":{"2026-11-01":"D0e"},"doc":"Advance a named patron arc after an interaction","optional":true},
    "patronControlOtherRelationshipReaction": {"raw":{"2026-11-01":"Fke"},"doc":"Apply other relationship reactions after a patron act","optional":true},
    "patronControlOpenReaction": {"raw":{"2026-11-01":"hx"},"doc":"Open the post-patron reaction window from the current subjective context","optional":true},
    "patronControlInnerThought": {"raw":{"2026-11-01":"Ih"},"doc":"Generate the wife post-patron inner thought from the current subjective context","optional":true},
    "patronControlRecordMoment": {"raw":{"2026-11-01":"_be"},"doc":"Record the factual patron moment with subjective aftermath metadata","optional":true},
    "patronControlMomentTitle": {"raw":{"2026-11-01":"gx"},"doc":"Format a patron moment title with patron, act, location, time, and player response","optional":true},
    "intimacyReceptionLabels": {"raw":{"2026-11-01":"doe"},"doc":"원본 만남 기록 화면에 착란 중 수용 상태를 별도 문구로 표시"},
    "recentPatronIntimacySummary": {"raw":{"2026-11-01":"j_e"},"doc":"착란 전용 이력 값을 당시 주관적 반응으로 투영해 최근 손님 친밀행위 감정을 계산"},
    "feelingSourceLabel": {"raw":{"2026-11-01":"gy"},"doc":"Format a feeling source for the mood and memory UI","optional":true},
    "patronControlResolvePrivateOffer": {"raw":{"2026-11-01":"Gg"},"doc":"사적 방 제안을 원본 그녀 결정 경로로 해결","optional":true},
    "patronControlPrivateOffer": {"raw":{"2026-11-01":"T0"},"doc":"착란 중 자발적 사적 방 제안을 선택창 전에 자동 진행","optional":true},
    "patronControlResolveReaction": {"raw":{"2026-11-01":"gj"},"doc":"목격한 BadGuest 사건에 대한 즉시 반응을 원인에 맞게 해결","optional":true},
    "patronControlExpireReaction": {"raw":{"2026-11-01":"owe"},"doc":"목격 반응 창 만료를 사건 원인에 맞게 처리","optional":true},
    "patronControlNightAccount": {"raw":{"2026-11-01":"kC"},"doc":"목격된 밤 사건을 이후 대화에서 설명","optional":true},
    "patronControlEnjoymentOpinion": {"raw":{"2026-11-01":"UWe"},"doc":"손님과의 경험에 대한 의견을 사건 원인에 맞게 설명","optional":true},
    "patronControlApplyNightAccount": {"raw":{"2026-11-01":"uX"},"doc":"Apply a cause-aware night account without voluntary-confession consequences","optional":true},
    "patronControlRecordConfession": {"raw":{"2026-11-01":"IU"},"doc":"Record a confession in the original rolling confession history","optional":true},
    "patronControlRecordConfessionReception": {"raw":{"2026-11-01":"pke"},"doc":"Record a response on the latest unanswered original confession","optional":true},
    "patronControlConfessionSummary": {"raw":{"2026-11-01":"D_"},"doc":"Summarize original confession response history and ceremony state","optional":true},
    "patronControlResolveConfession": {"raw":{"2026-11-01":"uBe"},"doc":"Resolve an original confession response including repair and sanction","optional":true},
    "patronControlIsUncommitted": {"raw":{"2026-11-01":"Gm"},"doc":"Use the original relationship gate for committed confession responses","optional":true},
    "recordLatitudeEncouragement": {"raw":{"2026-11-01":"Bi"},"doc":"Record category encouragement with an explicit signal"},
    "recordLatitudeRestriction": {"raw":{"2026-11-01":"Gr"},"doc":"Record category restriction with an explicit signal"},
    "recordPatronLatitude": {"raw":{"2026-11-01":"Ug"},"doc":"Record patron-specific encouragement or restriction"},
    "patronControlMomentCategory": {"raw":{"2026-11-01":"Aj"},"doc":"Map a patron moment to its original latitude category"},
    "patronControlUnpromptedCandidates": {"raw":{"2026-11-01":"hX"},"doc":"Preserve BadGuest incident confession candidates through qualified moment filtering"},
    "patronControlCanConfess": {"raw":{"2026-11-01":"AU"},"doc":"Preserve BadGuest incident confession candidates through qualified moment filtering"}
  },
  version: "1.4.3",
  game: "2026-11-01",
  author: '민트좋아',
  role: 'badguest',
  loadAfter: ['qualified-experience'],
  description: '적극적으로 대상 인물을 공략하는 나쁜 손님과 전용 사건을 추가합니다.',

  async setup(wmlApi) {
    const api = globalThis.__waywardModUiFactory.connect(wmlApi, {"id":"badguest","label":"나쁜 손님 모드 설정","bindings":{"2026-10-04":{"store":"ae","settingsStore":"At","React":"Z","jsx":"u","ActionButton":"Ze","ActionPanel":"aO","wife":"_","updateWife":"O","updateCharacter":"nn","log":"N","tick":"Jt","intoxLabel":"In","playerId":"fe","wifeId":"Re","locationOf":"$e","wifeLocation":"_e","playerLocation":"bt","moveOccupant":"Pt","patronScene":"Y","playerSexScene":"Le","setScene":"MV","patronSceneLocation":"tt","isSexualStage":"it","sceneDef":"ls","sceneOutfitState":"bx","garmentWorn":"vr","exposureSummary":"nf","patronWatchChoices":"Xae","patronChoice":"tNe","startPlayerSex":"_p","playerSexEvent":"Fl","ensureHusbandLed":"F8","addJoinedPatron":"nfe","joinSlots":"NH","registerAlert":"nr","queueAlert":"gn","drainAlerts":"gl","imagePrompt":"r8","imageKey":"s8","imageKeyOf":"n8","imageDescriptor":"o8","makeCustomer":"ff","addCustomer":"Ka","carryToBed":"RDe","talkToWife":"EF","actionTimes":"Oo","addFeeling":"we","addIdentityStrainFromPatronAct":"Kf","getCustomerLocation":"Yn","getEffectiveAttributes":"B","heroineConditioningMax":"QX","heroineDriveCalc":"si","moveWife":"pt","outfits":"fh","patronControlCustomerLocation":"ht","wifeById":"ul","wifePreview":"gue","reduceGameAction":"wT","brothelLog":"hs","decisionCategories":"bo","decisionResolve":"G$e","manaMax":"ms","minuteTick":"gp","recordPlayerTone":"Rt","wives":"mh","imageBackend":"Eh","brothelCustomerBusy":"XO","buildPatronMoveCandidates":"Phe","ejectCustomer":"Q5","endPatronInteraction":"jt","finishBackRoomService":"xF","forceAttemptChance":"Ppe","patronControlAcquaintanceStop":"_Ie","patronControlAttemptRoll":"Iy","patronControlBackRoomOpen":"Tr","patronControlBareForPushIn":"O5","patronControlChooseMove":"Yhe","patronControlCoercionEscape":"cpe","patronControlFavorTable":"h3","patronControlHerBackRoomProposal":"ipe","patronControlIntentEvolve":"z$","patronControlJoinerComfort":"wh","patronControlJoinerPushIn":"jIe","patronControlLineUp":"Gce","patronControlLungePlan":"Vre","patronControlMortifyingCheck":"b$","patronControlMoveCustomer":"Yt","patronControlNaturalEnd":"hI","patronControlPatronBackRoomProposal":"ape","patronControlPatronDrift":"Kbe","patronControlPlayerAway":"Tt","patronControlPositionWeights":"Fhe","patronControlPrivateSession":"wpe","patronControlPrivateSessionInfo":"a0","patronControlPushIn":"qce","patronControlPushInAnalReaction":"p6","patronControlPushInReaction":"R6","patronControlRelentChance":"Bpe","patronControlRequestTable":"E2e","patronControlSelfEscalationRoll":"Qre","patronControlShameStop":"dpe","patronControlSlotFree":"kS","patronControlSmallRequest":"R2e","patronControlStageLabel":"hG","patronControlStrengthContest":"Za","patronControlTacticTable":"lIe","patronControlUndressAttempt":"AIe","patronControlVerbalAsk":"$5e","patronControlWitnessesFor":"Ks","patronControlYieldRoll":"pB","playerActionPublicRefusal":"Rs","processPatronGroupJoin":"BS","processPatronGroupParticipants":"WS","processPatronInteractionTick":"R7","recordPatronMistreatment":"yl","recordPatronReach":"K5e","resolvePatronEscalation":"ub","resolvePatronForce":"gB","rotatePatronGroupAfterPrimary":"Gie","selectPatronTactic":"gIe","startPatronInteraction":"Go","transitionPatronStage":"Dn","evaluateIntimacy":"Pe","getMaritalDrift":"E4","getPatronAttachment":"Uo","nudgeRelationship":"Mo","recordAffection":"Iw","recordIntimateHistory":"Wd","recordPatronBoundary":"Qi","brothelRoomLabels":"bO","imageRoom":"lue","waitressAlternative":"u$","waitressAvailable":"Bd","waitressChooseOrder":"Jle","waitressConsume":"_w","waitressIncome":"Qt","waitressMissing":"CP","waitressPrice":"d$","waitressRecordDrink":"vw","waitressRecordWord":"VB","playerActionRespond":"P1e","playerActionTopicFatigue":"GY","playerActionTouchedOut":"er","promptJoin":"J6","promptRoomFilter":"$de","promptGenParams":"q6","outfitById":"Ot","saveSlotInfo":"Mb","listDayStarts":"ZI","saveDayStart":"UDe","wifePortraits":"z6e","resentment":"Ue","marriageBond":"VT","wakeUp":"FI","gameOverScreen":"HLe","allureScore":"Ir","normalVisitRoll":"nhe","lodgingChance":"IB","worldTick":"Dp","hotkeyAction":"sG","confirmAction":"N4e","busyTask":"X0","imageManifest":"Wb","imageServerUrl":"Cs","imageGenerate":"LPe","imageQueue":"g6e","imageBackendProbe":"JU","imageBackendForget":"UD","imagePackReset":"qD","imageAutoProbeAllowed":"KU"}}});
    if (api.game !== '2026-11-01') {
      throw new Error(`나쁜 손님 모드는 2026-11-01 게임용입니다. 현재 버전: ${api.game}`);
    }

    const CONFUSION_RECEPTION_LABELS = Object.freeze({
      badguest_confused_eager: Object.freeze({ base: 'eager', label: '착란하여 열렬히 응함' }),
      badguest_confused_willing: Object.freeze({ base: 'willing', label: '착란하여 기꺼이 응함' }),
      badguest_confused_hesitant: Object.freeze({ base: 'hesitant', label: '착란하여 망설임' }),
      badguest_confused_reluctant: Object.freeze({ base: 'reluctant', label: '착란하여 마지못해 응함' }),
      badguest_confused_paid: Object.freeze({ base: 'paid', label: '착란한 채 대가를 받음' }),
      badguest_confused_forced: Object.freeze({ base: 'forced', label: '착란한 채 강요당함' })
    });
    const APHRODISIAC_RECEPTION_LABELS = Object.freeze({
      badguest_aphrodisiac_eager: Object.freeze({ base: 'eager', label: '미약에 취해 열렬히 응함' }),
      badguest_aphrodisiac_willing: Object.freeze({ base: 'willing', label: '미약에 이끌려 기꺼이 응함' }),
      badguest_aphrodisiac_hesitant: Object.freeze({ base: 'hesitant', label: '미약에 휩쓸려 망설이며 응함' }),
      badguest_aphrodisiac_reluctant: Object.freeze({ base: 'reluctant', label: '미약을 이기지 못해 응함' }),
      badguest_aphrodisiac_paid: Object.freeze({ base: 'paid', label: '미약에 취한 채 대가를 받음' }),
      badguest_aphrodisiac_forced: Object.freeze({ base: 'forced', label: '미약 상태에서 강요당함' })
    });
    if (api.game === '2026-11-01') {
      const receptionLabels = api.fn('intimacyReceptionLabels');
      if (receptionLabels && typeof receptionLabels === 'object') {
        for (const [key, definition] of Object.entries({
          ...CONFUSION_RECEPTION_LABELS,
          ...APHRODISIAC_RECEPTION_LABELS
        })) {
          if (receptionLabels[key]) continue;
          receptionLabels[key] = Object.freeze({
            label: definition.label,
            color: receptionLabels[definition.base]?.color || 'text-stone-400'
          });
        }
      }
    }

    const store = {
      getState: () => api.store.get(),
      setState: updater => api.store.set(updater),
      subscribe: listener => api.store.subscribe(listener)
    };

    const getSleepActions = () => {
      try {
        const service = api.use?.('sleep-actions');
        return service?.apiVersion >= 7 && typeof service.session?.addDepth === 'function'
          ? service : null;
      } catch {
        return null;
      }
    };

    const getHerDebtDebt = () => {
      try {
        const service = api.use?.('her-debt');
        return service?.apiVersion === 1 && typeof service.debt?.add === 'function'
          ? service.debt : null;
      } catch {
        return null;
      }
    };

    const getQualifiedExperience = () => {
      try {
        const service = api.use?.('qualified-experience');
        return service?.apiVersion === 3
          && typeof service.reportExperience === 'function'
          && typeof service.reportVisit === 'function'
          && typeof service.reportPhysicalExperience === 'function'
          ? service : null;
      } catch {
        return null;
      }
    };

    const bridge = {
      gameVersion: api.game,
      state: { gameStore: store },
      settings: api.settings,
      integrations: { getSleepActions, getHerDebtDebt, getQualifiedExperience },
      character: {
        getWife: api.fn('wife'),
        getLocation: api.fn('wifeLocation'),
        getActiveScene: api.fn('patronScene'),
        getCustomerLocation: (state, id) => api.fn('locationOf')(state, id),
        getEffectiveAttributes: api.fn('getEffectiveAttributes'),
        getWifeSleepRoom: api.fn('getWifeSleepRoom'),
        addFeeling: api.fn('addFeeling'),
        addIdentityStrainFromPatronAct: api.fn('addIdentityStrainFromPatronAct')
      },
      relationship: {
        getRelationshipInfluence: state => api.fn('relationshipInfluence')(state),
        getMaritalDrift: api.fn('getMaritalDrift'),
        getPatronAttachment: api.fn('getPatronAttachment'),
        getPatronComfort: api.fn('patronControlJoinerComfort'),
        recordPatronBoundary: api.fn('recordPatronBoundary'),
        recordLatitudeEncouragement: api.fn('recordLatitudeEncouragement'),
        recordLatitudeRestriction: api.fn('recordLatitudeRestriction'),
        recordPatronLatitude: api.fn('recordPatronLatitude'),
        nudgeRelationship: api.fn('nudgeRelationship'),
        recordAffection: api.fn('recordAffection')
      },
      engine: {
        badGuestPrivateRoomCandidates: api.fn('badGuestPrivateRoomCandidates'),
        badGuestEnterPrivateRoom: api.fn('badGuestEnterPrivateRoom'),
        approachClosedDoor: api.fn('approachClosedDoor'),
        roomSideForOccupant: api.fn('roomSideForOccupant'),
        patronJealousyAssessment: api.game === '2026-11-01'
          ? api.fn('patronJealousyAssessment')
          : null,
        patronControlMomentCategory: api.fn('patronControlMomentCategory'),
        recordIntimateHistory: api.fn('recordIntimateHistory'),
        transitionPatronStage: (...args) => api.fn('transitionPatronStage')(...args),
        recordPatronReach: api.fn('recordPatronReach'),
        startPatronInteraction: api.fn('startPatronInteraction'),
        finishBackRoomService: api.fn('finishBackRoomService'),
        recordPlayerTone: api.fn('recordPlayerTone'),
        ejectCustomer: api.fn('ejectCustomer'),
        recordPatronMistreatment: api.fn('recordPatronMistreatment'),
        passOutWife: api.fn('passOutWife'),
        applyWifeRestBreak: api.fn('applyWifeRestBreak'),
        advanceWorldMinute: api.fn('tick'),
        resolvePrivateSessionExit: api.game === '2026-10-04'
          ? null
          : api.fn('resolvePrivateSessionExit'),
        applyPotionCupEffects: api.fn('applyPotionCupEffects'),
        retireWife: api.fn('retireWife'),
        patronControlNaturalEnd: api.fn('patronControlNaturalEnd'),
        patronControlBoundaryStop: api.fn('patronControlBoundaryStop'),
        patronControlFatigueStop: api.fn('patronControlFatigueStop'),
        patronControlClimax: api.fn('patronControlClimax'),
        patronControlAfterglow: api.fn('patronControlAfterglow'),
        patronControlPlayerReturnStop: api.game === '2026-10-04'
          ? null
          : api.fn('patronControlPlayerReturnStop'),
        patronControlRecallReach: api.game === '2026-11-01'
          ? api.fn('patronControlRecallReach')
          : null,
        patronControlShouldCheckWithHusband: api.game === '2026-11-01'
          ? api.fn('patronControlShouldCheckWithHusband')
          : null,
        patronControlPrivateOffer: api.game === '2026-11-01'
          ? api.fn('patronControlPrivateOffer')
          : null,
        patronControlResolvePrivateOffer: api.game === '2026-11-01'
          ? api.fn('patronControlResolvePrivateOffer')
          : null,
        patronControlWifeClimax: api.game === '2026-11-01'
          ? api.fn('patronControlWifeClimax')
          : null,
        patronControlAftermathFeeling: api.game === '2026-11-01'
          ? api.fn('patronControlAftermathFeeling')
          : null,
        patronControlRecordFirsts: api.game === '2026-11-01'
          ? api.fn('patronControlRecordFirsts')
          : null,
        patronControlCrossedLine: api.game === '2026-11-01'
          ? api.fn('patronControlCrossedLine')
          : null,
        patronControlSelfConceptDrift: api.game === '2026-11-01'
          ? api.fn('patronControlSelfConceptDrift')
          : null,
        patronControlAftercareFeeling: api.game === '2026-11-01'
          ? api.fn('patronControlAftercareFeeling')
          : null,
        patronControlAftercareBond: api.game === '2026-11-01'
          ? api.fn('patronControlAftercareBond')
          : null,
        patronControlRecordVisitOutcome: api.game === '2026-11-01'
          ? api.fn('patronControlRecordVisitOutcome')
          : null,
        patronControlAdvanceNamedPatron: api.game === '2026-11-01'
          ? api.fn('patronControlAdvanceNamedPatron')
          : null,
        patronControlOtherRelationshipReaction: api.game === '2026-11-01'
          ? api.fn('patronControlOtherRelationshipReaction')
          : null,
        patronControlOpenReaction: api.game === '2026-11-01'
          ? api.fn('patronControlOpenReaction')
          : null,
        patronControlResolveReaction: api.game === '2026-11-01'
          ? api.fn('patronControlResolveReaction')
          : null,
        patronControlExpireReaction: api.game === '2026-11-01'
          ? api.fn('patronControlExpireReaction')
          : null,
        patronControlNightAccount: api.game === '2026-11-01'
          ? api.fn('patronControlNightAccount')
          : null,
        patronControlUnpromptedCandidates: api.game === '2026-11-01'
          ? api.fn('patronControlUnpromptedCandidates')
          : null,
        patronControlCanConfess: api.game === '2026-11-01'
          ? api.fn('patronControlCanConfess')
          : null,
        patronControlApplyNightAccount: api.game === '2026-11-01'
          ? api.fn('patronControlApplyNightAccount')
          : null,
        patronControlRecordConfession: api.game === '2026-11-01'
          ? api.fn('patronControlRecordConfession')
          : null,
        patronControlRecordConfessionReception: api.game === '2026-11-01'
          ? api.fn('patronControlRecordConfessionReception')
          : null,
        patronControlConfessionSummary: api.game === '2026-11-01'
          ? api.fn('patronControlConfessionSummary')
          : null,
        patronControlResolveConfession: api.game === '2026-11-01'
          ? api.fn('patronControlResolveConfession')
          : null,
        patronControlIsUncommitted: api.game === '2026-11-01'
          ? api.fn('patronControlIsUncommitted')
          : null,
        patronControlEnjoymentOpinion: api.game === '2026-11-01'
          ? api.fn('patronControlEnjoymentOpinion')
          : null,
        patronControlInnerThought: api.game === '2026-11-01'
          ? api.fn('patronControlInnerThought')
          : null,
        patronControlRecordMoment: api.game === '2026-11-01'
          ? api.fn('patronControlRecordMoment')
          : null,
        patronControlMomentTitle: api.game === '2026-11-01'
          ? api.fn('patronControlMomentTitle')
          : null,
        patronControlCoercionEscape: api.fn('patronControlCoercionEscape'),
        patronControlAcquaintanceStop: api.fn('patronControlAcquaintanceStop'),
        patronControlShameStop: api.fn('patronControlShameStop'),
        patronControlServiceInterrupt: api.fn('patronControlServiceInterrupt'),
        patronControlExposureRedress: api.fn('patronControlExposureRedress'),
        patronControlLineUp: api.fn('patronControlLineUp'),
        patronControlPushIn: api.fn('patronControlPushIn'),
        patronControlRelentChance: api.fn('patronControlRelentChance')
      },
      movement: {}
    };

    const releases = [];
    if (api.game === '2026-11-01') {
      const React = api.fn('React');
      const JSX = api.fn('jsx');
      const ActionButton = api.fn('ActionButton');
      const confusionFeelingActions = Object.freeze({
        bold_touch: '대담한 접촉',
        groping: '몸 더듬기',
        intimate: '손가락으로 애무',
        fingering: '손가락으로 애무',
        handjob_patron: '손으로 자극하기',
        handjob: '손으로 자극하기',
        blowjob_patron: '입으로 해주기',
        blowjob: '입으로 해주기',
        rubbing_patron: '허벅지로 애무하기',
        thigh_job: '허벅지로 애무하기',
        sex_patron: '성관계',
        sex: '성관계',
        riding: '위에서 하는 성관계',
        anal: '항문 성교'
      });
      const confusionFeelingLabel = source => {
        const prefix = 'player:confusion:';
        if (typeof source !== 'string' || !source.toLowerCase().startsWith(prefix)) return null;
        const suffix = source.slice(prefix.length);
        if (suffix === 'aftercare') return '행위 뒤의 여운 · 당신으로 착각';
        if (suffix === 'witnessed') return '목격됨 · 당신으로 착각';
        if (suffix === 'forced') return '강제로 당한 일 · 당신으로 착각';
        const [actionId, outcome] = suffix.split(':');
        const action = confusionFeelingActions[actionId] || actionId.replaceAll('_', ' ');
        if (outcome === 'conflicted_climax') {
          return `${action} · 가치관과 충돌`;
        }
        if (outcome === 'she_came_anyway') {
          return `${action} · 원치 않은 절정 · 당신으로 착각`;
        }
        if (outcome === 'climax_tender') {
          return `${action} · 다정한 절정 · 당신으로 착각`;
        }
        if (outcome === 'climax') return `${action} · 절정 · 당신으로 착각`;
        return `${action} · 당신으로 착각`;
      };
      const recoveredConfusionFeelingLabel = (source, next, rest) => {
        if (typeof source !== 'string') return null;
        const deception = source.match(/^patron:([^:]+):confusion_deception$/i);
        if (deception) {
          const partner = next(`patron:${deception[1]}`, ...rest);
          return `착란 중 원치 않은 일 · ${partner}`;
        }
        const match = source.match(/^patron:([^:]+):([^:]+):(conflicted_climax|she_came_anyway|climax_tender|climax)$/i);
        if (!match) return null;
        const [, patronId, actionId, outcome] = match;
        const partner = next(`patron:${patronId}`, ...rest);
        const action = confusionFeelingActions[actionId] || actionId.replaceAll('_', ' ');
        if (outcome === 'conflicted_climax') {
          return `${action} · 가치관과 충돌 · ${partner}`;
        }
        if (outcome === 'she_came_anyway') return `${action} · 원치 않은 절정 · ${partner}`;
        if (outcome === 'climax_tender') return `${action} · 다정한 절정 · ${partner}`;
        return `${action} · 절정 · ${partner}`;
      };
      const aphrodisiacFeelingLabel = (source, next, rest) => {
        if (typeof source !== 'string') return null;
        const match = source.match(/^patron:([^:]+):aphrodisiac(_assisted)?:([^:]+)$/i);
        if (!match) return null;
        const [, patronId, assisted, actionId] = match;
        const partner = next(`patron:${patronId}`, ...rest);
        const action = confusionFeelingActions[actionId] || actionId.replaceAll('_', ' ');
        return assisted
          ? `${action} · 미약을 이기지 못함 · ${partner}`
          : `${action} · 미약의 영향 · ${partner}`;
      };
      const waitOptions = Object.freeze([
        Object.freeze({ label: '1m', minutes: 1, hotkey: '1' }),
        Object.freeze({ label: '5m', minutes: 5, hotkey: '2' }),
        Object.freeze({ label: '15m', minutes: 15, hotkey: '3' })
      ]);
      const hotkey = value => JSX.jsx('span', {
        'aria-hidden': true,
        className: 'hidden desk:inline-grid place-items-center shrink-0 w-[1.05rem] h-[1.05rem] mr-1.5 rounded border border-stone-600 bg-stone-900 text-amber-300 text-[0.6rem] font-mono leading-none align-middle',
        children: value
      });
      const timedDrugEffectActive = (state, effect) => !!effect
        && state.slot >= (effect.startedAtSlot ?? -Infinity)
        && state.slot < (effect.endsAtSlot ?? Infinity);
      const drugDoorControlContext = state => {
        if (!state || state.pendingEvent) return null;
        const scene = state.activeScene?.patron;
        const entry = scene?.badGuestDrugDoorEntry;
        const data = state.mods?.badguest;
        if (!scene?.customerId || !entry?.roomId || scene.playerEngaged) return null;
        if (!(timedDrugEffectActive(state, data?.effects?.aphrodisiac)
          || timedDrugEffectActive(state, data?.effects?.confusion))) return null;
        if (api.fn('playerLocation')(state) !== entry.roomId
          || api.fn('roomSideForOccupant')(state, entry.roomId, 'player') !== 'inside') return null;
        const restraint = data?.equipment?.restraint;
        const interventionStages = new Set([
          'flirting', 'light_touch', 'bold_touch', 'groping', 'intimate',
          'handjob_patron', 'blowjob_patron', 'rubbing_patron', 'sex_patron'
        ]);
        return {
          scene,
          entry,
          intervenable: !scene.afterglow && interventionStages.has(scene.stage),
          restrained: !!restraint?.active
            && String(restraint.patronId) === String(scene.customerId)
        };
      };
      const replaceBadGuestChoiceGrid = (element, replacement) => {
        if (!React.isValidElement(element)) return { element, replaced: false };
        const children = React.Children.toArray(element.props.children);
        const choiceIndex = children.findIndex(child => {
          if (child?.type !== 'div') return false;
          const classes = new Set(String(child.props?.className || '').split(/\s+/).filter(Boolean));
          return classes.has('grid') && classes.has('grid-cols-1') && classes.has('gap-2');
        });
        if (choiceIndex >= 0) {
          const nextChildren = [...children];
          nextChildren[choiceIndex] = replacement;
          return { element: React.cloneElement(element, {}, nextChildren), replaced: true };
        }
        for (let index = 0; index < children.length; index += 1) {
          const nested = replaceBadGuestChoiceGrid(children[index], replacement);
          if (!nested.replaced) continue;
          const nextChildren = [...children];
          nextChildren[index] = nested.element;
          return { element: React.cloneElement(element, {}, nextChildren), replaced: true };
        }
        return { element, replaced: false };
      };
      const drugDoorActionButton = action => JSX.jsx(ActionButton, {
        label: action.label,
        time: action.time,
        description: action.description,
        primary: action.primary === true,
        disabled: action.disabled === true,
        onClick: () => api.store.dispatch(action.dispatch)
      }, action.key);
      const drugDoorControls = context => {
        const actions = [
          {
            key: 'bad-guest-drug-door-intervene',
            label: '개입하기',
            description: context.restrained
              ? '수갑을 풀고 두 사람을 떼어놓은 뒤 안전한 방으로 데려갑니다.'
              : !context.intervenable
                ? '아직 끼어들 만한 일은 벌어지지 않았습니다.'
              : '다가가 멈추라고 말합니다. 그녀가 듣지 않으면 다시 어떻게 할지 정할 수 있습니다.',
            primary: true,
            disabled: !context.restrained && !context.intervenable,
            dispatch: { type: 'bad_guest_drug_door_intervene' }
          },
          {
            key: 'bad-guest-drug-door-leave',
            label: '방에서 물러서기',
            description: '아무것도 하지 않고 방 밖으로 물러납니다.',
            dispatch: { type: 'bad_guest_drug_door_leave' }
          }
        ];
        return JSX.jsxs('div', {
          className: 'space-y-3',
          'data-badguest-drug-door-controls': 'inside',
          children: [
            JSX.jsx('h3', {
              className: 'text-sm font-bold text-amber-400 uppercase tracking-wider mb-1',
              children: '진행 중인 상황'
            }),
            JSX.jsx('div', {
              className: 'grid grid-cols-1 gap-2',
              children: actions.map(drugDoorActionButton)
            }),
            JSX.jsx('div', {
              className: 'grid grid-cols-3 gap-2',
              'data-badguest-drug-door-wait': '',
              children: [1, 5, 15].map(minutes => drugDoorActionButton({
                key: `bad-guest-drug-door-wait-${minutes}`,
                label: `${minutes}분 흐르기`,
                time: minutes,
                description: '방 안에서 지켜봅니다.',
                dispatch: { type: 'wait', minutes }
              }))
            })
          ]
        });
      };
      releases.push(api.hook('ActionPanel', {
        after(originalPanel) {
          const state = api.store.game();
          if (!React.isValidElement(originalPanel) || !state) return originalPanel;
          const drugDoorContext = drugDoorControlContext(state);
          if (drugDoorContext) {
            const controls = drugDoorControls(drugDoorContext);
            const replaced = replaceBadGuestChoiceGrid(originalPanel, controls);
            if (replaced.replaced) return replaced.element;
            return React.cloneElement(originalPanel, {}, [
              ...React.Children.toArray(originalPanel.props.children), controls
            ]);
          }
          const event = state?.pendingEvent;
          const game = state?.mods?.badguest?.drinkingGame;
          if (event?.type !== 'bad_guest_drinking_game_wait' || !(game?.wakeAtSlot > state.slot)) return originalPanel;
          const total = Math.max(1, game.wakeAtSlot - (game.lostAtSlot ?? state.slot));
          const elapsed = Math.max(0, Math.min(total, state.slot - (game.lostAtSlot ?? state.slot)));
          const remaining = Math.max(0, game.wakeAtSlot - state.slot);
          const progress = Math.max(0, Math.min(100, elapsed / total * 100));
          const buttonClass = 'flex-1 px-1 desk:px-2 py-1.5 text-[0.8rem] desk:text-sm bg-stone-900 hover:bg-stone-700 transition-colors border-r border-stone-700 last:border-r-0';
          const progressCard = JSX.jsxs('div', {
            className: 'w-full rounded-lg border-y desk:border bg-stone-800 border-stone-700 overflow-hidden mb-3',
            'data-wml-ui': 'badguest-drinking-game-progress',
            children: [
              JSX.jsxs('div', {
                className: 'px-2 desk:px-3 pt-2 pb-2',
                children: [
                  JSX.jsx('div', { className: 'font-medium text-[0.8rem] desk:text-sm', children: '뒷방 술게임' }),
                  JSX.jsx('div', { className: 'text-xs text-stone-400 mt-0.5 break-words', children: event.text }),
                  JSX.jsx('div', {
                    className: 'mt-2 h-2 bg-stone-700 rounded-full overflow-hidden',
                    children: JSX.jsx('div', {
                      className: 'h-full bg-amber-600 rounded-full transition-all duration-300',
                      style: { width: `${progress}%` }
                    })
                  }),
                  JSX.jsxs('div', {
                    className: 'mt-1 text-[0.65rem] desk:text-xs text-stone-500 text-right',
                    children: [elapsed, ' / ', total, '분 · ', remaining, '분 남음']
                  })
                ]
              })
            ]
          });
          const waitPanel = JSX.jsxs('div', {
            className: 'w-full rounded-lg border-y desk:border bg-stone-800 border-stone-700 overflow-hidden',
            'data-wml-ui': 'badguest-drinking-game-wait',
            children: [
              JSX.jsxs('div', {
                className: 'px-2 desk:px-3 pt-2 pb-1',
                children: [
                  JSX.jsxs('div', {
                    className: 'flex items-baseline justify-between gap-1.5 min-w-0',
                    children: [
                      JSX.jsxs('span', {
                        className: 'font-medium text-[0.8rem] desk:text-sm',
                        children: [hotkey('W'), '기다리기']
                      }),
                      JSX.jsx('span', {
                        className: 'text-[0.65rem] desk:text-xs text-stone-500 shrink-0',
                        children: '시간 보내기'
                      })
                    ]
                  }),
                  JSX.jsx('div', {
                    className: 'hidden desk:block text-xs text-stone-400 mt-0.5 break-words',
                    children: '그동안 뒷방에 머뭅니다.'
                  })
                ]
              }),
              JSX.jsx('div', {
                className: 'flex border-t border-stone-700',
                children: waitOptions.map(option => JSX.jsxs('button', {
                  onClick: () => api.store.dispatch({
                    type: 'resolve_event',
                    choiceId: `bad_guest_drinking_game_wait_${option.minutes}`
                  }),
                  title: `${option.minutes}분 기다리기 (${option.hotkey})`,
                  className: buttonClass,
                  children: [hotkey(option.hotkey), option.label]
                }, option.label))
              })
            ]
          });
          return JSX.jsxs(React.Fragment, {
            children: [
              JSX.jsx('div', {
                style: { display: 'none' },
                'aria-hidden': true,
                children: originalPanel
              }),
              JSX.jsxs('div', {
                'data-wml-ui': 'badguest-drinking-game',
                children: [progressCard, waitPanel]
              })
            ]
          });
        }
      }));
      releases.push(api.hook('recentPatronIntimacySummary', {
        around(next, history, ...rest) {
          const projected = Array.isArray(history)
            ? history.map(entry => {
                const definition = CONFUSION_RECEPTION_LABELS[entry?.reception]
                  || APHRODISIAC_RECEPTION_LABELS[entry?.reception];
                if (!definition) return entry;
                return {
                  ...entry,
                  reception: entry.badGuestAphrodisiacAssisted
                    ? 'reluctant'
                    : entry.badGuestPerceivedReception || definition.base
                };
              })
            : history;
          return next(projected, ...rest);
        }
      }));
      releases.push(api.hook('feelingSourceLabel', {
        around(next, source, ...rest) {
          return confusionFeelingLabel(source)
            ?? recoveredConfusionFeelingLabel(source, next, rest)
            ?? aphrodisiacFeelingLabel(source, next, rest)
            ?? next(source, ...rest);
        }
      }));
    }
    function hookSlot(target, property, binding) {
      const nextStack = [];
      let bypassDepth = 0;
      const original = (...args) => {
        const next = nextStack[nextStack.length - 1];
        if (next) return next(...args);
        bypassDepth += 1;
        try {
          return api.fn(binding)(...args);
        } finally {
          bypassDepth -= 1;
        }
      };
      let current = original;
      let release = null;
      Object.defineProperty(target, property, {
        configurable: true,
        enumerable: true,
        get: () => current,
        set: replacement => {
          release?.();
          release = null;
          current = replacement;
          if (replacement === original) return;
          release = api.hook(binding, { around(next, ...args) {
              if (bypassDepth > 0) return next(...args);
              nextStack.push(next);
              try {
                return replacement(...args);
              } finally {
                nextStack.pop();
              }
          } });
        }
      });
      releases.push(() => {
        release?.();
        release = null;
        current = original;
      });
    }

    hookSlot(bridge.engine, 'reduceGameAction', 'reduceGameAction');
    hookSlot(bridge.engine, 'acceptanceBreakdown', 'acceptanceBreakdown');
    hookSlot(bridge.engine, 'acceptanceCalculator', 'acceptanceCalculator');
    hookSlot(bridge.engine, 'evaluateIntimacy', 'evaluateIntimacy');
    hookSlot(bridge.engine, 'selectPatronTactic', 'selectPatronTactic');
    hookSlot(bridge.engine, 'forceAttemptChance', 'forceAttemptChance');
    hookSlot(bridge.engine, 'buildPatronMoveCandidates', 'buildPatronMoveCandidates');
    hookSlot(bridge.engine, 'processPatronGroupJoin', 'processPatronGroupJoin');
    hookSlot(bridge.engine, 'processPatronGroupParticipants', 'processPatronGroupParticipants');
    hookSlot(bridge.engine, 'rotatePatronGroupAfterPrimary', 'rotatePatronGroupAfterPrimary');
    hookSlot(bridge.engine, 'recordIntimateHistory', 'recordIntimateHistory');
    hookSlot(bridge.engine, 'recordPatronReach', 'recordPatronReach');
    if (typeof bridge.engine.patronJealousyAssessment === 'function') {
      hookSlot(bridge.engine, 'patronJealousyAssessment', 'patronJealousyAssessment');
    }
    hookSlot(bridge.character, 'addFeeling', 'addFeeling');
    hookSlot(bridge.character, 'addIdentityStrainFromPatronAct', 'addIdentityStrainFromPatronAct');
    hookSlot(bridge.engine, 'patronControlNaturalEnd', 'patronControlNaturalEnd');
    hookSlot(bridge.engine, 'patronControlBoundaryStop', 'patronControlBoundaryStop');
    hookSlot(bridge.engine, 'patronControlFatigueStop', 'patronControlFatigueStop');
    hookSlot(bridge.engine, 'patronControlClimax', 'patronControlClimax');
    hookSlot(bridge.engine, 'patronControlAfterglow', 'patronControlAfterglow');
    if (typeof bridge.engine.patronControlPlayerReturnStop === 'function') {
      hookSlot(bridge.engine, 'patronControlPlayerReturnStop', 'patronControlPlayerReturnStop');
    }
    if (typeof bridge.engine.patronControlRecallReach === 'function') {
      hookSlot(bridge.engine, 'patronControlRecallReach', 'patronControlRecallReach');
    }
    if (typeof bridge.engine.patronControlShouldCheckWithHusband === 'function') {
      hookSlot(bridge.engine, 'patronControlShouldCheckWithHusband', 'patronControlShouldCheckWithHusband');
    }
    if (typeof bridge.engine.patronControlPrivateOffer === 'function') {
      hookSlot(bridge.engine, 'patronControlPrivateOffer', 'patronControlPrivateOffer');
    }
    for (const binding of [
      'patronControlWifeClimax',
      'patronControlAftermathFeeling',
      'patronControlRecordFirsts',
      'patronControlCrossedLine',
      'patronControlSelfConceptDrift',
      'patronControlAftercareFeeling',
      'patronControlAftercareBond',
      'patronControlRecordVisitOutcome',
      'patronControlAdvanceNamedPatron',
      'patronControlOtherRelationshipReaction',
      'patronControlOpenReaction',
      'patronControlResolveReaction',
      'patronControlExpireReaction',
      'patronControlNightAccount',
      'patronControlUnpromptedCandidates',
      'patronControlApplyNightAccount',
      'patronControlEnjoymentOpinion',
      'patronControlInnerThought',
      'patronControlRecordMoment'
    ]) {
      if (typeof bridge.engine[binding] === 'function') hookSlot(bridge.engine, binding, binding);
    }
    hookSlot(bridge.engine, 'patronControlCoercionEscape', 'patronControlCoercionEscape');
    hookSlot(bridge.engine, 'patronControlAcquaintanceStop', 'patronControlAcquaintanceStop');
    hookSlot(bridge.engine, 'patronControlShameStop', 'patronControlShameStop');
    hookSlot(bridge.engine, 'patronControlServiceInterrupt', 'patronControlServiceInterrupt');
    hookSlot(bridge.engine, 'patronControlExposureRedress', 'patronControlExposureRedress');
    hookSlot(bridge.engine, 'patronControlLineUp', 'patronControlLineUp');
    hookSlot(bridge.engine, 'patronControlPushIn', 'patronControlPushIn');
    hookSlot(bridge.engine, 'patronControlRelentChance', 'patronControlRelentChance');
    hookSlot(bridge.engine, 'processPatronInteractionTick', 'processPatronInteractionTick');
    hookSlot(bridge.engine, 'startPatronInteraction', 'startPatronInteraction');
    hookSlot(bridge.engine, 'resolvePatronEscalation', 'resolvePatronEscalation');
    hookSlot(bridge.engine, 'resolvePatronForce', 'resolvePatronForce');
    hookSlot(bridge.engine, 'endPatronInteraction', 'endPatronInteraction');
    hookSlot(bridge.engine, 'passOutWife', 'passOutWife');
    hookSlot(bridge.engine, 'applyWifeRestBreak', 'applyWifeRestBreak');
    if (typeof bridge.engine.resolvePrivateSessionExit === 'function') {
      hookSlot(bridge.engine, 'resolvePrivateSessionExit', 'resolvePrivateSessionExit');
    }
    hookSlot(bridge.engine, 'applyPotionEffect', 'applyPotionEffect');
    hookSlot(bridge.movement, 'movePlayer', 'moveOccupant');
    hookSlot(bridge.movement, 'moveWife', 'moveWife');
    hookSlot(bridge, 'minuteTick', 'minuteTick');
    hookSlot(bridge, 'decreaseWifeIntoxication', 'decreaseWifeIntoxication');

    const previousBridge = globalThis.__WAYWARD_ADDON_API__;
    globalThis.__WAYWARD_ADDON_API__ = bridge;
    try {
      await api.loadScript('files/core.js');
    } finally {
      if (globalThis.__WAYWARD_ADDON_API__ === bridge) {
        if (previousBridge === undefined) delete globalThis.__WAYWARD_ADDON_API__;
        else globalThis.__WAYWARD_ADDON_API__ = previousBridge;
      }
    }

    const controller = () => globalThis.__WAYWARD_MODS__?.BadGuest;
    if (!controller()) {
      releases.forEach(release => release());
      throw new Error('나쁜 손님 핵심 모듈을 불러오지 못했습니다.');
    }

    const publicController = controller();
    const imageEquipmentPrompts = Object.freeze({
      blindfold: Object.freeze({
        id: 'blindfold', label: '안대',
        positivePrompt: '(blindfold:1.35), cloth covering eyes, blindfold tied behind head',
        negativePrompt: 'visible eyes, uncovered eyes, eye contact, looking at viewer'
      }),
      gag: Object.freeze({
        id: 'gag', label: '입마개',
        positivePrompt: '(gag:1.3), mouth covered by gag, gag strap tied behind head',
        negativePrompt: 'ungagged, uncovered mouth, tongue out, speaking'
      })
    });
    let imagePromptService = null;
    function connectImagePrompt(candidate) {
      if (imagePromptService || candidate?.version !== 1 || typeof candidate.register !== 'function'
        || typeof candidate.resolve !== 'function' || typeof candidate.cacheToken !== 'function') return;
      try {
        const unregister = candidate.register({
          id: 'badguest',
          title: '나쁜 손님 · 착용 도구',
          note: '안대와 입마개를 실제로 착용 중인 장면의 이미지에 적용합니다.',
          entries: Object.values(imageEquipmentPrompts).map(entry => ({
            ...entry, hook: 'imagePrompt / imageKey'
          }))
        });
        if (typeof unregister === 'function') releases.push(unregister);
        imagePromptService = candidate;
      } catch (error) {
        api.warn?.(`BadGuest image prompt registration failed: ${error?.message || error}`);
      }
    }
    connectImagePrompt(globalThis.AttentionImagePrompt);
    if (typeof globalThis.addEventListener === 'function') {
      const onImagePromptReady = event => connectImagePrompt(event.detail);
      globalThis.addEventListener('attention-image-prompt:ready', onImagePromptReady);
      releases.push(() => globalThis.removeEventListener?.('attention-image-prompt:ready', onImagePromptReady));
    }
    function selectedImageEquipment(character) {
      const state = api.store.game();
      if (!state || !character?.id) return null;
      const current = api.fn('wife')(state);
      if (!current || String(character.id) !== String(current.id)
        || character.sceneOverride !== current.sceneOverride
        || character.sceneSetAtSlot !== current.sceneSetAtSlot) return null;
      const worn = publicController.imageEquipment(state, character.id);
      const selected = Object.values(imageEquipmentPrompts)
        .filter(entry => worn[entry.id])
        .map(entry => {
          const resolved = imagePromptService?.resolve('badguest', entry.id);
          return {
            ...entry,
            positivePrompt: resolved?.positivePrompt ?? entry.positivePrompt,
            negativePrompt: resolved?.negativePrompt ?? entry.negativePrompt,
            token: imagePromptService?.cacheToken('badguest', entry.id) || 'default'
          };
        });
      return selected.length ? selected : null;
    }
    function keyWithImageEquipment(key, selected) {
      if (typeof key !== 'string' || !selected?.length || key.includes('__badguest-equipment-')) return key;
      const suffix = selected.map(entry => `${entry.id}-${String(entry.token).replace(/[^a-zA-Z0-9_-]/g, '')}`).join('-');
      return key.replace(/(__v-\d+)?$/, `__badguest-equipment-${suffix}$1`);
    }
    releases.push(api.hook('imageKey', {
      priority: -1900000,
      after(result, [character]) {
        return keyWithImageEquipment(result, selectedImageEquipment(character));
      }
    }));
    releases.push(api.hook('imagePrompt', {
      priority: -1900000,
      after(result, [character]) {
        if (!result || !Array.isArray(result.parts)) return result;
        const selected = selectedImageEquipment(character);
        if (!selected) return result;
        const prompt = [result.prompt, ...selected.map(entry => entry.positivePrompt)].filter(Boolean).join(', ');
        return {
          ...result,
          key: keyWithImageEquipment(result.key, selected),
          prompt,
          negativePrompt: [result.negativePrompt, ...selected.map(entry => entry.negativePrompt)].filter(Boolean).join(', '),
          parts: [...result.parts, ...selected.map(entry => ({ label: entry.label, tags: entry.positivePrompt }))],
          genParams: api.fn('promptGenParams')(prompt)
        };
      }
    }));
    // The official join-in mod replaces the patron scene without ending it. Keep BadGuest
    // equipment and drug incidents on their original scene until that scene is resolved.
    releases.push(api.hook('patronWatchChoices', {
      priority: -100,
      after(choices) {
        const state = api.store.game();
        if (!Array.isArray(choices) || !state || !publicController.joinInBlocked(state)) return choices;
        return choices.filter(choice => choice?.id !== 'join-in');
      }
    }));
    releases.push(api.hook('patronChoice', {
      priority: 100,
      before([state, choiceId]) {
        if (choiceId === 'join-in' && publicController.joinInBlocked(state)) {
          return { cancel: true, value: state };
        }
      }
    }));
    wmlApi.provide(Object.freeze({
      apiVersion: publicController.apiVersion,
      version: publicController.version,
      hooks: publicController.hooks,
      getSettings: () => publicController.getSettings(),
      updateSettings: next => publicController.updateSettings(next),
      resetSettings: () => publicController.resetSettings(),
      getProbabilitySnapshot: preview => publicController.getProbabilitySnapshot(preview),
      getState: () => publicController.getState(),
      isBadGuest: (state, customerOrId) => publicController.isBadGuest(state, customerOrId),
      actions: publicController.actions,
      debug: publicController.debug,
      resolveCompatibilityEnd: (state, request) => publicController.resolveCompatibilityEnd(state, request)
    }));

    const CHECKS = {
      wifeDrugNotice: '대상 인물의 미약 간파',
      wifeDrugRefusal: '간파 후 압박 거절',
      husbandNotice: '주인의 기만 간파',
      wifeBackRoomNotice: '대상 인물의 사적 장소 유도 간파',
      wifeBackRoomRefusal: '간파 후 뒷방 압박 거절',
      handcuffGuestSuccess: '손님의 수갑 성공',
      handcuffEscapeSuccess: '대상 인물의 수갑 탈출 성공',
      groupDrugNotice: '단체 미약 간파 저항',
      groupPressureResistance: '단체 미약 압박 저항',
      groupStrengthResistance: '단체 미약 힘 저항',
      groupHandcuffGuestSuccess: '단체 수갑 성공',
      doorBreakAt50: '문 부수기 성공'
    };
    const WEIGHTS = [
      ['drug', '미약', '술에 약을 섞으려는 행동입니다.'],
      ['sleepDrug', '수면약', '실제 수면 물약 한 단위를 먹인 뒤 위층 이동을 기다리게 합니다.'],
      ['intoxicationDrug', '만취약', '취기를 90으로 만들고 설정된 시간 동안 하한을 유지합니다.'],
      ['confusionDrug', '착란약', '수용 판정의 오인 기준 인물을 60분 동안 고정합니다.'],
      ['aggressiveDeception', '공격적 기만', '꾸며 낸 손해를 내세워 돈이나 수상한 술을 요구합니다.'],
      ['blindfold', '안대', '손님 행동 한 번으로 눈을 가리려 시도합니다.'],
      ['gag', '입마개', '안대 시도 뒤 입을 막으려 시도합니다.'],
      ['backRoomPretext', '사적 장소 유도', '핑계를 대며 이용 가능한 사적 장소로 데려가려는 행동입니다.'],
      ['doorLock', '문 잠그기', '주인이 없는 방의 문을 안에서 잠급니다.']
    ];
    const pct = value => value == null || !Number.isFinite(value)
      ? '—'
      : `${(value * 100).toFixed(value * 100 % 1 ? 1 : 0)}%`;
    const cumulative = (percent, minutes) => 1 - (1 - Math.max(0, Math.min(1, percent / 100))) ** minutes;
    const valueAt = (source, path) => path.split('.').reduce((value, key) => value?.[key], source);
    const patchAt = (path, value) => {
      const parts = path.split('.');
      const patch = {};
      let cursor = patch;
      while (parts.length > 1) {
        const key = parts.shift();
        cursor[key] = {};
        cursor = cursor[key];
      }
      cursor[parts[0]] = value;
      return patch;
    };

    api.ui.settings((body, win) => {
      const mod = controller();
      if (!mod) {
        body.append(api.ui.h('div', { class: 'wml-note' }, '핵심 모듈을 불러오지 못했습니다.'));
        return;
      }
      if (!win.el.dataset.badGuestSettingsSized) {
        const width = Math.min(920, window.innerWidth - 16);
        const height = Math.min(840, window.innerHeight - 16);
        win.el.style.width = `${width}px`;
        win.el.style.height = `${height}px`;
        win.el.style.left = `${Math.max(8, (window.innerWidth - width) / 2)}px`;
        win.el.style.top = `${Math.max(8, (window.innerHeight - height) / 2)}px`;
        win.el.dataset.badGuestSettingsSized = 'true';
      }
      body.style.fontSize = '14px';
      body.style.color = '#e7e5e4';
      const settings = mod.getSettings();
      const snapshot = mod.getProbabilitySnapshot();
      const section = (title, ...children) => api.ui.h(
        'section',
        { class: 'wml-section', style: 'margin:0 0 12px' },
        api.ui.h('div', { style: 'font-weight:700;margin-bottom:7px' }, title),
        ...children
      );
      const numberRow = (path, label, min, max, step = 1, note = '', title = '') => {
        const fieldId = `badguest-native-setting-${path.replace(/[^a-zA-Z0-9_-]/g, '-')}`;
        const input = api.ui.h('input', {
          id: fieldId, name: path, type: 'number', min, max, step, value: valueAt(settings, path),
          style: 'width:120px;padding:6px 8px;border:1px solid #78716c;border-radius:6px;background:#292524;color:#fafaf9;color-scheme:dark;font:inherit;line-height:1.3'
        });
        input.onchange = () => {
          mod.updateSettings(patchAt(path, Number(input.value)));
          win.refresh();
        };
        return api.ui.h(
          'label',
          { htmlFor: fieldId, title, style: 'display:grid;grid-template-columns:minmax(230px,1fr) 120px minmax(180px,auto);gap:12px;align-items:center;margin:7px 0' },
          api.ui.h('span', {}, label), input,
          api.ui.h('span', { class: 'wml-small wml-muted', style: 'text-align:right' }, note)
        );
      };
      const checkboxRow = (path, label, title = '') => {
        const fieldId = `badguest-native-setting-${path.replace(/[^a-zA-Z0-9_-]/g, '-')}`;
        const input = api.ui.h('input', { id: fieldId, name: path, type: 'checkbox', checked: valueAt(settings, path) === true });
        input.onchange = () => {
          mod.updateSettings(patchAt(path, input.checked));
          win.refresh();
        };
        return api.ui.h('label', { htmlFor: fieldId, title, style: 'display:flex;gap:8px;align-items:center;margin:6px 0' }, input, label);
      };

      const activeSpecialActionWeights = snapshot?.effectiveSpecialActionWeights || settings.specialActionWeights;
      const weightTotal = Object.values(activeSpecialActionWeights).reduce((sum, value) => sum + Math.max(0, value), 0);
      const weightRows = Object.fromEntries(WEIGHTS.map(([key, label, title]) => {
        const allChance = weightTotal > 0
          ? settings.activeActionChance / 100 * activeSpecialActionWeights[key] / weightTotal
          : 0;
        const current = snapshot?.specialActions?.find(action => action.kind === ({
          drug: 'drug', sleepDrug: 'sleep_drug', intoxicationDrug: 'intoxication_drug',
          confusionDrug: 'confusion_drug', aggressiveDeception: 'aggressive_deception',
          blindfold: 'blindfold', gag: 'gag', backRoomPretext: 'back_room_pretext', doorLock: 'door_lock'
        })[key]);
        return [key, numberRow(
          `specialActionWeights.${key}`,
          `${label} 가중치`, 0, 100, 0.1,
          key === 'sleepDrug' && snapshot?.sleepActionsAvailable === false
            ? '비활성 · sleep-actions 필요'
            : `전체 ${pct(allChance)} · ${current ? `현재 ${pct(current.perMinuteChance)}` : '현재 후보 아님'}`,
          title
        )];
      }));
      const checkRows = (...keys) => keys.flatMap(key => [
        numberRow(
          `checkBaseChances.${key}`, `${CHECKS[key]} 기본 확률`, 0, 100, 0.1,
          `현재 ${pct(snapshot?.checks?.[key])}`,
          '양쪽 계산 점수가 같을 때의 확률입니다. 실제 확률은 유효 능력치와 성향·상태 보정을 반영합니다.'
        ),
        numberRow(
          `checkPointIncrements.${key}`, `${CHECKS[key]} 점수 차이 1당 증분`, 0, 5, 0.05,
          '%p / 점수',
          '공격·방어 계산 점수 차이 1점마다 기본 확률에 더하거나 빼는 퍼센트포인트입니다.'
        )
      ]);
      const activePatternWeights = snapshot?.effectivePatternWeights || settings.patternWeights;
      const patternWeightTotal = Object.values(activePatternWeights)
        .reduce((sum, value) => sum + Math.max(0, value), 0);
      const patternShare = key => patternWeightTotal > 0
        ? `${(activePatternWeights[key] / patternWeightTotal * 100).toFixed(1)}%`
        : '—';

      body.append(
        api.ui.h('div', { class: 'wml-small wml-muted', style: 'margin-bottom:10px' }, '모든 저장 파일에 공통으로 적용됩니다.'),
        section('미약',
          numberRow('drugMaxAcceptanceBonus', '최대 수용도 보정', 0, 500, 10),
          numberRow('drugRampMinutes', '열기가 차오르는 시간', 1, 240, 1, '분'),
          numberRow('drugPlateauMinutes', '최대 유지 시간', 0, 480, 1, '분'),
          numberRow('drugFallMinutes', '열기가 가라앉는 시간', 1, 240, 1, '분'),
          numberRow('ambientDrugChancePerMinute', '응대 밖 미약 확률/분', 0, 100, 0.1, `30분 ${pct(cumulative(settings.ambientDrugChancePerMinute, 30))}`),
          numberRow('drugActionCooldownMinutes', '같은 손님의 미약 개별 쿨다운', 0, 240, 1, '분', '손님별로 마지막 미약 시도부터 계산합니다.'),
          ...checkRows('wifeDrugNotice', 'wifeDrugRefusal', 'husbandNotice')
        ),
        section('수면약',
          numberRow('sleepPotionDepartureDelayMin', '이동 대기 최소', 0, 240, 1, '분'),
          numberRow('sleepPotionDepartureDelayMax', '이동 대기 최대', 0, 240, 1, '분'),
          numberRow('sleepPotionGuestRoomChance', '가로채기 없을 때 열린 객실 확률', 0, 100, 0.1, '%')
        ),
        section('등장 확률',
          numberRow('spawnChance', '새 손님의 나쁜 손님 확률', 0, 100, 0.1, '%'),
          numberRow('wealthyPartyDailyChance', '부유한 단체손님 일일 확률', 0, 100, 0.1, '%'),
          numberRow('drinkingGameVisitChance', '나쁜 손님의 방문별 술게임 제안 확률', 0, 100, 0.1, '%')
        ),
        section('행동 유형',
          numberRow('patternWeights.enforcer', '제압형 분포 가중치', 0, 100, 1, `실효 ${patternShare('enforcer')}`),
          numberRow('patternWeights.lurer', '유인형 분포 가중치', 0, 100, 1, `실효 ${patternShare('lurer')}`),
          numberRow('patternWeights.infiltrator', '잠입형 분포 가중치', 0, 100, 1, `실효 ${patternShare('infiltrator')}`),
          numberRow('patternWeights.impostor', '가장형 분포 가중치', 0, 100, 1, `실효 ${patternShare('impostor')}`),
          numberRow('nonEnforcerHandcuffMultiplierPercent', '제압형 외 수갑 시도율', 0, 100, 1, '공통 설정 대비 %'),
          numberRow('intoxicationDurationMinutes', '만취약 유지 시간', 1, 480, 1, '분'),
          numberRow('lurerFinishDelayMinutes', '유인형 후속 권유 대기', 0, 240, 1, '분'),
          numberRow('lurerFinishWeight', '유인형 후속 권유 가중치', 0, 100, 0.1),
          numberRow('lurerFinishMinRefusal', '유인형 후속 최소 거절률', 0, 100, 0.1, '%'),
          numberRow('lurerFinishMaxRefusal', '유인형 후속 최대 거절률', 0, 100, 0.1, '%')
        ),
        section('나쁜 손님 협력',
          checkboxRow('cooperativeIncidentMovementEnabled', '사고 현장으로 다른 나쁜 손님이 이동', 'BadGuest 약효·수면·구속구 사고를 같은 방에서 목격한 나쁜 손님이 있으면 다른 방의 나쁜 손님도 그 장소로 이동합니다.'),
          checkboxRow('sharedIncidentTrackingEnabled', '수면 행동의 목격 정보를 나쁜 손님끼리 공유', '기반 수면 행동의 원격 탐색 확률 대신 BadGuest 사고 현장을 확정해서 찾습니다. 기반의 침실·쿨다운·점유 제한은 유지됩니다.')
        ),
        section('사적 장소 유도',
          numberRow('ambientBackRoomChancePerMinute', '응대 밖 장소 유도/분', 0, 100, 0.1, `30분 ${pct(cumulative(settings.ambientBackRoomChancePerMinute, 30))}`),
          numberRow('backRoomActionCooldownMinutes', '같은 손님의 장소 유도 개별 쿨다운', 0, 240, 1, '분', '손님별로 마지막 장소 유도 시도부터 계산합니다. 같은 응대 중에는 한 번만 시도합니다.'),
          ...checkRows('wifeBackRoomNotice', 'wifeBackRoomRefusal')
        ),
        section('문 잠그기·탈출',
          numberRow('selfLockMaxChancePerMinute', '대상 인물의 자발적 잠금 최대/분', 0, 100, 0.1, `${settings.selfLockMaxChancePerMinute}%`),
          ...checkRows('doorBreakAt50')
        ),
        section('특수행동 공통',
          numberRow('activeActionChance', '대화 중 특수행동 판정/분', 0, 100, 0.1, `${settings.activeActionChance}%`),
          ...WEIGHTS.map(([key]) => weightRows[key]),
          numberRow('actionCooldownMinutes', '다른 특수행동 재시도 간격', 0, 60, 1, '분', '특수행동이 성공한 뒤 다른 종류의 특수행동을 다시 시도하기까지의 공통 간격입니다.')
        ),
        section('수갑',
          numberRow('refusalHandcuffChance', '거절 직후 수갑 확률', 0, 100, 0.1, '%'),
          numberRow('rehandcuffChancePerMinute', '수갑 재진입 확률/분', 0, 100, 0.01, `5분 ${pct(cumulative(settings.rehandcuffChancePerMinute, 5))}`),
          checkboxRow('sleepWakeRefusalHandcuffsEnabled', '잠에서 깬 뒤 거절에도 수갑 시도', 'BadGuest가 관여한 수면 장면에서 깨어난 뒤 실제 행위를 거절하면 위의 공통 수갑 확률과 힘겨루기를 사용합니다.'),
          checkboxRow('confusionExpiryRefusalHandcuffsEnabled', '착란이 끝난 뒤 현실 거절에도 수갑 시도', '착란 중에는 수용했지만 실제 손님이라면 거절했을 행위가 효과 만료 뒤 이어질 때 위의 공통 수갑 확률과 힘겨루기를 사용합니다.'),
          ...checkRows('handcuffGuestSuccess', 'handcuffEscapeSuccess')
        ),
        section('부유한 단체손님',
          ...checkRows('groupDrugNotice', 'groupPressureResistance', 'groupStrengthResistance', 'groupHandcuffGuestSuccess'),
          api.ui.h('div', { class: 'wml-small wml-muted', style: 'margin-top:7px' }, '단체 미약 저항 3종은 상한 90%, 단체 수갑은 상한 95%입니다.')
        ),
        section('화면 표시',
          checkboxRow('showBadGuestMarkers', '주점 안의 나쁜 손님 이름 뒤에 빨간 점 표시'),
          checkboxRow('debugProbabilityPanel', '게임 화면에 접을 수 있는 확률 계산창 표시')
        ),
        api.ui.button('기본값 복원', () => {
          mod.resetSettings();
          win.refresh();
        })
      );
    });
  }
});
