WML.define({
  id: 'festival',
  author: "Hina_Lover",
  name: 'Festival · 마을 축제',
  version: "1.2.4",
  lang: 'ko',
  game: "2026-11-01",
  description: '촌장의 축제 초대와 직접 방문 제안, 이틀간의 준비 일손, 방문 증가와 남편의 출장 판매소를 추가합니다.',
  loadAfter: ['wife-view-mode', 'delivery', 'pregnancy'],
  symbols: {
    "FestivalVillageActions": {"raw":{"2026-11-01":"wB"},"doc":"마을 둘러보기 행동 패널"},
    "FestivalTavernDay": {"raw":{"2026-11-01":"pt"},"doc":"자정 이후에도 유지되는 주점 영업일"},
    "FestivalBaseArrivalChance": {"raw":{"2026-11-01":"RE"},"doc":"시간별 기본 손님 방문 확률"},
    "FestivalServiceArrivalFactor": {"raw":{"2026-11-01":"vTe"},"doc":"서비스 평판의 방문 확률 계수"},
    "FestivalRenownArrivalFactor": {"raw":{"2026-11-01":"xTe"},"doc":"명성의 방문 확률 계수"},
    "FestivalOutreachMultiplier": {"raw":{"2026-11-01":"fNe"},"doc":"현재 영업 효과의 방문 확률 배수"},
    "FestivalWeatherMultiplier": {"raw":{"2026-11-01":"Ive"},"doc":"날씨와 계절 방문 확률 배수"},
    "FestivalPreferredVisitChance": {"raw":{"2026-11-01":"kTe"},"doc":"단골 손님 방문의 시간 확률"},
    "FestivalEndDay": {"raw":{"2026-11-01":"xm"},"doc":"주점 영업을 마감하고 다음 날로 이동"},
    "FestivalAwayLog": {"raw":{"2026-11-01":"XC"},"doc":"이번 외출 중 아직 표시하지 않은 주점 기록을 이야기 창에 반영"}
  },
  async setup(wmlApi) {
    await wmlApi.loadScript('native-ui.js');
    const api = globalThis.__waywardPauseSettingsUiFactory.connect(wmlApi, { id: 'festival', label: 'Festival 모드 설정' });
    await api.loadScript('festival-compatible-wife-view-mode.js');
    const React = api.fn('React'), JSX = api.fn('jsx');
    const DEFAULTS = { tavernMultiplier: 2, stallMultiplier: 3, intervalMode: 'random', intervalDays: 30 };
    const ITEMS = { food: '식재료', readyFood: '조리된 음식', beer: '맥주', wine: '와인' };
    const HOME = new Set(['taproom', 'kitchen', 'bedroom', 'back_room', 'upstairs_hall', 'elena_room', 'upstairs_room_2', 'bathroom', 'bathhouse']);
    let writing = false, visitContext = null;
    let stockWindow = null, statusWindow = null;

    function Festival_숫자제한하기(value, minimum, maximum, fallback) {
      const number = Number(value);
      return Number.isFinite(number) ? Math.max(minimum, Math.min(maximum, number)) : fallback;
    }
    function Festival_설정읽기() {
      const saved = api.settings.get(DEFAULTS);
      return { tavernMultiplier: Festival_숫자제한하기(saved.tavernMultiplier, 1, 5, 2),
        stallMultiplier: Festival_숫자제한하기(saved.stallMultiplier, 1, 10, 3),
        intervalMode: saved.intervalMode === 'fixed' ? 'fixed' : 'random',
        intervalDays: Math.round(Festival_숫자제한하기(saved.intervalDays, 10, 90, 30)) };
    }
    function Festival_무작위정수만들기(minimum, maximum) {
      return minimum + Math.floor(Math.random() * (maximum - minimum + 1));
    }
    function Festival_영업일읽기(state, slot = state.slot) {
      return Math.max(1, api.fn('FestivalTavernDay')(slot));
    }
    function Festival_자료읽기(state) { return state?.mods?.festival || null; }
    function Festival_자료쓰기(state, data) {
      return { ...state, mods: { ...state.mods, festival: data } };
    }
    function Festival_기록하기(state, text) {
      return { ...state, log: [...(state.log || []), { slot: state.slot, text: `[축제] ${text}`,
        eventCategory: 'festival', important: true }] };
    }
    function Festival_재고읽기(state) {
      return { food: Math.max(0, Math.floor(state.supplies?.food || 0)),
        readyFood: Math.max(0, Math.floor(state.readyFood || 0)),
        beer: Math.max(0, Math.floor(state.supplies?.beer || 0)),
        wine: Math.max(0, Math.floor(state.supplies?.wine || 0)) };
    }
    function Festival_재고표현하기(stock) {
      return Object.entries(ITEMS).map(([key, label]) => `${label} ${stock[key] || 0}`).join(' · ');
    }
    function Festival_주기만들기(festivalDay) {
      return { id: `festival:${festivalDay}`, festivalDay, participation: 'pending', invitationQueued: false,
        requests: [festivalDay - 2, festivalDay - 1].map(day => ({ day,
          dueSlot: (day - 1) * 1440 + Festival_무작위정수만들기(17 * 60, 23 * 60),
          queued: false, completed: false, who: null })), stallRevenue: 0, stallVisitors: 0 };
    }
    function Festival_자료초기화하기(state) {
      if (!state || Festival_자료읽기(state)) return state;
      // 촌장 방문은 축제 이틀 전. 최초 방문 자체를 5~20일차로 정합니다.
      const first = Festival_영업일읽기(state) - 1 + Festival_무작위정수만들기(5, 20) + 2;
      return Festival_자료쓰기(state, { version: 1, current: Festival_주기만들기(first),
        labor: null, stall: null, history: [], totalStallRevenue: 0, totalStallVisitors: 0 });
    }
    function Festival_축제진행확인하기(state) {
      const round = Festival_자료읽기(state)?.current, day = Festival_영업일읽기(state);
      return !!round && day >= round.festivalDay && day <= round.festivalDay + 1;
    }
    function Festival_참여혜택확인하기(state) {
      return Festival_축제진행확인하기(state) && Festival_자료읽기(state)?.current.participation === 'accepted';
    }
    function Festival_준비요청읽기(state) {
      const round = Festival_자료읽기(state)?.current;
      if (round?.participation !== 'accepted') return null;
      return round.requests.find(request => !request.completed && state.slot >= request.dueSlot) || null;
    }
    function Festival_장소이동하기(state, actor, destination) {
      const locations = Object.fromEntries(Object.entries(state.locations).map(([id, room]) => [id,
        { ...room, occupants: (room.occupants || []).filter(occupant => occupant !== actor) }]));
      locations[destination] = { ...locations[destination], occupants: [...locations[destination].occupants, actor] };
      return { ...state, locations };
    }
    function Festival_장면진행확인하기(state) {
      return !!(state.activeScene?.sex || state.activeScene?.patron || state.activeScene?.situation || state.activeScene?.table
        || state.deliveryAddon?.activeDelivery || state.activeShoppingSession || state.errandSession);
    }
    function Festival_담당자불가이유읽기(state, who) {
      const data = Festival_자료읽기(state), wife = api.fn('wife')(state);
      if (data?.labor || data?.stall) return '진행 중인 축제 일을 먼저 마무리하세요.';
      if (who === 'player') {
        if (state.errandSession || state.activeShoppingSession || !HOME.has(api.fn('playerLocation')(state))) return "당신이 외출 중입니다.";
        if (state.activeScene?.sex || state.activeScene?.patron?.playerEngaged || state.deliveryAddon?.activeDelivery?.who === 'player') return "당신이 진행 중인 일을 먼저 마무리해야 합니다.";
        return '';
      }
      if (!wife || ['passed_out', 'sleeping'].includes(wife.currentTask)) return "그녀가 일손을 도울 수 없는 상태입니다.";
      if (!HOME.has(api.fn('wifeLocation')(state)) || Festival_장면진행확인하기(state) || wife.outing?.untilSlot > state.slot) return "그녀가 진행 중인 일을 먼저 마무리해야 합니다.";
      return '';
    }
    const invitationKind = api.events.onAlert('invitation', (state, choice) => {
      const original = Festival_자료읽기(state);
      if (!original || original.current.participation !== 'pending') return state;
      if (!['accept', 'decline'].includes(choice)) return Festival_초대넣기(state);
      const data = structuredClone(original);
      data.current.participation = choice === 'accept' ? 'accepted' : 'declined';
      let next = Festival_자료쓰기(state, data);
      if (choice === 'decline') {
        const reputation = state.tavernReputation;
        next = { ...next, tavernReputation: { ...reputation,
          renown: Math.max(0, (reputation.renown ?? 50) - 5), service: Math.max(0, (reputation.service ?? 50) - 5) } };
        return Festival_기록하기(next, '촌장의 축제 참여 요청을 거절했습니다. 명성 -5 · 서비스 평판 -5. 이번 축제의 참여 혜택과 준비 일손 의무는 적용하지 않습니다.');
      }
      return Festival_진행정리하기(Festival_기록하기(next, '촌장의 축제 참여 요청을 수락했습니다. 준비 이틀 동안 하루 한 명이 1시간씩 마을 일을 돕습니다.'));
    });
    const helpKind = api.events.onAlert('help', (state, choice) => Festival_일손시작하기(state, choice));
    const proposalKind = api.events.onAlert('proposal', (state, choice) => {
      const original = Festival_자료읽기(state), proposal = original?.proposal;
      if (!proposal) return state;
      if (!['accept', 'withdraw'].includes(choice)) return Festival_제안넣기(state);
      const data = structuredClone(original);
      delete data.proposal;
      if (choice === 'withdraw') return Festival_기록하기(Festival_자료쓰기(state, data), '축제 제안을 취소했습니다. 기존 일정과 평판을 유지합니다.');
      if (original.current.id !== proposal.previousRoundId || original.current.participation === 'accepted' || original.labor || original.stall)
        return Festival_기록하기(Festival_자료쓰기(state, data), '축제 일정이 이미 진행 중이어서 새 제안을 적용할 수 없습니다.');
      const festivalDay = Math.max(proposal.festivalDay, Festival_영업일읽기(state) + 3);
      data.current = { ...Festival_주기만들기(festivalDay), participation: 'accepted', invitationQueued: true, proposedByPlayer: true };
      return Festival_진행정리하기(Festival_기록하기(Festival_자료쓰기(state, data),
        `촌장이 축제 제안을 수락했습니다. ${festivalDay - 2}~${festivalDay - 1}일차에 준비하고 ${festivalDay}~${festivalDay + 1}일차에 축제를 엽니다. 준비 이틀 동안 하루 한 명이 60분씩 돕습니다.`));
    });

    function Festival_촌장방문불가이유읽기(state) {
      if (!state || state.gameOver) return '게임을 진행 중일 때 방문할 수 있습니다.';
      const data = Festival_자료읽기(state);
      if (!data) return '축제 일정을 정한 뒤 방문할 수 있습니다.';
      if (data.current.participation === 'accepted' || Festival_축제진행확인하기(state)) return '진행 중인 축제를 마친 뒤 새 축제를 제안하세요.';
      if (state.pendingEvent || data.proposal || data.labor || data.stall || Festival_장면진행확인하기(state)) return '진행 중인 사건이나 일을 먼저 마무리하세요.';
      if (!HOME.has(api.fn('playerLocation')(state))) return "당신이 주점에 돌아온 뒤 방문할 수 있습니다.";
      return '';
    }
    function Festival_제안넣기(state) {
      const proposal = Festival_자료읽기(state).proposal, day = proposal.festivalDay;
      return api.events.alert(state, { kind: proposalKind, title: '촌장 방문 · 축제 제안',
        body: `촌장을 찾아가 마을 축제를 제안합니다.\n${day - 2}~${day - 1}일차에 준비하고 ${day}~${day + 1}일차에 축제를 엽니다.\n제안을 확정하면 기존 예정일을 이 일정으로 바꾸고 축제 참여를 수락합니다. 준비 이틀 동안 당신 또는 그녀 한 명이 하루 60분씩 도와야 합니다. 취소하면 기존 일정과 평판을 유지합니다.`,
        // cancel은 게임이 모드 알림 처리 전에 가로채므로 별도 선택 이름을 씁니다.
        choices: [{ id: 'accept', label: '축제를 제안하고 준비를 맡는다' }, { id: 'withdraw', label: '이번에는 제안하지 않는다' }] });
    }
    function Festival_촌장방문시작하기(state) {
      const blocked = Festival_촌장방문불가이유읽기(state);
      if (blocked) return state ? Festival_기록하기(state, blocked) : state;
      const original = Festival_자료읽기(state);
      return Festival_제안넣기(Festival_자료쓰기(state, { ...original,
        proposal: { previousRoundId: original.current.id, festivalDay: Festival_영업일읽기(state) + 3 } }));
    }
    function Festival_촌장방문하기() {
      const blocked = Festival_촌장방문불가이유읽기(api.store.game());
      if (blocked) return false;
      api.store.dispatch({ type: 'festival/visit-mayor' });
      statusWindow?.close(); stockWindow?.close();
      // 게임의 계속하기 버튼을 사용하므로 pauseSettings 제공 여부에 의존하지 않습니다.
      document.querySelector('#root h2 + [class~="flex-col"][class~="gap-2"] > button:first-child.bg-amber-700')?.click();
      return !!Festival_자료읽기(api.store.game())?.proposal;
    }

    function Festival_초대넣기(state) {
      const round = Festival_자료읽기(state).current;
      return api.events.alert(state, { kind: invitationKind, title: '촌장의 방문 · 축제 참여 요청',
        body: `촌장이 마을에서 주점으로 찾아왔습니다.\n“${round.festivalDay}~${round.festivalDay + 1}일차에 축제를 열 예정입니다. ${round.festivalDay - 2}~${round.festivalDay - 1}일차에는 댁에서도 하루 한 명씩, 한 시간만 준비를 도와주시겠습니까?”\n참여하면 술집 방문 증가와 출장 판매소를 이용합니다. 거절하면 명성·서비스 평판이 각각 5 감소합니다.`,
        choices: [{ id: 'accept', label: '축제에 동참한다' }, { id: 'decline', label: '거절한다', description: '명성 -5 · 서비스 평판 -5' }] });
    }
    function Festival_일손요청넣기(state) {
      const wife = api.fn('wife')(state), choices = ['player', 'wife'].map(who => ({ id: who,
        label: who === 'player' ? "당신이 준비를 돕는다" : `${wife.name}이(가) 준비를 돕는다`,
        description: Festival_담당자불가이유읽기(state, who) || '마을에서 60분간 일합니다. 둘 중 한 명은 반드시 가야 합니다.' }));
      return api.events.alert(state, { kind: helpKind, title: '축제 준비 · 오늘의 일손 요청',
        body: "마을에서 오늘의 축제 준비 일손을 요청했습니다. 당신 또는 그녀 중 한 명이 반드시 1시간 동안 도와야 합니다. 누구를 보내겠습니까?", choices });
    }
    function Festival_일손시작하기(state, who) {
      let next = state;
      const request = Festival_준비요청읽기(next), original = Festival_자료읽기(next);
      if (!request || original.labor) return next;
      const blocked = !['player', 'wife'].includes(who) ? '준비를 도울 사람을 선택하세요.' : Festival_담당자불가이유읽기(next, who);
      if (blocked) return Festival_일손요청넣기(Festival_기록하기(next, blocked));
      const data = structuredClone(original), characterId = state.primaryCharacterId;
      data.labor = { who, characterId, requestDay: request.day, startSlot: state.slot, endSlot: state.slot + 60,
        awayEventStart: (state.awayEvents || []).length,
        originalLocation: who === 'player' ? api.fn('playerLocation')(state) : api.fn('wifeLocation')(state) };
      next = Festival_자료쓰기(next, data);
      next = Festival_장소이동하기(next, who === 'player' ? 'player' : characterId, 'village');
      if (who === 'wife') next = api.fn('updateWife')(next, wife => ({ ...wife, currentTask: 'away', taskTarget: 'festival_labor',
        busyUntilSlot: data.labor.endSlot, locationUntilSlot: data.labor.endSlot }));
      return Festival_기록하기(next, `${who === 'player' ? "당신" : api.fn('wife')(next).name}이(가) 마을로 가서 축제 준비를 돕습니다. 60분 후 돌아옵니다.`);
    }
    function Festival_미판매재고돌려놓기(state, stock) {
      return { ...state, readyFood: (state.readyFood || 0) + stock.readyFood,
        supplies: { ...state.supplies, food: state.supplies.food + stock.food,
          beer: state.supplies.beer + stock.beer, wine: state.supplies.wine + stock.wine } };
    }
    function Festival_진행정리하기(state) {
      if (!state || state.gameOver) return state;
      let next = Festival_자료초기화하기(state);
      const original = Festival_자료읽기(next), data = structuredClone(original);
      let changed = false;
      if (data.labor && next.slot >= data.labor.endSlot) {
        const task = data.labor;
        if (task.who === 'player') next = api.fn('FestivalAwayLog')(next, task.awayEventStart || 0);
        next = Festival_장소이동하기(next, task.who === 'player' ? 'player' : task.characterId, task.originalLocation || 'taproom');
        if (task.who === 'wife') next = api.fn('updateWife')(next, wife => ({ ...wife, currentTask: 'idle', taskTarget: undefined,
          busyUntilSlot: next.slot, locationUntilSlot: undefined }));
        const request = data.current.requests.find(item => item.day === task.requestDay);
        if (request) Object.assign(request, { completed: true, who: task.who });
        data.labor = null; changed = true;
        next = Festival_기록하기(next, '오늘의 축제 준비를 60분간 도운 뒤 주점으로 돌아왔습니다.');
      }
      if (data.stall?.stage === 'opening' && next.slot >= data.stall.readyAtSlot) {
        data.stall.stage = 'open'; changed = true;
        next = Festival_기록하기(next, "30분간 이동·설치를 마치고 당신의 출장 판매소를 열었습니다.");
      }
      if (data.stall && ['opening', 'open'].includes(data.stall.stage) && !Festival_참여혜택확인하기(next)) {
        data.stall.stage = 'returning'; data.stall.readyAtSlot = next.slot + 30; changed = true;
        next = Festival_기록하기(next, '축제가 끝나 출장 판매를 마감합니다. 30분 후 돌아옵니다.');
      }
      if (data.stall?.stage === 'returning' && next.slot >= data.stall.readyAtSlot) {
        const stall = data.stall;
        next = api.fn('FestivalAwayLog')(next, stall.awayEventStart || 0);
        next = Festival_미판매재고돌려놓기(next, stall.stock);
        next = Festival_장소이동하기(next, 'player', stall.originalLocation || 'taproom');
        data.stall = null; changed = true;
        next = Festival_기록하기(next, `30분간 정리·이동을 마치고 복귀했습니다. 미판매 재고를 돌려놓았습니다. 판매액 ${stall.revenue}골드 · 방문 ${stall.visitors}명.`);
      }
      const day = Festival_영업일읽기(next);
      if (day > data.current.festivalDay + 1 && !data.stall && !data.labor) {
        const previous = data.current, options = Festival_설정읽기();
        const interval = options.intervalMode === 'random' ? Festival_무작위정수만들기(10, 90) : options.intervalDays;
        data.history = [...data.history, previous].slice(-200);
        data.current = Festival_주기만들기(Math.max(previous.festivalDay + interval, day + 2));
        changed = true;
        next = Festival_기록하기(next, `이번 축제가 끝났습니다. 다음 축제는 ${data.current.festivalDay}일차입니다.`);
      }
      if (changed) next = Festival_자료쓰기(next, data);
      const current = Festival_자료읽기(next).current;
      if (!Festival_자료읽기(next).proposal && day >= current.festivalDay - 2 && current.participation === 'pending' && !current.invitationQueued) {
        next = Festival_자료쓰기(next, { ...Festival_자료읽기(next), current: { ...current, invitationQueued: true } });
        next = Festival_기록하기(next, '촌장이 밖에서 주점을 찾아와 마을 축제 참여를 요청합니다.');
        next = Festival_초대넣기(next);
      }
      const request = Festival_준비요청읽기(next);
      if (request && !request.queued && !Festival_자료읽기(next).labor
        && (!Festival_담당자불가이유읽기(next, 'player') || !Festival_담당자불가이유읽기(next, 'wife'))) {
        const copy = structuredClone(Festival_자료읽기(next));
        copy.current.requests.find(item => item.day === request.day).queued = true;
        next = Festival_일손요청넣기(Festival_자료쓰기(next, copy));
      }
      if (!next.pendingEvent && !next.errandSession && (next.alertQueue || []).some(alert => [invitationKind, helpKind, proposalKind].includes(alert.kind)))
        next = api.fn('drainAlerts')(next);
      return next;
    }
    function Festival_배수읽기(state, site = 'tavern') {
      return Festival_참여혜택확인하기(state) ? Festival_설정읽기()[site === 'stall' ? 'stallMultiplier' : 'tavernMultiplier'] : 1;
    }
    function Festival_방문확률읽기(state, site = 'tavern') {
      const base = api.fn('FestivalBaseArrivalChance')(state.slot) * api.fn('FestivalServiceArrivalFactor')(state.tavernReputation.service)
        * api.fn('FestivalRenownArrivalFactor')(state.tavernReputation.renown ?? 50)
        * api.fn('FestivalOutreachMultiplier')(state) * api.fn('FestivalWeatherMultiplier')(state);
      return { base: Math.min(1, base), multiplier: Festival_배수읽기(state, site),
        chance: Math.min(1, base * Festival_배수읽기(state, site)) };
    }
    function Festival_판매소개점불가이유읽기(state) {
      if (!state || state.gameOver) return '게임을 진행 중일 때 이용할 수 있습니다.';
      if (!Festival_참여혜택확인하기(state)) return '참여한 축제의 당일과 다음 날에 이용할 수 있습니다.';
      if (Festival_자료읽기(state)?.stall) return '이미 출장 판매소를 운영 중입니다.';
      if (state.pendingEvent || Festival_자료읽기(state)?.labor || Festival_장면진행확인하기(state)) return '진행 중인 사건이나 일을 먼저 마무리하세요.';
      if (!HOME.has(api.fn('playerLocation')(state))) return "당신이 주점에 있어야 개점할 수 있습니다.";
      return '';
    }
    function Festival_판매소열기(state, action) {
      const blocked = Festival_판매소개점불가이유읽기(state);
      if (blocked) return Festival_기록하기(state, blocked);
      const available = Festival_재고읽기(state), stock = {};
      for (const key of Object.keys(ITEMS)) {
        const count = Number(action.stock?.[key] ?? 0);
        if (!Number.isSafeInteger(count) || count < 0 || count > available[key]) return Festival_기록하기(state, '가져갈 수량이 현재 재고와 맞지 않습니다. 재고를 다시 선택하세요.');
        stock[key] = count;
      }
      if (!Object.values(stock).some(count => count > 0)) return Festival_기록하기(state, '최소 한 개의 판매 재고를 선택하세요.');
      const data = structuredClone(Festival_자료읽기(state));
      data.stall = { stage: 'opening', startSlot: state.slot, readyAtSlot: state.slot + 30,
        awayEventStart: (state.awayEvents || []).length,
        originalLocation: api.fn('playerLocation')(state), stock, visitors: 0, revenue: 0, lastRollSlot: state.slot };
      let next = Festival_자료쓰기({ ...state, readyFood: state.readyFood - stock.readyFood,
        supplies: { ...state.supplies, food: state.supplies.food - stock.food, beer: state.supplies.beer - stock.beer, wine: state.supplies.wine - stock.wine } }, data);
      next = Festival_장소이동하기(next, 'player', 'village');
      next = Festival_기록하기(next, `당신이 출장 판매소로 출발합니다. 개점까지 30분. 가져가는 재고: ${Festival_재고표현하기(stock)}.`);
      return Festival_시간보내기(next, { minutes: 30 });
    }
    function Festival_판매소돌아오기(state) {
      const original = Festival_자료읽기(state);
      if (!original?.stall) return state;
      if (original.stall.stage === 'returning') return Festival_시간보내기(state, { minutes: Math.max(0, original.stall.readyAtSlot - state.slot) });
      const data = structuredClone(original);
      data.stall.stage = 'returning'; data.stall.readyAtSlot = state.slot + 30;
      const next = Festival_기록하기(Festival_자료쓰기(state, data), '출장 판매를 중단하고 주점으로 돌아갑니다. 정리·이동에 30분이 소요됩니다.');
      return Festival_시간보내기(next, { minutes: 30 });
    }
    function Festival_판매진행하기(state) {
      const original = Festival_자료읽기(state), stall = original?.stall;
      if (stall?.stage !== 'open' || stall.lastRollSlot === state.slot) return state;
      if (!Festival_참여혜택확인하기(state)) {
        const data = structuredClone(original);
        data.stall.stage = 'returning'; data.stall.readyAtSlot = state.slot + 30;
        return Festival_기록하기(Festival_자료쓰기(state, data), '축제가 끝나 출장 판매를 마감합니다. 30분 후 돌아옵니다.');
      }
      const data = structuredClone(original); data.stall.lastRollSlot = state.slot;
      const priorContext = visitContext;
      let arrived;
      try {
        visitContext = { state, site: 'stall' };
        const baseMultiplier = api.fn('FestivalOutreachMultiplier')(state) * api.fn('FestivalWeatherMultiplier')(state);
        arrived = api.fn('normalVisitRoll')(state.slot, state.tavernReputation.service, 0, state.tavernReputation.renown ?? 50, baseMultiplier);
      } finally { visitContext = priorContext; }
      if (!arrived) return Festival_자료쓰기(state, data);
      data.stall.visitors++; data.current.stallVisitors++; data.totalStallVisitors++;
      const available = Object.keys(ITEMS).filter(key => data.stall.stock[key] > 0);
      if (!available.length) return Festival_기록하기(Festival_자료쓰기(state, data), '축제 손님이 출장 판매소를 찾아왔지만 판매할 재고가 없습니다.');
      const item = available[Festival_무작위정수만들기(0, available.length - 1)];
      const price = api.fn('waitressPrice')(['food', 'readyFood'].includes(item) ? 'food' : item);
      data.stall.stock[item]--; data.stall.revenue += price; data.current.stallRevenue += price; data.totalStallRevenue += price;
      let next = api.fn('waitressIncome')(Festival_자료쓰기(state, data), 'festival_stall', price);
      return Festival_기록하기(next, `출장 판매소에서 ${item === 'food' ? '식재료로 만든 음식' : ITEMS[item]} 1개를 ${price}골드에 판매했습니다.`);
    }
    function Festival_시간보내기(state, action) {
      let next = Festival_진행정리하기(state);
      const data = Festival_자료읽기(next), playerAway = data?.stall || data?.labor?.who === 'player';
      if (!playerAway) return next;
      const minutes = Math.round(Festival_숫자제한하기(action.minutes, 0, 1440, 15));
      const visitors = data.stall?.visitors ?? 0;
      for (let minute = 0; minute < minutes && !next.gameOver; minute++) {
        if (next.pendingEvent) break;
        const before = next.slot;
        next = api.fn('worldTick')(next, { playerPresent: false });
        const current = Festival_자료읽기(next);
        if (next.slot === before || next.pendingEvent || (!current?.stall && current?.labor?.who !== 'player')) break;
        if (action.until === 'customer' && (current.stall?.visitors ?? 0) > visitors) break;
      }
      return next;
    }
    function Festival_마감의무확인하기(state) {
      const data = Festival_자료읽기(state), round = data?.current, day = Festival_영업일읽기(state);
      return !!data?.stall || !!data?.labor || (round?.participation === 'accepted' &&
        round.requests.some(request => request.day <= day && !request.completed));
    }

    api.hook('normalVisitRoll', { around(next, slot, service, count, renown = 50, multiplier = 1) {
      const context = visitContext, state = context?.state || api.store.game();
      return next(slot, service, count, renown, multiplier * (state ? Festival_배수읽기(state, context?.site) : 1));
    } });
    api.hook('FestivalPreferredVisitChance', { after(result) {
      const state = visitContext?.state || api.store.game();
      return result * (state ? Festival_배수읽기(state, visitContext?.site) : 1);
    } });
    api.hook('worldTick', { priority: -100, around(next, state, context) {
      const previousContext = visitContext;
      let prepared = Festival_진행정리하기(state);
      const data = Festival_자료읽기(prepared);
      const absent = !!data?.stall || data?.labor?.who === 'player';
      try {
        visitContext = { state: prepared, site: 'tavern' };
        const result = next(prepared, absent ? { ...context, playerPresent: false } : context);
        if (result.slot === prepared.slot) return result;
        const progressed = Festival_진행정리하기(result);
        return data?.stall?.stage === 'open' ? Festival_판매진행하기(progressed) : progressed;
      } finally { visitContext = previousContext; }
    } });
    api.hook('FestivalEndDay', { priority: -100, around(next, state, ...args) {
      if (Festival_마감의무확인하기(state)) return Festival_기록하기(state, '축제 준비 일손이나 출장 판매를 마무리한 뒤 하루를 마감하세요.');
      return next(state, ...args);
    } });
    api.hook('reduceGameAction', { priority: -100, around(next, state, action) {
      const prepared = Festival_진행정리하기(state), data = Festival_자료읽기(prepared);
      if (action.type === 'wait' && (data?.stall || data?.labor?.who === 'player')) return Festival_시간보내기(prepared, action);
      if (['errand_return_now', 'go_to_bed_early', 'sleep', 'end_day'].includes(action.type) && Festival_마감의무확인하기(prepared))
        return Festival_기록하기(prepared, '오늘의 축제 일을 먼저 마무리해야 합니다. 출장 판매소는 복귀 버튼으로 닫을 수 있습니다.');
      if (action.type === 'resolve_event' && [invitationKind, helpKind, proposalKind].includes(prepared.pendingEvent?.alert?.kind)
        && !prepared.pendingEvent.choices.some(choice => choice.id === action.choiceId)) return prepared;
      if ((data?.stall || data?.labor?.who === 'player') && action.type !== 'resolve_event')
        return Festival_기록하기(prepared, "당신이 마을에서 축제 일을 하고 있습니다. 현재 일의 진행 버튼을 이용하세요.");
      return Festival_진행정리하기(next(prepared, action));
    } });
    api.actions.register('festival/open-stall', Festival_판매소열기, { label: '출장 판매소 개점' });
    api.actions.register('festival/return', Festival_판매소돌아오기, { label: '출장 판매소를 닫고 복귀' });
    api.actions.register('festival/advance', Festival_시간보내기, { label: '축제 일 계속하기' });
    api.actions.register('festival/visit-mayor', Festival_촌장방문시작하기, { label: '촌장 방문하러 가기' });

    function Festival_버튼그리기(label, description, onClick, disabled = false, key = label) {
      return JSX.jsxs('button', { type: 'button', disabled, onClick, 'data-festival-button': key,
        className: 'text-left w-full p-3 rounded-lg border border-amber-700 bg-stone-800 hover:bg-stone-700 disabled:opacity-50 text-stone-100',
        children: [JSX.jsx('div', { className: 'font-medium text-sm text-amber-200', children: label }),
          JSX.jsx('div', { className: 'text-xs text-stone-400 mt-1', children: description })] }, key);
    }
    function Festival_마을버튼그리기(state) {
      if (!Festival_축제진행확인하기(state)) return null;
      const blocked = Festival_판매소개점불가이유읽기(state);
      return Festival_버튼그리기('축제 출장 판매소 개점', blocked || "당신이 운영 · 가져갈 재고 선택 · 개점 30분 · 복귀 30분",
        Festival_재고창열기, !!blocked, 'open-stall');
    }
    function Festival_외부행동그리기(state) {
      const data = Festival_자료읽기(state), stall = data?.stall, labor = data?.labor;
      const title = stall ? ({ opening: '출장 판매소 개점 중', open: "당신의 축제 출장 판매소", returning: '출장 판매소에서 복귀 중' })[stall.stage] : "당신이 축제 준비를 돕는 중";
      const remaining = Math.max(0, (stall?.readyAtSlot || labor?.endSlot || state.slot) - state.slot);
      return JSX.jsxs('section', { 'data-festival-active': true, className: 'p-3 my-3 rounded-lg border-2 border-amber-700 bg-stone-900',
        children: [JSX.jsx('h3', { className: 'text-sm font-bold text-amber-300 mb-2', children: title }),
          JSX.jsx('p', { className: 'text-sm text-stone-200 mb-3', style: { whiteSpace: 'pre-line' }, children: stall
            ? `${Festival_재고표현하기(stall.stock)}\n방문 ${stall.visitors}명 · 판매액 ${stall.revenue}골드\n${stall.stage === 'open' ? `현재 방문 확률 ${Math.round(Festival_방문확률읽기(state, 'stall').chance * 10000) / 100}%/분 · 기준 대비 ${Festival_설정읽기().stallMultiplier}배` : `남은 시간 ${remaining}분`}`
            : `마을에서 준비를 돕습니다. 남은 시간 ${remaining}분. 오늘의 일손을 끝낸 뒤 돌아옵니다.` }),
          Festival_버튼그리기(stall?.stage === 'open' ? '15분 판매하기' : '남은 시간 계속하기', '주점에서도 같은 시간 동안 영업이 진행됩니다.',
            () => api.store.dispatch({ type: 'festival/advance', minutes: stall?.stage === 'open' ? 15 : remaining }), !!state.pendingEvent, 'advance'),
          stall ? Festival_버튼그리기('판매를 그만두고 주점으로 복귀', '미판매 재고 반환 · 정리와 이동에 30분',
            () => api.store.dispatch({ type: 'festival/return' }), false, 'return') : null] });
    }
    api.hook('FestivalVillageActions', { after(result) {
      const state = api.store.game();
      if (!state || !React.isValidElement(result)) return result;
      const button = Festival_마을버튼그리기(state);
      if (!button) return result;
      const children = React.Children.toArray(result.props.children), index = children.length - 1, village = children[index];
      if (React.isValidElement(village)) children[index] = React.cloneElement(village, {}, ...React.Children.toArray(village.props.children), button);
      return React.cloneElement(result, {}, ...children);
    } });
    api.hook('ActionPanel', { priority: -200, after(result) {
      const state = api.store.game(), data = Festival_자료읽기(state);
      if (data?.stall || data?.labor?.who === 'player') return JSX.jsxs('div', { children: [state.pendingEvent ? result : null, Festival_외부행동그리기(state)] });
      const villageButton = Festival_마을버튼그리기(state);
      if (state?.mods?.['wife-view-mode']?.active && villageButton) return JSX.jsxs('div', { children: [result,
        JSX.jsxs('section', { className: 'mt-3 pt-3 border-t border-stone-700', children: [
          JSX.jsx('h4', { className: 'text-xs text-stone-400 mb-2', children: '행동 · 마을 둘러보기' }), villageButton] })] });
      return result;
    } });

    function Festival_상태표현하기(state) {
      const data = Festival_자료읽기(state);
      if (!data) return '게임을 시작하면 첫 축제일을 정합니다.';
      const round = data.current, day = Festival_영업일읽기(state);
      const status = day < round.festivalDay - 2 ? '개최 예정' : day < round.festivalDay ? '준비 기간' : Festival_축제진행확인하기(state) ? '축제 기간' : '종료';
      return `${status} · 준비 ${round.festivalDay - 2}~${round.festivalDay - 1}일차 · 축제 ${round.festivalDay}~${round.festivalDay + 1}일차\n참여: ${{ pending: '촌장의 초대 대기', accepted: '수락', declined: '거절' }[round.participation]}\n준비 일손: ${round.requests.filter(request => request.completed).length}/2일 완료\n이번 축제 출장 판매액 ${round.stallRevenue}골드 · 방문 ${round.stallVisitors}명`;
    }
    function Festival_설정그리기(body, win) {
      body.replaceChildren(); body.style.maxWidth = '100%';
      const settings = Festival_설정읽기();
      const status = document.createElement('p'); status.dataset.festivalStatus = ''; status.style.whiteSpace = 'pre-line';
      status.textContent = Festival_상태표현하기(api.store.game()); body.append(status);
      const note = document.createElement('p'); note.textContent = '최초 촌장 방문: 5~20일차 중 추첨. 첫 축제는 그 이틀 뒤인 7~22일차입니다. 준비 2일·축제 2일. 기존 저장의 일정은 유지합니다. 배수는 기존 방문 확률에 곱하며 술집 정원은 유지합니다.'; body.append(note);
      const visit = api.ui.button('촌장 방문하러 가기', () => { if (Festival_촌장방문하기()) win?.close?.(); });
      visit.dataset.festivalVisitMayor = '';
      const visitNote = document.createElement('p'); visitNote.dataset.festivalVisitReason = '';
      body.append(visit, visitNote);
      Festival_방문버튼갱신하기(body);
      function Festival_설정입력만들기(label, key, minimum, maximum, step = 1) {
        const row = document.createElement('label'); row.style.cssText = 'display:flex;justify-content:space-between;gap:12px;align-items:center;margin:12px 0;';
        const input = document.createElement('input'); input.type = 'number'; input.min = minimum; input.max = maximum; input.step = step;
        input.value = settings[key]; input.dataset.festivalSetting = key; input.style.cssText = 'width:85px;padding:6px;background:#292524;color:#fafaf9;border:1px solid #78716c;border-radius:4px';
        input.addEventListener('change', () => { api.settings.set({ [key]: Festival_숫자제한하기(input.value, minimum, maximum, settings[key]) }); input.value = Festival_설정읽기()[key]; });
        row.append(document.createTextNode(label), input); body.append(row); return input;
      }
      Festival_설정입력만들기('술집 방문 확률 배수 (1~5)', 'tavernMultiplier', 1, 5, .1);
      Festival_설정입력만들기('출장 판매소 방문 확률 배수 (1~10)', 'stallMultiplier', 1, 10, .1);
      const row = document.createElement('label'); row.style.cssText = 'display:flex;justify-content:space-between;margin:12px 0;gap:12px';
      const select = document.createElement('select'); select.dataset.festivalSetting = 'intervalMode';
      select.style.cssText = 'padding:6px;background:#292524;color:#fafaf9;border:1px solid #78716c;border-radius:4px;max-width:180px';
      for (const [value, text] of [['random', '무작위 10~90일'], ['fixed', '고정 간격']]) { const option = document.createElement('option'); option.value = value; option.textContent = text; select.append(option); }
      select.value = settings.intervalMode; row.append(document.createTextNode('이후 축제 개최 간격'), select); body.append(row);
      const interval = Festival_설정입력만들기('고정 간격 (10~90일)', 'intervalDays', 10, 90);
      interval.disabled = select.value !== 'fixed';
      select.addEventListener('change', () => { api.settings.set({ intervalMode: select.value }); interval.disabled = select.value !== 'fixed'; });
      const scheduleNote = document.createElement('p'); scheduleNote.textContent = '간격 변경은 이번 축제가 끝난 뒤 다음 일정을 정할 때 적용합니다. 이미 정한 축제일은 유지합니다.'; body.append(scheduleNote);
      body.append(api.ui.button('출장 판매 재고 선택', Festival_재고창열기));
    }
    function Festival_방문버튼갱신하기(root) {
      const blocked = Festival_촌장방문불가이유읽기(api.store.game());
      for (const button of root.querySelectorAll('[data-festival-visit-mayor]')) button.disabled = !!blocked;
      for (const note of root.querySelectorAll('[data-festival-visit-reason]')) note.textContent = blocked || '내일부터 이틀 준비하고 3일 뒤 축제를 엽니다. 제안 확인 후 일정을 바꿉니다.';
    }
    function Festival_설정창열기() {
      statusWindow = api.ui.window({ id: 'settings', title: 'Festival 모드 설정', width: 520, height: 620, settings: true, render: Festival_설정그리기,
        onClose: () => { statusWindow = null; } });
    }
    function Festival_재고창열기() {
      const state = api.store.game(), blocked = Festival_판매소개점불가이유읽기(state);
      stockWindow = api.ui.window({ id: 'stock', title: '축제 출장 판매소 · 가져갈 재고', width: 440, height: 470,
        onClose: () => { stockWindow = null; }, render(body) {
          body.replaceChildren();
          const note = document.createElement('p'); note.textContent = blocked || "당신이 운영합니다. 재고는 출발할 때 차감하며 미판매분은 복귀 후 반환합니다. 식재료는 간단한 음식으로 만들어 판매합니다."; body.append(note);
          const inputs = {}, available = state ? Festival_재고읽기(state) : {};
          for (const [key, label] of Object.entries(ITEMS)) {
            const row = document.createElement('label'); row.style.cssText = 'display:flex;justify-content:space-between;gap:10px;margin:12px 0;align-items:center';
            const input = document.createElement('input'); input.type = 'number'; input.min = 0; input.max = available[key] || 0; input.step = 1; input.value = 0;
            input.dataset.festivalStock = key; input.style.cssText = 'width:80px;padding:6px;background:#292524;color:#fafaf9;border:1px solid #78716c';
            input.disabled = !!blocked; row.append(document.createTextNode(`${label} · 재고 ${available[key] || 0}`), input); body.append(row); inputs[key] = input;
          }
          body.append(api.ui.button('재고를 챙겨 개점하기 · 30분', () => {
            if (Festival_판매소개점불가이유읽기(api.store.game())) return;
            const stock = Object.fromEntries(Object.entries(inputs).map(([key, input]) => [key, Number(input.value)]));
            api.store.dispatch({ type: 'festival/open-stall', stock });
            if (Festival_자료읽기(api.store.game())?.stall) stockWindow?.close();
          }, { disabled: !!blocked }));
          body.append(api.ui.button('닫기', () => stockWindow?.close()));
        } });
    }
    function Festival_저장소동기화하기() {
      if (writing || !api.store.get().started || !api.store.game()) return;
      const state = api.store.game(), next = Festival_진행정리하기(state);
      if (next !== state) { writing = true; try { api.store.update(current => current === state ? next : current); } finally { writing = false; } }
      statusWindow?.el.querySelector('[data-festival-status]')?.replaceChildren(document.createTextNode(Festival_상태표현하기(api.store.game())));
      Festival_방문버튼갱신하기(document);
    }
    globalThis.__waywardWifeViewLegacyGuard.register('festival-compatible-wife-view-mode', api, state => {
      const data = Festival_자료읽기(state);
      return !!data?.labor || !!data?.stall || !!data?.proposal || [invitationKind, helpKind, proposalKind].includes(state.pendingEvent?.alert?.kind);
    });
    api.ui.addButton({ label: '축제', title: 'Festival 모드 설정', onClick: Festival_설정창열기 });
    // 기본 설정 등록만 사용해 일시정지 메뉴의 자동·구형 버튼 등록을 피합니다.
    wmlApi.ui.settings(Festival_설정그리기);
    api.onBack(() => { if (stockWindow) { stockWindow.close(); return true; } if (statusWindow) { statusWindow.close(); return true; } return false; });
    api.store.subscribe(Festival_저장소동기화하기);
    const exposed = { getData: () => structuredClone(Festival_자료읽기(api.store.game())), getSettings: Festival_설정읽기,
      getStatus: () => Festival_상태표현하기(api.store.game()), getArrivalChance: site => Festival_방문확률읽기(api.store.game(), site),
      openSettings: Festival_설정창열기, openStock: Festival_재고창열기, visitMayor: Festival_촌장방문하기,
      getMayorVisitBlocked: () => Festival_촌장방문불가이유읽기(api.store.game()), renderActionButton: Festival_버튼그리기,
      setSettings: patch => { api.settings.set(patch); return Festival_설정읽기(); },
      invitationKind, helpKind, proposalKind };
    globalThis.__waywardFestival = Object.freeze(exposed);
    api.provide(exposed);
    Festival_저장소동기화하기();
  }
});
