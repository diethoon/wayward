// Festival-compatible-Wife_View_Mode: bundled so the Festival folder is portable.
// Share the existing ownership guard when pregnancy/delivery has installed it.
(() => {
  if (globalThis.__waywardWifeViewLegacyGuard) return;
  const owners = new Map();
  let store = null, writing = false;
  function FestivalCompatibleWifeView_상태복원하기() {
    if (writing || !store) return;
    const state = store.game();
    if (!state) return;
    const view = state.mods?.['wife-view-mode'] || {}, saved = view.portableCompatibility;
    const active = [...owners].filter(([, rule]) => rule(state)).map(([id]) => id).sort();
    if (!saved && (!active.length || view.active !== true)) return;
    if (saved && active.length && view.active === false && JSON.stringify(active) === JSON.stringify(saved.owners)) return;
    const next = active.length
      ? { ...view, active: false, portableCompatibility: { wasActive: saved?.wasActive ?? view.active, owners: active } }
      : { ...view, active: saved.wasActive === true };
    if (!active.length) delete next.portableCompatibility;
    writing = true;
    try { store.update(current => ({ ...current, mods: { ...current.mods, 'wife-view-mode': next } })); }
    finally { writing = false; }
  }
  function FestivalCompatibleWifeView_연결하기(owner, api, rule) {
    owners.set(owner, rule);
    if (!store) { store = api.store; store.subscribe(FestivalCompatibleWifeView_상태복원하기); }
    FestivalCompatibleWifeView_상태복원하기();
    return () => { owners.delete(owner); FestivalCompatibleWifeView_상태복원하기(); };
  }
  globalThis.__waywardWifeViewLegacyGuard = {
    register: FestivalCompatibleWifeView_연결하기, reconcile: FestivalCompatibleWifeView_상태복원하기
  };
})();
