// 실행: node wml/mods/festival/tests/settings-regression.mjs [--mobile] [--legacy] [--missing-menu] [--throwing-api] [--official-only] [--zip]
// seed 1138. MCP의 격리 브라우저만 사용하며 사용자 저장과 공통 파일을 수정하지 않습니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {playStart,playEval,playReload,playStatus,playStop,playScreenshot} from '../../../../MCP/lib/play.mjs';
import {checkMod} from '../../../../MCP/lib/check.mjs';
const mobile=process.argv.includes('--mobile'),legacy=process.argv.includes('--legacy');
const throwing=process.argv.includes('--throwing-api'),missing=process.argv.includes('--missing-menu');
const officialOnly=process.argv.includes('--official-only'),fallback=legacy||throwing||missing;
const ids=['addon-compat','brothel','festival','brothel-compatible-festival'];
async function FestivalSettingsTest_평가하기(code){return (await playEval({code})).result;}
try{
  for(const id of ['festival','brothel-compatible-festival'])assert.ok(checkMod(id).ok,id);
  await playStart({mods:Object.fromEntries(ids.map(id=>[id,true])),...(mobile?{viewport:{width:390,height:844}}:{})});
  await FestivalSettingsTest_평가하기(`localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify(ids)}));return true;`);
  if(process.argv.includes('--zip')){
    const packages=[['festival','festival-1.2.0.zip'],['brothel-compatible-festival','brothel-compatible-festival-1.0.4.zip']];
    const installed=await FestivalSettingsTest_평가하기(`return WML.install(await Promise.all(${JSON.stringify(packages)}.map(async([id,file])=>({path:file,blob:await(await fetch('wml/mods/'+id+'/'+file)).blob()}))));`);
    assert.deepEqual(installed.map(item=>item.id).sort(),['brothel-compatible-festival','festival']);
    console.log('PASS versioned mod packages recognized');
  }
  if(fallback||officialOnly){
    await FestivalSettingsTest_평가하기(`
      let source=await(await fetch('wml/mods/festival/mod.js')).text();
      source=source.replace("version: '1.2.0'","version: '999.0.0.test'");
      ${fallback?`source=source.replace('async setup(wmlApi) {','async setup(testApi) { const wmlApi={...testApi,ui:{...testApi.ui,pauseSettings:${legacy?'undefined':throwing?'()=>{throw Error("Simulated pause API failure")}':'()=>{}'}}};');`:''}
      ${officialOnly?`source=source.replace('api.ui.settings(Festival_설정그리기);','wmlApi.ui.settings(Festival_설정그리기);').replace('api.ui.menuSettings({','(()=>()=>{})({');`:''}
      const files=[{path:'festival/mod.js',blob:new Blob([source],{type:'text/javascript'})}];
      for(const name of ['native-ui.js','festival-compatible-wife-view-mode.js'])files.push({path:'festival/'+name,blob:await(await fetch('wml/mods/festival/'+name)).blob()});
      return WML.install(files);
    `);
  }
  const loaded=await playReload({});assert.deepEqual(loaded.failed,[]);for(const id of ids)assert.ok(loaded.loaded.includes(id),id);
  console.log('START '+(mobile?'mobile':'desktop')+' '+(fallback?'fallback':officialOnly?'official only':'dual registration'));
  await FestivalSettingsTest_평가하기(`
    globalThis.festivalSettingsSeed=1138;
    Math.random=function FestivalSettingsTest_난수만들기(){festivalSettingsSeed=(Math.imul(festivalSettingsSeed,1664525)+1013904223)>>>0;return festivalSettingsSeed/4294967296;};
    for(let step=0;step<30;step++){
      if(document.querySelector('button[title="메뉴"]'))break;
      const buttons=[...document.querySelectorAll('button')].filter(button=>button.offsetParent);
      const button=buttons.find(item=>!item.disabled&&/^(예$|이해하고 동의합니다$|새 게임$|계속하기 —|시작 —|시작하기$|건너뛰기$)/.test(item.innerText.trim()))||buttons.find(item=>item.innerText.trim().startsWith('마라'));
      if(!button)throw Error('새 게임 버튼 없음');button.click();await new Promise(resolve=>setTimeout(resolve,150));
    }
    globalThis.festivalSettingsBase=structuredClone(WML.dev().store.game());
    globalThis.FestivalSettingsTest_초기화하기=function(day=1,participation='pending'){
      const state=structuredClone(festivalSettingsBase);state.day=day;state.slot=(day-1)*1440+780;state.phase='prep';
      state.pendingEvent=undefined;state.alertQueue=[];state.activeScene={};state.errandSession=undefined;state.activeShoppingSession=undefined;state.deliveryAddon={};
      state.customers=[];state.economy.debt=0;state.pendingCollectorVisit=false;
      state.mods.festival={version:1,current:{id:'festival:20',festivalDay:20,participation,invitationQueued:participation!=='pending',
        requests:[18,19].map(day=>({day,dueSlot:(day-1)*1440+1020,queued:false,completed:day<state.day,who:null})),stallRevenue:0,stallVisitors:0},labor:null,stall:null,history:[],totalStallRevenue:0,totalStallVisitors:0};
      for(const room of Object.values(state.locations))room.occupants=[];state.locations.taproom.occupants=['player',state.primaryCharacterId];
      WML.dev().store.update(()=>state);return WML.dev().store.game();
    };
    document.querySelector('button[title="메뉴"]').click();await new Promise(resolve=>setTimeout(resolve,200));return true;
  `);
  const menu=await FestivalSettingsTest_평가하기(`
    const official=document.querySelectorAll('[data-wml-pause-entry="festival"]'),legacy=document.querySelectorAll('[data-wayward-native-settings="festival"]');
    const button=official[0]||legacy[0];button.click();await new Promise(resolve=>setTimeout(resolve,150));
    const panel=document.querySelector('[data-wayward-native-window="festival:settings"]');
    return{official:official.length,legacy:legacy.length,open:!!panel,aboveMenu:panel&&getComputedStyle(panel).zIndex,
      visit:panel?.querySelector('[data-festival-visit-mayor]')?.textContent,horizontal:document.documentElement.scrollWidth<=innerWidth};
  `);
  assert.equal(menu.official,fallback?0:1);assert.equal(menu.legacy,fallback?1:0);assert.ok(menu.open);assert.equal(menu.visit,'촌장 방문하러 가기');assert.ok(menu.horizontal);
  console.log('PASS working pause settings button without duplication, settings window and mobile bounds');
  const cancel=await FestivalSettingsTest_평가하기(`
    FestivalSettingsTest_초기화하기();const api=WML.dev(),before=structuredClone(api.store.game());
    document.querySelector('[data-festival-visit-mayor]').click();await new Promise(resolve=>setTimeout(resolve,120));
    const event=api.store.game().pendingEvent,shown=!!document.querySelector('[data-wayward-native-window="festival:settings"]');
    api.store.dispatch({type:'resolve_event',choiceId:'withdraw'});const after=api.store.game();
    return{kind:event?.alert?.kind,shown,beforeRound:before.mods.festival.current,afterRound:after.mods.festival.current,
      beforeRep:before.tavernReputation,afterRep:after.tavernReputation,proposal:after.mods.festival.proposal,
      menuOpen:!!document.querySelector('#root h2 + [class~="flex-col"][class~="gap-2"] > button:first-child.bg-amber-700')};
  `);
  assert.equal(cancel.kind,'festival:proposal');assert.equal(cancel.shown,false);assert.equal(cancel.menuOpen,false);
  assert.deepEqual(cancel.afterRound,cancel.beforeRound);assert.deepEqual(cancel.afterRep,cancel.beforeRep);assert.equal(cancel.proposal,undefined);
  console.log('PASS settings visit opens proposal, closes pause menu, cancellation preserves schedule and reputation');
  const proposal=await FestivalSettingsTest_평가하기(`
    FestivalSettingsTest_초기화하기();const api=WML.dev(),mod=__waywardFestival;
    const first=mod.visitMayor();api.store.get().saveToSlot(0);api.store.get().loadFromSlot(0);
    const kind=api.store.game().pendingEvent?.alert?.kind;const second=mod.visitMayor();
    api.store.dispatch({type:'resolve_event',choiceId:'invalid'});const invalid=api.store.game().pendingEvent?.alert?.kind;
    api.store.dispatch({type:'resolve_event',choiceId:'accept'});const round=mod.getData().current,again=mod.visitMayor();
    const accepted=structuredClone(api.store.game());api.store.get().saveToSlot(0);api.store.get().loadFromSlot(0);
    api.store.update(state=>({...state,day:2,slot:1440+1380,phase:'service'}));const help=api.store.game().pendingEvent?.alert?.kind;
    return{first,second,kind,invalid,round,again,help,location:api.fn('playerLocation')(accepted),queue:accepted.alertQueue};
  `);
  assert.ok(proposal.first);assert.equal(proposal.second,false);assert.equal(proposal.kind,'festival:proposal');assert.equal(proposal.invalid,'festival:proposal');
  assert.equal(proposal.round.festivalDay,4);assert.equal(proposal.round.participation,'accepted');assert.deepEqual(proposal.round.requests.map(r=>r.day),[2,3]);
  assert.equal(proposal.again,false);assert.equal(proposal.help,'festival:help');assert.equal(proposal.location,'taproom');assert.deepEqual(proposal.queue,[]);
  console.log('PASS saved proposal, explicit acceptance, two preparation days, duplicate guard and normal labor request');
  const dates=await FestivalSettingsTest_평가하기(`
    const api=WML.dev(),originalRandom=Math.random,rows=[];
    try{for(const value of [0,.999999]){Math.random=()=>value;FestivalSettingsTest_초기화하기();api.store.update(state=>{const mods={...state.mods};delete mods.festival;return{...state,mods}});rows.push(__waywardFestival.getData().current.festivalDay-2);}}
    finally{Math.random=originalRandom;}return rows;
  `);
  assert.deepEqual(dates,[5,20]);console.log('PASS inclusive first mayor visit bounds 5 and 20');
  const hidden=await FestivalSettingsTest_평가하기(`
    FestivalSettingsTest_초기화하기(17,'accepted');await new Promise(resolve=>setTimeout(resolve,120));
    return{festival:!!document.querySelector('[data-festival-button="open-stall"]'),brothel:!!document.querySelector('[data-brothel-festival-configure]'),card:!!document.querySelector('[data-brothel-festival-site]')};
  `);
  assert.deepEqual(hidden,{festival:false,brothel:false,card:false});
  console.log('PASS all opening buttons hidden outside the festival period');
  const buttons=await FestivalSettingsTest_평가하기(`
    FestivalSettingsTest_초기화하기(20,'accepted');const api=WML.dev();
    api.store.update(state=>({...state,mods:{...state.mods,festival:{...state.mods.festival,current:{...state.mods.festival.current,requests:state.mods.festival.current.requests.map(r=>({...r,completed:true}))}}}}));
    await new Promise(resolve=>setTimeout(resolve,150));
    const selling=document.querySelector('[data-festival-button="open-stall"]');
    const village=selling.parentElement,brothel=village.querySelector('[data-brothel-festival-configure]'),card=document.querySelector('[data-brothel-festival-site]');
    const shapes={classSame:brothel.className===selling.className,childClasses:[...brothel.children].map((node,i)=>node.className===selling.children[i].className),label:brothel.firstElementChild.textContent,cardLabel:card?.querySelector('[data-brothel-festival-configure]')?.firstElementChild.textContent};
    brothel.click();await new Promise(resolve=>setTimeout(resolve,100));
    shapes.inputs=document.querySelectorAll('[data-brothel-festival-stock]').length;shapes.horizontal=document.documentElement.scrollWidth<=innerWidth;
    document.querySelectorAll('.wml-win').forEach(node=>node.querySelector('button[title="닫기"]')?.click());
    return shapes;
  `);
  assert.equal(buttons.label,'축제 출장 매춘소 개점');assert.equal(buttons.cardLabel,buttons.label);assert.ok(buttons.classSame);assert.deepEqual(buttons.childClasses,[true,true]);assert.equal(buttons.inputs,4);assert.ok(buttons.horizontal);
  console.log('PASS matching Festival button shape in village section and operating card; configuration opens');
  const shots=new URL('./shots/',import.meta.url);fs.mkdirSync(shots,{recursive:true});
  fs.writeFileSync(new URL((mobile?'mobile':'desktop')+'-'+(legacy?'legacy':throwing?'throwing':missing?'missing':officialOnly?'official-only':'dual')+'-festival.jpg',shots),Buffer.from(await playScreenshot({}),'base64'));
  const status=await playStatus({});assert.deepEqual(status.failed,[]);assert.deepEqual(status.pageErrors,[]);console.log('PASS no browser errors');
}finally{await playStop({});}
