// 실행: node wml/mods/festival/tests/regression.mjs [--integrated] [--mobile] [--zip]
// seed 1138. 별도 브라우저 프로필을 사용하며 사용자 저장과 모드 목록을 수정하지 않습니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {playStart,playEval,playStatus,playReload,playStop,playScreenshot} from '../../../../MCP/lib/play.mjs';
import {checkMod} from '../../../../MCP/lib/check.mjs';
const integrated=process.argv.includes('--integrated'),mobile=process.argv.includes('--mobile');
async function FestivalTest_평가하기(code){return (await playEval({code})).result;}
try{
  assert.ok(checkMod('festival').ok);
  await playStart({mods:{...Object.fromEntries(fs.readdirSync('wml/mods',{withFileTypes:true}).filter(e=>e.isDirectory()).map(e=>[e.name,false])),'wife-view-mode':integrated,'addon-compat':integrated,'h-status':integrated,
    pregnancy:integrated,'h-status-pregnancy':integrated,'pregnancy-compatible-wife-view-mode':integrated,
    delivery:integrated,imagestudio:false,festival:true},...(mobile?{viewport:{width:390,height:844}}:{})});
  if(process.argv.includes('--zip')){
    const installation=await FestivalTest_평가하기(`return WML.install([{path:'festival-1.2.0.zip',blob:await (await fetch('wml/mods/festival/festival-1.2.0.zip')).blob()}]);`);
    assert.equal(installation[0].id,'festival');console.log('PASS portable ZIP installation and folder registration');
  }
  await FestivalTest_평가하기(`localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify(integrated?['addon-compat','wife-view-mode','h-status','pregnancy','h-status-pregnancy','pregnancy-compatible-wife-view-mode','delivery','festival']:['festival'])}));return true;`);
  const loaded=await playReload({});
  assert.deepEqual(loaded.failed,[]);assert.ok(loaded.loaded.includes('festival'));
  console.log('START '+(integrated?'integrated':'standalone')+' '+(mobile?'mobile':'desktop'));
  await FestivalTest_평가하기(`
    globalThis.festivalTestSeed=1138;
    Math.random=function FestivalTest_난수만들기(){festivalTestSeed=(Math.imul(festivalTestSeed,1664525)+1013904223)>>>0;return festivalTestSeed/4294967296;};
    for(let step=0;step<30;step++){
      if(document.querySelector('button[title="메뉴"]'))break;
      const buttons=[...document.querySelectorAll('button')].filter(button=>button.offsetParent);
      const button=buttons.find(item=>!item.disabled&&/^(예$|이해하고 동의합니다$|새 게임$|계속하기 —|시작 —|시작하기$|건너뛰기$)/.test(item.innerText.trim()))
        ||buttons.find(item=>item.innerText.trim().startsWith('마라'));
      if(!button)throw Error('새 게임 시작 버튼 없음: '+buttons.map(item=>item.innerText).join(' / '));
      button.click();await new Promise(resolve=>setTimeout(resolve,150));
    }
    globalThis.festivalTestBase=structuredClone(WML.dev().store.game());
    if(!festivalTestBase)throw Error('새 게임 없음');
    globalThis.FestivalTest_초기화하기=function(day=10,hour=17,participation='accepted'){
      const state=structuredClone(festivalTestBase);
      state.day=day;state.slot=(day-1)*1440+hour*60;state.phase=hour>=17?'service':'prep';
      state.pendingEvent=undefined;state.alertQueue=[];state.activeScene={};state.customers=[];state.awayEvents=[];
      state.errandSession=undefined;state.activeShoppingSession=undefined;state.deliveryAddon={};state.economy.debt=0;state.pendingCollectorVisit=false;
      state.mods={...state.mods,'wife-view-mode':{...state.mods?.['wife-view-mode'],active:false},festival:{
        version:1,current:{id:'festival:10',festivalDay:10,participation,invitationQueued:participation!=='pending',
        requests:[8,9].map(day=>({day,dueSlot:(day-1)*1440+1020,queued:false,completed:day<state.day,who:null})),stallRevenue:0,stallVisitors:0},
        labor:null,stall:null,history:[],totalStallRevenue:0,totalStallVisitors:0}};
      for(const location of Object.values(state.locations))location.occupants=[];
      state.locations.taproom.occupants=['player',state.primaryCharacterId];
      const wife=state.characters[state.primaryCharacterId];
      Object.assign(wife,{currentTask:'idle',busyUntilSlot:0,sceneOverride:undefined,passedOutAtSlot:undefined,locationUntilSlot:undefined});
      wife.stats.energy=100;
      if(state.situationEventMod)for(const key of ['hotelSession','intrusion','mageTreatment','suspiciousPatron','potionPayment','cardFunding','aphrodisiacChain','observation','cleanupSession','crestAutonomy'])state.situationEventMod[key]=null;
      WML.dev().store.update(()=>state);return WML.dev().store.game();
    };
    globalThis.FestivalTest_일분진행하기=function(minutes,playerPresent=true){
      const api=WML.dev();for(let step=0;step<minutes;step++)api.store.update(state=>api.fn('worldTick')(state,{playerPresent}));
      return api.store.game();
    };
    return festivalTestBase.mods.festival.current;
  `).then(round=>{assert.ok(round.festivalDay-2>=5&&round.festivalDay-2<=20);for(const r of round.requests){assert.ok(r.dueSlot%1440>=1020&&r.dueSlot%1440<=1380);}console.log('PASS first mayor visit at day 5–20, preparation hours');});
  const invitation=await FestivalTest_평가하기(`
    FestivalTest_초기화하기(8,16,'pending');const api=WML.dev();
    const event=api.store.game().pendingEvent;
    api.store.dispatch({type:'resolve_event',choiceId:'decline'});
    const state=api.store.game();
    return {kind:event?.alert?.kind,choices:event?.choices.map(c=>c.id),participation:state.mods.festival.current.participation,
      renown:state.tavernReputation.renown,service:state.tavernReputation.service,
      before:festivalTestBase.tavernReputation,queued:state.alertQueue};
  `);
  assert.equal(invitation.kind,'festival:invitation');assert.deepEqual(invitation.choices,['accept','decline']);
  assert.equal(invitation.participation,'declined');assert.equal(invitation.renown,Math.max(0,invitation.before.renown-5));assert.equal(invitation.service,Math.max(0,invitation.before.service-5));
  console.log('PASS mayor invitation and decline penalties');
  const labor=await FestivalTest_평가하기(`
    FestivalTest_초기화하기(8,17,'pending');const api=WML.dev();api.store.dispatch({type:'resolve_event',choiceId:'accept'});
    const help=api.store.game().pendingEvent;
    api.store.dispatch({type:'resolve_event',choiceId:'player'});
    const start=api.store.game().slot,away=api.fn('playerLocation')(api.store.game());
    api.store.dispatch({type:'festival/advance',minutes:59});const beforeEnd=api.store.game();
    api.store.dispatch({type:'festival/advance',minutes:1});const end=api.store.game();
    return {help:help?.alert?.kind,choices:help?.choices.map(c=>c.id),start,away,before:beforeEnd.slot,beforeLabor:beforeEnd.mods.festival.labor,
      end:end.slot,labor:end.mods.festival.labor,location:api.fn('playerLocation')(end),completed:end.mods.festival.current.requests[0].completed};
  `);
  assert.equal(labor.help,'festival:help');assert.deepEqual(labor.choices,['player','wife']);assert.equal(labor.away,'village');
  assert.equal(labor.before-labor.start,59);assert.ok(labor.beforeLabor);assert.equal(labor.end-labor.start,60);assert.equal(labor.labor,null);assert.equal(labor.location,'taproom');assert.ok(labor.completed);
  console.log('PASS husband preparation 60 minutes');
  const wifeLabor=await FestivalTest_평가하기(`
    FestivalTest_초기화하기(9,17);const api=WML.dev();api.store.dispatch({type:'resolve_event',choiceId:'wife'});
    const start=api.store.game().slot,places=[];
    for(let step=0;step<60;step++){FestivalTest_일분진행하기(1);if(step<59)places.push(api.fn('wifeLocation')(api.store.game()));}
    const state=api.store.game();return {start,end:state.slot,places:[...new Set(places)],labor:state.mods.festival.labor,
      wifeLocation:api.fn('wifeLocation')(state),playerLocation:api.fn('playerLocation')(state),completed:state.mods.festival.current.requests[1].completed};
  `);
  assert.equal(wifeLabor.end-wifeLabor.start,60);assert.deepEqual(wifeLabor.places,['village']);assert.equal(wifeLabor.labor,null);assert.ok(wifeLabor.completed);assert.equal(wifeLabor.wifeLocation,'taproom');assert.equal(wifeLabor.playerLocation,'taproom');
  console.log('PASS wife preparation 60 minutes');
  const stall=await FestivalTest_평가하기(`
    FestivalTest_초기화하기(10,17);const api=WML.dev(),stock={food:2,readyFood:0,beer:2,wine:1};
    const before=structuredClone(api.store.game());api.store.dispatch({type:'festival/open-stall',stock});
    const opened=structuredClone(api.store.game());api.store.dispatch({type:'festival/advance',minutes:60});
    const sold=structuredClone(api.store.game());api.store.dispatch({type:'festival/return'});const end=api.store.game();
    return {beforeSlot:before.slot,openedSlot:opened.slot,stage:opened.mods.festival.stall?.stage,openedStock:opened.mods.festival.stall?.stock,
      sold:sold.mods.festival.stall,delta:sold.economy.gold-before.economy.gold,endSlot:end.slot,soldSlot:sold.slot,endStall:end.mods.festival.stall,
      beforeStock:before.supplies,endStock:end.supplies,location:api.fn('playerLocation')(end),pending:end.pendingEvent?.alert?.kind};
  `);
  assert.equal(stall.openedSlot-stall.beforeSlot,30);assert.equal(stall.stage,'open');assert.equal(stall.endSlot-stall.soldSlot,30);assert.equal(stall.endStall,null);assert.equal(stall.location,'taproom');
  for(const count of Object.values(stall.sold.stock))assert.ok(Number.isSafeInteger(count)&&count>=0);
  console.log('PASS stall opening, sales and return');
  const returned=await FestivalTest_평가하기(`
    FestivalTest_초기화하기(10,13);const api=WML.dev(),before=structuredClone(api.store.game());
    api.store.dispatch({type:'festival/open-stall',stock:{food:2,beer:2,wine:1}});
    const opened=structuredClone(api.store.game());api.store.dispatch({type:'festival/return'});
    const after=structuredClone(api.store.game());api.store.dispatch({type:'festival/return'});
    return {before:before.supplies,opened:opened.supplies,after:after.supplies,twice:api.store.game().supplies,
      beforeFood:before.supplies.food+before.readyFood,afterFood:after.supplies.food+after.readyFood,
      stage:opened.mods.festival.stall.stage,stock:opened.mods.festival.stall.stock,visitors:opened.mods.festival.stall.visitors,
      minutes:after.slot-before.slot};
  `);
  assert.equal(returned.afterFood,returned.beforeFood);assert.equal(returned.after.beer,returned.before.beer);assert.equal(returned.after.wine,returned.before.wine);
  assert.deepEqual(returned.twice,returned.after);assert.equal(returned.minutes,60);assert.equal(returned.visitors,0);
  assert.equal(returned.before.beer-returned.opened.beer,2);assert.equal(returned.before.wine-returned.opened.wine,1);
  console.log('PASS inventory deduction and one-time unsold return');
  const invalid=await FestivalTest_평가하기(`
    const results=[];for(const stock of [{food:-1},{food:1.5},{food:999999},{food:0},{beer:'not-a-number'}]){
      FestivalTest_초기화하기(10,13);const api=WML.dev(),before=structuredClone(api.store.game());
      api.store.dispatch({type:'festival/open-stall',stock});const after=api.store.game();
      results.push({same:JSON.stringify(before.supplies)===JSON.stringify(after.supplies)&&before.readyFood===after.readyFood,
        minutes:after.slot-before.slot,stall:after.mods.festival.stall});
    }return results;
  `);
  for(const result of invalid){assert.ok(result.same);assert.equal(result.minutes,0);assert.equal(result.stall,null);}
  console.log('PASS invalid stock rejected without inventory or time loss');
  const multipliers=await FestivalTest_평가하기(`
    FestivalTest_초기화하기(10,20);const api=WML.dev(),mod=__waywardFestival,rows=[];
    const stop=api.hook('normalVisitRoll',{priority:100,around(next,...args){rows.push(args);return next(...args);}});
    mod.setSettings({tavernMultiplier:2,stallMultiplier:3});api.fn('normalVisitRoll')(api.store.game().slot,50,0,50,4);
    const tavern=mod.getArrivalChance('tavern'),stall=mod.getArrivalChance('stall');
    mod.setSettings({tavernMultiplier:5,stallMultiplier:10});api.fn('normalVisitRoll')(api.store.game().slot,50,0,50,4);
    mod.setSettings({tavernMultiplier:0,stallMultiplier:50,intervalDays:999});const clamp=mod.getSettings();
    FestivalTest_초기화하기(10,20,'declined');api.fn('normalVisitRoll')(api.store.game().slot,50,0,50,4);
    stop();mod.setSettings({tavernMultiplier:2,stallMultiplier:3,intervalDays:30});
    return {incoming:rows.map(row=>row[4]),tavern,stall,clamp,
      full:api.fn('normalVisitRoll')(api.store.game().slot,100,8,100,999)};
  `);
  assert.deepEqual(multipliers.incoming,[8,20,4]);assert.equal(multipliers.tavern.chance,multipliers.tavern.base*2);
  assert.equal(multipliers.stall.chance,multipliers.stall.base*3);assert.equal(multipliers.clamp.tavernMultiplier,1);
  assert.equal(multipliers.clamp.stallMultiplier,10);assert.equal(multipliers.clamp.intervalDays,90);assert.equal(multipliers.full,false);
  console.log('PASS current chance multipliers, independent stall factor, range limits and pub capacity');
  const stallMultiplier=await FestivalTest_평가하기(`
    FestivalTest_초기화하기(10,20);const api=WML.dev(),mod=__waywardFestival,rows=[];
    api.store.update(state=>({...state,supplies:{food:100,beer:100,wine:100},readyFood:100}));
    api.store.dispatch({type:'festival/open-stall',stock:{food:2,beer:2,wine:1}});
    const stop=api.hook('normalVisitRoll',{priority:100,around(next,...args){rows.push(args);return false;}});
    const expected=mod.getArrivalChance('stall');FestivalTest_일분진행하기(1,false);stop();
    return {rows:rows.map(row=>({slot:row[0],service:row[1],renown:row[3],multiplier:row[4]})),expected,slot:api.store.game().slot};
  `);
  // 출장 판정은 같은 분의 주점 판정 뒤에 별도로 호출됩니다.
  assert.equal(stallMultiplier.rows.length,2);assert.ok(stallMultiplier.rows[1].multiplier>0);
  const arrival=stallMultiplier.rows[1];
  const expectedRatio=stallMultiplier.expected.base/(.03*(.4+arrival.service/100*1.1)*(.1+arrival.renown/100*1.4))*3;
  assert.ok(Math.abs(stallMultiplier.rows[1].multiplier-expectedRatio)<1e-10);
  console.log('PASS stall uses baseline ×3 while pub operates separately');
  const depletion=await FestivalTest_평가하기(`
    FestivalTest_초기화하기(10,20);const api=WML.dev();api.store.dispatch({type:'festival/open-stall',stock:{beer:1,wine:1}});
    const stop=api.hook('normalVisitRoll',{priority:100,around(){return true;}});
    FestivalTest_일분진행하기(5,false);stop();const data=__waywardFestival.getData(),state=api.store.game();
    api.store.update(current=>({...current,day:12,slot:11*1440+660,phase:'prep'}));
    const closing=__waywardFestival.getData().stall;api.store.dispatch({type:'festival/advance',minutes:30});
    return {stock:data.stall.stock,revenue:data.stall.revenue,visitors:data.stall.visitors,
      booked:state.incomeBreakdownToday.festival_stall,round:data.current.stallRevenue,total:data.totalStallRevenue,
      closing:closing.stage,remaining:closing.readyAtSlot-(11*1440+660),final:__waywardFestival.getData().stall};
  `);
  assert.deepEqual(depletion.stock,{food:0,readyFood:0,beer:0,wine:0});assert.equal(depletion.revenue,9);
  assert.equal(depletion.booked,9);assert.equal(depletion.round,9);assert.equal(depletion.total,9);assert.ok(depletion.visitors>=5);
  assert.equal(depletion.closing,'returning');assert.equal(depletion.remaining,30);assert.equal(depletion.final,null);
  console.log('PASS sold-out stock, once-only revenue and festival-end return');
  const awayReport=await FestivalTest_평가하기(`
    FestivalTest_초기화하기(10,13);const api=WML.dev();
    api.store.update(state=>({...state,awayEvents:[{slot:state.slot,text:'이전 외출 기록'}]}));
    api.store.dispatch({type:'festival/open-stall',stock:{beer:1}});
    api.store.update(state=>({...state,awayEvents:[...state.awayEvents,{slot:state.slot,text:'축제 외출 중 주점 기록'}]}));
    api.store.dispatch({type:'festival/return'});api.store.dispatch({type:'festival/return'});
    return {old:api.store.game().log.filter(item=>item.text==='이전 외출 기록').length,
      fresh:api.store.game().log.filter(item=>item.text==='축제 외출 중 주점 기록').length};
  `);
  assert.equal(awayReport.old,0);assert.equal(awayReport.fresh,1);
  console.log('PASS husband absence report added once on return');
  const schedules=await FestivalTest_평가하기(`
    const mod=__waywardFestival,results=[];for(const days of [10,90]){
      mod.setSettings({intervalMode:'fixed',intervalDays:days});FestivalTest_초기화하기(12,12);
      const round=mod.getData().current;results.push(round.festivalDay-10);
    }
    mod.setSettings({intervalMode:'random'});
    for(let step=0;step<60;step++){FestivalTest_초기화하기(12,12);results.push(mod.getData().current.festivalDay-10);}
    FestivalTest_초기화하기(10,13);const before=JSON.stringify(mod.getData().current);
    mod.setSettings({intervalMode:'fixed',intervalDays:40});const unchanged=before===JSON.stringify(mod.getData().current);
    mod.setSettings({intervalMode:'random',intervalDays:30});
    return {fixed:results.slice(0,2),random:results.slice(2),unchanged};
  `);
  assert.deepEqual(schedules.fixed,[10,90]);for(const days of schedules.random)assert.ok(days>=10&&days<=90);assert.ok(schedules.unchanged);
  console.log('PASS fixed/random repeat intervals and existing schedule preservation');
  const blocking=await FestivalTest_평가하기(`
    FestivalTest_초기화하기(8,16);const api=WML.dev();const slot=api.store.game().slot;
    api.store.dispatch({type:'go_to_bed_early'});const blocked=api.store.game().slot===slot;
    // 둘 다 다른 일에 묶였을 때는 선택을 보류해 진행이 막히지 않도록 합니다.
    api.store.update(state=>({...state,slot:7*1440+1020,activeScene:{patron:{playerEngaged:true}},
      characters:{...state.characters,[state.primaryCharacterId]:{...state.characters[state.primaryCharacterId],currentTask:'sleeping'}}}));
    const deferred=!api.store.game().pendingEvent;
    api.store.update(state=>({...state,activeScene:{},characters:{...state.characters,[state.primaryCharacterId]:{...state.characters[state.primaryCharacterId],currentTask:'idle'}}}));
    const shown=api.store.game().pendingEvent?.alert?.kind;
    api.store.dispatch({type:'resolve_event',choiceId:'skip'});const cannotSkip=api.store.game().pendingEvent?.alert?.kind;
    return {blocked,deferred,shown,cannotSkip};
  `);
  assert.ok(blocking.blocked);assert.ok(blocking.deferred);assert.equal(blocking.shown,'festival:help');assert.equal(blocking.cannotSkip,'festival:help');
  console.log('PASS mandatory preparation and deferral when both actors are busy');
  const interruption=await FestivalTest_평가하기(`
    FestivalTest_초기화하기(10,13);const api=WML.dev();
    const kind=api.events.onAlert('festival-test-interruption',(state)=>state);
    let ticks=0;const stop=api.hook('worldTick',{priority:100,after(result){ticks++;return ticks===10?api.events.alert(result,{kind,title:'시험 사건',body:'개점 중 선택',choices:[{id:'ok',label:'확인'}]}):result;}});
    api.store.dispatch({type:'festival/open-stall',stock:{beer:2}});stop();
    const paused=structuredClone(api.store.game());
    api.store.dispatch({type:'festival/return'});const returning=structuredClone(api.store.game());
    const saved=JSON.parse(JSON.stringify(returning));api.store.update(()=>saved);
    api.store.dispatch({type:'resolve_event',choiceId:'ok'});api.store.dispatch({type:'festival/advance',minutes:29});
    const beforeReturn=structuredClone(api.store.game());api.store.dispatch({type:'festival/advance',minutes:1});
    const final=api.store.game();
    return {paused:paused.slot-((10-1)*1440+780),opening:paused.mods.festival.stall.stage,
      ready:paused.mods.festival.stall.readyAtSlot-paused.slot,returnMinutes:returning.mods.festival.stall.readyAtSlot-returning.slot,
      remaining:beforeReturn.mods.festival.stall.readyAtSlot-beforeReturn.slot,final:final.mods.festival.stall,
      beer:final.supplies.beer,original:festivalTestBase.supplies.beer};
  `);
  assert.equal(interruption.paused,10);assert.equal(interruption.opening,'opening');assert.equal(interruption.ready,20);
  assert.equal(interruption.returnMinutes,30);assert.equal(interruption.remaining,1);assert.equal(interruption.final,null);assert.equal(interruption.beer,interruption.original);
  console.log('PASS interrupted opening, immediate cancellation and saved 30-minute return');
  if(integrated){
    const proposalCompatible=await FestivalTest_평가하기(`
      FestivalTest_초기화하기(1,13,'pending');const api=WML.dev();
      api.store.update(state=>({...state,mods:{...state.mods,'wife-view-mode':{...state.mods['wife-view-mode'],active:true}}}));
      const visited=__waywardFestival.visitMayor();await new Promise(resolve=>setTimeout(resolve,700));
      const meeting=structuredClone(api.store.game());api.store.dispatch({type:'resolve_event',choiceId:'withdraw'});
      return{visited,kind:meeting.pendingEvent?.alert?.kind,paused:meeting.mods['wife-view-mode'].active,
        restored:api.store.game().mods['wife-view-mode'].active,proposal:api.store.game().mods.festival.proposal};
    `);
    assert.ok(proposalCompatible.visited);assert.equal(proposalCompatible.kind,'festival:proposal');assert.equal(proposalCompatible.paused,false);
    assert.equal(proposalCompatible.restored,true);assert.equal(proposalCompatible.proposal,undefined);
    console.log('PASS mayor proposal awaits manual choice and restores wife-view on cancellation');
    const compatible=await FestivalTest_평가하기(`
      FestivalTest_초기화하기(8,16,'declined');const api=WML.dev();
      api.store.update(state=>({...state,mods:{...state.mods,'wife-view-mode':{...state.mods['wife-view-mode'],active:true},
        festival:{...state.mods.festival,current:{...state.mods.festival.current,participation:'pending',invitationQueued:false}}}}));
      await new Promise(resolve=>setTimeout(resolve,700));const invitation=structuredClone(api.store.game());
      api.store.dispatch({type:'resolve_event',choiceId:'accept'});const restored=api.store.game().mods['wife-view-mode'].active;
      api.store.update(state=>({...state,slot:7*1440+1020,phase:'service'}));
      const help=structuredClone(api.store.game());api.store.dispatch({type:'resolve_event',choiceId:'player'});
      const away=api.store.game().mods['wife-view-mode'].active;
      api.store.dispatch({type:'festival/advance',minutes:60});const returned=api.store.game().mods['wife-view-mode'].active;
      return {invitation:invitation.pendingEvent?.alert?.kind,paused:invitation.mods['wife-view-mode'].active,
        owners:invitation.mods['wife-view-mode'].portableCompatibility?.owners,restored,
        help:help.pendingEvent?.alert?.kind,away,returned};
    `);
    assert.equal(compatible.invitation,'festival:invitation');assert.equal(compatible.paused,false);
    assert.ok(compatible.owners.includes('festival-compatible-wife-view-mode'));assert.equal(compatible.restored,true);
    assert.equal(compatible.help,'festival:help');assert.equal(compatible.away,false);assert.equal(compatible.returned,true);
    console.log('PASS wife-view manual choices and prior mode restoration with pregnancy/delivery');
  }
  await FestivalTest_평가하기(`FestivalTest_초기화하기(10,17);__waywardFestival.openSettings();return true;`);
  const ui=await FestivalTest_평가하기(`
    await new Promise(resolve=>setTimeout(resolve,150));
    const settings=[...document.querySelectorAll('[data-festival-setting]')].map(input=>input.dataset.festivalSetting);
    const village=document.querySelector('[data-festival-button="open-stall"]');
    const villageSection=village?.parentElement.previousElementSibling?.textContent;village.click();
    const inputs=[...document.querySelectorAll('[data-festival-stock]')];inputs.find(input=>input.dataset.festivalStock==='beer').value=1;
    const button=[...document.querySelectorAll('button')].find(button=>button.textContent==='재고를 챙겨 개점하기 · 30분');
    button.click();await new Promise(resolve=>setTimeout(resolve,150));
    return {settings,villageSection,stockCount:inputs.length,stage:__waywardFestival.getData().stall?.stage,
      active:!!document.querySelector('[data-festival-active]'),horizontal:document.documentElement.scrollWidth<=innerWidth};
  `);
  assert.deepEqual(ui.settings,['tavernMultiplier','stallMultiplier','intervalMode','intervalDays']);assert.ok(ui.villageSection.includes('마을 둘러보기'));assert.equal(ui.stockCount,4);assert.equal(ui.stage,'open');assert.ok(ui.active);
  const shots=new URL('./shots/',import.meta.url);fs.mkdirSync(shots,{recursive:true});
  fs.writeFileSync(new URL((mobile?'mobile':'desktop')+(integrated?'-integrated':'-standalone')+'.jpg',shots),Buffer.from(await playScreenshot({fullPage:false}),'base64'));
  console.log('PASS settings and stock UI click; screenshot saved');
  const saved=await FestivalTest_평가하기(`
    const api=WML.dev(),mod=__waywardFestival;
    mod.setSettings({tavernMultiplier:4.2,stallMultiplier:7.5,intervalMode:'fixed',intervalDays:44});
    api.store.get().saveToSlot(0);const before=structuredClone(mod.getData()),slot=api.store.game().slot;
    api.store.dispatch({type:'festival/return'});api.store.get().loadFromSlot(0);
    return {before,after:mod.getData(),slot,location:api.fn('playerLocation')(api.store.game()),settings:mod.getSettings()};
  `);
  assert.deepEqual(saved.after,saved.before);assert.equal(saved.location,'village');
  const reloaded=await playReload({});assert.deepEqual(reloaded.failed,[]);
  const restored=await FestivalTest_평가하기(`
    const api=WML.dev(),mod=__waywardFestival,before=mod.getData(),slot=api.store.game().slot;
    const location=api.fn('playerLocation')(api.store.game()),settings=mod.getSettings();
    api.store.dispatch({type:'festival/return'});const after=api.store.game();
    return {before,slot,location,settings,minutes:after.slot-slot,stall:mod.getData().stall,home:api.fn('playerLocation')(after)};
  `);
  assert.deepEqual(restored.before,saved.before);assert.equal(restored.slot,saved.slot);assert.equal(restored.location,'village');
  assert.deepEqual(restored.settings,saved.settings);assert.equal(restored.minutes,30);assert.equal(restored.stall,null);assert.equal(restored.home,'taproom');
  console.log('PASS native save/load and browser reload retain stock, cash, stage, location, schedule and settings');
  const status=await playStatus();assert.deepEqual(status.failed,[]);assert.deepEqual(status.pageErrors,[]);
  console.log('PASS no browser errors');
}finally{await playStop();}
