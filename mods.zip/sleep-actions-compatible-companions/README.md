<!-- STABLE_PORT -->
## 2026-11-01 정식판 이식

모드 버전 **1.0.1**, 대상 게임 **2026-11-01**, WML **0.9.5**입니다. MCP 0.6.2로 연결을 검사합니다. 새 게임을 기준으로 하며 pre7 및 기존 저장 이전은 지원 범위에 포함하지 않습니다.

배포 파일: `sleep-actions-compatible-companions-1.0.1-20261101.zip`. 압축의 폴더 이름과 설치 ID는 `sleep-actions-compatible-companions`이며 `wml/mods/sleep-actions-compatible-companions/mod.js`로 설치합니다. WML 모드 관리자에서 ZIP 설치도 가능합니다. 아래의 pre7 버전·ZIP 안내는 이전 변경 기록입니다.
<!-- /STABLE_PORT -->

# 수면 행동 + 동료 UI 호환 1.0.0

제작: Hina_Lover. 원본 Sleep Actions 제작: 민트좋아, Companions 제작: Hina_Lover.
원본 파일과 원제작자·출처 표기는 수정하지 않습니다.

대상: 2026-10-24-pre7 / Sleep Actions 1.14.8 이상 / Companions 2.7.3 이상.

Companions의 ActionHost에 외부 ActionPanel 후처리가 추가한 자식 UI가 렌더링되지 않던 연결을 보완합니다. 누락된 자식을 원래 호스트 옆에서 한 번 표시하고, 동료 대화가 실제 표시되는 동안에는 숨깁니다. 다른 모드가 호스트를 감싸고 그 바깥에 UI를 추가하는 구성도 같은 표시 규칙을 적용합니다. 동료 대화 구독과 게임 상태 구독을 함께 사용하여 닫기·이동·대상 제거 뒤에도 표시를 갱신합니다. 외부 자식이 없는 패널에 새 버튼을 만들지 않으며 원본 컴포넌트 함수를 직접 호출하거나 게임 상태/행동을 다시 실행하지 않습니다.

설치: `sleep-actions-compatible-companions-1.0.0-pre7.zip`을 WML 모드 관리자에서 설치하고 활성화한 뒤 새로고침합니다. 원본 두 모드도 켜야 합니다. 게임의 mods.js를 직접 수정할 필요는 없습니다.

검증 명령: `node --import ./wml/mods/companions/tests/runtime.mjs wml/mods/sleep-actions-compatible-companions/tests/compatibility.mjs [--all] [--mobile]`.
시험은 격리 새 게임과 ZIP 설치를 사용합니다. 버튼 표시/중복·위치/깨어남 조건·동료 화면과 외부 UI 분리·재열기/재로딩을 확인하며 행동 내용/수면 규칙은 변경하지 않습니다. 실제 사용자 저장·실기 모바일·장기 플레이는 별도입니다.

2026-10-31 검증: 실제 ZIP 설치의 최소3모드·현재 통합54모드에서 PC/390px 각각10시나리오 통과. BadGuest 1.4.2 ZIP까지 설치한 통합55모드 PC도10시나리오 통과(`--all --badguest`). 남성/여성 원본 대화 열기·닫기/대상 이탈, 무관 사건, 슬롯 저장/불러오기와 주 인물/시간 불변 확인. 로드/페이지/호환 훅 오류0, 정적 오류0. 정적 검사의 mods.js 미등록 안내는 ZIP 설치로 등록·로드되는 방식과 구분합니다. 결과는 tests/result-*.json, 화면은 tests/preview-*.jpg입니다. BadGuest 사건/수면 행동의 내용별 전체 회귀는 이번 UI 호환 검증 범위에 포함하지 않습니다.
