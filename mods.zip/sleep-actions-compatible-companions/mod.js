// Compatibility by Hina_Lover. Sleep Actions: 민트좋아; Companions: Hina_Lover.
// Original mods and their author/source notices remain unchanged.
WML.define({
  id:'sleep-actions-compatible-companions',
  name:{ko:'수면 행동 + 동료 UI 호환',en:'Sleep Actions / Companions UI compatibility'},
  author:'Hina_Lover',version:"1.0.1",game:"2026-11-01",lang:'ko',tags:['util'],
  description:'동료 행동 패널에 다른 모드가 추가한 UI를 보존합니다.',
  requires:['sleep-actions','companions'],
  requiresVersion:{'sleep-actions':'>=1.14.8',companions:'>=2.7.3'},
  setup(api){
    const React=api.fn('React'),jsx=api.fn('jsx').jsx,people=api.use('companions');
    if(!people.subscribeDialogue||!people.dialogueTarget)throw Error('Companions를 최신 버전으로 갱신해 주세요.');
    function ExternalChildren({children}){
      const state=api.fn('store')(root=>root.state);
      const id=React.useSyncExternalStore(people.subscribeDialogue,people.dialogueTarget,people.dialogueTarget);
      const person=people.get(state,id);
      // Follow ActionHost's visibility test, including its deferred target cleanup.
      const shown=person&&(person.gender==='male'||person.nativeSession?.partner==='player')
        &&person.site===people.context(state).active&&person.room===api.fn('playerLocation')(state)
        &&person.room!=='town:transit'&&!people.blocked(state);
      return shown?null:children;
    }
    function visit(node){
      if(!React.isValidElement(node))return {node,host:false};
      if(node.type?.name==='ActionHost'&&typeof node.props.render==='function'&&Array.isArray(node.props.args)){
        if(React.Children.count(node.props.children)===0)return {node,host:true};
        return {host:true,node:jsx(React.Fragment,{children:[
          React.cloneElement(node,{children:undefined,key:'host'}),
          jsx(ExternalChildren,{children:node.props.children},'external'),
        ]},node.key||'sleep-companions-ui')};
      }
      if(!node.props.children)return {node,host:false};
      const branches=React.Children.toArray(node.props.children).map(visit);
      const host=branches.some(branch=>branch.host);
      if(!host)return {node,host:false};
      // Other mods can wrap ActionHost before Sleep Actions appends its UI.
      // Those sibling additions need the same dialogue visibility as hoisted UI.
      return {host,node:React.cloneElement(node,{},branches.map((branch,index)=>branch.host?branch.node:
        jsx(ExternalChildren,{children:branch.node},'external-'+index)))};
    }
    // Run after UI additions; never invoke a React component or replay a renderer.
    api.hook('ActionPanel',{priority:-5000000,after:tree=>visit(tree).node});
  }
});
