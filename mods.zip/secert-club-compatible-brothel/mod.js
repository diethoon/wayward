// 호환성 패치 기준: secert-club 1.3.0 / brothel 3.14.1 (개정 기준, 버전 번호에 따른 실행 제한 없음)
WML.define({
  tags: ["content","h-scene"],
  id: 'secert-club-compatible-brothel',
  author: "Hina_Lover",
  name: { ko: 'Secert Club with Brothel', en: 'Secert Club with Brothel' },
  version: "1.3.1",
  game: "2026-11-01",
  lang: 'ko',
  description: {
    ko: '비밀 클럽의 개장 조건·참여자·초대 관계·서비스를 창관의 고용 창부와 연결합니다.',
    en: 'Connects Secert Club eligibility, hosts, invitation relationships, and services to hired brothel workers.',
  },
  requires: ['secert-club', 'brothel'],
  requiresVersion: { 'secert-club': '>=1.3.0 <2', brothel: '>=3.14.1 <4' },
  setup(api) {
    const MOD_ID = 'secert-club-compatible-brothel';
    const OWNER = MOD_ID;
    const DEFAULT_SETTINGS = { serviceFeeMultiplier: 2 };
    const club = api.use('secert-club');
    const brothel = globalThis.__waywardBrothelPublic;
    if (!brothel || typeof brothel.workers !== 'function' || typeof brothel.assign !== 'function' || typeof brothel.service !== 'function'
      || typeof brothel.externalActivity !== 'function' || typeof brothel.endExternalActivity !== 'function') {
      throw new Error('Brothel 3.9.0 이상의 공개 연결 API를 찾지 못했습니다.');
    }
    // Native bath/drift and club serving must see an externally assigned club session as busy.
    api.hook('brothelCustomerBusy', { after(result, [state, customerId]) {
      const active = club.readData(state).active;
      if (result || active?.day !== state.day || !active?.guestIds?.includes(customerId)) return result;
      return Object.values(state.mods?.brothel?.assignments || {}).some(assignment => assignment.owner === OWNER
        && assignment.interaction?.customerId === customerId) || result;
    } });

    function SecertClubBrothel_수치제한하기(value, min, max) {
      const number = Number(value);
      return Math.max(min, Math.min(max, Number.isFinite(number) ? number : min));
    }

    function SecertClubBrothel_설정읽기() {
      return { ...DEFAULT_SETTINGS, ...api.settings.get(DEFAULT_SETTINGS) };
    }

    function SecertClubBrothel_자료읽기(state) {
      return { extraRevenue: 0, services: 0, ...(state?.mods?.[MOD_ID] || {}) };
    }

    function SecertClubBrothel_자료쓰기(state, patch) {
      return {
        ...state,
        mods: {
          ...(state.mods || {}),
          [MOD_ID]: { ...SecertClubBrothel_자료읽기(state), ...patch },
        },
      };
    }

    function SecertClubBrothel_참여형태에아내포함여부(participants) {
      return participants !== 'workers_only';
    }

    function SecertClubBrothel_참여형태에창부포함여부(participants) {
      return participants === 'wife_workers' || participants === 'workers_only';
    }

    function SecertClubBrothel_직원전체읽기(state) {
      try { return brothel.workers(state) || []; } catch { return []; }
    }

    function SecertClubBrothel_직원원본읽기(id) {
      return (brothel.getConfig?.()?.workers || []).find(worker => worker.id === id);
    }

    function SecertClubBrothel_관계점수읽기(relationship) {
      if (!relationship) return 10;
      const values = [relationship.platonic, relationship.romantic, relationship.sexual, relationship.affection, relationship.trust, relationship.intimacy].filter(Number.isFinite);
      if (!values.length) return SecertClubBrothel_수치제한하기(10 + (relationship.visitCount || 0) * 5 + (relationship.kindnessCount || 0) * 3, 0, 100);
      return SecertClubBrothel_수치제한하기(values.reduce((sum, value) => sum + value, 0) / values.length, 0, 100);
    }

    function SecertClubBrothel_직원손님점수읽기(state, record, worker, wifeScore) {
      const relationship = brothel.patronRelationship?.(state, worker.id, record.name);
      const relationshipScore = SecertClubBrothel_관계점수읽기(relationship);
      const settings = club.settings();
      const visitWeights = settings.visitWeights || {};
      const base = { intent: 0.4, openness: 0.1, boldness: 0.1, approach: 0.1, relationship: 0.3 };
      const components = { ...(wifeScore.components || {}), relationship: relationshipScore };
      let total = 0;
      let divisor = 0;
      for (const key of Object.keys(base)) {
        const weight = base[key] * SecertClubBrothel_수치제한하기(visitWeights[key] ?? 1, 0, 2);
        total += (components[key] || 0) * weight;
        divisor += weight;
      }
      const workerSource = SecertClubBrothel_직원원본읽기(worker.id);
      const affinityBonus = Math.max(0, Number(workerSource?.tendencies?.sociability) || 0) * 0.04 + Math.max(0, Number(workerSource?.tendencies?.flirtation) || 0) * 0.04;
      return {
        score: SecertClubBrothel_수치제한하기((divisor > 0 ? total / divisor : 0) + affinityBonus, 0, 100),
        components,
        hostName: worker.name,
      };
    }

    function SecertClubBrothel_초대점수읽기(state, record, participants, wifeScore) {
      const candidates = [];
      if (SecertClubBrothel_참여형태에아내포함여부(participants)) candidates.push(wifeScore);
      if (SecertClubBrothel_참여형태에창부포함여부(participants)) {
        for (const worker of SecertClubBrothel_직원전체읽기(state)) candidates.push(SecertClubBrothel_직원손님점수읽기(state, record, worker, wifeScore));
      }
      return candidates.sort((left, right) => right.score - left.score)[0] || wifeScore;
    }

    function SecertClubBrothel_배정가능직원읽기(state) {
      return SecertClubBrothel_직원전체읽기(state).filter(worker => {
        try { return !brothel.unavailable(state, worker.id); } catch { return false; }
      });
    }

    function SecertClubBrothel_개장준비하기(state, prepared) {
      if (!SecertClubBrothel_참여형태에창부포함여부(prepared.participants)) return { state, extensionData: { workerIds: [], nextInteractionSlot: state.slot, serviceIndex: 0, sessions: {} } };
      const workers = SecertClubBrothel_배정가능직원읽기(state);
      const ids = workers.map(worker => worker.id);
      let next = ids.length ? brothel.assign(state, ids, {
        owner: OWNER,
        location: prepared.venue,
        task: '비밀 클럽 접객',
        situation: '초대받은 손님을 상대로 비밀 클럽 서비스를 진행하고 있습니다.',
      }) : state;
      if (!ids.length) next = api.fn('log')(next, "[비밀 클럽 · 창관] 현재 배정할 수 있는 창부가 없어 그녀만 참여합니다.");
      else next = api.fn('log')(next, `[비밀 클럽 · 창관] ${workers.map(worker => worker.name).join(', ')}을(를) 클럽 접객에 배정했습니다.`);
      return { state: next, extensionData: { workerIds: ids, nextInteractionSlot: state.slot + 1, serviceIndex: 0, sessions: {} } };
    }

    function SecertClubBrothel_서비스단계읽기(state, customer, worker, index) {
      const source = SecertClubBrothel_직원원본읽기(worker?.id);
      const relationship = brothel.patronRelationship?.(state, worker?.id, customer?.name);
      const runtime = brothel.getRuntime?.()?.get(worker?.id);
      const fullContext = SecertClubBrothel_관계점수읽기(relationship) * 0.35
        + SecertClubBrothel_수치제한하기(customer?.boldness ?? customer?.attributes?.boldness ?? 50, 0, 100) * 0.2
        + SecertClubBrothel_수치제한하기(customer?.attributes?.openness ?? 50, 0, 100) * 0.15
        + SecertClubBrothel_수치제한하기(source?.tendencies?.libido ?? 50, 0, 100) * 0.15
        + SecertClubBrothel_수치제한하기(runtime?.stats?.arousal ?? source?.stats?.arousal ?? 0, 0, 100) * 0.15;
      const highService = fullContext >= club.relaxedThreshold(60);
      const paid = highService
        ? ['sex_patron', 'blowjob_patron', 'sex_patron', 'handjob_patron']
        : ['handjob_patron', 'blowjob_patron'];
      return ['flirting', 'light_touch', 'groping', paid[index % paid.length]];
    }

    function SecertClubBrothel_비공개장소읽기(state, active) {
      return active.venue;
    }

    function SecertClubBrothel_체력절반환급하기(workerId, beforeEnergy) {
      const runtime = brothel.getRuntime?.()?.get(workerId);
      if (!runtime?.stats || !Number.isFinite(beforeEnergy) || !Number.isFinite(runtime.stats.energy)) return 0;
      const spent = Math.max(0, beforeEnergy - runtime.stats.energy);
      if (spent <= 0) return 0;
      const refund = spent * 0.5;
      runtime.stats.energy = SecertClubBrothel_수치제한하기(runtime.stats.energy + refund, 0, 100);
      const configured = SecertClubBrothel_직원원본읽기(workerId);
      if (configured) configured.stats = { ...runtime.stats };
      brothel.saveConfig?.();
      return refund;
    }

    function SecertClubBrothel_할인체력비용읽기(workerId, stage) {
      const base = ({ chatting: 0, flirting: 0, light_touch: 1, bold_touch: 2, groping: 4, intimate: 7,
        handjob_patron: 10, blowjob_patron: 12, titfuck_patron: 12, sex_patron: 20 })[stage] ?? 0;
      if (base <= 0) return 0;
      const worker = SecertClubBrothel_직원원본읽기(workerId);
      const libidoMultiplier = SecertClubBrothel_수치제한하기(1.4 - SecertClubBrothel_수치제한하기(worker?.tendencies?.libido ?? 50, 0, 100) / 100, 0.55, 1.6);
      const pregnancyValue = Number(globalThis.__waywardBrothelPregnancy?.energyMultiplier?.(workerId) ?? 1);
      const pregnancyMultiplier = Number.isFinite(pregnancyValue) && pregnancyValue > 0 ? pregnancyValue : 1;
      return base * libidoMultiplier * pregnancyMultiplier * 0.5;
    }

    function SecertClubBrothel_할증정산하기(state, worker, customer, stage) {
      const baseFee = Math.max(1, Math.round(Number(brothel.fee(state, stage)) || 1));
      const multiplier = SecertClubBrothel_수치제한하기(SecertClubBrothel_설정읽기().serviceFeeMultiplier, 1, 10);
      const totalFee = Math.max(baseFee, Math.round(baseFee * multiplier));
      const beforeEnergy = Number(brothel.getRuntime?.()?.get(worker?.id)?.stats?.energy ?? worker?.energy);
      const discountedEnergy = worker ? SecertClubBrothel_할인체력비용읽기(worker.id, stage) : 0;
      if (!worker || (Number(customer.walletGold) || 0) < totalFee || beforeEnergy - discountedEnergy < 10) return { state, paid: false };
      let next = brothel.service(state, worker.id, customer, stage, { owner: OWNER });
      if (next === state) return { state, paid: false };
      SecertClubBrothel_체력절반환급하기(worker.id, beforeEnergy);
      const surcharge = Math.max(0, totalFee - baseFee);
      next = {
        ...next,
        customers: next.customers.map(item => item.id === customer.id ? { ...item, walletGold: Math.max(0, (Number(item.walletGold) || totalFee) - totalFee) } : item),
        economy: { ...next.economy, gold: (next.economy?.gold || 0) + surcharge },
        goldEarnedToday: (next.goldEarnedToday || 0) + surcharge,
        incomeBreakdownToday: { ...(next.incomeBreakdownToday || {}), secretClubBrothelSurcharge: ((next.incomeBreakdownToday || {}).secretClubBrothelSurcharge || 0) + surcharge },
      };
      const saved = SecertClubBrothel_자료읽기(next);
      next = SecertClubBrothel_자료쓰기(next, { extraRevenue: saved.extraRevenue + surcharge, services: saved.services + 1 });
      if (surcharge > 0) next = api.fn('log')(next, `[비밀 클럽 · 창관] ${customer.name}이(가) 비밀 영업 할증 ${surcharge}골드를 추가로 냅니다. 총 서비스 요금 ${totalFee}골드(${multiplier}배).`);
      return { state: next, paid: true };
    }

    function SecertClubBrothel_직원서비스진행하기(state, active) {
      const data = active.extensionData || { workerIds: [], nextInteractionSlot: state.slot, serviceIndex: 0, sessions: {} };
      if (!SecertClubBrothel_참여형태에창부포함여부(active.participants) || !data.workerIds?.length) return { state, extensionData: data };
      const ejected = new Set(active.ejected || []);
      const guests = (state.customers || []).filter(customer => (active.guestIds || []).includes(customer.id) && !ejected.has(customer.id) && customer.status !== 'gone' && customer.status !== 'leaving');
      let next = state;
      const nextData = { ...data, sessions: { ...(data.sessions || {}) } };
      for (const [workerId, savedSession] of Object.entries(nextData.sessions)) {
        let session = savedSession;
        const customer = next.customers.find(item => item.id === session.customerId);
        if (!customer || ejected.has(session.customerId) || ['gone', 'leaving'].includes(customer.status)) {
          next = brothel.endExternalActivity(next, workerId, { owner: OWNER, returnLocation: active.venue, location: active.venue });
          delete nextData.sessions[workerId];
          continue;
        }
        // Restore an off-site 1.1.0 session without restarting or charging it again.
        if (session.room !== active.venue || (session.privateRoom && session.privateRoom !== active.venue)) {
          next = brothel.externalActivity(next, workerId, customer, session.stages?.[session.index], {
            owner: OWNER, location: active.venue, untilSlot: session.endsAtSlot });
          session = { ...session, room: active.venue, privateRoom: active.venue };
          nextData.sessions[workerId] = session;
        }
        if (state.slot < session.endsAtSlot) continue;
        const sessionWorker = SecertClubBrothel_직원전체읽기(next).find(item => item.id === workerId);
        const stages = session.stages || SecertClubBrothel_서비스단계읽기(next, customer, sessionWorker, nextData.serviceIndex || 0);
        const index = session.index + 1;
        if (index >= stages.length) {
          next = brothel.endExternalActivity(next, workerId, { owner: OWNER, returnLocation: active.venue, location: active.venue,
            situation: `${customer.name}과(와)의 비밀 클럽 접객을 마치고 다음 손님을 찾고 있습니다.` });
          next = api.fn('log')(next, `[비밀 클럽 · 창관] ${SecertClubBrothel_직원전체읽기(next).find(item => item.id === workerId)?.name || '창부'}이(가) ${customer.name}과(와)의 접객을 마치고 클럽에서 다음 손님을 기다립니다.`);
          delete nextData.sessions[workerId];
          continue;
        }
        const stage = stages[index];
        const room = SecertClubBrothel_비공개장소읽기(next, active);
        const worker = SecertClubBrothel_직원전체읽기(next).find(item => item.id === workerId);
        if (stage.endsWith('_patron') || ['groping', 'intimate'].includes(stage)) {
          const paid = SecertClubBrothel_할증정산하기(next, worker, customer, stage);
          next = paid.state;
        }
        const endsAtSlot = state.slot + (index >= 2 ? 8 : 6);
        next = brothel.externalActivity(next, workerId, customer, stage, { owner: OWNER, location: room, untilSlot: endsAtSlot,
          situation: `${room === active.venue ? '클럽' : '비공개 공간'}에서 ${customer.name}과(와) ${stage === 'flirting' ? '추파와 농담' : stage === 'light_touch' ? '가벼운 접촉' : stage === 'groping' ? '짙은 스킨십' : '성적 서비스'} 중입니다.` });
        nextData.sessions[workerId] = { ...session, stages, index, room, privateRoom: index >= 2 ? room : session.privateRoom, endsAtSlot };
      }
      if (state.slot >= (nextData.nextInteractionSlot || 0) && guests.length) {
        const busyGuests = new Set(Object.values(nextData.sessions).map(session => session.customerId));
        const freeWorkers = data.workerIds.filter(id => !nextData.sessions[id]);
        let offset = 0;
        for (const workerId of freeWorkers) {
          const customer = guests.find((item, guestIndex) => !busyGuests.has(item.id) && (guestIndex + offset) % guests.length >= 0);
          if (!customer) break;
          const worker = SecertClubBrothel_직원전체읽기(next).find(item => item.id === workerId);
          const stages = SecertClubBrothel_서비스단계읽기(next, customer, worker, nextData.serviceIndex || 0);
          const endsAtSlot = state.slot + 6;
          next = brothel.externalActivity(next, workerId, customer, stages[0], { owner: OWNER, location: active.venue, untilSlot: endsAtSlot,
            situation: `${customer.name}에게 먼저 다가가 추파와 농담을 건네고 있습니다.` });
          next = api.fn('log')(next, `[비밀 클럽 · 창관] ${SecertClubBrothel_직원전체읽기(next).find(item => item.id === workerId)?.name || '창부'}이(가) 먼저 ${customer.name} 곁에 앉아 평소처럼 유혹을 시작합니다.`);
          nextData.sessions[workerId] = { workerId, customerId: customer.id, stages, index: 0, room: active.venue, privateRoom: null, endsAtSlot };
          nextData.serviceIndex = (nextData.serviceIndex || 0) + 1;
          busyGuests.add(customer.id);offset++;
        }
        nextData.nextInteractionSlot = state.slot + 10;
      }
      return { state: next, extensionData: nextData };
    }

    function SecertClubBrothel_영업종료하기(state) {
      let next = state;
      for (const worker of SecertClubBrothel_직원전체읽기(next)) next = brothel.endExternalActivity(next, worker.id, { owner: OWNER });
      return brothel.release(next, OWNER);
    }

    function SecertClubBrothel_요소만들기(tag, props, ...children) {
      return api.ui.h(tag, props || {}, ...children);
    }

    function SecertClubBrothel_설정창그리기(body) {
      const settings = SecertClubBrothel_설정읽기();
      body.textContent = '';
      body.dataset.wmlUi = 'true';
      body.style.cssText = 'display:flex;flex-direction:column;gap:12px;color:#eee;';
      body.append(
        SecertClubBrothel_요소만들기('p', { class: 'wml-note' }, "창부가 한 명 이상 고용되어 있으면 그녀 점수와 관계없이 비밀 클럽을 준비할 수 있습니다."),
      );
      const row = SecertClubBrothel_요소만들기('label', { style: 'display:grid;grid-template-columns:1fr 120px;gap:10px;align-items:center;' });
      const title = SecertClubBrothel_요소만들기('span', {}, '서비스 요금 배수', SecertClubBrothel_요소만들기('small', { class: 'wml-muted', style: 'display:block;' }, "창부 서비스와 그녀의 비밀 클럽 서비스에 적용합니다. 기본 2배."));
      const input = SecertClubBrothel_요소만들기('input', { type: 'number', min: 1, max: 10, step: 0.1, value: settings.serviceFeeMultiplier, style: 'width:100%;background:#16120f;color:#fff;border:1px solid #6c573d;border-radius:4px;padding:5px;' });
      input.addEventListener('change', () => {
        const value = SecertClubBrothel_수치제한하기(input.value, 1, 10);
        input.value = String(value);
        api.settings.set({ serviceFeeMultiplier: value });
      });
      row.append(title, input);
      body.append(row);
      const state = api.store.game();
      if (state) {
        const data = SecertClubBrothel_자료읽기(state);
        body.append(SecertClubBrothel_요소만들기('p', { class: 'wml-muted' }, `누적 호환 서비스 ${data.services}건 · 비밀 영업 할증 수입 ${data.extraRevenue}골드`));
      }
    }

    club.registerCompatibility({
      id: MOD_ID,
      eligible: state => SecertClubBrothel_직원전체읽기(state).length >= 1,
      participantChoices: state => [
        { id: 'wife_workers', label: "그녀, 창부 모두 참여", description: `고용 창부 ${SecertClubBrothel_직원전체읽기(state).length}명과 그녀가 함께 접객합니다.` },
        { id: 'wife_only', label: "그녀만 참여", description: "창부를 배정하지 않고 그녀만 접객합니다." },
        { id: 'workers_only', label: '창부만 참여', description: "그녀는 참여하지 않고 고용 창부만 접객합니다." },
      ],
      guestScore: SecertClubBrothel_초대점수읽기,
      beforeOpen: SecertClubBrothel_개장준비하기,
      onTick: SecertClubBrothel_직원서비스진행하기,
      afterClose: SecertClubBrothel_영업종료하기,
      feeMultiplier: () => SecertClubBrothel_설정읽기().serviceFeeMultiplier,
      renderSettings: SecertClubBrothel_설정창그리기,
    });
  },
});
