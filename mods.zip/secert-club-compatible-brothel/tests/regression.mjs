// 실행: node wml/mods/secert-club-compatible-brothel/tests/regression.mjs
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { playStart, playEval, playReload, playStatus, shutdown } from '../../../../MCP/lib/play.mjs';
import { checkMod } from '../../../../MCP/lib/check.mjs';

const ids = ['addon-compat', 'brothel', 'secert-club', 'secert-club-compatible-brothel'];
const evaluate = async code => (await playEval({ code })).result;

try {
  for (const id of ids.slice(1)) assert.ok(checkMod(id).ok, id);
  const mods = Object.fromEntries(fs.readdirSync(new URL('../../', import.meta.url), { withFileTypes: true }).filter(entry => entry.isDirectory()).map(entry => [entry.name, ids.includes(entry.name)]));
  await playStart({ mods });
  await evaluate(`localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify(ids)}));return true;`);
  if (process.argv.includes('--zip')) {
    const version=fs.readFileSync('wml/mods/secert-club-compatible-brothel/mod.js','utf8').match(/version:\s*['"]([^'"]+)/)[1];
    const installed = await evaluate(`return WML.install([{path:'secert-club-compatible-brothel-${version}-20261101.zip',blob:await(await fetch('wml/mods/secert-club-compatible-brothel/secert-club-compatible-brothel-${version}-20261101.zip')).blob()}]);`);
    assert.equal(installed[0].version, version);
  }
  const loaded = await playReload({});
  assert.deepEqual(loaded.failed, []);
  for (const id of ids) assert.ok(loaded.loaded.includes(id), id);

  const result = await evaluate(`
    let clubSeed=1138;Math.random=()=>{clubSeed=(Math.imul(clubSeed,1664525)+1013904223)>>>0;return clubSeed/4294967296;};
    for(let step=0;step<30;step++){
      if(document.querySelector('button[title="메뉴"]'))break;
      const buttons=[...document.querySelectorAll('button')].filter(button=>button.offsetParent);
      const button=buttons.find(item=>!item.disabled&&/^(예$|이해하고 동의합니다$|새 게임$|계속하기 —|시작 —|시작하기$|건너뛰기$)/.test(item.innerText.trim()))||buttons.find(item=>item.innerText.trim().startsWith('마라'));
      if(!button)throw Error('새 게임 버튼 없음');button.click();await new Promise(resolve=>setTimeout(resolve,100));
    }
    const api=WML.dev(),brothel=__waywardBrothelPublic,club=__waywardSecertClubPublic;
    const config=brothel.getConfig();config.enabled=true;config.allowTaproomSex=false;
    config.workers.forEach((worker,index)=>{worker.enabled=index<2;worker.stats.energy=100;worker.stats.arousal=100;worker.tendencies.libido=100;worker.lastFullRestDay=10;});
    brothel.getRuntime().clear();brothel.saveConfig();
    api.store.update(current=>{
      const state=structuredClone(current);state.day=10;state.slot=9*1440+17*60;state.phase='service';
      state.pendingEvent=undefined;state.alertQueue=[];state.activeScene={};state.customers=[];state.patronRecords=[
        {name:'초대 손님 A',patronType:'regular',intent:'interested',boldness:80,charm:70,platonic:60,romantic:30,sexual:20,visitCount:4},
        {name:'초대 손님 B',patronType:'noble',intent:'predatory',boldness:90,charm:75,platonic:65,romantic:35,sexual:25,visitCount:5}
      ];
      state.tavern={...state.tavern,backRoomReady:true,hasRoom:true,hasRoom2:true,hasBathhouse:true,tonightRenter:null,tonightRenter2:null};
      state.economy={...state.economy,gold:100};state.mods={...state.mods,brothel:{assignments:{},playerSession:null,relationships:{},playerHistory:[]}};
      for(const room of Object.values(state.locations))room.occupants=[];
      state.locations.taproom.occupants=['player',state.primaryCharacterId];
      return club.writeData(state,{unlocked:true,prepared:{day:10,venue:'taproom',participants:'workers_only',approved:[{name:'초대 손님 A'},{name:'초대 손님 B'}]}});
    });
    globalThis.clubBrothelFixture=structuredClone(api.store.game());
    api.store.update(state=>club.openClub(state));
    function advance(minutes){for(let minute=0;minute<minutes;minute++)api.store.update(state=>api.fn('worldTick')(state,{playerPresent:true}));return api.store.game()}
    let state=advance(2),active=state.mods['secert-club'].active,workerId=active.extensionData.workerIds[0];
    const first={stage:state.mods.brothel.assignments[workerId]?.interaction?.stage,portrait:brothel.portrait(state,workerId),task:brothel.workers(state).find(item=>item.id===workerId)?.task};
    state=advance(13);active=state.mods['secert-club'].active;
    const middle={stage:state.mods.brothel.assignments[workerId]?.interaction?.stage,room:state.mods.brothel.assignments[workerId]?.location,portrait:brothel.portrait(state,workerId)};
    state=advance(10);active=state.mods['secert-club'].active;
    const final={stage:state.mods.brothel.assignments[workerId]?.interaction?.stage,
      energy:brothel.workers(state).find(item=>item.id===workerId)?.energy};
    return{first,middle,services:state.mods['secert-club-compatible-brothel']?.services||0,
      final,sessions:Object.keys(active.extensionData.sessions),logs:state.log.slice(-80).map(item=>item.text),errors:[]};
  `);
  assert.equal(result.first.stage, 'flirting');
  assert.equal(result.first.task, 'interaction');
  assert.ok(result.first.portrait);
  assert.ok(['groping', 'handjob_patron', 'blowjob_patron', 'sex_patron'].includes(result.middle.stage), result.middle.stage);
  assert.equal(result.middle.room, 'taproom');
  assert.ok(result.middle.portrait);
  assert.notEqual(result.middle.portrait, result.first.portrait);
  assert.ok(result.services > 0);
  assert.equal(result.final.stage, 'sex_patron');
  assert.ok(Math.abs(result.final.energy-93.4)<0.001, JSON.stringify(result.final));
  assert.ok(result.logs.some(text => text.includes('평소처럼 유혹을 시작')));
  assert.ok(!result.logs.some(text => text.includes('데려갑니다')));
  const venues = await evaluate(`
    const api=WML.dev(),club=__waywardSecertClubPublic,brothel=__waywardBrothelPublic,out=[];
    for(const venue of Array.from({length:10},()=>['taproom','back_room','upstairs_hall','upstairs_room_2','bathhouse']).flat()){
      brothel.getRuntime().clear();
      const config=brothel.getConfig();config.workers.forEach(worker=>{worker.stats.energy=100;worker.lastFullRestDay=10;});
      let s=structuredClone(clubBrothelFixture);s.mods['secert-club'].prepared.venue=venue;
      api.store.update(()=>club.openClub(s));
      let escaped=false;const movements=[];
      for(let minute=0;minute<18;minute++){
        api.store.update(state=>api.fn('worldTick')(state,{playerPresent:true}));
        const state=api.store.game(),active=club.readData(state).active;
        for(const id of active.extensionData.workerIds){
          const assignment=state.mods.brothel.assignments[id];
          if(assignment.location!==venue){escaped=true;movements.push({minute,id,worker:assignment.location});}
          if(assignment.interaction&&api.fn('getCustomerLocation')(state,assignment.interaction.customerId)!==venue){escaped=true;
            movements.push({minute,id,stage:assignment.interaction.stage,customer:api.fn('getCustomerLocation')(state,assignment.interaction.customerId),logs:state.log.slice(-3).map(item=>item.text)});}
        }
      }
      s=api.store.game();const active=club.readData(s).active,workerId=active.extensionData.workerIds[0];
      const session=active.extensionData.sessions[workerId];
      const before={index:session.index,ends:session.endsAtSlot,services:s.mods['secert-club-compatible-brothel']?.services||0};
      const oldRoom=venue==='back_room'?'bathroom':'back_room';
      let old=brothel.externalActivity(s,workerId,s.customers.find(c=>c.id===session.customerId),session.stages[session.index],{
        owner:'secert-club-compatible-brothel',location:oldRoom,untilSlot:session.endsAtSlot});
      old=club.writeData(old,{active:{...active,extensionData:{...active.extensionData,sessions:{...active.extensionData.sessions,
        [workerId]:{...session,room:oldRoom,privateRoom:oldRoom}}}}});
      // An unrelated custom action invokes club progression without advancing the stage clock.
      api.store.update(()=>api.fn('reduceGameAction')(old,{type:'privacy-test/noop'}));
      const migrated=api.store.game(),current=club.readData(migrated).active.extensionData.sessions[workerId];
      out.push({venue,escaped,movements,outsiders:migrated.customers.filter(c=>!active.guestIds.includes(c.id)&&!['gone','leaving'].includes(c.status)).length,
        stage:migrated.mods.brothel.assignments[workerId]?.interaction?.stage,
        room:migrated.mods.brothel.assignments[workerId]?.location,customerRoom:api.fn('getCustomerLocation')(migrated,session.customerId),
        before,after:{index:current.index,ends:current.endsAtSlot,services:migrated.mods['secert-club-compatible-brothel']?.services||0}});
    }return out;
  `);
  for (const row of venues) {
    assert.ok(!row.escaped, JSON.stringify(row));
    assert.equal(row.outsiders, 0, row.venue);
    assert.equal(row.room, row.venue);assert.equal(row.customerRoom, row.venue);
    assert.deepEqual(row.after, row.before, row.venue);
    assert.ok(row.stage);
  }
  const floor = await evaluate(`
    const api=WML.dev(),club=__waywardSecertClubPublic,brothel=__waywardBrothelPublic,config=brothel.getConfig();
    config.workers.forEach((worker,index)=>{worker.enabled=index===0;worker.stats.energy=15;worker.stats.arousal=100;worker.tendencies.libido=100;worker.lastFullRestDay=10;});
    brothel.getRuntime().clear();brothel.saveConfig();api.store.update(()=>club.openClub(structuredClone(clubBrothelFixture)));
    for(let minute=0;minute<25;minute++)api.store.update(state=>api.fn('worldTick')(state,{playerPresent:true}));
    const state=api.store.game(),active=club.readData(state).active,id=active.extensionData.workerIds[0];
    return{energy:brothel.workers(state).find(worker=>worker.id===id).energy,
      stage:state.mods.brothel.assignments[id].interaction.stage,services:state.mods['secert-club-compatible-brothel'].services};
  `);
  assert.equal(floor.stage, 'sex_patron');
  assert.equal(floor.services, 1);
  assert.ok(Math.abs(floor.energy-13.9)<0.001, JSON.stringify(floor));
  const status = await playStatus({});
  assert.deepEqual(status.pageErrors, []);
  console.log('PASS staged flirting, selected-venue retention, changing portrait and paid secret-club service');
  console.log('PASS 50% actual energy cost and post-service rest floor');
  console.log('PASS 50 venue runs (seed 1138), busy guest retention, no uninvited guests, old-session migration without stage reset or duplicate fees');
} finally {
  await shutdown();
}
