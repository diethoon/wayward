// node --import ./wml/mods/companions/tests/runtime.mjs wml/mods/secert-club-compatible-companions/tests/integration.mjs [--mobile] [--zip] [--without-brothel]
// Only a fresh MCP browser context is used. GPU/external requests are blocked by MCP.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {playStart,playEval,playReload,playStatus,playScreenshot,shutdown} from '../../../../MCP/lib/play.mjs';
import {checkMod} from '../../../../MCP/lib/check.mjs';
const ID='secert-club-compatible-companions',mobile=process.argv.includes('--mobile'),zip=process.argv.includes('--zip'),core=process.argv.includes('--without-brothel');
const tag=(mobile?'mobile':'desktop')+(core?'-core':'-all')+(zip?'-zip':'');
const report={tag,cases:[]},root=new URL('./',import.meta.url);
async function run(code){const r=await playEval({code,timeoutMs:30000});assert.ok(!r.error,JSON.stringify(r));assert.equal(r.pageErrorsSoFar,0,JSON.stringify(r));return r.result;}
async function check(name,code){const result=await run(code);console.log(name,JSON.stringify(result));report.cases.push({name,result});assert.ok(result&&Object.values(result).every(v=>v===true),JSON.stringify(result));}
try{
  const changed=[ID,'brothel-compatible-h-status','brothel-compatible-pregnancy'];
  for(const id of changed){const c=checkMod(id);assert.ok(c.ok,JSON.stringify(c));}
  const mods=core?Object.fromEntries(fs.readdirSync('wml/mods',{withFileTypes:true}).filter(e=>e.isDirectory()).map(e=>[e.name,['addon-compat','companions','secert-club',ID].includes(e.name)])):{};
  const first=await playStart({mods,fresh:true,viewport:mobile?{width:390,height:844}:{width:1440,height:1000}});
  const ids=[...first.loaded,ID];
  await run(`localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify(ids)}));localStorage.setItem('wml.toggles',JSON.stringify({...JSON.parse(localStorage.getItem('wml.toggles')||'{}'),'${ID}':true}));return true;`);
  if(zip){
    const installIds=core?['secert-club',ID]:['secert-club','secert-club-compatible-brothel',...changed];
    const packages=installIds.map(id=>({id,version:fs.readFileSync('wml/mods/'+id+'/mod.js','utf8').match(/version:\s*['"]([^'"]+)/)[1]}));
    const installed=await run(`const packages=${JSON.stringify(packages)},append=document.head.appendChild;
      document.head.appendChild=function(node){if(node.tagName==='SCRIPT'&&packages.some(p=>node.src.endsWith('/wml/mods/'+p.id+'/mod.js'))){queueMicrotask(()=>node.dispatchEvent(new Event('error')));return node;}return append.call(this,node);};
      try{return (await WML.install(await Promise.all(packages.map(async p=>({path:p.id+'.zip',blob:await(await fetch('wml/mods/'+p.id+'/'+p.id+'-'+p.version+'-20261101.zip')).blob()}))))).map(p=>({id:p.id,version:p.version,mode:p.mode}));}
      finally{document.head.appendChild=append;}`);
    assert.equal(installed.length,installIds.length);assert.ok(installed.every(p=>p.mode==='browser'));report.installed=installed;
  }
  const loaded=await playReload({});assert.deepEqual(loaded.failed,[]);assert.ok(loaded.loaded.includes(ID));report.loaded=loaded.loaded;
  await run(`let initialSeed=1138;Math.random=()=>{initialSeed=(Math.imul(initialSeed,1664525)+1013904223)>>>0;return initialSeed/4294967296};
    globalThis.d=WML.dev();globalThis.v=WML.use('companions');globalThis.club=WML.use('secert-club');globalThis.patch=WML.use('${ID}');
    d.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true});d.store.get().newGame();
    d.fn('store').setState({started:true,selectingArchetype:false,selectingBuilder:false,selectingPicks:false});
    globalThis.__waywardSituationEventMod?.setSettings({enabled:false,pokerEnabled:false,outingEnabled:false});
    d.store.update(s=>({...s,day:3,slot:2*1440+16*60,phase:'prep',brothelAddonCampaignVersion:1,pendingEvent:undefined,alertQueue:[],activeScene:{},gameOver:false,
      economy:{...s.economy,gold:30000,debt:0},customers:[],patronRecords:[{name:'초대 손님 A',patronType:'regular',intent:'interested',boldness:60,charm:70,platonic:100,romantic:50,sexual:50,visitCount:10}],
      tavern:{...s.tavern,hasBathhouse:true,backRoomReady:true,hasRoom:true,hasRoom2:true},
      locations:Object.fromEntries(Object.entries(s.locations).map(([key,row])=>[key,{...row,occupants:key==='taproom'?['player',s.primaryCharacterId]:[]}]))}));
    for(const [gender,name]of [['female','참가 여성'],['male','참가 남성'],['female','선택 제외']])d.store.dispatch({type:'companions/hire',options:{gender,name,relationType:'childhood_friend',employed:false}});
    globalThis.personIds=v.list(d.store.game()).map(p=>p.id);
    d.store.update(s=>{let n=club.writeData(s,{unlocked:true});for(const p of v.list(n))n=v.save(n,{...p,room:'taproom',energy:100,mood:90,readyAt:n.slot,
      character:{...p.character,stats:{...p.character.stats,energy:100,mood:90,arousal:80},attributes:{...p.character.attributes,openness:100,confidence:100}}});return n;});
    const b=globalThis.__waywardBrothelPublic;if(b){b.getConfig().enabled=false;for(const w of b.getConfig().workers)w.enabled=false;b.saveConfig();}
    let seed=1138;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
    globalThis.fixture=structuredClone(d.store.game());globalThis.restore=()=>d.store.update(()=>structuredClone(fixture));
    if(personIds.length!==3)throw Error(JSON.stringify({ids:personIds,log:d.store.game().log.slice(-6),event:d.store.game().pendingEvent}));return true;`);
  await check('optional Brothel adapter coexists or standalone bridge registers',`return{registered:patch.bridge===${JSON.stringify(core?ID:'secert-club-compatible-brothel')},male:v.list(d.store.game()).some(p=>p.gender==='male')};`);
  await check('preparation defaults all; individual choice survives preparation redraw',`club.openPreparation();await new Promise(r=>setTimeout(r,80));
    let inputs=[...document.querySelectorAll('[data-club-companion]')];const defaults=inputs.length===3&&inputs.every(n=>n.checked);
    inputs[2].click();const off=!patch.selected(d.store.game()).includes(personIds[2]);
    const button=[...document.querySelectorAll('button')].find(b=>b.textContent==='직접 고르기');button.click();await new Promise(r=>setTimeout(r,80));
    return{defaults,off,persists:document.querySelector('[data-club-companion="'+personIds[2]+'"]').checked===false};`);
  fs.writeFileSync(new URL('preparation-'+tag+'.jpg',root),Buffer.from(await playScreenshot({}),'base64'));
  await check('actual open enrolls selected men and women without roster identity changes',`
    d.store.dispatch({type:'secert-club/prepare',venue:'taproom',method:'direct',invited:['초대 손님 A'],participants:'wife_only'});
    d.store.update(s=>{const data=club.readData(s);return club.writeData({...s,phase:'service'}, {prepared:{...data.prepared,approved:[{name:'초대 손님 A'}]}});});
    const before=d.store.game(),main=before.primaryCharacterId,keys=JSON.stringify(Object.keys(before.characters));
    d.store.update(s=>club.openClub(s));const s=d.store.game(),own=patch.read(s),live=club.readData(s).active;
    globalThis.clubFixture=structuredClone(s);globalThis.guestId=live.guestIds[0];
    return{two:own.active.ids.length===2,selected:personIds.slice(0,2).every(id=>own.active.ids.includes(id)),excluded:!own.active.ids.includes(personIds[2]),
      male:v.get(s,personIds[1]).room==='taproom',guest:!!patch.guestActor(s,guestId),identity:s.primaryCharacterId===main&&JSON.stringify(Object.keys(s.characters))===keys,
      noEmployment:v.list(s).every(p=>!p.employed),noBrothel:!globalThis.__waywardBrothelPublic||!__waywardBrothelPublic.getConfig().workers.some(w=>w.enabled)};`);
  await check('0/50/100 relaxation scales base and companion action thresholds',`
    [...document.querySelectorAll('.wml-win')].forEach(win=>win.querySelector('.wml-win-close')?.click());
    const settingsButton=[...document.querySelectorAll('.wml-dock button')].find(button=>button.textContent==='비밀 클럽');
    if(!settingsButton)throw Error('비밀 클럽 설정 버튼 없음');settingsButton.click();
    const input=document.querySelector('[data-secert-club-acceptance-relaxation] input');if(!input)throw Error('완화율 입력 없음');
    const set=value=>{input.value=String(value);input.dispatchEvent(new Event('change',{bubbles:true}));return patch.thresholds();};
    const zero=set(0),half=set(50),full=set(100),s=structuredClone(clubFixture),wife=d.fn('wife')(s);
    const category=Object.keys(wife.latitude?.byCategory||{})[0]||'sex';
    const context={kind:'patron_request',activeCustomerId:guestId,characterId:s.primaryCharacterId,comfortWithPatron:0,isReturning:false,pressureLevel:0};
    set(0);const original=d.fn('evaluateIntimacy')(s,category,context);
    set(50);const relaxed=d.fn('evaluateIntimacy')(s,category,context);
    set(100);const all=d.fn('evaluateIntimacy')(s,category,context),outsider=d.fn('evaluateIntimacy')(s,category,{...context,activeCustomerId:'not-invited'});
    set(50);document.querySelector('[data-secert-club-settings] .wml-win-close')?.click();
    return{zero:zero.flirtLike===8&&zero.kissLike===20&&zero.privateLike===30,
      half:half.flirtLike===4&&half.kissLike===10&&half.kissHeart===5&&half.privateLike===15&&half.privateHeart===5,
      full:Object.values(full).every(value=>value===0),base:Number.isFinite(original.threshold)&&original.threshold>0&&relaxed.threshold===original.threshold/2&&all.threshold===0,
      invitedOnly:outsider.threshold===original.threshold,saved:club.settings().femaleAcceptanceRelaxation===50};`);
  await check('female initiative opportunity rotates between eligible women',`
    let s=structuredClone(clubFixture);
    function ready(state){let next=state;for(const id of [...patch.read(next).active.ids,v.mainId(next)]){const p=v.actor(next,id);if(p)next=v.saveActor(next,{...p,readyAt:next.slot,nativeSession:null,interaction:null});}return next;}
    s={...s,mods:{...s.mods,'${ID}':{...patch.read(s),active:{...patch.read(s).active,nextSocialSlot:s.slot,initiativeCursor:0}}}};s=ready(s);s=patch.tick(s);
    const first=patch.read(s).active.lastInitiatorId;s={...s,slot:s.slot+50};s=ready(s);s={...s,mods:{...s.mods,'${ID}':{...patch.read(s),active:{...patch.read(s).active,nextSocialSlot:s.slot}}}};s=patch.tick(s);
    const second=patch.read(s).active.lastInitiatorId;return{first:!!first,second:!!second,rotated:first!==second,
      female:[first,second].every(id=>v.actor(s,id)?.gender==='female')};`);
  await check('own consent rules apply; guest and participant native conversations persist separately',`
    let s=structuredClone(clubFixture),p=v.get(s,personIds[0]);s=v.save(s,{...p,allowRomance:false});
    const refusal=JSON.stringify(v.get(s,p.id));const denied=v.socialize(s,p.id,guestId,'private',{roll:20});
    const blocked=JSON.stringify(v.get(denied,p.id))===refusal;
    s=v.save(s,{...v.get(s,p.id),allowRomance:true});s=v.socialize(s,p.id,guestId,'talk',{roll:20});
    const guest=v.get(s,guestId),guestTalk=guest.memories.length>0&&v.get(s,p.id).memories.some(m=>m.partner===guestId);
    if(!guestTalk)throw Error(JSON.stringify({guest,person:v.get(s,p.id),logs:s.log.slice(-4)}));
    s={...s,slot:s.slot+50};s=v.save(s,{...v.get(s,personIds[1]),readyAt:s.slot});
    s=v.socialize(s,personIds[1],v.mainId(s),'talk',{roll:20});
    const main=v.actor(s,v.mainId(s)),mainTalk=(main.memories||[]).some(m=>m.partner===personIds[1]);
    s={...s,slot:s.slot+50};for(const id of personIds.slice(0,2))s=v.save(s,{...v.get(s,id),readyAt:s.slot});
    s=v.socialize(s,personIds[0],personIds[1],'talk',{roll:20});
    return{blocked,guestTalk,mainTalk,companionTalk:v.get(s,personIds[0]).memories.some(m=>m.partner===personIds[1]),guestNotRoster:!v.list(s).some(p=>p.id===guestId)};`);
  await check('world ticks run autonomous club actions; selected companions stay and excluded keep settings',`
    d.store.update(()=>structuredClone(clubFixture));d.store.update(s=>({...s,mods:{...s.mods,'${ID}':{...patch.read(s),active:{...patch.read(s).active,nextSocialSlot:s.slot}}}}));
    const before=d.store.game(),excluded=JSON.stringify(v.get(before,personIds[2]).socialEnabled);
    for(let i=0;i<18&&!d.store.game().pendingEvent;i++)d.store.update(s=>d.fn('worldTick')(s,{playerPresent:true}));
    const s=d.store.game();if(!personIds.slice(0,2).some(id=>v.get(s,id).memories.length>v.get(before,id).memories.length))throw Error(JSON.stringify({slot:s.slot,own:patch.read(s),people:v.list(s).map(p=>({id:p.id,ready:p.readyAt,social:p.socialEnabled,task:p.task,session:!!p.nativeSession,room:p.room})),event:s.pendingEvent,log:s.log.slice(-4)}));return{time:s.slot>before.slot,actions:personIds.slice(0,2).some(id=>v.get(s,id).memories.length>v.get(before,id).memories.length),
      room:personIds.slice(0,2).every(id=>v.get(s,id).room==='taproom'),excluded:JSON.stringify(v.get(s,personIds[2]).socialEnabled)===excluded,
      noHookErrors:WML.status().failed.length===0};`);
  await check('eligible native private scene reserves guest and autonomously releases both actors',`
    let s=structuredClone(clubFixture),id=personIds[0],p=v.get(s,id),g=v.get(s,guestId);
    s=v.save(s,{...p,mood:100,energy:100,character:{...p.character,selfConcept:{openness:100,confidence:100},traitsAtGeneration:{openness:100,confidence:100},attributes:{...p.character.attributes,openness:100,confidence:100,composure:100,libido:100},
      stats:{...p.character.stats,energy:100,mood:100,arousal:100},latentTraits:[],affinities:{...p.character.affinities,romantic:2,vaginal:2},latitude:{byCategory:{},byPatron:{}}}});
    s=v.setBond(s,id,guestId,{trust:100,like:100,heart:100,status:'lover'});
    s=v.save(s,{...v.get(s,guestId),bonds:{[id]:{trust:100,like:100,heart:100,status:'lover'}},mood:100});
    const before=s.slot;s=v.socialize(s,id,guestId,'private',{roll:20});const started=!!v.get(s,id).nativeSession?.scenes?.sex;
    if(!started)throw Error(JSON.stringify({logs:s.log.slice(-4),menu:v.nativeEvent(s,id,guestId),person:v.get(s,id)}));
    globalThis.privateFixture=structuredClone(s);const reserved=d.fn('brothelCustomerBusy')(s,guestId),main=s.primaryCharacterId;
    for(let n=0;n<180&&v.get(s,id).nativeSession;n++)s=d.fn('minuteTick')(s);
    return{started,reserved,released:!v.get(s,id).nativeSession&&!v.get(s,guestId).interaction,
      finished:s.slot>before,isolated:s.primaryCharacterId===main&&!s.activeScene?.sex&&!v.list(s).some(p=>p.id===guestId)};`);
  await check('closing during a native scene releases both reservations without advancing the clock',`
    const before=structuredClone(privateFixture),s=club.closeClub(before);return{time:s.slot===before.slot,
      session:!v.get(s,personIds[0]).nativeSession,interaction:!v.get(s,personIds[0]).interaction,
      partner:!patch.read(s).guestArchive['초대 손님 A'].interaction,closed:!club.readData(s).active&&!patch.read(s).active};`);
  await check('all five club venues preserve participant location and remove temporary guest projections',`
    const rooms=['taproom','back_room','upstairs_hall','upstairs_room_2','bathhouse'];let joined=true,pinned=true,clean=true,closed=true;
    for(const room of rooms){let s=structuredClone(fixture);s=club.writeData(s,{prepared:{day:s.day,venue:room,participants:'wife_only',approved:[{name:'초대 손님 A'}]}});
      s=club.openClub(s);joined=joined&&patch.read(s).active.ids.length===3;s=d.fn('minuteTick')(s);
      pinned=pinned&&patch.read(s).active.ids.every(id=>v.get(s,id).room===room);
      clean=clean&&!v.list(s).some(p=>p.clubGuest);s=club.closeClub(s);closed=closed&&!patch.read(s).active;}
    return{joined,pinned,clean,closed};`);
  await check('close releases private sessions, restores pending work once, preserves actor changes',`
    let s=structuredClone(clubFixture),own=patch.read(s);own.active.resume[personIds[0]]={room:'kitchen',task:'cleaning',remaining:7,pendingRemaining:7,
      targetId:null,pending:{phase:'work',due:s.slot+7,plan:{type:'cleaning',duration:7,room:'kitchen'}}};
    s={...s,slot:s.slot+20};s=v.save(s,{...v.get(s,personIds[0]),mood:77});const next=club.closeClub(s),p=v.get(next,personIds[0]);
    return{closed:!patch.read(next).active,guests:Object.keys(patch.read(next).guests).length===0,restored:p.room==='kitchen'&&p.task==='cleaning'&&p.life.pending.due===next.slot+7,
      retained:p.mood===77,idempotent:JSON.stringify(patch.release(next))===JSON.stringify(next)};`);
  await check('repeat invitations retain the same guest relationship and remap a new customer ID',`
    let s=structuredClone(clubFixture),id=personIds[0];s=v.setBond(s,id,guestId,{trust:72,like:48,heart:25});
    s=v.save(s,{...v.get(s,guestId),bonds:{[id]:{trust:61,like:42,heart:18}}});s=club.closeClub(s);
    const archive=patch.read(s).guestArchive['초대 손님 A'];s={...s,day:s.day+1,slot:s.slot+1440,customers:[]};
    s=club.writeData(s,{prepared:{day:s.day,venue:'taproom',participants:'wife_only',approved:[{name:'초대 손님 A'}]}});s=club.openClub(s);
    const current=club.readData(s).active.guestIds[0];return{archived:!!archive,newId:current!==guestId,
      companion:v.get(s,id).bonds[current].like===48,guest:v.get(s,current).bonds[id].like===42,oldRemoved:!v.get(s,id).bonds[guestId]};`);
  await check('pending mandatory events freeze club social choices and preserve original participant settings',`
    const s={...structuredClone(clubFixture),pendingEvent:{type:'alert',text:'사건 우선 확인',choices:[{id:'ok',label:'확인'}]}};
    const before=JSON.stringify(s.mods),next=patch.tick({...s,slot:s.slot+10});return{preserved:JSON.stringify(next.mods)===before,event:next.pendingEvent===s.pendingEvent};`);
  await check('moving or sleeping companions are skipped; no selected companions leaves vanilla behavior',`
    restore();d.store.dispatch({type:'${ID}/selection',ids:personIds});
    d.store.update(s=>v.save(v.save(s,{...v.get(s,personIds[0]),room:'town:transit'}),{...v.get(s,personIds[1]),task:'sleeping'}));
    let s=d.store.game();s=club.writeData(s,{prepared:{day:s.day,venue:'taproom',participants:'wife_only',approved:[{name:'초대 손님 A'}]}});s=club.openClub(s);
    const skipped=patch.read(s).active.ids.length===1&&patch.read(s).active.ids[0]===personIds[2];
    s=club.closeClub(s);d.store.update(()=>s);d.store.dispatch({type:'${ID}/selection',ids:[]});s=d.store.game();
    s=club.writeData(s,{prepared:{day:s.day,venue:'taproom',participants:'wife_only',approved:[{name:'초대 손님 A'}]}});s=club.openClub(s);
    const before=JSON.stringify(v.read(s)),next=patch.tick({...s,slot:s.slot+10});return{skipped,none:patch.read(next).active.ids.length===0,unchanged:JSON.stringify(v.read(next))===before};`);
  if(!core){
    await check('Brothel hosts and companion hosts run together without duplicate guest reservations',`
      let s=club.closeClub(structuredClone(clubFixture));const b=__waywardBrothelPublic,c=b.getConfig(),w=c.workers[0];
      w.enabled=true;w.relationshipId='club-coexist';w.stats.energy=100;w.lastFullRestDay=s.day;b.getRuntime().clear();c.enabled=true;c.allowTaproomSex=true;b.saveConfig();
      s={...s,patronRecords:[...s.patronRecords,{...s.patronRecords[0],name:'초대 손님 B'},{...s.patronRecords[0],name:'초대 손님 C'}]};
      s=club.writeData(s,{prepared:{day:s.day,venue:'taproom',participants:'wife_workers',approved:s.patronRecords.map(p=>({name:p.name}))}});s=club.openClub(s);
      const assigned=club.readData(s).active.extensionData.workerIds.includes(w.id),members=patch.read(s).active.ids.length===2;
      for(let n=0;n<16&&!s.pendingEvent;n++)s=d.fn('worldTick')(s,{playerPresent:true});
      const sessions=club.readData(s).active.extensionData.sessions||{};
      const distinct=Object.values(sessions).every(session=>!v.list(s).some(p=>p.nativeSession?.partner===session.customerId));
      s=club.closeClub(s);w.enabled=false;c.enabled=false;b.saveConfig();return{assigned,members,distinct,released:!s.mods.brothel.assignments?.[w.id]};`);
    await run(`restore();globalThis.b=__waywardBrothelPublic;globalThis.h=__waywardBrothelHStatus;globalThis.hs=__waywardSituationEventMod;
      const c=b.getConfig();c.enabled=false;c.workers.forEach((w,i)=>{w.enabled=i<2;w.relationshipId='full-test-'+i;w.name='직원 '+(i+1);w.portrait='hina';
        w.sexualExperience={groping:0,intimate:0,handjob_patron:i===0?3:0,blowjob_patron:i===1?2:0,titfuck_patron:0,sex_patron:0};w.sexualHistory=[];w.stats.energy=100;w.lastFullRestDay=10;});
      b.getRuntime().clear();b.saveConfig();h.refresh();b.openSettings();for(const card of document.querySelectorAll('details.ww-editor-card'))card.open=true;
      await new Promise(r=>setTimeout(r,1200));globalThis.workerFixture=structuredClone(d.store.game());return true;`);
    await check('original H_Status panels show independent body, assessment and picture regions within worker details',`
      const s=d.store.game(),a=h.getRecord(s,'brothel_worker_1'),b=h.getRecord(s,'brothel_worker_2'),panels=[...document.querySelectorAll('[data-brothel-secret]')];
      return{two:panels.length===2,inside:panels.every(p=>p.closest('details.ww-editor-card')),
        full:panels.every(p=>p.textContent.includes('쓰리사이즈')&&p.textContent.includes('가장 좋았던')&&p.querySelectorAll('.ko-se-fluid-card').length===5),
        separate:a.character.id!==b.character.id&&a.situationStats.totalSexActCount===3&&b.situationStats.totalSexActCount===2,
        noBackfill:a.character.situationStats.totalSexActCount===0&&a.character.intimateHistory.length===0,
        identity:s.primaryCharacterId===workerFixture.primaryCharacterId&&!s.characters.brothel_worker_1};`);
    await check('external completed service creates native assessment once; cancelled stage is not a completion',`
      let s=d.store.game(),w='brothel_worker_1',customer={id:'new-history-guest',name:'평가 손님',walletGold:10000,boldness:70,charm:60,attributes:{}};
      s=b.assign(s,[w],{owner:'history-test',location:'taproom'});s=b.service(s,w,customer,'sex_patron',{owner:'history-test'});
      s=b.externalActivity(s,w,customer,'sex_patron',{owner:'history-test',location:'taproom',untilSlot:s.slot+5});
      s={...s,slot:s.slot+5};s=b.endExternalActivity(s,w,{owner:'history-test'});s=b.release(s,'history-test');d.store.update(()=>s);h.refresh();
      const first=h.getRecord(d.store.game(),w);h.refresh();const once=h.getRecord(d.store.game(),w).character.situationStats.totalSexActCount===1;
      s=d.store.game();s=b.assign(s,[w],{owner:'cancel-test',location:'taproom'});s=b.service(s,w,customer,'blowjob_patron',{owner:'cancel-test'});
      s=b.externalActivity(s,w,customer,'blowjob_patron',{owner:'cancel-test',location:'taproom',untilSlot:s.slot+20});s=b.endExternalActivity(s,w,{owner:'cancel-test'});s=b.release(s,'cancel-test');d.store.update(()=>s);h.refresh();
      await new Promise(r=>setTimeout(r,120));const panel=document.querySelector('[data-brothel-secret="'+w+'"]');
      return{once,record:first.character.intimateHistory.at(-1).partner==='평가 손님',assessment:!!panel.querySelector('.ko-se-history-evaluation'),
        cancelled:h.getRecord(d.store.game(),w).character.situationStats.totalSexActCount===1,other:h.getRecord(d.store.game(),'brothel_worker_2').character.situationStats.totalSexActCount===0};`);
    await check('natural and player services produce employee-only completion history',`
      let s=d.store.game(),w=b.getConfig().workers[0],runtime=b.getRuntime().get(w.id),before=h.getRecord(s,w.id).character.situationStats.totalSexActCount;
      const mainId=s.primaryCharacterId,main=JSON.stringify(s.characters[mainId].intimateHistory||[]),customer={id:'natural-completion',name:'일반 접객 손님',walletGold:10000,boldness:70,charm:80,status:'drinking',stayTimer:1000,intent:'interested'};
      s={...s,slot:s.slot+1,customers:[customer],phase:'service',pendingEvent:undefined,alertQueue:[],activeScene:{}};
      s=d.fn('moveOccupant')(s,customer.id,'taproom');b.getConfig().enabled=false;s=b.tick(s);s={...s,slot:s.slot+1};b.getConfig().enabled=true;b.getConfig().allowTaproomSex=true;
      b.getRuntime().set(w.id,{...runtime,task:'interaction',location:'taproom',busyUntil:s.slot,stats:{...w.stats,energy:100},interaction:{customerId:customer.id,customerName:customer.name,
        customerSnapshot:customer,stages:['groping','sex_patron'],index:0,stage:'groping',comfort:90}});
      const other=b.getRuntime().get('brothel_worker_2');if(other){other.task='rest';other.busyUntil=s.slot+100;}
      s=b.tick(s);s={...s,slot:s.slot+6};s=b.tick(s);b.getConfig().enabled=false;d.store.update(()=>s);h.refresh();
      const natural=h.getRecord(d.store.game(),w.id).character.situationStats.totalSexActCount===before+1;
      runtime=b.getRuntime().get(w.id);Object.assign(runtime,{task:'idle',interaction:null,busyUntil:s.slot,location:'taproom',stats:{...runtime.stats,energy:100}});
      d.store.update(s=>({...s,customers:[],pendingEvent:undefined,alertQueue:[],activeScene:{}}));
      d.store.dispatch({type:'brothel/player-service',workerId:w.id,stage:'handjob_patron'});
      const started=!!d.store.game().mods.brothel.playerSession;
      for(let n=0;n<60&&d.store.game().mods.brothel.playerSession;n++){
        const current=d.store.game(),session=current.mods.brothel.playerSession;
        if(current.pendingEvent){const option=current.pendingEvent.choices?.find(c=>!c.disabled);if(!option)throw Error(JSON.stringify(current.pendingEvent));d.store.dispatch({type:'resolve_event',choiceId:option.id});continue;}
        if(session.waitingUntil!=null){d.store.dispatch({type:'brothel/player-continue',sessionId:session.id,turn:session.turn});continue;}
        const choice=b.playerChoices(current)[0];if(!choice)break;d.store.dispatch({type:'brothel/player-choice',sessionId:session.id,turn:session.turn,choiceId:choice.id});
      }
      h.refresh();const now=d.store.game(),record=h.getRecord(now,w.id);
      return{natural,started,player:record.character.situationStats.totalSexActCount===before+2,
        separated:record.character.intimateHistory.at(-1).partnerType==='player',main:now.primaryCharacterId===mainId&&JSON.stringify(now.characters[mainId].intimateHistory||[])===main};`);
    await check('Pregnancy worker information and images move entirely into matching details',`
      const rows=[...document.querySelectorAll('[data-brothel-pregnancy-status]')],images=[...document.querySelectorAll('[data-brothel-pregnancy-visual]')];
      return{two:rows.length===2,inside:rows.every(p=>p.closest('details.ww-editor-card')),
        text:rows.every(p=>p.querySelector('[data-brothel-pregnancy-information]')?.textContent.includes('직원')),
        noSummary:!document.querySelector('.ww-pregnancy-workers,.brothel-pregnancy-visual-grid'),
        images:images.length===2&&images.every(p=>p.closest('[data-brothel-pregnancy-status]')&&p.querySelector('img')?.complete&&p.querySelector('img').naturalWidth>0),
        log:!!document.querySelector('.ww-pregnancy-log')};`);
    await check('Pregnancy OFF hides employee images and preserves existing reproductive records',`
      const saved=structuredClone(d.store.game().waywardBrothelPregnancyV1);__wc2PregnancyBirth265.setEnabled(false);b.refreshSettings();
      await new Promise(r=>setTimeout(r,80));const hidden=!document.querySelector('[data-brothel-pregnancy-status] img');
      const current=d.store.game().waywardBrothelPregnancyV1;
      const retained=Object.entries(saved.workers).every(([id,r])=>['spermDeposits','pregnancy','seenServices'].every(key=>JSON.stringify(r[key])===JSON.stringify(current.workers[id][key])))&&JSON.stringify(saved.events)===JSON.stringify(current.events);
      __wc2PregnancyBirth265.setEnabled(true);b.refreshSettings();await new Promise(r=>setTimeout(r,100));
      return{hidden,retained,restored:document.querySelectorAll('[data-brothel-pregnancy-status] img').length===2};`);
    await check('H_Status uses the employee portrait pack and loads existing local artwork',`
      await new Promise(r=>setTimeout(r,800));const hosts=[...document.querySelectorAll('[data-brothel-secret]')],images=hosts.flatMap(p=>[...p.querySelectorAll('img')]);
      if(!images.length)throw Error(JSON.stringify(hosts.map(p=>({text:p.textContent.slice(0,60),html:p.innerHTML.slice(0,160),record:h.getRecord(d.store.game(),p.dataset.brothelSecret).character.archetypeId}))));
      const correct=images.every(img=>(img.currentSrc||img.src).includes('/hina/')||img.src.startsWith('blob:'));
      return{images:images.length>=2,loaded:images.every(img=>img.complete&&img.naturalWidth>0),correct};`);
    await run(`globalThis.expectedWorkerCount=h.getRecord(d.store.game(),'brothel_worker_1').character.situationStats.totalSexActCount;
      d.store.get().saveToSlot(1);return true;`);
    await run(`document.querySelector('[data-brothel-h-status]')?.scrollIntoView({block:'start'});await new Promise(r=>setTimeout(r,80));return true;`);
    fs.writeFileSync(new URL('worker-details-'+tag+'.jpg',root),Buffer.from(await playScreenshot({}),'base64'));
    await check('same portrait rehire does not inherit prior employee detailed records',`
      const old=h.getRecord(d.store.game(),'brothel_worker_1');b.getConfig().workers[0].relationshipId='replacement-worker';b.saveConfig();h.refresh();
      const current=h.getRecord(d.store.game(),'brothel_worker_1');b.getConfig().workers[0].relationshipId='full-test-0';b.saveConfig();return{reset:current.character.intimateHistory.length===0&&current.character.situationStats.totalSexActCount===0,
        identity:old.employeeKey!==current.employeeKey,second:h.getRecord(d.store.game(),'brothel_worker_2').employeeKey==='full-test-1'};`);
  }
  await run(`d.store.update(()=>structuredClone(clubFixture));d.store.get().saveToSlot(0);return true;`);
  const reloaded=await playReload({});assert.deepEqual(reloaded.failed,[]);
  if(!core)await check('detailed worker completion history survives actual slot save and reload',`
    const d=WML.dev();d.store.get().loadFromSlot(1);const h=__waywardBrothelHStatus;h.refresh();const s=d.store.game(),r=h.getRecord(s,'brothel_worker_1');
    return{count:r.character.situationStats.totalSexActCount===3,history:r.character.intimateHistory.length===3,
      own:r.character.intimateHistory.some(x=>x.partnerType==='player'),other:h.getRecord(s,'brothel_worker_2').character.intimateHistory.length===0,
      isolated:!s.characters.brothel_worker_1};`);
  await check('real saved slot reload restores selected membership and guest model without main replacement',`
    const d=WML.dev();d.store.get().loadFromSlot(0);const s=d.store.game(),v=WML.use('companions'),p=WML.use('${ID}'),own=p.read(s);
    return{active:own.active.ids.length===2,guest:Object.keys(own.guests).length===1,
      male:own.active.ids.some(id=>v.get(s,id).gender==='male'),identity:!s.characters[own.active.ids[0]]&&!!s.characters[s.primaryCharacterId]};`);
  const status=await playStatus({});assert.deepEqual(status.pageErrors,[]);report.errors=status.pageErrors;report.warnings=status.warnings;
  fs.writeFileSync(new URL('result-'+tag+'.json',root),JSON.stringify(report,null,2)+'\n');console.log('PASS',tag,report.cases.length);
}finally{await shutdown();}
process.exit(0);
