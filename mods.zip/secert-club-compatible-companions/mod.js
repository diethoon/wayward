// 비밀 클럽 · Companions 연결. 기존 모드 원본은 수정하지 않습니다.
// Companions의 원본 행동·인물별 문맥 및 자율 생활 API를 사용합니다.
WML.define({
  id: 'secert-club-compatible-companions',
  name: '비밀 클럽 + 동료', author: 'Hina_Lover',
  version: "1.1.1", game: "2026-11-01", lang: 'ko',
  tags: ['content','h-scene'],
  description: '선택한 남녀 동료가 초대 손님·그녀·다른 참가 동료와 자신의 성향에 따라 교류합니다.',
  requires: ['secert-club','companions'],
  requiresVersion: {'secert-club':'>=1.3.0 <2',companions:'>=2.7.3 <3'},
  loadAfter: ['secert-club','companions'],
  loadBefore: ['secert-club-compatible-brothel'],
  symbols: {
    "clubCompanionCharacter": {"raw":{"2026-11-01":"RZe"}},
    "clubCompanionCustomerBusy": {"raw":{"2026-11-01":"z5"}}
  },
  setup(api) {
    const ID=api.id, club=api.use('secert-club'), people=api.use('companions');
    const copy=v=>v==null?v:structuredClone(v);
    const read=s=>s?.mods?.[ID]||{};
    const write=(s,patch)=>({...s,mods:{...s.mods,[ID]:{...read(s),...patch}}});
    const active=s=>club.readData(s).active;
    const member=(s,id)=>!!active(s)&&read(s).active?.openedAt===active(s).openedAtSlot&&read(s).active.ids.includes(id);
    const original={get:people.get,save:people.save,actor:people.actor,saveActor:people.saveActor};
    const roster=s=>people.list(s).filter(p=>p.site===people.context(s).active);
    const selected=s=>roster(s).filter(p=>!(read(s).selection?.day===s.day?read(s).selection.excluded:[]).includes(p.id)).map(p=>p.id);
    const selection=s=>read(s).prepared?.day===s.day?read(s).prepared.ids:selected(s);
    let registered=false, baseAdapter=null, scheduled=false, clubSocialContext=null;
    // Guest actors live only in this patch's saved data, never in the companion/main roster.
    people.get=(s,id)=>original.get(s,id)||read(s).guests?.[id];
    people.save=(s,p)=>{
      if(p?.clubGuest)return write(s,{guests:{...read(s).guests,[p.id]:p}});
      if(member(s,p?.id))p={...p,room:active(s).venue};
      return original.save(s,p);
    };
    people.actor=(s,id)=>original.actor(s,id)||read(s).guests?.[id];
    people.saveActor=(s,p)=>p?.clubGuest?people.save(s,p):original.saveActor(s,p);
    function projectGuests(s){
      const guests=read(s).guests;if(!active(s)||!Object.keys(guests||{}).length)return s;
      const data=people.read(s);return people.write(s,{...data,people:{...data.people,...guests}});
    }
    function settle(s){
      const data=people.read(s),guests={...read(s).guests},roster={};
      for(const [id,p]of Object.entries(data.people)){
        if(p.clubGuest)guests[id]=active(s)?{...p,room:active(s).venue}:p;
        else roster[id]=member(s,id)?{...p,room:active(s).venue}:p;
      }
      return write(people.write(s,{...data,people:roster}),{guests});
    }
    // Companions publishes a copy of its API. Pass an isolated actor roster to its original closures,
    // then remove guest projections before the returned state reaches the real game store.
    const invokeSocialize=people.socialize;
    people.socialize=(s,aId,bId,kind='talk',options={})=>{
      const projected=projectGuests(s),a=people.actor(projected,aId),b=people.actor(projected,bId);
      const romantic=['flirt','hand','hug','kiss','confess','private'].includes(kind);
      const woman=b?.gender==='female'?b:a?.gender==='female'?a:null;
      const live=active(s),own=read(s),participants=new Set([...(own.active?.ids||[]),...(live?.guestIds||[])]);
      if(live?.participants!=='workers_only')participants.add(people.mainId(s));
      const partyAction=!!live&&own.active?.openedAt===live.openedAtSlot&&romantic&&woman?.allowRomance!==false&&
        participants.has(aId)&&participants.has(bId);
      const threshold=kind==='confess'?83:kind==='private'?85:romantic?62:40;
      const genericBonus=partyAction&&b?.gender==='female'?threshold*(1-club.acceptanceFactor()):0;
      const prior=clubSocialContext;
      clubSocialContext=partyAction?{aId,bId,kind,womanId:woman.id}:prior;
      try{
        const supplied=Number.isFinite(options?.roll)?Number(options.roll):Math.random()*20;
        const result=invokeSocialize(projected,aId,bId,kind,{...options,roll:supplied+genericBonus});
        return projected===s?result:settle(result);
      }finally{clubSocialContext=prior;}
    };
    for(const name of ['nativeChoose','nativeClose']){
      const invoke=people[name];people[name]=(s,...args)=>{
        const projected=projectGuests(s),result=invoke(projected,...args);
        return projected===s?result:settle(result);
      };
    }
    const nativeEvent=people.nativeEvent;
    people.nativeEvent=(s,...args)=>nativeEvent(projectGuests(s),...args);
    function guest(s,c,room){
      const prior=read(s).guestArchive?.[c.name];
      if(prior)return {...copy(prior),id:c.id,character:{...copy(prior.character),id:c.id,name:c.name},
        room,homeRoom:room,site:people.context(s).active,readyAt:s.slot,interaction:null,nativeSession:null,
        task:'club',life:{},customerId:c.id};
      const profile=api.fn('wives')[0];
      const character=api.fn('clubCompanionCharacter')(profile,{id:c.id,name:c.name,day:s.day,commitment:0});
      return {id:c.id,name:c.name,gender:c.gender||'male',age:25,active:true,clubGuest:true,
        site:people.context(s).active,room,homeRoom:room,energy:100,mood:65,readyAt:s.slot,
        socialEnabled:true,allowRomance:true,task:'club',character:{...character,gender:c.gender||'male',age:25,
          attributes:{...character.attributes,...c.attributes,charm:c.charm??50},stats:{...character.stats,energy:100,mood:65}},
        bonds:{},memories:[],cooldowns:{},relationship:{trust:20,affection:0},customerId:c.id};
    }
    function enroll(s,prepared,live){
      const ids=[],resume={},guests={};let next=s;
      for(const id of selection(s)){
        const p=original.get(next,id);
        if(!p||p.active===false||p.site!==people.context(next).active)continue;
        if(p.nativeSession||p.interaction||p.room==='town:transit'||p.task==='sleeping'){
          next=people.log(next,p.name+'은(는) 진행 중인 만남·이동·수면 때문에 이번 클럽에 합류하지 못했습니다.',id);continue;
        }
        resume[id]={room:p.room,task:p.task,remaining:Math.max(0,p.readyAt-s.slot),pending:copy(p.life?.pending),
          pendingRemaining:Math.max(0,(p.life?.pending?.due??s.slot)-s.slot),targetId:p.targetId};
        ids.push(id);next=original.save(next,{...p,room:live.venue,task:'club',readyAt:s.slot,targetId:null,life:{...p.life,pending:null}});
      }
      for(const id of live.guestIds){const c=next.customers.find(c=>c.id===id);if(!c)continue;
        const old=read(next).guestArchive?.[c.name];guests[id]=guest(next,c,live.venue);
        if(old?.id&&old.id!==id){
          for(const person of people.list(next))if(person.bonds?.[old.id]){const bonds={...person.bonds,[id]:person.bonds[old.id]};delete bonds[old.id];next=original.save(next,{...person,bonds});}
          const data=people.read(next);if(data.mainBonds?.[old.id]){const bonds={...data.mainBonds,[id]:data.mainBonds[old.id]};delete bonds[old.id];next=people.write(next,{...data,mainBonds:bonds});}
        }
      }
      next=write(next,{active:{day:s.day,openedAt:live.openedAtSlot,ids,resume,nextSocialSlot:s.slot+5},guests});
      return ids.length?people.log(next,ids.map(id=>original.get(next,id).name).join(', ')+'이(가) 비밀 클럽에 참가했습니다.'):next;
    }
    function release(s){
      const own=read(s),live=own.active;if(!live)return s;let next=s;
      const main=people.mainId(next),closeIds=[...live.ids,...Object.keys(own.guests||{}),main];
      for(const id of closeIds){const p=people.actor(next,id);
        if(p?.nativeSession&&(id!==main||live.ids.includes(p.nativeSession.partner)||own.guests?.[p.nativeSession.partner]))next=people.nativeClose(next,id);
      }
      for(const id of live.ids){const p=original.get(next,id),resume=live.resume[id];if(!p||!resume)continue;
        const pending=resume.pending?{...resume.pending,due:next.slot+resume.pendingRemaining}:null;
        next=original.save(next,{...p,room:resume.room,task:resume.task,readyAt:next.slot+resume.remaining,
          targetId:resume.targetId,life:{...p.life,pending}});
      }
      const guestArchive={...own.guestArchive};for(const p of Object.values(read(next).guests||{}))guestArchive[p.name]=copy(p);
      return write(next,{active:null,guests:{},guestArchive});
    }
    const ai=people.getAIAdapter(),originalTick=ai.tick;
    ai.tick=(s,p)=>{
      if(!member(s,p.id))return originalTick(s,p);
      const updated=people.nativePassive(s,p);
      return people.save(s,{...updated,room:active(s).venue,task:updated.nativeSession?'private':'club',life:{...updated.life,pending:null}});
    };
    function compose(base){
      return {...base,
        eligible:s=>!!base.eligible?.(s)||roster(s).length>0,
        beforeOpen(s,p,a){const result=base.beforeOpen?.(s,p,a)||{};return {...result,state:enroll(result.state||s,p,a)};},
        afterClose(s,a){const next=release(s);return base.afterClose?.(next,a)||next;}
      };
    }
    const register=club.registerCompatibility;
    club.registerCompatibility=adapter=>{
      const result=register(compose(adapter));baseAdapter=adapter;registered=true;return result;
    };
    // The optional Brothel adapter registers after this mod. Without it, register at boot completion.
    function finishRegistration(){
      if(registered)return;
      if(!WML.status().booted){setTimeout(finishRegistration,25);return;}
      club.registerCompatibility({id:ID});
    }
    setTimeout(finishRegistration,0);
    api.actions.observe(({type})=>{
      if(type==='secert-club/prepare')api.store.update(s=>write(s,{prepared:{day:s.day,ids:selected(s)}}));
    });
    api.actions.register(ID+'/selection',(s,a)=>{
      const ids=roster(s).map(p=>p.id),excluded=ids.filter(id=>!a.ids?.includes(id));
      return write(s,{selection:{day:s.day,excluded},prepared:null});
    });
    function busy(s,id){
      if(!active(s)?.guestIds.includes(id))return false;
      return !!read(s).guests?.[id]?.interaction||!!read(s).guests?.[id]?.nativeSession||
        (read(s).active?.ids||[]).some(key=>original.get(s,key)?.nativeSession?.partner===id)||
        people.actor(s,people.mainId(s))?.nativeSession?.partner===id;
    }
    api.hook('clubCompanionCustomerBusy',{after(result,[s,id]){return result||busy(s,id);}});
    api.hook('evaluateIntimacy',{priority:-110,after(result){
      return clubSocialContext?club.relaxIntimacyResult(result):result;
    }});
    function canSocial(s,p){
      if(!p||!people.freeForSocial(s,p)||p.energy<20||p.room!==active(s)?.venue)return false;
      if(p.clubGuest){const c=s.customers.find(c=>c.id===p.id);return c&&!['gone','leaving'].includes(c.status)&&
        api.fn('getCustomerLocation')(s,p.id)===p.room&&!api.fn('clubCompanionCustomerBusy')(s,p.id);}
      return true;
    }
    const romanticKinds=new Set(['flirt','kiss','private']);
    function actionThresholds(){
      return {flirtLike:club.relaxedThreshold(8),kissLike:club.relaxedThreshold(20),kissHeart:club.relaxedThreshold(10),
        privateLike:club.relaxedThreshold(30),privateHeart:club.relaxedThreshold(10)};
    }
    function willingness(s,p){
      if(!p)return 0;
      const attrs=api.fn('getEffectiveAttributes')(p.character)||{},stats=p.character?.stats||{};
      return Math.max(0,Math.min(1,((Number(stats.arousal)||0)*.6+(Number(attrs.openness??50)||0)*.2+(Number(p.mood??50)||0)*.2)/100));
    }
    function proposalChance(s,base,woman){
      if(!woman)return base;
      const boost=Math.max(1,Number(club.settings().sexualBoost)||1);
      return Math.max(0,Math.min(.95,base*(.25+willingness(s,woman))*boost));
    }
    function chooseKind(s,a,b,initiative=false){
      const fallback=['talk','joke','praise'][Math.floor(Math.random()*3)];
      if(!a.allowRomance||!b.allowRomance)return fallback;
      const woman=initiative&&a.gender==='female'?a:b.gender==='female'?b:a.gender==='female'?a:null;
      const focus=woman||b,other=focus.id===a.id?b:a,row=people.bond(s,focus.id,other.id),limits=actionThresholds();
      if(a.gender!==b.gender&&row.like>=limits.privateLike&&row.heart>=limits.privateHeart&&Math.random()<proposalChance(s,.35,woman))return 'private';
      if(row.like>=limits.kissLike&&row.heart>=limits.kissHeart&&Math.random()<proposalChance(s,.45,woman))return 'kiss';
      if(row.like>=limits.flirtLike&&Math.random()<proposalChance(s,.5,woman))return 'flirt';
      return fallback;
    }
    function socialize(s){
      const live=active(s),own=read(s);if(!live||!own.active)return own.active?release(s):s;
      if(live.openedAtSlot!==own.active.openedAt)return release(s);
      if(!own.active.ids.length)return s;
      if(people.inProjection()||s.pmCore||s.pendingEvent||s.gameOver||Object.values(s.activeScene||{}).some(Boolean))return s;
      if(s.slot<own.active.nextSocialSlot)return s;
      let next=write(s,{active:{...own.active,nextSocialSlot:s.slot+5}});
      const ids=[...own.active.ids,...live.guestIds];
      if(live.participants!=='workers_only')ids.push(people.mainId(s));
      const used=new Set();let interactions=0;
      const candidatesFor=(state,a)=>ids.filter(other=>other!==a.id&&!used.has(other)).map(other=>people.actor(state,other))
        .filter(b=>canSocial(state,b)&&!(a.clubGuest&&b.clubGuest)&&(!a.clubGuest||!b.main||live.participants!=='workers_only')&&
          (people.bond(state,b.id,a.id).nextSlot||0)<=state.slot);
      const interact=(a,b,initiative=false)=>{
        const kind=chooseKind(next,a,b,initiative);
        if(initiative&&romanticKinds.has(kind)){
          const action={flirt:'호감 표현',kiss:'입맞춤',private:'사적인 만남'}[kind];
          next=people.log(next,`${a.name}이(가) 먼저 ${b.name}에게 ${action}을(를) 제안합니다.`,a.id);
        }
        next=people.socialize(next,a.id,b.id,kind);used.add(a.id);used.add(b.id);interactions++;
      };
      const women=ids.map(id=>people.actor(next,id)).filter(p=>p?.gender==='female'&&p.allowRomance!==false&&canSocial(next,p));
      if(women.length){
        const cursor=Math.max(0,Number(own.active.initiativeCursor)||0)%women.length;
        for(let offset=0;offset<women.length;offset++){
          const index=(cursor+offset)%women.length,a=women[index],candidates=candidatesFor(next,a);
          if(!candidates.length)continue;
          interact(a,candidates[Math.floor(Math.random()*candidates.length)],true);
          next=write(next,{active:{...read(next).active,initiativeCursor:(index+1)%women.length,lastInitiatorId:a.id}});
          break;
        }
      }
      for(const id of ids){
        const a=people.actor(next,id);if(used.has(id)||!canSocial(next,a)||interactions>=6)continue;
        const candidates=candidatesFor(next,a);
        if(!candidates.length)continue;
        interact(a,candidates[Math.floor(Math.random()*candidates.length)]);
      }
      return next;
    }
    // The original life hook advances scenes and applies its own consent checks. Temporarily expose
    // guest actors there, excluding unselected companions in the club room, then remove the projection.
    const frames=[];
    api.hook('minuteTick',{priority:-1900,after(s){
      if(!active(s)||!read(s).active?.ids.length||people.inProjection()){frames.push(null);return s;}
      const frame={social:{},mainPending:null},projected=projectGuests(s),data=people.read(projected),rows={...data.people};
      for(const [id,p]of Object.entries(rows))if(p.room===active(s).venue){frame.social[id]=p.socialEnabled;rows[id]={...p,socialEnabled:false};}
      let patch={...data,people:rows};
      if(api.fn('wifeLocation')(s)===active(s).venue){frame.mainPending=copy(data.mainLife?.pending);patch.mainLife={...data.mainLife,pending:{clubSocialMask:true}};frame.maskMain=true;}
      frames.push(frame);return people.write(projected,patch);
    }});
    api.hook('minuteTick',{priority:-2100,after(s){
      const frame=frames.pop();if(!frame)return s;
      const data=people.read(s),rows={...data.people};for(const [id,value]of Object.entries(frame.social))if(rows[id])rows[id]={...rows[id],socialEnabled:value};
      return settle(people.write(s,{...data,people:rows,...(frame.maskMain?{mainLife:{...data.mainLife,pending:frame.mainPending}}:{})}));
    }});
    api.hook('minuteTick',{priority:-3000,after:socialize});
    api.hook('worldTick',{priority:-1000,after(s){return !active(s)&&read(s).active?release(s):s;}});
    function renderSelection(){
      scheduled=false;const s=api.store.game();if(!s)return;
      for(const radio of document.querySelectorAll('input[name="secert-club-venue"]')){
        const body=radio.closest('[data-wml-ui]');if(!body||body.querySelector('[data-club-companions]'))continue;
        const section=document.createElement('section');section.className='wml-section';section.dataset.clubCompanions='';
        const title=document.createElement('h3');title.textContent='참가 동료';section.append(title);
        const tip=document.createElement('p');tip.textContent='기본은 모두 참가합니다. 성향·허용·거절 기준은 각 인물의 것을 따릅니다.';section.append(tip);
        const list=roster(s),chosen=new Set(selected(s));
        const choose=ids=>api.store.dispatch({type:ID+'/selection',ids});
        const controls=document.createElement('div');controls.style.cssText='display:flex;gap:8px;flex-wrap:wrap';
        for(const [label,ids]of [['동료 모두 선택',list.map(p=>p.id)],['동료 모두 해제',[]]]){
          const button=api.ui.button(label,()=>{choose(ids);section.remove();schedule();});controls.append(button);
        }
        section.append(controls);
        for(const p of list){const label=document.createElement('label');label.style.cssText='display:flex;gap:8px;align-items:center;min-height:32px;margin:5px 0';
          const input=document.createElement('input');input.type='checkbox';input.checked=chosen.has(p.id);input.dataset.clubCompanion=p.id;
          input.addEventListener('change',()=>{input.checked?chosen.add(p.id):chosen.delete(p.id);choose([...chosen]);});
          label.append(input,document.createTextNode(p.name+' · '+(p.gender==='male'?'남성':'여성')));section.append(label);
        }
        if(!list.length)section.append(document.createTextNode('현재 사업장에 참가할 동료가 없습니다.'));
        const actions=body.lastElementChild;body.insertBefore(section,actions);
      }
    }
    function schedule(){if(!scheduled){scheduled=true;queueMicrotask(renderSelection);}}
    const observer=new MutationObserver(schedule);observer.observe(document.body,{childList:true,subtree:true});
    window.addEventListener('pagehide',()=>observer.disconnect(),{once:true});
    api.store.subscribe(schedule);
    api.provide({read,selected,enroll,release,tick:socialize,thresholds:actionThresholds,guestActor:(s,id)=>read(s).guests?.[id],
      get bridge(){return baseAdapter?.id;}});
  }
});
