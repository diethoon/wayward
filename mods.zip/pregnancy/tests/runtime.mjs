// Test-only dependency lookup. Does not modify the game, MCP, or other mods.
// Optional: WML_TEST_NODE_MODULES points to an existing node_modules directory.
import {createRequire,registerHooks} from 'node:module';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
const fallback=process.env.WML_TEST_NODE_MODULES;
if(fallback){
  const require=createRequire(path.join(path.resolve(fallback),'../package.json'));
  registerHooks({resolve(specifier,context,next){
    try{return next(specifier,context);}catch(error){
      if(error.code!=='ERR_MODULE_NOT_FOUND'||specifier.startsWith('.')||specifier.includes(':'))throw error;
      return next(pathToFileURL(require.resolve(specifier)).href,context);
    }
  }});
}
