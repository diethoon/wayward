// node --import ./wml/mods/pregnancy/tests/runtime.mjs wml/mods/pregnancy/tests/public-api.mjs [--bio] [--mobile] [--all] [--zip]
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {checkMod} from '../../../../MCP/lib/check.mjs';
import {playStart,playEval,playReload,playStatus,playScreenshot,shutdown} from '../../../../MCP/lib/play.mjs';
const mobile=process.argv.includes('--mobile'),bio=process.argv.includes('--bio'),all=process.argv.includes('--all'),zip=process.argv.includes('--zip');
const tag=[mobile?'mobile':'desktop',bio?'bio':'basic',all?'all':'core',zip?'zip':'disk'].join('-');
const report={tag,cases:[]};
const folders=fs.readdirSync('wml/mods',{withFileTypes:true}).filter(e=>e.isDirectory()).map(e=>e.name);
const wanted=['addon-compat','pregnancy','companions','companions-compatible-pregnancy','construction-tool','brothel','brothel-pregnancy','brothel-compatible-pregnancy','ui-customize',...(bio?['pregnancy_biological_realism']:[])];
async function run(code){const out=await playEval({code,timeoutMs:30000});assert.equal(out.pageErrorsSoFar,0,JSON.stringify(out));assert.ok(!out.error,JSON.stringify(out));return out.result;}
async function check(name,code){const result=await run(code);report.cases.push({name,result});console.log(name,JSON.stringify(result));assert.ok(result&&Object.values(result).every(v=>v===true),JSON.stringify(result));}
try{
  report.static=checkMod('pregnancy');assert.equal(report.static.ok,true,JSON.stringify(report.static));
  const mods=all?{pregnancy_biological_realism:bio}:Object.fromEntries(folders.map(id=>[id,wanted.includes(id)]));
  report.start=await playStart({mods,viewport:mobile?{width:390,height:844}:{width:1500,height:1000}});
  await run(`localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify(all?folders:wanted)}));return true;`);
  if(zip){
    report.install=await run(`const append=document.head.appendChild;document.head.appendChild=function(n){if(n.tagName==='SCRIPT'&&n.src.endsWith('/wml/mods/pregnancy/mod.js')){queueMicrotask(()=>n.dispatchEvent(new Event('error')));return n;}return append.call(this,n);};try{return await WML.install([{path:'pregnancy.zip',blob:await(await fetch('wml/mods/pregnancy/pregnancy-3.7.0-20261101.zip')).blob()}]);}finally{document.head.appendChild=append;}`);
    assert.equal(report.install[0].mode,'browser');
  }
  report.reload=await playReload({});assert.deepEqual(report.reload.failed,[]);
  if(zip){
    report.installProof=await run(`let stack='';try{WML.use('pregnancy').shiftSchedule({},-1);}catch(e){stack=e.stack;}
      const status=WML.status();return{installed:status.installed.includes('pregnancy'),sourceNotes:status.sourceNotes,
        browserCode:/wml-installed\\/pregnancy\\/mod.js/.test(stack)};`);
    assert.equal(report.installProof.installed,true);assert.equal(report.installProof.browserCode,true);
    assert.ok(!report.installProof.sourceNotes.some(row=>row.id==='pregnancy'));
  }
  await run(`
    globalThis.d=WML.dev();globalThis.preg=WML.use('pregnancy');globalThis.a=preg.actorApi;globalThis.KEY=a.stateKey;
    d.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true,imageBackendMode:'off'});
    d.store.get().newGame();d.fn('store').setState({started:true,selectingArchetype:false,selectingBuilder:false,selectingPicks:false});
    await new Promise(r=>setTimeout(r,80));[...document.querySelectorAll('button')].find(b=>b.textContent==='건너뛰기')?.click();
    globalThis.__waywardSituationEventMod?.setSettings({enabled:false,pokerEnabled:false,outingEnabled:false});
    d.store.update(s=>({...s,pendingEvent:undefined,alertQueue:[],activeScene:{},phase:'prep',customers:[],economy:{...s.economy,gold:30000}}));
    globalThis.base=structuredClone(d.store.game());
    globalThis.project=(id,day=4)=>{const s=structuredClone(base),c=structuredClone(s.characters[s.primaryCharacterId]);
      s.primaryCharacterId=id;s.characters={[id]:{...c,id,name:id,affinities:{...c.affinities,vaginal:2}}};s.day=day;s.slot=(day-1)*1440+840;
      s.phase='prep';s.activeScene={};s.pendingEvent=undefined;s.alertQueue=[];s.errandSession=undefined;s.awayEvents=[];
      for(const r of Object.values(s.locations))r.occupants=[];s.locations.taproom.occupants=['wife',id,'player'];
      Object.defineProperty(s,KEY,{enumerable:true,get(){throw Error('READ MAIN PREGNANCY SLOT');}});return s;};
    globalThis.withoutMainRead=fn=>{const store=__WAYWARD_ADDON_API__.ue,read=store.getState;store.getState=()=>{throw Error('READ REAL STORE');};
      try{return fn();}finally{store.getState=read;}};
    Math.random=(()=>{let seed=1138;return()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};})();return true;
  `);
  await check('public namespace, backwards compatible actor API and shared implementations',`
    return {namespace:preg===__wc2PregnancyBirth265,versions:preg.npcApiVersion===1&&a.version===1,
      old:['newData','normalize','advance','capture','visual','resolveChild','medicine','isAware','subscribeOptions','renderVisual'].every(k=>typeof a[k]==='function'),
      added:['newData','normalizeData','captureFinishes','processMorning','applyMedicine','shiftSchedule','cycle','stage','renderStatus'].every(k=>typeof preg[k]==='function'&&preg[k]===a[k])};
  `);
  await check('normalization preserves custom fields and independent records',`
    const s=project('NPC A'),raw={extension:{value:7},ejaculationCounts:{vaginal:2}},before=JSON.stringify(raw);
    const one=withoutMainRead(()=>preg.normalizeData(raw,4,s)),two=preg.newData(4);one.spermDeposits.push({id:'one'});
    return{copy:JSON.stringify(raw)===before,extension:one.extension.value===7,counts:one.ejaculationCounts.vaginal===2&&one.ejaculationCounts.anal===0,independent:two.spermDeposits.length===0};
  `);
  await check('all actor calculations use supplied data while real store and main slot are inaccessible',`
    const original=JSON.stringify(d.store.game()),s=project('NPC A'),other=preg.newData(4),otherJSON=JSON.stringify(other);
    const result=withoutMainRead(()=>{const data=preg.normalizeData(null,4,s),out=a.advance(s,data);preg.cycle(4,out.data);preg.stage(out.data,4);a.visual(s,out.data);
      const host=document.createElement('div');preg.renderStatus(host,s,out.data);
      const draft=preg.normalizeData(out.data,4,s);preg.applyMedicine(draft,s,[]);preg.processMorning(draft,s,[],[],[]);preg.shiftSchedule(draft,2);
      return host.querySelector('.mother')?.textContent==='NPC A'&&out.character.name==='NPC A';});
    return{actor:result,main:JSON.stringify(d.store.game())===original,other:JSON.stringify(other)===otherJSON};
  `);
  await check('finish capture, duplicate suppression, anal exclusion and replaceable connection hooks',`
    const original=JSON.stringify(d.store.game()),s=project('NPC B'),data=preg.newData(4),counts={affection:0,aware:0,wife:0,player:0};
    const hooks=[d.hook('Mo',{around(){counts.affection++;return 100;}}),d.hook('pee',{around(){counts.aware++;return null;}}),
      d.hook('wifeLocation',{around(){counts.wife++;return 'taproom';}}),d.hook('playerLocation',{around(){counts.player++;return 'taproom';}})];
    let out,again,anal;
    try{withoutMainRead(()=>{s.activeScene={sex:{type:'sex',finish:{reason:'cum_inside',startedAtSlot:200}}};out=preg.captureFinishes(data,s,null);
      again=preg.captureFinishes(data,s,null);s.activeScene={sex:{type:'anal',finish:{reason:'cum_inside',startedAtSlot:201}}};anal=preg.captureFinishes(data,s,null);
      a.visual(s,data);const host=document.createElement('div');preg.renderStatus(host,s,data);
      s.activeScene={sex:{type:'sex',finish:{reason:'cum_inside',startedAtSlot:202}}};
      preg.captureFinishes(preg.newData(4),s,null,{partnerId:'guest',partnerName:'Guest'});});}finally{hooks.forEach(off=>off());}
    return{first:out.changed&&!again.changed,counts:data.ejaculationCounts.vaginal===1&&data.ejaculationCounts.anal===1,
      site:data.spermDeposits.length===1&&data.spermDeposits[0].sourceId==='player',aware:data.spermDeposits[0].wifeKnows&&data.spermDeposits[0].husbandKnows,
      hooks:Object.values(counts).every(n=>n>0),main:JSON.stringify(d.store.game())===original,anal:anal.changed};
  `);
  await check('medicine uses target cycle and returns logs without displaying or saving',`
    const s=project('Medicine target',8),data=withoutMainRead(()=>a.advance(s,null).data);data.pendingCycleMedicine={phase:'luteal',startDay:8};
    const logs=[],before=JSON.stringify(d.store.game());const changed=withoutMainRead(()=>preg.applyMedicine(data,s,logs));
    return{changed,phase:preg.cycle(8,data).id==='luteal',cleared:data.pendingCycleMedicine===null,logs:logs.length===1,main:JSON.stringify(d.store.game())===before};
  `);
  await check('conception, provider rules, stable child count and morning idempotency',`
    preg.setChance(100);const s=project('Conception target',4),data=withoutMainRead(()=>a.advance(s,null).data);
    const day=Array.from({length:100},(_,i)=>4+i).find(day=>preg.cycle(day,data).id==='ovulation');s.day=day;s.slot=(day-1)*1440+840;
    data.lastMorningDay=day-1;data.spermDeposits=[{id:'seed',day,slot:s.slot,amount:75,sourceId:'player',sourceName:'당신',wifeKnows:true,husbandKnows:true}];
    const notices=[],logs=[],alerts=[],before=JSON.stringify(d.store.game());
    const first=withoutMainRead(()=>preg.processMorning(data,s,notices,logs,alerts)),saved=JSON.stringify(data);
    const again=withoutMainRead(()=>preg.processMorning(data,s,[],[],[]));
    globalThis.conceived={data:structuredClone(data),day};
    return{pregnant:data.pregnancy?.fatherId==='player',notice:notices.length===1&&notices[0].motherName==='Conception target',
      count:data.pregnancy.childCount>=1&&data.pregnancy.childCount<=5,once:!again.changed&&JSON.stringify(data)===saved,
      provider:${bio?'!!data.biologicalCycle&&!!data.pregnancy.biologicalId':'!data.biologicalCycle'},main:JSON.stringify(d.store.game())===before,changed:first.changed};
  `);
  await check('birth returns effects and alerts; in-progress scene defers birth',`
    const data=structuredClone(conceived.data),due=conceived.day+preg.getGestationPlan().totalDays,s=project('Birth target',due);
    s.activeScene={sex:{type:'sex'}};const deferred=withoutMainRead(()=>preg.processMorning(data,s,[],[],[]));
    const held=!!data.pregnancy&&data.pregnancy.birthDeferred===true;s.activeScene={};s.phase='service';
    const notices=[],logs=[],alerts=[],before=JSON.stringify(d.store.game()),energy=s.characters[s.primaryCharacterId].stats.energy;
    const result=withoutMainRead(()=>preg.processMorning(data,s,notices,logs,alerts));
    return{held:deferred.changed&&held,birth:!data.pregnancy&&data.birthLog.length===1,count:data.birthLog[0].children.length===conceived.data.pregnancy.childCount,
      returned:result.birthEnergy===10&&notices[0].type==='birth'&&alerts.length===1,unapplied:s.characters[s.primaryCharacterId].stats.energy===energy,
      main:JSON.stringify(d.store.game())===before};
  `);
  await check('full schedule shift includes live dates and provider extensions, preserves history',`
    const data=structuredClone(conceived.data);data.cycleAnchor={day:3,cycleDay:2};data.pendingCycleMedicine={phase:'ovulation',startDay:9};
    data.spermDeposits=[{day:4,amount:1}];data.birthLog=[{id:'history',day:1}];data.pausedAtDay=5;
    if(${bio}){data.pregnancy.biologicalBirthDay=100;data.pregnancy.biologicalAcceleration={startDay:7};}
    const before=structuredClone(data),ret=withoutMainRead(()=>preg.shiftSchedule(data,3));let invalid=false;
    try{preg.shiftSchedule(data,-1);}catch(e){invalid=e instanceof RangeError;}
    return{same:ret===data,live:data.pregnancy.conceptionDay===before.pregnancy.conceptionDay+3&&data.spermDeposits[0].day===7,
      calendar:data.cycleAnchor.day===6&&data.pendingCycleMedicine.startDay===12&&data.lastMorningDay===before.lastMorningDay+3,
      history:data.birthLog[0].day===1&&data.pausedAtDay===5,invalid,
      provider:${bio?'data.biologicalCycle.rounds[0].startDay===before.biologicalCycle.rounds[0].startDay+3&&data.pregnancy.biologicalBirthDay===103&&data.pregnancy.biologicalAcceleration.startDay===10':'true'}};
  `);
  await check('OFF blocks calculation and high-level resume shifts once',`
    const s=project('Paused target',4),data=preg.newData(4);preg.setEnabled(false);
    const raw=JSON.stringify(data),morning=withoutMainRead(()=>preg.processMorning(data,s,[],[],[])),medicine=withoutMainRead(()=>preg.applyMedicine(data,s,[])),captured=withoutMainRead(()=>preg.captureFinishes(data,s));
    let out=withoutMainRead(()=>a.advance(s,data));const anchor=out.data.pausedAtDay;s.day=9;preg.setEnabled(true);
    out=withoutMainRead(()=>a.advance(s,out.data));const again=withoutMainRead(()=>a.advance(s,out.data));
    return{off:!morning.changed&&!medicine&&!captured.changed&&JSON.stringify(data)===raw,pause:anchor===4,
      resumed:out.data.pausedAtDay===null&&out.data.lastMorningDay===9,once:JSON.stringify(again.data)===JSON.stringify(out.data)};
  `);
  await check('native status ownership, NPC exclusions and removable compatibility filter',`
    await new Promise(r=>setTimeout(r,180));const panel=document.querySelector('[data-wc2-preg-main-panel]');if(!panel)throw Error('No native stats panel');
    const original=panel.querySelectorAll(':scope > [data-wc2-preg-auto]').length===1;
    panel.setAttribute('data-npc-status-panel','');await new Promise(r=>setTimeout(r,100));const excluded=!panel.querySelector('[data-wc2-preg-auto]');
    panel.removeAttribute('data-npc-status-panel');await new Promise(r=>setTimeout(r,100));
    const off=preg.registerStatusFilter('test',()=>false);await new Promise(r=>setTimeout(r,100));const filtered=!panel.querySelector('[data-wc2-preg-auto]');
    off();await new Promise(r=>setTimeout(r,100));const restored=!!panel.querySelector('[data-wc2-preg-auto]');
    const fake=document.createElement('div');fake.dataset.npcCharacterSheet='';fake.innerHTML='<div><h3>상태</h3>기력 흥분도</div>';document.body.append(fake);
    await new Promise(r=>setTimeout(r,100));const clean=!fake.querySelector('[data-wc2-preg-status]');fake.remove();
    return{original,excluded,filtered,restored,clean,identity:!preg.shouldInjectStatus(panel,project('different actor'))};
  `);
  await check('external renderer changes actor, does not overwrite sibling content or mutate data',`
    const host=document.createElement('section');host.id='pregnancy-api-render-test';host.style.cssText='position:fixed;top:70px;left:8px;width:min(350px,95vw);background:#1c1917;padding:8px;z-index:2147483647';
    host.innerHTML='<h3>API · NPC</h3>';document.body.append(host);const data=preg.newData(4),s=project('Screen A'),before=JSON.stringify(data);
    withoutMainRead(()=>preg.renderStatus(host,s,data));const first=host.querySelector('.mother')?.textContent;
    withoutMainRead(()=>preg.renderStatus(host,project('Screen B'),data));const second=host.querySelector('.mother')?.textContent;
    withoutMainRead(()=>preg.renderStatus(host,project('Screen B'),data));await new Promise(r=>setTimeout(r,120));
    await Promise.all([...host.querySelectorAll('img')].map(i=>i.decode().catch(()=>{})));
    return{first:first==='Screen A',second:second==='Screen B',single:host.querySelectorAll('[data-wc2-preg-body]').length===1,
      title:host.querySelector('h3').textContent==='API · NPC',unchanged:JSON.stringify(data)===before,images:[...host.querySelectorAll('img')].every(i=>i.naturalWidth>0),fits:host.scrollWidth<=host.clientWidth+1};
  `);
  await check('existing companion adapter continues independent pregnancy processing',`
    const v=WML.use('companions'),patch=WML.use('companions-compatible-pregnancy');
    d.store.dispatch({type:'companions/hire',options:{gender:'female',name:'API regression companion',employed:false,relationType:'childhood_friend',tier:'basic'}});
    const s=d.store.game(),p=v.list(s).find(p=>p.name==='API regression companion');if(!p)throw Error('Hire fixture failed');
    const data=patch.record(s,p.id).data,view=v.nativeView(s,p.id),before=JSON.stringify(s[KEY]);
    const out=withoutMainRead(()=>a.advance(view,data));const again=withoutMainRead(()=>a.advance(view,out.data));
    return{record:!!data,identity:out.character.name===p.name,main:JSON.stringify(d.store.game()[KEY])===before,
      once:JSON.stringify(out.data)===JSON.stringify(again.data),provider:${bio?'!!out.data.biologicalCycle':'!out.data.biologicalCycle'}};
  `);
  await check('existing brothel integration keeps its cycle policy, conception and birth records',`
    const b=__waywardBrothelPublic,bp=__waywardBrothelPregnancy,c=b.getConfig(),saved=structuredClone(c),original=structuredClone(d.store.game());
    const template=c.workers[0]||b.hireTemplate(original,{tier:'basic',name:'API brothel fixture'});
    const worker={...structuredClone(template),id:'api-brothel-fixture',name:'API brothel fixture',enabled:true};
    c.enabled=false;c.workers=[worker];b.saveConfig();let result;
    try{
      let s={...structuredClone(original),day:4,slot:5160,phase:'prep',pendingEvent:undefined,alertQueue:[],activeScene:{},[KEY]:{...original[KEY],lastMorningDay:4}};
      s=bp.recordService(s,worker,{id:'api-guest',name:'Guest',boldness:80});d.store.update(()=>s);
      const conceived=bp.getData().workers[worker.id]?.pregnancy;if(!conceived)throw Error('Brothel conception fixture failed');
      const count=conceived.childCount;
      d.store.update(s=>({...s,day:8,slot:10920,phase:'prep',pendingEvent:undefined,alertQueue:[],activeScene:{},[KEY]:{...s[KEY],lastMorningDay:8}}));
      const after=bp.getData(),birth=after.events.find(e=>e.type==='birth'&&e.workerId===worker.id);
      result={cycle:preg.getCycleInfo(4,{}).length===7,conception:conceived.fatherId==='api-guest',birth:!!birth&&!after.workers[worker.id].pregnancy,
        count:birth.children.length===count,child:!!birth.childDisposition,leave:d.store.game().mods.brothel.birthLeave[worker.id]===8};
    }finally{Object.assign(c,saved);b.saveConfig();d.store.update(()=>original);}
    return result;
  `);
  await check('native stats rendered through companion projection retain NPC identity without automatic main data',`
    const v=WML.use('companions'),person=v.list(d.store.game()).find(p=>p.name==='API regression companion');
    const project=v.displayRoot(root=>({...root,state:v.nativeView(root.state,person.id)}));
    const off=d.hook('WB',{after(result){return v.withDisplay(project,()=>result);}});let result;
    try{
      d.store.update(s=>({...s,characters:{...s.characters}}));await new Promise(r=>setTimeout(r,160));
      const panels=[...document.querySelectorAll('[data-wc2-preg-main-panel]')].filter(n=>n.dataset.wc2PregMainPanel===person.id);
      result={projected:panels.length>0,noMain:panels.every(n=>!n.querySelector('[data-wc2-preg-auto]'))};
    }finally{off();d.store.update(s=>({...s,characters:{...s.characters}}));await new Promise(r=>setTimeout(r,100));}
    return result;
  `);
  report.status=await playStatus({});assert.deepEqual(report.status.failed,[]);assert.deepEqual(report.status.pageErrors,[]);
  fs.writeFileSync(new URL('public-api-'+tag+'.jpg',import.meta.url),Buffer.from(await playScreenshot({}),'base64'));
  console.log('PASS',tag,report.cases.length,'cases');
}catch(error){report.error=String(error.stack||error);console.error(report.error);report.status=await playStatus({});process.exitCode=1;}
finally{fs.writeFileSync(new URL('public-api-'+tag+'.json',import.meta.url),JSON.stringify(report,null,2));await shutdown();}
process.exit(process.exitCode||0);
