// 실행: 게임 폴더에서 node wml/mods/pregnancy/tests/duration-visuals.mjs [--mobile]
// seed 1138; MCP의 별도 브라우저에서 기간·수정 보고·이미지·체력·저장을 검증합니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {playStart,playEval,playStatus,playStop,playReload,playScreenshot} from '../../../../MCP/lib/play.mjs';
import {checkMod} from '../../../../MCP/lib/check.mjs';

const mobile=process.argv.includes('--mobile');
const disabled=Object.fromEntries(fs.readdirSync('wml/mods',{withFileTypes:true}).filter(entry=>entry.isDirectory()).map(entry=>[entry.name,false]));
const stateKey='wc2PregnancyBirthMode265';
async function PregnancyVisualTest_평가하기(code){return (await playEval({code})).result}
async function PregnancyVisualTest_사진저장하기(name){
  fs.writeFileSync(`wml/mods/pregnancy/tests/${name}-${mobile?'mobile':'desktop'}.jpg`,await playScreenshot({}),{encoding:'base64'});
}
assert.equal(checkMod('pregnancy').ok,true);
try{
  const started=await playStart({mods:{...disabled,pregnancy:true,'addon-compat':true,
    'h-status':false,'h-status-pregnancy':false,'wife-view-mode':true,'pregnancy-compatible-wife-view-mode':true,
    brothel:false,'brothel-pregnancy':false,'brothel-compatible-festival':false,delivery:false,
    'delivery-compatible-brothel':false,'delivery-compatible-wife-view-mode':false,imagestudio:false},
    ...(mobile?{viewport:{width:390,height:844}}:{})});
  assert.deepEqual(started.failed,[]);
  const bootstrap=`
    for(let step=0;step<25;step++){
      if(document.querySelector('button[title="메뉴"]'))break;
      const buttons=[...document.querySelectorAll('button')].filter(button=>button.offsetParent);
      const button=buttons.find(item=>!item.disabled&&/^(예$|이해하고 동의합니다$|새 게임$|계속하기 —|시작 —|시작하기$|건너뛰기$)/.test(item.innerText.trim()))
        ||buttons.find(item=>item.innerText.trim().startsWith('마라'));
      if(!button)throw Error('새 게임 시작 버튼 없음');button.click();await new Promise(resolve=>setTimeout(resolve,150));
    }
    globalThis.pregnancyVisualTestSeed=1138;
    Math.random=function PregnancyVisualTest_난수만들기(){pregnancyVisualTestSeed=(Math.imul(pregnancyVisualTestSeed,1664525)+1013904223)>>>0;return pregnancyVisualTestSeed/4294967296};
    globalThis.pregnancyVisualTestBase=structuredClone(WML.dev().store.game());
    globalThis.PregnancyVisualTest_초기화하기=function(day=4,data={},active=false){
      document.getElementById('wc2-pregnancy-settings-265')?.remove();
      const api=WML.dev(),state=structuredClone(pregnancyVisualTestBase);
      state.day=day;state.slot=(day-1)*1440+540;state.phase='prep';
      state.pendingEvent=undefined;state.alertQueue=[];state.activeScene={};state.customers=[];state.errandSession=undefined;
      state.economy.debt=0;state.pendingCollectorVisit=false;state.deliveryAddon={};
      state.mods={...state.mods,'wife-view-mode':{...state.mods?.['wife-view-mode'],active}};
      for(const location of Object.values(state.locations))location.occupants=[];
      state.locations.taproom.occupants=['player',state.primaryCharacterId];
      const wife=state.characters[state.primaryCharacterId];
      Object.assign(wife,{currentTask:'idle',busyUntilSlot:0,sceneOverride:undefined,passedOutAtSlot:undefined,locationUntilSlot:undefined});wife.stats.energy=100;
      state['${stateKey}']={version:7,lastMorningDay:day-1,spermDeposits:[],...data};
      api.store.update(()=>state);return api.store.game();
    };
    globalThis.PregnancyVisualTest_수정하기=function(active=false){
      __wc2PregnancyBirth265.setChance(100);
      return PregnancyVisualTest_초기화하기(4,{spermDeposits:[{id:'test',day:4,slot:0,amount:10,sourceId:'player',sourceName:'남편(당신)',wifeKnows:true,husbandKnows:true}]},active);
    };
    globalThis.PregnancyVisualTest_대기하기=async function(){
      await new Promise(resolve=>setTimeout(resolve,250));
      await Promise.all([...document.querySelectorAll('.wc2pb-visual img')].map(image=>image.decode().catch(()=>{})));
    };
    PregnancyVisualTest_초기화하기();
  `;
  await PregnancyVisualTest_평가하기(bootstrap);
  const initial=await PregnancyVisualTest_평가하기(`
    const mod=__wc2PregnancyBirth265;mod.openSettings();await PregnancyVisualTest_대기하기();
    return {plan:mod.getGestationPlan(),options:mod.getOptions(),ranges:['early','middle','late'].map(stage=>{
      const input=document.querySelector('[data-wc2pb-'+stage+'-days]');return [input.min,input.max,input.value];
    }),noBiology:!document.querySelector('#wc2-pregnancy-settings-265').textContent.includes('생물학적 고증')};
  `);
  assert.equal(initial.plan.totalDays,5);
  assert.deepEqual(initial.plan.stages.map(({id,duration})=>[id,duration]),[['fertilization',1],['early',1],['middle',1],['late',1],['birth',1]]);
  assert.deepEqual(initial.ranges,[['1','90','1'],['1','100','1'],['1','90','1']]);assert.equal(initial.noBiology,true);
  assert.equal('biologicalGestation' in initial.options,false);
  console.log('PASS default five-day schedule, fixed endpoint days, UI ranges and removed biology option');
  const limits=await PregnancyVisualTest_평가하기(`
    const mod=__wc2PregnancyBirth265;
    for(const stage of ['early','middle','late']){
      const input=document.querySelector('[data-wc2pb-'+stage+'-days]');input.value='999';input.dispatchEvent(new Event('change',{bubbles:true}));
    }
    const max=mod.getGestationPlan();
    mod.setGestationDuration('early',0);mod.setGestationDuration('middle','bad');mod.setGestationDuration('late',-5);
    const min=mod.getGestationPlan();
    mod.setGestationDuration('early',2);mod.setGestationDuration('middle',3);mod.setGestationDuration('late',4);
    return {max,min,custom:mod.getGestationPlan()};
  `);
  assert.equal(limits.max.totalDays,282);assert.equal(limits.min.totalDays,5);assert.equal(limits.custom.totalDays,11);
  await playReload({});
  assert.deepEqual(await PregnancyVisualTest_평가하기('__wc2PregnancyBirth265.getGestationPlan()'),limits.custom);
  await PregnancyVisualTest_평가하기(bootstrap);
  await PregnancyVisualTest_평가하기(`for(const stage of ['early','middle','late'])__wc2PregnancyBirth265.setGestationDuration(stage,1);`);
  console.log('PASS real UI limit clamping, invalid values, custom schedule and reload persistence');
  for(const wifeView of [false,true]){
    const event=await PregnancyVisualTest_평가하기(`
      PregnancyVisualTest_수정하기(${wifeView});await PregnancyVisualTest_대기하기();
      const api=WML.dev(),state=api.store.game(),alert=state.pendingEvent.alert;
      const figure=[...document.querySelectorAll('[data-wc2pb-visual="event"]')].find(node=>node.offsetParent);
      const images=[...figure?.querySelectorAll('img')??[]];
      api.store.update(state=>({...state}));await PregnancyVisualTest_대기하기();
      return {title:alert.title,kind:alert.kind,pause:alert.pause,stage:__wc2PregnancyBirth265.getPregnancyStage().id,
        count:[...document.querySelectorAll('[data-wc2pb-visual="event"]')].filter(node=>node.offsetParent).length,label:figure?.querySelector('strong')?.textContent,
        fits:figure?.scrollWidth<=figure?.clientWidth+1,
        loaded:images.length===2&&images.every(image=>image.complete&&image.naturalWidth===400),
        animated:figure?.querySelector('.wc2pb-visual-image')?.dataset.animated==='1',
        once:api.store.game().log.filter(entry=>entry.pregnancyPaternityNotice?.type==='pregnancy').length===1,
        choice:!![...document.querySelectorAll('button')].find(button=>button.offsetParent&&button.textContent.includes('계속하기')),
        visual:__wc2PregnancyBirth265.getVisualState().file};
    `);
    assert.equal(event.kind,'wc2_pregnancy_reaction');assert.equal(event.stage,'fertilization');assert.equal(event.count,1);
    assert.equal(event.label,'D1수정 발생');assert.ok(event.title.includes('임신 보고'));
    for(const key of ['pause','loaded','animated','once','choice','fits'])assert.equal(event[key],true,JSON.stringify(event));
    assert.equal(event.visual,'two-cell-with-sperm-field-000.png');
    await PregnancyVisualTest_사진저장하기(wifeView?'fertilization-wife-view':'fertilization-report');
  }
  console.log('PASS paused morning report, D1 image animation, no duplicate events, native and wife-view screens');
  const energy=await PregnancyVisualTest_평가하기(`
    const api=WML.dev(),mod=__wc2PregnancyBirth265;PregnancyVisualTest_수정하기();
    api.store.dispatch({type:'resolve_event',choiceId:'dismiss'});await PregnancyVisualTest_대기하기();
    const dismissed=!document.querySelector('[data-wc2pb-visual="event"]');
    api.store.update(state=>api.fn('updateWife')({...state,slot:state.slot+1},wife=>({...wife,stats:{...wife.stats,energy:90}})));
    const fertilization=api.fn('wife')(api.store.game()).stats.energy;
    api.store.update(state=>({...state,day:5,slot:4*1440+540,phase:'prep'}));
    const before=api.fn('wife')(api.store.game()).stats.energy;
    api.store.update(state=>api.fn('updateWife')({...state,slot:state.slot+1},wife=>({...wife,stats:{...wife.stats,energy:before-10}})));
    return {dismissed,fertilization,early:api.fn('wife')(api.store.game()).stats.energy};
  `);
  assert.deepEqual(energy,{dismissed:true,fertilization:90,early:75});
  console.log('PASS fertilization day has no extra energy loss, early pregnancy retains +50% cost');
  const stages=await PregnancyVisualTest_평가하기(`
    const api=WML.dev(),mod=__wc2PregnancyBirth265;PregnancyVisualTest_수정하기();api.store.dispatch({type:'resolve_event',choiceId:'dismiss'});
    const rows=[];
    for(let day=4;day<=8;day++){
      api.store.update(state=>({...state,day,slot:(day-1)*1440+540,phase:'prep'}));
      mod.openSettings();await PregnancyVisualTest_대기하기();
      const stage=mod.getPregnancyStage(),visual=mod.getVisualState();
      rows.push({id:stage.id,file:visual.file,loaded:[...document.querySelectorAll('[data-wc2pb-current] img')].every(image=>image.naturalWidth===400),births:mod.getData().birthLog.length});
      document.getElementById('wc2-pregnancy-settings-265').remove();
    }
    api.store.update(state=>({...state,day:9,slot:8*1440+540,phase:'prep'}));
    const birth={pregnancy:mod.getData().pregnancy,count:mod.getData().birthLog.length,day:mod.getData().birthLog[0].day,energy:api.fn('wife')(api.store.game()).stats.energy};
    const saved=JSON.parse(JSON.stringify(api.store.game()));api.store.update(()=>saved);
    return {rows,birth,stable:mod.getData().birthLog.length===1};
  `);
  assert.deepEqual(stages.rows.map(row=>row.id),['fertilization','early','middle','late','birth']);
  assert.deepEqual(stages.rows.map(row=>row.file),['two-cell-with-sperm-field-000.png','thirty-cell-with-sperm-field-000.png',
    'development-4-embryo-uterine-lining.png','development-5-fetus-uterine-lining.png','development-5-fetus-uterine-lining.png']);
  assert.ok(stages.rows.every(row=>row.loaded&&row.births===0));
  assert.deepEqual(stages.birth,{pregnancy:null,count:1,day:9,energy:10});assert.equal(stages.stable,true);
  console.log('PASS every default stage and loaded image, five full days before birth, once-only birth');
  const custom=await PregnancyVisualTest_평가하기(`
    const api=WML.dev(),mod=__wc2PregnancyBirth265;
    mod.setGestationDuration('early',2);mod.setGestationDuration('middle',3);mod.setGestationDuration('late',4);
    PregnancyVisualTest_수정하기();api.store.dispatch({type:'resolve_event',choiceId:'dismiss'});
    const rows=Array.from({length:11},(_,age)=>mod.getPregnancyStage(4+age).id);
    const saved=JSON.parse(JSON.stringify(api.store.game()));api.store.update(()=>saved);
    const restored=mod.getGestationPlan().totalDays===11&&mod.getData().pregnancy.conceptionDay===4;
    api.store.update(state=>({...state,day:14,slot:13*1440+540,phase:'prep'}));const lastDay=mod.getPregnancyStage().id;
    api.store.update(state=>({...state,day:15,slot:14*1440+540,phase:'prep'}));
    const birthDay=mod.getData().birthLog[0].day;
    for(const stage of ['early','middle','late'])mod.setGestationDuration(stage,1);
    PregnancyVisualTest_수정하기();api.store.dispatch({type:'resolve_event',choiceId:'dismiss'});
    mod.setEnabled(false);api.store.update(state=>({...state,day:14,slot:13*1440+540,phase:'prep'}));
    const paused=mod.getPregnancyStage().id;mod.setEnabled(true);
    const resumed={day:mod.getData().pregnancy.conceptionDay,stage:mod.getPregnancyStage().id};
    api.store.update(state=>({...state,day:19,slot:18*1440+540,phase:'prep'}));
    return {rows,restored,lastDay,birthDay,paused,resumed,resumedBirth:mod.getData().birthLog[0].day};
  `);
  assert.deepEqual(custom.rows,['fertilization','early','early','middle','middle','middle','late','late','late','late','birth']);
  assert.equal(custom.restored,true);assert.equal(custom.lastDay,'birth');assert.equal(custom.birthDay,15);
  assert.equal(custom.paused,'fertilization');assert.deepEqual(custom.resumed,{day:14,stage:'fertilization'});assert.equal(custom.resumedBirth,19);
  console.log('PASS custom boundaries, save roundtrip, OFF pause/resume and shifted birth day');
  const maximum=await PregnancyVisualTest_평가하기(`
    const api=WML.dev(),mod=__wc2PregnancyBirth265;
    mod.setGestationDuration('early',90);mod.setGestationDuration('middle',100);mod.setGestationDuration('late',90);
    PregnancyVisualTest_수정하기();api.store.dispatch({type:'resolve_event',choiceId:'dismiss'});
    const boundaries=[4,5,94,95,194,195,284,285].map(day=>({day,id:mod.getPregnancyStage(day).id}));
    api.store.update(state=>({...state,day:285,slot:284*1440+540,phase:'prep'}));
    const lastDay=!!mod.getData().pregnancy;
    api.store.update(state=>({...state,day:286,slot:285*1440+540,phase:'prep'}));
    const birthDay=mod.getData().birthLog[0].day;
    PregnancyVisualTest_수정하기();api.store.dispatch({type:'resolve_event',choiceId:'dismiss'});
    api.store.update(state=>({...state,day:20,slot:19*1440+540,phase:'prep'}));
    for(const stage of ['early','middle','late'])mod.setGestationDuration(stage,1);
    const noImmediateBirth=!!mod.getData().pregnancy;
    api.store.update(state=>({...state,day:21,slot:20*1440+540,phase:'prep'}));
    return {boundaries,lastDay,birthDay,noImmediateBirth,shortenedBirth:mod.getData().birthLog[0].day};
  `);
  assert.deepEqual(maximum.boundaries.map(row=>row.id),['fertilization','early','early','middle','middle','late','late','birth']);
  assert.equal(maximum.lastDay,true);assert.equal(maximum.birthDay,286);assert.equal(maximum.noImmediateBirth,true);assert.equal(maximum.shortenedBirth,21);
  console.log('PASS maximum 282-day boundaries and birth, active pregnancy shortened only delivers on the next morning');
  const sperm=await PregnancyVisualTest_평가하기(`
    const mod=__wc2PregnancyBirth265;mod.setChance(0);const rows=[];
    for(const day of [2,4])for(const amount of [0,1,75,76,150,151,225,226,300,301,500]){
      PregnancyVisualTest_초기화하기(day,{lastMorningDay:day,spermDeposits:amount?[{id:'a',day,slot:0,amount,sourceId:'guest',sourceName:'방문객'}]:[]});
      mod.openSettings();await PregnancyVisualTest_대기하기();
      rows.push({day,amount,visual:mod.getVisualState(),loaded:[...document.querySelectorAll('[data-wc2pb-current] img')].every(image=>image.naturalWidth===400)});
    }
    PregnancyVisualTest_초기화하기(2,{lastMorningDay:2,spermDeposits:[{id:'a',day:2,slot:1,amount:75,sourceId:'guest',sourceName:'방문객'},
      {id:'b',day:2,slot:2,amount:75,sourceId:'guest',sourceName:'방문객'}]});
    mod.openSettings();await PregnancyVisualTest_대기하기();
    return {rows,owners:mod.getVisualState().spermOwners,overflow:document.documentElement.scrollWidth>innerWidth,
      figureOverflow:[...document.querySelectorAll('.wc2pb-visual')].some(node=>node.scrollWidth>node.clientWidth+1)};
  `);
  assert.ok(sperm.rows.every(row=>row.loaded),JSON.stringify(sperm.rows.filter(row=>!row.loaded)));
  assert.equal(sperm.rows.find(row=>row.day===4&&row.amount===0).visual.file,'ovum-unfertilized-count-000.png');
  assert.deepEqual(sperm.owners,['방문객']);assert.equal(sperm.overflow,false);assert.equal(sperm.figureOverflow,false);
  await PregnancyVisualTest_평가하기(`document.querySelector('[data-wc2pb-current]').closest('section').scrollIntoView({block:'center'});`);
  await PregnancyVisualTest_사진저장하기('reproductive-settings');
  console.log('PASS ovulation and sperm-only images at all tier boundaries, donor grouping and viewport layout');
  const status=await playStatus({});assert.deepEqual(status.failed,[]);assert.deepEqual(status.pageErrors,[]);
  console.log(`ALL PASS ${mobile?'mobile':'desktop'}`);
}finally{await playStop({})}
