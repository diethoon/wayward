# 생식 상태 이미지

사용자가 제공한 `pregnancy-open-visuals/assets`의 이름 기반 PNG 27개를 복사했습니다. 이미지 픽셀은 수정하지 않았습니다. 원본 자료의 자산 세트 식별자는 `wayward-reproductive-complete-all-v1-20261016`입니다.

`development-1-fertilization-entry-A.png`와 `-B.png`는 아침 수정 보고에서 사용합니다. 상태 화면은 `two-cell-with-sperm-field-*.png`(수정일), `thirty-cell-with-sperm-field-*.png`(초기), `development-4-embryo-uterine-lining.png`(중기), `development-5-fetus-uterine-lining.png`(후기·출산일)를 사용합니다.

임신하지 않은 상태는 배란 중 `ovum-unfertilized-count-000.png` 또는 `ovum-surrounded-level-*.png`, 그 밖의 주기에서는 `sperm-only-level-*-count-*.png`를 사용합니다. 모든 PNG는 400×400입니다. 같은 파일명을 유지해 교체할 수 있으며 모드를 다시 불러오면 반영됩니다.
