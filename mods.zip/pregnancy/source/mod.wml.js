// 임신·출산 — WML 포팅판
// 원본: pregnancy.src.js (md5 5aae48bea4b47f2ea647decda4cb7a11), 9-30 한글판 모드 매니저용 애드온.
// 원본 코드는 아래 setup() 안에서 그대로 실행돼요. 게임 함수 연결은 addon-compat 모드가 해 줘요.
WML.define({
  id: "pregnancy",
  author: "Hina_Lover",
  name: "임신·출산",
  version: "3.7.0",
  game: "2026-11-01",
  lang: 'ko',
  description: "수정일과 임신 단계별 기간 조절, 생식 상태 이미지와 아침 수정 보고를 지원합니다. 친부 추정과 출산 후 아이 처치 상의를 함께 기록합니다.",
  requires: ["addon-compat"],
  loadAfter: ["h-status"],
  conflicts: [],
  symbols: {
    "PregnancyWorkTick": {"raw":{"2026-11-01":"Kje"}},
    "PregnancyStatusPanel": {"raw":{"2026-11-01":"Goe"},"doc":"Native main-character stats panel; identifies automatic pregnancy status placement."},
    "PregnancyConversationMenu": {"raw":{"2026-11-01":"Su"},"doc":"Builds the native wife conversation menu, including clothing choices."},
    "PregnancyConversationBlockReason": {"raw":{"2026-11-01":"pee"},"doc":"Checks whether the wife is asleep or unconscious before a conversation."},
    "PregnancyHusbandAffection": {"raw":{"2026-11-01":"Mo"},"doc":"Existing affection/desire toward the husband, read from the wife feelings."}
  },

  setup(wmlApi) {
    const api = globalThis.__waywardPauseSettingsUiFactory.connect(wmlApi, {"id":"pregnancy","label":"임신 / 출산모드 설정","bindings":{"2026-10-04":{"store":"ae","settingsStore":"At","React":"Z","jsx":"u","ActionButton":"Ze","ActionPanel":"aO","wife":"_","updateWife":"O","updateCharacter":"nn","log":"N","tick":"Jt","intoxLabel":"In","playerId":"fe","wifeId":"Re","locationOf":"$e","wifeLocation":"_e","playerLocation":"bt","moveOccupant":"Pt","patronScene":"Y","playerSexScene":"Le","setScene":"MV","patronSceneLocation":"tt","isSexualStage":"it","sceneDef":"ls","sceneOutfitState":"bx","garmentWorn":"vr","exposureSummary":"nf","patronWatchChoices":"Xae","patronChoice":"tNe","startPlayerSex":"_p","playerSexEvent":"Fl","ensureHusbandLed":"F8","addJoinedPatron":"nfe","joinSlots":"NH","registerAlert":"nr","queueAlert":"gn","drainAlerts":"gl","imagePrompt":"r8","imageKey":"s8","imageKeyOf":"n8","imageDescriptor":"o8","makeCustomer":"ff","addCustomer":"Ka","carryToBed":"RDe","talkToWife":"EF","actionTimes":"Oo","addFeeling":"we","addIdentityStrainFromPatronAct":"Kf","getCustomerLocation":"Yn","getEffectiveAttributes":"B","heroineConditioningMax":"QX","heroineDriveCalc":"si","moveWife":"pt","outfits":"fh","patronControlCustomerLocation":"ht","wifeById":"ul","wifePreview":"gue","reduceGameAction":"wT","brothelLog":"hs","decisionCategories":"bo","decisionResolve":"G$e","manaMax":"ms","minuteTick":"gp","recordPlayerTone":"Rt","wives":"mh","imageBackend":"Eh","brothelCustomerBusy":"XO","buildPatronMoveCandidates":"Phe","ejectCustomer":"Q5","endPatronInteraction":"jt","finishBackRoomService":"xF","forceAttemptChance":"Ppe","patronControlAcquaintanceStop":"_Ie","patronControlAttemptRoll":"Iy","patronControlBackRoomOpen":"Tr","patronControlBareForPushIn":"O5","patronControlChooseMove":"Yhe","patronControlCoercionEscape":"cpe","patronControlFavorTable":"h3","patronControlHerBackRoomProposal":"ipe","patronControlIntentEvolve":"z$","patronControlJoinerComfort":"wh","patronControlJoinerPushIn":"jIe","patronControlLineUp":"Gce","patronControlLungePlan":"Vre","patronControlMortifyingCheck":"b$","patronControlMoveCustomer":"Yt","patronControlNaturalEnd":"hI","patronControlPatronBackRoomProposal":"ape","patronControlPatronDrift":"Kbe","patronControlPlayerAway":"Tt","patronControlPositionWeights":"Fhe","patronControlPrivateSession":"wpe","patronControlPrivateSessionInfo":"a0","patronControlPushIn":"qce","patronControlPushInAnalReaction":"p6","patronControlPushInReaction":"R6","patronControlRelentChance":"Bpe","patronControlRequestTable":"E2e","patronControlSelfEscalationRoll":"Qre","patronControlShameStop":"dpe","patronControlSlotFree":"kS","patronControlSmallRequest":"R2e","patronControlStageLabel":"hG","patronControlStrengthContest":"Za","patronControlTacticTable":"lIe","patronControlUndressAttempt":"AIe","patronControlVerbalAsk":"$5e","patronControlWitnessesFor":"Ks","patronControlYieldRoll":"pB","playerActionPublicRefusal":"Rs","processPatronGroupJoin":"BS","processPatronGroupParticipants":"WS","processPatronInteractionTick":"R7","recordPatronMistreatment":"yl","recordPatronReach":"K5e","resolvePatronEscalation":"ub","resolvePatronForce":"gB","rotatePatronGroupAfterPrimary":"Gie","selectPatronTactic":"gIe","startPatronInteraction":"Go","transitionPatronStage":"Dn","evaluateIntimacy":"Pe","getMaritalDrift":"E4","getPatronAttachment":"Uo","nudgeRelationship":"Mo","recordAffection":"Iw","recordIntimateHistory":"Wd","recordPatronBoundary":"Qi","brothelRoomLabels":"bO","imageRoom":"lue","waitressAlternative":"u$","waitressAvailable":"Bd","waitressChooseOrder":"Jle","waitressConsume":"_w","waitressIncome":"Qt","waitressMissing":"CP","waitressPrice":"d$","waitressRecordDrink":"vw","waitressRecordWord":"VB","playerActionRespond":"P1e","playerActionTopicFatigue":"GY","playerActionTouchedOut":"er","promptJoin":"J6","promptRoomFilter":"$de","promptGenParams":"q6","outfitById":"Ot","saveSlotInfo":"Mb","listDayStarts":"ZI","saveDayStart":"UDe","wifePortraits":"z6e","resentment":"Ue","marriageBond":"VT","wakeUp":"FI","gameOverScreen":"HLe","allureScore":"Ir","normalVisitRoll":"nhe","lodgingChance":"IB","worldTick":"Dp","hotkeyAction":"sG","confirmAction":"N4e","busyTask":"X0","imageManifest":"Wb","imageServerUrl":"Cs","imageGenerate":"LPe","imageQueue":"g6e","imageBackendProbe":"JU","imageBackendForget":"UD","imagePackReset":"qD","imageAutoProbeAllowed":"KU","PregnancyConversationMenu":"Vc","PregnancyConversationBlockReason":"AF","PregnancyHusbandAffection":"sn"}, "2026-11-01": {"store":"ae","settingsStore":"at","React":"J","jsx":"u","ActionButton":"ht","ActionPanel":"SB","wife":"_","updateWife":"C","updateCharacter":"rn","log":"j","tick":"Jt","intoxLabel":"Sn","playerId":"ge","wifeId":"Ee","locationOf":"Ae","wifeLocation":"we","playerLocation":"vt","moveOccupant":"Ht","patronScene":"U","playerSexScene":"Be","setScene":"dK","patronSceneLocation":"Je","isSexualStage":"ct","sceneDef":"Sr","sceneOutfitState":"KMe","garmentWorn":"Zr","exposureSummary":"_g","patronWatchChoices":"Dbe","patronChoice":"uZ","startPlayerSex":"uh","playerSexEvent":"Kl","ensureHusbandLed":"ihe","addJoinedPatron":"C3e","joinSlots":"eU","registerAlert":"ar","queueAlert":"_n","drainAlerts":"oi","imagePrompt":"DR","imageKey":"zz","imageKeyOf":"CR","imageDescriptor":"RR","makeCustomer":"Ag","addCustomer":"Fi","carryToBed":"r5e","talkToWife":"gee","actionTimes":"tn","addFeeling":"Se","addIdentityStrainFromPatronAct":"Qf","getCustomerLocation":"Jn","getEffectiveAttributes":"B","heroineConditioningMax":"eue","heroineDriveCalc":"il","moveWife":"Nt","outfits":"Oi","patronControlCustomerLocation":"et","wifeById":"$m","wifePreview":"WL","reduceGameAction":"p5","brothelLog":"ds","decisionCategories":"Ho","decisionResolve":"DFe","manaMax":"Ys","minuteTick":"ry","recordPlayerTone":"qn","wives":"kr","imageBackend":"yh","brothelCustomerBusy":"z5","buildPatronMoveCandidates":"Zve","ejectCustomer":"HR","endPatronInteraction":"Rt","finishBackRoomService":"IV","forceAttemptChance":"iIe","patronControlAcquaintanceStop":"OUe","patronControlAttemptRoll":"g0","patronControlBackRoomOpen":"xS","patronControlBareForPushIn":"Q2","patronControlChooseMove":"sxe","patronControlCoercionEscape":"YOe","patronControlFavorTable":"wY","patronControlHerBackRoomProposal":"dGe","patronControlIntentEvolve":"AC","patronControlJoinerComfort":"ch","patronControlJoinerPushIn":"KUe","patronControlLineUp":"ADe","patronControlLungePlan":"s8e","patronControlMortifyingCheck":"b_","patronControlMoveCustomer":"lo","patronControlNaturalEnd":"GC","patronControlPatronBackRoomProposal":"cGe","patronControlPatronDrift":"NHe","patronControlPlayerAway":"yt","patronControlPositionWeights":"rxe","patronControlPrivateSession":"ZJ","patronControlPrivateSessionInfo":"Nh","patronControlPushIn":"jDe","patronControlPushInAnalReaction":"N9","patronControlPushInReaction":"wz","patronControlRelentChance":"mIe","patronControlRequestTable":"JGe","patronControlSelfEscalationRoll":"l8e","patronControlShameStop":"WOe","patronControlSlotFree":"G$","patronControlSmallRequest":"QGe","patronControlStageLabel":"Ote","patronControlStrengthContest":"el","patronControlTacticTable":"$Ue","patronControlUndressAttempt":"zUe","patronControlVerbalAsk":"A7e","patronControlWitnessesFor":"hs","patronControlYieldRoll":"Xq","playerActionPublicRefusal":"ir","processPatronGroupJoin":"gN","processPatronGroupParticipants":"XS","processPatronInteractionTick":"cZ","recordPatronMistreatment":"yl","recordPatronReach":"bPe","resolvePatronEscalation":"_b","resolvePatronForce":"Zq","rotatePatronGroupAfterPrimary":"jle","selectPatronTactic":"MUe","startPatronInteraction":"Xo","transitionPatronStage":"js","evaluateIntimacy":"We","getMaritalDrift":"i4","getPatronAttachment":"Uo","nudgeRelationship":"ko","recordAffection":"Iw","recordIntimateHistory":"Om","recordPatronBoundary":"tl","brothelRoomLabels":"LB","imageRoom":"ER","waitressAlternative":"JA","waitressAvailable":"zr","waitressChooseOrder":"uTe","waitressConsume":"v_","waitressIncome":"vo","waitressMissing":"K7","waitressPrice":"zv","waitressRecordDrink":"ox","waitressRecordWord":"vK","playerActionRespond":"IWe","playerActionTopicFatigue":"sX","playerActionTouchedOut":"er","promptJoin":"Yz","promptRoomFilter":"uMe","promptGenParams":"Dz","outfitById":"Ot","saveSlotInfo":"Bk","listDayStarts":"h$","saveDayStart":"y5e","wifePortraits":"Uit","resentment":"qe","marriageBond":"dA","wakeUp":"vD","gameOverScreen":"kat","allureScore":"aa","normalVisitRoll":"wTe","lodgingChance":"mK","worldTick":"py","hotkeyAction":"KG","confirmAction":"NYe","busyTask":"sv","imageManifest":"bh","imageServerUrl":"es","imageGenerate":"xst","imageQueue":"eit","imageBackendProbe":"FD","imageBackendForget":"iM","imagePackReset":"t_","imageAutoProbeAllowed":"eoe","PregnancyConversationMenu":"Su","PregnancyConversationBlockReason":"pee","PregnancyHusbandAffection":"Mo"}}});
    api.ui.menuSettings({label:"임신 / 출산모드 설정",legacyButton:"[data-wc2-preg-menu]",windowSelector:"#wc2-pregnancy-settings-265",attributes:{"data-wc2-preg-menu":"1"},onClick:()=>globalThis.__wc2PregnancyBirth265?.openSettings?.()});
    try { api.ui.pauseSettings?.({label:{ko:'임신 / 출산모드 설정',en:'Pregnancy settings'},attributes:{'data-wc2-preg-menu':'1'},onClick:()=>globalThis.__wc2PregnancyBirth265?.openSettings?.()}); } catch (error) { console.warn("[pregnancy] 공통 설정 메뉴 등록 실패: 기존 직접 삽입 방식으로 계속합니다.", error); }

    // ---- 원본 애드온 ----
/* Wayward 2026-09-30 - Pregnancy Addon
 * Patron act and climax alerts use the game's native pendingEvent alert format.
 */
/* --- Pregnancy / birth mode, Wayward 2026-09-30 --- */
const Pregnancy_Wml=api;
(()=>{
  'use strict';
  if(globalThis.__WAYWARD_PREGNANCY_ADDON_LOADED__)return;
  globalThis.__WAYWARD_PREGNANCY_ADDON_LOADED__=true;

  const STATE_KEY='wc2PregnancyBirthMode265';
  const OPTIONS_KEY='wc2-pregnancy-birth-options-v1';
  const actorOptionListeners=new Set();
  const DEFAULT_OPTIONS={
    enabled:true,
    cycleLength:7,
    earlyDays:1,
    middleDays:1,
    lateDays:1,
    showActualFather:false,
    childDispositionConsultation:true,
    adoptionFeeMode:'random',
    adoptionFeeFixed:75,
    adoptionFeeMin:50,
    adoptionFeeMax:100,
    conceptionChance:30,
    pauseOnPatronClimax:true,
    pauseOnPatronActStart:true,
    showPatronEventAlerts:true
  };
  const VAGINAL_PLAYER_SCENES=new Set(['sex','riding','standing_sex','sex_rough','doggy_style','spooning']);
  const ANAL_PLAYER_SCENES=new Set(['anal']);
  const PATRON_ACT_LABELS={
    handjob_patron:'손으로 해주기',
    blowjob_patron:'구강성교',
    sex_patron:'삽입'
  };
  const MAX_SEEN_FINISHES=120;
  const MAX_BIRTH_LOG=200;
  // Each pair is [spoken dialogue, private thought]. Only the wife's beliefs
  // and existing affection/preference scores select a condition.
  const Pregnancy_반응문구목록={
    pregnancy:{
      husband_welcomed:[
        ['아이가 생긴 것 같아. 당신의 아이일 가능성이 높다고 생각해. 앞으로의 일도 같이 준비하자.','바라던 소식이다. 아직 부모가 된다는 실감은 없지만, 그와 함께라면 차근차근 준비할 수 있을 것 같다.'],
        ['당신과의 관계를 생각하면 당신의 아이 같아. 나, 이 아이를 만나고 싶어.','기쁜 마음이 먼저 든다. 막연히 상상하던 일이 내 몸 안에서 시작되었다는 게 신기하다.'],
        ['임신했어. 당신의 아이일 거라고 생각해. 오늘은 우리 둘이 이 소식을 천천히 받아들이고 싶어.','그에게 먼저 말하고 싶었다. 기대만큼 두려움도 있지만, 아이를 갖고 싶다는 마음은 분명하다.']
      ],
      husband_hesitant:[
        ['임신한 것 같아. 당신의 아이일 가능성이 높지만, 아직 마음의 준비가 다 되지는 않았어.','그의 아이라면 좋겠다는 생각과 지금 감당할 수 있을지 걱정하는 마음이 함께 든다.'],
        ['당신의 아이 같아. 기쁘다고 바로 말하기는 어려워. 조금만 생각할 시간을 줘.','아이를 싫어하는 건 아니다. 다만 앞으로 달라질 생활이 아직 선명하게 그려지지 않는다.'],
        ['아이가 생겼어. 당신의 아이라고 추정하고 있어. 앞으로 어떻게 지낼지부터 이야기하자.','기대와 부담 중 어느 쪽이 더 큰지 모르겠다. 먼저 해야 할 일을 하나씩 정하면 마음도 정리될까.']
      ],
      husband_unwanted:[
        ['임신했어. 당신의 아이일 가능성이 높지만, 나는 지금 임신을 원하지 않았어. 내 이야기도 들어 줘.','그의 아이일 것이라는 추정이 내 망설임을 없애 주지는 않는다. 원하지 않았다는 마음부터 인정하고 싶다.'],
        ['당신의 아이 같아. 하지만 지금은 기뻐해 달라는 말을 받아들이기 어려워.','이 소식을 반겨야 한다는 부담까지 짊어지고 싶지 않다. 내가 어떤 상태인지 먼저 말해야겠다.'],
        ['아이가 생긴 것 같아. 당신의 아이라고 생각하지만, 앞으로의 일이 많이 부담스러워.','갑자기 내 생활의 방향이 바뀐 느낌이다. 그의 반응보다 내 몸과 마음을 추스를 시간이 필요하다.']
      ],
      other_welcomed:[
        ['임신했어. 내가 아는 관계를 생각하면 {partner}의 아이일 가능성이 높아. 나는 이 아이를 만나고 싶어.','그 사람에게 향한 마음 때문에 기대가 앞선다. 그래도 친부에 대한 내 추정을 사실처럼 단정하지는 말아야 한다.'],
        ['아이가 생긴 것 같아. {partner}의 아이일 거라고 생각해. 이 소식을 숨기기보다 이야기하고 싶었어.','아이를 갖고 싶다는 마음은 분명하다. 이제 그 마음과 우리 사이에 생길 변화를 함께 마주해야 한다.'],
        ['내가 추정하는 친부는 {partner}야. 임신했다는 걸 알고 나니, 앞으로를 준비하고 싶어졌어.','그 사람의 아이일 가능성을 떠올리면 설렌다. 기대만으로 모든 문제가 해결되지는 않으니 준비도 필요하다.']
      ],
      other_hesitant:[
        ['임신했어. {partner}의 아이일 가능성이 높다고 생각해. 아직 내 마음을 어떻게 말해야 할지 모르겠어.','그 사람에게 느끼는 마음과 아이를 갖는 일은 같은 문제가 아니다. 둘을 나누어 생각할 시간이 필요하다.'],
        ['아이가 생긴 것 같아. 내 추정으로는 {partner}의 아이야. 지금은 기대보다 혼란이 커.','친부를 추정할 수 있어도 앞으로의 관계까지 정해지는 건 아니다. 어디서부터 이야기해야 할까.'],
        ['{partner}의 아이일 것 같아. 임신은 확인했지만, 당장 기쁘다고 말할 준비는 안 됐어.','아이를 만나고 싶은 마음도 있다. 하지만 그 마음만으로 지금의 부담을 지워 버릴 수는 없다.']
      ],
      other_unwanted:[
        ['임신했어. {partner}의 아이일 가능성이 높다고 생각해. 나는 이런 임신을 원하지 않았어.','그 사람과의 관계가 있었다는 것과 아이를 원했다는 것은 다르다. 내 의향을 멋대로 해석하게 두고 싶지 않다.'],
        ['아이가 생긴 것 같아. 내 추정은 {partner} 쪽이야. 지금은 이 상황을 받아들이기가 힘들어.','앞으로의 일이 한꺼번에 밀려온다. 마음에도 없는 기쁜 표정을 짓기보다 내 부담을 먼저 설명하고 싶다.'],
        ['{partner}의 아이일 것 같아. 이 소식이 내게는 반갑지 않다는 걸 알아 줬으면 해.','누구의 아이일지 추정하는 일보다, 원하지 않았던 임신을 어떻게 마주할지가 지금은 더 어렵다.']
      ],
      uncertain_welcomed:[
        ['임신했어. 아이를 만나고 싶은 마음은 있지만, 친부는 아직 확실히 말할 수 없어.','내가 아는 정보로는 친부를 단정할 수 없다. 그래도 아이를 기다리고 싶다는 내 마음까지 불확실한 것은 아니다.'],
        ['아이가 생긴 것 같아. 친부에 대한 추정은 아직 불명확해. 먼저 아이를 맞을 준비를 이야기하자.','기대가 앞서지만, 바라는 상대를 친부라고 믿어 버려서는 안 된다. 아는 것과 바라는 것을 구분해야 한다.'],
        ['임신 소식은 반가워. 다만 누구의 아이인지는 내 추정만으로 결정할 수 없어.','아이를 기다리는 마음과 친부에 대한 의문이 함께 있다. 의문을 억지로 없애지 않고도 준비는 시작할 수 있다.']
      ],
      uncertain_hesitant:[
        ['임신했어. 친부도 확신하기 어렵고, 아이를 갖는 일에 대한 내 마음도 아직 정리되지 않았어.','내가 아는 것부터 차분히 정리해야겠다. 모르는 일을 확실한 것처럼 말하면 혼란만 더 커질 것이다.'],
        ['아이가 생긴 것 같아. 누구의 아이인지 단정할 수 없어. 앞으로의 일도 조금 천천히 이야기하고 싶어.','기쁘기도 하고 두렵기도 하다. 친부를 정할 수 없다고 해서 내 감정까지 하나로 정할 필요는 없다.'],
        ['임신은 확인했어. 하지만 친부에 대한 추정이 불확실해서, 지금은 쉽게 결론 내리고 싶지 않아.','막연한 기대에 기대거나 최악만 상상하지 말자. 현재의 정보와 내 의향부터 따로 생각해야 한다.']
      ],
      uncertain_unwanted:[
        ['임신했어. 친부는 확실히 알 수 없고, 나는 지금 임신을 원하지 않았어.','모르는 것이 많다는 사실이 더 부담스럽다. 그래도 원하지 않았다는 내 마음은 분명히 말할 수 있다.'],
        ['아이가 생긴 것 같아. 누구의 아이인지 단정할 수 없어. 이 상황이 내게는 많이 버거워.','확실한 답을 내놓으라는 요구까지 받고 싶지는 않다. 지금 가진 정보로는 모른다고 말하는 것이 맞다.'],
        ['임신 소식이 반갑지는 않아. 친부도 불명확하니, 추정을 사실처럼 몰아가지 않았으면 해.','누구의 아이인가 하는 질문에 내 상태가 가려질까 걱정된다. 내 몸과 마음에 대한 이야기도 필요하다.']
      ]
    },
    birth:{
      husband_welcomed:[
        ['아이가 태어났어. 당신의 아이일 거라고 생각해. 지금은 지쳤지만, 드디어 만났다는 게 기뻐.','바라던 아이를 만났다는 실감이 조금씩 난다. 기쁜 마음과 별개로 몸을 회복할 시간은 충분히 갖고 싶다.'],
        ['당신의 아이일 가능성이 높다고 생각해. 아이에 대한 일을 이야기하고, 오늘은 잠깐 쉬고 싶어.','아이를 다시 만날 때는 조금 더 기운이 있었으면 좋겠다. 지금은 안도감 속에서 쉬고 싶다.'],
        ['출산했어. 당신의 아이라고 추정하고 있어. 앞으로도 이 아이 이야기를 같이 나누고 싶어.','기다림이 끝났고 새로운 생활이 시작됐다. 모든 걸 잘할 자신은 없어도 아이를 기다린 마음은 그대로다.']
      ],
      husband_hesitant:[
        ['아이가 태어났어. 당신의 아이 같아. 안심은 되지만, 아직 부모가 됐다는 실감은 없어.','출산이 끝났다고 망설임까지 끝나는 건 아니다. 내 마음이 따라올 시간을 조금 더 갖고 싶다.'],
        ['출산했어. 당신의 아이일 가능성이 높다고 생각해. 기쁜지 두려운지, 지금은 잘 모르겠어.','몸이 지쳐서인지 여러 감정이 뒤섞인다. 오늘 당장 한 가지 마음으로 설명할 필요는 없을 것이다.'],
        ['아이가 태어났어. 당신의 아이라고 추정하지만, 앞으로의 일은 천천히 정하고 싶어.','당장 출산을 마친 것은 다행이다. 그렇다고 내가 준비됐다는 뜻은 아니니, 해야 할 일을 나누어 생각하자.']
      ],
      husband_unwanted:[
        ['아이가 태어났어. 당신의 아이 같아. 하지만 출산했다고 내 마음이 갑자기 바뀐 건 아니야.','아이에게 느낄 마음과 원하지 않았던 임신에 대한 감정은 따로 살펴야 한다. 둘을 억지로 같게 만들고 싶지 않다.'],
        ['출산은 끝났어. 당신의 아이일 가능성이 높다고 생각해. 지금은 축하보다 휴식과 도움이 필요해.','몸을 회복하는 것부터 시작하고 싶다. 다른 사람이 기대하는 표정에 맞추기에는 아직 여유가 없다.'],
        ['당신의 아이라고 추정하고 있어. 출산은 끝났으니, 오늘은 내 상태를 먼저 이야기하고 싶어.','출산까지 마쳤다. 나도 회복과 마음 정리에 필요한 도움을 구체적으로 말해야겠다.']
      ],
      other_welcomed:[
        ['아이가 태어났어. {partner}의 아이일 가능성이 높다는 내 생각은 같아. 아이를 만난 건 기뻐.','아이를 기다린 마음이 실제 만남으로 이어졌다. 하지만 출산 자체가 친부에 대한 증거가 되는 것은 아니다.'],
        ['출산했어. 내가 추정하는 친부는 {partner}야. 앞으로의 관계도 피하지 않고 이야기하고 싶어.','아이를 만나고 싶다는 마음은 변하지 않았다. 이제 기대와 관계의 책임을 함께 생각해야 한다.'],
        ['{partner}의 아이일 거라고 생각해. 출산을 마쳤으니, 나는 잠깐 쉬면서 다음 일을 준비할게.','출산이 끝나서 안도한다. 아이를 반기는 마음을 지키면서도 내 몸을 무리하게 몰아붙이지는 말자.']
      ],
      other_hesitant:[
        ['아이가 태어났어. {partner}의 아이 같아. 출산이 끝나도 내 마음은 아직 복잡해.','아이를 만났다는 안도와 앞으로의 관계에 대한 걱정이 함께 남아 있다. 하나가 다른 하나를 지우지는 않는다.'],
        ['출산했어. {partner}의 아이일 가능성이 높다고 생각해. 앞으로 어떻게 지낼지는 조금 더 이야기해야겠어.','아이의 존재가 모든 관계를 정리해 주지는 않는다. 쉬고 난 뒤 내가 원하는 생활부터 생각해 보자.'],
        ['내 추정은 여전히 {partner} 쪽이야. 출산은 마쳤으니, 지금은 몸과 마음을 추스르고 싶어.','지금 느끼는 망설임을 숨기면 나중에 더 어려워질 것이다. 회복한 뒤에도 차분히 말할 기회를 갖고 싶다.']
      ],
      other_unwanted:[
        ['아이가 태어났어. {partner}의 아이일 가능성이 높다고 생각해. 그래도 원하지 않았던 임신이라는 마음은 남아 있어.','출산을 마쳤다는 사실과 내 의향은 다른 문제다. 아이를 어떻게 대할지와 내 감정을 어떻게 돌볼지 둘 다 생각해야 한다.'],
        ['출산은 끝났어. 내가 추정하는 친부는 {partner}야. 지금은 기뻐하라는 말보다 쉬게 해 줬으면 해.','일단 몸을 회복하고 싶다. 마음이 달라졌다고 서둘러 말하거나 남의 기대에 맞추고 싶지는 않다.'],
        ['{partner}의 아이일 것 같아. 출산을 마쳤어. 내게 필요한 도움도 같이 이야기하자.','아이의 돌봄과 별개로 나에게도 돌봄이 필요하다. 원하지 않았던 일을 혼자 감당하는 것처럼 지내고 싶지는 않다.']
      ],
      uncertain_welcomed:[
        ['아이가 태어났어. 만나서 기쁘지만, 출산했다고 친부를 확실히 알게 된 것은 아니야.','기다리던 아이를 만났다. 기쁨 때문에 내가 모르는 사실까지 알게 된 것처럼 여기지는 말자.'],
        ['출산했어. 친부에 대한 추정은 아직 불확실해. 그래도 이 아이를 기다린 마음은 그대로야.','아이를 반기는 마음과 친부에 대한 의문은 함께 남아 있을 수 있다. 하나의 답으로 모두 설명할 필요는 없다.'],
        ['아이가 태어났어. 누구의 아이인지는 단정할 수 없지만, 나는 아이를 만나서 기뻐.','지금은 무사히 출산했다는 안도감이 크다. 불확실한 문제는 불확실한 채로 두고 몸부터 회복하자.']
      ],
      uncertain_hesitant:[
        ['아이가 태어났어. 친부도 아직 불명확하고, 내 마음도 쉽게 정리되지 않아.','출산이 모든 질문의 답은 아니었다. 지친 상태에서 서둘러 결론 내리지 않고 시간을 갖고 싶다.'],
        ['출산은 끝났어. 누구의 아이인지 단정할 수 없다는 점은 같아. 앞으로의 일은 천천히 생각하자.','안도감은 있지만 망설임도 남아 있다. 아는 사실과 걱정하는 일을 구분해서 이야기해야겠다.'],
        ['아이가 태어났어. 친부를 추정하는 일과 내가 앞으로 원하는 일을 따로 이야기하고 싶어.','추정이 불확실하다고 내 생활까지 남에게 맡길 수는 없다. 회복한 뒤 내가 선택할 수 있는 일부터 정리하자.']
      ],
      uncertain_unwanted:[
        ['아이가 태어났어. 친부는 아직 단정할 수 없어. 원하지 않았던 임신에 대한 내 마음도 남아 있어.','출산이 끝나도 부담이 저절로 사라지지는 않는다. 모르는 사실은 모른다고 말하면서 내 상태도 설명하고 싶다.'],
        ['출산은 끝났어. 누구의 아이인지 확신할 수 없으니, 추측으로 나를 몰아붙이지 않았으면 해.','지금은 몸이 지쳤다. 확실하지 않은 답을 요구받기보다 회복에 필요한 도움을 먼저 받고 싶다.'],
        ['출산은 끝났어. 친부는 불명확하고, 나는 지금 마음을 추스를 시간이 필요해.','출산을 무사히 마친 것은 다행이다. 이제 내 의향과 앞으로의 생활을 차분히 생각하고 싶다.']
      ]
    }
  };
  let api=null;
  let unsubscribe=null;
  let internalWrite=false;
  let previousState=null;
  let uiFrame=0;
  let originalDispatch=null;
  let guardedWaitDispatch=null;
  let steppingWait=false;
  let options=loadOptions();
  let ruleProvider=null;
  const statusFilters=new Map();

  function loadOptions(){
    try{
      const raw=JSON.parse(localStorage.getItem(OPTIONS_KEY)||'{}');
      return{
        enabled:raw.enabled!==false,
        cycleLength:Pregnancy_주기길이정규화하기(raw.cycleLength),
        earlyDays:Pregnancy_임신기간정규화하기(raw.earlyDays,90),
        middleDays:Pregnancy_임신기간정규화하기(raw.middleDays,100),
        lateDays:Pregnancy_임신기간정규화하기(raw.lateDays,90),
        showActualFather:raw.showActualFather===true,
        childDispositionConsultation:raw.childDispositionConsultation!==false,
        adoptionFeeMode:raw.adoptionFeeMode==='fixed'?'fixed':'random',
        adoptionFeeFixed:Math.round(clampNumber(raw.adoptionFeeFixed,0,9999,DEFAULT_OPTIONS.adoptionFeeFixed)),
        adoptionFeeMin:Math.round(clampNumber(raw.adoptionFeeMin,0,9999,DEFAULT_OPTIONS.adoptionFeeMin)),
        adoptionFeeMax:Math.round(clampNumber(raw.adoptionFeeMax,0,9999,DEFAULT_OPTIONS.adoptionFeeMax)),
        conceptionChance:clampNumber(raw.conceptionChance,0,100,DEFAULT_OPTIONS.conceptionChance),
        pauseOnPatronClimax:raw.pauseOnPatronClimax!==false,
        pauseOnPatronActStart:raw.pauseOnPatronActStart!==false,
        showPatronEventAlerts:raw.showPatronEventAlerts!==false
      };
    }catch(_){return{...DEFAULT_OPTIONS}}
  }

  function saveOptions(){
    try{localStorage.setItem(OPTIONS_KEY,JSON.stringify(options))}catch(_){}
    for(const handler of actorOptionListeners)handler();
  }

  function clampNumber(value,min,max,fallback){
    const number=Number(value);
    return Number.isFinite(number)?Math.max(min,Math.min(max,number)):fallback;
  }

  function clone(value){
    try{return structuredClone(value)}catch(_){return JSON.parse(JSON.stringify(value))}
  }

  // Replace the pregnancy slot without even reading a projected state's main-record getter.
  function Pregnancy_인물상태만들기(state,data){
    const view={};
    for(const key of Object.keys(state))if(key!==STATE_KEY)view[key]=state[key];
    view[STATE_KEY]=data;
    return view;
  }

  function makeId(prefix){
    try{return `${prefix}:${crypto.randomUUID()}`}catch(_){return `${prefix}:${Date.now()}:${Math.random().toString(36).slice(2)}`}
  }

  function newData(day){
    return{
      version:8,
      cycleAnchor:null,
      pendingCycleMedicine:null,
      lastMorningDay:Math.max(0,(Number(day)||1)-1),
      pausedAtDay:null,
      spermDeposits:[],
      ejaculationCounts:{vaginal:0,anal:0},
      pregnancy:null,
      birthLog:[],
      seenFinishes:[]
    };
  }

  function normalizeData(raw,day,state=null){
    const source=raw&&typeof raw==='object'?raw:{};
    const data={...clone(source),...newData(day)};
    data.lastMorningDay=Number.isFinite(source.lastMorningDay)?source.lastMorningDay:data.lastMorningDay;
    data.pausedAtDay=Number.isFinite(source.pausedAtDay)?source.pausedAtDay:null;
    if(Number.isInteger(source.cycleAnchor?.day)&&Number.isInteger(source.cycleAnchor?.cycleDay)){
      data.cycleAnchor={day:source.cycleAnchor.day,cycleDay:Math.max(1,Math.min(options.cycleLength,source.cycleAnchor.cycleDay))};
    }
    if(Pregnancy_약단계목록().includes(source.pendingCycleMedicine?.phase)&&Number.isInteger(source.pendingCycleMedicine?.startDay)){
      data.pendingCycleMedicine={phase:source.pendingCycleMedicine.phase,startDay:source.pendingCycleMedicine.startDay};
    }
    data.spermDeposits=Array.isArray(source.spermDeposits)?source.spermDeposits.filter(item=>item&&Number.isFinite(item.day)&&Number.isFinite(item.amount)).map(item=>({
      id:String(item.id||makeId('sperm')),
      day:Number(item.day),
      slot:Number.isFinite(item.slot)?Number(item.slot):0,
      amount:Math.max(0,Math.round(Number(item.amount))),
      sourceId:item.sourceId==null?null:String(item.sourceId),
      sourceName:String(item.sourceName||'알 수 없음'),
      ...Pregnancy_관계인지정규화하기(item,state)
    })).filter(item=>item.amount>0):[];
    data.ejaculationCounts={
      vaginal:Math.max(0,Math.floor(Number(source.ejaculationCounts?.vaginal)||0)),
      anal:Math.max(0,Math.floor(Number(source.ejaculationCounts?.anal)||0))
    };
    if(source.pregnancy&&Number.isFinite(source.pregnancy.conceptionDay)){
      data.pregnancy={
        ...clone(source.pregnancy),
        conceptionDay:Number(source.pregnancy.conceptionDay),
        childCount:normalizeChildCount(source.pregnancy.childCount),
        fatherId:source.pregnancy.fatherId==null?null:String(source.pregnancy.fatherId),
        fatherName:String(source.pregnancy.fatherName||'알 수 없음'),
        sourceDepositId:source.pregnancy.sourceDepositId==null?null:String(source.pregnancy.sourceDepositId),
        fatherEstimates:Pregnancy_친부추정정규화하기(source.pregnancy.fatherEstimates),
        reaction:Pregnancy_반응정규화하기(source.pregnancy.reaction)
      };
    }
    data.birthLog=Array.isArray(source.birthLog)?source.birthLog.filter(entry=>entry?.type==='birth').slice(-MAX_BIRTH_LOG).map(entry=>{
      const id=String(entry.id||makeId('birth-log'));
      return {
      id,
      type:'birth',
      day:Number.isFinite(entry.day)?Number(entry.day):Number(day)||1,
      conceptionDay:Number.isFinite(entry.conceptionDay)?entry.conceptionDay:null,
      fatherId:entry.fatherId==null?null:String(entry.fatherId),
      fatherName:String(entry.fatherName||'알 수 없음'),
      fatherEstimates:Pregnancy_친부추정정규화하기(entry.fatherEstimates),
      pregnancyReaction:Pregnancy_반응정규화하기(entry.pregnancyReaction),
      reaction:Pregnancy_반응정규화하기(entry.reaction),
      motherName:String(entry.motherName||"그녀"),
      childDisposition:Pregnancy_아이처치정규화하기(entry.childDisposition),
      children:birthChildren(id,entry.childCount??entry.children?.length)
    };}):[];
    data.seenFinishes=Array.isArray(source.seenFinishes)?source.seenFinishes.map(String).slice(-MAX_SEEN_FINISHES):[];
    return data;
  }

  function Pregnancy_관계인지정규화하기(item,state){
    const event=(state?.awayEvents??[]).find(entry=>item.id===`sperm:situation:${entry.completionId}`&&entry.completionId);
    return {
      wifeKnows:typeof item.wifeKnows==='boolean'?item.wifeKnows:!!event,
      husbandKnows:typeof item.husbandKnows==='boolean'?item.husbandKnows:item.sourceId==='player'
    };
  }

  function Pregnancy_친부추정정규화하기(raw){
    const result={};
    for(const role of ['wife','husband']){
      const candidates=Array.isArray(raw?.[role]?.candidates)?raw[role].candidates.filter(item=>item&&item.name).map(item=>({
        id:item.id==null?null:String(item.id),name:String(item.name)
      })).slice(0,120):[];
      result[role]={certainty:candidates.length===1?'likely':candidates.length?'suspected':'unknown',candidates};
    }
    return result;
  }

  function Pregnancy_친부추정만들기(deposits){
    const estimates={};
    for(const role of ['wife','husband']){
      const known=deposits.filter(item=>item[`${role}Knows`]===true);
      estimates[role]={candidates:[...new Map(known.map(item=>[item.sourceId??item.sourceName,{id:item.sourceId,name:item.sourceName}])).values()]};
    }
    return Pregnancy_친부추정정규화하기(estimates);
  }

  function Pregnancy_친부추정표현하기(estimate){
    const names=estimate.candidates.map(item=>item.name);
    if(!names.length)return '불명';
    return `${names.join(' 또는 ')} (${names.length===1?'유력':'의심'})`;
  }

  function Pregnancy_친부표시만들기(record){
    const estimates=Pregnancy_친부추정정규화하기(record?.fatherEstimates);
    const display={wife:Pregnancy_친부추정표현하기(estimates.wife),husband:Pregnancy_친부추정표현하기(estimates.husband)};
    if(options.showActualFather)display.actual=String(record?.fatherName||'알 수 없음');
    return display;
  }

  function Pregnancy_친부알림문장만들기(notice){
    const display=Pregnancy_친부표시만들기(notice);
    const status=notice.type==='birth'?'출산':'임신';
    const disposition=Pregnancy_아이처치정규화하기(notice.childDisposition);
    const suffix=notice.type!=='birth'?'':disposition?.status==='adopted'
      ?' 아이는 출산 후 입양 보냈습니다.'
      :disposition?.status==='pending'?' 출산 후 아이를 어떻게 할지 상의해야 합니다.':' 아이는 부모님이 맡아 키웁니다.';
    const count=normalizeChildCount(notice.childCount);
    return `${notice.motherName}이(가) ${status}했습니다.${count>1?` 아이 ${count}명.`:''} 추정 — 그녀: ${display.wife} / 당신: ${display.husband}.${display.actual?` 실제 친부: ${display.actual}.`:''}${suffix}`;
  }

  function Pregnancy_반응문장만들기(reaction){
    return reaction?`\n대사: “${reaction.dialogue}”\n속마음: ${reaction.innerThought}`:'';
  }

  function Pregnancy_사건문장만들기(notice){
    return Pregnancy_친부알림문장만들기(notice)+Pregnancy_반응문장만들기(notice.reaction);
  }

  function Pregnancy_친부로그갱신하기(state,data){
    let changed=false;
    const records=[...(data.birthLog??[]),...(data.pregnancy?[data.pregnancy]:[])];
    const log=(state.log??[]).map(entry=>{
      let notice=entry.pregnancyPaternityNotice;
      if(!notice&&entry.eventCategory==='wc2_pregnancy_birth'){
        const match=String(entry.text??'').match(/^\[임신 \/ 출산모드\] (.+?)이\(가\) (.+?)의 아이를 (임신|출산)했습니다\./);
        if(match){
          const record=records.find(item=>item.fatherName===match[2]&&(!item.motherName||item.motherName===match[1]));
          notice={type:match[3]==='출산'?'birth':'pregnancy',motherName:match[1],fatherName:match[2],
            fatherEstimates:Pregnancy_친부추정정규화하기(record?.fatherEstimates)};
        }
      }
      if(!notice)return entry;
      const birth=notice.type==='birth'&&records.find(item=>item.reaction?.id&&item.reaction.id===notice.reaction?.id);
      if(birth?.childDisposition)notice={...notice,childDisposition:birth.childDisposition};
      const text=`[임신 / 출산모드] ${Pregnancy_사건문장만들기(notice)}`;
      if(text===entry.text&&entry.pregnancyPaternityNotice)return entry;
      changed=true;return {...entry,text,pregnancyPaternityNotice:notice};
    });
    // Native recentAlerts drops custom metadata. Recover the notice by its
    // saved reaction id so reveal/hide also updates dismissed event history.
    const notices=new Map(log.filter(entry=>entry.pregnancyPaternityNotice?.reaction).map(entry=>[
      entry.pregnancyPaternityNotice.reaction.id,entry.pregnancyPaternityNotice
    ]));
    function Pregnancy_알림표시갱신하기(alert){
      const notice=notices.get(alert?.id)??alert?.pregnancyPaternityNotice;
      if(!notice)return alert;
      const body=Pregnancy_사건문장만들기(notice);
      if(body===alert.body)return alert;
      changed=true;return {...alert,body};
    }
    const alertQueue=(state.alertQueue??[]).map(Pregnancy_알림표시갱신하기);
    const recentAlerts=(state.recentAlerts??[]).map(Pregnancy_알림표시갱신하기);
    let pendingEvent=state.pendingEvent;
    if(pendingEvent?.type==='alert'){
      const alert=Pregnancy_알림표시갱신하기(pendingEvent.alert);
      if(alert!==pendingEvent.alert)pendingEvent={...pendingEvent,alert,text:alert.body};
    }
    return changed?{...state,log,alertQueue,recentAlerts,pendingEvent}:state;
  }

  function Pregnancy_임신의향계산하기(state,partnerId='player',partnerName=''){
    const wife=getWife(state);
    if(!wife)return null;
    const record=(state.patronRecords??[]).find(item=>item.id===partnerId||item.name===partnerName);
    const affection=partnerId==='player'
      ?clampNumber(Pregnancy_Wml.fn('PregnancyHusbandAffection')(wife),0,100,0)
      :clampNumber(record?.romantic,0,100,0);
    const sexualPreference=clampNumber(wife.affinities?.vaginal,-2,2,0);
    const sexualScore=(sexualPreference+2)*25;
    const score=Math.round(affection*.6+sexualScore*.4);
    return {score,label:score>=70?'강하게 원함':score>=50?'긍정적':score>=30?'망설임':'원하지 않음',affection,sexualPreference};
  }

  function Pregnancy_반응정규화하기(raw){
    if(!raw||!Pregnancy_반응문구목록[raw.type]?.[raw.condition]||
      typeof raw.dialogue!=='string'||typeof raw.innerThought!=='string')return null;
    return {id:String(raw.id),type:raw.type,day:Number(raw.day)||1,condition:raw.condition,
      variant:Math.round(clampNumber(raw.variant,0,2,0)),
      desireScore:clampNumber(raw.desireScore,0,100,0),
      dialogue:raw.dialogue,innerThought:raw.innerThought};
  }

  function Pregnancy_반응만들기(state,type,record){
    const candidates=Pregnancy_친부추정정규화하기(record.fatherEstimates).wife.candidates;
    const fatherBelief=candidates.length===1?(candidates[0].id==='player'?'husband':'other'):'uncertain';
    const desires=candidates.length?candidates.map(candidate=>
      Pregnancy_임신의향계산하기(state,candidate.id,candidate.name)?.score??0
    ):[Pregnancy_임신의향계산하기(state)?.score??0];
    const desireScore=Math.round(desires.reduce((sum,score)=>sum+score,0)/desires.length);
    const attitude=desireScore>=50?'welcomed':desireScore>=30?'hesitant':'unwanted';
    const condition=`${fatherBelief}_${attitude}`;
    const variants=Pregnancy_반응문구목록[type][condition];
    const variant=Math.floor(Math.random()*variants.length);
    const [dialogue,innerThought]=variants[variant].map(text=>text.replaceAll('{partner}',candidates[0]?.name??'그 사람'));
    return {id:makeId(`wc2_pregnancy_reaction_${type}`),type,day:Number(state.day)||1,
      condition,variant,desireScore,dialogue,innerThought};
  }

  function Pregnancy_아이처치문구정규화하기(raw){
    if(!raw||typeof raw.dialogue!=='string'||typeof raw.innerThought!=='string')return null;
    return {dialogue:raw.dialogue,innerThought:raw.innerThought,
      ...(typeof raw.husbandDialogue==='string'?{husbandDialogue:raw.husbandDialogue}:{}),
      ...(['positive','negative','neutral'].includes(raw.effect)?{effect:raw.effect}:{}),
      ...(typeof raw.responseKind==='string'?{responseKind:raw.responseKind}:{}),
      ...(raw.refused===true?{refused:true}:{}),
      ...(raw.parameterChanges?{parameterChanges:Pregnancy_아이처치영향정규화하기(raw.parameterChanges)}:{})};
  }

  function Pregnancy_아이처치영향정규화하기(raw={}){
    const result={};
    for(const key of ['trust','resentment','mood','affection'])result[key]=clampNumber(raw[key],-100,100,0);
    result.emotion=['tenderness','anger','sadness','relief'].includes(raw.emotion)?raw.emotion:'sadness';
    result.intensity=clampNumber(raw.intensity,0,100,40);
    return result;
  }

  function Pregnancy_아이처치가치관만들기(profile={},desireScore=0,wifeBelief='unknown'){
    const pragmatic=Pregnancy_성향있는지(profile,'pragmatic'),cold=Pregnancy_성향있는지(profile,'cold_pragmatist');
    const romantic=clampNumber(profile.affinities?.romantic,-2,2,0),starved=Pregnancy_성향있는지(profile,'romance_starved');
    return{pragmatism:Math.min(100,(pragmatic?35:0)+(cold?70:0)),romantic,romanceStarved:starved,
      attachment:Math.round(clampNumber(desireScore*.6+Math.max(0,romantic)*15+(starved?15:0)+(wifeBelief==='husband'?10:0),0,100,0))};
  }

  function Pregnancy_아이처치정규화하기(raw){
    if(!raw||!['pending','parents','adopted'].includes(raw.status))return null;
    return {id:String(raw.id||makeId('child-disposition')),status:raw.status,
      decisionMode:raw.decisionMode==='husband_choice'?'husband_choice':'automatic',
      reason:String(raw.reason||'legacy'),preference:raw.preference==='adoption'?'adoption':'parents',
      honesty:raw.honesty==='concealed'?'concealed':'honest',
      husbandBelief:['husband','other','unknown'].includes(raw.husbandBelief)?raw.husbandBelief:'unknown',
      wifeBelief:['husband','other','unknown'].includes(raw.wifeBelief)?raw.wifeBelief:'unknown',
      desireScore:Math.round(clampNumber(raw.desireScore,0,100,0)),partnerName:String(raw.partnerName||'다른 사람'),
      tormenting:raw.tormenting===true,address:String(raw.address||'당신'),showEvent:raw.showEvent===true,
      values:raw.values?{pragmatism:clampNumber(raw.values.pragmatism,0,100,0),romantic:clampNumber(raw.values.romantic,-2,2,0),
        romanceStarved:raw.values.romanceStarved===true,attachment:clampNumber(raw.values.attachment,0,100,0)}
        :Pregnancy_아이처치가치관만들기({},Number(raw.desireScore)||0,raw.wifeBelief),
      husbandChoice:['parents','adoption','adoption_profit'].includes(raw.husbandChoice)?raw.husbandChoice:null,
      consultation:Pregnancy_아이처치문구정규화하기(raw.consultation),
      outcome:Pregnancy_아이처치문구정규화하기(raw.outcome),
      adoptionFee:Math.round(clampNumber(raw.adoptionFee,0,9999,0)),
      decidedDay:Number.isFinite(raw.decidedDay)?Number(raw.decidedDay):null};
  }

  function Pregnancy_친부믿음분류하기(estimate){
    const candidates=Pregnancy_친부추정정규화하기({wife:estimate}).wife.candidates;
    if(candidates.some(item=>item.id!=='player'))return'other';
    if(candidates.some(item=>item.id==='player'))return'husband';
    return'unknown';
  }

  function Pregnancy_성향있는지(profile,key){
    for(const group of [profile?.latentTraits,profile?.traits]){
      if(Array.isArray(group)&&group.includes(key))return true;
      if(group instanceof Set&&group.has(key))return true;
      if(group&&typeof group==='object'&&group[key]===true)return true;
    }
    return false;
  }

  function Pregnancy_괴롭힘성향인지(profile){
    if(['enjoys_making_him_jealous','sadistic','latent_sadist','sadist'].some(key=>Pregnancy_성향있는지(profile,key)))return true;
    return Pregnancy_성향있는지(profile,'latent_dominant')&&Number(profile?.affinities?.domination)>=1;
  }

  function Pregnancy_정직하게말하는지(profile,relationshipTrust){
    const trust=Number.isFinite(Number(relationshipTrust))?Number(relationshipTrust):Number(profile?.relationship?.trust);
    return !Pregnancy_성향있는지(profile,'self_protective')&&!Pregnancy_성향있는지(profile,'likes_cheating')&&
      (!Number.isFinite(trust)||trust>=50);
  }

  function Pregnancy_입양비뽑기(){
    if(options.adoptionFeeMode==='fixed')return Math.round(clampNumber(options.adoptionFeeFixed,0,9999,DEFAULT_OPTIONS.adoptionFeeFixed));
    const first=Math.round(clampNumber(options.adoptionFeeMin,0,9999,DEFAULT_OPTIONS.adoptionFeeMin));
    const second=Math.round(clampNumber(options.adoptionFeeMax,0,9999,DEFAULT_OPTIONS.adoptionFeeMax));
    const min=Math.min(first,second),max=Math.max(first,second);
    return min+Math.floor(Math.random()*(max-min+1));
  }

  function Pregnancy_아이처치질문만들기(plan){
    const partner=plan.partnerName,address=plan.address;
    if(plan.tormenting)return{
      dialogue:plan.wifeBelief==='husband'
        ?`${address}은 다른 사람의 아이라고 보고 있잖아. 그래도 부모님께 맡겨 키우자. 그 의심을 안고도 아이를 받아들이는 모습을 보고 싶어.`
        :`${address}의 아이는 아니라고 생각해. 그래도 부모님께 맡겨서 우리 아이처럼 키우자. 다른 남자의 아이를 볼 때마다 어떤 기분일지 궁금하거든.`,
      innerThought:'그가 이 아이를 볼 때마다 흔들리는 모습을 오래 지켜보고 싶어.'};
    if(plan.reason==='both_husband'){
      if(plan.preference==='adoption')return{dialogue:`${address}의 아이라고 생각해. 그래도 지금 우리 형편에는 양육보다 입양을 택하는 편이 나을 것 같아. 사례금도 생활에 보탤 수 있고. 어떻게 생각해?`,
        innerThought:plan.values.pragmatism>=35?'아이를 맡길 곳과 우리 살림을 함께 계산해야 해. 피가 이어졌다는 이유만으로 생활이 나아지는 건 아니잖아.'
          :'그의 아이여도 내가 양육을 원하는 것은 아니야. 그래도 떠나보내자는 말을 꺼내는 건 쉽지 않다.'};
      if(plan.values.romantic>=1||plan.values.romanceStarved)return{dialogue:`우리 둘 다 ${address}의 아이라고 생각하고 있잖아. 부모님께 맡겨서 우리 아이로 키우고 싶어. 내 마음과 같은지 말해 줘.`,
        innerThought:'우리 사이에서 태어난 아이를 가족으로 남기고 싶어. 이 아이까지 돈으로 계산하는 말은 듣고 싶지 않아.'};
      return{dialogue:`${address}의 아이라고 생각해. 부모님께 맡겨 키우면 어떨까? 앞으로의 생활까지 생각해서 같이 정하자.`,
        innerThought:'아이를 가족으로 남기는 쪽이 먼저 떠오른다. 하지만 그도 앞으로를 어떻게 생각하는지 듣고 싶어.'};
    }
    if(plan.reason==='both_other')return{dialogue:`우리 둘 다 ${address}의 아이는 아니라고 보고 있네. 나는 입양 보내는 편이 낫겠어. ${address} 생각도 듣고 싶어.`,
      innerThought:'서로 비슷하게 생각하는 것 같지만, 아이를 떠나보내기 전에 그의 답을 듣고 정하고 싶어.'};
    if(plan.husbandBelief==='husband'&&plan.wifeBelief==='other'){
      if(plan.desireScore>=50)return{dialogue:plan.honesty==='honest'
        ?`나는 ${partner}의 아이일 가능성이 높다고 생각해. 그래도 이 아이를 남기고 싶어. 부모님께 맡겨 키우면 어떨까?`
        :'나는 이 아이를 가족으로 남기고 싶어. 부모님께 맡겨 키우면 어떨까?',
        innerThought:`${partner}의 아이일 가능성이 있어도, 기다리던 아이를 떠나보내고 싶지는 않아.`};
      if(plan.desireScore<30&&plan.honesty==='honest')return{
        dialogue:`미안한데, ${partner}의 아이인 것 같아. 나는 이 아이를 입양 보내고 싶어. ${address} 생각은 어때?`,
        innerThought:`${partner}의 아이를 키우고 싶지 않아.`};
      if(plan.desireScore<30)return{
        dialogue:`미안한데, 우리가 아이를 키울 여건이 안 되는 것 같아. 입양 보내자. ${address} 생각은 어때?`,
        innerThought:`${partner}의 아이를 키우고 싶지 않아.`};
      if(plan.honesty==='honest')return{
        dialogue:`내 생각에는 ${partner}의 아이일 가능성이 높아. 아직 이 아이를 키울 마음이 확실하지 않아. 부모님께 맡길지 입양 보낼지 같이 정해 줘.`,
        innerThought:'아이를 원하지 않는다고 단정할 정도는 아니지만, 다른 사람의 아이를 가족으로 받아들일 자신도 아직 없다.'};
      return{dialogue:'앞으로의 형편을 생각하면 아이를 입양 보내는 편이 나을지도 몰라. 당신은 어떻게 하고 싶어?',
        innerThought:`${partner}의 아이일 가능성을 말하지 않고도 내 망설임을 받아들여 줬으면 좋겠어.`};
    }
    if(plan.husbandBelief==='other'&&plan.wifeBelief==='husband'){
      if(plan.desireScore>=50)return{dialogue:`나는 ${address}의 아이라고 생각해. 하지만 ${address}은(는) 다르게 보고 있는 거지? 그래도 부모님께 맡겨 키우고 싶은데, 당신 생각을 말해 줘.`,
        innerThought:'그의 의심이 두렵지만, 나는 이 아이를 가족으로 남기고 싶어.'};
      if(plan.desireScore>=30)return{dialogue:`나는 ${address}의 아이라고 생각하지만, ${address}은(는) 다른 사람의 아이라고 보는 거지? 부모님께 맡길지 입양 보낼지 함께 결정하자.`,
        innerThought:'내 추정과 그의 추정이 다르다. 어느 쪽도 사실로 단정하지 말고 지금 감당할 수 있는 선택을 해야 한다.'};
      return{dialogue:`나는 ${address}의 아이라고 생각해. 그래도 지금 아이를 키울 마음은 없어. 입양 보내는 쪽을 생각해 줬으면 해.`,
        innerThought:'그의 아이라고 믿는 것과 내가 이 아이를 키우고 싶다는 것은 같은 말이 아니다.'};
    }
    if(plan.reason==='no_other_belief')return{dialogue:plan.preference==='parents'
      ?'친부는 확실히 말할 수 없지만, 나는 이 아이를 부모님께 맡겨 키우고 싶어. 당신은 어떻게 생각해?'
      :'친부에 대한 확신도 없고 지금 양육할 마음도 준비되지 않았어. 입양 보내는 쪽을 생각해 줬으면 해.',
      innerThought:'아는 정보 이상으로 친부를 단정하지 말자. 지금 내가 원하는 일부터 솔직히 이야기해야겠다.'};
    if(plan.preference==='parents')return{dialogue:`친부에 대한 우리 생각이 다르지만, 나는 이 아이를 가족으로 남기고 싶어. 부모님께 맡길지 ${address}이(가) 정해 줘.`,
      innerThought:'불확실한 점은 남아 있어도 아이를 보내고 싶지는 않다.'};
    return{dialogue:`친부에 대한 생각이 서로 다르니 이 아이를 어떻게 할지 정해야 해. 나는 입양 보내는 쪽이 낫다고 생각해.`,
      innerThought:'확신도 준비도 부족한 상태로 아이를 가족에게 맡기는 것은 원하지 않는다.'};
  }

  function Pregnancy_아이처치자동결과만들기(plan,status){
    if(status==='parents')return{dialogue:`나는 ${plan.partnerName}의 아이일 가능성이 높다고 생각하지만, 그래도 이 아이를 가족으로 받아들이고 싶어. 부모님께 맡기자.`,
      innerThought:'친부에 대한 내 추정과 아이를 키우고 싶은 마음은 별개다. 이 선택의 책임도 피하지 않겠다.'};
    if(plan.husbandBelief==='other'&&plan.wifeBelief==='other')return{dialogue:'우리 둘 다 당신의 아이는 아니라고 생각하고 있어. 이 아이는 입양 보내는 게 맞겠어.',
      innerThought:'아이에게 미안하지만, 서로 다른 기대 속에 남겨 두는 것보다 새 가족을 찾는 편이 낫다고 생각한다.'};
    return{dialogue:'우리가 알고 있는 관계와 지금의 마음을 생각하면, 이 아이는 입양 보내는 편이 낫겠어.',
      innerThought:'쉬운 결정은 아니지만 원하지 않는 책임을 억지로 떠안는 것이 아이를 위한 일이라고 생각하지 않는다.'};
  }

  function Pregnancy_아이처치답변결과만들기(plan,status){
    const choseParents=status==='parents',preferredParents=plan.preference==='parents';
    if(choseParents&&preferredParents){
      if(plan.tormenting)return{husbandDialogue:'부모님께 맡기자.',dialogue:'그래, 그렇게 말할 줄 알았어. 부모님께 맡겨서 잘 키워 달라고 하자.',
        innerThought:'다른 남자의 아이를 받아들인 그의 표정을 앞으로도 지켜볼 수 있겠네.',effect:'positive'};
      return{husbandDialogue:'부모님께 맡기자.',dialogue:'내 뜻을 받아줘서 고마워. 부모님께 잘 부탁드리자.',
        innerThought:'그가 내 말을 듣고 아이를 가족으로 남겨 줬다. 이제 이 선택을 함께 책임지고 싶다.',effect:'positive'};
    }
    if(choseParents)return{husbandDialogue:'부모님께 맡기자.',dialogue:'알겠어. 부모님께 맡기자. 하지만 내가 왜 입양을 말했는지는 잊지 말아 줘.',
      innerThought:'왜 내 말을 안 들어주는 거야?',effect:'negative'};
    if(!preferredParents)return{husbandDialogue:'입양시키자.',dialogue:'내 말을 들어줘서 고마워. 좋은 가족을 만날 수 있게 끝까지 확인하자.',
      innerThought:'다행이야. 그렇지만 아이야 미안해.',effect:'positive'};
    if(plan.tormenting)return{husbandDialogue:'입양시키자.',dialogue:'결국 보내 버리겠다는 거네. 당신 뜻이 그렇다면 그렇게 해.',
      innerThought:'내가 원한 모습을 보여 주지 않다니, 순순히 넘어가 주고 싶지 않아.',effect:'negative'};
    return{husbandDialogue:'입양시키자.',dialogue:'알겠어. 입양 절차를 밟을게. 하지만 나는 이 아이를 남기고 싶었다는 걸 기억해 줘.',
      innerThought:'내가 키우고 싶다고 말했는데도 그는 다른 선택을 했다.',effect:'negative'};
  }

  function Pregnancy_입양제안반응만들기(plan,forProfit){
    const values=plan.values,preferredAdoption=plan.preference==='adoption';
    const advantage=values.pragmatism-values.attachment;
    const husbandDialogue=forProfit
      ?plan.husbandBelief==='husband'?'내 아이라고 생각해도 사례금을 받는 편이 우리 살림에는 낫겠어. 입양 보내자.'
        :'사례금을 받아서 살림에 보태자. 입양 보내는 게 좋겠어.'
      :'아이를 입양 보내자.';
    if(!preferredAdoption&&values.attachment>=70&&advantage<=-35)return{
      husbandDialogue,dialogue:forProfit
        ?plan.wifeBelief==='husband'?'싫어. 당신의 아이라고 생각하면서도 돈 때문에 보내자는 거야? 나는 동의 못 해. 부모님께 맡겨 키울 거야.'
          :'돈 때문에 이 아이를 보내고 싶지는 않아. 나는 동의 못 해. 부모님께 맡겨 키우자.'
        :'나는 이 아이를 남기고 싶다고 말했잖아. 입양에는 동의 못 해. 부모님께 맡겨 키우자.',
      innerThought:forProfit?'아이를 보내고 받는 돈으로 우리 사이의 믿음까지 되살릴 수는 없어. 내 뜻까지 돈으로 바꾸게 두지는 않겠어.'
        :'내가 얼마나 이 아이를 기다렸는지 그는 듣고 있기는 한 걸까. 이번에는 내 마음을 지키고 싶어.',
      effect:'negative',responseKind:'refused',refused:true,
      parameterChanges:{trust:forProfit?-7:-5,resentment:forProfit?10:7,mood:-12,affection:-4,emotion:'anger',intensity:70}};
    if((preferredAdoption&&values.pragmatism>=35)||(!preferredAdoption&&advantage>=10))return{
      husbandDialogue,dialogue:forProfit
        ?'마음만으로 살림이 나아지지는 않으니까. 입양 보내고 사례금은 생활에 보태자. 나도 그 편이 낫겠어.'
        :'앞으로의 살림을 생각하면 입양이 현실적인 선택이겠어. 나도 동의해.',
      innerThought:plan.wifeBelief==='husband'?'그의 아이여도 양육에 드는 비용은 사라지지 않는다. 아이를 맡기고 받는 돈이 지금 우리에게는 더 필요해.'
        :'내가 원하는 생활과 당장의 이익을 함께 챙길 수 있다. 그도 같은 계산을 해 줘서 다행이다.',
      effect:'positive',responseKind:'practical_acceptance',
      parameterChanges:{trust:2,resentment:-2,mood:4,affection:2,emotion:'tenderness',intensity:35}};
    if(preferredAdoption){
      const result=Pregnancy_아이처치답변결과만들기(plan,'adopted');
      if(forProfit&&(values.romantic>=1||values.romanceStarved))return{
        ...result,husbandDialogue,dialogue:'입양을 보내는 건 나도 원해. 하지만 아이를 돈으로 바꾼다는 식으로 말하지는 말아 줘.',
        innerThought:'보내기로 마음먹었어도 그가 돈부터 말하니 서운하다. 함께 고민해 줬으면 했는데.',
        effect:'negative',responseKind:'hurt_agreement',
        parameterChanges:{trust:-1,resentment:2,mood:-3,affection:-1,emotion:'sadness',intensity:35}};
      return{...result,husbandDialogue,responseKind:'agreed',
        parameterChanges:{trust:3,resentment:-4,mood:6,affection:3,emotion:'tenderness',intensity:45}};
    }
    if(plan.tormenting)return{...Pregnancy_아이처치답변결과만들기(plan,'adopted'),husbandDialogue,responseKind:'disagreed',
      parameterChanges:{trust:-3,resentment:5,mood:-6,affection:-2,emotion:'anger',intensity:45}};
    return{husbandDialogue,dialogue:forProfit?'알겠어. 지금 살림에 돈이 필요하다는 건 나도 알아. 입양에는 동의할게. 하지만 마음까지 편한 건 아니야.'
        :'알겠어. 입양에는 동의할게. 그래도 나는 이 아이를 남기고 싶었다는 걸 기억해 줘.',
      innerThought:forProfit?'돈이 도움이 될 거라는 건 알지만, 아이가 없는 자리가 그 돈으로 채워지지는 않을 것 같아.'
        :'같이 정한 일이니 받아들이겠지만, 아이를 남기고 싶었던 마음까지 사라진 건 아니다.',
      effect:'negative',responseKind:'reluctant_acceptance',
      parameterChanges:{trust:-2,resentment:3,mood:-6,affection:-1,emotion:'sadness',intensity:45}};
  }

  function Pregnancy_아이처치완료하기(raw,choice,day){
    const plan=Pregnancy_아이처치정규화하기(raw);
    if(!plan)return null;
    if(plan.status!=='pending')return plan;
    if(!['parents','adoption','adoption_profit'].includes(choice))return plan;
    let status=choice==='parents'?'parents':'adopted';
    const outcome=plan.decisionMode==='husband_choice'
      ?choice==='parents'?Pregnancy_아이처치답변결과만들기(plan,status):Pregnancy_입양제안반응만들기(plan,choice==='adoption_profit')
      :Pregnancy_아이처치자동결과만들기(plan,status);
    if(outcome.refused)status='parents';
    if(!outcome.parameterChanges){const positive=outcome.effect==='positive';outcome.parameterChanges={trust:positive?3:-3,
      resentment:positive?-4:5,mood:positive?6:-6,affection:positive?3:-2,emotion:positive?'tenderness':'anger',intensity:45};}
    return Pregnancy_아이처치정규화하기({...plan,status,outcome,husbandChoice:choice,
      adoptionFee:status==='adopted'?Pregnancy_입양비뽑기():0,decidedDay:Number(day)||1});
  }

  function Pregnancy_아이처치계획만들기(input={}){
    const estimates=Pregnancy_친부추정정규화하기(input.fatherEstimates),profile=input.profile??{};
    const wifeBelief=Pregnancy_친부믿음분류하기(estimates.wife),husbandBelief=Pregnancy_친부믿음분류하기(estimates.husband);
    const wifeOther=estimates.wife.candidates.find(item=>item.id!=='player');
    const husbandOther=estimates.husband.candidates.find(item=>item.id!=='player');
    const desireScore=Math.round(clampNumber(input.desireScore,0,100,0));
    const hasOther=husbandBelief==='other'||wifeBelief==='other';
    const tormenting=hasOther&&Pregnancy_괴롭힘성향인지(profile);
    const values=Pregnancy_아이처치가치관만들기(profile,desireScore,wifeBelief);
    const base={id:makeId('child-disposition'),status:'pending',decisionMode:'husband_choice',reason:'belief_mismatch',
      preference:desireScore>=50?'parents':'adoption',honesty:Pregnancy_정직하게말하는지(profile,input.relationshipTrust)?'honest':'concealed',
      husbandBelief,wifeBelief,desireScore,partnerName:String(wifeOther?.name??husbandOther?.name??'다른 사람'),
      tormenting,values,address:String(input.address||'당신'),showEvent:true,consultation:null,outcome:null,adoptionFee:0,decidedDay:null};
    if(!options.childDispositionConsultation)return Pregnancy_아이처치정규화하기({...base,status:'parents',decisionMode:'automatic',reason:'setting_disabled',showEvent:false,decidedDay:Number(input.day)||1});
    let plan={...base};
    if(husbandBelief==='husband'&&wifeBelief==='husband')plan={...plan,reason:'both_husband',
      preference:desireScore<30&&values.pragmatism>=35&&values.romantic<1?'adoption':'parents'};
    else if(!hasOther)plan={...plan,reason:'no_other_belief'};
    else if(tormenting)plan={...plan,reason:'tormenting_keep',preference:'parents'};
    else if(husbandBelief==='husband'&&wifeBelief==='other'&&desireScore>=50)
      plan={...plan,reason:'wife_other_welcomed',preference:'parents'};
    else if(husbandBelief==='other'&&wifeBelief==='other')
      plan={...plan,reason:'both_other',preference:'adoption'};
    else if(husbandBelief==='unknown'&&wifeBelief==='other'&&desireScore<30)
      plan={...plan,reason:'wife_other_unwanted',preference:'adoption'};
    else if(husbandBelief==='husband'&&wifeBelief==='other')plan={...plan,reason:desireScore<30?'wife_other_unwanted':'wife_other_hesitant',preference:'adoption'};
    else if(husbandBelief==='other'&&wifeBelief==='husband')plan={...plan,reason:'husband_other_wife_husband',preference:desireScore>=50?'parents':'adoption'};
    else plan={...plan,reason:'other_belief_uncertain',preference:desireScore>=50?'parents':'adoption'};
    plan.consultation=Pregnancy_아이처치질문만들기(plan);
    return Pregnancy_아이처치정규화하기(plan);
  }

  function Pregnancy_아이처치알림만들기(disposition,recordId,motherName,source='pregnancy',workerId=null){
    const question=disposition.status==='pending',copy=question?disposition.consultation:disposition.outcome;
    const lines=[];
    if(copy?.husbandDialogue)lines.push(`${disposition.address==='사장님'?'사장님':"당신"}: “${copy.husbandDialogue}”`);
    if(copy?.dialogue)lines.push(`${motherName}: “${copy.dialogue}”`);
    if(copy?.innerThought)lines.push(`속마음: ${copy.innerThought}`);
    if(!question)lines.push(disposition.status==='adopted'
      ?`결과: 아이를 입양 보냈습니다. 입양 사례금 ${disposition.adoptionFee}골드를 받았습니다.`
      :copy?.refused?'결과: 입양 제안을 거절하여 아이는 부모님께 맡겨 키우기로 했습니다. 입양 사례금은 받지 않습니다.'
        :'결과: 아이는 부모님께 맡겨 키우기로 했습니다.');
    if(!question&&copy?.parameterChanges)lines.push(Pregnancy_아이처치변화문장만들기(copy,source));
    return{id:makeId(question?'wc2_child_disposition_question':'wc2_child_disposition_result'),kind:'wc2_child_disposition',
      severity:'critical',pause:true,title:`${motherName} · 출산 후 아이 처치 ${question?'상의':'결과'}`,body:lines.join('\n'),
      choices:question?[{id:'pregnancy_child_parents',label:'부모님께 맡기자',description:'아이를 부모님께 맡겨 키웁니다.'},
        {id:'pregnancy_child_adoption',label:'입양시키자',description:"입양을 제안합니다. 그녀가 동의하면 사례금을 받습니다."},
        {id:'pregnancy_child_adoption_profit',label:'사례금을 받으니 입양시키자',description:"자신의 아이라고 믿어도 금전적 이유로 입양을 제안합니다. 반응과 동의 여부는 그녀의 성향에 따릅니다."}]
        :[{id:'dismiss',label:'계속하기',description:'결정 결과를 확인하고 진행합니다.'}],
      childDisposition:{source,recordId,workerId,phase:question?'question':'result'}};
  }

  function Pregnancy_아이처치변화문장만들기(outcome,source='pregnancy'){
    const delta=outcome?.parameterChanges;
    if(!delta)return'';
    const labels=source==='brothel-pregnancy'?[['affection','애정'],['trust','신뢰'],['mood','기분']]
      :[['trust','신뢰'],['resentment','반감'],['mood','기분']];
    return'기본 변화: '+labels.map(([key,label])=>`${label} ${delta[key]>0?'+':''}${delta[key]}`).join(' · ');
  }

  function Pregnancy_아이처치기록문장만들기(disposition){
    if(!disposition)return'';
    let text='';
    if(disposition.consultation)text+=`\n그녀의 제안: “${disposition.consultation.dialogue}”\n제안 당시 속마음: ${disposition.consultation.innerThought}`;
    if(disposition.outcome){
      const result=disposition.outcome;
      if(result.husbandDialogue)text+=`\n당신의 답변: “${result.husbandDialogue}”`;
      text+=`\n답변 후 대사: “${result.dialogue}”\n답변 후 속마음: ${result.innerThought}`;
      const changes=Pregnancy_아이처치변화문장만들기(result,disposition.address==='사장님'?'brothel-pregnancy':'pregnancy');
      if(changes)text+=`\n${changes}`;
    }
    return text;
  }

  function Pregnancy_아이처치로그추가하기(state,motherName,disposition,phase){
    const copy=phase==='question'?disposition.consultation:disposition.outcome;
    const lines=[`[아이 처치 상의] ${motherName}`];
    if(copy?.husbandDialogue)lines.push(`당신: “${copy.husbandDialogue}”`);
    if(copy?.dialogue)lines.push(`${motherName}: “${copy.dialogue}”`);
    if(copy?.innerThought)lines.push(`속마음: ${copy.innerThought}`);
    if(phase==='result')lines.push(disposition.status==='adopted'
      ?`아이를 입양 보내고 사례금 ${disposition.adoptionFee}골드를 받았습니다.`:'아이를 부모님께 맡겨 키우기로 했습니다.');
    if(phase==='result'&&copy?.parameterChanges)lines.push(Pregnancy_아이처치변화문장만들기(copy));
    state.log=[...(state.log??[]),{slot:Number(state.slot)||0,text:lines.join('\n'),eventCategory:'wc2_child_disposition',important:true,
      childDispositionId:disposition.id}];
  }

  function Pregnancy_아이처치현재반응반영하기(state,data){
    const event=state.pendingEvent,alert=event?.alert,meta=alert?.childDisposition;
    if(alert?.kind!=='wc2_child_disposition'||meta?.source!=='pregnancy'||event.childDispositionPresented===alert.id)return state;
    const plan=data.birthLog.find(item=>item.id===meta.recordId)?.childDisposition;
    const copy=meta.phase==='question'?plan?.consultation:plan?.outcome;
    if(!copy)return state;
    const result=Pregnancy_Wml.fn('updateWife')(state,wife=>({...wife,lastResponse:copy.dialogue,
      lastResponseType:copy.parameterChanges?.emotion==='anger'?'angry':copy.effect==='negative'?'hesitant':'accept',lastResponseSlot:Number(state.slot)||0,
      innerThought:copy.innerThought,innerThoughtType:'conflicted',innerThoughtSlot:Number(state.slot)||0}));
    return{...result,pendingEvent:{...event,childDispositionPresented:alert.id}};
  }

  function Pregnancy_반응알림만들기(state,notice){
    return {id:notice.reaction.id,kind:'wc2_pregnancy_reaction',severity:'critical',pause:true,
      title:`${notice.motherName} · ${notice.type==='birth'?'출산 직후':'D1 수정 발생 · 임신 보고'}`,
      body:Pregnancy_사건문장만들기(notice),slot:Number(state.slot)||0,
      choices:[{id:'dismiss',label:'계속하기',description:'대사와 속마음을 확인하고 진행합니다.'}],
      tags:['pregnancy_mode','pregnancy_reaction',notice.type],
      pregnancyPaternityNotice:notice};
  }

  function Pregnancy_임신기간정규화하기(value,max){
    return Math.round(clampNumber(value,1,max,1));
  }

  function Pregnancy_임신일정만들기(useProvider=true){
    if(useProvider&&ruleProvider?.getGestationPlan)return ruleProvider.getGestationPlan();
    const durations=[1,options.earlyDays,options.middleDays,options.lateDays,1];
    const definitions=[['fertilization','수정일'],['early','임신 초기'],['middle','임신 중기'],['late','임신 후기'],['birth','출산일']];
    let start=0;
    const stages=definitions.map(([id,label],index)=>{
      const stage={id,label,start,duration:durations[index]};start+=stage.duration;return stage;
    });
    return {totalDays:start,stages};
  }

  function Pregnancy_출산예정일구하기(pregnancy){
    if(ruleProvider?.getBirthDay)return ruleProvider.getBirthDay(pregnancy);
    return pregnancy.conceptionDay+Pregnancy_임신일정만들기().totalDays;
  }

  function Pregnancy_임신기간설정하기(stage,value){
    const max={early:90,middle:100,late:90}[stage];
    if(!max)return;
    options={...options,[`${stage}Days`]:Pregnancy_임신기간정규화하기(value,max)};
    saveOptions();renderSettings();scheduleUI();
  }

  function Pregnancy_주기길이정규화하기(value){
    const length=Number(value);
    return [7,14,21,28,35].includes(length)?length:7;
  }

  function Pregnancy_약단계목록(){return ['follicular','ovulation','luteal']}

  function Pregnancy_주기단계만들기(length=options.cycleLength,useProvider=true,state=null){
    if(useProvider&&ruleProvider?.getCyclePhases)return ruleProvider.getCyclePhases(state);
    const unit=length/7;
    return [
      {id:'menstrual',label:'월경기',start:1,duration:unit},
      {id:'follicular',label:'난포기',start:unit+1,duration:unit*2},
      {id:'ovulation',label:'배란기',start:unit*3+1,duration:unit},
      {id:'luteal',label:'황체기',start:unit*4+1,duration:unit*3}
    ];
  }

  function Pregnancy_주기정보만들기(day,data={},useProvider=true){
    if(useProvider&&ruleProvider?.getCycleInfo)return ruleProvider.getCycleInfo(day,data);
    const length=options.cycleLength;
    const anchor=data.cycleAnchor??{day:1,cycleDay:1};
    const elapsed=(Math.max(1,Number(day)||1)-anchor.day)+anchor.cycleDay-1;
    const cycleDay=((elapsed%length)+length)%length+1;
    const phase=Pregnancy_주기단계만들기(length,false).find(item=>cycleDay>=item.start&&cycleDay<item.start+item.duration);
    return {...phase,cycleDay,length};
  }

  function Pregnancy_약예약적용하기(data,state,modeLogs){
    const pending=data.pendingCycleMedicine;
    if(!pending||Number(state.day)<pending.startDay)return false;
    data.pendingCycleMedicine=null;
    if(data.pregnancy){
      modeLogs.push('[임신 / 출산모드] 임신 중이므로 예약된 주기 변경 약을 취소했습니다.');
      return true;
    }
    const phase=Pregnancy_주기단계만들기(options.cycleLength,true,Pregnancy_인물상태만들기(state,data)).find(item=>item.id===pending.phase);
    if(ruleProvider?.applyCycleMedicine)ruleProvider.applyCycleMedicine(data,pending,phase);
    else data.cycleAnchor={day:pending.startDay,cycleDay:phase.start};
    modeLogs.push(`[임신 / 출산모드] 약의 효과로 ${pending.startDay}일차부터 ${phase.label}가 시작됩니다.`);
    return true;
  }

  function Pregnancy_임신단계만들기(data,day,useProvider=true){
    if(useProvider&&ruleProvider?.getPregnancyStage)return ruleProvider.getPregnancyStage(data,day);
    if(!data?.pregnancy)return null;
    const effectiveDay=data.pausedAtDay??day;
    const age=Math.max(0,(Number(effectiveDay)||1)-data.pregnancy.conceptionDay);
    const plan=Pregnancy_임신일정만들기(useProvider);
    const stage=plan.stages.find(item=>age<item.start+item.duration)??plan.stages.at(-1);
    return {...stage,age,dayInStage:Math.min(stage.duration,age-stage.start+1),birthIn:Math.max(0,plan.totalDays-age)};
  }

  function uterusLabel(data,day){
    const stage=Pregnancy_임신단계만들기(data,day);
    const cycle=Pregnancy_주기정보만들기(day,data);
    return stage?stage.label:`${cycle.label} (${cycle.cycleDay}/${cycle.length}일차)`;
  }

  function Pregnancy_시각상태만들기(state,data){
    if(!state||!options.enabled)return null;
    const day=Number(data.pausedAtDay??state.day)||1;
    const deposits=data.spermDeposits.filter(item=>day>=item.day&&day-item.day<=2);
    const amount=deposits.reduce((sum,item)=>sum+item.amount,0);
    const tier=amount<=0?0:Math.min(5,Math.ceil(amount/75));
    const field=['000','075','150','225','300','300'][tier];
    const owners=new Map();
    for(const item of deposits){
      const key=item.sourceId??item.sourceName,prior=owners.get(key);
      owners.set(key,{name:item.sourceName,amount:(prior?.amount??0)+item.amount,slot:Math.max(prior?.slot??0,item.slot)});
    }
    const spermOwners=[...owners.values()].sort((a,b)=>b.amount-a.amount||b.slot-a.slot||a.name.localeCompare(b.name,'ko')).map(item=>item.name);
    const common={amount,tier,ovumOwner:getWife(state)?.name||"그녀",spermOwners};
    if(ruleProvider?.getVisualState)return ruleProvider.getVisualState(state,data,common);
    const stage=Pregnancy_임신단계만들기(data,day);
    if(stage){
      const fileByStage={
        fertilization:`two-cell-with-sperm-field-${field}.png`,
        early:`thirty-cell-with-sperm-field-${field}.png`,
        middle:'development-4-embryo-uterine-lining.png',
        late:'development-5-fetus-uterine-lining.png',
        birth:'development-5-fetus-uterine-lining.png'
      };
      const description={fertilization:'2세포',early:'30세포 / 착상',middle:'배아',late:'태아',birth:'태아'}[stage.id];
      return {...common,kind:'pregnancy',stage:stage.id,label:`${stage.label} · ${description}`,
        file:fileByStage[stage.id],
        detail:`수정 후 ${stage.age}일 · 단계 ${stage.dayInStage}/${stage.duration}일 · 출산까지 ${stage.birthIn}일`};
    }
    const cycle=Pregnancy_주기정보만들기(day,data);
    const ovulating=cycle.id==='ovulation';
    return {...common,kind:'cycle',stage:cycle.id,label:cycle.label,
      file:ovulating?(tier?`ovum-surrounded-level-${tier}.png`:'ovum-unfertilized-count-000.png')
        :`sperm-only-level-${Math.min(5,tier+1)}-count-${field}.png`,
      detail:`주기 ${cycle.cycleDay}/${cycle.length}일차 · 정자량 ${amount}백만 마리 · ${tier}/5단계`};
  }

  function Pregnancy_생식그림표시하기(target,visual,context='state'){
    if(!target||!visual)return;
    const stamp=JSON.stringify(visual);
    let figure=target.querySelector(`:scope > [data-wc2pb-visual="${context}"]`);
    if(figure?.dataset.state===stamp)return;
    figure?.remove();
    figure=document.createElement('figure');
    figure.className='wc2pb-visual';figure.dataset.wc2pbVisual=context;figure.dataset.state=stamp;
    const shell=document.createElement('div');shell.className='wc2pb-visual-shell';
    const mother=document.createElement('span');mother.className='wc2pb-visual-owner mother';mother.textContent=visual.ovumOwner;mother.title=visual.ovumOwner;
    const imageBox=document.createElement('div');imageBox.className='wc2pb-visual-image';
    imageBox.setAttribute('role','img');imageBox.setAttribute('aria-label',visual.label);
    const files=visual.animated?['development-1-fertilization-entry-A.png','development-1-fertilization-entry-B.png']:[visual.file];
    let loaded=0;
    files.forEach((file,index)=>{
      const image=document.createElement('img');
      image.alt='';image.setAttribute('aria-hidden','true');image.width=400;image.height=400;
      image.dataset.layer=String(index);
      image.addEventListener('load',()=>{if(++loaded===2)imageBox.dataset.animated='1'},{once:true});
      image.addEventListener('error',()=>{imageBox.dataset.failed='1';imageBox.dataset.animated='0';
        if(!index)image.alt='생식 상태 이미지를 불러오지 못했습니다.';},{once:true});
      image.src=visual.assetUrls?.[file]??Pregnancy_Wml.fileUrl(`assets/${file}`);
      imageBox.appendChild(image);
    });
    const owners=document.createElement('div');owners.className='wc2pb-visual-owners';
    for(const name of visual.spermOwners??[]){
      const badge=document.createElement('span');badge.className='wc2pb-visual-owner sperm';badge.textContent=name;badge.title=name;owners.appendChild(badge);
    }
    shell.append(mother,imageBox,owners);
    const caption=document.createElement('figcaption');
    const title=document.createElement('strong');title.textContent=visual.label;
    const detail=document.createElement('span');detail.textContent=visual.detail;
    caption.append(title,detail);figure.append(shell,caption);target.prepend(figure);
  }

  function Pregnancy_수정알림그림갱신하기(){
    const state=getCurrentState(),event=state?.pendingEvent,alert=event?.alert;
    const isConception=alert?.kind==='wc2_pregnancy_reaction'&&
      (alert.pregnancyPaternityNotice?.type==='pregnancy'||alert.tags?.includes('pregnancy'));
    for(const old of document.querySelectorAll('[data-wc2pb-visual="event"]')){
      if(!isConception||old.dataset.eventId!==alert.id)old.remove();
    }
    if(!isConception)return;
    // 본문에는 게임의 한글 조사 보정이 적용됩니다. 원문 비교 대신 현재 사건 제목과 구조로 찾습니다.
    const headings=[...document.querySelectorAll('#root h3')].filter(node=>node.textContent.includes(alert.title));
    for(const heading of headings){
      const host=heading.parentElement;
      const body=host.querySelector(':scope > p')??host.querySelector('.border-2 > p');
      if(!body)continue;
      Pregnancy_생식그림표시하기(body.parentElement,{
        file:'development-1-fertilization-entry-A.png',animated:true,label:'D1수정 발생',
        ovumOwner:alert.pregnancyPaternityNotice?.motherName||getWife(state)?.name||"그녀",spermOwners:[],
        detail:'아침 임신 보고 · 내용을 확인하고 계속하기를 눌러 주세요.'
      },'event');
      const figure=body.parentElement.querySelector('[data-wc2pb-visual="event"]');
      figure.dataset.eventId=alert.id;
      if(body.previousElementSibling!==figure)body.before(figure);
      body.style.whiteSpace='pre-line';
    }
  }

  function Pregnancy_기간설정화면만들기(modal){
    const section=document.createElement('section');section.className='wc2pb-section';
    section.innerHTML=`<h3>임신 기간 조절</h3>
      <div class="wc2pb-setting"><label>수정일 / 출산일<small>각 1일로 고정됩니다. 출산일을 모두 보낸 다음 아침에 출산합니다.</small></label><span>각 1일</span></div>
      ${[['early','임신 초기',90],['middle','임신 중기',100],['late','임신 후기',90]].map(([id,label,max])=>`<div class="wc2pb-setting"><label for="wc2pb-${id}-days">${label}<small>1일(기본) ~ ${max}일</small></label><div><input id="wc2pb-${id}-days" data-wc2pb-${id}-days type="number" min="1" max="${max}" step="1"><span> 일</span></div></div>`).join('')}
      <p class="wc2pb-note" data-wc2pb-duration-note></p>`;
    modal.querySelector('[data-wc2pb-child-disposition]').closest('section').before(section);
    for(const stage of ['early','middle','late'])section.querySelector(`[data-wc2pb-${stage}-days]`).addEventListener('change',event=>Pregnancy_임신기간설정하기(stage,event.target.value));
  }

  function spermTotal(data){
    return(data?.spermDeposits??[]).reduce((sum,item)=>sum+(Number(item.amount)||0),0);
  }

  function conceptionChance(data){
    return clampNumber(options.conceptionChance+spermTotal(data),0,100,DEFAULT_OPTIONS.conceptionChance);
  }

  function getCurrentState(){
    try{return api?.ue?.getState?.().state??null}catch(_){return null}
  }

  function getWife(state){
    if(!state)return null;
    return state.characters?.[state.primaryCharacterId]??null;
  }

  function getStoredData(state){
    if(!state)return newData(1);
    return normalizeData(state[STATE_KEY],state.day,state);
  }

  function patronContextChanged(before,after){
    if(!after)return false;
    return!before||
      after.createdAtSlot!==before.createdAtSlot||
      after.patronName!==before.patronName||
      after.endReason!==before.endReason;
  }

  function patronClimaxedBetween(beforeState,afterState){
    const beforePatron=beforeState?.activeScene?.patron;
    const afterPatron=afterState?.activeScene?.patron;
    if(afterPatron?.afterglow){
      const sameAfterglow=!!beforePatron?.afterglow&&
        beforePatron.customerId===afterPatron.customerId&&
        beforePatron.afterglow.sinceSlot===afterPatron.afterglow.sinceSlot;
      if(!sameAfterglow)return true;
    }

    const beforeContext=getWife(beforeState)?.lastPatronContext;
    const afterContext=getWife(afterState)?.lastPatronContext;
    return!!(
      beforePatron&&
      !beforePatron.afterglow&&
      afterContext?.endReason==='patron_climax'&&
      patronContextChanged(beforeContext,afterContext)
    );
  }

  function patronActStartedBetween(beforeState,afterState){
    const before=beforeState?.activeScene?.patron;
    const after=afterState?.activeScene?.patron;
    const label=PATRON_ACT_LABELS[after?.stage];
    if(!after||after.afterglow||!label)return null;
    const samePatron=!!before&&String(before.customerId??before.customerName??'')===String(after.customerId??after.customerName??'');
    if(samePatron&&before.stage===after.stage)return null;
    return{patron:after,label};
  }

  function makePatronAlert(state,kind,patron){
    const wifeName=getWife(state)?.name||"그녀";
    const patronName=patron?.customerName||state.customers?.find(item=>item.id===patron?.customerId)?.name||'손님';
    const label=patron?.stage==='sex_patron'
      ?patron.primarySlot==='inside_anal'?'항문 삽입':'질 삽입'
      :PATRON_ACT_LABELS[patron?.stage]||'성행위';
    const isClimax=kind==='climax';
    const title=isClimax?'손님의 사정':'성행위 시작';
    const body=isClimax
      ?`${patronName}이(가) ${label} 도중 사정했습니다.`
      :`${wifeName}과(와) ${patronName}: ${label} 시작.`;
    return{
      id:makeId(`wc2_pregnancy_${kind}`),
      kind:`wc2_pregnancy_${kind}`,
      severity:'critical',
      pause:true,
      title,
      body,
      slot:Number(state.slot)||0,
      choices:[{id:'dismiss',label:'계속하기'}],
      tags:['pregnancy_mode','patron',kind]
    };
  }

  function hasNativeActStartAlert(state,patron){
    const id=String(patron?.customerId??'');
    const stage=String(patron?.stage??'');
    if(!id||!stage)return false;
    const nativeIds=new Set([`patron_escalation:${id}:${stage}`,`patron_escalation_away:${id}:${stage}`]);
    return nativeIds.has(state.pendingEvent?.alert?.id)||
      (state.alertQueue??[]).some(alert=>nativeIds.has(alert?.id));
  }

  function enqueuePatronAlert(draft,alert){
    if(draft.pendingEvent||draft.errandSession){
      draft.alertQueue=[...(draft.alertQueue??[]),alert];
      return;
    }
    draft.pendingEvent={
      type:'alert',alert,customerId:'',customerName:alert.title,text:alert.body,
      choices:alert.choices.map(choice=>({id:choice.id,label:choice.label,description:''}))
    };
  }

  function isPatronModeAlert(alert){
    return alert?.kind==='wc2_pregnancy_act_start'||alert?.kind==='wc2_pregnancy_climax';
  }

  function clearPatronModeAlerts(){
    const state=getCurrentState();
    if(!state)return;
    const queue=state.alertQueue??[];
    const filtered=queue.filter(alert=>!isPatronModeAlert(alert));
    const clearPending=state.pendingEvent?.type==='alert'&&isPatronModeAlert(state.pendingEvent.alert);
    if(filtered.length===queue.length&&!clearPending)return;
    const draft=clone(state);
    if(filtered.length!==queue.length)draft.alertQueue=filtered;
    if(clearPending)delete draft.pendingEvent;
    commitDraft(draft);
  }

  function dispatchWithPregnancyWaitGuard(action){
    if(
      !options.enabled||
      (!options.pauseOnPatronClimax&&!options.pauseOnPatronActStart)||
      steppingWait||
      action?.type!=='wait'||
      action.until||
      !Number.isFinite(Number(action.minutes))||
      Number(action.minutes)<=1||
      !getCurrentState()?.activeScene?.patron||
      getCurrentState()?.errandSession // 10-04: errand/sleep waits are capped by the game, never step them
    )return originalDispatch(action);

    const minutes=Math.max(1,Math.floor(Number(action.minutes)));
    let before=getCurrentState();
    const startingPhase=before?.phase;
    steppingWait=true;
    try{
      for(let minute=0;minute<minutes;minute++){
        originalDispatch({...action,minutes:1});
        const after=getCurrentState();
        if(!after)break;
        if(!before?.errandSession!==!after.errandSession)break; // an errand started or ended: stop stepping
        const climaxed=options.pauseOnPatronClimax&&patronClimaxedBetween(before,after);
        const actStarted=options.pauseOnPatronActStart&&patronActStartedBetween(before,after);
        if(climaxed||actStarted)break;
        if(after.pendingEvent||(startingPhase!=='bedroom'&&after.phase==='bedroom'))break;
        before=after;
      }
    }finally{steppingWait=false}
  }

  function installPregnancyWaitGuard(){
    const dispatch=api?.ue?.getState?.().dispatch;
    if(typeof dispatch!=='function'||dispatch.__wc2PregnancyWaitGuard)return;
    originalDispatch=dispatch;
    guardedWaitDispatch=action=>dispatchWithPregnancyWaitGuard(action);
    Object.defineProperty(guardedWaitDispatch,'__wc2PregnancyWaitGuard',{value:true});
    api.ue.setState({dispatch:guardedWaitDispatch});
  }

  function appendModeLog(draft,text){
    if(!text)return;
    const notice=typeof text==='object'?text:null;
    const displayed=notice?`[임신 / 출산모드] ${Pregnancy_사건문장만들기(notice)}`:text;
    draft.log=[...(draft.log??[]),{slot:Number(draft.slot)||0,text:displayed,eventCategory:'wc2_pregnancy_birth',important:true,
      ...(notice?{pregnancyPaternityNotice:notice}:{})}];
  }

  function normalizeChildCount(count){
    return Number.isInteger(count)&&count>=1&&count<=5?count:1;
  }
  function rollChildCount(random=Math.random()){
    const roll=Math.floor(random*10000);
    if(roll<1)return 5;
    if(roll<10)return 4;
    if(roll<50)return 3;
    if(roll<200)return 2;
    return 1;
  }
  function birthChildren(birthId,count){
    return Array.from({length:normalizeChildCount(count)},(_,index)=>({id:birthId+':'+(index+1),order:index+1}));
  }
  function pushHistory(data,type,day,pregnancy,motherName,reaction){
    const entry={
      id:makeId(type),
      type,
      day,
      conceptionDay:pregnancy.conceptionDay,
      fatherId:pregnancy.fatherId,
      fatherName:pregnancy.fatherName,
      fatherEstimates:Pregnancy_친부추정정규화하기(pregnancy.fatherEstimates),
      pregnancyReaction:pregnancy.reaction??null,
      reaction,
      motherName,
      childDisposition:null
    };
    entry.children=birthChildren(entry.id,pregnancy.childCount);
    data.birthLog=[...data.birthLog,entry].slice(-MAX_BIRTH_LOG);
    return entry;
  }

  function recordEjaculation(data,state,sourceId,sourceName,fingerprint,site,awarenessState=state){
    if(data.seenFinishes.includes(fingerprint))return null;
    data.seenFinishes=[...data.seenFinishes,fingerprint].slice(-MAX_SEEN_FINISHES);
    data.ejaculationCounts={...data.ejaculationCounts,[site]:(data.ejaculationCounts?.[site]??0)+1};
    if(site!=='vaginal')return 0;
    const amount=1+Math.floor(Math.random()*50);
    data.spermDeposits.push({
      id:makeId('sperm'),
      day:Number(state.day)||1,
      slot:Number(state.slot)||0,
      amount,
      sourceId:sourceId==null?null:String(sourceId),
      sourceName:String(sourceName||'알 수 없음'),
      wifeKnows:!Pregnancy_Wml.fn('PregnancyConversationBlockReason')(awarenessState),
      husbandKnows:sourceId==='player'||(!awarenessState.errandSession&&
        !!Pregnancy_Wml.fn('wifeLocation')(awarenessState)&&
        Pregnancy_Wml.fn('wifeLocation')(awarenessState)===Pregnancy_Wml.fn('playerLocation')(awarenessState))
    });
    return amount;
  }

  function recordPatronEjaculation(data,state,patron,at,awarenessState=state){
    const sourceId=patron.customerId??patron.customerName??'patron';
    const sourceName=patron.customerName||state.customers?.find(item=>item.id===patron.customerId)?.name||'손님';
    const fingerprint=`patron:${sourceId}:${at}`;
    const site=patron.primarySlot==='inside_anal'?'anal':'vaginal';
    recordEjaculation(data,state,sourceId,sourceName,fingerprint,site,awarenessState);
  }

  function captureFinishes(data,state,priorState,actorContext=null){
    const sex=state.activeScene?.sex;
    if(sex?.finish&&VAGINAL_PLAYER_SCENES.has(sex.type)){
      const at=Number.isFinite(sex.finish.startedAtSlot)?sex.finish.startedAtSlot:Number(state.slot)||0;
      const fingerprint=`${actorContext?.partnerId??'player'}:${at}:${sex.type}`;
      if(sex.finish.reason==='cum_inside')recordEjaculation(data,state,actorContext?.partnerId??'player',actorContext?.partnerName??"당신",fingerprint,'vaginal');
    }else if(sex?.finish&&ANAL_PLAYER_SCENES.has(sex.type)){
      const at=Number.isFinite(sex.finish.startedAtSlot)?sex.finish.startedAtSlot:Number(state.slot)||0;
      const fingerprint=`${actorContext?.partnerId??'player'}:${at}:${sex.type}`;
      recordEjaculation(data,state,actorContext?.partnerId??'player',actorContext?.partnerName??"당신",fingerprint,'anal');
    }

    const patron=state.activeScene?.patron;
    if(patron?.afterglow&&patron.stage==='sex_patron'&&Number(patron.patronBoldness)>55){
      const at=Number.isFinite(patron.afterglow.sinceSlot)?patron.afterglow.sinceSlot:Number(state.slot)||0;
      recordPatronEjaculation(data,state,patron,at);
    }

    // Some patron climaxes have a zero-length afterglow. The game finalizes and
    // removes activeScene.patron in the same store update, so subscribers never
    // get to observe the afterglow object. Confirm that exact transition through
    // the newly written lastPatronContext before recording the deposit.
    const priorPatron=priorState?.activeScene?.patron;
    const context=getWife(state)?.lastPatronContext;
    const priorContext=getWife(priorState)?.lastPatronContext;
    const contextChanged=patronContextChanged(priorContext,context);
    if(
      priorPatron&&
      !patron?.afterglow&&
      !priorPatron.afterglow&&
      priorPatron.stage==='sex_patron'&&
      Number(priorPatron.patronBoldness)>55&&
      contextChanged&&
      context.endReason==='patron_climax'&&
      context.maxStage==='sex_patron'&&
      context.patronName===priorPatron.customerName
    ){
      const at=Number.isFinite(context.createdAtSlot)?context.createdAtSlot:Number(state.slot)||0;
      recordPatronEjaculation(data,state,priorPatron,at,priorState);
    }
  }

  function processMorning(data,state,notices,modeLogs,childAlerts){
    const day=Number(state.day)||1;
    const due=data.pregnancy&&day>=Pregnancy_출산예정일구하기(data.pregnancy);
    const deferred=due&&data.pregnancy.birthDeferred===true;
    if(!deferred&&(state.phase!=='prep'||day===data.lastMorningDay))return{birthEnergy:null,adoptionGold:0,changed:false};
    if(due&&(state.activeScene?.patron||state.activeScene?.sex)){
      data.pregnancy.birthDeferred=true;
      return{birthEnergy:null,adoptionGold:0,changed:!deferred};
    }
    if(day<data.lastMorningDay){data.lastMorningDay=day;return{birthEnergy:null,adoptionGold:0,changed:true}}

    data.lastMorningDay=day;
    data.spermDeposits=data.spermDeposits.filter(item=>day-item.day<=2);
    const wife=getWife(state);
    const motherName=wife?.name||"그녀";
    let birthEnergy=null;
    let adoptionGold=0;

    if(data.pregnancy&&day>=Pregnancy_출산예정일구하기(data.pregnancy)){
      const reaction=Pregnancy_반응만들기(state,'birth',data.pregnancy);
      const notice={...data.pregnancy,type:'birth',motherName,reaction};
      const history=pushHistory(data,'birth',day,data.pregnancy,motherName,reaction);
      const childDisposition=Pregnancy_아이처치계획만들기({fatherEstimates:data.pregnancy.fatherEstimates,
        desireScore:reaction.desireScore,profile:wife,relationshipTrust:wife?.relationship?.trust,motherName,day,address:'당신'});
      history.childDisposition=childDisposition;
      notice.childCount=history.children.length;
      notice.childDisposition=childDisposition;
      if(childDisposition.showEvent){
        childAlerts.push(Pregnancy_아이처치알림만들기(childDisposition,history.id,motherName));
      }
      adoptionGold+=childDisposition.adoptionFee;
      ruleProvider?.afterBirth?.(data,state);
      data.pregnancy=null;
      notices.push(notice);
      modeLogs.push(notice);
      birthEnergy=10;
    }else Pregnancy_수정판정하기(data,state,notices,modeLogs);
    const morningStatus=birthEnergy!=null?'출산 직후':uterusLabel(data,day);
    modeLogs.push(`[임신 / 출산모드 아침 브리핑] ${motherName}의 자궁 상태: ${morningStatus}. 자궁 내 정자량: ${spermTotal(data)} (단위 : 백만마리).`);
    return{birthEnergy,adoptionGold,changed:true};
  }

  function Pregnancy_수정판정하기(data,state,notices,modeLogs){
    const day=Number(state.day)||1,motherName=getWife(state)?.name||"그녀";
    if(!data.pregnancy&&['ovulation','luteal'].includes(Pregnancy_주기정보만들기(day,data).id)&&data.spermDeposits.length>0&&Math.random()*100<conceptionChance(data)){
      const possibleFathers=[...new Map(data.spermDeposits.map(item=>[item.sourceId??item.sourceName,item])).values()];
      const source=possibleFathers[Math.floor(Math.random()*possibleFathers.length)];
      data.pregnancy={
        conceptionDay:day,
        childCount:rollChildCount(),
        fatherId:source.sourceId,
        fatherName:source.sourceName,
        sourceDepositId:source.id,
        fatherEstimates:Pregnancy_친부추정만들기(data.spermDeposits)
      };
      data.pregnancy.reaction=Pregnancy_반응만들기(state,'pregnancy',data.pregnancy);
      ruleProvider?.afterConception?.(data,state);
      if(!ruleProvider?.retainDeposits)data.spermDeposits=[];
      const notice={...data.pregnancy,type:'pregnancy',motherName};
      notices.push(notice);
      modeLogs.push(notice);
    }
  }

  function commitDraft(draft){
    internalWrite=true;
    try{api.ue.setState(root=>({...root,state:draft}))}
    finally{
      internalWrite=false;
      previousState=getCurrentState();
    }
  }

  function onStoreChange(){
    let state=getCurrentState();
    if(!state){previousState=null;return}
    if(internalWrite){previousState=state;return}

    const root=api.ue.getState();
    if(!root.started){previousState=state;scheduleUI();return}
    const presented=Pregnancy_아이처치현재반응반영하기(Pregnancy_친부로그갱신하기(state,getStoredData(state)),getStoredData(state));
    const presentationChanged=presented!==state;
    state=presented;
    const obsoleteNotice=state.pendingEvent?.type==='patron_interaction'&&
      String(state.pendingEvent.text??'').startsWith('[임신 / 출산모드]')&&
      state.pendingEvent.choices?.length===1&&
      state.pendingEvent.choices[0]?.id==='continue_after_climax';
    if(!options.enabled){
      if(obsoleteNotice){const draft=clone(state);delete draft.pendingEvent;commitDraft(draft)}
      else if(presentationChanged)commitDraft(state);
      else previousState=state;
      scheduleUI();
      return;
    }

    const hadData=!!state[STATE_KEY];
    const data=getStoredData(state);
    let changed=presentationChanged||!hadData||state[STATE_KEY]?.version!==8||
      !state[STATE_KEY]?.ejaculationCounts||
      state[STATE_KEY]?.spermDeposits?.some(item=>typeof item.wifeKnows!=='boolean'||typeof item.husbandKnows!=='boolean');
    const notices=[];
    const modeLogs=[];
    const childAlerts=[];
    const queuedReaction=!state.pendingEvent&&!state.errandSession&&
      (state.alertQueue??[]).some(alert=>alert.kind==='wc2_pregnancy_reaction');
    const queuedChildDisposition=!state.pendingEvent&&!state.errandSession&&
      (state.alertQueue??[]).some(alert=>alert.kind==='wc2_child_disposition');
    let birthEnergy=null;
    const actStarted=options.showPatronEventAlerts&&patronActStartedBetween(previousState,state);
    const climaxed=options.showPatronEventAlerts&&patronClimaxedBetween(previousState,state);
    const patronAlerts=[];
    if(actStarted&&!hasNativeActStartAlert(state,actStarted.patron))
      patronAlerts.push(makePatronAlert(state,'act_start',actStarted.patron));
    if(climaxed)patronAlerts.push(makePatronAlert(state,'climax',state.activeScene?.patron??previousState?.activeScene?.patron));

    if(data.pausedAtDay!=null){
      const gap=Math.max(0,(Number(state.day)||1)-data.pausedAtDay);
      Pregnancy_일정미루기(data,gap);
      data.pausedAtDay=null;
      data.lastMorningDay=Number(state.day)||1;
      changed=true;
    }

    changed=ruleProvider?.prepareData?.(data,state)||changed;
    changed=Pregnancy_약예약적용하기(data,state,modeLogs)||changed;
    const morning=processMorning(data,state,notices,modeLogs,childAlerts);
    changed=changed||morning.changed;
    birthEnergy=morning.birthEnergy;

    const beforeSperm=data.spermDeposits.length;
    const beforeSeen=data.seenFinishes.length;
    captureFinishes(data,state,previousState);
    if(ruleProvider?.immediateConception&&beforeSperm!==data.spermDeposits.length)Pregnancy_수정판정하기(data,state,notices,modeLogs);
    changed=changed||beforeSperm!==data.spermDeposits.length||beforeSeen!==data.seenFinishes.length;

    let pregnancyEnergy=null;
    if(previousState&&previousState.day===state.day&&Number(state.slot)>=Number(previousState.slot)&&data.pregnancy&&
      Pregnancy_임신단계만들기(data,state.day).id!=='fertilization'){
      const oldEnergy=Number(getWife(previousState)?.stats?.energy);
      const newEnergy=Number(getWife(state)?.stats?.energy);
      if(Number.isFinite(oldEnergy)&&Number.isFinite(newEnergy)&&newEnergy<oldEnergy){
        pregnancyEnergy=Math.max(0,newEnergy-(oldEnergy-newEnergy)*.5);
        changed=true;
      }
    }

    if(changed||obsoleteNotice||patronAlerts.length||queuedReaction||queuedChildDisposition||childAlerts.length){
      const draft=clone(state);
      draft[STATE_KEY]=data;
      if(morning.adoptionGold)draft.economy={...(draft.economy??{}),gold:(Number(draft.economy?.gold)||0)+morning.adoptionGold};
      const wife=draft.characters?.[draft.primaryCharacterId];
      const targetEnergy=birthEnergy!=null?birthEnergy:pregnancyEnergy;
      if(wife&&targetEnergy!=null)wife.stats={...(wife.stats??{}),energy:targetEnergy};
      if(wife&&birthEnergy!=null)wife.birthLeaveDay=draft.day;
      modeLogs.forEach(text=>appendModeLog(draft,text));
      if(obsoleteNotice)delete draft.pendingEvent;
      for(const notice of notices){
        if(!notice.reaction)continue;
        if(wife){
          wife.lastResponse=notice.reaction.dialogue;
          wife.lastResponseType=notice.reaction.condition.endsWith('_welcomed')?'accept':'hesitant';
          wife.lastResponseSlot=Number(draft.slot)||0;
          wife.innerThought=notice.reaction.innerThought;
          wife.innerThoughtType='conflicted';
          wife.innerThoughtSlot=Number(draft.slot)||0;
        }
        draft.alertQueue=[...(draft.alertQueue??[]),Pregnancy_반응알림만들기(draft,notice)];
      }
      for(const alert of childAlerts){
        const history=data.birthLog.find(item=>item.id===alert.childDisposition?.recordId),disposition=history?.childDisposition;
        if(disposition)Pregnancy_아이처치로그추가하기(draft,history.motherName,disposition,disposition.status==='pending'?'question':'result');
        draft.alertQueue=[...(draft.alertQueue??[]),alert];
      }
      if(notices.length||queuedReaction||queuedChildDisposition||childAlerts.length)Object.assign(draft,Pregnancy_Wml.fn('drainAlerts')(draft));
      patronAlerts.forEach(alert=>enqueuePatronAlert(draft,alert));
      commitDraft(Pregnancy_아이처치현재반응반영하기(draft,data));
    }else previousState=state;

    notices.forEach(showToast);
    scheduleUI();
  }

  function updateDataDirect(mutator){
    const state=getCurrentState();
    if(!state)return;
    const draft=clone(state);
    const data=getStoredData(draft);
    mutator(data,draft);
    draft[STATE_KEY]=data;
    commitDraft(draft);
    scheduleUI();
  }

  function setEnabled(enabled){
    enabled=!!enabled;
    if(enabled===options.enabled)return;
    const state=getCurrentState();
    if(state){
      updateDataDirect(data=>{
        const day=Number(state.day)||1;
        if(!enabled)data.pausedAtDay=day;
        else{
          const gap=data.pausedAtDay==null?0:Math.max(0,day-data.pausedAtDay);
          Pregnancy_일정미루기(data,gap);
          data.pausedAtDay=null;
          data.lastMorningDay=day;
        }
      });
    }
    options={...options,enabled};
    saveOptions();
    if(!enabled)clearPatronModeAlerts();
    renderSettings();
    scheduleUI();
    showToast(`임신 / 출산모드 ${enabled?'ON':'OFF'}`);
  }

  function setChance(value){
    options={...options,conceptionChance:clampNumber(value,0,100,DEFAULT_OPTIONS.conceptionChance)};
    saveOptions();
    renderSettings();
  }

  function Pregnancy_실제친부공개설정하기(enabled){
    options={...options,showActualFather:!!enabled};
    saveOptions();
    const state=getCurrentState();
    if(state){
      const presented=Pregnancy_친부로그갱신하기(state,getStoredData(state));
      if(presented!==state)commitDraft(presented);
    }
    const toast=document.getElementById('wc2-pregnancy-toast-265');
    if(toast?.pregnancyPaternityNotice)toast.textContent=Pregnancy_친부알림문장만들기(toast.pregnancyPaternityNotice);
    renderSettings();scheduleUI();
  }

  function Pregnancy_아이처치상의설정하기(enabled){
    options={...options,childDispositionConsultation:!!enabled};
    saveOptions();renderSettings();scheduleUI();
  }

  function Pregnancy_입양비방식설정하기(mode){
    options={...options,adoptionFeeMode:mode==='fixed'?'fixed':'random'};
    saveOptions();renderSettings();
  }

  function Pregnancy_입양비금액설정하기(key,value){
    const optionKey={fixed:'adoptionFeeFixed',min:'adoptionFeeMin',max:'adoptionFeeMax'}[key];
    if(!optionKey)return;
    options={...options,[optionKey]:Math.round(clampNumber(value,0,9999,DEFAULT_OPTIONS[optionKey]))};
    saveOptions();renderSettings();
  }

  // All live schedules move together. Historical birth/reaction records and pausedAtDay stay unchanged.
  function Pregnancy_일정미루기(data,gap){
    if(!Number.isInteger(gap)||gap<0)throw new RangeError('Pregnancy schedule days must be a non-negative integer');
    if(!gap)return data;
    data.spermDeposits=data.spermDeposits.map(item=>({...item,day:item.day+gap}));
    if(data.pregnancy)data.pregnancy={...data.pregnancy,conceptionDay:data.pregnancy.conceptionDay+gap};
    ruleProvider?.shiftSchedule?.(data,gap);
    if(data.cycleAnchor)data.cycleAnchor={...data.cycleAnchor,day:data.cycleAnchor.day+gap};
    if(data.pendingCycleMedicine)data.pendingCycleMedicine={...data.pendingCycleMedicine,startDay:data.pendingCycleMedicine.startDay+gap};
    data.lastMorningDay+=gap;
    return data;
  }

  function Pregnancy_주기길이설정하기(value){
    const previousLength=options.cycleLength;
    const length=Pregnancy_주기길이정규화하기(value);
    const state=getCurrentState();
    const cycle=state?Pregnancy_주기정보만들기(state.day,getStoredData(state)):null;
    options={...options,cycleLength:length};
    saveOptions();
    if(cycle&&length!==previousLength)updateDataDirect((data,draft)=>{
      data.cycleAnchor={day:Number(draft.day)||1,cycleDay:Math.floor((cycle.cycleDay-1)*length/previousLength)+1};
    });
    renderSettings();
    scheduleUI();
  }

  function Pregnancy_약사용가능여부(state){
    const wife=getWife(state);
    return options.enabled&&!!wife&&!getStoredData(state).pregnancy&&!state.errandSession
      &&!state.activeScene?.sex&&!state.activeScene?.patron
      &&!Pregnancy_Wml.fn('PregnancyConversationBlockReason')(state)
      &&Pregnancy_Wml.fn('wifeLocation')(state)===Pregnancy_Wml.fn('playerLocation')(state);
  }

  function Pregnancy_약선택지추가하기(state){
    const event=state?.pendingEvent;
    if(event?.type!=='wife_conversation'||(event.category&&event.category!=='behavior'))return state;
    const id='pregnancy_ask_cycle_medicine';
    const choices=(event.choices??[]).filter(choice=>choice.id!==id);
    if(options.enabled)choices.push({id,label:'약 복용을 부탁한다',
      description:getStoredData(state).pregnancy?'임신 중에는 주기 변경 약을 복용할 수 없습니다.':'약을 선택하면 다음 날부터 해당 주기가 시작됩니다.',
      disabled:!Pregnancy_약사용가능여부(state)});
    return {...state,pendingEvent:{...event,choices,pregnancyMedicineConversation:options.enabled}};
  }

  function Pregnancy_아이처치답변처리하기(next,state,action){
    const event=state?.pendingEvent,alert=event?.alert,choiceId=action?.choiceId;
    if(action?.type!=='resolve_event'||alert?.kind!=='wc2_child_disposition'||alert.childDisposition?.source!=='pregnancy'||
      alert.childDisposition?.phase!=='question')return null;
    if(!['pregnancy_child_parents','pregnancy_child_adoption','pregnancy_child_adoption_profit'].includes(choiceId))return state;
    const choices=event.choices??alert.choices??[];
    if(!choices.some(choice=>choice.id===choiceId&&!choice.disabled))return state;
    const initialRecord=getStoredData(state).birthLog.find(item=>item.id===alert.childDisposition.recordId);
    if(initialRecord?.childDisposition?.status!=='pending')return state;
    const deferredQueue=state.alertQueue??[];
    let result=next({...state,alertQueue:[]},action);
    const data=getStoredData(result),history=data.birthLog.find(item=>item.id===alert.childDisposition.recordId);
    if(!history?.childDisposition||history.childDisposition.status!=='pending')return result;
    const decision=choiceId==='pregnancy_child_adoption_profit'?'adoption_profit':choiceId==='pregnancy_child_adoption'?'adoption':'parents';
    const disposition=Pregnancy_아이처치완료하기(history.childDisposition,decision,result.day);
    history.childDisposition=disposition;
    result={...result,[STATE_KEY]:data};
    if(disposition.adoptionFee)result={...result,economy:{...(result.economy??{}),gold:(Number(result.economy?.gold)||0)+disposition.adoptionFee}};
    const effect=disposition.outcome?.effect;
    const delta=disposition.outcome?.parameterChanges;
    if(delta){
      result=Pregnancy_Wml.fn('nudgeRelationship')(result,{trust:delta.trust,resentment:delta.resentment});
      result=Pregnancy_Wml.fn('updateWife')(result,wife=>({...wife,stats:{...wife.stats,mood:clampNumber(Number(wife.stats?.mood)+delta.mood,0,100,50)}}));
      result=Pregnancy_Wml.fn('addFeeling')(result,delta.emotion,{
        intensity:delta.intensity,source:`pregnancy:child_disposition:${disposition.id}`,target:{kind:'husband'},durationSlots:1440,
        blurb:disposition.outcome.refused?'그녀는 출산 후 입양 제안을 거절했다':disposition.outcome.innerThought});
      if(disposition.status==='adopted')result=Pregnancy_Wml.fn('addFeeling')(result,'regret',{
        intensity:28,source:`pregnancy:child_adoption:${disposition.id}`,target:{kind:'self'},durationSlots:720});
    }
    result=Pregnancy_Wml.fn('updateWife')(result,wife=>({...wife,lastResponse:disposition.outcome.dialogue,
      lastResponseType:delta?.emotion==='anger'?'angry':effect==='positive'?'accept':'hesitant',lastResponseSlot:Number(result.slot)||0,
      innerThought:disposition.outcome.innerThought,innerThoughtType:effect==='positive'?'conflicted':'resentful',innerThoughtSlot:Number(result.slot)||0}));
    Pregnancy_아이처치로그추가하기(result,history.motherName,disposition,'result');
    const followup=Pregnancy_아이처치알림만들기(disposition,history.id,history.motherName);
    result={...result,alertQueue:[followup,...(result.alertQueue??[]),...deferredQueue]};
    if(!result.pendingEvent&&!result.errandSession)result=Pregnancy_Wml.fn('drainAlerts')(result);
    return result;
  }

  function Pregnancy_대화행동처리하기(next,state,action){
    const childEvent=state?.pendingEvent;
    if(action?.type==='resolve_event'&&childEvent?.alert?.kind==='wc2_child_disposition'){
      const choices=childEvent.choices??childEvent.alert.choices??[];
      if(!choices.some(choice=>choice.id===action.choiceId&&!choice.disabled))return state;
      if(childEvent.alert.childDisposition?.phase==='result'){
        let result=next(state,action);
        if(!result.pendingEvent&&!result.errandSession)result=Pregnancy_Wml.fn('drainAlerts')(result);
        return result;
      }
    }
    const childDisposition=Pregnancy_아이처치답변처리하기(next,state,action);
    if(childDisposition)return childDisposition;
    const event=state?.pendingEvent;
    const id=action?.topicId??action?.choiceId;
    const isChoice=['wife_topic','resolve_event'].includes(action?.type)&&event?.type==='wife_conversation';
    if(isChoice&&id==='pregnancy_ask_cycle_medicine'){
      if(!event.choices?.some(choice=>choice.id===id&&!choice.disabled)||!Pregnancy_약사용가능여부(state))return state;
      const choices=Pregnancy_주기단계만들기(options.cycleLength,true,state).filter(phase=>Pregnancy_약단계목록().includes(phase.id)).map(phase=>({
        id:`pregnancy_medicine_${phase.id}`,label:`${phase.label} 약을 준다`,description:`${Number(state.day)+1}일차에 ${phase.label}가 시작됩니다.`
      }));
      choices.push({id:'pregnancy_medicine_back',label:'뒤로',description:'약을 주지 않고 대화로 돌아갑니다.'});
      return {...state,pendingEvent:{...event,category:'pregnancy_cycle_medicine',pregnancyMedicineConversation:true,
        text:'어떤 주기 변경 약을 줄까요?',choices}};
    }
    if(isChoice&&event.category==='pregnancy_cycle_medicine'&&String(id).startsWith('pregnancy_medicine_')){
      if(!event.choices?.some(choice=>choice.id===id&&!choice.disabled))return state;
      if(id==='pregnancy_medicine_back')return Pregnancy_약선택지추가하기({...state,pendingEvent:Pregnancy_Wml.fn('PregnancyConversationMenu')(state)});
      if(!Pregnancy_약사용가능여부(state))return state;
      const phaseId=id.slice('pregnancy_medicine_'.length);
      if(!Pregnancy_약단계목록().includes(phaseId))return state;
      const data=getStoredData(state);
      data.pendingCycleMedicine={phase:phaseId,startDay:Number(state.day)+1};
      const phase=Pregnancy_주기단계만들기(options.cycleLength,true,state).find(item=>item.id===phaseId);
      const result={...state,[STATE_KEY]:data,pendingEvent:undefined};
      appendModeLog(result,`[임신 / 출산모드] ${getWife(state).name}에게 ${phase.label} 약을 주었습니다. ${data.pendingCycleMedicine.startDay}일차부터 적용됩니다.`);
      return result;
    }
    return Pregnancy_약선택지추가하기(next(state,action));
  }

  function setPauseOnPatronClimax(enabled){
    options={...options,pauseOnPatronClimax:!!enabled};
    saveOptions();
    renderSettings();
  }

  function setPauseOnPatronActStart(enabled){
    options={...options,pauseOnPatronActStart:!!enabled};
    saveOptions();
    renderSettings();
  }

  function setShowPatronEventAlerts(enabled){
    options={...options,showPatronEventAlerts:!!enabled};
    saveOptions();
    if(!options.showPatronEventAlerts)clearPatronModeAlerts();
    renderSettings();
  }

  function showToast(message){
    let node=document.getElementById('wc2-pregnancy-toast-265');
    if(!node){
      node=document.createElement('div');
      node.id='wc2-pregnancy-toast-265';
      node.setAttribute('role','status');
      document.body.appendChild(node);
    }
    node.pregnancyPaternityNotice=typeof message==='object'?message:null;
    node.textContent=node.pregnancyPaternityNotice?Pregnancy_친부알림문장만들기(message):message;
    node.classList.add('show');
    clearTimeout(node._wc2Timer);
    node._wc2Timer=setTimeout(()=>node.classList.remove('show'),3200);
  }

  function addInfoRow(parent,label,value,accent){
    const row=document.createElement('div');
    row.className='wc2pb-info-row';
    const left=document.createElement('span');
    left.textContent=label;
    const right=document.createElement('span');
    right.textContent=value;
    if(accent)right.classList.add(accent);
    row.append(left,right);
    parent.appendChild(row);
  }

  function Pregnancy_약예약표시하기(parent,data,state){
    if(!data.pendingCycleMedicine)return;
    const pending=data.pendingCycleMedicine;
    const phase=Pregnancy_주기단계만들기(options.cycleLength,true,Pregnancy_인물상태만들기(state,data)).find(item=>item.id===pending.phase);
    addInfoRow(parent,'약 복용 예약',`${pending.startDay}일차부터 ${phase.label}`,'');
  }

  function Pregnancy_친부정보표시하기(parent,record){
    const display=Pregnancy_친부표시만들기(record);
    addInfoRow(parent,"친부 추정 · 그녀",display.wife,'father');
    addInfoRow(parent,"친부 추정 · 당신",display.husband,'father');
    if(display.actual)addInfoRow(parent,'실제 친부',display.actual,'father');
  }

  function Pregnancy_임신의향표시하기(parent,desire){
    if(desire)addInfoRow(parent,"임신 의향 · 당신의 아이",`${desire.label} (${desire.score}/100)`,'');
  }

  function renderStatus(section,state,raw){
    if(!section?.appendChild)throw new TypeError('Pregnancy renderStatus requires a DOM element');
    const data=state?normalizeData(raw,state.day,state):null;
    if(state)state=Pregnancy_인물상태만들기(state,data);
    let body=section.querySelector(':scope > [data-wc2-preg-body]');
    if(!body){body=document.createElement('div');body.dataset.wc2PregBody='1';section.appendChild(body);}
    const desire=state?Pregnancy_임신의향계산하기(state):null;
    const renderKey=JSON.stringify([options,ruleProvider?.getOptions?.(),state?.primaryCharacterId,getWife(state)?.name,state?.day,data,desire]);
    if(section.dataset.wc2PregRenderKey===renderKey&&body.childNodes.length)return section;
    section.dataset.wc2PregRenderKey=renderKey;
    body.replaceChildren();
    if(!options.enabled){addInfoRow(body,'모드 상태','OFF','muted');return section;}
    if(!state){addInfoRow(body,'상태','게임 시작 전','muted');return section;}
    Pregnancy_생식그림표시하기(body,Pregnancy_시각상태만들기(state,data));
    addInfoRow(body,'생리 / 임신 상태',uterusLabel(data,state.day),data.pregnancy?'pregnant':'');
    addInfoRow(body,'자궁 내 정자량 (단위 : 백만마리)',String(spermTotal(data)),'sperm');
    if(!data.pregnancy)addInfoRow(body,'현재 임신 판정 확률',data.spermDeposits.length?`${conceptionChance(data)}% (배란기·황체기 아침)`:'정자 없음','');
    Pregnancy_약예약표시하기(body,data,state);
    Pregnancy_임신의향표시하기(body,desire);
    if(data.pregnancy)Pregnancy_친부정보표시하기(body,data.pregnancy);
    return section;
  }

  function shouldInjectStatus(panel,state){
    if(!state||!panel?.matches?.('[data-wc2-preg-main-panel]')||panel.dataset.wc2PregMainPanel!==String(state.primaryCharacterId))return false;
    if(panel.closest('[data-npc-status-panel],[data-npc-character-sheet],[data-pregnancy-status-auto="off"]'))return false;
    const owner=panel.closest('[data-character-id]');
    if(owner&&owner.dataset.characterId!==String(state.primaryCharacterId))return false;
    for(const filter of statusFilters.values())if(filter(panel,state)===false)return false;
    return true;
  }

  function registerStatusFilter(owner,filter){
    if(!owner||typeof filter!=='function'||statusFilters.has(owner))throw new TypeError('Pregnancy status filter requires a unique owner and function');
    statusFilters.set(owner,filter);scheduleUI();
    return()=>{if(statusFilters.get(owner)===filter){statusFilters.delete(owner);scheduleUI();}};
  }

  function injectWifeStatus(){
    const state=getCurrentState();
    for(const section of document.querySelectorAll('[data-wc2-preg-auto]')){
      if(!shouldInjectStatus(section.parentElement,state))section.remove();
    }
    for(const panel of document.querySelectorAll('[data-wc2-preg-main-panel]')){
      if(!shouldInjectStatus(panel,state))continue;
      let section=panel.querySelector(':scope > [data-wc2-preg-auto]');
      if(!section){
        section=document.createElement('div');
        section.className='mb-4 wc2pb-status-section';
        section.dataset.wc2PregStatus='1';
        section.dataset.wc2PregAuto='1';
        const title=document.createElement('h3');
        title.className='text-xs font-bold text-stone-400 uppercase tracking-wider mb-2';
        title.textContent='자궁 상태';
        const body=document.createElement('div');
        body.dataset.wc2PregBody='1';
        section.append(title,body);
        panel.appendChild(section);
      }
      renderStatus(section,state,state[STATE_KEY]);
    }
  }

  function injectPauseButton(){
    const pauseTitle=[...document.querySelectorAll('h2')].find(node=>['일시 정지','Paused'].includes((node.textContent||'').trim()));
    const pauseRoot=pauseTitle?.closest('.fixed');
    if(!pauseRoot)return;
    const modButton=[...pauseRoot.querySelectorAll('button')].find(node=>['설정','Settings'].includes((node.textContent||'').trim()));
    if(!modButton||pauseRoot.querySelector('[data-wc2-preg-menu]'))return;
    const button=document.createElement('button');
    button.type='button';
    button.dataset.wc2PregMenu='1';
    button.className=modButton.className;
    button.textContent='임신 / 출산모드 설정';
    button.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();openSettings()});
    modButton.insertAdjacentElement('afterend',button);
  }

  function scheduleUI(){
    if(uiFrame)return;
    uiFrame=requestAnimationFrame(()=>{
      uiFrame=0;
      injectPauseButton();
      injectWifeStatus();
      Pregnancy_수정알림그림갱신하기();
      const modal=document.getElementById('wc2-pregnancy-settings-265');
      if(modal)renderSettings();
    });
  }

  function ensureStyles(){
    if(document.getElementById('wc2-pregnancy-style-265'))return;
    const style=document.createElement('style');
    style.id='wc2-pregnancy-style-265';
    style.textContent=`
      #wc2-pregnancy-toast-265{position:fixed;left:50%;bottom:78px;z-index:2147483647;max-width:min(560px,calc(100vw - 32px));transform:translate(-50%,18px);opacity:0;pointer-events:none;background:#1c1917;color:#fde68a;border:1px solid #b45309;border-radius:10px;padding:9px 13px;box-shadow:0 12px 36px rgba(0,0,0,.55);font:700 12px/1.45 "Malgun Gothic","Apple SD Gothic Neo",sans-serif;transition:opacity .18s ease,transform .18s ease;text-align:center}
      #wc2-pregnancy-toast-265.show{opacity:1;transform:translate(-50%,0)}
      .wc2pb-info-row{display:flex;justify-content:space-between;gap:12px;margin-bottom:6px;font-size:12px;color:#a8a29e}.wc2pb-info-row>span:last-child{color:#e7e5e4;text-align:right;font-weight:600}.wc2pb-info-row>span.pregnant{color:#f9a8d4}.wc2pb-info-row>span.sperm{color:#93c5fd}.wc2pb-info-row>span.father{color:#fcd34d}.wc2pb-info-row>span.muted{color:#78716c}
      #wc2-pregnancy-settings-265{position:fixed;inset:0;z-index:2147483646;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(0,0,0,.78);font-family:"Malgun Gothic","Apple SD Gothic Neo","Noto Sans KR",sans-serif;color:#e7e5e4}
      #wc2-pregnancy-settings-265 .wc2pb-card{width:min(620px,100%);max-height:90dvh;overflow:auto;background:#1c1917;border:1px solid #57534e;border-radius:13px;box-shadow:0 22px 70px rgba(0,0,0,.65);padding:20px}
      #wc2-pregnancy-settings-265 .wc2pb-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:14px}#wc2-pregnancy-settings-265 h2{margin:0;color:#fcd34d;font-size:20px;font-weight:800}#wc2-pregnancy-settings-265 .wc2pb-version{margin-top:3px;color:#a16207;font-size:11px}#wc2-pregnancy-settings-265 .wc2pb-close{color:#a8a29e;font-size:18px;padding:2px 7px;border-radius:6px}#wc2-pregnancy-settings-265 .wc2pb-close:hover{background:#292524;color:#fff}
      #wc2-pregnancy-settings-265 .wc2pb-note{padding:10px 12px;margin-bottom:14px;background:#0c0a09;border:1px solid #292524;border-radius:8px;color:#a8a29e;font-size:11px;line-height:1.55}#wc2-pregnancy-settings-265 .wc2pb-section{margin-top:14px;padding:12px;background:#0c0a09aa;border:1px solid #292524;border-radius:9px}#wc2-pregnancy-settings-265 h3{margin:0 0 9px;color:#f5f5f4;font-size:13px;font-weight:800}
      #wc2-pregnancy-settings-265 .wc2pb-setting{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:8px 0;border-bottom:1px solid #292524}#wc2-pregnancy-settings-265 .wc2pb-setting:last-child{border-bottom:0}#wc2-pregnancy-settings-265 .wc2pb-setting label{font-size:12px;color:#d6d3d1}#wc2-pregnancy-settings-265 .wc2pb-setting small{display:block;margin-top:2px;color:#78716c;font-size:10px}#wc2-pregnancy-settings-265 select,#wc2-pregnancy-settings-265 input{background:#292524;color:#fff;border:1px solid #57534e;border-radius:7px;padding:6px 8px}#wc2-pregnancy-settings-265 [data-wc2pb-chance]{width:84px;text-align:right}#wc2-pregnancy-settings-265 [data-wc2pb-adoption-min],#wc2-pregnancy-settings-265 [data-wc2pb-adoption-max],#wc2-pregnancy-settings-265 [data-wc2pb-adoption-fixed-value]{width:76px;text-align:right}#wc2-pregnancy-settings-265 [data-wc2pb-patron-alerts]{width:18px;height:18px;accent-color:#b91c1c;cursor:pointer}
      #wc2-pregnancy-settings-265 [hidden]{display:none!important}
      #wc2-pregnancy-settings-265 .wc2pb-list{display:flex;flex-direction:column;gap:6px}#wc2-pregnancy-settings-265 .wc2pb-entry{display:grid;grid-template-columns:auto 1fr auto;gap:8px;padding:7px 8px;background:#1c1917;border:1px solid #292524;border-radius:7px;font-size:11px}#wc2-pregnancy-settings-265 .wc2pb-entry .kind{color:#f9a8d4;font-weight:800}#wc2-pregnancy-settings-265 .wc2pb-entry .day{color:#78716c}#wc2-pregnancy-settings-265 .wc2pb-empty{color:#57534e;font-size:11px;font-style:italic}#wc2-pregnancy-settings-265 .wc2pb-done{width:100%;margin-top:16px;padding:9px 12px;background:#b45309;color:#fff;border-radius:8px;font-size:13px;font-weight:800}#wc2-pregnancy-settings-265 .wc2pb-done:hover{background:#d97706}
      @media(max-width:560px){#wc2-pregnancy-settings-265{padding:8px}#wc2-pregnancy-settings-265 .wc2pb-card{padding:14px}#wc2-pregnancy-settings-265 .wc2pb-setting{align-items:flex-start}#wc2-pregnancy-settings-265 .wc2pb-entry{grid-template-columns:auto 1fr}.wc2pb-entry .day{grid-column:2}}
    `;
    style.textContent+=`
      .wc2pb-visual{container-type:inline-size;margin:0 0 12px;padding:0 0 10px;border-bottom:1px solid #44403c;color:#a8a29e;max-width:100%}
      .wc2pb-visual-shell{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,195px) minmax(0,1fr);gap:7px;align-items:center}
      .wc2pb-visual-image{position:relative;aspect-ratio:1;background:#000;border-radius:8px;overflow:hidden;width:100%}
      .wc2pb-visual-image img{display:block;width:100%;height:100%;object-fit:contain}
      .wc2pb-visual-image img[data-layer="1"]{position:absolute;inset:0;opacity:0}
      .wc2pb-visual-image[data-animated="1"]:not([data-failed]) img[data-layer="0"]{animation:wc2pb-fertilization-a .24s step-end infinite}
      .wc2pb-visual-image[data-animated="1"]:not([data-failed]) img[data-layer="1"]{animation:wc2pb-fertilization-b .24s step-end infinite}
      .wc2pb-visual-owner{display:block;box-sizing:border-box;min-width:0;max-width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:10px;line-height:1.4;padding:3px 5px;border-radius:8px;border:1px solid #57534e;background:#1c1917}
      .wc2pb-visual-owner.mother{justify-self:end;color:#fbcfe8;border-color:#9d174d}
      .wc2pb-visual-owner.sperm{color:#cffafe;border-color:#155e75}
      .wc2pb-visual-owners{display:flex;flex-direction:column;gap:4px;min-width:0}
      .wc2pb-visual figcaption{text-align:center;font-size:11px;line-height:1.6;margin-top:7px}
      .wc2pb-visual strong,.wc2pb-visual figcaption>span{display:block}.wc2pb-visual strong{font-size:13px;color:#f9a8d4}
      #wc2-pregnancy-settings-265 [data-wc2pb-early-days],#wc2-pregnancy-settings-265 [data-wc2pb-middle-days],#wc2-pregnancy-settings-265 [data-wc2pb-late-days]{box-sizing:border-box;width:70px;text-align:right}
      #wc2-pregnancy-settings-265 [data-wc2pb-duration-note]{margin:10px 0 0}
      @keyframes wc2pb-fertilization-a{0%,49.999%,100%{opacity:1}50%,99.999%{opacity:0}}
      @keyframes wc2pb-fertilization-b{0%,49.999%,100%{opacity:0}50%,99.999%{opacity:1}}
      @media(max-width:560px){.wc2pb-visual-shell{grid-template-columns:minmax(0,1fr) minmax(0,150px) minmax(0,1fr);gap:5px}.wc2pb-visual-owner{font-size:9px}}
      @container(max-width:359px){.wc2pb-visual-shell{grid-template-columns:minmax(0,1fr) minmax(0,138px) minmax(0,1fr);gap:5px}.wc2pb-visual-owner{font-size:9px;padding:3px 4px}}
      @container(max-width:239px){.wc2pb-visual-shell{display:flex;flex-direction:column}.wc2pb-visual-image{width:min(100%,150px)}.wc2pb-visual-owner.mother{align-self:center}.wc2pb-visual-owners{flex-direction:row;flex-wrap:wrap;justify-content:center}}
      @media(prefers-reduced-motion:reduce){.wc2pb-visual-image img{animation:none!important}.wc2pb-visual-image img[data-layer="0"]{opacity:1!important}.wc2pb-visual-image img[data-layer="1"]{opacity:0!important}}
    `;
    document.head.appendChild(style);
  }

  function openSettings(){
    ensureStyles();
    let modal=document.getElementById('wc2-pregnancy-settings-265');
    if(!modal){
      modal=document.createElement('div');
      modal.id='wc2-pregnancy-settings-265';
      modal.innerHTML=`<div class="wc2pb-card" role="dialog" aria-modal="true" aria-labelledby="wc2pb-title"><div class="wc2pb-head"><div><h2 id="wc2pb-title">임신 / 출산모드 설정</h2><div class="wc2pb-version">Pregnancy 3.4.0 · 2026-10-25</div></div><button type="button" class="wc2pb-close" aria-label="닫기">✕</button></div><div class="wc2pb-note" data-wc2pb-cycle-note></div><section class="wc2pb-section"><h3>모드 설정</h3><div class="wc2pb-setting"><label>모드 적용<small>OFF 동안 임신·출산 진행과 체력 효과가 일시정지됩니다.</small></label><select data-wc2pb-enabled><option value="on">ON</option><option value="off">OFF</option></select></div><div class="wc2pb-setting"><label>생리 주기<small>7일 단위로 35일까지 선택합니다.</small></label><select data-wc2pb-cycle-length><option value="7">7일</option><option value="14">14일</option><option value="21">21일</option><option value="28">28일</option><option value="35">35일</option></select></div><div class="wc2pb-setting"><label>기본 가중치<small>최종 확률 = 기본 가중치 + 자궁 내 정자량(1M당 1%), 최대 100%. 1회 질내사정당 정자량은 1~50M입니다.</small></label><div><input data-wc2pb-chance type="text" inputmode="numeric" pattern="[0-9]*" maxlength="3" autocomplete="off"><span> %</span></div></div><div class="wc2pb-setting"><label>사정 시 시간 정지<small>손님이 사정하면 남은 Skip을 멈춥니다.</small></label><select data-wc2pb-pause-climax><option value="on">ON</option><option value="off">OFF</option></select></div><div class="wc2pb-setting"><label>성행위 시작 시 시간 정지<small>손으로 해주기·구강성교·삽입이 시작되면 남은 Skip을 멈춥니다.</small></label><select data-wc2pb-pause-act-start><option value="on">ON</option><option value="off">OFF</option></select></div><div class="wc2pb-setting"><label for="wc2pb-patron-alerts">성행위 시작·사정 이벤트<small>게임의 빨간 테두리 이벤트 창을 표시합니다. 초상화는 바꾸지 않습니다.</small></label><input id="wc2pb-patron-alerts" data-wc2pb-patron-alerts type="checkbox"></div></section><section class="wc2pb-section"><h3>출산 후 아이 처치</h3><div class="wc2pb-setting"><label>아이 처치 상의 이벤트<small>OFF면 현재 방식대로 모든 아이를 부모님께 맡깁니다. 이미 시작된 상의는 유지됩니다.</small></label><select data-wc2pb-child-disposition><option value="on">ON</option><option value="off">OFF</option></select></div><div class="wc2pb-setting"><label>입양 사례금 방식<small>입양이 확정될 때 한 번만 지급됩니다.</small></label><select data-wc2pb-adoption-fee-mode><option value="random">랜덤 구간</option><option value="fixed">고정 금액</option></select></div><div class="wc2pb-setting" data-wc2pb-adoption-random><label>랜덤 구간<small>기본값 50~100골드. 최소·최대가 뒤바뀌어도 작은 값부터 적용합니다.</small></label><div><input data-wc2pb-adoption-min type="number" min="0" max="9999" step="1"><span> ~ </span><input data-wc2pb-adoption-max type="number" min="0" max="9999" step="1"><span> G</span></div></div><div class="wc2pb-setting" data-wc2pb-adoption-fixed><label>고정 금액<small>고정 방식일 때 지급할 사례금입니다.</small></label><div><input data-wc2pb-adoption-fixed-value type="number" min="0" max="9999" step="1"><span> G</span></div></div></section><section class="wc2pb-section"><h3>현재 자궁 상태</h3><div data-wc2pb-current></div></section><section class="wc2pb-section"><h3>보관 중인 정액</h3><div class="wc2pb-list" data-wc2pb-sperm></div></section><section class="wc2pb-section" data-wc2pb-father-disclosure><div class="wc2pb-setting"><label for="wc2pb-actual-father">실제 친부 공개 여부<small>체크 해제: 각자의 추정 표시 · 체크: 추정과 실제 친부 함께 표시</small></label><input id="wc2pb-actual-father" data-wc2pb-actual-father type="checkbox" style="width:18px;height:18px;accent-color:#b91c1c;cursor:pointer"></div></section><section class="wc2pb-section"><h3>출산 Log</h3><div class="wc2pb-list" data-wc2pb-log></div></section><button type="button" class="wc2pb-done">닫기</button></div>`;
      modal.addEventListener('click',event=>{if(event.target===modal)closeSettings()});
      Pregnancy_기간설정화면만들기(modal);
      modal.querySelector('.wc2pb-close').addEventListener('click',closeSettings);
      modal.querySelector('.wc2pb-done').addEventListener('click',closeSettings);
      modal.querySelector('[data-wc2pb-enabled]').addEventListener('change',event=>setEnabled(event.target.value==='on'));
      modal.querySelector('[data-wc2pb-cycle-length]').addEventListener('change',event=>Pregnancy_주기길이설정하기(event.target.value));
      modal.querySelector('[data-wc2pb-pause-climax]').addEventListener('change',event=>setPauseOnPatronClimax(event.target.value==='on'));
      modal.querySelector('[data-wc2pb-pause-act-start]').addEventListener('change',event=>setPauseOnPatronActStart(event.target.value==='on'));
      modal.querySelector('[data-wc2pb-patron-alerts]').addEventListener('change',event=>setShowPatronEventAlerts(event.target.checked));
      modal.querySelector('[data-wc2pb-actual-father]').addEventListener('change',event=>Pregnancy_실제친부공개설정하기(event.target.checked));
      modal.querySelector('[data-wc2pb-child-disposition]').addEventListener('change',event=>Pregnancy_아이처치상의설정하기(event.target.value==='on'));
      modal.querySelector('[data-wc2pb-adoption-fee-mode]').addEventListener('change',event=>Pregnancy_입양비방식설정하기(event.target.value));
      for(const [selector,key] of [['[data-wc2pb-adoption-fixed-value]','fixed'],['[data-wc2pb-adoption-min]','min'],['[data-wc2pb-adoption-max]','max']]){
        modal.querySelector(selector).addEventListener('change',event=>Pregnancy_입양비금액설정하기(key,event.target.value));
      }
      const chanceInput=modal.querySelector('[data-wc2pb-chance]');
      chanceInput.addEventListener('input',event=>{
        const cleaned=event.target.value.replace(/[^0-9]/g,'').slice(0,3);
        if(event.target.value!==cleaned)event.target.value=cleaned;
        if(cleaned!=='')setChance(cleaned);
      });
      chanceInput.addEventListener('blur',event=>{
        if(event.target.value==='')event.target.value=String(options.conceptionChance);
        else{
          setChance(event.target.value);
          event.target.value=String(options.conceptionChance);
        }
      });
      document.body.appendChild(modal);
    }
    renderSettings();
  }

  function closeSettings(){document.getElementById('wc2-pregnancy-settings-265')?.remove()}

  function renderSettings(){
    const modal=document.getElementById('wc2-pregnancy-settings-265');
    if(!modal)return;
    const state=getCurrentState();
    const data=getStoredData(state);
    const desire=state?Pregnancy_임신의향계산하기(state):null;
    const renderKey=JSON.stringify([options,ruleProvider?.getOptions?.(),state?.day,data,desire]);
    if(modal.dataset.wc2PregRenderKey===renderKey)return;
    modal.dataset.wc2PregRenderKey=renderKey;
    ruleProvider?.renderSettings?.(modal);
    const gestation=Pregnancy_임신일정만들기();
    for(const stage of ['early','middle','late'])modal.querySelector(`[data-wc2pb-${stage}-days]`).value=String(options[`${stage}Days`]);
    modal.querySelector('[data-wc2pb-duration-note]').textContent=`임신 기간 총 ${gestation.totalDays}일 (수정일 1일 + 초기 ${options.earlyDays}일 + 중기 ${options.middleDays}일 + 후기 ${options.lateDays}일 + 출산일 1일). 수정일에는 체력 추가 소모가 없습니다. 기간 변경은 현재 임신에도 적용되며, 예정일이 지나면 다음 아침에 출산합니다.`;
    const enabled=modal.querySelector('[data-wc2pb-enabled]');
    modal.querySelector('[data-wc2pb-cycle-length]').value=String(options.cycleLength);
    modal.querySelector('[data-wc2pb-cycle-note]').textContent=`생리 주기는 ${options.cycleLength}일입니다 (${Pregnancy_주기단계만들기(options.cycleLength,true,state).map(phase=>`${phase.label} ${phase.duration}일`).join(' · ')}). 배란기·황체기 아침마다 보관 중인 정액이 있으면 임신을 판정합니다. 정자는 사정일 포함 3일간 생존하며 D+3 아침에 소멸합니다. 약은 게임용 주기 변경 기능으로, 선택한 다음 날부터 적용됩니다.`;
    const chance=modal.querySelector('[data-wc2pb-chance]');
    const pauseClimax=modal.querySelector('[data-wc2pb-pause-climax]');
    const pauseActStart=modal.querySelector('[data-wc2pb-pause-act-start]');
    const patronAlerts=modal.querySelector('[data-wc2pb-patron-alerts]');
    const childDisposition=modal.querySelector('[data-wc2pb-child-disposition]');
    const adoptionFeeMode=modal.querySelector('[data-wc2pb-adoption-fee-mode]');
    enabled.value=options.enabled?'on':'off';
    pauseClimax.value=options.pauseOnPatronClimax?'on':'off';
    pauseActStart.value=options.pauseOnPatronActStart?'on':'off';
    patronAlerts.checked=options.showPatronEventAlerts;
    childDisposition.value=options.childDispositionConsultation?'on':'off';
    adoptionFeeMode.value=options.adoptionFeeMode;
    modal.querySelector('[data-wc2pb-adoption-min]').value=String(options.adoptionFeeMin);
    modal.querySelector('[data-wc2pb-adoption-max]').value=String(options.adoptionFeeMax);
    modal.querySelector('[data-wc2pb-adoption-fixed-value]').value=String(options.adoptionFeeFixed);
    modal.querySelector('[data-wc2pb-adoption-random]').hidden=options.adoptionFeeMode!=='random';
    modal.querySelector('[data-wc2pb-adoption-fixed]').hidden=options.adoptionFeeMode!=='fixed';
    modal.querySelector('[data-wc2pb-actual-father]').checked=options.showActualFather;
    if(document.activeElement!==chance)chance.value=String(options.conceptionChance);

    const current=modal.querySelector('[data-wc2pb-current]');
    current.replaceChildren();
    Pregnancy_생식그림표시하기(current,Pregnancy_시각상태만들기(state,data));
    addInfoRow(current,'모드 상태',options.enabled?'ON':'OFF',options.enabled?'pregnant':'muted');
    if(state){
      addInfoRow(current,'생리 / 임신 상태',uterusLabel(data,state.day),data.pregnancy?'pregnant':'');
      addInfoRow(current,'자궁 내 정자량 (단위 : 백만마리)',String(spermTotal(data)),'sperm');
      addInfoRow(current,'질 사정 누적',`${data.ejaculationCounts.vaginal}회`,'');
      addInfoRow(current,'항문 사정 누적',`${data.ejaculationCounts.anal}회`,'');
      if(!data.pregnancy)addInfoRow(current,'현재 임신 판정 확률',data.spermDeposits.length?`${conceptionChance(data)}% (배란기·황체기 아침)`:'정자 없음','');
      Pregnancy_약예약표시하기(current,data,state);
      Pregnancy_임신의향표시하기(current,desire);
      if(data.pregnancy){
        Pregnancy_친부정보표시하기(current,data.pregnancy);
        addInfoRow(current,'출산 예정',`${Pregnancy_출산예정일구하기(data.pregnancy)}일차 아침`,'');
      }
    }else addInfoRow(current,'상태','게임 시작 전','muted');

    const sperm=modal.querySelector('[data-wc2pb-sperm]');
    sperm.replaceChildren();
    if(!state||data.spermDeposits.length===0){
      const empty=document.createElement('div');empty.className='wc2pb-empty';empty.textContent='보관 중인 정액이 없습니다.';sperm.appendChild(empty);
    }else{
      [...data.spermDeposits].sort((a,b)=>b.slot-a.slot).forEach(item=>{
        const entry=document.createElement('div');entry.className='wc2pb-entry';
        const kind=document.createElement('span');kind.className='kind';kind.textContent=`${item.amount} 백만마리`;
        const who=document.createElement('span');who.textContent=item.sourceName;
        const when=document.createElement('span');when.className='day';when.textContent=`${item.day}일차 · D+${Math.max(0,(state.day||1)-item.day)}`;
        entry.append(kind,who,when);sperm.appendChild(entry);
      });
    }

    const log=modal.querySelector('[data-wc2pb-log]');
    log.replaceChildren();
    if(data.birthLog.length===0){
      const empty=document.createElement('div');empty.className='wc2pb-empty';empty.textContent='아직 출산 기록이 없습니다.';log.appendChild(empty);
    }else{
      [...data.birthLog].reverse().forEach(item=>{
        const entry=document.createElement('div');entry.className='wc2pb-entry';
        const kind=document.createElement('span');kind.className='kind';kind.textContent='출산 · '+item.children.length+'명';
        const display=Pregnancy_친부표시만들기(item);
        const text=document.createElement('span');text.style.whiteSpace='pre-line';
        const disposition=item.childDisposition,dispositionText=disposition
          ?disposition.status==='adopted'?`\n아이 처치: 입양 · 사례금 ${disposition.adoptionFee}G`
            :disposition.status==='pending'?"\n아이 처치: 당신의 답변 대기":'\n아이 처치: 부모님께 맡김'
          :'\n아이 처치: 부모님께 맡김 (구버전 기록)';
        text.textContent=`${item.motherName}\n추정 · 그녀: ${display.wife}\n추정 · 당신: ${display.husband}${display.actual?`\n실제: ${display.actual}`:''}${dispositionText}${Pregnancy_반응문장만들기(item.reaction)}${Pregnancy_아이처치기록문장만들기(disposition)}`;
        const day=document.createElement('span');day.className='day';day.textContent=`${item.day}일차`;
        entry.append(kind,text,day);log.appendChild(entry);
      });
    }
  }

  // Pure, caller-owned actor processing. Never writes to the real store or changes the selected main actor.
  function Pregnancy_인물API(){
    function character(state){return getWife(state);}
    function scoped(state,data){
      if(!character(state))throw new TypeError('Pregnancy actor state requires characters[primaryCharacterId]');
      return Pregnancy_인물상태만들기(state,data);
    }
    function effects(state,data,notices,modeLogs,childAlerts,morning){
      let wife=clone(character(state));
      if(morning.birthEnergy!=null)wife={...wife,birthLeaveDay:state.day,stats:{...wife.stats,energy:morning.birthEnergy}};
      for(const notice of notices)if(notice.reaction)wife={...wife,lastResponse:notice.reaction.dialogue,lastResponseSlot:state.slot,
        lastResponseType:notice.reaction.condition.endsWith('_welcomed')?'accept':'hesitant',innerThought:notice.reaction.innerThought,innerThoughtType:'conflicted',innerThoughtSlot:state.slot};
      const alerts=[...notices.filter(n=>n.reaction).map(n=>Pregnancy_반응알림만들기(state,n)),...childAlerts];
      const log=[];for(const text of modeLogs){const draft={...state,log:[]};appendModeLog(draft,text);log.push(...draft.log);}
      return{data,character:wife,alerts,log,gold:morning.adoptionGold||0};
    }
    function advance(state,raw,prior=null){
      const data=normalizeData(raw,state.day,state),notices=[],logs=[],childAlerts=[];
      const empty={birthEnergy:null,adoptionGold:0};
      if(!options.enabled){if(data.pausedAtDay==null)data.pausedAtDay=state.day;return effects(state,data,notices,logs,childAlerts,empty);}
      if(data.pausedAtDay!=null){const gap=Math.max(0,state.day-data.pausedAtDay);
        Pregnancy_일정미루기(data,gap);data.pausedAtDay=null;data.lastMorningDay=state.day;}
      const view=scoped(state,data);ruleProvider?.prepareData?.(data,view);
      Pregnancy_약예약적용하기(data,view,logs);
      const morning=processMorning(data,view,notices,logs,childAlerts);
      const result=effects(view,data,notices,logs,childAlerts,morning);
      if(prior&&prior.day===state.day&&state.slot>=prior.slot&&data.pregnancy&&Pregnancy_임신단계만들기(data,state.day)?.id!=='fertilization'){
        const a=character(prior)?.stats?.energy,b=character(state)?.stats?.energy;
        if(Number.isFinite(a)&&Number.isFinite(b)&&b<a&&morning.birthEnergy==null)result.character.stats.energy=Math.max(0,b-(a-b)*.5);
      }
      return result;
    }
    function capture(before,after,raw,context={}){
      const data=normalizeData(raw,after.day,after);
      const result=captureData(data,after,before,{motherKnows:true,playerKnows:false,...context});
      return effects(scoped(after,data),data,result.notices,result.logs,[],{});
    }
    // Low-level calls mutate caller-owned data only. They do not commit or display their results.
    function captureData(data,state,prior=null,context={}){
      const view=scoped(state,data),start=data.spermDeposits.length,seen=data.seenFinishes.length,notices=[],logs=[];
      if(!options.enabled)return{changed:false,notices,logs};
      captureFinishes(data,view,prior,context);
      for(const item of data.spermDeposits.slice(start)){
        if(typeof context.motherKnows==='boolean')item.wifeKnows=context.motherKnows;
        if(typeof context.playerKnows==='boolean')item.husbandKnows=context.playerKnows;
      }
      const prepared=ruleProvider?.prepareData?.(data,view)||false;
      if(ruleProvider?.immediateConception&&data.spermDeposits.length>start)Pregnancy_수정판정하기(data,view,notices,logs);
      return{changed:prepared||seen!==data.seenFinishes.length||start!==data.spermDeposits.length,notices,logs};
    }
    function morning(data,state,notices=[],logs=[],childAlerts=[]){
      const view=scoped(state,data);
      if(!options.enabled)return{birthEnergy:null,adoptionGold:0,changed:false};
      const prepared=ruleProvider?.prepareData?.(data,view)||false;
      const result=processMorning(data,view,notices,logs,childAlerts);
      return{...result,changed:result.changed||prepared};
    }
    function applyMedicine(data,state,logs=[]){
      const view=scoped(state,data);
      if(!options.enabled)return false;
      const prepared=ruleProvider?.prepareData?.(data,view)||false;
      return Pregnancy_약예약적용하기(data,view,logs)||prepared;
    }
    function visual(state,raw){const data=normalizeData(raw,state.day,state);return Pregnancy_시각상태만들기(scoped(state,data),data);}
    function resolveChild(state,raw,recordId,choice){
      const data=normalizeData(raw,state.day,state),record=data.birthLog.find(x=>x.id===recordId);
      if(!record||record.childDisposition?.status!=='pending')return null;
      const alert=Pregnancy_아이처치알림만들기(record.childDisposition,record.id,record.motherName);
      const view={...scoped(state,data),pendingEvent:{type:'alert',alert,choices:alert.choices},alertQueue:[],log:[]};
      const result=Pregnancy_아이처치답변처리하기(s=>({...s,pendingEvent:undefined}),view,{type:'resolve_event',choiceId:choice});
      if(!result)return null;
      return{data:result[STATE_KEY],character:character(result),gold:(result.economy?.gold||0)-(state.economy?.gold||0),alerts:result.alertQueue||[],log:result.log||[]};
    }
    return{version:1,stateKey:STATE_KEY,newData,normalize:normalizeData,normalizeData,advance,capture,visual,resolveChild,
      captureFinishes:captureData,processMorning:morning,applyMedicine,shiftSchedule:Pregnancy_일정미루기,
      cycle:(day,data)=>Pregnancy_주기정보만들기(day,data),stage:(data,day)=>Pregnancy_임신단계만들기(data,day),
      renderStatus,
      isAware:state=>!Pregnancy_Wml.fn('PregnancyConversationBlockReason')(state),
      subscribeOptions(handler){actorOptionListeners.add(handler);return()=>actorOptionListeners.delete(handler);},
      ruleOptions:()=>({...options,...ruleProvider?.getOptions?.()}),
      medicine(raw,state,phase){if(!options.enabled||!Pregnancy_약단계목록().includes(phase))return null;const data=normalizeData(raw,state.day,state);if(data.pregnancy)return null;data.pendingCycleMedicine={phase,startDay:state.day+1};return data;},
      renderVisual:Pregnancy_생식그림표시하기};
  }

  function init(){
    if(api||!globalThis.__WAYWARD_ADDON_API__)return false;
    api=globalThis.__WAYWARD_ADDON_API__;
    if(!api.ue?.getState||!api.ue?.subscribe||!api.g)return false;
    ensureStyles();
    installPregnancyWaitGuard();
    Pregnancy_Wml.hook('reduceGameAction',{around:Pregnancy_대화행동처리하기});
    Pregnancy_Wml.hook('PregnancyWorkTick',{around(next,state,...args){
      return getWife(state)?.birthLeaveDay===state.day?state:next(state,...args);
    }});
    Pregnancy_Wml.hook('PregnancyStatusPanel',{after(result){
      // Read through the native render selector so projected NPC panels retain their own identity.
      const id=Pregnancy_Wml.fn('store')(root=>root.state.primaryCharacterId);
      if(!result||!id)return result;
      return Pregnancy_Wml.fn('jsx').jsx('div',{'data-wc2-preg-main-panel':String(id),children:result});
    }});
    Pregnancy_Wml.ui.addButton({label:'임신/출산',title:'임신 / 출산모드 설정',onClick:openSettings});
    Pregnancy_Wml.onBack(()=>{
      if(!document.getElementById('wc2-pregnancy-settings-265'))return false;
      closeSettings();return true;
    });
    previousState=getCurrentState();
    unsubscribe=api.ue.subscribe(onStoreChange);
    const observer=new MutationObserver(scheduleUI);
    observer.observe(document.body,{childList:true,subtree:true,attributes:true,
      attributeFilter:['data-npc-status-panel','data-npc-character-sheet','data-pregnancy-status-auto','data-character-id','data-wc2-preg-main-panel']});
    window.addEventListener('keydown',event=>{
      if(event.key==='Escape'&&document.getElementById('wc2-pregnancy-settings-265')){
        event.preventDefault();
        event.stopImmediatePropagation();
        closeSettings();
      }
    },true);
    const actorApi=Pregnancy_인물API();
    globalThis.__wc2PregnancyBirth265={
      actorApi,
      // Version 1 aliases share actorApi's implementation; no separate NPC calculation engine.
      npcApiVersion:actorApi.version,
      newData:actorApi.newData,normalizeData:actorApi.normalizeData,captureFinishes:actorApi.captureFinishes,
      processMorning:actorApi.processMorning,applyMedicine:actorApi.applyMedicine,shiftSchedule:actorApi.shiftSchedule,
      cycle:actorApi.cycle,stage:actorApi.stage,renderStatus:actorApi.renderStatus,
      shouldInjectStatus,registerStatusFilter,
      rollChildCount,normalizeChildCount,birthChildren,
      openSettings,
      getOptions:()=>({...options}),
      getData:(state)=>getStoredData(state??getCurrentState()),
      getEjaculationCounts:(state)=>({...getStoredData(state??getCurrentState()).ejaculationCounts}),
      rulesApiVersion:1,
      registerRules:(owner,provider)=>{
        if(!owner||!provider||typeof provider!=='object')throw new Error('Pregnancy rules require an owner and provider');
        if(ruleProvider)throw new Error('Pregnancy rules are already registered');
        ruleProvider=provider;
        onStoreChange();renderSettings();scheduleUI();
        return {owner,refresh:()=>{onStoreChange();renderSettings();scheduleUI()}};
      },
      getConceptionChance:data=>conceptionChance(data??getStoredData(getCurrentState())),
      setShowActualFather:Pregnancy_실제친부공개설정하기,
      getFatherDisplay:record=>Pregnancy_친부표시만들기(record??getStoredData(getCurrentState()).pregnancy),
      getPregnancyDesire:(partnerId,partnerName)=>Pregnancy_임신의향계산하기(getCurrentState(),partnerId,partnerName),
      getReactionCatalog:()=>clone(Pregnancy_반응문구목록),
      planChildDisposition:input=>clone(Pregnancy_아이처치계획만들기(input)),
      resolveChildDisposition:(plan,choice,day)=>clone(Pregnancy_아이처치완료하기(plan,choice,day)),
      makeChildDispositionAlert:(plan,recordId,motherName,source,workerId)=>Pregnancy_아이처치알림만들기(plan,recordId,motherName,source,workerId),
      getChildDispositionHistoryText:plan=>Pregnancy_아이처치기록문장만들기(plan),
      setCycleLength:Pregnancy_주기길이설정하기,
      getCycleInfo:(day,data)=>Pregnancy_주기정보만들기(day??getCurrentState()?.day,data??getStoredData(getCurrentState()),!data||!ruleProvider||!!ruleProvider.acceptExternalData?.(data)),
      getGestationPlan:()=>clone(Pregnancy_임신일정만들기()),
      getPregnancyStage:(day,data)=>Pregnancy_임신단계만들기(data??getStoredData(getCurrentState()),day??getCurrentState()?.day,!data||!ruleProvider||!!ruleProvider.acceptExternalData?.(data)),
      getVisualState:()=>Pregnancy_시각상태만들기(getCurrentState(),getStoredData(getCurrentState())),
      setGestationDuration:Pregnancy_임신기간설정하기,
      setEnabled,
      setChance,
      setChildDispositionConsultation:Pregnancy_아이처치상의설정하기,
      setAdoptionFeeMode:Pregnancy_입양비방식설정하기,
      setAdoptionFee:(key,value)=>Pregnancy_입양비금액설정하기(key,value),
      setPauseOnPatronClimax,
      setPauseOnPatronActStart,
      setShowPatronEventAlerts
    };
    Pregnancy_Wml.provide(globalThis.__wc2PregnancyBirth265);
    onStoreChange();
    scheduleUI();
    return true;
  }

  if(!init()){
    let attempts=0;
    const timer=setInterval(()=>{
      attempts++;
      if(init()||attempts>240)clearInterval(timer);
    },250);
  }
})();
/* --- End pregnancy / birth mode --- */

  },
});
