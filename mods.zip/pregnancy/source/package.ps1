﻿# Run from the game folder. -ModDirectory may select another authorized mod folder.
# Version is numeric; game target is 2026-11-01; ZIP contains the stable mod ID folder.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$releaseRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$releaseSource = Get-Content -LiteralPath (Join-Path $releaseRoot 'mod.js') -Raw -Encoding UTF8
$releaseDefinition = $releaseSource.Substring($releaseSource.IndexOf('WML.define'))
$releaseId = [regex]::Match($releaseDefinition, 'id\s*:\s*[\x27\x22]([^\x27\x22]+)').Groups[1].Value
$releaseVersion = [regex]::Match($releaseDefinition, 'version\s*:\s*[\x27\x22]([^\x27\x22]+)').Groups[1].Value
if ($releaseId -ne (Split-Path $releaseRoot -Leaf) -or $releaseVersion -notmatch '^\d+\.\d+\.\d+$') { throw 'ID/folder or numeric version mismatch' }
$releaseZip = Join-Path $releaseRoot ($releaseId + '-' + $releaseVersion + '-20261101.zip')
$releaseFiles = @('README.md', 'assets/README.md', 'assets/development-1-fertilization-entry-A.png', 'assets/development-1-fertilization-entry-B.png', 'assets/development-2-two-cell.png', 'assets/development-3-thirty-cell.png', 'assets/development-4-embryo-uterine-lining.png', 'assets/development-5-fetus-uterine-lining.png', 'assets/ovum-surrounded-level-1.png', 'assets/ovum-surrounded-level-2.png', 'assets/ovum-surrounded-level-3.png', 'assets/ovum-surrounded-level-4.png', 'assets/ovum-surrounded-level-5.png', 'assets/ovum-unfertilized-count-000.png', 'assets/sperm-only-level-1-count-000.png', 'assets/sperm-only-level-2-count-075.png', 'assets/sperm-only-level-3-count-150.png', 'assets/sperm-only-level-4-count-225.png', 'assets/sperm-only-level-5-count-300.png', 'assets/thirty-cell-with-sperm-field-000.png', 'assets/thirty-cell-with-sperm-field-075.png', 'assets/thirty-cell-with-sperm-field-150.png', 'assets/thirty-cell-with-sperm-field-225.png', 'assets/thirty-cell-with-sperm-field-300.png', 'assets/two-cell-with-sperm-field-000.png', 'assets/two-cell-with-sperm-field-075.png', 'assets/two-cell-with-sperm-field-150.png', 'assets/two-cell-with-sperm-field-225.png', 'assets/two-cell-with-sperm-field-300.png', 'mod.js', 'source/build.mjs', 'source/mod.wml.js', 'source/native-ui.js', 'source/package.ps1')
if (Test-Path -LiteralPath $releaseZip) { throw 'Existing release is preserved. Bump mod version before packaging.' }
$releaseArchive = [IO.Compression.ZipFile]::Open($releaseZip, [IO.Compression.ZipArchiveMode]::Create, [Text.Encoding]::UTF8)
try { foreach ($releaseName in $releaseFiles) {
  $releasePath = [IO.Path]::GetFullPath((Join-Path $releaseRoot $releaseName))
  if (!$releasePath.StartsWith($releaseRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Path outside mod folder' }
  [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($releaseArchive, $releasePath, ($releaseId + '/' + $releaseName), [IO.Compression.CompressionLevel]::Optimal) | Out-Null
}} finally { $releaseArchive.Dispose() }
$releaseArchive = [IO.Compression.ZipFile]::OpenRead($releaseZip)
try {
 if ($releaseArchive.Entries.Count -ne $releaseFiles.Count) { throw 'ZIP count mismatch' }
 foreach ($releaseName in $releaseFiles) {
  $releaseEntry = $releaseArchive.GetEntry($releaseId + '/' + $releaseName)
  if (!$releaseEntry) { throw ('ZIP missing: ' + $releaseName) }
  $releaseInput = $releaseEntry.Open(); $releaseHash = [Security.Cryptography.SHA256]::Create()
  try { $releaseActual = ([BitConverter]::ToString($releaseHash.ComputeHash($releaseInput))).Replace('-', '') } finally { $releaseInput.Dispose(); $releaseHash.Dispose() }
  if ($releaseActual -ne (Get-FileHash -LiteralPath (Join-Path $releaseRoot $releaseName) -Algorithm SHA256).Hash) { throw ('ZIP differs: ' + $releaseName) }
 }
} finally { $releaseArchive.Dispose() }
Write-Output ('VERIFIED ' + $releaseZip)
