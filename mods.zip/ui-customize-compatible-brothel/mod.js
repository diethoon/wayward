// UI_customize + Brothel adapter. Original live monitor: Hina_Lover's Brothel.
// Uses the original renderer for independent views; never starts a second simulation.
WML.define({
  id:'ui-customize-compatible-brothel',name:'UI_customize · 창관 실시간 연결',
  author:'Hina_Lover',version:"1.3.2",game:"2026-11-01",lang:'ko',tags:['util'],
  description:'창관 전체 창과 직원별 실시간 카드를 독립적인 고정·Floating 블록으로 연결합니다.',
  requires:['ui-customize','brothel'],requiresVersion:{'ui-customize':'>=1.2.0','brothel':'>=3.13.0'},loadAfter:['ui-customize','brothel'],
  setup(api){
    const layout=WML.use('ui-customize'),b=globalThis.__waywardBrothelPublic;
    if(!layout?.registerBlock||!b?.createLiveCard)throw Error('UI_customize 1.2.0과 Brothel 3.13.0 이상이 필요합니다.');
    const entries=new Map(),host=document.createElement('div');host.hidden=true;host.dataset.uicBrothelCards='';document.body.append(host);
    let whole=null,queued=false,stopped=false;
    const style=document.createElement('style');style.textContent=`[data-uic-brothel-source]{visibility:hidden!important;pointer-events:none!important}.uic-brothel-monitor{display:flex;flex-direction:column;width:100%;height:100%;min-height:0;overflow:auto;font-size:1rem}[data-uic-body]>.ww-live-card{width:100%;height:100%;min-height:0;box-sizing:border-box;font-size:1rem}.uic-brothel-monitor>.ww-live-head{cursor:default}[data-uic-block="brothel:live"] .ww-live-close{display:none}`;document.head.append(style);
    function variables(node){const c=b.getConfig();for(const [name,value]of Object.entries({'--ww-live-image-height':c.liveImageHeight+'px','--ww-live-status-height':c.liveStatusHeight+'px','--ww-live-story-height':c.liveStoryHeight+'px'}))if(node.style.getPropertyValue(name)!==value)node.style.setProperty(name,value);}
    function scan(){
      queued=false;if(stopped)return;const owner=document.querySelector('#ww-live-panel');layout.setBlockAvailable('brothel:live',!!owner&&!owner.hidden);
      if(whole&&(owner!==whole.owner||owner.hidden)){whole.unregister();whole.owner.removeAttribute('data-uic-brothel-source');whole=null;}
      if(owner&&!owner.hidden&&!whole){let node=owner.querySelector('.uic-brothel-monitor');if(!node){node=document.createElement('div');node.className='uic-brothel-monitor';node.append(owner.querySelector('.ww-live-head'),owner.querySelector('.ww-live-grid'));owner.append(node);const native=owner.querySelector;owner.querySelector=function(selector){return native.call(this,selector)||node.querySelector(selector);};node.querySelector('.ww-live-head').addEventListener('pointerdown',e=>{if(layout.isPlaced('brothel:live')&&!e.target.closest('button'))e.stopImmediatePropagation();},true);}
        const unregister=layout.registerBlock({id:'brothel:live',node,title:'창관 실시간 · 전체',source:'brothel',dockLabel:'고정',gameFontSize:true,kind:'monitor',onClose(){owner.querySelector('.ww-live-close')?.click();},onClaim(){owner.setAttribute('data-uic-brothel-source','');},onRelease(){owner.removeAttribute('data-uic-brothel-source');}});whole={owner,node,unregister};}
      if(whole)variables(whole.node);
      const actors=b.liveActors(),keep=new Set(actors.map(a=>a.id));
      for(const [id,entry]of entries)if(!keep.has(id)){layout.restore('brothel:card:'+id);entry.unregister();entry.node.remove();entries.delete(id);}
      for(const actor of actors){const key='brothel:card:'+actor.id,title=(actor.id==='wife'?'메인 인물':'창관 직원')+' · '+actor.name;let entry=entries.get(actor.id);
        if(!entry){const node=b.createLiveCard(actor.id);host.append(node);entry={node,title};entries.set(actor.id,entry);entry.unregister=layout.registerBlock({id:key,node,title,source:'brothel',dockLabel:'고정',gameFontSize:true,kind:'card',onClose(){layout.restore(key);},onClaim(){b.updateLiveCard(node,actor.id);}});}
        if(entry.title!==title){entry.title=title;layout.updateBlock(key,{title});}variables(entry.node);if(layout.isPlaced(key))b.updateLiveCard(entry.node,actor.id);
      }
    }
    function schedule(){if(queued||stopped)return;queued=true;requestAnimationFrame(scan);}
    window.addEventListener('brothel-live-change',schedule);const unlayout=layout.subscribe(schedule);api.store.subscribe(schedule);
    api.ui.settings(root=>root.append(api.ui.h('p',{},'UI_customize에서 창관 실시간 전체 또는 직원 이름을 선택해 배치합니다. 개인 창은 전체 표시·그리드 수용 인원과 독립적입니다.'),api.ui.button('창관 설정 열기',()=>b.openSettings()),api.ui.button('UI_customize 열기',()=>layout.openSettings())));
    api.provide({refresh:scan,ids:()=>[...(whole?['brothel:live']:[]),...[...entries.keys()].map(id=>'brothel:card:'+id)]});schedule();
    window.addEventListener('pagehide',()=>{stopped=true;unlayout();window.removeEventListener('brothel-live-change',schedule);},{once:true});
  }
});