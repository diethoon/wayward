// Image Search Customize / attention-image-prompt compatibility by Hina_Lover.
// Original AIP: aaajjaaaadsfa. Parent mod files and saved image preferences are preserved.
WML.define({
  id: 'image-search-customize-compatible-attention-image-prompt',
  name: { ko: '이미지 기준 + AIP', en: 'Image Search Customize · AIP' },
  author: 'Hina_Lover',
  version: '1.0.0', game: '2026-11-01', lang: 'ko',
  tags: ['image', 'util'],
  requires: ['image-search-customize', 'attention-image-prompt'],
  requiresVersion: { 'image-search-customize': '>=1.0.0 <2', 'attention-image-prompt': '>=1.77.0 <2' },
  loadAfter: ['imagestudio-compatible-attention-image-prompt'],
  description: '이미지 기준을 켠 동안 AIP의 중복 이미지 조회·변형·재사용 처리를 우회합니다. AIP 원본은 교체하지 않습니다.',
  symbols: {
    imageLookup: { raw: { '2026-11-01': 'vy' } },
    imageVariantState: { raw: { '2026-11-01': 'NB' } },
    saveImageVariantState: { raw: { '2026-11-01': 'Ip' } },
    currentPortraitImageKey: { raw: { '2026-11-01': 'bee' } },
  },
  setup(api) {
    const search = api.use('image-search-customize');
    if (typeof search?.isEnabled !== 'function') throw Error('이미지 기준 모드를 갱신해 주세요.');
    if (WML.VERSION !== '0.9.5') throw Error('이 호환 모드는 WML 0.9.5의 훅 구조를 지원합니다.');

    // WML 0.9.5 has no public per-owner hook switch. Obtain its diagnostic hook
    // table once, synchronously, and restore the exact developer setting in finally.
    // No AIP source is evaluated, replaced, copied or written by this adapter.
    function readHooks() {
      const key = 'wml.dev', previous = WML.rawGetItem(key);
      try {
        if (previous !== 'true') localStorage.setItem(key, 'true');
        return WML.dev().hooks;
      } finally {
        if (previous === null) localStorage.removeItem(key);
        else localStorage.setItem(key, previous);
      }
    }
    const hooks = readHooks();
    if (!(hooks instanceof Map)) throw Error('WML 이미지 훅 구조를 확인할 수 없습니다.');
    const targets = ['imageLookup', 'imageVariantState', 'saveImageVariantState', 'currentPortraitImageKey', 'imageGenerate'];
    const records = targets.map(name => ({ name, hook: hooks.get(api.sym(name)) }));
    for (const { name, hook } of records) {
      if (!hook || !['before', 'around', 'after'].every(kind => Array.isArray(hook[kind]))
        || hook.replace?.owner === 'attention-image-prompt'
        || !['before', 'around', 'after'].some(kind => hook[kind].some(row => row.owner === 'attention-image-prompt')))
        throw Error('AIP 이미지 훅 구조가 지원 범위와 다릅니다: ' + name);
    }
    const wrapped = new WeakSet(), installed = [];
    function active() { return search.isEnabled() === true; }
    function install() {
      for (const { name, hook } of records) {
        for (const kind of name === 'imageGenerate' ? ['around'] : ['before', 'around', 'after']) {
          for (const entry of hook[kind]) {
            if (entry.owner !== 'attention-image-prompt' || wrapped.has(entry)) continue;
            const original = entry.fn;
            const replacement = function (...args) {
              if (!active()) return original.apply(this, args);
              if (kind === 'before') return undefined;
              if (kind === 'after') return args[0];
              return args[0](...args.slice(1));
            };
            entry.fn = replacement;
            wrapped.add(entry); installed.push({ entry, original, replacement });
          }
        }
      }
    }
    install();
    const stop = api.afterEachSetup(install);
    // Hide AIP's alternate selection controls; prompt/camera editors stay available.
    const style = api.ui.h('style', { 'data-isc-aip-compat': '' },
      'html[data-isc-aip-selection] [data-attention-similar-images],html[data-isc-aip-selection] [data-attention-offline-area]{display:none!important}');
    const sync = () => document.documentElement.toggleAttribute('data-isc-aip-selection', active());
    const changed = () => queueMicrotask(sync);
    document.head.append(style); sync();
    window.addEventListener('change', changed, true);
    api.ui.settings(body => body.replaceChildren(
      api.ui.h('p', {}, active() ? '이미지 기준이 이미지 조회·추첨·표시를 담당합니다.' : '이미지 기준이 꺼져 있어 AIP의 기존 동작을 사용합니다.'),
      api.ui.h('p', {}, 'AIP 원본과 저장 설정은 유지됩니다. ImageStudio를 함께 켜면 AIP 자체의 기존 선택 제한도 적용됩니다.')));
    api.provide({ version: 1, isDelegated: active, hooked: () => installed.length });
    window.addEventListener('pagehide', () => {
      stop(); window.removeEventListener('change', changed, true);
      for (const { entry, original, replacement } of installed) if (entry.fn === replacement) entry.fn = original;
      style.remove(); document.documentElement.removeAttribute('data-isc-aip-selection');
    }, { once: true });
  },
});
