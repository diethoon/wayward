$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$releaseRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$releaseId = Split-Path $releaseRoot -Leaf
$releaseVersion = [regex]::Match((Get-Content -LiteralPath (Join-Path $releaseRoot 'mod.js') -Raw), 'version:\s*[''\"]([^''\"]+)').Groups[1].Value
$releaseZip = Join-Path $releaseRoot ($releaseId + '-' + $releaseVersion + '-20261101.zip')
if (Test-Path -LiteralPath $releaseZip) { throw 'Existing release is preserved. Bump version before packaging.' }
$releaseFiles = @('mod.js','README.md','package.ps1')
foreach ($releaseName in $releaseFiles) {
 if (!(Test-Path -LiteralPath (Join-Path $releaseRoot $releaseName) -PathType Leaf)) { throw ('Missing: ' + $releaseName) }
}
$releaseArchive = [IO.Compression.ZipFile]::Open($releaseZip,[IO.Compression.ZipArchiveMode]::Create)
try {
 foreach ($releaseName in $releaseFiles) {
  [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($releaseArchive,(Join-Path $releaseRoot $releaseName),($releaseId + '/' + $releaseName),[IO.Compression.CompressionLevel]::Optimal) | Out-Null
 }
} finally { $releaseArchive.Dispose() }
$releaseArchive = [IO.Compression.ZipFile]::OpenRead($releaseZip)
try {
 if ($releaseArchive.Entries.Count -ne $releaseFiles.Count) { throw 'ZIP count mismatch' }
 foreach ($releaseName in $releaseFiles) {
  $releaseEntry = $releaseArchive.GetEntry($releaseId + '/' + $releaseName)
  if (!$releaseEntry) { throw ('ZIP missing: ' + $releaseName) }
  $releaseInput = $releaseEntry.Open(); $releaseHash = [Security.Cryptography.SHA256]::Create()
  try { $releaseActual = ([BitConverter]::ToString($releaseHash.ComputeHash($releaseInput))).Replace('-', '') } finally { $releaseInput.Dispose(); $releaseHash.Dispose() }
  if ($releaseActual -ne (Get-FileHash -LiteralPath (Join-Path $releaseRoot $releaseName) -Algorithm SHA256).Hash) { throw ('ZIP differs: ' + $releaseName) }
 }
} finally { $releaseArchive.Dispose() }
Write-Output ('VERIFIED ' + $releaseZip)
