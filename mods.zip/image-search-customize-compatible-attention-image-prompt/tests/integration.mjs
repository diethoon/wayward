// Isolated WML browser tests. GPU/network generation and user profiles are not used.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createRequire, registerHooks } from 'node:module';
import { pathToFileURL, fileURLToPath } from 'node:url';
const req = createRequire(new URL('../../../../MCP/package.json', import.meta.url));
registerHooks({ resolve(s,c,next) { try { return next(s,c); } catch(e) {
  if(e.code === 'ERR_MODULE_NOT_FOUND' && !s.startsWith('.') && !s.includes(':')) return next(pathToFileURL(req.resolve(s)).href,c);
  throw e;
} } });
const p = await import('../../../../MCP/lib/play.mjs');
const own = 'image-search-customize-compatible-attention-image-prompt';
const mobile = process.argv.includes('--mobile');
const all = process.argv.includes('--all');
const modsRoot = fileURLToPath(new URL('../../', import.meta.url));
const listed = [...fs.readFileSync(path.join(modsRoot,'mods.js'),'utf8').matchAll(/^\s*"([^":]+)"/gm)].map(m=>m[1]);
const snapshot = () => Object.fromEntries(['attention-image-prompt','image-search-customize','imagestudio','imagestudio-compatible-attention-image-prompt'].flatMap(id => {
  const walk = dir => fs.readdirSync(dir,{withFileTypes:true}).flatMap(e => e.isDirectory() ? walk(path.join(dir,e.name)) : [path.join(dir,e.name)]);
  return walk(path.join(modsRoot,id)).filter(f=>!f.includes(path.sep+'tests'+path.sep)).map(f=>[path.relative(modsRoot,f),createHash('sha256').update(fs.readFileSync(f)).digest('hex')]);
}));
const before = snapshot(), results = [];
const call = async (id,fn,arg) => {
  const r=await p.playEval({id,timeoutMs:30000,code:'return ('+fn.toString()+')('+JSON.stringify(arg??null)+');'});
  assert.equal(r.pageErrorsSoFar,0); return r.result;
};
try {
 for(const studio of all ? [true] : [false,true]) {
  const id='isc-aip-'+studio;
  const toggles=Object.fromEntries(listed.map(id=>[id,all]));
  Object.assign(toggles,{'attention-image-prompt':true,'imagestudio':studio,'imagestudio-compatible-attention-image-prompt':studio,'addon-compat':studio});
  const start=await p.playStart({id,mods:toggles,devMode:false,viewport:mobile?{width:390,height:844}:{width:1500,height:1000}});
  assert.deepEqual(start.failed,[]);
  const install=await call(id,async own=>{
    const packages={'image-search-customize':'1.0.0',[own]:'1.0.0'};
    const append=Node.prototype.appendChild;
    Node.prototype.appendChild=function(node){if(node.tagName==='SCRIPT'&&Object.keys(packages).some(id=>node.src.endsWith('/'+id+'/mod.js'))){queueMicrotask(()=>node.dispatchEvent(new Event('error')));return node;}return append.call(this,node);};
    try{return await WML.install(await Promise.all(Object.entries(packages).map(async([id,v])=>({path:id+'.zip',blob:await(await fetch('wml/mods/'+id+'/'+id+'-'+v+'-20261101.zip')).blob()}))));}
    finally{Node.prototype.appendChild=append;}
  },own);
  assert.ok(install.every(row=>row.mode==='browser'),JSON.stringify(install));
  const loaded=await p.playReload({id});assert.deepEqual(loaded.failed,[]);assert.ok(loaded.loaded.includes(own));
  const value=await call(id,async ({studio,own})=>{
    const devBefore=WML.rawGetItem('wml.dev');
    localStorage.setItem('wml.dev','true'); const d=WML.dev();
    if(devBefore===null)localStorage.removeItem('wml.dev');else localStorage.setItem('wml.dev',devBefore);
    d.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true,imageBackendMode:'off'});d.store.get().newGame();
    if(studio)await WW_ImageStudioBridge.ready();
    const game=JSON.stringify(d.store.game()), settingsKey='wml.mod.attention-image-prompt';
    const initial=JSON.parse(localStorage.getItem(settingsKey)||'{}');
    const variantKey='iroha__task-idle__outfit-modest__room-taproom__v-0',v1=variantKey.replace('__v-0','__v-1');
    const target='pippa__task-cleaning__outfit-modest__room-taproom__v-0',source=target.replace('outfit-modest','outfit-barmaid_corset');
    const preferences={...initial,unusedPortraitImages:{[variantKey.replace('__v-0','')]:[variantKey]},similarImageChoices:{[target.replace('__v-0','')]:{keys:[source],mode:'selected'}}};
    localStorage.setItem(settingsKey,JSON.stringify(preferences));
    const preserved=localStorage.getItem(settingsKey), rows=[];
    let otherCalls=0;
    const undoOther=d.hook('vy',{after(result){otherCalls++;return Promise.resolve(result).then(value=>value&&{...value,otherHookPreserved:true});}});
    const lookup=d.hooks.get('vy'), nativeLookup=lookup.orig;
    const entry=k=>({talentName:k,imagePath:'diagnostic.webp',imageType:'portrait',source:'server'});
    lookup.orig=entry;
    const fetchOriginal=window.fetch;
    window.fetch=(url,options)=>options?.method==='HEAD'?Promise.resolve(new Response(null,{status:200})):fetchOriginal(url,options);
    const undoBackend=d.hook('imageBackend',{replace:()=>({baseUrl:'',comfyui:false})});
    const undoManifest=d.hook('imageManifest',{replace:async()=>({version:1,entries:{[target]:entry(target)}})});
    const packFunction=studio?WW_ImageStudioBridge.packs:null;
    if(studio)WW_ImageStudioBridge.packs=()=>[{version:1,entries:{[target]:entry(target)}}];
    try {
      for(const enabled of [true,false,true]) {
        WW_ImageStudioMatching.set({...WW_ImageStudioMatching.get(),enabled});WW_ImageStudioMatching.refresh();
        d.fn('Ip')(variantKey,{variants:[variantKey,v1],currentIdx:0});
        const variants=d.fn('NB')(variantKey).variants;
        const found=await d.fn('vy')(target);
        // These are actual AIP hook wrappers and the complete search chain, not copied policies.
        let generation;
        if(enabled){
          const result=await d.fn('xst')({imageKey:target,prompt:'diagnostic prompt',negativePrompt:''});
          generation={key:result?.key,fresh:result?.fresh};
        }
        rows.push({enabled,variants,resolved:found?.talentName,delegated:WML.use(own).isDelegated(),otherHookPreserved:found?.otherHookPreserved,generation});
      }
    } finally {
      lookup.orig=nativeLookup;window.fetch=fetchOriginal;undoBackend();undoManifest();undoOther();if(studio)WW_ImageStudioBridge.packs=packFunction;
    }
    const preferencesUnchanged=localStorage.getItem(settingsKey)===preserved;
    let prompt=null, comparison=null;
    if(studio){
      const selected={},combo=WW_ImageStudioPrompt.combinationSpace(selected).at(0n);
      const item=WW_ImageStudioBridge.fromKey('pippa',target,selected,true,combo)[0];
      prompt={key:item?.talentId,prompt:item?.prompt,parts:item?.ImageStudioParts?.length};
      const aip=WML.use('attention-image-prompt');
      const plan=()=>WW_ImageStudioBridge.fromKey('pippa',target,{},true,WW_ImageStudioPrompt.combinationSpace({}).at(0n))[0];
      const change=patch=>{localStorage.setItem(settingsKey,JSON.stringify({...initial,...patch}));aip.editor.reload();};
      change({sceneBaseOverrides:{'task-cleaning':{positivePrompt:'studio_scene_probe'}}});
      const scene=plan();
      change({sceneBaseOverrides:{},sceneCandidatePools:{'task-cleaning':{edits:[],additions:[{id:'add-1',prompt:'studio_candidate_probe'}],selected:'add-1'}}});
      const candidate=plan();
      const shots=[{id:'probe-a',name:'A',positive:'studio_camera_a',negative:'studio_camera_negative'},{id:'probe-b',name:'B',positive:'studio_camera_b',negative:''}];
      change({sceneBaseOverrides:{},sceneCandidatePools:{},cameraSceneSettings:{'task-cleaning':{shots,selected:['probe-a'],removeTags:''}},cameraImageMetadata:{},cameraPresetRevision:2});
      const single=plan();
      change({sceneBaseOverrides:{},sceneCandidatePools:{},cameraSceneSettings:{'task-cleaning':{shots,selected:['probe-a','probe-b'],removeTags:''}},cameraImageMetadata:{},cameraPresetRevision:2});
      const multi=plan();
      const long={key:'pippa__task-cleaning__outfit-modest__room-taproom__external-'+('x'.repeat(240))+'__v-0',prompt:'quality, diagnostic scene',negativePrompt:'',parts:[]};
      change({shortImageKeys:false,cameraSceneSettings:{}});const longOff=aip.editor.finishPlan(long).key;
      change({shortImageKeys:true,cameraSceneSettings:{}});const longOn=aip.editor.finishPlan(long).key;
      comparison={sceneEdit:scene?.prompt.includes('studio_scene_probe'),selectedCandidate:candidate?.prompt.includes('studio_candidate_probe'),singleCamera:single?.prompt.includes('studio_camera_a'),cameraNegative:single?.negativePrompt.includes('studio_camera_negative'),multiCameraWithoutMetadata:multi?.prompt.includes('studio_camera_a')||multi?.prompt.includes('studio_camera_b'),longKey:{input:long.key.length,output:longOn.length,toggleChanges:longOff!==longOn},axes:WW_ImageStudioPrompt.axes().map(axis=>axis.id)};
    }
    localStorage.setItem(settingsKey,JSON.stringify(initial));if(studio)WML.use('attention-image-prompt').editor.reload();
    const win=WW_ImageStudioMatching.open();
    const checkbox=()=>document.querySelector('[data-match-enabled]');
    if(!checkbox())throw Error('Search toggle absent');
    checkbox().click();await new Promise(r=>setTimeout(r,80));
    const off=!WML.use(own).isDelegated()&&!document.documentElement.hasAttribute('data-isc-aip-selection');
    checkbox().click();await new Promise(r=>setTimeout(r,80));
    const on=WML.use(own).isDelegated()&&document.documentElement.hasAttribute('data-isc-aip-selection');
    const pane=document.querySelector('.wwis-matching').getBoundingClientRect();win.close();
    return {rows,prompt,comparison,preferencesUnchanged,devBefore,devAfter:WML.rawGetItem('wml.dev'),gameUnchanged:JSON.stringify(d.store.game())===game,wrapped:WML.use(own).hooked(),otherCalls,ui:{off,on,width:pane.width,viewport:innerWidth}};
  },{studio,own});
  for(const row of value.rows){
    assert.deepEqual(row.variants,!row.enabled&&!studio?['iroha__task-idle__outfit-modest__room-taproom__v-1']:['iroha__task-idle__outfit-modest__room-taproom__v-0','iroha__task-idle__outfit-modest__room-taproom__v-1']);
    assert.equal(row.resolved,!row.enabled&&!studio?'pippa__task-cleaning__outfit-barmaid_corset__room-taproom__v-0':'pippa__task-cleaning__outfit-modest__room-taproom__v-0');
    assert.equal(row.delegated,row.enabled);
    assert.equal(row.otherHookPreserved,true);
    if(row.enabled)assert.deepEqual(row.generation,{key:'pippa__task-cleaning__outfit-modest__room-taproom__v-0',fresh:false});
  }
  assert.equal(value.preferencesUnchanged,true);assert.equal(value.gameUnchanged,true);assert.equal(value.devBefore,null);assert.equal(value.devAfter,null);
  assert.ok(value.otherCalls>=3);assert.equal(value.ui.off,true);assert.equal(value.ui.on,true);assert.ok(value.ui.width<=value.ui.viewport);
  if(studio)assert.ok(value.prompt?.prompt&&value.prompt.key.startsWith('pippa__'),JSON.stringify(value));
  if(studio){assert.equal(value.comparison.sceneEdit,true);assert.equal(value.comparison.selectedCandidate,true);assert.equal(value.comparison.singleCamera,true);assert.equal(value.comparison.cameraNegative,true);assert.equal(value.comparison.multiCameraWithoutMetadata,false);assert.equal(value.comparison.longKey.toggleChanges,false);}
  const status=await p.playStatus({id});assert.deepEqual(status.pageErrors,[]);
  results.push({studio,loaded:loaded.loaded.length,...value});console.log(JSON.stringify(results.at(-1)));
  await p.playStop({id});
 }
 assert.deepEqual(snapshot(),before,'Parent files changed');
 fs.writeFileSync(new URL('integration-'+(all?'all-':'')+(mobile?'mobile':'pc')+'.json',import.meta.url),JSON.stringify({mobile,all,parentFilesUnchanged:Object.keys(before).length,results},null,2)+'\n');
} finally {await p.shutdown();}
