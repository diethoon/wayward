<!-- STABLE_PORT -->
## 2026-11-01 정식판 이식

모드 버전 **1.0.2**, 대상 게임 **2026-11-01**, WML **0.9.5**입니다. MCP 0.6.2로 연결을 검사합니다. 새 게임을 기준으로 하며 pre7 및 기존 저장 이전은 지원 범위에 포함하지 않습니다.

배포 파일: `companions-compatible-waitress-1.0.2-20261101.zip`. 압축의 폴더 이름과 설치 ID는 `companions-compatible-waitress`이며 `wml/mods/companions-compatible-waitress/mod.js`로 설치합니다. WML 모드 관리자에서 ZIP 설치도 가능합니다. 아래의 pre7 버전·ZIP 안내는 이전 변경 기록입니다.
<!-- /STABLE_PORT -->

# 동료 + 웨이트리스 업무 분담 1.0.1

## [pre7 배포 · 버전 분리]

현재 모드 버전: 1.0.1. 대상 게임: 2026-10-24-pre7. 이전 모드 버전: 1.0.0-pre7.1.
배포 파일: companions-compatible-waitress-1.0.1-pre7.zip
압축 내부 최상위 폴더와 로딩 ID는 항상 `companions-compatible-waitress`이며 버전·pre 표기를 붙이지 않습니다. 폴더 복사 설치 경로는 `wml/mods/companions-compatible-waitress/mod.js`입니다. ZIP 설치는 WML 모드 관리자를 사용하세요. 모드의 version은 숫자 버전, game은 대상 게임 식별자로 분리했습니다. 업데이트 인식을 위해 모드 버전의 마지막 숫자를 올렸으며 게임 동작은 이번 변경에서 수정하지 않았습니다. 이전 ZIP과 과거 변경 기록은 보존합니다.


Companions 2.4.0·Waitress 1.1.0 이상을 함께 켤 때 사용합니다. 서로 진행 중인 손님 업무와 조리대를 공유하여 상대가 맡은 일을 중복 선택하지 않습니다. 메인 인물의 손님·조리대도 기존 판정을 따릅니다. 각 모드의 고용·급료·재고·업무 실행기는 유지합니다.

이 폴더의 ZIP을 WML 관리자에 설치·활성화하고 게임을 새로고침합니다. Companions와 Waitress도 함께 갱신해야 합니다. 원제작자: Hina_Lover.
