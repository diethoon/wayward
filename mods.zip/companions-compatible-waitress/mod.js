// Companions / Waitress compatibility by Hina_Lover. Original mods remain independent.
WML.define({
  id:'companions-compatible-waitress',name:'동료 + 웨이트리스 업무 분담',author:'Hina_Lover',
  version:"1.0.2",game:"2026-11-01",lang:'ko',tags:['content'],
  description:'동료와 웨이트리스가 맡은 손님·조리대를 공유하여 중복 배정하지 않습니다.',
  requires:['companions','waitress'],requiresVersion:{companions:'>=2.4.0',waitress:'>=1.1.0'},
  setup(api){
    const people=api.use('companions'),waitress=globalThis.__waywardSimpleWaitressPublic;
    if(!people.registerWorkReservations||!waitress?.registerReservations)throw Error('동료와 웨이트리스를 최신 버전으로 갱신해 주세요.');
    waitress.registerReservations(api.id,s=>people.workReservations(s));
    people.registerWorkReservations(api.id,s=>waitress.getReservations(s));
  }
});
