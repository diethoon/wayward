globalThis.ConstructionTool_초기화 = function ConstructionTool_초기화(api) {
  'use strict';
  const ID = api.id, UPPER = 'ct_upper_hall', f = name => api.fn(name);
  const types = new Map(), plots = new Map(), roomActions = new Map(), existingRooms = new Map(), hallEvacuators = new Map();
  const plotPolicies = new Map(), occupancyProviders = new Map(), buildings = new Map();
  const vacantLots = new Set(['main_left', 'main_right', 'main_rear']);
  let lodgingProvider = null;
  const nativePresent = (s, id) => id !== 'upstairs_room_2' || !lodgingProvider || !!s?.tavern?.hasRoom2;
  // 바닐라 방의 표시 이름은 게임의 위치 카드 이름표를 그대로 읽습니다.
  // 내부 ID·면적·저장된 배치는 이름과 독립적으로 유지합니다.
  function ConstructionTool_기본방이름(id, state) {
    const short = f('constructionShortLabels'), label = short[id] || f('constructionLocationLabels')[id] || id;
    // 원본 위치판처럼 두 번째 객실이 있으면 첫 번째도 1번으로 구분합니다.
    const second = short.upstairs_room_2;
    return id === 'upstairs_hall' && state?.tavern?.hasRoom2 && typeof second === 'string'
      && / 2$/.test(second) && second.slice(0, -2) === label ? label + ' 1' : label;
  }
  const nativeRooms = [
    ['taproom', 'ground:0'], ['kitchen', 'ground:3'], ['back_room', 'ground:11'],
    ['bathhouse', 'basement:2'], ['bedroom', 'upper:2'], ['elena_room', 'upper:6'],
    ['bathroom', 'upper:0'], ['upstairs_hall', 'upper:10'], ['upstairs_room_2', 'upper:14']
  ].map(([id, slot]) => ({ id, label:ConstructionTool_기본방이름(id), slot, native: true, type: id }));
  function ConstructionTool_기록(s, text) { return f('log')(s, '[건축 툴] ' + text); }
  function ConstructionTool_공사가능(s) {
    return !!s && !s.gameOver && s.phase === 'prep' && !s.pendingEvent && !s.errandSession &&
      !s.activeShoppingSession && !Object.values(s.activeScene || {}).some(Boolean);
  }
  function ConstructionTool_위치등록(id, label) {
    const ids = f('constructionLocationIds');if (!ids.includes(id)) ids.push(id);
    f('constructionIndoorRooms').add(id);f('constructionLocationLabels')[id] = label;f('constructionShortLabels')[id] = label;
  }
  function ConstructionTool_부지등록(def) {
    if (!def || !/^[a-z][a-z0-9_-]*$/.test(def.id) || plots.has(def.id) || !def.label ||
        !Number.isInteger(def.slots) || def.slots < 1 || def.slots > 24) throw Error('부지 정의를 확인해 주세요.');
    plots.set(def.id, Object.freeze({ ...def }));
    // 건물 공통 인력 시설은 나중에 등록된 부지도 같은 정의를 사용합니다.
    for(const [id,type] of types)if(type.allBuildings&&!type.plots.includes(def.id))
      types.set(id,Object.freeze({...type,plots:Object.freeze([...type.plots,def.id])}));
  }
  function ConstructionTool_방유형등록(def) {
    if (!def || !/^[a-z][a-z0-9_-]*$/.test(def.id) || types.has(def.id) || !def.label || !Array.isArray(def.plots) ||
        !def.plots.length || def.plots.some(p => !plots.has(p)) || !Number.isInteger(def.cost) || def.cost < 0) throw Error('방 유형 정의를 확인해 주세요.');
    const roomId = def.roomId || 'ct_' + def.id;
    if (!/^ct_[a-z0-9_]+$/.test(roomId) || existingRooms.has(roomId) || [...types.values()].some(t => t.roomId === roomId)) throw Error('방 ID가 중복되거나 잘못되었어요.');
    if (!Number.isInteger(def.width ?? 1) || !Number.isInteger(def.height ?? 1) || (def.width ?? 1) < 1 || (def.width ?? 1) > 4 ||
        (def.height ?? 1) < 1 || (def.height ?? 1) > 6) throw Error('방 크기는 가로 1~4칸, 세로 1~6칸 정수여야 해요.');
    types.set(def.id, Object.freeze({ width: 1, height: 1, ...def, plots: Object.freeze([...def.plots]), roomId }));ConstructionTool_위치등록(roomId, def.label);
  }
  ConstructionTool_부지등록({ id: 'upper', label: '2층', slots: 16 });
  ConstructionTool_부지등록({ id: 'ground', label: '1층', slots: 16 });
  ConstructionTool_부지등록({ id: 'basement', label: '지하', slots: 16 });
  ConstructionTool_방유형등록({ id: 'upper_hall', roomId: UPPER, label: '2층 홀', plots: ['upper'], cost: 300,
    width: 2, height: 2, description: '고정 2×2 공간 · 건설 300골드 · 유지비 면적 1칸당 하루 1골드 · 테이블 별도 구매' });
  ConstructionTool_방유형등록({ id: 'brewery', label: '양조실', plots: ['basement', 'ground', 'upper'], cost: 200,
    width: 1, height: 1, multiple: true, description: '1×1 · 매일 기상 후 맥주·와인 각 1개 · 유지비 하루 5골드' });
  ConstructionTool_방유형등록({ id: 'guest_room', label: '추가 객실', plots: ['upper'], cost: 300,
    width: 2, height: 1, multiple: true, description: '2×1 · 객실 한 실 300골드 · 숙박 운영은 숙박 확장 연결 시 해당 규칙 적용' });
  ConstructionTool_방유형등록({id:'manager_office',roomId:'ct_manager_office',label:'매니저실',
    plots:[...plots.keys()],cost:500,width:2,height:1,multiple:true,staffRole:'manager',template:'bedroom',allBuildings:true,
    description:'침실을 참고한 관리 공간 · 2칸 · 500g · 이 건물의 매니저 지정에 필요'});
  ConstructionTool_방유형등록({id:'servant_room',roomId:'ct_servant_room',label:'고용인의 방',
    plots:[...plots.keys()],cost:300,width:2,height:1,multiple:true,staffRole:'servant',template:'elena_room',allBuildings:true,
    description:'그녀의 방을 참고한 1인 거주실 · 2칸 · 300g · 한 방에 한 명 고용'});
  function ConstructionTool_방사용중(s, id) {
    for (const provider of occupancyProviders.values()) if (provider(s, id)) return true;
    if (existingRooms.get(id)?.isOccupied?.(s)) return true;
    const patrons = new Set((s.customers || []).filter(c => c.status !== 'gone').map(c => c.id));
    return (s.locations?.[id]?.occupants || []).some(o => o === f('playerId') || s.characters?.[o] || patrons.has(o)) || Object.values(s.activeScene || {}).some(Boolean);
  }
  let model;

  // ---------------------------------------------------------------------------
  // 영업 준비 중 테이블을 손보기 전에 홀을 비워요.
  // 숙박 손님은 계약된 객실로 돌려보내고, 부부는 침실로 이동시켜
  // 점유자 정보를 삭제하지 않은 채 위치만 바꿉니다.
  // ---------------------------------------------------------------------------
  function ConstructionTool_홀비우기(s, roomId) {
    if (!ConstructionTool_공사가능(s) || !['taproom', UPPER].includes(roomId)) return s;

    const rooms = model.rooms(s);
    const usableRoom = id => !!id && !!s.locations?.[id] && rooms.some(room =>
      room.id === id && room.built !== false && !room.stored
    );
    const fallbackRoom = ['back_room', 'kitchen', 'bedroom'].find(id => id !== roomId && usableRoom(id));
    const renterRooms = new Map([
      [s.tavern?.tonightRenter?.customerId, 'upstairs_hall'],
      [s.tavern?.tonightRenter2?.customerId, 'upstairs_room_2'],
      ...model.data(s).rooms
        .filter(room => room.type === 'guest_room' && room.renter?.customerId)
        .map(room => [room.renter.customerId, room.id])
    ].filter(([id, destination]) => id && usableRoom(destination)));
    const customers = new Map((s.customers || []).map(customer => [customer.id, customer]));
    const playerId = f('playerId'), wifeId = f('wifeId');
    const hallOccupants = new Set(s.locations?.[roomId]?.occupants || []);

    // constructionSeat가 홀을 가리키는 손님도 실제 위치와 별개로 점유 판정을 받으므로 함께 이동시켜요.
    for (const customer of customers.values()) {
      if (!['gone', 'leaving'].includes(customer.status) && customer.constructionSeat === roomId) hallOccupants.add(customer.id);
    }

    let moved = 0;
    for (const occupantId of hallOccupants) {
      let destination;
      if (occupantId === playerId || occupantId === wifeId || occupantId === s.primaryCharacterId) {
        destination = usableRoom('bedroom') ? 'bedroom' : fallbackRoom;
      } else if (customers.has(occupantId)) {
        const customer = customers.get(occupantId);
        destination = usableRoom(customer.constructionGuestRoom) ? customer.constructionGuestRoom : renterRooms.get(occupantId);
        if (!destination) destination = s.locations?.village ? 'village' : fallbackRoom;
      } else {
        destination = fallbackRoom;
      }
      if (!destination || destination === roomId) continue;

      s = occupantId === wifeId || occupantId === s.primaryCharacterId
        ? f('moveWife')(s, destination)
        : f('moveOccupant')(s, occupantId, destination);
      moved++;
    }

    // 이동한 손님의 좌석 고정값을 제거해 새 위치가 실제 점유 판정에 사용되도록 해요.
    if (moved) {
      s = { ...s, customers: (s.customers || []).map(customer => {
        if (!hallOccupants.has(customer.id) || customer.constructionSeat !== roomId) return customer;
        const { constructionSeat, ...rest } = customer;
        return rest;
      }) };
    }

    // 별도 저장소로 인물을 관리하는 호환 모드도 같은 시점에 홀을 비울 수 있어요.
    for (const evacuator of hallEvacuators.values()) {
      const next = evacuator(s, { roomId, fallbackRoom });
      if (next) s = next;
    }
    return moved ? ConstructionTool_기록(s, `테이블 작업 전에 홀의 인원 ${moved}명을 다른 장소로 이동시켰어요.`) : s;
  }
  model = globalThis.ConstructionTool_모델초기화(api, { nativeRooms, nativeLabel:ConstructionTool_기본방이름, types, plots, existingRooms, plotPolicies,
    canBuild: ConstructionTool_공사가능, busy: ConstructionTool_방사용중, log: ConstructionTool_기록,
    registerLocation: ConstructionTool_위치등록, evacuateHall: ConstructionTool_홀비우기, nativePresent,
    ownsLodging: () => !!lodgingProvider });
  const hasUpper = s => model.data(s).rooms.some(r => r.id === UPPER);
  function ConstructionTool_예약손님(s, c) {
    const scene = f('patronScene')(s);
    return !!(c.isResident || c.isEventGuest || c.eventGuest || c.forcedGuest || c.scriptedGuest || c.priorityEntry ||
      c.eventId || c.namedPatronId || c.questBoardVisit || s.pendingForcedPatron?.customerId === c.id ||
      scene?.customerId === c.id || scene?.joinedPatronIds?.includes(c.id));
  }
  function ConstructionTool_좌석사용(s, floor) {
    return (s.customers || []).filter(c => !['gone', 'leaving'].includes(c.status) && !c.constructionGuestRoom &&
      (c.constructionSeat || f('locationOf')(s, c.id)) === floor).length;
  }
  api.hook('addCustomer', { before([s, c, room]) {
    if (!s || !c || room !== 'taproom' || c.status !== 'arrived') return;
    const cap = model.capacity(s), destination = ConstructionTool_좌석사용(s, 'taproom') < cap.ground ? 'taproom' :
      ConstructionTool_좌석사용(s, UPPER) < cap.upper ? UPPER : null;
    if (!destination) return ConstructionTool_예약손님(s, c) ? undefined : { cancel: true, value: s };
    return [s, { ...c, constructionSeat: destination }, destination];
  } });
  let tickState = null;
  api.hook('worldTick', { around(next, s, ...args) {
    const prior = tickState;tickState = s;try { return next(s, ...args); } finally { tickState = prior; }
  } });
  api.hook('normalVisitRoll', { around(next, slot, service, count, renown = 50, scale = 1) {
    const s = tickState || api.store.game();if (!s) return next(slot, service, count, renown, scale);
    if (ConstructionTool_좌석사용(s, 'taproom') + ConstructionTool_좌석사용(s, UPPER) >= model.capacity(s).total) return false;
    return next(slot, service, 0, renown, scale);
  } });
  api.hook('constructionServicePatron', { after(value, [s, c]) {
    return value || (f('locationOf')(s, c.id) === UPPER && hasUpper(s) && f('constructionActivePatron')(c) && !f('constructionBusyPatron')(s, c));
  } });
  api.hook('constructionPlayerInHall', { after(value, [s]) { return value || (hasUpper(s) && f('playerLocation')(s) === UPPER); } });
  for (const name of ['constructionGreet', 'constructionOrder', 'constructionServe', 'constructionApologize']) api.hook(name, { before([s, id]) {
    const where = f('locationOf')(s, id), player = f('playerLocation')(s);
    if ((where === UPPER || player === UPPER) && where !== player) return { cancel: true, value: ConstructionTool_기록(s, '같은 홀로 이동한 뒤 응대해 주세요.') };
  } });
  api.hook('constructionAutoServiceAction', { around(next, s) {
    if (!hasUpper(s) || !['taproom', UPPER].includes(f('playerLocation')(s))) return next(s);
    return next({ ...s, customers: s.customers.filter(c => f('locationOf')(s, c.id) === f('playerLocation')(s)) });
  } });
  api.hook('constructionWifeServiceAI', { priority: 100, around(next, s) {
    if (!hasUpper(s) || !['service', 'last_call'].includes(s.phase) || s.pendingEvent || Object.values(s.activeScene || {}).some(Boolean)) return next(s);
    const wife = f('wife')(s), loc = f('wifeLocation')(s);
    if (!['taproom', UPPER].includes(loc) || wife.currentTask !== 'idle' || wife.retiredAtSlot != null ||
        wife.busyUntilSlot > s.slot || wife.locationUntilSlot > s.slot || wife.stats.energy < 15) return next(s);
    const needs = room => s.customers.some(c => ['arrived', 'greeted', 'ordered', 'wants_more'].includes(c.status) && f('locationOf')(s, c.id) === room);
    const other = loc === 'taproom' ? UPPER : 'taproom';return next(!needs(loc) && needs(other) ? f('moveWife')(s, other) : s);
  } });
  api.hook('wakeUp', { after(s) { return model.wake(s); } });
  api.hook('constructionLodgingRoll', { around(next, s) {
    return lodgingProvider ? lodgingProvider.book(s) : model.lodging(next(s), next);
  } });
  api.hook('reduceGameAction', { before([s,a]) {
    if(lodgingProvider && a?.type === 'buy_room2_upgrade')
      return {cancel:true,value:ConstructionTool_기록(s,'추가 객실은 건축 설계도에서 한 실 300g에 지어 주세요.')};
  } });
  function ConstructionTool_이동(s, a) {
    if (s.gameOver || !f('constructionCanMove')(s)) return s;
    const room = model.rooms(s).find(r => r.id === a.roomId);
    if (!room || room.built === false || room.stored || (room.native && !room.external)) return s;
    const gate = f('constructionMovementGate')(s, f('playerLocation')(s), room.id);if (gate.caught) return gate.state;
    return ConstructionTool_기록(f('moveOccupant')(gate.state, f('playerId'), room.id), `${room.label}로 이동했어요.`);
  }
  api.actions.register(ID + '/construct', model.construct, { label: '시설 건축/배치/확장' });
  api.actions.register(ID + '/table', model.table, { label: '테이블 구매/배치/업그레이드' });
  api.actions.register(ID + '/build-building', (s, a) => {
    const def = buildings.get(a.buildingId), lotId = String(a.lotId || '');
    if (!def || !vacantLots.has(lotId) || !def.lots.includes(lotId) || !ConstructionTool_공사가능(s)) return s;
    if (def.currentLot(s) || [...buildings.values()].some(other => other.currentLot(s) === lotId))
      return ConstructionTool_기록(s, '선택한 공터에는 이미 건물이 있습니다.');
    const reason = def.canBuild?.(s, lotId);
    if (reason) return ConstructionTool_기록(s, reason);
    const next = def.build(s, lotId);
    return next || s;
  }, { label: '공터에 건물 건설' });
  api.actions.register(ID + '/move', ConstructionTool_이동, { label: '건축한 방으로 이동' });
  api.actions.register(ID + '/room-action', (s, a) => {
    const room = model.data(s).rooms.find(r => r.id === a.roomId), def = roomActions.get(a.actionId);
    return room && def && room.type === def.roomType && !s.gameOver && def.enabled?.(s, room) !== false ? def.run(s, { ...room }) : s;
  });
  let normalizing = false;
  function ConstructionTool_저장위치동기화() {
    const s = api.store.game();if (!s) return;
    const data = model.data(s);
    for (const room of data.rooms) ConstructionTool_위치등록(room.id, room.label || room.id);
    if (!normalizing && s.mods?.[ID]?.schema !== 2) {
      normalizing = true;
      try { api.store.update(current => current === s ? model.save(current, data) : current); }
      finally { normalizing = false; }
    }
  }
  ConstructionTool_저장위치동기화();api.store.subscribe(ConstructionTool_저장위치동기화);
  const publicAPI = Object.freeze({
    version: 1, gridVersion: 2, plotPolicyVersion: 1, buildingLotVersion: 1, lodgingProviderVersion: 1,
    hasLodgingProvider: () => !!lodgingProvider,
    setLodgingProvider(provider) {
      if(lodgingProvider || typeof provider?.book !== 'function') throw Error('숙박 운영 연결이 중복되거나 잘못되었습니다.');
      lodgingProvider = provider;
    },
    // 추가 부지의 면적과 비용은 소유 애드온이 관리하고 실제 배치는 같은 격자 엔진이 검사합니다.
    registerPlotPolicy(def) {
      if (!def?.id || !plots.has(def.id) || plotPolicies.has(def.id) || typeof def.size !== 'function') throw Error('부지 정책을 확인해 주세요.');
      plotPolicies.set(def.id, Object.freeze({ ...def }));
    },
    registerOccupancyProvider(def) {
      if (!def?.id || occupancyProviders.has(def.id) || typeof def.isOccupied !== 'function') throw Error('점유 검사 정의를 확인해 주세요.');
      occupancyProviders.set(def.id, def.isOccupied);
    },
    registerBuilding(def) {
      if (!def || !/^[a-z][a-z0-9_-]*$/.test(def.id) || buildings.has(def.id) || !def.label ||
          !Array.isArray(def.lots) || !def.lots.length || def.lots.some(id => !vacantLots.has(id)) ||
          typeof def.currentLot !== 'function' || typeof def.build !== 'function') throw Error('공터 건물 정의를 확인해 주세요.');
      buildings.set(def.id, Object.freeze({ cost: 0, description: '', ...def, lots: Object.freeze([...def.lots]) }));
    },
    registerPlot: ConstructionTool_부지등록, registerRoomType: ConstructionTool_방유형등록,
    registerExistingRoom(def) {
      if (!def || !/^[a-z][a-z0-9_]*$/.test(def.id) || !def.label || typeof def.isBuilt !== 'function' ||
          !plots.has(def.slot?.split(':')[0]) || existingRooms.has(def.id) || nativeRooms.some(r => r.id === def.id) || [...types.values()].some(r => r.roomId === def.id)) throw Error('기존 시설 정의를 확인해 주세요.');
      const placement = model.defaults[def.id] || { floor: def.slot.split(':')[0], cells: def.cells || [Number(def.slot.split(':')[1])] };
      const collisions = model.rooms(api.store.game()).filter(r => r.id !== def.id && r.floor === placement.floor).flatMap(r => r.cells);
      if (placement.cells.some(c => !Number.isInteger(c) || c < 0 || c >= 24 || collisions.includes(c))) throw Error('기존 시설의 면적이 다른 시설과 겹쳐요.');
      existingRooms.set(def.id, Object.freeze({ ...def }));ConstructionTool_위치등록(def.id, def.label);
    },
    buildExistingRoom(id) {
      const s = api.store.game(), def = existingRooms.get(id);
      if (!def || !ConstructionTool_공사가능(s) || def.isBuilt(s) || def.canBuild?.(s) || typeof def.build !== 'function') return false;
      def.build();return true;
    },
    registerRoomAction(def) {
      if (!def?.id || roomActions.has(def.id) || !types.has(def.roomType) || typeof def.run !== 'function' || !def.label) throw Error('방 행동 정의를 확인해 주세요.');
      roomActions.set(def.id, Object.freeze({ ...def }));
    },
    registerHallEvacuator(def) {
      if (!def?.id || hallEvacuators.has(def.id) || typeof def.evacuate !== 'function') throw Error('홀 인원 이동 정의를 확인해 주세요.');
      hallEvacuators.set(def.id, def.evacuate);
    },
    getRooms: s => model.rooms(s || api.store.game()),getPlots: () => [...plots.values()].map(p => ({ ...p })),
    getRoomTypes:()=>[...types.values()].map(type=>({...type,plots:[...type.plots]})),
    getBlueprint: (floor, s) => structuredClone(model.blueprint(s || api.store.game(), floor)),
    getCapacity: s => model.capacity(s || api.store.game()),getData: s => structuredClone(model.data(s || api.store.game())),
    getUpkeep: s => model.upkeep(s || api.store.game()),canConstruct: ConstructionTool_공사가능
  });
  return { ID, UPPER, f, types, plots, nativeRooms, existingRooms, roomActions, buildings, vacantLots, publicAPI, model,
    data: model.data,rooms: model.rooms,capacity: model.capacity,blueprint: model.blueprint,upkeep: model.upkeep,
    canBuild: ConstructionTool_공사가능,busy: ConstructionTool_방사용중,hasUpper };
};
