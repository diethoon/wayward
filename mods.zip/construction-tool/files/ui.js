globalThis.ConstructionTool_화면초기화 = function ConstructionTool_화면초기화(api, core) {
  'use strict';
  const { ID, UPPER, f } = core, React = f('React'), jsx = f('jsx').jsx;
  // 다른 모드가 영업 준비 컴포넌트의 props를 생략해도 시설 전용 표시 범위는 유지해요.
  const facilitiesContext = React.createContext(false);
  const dispatch = a => api.store.dispatch(a), construct = a => dispatch({ type: ID + '/construct', ...a });
  // 바닐라 방은 검정에 가까운 단색으로, 모드 방은 1.2.6의 화면별 음영으로 표시해요.
  const colors = { ct_upper_hall: '#293d56' };
  const style = {
    button: { background: '#293a43', color: '#e7f3f5', border: '1px solid #52727d', borderRadius: 6, padding: '7px 10px', cursor: 'pointer', fontSize: 13 },
    panel: { padding: 12, border: '1px solid #344a55', borderRadius: 8, background: '#111d26', marginBottom: 12 },
    muted: { color: '#a7b7c1', fontSize: 12, lineHeight: 1.6 },
    flex: { display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' },
    // 현재 위치 카드는 바닐라의 6px 여백·12px 본문을 공통으로 사용해요. 인물이 많으면 자연스럽게 늘어나요.
    roomCard: { boxSizing: 'border-box', display: 'block', width: '100%', height: '100%', minWidth: 0,
      minHeight: 44, padding: 6, fontSize: 12, lineHeight: 1.25, textAlign: 'left', borderRadius: 4,
      color: '#e8eff4', overflowWrap: 'anywhere' }
  };
  const css = document.createElement('style');
  // 현재 위치는 PC에서 4열, 좁은 화면에서 2열로 표시해 시설 카드를 읽기 쉽게 유지해요.
  css.textContent = `
    [data-ct-location-grid]{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:5px}
    [data-ct-native-room] .text-stone-500,
    [data-ct-native-room] .text-stone-600,
    [data-ct-native-room] .text-stone-700{color:#c7d5df}
    [data-ct-location-card]>:first-child{color:inherit;font-size:10.4px;line-height:13px;font-weight:600;letter-spacing:normal;text-transform:none;margin:0 0 2px}
    [data-ct-location-card]:focus-visible{outline:2px solid #f7c474;outline-offset:2px}
    [data-ct-simple-grid]{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
    @media(max-width:540px){
      [data-ct-location-grid],[data-ct-simple-grid]{grid-template-columns:repeat(2,minmax(0,1fr))}
      [data-ct-cell]{padding:5px!important;font-size:11px!important;min-height:84px!important}
    }
  `;
  document.head.append(css);
  function ConstructionTool_방음영읽기(room, fallback = '#293a43') {
    if (room.native && !room.external) return '#1e1e1e';
    return colors[room.id] || fallback;
  }
  function ConstructionTool_버튼(label, onClick, disabled = false, attrs = {}) {
    return jsx('button', { type: 'button', ...attrs, onClick, disabled, style: { ...style.button,
      opacity: disabled ? .45 : 1, cursor: disabled ? 'not-allowed' : 'pointer', ...attrs.style }, children: label });
  }
  function ConstructionTool_방이름(label, id) {
    return jsx('span', { style: { display: 'inline-flex', flexWrap: 'wrap', alignItems: 'baseline', gap: '2px 6px', maxWidth: '100%', whiteSpace: 'normal' }, children: [
      jsx('span', { children: label }), jsx('span', { 'data-ct-game-id': id, style: { color: '#fb923c', fontFamily: 'monospace', fontSize: 10,
        fontWeight: 400, textTransform: 'none', letterSpacing: 'normal', overflowWrap: 'anywhere', minWidth: 0 }, children: id })
    ] });
  }
  function ConstructionTool_재실이름(s, id) {
    const known = new Set([f('playerId'), ...Object.keys(s.characters || {}), ...s.customers.filter(c => c.status !== 'gone').map(c => c.id)]);
    return [...(s.locations?.[id]?.occupants || []).filter(o => known.has(o)).map(o => o === f('playerId') ? '당신' : s.characters?.[o]?.name || s.customers.find(c => c.id === o)?.name || o),
      ...(core.existingRooms.get(id)?.occupantNames?.(s) || [])];
  }
  // 보기 선택은 게임 저장과 분리해 창을 다시 열어도 건물별 마지막 층을 기억해요.
  const view = { building: 'main', floors: { main: 'upper' }, tab: 'blueprint' };
  function ConstructionTool_선택연결읽기(id) {
    // 기본 모드만 켠 구성에서도 열리도록 선택 연결은 화면을 그릴 때 조회해요.
    try { return api.use(id); } catch { return null; }
  }
  function ConstructionTool_설계대상읽기(state) {
    const groups = new Map([
      ['main', { id: 'main', label: '본관', order: 0, plots: [] }],
      ['main_left', { id: 'main_left', label: '본관 좌측 · 공터', order: 20, plots: [] }],
      ['main_right', { id: 'main_right', label: '본관 우측 · 공터', order: 30, plots: [] }],
      ['main_rear', { id: 'main_rear', label: '본관 뒤편 · 공터', order: 35, plots: [] }]
    ]);
    const floors = { upper: ['2층', 0], ground: ['1층', 1], basement: ['지하', 2] };
    const districts = { north: ['마을 북쪽 구역', 40], east: ['마을 동쪽 구역', 50], south: ['마을 남쪽 구역', 60] };
    for (const plot of core.plots.values()) {
      const estate = /^estate_(north|east|south)_(upper|ground|basement)$/.exec(plot.id);
      const known = floors[plot.id] ? { id: 'main', label: '본관', order: 0, floor: plot.id }
        : estate ? { id: 'estate_' + estate[1], label: districts[estate[1]][0], order: districts[estate[1]][1], floor: estate[2] }
        : null;
      // 새 애드온은 표시용 메타데이터로 묶고, 기존 애드온은 안정된 ID로 호환해요.
      const id = plot.buildingId || known?.id || plot.id;
      const registered = core.buildings.get(id);
      if (registered && !registered.currentLot(state)) continue;
      let group = groups.get(id);
      if (!group) {
        group = { id, label: plot.buildingLabel || known?.label || plot.label,
          order: plot.buildingOrder ?? known?.order ?? 100, plots: [] };
        groups.set(id, group);
      }
      if (plot.buildingLabel) group.label = plot.buildingLabel;
      group.plots.push({ ...plot, floorLabel: plot.floorLabel || floors[known?.floor]?.[0] || known?.floorLabel || plot.label,
        floorOrder: plot.floorOrder ?? floors[known?.floor]?.[1] ?? 100 });
    }
    for (const group of groups.values()) {
      const occupant = [...core.buildings.values()].find(def => def.currentLot(state) === group.id);
      if (occupant) group.label = group.label.replace(/ · 공터$/, '') + ' · ' + occupant.label;
    }
    return [...groups.values()].sort((a, b) => a.order - b.order).map(group => ({ ...group,
      plots: group.plots.sort((a, b) => a.floorOrder - b.floorOrder) }));
  }
  function ConstructionTool_설계화면() {
    const s = f('store')(o => o.state), [buildingId, setBuilding] = React.useState(view.building);
    const [selectedFloor, setFloor] = React.useState(view.floors[view.building]), [tab, setTab] = React.useState(view.tab);
    const [cell, setCell] = React.useState(() => view.floors[view.building] === 'upper' ? 4 : 0);
    const [roomId, setRoomId] = React.useState(null), [rotate, setRotate] = React.useState(false);
    const [moving, setMoving] = React.useState(null), [confirm, setConfirm] = React.useState(null);
    if (!s) return jsx('p', { children: '게임을 시작한 뒤 열어 주세요.' });
    const buildings = ConstructionTool_설계대상읽기(s), building = buildings.find(b => b.id === buildingId) || buildings[0];
    const plot = building.plots.find(p => p.id === selectedFloor) || building.plots[0], floor = plot?.id;
    const plan = floor ? core.blueprint(s, floor) : { rooms: [], tables: [], size: 0 };
    const cap = core.capacity(s), upkeep = core.upkeep(s), allowed = core.canBuild(s);
    const district = /^estate_(north|east|south)$/.exec(building.id)?.[1];
    const estate = district ? ConstructionTool_선택연결읽기('real-estate') : null;
    const estateLot = estate?.getLots?.(s).find(lot => lot.id === district);
    const title = building.label + (estateLot?.building ? ' · ' + estateLot.building.label : '');
    const unbuiltEstate = estateLot && estateLot.status !== 'complete';
    const expansion = plan.expansion || (building.id === 'main' ? null
      : { label: '이 부지는 층 확장을 지원하지 않아요.', cost: 0, disabled: true,
        description: '건물별 확장 정책을 따라요.' });
    const room = roomId ? plan.rooms.find(r => r.id === roomId) : plan.rooms.find(r => r.cells.includes(cell));
    const table = plan.tables.find(t => t.cells.includes(cell));
    const external = room && core.existingRooms.get(room.id), selectedCellRoom = plan.rooms.find(r => r.cells.includes(cell));
    const furniture = a => dispatch({ type: ID + '/table', ...a });
    const registeredBuilding = core.buildings.get(building.id);
    const lotOccupant = !plot ? [...core.buildings.values()].find(def => def.currentLot(s) === building.id) : null;
    const lotChoices = !plot && !lotOccupant ? [...core.buildings.values()].filter(def => !def.currentLot(s) && def.lots.includes(building.id)) : [];
    const resetSelection = id => {
      setCell(id === 'upper' ? 4 : 0);setRoomId(null);setMoving(null);setConfirm(null);setRotate(false);
    };
    const changeFloor = id => { view.floors[building.id] = id;setFloor(id);resetSelection(id); };
    const changeBuilding = id => {
      const target = buildings.find(b => b.id === id);
      const next = target.plots.find(p => p.id === view.floors[id])?.id || target.plots[0]?.id;
      view.building = id;setBuilding(id);setFloor(next);resetSelection(next);
    };
    const changeTab = id => { view.tab = id;setTab(id);setRoomId(null);setMoving(null);setConfirm(null);setRotate(false); };
    const selectCell = i => {
      if (moving) {
        if (moving.kind === 'table') furniture({ operation: 'move', tableId: moving.id, cell: i, rotate });
        else construct({ operation: 'move', roomId: moving.id, floor, cell: i, rotate });
        setMoving(null);
      }
      setCell(i);setRoomId(null);setConfirm(null);
    };
    const nativeBuild = { bathhouse: 'buy_bathhouse', upstairs_hall: 'buy_room_upgrade', upstairs_room_2: 'buy_room2_upgrade', back_room: 'clean_back_room' };
    return jsx('div', { 'data-ct-window': true, style: { color: '#e3ecf0', fontSize: 14, padding: 4 }, children: [
      jsx('nav', { style: { ...style.flex, marginBottom: 12 }, 'aria-label': '설계/건축 메뉴', children: [
        ConstructionTool_버튼('건축 설계도', () => changeTab('blueprint'), false, { 'data-ct-tab': 'blueprint', 'aria-pressed': tab === 'blueprint' }),
        ConstructionTool_버튼('시설 업그레이드', () => changeTab('upgrades'), false, { 'data-ct-tab': 'upgrades', 'aria-pressed': tab === 'upgrades' })
      ] }),
      tab === 'blueprint' && jsx('nav', { style: { ...style.flex, marginBottom: 12 }, 'aria-label': '건물·부지 선택', children: buildings.map(b =>
        ConstructionTool_버튼(b.label, () => changeBuilding(b.id), false, { key: b.id, 'data-ct-building-tab': b.id,
          'aria-pressed': building.id === b.id, style: { flex: '1 1 145px', minWidth: 0, overflowWrap: 'anywhere',
            background: building.id === b.id ? '#285d6b' : '#182b35' } })) }),
      tab === 'blueprint' && plot && jsx('nav', { style: { ...style.flex, marginBottom: 12 }, 'aria-label': building.label + ' 층·시설 선택', children: building.plots.map(p =>
        ConstructionTool_버튼(p.floorLabel, () => changeFloor(p.id), false, { key: p.id, 'data-ct-floor-tab': p.id,
          'aria-pressed': floor === p.id, style: { flex: '1 1 80px', minWidth: 0, background: floor === p.id ? '#285d6b' : '#182b35' } })) }),
      jsx('div', { style: { ...style.flex, justifyContent: 'space-between', marginBottom: 12 }, children: [
        jsx('div', { children: [jsx('strong', { 'data-ct-plan-title': true, children: tab === 'upgrades' ? '본관 시설 업그레이드'
          : title + (plot ? ' · ' + plot.floorLabel : '') }), jsx('p', { style: style.muted, children: tab === 'upgrades'
          ? '본관의 기존 시설 구매·개선을 관리해요.' : unbuiltEstate ? estateLot.statusLabel
          : plot ? `${plan.size}칸${building.id === 'main' ? ' / 최대 24칸' : ''} · 4열 고정` : '미건축 부지' })] }),
        jsx('div', { style: { textAlign: 'right' }, children: [`${s.economy.gold} 골드`, tab === 'blueprint' && building.id === 'main' &&
          jsx('p', { style: style.muted, children: `일반 ${cap.total}석 (1층 ${cap.ground} / 2층 ${cap.upper}) · 유지비 ${upkeep.total}g/일` })] })
      ] }),
      !allowed && jsx('p', { style: { ...style.muted, color: '#edc68a' }, children: '현재는 열람만 가능해요. 공사·가구 변경은 사건이 없는 영업 준비 시간에 할 수 있어요.' }),
      tab === 'upgrades' ? (allowed ? jsx(facilitiesContext.Provider, { value: true, children:
        jsx('section', { 'data-ct-facilities': true, children: jsx(f('constructionPrepPanel'), { constructionFacilitiesOnly: true }) })
      }) : jsx('p', { style: style.muted, children: '기존 시설 구매는 영업 준비 시간에 가능해요.' })) : !plot ?
        jsx('section', { style: style.panel, 'data-ct-empty-building': building.id, children: [
          jsx('h3', { children: lotOccupant ? `${lotOccupant.label}이(가) 건설된 부지예요.` : '아직 건물이 없는 공터예요.' }),
          jsx('p', { style: style.muted, children: lotOccupant
            ? '이 부지의 건물 설계도와 관리 화면으로 이동할 수 있어요.'
            : '각 공터에는 등록된 건물 한 채를 지을 수 있어요.' }),
          lotOccupant && ConstructionTool_버튼(`${lotOccupant.label} 설계도`, () => changeBuilding(lotOccupant.id), false,
            { 'data-ct-lot-open': lotOccupant.id }),
          lotOccupant?.open && ConstructionTool_버튼(`${lotOccupant.label} 관리`, () => lotOccupant.open(), false,
            { 'data-ct-lot-manage': lotOccupant.id }),
          !lotOccupant && lotChoices.length === 0 && jsx('p', { style: style.muted, children: '현재 이 공터에 건설할 수 있는 등록 건물이 없어요.' }),
          ...lotChoices.map(def => jsx('div', { style: { marginTop: 8 }, children: [
            ConstructionTool_버튼(`${def.label} 건설 · ${def.cost}g`, () => dispatch({ type: ID + '/build-building', buildingId: def.id, lotId: building.id }),
              !allowed || !!def.canBuild?.(s, building.id), { 'data-ct-build-building': def.id }),
            jsx('p', { style: style.muted, children: def.canBuild?.(s, building.id) || def.description })
          ] }, def.id))
        ] }) : unbuiltEstate ? jsx('section', { style: style.panel, 'data-ct-estate-status': estateLot.status, children: [
          jsx('h3', { children: estateLot.statusLabel }),
          jsx('p', { style: style.muted, children: '부동산에서 부지를 매입하고 건물을 완공한 뒤 내부를 설계할 수 있어요.' }),
          ConstructionTool_버튼('부동산 · 계약·건축 관리', () => estate.open(), false, { 'data-ct-estate-open': district })
        ] }) : jsx('div', { children: [
        registeredBuilding?.open && jsx('section', { style: style.panel, 'data-ct-building-management': building.id, children:
          ConstructionTool_버튼(`${registeredBuilding.label} 관리`, () => registeredBuilding.open(), false, { 'data-ct-building-manage': building.id }) }),
        jsx('section', { style: style.panel, 'data-ct-simple': floor, children: [
          jsx('h3', { style: { marginBottom: 8 }, children: '단순 시설 배치' }),
          jsx('div', { 'data-ct-simple-grid': true, children: plan.rooms.map(r => ConstructionTool_버튼(jsx('div', { children: [
            ConstructionTool_방이름(r.label, r.id), jsx('p', { style: { ...style.muted, marginTop: 5 }, children:
              `${r.cells.length}칸 · ${r.built === false ? r.external ? '미건설 · (모드) 예약 자리' : '미건설 · 고정 자리' : r.external ? '(모드) 시설' : r.stored ? '보관 중' : '사용 가능'}` }),
            jsx('p', { style: style.muted, children: ConstructionTool_재실이름(s, r.id).join(', ') || '비어 있음' })
          ] }), () => { setRoomId(r.id);setCell(r.cells[0] ?? 0);setConfirm(null); }, false,
          { key: r.id, 'data-ct-simple-room': r.id, style: { textAlign: 'left', background: ConstructionTool_방음영읽기(r, '#273841'),
            borderColor: r.native && !r.external ? '#666666' : '#52727d' } })) })
        ] }),
        jsx('section', { style: style.panel, 'data-ct-detail': floor, children: [
          jsx('div', { style: { ...style.flex, justifyContent: 'space-between', marginBottom: 8 }, children: [
            jsx('h3', { children: '세부 시설 배치' }), jsx('span', { style: style.muted, children: '각 칸을 눌러 시설·테이블을 선택해요.' })
          ] }),
          moving && jsx('p', { style: { ...style.muted, color: '#f2cd85' }, children: '옮길 곳의 시작 칸을 클릭하세요. 다른 시설과 겹치는 배치는 거부돼요.' }),
          jsx('div', { 'data-ct-grid': floor, style: { display: 'grid', gridTemplateColumns: 'repeat(4,minmax(0,1fr))', gap: 5 }, children:
            Array.from({ length: plan.size }, (_, i) => {
              const r = plan.rooms.find(r => r.cells.includes(i)), t = plan.tables.find(t => t.cells.includes(i));
              return ConstructionTool_버튼(jsx('div', { children: [
                jsx('div', { style: { fontSize: 9, color: '#91a8b4' }, children: `${Math.floor(i / 4) + 1}행 ${i % 4 + 1}열` }),
                jsx('div', { style: { margin: '5px 0', fontWeight: 600 }, children: r?.label || '빈칸' }),
                t ? jsx('div', { style: { color: t.premium ? '#f1cc75' : '#c8dee0', fontSize: 11 }, children: `${t.premium ? '고급' : '기본'}테이블 ${t.id.split('_').pop()} · ${t.premium ? 3 : 2}석${t.active === false ? ' (휴지)' : ''}` }) :
                  jsx('div', { style: { ...style.muted, fontSize: 10 }, children: r?.built === false ? r.external ? '(모드) 예약 자리' : '건축 필요' : r ? `${r.cells.length}칸 시설` : '건축 / 홀 확장' })
              ] }), () => selectCell(i), false, { key: i, 'data-ct-cell': `${floor}:${i}`, 'data-ct-cell-room': r?.id || '',
                'data-ct-cell-table': t?.id || '', 'aria-pressed': cell === i,
                style: { minHeight: 94, width: '100%', textAlign: 'left', padding: 7, overflowWrap: 'anywhere',
                  border: cell === i ? '2px solid #f7c474' : r?.built === false ? '1px dashed #67818b' : '1px solid #49606b',
                  ...(cell !== i && r?.native && !r.external ? { borderColor: '#666666' } : {}),
                  background: r ? ConstructionTool_방음영읽기(r, '#34404b') : '#11212c' } });
            }) }),
          jsx('div', { style: { ...style.flex, marginTop: 12 }, children: [
            ConstructionTool_버튼(expansion?.label || `4×1칸 확장 공사 · 300g (${plan.expansions}/2회)`, () => construct({ operation: 'expand-floor', floor }),
              !allowed || (expansion ? !!expansion.disabled || s.economy.gold < expansion.cost :
                !!plan.job || plan.expansions >= 2 || s.economy.gold < 300), { 'data-ct-expand-floor': floor }),
            jsx('span', { style: style.muted, children: expansion?.description || (plan.job ? `${plan.job.dueDay}일 기상 후 완공 예정` : '주문한 날의 다다음 날 기상 후 아래쪽에 1행 추가') })
          ] })
        ] }),
        jsx('section', { style: style.panel, 'data-ct-selection': true, children: [
          jsx('h3', { style: { marginBottom: 10 }, children: table ? `${table.premium ? '고급' : '기본'} 테이블 · ${table.premium ? 3 : 2}석` : room ? ConstructionTool_방이름(room.label, room.id) : '빈칸에 시설 배치' }),
          jsx('label', { style: { ...style.flex, ...style.muted, marginBottom: 8 }, children: [
            jsx('input', { type: 'checkbox', checked: rotate, onChange: e => setRotate(e.target.checked), 'data-ct-rotate': true }),
            '90도 회전 (테이블은 기본 세로 2칸 / 체크하면 가로 2칸)'
          ] }),
          table ? jsx('div', { style: style.flex, children: [
            !table.premium && ConstructionTool_버튼('고급으로 업그레이드 · 20g', () => furniture({ operation: 'upgrade', tableId: table.id }), !allowed || s.economy.gold < 20, { 'data-ct-upgrade-table': table.id }),
            ConstructionTool_버튼('테이블 배치 이동', () => setMoving({ kind: 'table', id: table.id }), !allowed),
            ConstructionTool_버튼(table.active === false ? '사용하기' : '사용 중지', () => furniture({ operation: 'toggle', tableId: table.id }), !allowed),
            ConstructionTool_버튼('테이블 철거', () => setConfirm({ kind: 'table', id: table.id }), !allowed)
          ] }) : jsx('div', { children: [
            room && jsx('div', { style: style.flex, children: [
              !room.fixed && ConstructionTool_버튼('시설 배치 이동', () => setMoving({ kind: 'room', id: room.id }), !allowed || core.busy(s, room.id)),
              !room.native && room.built && ConstructionTool_버튼('시설 철거', () => setConfirm({ kind: 'room', id: room.id }), !allowed || core.busy(s, room.id)),
              room.built && (!room.native || room.external) && ConstructionTool_버튼('이 방으로 이동', () => dispatch({ type: ID + '/move', roomId: room.id }), !f('constructionCanMove')(s)),
              room.id === UPPER && !room.built && ConstructionTool_버튼('2층 홀 건설 · 300g', () => construct({ operation: 'build', roomType: 'upper_hall' }), !allowed || s.economy.gold < 300, { 'data-ct-build': 'upper_hall' }),
              room.native && !room.external && !room.built && nativeBuild[room.id] && ConstructionTool_버튼('기본 게임 시설 건설', () => dispatch({ type: nativeBuild[room.id] }), !allowed),
              external?.build && !room.built && ConstructionTool_버튼(external.buildLabel || '시설 건설', () => core.publicAPI.buildExistingRoom(room.id), !allowed || !!external.canBuild?.(s), { 'data-ct-build-existing': room.id })
            ] }),
            room?.id === 'elena_room' && jsx('p', { style: style.muted, children: `${room.label}은 바닐라 elena_room이에요. 관계 유형에 따라 사용하며, 관계·수면 설정은 기본 게임 규칙을 따릅니다.` }),
            room?.id === UPPER && jsx('p', { style: style.muted, children: `2층 홀 유지비: ${room.cells.length}칸 × 1g = ${room.built ? room.cells.length : 0}g/일. 테이블은 별도로 놓아요.` }),
            external && jsx('p', { style: style.muted, children: external.canBuild?.(s) || external.description }),
            room?.external && !external && jsx('p', { style: style.muted, children: 'Brothel과 건축 툴·Brothel 연결 모드를 켜면 이 예약 자리에 원래 시설을 건설할 수 있어요.' }),
            room && ['taproom', UPPER].includes(room.id) && room.built && selectedCellRoom?.id === room.id && jsx('div', { style: { ...style.flex, marginTop: 8 }, children: [
              ConstructionTool_버튼('기본 테이블 · 30g / 2석', () => furniture({ operation: 'buy', roomId: room.id, cell, rotate }), !allowed || s.economy.gold < 30, { 'data-ct-buy-table': 'basic' }),
              ConstructionTool_버튼('고급 테이블 · 50g / 3석', () => furniture({ operation: 'buy', roomId: room.id, cell, rotate, premium: true }), !allowed || s.economy.gold < 50, { 'data-ct-buy-table': 'premium' })
            ] }),
            !selectedCellRoom && jsx('div', { children: [
              ['upper', 'ground'].includes(floor) && (floor === 'ground' || core.hasUpper(s)) && ConstructionTool_버튼('이 빈칸을 홀로 편입', () => construct({ operation: 'expand-hall', floor, cell }), !allowed, { 'data-ct-expand-hall': true }),
              ...[...core.types.values()].filter(t => t.id !== 'upper_hall' && t.plots.includes(floor)).map(t => jsx('div', { style: { marginTop: 8 }, children: [
                ConstructionTool_버튼(`${t.label} 건설 · ${t.cost}g (${t.width}×${t.height})`, () => construct({ operation: 'build', roomType: t.id, floor, cell, rotate }), !allowed || s.economy.gold < t.cost,
                  { 'data-ct-build': t.id }), jsx('p', { style: style.muted, children: t.description })
              ] }, t.id))
            ] }),
            ...[...core.roomActions.values()].filter(a => a.roomType === room?.type && a.id !== barnAction?.id).map(a => ConstructionTool_버튼(a.label,
              () => dispatch({ type: ID + '/room-action', roomId: room.id, actionId: a.id }), a.enabled?.(s, room) === false, { key: a.id }))
          ] }),
          moving && ConstructionTool_버튼('배치 이동 취소', () => setMoving(null)),
          confirm && jsx('div', { style: { ...style.flex, marginTop: 12 }, children: [
            jsx('span', { style: style.muted, children: confirm.kind === 'table' ? '테이블을 철거할까요? 환급은 없어요.' : '건축비 25%를 회수하고 실내 테이블도 함께 철거해요.' }),
            ConstructionTool_버튼('철거 확정', () => { if (confirm.kind === 'table') furniture({ operation: 'remove', tableId: confirm.id });else construct({ operation: 'demolish', roomId: confirm.id });setConfirm(null); }, !allowed),
            ConstructionTool_버튼('취소', () => setConfirm(null))
          ] })
        ] }),
        building.id === 'main' && jsx('p', { style: style.muted, children: '양조실은 기상할 때 개소당 맥주·와인 각 1개를 생산하고 하루 5g 유지비를 내요. 층 확장은 16 → 20 → 24칸이에요.' })
      ] })
    ] });
  }
  let handle = null, root = null;
  function ConstructionTool_창열기() {
    if (handle) { handle.focus();return; }
    handle = api.ui.window({ id: 'blueprint', title: '설계/건축 · 건축 설계도', width: 920, height: 820,
      render(body) { body.style.background = '#0c1720';if (!root) root = f('constructionReactDOM').createRoot(body);root.render(jsx(ConstructionTool_설계화면, {})); },
      onClose() { root?.unmount();root = null;handle = null; } });
  }
  // 설계/건축은 가게의 현재 위치 목록에서 엽니다.
  window.addEventListener('keydown', e => {
    if (e.key !== 'Escape' || !handle) return;
    // 설계도에서 연 앞창이 먼저 Esc를 처리할 수 있게 해요.
    const z = Number(getComputedStyle(handle.el).zIndex);
    if ([...document.querySelectorAll('.wml-win')].some(win => win !== handle.el && Number(getComputedStyle(win).zIndex) > z)) return;
    e.preventDefault();e.stopImmediatePropagation();handle.close();
  }, true);
  function ConstructionTool_시설찾기(tree) {
    if (!React.isValidElement(tree)) return null;
    if (tree.type === f('constructionAccordion')) return tree;
    for (const child of React.Children.toArray(tree.props.children)) {
      const found = ConstructionTool_시설찾기(child);
      if (found) return found;
    }
    return null;
  }
  function ConstructionTool_시설만표시(tree) {
    const facility = ConstructionTool_시설찾기(tree);
    return facility ? React.cloneElement(facility, { open: true, onToggle: () => {} })
      : jsx('p', { style: style.muted, children: '시설 업그레이드를 불러올 수 없어요. 건축 설계도에서 시설을 선택해 주세요.' });
  }
  function filterLodgingPurchase(tree) {
    if (!React.isValidElement(tree)) return tree;
    if (core.publicAPI.hasLodgingProvider() && typeof tree.props.onClick === 'function' &&
        tree.props.onClick.toString().includes('buy_room2_upgrade')) return null;
    return tree.props.children == null ? tree : React.cloneElement(tree, {}, React.Children.map(tree.props.children, filterLodgingPurchase));
  }
  api.hook('constructionPrepPanel', {priority:-20000,after:filterLodgingPurchase});
  api.hook('constructionPrepPanel', { after(tree, [props]) {
    const facilitiesOnly = React.useContext(facilitiesContext);
    if (facilitiesOnly || props?.constructionFacilitiesOnly) return ConstructionTool_시설만표시(tree);
    if (!React.isValidElement(tree)) return tree;
    const children = React.Children.toArray(tree.props.children), facility = children.find(c => React.isValidElement(c) && c.type === f('constructionAccordion'));
    if (!facility) return tree;
    return React.cloneElement(tree, {}, children.map(c => c === facility ? jsx('div', { style: { marginBottom: 12 },
      children: ConstructionTool_버튼('시설 업그레이드 → 건축 설계도', ConstructionTool_창열기, false, { 'data-ct-facilities-link': true }) }, 'ct-upgrades') : c));
  } });
  // 준비 화면에 덧붙이는 다른 모드의 대출·운영 패널도 설계창 안에서는 제외해요.
  api.hook('constructionPrepPanel', { priority: -10000, after(tree) {
    const facilitiesOnly = React.useContext(facilitiesContext);
    return facilitiesOnly ? ConstructionTool_시설만표시(tree) : tree;
  } });
  // 가게의 현재 위치 목록에서는 방 이름만 표시하고 설계도용 게임 ID는 붙이지 않아요.
  function ConstructionTool_기본방이름(card, room) {
    const body = card.props.children;
    if (!React.isValidElement(body) || !Array.isArray(body.props.children)) return card;
    const parts = [...body.props.children], heading = parts[0];
    if (!React.isValidElement(heading)) return card;
    if (Array.isArray(heading.props.children) && React.isValidElement(heading.props.children[0])) {
      const titles = [...heading.props.children];
      titles[0] = React.cloneElement(titles[0], {}, room.label);
      parts[0] = React.cloneElement(heading, {}, titles);
    } else {
      parts[0] = React.cloneElement(heading, {}, room.label);
    }
    // 이전 flex 배치의 최소 너비를 제거해 추가 방과 같은 격자 너비에 맞춰요.
    // 바닐라의 방 음영과 테두리는 통일하고 재실 인물 표시는 원래 내용을 사용해요.
    const roomBody = React.cloneElement(body, { 'data-ct-location-card': room.id,
      style: { ...body.props.style, ...style.roomCard, background: ConstructionTool_방음영읽기(room), borderColor: '#666666' } }, parts);
    return React.cloneElement(card, { className: 'min-w-0', style: { minWidth: 0, height: '100%' }, 'data-ct-native-room': room.id }, roomBody);
  }
  function ConstructionTool_방카드(s, room) {
    return ConstructionTool_버튼(jsx(React.Fragment, { children: [jsx('div', { children: room.label }),
      jsx('div', { style: { color: '#a7b7c1', fontSize: 11.2, lineHeight: '14px' }, children: ConstructionTool_재실이름(s, room.id).join(', ') || '비어 있음' })] }),
      () => dispatch({ type: ID + '/move', roomId: room.id }), !f('constructionCanMove')(s),
      { 'data-ct-room': room.id, 'data-ct-location-card': room.id,
        style: { ...style.roomCard, background: '#293a43', borderColor: '#52727d', color: '#e7f3f5', opacity: 1 } });
  }
  function ConstructionTool_위치판변환(tree, s) {
    if (!React.isValidElement(tree) || tree.props['data-ct-location-overview']) return tree;
    const rows = tree.props.children;
    // Context Provider·Fragment 등으로 감싼 원본은 감싸는 요소를 보존하고 내부 위치판만 바꿔요.
    if (!Array.isArray(rows) || !React.isValidElement(rows[0]) || !React.isValidElement(rows[1]) || !React.isValidElement(rows[2]) ||
        !Array.isArray(rows[1].props.children) || rows[1].props.children.length < 5 ||
        !Array.isArray(rows[2].props.children) || rows[2].props.children.length < 4) {
      let changed = false;
      const children = React.Children.map(tree.props.children, child => {
        const next = ConstructionTool_위치판변환(child, s);if (next !== child) changed = true;return next;
      });
      return changed ? React.cloneElement(tree, {}, children) : tree;
    }
    const children = [...tree.props.children], header = children[0];if (!React.isValidElement(header)) return tree;
    const headings = React.Children.toArray(header.props.children), originals = new Map();
    for (const [index, ids] of [[1, ['bedroom', 'elena_room', 'bathroom', 'upstairs_hall', 'upstairs_room_2']], [2, ['taproom', 'kitchen', 'back_room', 'bathhouse']]]) {
      const row = children[index];if (!React.isValidElement(row) || !Array.isArray(row.props.children)) continue;
      row.props.children.forEach((card, i) => { if (React.isValidElement(card) && ids[i]) originals.set(ids[i], card); });
    }
    // 이 제목만 본문과 어울리는 14px로 줄이고 다른 화면의 제목 크기는 유지해요.
    const locationTitle = React.isValidElement(headings[0])
      ? React.cloneElement(headings[0], {
        'data-ct-location-title': true,
        style: { ...headings[0].props.style, fontSize: 14, lineHeight: 1.4, margin: 0 },
      })
      : jsx('span', {
        'data-ct-location-title': true,
        style: { fontSize: 14, lineHeight: 1.4 },
        children: headings[0],
      });
    const newHeader = React.cloneElement(header, { className: 'flex flex-wrap gap-2 items-center justify-between mb-2', 'data-ct-location-header': true },
      [locationTitle, ConstructionTool_버튼('설계/건축', ConstructionTool_창열기, false, { key: 'ct-open', 'data-ct-open': true, style: { padding: '3px 10px', fontSize: 12 } }), ...headings.slice(1)]);
    // 양조실은 이동창에서만 숨겨요. 설계도·생산·유지비용 방 목록은 그대로 사용해요.
    const rooms = core.rooms(s).filter(room => room.type !== 'brewery');
    const locationRows = [...core.plots.values()].map(plot => jsx('section', { className: 'mt-1.5', 'data-ct-floor': plot.id, children: [
      jsx('h3', { style: { color: '#91cdd6', fontSize: 11, marginBottom: 5 }, children: plot.label }),
      jsx('div', { 'data-ct-location-grid': plot.id, children: rooms.filter(r => r.floor === plot.id && !r.stored).map(room => {
        if (room.native && !room.external) return originals.has(room.id) ? jsx(React.Fragment, { children: ConstructionTool_기본방이름(originals.get(room.id), room) }, room.id) : null;
        return room.built ? jsx('div', { className: 'min-w-0', style: { minWidth: 0, height: '100%' }, children: ConstructionTool_방카드(s, room) }, room.id) : null;
      }) })
    ] }, plot.id));
    return React.cloneElement(tree, { 'data-ct-location-overview': true }, [newHeader, ...locationRows, ...children.slice(3)]);
  }
  api.hook('constructionLocationOverview', { priority: 100, after(tree) {
    const s = api.store.game();return s ? ConstructionTool_위치판변환(tree, s) : tree;
  } });
  api.hook('ActionPanel', { after(tree) {
    const s = api.store.game();if (!s || f('playerLocation')(s) !== UPPER || !core.hasUpper(s)) return tree;
    const blocked = !['service', 'last_call'].includes(s.phase) || !!s.pendingEvent || Object.values(s.activeScene || {}).some(Boolean);
    const patrons = s.customers.filter(c => f('locationOf')(s, c.id) === UPPER && !['leaving', 'gone'].includes(c.status));
    return jsx(React.Fragment, { children: [jsx('section', { style: style.panel, 'data-ct-upper-service': true, children: [
      jsx('h3', { children: '2층 홀 · 손님 응대' }), ...patrons.map(c => jsx('div', { style: style.flex, children: [jsx('span', { children: c.name }),
        ...[['greet', '인사', c.status === 'arrived'], ['take_order', '주문 받기', ['greeted', 'wants_more'].includes(c.status)], ['serve', '서빙', c.status === 'ordered'],
          ['apologize_out_of_stock', '재고 부족 사과', c.status === 'ordered']].filter(([, , show]) => show).map(([type, label]) =>
            ConstructionTool_버튼(label, () => dispatch({ type, customerId: c.id }), blocked, { key: type, 'data-ct-service': type }))
      ] }, c.id))
    ] }), tree] });
  } });
  // 등록된 모든 추가 방에 공통 출구를 제공합니다. 기본 행동 화면이 null이어도 표시합니다.
  // 외부 모드가 등록한 기존 방과 저장에서 복원된 추가 방도 같은 방 목록으로 판정합니다.
  api.hook('ActionPanel', { priority: -10000, after(tree) {
    const s = api.store.game();if (!s) return tree;
    const roomId = f('playerLocation')(s);
    const room = core.rooms(s).find(candidate => candidate.id === roomId && (!candidate.native || candidate.external));
    if (!room || roomId === 'taproom') return tree;
    // 교감 종료처럼 사건 자체가 같은 복귀 선택지를 제공하면 그 고유 처리를 사용합니다.
    // 비활성 공통 버튼이 기존의 동행 복귀 버튼과 중복되지 않게 합니다.
    if (s.pendingEvent?.choices?.some(choice => choice.label === '홀로 돌아가기')) return tree;
    const blocked = !!s.gameOver || !f('constructionCanMove')(s);
    return jsx(React.Fragment, { children: [jsx('section', { style: style.panel, 'data-ct-room-exit': roomId, children: [
      ConstructionTool_버튼('홀로 돌아가기', () => {
        const current = api.store.game();
        if (!current || current.gameOver || !f('constructionCanMove')(current)) return;
        // 원래 이동 액션으로 시간·동행·다른 모드의 이동 제한을 그대로 적용합니다.
        dispatch({ type: 'return_to_taproom' });
      }, blocked, { 'data-ct-return-hall': true }),
      jsx('p', { style: style.muted, children: blocked
        ? '진행 중인 사건·행동을 마치면 홀로 돌아갈 수 있어요.'
        : `${room.label}에서 1층 홀로 돌아갑니다.` })
    ] }), tree] });
  } });
};
