globalThis.ConstructionTool_모델초기화 = function ConstructionTool_모델초기화(api, ctx) {
  'use strict';
  const { nativeRooms, nativeLabel, types, existingRooms, plots, plotPolicies, canBuild, busy, log, registerLocation, evacuateHall, nativePresent, ownsLodging } = ctx;
  const ID = api.id, UPPER = 'ct_upper_hall', f = name => api.fn(name);
  const floors = ['upper', 'ground', 'basement'];
  const defaults = {
    bathroom: { floor: 'upper', cells: [0, 1] }, bedroom: { floor: 'upper', cells: [2, 3] },
    elena_room: { floor: 'upper', cells: [6, 7] }, upstairs_hall: { floor: 'upper', cells: [10, 11] },
    upstairs_room_2: { floor: 'upper', cells: [14, 15] }, ct_upper_hall: { floor: 'upper', cells: [8, 9, 12, 13] },
    taproom: { floor: 'ground', cells: [0, 1, 2, 4, 5, 6, 8, 9, 10, 12, 13, 14] },
    kitchen: { floor: 'ground', cells: [3, 7] }, back_room: { floor: 'ground', cells: [11, 15] },
    bathhouse: { floor: 'basement', cells: [2, 3, 6, 7] },
    brothel_cellar_1: { floor: 'basement', cells: [0, 1] },
    brothel_cellar_2: { floor: 'basement', cells: [4, 5] },
    brothel_break_room: { floor: 'basement', cells: [8, 9] }
  };
  const copy = value => structuredClone(value);
  const makeTable = (id, roomId, cells, premium = false) => ({ id, roomId, cells: [...cells], premium, active: true });
  function ConstructionTool_기본가구() {
    return [[2, 6], [1, 5], [10, 14], [9, 13]].map((cells, i) => makeTable('ct_table_' + (i + 1), 'taproom', cells));
  }
  function ConstructionTool_크기(d, floor, s) {
    const policy = plotPolicies.get(floor);
    if (!policy) return (plots.get(floor)?.slots || 16) + Math.min(2, d.floors[floor]?.expansions || 0) * 4;
    const size = policy.size(s, d);
    if (!Number.isInteger(size) || size < 0 || size > 24) throw Error('추가 부지 면적은 0~24칸 정수여야 해요.');
    return size;
  }
  function ConstructionTool_사용칸(d, floor, exclude, s) {
    const result = new Set();
    for (const [id, p] of Object.entries(d.placements)) {
      if (!nativePresent(s, id)) continue;
      if (existingRooms.get(id)?.isPresent?.(s) === false) continue;
      if (id !== exclude && p.floor === floor) for (const cell of p.cells) result.add(cell);
    }
    for (const room of d.rooms) if (room.id !== UPPER && room.id !== exclude && room.floor === floor) for (const cell of room.cells || []) result.add(cell);
    return result;
  }
  function ConstructionTool_직사각형(cell, width, height, limit) {
    if (!Number.isInteger(cell) || cell < 0 || !Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 || cell % 4 + width > 4) return null;
    const cells = [];
    for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) cells.push(cell + y * 4 + x);
    return cells.every(i => i < limit) ? cells : null;
  }
  function ConstructionTool_빈자리탐색(d, floor, width, height, s) {
    const used = ConstructionTool_사용칸(d, floor, null, s);
    for (let i = 0; i < ConstructionTool_크기(d, floor, s); i++) {
      const cells = ConstructionTool_직사각형(i, width, height, ConstructionTool_크기(d, floor, s));
      if (cells && cells.every(c => !used.has(c))) return cells;
    }
    return null;
  }
  function ConstructionTool_자료(s) {
    const old = s?.mods?.[ID] || {};
    if (old.schema === 2) {
      const d = { ...old, floors: { ...old.floors }, placements: { ...old.placements }, furniture: [...(old.furniture || [])], rooms: [...(old.rooms || [])] };
      for (const floor of plots.keys()) d.floors[floor] = { expansions: 0, ...d.floors[floor] };
      for (const id of ['brothel_cellar_1', 'brothel_cellar_2', 'brothel_break_room']) if (!d.placements[id]) d.placements[id] = copy(defaults[id]);
      for (const [id, def] of existingRooms) if (!d.placements[id]) d.placements[id] = copy(defaults[id] || { floor: def.slot.split(':')[0], cells: def.cells || [Number(def.slot.split(':')[1])] });
      return d;
    }
    const d = { ...old, schema: 2, floors: Object.fromEntries([...plots.keys()].map(p => [p, { expansions: 0 }])),
      placements: copy(defaults),
      furniture: ConstructionTool_기본가구(), rooms: [], nextId: 5, lastWakeDay: s?.day ?? 1, bookingDay: null,
      legacy: old.schema ? copy(old) : undefined };
    // 새 게임·구형 저장에도 이미 등록된 외부 건물의 기본 배치를 채웁니다.
    for(const [id,def] of existingRooms)if(!d.placements[id])d.placements[id]=copy(defaults[id]||{
      floor:def.slot.split(':')[0],cells:def.cells||[Number(def.slot.split(':')[1])]});
    const legacyRooms = Array.isArray(old.rooms) ? old.rooms : [];
    const upper = legacyRooms.find(r => r.id === UPPER);
    if (upper) {
      d.rooms.push({ ...upper, floor: 'upper', cells: [...defaults[UPPER].cells], slot: 'upper:8' });
      const target = Math.max(0, old.openUpper ?? old.upperTables ?? 2);
      if (target > 0) d.furniture.push(makeTable('ct_table_' + d.nextId++, UPPER, [8, 12]));
      if (target > 2) d.furniture.push(makeTable('ct_table_' + d.nextId++, UPPER, [9, 13], target > 4));
      if (target > 5) d.furniture = d.furniture.map(t => t.roomId === UPPER ? { ...t, premium: true } : t);
    }
    // Old tables were one seat each. Preserve purchased seating without charging again.
    let target = Math.min(18, Math.max(8, old.tables || 8));
    for (let i = 0; i < 4 && target > 8; i++) { d.furniture[i] = { ...d.furniture[i], premium: true }; target--; }
    for (const cells of [[0, 4], [8, 12]]) if (target > 8) {
      const seats = Math.min(3, target - 8);
      d.furniture.push(makeTable('ct_table_' + d.nextId++, 'taproom', cells, seats > 2)); target -= seats;
    }
    if (Number.isFinite(old.openTables)) {
      let left = old.openTables;
      d.furniture = d.furniture.map(t => {
        if (t.roomId !== 'taproom') return t;
        const seats = t.premium ? 3 : 2, active = left > 0; left -= active ? seats : 0;
        return { ...t, active };
      });
    }
    for (const room of legacyRooms.filter(r => r.id !== UPPER)) {
      const floor = room.slot?.split(':')[0] || 'basement', def = types.get(room.type);
      let cells = ConstructionTool_빈자리탐색(d, floor, def?.width || 1, def?.height || 1, s);
      if (!cells && floors.includes(floor)) {
        d.floors[floor] = { expansions: 2 }; cells = ConstructionTool_빈자리탐색(d, floor, def?.width || 1, def?.height || 1, s);
      }
      d.rooms.push({ ...room, floor, cells: cells || [], slot: `${floor}:${cells?.[0] ?? 0}`, stored: !cells });
    }
    return d;
  }
  function ConstructionTool_저장(s, d) { return { ...s, mods: { ...s.mods, [ID]: d } }; }
  function ConstructionTool_방목록(s) {
    const d = ConstructionTool_자료(s);
    const base = nativeRooms.filter(r => nativePresent(s, r.id)).map(r => {
      const p = d.placements[r.id];
      const built = r.id === 'bathhouse' ? !!s?.tavern?.hasBathhouse : r.id === 'upstairs_hall' ? !!s?.tavern?.hasRoom :
        r.id === 'upstairs_room_2' ? !!s?.tavern?.hasRoom2 : r.id === 'back_room' ? s?.tavern?.backRoomReady !== false : true;
      return { ...r, label:nativeLabel(r.id,s), ...p, cells: [...p.cells], slot: `${p.floor}:${p.cells[0]}`, built, fixed: true };
    });
    for (const [id, def] of existingRooms) {
      if (def.isPresent?.(s) === false) continue;
      const p = d.placements[id];
      base.push({ id, type: id, label: def.label, ...p, slot: `${p.floor}:${p.cells[0]}`, native: true, external: true, built: def.isBuilt(s) });
    }
    for (const [id, label] of [['brothel_cellar_1', '지하방1'], ['brothel_cellar_2', '지하방2'], ['brothel_break_room', '휴게실']]) {
      if (!existingRooms.has(id)) {
        const p = d.placements[id];
        base.push({ id, type: id, label, ...p, slot: `${p.floor}:${p.cells[0]}`, native: true, external: true, built: false, planned: true });
      }
    }
    base.push(...d.rooms.map(r => {
      const p = r.id === UPPER ? d.placements[UPPER] : r;
      const def=types.get(r.type);
      return { ...r, staffRole:def?.staffRole||null,template:def?.template||null,
        floor: p.floor, cells: [...p.cells], label: def?.label || r.label || r.id,
        slot: `${p.floor}:${p.cells[0]}`, native: false, built: true, fixed: r.id === UPPER };
    }));
    if (!d.rooms.some(r => r.id === UPPER)) base.push({ id: UPPER, type: 'upper_hall', label: '2층 홀', ...d.placements[UPPER], slot: 'upper:8', built: false, fixed: true, native: false, planned: true });
    return base;
  }
  function ConstructionTool_정원(s) {
    const d = ConstructionTool_자료(s), upperBuilt = d.rooms.some(r => r.id === UPPER);
    const tableCapacity = (id, onlyActive) => d.furniture.filter(t => t.roomId === id && (!onlyActive || t.active !== false)).reduce((sum, t) => sum + (t.premium ? 3 : 2), 0);
    const ground = tableCapacity('taproom', true), upper = upperBuilt ? tableCapacity(UPPER, true) : 0;
    return { ground, upper, total: ground + upper, groundOwned: tableCapacity('taproom', false), upperOwned: tableCapacity(UPPER, false) };
  }
  function ConstructionTool_면적(d) { return d.rooms.some(r => r.id === UPPER) ? d.placements[UPPER].cells.length : 0; }
  function ConstructionTool_유지비(s) {
    const d = ConstructionTool_자료(s), brewery = d.rooms.filter(r => r.type === 'brewery' && !r.stored).length;
    return { hall: ConstructionTool_면적(d), brewery: brewery * 5, total: ConstructionTool_면적(d) + brewery * 5, breweryCount: brewery };
  }
  function ConstructionTool_결제(s, d, cost, message) {
    if (!Number.isFinite(cost) || cost < 0 || s.economy.gold < cost) return log(s, '골드가 부족해요.');
    return log(ConstructionTool_저장({ ...s, economy: { ...s.economy, gold: s.economy.gold - cost } }, d), message);
  }
  function ConstructionTool_공사(s, a) {
    if (!canBuild(s)) return log(s, '공사·배치·가구 변경은 사건이 없는 영업 준비 시간에만 가능해요.');
    const d = ConstructionTool_자료(s), floor = a.floor || a.slot?.split(':')[0], cell = a.cell ?? Number(a.slot?.split(':')[1]);
    const roomFloor = floor || ConstructionTool_방목록(s).find(room => room.id === a.roomId)?.floor;
    const policy = plotPolicies.get(roomFloor), reason = policy?.check?.(s, a);
    if (reason) return log(s, reason);
    if (a.operation === 'expand-floor' && policy) return policy.expand ? policy.expand(s, a) : s;
    if (a.operation === 'expand-floor') {
      if (!floors.includes(floor) || d.floors[floor].expansions >= 2 || d.floors[floor].job) return s;
      d.floors[floor] = { ...d.floors[floor], job: { orderedDay: s.day, dueDay: s.day + 2, cost: 300 } };
      return ConstructionTool_결제(s, d, 300, `${floor === 'upper' ? '2층' : floor === 'ground' ? '1층' : '지하'} 4×1 확장 공사 시작. ${s.day + 2}일 기상 후 완공돼요. (300골드)`);
    }
    if (a.operation === 'expand-hall') {
      if (!['ground', 'upper'].includes(floor)) return s;
      const id = floor === 'upper' ? UPPER : 'taproom';
      if (floor === 'upper' && !d.rooms.some(r => r.id === UPPER)) return s;
      const used = ConstructionTool_사용칸(d, floor, id, s), p = d.placements[id];
      if (!Number.isInteger(cell) || cell < 0 || cell >= ConstructionTool_크기(d, floor, s) || used.has(cell) || p.cells.includes(cell)) return s;
      if (!p.cells.some(c => Math.abs(Math.floor(c / 4) - Math.floor(cell / 4)) + Math.abs(c % 4 - cell % 4) === 1)) return log(s, '기존 홀에 맞닿은 빈칸만 홀로 편입할 수 있어요.');
      d.placements[id] = { ...p, cells: [...p.cells, cell].sort((a, b) => a - b) };
      return log(ConstructionTool_저장(s, d), '빈칸을 홀로 편입했어요. 2층 홀 유지비는 면적에 비례해요.');
    }
    if (a.operation === 'build') {
      const def = types.get(a.roomType);
      if (!def || (!def.multiple && d.rooms.some(r => r.type === def.id))) return s;
      const roomFloor = def.id === 'upper_hall' ? 'upper' : floor;
      if (!def.plots.includes(roomFloor)) return s;
      const reason = def.canBuild?.(s); if (reason) return log(s, reason);
      if (s.economy.gold < def.cost) return log(s, '건축 자금이 부족해요.');
      const cells = def.id === 'upper_hall' ? [...d.placements[UPPER].cells] :
        ConstructionTool_직사각형(cell, a.rotate ? def.height || 1 : def.width || 1, a.rotate ? def.width || 1 : def.height || 1, ConstructionTool_크기(d, roomFloor, s));
      const used = ConstructionTool_사용칸(d, roomFloor, null, s);
      if (!cells || (def.id !== 'upper_hall' && cells.some(c => used.has(c)))) return log(s, '방의 면적이 부족하거나 다른 시설과 겹쳐요.');
      const id = def.multiple ? `${def.roomId}_${d.nextId++}` : def.roomId;
      registerLocation(id, def.label);
      d.rooms.push({ id, type: def.id, label: def.label, floor: roomFloor, cells, slot: `${roomFloor}:${cells[0]}`, paid: def.cost });
      return ConstructionTool_결제({ ...s, locations: { ...s.locations, [id]: { occupants: [], meta: {} } } }, d, def.cost, `${def.label} 건설 완료. (${def.cost}골드)`);
    }
    if (a.operation === 'move') {
      const room = ConstructionTool_방목록(s).find(r => r.id === a.roomId);
      if (!room || room.fixed || room.floor !== floor || busy(s, room.id)) return log(s, '고정 시설·사용 중인 시설은 옮길 수 없고, 층을 바꿀 수 없어요.');
      const p = d.placements[room.id] || d.rooms.find(r => r.id === room.id);
      const origin = Math.min(...p.cells), dx = cell % 4 - origin % 4, dy = Math.floor(cell / 4) - Math.floor(origin / 4);
      const width = Math.max(...p.cells.map(c => c % 4)) - Math.min(...p.cells.map(c => c % 4)) + 1;
      const height = Math.max(...p.cells.map(c => Math.floor(c / 4))) - Math.min(...p.cells.map(c => Math.floor(c / 4))) + 1;
      const cells = a.rotate ? ConstructionTool_직사각형(cell, height, width, ConstructionTool_크기(d, floor, s)) : p.cells.map(c => c + dx + dy * 4);
      const used = ConstructionTool_사용칸(d, floor, room.id, s);
      if (!cells || (!a.rotate && p.cells.some(c => c % 4 + dx < 0 || c % 4 + dx > 3)) || cells.some(c => c < 0 || c >= ConstructionTool_크기(d, floor, s) || used.has(c))) return log(s, '배치가 겹치거나 층의 범위를 벗어나요.');
      if (d.placements[room.id]) d.placements[room.id] = { ...p, cells };
      else d.rooms = d.rooms.map(r => r.id === room.id ? { ...r, cells, slot: `${floor}:${cells[0]}` } : r);
      return ConstructionTool_저장(s, d);
    }
    if (a.operation === 'demolish') {
      const room = d.rooms.find(r => r.id === a.roomId), def = room && types.get(room.type);
      if (!room || !def || busy(s, room.id) || room.renter) return log(s, '사용 중이거나 투숙 중인 시설은 철거할 수 없어요.');
      const reason = def.canDemolish?.(s, room); if (reason) return log(s, reason);
      d.rooms = d.rooms.filter(r => r.id !== room.id);
      d.furniture = d.furniture.filter(t => t.roomId !== room.id);
      const refund = Math.floor((room.paid || 0) / 4);
      return log(ConstructionTool_저장({ ...s, economy: { ...s.economy, gold: s.economy.gold + refund },
        locations: { ...s.locations, [room.id]: { occupants: [], meta: {} } } }, d), `시설 철거. 건축비 ${refund}골드 회수. 실내 테이블은 함께 철거돼요.`);
    }
    return s;
  }
  function ConstructionTool_가구(s, a) {
    if (!canBuild(s)) return s;
    let d = ConstructionTool_자료(s), table = d.furniture.find(t => t.id === a.tableId);
    const occupied = id => s.customers.some(c => !['gone', 'leaving'].includes(c.status) &&
      (c.constructionSeat || f('locationOf')(s, c.id)) === id);
    let evacuated = false;
    if (table) {
      const validTableAction = ['toggle', 'remove', 'move'].includes(a.operation) ||
        (a.operation === 'upgrade' && !table.premium);
      if (!validTableAction) return s;
      s = evacuateHall(s, table.roomId);
      evacuated = true;
      d = ConstructionTool_자료(s);
      table = d.furniture.find(t => t.id === a.tableId);
      if (occupied(table.roomId)) return log(s, '이동할 수 없는 손님이 있는 홀의 가구는 변경할 수 없어요.');
      if (a.operation === 'upgrade' && !table.premium) {
        d.furniture = d.furniture.map(t => t.id === table.id ? { ...t, premium: true } : t);
        return ConstructionTool_결제(s, d, 20, '고급 테이블로 업그레이드했어요. 3명 착석 가능. (20골드)');
      }
      if (a.operation === 'toggle') {
        d.furniture = d.furniture.map(t => t.id === table.id ? { ...t, active: t.active === false } : t);
        return ConstructionTool_저장(s, d);
      }
      if (a.operation === 'remove') { d.furniture = d.furniture.filter(t => t.id !== table.id); return ConstructionTool_저장(s, d); }
    }
    if (!['buy', 'move'].includes(a.operation)) return s;
    const roomId = table?.roomId || a.roomId, room = ConstructionTool_방목록(s).find(r => r.id === roomId);
    if (!room || !['taproom', UPPER].includes(roomId) || room.built === false) return s;
    if (!evacuated) {
      s = evacuateHall(s, roomId);
      d = ConstructionTool_자료(s);
      table = d.furniture.find(t => t.id === a.tableId);
    }
    if (occupied(roomId)) return log(s, '이동할 수 없는 손님이 있는 홀의 가구는 변경할 수 없어요.');
    const cells = ConstructionTool_직사각형(a.cell, a.rotate ? 2 : 1, a.rotate ? 1 : 2, ConstructionTool_크기(d, room.floor, s));
    const usedFurniture = new Set(d.furniture.filter(t => t.id !== table?.id && t.roomId === roomId).flatMap(t => t.cells));
    if (!cells || cells.some(c => !room.cells.includes(c) || usedFurniture.has(c))) return log(s, '테이블은 홀 안의 연속된 빈 2칸에 놓아야 해요.');
    if (table) {
      d.furniture = d.furniture.map(t => t.id === table.id ? { ...t, cells } : t);
      return ConstructionTool_저장(s, d);
    }
    const cost = a.premium ? 50 : 30;
    d.furniture.push(makeTable('ct_table_' + d.nextId++, roomId, cells, !!a.premium));
    return ConstructionTool_결제(s, d, cost, `${a.premium ? '고급' : '기본'} 테이블 설치. ${a.premium ? 3 : 2}명 착석 가능. (${cost}골드)`);
  }
  function ConstructionTool_기상(s) {
    let d = ConstructionTool_자료(s);
    if (d.lastWakeDay >= s.day) return s;
    d.lastWakeDay = s.day;
    for (const floor of floors) {
      const data = d.floors[floor];
      if (data.job && s.day >= data.job.dueDay) {
        d.floors[floor] = { expansions: Math.min(2, data.expansions + 1), job: null };
        s = log(s, `${floor === 'upper' ? '2층' : floor === 'ground' ? '1층' : '지하'} 확장 공사 완료. ${ConstructionTool_크기(d, floor, s)}칸을 사용할 수 있어요.`);
      }
    }
    if (!ownsLodging()) {
    const previousGuestIds = d.rooms.filter(room => room.type === 'guest_room').map(room => room.renter?.customerId).filter(Boolean);
    d.rooms = d.rooms.map(room => room.type === 'guest_room' ? { ...room, renter: undefined } : room);
    const extraIds = new Set(d.rooms.filter(r => r.type === 'guest_room').map(r => r.id));
    const checkedOut = new Set([...previousGuestIds, ...s.customers.filter(c => extraIds.has(c.constructionGuestRoom)).map(c => c.id)]);
    s = { ...s, customers: s.customers.filter(c => !checkedOut.has(c.id)),
      locations: Object.fromEntries(Object.entries(s.locations).map(([id, r]) => [id, { ...r, occupants: (r.occupants || []).filter(o => !checkedOut.has(o)) }])) };
    }
    s = ConstructionTool_저장(s, d);
    const upkeep = ConstructionTool_유지비(s), paid = Math.min(s.economy.gold, upkeep.total), short = upkeep.total - paid;
    s = { ...s, supplies: { ...s.supplies, beer: (s.supplies.beer || 0) + upkeep.breweryCount, wine: (s.supplies.wine || 0) + upkeep.breweryCount },
      economy: { ...s.economy, gold: s.economy.gold - paid, debt: (s.economy.debt || 0) + short } };
    if (upkeep.total || upkeep.breweryCount) s = log(s, `기상 정산: 2층 홀 ${upkeep.hall} + 양조실 ${upkeep.brewery} = 유지비 ${upkeep.total}골드. 양조실에서 맥주·와인 각 ${upkeep.breweryCount}개 생산.${short ? ` 부족액 ${short}골드는 빚에 더해요.` : ''}`);
    return s;
  }
  function ConstructionTool_추가숙박(s, nativeRoll) {
    let d = ConstructionTool_자료(s);
    if (d.bookingDay === s.day || !['service', 'last_call'].includes(s.phase)) return s;
    d.bookingDay = s.day;
    for (const room of d.rooms.filter(r => r.type === 'guest_room' && !r.stored && !r.renter)) {
      if ((s.locations?.[room.id]?.occupants || []).some(id => id === f('playerId') || s.characters?.[id])) continue;
      const original = s.tavern || {}, projected = { ...s, tavern: { ...original, hasRoom2: true, tonightRenter2: undefined } };
      const result = nativeRoll(projected), renter = result.tavern?.tonightRenter2;
      s = { ...result, tavern: { ...result.tavern, hasRoom2: original.hasRoom2, tonightRenter2: original.tonightRenter2 } };
      if (renter?.customerId) {
        s = { ...s, customers: s.customers.map(c => c.id === renter.customerId ? { ...c, constructionGuestRoom: room.id } : c) };
        s = f('moveOccupant')(s, renter.customerId, room.id);
        d.rooms = d.rooms.map(r => r.id === room.id ? { ...r, renter: { ...renter, nightsRemaining: 1 } } : r);
        s = log(s, `${room.label}에 ${renter.name}이(가) 1박 입주했어요. 숙박료 ${renter.rentPaid}골드는 기본 게임 규칙으로 받았어요.`);
      }
    }
    return ConstructionTool_저장(s, d);
  }
  function ConstructionTool_도면(s, floor) {
    const d = ConstructionTool_자료(s);
    return { floor, size: ConstructionTool_크기(d, floor, s), expansion: plotPolicies.get(floor)?.expansion?.(s) || null,
      expansions: d.floors[floor]?.expansions || 0, job: d.floors[floor]?.job || null,
      rooms: ConstructionTool_방목록(s).filter(r => r.floor === floor && !r.stored),
      tables: d.furniture.filter(t => (t.roomId === UPPER ? 'upper' : 'ground') === floor) };
  }
  return { defaults, data: ConstructionTool_자료, rooms: ConstructionTool_방목록, capacity: ConstructionTool_정원,
    construct: ConstructionTool_공사, table: ConstructionTool_가구, wake: ConstructionTool_기상,
    lodging: ConstructionTool_추가숙박, blueprint: ConstructionTool_도면, upkeep: ConstructionTool_유지비,
    save: ConstructionTool_저장, floorSize: ConstructionTool_크기 };
};
