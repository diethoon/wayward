// 실행: node wml/mods/construction-tool/tests/facilities.mjs [--all-mods] [--mobile] [--zip]
// 격리 저장소에서 실제 설계창 탭·원래 구매 액션·다른 모드의 props 생략을 검사합니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { parseMod, readModsJs } from '../../../../MCP/lib/mods.mjs';
import { playStart, playEval, playReload, playStatus, playScreenshot, shutdown } from '../../../../MCP/lib/play.mjs';

const all=process.argv.includes('--all-mods'),mobile=process.argv.includes('--mobile');
const meta=parseMod(fs.readFileSync('wml/mods/construction-tool/mod.js','utf8')).meta;
const qualityTable=/\bconst\s+([\w$]+)=\[\{id:"upgrade_interior"/.exec(fs.readFileSync('Wayward_WML_ko.html','utf8'))?.[1];
assert.ok(qualityTable,'현재 게임의 시설 업그레이드 표를 찾지 못했어요.');
const ids=fs.readdirSync('wml/mods',{withFileTypes:true}).filter(d=>d.isDirectory()).flatMap(d=>{
  const file=`wml/mods/${d.name}/mod.js`;
  return fs.existsSync(file)?[parseMod(fs.readFileSync(file,'utf8')).meta?.id].filter(Boolean):[];
});
const disabled=Object.fromEntries([...ids,...readModsJs().entries.map(e=>e.id)].map(id=>[id,false]));
async function evaluate(code){const r=await playEval({code});assert.equal(r.pageErrorsSoFar,0,JSON.stringify(r));return r.result}
try{
  let started=await playStart({mods:all?{}:{...disabled,'addon-compat':true,'construction-tool':true},
    viewport:mobile?{width:390,height:844}:{width:1400,height:950}});
  assert.deepEqual(started.failed,[]);
  if(process.argv.includes('--zip')){
    const installed=await evaluate(`
      const file={path:'construction-tool-${meta.version}-20261101.zip',blob:await(await fetch('wml/mods/construction-tool/construction-tool-${meta.version}-20261101.zip')).blob()};
      const append=Node.prototype.appendChild;
      Node.prototype.appendChild=function(node){
        if(node.tagName==='SCRIPT'&&node.src&&new URL(node.src,location.href).pathname.endsWith('/wml/mods/construction-tool/mod.js')){
          queueMicrotask(()=>node.dispatchEvent(new Event('error')));return node;
        }return append.call(this,node);
      };
      try{return await WML.install([file])}finally{Node.prototype.appendChild=append}
    `);
    assert.equal(installed[0].version,meta.version);assert.equal(installed[0].mode,'browser');
    started=await playReload({});assert.deepEqual(started.failed,[]);
  }
  await evaluate(`
    const dev=WML.dev();dev.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true});
    dev.store.get().newGame();await new Promise(r=>setTimeout(r,100));
    [...document.querySelectorAll('button')].find(b=>b.textContent.trim()==='건너뛰기')?.click();
    dev.store.update(s=>({...s,day:1,slot:840,phase:'prep',pendingEvent:undefined,errandSession:undefined,activeScene:{},
      economy:{...s.economy,gold:5000,debt:1000},tavern:{...s.tavern,hasRoom:false,hasRoom2:false,hasBathhouse:false,backRoomReady:false,qualityUpgrades:[]}}));
    await new Promise(r=>setTimeout(r,120));
    if(![...document.querySelectorAll('[data-ct-open]')].some(b=>b.getBoundingClientRect().width>0)){
      [...document.querySelectorAll('#root button')].find(b=>b.getBoundingClientRect().width>0&&b.textContent.trim()==='가게')?.click();
      await new Promise(r=>setTimeout(r,100));
    }
    const button=[...document.querySelectorAll('[data-ct-open]')].find(b=>b.getBoundingClientRect().width>0);
    if(!button)throw Error('설계/건축 열기 버튼 없음');button.click();await new Promise(r=>setTimeout(r,120));
    globalThis.FacilityTest={dev,sleep:()=>new Promise(r=>setTimeout(r,100)),check:(v,m)=>{if(!v)throw Error(m)},
      state:()=>{const s=dev.store.game();return JSON.stringify({slot:s.slot,phase:s.phase,economy:s.economy,supplies:s.supplies,tavern:s.tavern})}};
    return true;
  `);
  const result=await evaluate(`
    const {dev,sleep,check,state}=FacilityTest,passed=[],before=state();
    const tab=id=>document.querySelector('[data-ct-tab="'+id+'"]');
    const facilities=()=>document.querySelector('[data-ct-facilities]');
    const verify=()=>{
      const node=facilities();check(node,'시설 전용 영역 없음');
      check(node.innerText.includes('선술집 품질'),'시설 구매 화면 누락');
      check(!/오후 영업 준비|물자 채우기|전액 상환|15분 보내기|준비된 요리/.test(node.innerText),'영업 준비 내용이 설계창에 표시됨');
      check(!node.querySelector('[data-ct-facilities-link]'),'설계창 안에 재귀 바로가기 표시');
      check(node.querySelectorAll('input[type="number"]').length===0,'상환/물자 입력칸 표시');
      check(!node.querySelector('[data-npc-prep-debt]'),'NPC 영업 준비 부채 패널 표시');
    };
    tab('upgrades').click();await sleep();verify();
    check(state()===before,'탭 열기로 게임 자료 변경');
    const native=[...document.querySelectorAll('#root h2')].find(h=>h.textContent.trim()==='오후 영업 준비');
    check(native?.parentElement.innerText.includes('물자 채우기'),'원래 이야기의 영업 준비 내용 소실');
    check(native?.parentElement.querySelector('[data-ct-facilities-link]'),'이야기의 설계도 바로가기 소실');
    passed.push('facilities only; native story preparation intact; no state change');
    for(let i=0;i<3;i++){tab('blueprint').click();await sleep();check(document.querySelector('[data-ct-grid]'),'설계도 복귀 실패');tab('upgrades').click();await sleep();verify()}
    passed.push('repeated blueprint/facilities switches');

    const raw=WML.status().modSymbols['construction-tool'].constructionPrepPanel,original=dev.engine[raw];
    dev.engine[raw]=function(){return original()};
    try{tab('blueprint').click();await sleep();tab('upgrades').click();await sleep();verify()}
    finally{dev.engine[raw]=original}
    passed.push('component wrapper discarding props');

    const quality=dev.fn(${JSON.stringify(qualityTable)}).find(q=>q.id==='upgrade_interior');check(quality,'검증할 원래 시설 없음');
    dev.store.update(s=>({...s,economy:{...s.economy,gold:0}}));await sleep();verify();
    let purchase=[...facilities().querySelectorAll('button')].find(b=>b.textContent.includes(quality.label));
    check(purchase?.disabled,'금화 부족 구매 버튼 활성화');
    const poor=state();purchase.click();await sleep();check(state()===poor,'금화 부족 구매로 상태 변경');
    dev.store.update(s=>({...s,economy:{...s.economy,gold:5000}}));await sleep();
    const actions=[],undo=dev.hook('reduceGameAction',{priority:10000,before([s,a]){if(a.type==='buy_quality_upgrade')actions.push(a)}});
    try{purchase=[...facilities().querySelectorAll('button')].find(b=>b.textContent.includes(quality.label));check(purchase&&!purchase.disabled,'시설 구매 비활성');purchase.click();await sleep()}
    finally{undo()}
    check(actions.length===1&&actions[0].upgradeId===quality.id,'원래 시설 구매 액션 불일치/중복');
    check(dev.store.game().economy.gold===5000-quality.cost,'원래 시설 가격과 차감 불일치');
    check(dev.store.game().tavern.qualityUpgrades.includes(quality.id),'시설 구매값 미저장');
    check(![...facilities().querySelectorAll('button')].some(b=>b.textContent.includes(quality.label)),'구매한 시설 중복 표시');
    passed.push('native purchase dispatch once, original price, insufficient funds and purchased-item update');

    const purchased=structuredClone(dev.store.game());
    for(const phase of ['service','last_call','closed','bedroom']){
      dev.store.update(s=>({...s,phase}));await sleep();
      const panel=document.querySelector('[data-ct-window]');
      check(!facilities()&&panel.innerText.includes('기존 시설 구매는 영업 준비 시간에 가능해요.'),'개장 후 시설 구매 제한 누락');
    }
    dev.store.update(()=>({...structuredClone(purchased),phase:'prep',pendingEvent:{type:'wife_conversation',customerName:'시험',text:'사건 검사',choices:[{id:'cancel',label:'취소'}]}}));await sleep();
    check(!facilities(),'사건 중 시설 구매 표시');
    dev.store.update(()=>purchased);await sleep();verify();passed.push('service/last-call/closed/bedroom and pending-event restrictions');
    dev.store.get().saveToSlot(0);dev.store.get().loadFromSlot(0);await sleep();verify();
    check(dev.store.game().tavern.qualityUpgrades.includes(quality.id),'저장/불러오기 시설 구매 소실');
    passed.push('save/load purchased facilities');
    return{passed,loaded:WML.status().loaded.length,hStatus:WML.status().loaded.includes('h-status'),npc:WML.status().loaded.includes('npc-simulator')};
  `);
  if(all)assert.equal(result.hStatus,true); // NPC Simulator는 현재 기본 활성 목록에 없어요.
  const profile=`facilities-${mobile?'mobile':'desktop'}-${all?'all':'minimal'}`;
  await evaluate(`document.querySelector('[data-ct-facilities]').scrollIntoView({block:'start'});return true;`);
  fs.writeFileSync(`wml/mods/construction-tool/tests/${profile}.jpg`,Buffer.from(await playScreenshot({}),'base64'));
  const final=await playStatus({});assert.deepEqual(final.failed,[]);assert.deepEqual(final.pageErrors,[]);
  console.log(JSON.stringify({profile,version:meta.version,zip:process.argv.includes('--zip'),...result}));
}finally{await shutdown()}
process.exit(0);
