// 실행: node wml/mods/construction-tool/tests/regression.mjs [--integrated] [--mobile] [--zip]
// MCP의 격리 브라우저 저장소를 사용해요. 사용자 세이브·공용 파일을 변경하지 않아요. seed=1138.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { playStart, playEval, playReload, playStatus, playScreenshot, shutdown } from '../../../../MCP/lib/play.mjs';
import { checkMod } from '../../../../MCP/lib/check.mjs';
import { parseMod } from '../../../../MCP/lib/mods.mjs';
const integrated=process.argv.includes('--integrated'), mobile=process.argv.includes('--mobile');
const ids=['addon-compat','construction-tool',...(integrated?['brothel','construction-tool-compatible-brothel']:[])];
const evaluate=async code=>(await playEval({code})).result;
async function ConstructionTool_검사(name,code){const r=await evaluate(code);console.log(name,JSON.stringify(r));assert.ok(r&&Object.values(r).every(v=>v===true),name+': '+JSON.stringify(r));}
try{
  for(const id of ids)assert.ok(checkMod(id).ok,id);
  const disabled=Object.fromEntries(fs.readdirSync('wml/mods',{withFileTypes:true}).filter(d=>d.isDirectory()).map(d=>[d.name,false]));
  await playStart({mods:{...disabled,...Object.fromEntries(ids.map(id=>[id,true]))},viewport:mobile?{width:390,height:844}:{width:1500,height:1000}});
  await evaluate(`localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify(ids)}));return true;`);
  if(process.argv.includes('--zip')){
    const packages=['construction-tool',...(integrated?['construction-tool-compatible-brothel']:[])].map(id=>
      [id,parseMod(fs.readFileSync('wml/mods/'+id+'/mod.js','utf8')).meta.version]);
    const installed=await evaluate(`
      const packages=${JSON.stringify(packages)},files=await Promise.all(packages.map(async([id,v])=>({path:id+'.zip',blob:await(await fetch('wml/mods/'+id+'/'+id+'-'+v+'-20261101.zip')).blob()})));
      const append=Node.prototype.appendChild;Node.prototype.appendChild=function(node){
        if(node.tagName==='SCRIPT'&&node.src&&packages.some(([id])=>new URL(node.src,location.href).pathname.endsWith('/wml/mods/'+id+'/mod.js'))){
          queueMicrotask(()=>node.dispatchEvent(new Event('error')));return node;
        }return append.call(this,node);
      };try{return await WML.install(files);}finally{Node.prototype.appendChild=append;}
    `);
    assert.equal(installed.length,packages.length);
    assert.ok(installed.every(item=>item.mode==='browser'),JSON.stringify(installed));
  }
  const loaded=await playReload({});assert.deepEqual(loaded.failed,[]);for(const id of ids)assert.ok(loaded.loaded.includes(id),JSON.stringify(loaded));
  await evaluate(`
    globalThis.dev=WML.dev();globalThis.ct=WML.use('construction-tool');
    let seed=1138;Math.random=()=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return(seed>>>0)/4294967296};
    dev.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true});
    dev.store.get().newGame();dev.fn('store').setState({started:true,selectingArchetype:false,selectingBuilder:false,selectingPicks:false});
    await new Promise(r=>setTimeout(r,80));[...document.querySelectorAll('button')].find(b=>b.textContent.trim()==='건너뛰기')?.click();
    if(globalThis.__waywardBrothelPublic){const b=__waywardBrothelPublic;b.getConfig().enabled=false;b.getConfig().workers.forEach(w=>w.enabled=false);b.getRuntime().clear();b.saveConfig();}
    dev.store.update(s=>({...s,day:1,slot:600,phase:'prep',pendingEvent:undefined,activeScene:{},errandSession:undefined,activeShoppingSession:undefined,
      economy:{...s.economy,gold:10000,debt:0},customers:[],mods:{},tavern:{...s.tavern,hasRoom:true,hasRoom2:true,hasBathhouse:true,backRoomReady:true,roomListing:'discreet'},
      locations:Object.fromEntries(Object.entries(s.locations).map(([id,r])=>[id,{...r,occupants:id==='taproom'?['player',s.primaryCharacterId]:[]}]))}));
    globalThis.action=a=>dev.store.dispatch({type:'construction-tool/construct',...a});
    globalThis.table=a=>dev.store.dispatch({type:'construction-tool/table',...a});
    globalThis.state=()=>dev.store.game();globalThis.privateFn=n=>dev.fn(WML.status().modSymbols['construction-tool'][n]);
    globalThis.wake=()=>{let before;const off=dev.hook('wakeUp',{priority:999,after:s=>{before=structuredClone(s);return s;}});
      const s=state();let out;try{out=dev.fn('wakeUp')(s,{lampsOutSlot:s.slot,wakeSlot:s.slot+1440});}finally{off();}
      dev.store.update(()=>({...out,pendingEvent:undefined,activeScene:{},phase:'prep'}));return before;};
    await new Promise(r=>setTimeout(r,100));
    if(!document.querySelector('[data-ct-open]'))throw Error('설계 버튼 없음: '+document.body.innerText.slice(-1500));
    document.querySelector('[data-ct-open]').click();await new Promise(r=>setTimeout(r,120));return true;
  `);

  await ConstructionTool_검사('vanilla room names match the game in blueprint, overview and API',`
    const expected={taproom:'홀',kitchen:'부엌',back_room:'뒷방',bedroom:'침실',elena_room:'그녀의 방',
      bathroom:'욕실',bathhouse:'목욕탕',upstairs_hall:'객실 1',upstairs_room_2:'객실 2'};
    const before=JSON.stringify({data:ct.getData(),economy:state().economy,locations:state().locations}),labels=JSON.stringify(privateFn('constructionShortLabels'));
    const rooms=ct.getRooms(),ids=Object.keys(expected),apiLabels=ids.every(id=>rooms.find(r=>r.id===id)?.label===expected[id]);
    let blueprint=true;
    for(const floor of ['ground','basement','upper']){
      document.querySelector('[data-ct-floor-tab="'+floor+'"]').click();await new Promise(r=>setTimeout(r,65));
      for(const room of rooms.filter(r=>ids.includes(r.id)&&r.floor===floor)){
        const names=[...document.querySelectorAll('[data-ct-window] [data-ct-game-id]')].filter(n=>n.dataset.ctGameId===room.id);
        blueprint=blueprint&&names.length>0&&names.every(n=>n.parentElement.textContent.includes(expected[room.id]));
      }
    }
    const overview=ids.every(id=>{const card=document.querySelector('[data-ct-location-card="'+id+'"]');return card?card.textContent.includes(expected[id]):id==='elena_room';});
    const single={...state(),tavern:{...state().tavern,hasRoom2:false}},first=ct.getRooms(single).find(r=>r.id==='upstairs_hall').label;
    const data=JSON.stringify({data:ct.getData(),economy:state().economy,locations:state().locations})===before;
    return {apiLabels,blueprint,overview,singleRoom:first==='객실',namesPreserved:JSON.stringify(privateFn('constructionShortLabels'))===labels,data};
  `);
  await ConstructionTool_검사('shop location overview hides game IDs and uses a compact title',`
    const overview=document.querySelector('[data-ct-location-overview]');
    const title=overview?.querySelector('[data-ct-location-title]');
    const blueprintIds=[...document.querySelectorAll('[data-ct-window] [data-ct-game-id]')];
    return{
      overview:!!overview,
      title:title?.textContent.includes('모두의 현재 위치')===true,
      compactTitle:parseFloat(getComputedStyle(title).fontSize)<=14.1,
      facilityColumns:[...overview.querySelectorAll('[data-ct-location-grid]')].every(grid=>{
        const columns=getComputedStyle(grid).gridTemplateColumns;
        const count=columns.startsWith('repeat(')?parseInt(columns.slice(7),10):columns.split(' ').length;
        return count===(innerWidth<=540?2:4);
      }),
      noLocationIds:overview?.querySelectorAll('[data-ct-game-id]').length===0,
      blueprintIdsRemain:blueprintIds.length>0
    };
  `);
  await ConstructionTool_검사('floor tabs, two panels, fixed four-column 16-cell map and requested footprints',`
    const tabs=[...document.querySelectorAll('[data-ct-floor-tab]')].map(n=>n.dataset.ctFloorTab).join(',');
    const p=ct.getBlueprint('upper'),g=ct.getBlueprint('ground'),b=ct.getBlueprint('basement');
    return{tabs:tabs==='upper,ground,basement',panels:!!document.querySelector('[data-ct-simple=upper]')&&!!document.querySelector('[data-ct-detail=upper]'),
      sixteen:document.querySelectorAll('[data-ct-cell]').length===16,capacity:ct.getCapacity().total===8,
      bath:JSON.stringify(p.rooms.find(r=>r.id==='bathroom').cells)==='[0,1]',bed:JSON.stringify(p.rooms.find(r=>r.id==='bedroom').cells)==='[2,3]',
      hall:g.rooms.find(r=>r.id==='taproom').cells.length===12,kitchen:JSON.stringify(g.rooms.find(r=>r.id==='kitchen').cells)==='[3,7]',
      basementBath:JSON.stringify(b.rooms.find(r=>r.id==='bathhouse').cells)==='[2,3,6,7]',reserved:b.rooms.filter(r=>r.external).length===3,
      renamed:document.querySelector('[data-ct-tab=blueprint]').textContent==='건축 설계도'};
  `);
  await ConstructionTool_검사('before opening, table work relocates hall occupants by role',`
    const lodger={id:'ct-native-lodger',name:'숙박 손님',status:'arrived',constructionSeat:'taproom'};
    const walkIn={id:'ct-walk-in',name:'일반 손님',status:'arrived',constructionSeat:'taproom'};
    dev.store.update(s=>({...s,phase:'prep',customers:[lodger,walkIn],tavern:{...s.tavern,tonightRenter:{customerId:lodger.id,name:lodger.name}},
      locations:Object.fromEntries(Object.entries(s.locations).map(([id,room])=>[id,{...room,occupants:id==='taproom'?
        [dev.fn('playerId'),s.primaryCharacterId,lodger.id,walkIn.id,'ct-extra-person']:[]}]))}));
    const before=state();table({operation:'toggle',tableId:'ct_table_1'});const after=state();
    return{
      changed:ct.getData().furniture.find(item=>item.id==='ct_table_1').active===false,
      hallEmpty:(after.locations.taproom?.occupants||[]).length===0,
      coupleInBedroom:[dev.fn('playerId'),after.primaryCharacterId].every(id=>(after.locations.bedroom?.occupants||[]).includes(id)),
      lodgerInRoom:(after.locations.upstairs_hall?.occupants||[]).includes(lodger.id),
      walkInOutside:(after.locations.village?.occupants||[]).includes(walkIn.id),
      extraPersonMoved:(after.locations.back_room?.occupants||[]).includes('ct-extra-person'),
      seatsCleared:after.customers.every(customer=>customer.constructionSeat===undefined),
      immutable:before!==after
    };
  `);
  await ConstructionTool_검사('after opening, table work remains locked and does not relocate people',`
    dev.store.update(s=>dev.fn('moveOccupant')({...s,phase:'service'},dev.fn('playerId'),'taproom'));
    const before=state(),active=ct.getData().furniture.find(item=>item.id==='ct_table_1').active;
    table({operation:'toggle',tableId:'ct_table_1'});const after=state();
    return{unchanged:ct.getData().furniture.find(item=>item.id==='ct_table_1').active===active,
      stayed:dev.fn('playerLocation')(after)==='taproom',same:before===after};
  `);
  await evaluate(`
    dev.store.update(s=>({...s,phase:'prep',customers:[],tavern:{...s.tavern,tonightRenter:undefined}}));
    table({operation:'toggle',tableId:'ct_table_1'});return true;
  `);
  await ConstructionTool_검사('2/3 seats, exact 20/30/50 prices and overlap rejection',`
    const gold=state().economy.gold;table({operation:'upgrade',tableId:'ct_table_1'});const upgrade=state().economy.gold===gold-20&&ct.getCapacity().ground===9;
    table({operation:'buy',roomId:'taproom',cell:0});const basic=state().economy.gold===gold-50&&ct.getCapacity().ground===11;
    table({operation:'buy',roomId:'taproom',cell:8,premium:true});const premium=state().economy.gold===gold-100&&ct.getCapacity().ground===14;
    table({operation:'buy',roomId:'taproom',cell:1});table({operation:'buy',roomId:'taproom',cell:15,rotate:true});
    return{upgrade,basic,premium,rejected:state().economy.gold===gold-100&&ct.getData().furniture.length===6};
  `);
  await ConstructionTool_검사('300g fixed upstairs hall, furniture placement, brewery and extra room footprints',`
    const gold=state().economy.gold;document.querySelector('[data-ct-simple-room=ct_upper_hall]').click();await new Promise(r=>setTimeout(r,40));
    document.querySelector('[data-ct-build=upper_hall]').click();const built=state().economy.gold===gold-300&&ct.getCapacity().upper===0;
    table({operation:'buy',roomId:'ct_upper_hall',cell:8});table({operation:'buy',roomId:'ct_upper_hall',cell:9});
    action({operation:'move',roomId:'ct_upper_hall',floor:'upper',cell:4});
    action({operation:'build',roomType:'brewery',floor:'basement',cell:10});action({operation:'build',roomType:'brewery',floor:'basement',cell:11});
    action({operation:'build',roomType:'guest_room',floor:'upper',cell:4});
    const rooms=ct.getRooms();return{built,seats:ct.getCapacity().upper===4,fixed:JSON.stringify(rooms.find(r=>r.id==='ct_upper_hall').cells)==='[8,9,12,13]',
      breweries:rooms.filter(r=>r.type==='brewery').length===2,guest:JSON.stringify(rooms.find(r=>r.type==='guest_room').cells)==='[4,5]',upkeep:ct.getUpkeep().total===14};
  `);
  await ConstructionTool_검사('native and added location cards share size, fit their grid and keep readable shading',`
    const shop=[...document.querySelectorAll('button')].find(button=>button.textContent==='가게'&&button.getClientRects().length);
    shop?.click();await new Promise(resolve=>setTimeout(resolve,100));
    const overview=[...document.querySelectorAll('[data-ct-location-overview]')].find(node=>node.getClientRects().length);
    const cards=[...overview.querySelectorAll('[data-ct-location-card]')];
    const native=overview.querySelector('[data-ct-location-card=kitchen]'),nativeStyle=getComputedStyle(native);
    const added=cards.filter(node=>node.hasAttribute('data-ct-room'));
    const luminance=color=>{
      const channels=color.slice(color.indexOf('(')+1,color.lastIndexOf(')')).split(',').slice(0,3).map(Number).map(value=>{
        const channel=value/255;return channel<=0.04045?channel/12.92:((channel+0.055)/1.055)**2.4;
      });
      return channels[0]*0.2126+channels[1]*0.7152+channels[2]*0.0722;
    };
    const contrast=(first,second)=>{
      const a=luminance(first),b=luminance(second);return(Math.max(a,b)+0.05)/(Math.min(a,b)+0.05);
    };
    const fits=[...overview.querySelectorAll('[data-ct-location-grid]')].every(grid=>{
      const bounds=grid.getBoundingClientRect(),computed=getComputedStyle(grid);
      const columns=computed.gridTemplateColumns.split(' ').length;
      const width=(bounds.width-parseFloat(computed.columnGap)*(columns-1))/columns;
      return [...grid.querySelectorAll('[data-ct-location-card]')].every(node=>{
        const rect=node.getBoundingClientRect();return Math.abs(rect.width-width)<1&&rect.left>=bounds.left-1&&rect.right<=bounds.right+1;
      });
    });
    return{
      nativeAndAdded:cards.length>=9&&added.length>=2,
      sameSizing:added.every(node=>{
        const css=getComputedStyle(node);return css.fontSize===nativeStyle.fontSize&&css.padding===nativeStyle.padding&&css.minHeight===nativeStyle.minHeight;
      }),
      compactEmptyCards:added.every(node=>node.getBoundingClientRect().height<=native.getBoundingClientRect().height+1),
      fits,
      opaqueShading:cards.every(node=>getComputedStyle(node).backgroundColor.startsWith('rgb(')),
      vanillaBlackAndGray:cards.filter(node=>!node.hasAttribute('data-ct-room')).every(node=>{
        const css=getComputedStyle(node);return css.backgroundColor==='rgb(30, 30, 30)'&&css.borderColor==='rgb(102, 102, 102)';
      }),
      originalModColors:added.every(node=>{
        const css=getComputedStyle(node);return css.backgroundColor==='rgb(41, 58, 67)'&&css.borderColor==='rgb(82, 114, 125)';
      }),
      titleContrast:cards.every(node=>contrast(getComputedStyle(node.firstElementChild).color,getComputedStyle(node).backgroundColor)>=4.5),
      emptyTextContrast:cards.every(node=>{
        const empty=[...node.children].find(child=>child.textContent==='비어 있음');
        return !empty||contrast(getComputedStyle(empty).color,getComputedStyle(node).backgroundColor)>=4.5;
      }),
      noGameIds:overview.querySelectorAll('[data-ct-game-id]').length===0
    };
  `);
  await ConstructionTool_검사('floor construction waits for D+2 waking; beer/wine production and area-based daily maintenance',`
    const gold=state().economy.gold;action({operation:'expand-floor',floor:'upper'});action({operation:'expand-floor',floor:'upper'});
    const once=state().economy.gold===gold-300&&ct.getBlueprint('upper').job.dueDay===3;
    action({operation:'expand-hall',floor:'upper',cell:16});const locked=ct.getRooms().find(r=>r.id==='ct_upper_hall').cells.length===4;
    const before1=wake(),notYet=ct.getBlueprint('upper').size===16;
    const production1=state().supplies.beer===before1.supplies.beer+2&&state().supplies.wine===before1.supplies.wine+2;
    const cost1=state().economy.gold===before1.economy.gold-14;
    const before2=wake();return{once,locked,notYet,production1,cost1,complete:ct.getBlueprint('upper').size===20,day:state().day===3,
      cost2:state().economy.gold===before2.economy.gold-14};
  `);
  await ConstructionTool_검사('repeated wake settlement is idempotent',`
    const handler=dev.hooks.get(dev.sym('wakeUp')).after.find(h=>h.owner==='construction-tool').fn;
    const s=state(),out=handler(s,[s,{}]);return{same:out===s,beer:out.supplies.beer===s.supplies.beer,gold:out.economy.gold===s.economy.gold};
  `);
  await ConstructionTool_검사('expanded floor can become hall; rotated table and second expansion reach 24 only',`
    action({operation:'expand-hall',floor:'upper',cell:16});action({operation:'expand-hall',floor:'upper',cell:17});
    table({operation:'buy',roomId:'ct_upper_hall',cell:16,rotate:true});
    const area=ct.getUpkeep().hall===6,seats=ct.getCapacity().upper===6;
    action({operation:'expand-floor',floor:'upper'});wake();const waiting=ct.getBlueprint('upper').size===20;wake();
    const gold=state().economy.gold;action({operation:'expand-floor',floor:'upper'});
    return{area,seats,waiting,max:ct.getBlueprint('upper').size===24,twice:ct.getBlueprint('upper').expansions===2,thirdBlocked:state().economy.gold===gold};
  `);
  await ConstructionTool_검사('additional guest room uses native rental fee and does not duplicate bookings',`
    dev.store.update(s=>({...s,phase:'service',slot:s.slot+480,pendingEvent:undefined,activeScene:{},tavern:{...s.tavern,tonightRenter2:undefined,roomListing:'discreet'}}));
    const off=dev.hook('lodgingChance',{after:()=>1});const random=Math.random;let draw=0;Math.random=()=>0.01+(draw++%9)/10;
    try{dev.store.update(s=>privateFn('constructionLodgingRoll')(s));}finally{off();Math.random=random;}
    const room=ct.getRooms().find(r=>r.type==='guest_room'),gold=state().economy.gold;
    dev.store.update(s=>privateFn('constructionLodgingRoll')(s));
    const c=state().customers.find(c=>c.constructionGuestRoom===room.id);
    return{booked:!!room.renter?.customerId,fee:room.renter?.rentPaid>0,location:!!c&&dev.fn('locationOf')(state(),c.id)===room.id,noDoublePay:state().economy.gold===gold};
  `);
  await ConstructionTool_검사('preparation table work returns an additional-room guest to the assigned room',`
    const room=ct.getRooms().find(item=>item.type==='guest_room'),customer=state().customers.find(item=>item.constructionGuestRoom===room.id);
    dev.store.update(s=>{
      let next=dev.fn('moveOccupant')({...s,phase:'prep',pendingEvent:undefined,activeScene:{}},customer.id,'taproom');
      return{...next,customers:next.customers.map(item=>item.id===customer.id?{...item,constructionSeat:'taproom'}:item)};
    });
    table({operation:'toggle',tableId:'ct_table_2'});const returned=state();
    table({operation:'toggle',tableId:'ct_table_2'});
    return{assignedRoom:dev.fn('locationOf')(returned,customer.id)===room.id,
      seatCleared:returned.customers.find(item=>item.id===customer.id).constructionSeat===undefined};
  `);
  await ConstructionTool_검사('extra guest checks out at waking without stale occupants',`
    const room=ct.getRooms().find(r=>r.type==='guest_room'),id=room.renter.customerId;wake();
    return{reservationCleared:!ct.getRooms().find(r=>r.id===room.id).renter,customerRemoved:!state().customers.some(c=>c.id===id),
      locationCleared:!(state().locations[room.id]?.occupants||[]).includes(id)};
  `);
  if(integrated)await ConstructionTool_검사('Brothel reserved areas build through its API; no bath overlap and original costs',`
    dev.store.update(s=>({...s,phase:'prep',pendingEvent:undefined,activeScene:{}}));const gold=state().economy.gold;
    const built=ct.buildExistingRoom('brothel_cellar_1');const rooms=ct.getBlueprint('basement').rooms;
    const bath=rooms.find(r=>r.id==='bathhouse').cells,brothel=rooms.filter(r=>r.external).flatMap(r=>r.cells);
    return{built,cost:state().economy.gold===gold-400,flag:state().tavern.hasBrothelCellar1===true,noOverlap:brothel.every(c=>!bath.includes(c))};
  `);
  if(integrated)await ConstructionTool_검사('Brothel workers leave the hall before preparation table work',`
    const brothel=__waywardBrothelPublic,worker=brothel.getConfig().workers[0],runtime=brothel.getRuntime();
    brothel.getConfig().enabled=true;worker.enabled=true;brothel.workers(state());
    runtime.set(worker.id,{...runtime.get(worker.id),location:'taproom'});
    dev.store.update(s=>({...s,phase:'prep',pendingEvent:undefined,activeScene:{},errandSession:undefined,activeShoppingSession:undefined}));
    const before=ct.getData().furniture.find(item=>item.id==='ct_table_1').active;
    table({operation:'toggle',tableId:'ct_table_1'});
    return{tableChanged:ct.getData().furniture.find(item=>item.id==='ct_table_1').active!==before,
      workerMoved:runtime.get(worker.id).location==='back_room'};
  `);
  await ConstructionTool_검사('seating capacity actually limits normal arrivals',`
    dev.store.update(s=>({...s,phase:'service',customers:[],pendingEvent:undefined,activeScene:{}}));
    const cap=ct.getCapacity();dev.store.update(s=>{for(let i=0;i<cap.total+1;i++){
      const c={...dev.fn('makeCustomer')(s.slot,[],s.patronRecords,s.tavernReputation,s),id:'ct-test-'+i,status:'arrived',namedPatronId:undefined,isResident:false};
      s=dev.fn('addCustomer')(s,c,'taproom');}return s;});
    return{total:state().customers.length===cap.total,ground:state().customers.filter(c=>dev.fn('locationOf')(state(),c.id)==='taproom').length===cap.ground,
      upper:state().customers.filter(c=>dev.fn('locationOf')(state(),c.id)==='ct_upper_hall').length===cap.upper};
  `);
  await ConstructionTool_검사('save/load preserves grid, projects, furniture, economy ledger; mobile fits',`
    dev.store.update(s=>({...s,phase:'prep',customers:[],pendingEvent:undefined,activeScene:{}}));const before=JSON.stringify(ct.getData());
    dev.store.get().saveToSlot(0);dev.store.get().loadFromSlot(0);const saved=JSON.stringify(ct.getData())===before;
    document.querySelector('[data-ct-floor-tab=ground]').click();await new Promise(r=>setTimeout(r,70));
    const nodes=[...document.querySelectorAll('[data-ct-cell]')],p=document.querySelector('[data-ct-simple]'),q=document.querySelector('[data-ct-detail]');
    return{saved,ground16:nodes.length===16,order:p.getBoundingClientRect().top<q.getBoundingClientRect().top,
      fits:nodes.every(n=>{const r=n.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth+1;}),ids:[...document.querySelectorAll('[data-ct-game-id]')].every(n=>getComputedStyle(n).color==='rgb(251, 146, 60)')};
  `);
  await ConstructionTool_검사('legacy seats and room IDs migrate without charging or deleting rooms',`
    const current=structuredClone(state()),gold=current.economy.gold;
    dev.store.update(s=>({...s,mods:{...s.mods,'construction-tool':{schema:1,tables:16,openTables:16,upperTables:6,openUpper:6,
      layout:{kitchen:'ground:5'},rooms:[{id:'ct_upper_hall',type:'upper_hall',label:'2층 홀',slot:'upper:5',paid:1000},
      {id:'ct_legacy_store',type:'legacy_store',label:'이전 창고',slot:'upper:7',paid:200}]}}}));
    const d=ct.getData(),cap=ct.getCapacity();const result={schema:d.schema===2,seats:cap.ground>=16&&cap.upper>=6,
      room:d.rooms.some(r=>r.id==='ct_legacy_store'),paid:d.rooms.find(r=>r.id==='ct_upper_hall').paid===1000,
      backup:d.legacy.layout.kitchen==='ground:5',noCharge:state().economy.gold===gold};dev.store.update(()=>current);return result;
  `);
  if(process.argv.includes('--screenshot'))fs.writeFileSync(`wml/mods/construction-tool/tests/grid-${mobile?'mobile':'desktop'}.jpg`,Buffer.from(await playScreenshot({}),'base64'));
  const saved=await evaluate('dev.store.get().saveToSlot(0);return ct.getData();');await playReload({});
  assert.deepEqual(await evaluate('WML.dev().store.get().loadFromSlot(0);return WML.use("construction-tool").getData();'),saved);
  const status=await playStatus({});assert.deepEqual(status.failed,[]);assert.deepEqual(status.pageErrors,[]);
  console.log('PASS grid save/reload; no browser errors');
}catch(error){console.log('FAIL STATUS',JSON.stringify(await playStatus({})));throw error;}finally{await shutdown();}
process.exit(0);
