# Construction Tool 1.3 · API v1 / gridVersion 2

`requires: ['construction-tool']`, `requiresVersion: {'construction-tool': '>=1.2.0 <2'}`를 선언하고 `api.use('construction-tool')`을 사용해요.
공용 게임 파일을 수정하지 않고 모드 폴더 하나로 배포해요.

## 좌표와 저장

### 1.3.4: 공터 건물 등록

`buildingLotVersion === 1`을 확인한 뒤 `registerBuilding`으로 본관 좌측·우측·뒤편 공터에 들어갈 건물을 등록할 수 있습니다.
공터 ID는 `main_left`, `main_right`, `main_rear`입니다. 건축 툴이 공사 가능 시간·공터 중복·같은 건물 중복을 먼저 검사하고,
애드온의 `canBuild`와 `build`를 호출합니다. 비용 차감과 실제 건물 저장은 소유 애드온이 담당합니다.

```js
ct.registerBuilding({
  id: 'my_annex', label: '별관', cost: 1000,
  lots: ['main_left', 'main_right', 'main_rear'],
  description: '최초 시설 포함',
  currentLot: state => state.mods?.myAnnex?.lot || null,
  canBuild: (state, lotId) => state.economy.gold < 1000 ? '건축 자금이 부족합니다.' : null,
  build: (state, lotId) => ({ ...state, mods: { ...state.mods, myAnnex: { lot: lotId } } }),
  open: () => openManagementWindow()
});
```

`currentLot(state)`은 미건설이면 `null`, 완공됐으면 위 공터 ID 중 하나를 반환해야 합니다.
`open`은 선택 사항이며 완공된 공터와 해당 건물 설계도에 **관리** 버튼을 추가합니다.
건물의 층 격자는 기존 `registerPlot`에서 같은 `buildingId`를 사용해 등록합니다. 미건설 동안 그 건물의 독립 설계도 탭은 숨깁니다.

### 1.3.3: 숙박 운영 제공자

`lodgingProviderVersion === 1`을 확인하고 `setLodgingProvider({book(state)})`를 한 번 등록할 수 있습니다.
`book`은 새 상태를 반환하는 순수 처리 함수이며 중복 예약·숙박 요금·담당·퇴실은 제공자가 관리합니다.
연결되면 본체의 추가 객실 1박 추첨/기상 초기화를 생략합니다. 바닐라 두 번째 객실의 구매 UI/행동을 막고 미구매 고정 면적을 해제합니다.
이미 구매한 바닐라 두 번째 객실과 첫 고정 객실은 보존합니다. `hasLodgingProvider()`로 연결 여부를 조회합니다.
제공자는 첫 바닐라 객실의 예약·두 바닐라 객실의 기상 처리도 별도로 연결해야 합니다. 숙박 확장이 이 역할을 맡습니다.

`upper`(2층), `ground`(1층), `basement`(지하)의 기본 면적은 각각 16칸이에요.
각 층은 4열 고정이고 칸 번호는 왼쪽 위부터 0~15예요. 층 확장 시 16~19, 20~23을 추가해요.
`getBlueprint(floor, state?)`는 `{floor,size,expansions,job,rooms,tables}`를 복사해서 반환해요.

방은 `{id,type,label,floor,cells:[...],slot,native,built,...}`예요. `slot`은 이전 애드온 호환을 위한 `floor:첫칸` 표시이며,
실제 면적은 `cells`를 사용해요. 기본 방과 미건설 2층 홀은 고정·예약 공간으로 포함해요.
Brothel의 세 방도 연결 모드가 없을 때는 미건설 예약 공간으로 포함해요.

## 방 유형 등록

1.3의 `getRoomTypes()`는 등록 유형의 복사 목록을 반환합니다. 공통 유형 `manager_office`(500g, 2칸)와 `servant_room`(300g, 2칸)은 새로 등록되는 부지도 지원하지만 해당 부지의 정책을 그대로 따릅니다. 반환 방의 `staffRole`은 `manager`/`servant` 또는 null, `template`은 이미지 장소 참고용 `bedroom`/`elena_room` 또는 null입니다. 인물 배정은 콘텐츠 모드에서 관리하고 `registerOccupancyProvider`로 배정 중 철거를 막으세요. 이 표식만으로 원본 아내의 수면·관계를 복제하지 않습니다.

```js
const ct = api.use('construction-tool');
ct.registerRoomType({
  id: 'my_lounge', roomId: 'ct_my_lounge', label: '휴게 공간',
  plots: ['basement'], width: 2, height: 1,
  cost: 250, multiple: true,
  description: '영업 규칙은 이 애드온에서 추가해요.',
  canBuild: state => state.economy.debt > 0 ? '빚을 먼저 정리해 주세요.' : null,
  canDemolish: (state, room) => null
});
```

- 필수는 `id,label,plots,cost`이고, `width,height`는 생략 시 1이에요.
- 가로 1~4칸, 세로 1~6칸 정수이며 실제 층 범위와 겹침은 건설할 때 검사해요.
- `multiple: true`이면 `ct_my_lounge_번호` 같은 고유 위치 ID를 만들어 여러 개 지을 수 있어요.
- `canBuild`/`canDemolish`는 거부 이유 문자열 또는 허용 시 `null`을 반환하는 순수 조회 함수예요.
- 등록된 방 위치는 기본 게임의 위치 목록·실내 목록·이름표에 런타임으로 연결해요. 모든 원래 게임 AI가 그 방을 자동 지원한다는 의미는 아니에요.
- 현재 위치 목록의 추가 방 카드는 본체가 바닐라와 같은 크기·글자·여백으로 그려요. 방 면적(`cells`)과 카드 표시 크기는 별개이며 애드온에서 카드 높이를 덮어쓰지 마세요.
- 1.2.5부터 등록된 추가 방에 플레이어가 있으면 본체가 **홀로 돌아가기** 버튼을 자동 표시해요. 기본 행동 화면이 비어도 표시하고, 같은 버튼을 애드온마다 추가할 필요는 없어요. 여러 개 건설한 방과 저장에서 복원한 방에도 적용해요.
- 복귀는 게임의 `return_to_taproom` 액션을 사용하므로 원래 이동 시간과 이동 제한을 따릅니다. 진행 중인 사건·행동으로 이동할 수 없으면 버튼이 비활성화됩니다. 아내를 함께 이동시키거나 고유 사건을 종료하는 처리는 해당 콘텐츠 모드가 담당해요.
- 건축·배치·철거는 본체가 처리하고, 고용·영업·계약 같은 사업 데이터는 `state.mods[애드온id]`에 두세요.

## 다른 모드의 기존 방 연결

`isPresent(state)`는 선택 사항입니다. false이면 방 목록과 면적 예약에서 모두 제외합니다.
여러 게임·다른 건물 용도가 같은 부지를 재사용할 때만 사용하세요.

```js
ct.registerExistingRoom({
  id: 'other_mod_room', label: '기존 방', slot: 'basement:12', cells: [12,13],
  isBuilt: state => !!state.tavern?.hasOtherRoom,
  isOccupied: state => false,
  occupantNames: state => [],
  canBuild: state => null,
  buildLabel: '원래 모드에서 건설',
  build: () => originalMod.purchaseRoom()
});
```

실제 건설 여부·구매 비용·소요 시간은 원래 모드가 소유하고, 본체는 면적·배치·겹침을 관리해요.
`registerExistingRoom`으로 연결한 지하방·휴게실 등에도 같은 기본 복귀 버튼이 자동 적용돼요.
`buildExistingRoom(id)`를 UI 클릭에서 호출하면 준비 시간·기건설 여부·조건을 검사하고 `build()`로 연결해요.
미건설이어도 공간을 예약하며 같은 층의 빈 공간으로만 이동해요. 겹치는 자리 교환과 기존 방 철거는 제공하지 않아요.
일반 외부 방의 기본 면적은 `cells` 또는 slot의 1칸이에요. Brothel 세 방은 본체의 지정된 2×1 예약 면적을 사용해요.

## 방 행동과 조회

`registerRoomAction({id,roomType,label,enabled?,run})`은 선택한 방의 행동 버튼을 등록해요.
`run(state,room)`은 새 상태를 반환해야 해요. 비용·시간·사건 검증은 애드온 책임이고 상태를 직접 수정하면 안 돼요.

`registerHallEvacuator({id,evacuate})`는 자체 저장소로 관리하는 인물이 홀에 있을 때 사용해요.
`evacuate(state,{roomId,fallbackRoom})`에서 대상 인물을 다른 장소로 옮기고 상태를 반환합니다.
건축 툴은 사건·장면이 없는 영업 준비 시간에 테이블 작업을 시작할 때만 이 함수를 호출해요.

- `getRooms(state?)`: 방 배열. 임대 여부·외부 방의 건설 상태·현재 면적 포함.
- `getPlots()`: 부지 기본 정의. 현재 확장 면적은 `getBlueprint()`를 사용해요.
- `getCapacity(state?)`: `{ground,upper,total,groundOwned,upperOwned}`. 숫자는 **테이블 수가 아닌 좌석 수**예요.
- `getUpkeep(state?)`: `{hall,brewery,total,breweryCount}`. 현재 본체의 일일 유지비예요.
- `getData(state?)`: 본체 저장 데이터 복사본. 외부에서 직접 덮어쓰지 마세요.
- `canConstruct(state)`: 사건이 없는 영업 준비 시간인지 확인해요. 실제 잔액·점유 검사는 처리 단계에서 다시 해요.
- `registerPlot({id,label,slots})`: 추가 부지 정의. 본관의 유료 2회 확장 규칙은 기본 세 층에 적용해요.

### 1.3.1: 설계창의 건물·층 분류

`registerPlot`에 선택적인 표시 자료 `buildingId`, `buildingLabel`, `buildingOrder`, `floorLabel`, `floorOrder`를 함께 지정할 수 있습니다.
같은 `buildingId`의 부지는 한 건물 버튼 아래 모이며 층 버튼은 `floorOrder` 오름차순으로 표시합니다.
`id`·격자·방·저장 자료와 건설 정책은 바꾸지 않습니다. 분류 자료는 같은 건물의 각 층에 일관되게 지정하세요.

```js
ct.registerPlot({id:'my_annex_ground',label:'별관 · 1층',slots:16,
  buildingId:'my_annex',buildingLabel:'별관',buildingOrder:100,floorLabel:'1층',floorOrder:1});
```

그 밖의 기존 부지는 각각 독립 버튼으로 표시하므로 접근이 사라지지 않습니다.
좌·우·뒤 공터는 등록된 격자가 아니며, 건물 자체는 `registerBuilding`으로 연결합니다.
표시 자료와 실제 공터당 한 채·중복 건설 검사는 1.3.4의 공터 건물 등록 기능이 담당합니다.

### 1.2.10: 추가 부지 면적과 점유 연결

`plotPolicyVersion === 1`을 확인한 뒤 `registerPlotPolicy({id,size,check?,expansion?,expand?})`로
이미 등록된 부지를 한 번 연결합니다. `size(state,data)`는 0~24 정수를 반환하며 실제 건설·이동의
범위 검사에도 사용합니다. 0이면 아직 개방되지 않은 층입니다. `check(state,action)`은 거부 이유
또는 null, `expansion(state)`은 `{label,cost,disabled,description}`, `expand(state,action)`은
비용·공사 자료를 반영한 새 상태를 반환합니다. 공사 기상 처리는 소유 애드온이 담당합니다.

`registerOccupancyProvider({id,isOccupied})`의 `isOccupied(state,roomId)`로 별도 명부의 점유를
공통 이동·철거 검사에 보강합니다. 원래 인물·손님 점유와 사건 제한도 계속 적용합니다.

## 본체 액션

```js
api.store.dispatch({type:'construction-tool/construct', operation:'build', roomType:'my_lounge', floor:'basement', cell:12});
api.store.dispatch({type:'construction-tool/construct', operation:'move', roomId:'ct_my_lounge_5', floor:'basement', cell:16, rotate:true});
api.store.dispatch({type:'construction-tool/construct', operation:'demolish', roomId:'ct_my_lounge_5'});
api.store.dispatch({type:'construction-tool/construct', operation:'expand-floor', floor:'upper'});
api.store.dispatch({type:'construction-tool/construct', operation:'expand-hall', floor:'upper', cell:16});
api.store.dispatch({type:'construction-tool/table', operation:'buy', roomId:'taproom', cell:0, premium:false, rotate:false});
api.store.dispatch({type:'construction-tool/table', operation:'upgrade', tableId:'ct_table_1'});
api.store.dispatch({type:'construction-tool/table', operation:'toggle', tableId:'ct_table_1'});
api.store.dispatch({type:'construction-tool/move', roomId:'ct_my_lounge_5'});
```

새 시설은 등록된 `width×height`, 테이블은 세로 2칸이 기본이에요. `rotate:true`이면 90도 회전해요.

`schema:1` 저장은 로드 시 `schema:2`로 전환해요. 이전 단일 슬롯 `layout`을 본체에 다시 덮어쓰지 마세요.
1.1.x의 예약 전용 `setCapacityProvider`는 실제 사용 어댑터가 없어 제거했어요. 좌석 사업과의 새 어댑터는 격자·가구 자료를 기준으로 작성해야 해요.
