/* Construction Tool — original implementation, not a redistribution of tavern-expansion. */
WML.define({
  tags: ["util","content"],
  id: 'construction-tool',
  author: "Hina_Lover",
  name: '건축 툴 (Construction Tool)',
  // mod symbols (tools/mod-symbols.mjs / MCP symbol_add keep this block; data only)
  symbols: {
    "constructionLocationIds": {"raw":{"2026-11-01":"Za"}},
    "constructionIndoorRooms": {"raw":{"2026-11-01":"Pqe"}},
    "constructionLocationLabels": {"raw":{"2026-11-01":"YZ"}},
    "constructionShortLabels": {"raw":{"2026-11-01":"LB"}},
    "constructionServicePatron": {"raw":{"2026-11-01":"$r"}},
    "constructionActivePatron": {"raw":{"2026-11-01":"ia"}},
    "constructionBusyPatron": {"raw":{"2026-11-01":"Pa"}},
    "constructionPlayerInHall": {"raw":{"2026-11-01":"my"}},
    "constructionGreet": {"raw":{"2026-11-01":"zZe"}},
    "constructionOrder": {"raw":{"2026-11-01":"JZe"}},
    "constructionServe": {"raw":{"2026-11-01":"QZe"}},
    "constructionApologize": {"raw":{"2026-11-01":"XZe"}},
    "constructionWifeServiceAI": {"raw":{"2026-11-01":"Kje"}},
    "constructionCanMove": {"raw":{"2026-11-01":"MJ"}},
    "constructionMovementGate": {"raw":{"2026-11-01":"Eh"}},
    "constructionReactDOM": {"raw":{"2026-11-01":"Are"}},
    "constructionPrepPanel": {"raw":{"2026-11-01":"wst"}},
    "constructionAccordion": {"raw":{"2026-11-01":"yst"}},
    "constructionLocationOverview": {"raw":{"2026-11-01":"hat"}},
    "constructionAutoServiceAction": {"raw":{"2026-11-01":"RW"}},
    "constructionLodgingRoll": {"raw":{"2026-11-01":"xee"}}
  },
  version: "1.3.5",
  game: "2026-11-01",
  lang: 'ko',
  role: ['layout', 'tavern-capacity'],
  description: '건물·부지별 층 설계도와 본관 확장·테이블·양조실·객실을 관리해요.',
  loadAfter: ['wife-view-mode'],
  async setup(api) {
    await api.loadScript('files/model.js');
    await api.loadScript('files/core.js');
    const core = globalThis.ConstructionTool_초기화(api);
    await api.loadScript('files/ui.js');
    globalThis.ConstructionTool_화면초기화(api, core);
    api.provide(core.publicAPI);
  }
});
