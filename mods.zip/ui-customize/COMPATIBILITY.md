# UI_customize 외부 모드 창 연결 안내

## 1.4.0 추가 API와 기존 호환

현재 기준은 **UI_customize 1.4.0 / 게임 2026-11-01 정식판**입니다. 아래 기존 API 계약도 유지합니다. 기존 `setEditing(true/false)`는 전체 편집/편집 종료로 연결됩니다. 사용자 화면의 편집 제한은 호환 패치의 기존 `dock`/`float`/`restore` 호출을 막지 않으며 패치가 모드를 바꿀 필요는 없습니다.

| 추가 API | 동작 |
| --- | --- |
| `setEditMode('none' | 'all' | 'inside' | 'tabs')` | 종료/전체/내부 높이/열 전체 좌우 편집. 선택한 모드 문자열 반환, 잘못된 값 false. 저장 배치를 변경하지 않습니다. |
| `editMode` | 현재 모드를 읽는 getter. 재시작 시 none입니다. |
| `listTabs()` | 현재 열의 `{id, title, blocks, width, custom, empty}` 배열. width는 전체 너비 비중이며 픽셀 값이 아닙니다. blocks는 ID 복사본입니다. |
| `addTab(title)` | 빈 사용자 열을 추가하고 저장 ID 문자열을 반환합니다. 빈 이름은 자동 이름을 사용합니다. |
| `moveTab(id, targetId, 'left' | 'right')` | 열 전체를 대상 옆으로 이동합니다. 내부 트리·너비 비중 유지. 성공 true, 무효 대상 false. |
| `removeTab(id)` | 비어 있는 사용자 열만 삭제합니다. 성공 true, 내용이 있거나 자동 열이면 false. |
| `dock(blockId, customTabId, side)` | 기존 dock의 확장. 사용자 열 ID를 대상으로 전달하면 빈 열을 채우거나 해당 열 안에 배치합니다. |

자동 열 ID(`uic:auto:…`)는 현재 첫 블록 기준으로 파생되므로 블록을 옮긴 후에는 `listTabs()`를 다시 조회합니다. 사용자 열 ID(`uic:tab:…`)는 저장·재로드에 유지됩니다. 내부 배치 트리를 직접 파싱하지 마세요. `getLayout().tree`는 기존 leaf/split과 함께 빈 사용자 열을 위한 empty 노드 및 tab 메타데이터를 포함할 수 있습니다. 새 열을 쓴 저장 배치는 1.4.0 이상이 필요하며 구 version1 저장은 계속 읽습니다.

열 전체 이동은 원본 노드·인물 상태를 옮기는 것이 아니라 같은 렌더 컨테이너의 배치만 옮깁니다. 새 모드용 창을 연결할 때는 기존 `registerBlock`과 안정적인 인물 ID를 그대로 사용합니다. 사용자 요청 없이 모드를 켜거나 새 열을 자동 생성하지 않습니다.

이 문서는 모드 제작자와 Codex·Claude 등 코딩 도구가 함께 읽는 일반 Markdown 참고자료입니다. UI_customize 배포 ZIP에 포함되며, 특정 에이전트 설정이나 개발 PC의 절대 경로를 요구하지 않습니다. 예제의 `example-panel`은 실제 모드 ID로 바꿀 자리입니다.

설명 기준은 **UI_customize 1.3.1 공개 API / 게임 2026-11-01 정식판**입니다. 이후 판에서는 함께 배포된 mod.js의 공개 API를 먼저 확인하세요. 이 문서는 사용자의 기존 배치를 초기화하라는 지시가 아닙니다.

1.3.1부터 설정 창의 외부 블록 이름은 본체가 `mod - <등록 title>`로 표시합니다. 패치에서는 title에 `mod - `를 직접 붙이지 마세요. 실제 창 제목과 `listBlocks().title`은 등록한 그대로이며 ID·저장 규격도 유지합니다. 외부 창을 본편 열에 고정해도 그 열의 부분 복원 대상에 넣지 않습니다. 본체는 원래 소속이 정해진 본편 블록만 모으고 외부 창의 배치값과 나머지 블록 사이의 분할 관계를 보존합니다. 복원하는 열이 공간을 차지해 실제 표시 면적은 달라질 수 있습니다.

## 1. 연결 구조와 작업 범위

원본 모드는 창의 내용·렌더링·게임 진행을 소유하고, UI_customize는 등록된 **내용 DOM 노드의 배치**를 소유합니다. 연결 모드는 둘 사이의 열기/닫기·갱신·복귀만 연결합니다. UI_customize가 새 시뮬레이션이나 인물 데이터를 만들어 주지는 않습니다.

원본을 수정할 수 있으면 안정적인 창 참조와 생성/제거 알림을 공개하세요. 다른 제작자의 모드라면 별도 `<작업 모드>-compatible-<상대 모드>` 폴더를 만들고 원본 수정 권한을 별도로 확인하세요. UI_customize 본체나 게임 HTML을 새 창마다 수정할 필요는 없습니다.

- 필수 연결 패치는 `requires: ['ui-customize', '<원본 ID>']`, `loadAfter`에 같은 ID들을 선언하고 setup 안에서 `WML.use('ui-customize')`를 호출합니다. 아래 예제의 새 표시 옵션을 사용하면 `requiresVersion: { 'ui-customize': '>=1.1.1' }`도 선언하세요.
- UI_customize가 없어도 작동해야 하는 원본 모드는 연결 코드를 별도 선택 설치 패치로 분리하는 구성이 단순합니다. 로드 순서만 선언해 놓고 UI_customize가 항상 존재한다고 가정하지 마세요.
- 연결할 것은 창 외곽의 제목/드래그/고정 좌표 프레임보다 **그 안의 내용 컨테이너**입니다. 모달 확인창보다 계속 갱신되는 정보창·실시간 카드에 적합합니다.
- 같은 DOM 노드는 한 곳에서만 표시됩니다. 전체 모니터와 개인 카드에 같은 인물을 동시에 표시하려면 원본의 카드 렌더러로 **별도 보기 인스턴스**를 만들고 같은 상태를 읽게 하세요. `cloneNode()`로 이벤트·React 상태를 복사하거나 시뮬레이션을 두 번 실행하지 마세요.

## 2. 공개 API 계약

`const layout = WML.use('ui-customize');`로 받은 객체를 사용합니다. 내부 records, CSS 선택자, localStorage 키, 배치 트리 구현을 직접 수정하지 마세요.

| 호출 | 동작과 반환값 |
|---|---|
| `registerBlock(def)` | 블록 등록. 해제 함수 `unregister()`를 반환합니다. ID 중복·DOM 노드 누락은 예외입니다. 등록만으로 기본 배치를 강제로 만들지는 않으며, 같은 ID의 저장 배치가 있으면 재사용합니다. |
| `updateBlock(id, {title, node})` | 등록된 제목 또는 원본 노드를 갱신합니다. 성공 true, 미등록 false. 새 노드는 원본 호스트에 붙인 뒤 넘기세요. 다른 등록 옵션을 바꾸는 API가 아닙니다. |
| `isPlaced(id)` | 저장 배치가 dock 또는 floating이면 true. 현재 DOM 등록/실제 표시 여부를 보장하지 않습니다. |
| `dock(id, target, side)` | target의 left/right/top/bottom에 고정합니다. 기본 target은 story, side는 right. 미등록 ID·잘못된 방향·자기 자신·고정 트리에 없는 대상 등은 false입니다. |
| `float(id)` | 게임 화면 내부 Floating으로 전환합니다. 성공 true, 미등록 또는 마지막 고정 블록 분리 불가 시 false입니다. 별도 브라우저 창을 열지 않습니다. |
| `restore(id)` | 외부 블록의 배치값을 지우고 원본 위치로 돌려줍니다. 개인 카드가 숨긴 호스트에 등록되었다면 독립 창을 닫는 동작이 됩니다. 본편 내부 블록의 복원 방식과 구분하세요. |
| `setBlockAvailable(id, available)` | 1.0.6부터 제공. false이면 **고정 트리에서** 일시 제외하여 닫힌 창의 빈 자리를 숨깁니다. 저장 배치는 유지합니다. 이것만으로 Floating DOM을 닫지는 않으므로 창 종료 시 unregister도 함께 처리하세요. 다시 연결할 때 true로 돌립니다. |
| `migrateBlockIds(mapping)` | 1.0.6부터 제공. 현재 배치와 배치 저장본의 ID를 이전합니다. 예: `{'old:slot:0': 'new:person:abc', 'old:slot:1': null}`. null은 해당 배치를 제거합니다. 새 ID의 배치가 이미 있으면 기존 새 배치를 유지하고 옛 배치를 제거합니다. |
| `listBlocks()` | 현재 등록된 `{id, title, mode}` 목록. mode는 source/dock/floating입니다. 일시 해제된 저장 자리 전체를 나열하는 API가 아닙니다. |
| `getLayout()` | 배치 설정의 깊은 복사본. 수정해도 실제 배치는 바뀌지 않습니다. 배치 저장 형식의 version은 모드 배포 버전과 다릅니다. |
| `subscribe(listener)` | 배치/등록/마운트 변경 알림. **등록 즉시** listener(layout)을 한 번 호출하며 해제 함수를 반환합니다. 게임 상태의 매 변경을 알려 주는 API는 아닙니다. |
| `active` | 게임 내부 배치 루트가 문서에 연결되었는지 나타내는 getter입니다. |
| `setEditing(boolean)`, `openSettings()` | 편집 상태를 바꾸거나 UI 설정창을 엽니다. |
| `reset()` | 모든 창을 새 기본 배치로 복원합니다. 외부 창의 claim도 해제합니다. 사용자 요청에 따른 전체 복원용이며 패치 초기화/갱신 루틴에서 자동 호출하지 마세요. |
| `resetColumn(column)` | 1.3.1부터 제공. `story`/`house`/`focus`/`actions`의 원래 본편 블록만 기본 순서·내부 비율의 독립 고정 열로 복원합니다. 외부 창의 배치값과 나머지 분할을 보존합니다. 성공 true, 모르는 열 false. 사용자 동작용이며 패치 초기화/갱신에서 자동 호출하지 마세요. |

`updateBlock`과 `setBlockAvailable`은 화면 갱신을 예약하지만 subscribe 알림을 직접 보내지 않습니다. 반대로 register/unregister와 배치 조작에서는 알림이 발생할 수 있습니다. 배치 알림에서 다시 등록을 반복하지 말고 변경분만 동기화하세요. 필요하면 requestAnimationFrame으로 한 프레임에 모으세요.

### registerBlock의 def

```js
const unregister = layout.registerBlock({
  id: 'my-mod:live',          // 모드별 이름 공간 + 안정적인 창 ID
  title: '내 모드 · 실시간', // 사용자에게 보이는 이름
  node: contentElement,      // 실제 Element. 문자열/React element/복제본 아님
  source: 'my-mod',          // 출처 메타데이터
  kind: 'monitor',           // 예: monitor 또는 card. 별도 자동 동작 없음
  dockLabel: '고정',         // 1.1.1+: Floating의 고정 전환 버튼 문구
  gameFontSize: true,        // 1.1.1+: UI_customize 제목/버튼에 rem 기준 적용
  onClaim() { /* 원본 외곽 프레임만 숨기거나 원본 드래그를 중지 */ },
  onRelease() { /* 원본 외곽 프레임과 조작을 복구 */ }
});
```

id와 node는 필수입니다. title 생략 시 ID가 제목이 됩니다. source/kind는 메타데이터이며 카드 생성·업데이트·독립 표시를 자동 구현하지 않습니다. dockLabel/gameFontSize는 등록 때 지정합니다. gameFontSize가 내용의 px 고정 글자까지 바꿔 주지는 않으므로 원본 렌더러도 rem/em을 사용해야 합니다.

onClaim은 원본 자리에 복귀 표식을 남긴 뒤 **노드를 옮기기 직전**, onRelease는 표식 자리로 노드를 돌려준 뒤 호출됩니다. 매번 내용이 갱신될 때 호출되는 콜백은 아닙니다. 인수/반환값 계약은 없으며, 반복 claim/release와 페이지 종료에 안전하게 작성하세요. 콜백에서 원본 부모·복귀 표식을 제거하거나 예외를 던지지 마세요.

unregister는 실제 등록과 프레임을 해제하지만 **저장된 배치값은 보존**합니다. 일시적으로 닫힌 창을 다시 같은 ID로 등록하면 위치/크기가 돌아옵니다. 영구적으로 없어진 인물의 자리를 지우려면 등록이 살아 있는 동안 restore(id) 후 unregister를 하세요. 미등록 옛 ID를 제거하려면 migrateBlockIds({[id]: null})을 사용할 수 있습니다. 표시 제외 상태는 등록과 별개이므로 재등록 때 available=true도 명시하세요.

## 3. 복사해서 조정할 수 있는 창 연결 예제

다음은 별도 호환 모드의 mod.js 템플릿입니다. `example-panel`은 원본 모드 ID로, 메타데이터의 제작자/버전은 실제 값으로 바꾸세요. 필요한 공개 계약은 다음과 같습니다.

1. 원본이 `api.provide({ getPanel, subscribePanels })`로 공개합니다. `getPanel()`은 창이 열렸으면 `{node, owner, title}`을, 닫혔으면 null을 반환합니다. owner는 외곽 프레임, node는 그 안의 내용이며 서로 다른 Element입니다.
2. node가 UI_customize로 옮겨져도 getPanel은 **저장된 같은 참조**를 반환합니다. 원본 부모 아래 querySelector로만 찾으면 분리 후 놓칩니다.
3. subscribePanels(listener)는 해제 함수를 반환합니다. 창 생성 후, 제목/노드 변경 시, 그리고 **getPanel이 null로 바뀌었지만 owner를 아직 제거하기 전**에 동기적으로 알립니다. 종료 알림이 늦으면 원본 복귀 표식이 사라질 수 있습니다.
4. 원본은 기존 갱신 경로로 같은 node의 내용을 계속 렌더합니다. 연결 패치는 게임 시간을 진행시키지 않습니다.

```js
WML.define({
  id: 'example-panel-compatible-ui-customize',
  name: '예제 정보창 · UI_customize 연결',
  author: 'YourName', version: '1.0.0',
  game: '2026-10-24-pre7', lang: 'ko', tags: ['util'],
  requires: ['ui-customize', 'example-panel'],
  requiresVersion: {'ui-customize': '>=1.1.1'},
  loadAfter: ['ui-customize', 'example-panel'],
  setup(api) {
    const layout = WML.use('ui-customize');
    const panels = WML.use('example-panel');
    if (!layout?.registerBlock || !panels?.getPanel || !panels?.subscribePanels)
      throw Error('UI_customize 또는 원본 모드의 창 공개 API를 확인하세요.');
    const id = 'example-panel:live';
    let entry = null, pending = 0, stopped = false;
    const style = document.createElement('style');
    style.textContent = '[data-example-uic-source]{visibility:hidden!important;pointer-events:none!important}';
    document.head.append(style);

    function sync() {
      if (stopped) return;
      const panel = panels.getPanel();
      layout.setBlockAvailable(id, !!panel);
      if (entry && (!panel || entry.node !== panel.node || entry.owner !== panel.owner)) {
        entry.unregister();
        entry = null;
      }
      if (!panel) return;
      const {node, owner} = panel;
      const title = panel.title || '예제 실시간';
      if (!entry) {
        const unregister = layout.registerBlock({
          id, title, node, source: 'example-panel', kind: 'monitor',
          dockLabel: '고정', gameFontSize: true,
          onClaim() { owner.setAttribute('data-example-uic-source', ''); },
          onRelease() { owner.removeAttribute('data-example-uic-source'); }
        });
        entry = {node, owner, title, unregister};
      } else if (entry.title !== title) {
        entry.title = title;
        layout.updateBlock(id, {title});
      }
    }
    function schedule() {
      if (!stopped && !pending) pending = requestAnimationFrame(() => {
        pending = 0;
        sync();
      });
    }
    // 종료 전에 DOM을 반환해야 하므로 원본의 수명 알림은 동기 처리합니다.
    const stopPanels = panels.subscribePanels(sync);
    // 즉시 호출도 있는 배치 알림은 다음 프레임에 모아 재등록 알림 연쇄를 피합니다.
    const stopLayout = layout.subscribe(schedule);
    api.ui.settings(body => body.append(
      api.ui.button('UI_customize에서 배치', () => layout.openSettings())
    ));
    sync();
    window.addEventListener('pagehide', () => {
      stopped = true;
      if (pending) cancelAnimationFrame(pending);
      stopPanels(); stopLayout();
      layout.setBlockAvailable(id, false);
      entry?.unregister();
      style.remove();
    }, {once: true});
  }
});
```

위 템플릿은 원본 창을 연 뒤 UI의 세부 창 목록에서 선택하는 방식입니다. 등록 시 자동 float/dock을 호출하지 않으므로 기존 저장 배치를 덮어쓰지 않습니다. 사용자 버튼으로 직접 열려면 등록 후 `layout.float(id)` 또는 `layout.dock(id, 'story', 'right')`를 호출하고 반환값을 확인하세요. 초기 setup에서 매번 호출하면 사용자가 저장한 위치를 덮어쓸 수 있습니다.

원본이 창 생성/제거 API를 제공하지 않으면 안정적인 data 속성으로 찾는 어댑터도 가능하지만, 이동한 node 참조와 owner 수명을 별도로 관리해야 합니다. document 전체를 계속 훑거나 자신의 DOM 변경을 다시 감지하는 MutationObserver 루프보다 원본 수명 알림을 우선하세요.

## 4. 창 수명·개인 카드·저장 배치

| 상황 | 연결 측 처리 |
|---|---|
| 최초 표시 | 원본 호스트에 실제 내용 노드를 붙인 뒤 안정적인 ID로 한 번 등록. 사용자가 배치하도록 둠 |
| 내용/수치 변화 | 기존 노드 안에서 원본 렌더러를 갱신. 같은 ID를 재등록하지 않음 |
| 제목만 변경 | updateBlock(id, {title}) |
| 내용 노드만 교체 | 새 노드를 원본 호스트에 붙인 뒤 updateBlock(id, {node}); 부모도 교체하면 옛 owner 제거 전에 해제 후 재등록 |
| 일시 닫기/owner 제거 | available=false → unregister → 원본 owner 제거. 저장 배치는 유지 |
| 재열기 | available=true → 같은 ID 재등록. 저장된 고정/Floating 재사용 |
| 원래 영역/전체 배치 복원 | onRelease로 원래 창 조작 복구. 숨긴 개인 카드 호스트라면 개인 창 닫기. 강제로 다시 float하지 않음 |
| 명부에서 영구 제거 | restore → unregister → 원본 보기 파괴. ID는 다른 인물에게 재사용하지 않음 |
| 패치 종료 | 구독/타이머/감시 해제, 노드 반환, 표시 제외 및 등록 해제, 자체 CSS/호스트 정리 |

개인 카드를 전체 창이 꺼져 있어도 UI에서 선택하려면 원본 렌더러로 개인 보기 하나씩을 만들고 **별도 숨긴 호스트**에 붙여 등록합니다. 이 경우 source 상태는 숨김, dock/floating은 표시이며 restore는 그 개인 보기를 숨긴 호스트로 돌려줍니다. 전체 모니터의 OFF나 격자 축소가 개인 카드의 명부·구독을 해제하지 않게 하세요. 부모 전체 창을 함께 표시할 필요는 없습니다. 두 보기 모두 같은 게임 상태를 읽고 원본 카드의 이미지/내용 갱신 함수를 사용합니다.

ID는 `my-mod:person:<저장된 인물 ID>`처럼 인물에 고정하세요. 화면의 0번 칸·이름·정렬 순서를 ID로 쓰면 위치가 다른 인물에게 넘어갑니다. 기존 칸 ID를 바꿀 때는 인물 목록이 준비된 뒤 migrateBlockIds를 한 번 적용하세요. 아직 목록이 없는 시점에 전부 null로 이전하면 사용자의 배치를 지워 버립니다. 동일 인물에 여러 옛 칸이 대응하면 입력 순서상 먼저 옮긴 배치가 남으므로 순서도 정하세요.

UI_customize 설정의 네 Column은 story/house/focus/actions입니다. 독립 기본 배치의 house/focus는 해당 영역의 정보 블록으로 연결됩니다. 현재 화면 전체의 절대 좌표나 열 번호를 지정하는 API는 아닙니다. 사용자가 대상 Column을 Floating으로 옮긴 경우 dock의 대상이 없을 수도 있으므로 실패를 처리하고 설정창에서 선택하게 하세요. 다른 제작자의 블록 ID에 의존할 때는 상대 버전과 ID 계약을 확인하세요.

## 5. 렌더링·크기·드래그 충돌을 피하는 방법

- 노드 자체를 이동하며 이벤트 리스너를 유지합니다. UI_customize가 만든 `.uic-*` 프레임을 복제하거나 내부 body에 innerHTML을 덮어쓰지 마세요. UI 본체의 내부 DOM은 공개 API가 아닙니다.
- React 등 프레임워크가 소유한 자식 노드를 외부에서 임의로 빼면 갱신/해제 오류가 날 수 있습니다. 원본이 관리하는 안정적인 DOM 호스트 또는 원본 portal 렌더링 대상을 공개하고, 프레임워크의 마운트/언마운트 수명을 유지하세요. 임의의 React 자식을 옮기는 것만으로 호환이 보장되지는 않습니다.
- 내용 컨테이너의 position:fixed·left/top·고정 px 폭/높이를 제거하거나 claim 중만 덮어쓰세요. 보통 width/height:100%, min-width/min-height:0, box-sizing:border-box와 적절한 overflow가 필요합니다. 숨긴 호스트의 0px 측정을 영구 캐시하지 마세요.
- 게임 글자 크기를 따르려면 내용에 rem/em을 사용합니다. 등록의 gameFontSize는 UI 헤더만 담당합니다. 원본의 별도 글자 배율과 중복 적용하지 않도록 렌더러도 확인하세요.
- 원본 창의 숨긴 외곽 프레임이 클릭을 가로채지 않게 하고, UI_customize 안에서는 원본 전체 창 드래그를 중지합니다. 창 제목 드래그와 카드 내부 이미지 높이 드래그를 구분하세요.
- content 전체를 새로 고치거나 reparent한 뒤에도 같은 노드를 갱신하도록 하세요. 최초 부모 아래에서만 다시 찾는 코드, 전역 ID 중복, 닫힌 전체 창을 구독 조건으로 쓰는 코드를 점검하세요.
- 위치/크기/편집 상태는 UI_customize가, 전체 표시 ON/OFF·선택 인물·이미지 높이·실제 내용은 원본이 저장합니다. 다른 모드의 설정 키를 직접 수정하거나 배치 복원 때 게임 상태를 바꾸지 마세요.

## 6. 배포 전 확인과 기존 예시

새 호환 패치를 검증할 때는 실제 수행한 범위를 기록하세요. 아래는 제작 시 확인할 항목이며 이 문서를 읽었다고 자동 검증 완료가 되는 것은 아닙니다.

1. 원본만 켰을 때와 패치를 함께 켰을 때 모두 시작 가능. 의존 모드/버전 누락은 명확히 안내.
2. 같은 블록의 중복 등록·DOM 복제 없이 고정/Floating/원래 영역 반복. 기존 원본 버튼 클릭·내용·이미지 갱신 유지.
3. 창을 고정/Floating한 채 닫고 재열기, 부모 제거/재생성. 종료한 고정 자리와 Floating이 남지 않고 저장 위치로 복귀.
4. 전체/개인 동시 표시, 전체 OFF·격자 축소·정렬·이름 변경에도 개인 ID와 갱신 유지. 인물 영구 제거/다른 저장 슬롯 전환 정리.
5. 배치 저장/불러오기·브라우저 새로고침·실제 시험 저장 슬롯 불러오기. 기존 사용자 배치 자동 초기화 없음.
6. PC와 좁은 화면에서 경계 크기 조절·스크롤·제목 드래그·게임 글자 크기·버튼 접근성. 표시 조작만으로 게임 시간/돈/상태가 바뀌지 않음.
7. 호환 패치 폴더만 담은 ZIP을 설치해서 재현. 원본 모드·UI_customize가 별도 의존성임을 README에 명시하고 원저자/링크 보존.

별도 설치된 기존 패치가 있다면 다음 파일을 구현 예시로 볼 수 있습니다. 이 파일들이 UI_customize 본체 ZIP에 들어 있는 것은 아닙니다.

- [동료 연결](../ui-customize-compatible-companions/mod.js): 전체 창과 인물별 카드, 원본 createCard/updateCard/destroyCard, 옛 칸 ID 이전, 전체 OFF와 개인 표시 분리.
- [창관 연결](../ui-customize-compatible-brothel/mod.js): 전체 창 내용 묶기, 인물별 카드, 원본 CSS 변수/상태 갱신, 전체 창 닫기 후 개인 유지.

이 문서의 getPanel/subscribePanels는 **예제를 위한 원본 측 계약**입니다. UI_customize가 제공하는 함수가 아닙니다. 위 두 기존 패치는 각 원본이 제공하는 서로 다른 공개 API를 사용하므로 함수 이름과 DOM 선택자를 그대로 다른 모드에 복사하지 마세요. 기존 호환/원본의 버전과 본체 mod.js의 공개 API를 확인한 뒤 필요한 부분만 적용하세요.

## 1.2.0 추가 API

`fitHeight(id)`는 배치된 블록을 현재 폭에서 내용 높이에 한 번 맞추고 저장하며 성공 여부를 반환합니다. 화면과 이웃 블록 공간의 제한은 유지합니다. 일반 사용자는 테두리 또는 분할 경계를 더블클릭합니다.

등록 옵션 `onClose()`를 지정하면 제목줄 맨 오른쪽에 닫기 버튼을 추가합니다. Floating은 항상, 고정은 편집 중만 보입니다. 개인 보기는 `onClose(){layout.restore(id);}`로 원래 숨김 호스트에 복귀시키고, 전체 창은 원본의 표시 OFF 함수를 호출하세요. 이 옵션을 사용하는 패치는 UI_Customize >=1.2.0을 요구해야 합니다. 원본 내부 버튼 중복 숨김은 연결 패치가 담당합니다.
