// Test-only dependency lookup. Does not modify MCP or install packages.
import {createRequire,registerHooks} from 'node:module';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
if(process.env.WML_TEST_NODE_MODULES){
  const require=createRequire(path.join(path.resolve(process.env.WML_TEST_NODE_MODULES),'../package.json'));
  registerHooks({resolve(specifier,context,next){
    try{return next(specifier,context);}catch(error){
      if(error.code!=='ERR_MODULE_NOT_FOUND'||specifier.startsWith('.')||specifier.includes(':'))throw error;
      return next(pathToFileURL(require.resolve(specifier)).href,context);
    }
  }});
}
