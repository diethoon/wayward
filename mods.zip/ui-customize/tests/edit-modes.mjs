// Isolated MCP browser. --mobile, --zip and --legacy cover display/source/old-layout variants.
import fs from 'node:fs';import assert from 'node:assert/strict';import crypto from 'node:crypto';
import {playStart,playEval,playReload,playStatus,playScreenshot,shutdown} from '../../../../MCP/lib/play.mjs';
import {checkMod} from '../../../../MCP/lib/check.mjs';
const mobile=process.argv.includes('--mobile'),zip=process.argv.includes('--zip'),legacy=process.argv.includes('--legacy');
const version=fs.readFileSync('wml/mods/ui-customize/mod.js','utf8').match(/version:\s*['"]([^'"]+)/)[1];
const tag=(mobile?'mobile':'desktop')+(zip?'-zip':'-folder')+(legacy?'-legacy':'-fresh'),report={tag,version,cases:[]};
const files=['wml/mods/mods.js','Wayward_WML_ko.html','wml/runtime/wml-core.js','MCP/lib/play.mjs','wml/mods/companions/mod.js','wml/mods/companions/files/live.js','wml/mods/brothel/mod.js','wml/mods/ui-customize-compatible-companions/mod.js','wml/mods/ui-customize-compatible-brothel/mod.js'];
const hash=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex'),hashes=Object.fromEntries(files.map(f=>[f,hash(f)]));
const leaf=id=>({type:'leaf',id}),split=(axis,a,b,ratio=.5)=>({type:'split',axis,ratio,a,b});
const oldLayout={version:1,tree:split('x',split('x',leaf('story'),leaf('house'),.35),split('x',leaf('focus'),leaf('actions')),.47),placements:{story:{mode:'dock'},house:{mode:'dock'},focus:{mode:'dock'},actions:{mode:'dock'},map:{mode:'floating',rect:{x:30,y:40,w:320,h:280},z:9}}};
async function run(code){const r=await playEval({code,timeoutMs:30000});assert.ok(!r.error,JSON.stringify(r));assert.equal(r.pageErrorsSoFar,0,JSON.stringify(r));return r.result;}
async function check(name,code){const result=await run(code);report.cases.push({name,result});console.log(name,JSON.stringify(result));assert.ok(result&&Object.values(result).every(x=>x===true),JSON.stringify(result));}
const globals=`globalThis.d=WML.dev();globalThis.ui=WML.use('ui-customize');globalThis.v=WML.use('companions');globalThis.b=__waywardBrothelPublic;
 globalThis.pause=ms=>new Promise(r=>setTimeout(r,ms));globalThis.root=()=>document.querySelector('[data-ui-customize-root]');
 globalThis.block=id=>document.querySelector('[data-uic-block="'+id+'"]');globalThis.leaves=n=>!n?[]:n.type==='leaf'?[n.id]:n.type==='split'?[...leaves(n.a),...leaves(n.b)]:[];
 globalThis.findTab=(node,id)=>!node?null:node.tab?.id===id?node:node.type==='split'?(findTab(node.a,id)||findTab(node.b,id)):null;
 globalThis.closeWindows=()=>{for(const n of document.querySelectorAll('.wml-win'))n.querySelector('.wml-win-close')?.click();};
 globalThis.drag=(head,target,side='left')=>{const a=head.getBoundingClientRect(),r=target.getBoundingClientRect(),x=side==='left'?r.left+4:r.right-4,y=r.top+Math.min(13,r.height/2);head.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,button:0,pointerId:913,clientX:a.left+8,clientY:a.top+8}));window.dispatchEvent(new PointerEvent('pointermove',{bubbles:true,pointerId:913,clientX:x,clientY:y}));window.dispatchEvent(new PointerEvent('pointerup',{bubbles:true,pointerId:913,clientX:x,clientY:y}));};
 globalThis.gripKey=selector=>{const g=document.querySelector(selector);if(!g)throw Error('Missing divider '+selector);g.dispatchEvent(new KeyboardEvent('keydown',{key:g.parentElement.classList.contains('uic-axis-y')?'ArrowDown':'ArrowRight',bubbles:true}));};
 globalThis.clickMode=mode=>document.querySelector('[data-uic-edit-mode-button="'+mode+'"]').click();
 globalThis.nodeBodies=()=>Object.fromEntries(ui.listTabs().map(t=>[t.id,JSON.stringify(t.custom?findTab(ui.getLayout().tree,t.id):pick(ui.getLayout().tree,t.blocks))]));
 globalThis.pick=(n,ids)=>!n?null:JSON.stringify(leaves(n))===JSON.stringify(ids)?n:n.type==='split'?(pick(n.a,ids)||pick(n.b,ids)):null;`;
try{
 report.static=checkMod('ui-customize');assert.equal(report.static.ok,true);
 const start=await playStart({mods:{'layout-grid':false},viewport:mobile?{width:390,height:844}:{width:2560,height:1440}});assert.deepEqual(start.failed,[]);
 await run(`localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify([...new Set([...start.loaded,'ui-customize-compatible-brothel','ui-customize-compatible-companions'])])}));${legacy?`localStorage.setItem('wml.mod.ui-customize',JSON.stringify({layout:${JSON.stringify(oldLayout)},preset:${JSON.stringify(oldLayout)}}));`:''}return true;`);
 if(zip){report.installed=await run(`const append=document.head.appendChild;document.head.appendChild=function(n){if(n.tagName==='SCRIPT'&&n.src.endsWith('/wml/mods/ui-customize/mod.js')){queueMicrotask(()=>n.dispatchEvent(new Event('error')));return n;}return append.call(this,n);};try{return await WML.install([{path:'ui.zip',blob:await(await fetch('wml/mods/ui-customize/ui-customize-${version}-20261101.zip')).blob()}]);}finally{document.head.appendChild=append;}`);assert.equal(report.installed[0].mode,'browser');}
 assert.deepEqual((await playReload({})).failed,[]);
 if(zip){report.installProof=await run(`let stack='';try{WML.use('ui-customize').registerBlock(null);}catch(e){stack=e.stack;}return{source:stack.includes('wml-installed/ui-customize/mod.js'),notes:WML.status().sourceNotes};`);assert.equal(report.installProof.source,true);assert.ok(!report.installProof.notes.some(n=>n.id==='ui-customize'));}
 await run(`${globals}d.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true,imageBackendMode:'off'});d.store.get().newGame();d.fn('store').setState({started:true,selectingArchetype:false,selectingBuilder:false,selectingPicks:false});await pause(80);[...document.querySelectorAll('button')].find(n=>n.textContent==='건너뛰기')?.click();await pause(150);closeWindows();d.store.update(s=>({...s,economy:{...s.economy,gold:30000}}));return true;`);
 if(legacy)await check('old tree and preset are unchanged on load and mode switches',`const original=${JSON.stringify(JSON.stringify(oldLayout))};let same=JSON.stringify(ui.getLayout())===original;for(const mode of ['inside','tabs','all','none']){ui.setEditMode(mode);same&&=JSON.stringify(ui.getLayout())===original;}return{same,preset:JSON.stringify(JSON.parse(localStorage.getItem('wml.mod.ui-customize')).preset)===original};`);
 await check('three named exclusive edit modes and legacy setEditing API',`
  ui.reset();const old=JSON.stringify(ui.getLayout()),game=JSON.stringify(d.store.game());ui.openSettings();
  const labels=['전체 편집 시작','탭 내부 배치 편집 시작','탭 간 배치 변경 시작'];const initial=[...document.querySelectorAll('[data-uic-edit-mode-button]')].map(n=>n.textContent).join('|')===labels.join('|');
  let modes=true;for(const mode of ['all','inside','tabs']){clickMode(mode);modes&&=ui.editMode===mode&&document.querySelectorAll('[data-uic-edit-mode-button][aria-pressed=true]').length===1&&document.querySelector('[data-uic-edit-mode-button="'+mode+'"]').textContent.endsWith('종료');}
  clickMode('tabs');const stopped=ui.editMode==='none';ui.setEditing(true);const legacy=ui.editMode==='all';ui.setEditing(false);closeWindows();
  return{initial,modes,stopped,legacy,layout:JSON.stringify(ui.getLayout())===old,game:JSON.stringify(d.store.game())===game};
 `);
 await check('inside edit enables row dividers and blocks column resize and block movement',`
  ui.reset();ui.setEditMode('inside');await pause(80);const old=JSON.stringify(ui.getLayout());gripKey('[data-uic-split-kind=tabs]');const outer=JSON.stringify(ui.getLayout())===old;
  const row=document.querySelector('[data-uic-split-kind=blocks][data-uic-resize-enabled=true]'),r=row.getBoundingClientRect(),before=JSON.stringify(ui.getLayout());
  row.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,button:0,pointerId:914,clientX:r.left+2,clientY:r.top}));window.dispatchEvent(new PointerEvent('pointermove',{bubbles:true,pointerId:914,clientX:r.left+2,clientY:r.top+25}));window.dispatchEvent(new PointerEvent('pointerup',{bubbles:true,pointerId:914,clientX:r.left+2,clientY:r.top+25}));const resized=JSON.stringify(ui.getLayout())!==before;
  const now=JSON.stringify(ui.getLayout());drag(block('story').querySelector('[data-uic-drag]'),block('portrait'));const fixed=JSON.stringify(ui.getLayout())===now;
  ui.openSettings();const controls=[...document.querySelectorAll('[data-uic-manager-row=placement] select,[data-uic-manager-row=placement] button')].every(n=>n.disabled);closeWindows();return{outer,resized,fixed,controls,visible:r.height>0};
 `);
 await check('between edit keeps all internal node ratios and permits only horizontal column resize',`
  ui.reset();ui.setEditMode('tabs');await pause(80);const bodies=nodeBodies(),before=JSON.stringify(ui.getLayout());
  const inactive=document.querySelector('[data-uic-split-kind=blocks]');inactive.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowDown',bubbles:true}));const locked=JSON.stringify(ui.getLayout())===before;
  gripKey('[data-uic-split-kind=tabs][data-uic-resize-enabled=true]');const changed=JSON.stringify(ui.getLayout())!==before;
  const after=nodeBodies();return{locked,changed,internals:Object.keys(bodies).every(k=>bodies[k]===after[k]),fitBlocked:ui.fitHeight('portrait')===false,allHorizontal:[...document.querySelectorAll('[data-uic-resize-enabled=true]')].every(n=>n.dataset.uicSplitKind==='tabs'&&n.parentElement.classList.contains('uic-axis-x'))};
 `);
 await check('column header arrows reorder whole columns without changing row geometry',`
  const before=ui.listTabs(),bodies=nodeBodies(),source=before[1],header=[...document.querySelectorAll('[data-uic-tab]')].find(n=>n.dataset.uicTab===source.id).querySelector('.uic-column-head');
  [...header.querySelectorAll('button')].find(n=>n.title==='탭을 오른쪽으로').click();const after=ui.listTabs(),next=nodeBodies();
  return{moved:after[2].id===source.id,internals:Object.keys(bodies).every(k=>bodies[k]===next[k]),width:before.every(t=>Math.abs(t.width-after.find(n=>n.id===t.id).width)<1e-8)};
 `);
 if(!mobile)await check('real pointer drag moves entire column across its neighbour',`
  const before=ui.listTabs(),first=before[0],target=before[1];const source=[...document.querySelectorAll('[data-uic-tab]')].find(n=>n.dataset.uicTab===first.id),dest=[...document.querySelectorAll('[data-uic-tab]')].find(n=>n.dataset.uicTab===target.id),bodies=nodeBodies();
  drag(source.querySelector('[data-uic-tab-drag]'),dest,'right');const after=ui.listTabs(),next=nodeBodies();return{order:after[1].id===first.id,internals:Object.keys(bodies).every(k=>bodies[k]===next[k])};
 `);
 await check('none mode locks dividers and quick completion ends every mode',`
  ui.setEditing(false);let before=JSON.stringify(ui.getLayout());for(const divider of document.querySelectorAll('[data-uic-split]'))divider.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowDown',bubbles:true}));
  const locked=before===JSON.stringify(ui.getLayout());let done=true;for(const mode of ['all','inside','tabs']){ui.setEditMode(mode);root().querySelector('[data-uic-edit-done]').click();done&&=ui.editMode==='none'&&!root().querySelector('[data-uic-edit-done]');}return{locked,done};
 `);
 await check('new empty tabs exceed four columns and populate target selector',`
  ui.reset();ui.openSettings();document.querySelector('[aria-label="새 탭 이름"]').value='창관 전용';document.querySelector('[data-uic-add-tab]').click();globalThis.tabA=ui.listTabs().find(t=>t.title==='창관 전용').id;
  globalThis.tabB=ui.addTab('동료 전용');ui.openSettings();const target=document.querySelector('[data-uic-select=target]');
  return{six:ui.listTabs().length===6,empty:ui.listTabs().filter(t=>[tabA,tabB].includes(t.id)).every(t=>t.empty),target:[...target.options].some(n=>n.value===tabA)&&[...target.options].some(n=>n.value===tabB),placeholder:!!document.querySelector('.uic-empty-tab')};
 `);
 await check('native and real mod blocks dock in named tabs and survive float round trips',`
  closeWindows();const game=JSON.stringify(d.store.game());ui.setEditMode('all');ui.dock('map',tabA,'top');ui.dock('surface',tabA,'bottom');const one=ui.listTabs().find(t=>t.id===tabA);
  ui.float('map');const stable=ui.listTabs().some(t=>t.id===tabA);ui.dock('map',tabA,'top');
  d.store.dispatch({type:'companions/hire',options:{gender:'female',name:'편집 모드 동료',employed:false,relationType:'childhood_friend',tier:'basic'}});await pause(100);const person=v.list(d.store.game()).find(p=>p.name==='편집 모드 동료');globalThis.cardId='companions:person:'+person.id;
  ui.dock(cardId,tabB,'top');await pause(100);const card=block(cardId).querySelector('.companions-live-card');globalThis.cardNode=card;
  const fixed=ui.listTabs().find(t=>t.id===tabB).blocks.includes(cardId);ui.moveTab(tabB,ui.listTabs()[0].id,'left');await pause(70);
  return{native:one.blocks.join(',')==='map,surface',stable,mod:fixed,same:!!card&&block(cardId).contains(card),unique:document.querySelectorAll('[data-uic-block="'+cardId+'"]').length===1};
 `);
 await check('filled tabs cannot be deleted, emptied tabs can and invalid operations preserve layout',`
  const before=JSON.stringify(ui.getLayout()),blocked=ui.removeTab(tabA)===false&&JSON.stringify(ui.getLayout())===before;
  ui.restore('map');ui.restore('surface');const empty=ui.listTabs().find(t=>t.id===tabA).empty,deleted=ui.removeTab(tabA)===true;
  const current=JSON.stringify(ui.getLayout()),bad=ui.moveTab('missing','missing')===false&&ui.removeTab('missing')===false&&ui.setEditMode('invalid')===false;
  return{blocked,empty,deleted,bad,unchanged:JSON.stringify(ui.getLayout())===current};
 `);
 await check('ten additional tabs retain unique identities and block selection preserves origin label',`
  for(let i=0;i<10;i++)ui.addTab('추가 열 '+i);const tabs=ui.listTabs();ui.openSettings();const source=document.querySelector('[data-uic-select=source]');
  return{many:tabs.length>12,unique:new Set(tabs.map(t=>t.id)).size===tabs.length,native:[...source.options].find(o=>o.value==='map').textContent==='가게 - 위치 그림',mod:[...source.options].find(o=>o.value===cardId).textContent==='mod - 동료 · 편집 모드 동료'};
 `);
 await check('partial original column restore keeps custom tabs and real mod DOM intact',`
  closeWindows();const old=ui.getLayout(),custom=ui.listTabs().filter(t=>t.custom).map(t=>({id:t.id,title:t.title}));ui.resetColumn('house');await pause(80);
  const after=ui.getLayout();return{custom:custom.every(t=>ui.listTabs().some(n=>n.id===t.id&&n.title===t.title)),map:after.placements.map.mode==='dock',mod:JSON.stringify(after.placements[cardId])===JSON.stringify(old.placements[cardId]),same:!!block(cardId)?.contains(cardNode)};
 `);
 await check('save/load preset preserves named and empty tabs and returns to the right mode',`
  ui.openSettings();const button=text=>[...document.querySelectorAll('.uic-manager-row button')].find(n=>n.textContent===text);button('배치 저장').click();globalThis.savedLayout=JSON.stringify(ui.getLayout());ui.reset();const reset=ui.listTabs().length===4;button('배치 불러오기').click();const same=JSON.stringify(ui.getLayout())===savedLayout;
  ui.setEditMode('tabs');const one=document.querySelectorAll('[data-uic-edit-mode-button][aria-pressed=true]').length===1;closeWindows();d.store.get().saveToSlot(0);return{reset,same,one};
 `);
 const saved=await run('return savedLayout;');assert.deepEqual((await playReload({})).failed,[]);
 await check('actual slot and browser reload retain tabs, mod contents and inactive edit mode',`
  ${globals}d.store.get().loadFromSlot(0);await pause(180);return{same:JSON.stringify(ui.getLayout())===${JSON.stringify(saved)},mode:ui.editMode==='none',custom:ui.listTabs().some(t=>t.title==='동료 전용'),content:[...document.querySelectorAll('.companions-live-card')].some(n=>n.textContent.includes('편집 모드 동료'))};
 `);
 await run(`closeWindows();ui.reset();ui.setEditMode('tabs');ui.addTab('창관 전용');ui.addTab('동료 전용');await pause(120);return true;`);
 if(mobile)await check('narrow between-tab view scrolls to the last column without clipping descendants',`
  const work=root().querySelector('[data-uic-work]');work.scrollLeft=work.scrollWidth;await pause(60);const columns=[...root().querySelectorAll('[data-uic-tab]')],last=columns.at(-1).getBoundingClientRect(),viewport=work.getBoundingClientRect();
  return{scroll:work.scrollWidth>work.clientWidth,last:last.right<=viewport.right+1&&last.right>viewport.left+100,actions:!!columns.at(-1).querySelector('.uic-column-head button')};
 `);
 fs.writeFileSync(new URL('modes-layout-'+tag+'.jpg',import.meta.url),Buffer.from(await playScreenshot({}),'base64'));
 await run(`ui.openSettings();await pause(80);return true;`);
 fs.writeFileSync(new URL('modes-'+tag+'.jpg',import.meta.url),Buffer.from(await playScreenshot({}),'base64'));
 report.status=await playStatus({});assert.deepEqual(report.status.failed,[]);assert.deepEqual(report.status.pageErrors,[]);
 report.protected=Object.fromEntries(files.map(f=>[f,{before:hashes[f],after:hash(f)}]));for(const [f,h]of Object.entries(report.protected))assert.equal(h.before,h.after,f);
 console.log('PASS',tag,report.cases.length,'cases');
}catch(error){report.error=String(error.stack||error);console.error(report.error);try{report.status=await playStatus({});}catch{}process.exitCode=1;}
finally{fs.writeFileSync(new URL('result-modes-'+tag+'.json',import.meta.url),JSON.stringify(report,null,2));await shutdown();}process.exit(process.exitCode||0);
