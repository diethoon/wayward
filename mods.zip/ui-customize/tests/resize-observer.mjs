// Isolated reproduction at the reported 2560x1440 viewport. No production file patching.
// --previous serves UI_customize 1.2.3 from its ZIP in memory; --without-ui disables it.
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import {Readable} from 'node:stream';
import {playStart,playEval,playStatus,shutdown} from '../../../../MCP/lib/play.mjs';
const previous=process.argv.includes('--previous'),withoutUI=process.argv.includes('--without-ui'),all=process.argv.includes('--all');
const version=fs.readFileSync('wml/mods/ui-customize/mod.js','utf8').match(/version:\s*['"]([^'"]+)/)[1];
const tag=(previous?'previous':withoutUI?'without-ui':'current-'+version)+(all?'-all':'-core');
function zipEntry(file,name){const b=fs.readFileSync(file);let end=b.length-22;while(end>=0&&b.readUInt32LE(end)!==0x06054b50)end--;let at=b.readUInt32LE(end+16);
  for(let i=0;i<b.readUInt16LE(end+10);i++){const method=b.readUInt16LE(at+10),size=b.readUInt32LE(at+20),nl=b.readUInt16LE(at+28),xl=b.readUInt16LE(at+30),cl=b.readUInt16LE(at+32),local=b.readUInt32LE(at+42),entry=b.subarray(at+46,at+46+nl).toString();
    if(entry===name){const start=local+30+b.readUInt16LE(local+26)+b.readUInt16LE(local+28),data=b.subarray(start,start+size);return method===8?zlib.inflateRawSync(data):data;}at+=46+nl+xl+cl;}throw Error('Missing ZIP entry '+name);}
const createReadStream=fs.createReadStream;
if(previous){const code=zipEntry('wml/mods/ui-customize/ui-customize-1.2.3-20261101.zip','ui-customize/mod.js');fs.createReadStream=function(file,...args){return path.resolve(file)===path.resolve('wml/mods/ui-customize/mod.js')?Readable.from(code):createReadStream.call(this,file,...args);};}
async function run(code){const out=await playEval({code,timeoutMs:30000});if(out.error)throw Error(out.error);return out.result;}
const report={tag,version,steps:[]};
try{
  const wanted=['addon-compat','companions','brothel','construction-tool',...(!withoutUI?['ui-customize','ui-customize-compatible-companions','ui-customize-compatible-brothel']:[])];
  const mods=all?{...(withoutUI?{'ui-customize':false,'ui-customize-compatible-companions':false,'ui-customize-compatible-brothel':false}:{})}:Object.fromEntries(fs.readdirSync('wml/mods',{withFileTypes:true}).filter(e=>e.isDirectory()).map(e=>[e.name,wanted.includes(e.name)]));
  report.start=await playStart({mods,viewport:{width:2560,height:1440}});
  await run(`globalThis.d=WML.dev();globalThis.v=WML.use('companions');globalThis.b=__waywardBrothelPublic;globalThis.ui=WML.use('ui-customize');globalThis.pause=ms=>new Promise(r=>setTimeout(r,ms));
    globalThis.audit={observers:[],events:[],history:[]};const Native=ResizeObserver;
    globalThis.ResizeObserver=class extends Native{constructor(callback){const row={id:audit.observers.length,stack:new Error().stack,calls:0};audit.observers.push(row);
      super((entries,observer)=>{row.calls++;const item={id:row.id,time:performance.now(),entries:entries.map(e=>({class:e.target.className,w:e.target.clientWidth,h:e.target.clientHeight,rect:[e.contentRect.width,e.contentRect.height]}))};
        audit.history.push(item);if(audit.history.length>100)audit.history.shift();callback(entries,observer);});}};
    window.addEventListener('error',e=>{if(e.message.includes('ResizeObserver'))audit.events.push({message:e.message,time:performance.now(),recent:audit.history.slice(-4)});});
    d.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true,imageBackendMode:'off'});d.store.get().newGame();d.fn('store').setState({started:true,selectingArchetype:false,selectingBuilder:false,selectingPicks:false});
    await pause(80);[...document.querySelectorAll('button')].find(n=>n.textContent.trim()==='건너뛰기')?.click();await pause(120);
    for(const win of document.querySelectorAll('.wml-win'))win.querySelector('.wml-win-close')?.click();
    d.store.update(s=>({...s,day:2,phase:'service',economy:{...s.economy,gold:42690},pendingEvent:undefined,alertQueue:[],activeScene:{}}));
    for(const name of ['RO A','RO B','RO C','RO D'])d.store.dispatch({type:'companions/hire',options:{gender:'female',name,employed:false,relationType:'childhood_friend',tier:'basic'}});
    const config=b.getConfig();config.enabled=false;config.showLivePanel=true;config.showWifePanel=false;config.workers.forEach((p,i)=>{p.enabled=i<4;p.showPanel=true;});b.saveConfig();v.openLive();
    globalThis.form=document.createElement('div');v.live.renderSettings(form);globalThis.gridSize=(cols,rows)=>{for(const [name,value]of [['가로 칸',cols],['세로 칸',rows]]){const input=form.querySelector('[aria-label="'+name+'"]');input.value=value;input.dispatchEvent(new Event('change',{bubbles:true}));}};
    return true;`);
  for(const [name,code]of [
    ['native windows','await pause(350);'],
    ['float monitors',`if(ui){ui.float('companions:live');ui.float('brothel:live');}await pause(350);`],
    ['grids',`for(let n=1;n<=4;n++){gridSize(n,n);await pause(180);}gridSize(1,1);await pause(200);`],
    ['dock and fit',`if(ui){ui.dock('companions:live','story','right');ui.dock('brothel:live','actions','left');ui.setEditing(true);await pause(100);ui.fitHeight('companions:live');ui.fitHeight('brothel:live');}await pause(300);`],
    ['edit modes',`if(ui?.setEditMode){for(let i=0;i<3;i++)for(const mode of ['all','inside','tabs','none']){ui.setEditMode(mode);await pause(45);}const id=ui.addTab('관찰 검사');ui.dock('brothel:live',id,'top');ui.setEditMode('tabs');ui.moveTab(id,ui.listTabs()[0].id,'left');}await pause(250);`],
    ['many frame sizes',`for(let n=0;n<35;n++){const frame=document.querySelector('[data-uic-block="companions:live"]')||document.querySelector('[data-companions-window="live"]');if(frame){frame.style.width=(300+n*7.13)+'px';frame.style.height=(240+(n%7)*31.27)+'px';}await pause(30);}await pause(200);`],
    ['column resets',`if(ui?.resetColumn){for(const id of ['focus','house','story','actions']){ui.resetColumn(id);await pause(100);}}await pause(250);`],
    ['close and reopen',`v.live.setVisible(false);await pause(120);v.openLive();await pause(250);`]
  ]){const result=await run(code+'return{errors:audit.events.length,calls:audit.observers.map(r=>r.calls)};');report.steps.push({name,...result});console.log(name,JSON.stringify(result));}
  report.audit=await run('return audit;');report.status=await playStatus({});
}catch(error){report.error=String(error.stack||error);console.error(report.error);try{report.status=await playStatus({});}catch{}process.exitCode=1;}
finally{fs.createReadStream=createReadStream;fs.writeFileSync(new URL('resize-observer-'+tag+'.json',import.meta.url),JSON.stringify(report,null,2));await shutdown();}
process.exit(process.exitCode||0);
