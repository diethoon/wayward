// Isolated MCP browser. Use an installed dependency runtime if MCP/node_modules is absent.
// node --import ./wml/mods/ui-customize/tests/runtime.mjs wml/mods/ui-customize/tests/column-reset.mjs [--mobile] [--zip] [--legacy]
import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {checkMod} from '../../../../MCP/lib/check.mjs';
import {playStart,playEval,playReload,playStatus,playScreenshot,shutdown} from '../../../../MCP/lib/play.mjs';
const mobile=process.argv.includes('--mobile'),zip=process.argv.includes('--zip'),legacy=process.argv.includes('--legacy');
const version=fs.readFileSync('wml/mods/ui-customize/mod.js','utf8').match(/version:\s*['"]([^'"]+)/)[1];
const tag=(mobile?'mobile':'desktop')+(zip?'-zip':'-folder')+(legacy?'-legacy':'-fresh'),report={tag,cases:[]};
const protectedFiles=['Wayward_WML_ko.html','wml/mods/mods.js','wml/runtime/wml-core.js','MCP/lib/play.mjs',
  'wml/mods/ui-customize-compatible-companions/mod.js','wml/mods/ui-customize-compatible-brothel/mod.js',
  'wml/mods/editor/mod.js','wml/mods/pregnancy/mod.js','wml/mods/companions/mod.js','wml/mods/brothel/mod.js'];
const hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const beforeHashes=Object.fromEntries(protectedFiles.map(file=>[file,hash(file)]));
const leaf=id=>({type:'leaf',id}),split=(axis,a,b,ratio=.5)=>({type:'split',axis,a,b,ratio});
const legacyLayout={version:1,tree:split('x',split('x',leaf('story'),leaf('house'),.35),split('x',leaf('focus'),leaf('actions')),.47),
  placements:{story:{mode:'dock'},house:{mode:'dock'},focus:{mode:'dock'},actions:{mode:'dock'},map:{mode:'floating',rect:{x:30,y:40,w:320,h:280},z:9}}};
async function run(code){const out=await playEval({code,timeoutMs:30000});assert.equal(out.pageErrorsSoFar,0,JSON.stringify(out));assert.ok(!out.error,JSON.stringify(out));return out.result;}
async function check(name,code){const result=await run(code);report.cases.push({name,result});console.log(name,JSON.stringify(result));assert.ok(result&&Object.values(result).every(x=>x===true),JSON.stringify(result));}
const globals=`globalThis.d=WML.dev();globalThis.ui=WML.use('ui-customize');globalThis.v=WML.use('companions');globalThis.b=__waywardBrothelPublic;
  globalThis.pause=ms=>new Promise(r=>setTimeout(r,ms));globalThis.block=id=>document.querySelector('[data-uic-block="'+id+'"]');
  globalThis.leaves=n=>!n?[]:n.type==='leaf'?[n.id]:[...leaves(n.a),...leaves(n.b)];
  globalThis.groups={story:['story'],house:['map','house-wife-stats','urgent','whereabouts','night-summary','house'],focus:['portrait','focus-wife-stats','patron-info','acceptance','surface','last-change','response','remark-response','inner-thought','controls','bath-service','card-activity','focus'],actions:['actions']};
  globalThis.prune=(n,ids)=>{if(!n)return null;if(n.type==='leaf')return ids.includes(n.id)?null:n;const a=prune(n.a,ids),b=prune(n.b,ids);return a&&b?{...n,a,b}:a||b;};
  globalThis.findGroup=(n,ids)=>!n?null:JSON.stringify(leaves(n))===JSON.stringify(ids)?n:n.type==='split'?(findGroup(n.a,ids)||findGroup(n.b,ids)):null;
  globalThis.click=text=>{const button=[...document.querySelectorAll('.uic-manager-row button')].find(n=>n.textContent===text);if(!button)throw Error('Missing UI button '+text);button.click();};
  globalThis.closeManager=()=>document.querySelector('[data-uic-manager-row]')?.closest('.wml-win')?.querySelector('.wml-win-close')?.click();`;
try{
  report.static=checkMod('ui-customize');assert.equal(report.static.ok,true,JSON.stringify(report.static));
  const start=await playStart({mods:{'layout-grid':false},viewport:mobile?{width:390,height:844}:{width:1500,height:1000}});
  assert.deepEqual(start.failed,[]);report.initialLoaded=start.loaded;
  await run(`localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify([...new Set([...start.loaded,'ui-customize-compatible-brothel','ui-customize-compatible-companions'])])}));
    ${legacy?`localStorage.setItem('wml.mod.ui-customize',JSON.stringify({layout:${JSON.stringify(legacyLayout)},preset:${JSON.stringify(legacyLayout)},keep:'legacy-marker'}));`:''}return true;`);
  if(zip){
    report.installed=await run(`const append=document.head.appendChild;document.head.appendChild=function(n){if(n.tagName==='SCRIPT'&&n.src.endsWith('/wml/mods/ui-customize/mod.js')){queueMicrotask(()=>n.dispatchEvent(new Event('error')));return n;}return append.call(this,n);};
      try{return await WML.install([{path:'ui-customize.zip',blob:await(await fetch('wml/mods/ui-customize/ui-customize-${version}-20261101.zip')).blob()}]);}finally{document.head.appendChild=append;}`);
    assert.equal(report.installed[0].mode,'browser');
  }
  assert.deepEqual((await playReload({})).failed,[]);
  if(zip){report.installProof=await run(`let stack='';try{WML.use('ui-customize').registerBlock(null);}catch(e){stack=e.stack;}const s=WML.status();return{installed:s.installed.includes('ui-customize'),browserCode:stack.includes('wml-installed/ui-customize/mod.js'),sourceNotes:s.sourceNotes};`);
    assert.equal(report.installProof.installed,true);assert.equal(report.installProof.browserCode,true);assert.ok(!report.installProof.sourceNotes.some(n=>n.id==='ui-customize'));}
  await run(`${globals}d.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true,imageBackendMode:'off'});d.store.get().newGame();
    d.fn('store').setState({started:true,selectingArchetype:false,selectingBuilder:false,selectingPicks:false});await pause(80);[...document.querySelectorAll('button')].find(n=>n.textContent.trim()==='건너뛰기')?.click();await pause(160);
    for(const window of document.querySelectorAll('.wml-win'))window.querySelector('.wml-win-close')?.click();d.store.update(s=>({...s,economy:{...s.economy,gold:30000}}));return true;`);
  if(legacy)await check('existing legacy layout and saved preset preserved until explicit column reset',`
    const saved=JSON.parse(localStorage.getItem('wml.mod.ui-customize'));
    return{layout:JSON.stringify(ui.getLayout())===${JSON.stringify(JSON.stringify(legacyLayout))},preset:JSON.stringify(saved.preset)===${JSON.stringify(JSON.stringify(legacyLayout))},marker:saved.keep==='legacy-marker'};
  `);
  await check('four column reset buttons and native origin names; window titles and IDs unchanged',`
    ui.openSettings();const rows=[...document.querySelectorAll('[data-uic-manager-row]')],names=Object.fromEntries([...document.querySelector('[data-uic-select=source]').options].map(n=>[n.value,n.textContent]));
    return{buttons:[...document.querySelectorAll('[data-uic-reset-column]')].map(n=>n.dataset.uicResetColumn).join(',')==='story,house,focus,actions',
      order:rows.map(n=>n.dataset.uicManagerRow).join(',')==='editing,presets,recovery,column-recovery,tabs,placement',
      source:names.response==='그녀 - 최근 반응'&&names.map==='가게 - 위치 그림'&&names['inner-thought']==='그녀 - 그녀의 속마음',
      residual:names.house==='가게 - 추가 정보'&&names.focus==='그녀 - 추가 정보',
      original:ui.listBlocks().find(n=>n.id==='response').title==='최근 반응',all:[...document.querySelectorAll('.uic-manager-row button')].some(n=>n.textContent==='모든 창 배치를 복원')};
  `);
  if(legacy)await check('partial upgrade of a legacy layout changes only requested column',`
    closeManager();const before=ui.getLayout();ui.resetColumn('focus');const after=ui.getLayout();
    return{independent:after.independent===true,group:!!findGroup(after.tree,groups.focus),rest:JSON.stringify(prune(before.tree,groups.focus))===JSON.stringify(prune(after.tree,groups.focus)),
      floating:JSON.stringify(after.placements.map)===JSON.stringify(before.placements.map),preset:JSON.stringify(JSON.parse(localStorage.getItem('wml.mod.ui-customize')).preset)===${JSON.stringify(JSON.stringify(legacyLayout))}};
  `);
  await check('each original column returns from scattered dock and floating to exact default tree',`
    closeManager();ui.reset();globalThis.uiInitial=ui.getLayout();const defaults=JSON.stringify(uiInitial);let restored=true,stable=true,game=true;
    for(const [column,ids]of Object.entries(groups)){
      ui.reset();const anchor=column==='story'?'actions':'story';
      for(const [index,id]of ids.entries()){ui.dock(id,anchor,index%2?'bottom':'left');if(index%2===0)ui.float(id);}
      const before=JSON.stringify(d.store.game());ui.resetColumn(column);restored&&=JSON.stringify(ui.getLayout())===defaults;
      const first=JSON.stringify(ui.getLayout());ui.resetColumn(column);stable&&=JSON.stringify(ui.getLayout())===first;game&&=JSON.stringify(d.store.game())===before;
    }return{restored,stable,game};
  `);
  await check('real mod monitors and individual cards register with mod prefix',`
    for(const name of ['열 복원 동료 A','열 복원 동료 B'])d.store.dispatch({type:'companions/hire',options:{gender:'female',name,employed:false,relationType:'childhood_friend',tier:'basic'}});
    globalThis.personIds=v.list(d.store.game()).map(p=>p.id);if(personIds.length!==2)throw Error('Hire fixture failed');v.openLive();
    const c=b.getConfig();c.showLivePanel=true;c.showWifePanel=false;c.enabled=false;c.workers.forEach((w,i)=>{w.enabled=i<2;w.showPanel=true;});b.saveConfig();await pause(200);
    globalThis.cid='companions:person:'+personIds[0];globalThis.bid='brothel:card:'+c.workers[0].id;
    ui.openSettings();const names=Object.fromEntries([...document.querySelector('[data-uic-select=source]').options].map(n=>[n.value,n.textContent]));
    return{whole:names['brothel:live']==='mod - 창관 실시간 · 전체'&&names['companions:live']==='mod - 동료 실시간 · 전체',
      cards:names[cid]==='mod - 동료 · 열 복원 동료 A'&&names[bid]?.startsWith('mod - 창관 직원 · '),
      title:ui.listBlocks().find(n=>n.id===cid).title==='동료 · 열 복원 동료 A'};
  `);
  await check('focus reset preserves mod docked tree, floating coordinates and original DOM identity',`
    closeManager();ui.reset();ui.dock(cid,'surface','bottom');ui.dock('brothel:live','portrait','right');ui.float(bid);
    ui.dock('inner-thought','map','bottom');ui.float('portrait');await pause(100);
    const node=block(cid).querySelector('.companions-live-card'),before=ui.getLayout(),snapshot=JSON.stringify(d.store.game());
    ui.openSettings();document.querySelector('[data-uic-reset-column=focus]').click();closeManager();await pause(100);const after=ui.getLayout();
    const placements=Object.keys(before.placements).filter(id=>!groups.focus.includes(id)).every(id=>JSON.stringify(before.placements[id])===JSON.stringify(after.placements[id]));
    return{group:JSON.stringify(findGroup(after.tree,groups.focus))===JSON.stringify(findGroup(uiInitial.tree,groups.focus)),
      rest:JSON.stringify(prune(before.tree,groups.focus))===JSON.stringify(prune(after.tree,groups.focus)),placements,
      sameNode:block(cid).contains(node),floating:JSON.stringify(before.placements[bid])===JSON.stringify(after.placements[bid]),
      game:JSON.stringify(d.store.game())===snapshot,unique:document.querySelectorAll('[data-uic-block="'+cid+'"]').length===1};
  `);
  await check('hidden and unregistered mod placements survive partial reset and re-registration',`
    ui.reset();globalThis.host=document.createElement('div');host.hidden=true;document.body.append(host);globalThis.testNode=document.createElement('button');testNode.textContent='External test';host.append(testNode);
    let unregister=ui.registerBlock({id:'column:waiting',title:'외부 검사',node:testNode,source:'other'});ui.dock('column:waiting','map','bottom');
    unregister();ui.setBlockAvailable('column:waiting',false);const before=ui.getLayout();ui.resetColumn('house');const after=ui.getLayout();
    const kept=JSON.stringify(prune(before.tree,groups.house))===JSON.stringify(prune(after.tree,groups.house));
    unregister=ui.registerBlock({id:'column:waiting',title:'외부 검사',node:testNode,source:'other'});ui.setBlockAvailable('column:waiting',true);await pause(80);
    const alive=block('column:waiting')?.contains(testNode);ui.restore('column:waiting');unregister();host.remove();
    return{kept,alive,placement:JSON.stringify(before.placements['column:waiting'])===JSON.stringify(after.placements['column:waiting'])};
  `);
  await check('all four columns can be restored in sequence while mod windows remain independent',`
    ui.reset();ui.dock(cid,'portrait','left');ui.float(bid);const mods=ui.getLayout(),snapshot=JSON.stringify(d.store.game());
    for(const [index,ids]of Object.values(groups).entries())for(const id of ids){ui.dock(id,cid,index%2?'top':'right');ui.float(id);}
    for(const column of ['focus','house','story','actions'])ui.resetColumn(column);
    const after=ui.getLayout();return{unique:leaves(after.tree).length===new Set(leaves(after.tree)).size,
      docked:Object.values(groups).flat().every(id=>after.placements[id]?.mode==='dock'&&leaves(after.tree).includes(id)),
      groups:Object.values(groups).every(ids=>!!findGroup(after.tree,ids)),
      mod:Object.keys(mods.placements).filter(id=>id.includes(':')).every(id=>JSON.stringify(mods.placements[id])===JSON.stringify(after.placements[id])),
      state:JSON.stringify(d.store.game())===snapshot};
  `);
  await check('mixed layout stress preserves other split tree and placements for every column',`
    ui.reset();ui.dock(cid,'portrait','bottom');ui.float(bid);let seed=1138,valid=true,rest=true,placements=true;
    const rnd=n=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed%n;},ids=Object.values(groups).flat();
    for(let round=0;round<24;round++){
      for(let move=0;move<8;move++){const id=ids[rnd(ids.length)],targets=leaves(ui.getLayout().tree).filter(other=>other!==id);if(targets.length)ui.dock(id,targets[rnd(targets.length)],['left','right','top','bottom'][rnd(4)]);if(rnd(3)===0)ui.float(id);}
      const column=Object.keys(groups)[round%4],before=ui.getLayout();ui.resetColumn(column);const after=ui.getLayout(),leavesNow=leaves(after.tree);
      rest&&=JSON.stringify(prune(before.tree,groups[column]))===JSON.stringify(prune(after.tree,groups[column]));
      placements&&=Object.keys(before.placements).filter(id=>!groups[column].includes(id)).every(id=>JSON.stringify(before.placements[id])===JSON.stringify(after.placements[id]));
      valid&&=leavesNow.length===new Set(leavesNow).size&&groups[column].every(id=>after.placements[id].mode==='dock')&&!!findGroup(after.tree,groups[column]);
    }return{valid,rest,placements};
  `);
  await check('settings selection, prefixes after moving, invalid calls and saved preset preserved',`
    ui.reset();ui.dock('response','map','bottom');ui.openSettings();const source=document.querySelector('[data-uic-select=source]');source.value='response';source.dispatchEvent(new Event('change'));
    click('배치 저장');const preset=JSON.stringify(JSON.parse(localStorage.getItem('wml.mod.ui-customize')).preset),current=JSON.stringify(ui.getLayout());
    const invalid=ui.resetColumn('missing')===false&&JSON.stringify(ui.getLayout())===current;
    document.querySelector('[data-uic-reset-column=focus]').click();
    const selected=document.querySelector('[data-uic-select=source]'),label=selected.selectedOptions[0].textContent;
    const kept=JSON.stringify(JSON.parse(localStorage.getItem('wml.mod.ui-customize')).preset)===preset;click('배치 불러오기');
    const loaded=JSON.stringify(ui.getLayout())===current;closeManager();return{invalid,selected:selected.value==='response'&&label==='그녀 - 최근 반응',kept,loaded};
  `);
  await check('repeated column restore refreshes same settings window and preserves dimensions',`
    ui.openSettings();await pause(80);const window=document.querySelector('[data-uic-reset-column]').closest('.wml-win'),before=window.getBoundingClientRect();
    for(const column of ['story','house','focus','actions','focus'])document.querySelector('[data-uic-reset-column="'+column+'"]').click();
    click('전체 편집 시작');click('전체 편집 종료');await pause(450);const after=window.getBoundingClientRect();
    return{same:document.querySelector('[data-uic-reset-column]').closest('.wml-win')===window,
      size:Math.abs(after.width-before.width)<1&&Math.abs(after.height-before.height)<1,
      position:after.x===before.x&&after.y===before.y,controls:window.querySelectorAll('[data-uic-reset-column]').length===4};
  `);
  if(!mobile)await check('invalid zero window size recovers while valid user size is retained',`
    closeManager();await pause(350);const key='wml.win.ui-customize:ui-customize-manager';
    localStorage.setItem(key,JSON.stringify({x:8,y:8,w:0,h:0}));ui.openSettings();await pause(80);
    const window=document.querySelector('[data-uic-reset-column]').closest('.wml-win'),r=window.getBoundingClientRect(),placement=window.querySelector('[data-uic-manager-row=placement]').getBoundingClientRect();
    const recovered=r.width>=620&&r.height>=390&&placement.bottom<r.bottom;
    window.style.width='530px';window.style.height='420px';await pause(350);click('그녀 배치 복원');
    const retained=window.getBoundingClientRect().width===530&&window.getBoundingClientRect().height===420;
    return{recovered,retained};
  `);
  await check('restored layout saves without modifying game; settings controls fit viewport',`
    ui.resetColumn('focus');ui.openSettings();await pause(80);const buttons=[...document.querySelectorAll('[data-uic-reset-column]')],window=buttons[0].closest('.wml-win'),r=window.getBoundingClientRect();
    const fit=r.left>=-1&&r.right<=innerWidth+1&&window.scrollWidth<=window.clientWidth+1;
    closeManager();ui.setEditing(true);await pause(70);globalThis.expected=JSON.stringify(ui.getLayout());globalThis.beforeGame=JSON.stringify(d.store.game());
    d.store.get().saveToSlot(0);return{fit,buttons:buttons.length===4,saved:JSON.stringify(d.store.game())===beforeGame,unique:[...document.querySelectorAll('[data-uic-block]')].every(n=>document.querySelectorAll('[data-uic-block="'+n.dataset.uicBlock+'"]').length===1)};
  `);
  const expected=await run('return expected;');assert.deepEqual((await playReload({})).failed,[]);
  await check('restored layout and selection remain usable after actual slot reload',`
    ${globals}d.store.get().loadFromSlot(0);await pause(220);const before=JSON.stringify(d.store.game()),same=JSON.stringify(ui.getLayout())===${JSON.stringify(expected)};
    ui.openSettings();const label=[...document.querySelector('[data-uic-select=source]').options].find(n=>n.value==='inner-thought').textContent;
    return{same,label:label==='그녀 - 그녀의 속마음',game:JSON.stringify(d.store.game())===before};
  `);
  fs.writeFileSync(new URL('columns-'+tag+'.jpg',import.meta.url),Buffer.from(await playScreenshot({}),'base64'));
  report.status=await playStatus({});assert.deepEqual(report.status.failed,[]);assert.deepEqual(report.status.pageErrors,[]);
  report.protected=Object.fromEntries(protectedFiles.map(file=>[file,{before:beforeHashes[file],after:hash(file)}]));
  for(const [file,pair]of Object.entries(report.protected))assert.equal(pair.before,pair.after,file);
  console.log('PASS',tag,report.cases.length,'cases',report.status.loaded.length,'mods');
}catch(error){report.error=String(error.stack||error);report.status=await playStatus({});console.error(report.error);process.exitCode=1;}
finally{fs.writeFileSync(new URL('result-columns-'+tag+'.json',import.meta.url),JSON.stringify(report,null,2));await shutdown();}
process.exit(process.exitCode||0);
