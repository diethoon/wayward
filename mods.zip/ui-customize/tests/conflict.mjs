// Verify deliberate layout-grid coexistence guard without editing user's toggles/list.
import fs from 'node:fs';import assert from 'node:assert/strict';
import {playStart,playEval,playReload,playStatus,shutdown} from '../../../../MCP/lib/play.mjs';
let report={};
try{
 const first=await playStart({fresh:true,mods:{'layout-grid':true}});
 await playEval({code:`localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify([...first.loaded,'ui-customize'])}));localStorage.setItem('wml.toggles',JSON.stringify({...JSON.parse(localStorage.getItem('wml.toggles')||'{}'),'layout-grid':true,'ui-customize':true}));return true;`});
 const loaded=await playReload({});
 assert.ok(loaded.loaded.includes('layout-grid'));
 assert.ok(loaded.failed.some(x=>x.id==='ui-customize'&&/layout-grid|화면 블록 배치|같이 켤 수/.test(x.error)),JSON.stringify(loaded.failed));
 const r=await playEval({code:`const d=WML.dev();d.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true,imageBackendMode:'off'});d.store.get().newGame();d.fn('store').setState({started:true,selectingArchetype:false,selectingBuilder:false,selectingPicks:false});await new Promise(r=>setTimeout(r,200));[...document.querySelectorAll('button')].find(n=>n.textContent.trim()==='건너뛰기')?.click();await new Promise(r=>setTimeout(r,150));return {native:!!document.querySelector('div.hidden[class*="lg:flex"]'),noReplacement:!document.querySelector('[data-ui-customize-root]'),started:d.store.game().day===1};`});
 assert.ok(Object.values(r.result).every(Boolean),JSON.stringify(r));
 report={expectedGuard:loaded.failed.find(x=>x.id==='ui-customize'),result:r.result,status:await playStatus({})};
 assert.deepEqual(report.status.pageErrors,[]);
 console.log('PASS layout-grid guard',JSON.stringify(report.expectedGuard),JSON.stringify(r.result));
}finally{fs.writeFileSync(new URL('./result-conflict.json',import.meta.url),JSON.stringify(report,null,2));await shutdown();setTimeout(()=>process.exit(process.exitCode||0),30);}
