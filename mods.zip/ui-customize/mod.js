// UI_customize — 게임 내부 고정/부유 배치.
// 기본 패널의 의미 단위 구분은 민트좋아의 layout-grid 2.0.1을 참고했습니다.
// 원본: wml/mods/layout-grid/mod.js (화면 블록 배치, author: 민트좋아).
// 좌우/상하 분할 트리·원본 노드 이동·게임 내부 Floating 구현: HL 작업본.
WML.define({
  id:'ui-customize',name:'UI_customize',author:'Hina_Lover',version:"1.4.0",game:"2026-11-01",lang:'ko',
  description:'정보 블록을 좌우·상하로 고정하거나 게임 안에서 자유롭게 띄우고 배치를 저장합니다.',
  tags:['util'],role:'layout',conflicts:['layout-grid'],loadBefore:['h-status','editor'],
  symbols:{
    "uicDesktop": {"raw":{"2026-11-01":"fat"},"doc":"기본 데스크톱 패널 배치"},
    "uicHouse": {"raw":{"2026-11-01":"WB"},"doc":"가게·위치 패널"},
    "uicFocus": {"raw":{"2026-11-01":"Yrt"},"doc":"초상화·상황 정보"},
    "uicReactDom": {"raw":{"2026-11-01":"Fte"},"doc":"React DOM portal API"}
  },
  setup(api){
    if(WML.status().loaded.includes('layout-grid'))throw Error('UI_customize 사용 시 화면 블록 배치(layout-grid)를 끄고 새로고침하세요.');
    const R=api.fn('jsx'),RD=api.fn('uicReactDom');
    const titles={story:'이야기',house:'가게',focus:'그녀',actions:'행동',map:'위치 그림','house-wife-stats':'인물 수치·감정',urgent:'대응 필요 상황',whereabouts:'모두의 현재 위치','night-summary':'오늘 밤 요약',portrait:'초상화·상태','focus-wife-stats':'그녀 정보','patron-info':'손님 관계',acceptance:'그녀가 이러는 이유',surface:'겉으로 드러나는 상태','last-change':'최근 수치 변화',response:'최근 반응','remark-response':'말에 대한 반응','inner-thought':'그녀의 속마음',controls:'개입·이동 조작','bath-service':'목욕탕 진행','card-activity':'카드판 진행'};
    const baseIds=['story','house','focus','actions'],records=new Map(),subscribers=new Set(),unavailableBlocks=new Set();
    const leaf=id=>({type:'leaf',id}),split=(axis,a,b)=>({type:'split',axis,ratio:.5,a,b});
    const columns={house:['map','house-wife-stats','urgent','whereabouts','night-summary','house'],focus:['portrait','focus-wife-stats','patron-info','acceptance','surface','last-change','response','remark-response','inner-thought','controls','bath-service','card-activity','focus']};
    const columnBlocks={story:['story'],house:columns.house,focus:columns.focus,actions:['actions']};
    const originalColumn=id=>baseIds.find(column=>columnBlocks[column].includes(id));
    function settingsTitle(rec){const column=originalColumn(rec.id);return (column?titles[column]:'mod')+' - '+(columns[rec.id]?'추가 정보':rec.title);}
    const nativeIds=new Set([...baseIds,...columns.house,...columns.focus]);
    const stack=ids=>ids.length===1?leaf(ids[0]):{...split('y',leaf(ids[0]),stack(ids.slice(1))),ratio:({map:.42,'house-wife-stats':.54,portrait:.72,whereabouts:.85})[ids[0]]??.5};
    const defaultTree=()=>split('x',split('x',leaf('story'),stack(columns.house)),split('x',stack(columns.focus),leaf('actions')));
    const initial=()=>({version:1,independent:true,tree:defaultTree(),placements:Object.fromEntries([...nativeIds].map(id=>[id,{mode:'dock'}]))});
    const clone=v=>JSON.parse(JSON.stringify(v));
    let config=initial(),editing=false,editMode='none',root=null,mount=null,manager=null,queued=false,sourceId=null,managerTarget='story',managerSide='right',z=1,tabSerial=0;
    function validLayout(saved){
      if(saved?.version!==1||!saved.placements||typeof saved.placements!=='object')return false;
      const seen=new Set(),tabs=new Set();function valid(n,depth=0){if(depth>128||!n)return false;if(n.tab){if(typeof n.tab.id!=='string'||!n.tab.id.startsWith('uic:tab:')||typeof n.tab.title!=='string'||!n.tab.title.trim()||tabs.has(n.tab.id))return false;tabs.add(n.tab.id);}if(n.type==='empty')return !!n.tab;if(n.type==='leaf'){if(typeof n.id!=='string'||seen.has(n.id)||saved.placements[n.id]?.mode!=='dock')return false;seen.add(n.id);return true;}return n.type==='split'&&['x','y'].includes(n.axis)&&Number.isFinite(n.ratio)&&n.ratio>=.05&&n.ratio<=.95&&valid(n.a,depth+1)&&valid(n.b,depth+1);}
      if(!valid(saved.tree)||!baseIds.every(id=>seen.has(id)||saved.placements[id]?.mode==='floating'))return false;
      return Object.entries(saved.placements).every(([id,p])=>p&&['dock','floating'].includes(p.mode)&&(p.mode!=='dock'||seen.has(id))&&(p.mode!=='floating'||!p.rect||['x','y','w','h'].every(k=>Number.isFinite(p.rect[k]))));
    }
    try{const saved=api.settings.get({layout:null}).layout;if(validLayout(saved))config=saved;}catch(error){api.warn('배치 설정을 읽지 못해 기본 배치를 사용합니다: '+error.message);}
    const el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
    function button(text,fn,title){const b=el('button','',text);b.type='button';b.title=title||text;b.onclick=fn;return b;}
    function save(){api.settings.set({layout:clone(config)});}
    function notify(){for(const fn of subscribers)try{fn(publicApi);}catch(e){console.error('[ui-customize]',e);}}
    function mode(id){return config.placements[id]?.mode||'source';}
    function isPlaced(id){return ['dock','floating'].includes(mode(id));}
    function walk(n,fn){if(!n)return;fn(n);if(n.type==='split'){walk(n.a,fn);walk(n.b,fn);}}
    function remove(n,id){if(!n||n.type==='empty')return n;if(n.type==='leaf')return n.id===id?(n.tab?{type:'empty',tab:n.tab}:null):n;const a=remove(n.a,id),b=remove(n.b,id);if(a&&b)return{...n,a,b};const kept=a||b;return n.tab?(kept?{...kept,tab:n.tab}:{type:'empty',tab:n.tab}):kept;}
    function change(fn){fn();save();render();notify();return true;}
    function tabNodes(){const result=[];function visit(n,width=1){if(!n)return;if(!n.tab&&n.type==='split'&&n.axis==='x'){visit(n.a,width*n.ratio);visit(n.b,width*(1-n.ratio));return;}const blocks=[];walk(n,part=>{if(part.type==='leaf')blocks.push(part.id);});const origin=originalColumn(blocks[0]),custom=!!n.tab;result.push({node:n,id:n.tab?.id||'uic:auto:'+blocks[0],title:n.tab?.title||titles[origin]||'탭 '+(result.length+1),blocks,width,custom,empty:n.type==='empty'});}visit(config.tree);return result;}
    function joinTabs(tabs){if(tabs.length===1)return tabs[0].node;const mid=Math.ceil(tabs.length/2),a=tabs.slice(0,mid),b=tabs.slice(mid),weight=list=>list.reduce((sum,t)=>sum+t.width,0);return{...split('x',joinTabs(a),joinTabs(b)),ratio:Math.max(.05,Math.min(.95,weight(a)/weight(tabs)))};}
    function addTab(title=''){const tabs=tabNodes(),used=new Set(tabs.map(t=>t.id));let id;do{id='uic:tab:'+ ++tabSerial;}while(used.has(id));const label=String(title).trim().slice(0,80)||'새 탭 '+(tabs.length+1),node={type:'empty',tab:{id,title:label}};change(()=>{config.tree=joinTabs([...tabs,{node,width:tabs.reduce((sum,t)=>sum+t.width,0)/Math.max(1,tabs.length)}]);});return id;}
    function moveTab(id,target,side='left'){const tabs=tabNodes(),source=tabs.find(t=>t.id===id);if(!source||id===target||!tabs.some(t=>t.id===target)||!['left','right'].includes(side))return false;return change(()=>{const rest=tabs.filter(t=>t!==source),at=rest.findIndex(t=>t.id===target)+(side==='right'?1:0);rest.splice(at,0,source);config.tree=joinTabs(rest);});}
    function removeTab(id){const tabs=tabNodes(),tab=tabs.find(t=>t.id===id);if(!tab?.custom||!tab.empty||tabs.length<2)return false;return change(()=>{config.tree=joinTabs(tabs.filter(t=>t!==tab));if(managerTarget===id)managerTarget='story';});}
    function dockInTab(id,target,side){if(!records.has(id)||!['left','right','top','bottom'].includes(side)||!tabNodes().some(t=>t.id===target&&t.custom))return false;return change(()=>{const tree=remove(config.tree,id);function insert(n){if(n.tab?.id===target){if(n.type==='empty')return{...leaf(id),tab:n.tab};const content={...n};delete content.tab;return{...(['left','top'].includes(side)?split(['left','right'].includes(side)?'x':'y',leaf(id),content):split(['left','right'].includes(side)?'x':'y',content,leaf(id))),tab:n.tab};}return n.type==='split'?{...n,a:insert(n.a),b:insert(n.b)}:n;}config.tree=insert(tree);config.placements[id]={...config.placements[id],mode:'dock'};});}
    function columnTarget(id,excluding){if(!config.independent||!columns[id])return id;const visible=availableTree(config.tree),shown=[];walk(visible,n=>{if(n.type==='leaf')shown.push(n.id);});return columns[id].find(key=>key!==excluding&&shown.includes(key))||columns[id].find(key=>key!==excluding&&mode(key)==='dock')||id;}
    function dock(id,target='story',side='right'){
      if(tabNodes().some(t=>t.id===target&&t.custom))return dockInTab(id,target,side);
      target=columnTarget(target,id);
      if(!records.has(id)||id===target||!['left','right','top','bottom'].includes(side))return false;
      let found=false;walk(config.tree,n=>{if(n.type==='leaf'&&n.id===target)found=true;});if(!found)return false;
      return change(()=>{const tree=remove(config.tree,id);function insert(n){if(n.type==='leaf'&&n.id===target){const content={...n};delete content.tab;const group=['left','top'].includes(side)?split(['left','right'].includes(side)?'x':'y',leaf(id),content):split(['left','right'].includes(side)?'x':'y',content,leaf(id));return n.tab?{...group,tab:n.tab}:group;}return n.type==='split'?{...n,a:insert(n.a),b:insert(n.b)}:n;}config.tree=insert(tree);config.placements[id]={...config.placements[id],mode:'dock'};});
    }
    function float(id){if(!records.has(id))return false;let count=0;walk(config.tree,n=>{if(n.type==='leaf')count++;});if(mode(id)==='dock'&&count===1)return false;
      return change(()=>{config.tree=remove(config.tree,id);config.placements[id]={...config.placements[id],mode:'floating',rect:config.placements[id]?.rect||{x:30+(z%5)*24,y:32+(z%5)*24,w:360,h:400},z:++z};});}
    function dockAtStart(id){let target=null;walk(availableTree(config.tree),n=>{if(!target&&n.type==='leaf'&&n.id!==id)target=n.id;});return target?dock(id,target,'top'):false;}
    function restore(id){if(config.independent&&nativeIds.has(id)&&!baseIds.includes(id)){const peers=Object.values(columns).find(ids=>ids.includes(id)),index=peers.indexOf(id),next=peers.slice(index+1).find(key=>mode(key)==='dock'),previous=peers.slice(0,index).reverse().find(key=>mode(key)==='dock');return next?dock(id,next,'top'):previous?dock(id,previous,'bottom'):dockAtStart(id);}if(baseIds.includes(id)){let target=null;walk(config.tree,n=>{if(!target&&n.type==='leaf'&&n.id!==id)target=n.id;});return target?dock(id,target,'right'):false;}if(!records.has(id))return false;return change(()=>{config.tree=remove(config.tree,id);delete config.placements[id];});}
    function makeRecord(id,title){
      const rec={id,title,slot:el('div','uic-slot'),body:el('div','uic-native'),origin:null,node:null,claimed:false};
      rec.slot.dataset.uicSlot=id;rec.body.dataset.uicBody=id;rec.slot.append(rec.body);records.set(id,rec);return rec;
    }
    function getNative(id){if(records.has(id))return records.get(id);const rec=makeRecord(id,titles[id]||id);schedule();return rec;}
    function sourceSlot(id,content){const rec=getNative(id);rec.hasContent=content!==null&&content!==undefined&&content!==false;
      return R.jsxs('div',{'data-uic-source':id,style:{display:'contents'},ref:n=>{rec.origin=n;if(n&&!isPlaced(id)&&rec.slot.parentNode!==n)n.append(rec.slot);},children:RD.createPortal(content,rec.body,'uic-content-'+id)},'uic-source-'+id);}
    function nativePortal(id,content){const rec=getNative(id);return RD.createPortal(content,rec.body,'uic-base-'+id);}
    function claim(rec){if(!rec.node)return;if(!rec.claimed){rec.marker=document.createComment('ui-customize '+rec.id);rec.node.before(rec.marker);rec.onClaim?.();rec.claimed=true;}if(rec.node.parentNode!==rec.body)rec.body.append(rec.node);}
    function release(rec){if(rec.node&&rec.claimed){if(rec.marker?.parentNode)rec.marker.replaceWith(rec.node);rec.claimed=false;rec.onRelease?.();}else if(!rec.node&&rec.origin&&rec.slot.parentNode!==rec.origin)rec.origin.append(rec.slot);}
    function frame(rec){if(rec.frame)return rec.frame;const box=el('section','uic-block'),head=el('div','uic-head'),label=el('strong','',rec.title),body=el('div','uic-body');
      rec.toggle=button('↗',()=>{if(mode(rec.id)==='floating')dockAtStart(rec.id);else float(rec.id);},'Floating 전환');rec.toggle.dataset.uicToggle=rec.id;
      box.ondblclick=e=>{const r=box.getBoundingClientRect();if(e.target.closest('button,input,select,textarea'))return;if(e.target===box||e.clientX-r.left<=3||r.right-e.clientX<=3||e.clientY-r.top<=3||r.bottom-e.clientY<=3){e.preventDefault();e.stopPropagation();fitHeight(rec.id);}};
      box.dataset.uicBlock=rec.id;if(rec.gameFontSize)box.dataset.uicGameFont='';head.dataset.uicDrag=rec.id;head.append(label,rec.toggle,button('↩',()=>restore(rec.id),'원래 영역으로'),button('배치',()=>{sourceId=rec.id;openSettings();},'고정 위치 선택'));
      head.onpointerdown=e=>{if(e.target.closest('button')||e.button!==0)return;if(mode(rec.id)==='floating')dragFloat(e,rec);else if(editMode==='all')dragDock(e,rec);};
      if(rec.onClose){const close=button('닫기',()=>rec.onClose(),'이 창 닫기');close.dataset.uicClose=rec.id;head.append(close);}
      box.append(head,body);rec.frame=box;rec.head=head;rec.label=label;rec.frameBody=body;
      // Capture before title/resize handlers stop propagation; include restored/preset z values.
      box.addEventListener('pointerdown',()=>{if(mode(rec.id)==='floating'){z=Math.max(z,...Object.values(config.placements).map(p=>Number.isFinite(p.z)?p.z:0))+1;box.style.zIndex=String(z);config.placements[rec.id].z=z;save();}},{passive:true,capture:true});
      const resize=el('div','uic-float-resize');resize.title='크기 조절';resize.onpointerdown=e=>resizeFloat(e,rec);box.append(resize);return box;
    }
    function startPointer(e,move,done){e.preventDefault();e.stopPropagation();const id=e.pointerId;const target=e.currentTarget;try{target.setPointerCapture(id);}catch{}
      const onMove=p=>{if(p.pointerId===id)move(p);},end=p=>{if(p.pointerId!==id)return;window.removeEventListener('pointermove',onMove);window.removeEventListener('pointerup',end);window.removeEventListener('pointercancel',end);try{target.releasePointerCapture(id);}catch{}done?.();};
      window.addEventListener('pointermove',onMove);window.addEventListener('pointerup',end);window.addEventListener('pointercancel',end);
    }
    function rectFor(rec){const layer=root.querySelector('[data-uic-floats]'),width=layer.clientWidth,height=layer.clientHeight,r=config.placements[rec.id].rect||{x:24,y:24,w:360,h:400},w=Math.min(width,Math.max(160,r.w||360)),h=Math.min(height,Math.max(100,r.h||400));return{x:Math.max(0,Math.min(r.x||0,width-w)),y:Math.max(0,Math.min(r.y||0,height-h)),w,h};}
    function paintFloat(rec){const r=rectFor(rec);Object.assign(rec.frame.style,{left:r.x+'px',top:r.y+'px',width:r.w+'px',height:r.h+'px',zIndex:String(config.placements[rec.id].z||1)});}
    function dragFloat(e,rec){const r=rectFor(rec),sx=e.clientX,sy=e.clientY;startPointer(e,p=>{config.placements[rec.id].rect={...r,x:r.x+p.clientX-sx,y:r.y+p.clientY-sy};paintFloat(rec);},()=>{config.placements[rec.id].rect=rectFor(rec);save();});}
    function resizeFloat(e,rec){const r=rectFor(rec),sx=e.clientX,sy=e.clientY;startPointer(e,p=>{config.placements[rec.id].rect={...r,w:Math.max(160,r.w+p.clientX-sx),h:Math.max(100,r.h+p.clientY-sy)};paintFloat(rec);},()=>{config.placements[rec.id].rect=rectFor(rec);save();});}
    function fitHeight(id){
      if(editMode==='tabs'&&mode(id)==='dock')return false;
      const rec=records.get(id);if(!rec?.frame?.isConnected||!isPlaced(id))return false;
      const box=rec.frame,head=rec.head.offsetHeight,nodes=[rec.body,rec.slot,rec.node].filter(Boolean),styles=nodes.map(n=>n.style.height);
      let content;try{nodes.forEach(n=>n.style.height='auto');content=Math.ceil(Math.max(rec.body.scrollHeight,rec.body.getBoundingClientRect().height));}finally{nodes.forEach((n,i)=>n.style.height=styles[i]);}
      const limit=root.querySelector('[data-uic-floats]').clientHeight,wanted=Math.max(50,Math.min(limit,content+head+2));
      if(mode(id)==='floating'){const old=rectFor(rec);config.placements[id].rect={...old,h:Math.max(Math.min(100,limit),wanted)};config.placements[id].rect=rectFor(rec);paintFloat(rec);save();notify();return true;}
      config.placements[id].fitHeight=wanted;
      const tree=availableTree(config.tree),has=n=>!!n&&(n.type==='leaf'?n.id===id:n.type==='split'&&(has(n.a)||has(n.b)));
      const minimum=n=>n.type!=='split'?50:n.axis==='y'?minimum(n.a)+minimum(n.b)+1:Math.max(minimum(n.a),minimum(n.b));
      const demand=n=>!has(n)?minimum(n):n.type==='leaf'?wanted:n.axis==='y'?demand(n.a)+demand(n.b)+1:Math.max(demand(n.a),demand(n.b));
      function resize(n,height){if(n.type!=='split')return;if(n.axis==='x'){if(has(n.a))resize(n.a,height);if(has(n.b))resize(n.b,height);return;}
        const first=has(n.a),target=first?n.a:n.b,other=first?n.b:n.a,space=Math.max(1,height-1),size=Math.min(Math.max(0,space-minimum(other)),demand(target));
        n.ratio=Math.max(.05,Math.min(.95,first?size/space:1-size/space));if(visibleSources.has(n))visibleSources.get(n).ratio=n.ratio;resize(target,space*(first?n.ratio:1-n.ratio));}
      if(tree)resize(tree,root.querySelector('[data-uic-work]').clientHeight);save();render();notify();return true;
    }
    function hasVerticalParent(id){let result=false;function find(n,vertical=false){if(!n)return;if(n.type==='leaf'){if(n.id===id)result=vertical;}else if(n.type==='split'){find(n.a,vertical||n.axis==='y');find(n.b,vertical||n.axis==='y');}}find(availableTree(config.tree));return result;}
    function dragDock(e,rec){let target=null,side='right';startPointer(e,p=>{document.querySelectorAll('.uic-drop-target').forEach(n=>n.classList.remove('uic-drop-target'));rec.frame.style.pointerEvents='none';const n=document.elementFromPoint(p.clientX,p.clientY)?.closest('[data-uic-block]');rec.frame.style.pointerEvents='';target=n?.dataset.uicBlock;if(!n||target===rec.id)return;const r=n.getBoundingClientRect(),x=(p.clientX-r.x)/r.width,y=(p.clientY-r.y)/r.height;side=x<.25?'left':x>.75?'right':y<.5?'top':'bottom';n.classList.add('uic-drop-target');n.dataset.uicDropSide=side;},()=>{document.querySelectorAll('.uic-drop-target').forEach(n=>n.classList.remove('uic-drop-target'));if(target&&target!==rec.id)dock(rec.id,target,side);});}
    let renderTabs=new WeakMap(),visibleTabs=new WeakMap();
    function tabFrame(tab,content){const box=el('section','uic-column'),head=el('div','uic-column-head'),body=el('div','uic-column-body');box.dataset.uicTab=tab.id;head.dataset.uicTabDrag=tab.id;head.append(el('strong','',tab.title));const tabs=tabNodes(),index=tabs.findIndex(t=>t.id===tab.id);
      for(const [offset,label]of [[-1,'←'],[1,'→']]){const b=button(label,()=>{const target=tabs[index+offset];if(target)moveTab(tab.id,target.id,offset<0?'left':'right');},'탭을 '+(offset<0?'왼쪽':'오른쪽')+'으로');b.disabled=!tabs[index+offset]||!['all','tabs'].includes(editMode);head.append(b);}
      if(tab.custom){const close=button('빈 탭 삭제',()=>{if(removeTab(tab.id)&&manager)openSettings();});close.disabled=!tab.empty||!['none','all','tabs'].includes(editMode);head.append(close);}
      head.onpointerdown=e=>{if(e.button!==0||e.target.closest('button')||!['all','tabs'].includes(editMode))return;let target=null,side='left';startPointer(e,p=>{for(const n of root.querySelectorAll('.uic-tab-target'))n.classList.remove('uic-tab-target');const n=document.elementFromPoint(p.clientX,p.clientY)?.closest('[data-uic-tab]');if(!n||n.dataset.uicTab===tab.id)return;target=n.dataset.uicTab;side=p.clientX<n.getBoundingClientRect().left+n.getBoundingClientRect().width/2?'left':'right';n.classList.add('uic-tab-target');},()=>{for(const n of root.querySelectorAll('.uic-tab-target'))n.classList.remove('uic-tab-target');if(target)moveTab(tab.id,target,side);});};
      body.append(content);box.append(head,body);return box;}
    function buildTree(n,path='',scope=null){
      if(!n)return el('div','');const tab=visibleTabs.get(n);if(tab&&scope!==tab.id)return tabFrame(tab,buildTree(n,path,tab.id));
      if(n.type==='empty'){const empty=el('div','uic-empty-tab','빈 탭 · 전체 편집에서 블록을 배치하세요.');return empty;}
      if(n.type==='leaf'){const rec=records.get(n.id);if(!rec){const empty=el('div','uic-unavailable');empty.textContent=(titles[n.id]||n.id)+' · 연결 대기';if(!baseIds.includes(n.id))empty.append(button('이 자리 제거',()=>change(()=>{config.tree=remove(config.tree,n.id);delete config.placements[n.id];})));return empty;}return frame(rec);}
      const group=el('div','uic-split uic-axis-'+n.axis),a=el('div','uic-branch'),b=el('div','uic-branch'),grip=el('div','uic-divider');grip.setAttribute('role','separator');grip.setAttribute('aria-label','블록 크기 조절');grip.tabIndex=0;grip.dataset.uicSplit=path;
      const kind=scope?'blocks':'tabs',allowed=editMode==='all'||editMode==='inside'&&!!scope&&n.axis==='y'||editMode==='tabs'&&!scope&&n.axis==='x';grip.dataset.uicSplitKind=kind;grip.dataset.uicResizeEnabled=String(allowed);grip.tabIndex=allowed?0:-1;grip.setAttribute('aria-disabled',String(!allowed));
      if(kind==='tabs'&&editMode==='tabs'){const count=node=>visibleTabs.has(node)||node.type!=='split'?1:count(node.a)+count(node.b),minimum=matchMedia('(max-width:760px)').matches?180:100;a.style.minWidth=count(n.a)*minimum+'px';b.style.minWidth=count(n.b)*minimum+'px';group.style.minWidth=(count(n)*minimum+count(n)-1)+'px';}
      a.style.flex=String(n.ratio);b.style.flex=String(1-n.ratio);a.append(buildTree(n.a,path+'a',scope));b.append(buildTree(n.b,path+'b',scope));group.append(a,grip,b);
      const ratio=value=>{n.ratio=Math.min(.95,Math.max(.05,value));if(visibleSources.has(n))visibleSources.get(n).ratio=n.ratio;a.style.flex=String(n.ratio);b.style.flex=String(1-n.ratio);};
      grip.ondblclick=e=>{if(!allowed||kind==='tabs')return;e.preventDefault();e.stopPropagation();const pick=node=>node.type==='leaf'?node.id:node.type==='split'?pick(node.b):null;const id=pick(n.a);if(id)fitHeight(id);};
      grip.onpointerdown=e=>{if(!allowed)return;const r=group.getBoundingClientRect();startPointer(e,p=>ratio(n.axis==='x'?(p.clientX-r.x)/r.width:(p.clientY-r.y)/r.height),save);};
      grip.onkeydown=e=>{if(allowed&&['ArrowLeft','ArrowUp','ArrowRight','ArrowDown'].includes(e.key)){e.preventDefault();ratio(n.ratio+(['ArrowLeft','ArrowUp'].includes(e.key)?-.02:.02));save();}};return group;
    }
    const visibleSources=new WeakMap();
    function availableTree(node){if(!node)return null;let shown;if(node.type==='empty')shown=node;else if(node.type==='leaf')shown=unavailableBlocks.has(node.id)||(config.independent&&nativeIds.has(node.id)&&!['story','actions'].includes(node.id)&&!records.get(node.id)?.renderable)?null:node;else{const a=availableTree(node.a),b=availableTree(node.b);shown=!a||!b?a||b:a===node.a&&b===node.b?node:{...node,a,b};if(shown&&shown!==node&&a&&b)visibleSources.set(shown,node);}if(shown&&renderTabs.has(node))visibleTabs.set(shown,renderTabs.get(node));return shown;}
    // Keep portal origins connected even when empty residual house/focus containers are hidden.
    function measureNative(){let changed=false;for(const rec of records.values()){if(rec.node||!nativeIds.has(rec.id))continue;const visible=!!rec.body.textContent.trim()||!!rec.body.querySelector('img,video,canvas,svg,input,button');if(visible!==rec.renderable){rec.renderable=visible;changed=true;}}if(changed&&config.independent)schedule();}
    function setBlockAvailable(id,available=true){if(available===!unavailableBlocks.has(id))return;if(available)unavailableBlocks.delete(id);else unavailableBlocks.add(id);schedule();}
    function render(){if(!root?.isConnected)return;root.classList.toggle('uic-editing',editing);root.dataset.uicEditMode=editMode;root.classList.toggle('uic-full-edit',editMode==='all');root.classList.toggle('uic-tabs-edit',editMode==='tabs');renderTabs=new WeakMap();visibleTabs=new WeakMap();for(const tab of tabNodes())renderTabs.set(tab.node,tab);
      let toolbar=root.querySelector('[data-uic-toolbar]');
      if(editing&&!toolbar){toolbar=el('div','');toolbar.dataset.uicToolbar='';const done=button('편집 완료',()=>setEditing(false));done.dataset.uicEditDone='';toolbar.append(done);root.prepend(toolbar);}
      if(!editing&&toolbar){toolbar.remove();toolbar=null;}
      root.querySelector('[data-uic-floats]').style.top=(toolbar?.offsetHeight||0)+'px';
      // Detach persistent frames before replacing structural containers; portal targets retain identity.
      for(const rec of records.values()){if(rec.frame?.parentNode)rec.frame.remove();if(isPlaced(rec.id)){if(rec.node)claim(rec);}else{release(rec);}}
      const work=root.querySelector('[data-uic-work]'),floats=root.querySelector('[data-uic-floats]');work.replaceChildren(buildTree(availableTree(config.tree)));floats.replaceChildren();
      for(const rec of records.values()){
        rec.label&&(rec.label.textContent=rec.title);
        if(isPlaced(rec.id)){const box=frame(rec);const floating=mode(rec.id)==='floating';rec.toggle.textContent=floating?(rec.dockLabel||'고정 전환'):'↗';rec.toggle.title=floating?(rec.dockLabel||'고정 전환'):'Floating 전환';rec.toggle.setAttribute('aria-label',rec.toggle.title);if(config.independent&&nativeIds.has(rec.id)&&!rec.renderable&&!floating)root.querySelector('[data-uic-origins]').append(rec.slot);else rec.frameBody.append(rec.slot);box.classList.toggle('uic-floating',mode(rec.id)==='floating');box.classList.toggle('uic-docked',mode(rec.id)==='dock');box.style.cssText='';const fitted=config.placements[rec.id].fitHeight;if(!floating&&fitted&&(matchMedia('(max-width:760px)').matches||!hasVerticalParent(rec.id))){Object.assign(box.style,{height:fitted+'px',minHeight:'50px',maxHeight:Math.min(fitted,root.clientHeight)+'px',flex:'none',width:'100%',alignSelf:'start'});}if(mode(rec.id)==='floating'){floats.append(box);paintFloat(rec);}}
        else if(!rec.node&&rec.origin?.isConnected){rec.origin.append(rec.slot);}
        if(rec.toggle){for(const b of rec.head.querySelectorAll('button'))if(!b.dataset.uicClose)b.disabled=['inside','tabs'].includes(editMode);}
        rec.slot.classList.toggle('uic-source-slot',!isPlaced(rec.id));let handle=rec.slot.querySelector(':scope > .uic-source-handle');if(!handle){handle=button('↗ '+rec.title,()=>float(rec.id),'블록 분리');handle.className='uic-source-handle';rec.slot.prepend(handle);}handle.hidden=editMode!=='all'||isPlaced(rec.id)||!rec.hasContent;
      }
    }
    function schedule(){if(queued)return;queued=true;queueMicrotask(()=>{queued=false;render();});}
    function registerBlock(def){if(!def||typeof def.id!=='string'||!(def.node instanceof Element))throw Error('블록 ID와 원본 DOM 노드가 필요합니다.');if(records.has(def.id))throw Error('이미 등록된 블록: '+def.id);
      const rec=makeRecord(def.id,def.title||def.id);Object.assign(rec,def,{hasContent:true});schedule();notify();let live=true;return()=>{if(!live)return;live=false;release(rec);rec.frame?.remove();rec.slot.remove();records.delete(def.id);schedule();notify();};}
    function updateBlock(id,patch){const rec=records.get(id);if(!rec)return false;if(patch.node&&patch.node!==rec.node){release(rec);rec.node=patch.node;}if(patch.title)rec.title=patch.title;schedule();return true;}
    function reset(){return change(()=>{for(const rec of records.values())release(rec);config=initial();});}
    // Remove only this column's native leaves. All foreign placement values and the
    // remaining split tree (including mod windows) survive unchanged under pruning.
    function resetColumn(column){
      if(!baseIds.includes(column))return false;
      return change(()=>{
        const ids=columnBlocks[column],index=baseIds.indexOf(column);
        let remaining=config.tree;
        for(const id of ids){remaining=remove(remaining,id);config.placements[id]={mode:'dock'};}
        config.independent=true;
        const restored=stack(ids);
        if(!remaining){config.tree=restored;return;}
        const present=new Set();walk(remaining,n=>{if(n.type==='leaf')present.add(n.id);});
        // Prefer the default tree's sibling column, then the nearest original
        // neighbour. Floating/temporarily absent neighbours are never reset.
        const preferred={story:'house',house:'story',focus:'actions',actions:'focus'}[column];
        const neighbours=baseIds.filter(id=>id!==column&&columnBlocks[id].some(key=>present.has(key)))
          .sort((a,b)=>(a===preferred?-1:b===preferred?1:Math.abs(baseIds.indexOf(a)-index)-Math.abs(baseIds.indexOf(b)-index)));
        const neighbour=neighbours[0];
        if(!neighbour){config.tree=split('x',index<2?restored:remaining,index<2?remaining:restored);return;}
        const anchor=columnBlocks[neighbour].find(id=>present.has(id));
        // Keep an intact neighbouring column and the mod windows attached to it
        // together. A scattered neighbour falls back to the branch of its anchor.
        function owners(n){const found=new Set();walk(n,part=>{if(part.type==='leaf'){const owner=originalColumn(part.id);if(owner)found.add(owner);}});return found;}
        let target;
        function locate(n){
          if(!n)return false;
          if(n.type==='leaf'){if(n.id===anchor){target=n;return true;}return false;}
          if(locate(n.a)||locate(n.b)){const groups=owners(n);if(groups.size===1&&groups.has(neighbour))target=n;return true;}
          return false;
        }
        locate(remaining);
        const before=index<baseIds.indexOf(neighbour);
        function insert(n){if(n===target)return split('x',before?restored:n,before?n:restored);return n.type==='split'?{...n,a:insert(n.a),b:insert(n.b)}:n;}
        config.tree=insert(remaining);
      });
    }
    function setEditMode(value){if(!['none','all','inside','tabs'].includes(value))return false;editMode=value;editing=value!=='none';render();manager?.refresh();return editMode;}
    function setEditing(value){setEditMode(value?'all':'none');return editing;}
    function openSettings(){if(manager?.el.isConnected){manager.focus();manager.refresh();return;}manager=api.ui.window({id:'ui-customize-manager',title:'UI_customize · 배치',width:620,height:390,render(body,handle){handle.el.style.setProperty('z-index','2147483647','important');
      // Older repeated close/reopen cycles could persist a detached window's zero
      // dimensions. Recover only invalid geometry; keep intentional user resizes.
      if(!(parseFloat(handle.el.style.width)>0)||!(parseFloat(handle.el.style.height)>0)){
        const w=Math.min(620,innerWidth-16),h=Math.min(390,innerHeight-16);
        Object.assign(handle.el.style,{width:w+'px',height:h+'px',left:Math.max(8,(innerWidth-w)/2)+'px',top:Math.max(8,(innerHeight-h)/3)+'px'});
      }
      const editRow=el('div','uic-manager-row');editRow.dataset.uicManagerRow='editing';for(const [mode,label]of [['all','전체 편집'],['inside','탭 내부 배치 편집'],['tabs','탭 간 배치 변경']]){const b=button(label+(editMode===mode?' 종료':' 시작'),()=>setEditMode(editMode===mode?'none':mode));b.dataset.uicEditModeButton=mode;b.setAttribute('aria-pressed',String(editMode===mode));editRow.append(b);}body.append(editRow);
      const presets=el('div','uic-manager-row');presets.dataset.uicManagerRow='presets';presets.append(button('배치 저장',()=>{api.settings.set({preset:clone(config)});api.ui.toast?.('배치를 저장했습니다.');}),button('배치 불러오기',()=>{const p=api.settings.get({preset:null}).preset;if(validLayout(p)){config=clone(p);save();render();notify();openSettings();}}));body.append(presets);
      const actions=el('div','uic-manager-row');actions.dataset.uicManagerRow='recovery';actions.append(button('화면 안으로 모으기',()=>{for(const rec of records.values())if(mode(rec.id)==='floating')config.placements[rec.id].rect=rectFor(rec);save();render();}),button('모든 창 배치를 복원',()=>{reset();openSettings();}));body.append(actions);
      const columnRecovery=el('div','uic-manager-row');columnRecovery.dataset.uicManagerRow='column-recovery';
      for(const id of baseIds){const restoreButton=button(titles[id]+' 배치 복원',()=>{resetColumn(id);openSettings();});restoreButton.dataset.uicResetColumn=id;columnRecovery.append(restoreButton);}body.append(columnRecovery);
      const addRow=el('div','uic-manager-row');addRow.dataset.uicManagerRow='tabs';const name=el('input');name.placeholder='새 탭 이름';name.maxLength=80;name.setAttribute('aria-label','새 탭 이름');const add=button('새 탭 추가',()=>{managerTarget=addTab(name.value);openSettings();});add.dataset.uicAddTab='';add.disabled=editMode==='inside';addRow.append(name,add);body.append(addRow);
      const src=el('select',''),dest=el('select',''),side=el('select','');src.dataset.uicSelect='source';dest.dataset.uicSelect='target';side.dataset.uicSelect='side';src.setAttribute('aria-label','세부 창 선택');dest.setAttribute('aria-label','Column 선택');side.setAttribute('aria-label','배치 위치');
      for(const rec of records.values())src.add(new Option(settingsTitle(rec),rec.id));
      const columnReady=id=>tabNodes().some(t=>t.custom&&t.id===id)||mode(columnTarget(id))==='dock';
      for(const id of baseIds){const option=new Option(titles[id]+(columnReady(id)?'':' (Floating)'),id);option.disabled=!columnReady(id);dest.add(option);}
      for(const tab of tabNodes().filter(t=>t.custom))dest.add(new Option(tab.title,tab.id));
      for(const [k,v]of Object.entries({left:'왼쪽',right:'오른쪽',top:'위',bottom:'아래'}))side.add(new Option(v,k));
      if(sourceId&&records.has(sourceId))src.value=sourceId;sourceId=src.value;dest.value=columnReady(managerTarget)?managerTarget:(baseIds.find(columnReady)||'');side.value=managerSide;
      src.onchange=()=>{sourceId=src.value;};dest.onchange=()=>{managerTarget=dest.value;};side.onchange=()=>{managerSide=side.value;};
      const remember=()=>{sourceId=src.value;managerTarget=dest.value;managerSide=side.value;};
      const row=el('div','uic-manager-row uic-placement-row');row.dataset.uicManagerRow='placement';row.append(src,dest,side,button('고정',()=>{remember();if(dock(src.value,dest.value,side.value))openSettings();}),button('Floating',()=>{remember();if(float(src.value))openSettings();}),button('원래 영역',()=>{remember();if(restore(src.value))openSettings();}));body.append(row);
      if(['inside','tabs'].includes(editMode))for(const control of row.querySelectorAll('select,button'))control.disabled=true;
      body.append(el('p','','기본 4열과 독립 블록의 크기는 경계에서 조절합니다. 화면이 좁으면 고정 블록을 세로로 표시합니다.'));},onClose(){manager=null;}});}
    // Migrate adapter identities while preserving split ratios and saved presets.
    function migrateBlockIds(mapping){
      const migrate=saved=>{if(!validLayout(saved))return saved;const next=clone(saved);
        for(const [old,id]of Object.entries(mapping)){if(old===id||!next.placements[old])continue;
          if(!id||next.placements[id]){next.tree=remove(next.tree,old);delete next.placements[old];continue;}
          next.placements[id]=next.placements[old];delete next.placements[old];walk(next.tree,n=>{if(n.type==='leaf'&&n.id===old)n.id=id;});}
        return validLayout(next)?next:saved;};
      config=migrate(config);const preset=api.settings.get({preset:null}).preset;if(preset)api.settings.set({preset:migrate(preset)});save();schedule();notify();
    }
    const publicApi={fitHeight,registerBlock,updateBlock,isPlaced,dock,float,restore,reset,resetColumn,setEditing,setEditMode,get editMode(){return editMode;},addTab,moveTab,removeTab,listTabs:()=>tabNodes().map(({node,...tab})=>({...tab,blocks:[...tab.blocks]})),openSettings,migrateBlockIds,setBlockAvailable,listBlocks:()=>[...records.values()].map(r=>({id:r.id,title:r.title,mode:mode(r.id)})),getLayout:()=>clone(config),subscribe(fn){subscribers.add(fn);fn(publicApi);return()=>subscribers.delete(fn);},get active(){return !!root?.isConnected;}};
    api.provide(publicApi);
    const style=el('style');style.textContent=`
      .uic-desktop-host{display:flex!important}.uic-mobile-hidden{display:none!important}
      [data-ui-customize-root]{position:relative;isolation:isolate;flex:1;min-width:0;min-height:0;display:flex;flex-direction:column;overflow:hidden;color:#d6d3d1;background:#0c0a09;font-size:12px}
      [data-uic-toolbar]{flex:0 0 auto;position:relative;z-index:1000000;display:flex;align-items:center;padding:2px 6px;border-bottom:1px solid #292524;background:#1c1917;font-size:11px}
      [data-uic-toolbar]>button,.uic-head>button,.uic-source-handle,.uic-manager-row button{cursor:pointer;border:1px solid #57534e;background:#292524;color:#fde68a;border-radius:3px;padding:2px 5px}
      [data-uic-work]{flex:1;min-height:0;overflow:auto;display:flex}[data-uic-work]>.uic-split,[data-uic-work]>.uic-block{flex:1}
      .uic-split{display:flex;width:100%;height:100%;min-width:0;min-height:0}.uic-axis-y{flex-direction:column}.uic-branch{display:flex;min-width:60px;min-height:50px;overflow:hidden;flex-basis:0!important}.uic-branch>.uic-block{flex:1}
      .uic-column{display:flex;flex-direction:column;flex:1;min-width:0;min-height:0;width:100%;height:100%;overflow:hidden}.uic-column-body{display:flex;flex:1;min-width:0;min-height:0}.uic-column-body>.uic-block{flex:1}.uic-column-head{display:none;align-items:center;gap:4px;min-height:25px;padding:2px 4px;flex-shrink:0;border-bottom:1px solid #44403c;background:#1c1917;cursor:move;touch-action:none}.uic-column-head strong{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.uic-column-head button{font:inherit;color:#fde68a;background:#292524;border:1px solid #57534e;border-radius:3px;padding:1px 5px}.uic-full-edit .uic-column-head,.uic-tabs-edit .uic-column-head{display:flex}.uic-tab-target{outline:2px solid #f59e0b;outline-offset:-3px}.uic-empty-tab{padding:12px;color:#78716c;overflow-wrap:anywhere}.uic-divider[data-uic-resize-enabled="false"]{cursor:default;pointer-events:none}[data-uic-edit-mode="inside"] .uic-head{cursor:default}[data-uic-edit-mode="tabs"] .uic-docked>.uic-head{display:none}.uic-manager-row input{min-width:0;max-width:100%;padding:4px;background:#292524;color:#e7e5e4;border:1px solid #57534e}.uic-column-head button:disabled,.uic-head button:disabled,.uic-manager-row button:disabled{cursor:default;opacity:.45}
      .uic-block{position:relative;display:flex;flex-direction:column;min-width:0;min-height:0;border:1px solid #292524;background:#0c0a09;overflow:hidden}
      .uic-head{display:none;align-items:center;gap:4px;flex:0 0 auto;min-height:24px;padding:1px 4px;background:#292524;cursor:move;touch-action:none;font-size:10px}.uic-head strong{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      .uic-editing .uic-head,.uic-floating .uic-head{display:flex}.uic-body{flex:1;min-height:0;overflow:auto}.uic-slot{min-width:0;min-height:0}.uic-body>.uic-slot{height:100%}.uic-native{min-height:0;height:100%}.uic-source-slot{flex-shrink:0}.uic-source-slot>.uic-native{height:auto}
      .uic-divider{position:relative;flex:0 0 1px;background:#44403c;z-index:12;touch-action:none;cursor:col-resize}.uic-axis-y>.uic-divider{cursor:row-resize}.uic-divider:before{content:'';position:absolute;inset:0 -3px}.uic-axis-y>.uic-divider:before{inset:-3px 0}.uic-divider:hover,.uic-divider:focus{background:#f59e0b;outline:none}
      [data-uic-floats]{position:absolute;inset:0;pointer-events:none;overflow:hidden}.uic-floating{position:absolute;pointer-events:auto;box-shadow:0 5px 20px #0009;border-color:#78716c}.uic-float-resize{display:none}.uic-floating .uic-float-resize{display:block;position:absolute;right:0;bottom:0;width:12px;height:12px;cursor:nwse-resize;touch-action:none;border-right:2px solid #a8a29e;border-bottom:2px solid #a8a29e}
      .uic-source-handle{font-size:10px}.uic-drop-target{outline:2px solid #f59e0b;outline-offset:-3px}.uic-unavailable{color:#78716c;padding:8px}.uic-manager-row{display:flex;gap:6px;flex-wrap:wrap;margin:12px 0}.uic-manager-row select{background:#292524;color:#e7e5e4;max-width:100%;padding:4px}
      .uic-placement-row{display:grid;grid-template-columns:minmax(110px,2fr) minmax(65px,1fr) minmax(60px,.8fr) repeat(3,auto)}.uic-placement-row select{min-width:0;width:100%}
      @media(max-width:640px){.uic-placement-row{grid-template-columns:repeat(3,minmax(0,1fr))}}
      @media(max-width:760px){[data-uic-work]{display:block;overflow:auto}.uic-split{height:auto;flex-direction:column}.uic-branch{display:block;flex:none!important;min-height:160px;overflow:visible}.uic-docked{min-height:160px;max-height:70vh}.uic-divider{display:none}[data-uic-work]>.uic-block{height:60vh}}
      @media(max-width:760px){.uic-column{height:auto;min-height:160px}.uic-column-body{display:block}.uic-column-body>.uic-block{min-height:160px}.uic-tabs-edit [data-uic-work]{display:flex}.uic-tabs-edit .uic-axis-x{display:flex;flex-direction:row;height:100%}.uic-tabs-edit .uic-axis-x>.uic-branch{display:flex;flex-basis:0!important;flex-shrink:1!important;min-width:100px;overflow:hidden}.uic-tabs-edit .uic-axis-x>.uic-divider{display:block}.uic-tabs-edit .uic-column{height:100%}}
      @media(max-width:760px){[data-uic-edit-mode="inside"] .uic-column{height:70vh;min-height:240px}[data-uic-edit-mode="inside"] .uic-column-body{display:flex;min-height:0}[data-uic-edit-mode="inside"] .uic-axis-y{height:100%;display:flex;flex-direction:column}[data-uic-edit-mode="inside"] .uic-axis-y>.uic-branch{display:flex;flex-basis:0!important;flex-shrink:1!important;min-height:50px;overflow:hidden}[data-uic-edit-mode="inside"] .uic-axis-y>.uic-divider{display:block}[data-uic-edit-mode="inside"] .uic-docked{min-height:0;max-height:none}}
      [data-uic-game-font]>.uic-head{font-size:.625rem}[data-uic-game-font]>.uic-head button{font:inherit}
    `;document.head.append(style);
    function mountRoot(node){if(!node){mount=null;root?.remove();notify();return;}mount=node;const host=node.parentElement;if(host?.classList.contains('lg:flex')){host.classList.add('uic-desktop-host');host.nextElementSibling?.classList.add('uic-mobile-hidden');}if(!root){root=el('div','');root.dataset.uiCustomizeRoot='';const work=el('div','');work.dataset.uicWork='';const floats=el('div','');floats.dataset.uicFloats='';const origins=el('div','');origins.hidden=true;origins.dataset.uicOrigins='';root.append(work,floats,origins);const observer=new MutationObserver(measureNative);observer.observe(root,{subtree:true,childList:true,characterData:true});}if(root.parentNode!==node)node.append(root);schedule();notify();}
    function childrenOf(e){const c=e?.props?.children;return Array.isArray(c)?c:[c];}
    function copy(e,children){return e?.props?{...e,props:{...e.props,children}}:e;}
    api.hook('uicHouse',{after(result,args){if(!args[0]?.stats)return result;let base=result;const seen=new Set();while(base?.props?.el?.props&&!seen.has(base)){seen.add(base);base=base.props.el;}const c=childrenOf(base);if(c.length<5)return result;return copy(base,[sourceSlot('map',c[0]),sourceSlot('house-wife-stats',c[1]),sourceSlot('urgent',c[2]),sourceSlot('whereabouts',[c[3],c[4]]),sourceSlot('night-summary',c[5]),...c.slice(6)]);}});
    api.hook('uicFocus',{after(result,args){if(args[0]?.portrait==='external')return result;const c=childrenOf(result);if(c.length<2)return result;const ids=['focus-wife-stats','patron-info','acceptance','surface','last-change','response','remark-response','inner-thought','controls','bath-service','card-activity'];return copy(result,[sourceSlot('portrait',[c[0],c[1]]),...ids.map((id,i)=>sourceSlot(id,c[i+2])),...c.slice(13)]);}});
    api.hook('uicDesktop',{around(next,props,...rest){if(!props?.panes)return next(props,...rest);return R.jsxs('div',{style:{display:'flex',flex:'1 1 auto',minHeight:0,minWidth:0},ref:mountRoot,children:baseIds.map(id=>nativePortal(id,props.panes[id]?.body))});}});
    api.ui.addButton({label:'UI',title:'UI_customize · 화면 배치',onClick:openSettings});api.ui.settings(body=>body.append(button('배치 설정 열기',openSettings)));
    window.addEventListener('resize',()=>{if(root)render();});
    window.addEventListener('pagehide',()=>{for(const rec of records.values())release(rec);});
  }
});
