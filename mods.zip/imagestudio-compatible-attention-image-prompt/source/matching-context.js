// Runs inside the prompt editor closure, where real and planned state codes are available.
host.matchingContext = function ImageStudio_매칭맥락읽기(key, suppliedCharacter) {
  const state=api.store.game();
  const character=(host.planning&&suppliedCharacter?.id?state?.characters?.[suppliedCharacter.id]:null)||suppliedCharacter||state?.characters?.[state.primaryCharacterId];
  if(!state||!character)return null;
  const characterId=characterIdOf(state,character)||character.id||state.primaryCharacterId;
  const snapshot=host.matchingContextSnapshot;
  const base=value=>String(value).split('__').filter(part=>!['state-','dialogue-','position-','character-reuse-','character-regenerate-','studio-'].some(prefix=>part.startsWith(prefix))).join('__');
  const groups=snapshot?.state===state&&snapshot.character===character&&base(snapshot.key)===base(key)?snapshot.groups:(()=>{const context=promptContext(state,character,characterId,key);return [...context.positiveGroups,...context.negativeGroups];})();
  const codes=[...new Set(groups.flatMap(group=>group.value?.codes||[]))];
  const fakePrompts=Object.fromEntries(BAD_GUEST_FIELDS.map(field=>[field.key,'matching-state']));
  const actualBadGuest=ImageStudio_나쁜손님프롬프트읽기(state,character,characterId,fakePrompts)?.codes||[];
  const planned=host.planning?.combination;
  const manualBadGuest=planned&&Object.keys(planned).some(id=>id.startsWith('promptField:badguest.'));
  const badguest=manualBadGuest?groups.filter(group=>group.id==='badguest').flatMap(group=>group.value.codes):actualBadGuest;
  const emotions=host.planning?codes.filter(code=>code.startsWith('feeling-')).map(code=>code.slice(8))
    :topFeelings(character,2).filter(feeling=>Number(feeling.intensity)>15).map(feeling=>feeling.emotion);
  const pregnancy=ImageStudio_맥락상태값읽기('pregnancy',state,character,characterId,key)||'none';
  const detail=codes.filter(code=>!code.startsWith('character.')&&!code.startsWith('outfit.')&&!code.startsWith('feeling-')
    &&!code.startsWith('context.pregnancy.')&&!badguest.includes(code));
  return {version:1,emotions:[...new Set(emotions)].sort(),badguest:[...new Set(badguest)].sort(),
    pregnancy:Array.isArray(pregnancy)?pregnancy[0]||'none':pregnancy,detail:[...new Set(detail)].sort()};
};
