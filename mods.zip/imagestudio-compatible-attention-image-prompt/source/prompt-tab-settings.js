// 내장 프롬프트 편집기와 같은 클로저에서 탭별 JSON 범위를 관리합니다.
function ImageStudio_JSON전체읽기() {
  const presets = currentSituationPresets();
  return {
    format: 'wayward-state-image-prompts', version: 17,
    wives: (customWifeStore.getState().wives || []).map(entry => ({
      id: entry.id, inputs: { ...entry.inputs },
      ...(typeof entry.portraitKey === 'string' ? { portraitKey: entry.portraitKey } : {}),
      ...(typeof entry.portraitUrl === 'string' ? { portraitUrl: entry.portraitUrl } : {}),
    })),
    characterPrompt: currentCharacterPrompt(), outfitPrompts: currentOutfitPrompts(),
    nativeAxisPrompts: ImageStudio_기본축설정읽기(),
    contextStatePrompts: ImageStudio_맥락상태설정읽기(),
    situationPresets: presets, situationPresetAssignments: currentSituationPresetAssignments(presets),
    positionPresetPrompts: currentPositionPresetPrompts(), positionPresetNegativePrompts: currentPositionPresetNegativePrompts(),
    positionGroupPrompts: currentPositionGroupPrompts(),
    prompts: currentPrompts(), negativePrompts: currentNegativePrompts(), outfitStates: currentOutfitStates(),
    dialogueRules: currentDialogueRules(), fluidDecay: currentFluidDecaySettings(),
    residuePrompts: currentResiduePrompts(), customTags: currentCustomTags(),
  };
}

function ImageStudio_JSON탭섹션읽기(tab) {
  if (tab.id === 'character') return ['wives', 'characterPrompt'];
  if (tab.id === 'outfit-prompts') return ['outfitPrompts'];
  if (tab.id === 'situation-presets') return ['situationPresets', 'situationPresetAssignments'];
  if (tab.id === 'positions') return ['positionPresetPrompts', 'positionPresetNegativePrompts', 'positionGroupPrompts'];
  if (tab.id === 'dialogue') return ['dialogueRules'];
  if (tab.id === COMPOSITION_TAB.id || FIELD_GROUPS.some(group => group.id === tab.id)) return [
    'prompts', 'negativePrompts', 'outfitStates', ...(tab.id === 'h-status' ? ['fluidDecay', 'residuePrompts'] : []),
  ];
  return [];
}

function ImageStudio_JSON탭읽기(tab) {
  const data = { format: 'wayward-state-image-prompts', version: 17, scope: 'tab', tabId: tab.id };
  if (tab.axis) return { ...data, nativeAxisPrompts: { [tab.axis]: ImageStudio_기본축설정읽기()[tab.axis] } };
  if (tab.contextAxis) return { ...data, contextStatePrompts: { [tab.contextAxis]: ImageStudio_맥락상태설정읽기()[tab.contextAxis] } };
  const all = ImageStudio_JSON전체읽기();
  const config = activeSituationConfig();
  for (const section of ImageStudio_JSON탭섹션읽기(tab)) {
    const value = ['prompts', 'negativePrompts', 'outfitStates', 'dialogueRules'].includes(section) ? config[section] : all[section];
    data[section] = ['prompts', 'negativePrompts', 'outfitStates'].includes(section)
      ? Object.fromEntries(tab.fields.map(field => [field.key, value[field.key]])) : value;
  }
  return data;
}

function ImageStudio_JSON불러온뒤갱신하기(syncDecay = false) {
  publishCurrentWifePromptProfile();
  activeTagTarget = null;
  if (syncDecay) syncFluidDecay(true);
}

function ImageStudio_JSON탭불러오기(parsed, tab) {
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw Error('JSON 설정 객체가 필요합니다.');
  if (parsed.scope === 'tab' && parsed.tabId !== tab.id) throw Error('다른 탭의 JSON입니다. 해당 탭에서 불러오세요.');
  if (tab.axis) {
    const source = parsed.nativeAxisPrompts?.[tab.axis];
    if (!source || typeof source !== 'object' || Array.isArray(source)) throw Error('해당 탭의 프롬프트가 없습니다.');
    const normalized = ImageStudio_기본축설정정규화하기({ [tab.axis]: source });
    if (Object.keys(source).length && !Object.keys(normalized[tab.axis]).length) throw Error('올바른 프롬프트 항목이 없습니다.');
    api.settings.set({ nativeAxisPrompts: { ...ImageStudio_기본축설정읽기(), [tab.axis]: normalized[tab.axis] } });
  } else if (tab.contextAxis) {
    const source = parsed.contextStatePrompts?.[tab.contextAxis];
    if (!source || typeof source !== 'object' || Array.isArray(source)) throw Error('해당 탭의 프롬프트가 없습니다.');
    const normalized = ImageStudio_맥락상태설정정규화하기({ [tab.contextAxis]: source });
    if (Object.keys(source).length && !Object.keys(normalized[tab.contextAxis]).length) throw Error('올바른 프롬프트 항목이 없습니다.');
    api.settings.set({ contextStatePrompts: { ...ImageStudio_맥락상태설정읽기(), [tab.contextAxis]: normalized[tab.contextAxis] } });
  } else {
    const sections = ImageStudio_JSON탭섹션읽기(tab);
    const filtered = Object.fromEntries(sections.filter(section => Object.prototype.hasOwnProperty.call(parsed, section))
      .map(section => [section, parsed[section]]));
    // 필드형 탭은 편집 중인 프리셋의 해당 키만 합칩니다.
    if (tab.id === COMPOSITION_TAB.id || FIELD_GROUPS.some(group => group.id === tab.id) || tab.id === 'dialogue') {
      const config = activeSituationConfig();
      const changes = {};
      const allowed = new Set((tab.fields || []).map(field => field.key));
      for (const section of ['prompts', 'negativePrompts', 'outfitStates']) {
        if (!Object.prototype.hasOwnProperty.call(filtered, section)) continue;
        const imported = section === 'outfitStates' ? importedOutfitStates(filtered[section], parsed.outfitModes)
          : importedPrompts(filtered[section], section === 'prompts' ? DEFAULT_PROMPTS : DEFAULT_NEGATIVE_PROMPTS);
        const entries = Object.entries(imported).filter(([key]) => allowed.has(key));
        if (entries.length) changes[section] = { ...config[section], ...Object.fromEntries(entries) };
      }
      if (Array.isArray(filtered.dialogueRules)) changes.dialogueRules = filtered.dialogueRules.map(normalizeDialogueRule).filter(Boolean);
      const extras = {};
      for (const [section, normalize] of [['fluidDecay', normalizeFluidDecaySettings], ['residuePrompts', normalizeResiduePrompts]]) {
        const value = filtered[section];
        if (value && typeof value === 'object' && !Array.isArray(value)) extras[section] = normalize(value);
      }
      for(const section of ['equipmentPrompts','hStatusGenerationModes'])if(Object.prototype.hasOwnProperty.call(filtered,section)){
        extras[section]=importPromptSettings(JSON.stringify({[section]:filtered[section]}))[section];
      }
      if (!Object.keys(changes).length && !Object.keys(extras).length) throw Error('해당 탭에 불러올 설정이 없습니다.');
      for (const [section, value] of Object.entries(changes)) saveActiveSituationSection(section, value);
      if (Object.keys(extras).length) api.settings.set(extras);
    } else {
      // 기존 가져오기 검증·정규화를 재사용하되 다른 탭은 입력과 저장 양쪽에서 제외합니다.
      const imported = importPromptSettings(JSON.stringify(filtered));
      api.settings.set(Object.fromEntries(sections.filter(section => section !== 'wives' && section in filtered)
        .map(section => [section, imported[section]])));
      if (tab.id === 'situation-presets') activeSituationPresetId = LEGACY_SITUATION_PRESET_ID;
    }
  }
  ImageStudio_JSON불러온뒤갱신하기(tab.id === 'h-status');
}

function ImageStudio_JSON탭초기화하기(tab) {
  if (tab.axis) api.settings.set({ nativeAxisPrompts: { ...ImageStudio_기본축설정읽기(), [tab.axis]: {} } });
  else if (tab.contextAxis) api.settings.set({ contextStatePrompts: { ...ImageStudio_맥락상태설정읽기(), [tab.contextAxis]: {} } });
  else if (tab.id === 'character') api.settings.set({ characterPrompt: { ...DEFAULT_CHARACTER_PROMPT } });
  else if (tab.id === 'outfit-prompts') api.settings.set({ outfitPrompts: {} });
  else if (tab.id === 'situation-presets') {
    api.settings.set({ situationPresets: [], situationPresetAssignments: {} });
    activeSituationPresetId = LEGACY_SITUATION_PRESET_ID;
  } else if (tab.id === 'positions') {
    api.settings.set({ positionPresetPrompts: {}, positionPresetNegativePrompts: {}, positionGroupPrompts: {}, personDetails: undefined });
    positionSelection = { situationId: latestScenePrompt?.situationId || '', presetId: 'none', groupSlots: '' };
    positionRandomChoices.clear(); positionPlacementDrafts.clear(); positionGeneratedResults.clear();
  } else if (tab.id === 'dialogue') {
    saveActiveSituationSection('dialogueRules', DEFAULT_DIALOGUE_RULES.map(rule => ({ ...rule, outfitStates: [...rule.outfitStates] })));
  } else if (tab.id === COMPOSITION_TAB.id || FIELD_GROUPS.some(group => group.id === tab.id)) {
    if(tab.id==='h-status')api.settings.set({equipmentPrompts:undefined,hStatusGenerationModes:undefined});
    const config = activeSituationConfig();
    for (const [section, defaults] of [['prompts', DEFAULT_PROMPTS], ['negativePrompts', DEFAULT_NEGATIVE_PROMPTS], ['outfitStates', DEFAULT_OUTFIT_STATES]]) {
      saveActiveSituationSection(section, { ...config[section], ...Object.fromEntries(tab.fields.map(field => [field.key, defaults[field.key]])) });
    }
    if (tab.id === 'h-status') api.settings.set({ fluidDecay: { ...DEFAULT_FLUID_DECAY }, residuePrompts: {} });
  }
  ImageStudio_JSON불러온뒤갱신하기(tab.id === 'h-status');
}

function ImageStudio_JSON입력만들기(h, win, tab) {
  const input = h('input', {
    type: 'file', accept: '.json,application/json', style: 'display:none;', 'data-prompt-json-input': '',
    onchange: async () => {
      const file = input.files?.[0];
      if (!file) return;
      const scope = input.dataset.promptJsonScope;
      try {
        const text = await file.text();
        if (scope === 'tab') ImageStudio_JSON탭불러오기(JSON.parse(text), tab);
        else { api.settings.set(importPromptSettings(text)); ImageStudio_JSON불러온뒤갱신하기(true); }
        settingsMessage = `${file.name || '파일'}에서 ${scope === 'tab' ? tab.title : '전체'} 설정을 불러왔습니다.`;
      } catch (error) { settingsMessage = `불러오기 실패: ${error.message || error}`; }
      input.value = '';
      win.refresh();
    },
  });
  return input;
}

function ImageStudio_JSON버튼그리기(h, win, tab, input) {
  const editable = tab.id !== 'diagnostics';
  const ImageStudio_JSON파일내보내기 = async scope => {
    try {
      const data = scope === 'tab' ? ImageStudio_JSON탭읽기(tab) : ImageStudio_JSON전체읽기();
      await api.saveFile(scope === 'tab' ? `wayward-prompts-${tab.id}.json` : 'wayward-state-image-prompts.json', JSON.stringify(data, null, 2), 'application/json');
      settingsMessage = `${scope === 'tab' ? tab.title : '전체'} 설정을 JSON 파일로 내보냈습니다.`;
    } catch (error) { settingsMessage = `내보내기 실패: ${error.message || error}`; }
    win.refresh();
  };
  const ImageStudio_JSON파일선택하기 = scope => { input.dataset.promptJsonScope = scope; input.click(); };
  return [
    h('div', { class: 'wml-section', 'data-prompt-json-actions': tab.id, style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-top:10px;' },
      api.ui.button('전체 json 내보내기', () => { void ImageStudio_JSON파일내보내기('all'); }),
      api.ui.button('전체 json 불러오기', () => ImageStudio_JSON파일선택하기('all')),
      api.ui.button('해당 탭 json 내보내기', () => { void ImageStudio_JSON파일내보내기('tab'); }, { disabled: !editable }),
      api.ui.button('해당 탭 json 불러오기', () => ImageStudio_JSON파일선택하기('tab'), { disabled: !editable }),
      api.ui.button('해당 탭 프롬프트 초기화하기', () => {
        ImageStudio_JSON탭초기화하기(tab);
        settingsMessage = `${tab.title}의 프롬프트를 초기화했습니다.`;
        win.refresh();
      }, { disabled: !editable }), input,
    ),
    editable ? h('p', { class: 'wml-muted wml-small', style: 'margin:4px 0;' },
      '탭 작업은 해당 탭의 모든 항목을 대상으로 합니다. 나쁜 손님 모드용·상세 상태·H Status·대화는 편집 중인 상황 프리셋에 적용됩니다. 아내 탭 초기화는 외형 수정값을 복원하며 등록된 사용자 아내는 보존합니다.') : null,
  ];
}
