// 내장 상황 프롬프트 코드의 DEFAULT_PROMPTS 생성 직후 실행합니다.
// 상세 상태는 빈 기본값으로 시작하고, 사용자가 입력한 문구만 적용합니다.
const ImageStudio_기존상태필드 = [...DETAIL_FIELDS];
const ImageStudio_기존상태Positive = Object.fromEntries(ImageStudio_기존상태필드.map(field => [field.key, field.value]));
const ImageStudio_기존상태Negative = Object.fromEntries(ImageStudio_기존상태필드.map(field => [field.key, DEFAULT_NEGATIVE_PROMPTS[field.key] || '']));
for (const field of ImageStudio_기존상태필드) {
  field.value = '';
  DEFAULT_PROMPTS[field.key] = '';
  DEFAULT_NEGATIVE_PROMPTS[field.key] = '';
}

function ImageStudio_기존상태기본값비우기(value, previous) {
  const next = value && typeof value === 'object' && !Array.isArray(value) ? { ...value } : {};
  for (const [key, oldDefault] of Object.entries(previous)) {
    if (!Object.prototype.hasOwnProperty.call(next, key) || next[key] === oldDefault) next[key] = '';
  }
  return next;
}

function ImageStudio_대응필요설정지우기(value, section) {
  const next = value && typeof value === 'object' && !Array.isArray(value) ? { ...value } : {};
  for (const key of Object.keys(next)) if (key.startsWith('attention.')) delete next[key];
  const previousHandcuff = next['restraint.handcuffed'];
  if (!Object.prototype.hasOwnProperty.call(next, 'badguest.handcuffed')) {
    if (section === 'outfitStates' && Array.isArray(previousHandcuff)) next['badguest.handcuffed'] = [...previousHandcuff];
    else if (typeof previousHandcuff === 'string' && previousHandcuff.trim()) next['badguest.handcuffed'] = previousHandcuff;
  }
  delete next['restraint.handcuffed'];
  return next;
}

function ImageStudio_상황프리셋이전하기(preset, emptyStatusDefaults) {
  if (!preset || typeof preset !== 'object' || Array.isArray(preset)) return preset;
  let prompts = ImageStudio_대응필요설정지우기(preset.prompts, 'prompts');
  let negativePrompts = ImageStudio_대응필요설정지우기(preset.negativePrompts, 'negativePrompts');
  if (emptyStatusDefaults) {
    prompts = ImageStudio_기존상태기본값비우기(prompts, ImageStudio_기존상태Positive);
    negativePrompts = ImageStudio_기존상태기본값비우기(negativePrompts, ImageStudio_기존상태Negative);
  }
  return {
    ...preset,
    prompts,
    negativePrompts,
    outfitStates: ImageStudio_대응필요설정지우기(preset.outfitStates, 'outfitStates'),
  };
}

const ImageStudio_상태설정 = api.settings.get({
  statusPromptsEmptyDefaultsV1: false, attentionPromptsRemovedV1: false,
  prompts: {}, negativePrompts: {}, outfitStates: {}, situationPresets: [],
});
if (!ImageStudio_상태설정.statusPromptsEmptyDefaultsV1 || !ImageStudio_상태설정.attentionPromptsRemovedV1) {
  const emptyStatusDefaults = !ImageStudio_상태설정.statusPromptsEmptyDefaultsV1;
  let prompts = ImageStudio_대응필요설정지우기(ImageStudio_상태설정.prompts, 'prompts');
  let negativePrompts = ImageStudio_대응필요설정지우기(ImageStudio_상태설정.negativePrompts, 'negativePrompts');
  if (emptyStatusDefaults) {
    prompts = ImageStudio_기존상태기본값비우기(prompts, ImageStudio_기존상태Positive);
    negativePrompts = ImageStudio_기존상태기본값비우기(negativePrompts, ImageStudio_기존상태Negative);
  }
  api.settings.set({
    prompts,
    negativePrompts,
    outfitStates: ImageStudio_대응필요설정지우기(ImageStudio_상태설정.outfitStates, 'outfitStates'),
    situationPresets: Array.isArray(ImageStudio_상태설정.situationPresets)
      ? ImageStudio_상태설정.situationPresets.map(preset => ImageStudio_상황프리셋이전하기(preset, emptyStatusDefaults))
      : ImageStudio_상태설정.situationPresets,
    statusPromptsEmptyDefaultsV1: true,
    attentionPromptsRemovedV1: true,
  });
}
