// 내장 attention 설정과 같은 클로저에서 실행합니다. 실제 게임 상태는 수정하지 않습니다.
const ImageStudio_계획설정자료 = new WeakMap();
const ImageStudio_기본축탭목록 = [
  {
    id: 'native-situation-prompts', axis: 'situation', title: '장면/작업 프롬프트',
    note: '조건부 생성의 장면·작업 ID별 기본 Positive를 교체하고 추가 Negative를 설정합니다.', fields: [],
  },
  {
    id: 'native-room-prompts', axis: 'room', title: '장소 프롬프트',
    note: '조건부 생성의 장소 ID별 기본 Positive를 교체하고 추가 Negative를 설정합니다.', fields: [],
  },
  {
    id: 'native-mood-prompts', axis: 'mood', title: '기분 프롬프트',
    note: '조건부 생성의 기분 ID별 기본 Positive를 교체하고 추가 Negative를 설정합니다.', fields: [],
  },
  {
    id: 'native-men-prompts', axis: 'men', title: '남성 수 프롬프트',
    note: '화면의 전체 남성 수별 인원 Positive를 교체하고 추가 Negative를 설정합니다. 조건부 생성의 인원 조건과 같은 기준을 사용합니다.', fields: [],
  },
  {
    id: 'native-roles-prompts', axis: 'roles', title: '남성별 역할 조합 프롬프트',
    note: 'gslot 역할 조합별 그룹 Positive를 교체하고 추가 Negative를 설정합니다. 장면 자체의 행동과 장면별 세부 조정은 별도로 적용됩니다.', fields: [],
  },
  {
    id: 'native-exposure-prompts', axis: 'exposure', title: '노출 상태 프롬프트',
    note: '게임의 정규 exp 코드로 같은 노출 상태를 합칩니다. 정규 코드에 저장한 편집값을 우선하며 예전 코드의 값은 설정에 보존합니다. Positive를 교체하고 추가 Negative를 설정하며 의상·장면의 기본 Negative는 유지됩니다.', fields: [],
  },
];
const ImageStudio_기본축기본값 = Object.fromEntries(ImageStudio_기본축탭목록.map(tab => [tab.axis, new Map()]));
const ImageStudio_장면변형기본값 = new Map();
const ImageStudio_장면변형선택값 = new Map();
const ImageStudio_추가기분기본값 = new Map([
  ['aroused', 'aroused, flushed face, heavy breathing, parted lips'],
  ['enjoying', 'pleasure, blush, half-closed eyes, open mouth, relaxed expression'],
  ['relieved', 'relieved, soft eyes, faint smile, relaxed eyebrows'],
  ['nervous', 'nervous, furrowed brow, wide-eyed, tense expression, sweatdrop'],
]);
for (const [id, prompt] of ImageStudio_추가기분기본값) ImageStudio_기본축기본값.mood.set(id, prompt);
const ImageStudio_기본축선택값 = Object.fromEntries(ImageStudio_기본축탭목록.map(tab => [tab.axis, '']));
const ImageStudio_이미지키해석하기 = key => api.fn('imageKeyParse')(ImageStudio_노출키정규화하기(key));
const ImageStudio_노출팩목록 = new WeakMap();

function ImageStudio_노출항목ID읽기(id) {
  return ImageStudio_노출코드정규화하기(String(id)) || 'none';
}
function ImageStudio_노출플래그읽기(imageKey,character) {
  const fields=['bodiceUnlaced','topPulledDown','topRemoved','skirtUp','skirtRemoved','pantiesAside','pantiesRemoved'];
  const specified=String(imageKey || '').match(/(?:^|__)exp-([01]{7})(?=__|$)/)?.[1];
  const raw=specified || fields.map(field=>character?.exposure?.[field]===true?'1':'0').join('');
  const code=ImageStudio_노출코드정규화하기(raw) || '0000000';
  return Object.fromEntries(fields.map((field,index)=>[field,code[index]==='1']));
}

SETTINGS_TABS.splice(2, 0, ...ImageStudio_기본축탭목록);

function ImageStudio_기본축설정정규화하기(value) {
  const result = Object.fromEntries(ImageStudio_기본축탭목록.map(tab => [tab.axis, {}]));
  if (!value || typeof value !== 'object' || Array.isArray(value)) return result;
  for (const axis of Object.keys(result)) {
    const source = value[axis];
    if (!source || typeof source !== 'object' || Array.isArray(source)) continue;
    for (const [rawId, prompt] of Object.entries(source)) {
      const id = String(rawId || '').trim();
      if (!id || id.length > 160 || ['__proto__', 'prototype', 'constructor'].includes(id)
        || !prompt || typeof prompt !== 'object' || Array.isArray(prompt)) continue;
      const normalized = {};
      if (typeof prompt.positivePrompt === 'string') normalized.positivePrompt = prompt.positivePrompt;
      if (typeof prompt.negativePrompt === 'string' && (axis === 'exposure' || prompt.negativePrompt.trim())) normalized.negativePrompt = prompt.negativePrompt;
      if (axis === 'situation' && prompt.variants && typeof prompt.variants === 'object' && !Array.isArray(prompt.variants)) {
        const variants = {};
        for (const variant of ['0','1','2','3']) {
          const row = prompt.variants[variant];
          if (!row || typeof row !== 'object' || Array.isArray(row)) continue;
          const entry = {};
          for (const field of ['positivePrompt','negativePrompt']) if (typeof row[field] === 'string') entry[field] = row[field];
          if (Object.keys(entry).length) variants[variant] = entry;
        }
        if (Object.keys(variants).length) normalized.variants = variants;
      }
      if (Object.keys(normalized).length) result[axis][id] = normalized;
    }
  }
  // 읽기 별칭만 만듭니다. 같은 필드는 정규 코드의 값을 우선하며, 옛 ID와 그 원문은 삭제하지 않습니다.
  for(const id of Object.keys(result.exposure).sort()){
    const canonical=ImageStudio_노출항목ID읽기(id);
    if(canonical!==id)result.exposure[canonical]={...result.exposure[id],...result.exposure[canonical]};
  }
  return result;
}

function ImageStudio_기본축설정읽기() {
  return ImageStudio_기본축설정정규화하기(api.settings.get({ nativeAxisPrompts: {} }).nativeAxisPrompts);
}
host.nativeAxisPrompt = (axis,id) => ImageStudio_기본축설정읽기()[axis]?.[axis==='exposure'?ImageStudio_노출항목ID읽기(id):id];

function ImageStudio_기본축항목읽기(axis) {
  const entries = globalThis.WW_ImageStudioBridge?.axes?.()?.[axis] || [];
  const saved = ImageStudio_기본축설정읽기()[axis] || {};
  const defaults = ImageStudio_기본축기본값[axis] || new Map();
  const canonicalId = id => axis === 'exposure' ? ImageStudio_노출항목ID읽기(id) : String(id);
  const byId = new Map(entries.map(entry => [canonicalId(entry.value), {
    id: canonicalId(entry.value), label: String(entry.label || entry.value), description: String(entry.description || ''),
  }]));
  const known = [...defaults.keys(), ...Object.keys(saved)];
  // 현재 이미지팩에만 있는 상태도 본체의 조건부 목록과 같은 기준으로 표시합니다.
  if(axis==='exposure')for(const pack of globalThis.WW_ImageStudioBridge?.packs?.() || []){
    if(!ImageStudio_노출팩목록.has(pack))ImageStudio_노출팩목록.set(pack,[...new Set(Object.values(pack.entries || {})
      .map(entry=>entry.talentName?.match(/__exp-([01]{7})(?=__|$)/)?.[1] || 'none'))]);
    known.push(...ImageStudio_노출팩목록.get(pack));
  }
  for (const rawId of known) {
    const id=canonicalId(rawId);
    if (!byId.has(id)) byId.set(id, { id, label: id, description: '' });
  }
  return [...byId.values()];
}

function ImageStudio_기본축키값읽기(imageKey) {
  let parsed;
  try { parsed = ImageStudio_이미지키해석하기(String(imageKey || '')); } catch { return {}; }
  if (!parsed) return {};
  return {
    situation: String(parsed.scene || parsed.task || ''),
    room: parsed.room ? String(parsed.room) + (parsed.abed ? ' (침대 위)' : '') : '',
    mood: String(parsed.mood || 'default'),
    men: parsed.groupBoys ? String(parsed.groupBoys + 1) : parsed.task || ['self_pleasure', 'bath_solo'].includes(parsed.scene) ? '0' : '1',
    roles: String(parsed.groupSlots || ''),
    exposure: String(parsed.exposure || 'none'),
  };
}

function ImageStudio_기본축부분찾기(parts, axis, hasScene) {
  const labels = axis === 'situation'
    ? hasScene ? ['장면', 'Scene'] : ['작업', 'Task', '자세', 'Pose', 'Action']
    : axis === 'room' ? ['장소', 'Location']
    : axis === 'mood' ? ['기분', 'Mood']
    : axis === 'men' ? ['성별', 'Gender']
    : axis === 'roles' ? ['그룹', 'Group'] : ['노출도', 'Exposure'];
  return parts.findIndex(part => labels.includes(String(part?.label || '')));
}

function ImageStudio_기본축프롬프트기록하기(result) {
  if (!result || !Array.isArray(result.parts)) return result;
  const values = ImageStudio_기본축키값읽기(result.key);
  const parsed = (() => { try { return ImageStudio_이미지키해석하기(String(result.key || '')); } catch { return null; } })();
  const situationIndex = ImageStudio_기본축부분찾기(result.parts, 'situation', Boolean(parsed?.scene));
  if (values.situation && situationIndex >= 0) {
    const identity = values.situation + ':' + String(parsed?.variant || 0);
    if (!ImageStudio_장면변형기본값.has(identity)) ImageStudio_장면변형기본값.set(identity, String(result.parts[situationIndex].tags || ''));
  }
  for (const axis of Object.keys(ImageStudio_기본축기본값)) {
    const id = values[axis];
    if (!id) continue;
    const index = ImageStudio_기본축부분찾기(result.parts, axis, Boolean(parsed?.scene));
    const tags = index >= 0 ? String(result.parts[index]?.tags || '') : '';
    if (!ImageStudio_기본축기본값[axis].has(id) || (!ImageStudio_기본축기본값[axis].get(id) && tags)) {
      ImageStudio_기본축기본값[axis].set(id, tags);
    }
  }
  return result;
}

function ImageStudio_기본축수정목록읽기(imageKey) {
  const values = ImageStudio_기본축키값읽기(imageKey);
  const settings = ImageStudio_기본축설정읽기();
  return Object.entries(values).flatMap(([axis, id]) => {
    if (!id) return [];
    const saved = settings[axis]?.[id];
    if (saved) {
      const variant = axis === 'situation' ? String(ImageStudio_이미지키해석하기(imageKey)?.variant || 0) : '';
      const override = axis === 'situation' ? saved.variants?.[variant] : null;
      const prompt = Object.fromEntries(Object.entries(axis === 'situation' ? { ...saved, ...override } : saved).filter(([key]) => key !== 'variants'));
      return Object.keys(prompt).length ? [{ axis, id, ...(override ? { variant } : {}), prompt }] : [];
    }
    const builtIn = axis === 'mood' ? ImageStudio_추가기분기본값.get(id) : '';
    return builtIn ? [{ axis, id, prompt: { positivePrompt: builtIn } }] : [];
  });
}

function ImageStudio_기본축키적용하기(imageKey) {
  const clean = String(imageKey || '').split('__').filter(part => !part.startsWith('studio-')).join('__');
  const entries = ImageStudio_기본축수정목록읽기(clean);
  if (!entries.length) return clean;
  const signature = JSON.stringify(entries.map(entry => [entry.axis, entry.id, entry.prompt]));
  const variant = clean.match(/__v-\d+$/)?.[0] || '';
  const root = variant ? clean.slice(0, -variant.length) : clean;
  return `${root}__studio-${shortHash(signature)}${variant}`;
}

function ImageStudio_기본축프롬프트적용하기(result) {
  if (!result || !Array.isArray(result.parts)) return result;
  const entries = ImageStudio_기본축수정목록읽기(result.key);
  if (!entries.length) return { ...result, key: ImageStudio_기본축키적용하기(result.key) };
  const parsed = (() => { try { return ImageStudio_이미지키해석하기(String(result.key || '')); } catch { return null; } })();
  let parts = result.parts.map(part => ({ ...part }));
  let prompt = String(result.prompt || '');
  let negativePrompt = String(result.negativePrompt || '');
  for (const entry of entries) {
    if (Object.prototype.hasOwnProperty.call(entry.prompt, 'positivePrompt')) {
      const index = ImageStudio_기본축부분찾기(parts, entry.axis, Boolean(parsed?.scene));
      const replacement = String(entry.prompt.positivePrompt || '');
      if (index >= 0) {
        const otherTags = new Set(parts.filter((_, partIndex) => partIndex !== index)
          .flatMap(part => promptTokens(part.tags)).map(tag => promptTagIdentity(tag).spaced));
        const removable = promptTokens(parts[index].tags).filter(tag => !otherTags.has(promptTagIdentity(tag).spaced));
        prompt = joinPrompt(`${withoutPromptTags(prompt, removable.join(', '))}, ${replacement}`);
        if (replacement.trim()) parts[index] = { ...parts[index], tags: replacement };
        else parts.splice(index, 1);
      } else if (replacement.trim()) {
        const tab = ImageStudio_기본축탭목록.find(item => item.axis === entry.axis);
        parts.push({ label: tab?.title.replace(' 프롬프트', '') || entry.axis, tags: replacement });
        prompt = joinPrompt(`${prompt}, ${replacement}`);
      }
    }
    if (entry.prompt.negativePrompt) negativePrompt = joinPrompt(`${negativePrompt}, ${entry.prompt.negativePrompt}`);
  }
  return {
    ...result,
    key: ImageStudio_기본축키적용하기(result.key),
    prompt,
    negativePrompt,
    parts,
    genParams: promptGenParams(prompt),
  };
}

function ImageStudio_기본축필드저장하기(axis, id, field, value, variant) {
  if(axis==='exposure')id=ImageStudio_노출항목ID읽기(id);
  const settings = ImageStudio_기본축설정읽기();
  const axisPrompts = { ...settings[axis] };
  const prompt = { ...(axisPrompts[id] || {}) };
  if (axis === 'situation' && variant !== undefined) {
    const variants = { ...prompt.variants };
    variants[String(variant)] = { ...variants[String(variant)], [field]: String(value ?? '') };
    axisPrompts[id] = { ...prompt, variants };
    api.settings.set({ nativeAxisPrompts: { ...settings, [axis]: axisPrompts } });
    return;
  }
  if (axis !== 'exposure' && field === 'negativePrompt' && !String(value || '').trim()) delete prompt[field];
  else prompt[field] = String(value ?? '');
  if (Object.keys(prompt).length) axisPrompts[id] = prompt;
  else delete axisPrompts[id];
  api.settings.set({ nativeAxisPrompts: { ...settings, [axis]: axisPrompts } });
}

function ImageStudio_기본축프롬프트그리기(h, win, tab) {
  const sources = ImageStudio_기본축항목읽기(tab.axis);
  if (!sources.length) return [h('p', { class: 'wml-note' }, '게임에서 조건 목록을 읽지 못했습니다.')];
  const source = sources.find(entry => entry.id === ImageStudio_기본축선택값[tab.axis]) || sources[0];
  ImageStudio_기본축선택값[tab.axis] = source.id;
  const prompts = ImageStudio_기본축설정읽기();
  const commonOverride = prompts[tab.axis]?.[source.id] || {};
  const variant = tab.axis === 'situation' ? ImageStudio_장면변형선택값.get(source.id) || '0' : undefined;
  const override = variant !== undefined ? { ...commonOverride, ...commonOverride.variants?.[variant] } : commonOverride;
  const negative = activePromptPolarity === 'negative';
  const field = negative ? 'negativePrompt' : 'positivePrompt';
  const nativeValue = (variant !== undefined ? ImageStudio_장면변형기본값.get(source.id + ':' + variant) : undefined)
    ?? ImageStudio_기본축기본값[tab.axis]?.get(source.id) ?? '';
  const customized = Object.prototype.hasOwnProperty.call(override, field);
  const value = customized ? override[field] : negative ? '' : nativeValue;
  const save = next => { ImageStudio_기본축필드저장하기(tab.axis, source.id, field, next, variant); win.refresh(); };
  const inputStyle = 'width:100%;box-sizing:border-box;resize:vertical;min-height:100px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;';
  return [
    h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
      h('strong', { style: 'font-size:12px;' }, `${tab.title.replace(' 프롬프트', '')} ${sources.length}개`),
      h('select', {
        value: source.id,
        'data-native-axis-prompt-source': tab.axis,
        style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
        onchange: event => { ImageStudio_기본축선택값[tab.axis] = event.currentTarget.value; activeTagTarget = null; win.refresh(); },
      }, ...sources.map(entry => h('option', { value: entry.id, selected: entry.id === source.id }, `${entry.label} (${entry.id})`))),
      h('span', { class: 'wml-muted wml-small' }, customized ? '이 항목의 수정값을 표시 중입니다.' : negative ? '축별 기본 Negative는 없습니다. 입력한 태그를 전체 Negative에 추가합니다.' : '게임의 대표 기본 프롬프트를 표시 중입니다.'),
    ),
    source.description ? h('p', { class: 'wml-note', style: 'margin-bottom:10px;' }, source.description) : null,
    variant !== undefined ? h('div', { 'data-native-situation-variants': source.id, style: 'display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px;' },
      ...['0','1','2','3'].map(id => {
        const button = api.ui.button('v-' + id, () => { ImageStudio_장면변형선택값.set(source.id,id); activeTagTarget = null; win.refresh(); }, { primary: variant === id });
        button.dataset.nativeSituationVariant = id;return button;
      })) : null,
    h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
      h('strong', { style: 'font-size:12px;' }, negative ? '추가 Negative 프롬프트' : '교체할 Positive 프롬프트'),
      h('textarea', {
        rows: 5, value, spellcheck: false,
        'data-native-axis-prompt': `${tab.axis}:${activePromptPolarity}`,
        style: inputStyle,
        onfocus: () => { activeTagTarget = { kind: 'native-axis', axis: tab.axis, id: source.id, variant, polarity: activePromptPolarity, label: `${source.label}${variant !== undefined ? ' v-' + variant : ''} ${negative ? 'Negative' : 'Positive'}` }; },
        onchange: event => save(event.currentTarget.value),
      }),
      promptTagChips(h, value, win),
      promptTagAdder(h, value, save, `native:${tab.axis}:${source.id}:${activePromptPolarity}`),
    ),
    h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;' },
      api.ui.button('이 항목을 게임 기본값으로 복원', () => {
        const settings = ImageStudio_기본축설정읽기();
        const axisPrompts = { ...settings[tab.axis] };
        if (variant !== undefined) {
          const current = axisPrompts[source.id] || {}, variants = { ...current.variants };
          delete variants[variant];
          if (Object.hasOwn(current,'positivePrompt') || Object.hasOwn(current,'negativePrompt')) variants[variant] = { positivePrompt: nativeValue, negativePrompt: '' };
          axisPrompts[source.id] = { ...current, variants };
          if (!Object.keys(variants).length && !Object.hasOwn(current,'positivePrompt') && !Object.hasOwn(current,'negativePrompt')) delete axisPrompts[source.id];
        } else {
          delete axisPrompts[source.id];
          // 사용자가 이 상태의 복원을 명시한 경우에만 같은 상태의 예전 편집값도 함께 해제합니다.
          if(tab.axis==='exposure')for(const id of Object.keys(axisPrompts))if(ImageStudio_노출항목ID읽기(id)===source.id)delete axisPrompts[id];
        }
        api.settings.set({ nativeAxisPrompts: { ...settings, [tab.axis]: axisPrompts } });
        win.refresh();
      }, { disabled: variant !== undefined ? !commonOverride.variants?.[variant] && !Object.hasOwn(commonOverride,'positivePrompt') && !Object.hasOwn(commonOverride,'negativePrompt') : !Object.prototype.hasOwnProperty.call(prompts[tab.axis] || {}, source.id) }),
      h('span', { class: 'wml-muted wml-small' }, variant !== undefined ? '선택한 장면과 변형 번호에만 적용합니다. 일상 작업의 일반 생성은 v-0을 사용합니다.' : '같은 조건 ID에 공통 적용됩니다. 독립된 기본 태그가 없는 항목은 빈 값으로 표시됩니다.'),
    ),
  ];
}

const ImageStudio_원본설정그리기 = renderSettings;
function ImageStudio_확장설정그리기(body, win) {
  ImageStudio_원본설정그리기(body, win);
  const tab = ImageStudio_기본축탭목록.find(item => item.id === activeSettingsTab);
  if (!tab) return;
  body.querySelector('[data-active-situation-preset]')?.remove();
  const introduction = body.querySelector('main > p.wml-note');
  if (introduction) introduction.textContent = tab.axis === 'situation'
    ? '선택한 장면과 v-0~v-3 번호별 Positive를 교체하고 추가 Negative를 설정합니다. 다른 번호의 프롬프트는 유지합니다.'
    : '선택한 조건 ID의 Positive를 교체하고 추가 Negative를 설정합니다. 수정값은 같은 조건 ID를 사용하는 생성에 공통 적용됩니다.';
  const section = body.querySelector('main > section.wml-section');
  if (section) section.append(...ImageStudio_기본축프롬프트그리기(api.ui.h, win, tab).filter(Boolean));
}

api.ui.settings(ImageStudio_확장설정그리기);

host.positionApplicable = ImageStudio_자세상황에맞는가;

const ImageStudio_삽입자세우선순위 = ['missionary', 'doggystyle', 'spooning', 'mating-press', 'prone-bone', 'standing-sex', 'ekiben', 'daisuki-hold', 'full-nelson', 'double-penetration'];
const ImageStudio_기승자세우선순위 = ['cowgirl', 'reverse-cowgirl'];
const ImageStudio_구강손자세우선순위 = new Map([
  ['blowjob', ['kneeling-fellatio', 'deep-throat', 'irrumatio-front', 'upside-down-facefuck']],
  ['deepthroat', ['deep-throat', 'irrumatio-front', 'upside-down-facefuck']], ['clean_with_mouth', ['kneeling-fellatio']],
  ['cum_in_mouth', ['kneeling-fellatio', 'deep-throat']], ['patron_blowjob', ['kneeling-fellatio', 'deep-throat', 'irrumatio-front', 'upside-down-facefuck']],
  ['patron_deepthroat', ['deep-throat', 'irrumatio-front', 'upside-down-facefuck']],
  ['patron_blowjob_climax', ['kneeling-fellatio', 'deep-throat', 'irrumatio-front']], ['patron_blowjob_swallow', ['kneeling-fellatio', 'deep-throat']],
  ['cunnilingus', ['cunnilingus']], ['patron_cunnilingus', ['cunnilingus']], ['sixty_nine', ['sixty-nine']],
  ['bath_attendant_handjob', ['seated-handjob']], ['handjob', ['seated-handjob']], ['patron_handjob', ['seated-handjob']],
  ['patron_handjob_finish', ['seated-handjob']], ['patron_handjob_climax', ['seated-handjob']],
  ['titfuck', ['paizuri']], ['patron_titfuck', ['paizuri']],
]);

function ImageStudio_장면상황Id읽기(imageKey) {
  const part = String(imageKey || '').split('__').find(value => /^(?:scene|task)-/.test(value));
  return part?.replace(/^(?:scene|task)-/, '') || '';
}

function ImageStudio_장면자동자세후보읽기(imageKey) {
  const situation = ImageStudio_장면상황Id읽기(imageKey);
  if (!situation) return [];
  let priority = [];
  if (['riding', 'patron_riding'].includes(situation)) priority = ImageStudio_기승자세우선순위;
  else if (/^(?:patron_)?(?:sex|anal)(?:_|$)/.test(situation) || ['sex', 'anal'].includes(situation)) priority = ImageStudio_삽입자세우선순위;
  else if (['standing_sex', 'patron_standing_sex'].includes(situation)) priority = ['standing-sex'];
  else priority = ImageStudio_구강손자세우선순위.get(situation) || [];
  const compatiblePriority = priority.filter(id => ImageStudio_자세상황에맞는가(id, imageKey));
  if (compatiblePriority.length) return compatiblePriority;
  return Object.keys(POSITION_PRESETS).filter(id => ImageStudio_자세상황에맞는가(id, imageKey));
}

function ImageStudio_자세프리셋장면맞춤(preset, imageKey) {
  if (!preset || preset.id === 'double-penetration' || !/^(?:patron_)?anal(?:_|$)/.test(ImageStudio_장면상황Id읽기(imageKey))) return preset;
  return { ...preset, prompt: String(preset.prompt || '').replaceAll('vaginal sex', 'anal sex') };
}

function ImageStudio_장면자세정리하기(result, preset) {
  if (!Array.isArray(result?.parts)) return result;
  const 자세태그 = /^(?:standing|sitting|seated|on chair|kneeling|looking up|lying(?: on (?:back|side)| face down)?|on (?:all )?fours|all fours|ass up|bent over|legs (?:spread|raised)|straddling|girl on top|facing (?:another|away)|face to face|sex from behind|standing sex|rear view)$/;
  const 행위태그 = /^(?:vaginal sex|anal sex|fellatio|cunnilingus|handjob|paizuri|breast press|mutual oral sex|69 position)$/;
  const 행위교체 = !['standing', 'sitting', 'kneeling', 'lying-back', 'all-fours'].includes(preset?.id);
  const removed = [];
  const parts = result.parts.flatMap(part => {
    if (!POSITION_PART_LABELS.has(part.label)) return [part];
    const kept = promptTokens(part.tags).filter(tag => {
      const normalized = promptTagIdentity(tag).spaced;
      const conflict = 자세태그.test(normalized) || (행위교체 && 행위태그.test(normalized));
      if (conflict) removed.push(tag);
      return !conflict;
    });
    return kept.length ? [{ ...part, tags: kept.join(', ') }] : [];
  });
  return removed.length ? { ...result, prompt: withoutPromptTags(result.prompt, removed.join(', ')), parts } : result;
}

function ImageStudio_추가조건목록읽기() {
  if (host.planning?.axes) return host.planning.axes;
  const auto = { value: 'auto', label: '자동 · 추가 지정 없음' };
  const axes = [
    { id: 'promptPreset', label: '상황 프리셋', section: '프롬프트 세부 조건', items: [auto, legacySituationConfig(), ...currentSituationPresets()].map(item => item.value ? item : { value: item.id, label: item.name }) },
    { id: 'promptPosition', label: '자세 / 체위 · 장면별 적용', section: '프롬프트 세부 조건', items: [{value:'auto',label:'적용 안함 · 자세 추가 없음'}, ...Object.values(POSITION_PRESETS).filter(item=>item.id!=='none').map(item => ({ value: item.id, label: item.name, description: '이 자세와 어울리는 장면에만 적용됩니다.' }))] },
  ];
  for (const group of FIELD_GROUPS) {
    const families = new Map();
    for (const field of group.fields) {
      const family = field.key.startsWith('badguest.') || field.key.endsWith('.map') ? field.key : field.key.split('.').slice(0, -1).join('.');
      const id = 'promptField:' + family;
      if (!families.has(id)) families.set(id, { id, family, group: group.id, label: field.label.replace(/ · .*$| [0-9].*$/, ''), section: group.id === 'h-status' ? '추가 장면/작업' : group.title + ' · 세부 조건', items: [auto] });
      const axis = families.get(id);
      if (field.key.endsWith('.map')) {
        const maps = [currentPrompts(),currentNegativePrompts(), ...currentSituationPresets().flatMap(preset => [preset.prompts,preset.negativePrompts])];
        const keys = [...new Set(maps.flatMap(prompts => Object.keys(parseMap(prompts?.[field.key]))))];
        for (const key of keys) axis.items.push({ value: field.key + ':' + key, label: field.label + ' · ' + key });
      } else axis.items.push({ value: field.key, label: field.label });
    }
    axes.push(...families.values());
  }
  axes.push({ id: 'promptDialogue', label: '대화 감지 규칙', section: '대화 · 세부 조건', items: [auto, ...[legacySituationConfig(), ...currentSituationPresets()].flatMap(config => config.dialogueRules || []).filter((rule, index, rules) => rules.findIndex(other => other.id === rule.id) === index).map(rule => ({ value: rule.id, label: rule.text }))] });
  axes.push(...ImageStudio_맥락조건축읽기(auto));
  return axes;
}
function ImageStudio_추가조건공간읽기(selected = {}) {
  const settings = api.settings.get();
  const axes = ImageStudio_추가조건목록읽기();
  const dimensions = [];
  let count = 1n;
  for (const axis of axes) {
    const valid = new Set(axis.items.map(item => item.value));
    const values = Array.isArray(selected[axis.id]) && selected[axis.id].length ? selected[axis.id] : ['auto'];
    const choices = [...new Set(values)].filter(value => valid.has(value));
    if (!choices.length) throw Error(axis.label + '에서 유효한 세부 조건을 선택해 주세요.');
    dimensions.push({ id: axis.id, choices });
    count *= BigInt(choices.length);
  }
  return { count, at(index) {
    if (index < 0n || index >= count) throw Error('세부 조건 조합 인덱스가 범위를 벗어났습니다.');
    const values = [];
    for (let position = dimensions.length - 1; position >= 0; position--) {
      const { id, choices } = dimensions[position], size = BigInt(choices.length);
      values[position] = choices[Number(index % size)]; index /= size;
    }
    const combination = Object.fromEntries(dimensions.map(({id}, position) => [id,values[position]]));
    ImageStudio_계획설정자료.set(combination,{settings,axes});
    return combination;
  } };
}
function ImageStudio_추가조건조합읽기(selected = {}) {
  const space = ImageStudio_추가조건공간읽기(selected);
  if (space.count > 120000n) throw Error('세부 조건 조합이 120,000개를 넘었습니다. 선택을 줄여 주세요.');
  return Array.from({length:Number(space.count)}, (_, index) => space.at(BigInt(index)));
}
function ImageStudio_계획상황설정읽기(character, characterId) {
  const id = host.planning?.combination?.promptPreset;
  if (!id || id === 'auto') return situationConfigForCharacter(character, characterId);
  return id === 'default' ? legacySituationConfig() : currentSituationPresets().find(preset => preset.id === id) || legacySituationConfig();
}
function ImageStudio_상태코드읽기(value) {
  const [key,mapKey] = value.split(':');
  if (mapKey) return (key === 'status.feelings.map' ? 'feeling-' : 'drive-') + mapKey;
  if (key.startsWith('badguest.')) return key.slice(9);
  if (key.startsWith('jewelry.')) return key.replaceAll('.','-');
  return key.split('.').slice(1).join('-');
}
function ImageStudio_계획상태묶음읽기(state, character, characterId, config, imageKey, polarity) {
  if (!config) return [];
  const source = polarity === 'positivePrompt' ? config.prompts : config.negativePrompts;
  let groups = promptGroups(state, character, characterId, source, config.outfitStates, config.dialogueRules, imageKey, polarity);
  const combination = host.planning?.combination || {};
  const fields = ImageStudio_추가조건목록읽기().filter(axis => axis.family && combination[axis.id] && combination[axis.id] !== 'auto');
  // 명시한 영역은 자동 판정 대신 선택한 세부 상태로 구성합니다.
  const explicit = new Set(fields.map(axis => axis.group));
  if (host.planning && polarity === 'positivePrompt') {
    host.planning.gagged = fields.some(axis => combination[axis.id] === 'badguest.gagged')
      || (!explicit.has('badguest') && ImageStudio_입마개상태인가(state, character, characterId));
  }
  const bodyParts = new Set(fields.filter(axis => axis.group === 'h-status').map(axis => axis.family.split('.')[1]));
  groups = groups.filter(group => !(explicit.has('badguest') && group.id === 'badguest')
    && !(explicit.has('detail') && group.label === api.t({ko:'상세 상태',en:'Detailed status'}))
    && ![...bodyParts].some(part => group.id === 'body-' + part)
    && !(combination.promptDialogue && combination.promptDialogue !== 'auto' && group.id === 'dialogue'));
  const manual = new Map();
  for (const axis of fields) {
    const value = combination[axis.id], separator = value.indexOf(':'), key = separator < 0 ? value : value.slice(0, separator);
    const tags = separator < 0 ? source?.[key] || '' : parseMap(source?.[key])[value.slice(separator + 1)] || '';
    if (!outfitAllows(config.outfitStates?.[key] || DEFAULT_OUTFIT_STATES[key] || ALL_OUTFIT_STATES, outfitIdFor(character,imageKey),key,imageKey,character)) continue;
    const part = axis.family.split('.')[1];
    const id = axis.group === 'h-status' ? 'body-' + part : axis.group;
    const label = axis.group === 'badguest' ? api.t({ko:'나쁜 손님 모드용',en:'Bad Guest'}) : axis.group === 'detail' ? api.t({ko:'상세 상태',en:'Detailed status'}) : api.t({ko:'부위별 상태 · '+(FLUID_PARTS.find(entry=>entry.part===part)?.label || part),en:'Body status · '+part});
    if (!manual.has(id)) manual.set(id,{id,label,value:{codes:[],tags:[]}});
    addPrompt(manual.get(id).value,ImageStudio_상태코드읽기(value),tags);
  }
  groups.push(...[...manual.values()].filter(group=>group.value.tags.length));
  if (combination.promptDialogue && combination.promptDialogue !== 'auto') {
    const rule = [...(config.dialogueRules || []),...currentDialogueRules(),...currentSituationPresets().flatMap(preset => preset.dialogueRules || [])].find(rule => rule.id === combination.promptDialogue);
    if (rule && outfitAllows(rule.outfitStates || ALL_OUTFIT_STATES,outfitIdFor(character,imageKey),'',imageKey,character)) {
      const value={codes:[],tags:[]};addPrompt(value,'dialogue-'+rule.id,rule[polarity]);
      if(value.tags.length) groups.push({id:'dialogue',label:api.t({ko:'대화 감지',en:'Dialogue match'}),value});
    }
  }
  const order = group => group.id === 'dialogue' ? 100 : group.id === 'badguest' ? 0 : group.label === api.t({ko:'상세 상태',en:'Detailed status'}) ? 1 : 2 + FLUID_PARTS.findIndex(part => group.id === 'body-' + part.part);
  return groups.sort((left,right)=>order(left)-order(right));
}
function ImageStudio_계획프롬프트추가하기(build, combination, archetypeId) {
  const previous = host.planning;
  const planning = { combination, archetypeId, ...ImageStudio_계획설정자료.get(combination), state: null, raw: null, result: null };
  host.planning = planning;
  try {
    const items = build();
    if (!items.length) return [];
    if (!planning.result) throw Error('조건부 이미지의 프롬프트를 읽지 못했습니다. 게임과 ImageStudio 버전을 확인해 주세요.');
    const result = planning.result;
    const explicit = Object.entries(combination).filter(([,value]) => value !== 'auto');
    return items.map(item => ({ ...item, talentId: result.key, prompt: result.prompt, negativePrompt: result.negativePrompt, ImageStudioParts: result.parts,
      debug: { ...item.debug, imageMatching: globalThis.WW_ImageStudioMatching?.metadata?.(result.key) || host.matchingContext?.(result.key, host.planning.state?.characters?.[host.planning.state.primaryCharacterId]) },
      ImageStudioGagged: planning.gagged === true,
      ...result.genParams, contextSummary: item.contextSummary + (explicit.length ? ' · ' + explicit.map(([axis,value]) => axis + '=' + value).join(' ') : '') }));
  } finally { host.planning = previous; }
}
host.axes = ImageStudio_추가조건목록읽기;
host.combinations = ImageStudio_추가조건조합읽기;
host.combinationSpace = ImageStudio_추가조건공간읽기;
host.plan = ImageStudio_계획프롬프트추가하기;
baseApi.hook('imagePrompt', { priority: 10000, after(result) { if (host.planning) host.planning.raw = result; } });
