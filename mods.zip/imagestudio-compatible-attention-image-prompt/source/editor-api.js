function ImageStudio_상황프롬프트Api만들기(base, host) {
  const settingsKey = host.modern ? 'wml.mod.attention-image-prompt' : 'wml.mod.imagestudio-compatible-attention-image-prompt';
  const restorePosition = host.modern ? result => result : ImageStudio_체위호환연결하기(base);
  const settings = {
    get: (defaults = {}) => { if (host.planning?.settings) return { ...defaults, ...host.planning.settings }; try { return { ...defaults, ...JSON.parse(localStorage.getItem(settingsKey) || '{}') }; } catch { return { ...defaults }; } },
    set: patch => { const value = { ...settings.get(), ...patch }; localStorage.setItem(settingsKey, JSON.stringify(value)); return value; },
  };
  return { ...base, settings,
    store: { ...base.store, game: () => host.planning?.state || base.store.game() },
    fn: name => name === 'imageGenerate' ? request => host.generate(request) : base.fn(name),
    hook: (name, options) => {
      if (name === 'pauseMenu') return () => {};
      // 단독 attention이 켜져 있어도 공통 편집기의 의상 설정은 생성 전에 적용합니다.
      // 기존 의상 훅은 정의를 복제하여 프롬프트만 바꾸고 게임의 착용 상태는 유지합니다.
      if (host.external && !['imagePrompt', 'imageKey', ...(host.modern ? [] : ['imageLookup', 'outfitById'])].includes(name)) return () => {};
      if (name === 'imageKey') { host.keyHook = options.after; return () => { host.keyHook = null; }; }
      if (name === 'imagePrompt') {
        return globalThis.WW_ImageStudioBridge.extensions.registerPromptProvider({
          id: 'attention-editor', priority: -1000,
          key: (key, context) => host.modern && !host.planning ? host.modernKey?.(key) ?? key : host.keyHook?.(key, [context.character]) ?? key,
          compose(result, context) {
          if (host.modern && !host.planning) return host.modernCompose?.(result, context) ?? result;
          const args = [context.character, context.room];
          const unforced = restorePosition(result, args[0]);
          if (!host.planning) return options.after(unforced,args);
          const character = args[0], real = base.store.game();
          const id = character?.id || '__imagestudio_plan';
          const planned = { ...character, archetypeId: host.planning.archetypeId };
          host.planning.state = { ...real, primaryCharacterId:id, characters:{...real?.characters,[id]:planned} };
          let value = options.after(host.planning.raw || unforced, [planned,...args.slice(1)]);
          if (host.modern) value = host.modern.composePlan(value, planned, host.planning.state, context.room);
          host.planning.result = value || result;
          return value;
        } });
      }
      return base.hook(name, host.external ? { ...options, priority: -1000 } : options);
    },
    ui: { ...base.ui, settings: render => { host.renderSettings = render; },
      window: options => options.id === 'settings' ? host.open() : base.ui.window(options) },
  };
}

