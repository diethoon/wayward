// AIP 1.77 UI uses the original instance and storage. Legacy-only axes remain in this adapter.
function ImageStudio_Aip설정연결하기(aip) {
  const key = 'wml.mod.attention-image-prompt';
  const legacyKey = 'wml.mod.imagestudio-compatible-attention-image-prompt';
  const read = text => { const value = JSON.parse(text || '{}'); if (!value || Array.isArray(value) || typeof value !== 'object') throw Error('프롬프트 설정 객체가 올바르지 않습니다.'); return value; };
  const existing = read(localStorage.getItem(key));
  if (existing.imageStudioMigration177?.complete) return;
  const oldText = localStorage.getItem(legacyKey), legacy = read(oldText);
  const merge = (fallback, preferred) => {
    if (Array.isArray(preferred)) {
      if (preferred.length && preferred.every(row => row && typeof row.id === 'string') && Array.isArray(fallback)) {
        const rows = new Map(fallback.filter(row => row?.id).map(row => [row.id, row]));
        for (const row of preferred) rows.set(row.id, merge(rows.get(row.id), row));
        return [...rows.values()];
      }
      return preferred;
    }
    if (!preferred || typeof preferred !== 'object') return preferred;
    const result = fallback && typeof fallback === 'object' && !Array.isArray(fallback) ? { ...fallback } : {};
    for (const [id, value] of Object.entries(preferred)) {
      if (['__proto__', 'constructor', 'prototype', 'migration'].includes(id)) continue;
      result[id] = merge(result[id], value);
    }
    return result;
  };
  const backupKey = legacyKey + '.before-aip-1770';
  if (localStorage.getItem(backupKey) === null) localStorage.setItem(backupKey, JSON.stringify({
    attention: aip.editor.initialSettings, commonEditor: oldText,
  }));
  const settings = merge(existing, legacy);
  settings.imageStudioMigration177 = { complete: true, version: 1, backupKey };
  localStorage.setItem(key, JSON.stringify(settings));
  aip.editor.reload();
}

function ImageStudio_Aip편집기그리기(api, aip, host, body, win) {
  const h = api.ui.h;
  const style = h('style', {}, `
    [data-wwis-aip-editor] [data-aip-settings] .aip-outfit-layout { grid-template-columns:minmax(0,1fr); }
    [data-wwis-aip-editor] [data-aip-settings] .aip-outfit-preview { position:static; }
    [data-wwis-aip-editor] [data-aip-settings] .aip-outfit-editor textarea {
      width:100%; max-width:100%; min-width:0; box-sizing:border-box;
      min-height:160px!important; resize:vertical;
    }
  `);
  const modern = h('div', { 'data-wwis-aip-editor': aip.editor.modVersion });
  const extra = h('div', { 'data-wwis-legacy-axes': '' });
  const details = h('details', { 'data-wwis-additional-prompts': '', open: host.additionalOpen === true },
    h('summary', {}, 'ImageStudio 추가 조건 · 장소 / 기분 / 인원 / 노출 / 모드 상태'), extra);
  const modernWin = { ...win, refresh: () => { aip.editor.render(modern, modernWin); } };
  const legacyWin = { ...win, refresh: () => host.renderLegacyExtras(extra, legacyWin) };
  body.replaceChildren(style, modern, details);
  aip.editor.render(modern, modernWin);
  details.addEventListener('toggle', () => { host.additionalOpen = details.open; if (details.open && !extra.childNodes.length) legacyWin.refresh(); });
  if (details.open) legacyWin.refresh();
}
