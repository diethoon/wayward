// BadGuest 1.4.1 effects/equipment 및 구 상태를 읽기만 합니다. 제작자 코어/저장은 변경하지 않습니다.
function ImageStudio_나쁜손님자료읽기(state) {
  return state?.mods?.badguest ?? state?.mods?.BadGuest ?? state?.mods?.['bad-guest'] ?? state?.modData?.BadGuest ?? {};
}

function ImageStudio_나쁜손님상태읽기(state, character, characterId) {
  if (characterId !== state?.primaryCharacterId) return {};
  const data = ImageStudio_나쁜손님자료읽기(state), slot = Number(state.slot) || 0;
  const active = effect => effect?.startedAtSlot != null && Number(effect.startedAtSlot) <= slot
    && (effect.endsAtSlot == null || slot < Number(effect.endsAtSlot));
  const modernEffects = data.effects && typeof data.effects === 'object';
  const modernEquipment = data.equipment && typeof data.equipment === 'object';
  const visible = item => !!item && (item.active === true || item.afterUntilSlot != null && slot < Number(item.afterUntilSlot));
  const room = modernEquipment ? api.fn('wifeLocation')(state) : null;
  const worn = kind => visible(data.equipment?.[kind]) && data.equipment[kind].roomId === room;
  const restraint = data.restraint, legacyVisible = visible(restraint);
  const legacyDrug = data.drugEffect, legacyActive = active(legacyDrug);
  const unconscious = ['sleeping','passed_out'].includes(character?.currentTask ?? character?.task);
  return {
    handcuffed: modernEquipment ? worn('restraint') : legacyVisible,
    blindfolded: modernEquipment ? worn('blindfold') : !!(legacyVisible && restraint.blindfolded
      || visible(data.blindfold) || data.blindfolded === true || character?.badGuestBlindfolded === true),
    gagged: modernEquipment ? worn('gag') : !!(legacyVisible && restraint.gagged
      || visible(data.gag) || data.gagged === true || character?.badGuestGagged === true),
    drugged: modernEffects ? active(data.effects.aphrodisiac) : Number(character?.badGuestDrugArousal) > 0
      || legacyActive && (!legacyDrug.type || legacyDrug.type === 'aphrodisiac'),
    hallucinated: !modernEffects && (Number(character?.badGuestHallucinatedUntilSlot) > slot
      || legacyActive && legacyDrug.type === 'hallucinogen'),
    confused: !unconscious && !!modernEffects && active(data.effects.confusion),
    intoxicated: !!modernEffects && active(data.effects.intoxicationFloor),
    unconscious,
  };
}

function ImageStudio_입마개상태인가(state, character, characterId) {
  return ImageStudio_나쁜손님상태읽기(state, character, characterId).gagged === true;
}

function ImageStudio_나쁜손님프롬프트읽기(state, character, characterId, prompts) {
  if (characterId !== state?.primaryCharacterId) return null;
  const flags = ImageStudio_나쁜손님상태읽기(state, character, characterId), result = { codes: [], tags: [] };
  for (const code of ['handcuffed','blindfolded','gagged','drugged','hallucinated','confused','intoxicated']) {
    if (flags[code]) addPrompt(result, code, prompts['badguest.' + code]);
  }
  return result.tags.length ? result : null;
}
