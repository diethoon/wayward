// 내장 프롬프트 편집기와 같은 클로저에서 동의·흔적·임신·출산 상태를 이미지 조건으로 만듭니다.
const ImageStudio_맥락상태축목록 = [
  {
    id: 'consent', planningId: 'promptConsent', tabId: 'context-consent', title: '동의·강요 상태',
    note: '현재 성적 장면의 명시적 상태값으로 자발·망설임·강요·강제 합류·미약·환각·착란·만취약·의식 없음 상태를 구분합니다. 호감도 같은 추정 수치는 사용하지 않습니다.',
    values: [
      ['not_applicable', '적용 안 함', '성적 장면이 아니거나 이 조건을 사용하지 않습니다.'],
      ['voluntary', '자발적 참여', '강요·약물·의식 없음 기록이 없는 현재 성적 장면입니다.'],
      ['hesitant', '망설이며 참여', '거절·정체·압박 기록은 있지만 강제 진행 기록은 없는 현재 성적 장면입니다.'],
      ['coerced', '거절 뒤 강요', '현재 손님 장면에 coercedSinceSlot이 기록된 상태입니다.'],
      ['forced_join', '강제 합류', '현재 그룹 장면에 badGuestForcedJoinIds 또는 badGuestForcedGroup이 기록된 상태입니다.'],
      ['drugged', '미약 영향', 'BadGuest의 effects.aphrodisiac이 활성화되었거나 구 badGuestDrugArousal 값이 0보다 큰 상태입니다.'],
      ['hallucinated', '환각 상태', '구 badguest 환각제 효과가 활성화된 상태입니다.'],
      ['confused', '착란·상대 오인', 'BadGuest의 effects.confusion이 활성화되어 상대를 다른 인물로 오인합니다.'],
      ['intoxicated', '만취약 영향', 'BadGuest의 effects.intoxicationFloor가 활성화된 상태입니다.'],
      ['unconscious', '의식 없음', '그녀가 sleeping 또는 passed_out 상태인 성적 장면입니다.'],
    ],
  },
  {
    id: 'residue', planningId: 'promptResidue', tabId: 'context-residue', title: '사정 후 체액 흔적',
    note: 'aftermathTags의 정액 흔적을 읽습니다. 사정 뒤 다른 성행위가 계속되어도 현재 장면 프롬프트와 이미지 키에 흔적을 유지합니다.',
    values: [
      ['none', '흔적 없음', '별도 체액 흔적을 사용하지 않습니다.'],
      ['face', '얼굴의 흔적', 'cum_on_face 상태입니다.'],
      ['hands', '손의 흔적', 'cum_on_hands 상태입니다.'],
      ['chest', '가슴의 흔적', 'cum_on_chest 상태입니다.'],
      ['body', '몸의 흔적', 'cum_on_body 상태입니다.'],
      ['thighs', '허벅지에 흐르는 흔적', 'cum_dripping_thighs 상태입니다.'],
      ['mixed', '여러 부위 흔적', '수동 생성에서 여러 부위 흔적을 한 장에 지정합니다.'],
    ],
  },
  {
    id: 'pregnancy', planningId: 'promptPregnancy', tabId: 'context-pregnancy', title: '임신·산후 상태',
    note: '임신·출산 모드와 창관 임신 연동의 conceptionDay를 읽어 초기·중기·후기를 나누고, 출산 당일에는 산후 상태를 적용합니다. 게임의 임신 기간이나 규칙은 바꾸지 않습니다.',
    values: [
      ['none', '임신 상태 없음', '임신·산후 프롬프트를 사용하지 않습니다.'],
      ['early', '임신 초기', '수정일 당일과 다음 날입니다.'],
      ['middle', '임신 중기', '수정 후 2일째입니다.'],
      ['late', '임신 후기', '수정 후 3일째부터 출산 전까지입니다.'],
      ['postpartum', '출산 당일·산후', '해당 인물의 출산 기록이 현재 날짜에 생성된 상태입니다.'],
    ],
  },
  {
    id: 'life_event', planningId: 'promptLifeEvent', tabId: 'context-life-event', title: '출산·아이 처치 장면',
    note: '임신 모드가 실제로 띄운 출산 직후·아이 처치 상의·입양·부모님 위탁 알림에서만 장면을 적용합니다.',
    values: [
      ['none', '별도 사건 없음', '출산·아이 처치 사건 프롬프트를 사용하지 않습니다.'],
      ['birth', '출산 직후', 'wc2_pregnancy_reaction의 birth 알림입니다.'],
      ['child_discussion', '아이 처치 상의', '입양 또는 부모님 위탁을 결정하기 전의 상의 알림입니다.'],
      ['child_adoption', '입양 장면', '아이 처치 결과가 adopted인 알림입니다.'],
      ['child_parents', '부모님께 맡기는 장면', '아이 처치 결과가 parents인 알림입니다.'],
    ],
  },
];

const ImageStudio_맥락상태기본값 = {
  consent: {
    voluntary: { positivePrompt: 'eager expression, relaxed posture, reciprocating, looking at partner', negativePrompt: 'tears, scared, distressed expression' },
    hesitant: { positivePrompt: 'uncertain expression, nervous, tense posture, looking away', negativePrompt: 'eager expression, broad smile' },
    coerced: { positivePrompt: 'distressed expression, unwilling, tears, defensive posture', negativePrompt: 'smile, eager expression, relaxed expression' },
    forced_join: { positivePrompt: 'distressed expression, overwhelmed, frightened, defensive posture', negativePrompt: 'smile, eager expression, relaxed expression' },
    drugged: { positivePrompt: 'dazed expression, unfocused gaze, weak posture', negativePrompt: 'alert expression, confident expression' },
    hallucinated: { positivePrompt: 'hypnotized, spiral eyes, swirling pupils, concentric spiral pupils, dazed smile, vacant expression, anime-style spiral eyes', negativePrompt: 'normal pupils, sharp focused eyes, alert expression' },
    confused: { positivePrompt: 'dazed expression, unfocused gaze, confused expression', negativePrompt: 'alert expression, sharp focused eyes' },
    intoxicated: { positivePrompt: 'drunk, flushed face, unsteady posture', negativePrompt: 'alert expression' },
    unconscious: { positivePrompt: 'unconscious, limp body, closed eyes', negativePrompt: 'open eyes, alert expression, smile' },
  },
  residue: {
    face: { positivePrompt: 'cum on face', negativePrompt: '' },
    hands: { positivePrompt: 'cum on hands', negativePrompt: '' },
    chest: { positivePrompt: 'cum on chest, semen on breasts', negativePrompt: '' },
    body: { positivePrompt: 'cum on body', negativePrompt: '' },
    thighs: { positivePrompt: 'cum dripping down thighs, semen on thighs', negativePrompt: '' },
    mixed: { positivePrompt: 'cum on face, cum on chest, cum on body, cum dripping down thighs', negativePrompt: '' },
  },
  pregnancy: {
    early: { positivePrompt: '', negativePrompt: '' },
    middle: { positivePrompt: '', negativePrompt: '' },
    late: { positivePrompt: '', negativePrompt: '' },
    postpartum: { positivePrompt: 'postpartum woman, exhausted, resting', negativePrompt: '' },
  },
  life_event: {
    birth: { positivePrompt: 'childbirth aftermath, newborn baby, exhausted mother, resting in bed, clothed', negativePrompt: 'nsfw, sex, erotic, nude' },
    child_discussion: { positivePrompt: 'serious family discussion, newborn baby, conflicted expression, clothed', negativePrompt: 'nsfw, sex, erotic, nude' },
    child_adoption: { positivePrompt: 'newborn baby, adoption handoff, bittersweet expression, clothed', negativePrompt: 'nsfw, sex, erotic, nude' },
    child_parents: { positivePrompt: 'newborn baby, grandparents receiving baby, family farewell, clothed', negativePrompt: 'nsfw, sex, erotic, nude' },
  },
};

const ImageStudio_맥락상태선택값 = Object.fromEntries(ImageStudio_맥락상태축목록.map(axis => [axis.id, '']));
const ImageStudio_맥락상태탭목록 = ImageStudio_맥락상태축목록.map(axis => ({
  id: axis.tabId, title: axis.title, note: axis.note, fields: [], contextAxis: axis.id,
}));
SETTINGS_TABS.splice(SETTINGS_TABS.findIndex(tab => tab.id === 'dialogue'), 0, ...ImageStudio_맥락상태탭목록);

function ImageStudio_맥락상태설정정규화하기(value) {
  const result = Object.fromEntries(ImageStudio_맥락상태축목록.map(axis => [axis.id, {}]));
  if (!value || typeof value !== 'object' || Array.isArray(value)) return result;
  for (const axis of ImageStudio_맥락상태축목록) {
    const source = value[axis.id];
    if (!source || typeof source !== 'object' || Array.isArray(source)) continue;
    const allowed = new Set(axis.values.map(([id]) => id));
    for (const [rawId, prompt] of Object.entries(source)) {
      const id = String(rawId || '').trim();
      if (!allowed.has(id) || !prompt || typeof prompt !== 'object' || Array.isArray(prompt)) continue;
      const normalized = {};
      if (typeof prompt.positivePrompt === 'string') normalized.positivePrompt = prompt.positivePrompt;
      if (typeof prompt.negativePrompt === 'string') normalized.negativePrompt = prompt.negativePrompt;
      if (Object.keys(normalized).length) result[axis.id][id] = normalized;
    }
  }
  return result;
}

function ImageStudio_맥락상태설정읽기() {
  return ImageStudio_맥락상태설정정규화하기(api.settings.get({ contextStatePrompts: {} }).contextStatePrompts);
}

function ImageStudio_맥락상태프롬프트읽기(axisId, valueId, field) {
  const saved = ImageStudio_맥락상태설정읽기()[axisId]?.[valueId];
  if (saved && Object.prototype.hasOwnProperty.call(saved, field)) return String(saved[field] || '');
  return String(ImageStudio_맥락상태기본값[axisId]?.[valueId]?.[field] || '');
}

function ImageStudio_맥락상태필드저장하기(axisId, valueId, field, value) {
  const settings = ImageStudio_맥락상태설정읽기();
  const axis = { ...settings[axisId] };
  axis[valueId] = { ...(axis[valueId] || {}), [field]: String(value ?? '') };
  api.settings.set({ contextStatePrompts: { ...settings, [axisId]: axis } });
}

function ImageStudio_맥락상태항목초기화하기(axisId, valueId) {
  const settings = ImageStudio_맥락상태설정읽기();
  const axis = { ...settings[axisId] };
  delete axis[valueId];
  api.settings.set({ contextStatePrompts: { ...settings, [axisId]: axis } });
}

function ImageStudio_맥락장면읽기(imageKey) {
  try {
    const parsed = ImageStudio_이미지키해석하기(String(imageKey || ''));
    return String(parsed?.scene || parsed?.task || '');
  } catch {
    return String(imageKey || '').split('__').find(part => /^(?:scene|task)-/.test(part))?.replace(/^(?:scene|task)-/, '') || '';
  }
}

function ImageStudio_성적맥락인가(imageKey, state) {
  const situation = ImageStudio_맥락장면읽기(imageKey);
  if (state?.activeScene?.sex || state?.activeScene?.patron) return true;
  if (!situation) return false;
  if (situation.startsWith('patron_')) return !['patron_chatting', 'patron_flirting'].includes(situation);
  return /(?:sex|anal|blowjob|deepthroat|handjob|titfuck|cunnilingus|fingered|grinding|riding|thigh_job|sixty_nine|facial|finish|cum_in_mouth|groped|kissing|mutual_touching|breast_worship)/.test(situation);
}

function ImageStudio_동의상태판정하기(state, character, imageKey) {
  if (!ImageStudio_성적맥락인가(imageKey, state)) return 'not_applicable';
  const situation = ImageStudio_맥락장면읽기(imageKey);
  if (['sleeping','passed_out'].includes(character?.currentTask ?? character?.task) || situation === 'passed_out') return 'unconscious';
  const patron = state?.activeScene?.patron;
  const flags = ImageStudio_나쁜손님상태읽기(state, character, characterIdOf(state, character));
  if (patron) {
    if (patron.badGuestForcedGroup || (Array.isArray(patron.badGuestForcedJoinIds) && patron.badGuestForcedJoinIds.length)) return 'forced_join';
    if (patron.coercedSinceSlot != null) return 'coerced';
    if (flags.confused) return 'confused';
    if (flags.hallucinated) return 'hallucinated';
    if (flags.drugged) return 'drugged';
    if (flags.intoxicated) return 'intoxicated';
    if (patron.hasBeenRefused || Number(patron.stalled) > 0 || Number(patron.pressureLevel) > 0 || patron.lastResponse === 'refuse') return 'hesitant';
  }
  if (flags.confused) return 'confused';
  if (flags.hallucinated) return 'hallucinated';
  if (flags.drugged) return 'drugged';
  if (flags.intoxicated) return 'intoxicated';
  return 'voluntary';
}

const ImageStudio_흔적상태대응표 = new Map([
  ['cum_on_face', 'face'], ['cum_on_hands', 'hands'], ['cum_on_chest', 'chest'],
  ['cum_on_body', 'body'], ['cum_dripping_thighs', 'thighs'],
]);

function ImageStudio_흔적상태판정하기(character, imageKey) {
  const situation = ImageStudio_맥락장면읽기(imageKey);
  if (situation.includes('bath')) return [];
  const values = [...new Set((Array.isArray(character?.aftermathTags) ? character.aftermathTags : [])
    .map(tag => ImageStudio_흔적상태대응표.get(String(tag))).filter(Boolean))];
  return values;
}

function ImageStudio_임신기록읽기(state, character, characterId) {
  const main = state?.wc2PregnancyBirthMode265;
  if (characterId === state?.primaryCharacterId || character === state?.characters?.[state?.primaryCharacterId]) {
    return { pregnancy: main?.pregnancy || null, births: main?.birthLog || [] };
  }
  const keys = [characterId, character?.id, character?.workerId, character?.shortname].filter(Boolean).map(String);
  const workers = state?.waywardBrothelPregnancyV1?.workers || {};
  const workerId = keys.find(key => workers[key]);
  const events = state?.waywardBrothelPregnancyV1?.events || [];
  return workerId ? { pregnancy: workers[workerId]?.pregnancy || null, births: events.filter(event => event.workerId === workerId && event.type === 'birth') } : { pregnancy: null, births: [] };
}

function ImageStudio_임신상태판정하기(state, character, characterId) {
  const record = ImageStudio_임신기록읽기(state, character, characterId);
  const day = Number(state?.day) || 1;
  if (record.pregnancy && Number.isFinite(Number(record.pregnancy.conceptionDay))) {
    const elapsed = Math.max(0, day - Number(record.pregnancy.conceptionDay));
    return elapsed <= 1 ? 'early' : elapsed === 2 ? 'middle' : 'late';
  }
  return record.births.some(entry => Number(entry?.day) === day) ? 'postpartum' : 'none';
}

function ImageStudio_아이처치기록읽기(state, alert) {
  const reference = alert?.childDisposition;
  if (!reference?.recordId) return null;
  if (reference.source === 'brothel-pregnancy') return state?.waywardBrothelPregnancyV1?.events?.find(entry => entry.id === reference.recordId)?.childDisposition || null;
  return state?.wc2PregnancyBirthMode265?.birthLog?.find(entry => entry.id === reference.recordId)?.childDisposition || null;
}

function ImageStudio_생활사건판정하기(state, character, characterId) {
  const alert = state?.pendingEvent?.alert;
  const mainCharacter = characterId === state?.primaryCharacterId || character === state?.characters?.[state?.primaryCharacterId];
  if (alert?.kind === 'wc2_pregnancy_reaction' && alert?.pregnancyPaternityNotice?.type === 'birth') return mainCharacter ? 'birth' : 'none';
  if (alert?.kind !== 'wc2_child_disposition') return 'none';
  if (alert.childDisposition?.source === 'brothel-pregnancy') {
    const keys = [characterId, character?.id, character?.workerId, character?.shortname].filter(Boolean).map(String);
    if (!keys.includes(String(alert.childDisposition.workerId || ''))) return 'none';
  } else if (!mainCharacter) return 'none';
  if (alert.childDisposition?.phase === 'question') return 'child_discussion';
  const disposition = ImageStudio_아이처치기록읽기(state, alert);
  return disposition?.status === 'adopted' ? 'child_adoption' : disposition?.status === 'parents' ? 'child_parents' : 'child_discussion';
}

function ImageStudio_맥락상태값읽기(axisId, state, character, characterId, imageKey) {
  const explicit = host.planning?.combination?.[ImageStudio_맥락상태축목록.find(axis => axis.id === axisId)?.planningId];
  if (explicit && explicit !== 'auto') return axisId === 'residue' ? explicit === 'none' ? [] : [explicit] : explicit;
  if (host.planning) return axisId === 'residue' ? [] : axisId === 'consent' ? 'not_applicable' : 'none';
  if (axisId === 'consent') return ImageStudio_동의상태판정하기(state, character, imageKey);
  if (axisId === 'residue') return ImageStudio_흔적상태판정하기(character, imageKey);
  if (axisId === 'pregnancy') return ImageStudio_임신상태판정하기(state, character, characterId);
  return ImageStudio_생활사건판정하기(state, character, characterId);
}

function ImageStudio_맥락상태묶음읽기(state, character, characterId, imageKey, promptField) {
  const groups = [];
  for (const axis of ImageStudio_맥락상태축목록) {
    let values = ImageStudio_맥락상태값읽기(axis.id, state, character, characterId, imageKey);
    values = Array.isArray(values) ? values : [values];
    values = values.filter(value => value && !['none', 'not_applicable'].includes(value));
    if (!values.length) continue;
    const tags = values.flatMap(value => promptTokens(ImageStudio_맥락상태프롬프트읽기(axis.id, value, promptField)));
    if (!tags.length) continue;
    groups.push({
      id: `context-${axis.id}`,
      label: axis.title,
      value: { codes: values.map(value => `context.${axis.id}.${value}`), tags },
    });
  }
  return groups;
}

function ImageStudio_맥락프롬프트직접적용하기(result, state, character, characterId) {
  if (!result || !Array.isArray(result.parts)) return result;
  const positive = ImageStudio_맥락상태묶음읽기(state, character, characterId, result.key, 'positivePrompt');
  const negative = ImageStudio_맥락상태묶음읽기(state, character, characterId, result.key, 'negativePrompt');
  if (!positive.length && !negative.length) return result;
  const prompt = joinPrompt(`${result.prompt || ''}, ${positive.flatMap(group => group.value.tags).join(', ')}`);
  const negativePrompt = joinPrompt(`${result.negativePrompt || ''}, ${negative.flatMap(group => group.value.tags).join(', ')}`);
  return {
    ...result,
    key: keyWithState(result.key, combinedStateSignature(positive, negative), false, null, true),
    prompt,
    negativePrompt,
    parts: [...result.parts, ...positive.map(group => ({ label: group.label, tags: group.value.tags.join(', ') }))],
    genParams: promptGenParams(prompt),
  };
}

function ImageStudio_맥락조건축읽기(auto) {
  return ImageStudio_맥락상태축목록.map(axis => ({
    id: axis.planningId,
    label: axis.title,
    section: axis.id === 'life_event' ? '추가 장면/작업' : '상황 인식 · 세부 조건',
    items: [auto, ...axis.values.map(([value, label, description]) => ({ value, label, description }))],
  }));
}

function ImageStudio_맥락프롬프트그리기(h, win, tab) {
  const axis = ImageStudio_맥락상태축목록.find(item => item.id === tab.contextAxis);
  const candidates = axis.values.filter(([id]) => !['none', 'not_applicable'].includes(id));
  const selected = candidates.find(([id]) => id === ImageStudio_맥락상태선택값[axis.id]) || candidates[0];
  ImageStudio_맥락상태선택값[axis.id] = selected[0];
  const [valueId, label, description] = selected;
  const field = activePromptPolarity === 'negative' ? 'negativePrompt' : 'positivePrompt';
  const settings = ImageStudio_맥락상태설정읽기();
  const customized = Object.prototype.hasOwnProperty.call(settings[axis.id]?.[valueId] || {}, field);
  const value = ImageStudio_맥락상태프롬프트읽기(axis.id, valueId, field);
  const save = next => { ImageStudio_맥락상태필드저장하기(axis.id, valueId, field, next); win.refresh(); };
  return [
    h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
      h('strong', { style: 'font-size:12px;' }, `${axis.title} ${candidates.length}개`),
      h('select', {
        value: valueId, 'data-context-state-source': axis.id,
        style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
        onchange: event => { ImageStudio_맥락상태선택값[axis.id] = event.currentTarget.value; activeTagTarget = null; win.refresh(); },
      }, ...candidates.map(([id, itemLabel]) => h('option', { value: id, selected: id === valueId }, `${itemLabel} (${id})`))),
      h('span', { class: 'wml-muted wml-small' }, customized ? '이 항목의 수정값을 표시 중입니다.' : '내장 기본값을 표시 중입니다.'),
    ),
    h('p', { class: 'wml-note', style: 'margin-bottom:10px;' }, description),
    h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
      h('strong', { style: 'font-size:12px;' }, activePromptPolarity === 'negative' ? '추가 Negative 프롬프트' : '추가 Positive 프롬프트'),
      h('textarea', {
        rows: 5, value, spellcheck: false, 'data-context-state-prompt': `${axis.id}:${activePromptPolarity}`,
        style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:100px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
        onfocus: () => { activeTagTarget = { kind: 'context-state', axis: axis.id, id: valueId, polarity: activePromptPolarity, label: `${label} ${activePromptPolarity}` }; },
        onchange: event => save(event.currentTarget.value),
      }),
      promptTagChips(h, value, win),
      promptTagAdder(h, value, save, `context:${axis.id}:${valueId}:${activePromptPolarity}`),
    ),
    h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;' },
      api.ui.button('이 항목을 내장 기본값으로 복원', () => { ImageStudio_맥락상태항목초기화하기(axis.id, valueId); win.refresh(); }, { disabled: !settings[axis.id]?.[valueId] }),
      h('span', { class: 'wml-muted wml-small' }, '판정 기준은 위 설명대로 고정되며, 이미지에 보낼 Positive·Negative 문구는 여기서 직접 지정합니다.'),
    ),
  ];
}

const ImageStudio_맥락원본설정그리기 = ImageStudio_확장설정그리기;
function ImageStudio_맥락확장설정그리기(body, win) {
  ImageStudio_맥락원본설정그리기(body, win);
  const tab = ImageStudio_맥락상태탭목록.find(item => item.id === activeSettingsTab);
  if (!tab) return;
  body.querySelector('[data-active-situation-preset]')?.remove();
  const introduction = body.querySelector('main > p.wml-note');
  if (introduction) introduction.textContent = '게임 상태 판정은 설명된 명시적 값만 사용합니다. 각 결과에 보낼 Positive·Negative 프롬프트는 직접 수정할 수 있습니다.';
  const section = body.querySelector('main > section.wml-section');
  if (section) section.append(...ImageStudio_맥락프롬프트그리기(api.ui.h, win, tab).filter(Boolean));
}
api.ui.settings(ImageStudio_맥락확장설정그리기);
