// 실행: node wml/mods/<모드>/source/build.mjs
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
const dir=path.dirname(fileURLToPath(import.meta.url));
let attention;
vm.runInNewContext(fs.readFileSync(path.join(dir,'attention/original.js'),'utf8'), {WML:{define:value=>{attention=value;}}});
let attentionBody=attention.setup.toString();
attentionBody=attentionBody.slice(attentionBody.indexOf('{')+1,attentionBody.lastIndexOf('}'));
// 원본 출처 파일은 보존하고, 노출 판정만 게임의 대표 상태로 바꿉니다. 명시한 이미지 키가 실제 상태보다 우선합니다.
const exposureStart=attentionBody.indexOf('    function exposureFlags(imageKey, character) {');
const exposureEnd=attentionBody.indexOf('    function promptPart(key)',exposureStart);
if(exposureStart<0||exposureEnd<0)throw Error('Exposure flags source not found');
attentionBody=attentionBody.slice(0,exposureStart)+'    function exposureFlags(imageKey, character) {\n      return ImageStudio_노출플래그읽기(imageKey, character);\n    }\n\n'+attentionBody.slice(exposureEnd);
// 원본 출처는 보존하고 BadGuest 최신 상태 읽기만 호환부에서 교체합니다.
const badGuestStart=attentionBody.indexOf('    function ImageStudio_나쁜손님자료읽기(state) {');
const badGuestEnd=attentionBody.indexOf('    function detailPromptState(',badGuestStart);
if(badGuestStart<0||badGuestEnd<0)throw Error('BadGuest state reader location missing');
attentionBody=attentionBody.slice(0,badGuestStart)+fs.readFileSync(path.join(dir,'badguest-state.js'),'utf8')+'\n'+attentionBody.slice(badGuestEnd);
const badGuestFieldsEnd='    const DETAIL_FIELDS = [';
attentionBody=attentionBody.replace(badGuestFieldsEnd, `    BAD_GUEST_FIELDS.push(
      {key:'badguest.confused',label:'착란·상대 오인',value:'dazed expression, unfocused gaze, confused expression'},
      {key:'badguest.intoxicated',label:'만취약 효과',value:'drunk, flushed face, unfocused eyes, unsteady posture'}
    );
`+badGuestFieldsEnd);
// 원본 출처 파일은 유지하고 반복 로그 정규화만 메모합니다. 대화 판정/시간/설정은 매번 검사합니다.
const dialogueTextSource = "    function dialogueText(value) {\n      return String(value || '').replace(/\\s+/g, ' ').trim().toLocaleLowerCase();\n    }";
if (attentionBody.split(dialogueTextSource).length !== 2) throw Error('Dialogue text source mismatch');
attentionBody = attentionBody.replace(dialogueTextSource, `    const dialogueTextCache = new Map();
    function dialogueText(value) {
      const source = String(value || '');
      const cached = dialogueTextCache.get(source);
      if (cached !== undefined) return cached;
      const result = source.replace(/\\s+/g, ' ').trim().toLocaleLowerCase();
      if (dialogueTextCache.size >= 4096) dialogueTextCache.delete(dialogueTextCache.keys().next().value);
      dialogueTextCache.set(source, result);
      return result;
    }`);
const dialogueRuleStart = '      for (const rule of rules) {\n        if (!outfitAllows(rule.outfitStates, outfitId)) continue;';
if (attentionBody.split(dialogueRuleStart).length !== 2) throw Error('Dialogue rule source mismatch');
attentionBody = attentionBody.replace(dialogueRuleStart,
  '      for (const rule of rules) {\n        if (!cleanPrompt(rule[promptField])) continue;\n        if (!outfitAllows(rule.outfitStates, outfitId)) continue;');
// 프롬프트 편집기는 체액 감소 등 게임 상태를 쓰지 않습니다. 원본 설정과 읽기 규칙은 보존합니다.
const decayStart=attentionBody.indexOf('    let syncingFluidDecay = false;');
const decayEnd=attentionBody.indexOf('    function normalizeDialogueRule(',decayStart);
if(decayStart<0||decayEnd<0)throw Error('Fluid state subscription source not found');
attentionBody=attentionBody.slice(0,decayStart)+"    function syncFluidDecay() {}\n    api.store.subscribe(() => publishCurrentWifePromptProfile());\n    publishCurrentWifePromptProfile();\n\n"+attentionBody.slice(decayEnd);
const statusDefaultsMarker='    const OUTFIT_STATE_OPTIONS = [';
if (!attentionBody.includes(statusDefaultsMarker)) throw new Error('Status prompt defaults location not found');
attentionBody=attentionBody.replace(statusDefaultsMarker,
  fs.readFileSync(path.join(dir,'status-empty-defaults.js'),'utf8')+'\n'+statusDefaultsMarker);
const applyPositionSource = `      const placement = positionPlacementPrompt(choice.groupSlots);
      const removed = result.parts.filter(part => POSITION_PART_LABELS.has(part.label)
        || String(part.label || '').startsWith('체위 프리셋 ·')`;
if (!attentionBody.includes(applyPositionSource)) throw new Error('Position prompt merge source not found');
attentionBody=attentionBody.replace(applyPositionSource,
  `      result = ImageStudio_장면자세정리하기(result, preset);
      const placement = positionPlacementPrompt(choice.groupSlots);
      const removed = result.parts.filter(part => String(part.label || '').startsWith('체위 프리셋 ·')`);
attentionBody=attentionBody.replace("\n        || (placement && ['그룹', 'Group'].includes(part.label)));", ');');

attentionBody=attentionBody.replace("const POSITION_TAB = { id: 'positions', title: '체위 설정', note: '체위 프롬프트와 추가 인원 배치를 편집하고 여러 조합을 상황별로 고정합니다. 게임 속 실제 행동 상태는 바꾸지 않습니다.' };",
  "const POSITION_TAB = { id: 'positions', title: '장면별 세부 조정', note: '선택한 자세와 Positive·Negative는 검수용 수동 생성에만 사용합니다. 게임 중 장면에는 고정하지 않습니다.' };");

const promptHookStart=attentionBody.indexOf("api.hook('imagePrompt', {");
attentionBody=attentionBody.slice(0,promptHookStart)+attentionBody.slice(promptHookStart).replace('        const nativeNegative = nativeCharacterNegative(character);',
  `        if (host.external && !host.planning) {
          const outfitNegative = outfitPromptGroup(character,result.key,'negativePrompt');
          const corrected = outfitNegative ? {...result,negativePrompt:joinPrompt(result.negativePrompt + ', ' + outfitNegative.value.tags.join(', '))} : result;
          return rememberLatestScenePrompt(applyPositionPreset(corrected, positionChoiceForImageKey(corrected.key)), state, character, characterId);
        }
        const nativeNegative = nativeCharacterNegative(character);`);
attentionBody=attentionBody.replace("negativeGroups.filter(group => !['character', 'outfit'].includes(group.id))", "negativeGroups.filter(group => group.id !== 'character')");
attentionBody=attentionBody.replace(
  "      if (activeTagTarget.kind === 'field') {",
  `      if (activeTagTarget.kind === 'context-state') {
        const field = activeTagTarget.polarity === 'negative' ? 'negativePrompt' : 'positivePrompt';
        ImageStudio_맥락상태필드저장하기(activeTagTarget.axis, activeTagTarget.id, field,
          appendPromptTags(ImageStudio_맥락상태프롬프트읽기(activeTagTarget.axis, activeTagTarget.id, field), tag));
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'native-axis') {
        const settings = ImageStudio_기본축설정읽기();
        const prompt = settings[activeTagTarget.axis]?.[activeTagTarget.id] || {};
        const selectedPrompt = activeTagTarget.variant !== undefined ? {...prompt,...prompt.variants?.[activeTagTarget.variant]} : prompt;
        const field = activeTagTarget.polarity === 'negative' ? 'negativePrompt' : 'positivePrompt';
        const fallback = field === 'positivePrompt' ? (activeTagTarget.variant !== undefined ? ImageStudio_장면변형기본값.get(activeTagTarget.id+':'+activeTagTarget.variant) : undefined) ?? ImageStudio_기본축기본값[activeTagTarget.axis]?.get(activeTagTarget.id) ?? '' : '';
        ImageStudio_기본축필드저장하기(activeTagTarget.axis, activeTagTarget.id, field, appendPromptTags(selectedPrompt[field] ?? fallback, tag), activeTagTarget.variant);
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'field') {`);
attentionBody=attentionBody.replace(
  "        ...Object.values(currentOutfitPrompts()).flatMap(prompt => [prompt.positivePrompt, prompt.negativePrompt]),",
  `        ...Object.values(currentOutfitPrompts()).flatMap(prompt => [prompt.positivePrompt, prompt.negativePrompt]),
        ...Object.values(ImageStudio_기본축설정읽기()).flatMap(axis => Object.values(axis).flatMap(prompt => [prompt.positivePrompt, prompt.negativePrompt, ...Object.values(prompt.variants || {}).flatMap(row => [row.positivePrompt,row.negativePrompt])])),
        ...Object.values(ImageStudio_맥락상태설정읽기()).flatMap(axis => Object.values(axis).flatMap(prompt => [prompt.positivePrompt, prompt.negativePrompt])),`);
attentionBody=attentionBody.replace(
  "      const hasOutfitPrompts = parsed?.outfitPrompts && typeof parsed.outfitPrompts === 'object' && !Array.isArray(parsed.outfitPrompts);",
  `      const hasOutfitPrompts = parsed?.outfitPrompts && typeof parsed.outfitPrompts === 'object' && !Array.isArray(parsed.outfitPrompts);
      const hasNativeAxisPrompts = parsed?.nativeAxisPrompts && typeof parsed.nativeAxisPrompts === 'object' && !Array.isArray(parsed.nativeAxisPrompts);
      const hasContextStatePrompts = parsed?.contextStatePrompts && typeof parsed.contextStatePrompts === 'object' && !Array.isArray(parsed.contextStatePrompts);`);
attentionBody=attentionBody.replace(
  "&& !hasCharacterPrompt && !hasOutfitPrompts && !hasPositionPresetPrompts",
  "&& !hasCharacterPrompt && !hasOutfitPrompts && !hasNativeAxisPrompts && !hasContextStatePrompts && !hasPositionPresetPrompts");
attentionBody=attentionBody.replace(
  "        outfitPrompts: hasOutfitPrompts ? normalizeOutfitPrompts(parsed.outfitPrompts) : currentOutfitPrompts(),",
  `        outfitPrompts: hasOutfitPrompts ? normalizeOutfitPrompts(parsed.outfitPrompts) : currentOutfitPrompts(),
        nativeAxisPrompts: hasNativeAxisPrompts ? ImageStudio_기본축설정정규화하기(parsed.nativeAxisPrompts) : ImageStudio_기본축설정읽기(),
        contextStatePrompts: hasContextStatePrompts ? ImageStudio_맥락상태설정정규화하기(parsed.contextStatePrompts) : ImageStudio_맥락상태설정읽기(),`);

attentionBody=attentionBody.replace(
  "              outfitPrompts: {},",
  `              outfitPrompts: {},
              nativeAxisPrompts: {},
              contextStatePrompts: {},`);

attentionBody=attentionBody.replace(
  `        const { positiveGroups, negativeGroups, dialogue, characterPolicy, situational } = promptContext(state, character, characterId, result);
        const stateKey = positiveGroups.length || negativeGroups.length
          ? keyWithState(result, combinedStateSignature(positiveGroups, negativeGroups), dialogue, characterPolicy, situational)
          : result;`,
  `        const axisKey = ImageStudio_기본축키적용하기(result);
        const { positiveGroups, negativeGroups, dialogue, characterPolicy, situational } = promptContext(state, character, characterId, axisKey);
        const stateKey = positiveGroups.length || negativeGroups.length
          ? keyWithState(axisKey, combinedStateSignature(positiveGroups, negativeGroups), dialogue, characterPolicy, situational)
          : axisKey;`);
attentionBody=attentionBody.replace(
  `    api.hook('imagePrompt', {
      after(result, [character]) {
        const state = api.store.game();`,
  `    api.hook('imagePrompt', {
      after(result, [character]) {
        ImageStudio_기본축프롬프트기록하기(result);
        result = ImageStudio_기본축프롬프트적용하기(result);
        const state = api.store.game();`);
attentionBody=attentionBody.replace('      return [...builtIn, ...custom];',
  `      const sources = new Map([...builtIn, ...custom].map(source => [source.id, source]));
      for (const archetype of globalThis.WW_ImageStudioBridge?.wives?.() || []) {
        if (archetype?.id && !sources.has(archetype.id)) sources.set(archetype.id, {id:archetype.id,name:archetype.name || archetype.shortname || archetype.id,archetype,modded:true});
      }
      return [...sources.values()];`);
attentionBody=attentionBody.replace("${source.custom ? '사용자 아내' : '기본 캐릭터'}", "${source.custom ? '사용자 아내' : source.modded ? '모드 아내' : '기본 캐릭터'}");
// DOM 도우미는 select.value를 option 삽입 전에 설정합니다. 각 option에도 실제 선택 상태를 지정합니다.
function ImageStudio_선택옵션고치기(before, after) {
  if (!attentionBody.includes(before)) throw new Error('Prompt editor select source not found: ' + before.slice(0, 70));
  attentionBody=attentionBody.replace(before, after);
}
ImageStudio_선택옵션고치기(
  "h('option', { value: '' }, '현재 적용 중인 외형 · 직접 수정')",
  "h('option', { value: '', selected: !override?.sourceId }, '현재 적용 중인 외형 · 직접 수정')");
ImageStudio_선택옵션고치기(
  "...sources.map(source => h('option', { value: source.id }, `${source.custom ? '사용자 아내' : source.modded ? '모드 아내' : '기본 캐릭터'} · ${source.name}`))",
  "...sources.map(source => h('option', { value: source.id, selected: source.id === override?.sourceId }, `${source.custom ? '사용자 아내' : source.modded ? '모드 아내' : '기본 캐릭터'} · ${source.name}`))");
ImageStudio_선택옵션고치기(
  "h('option', { value: 'reuse' }, '기존 이미지 우선 · 필요한 장면만 수동 생성')",
  "h('option', { value: 'reuse', selected: characterPrompt.imagePolicy === 'reuse' }, '기존 이미지 우선 · 필요한 장면만 수동 생성')");
ImageStudio_선택옵션고치기(
  "h('option', { value: 'regenerate' }, '정확한 이미지가 없으면 장면별 자동 생성')",
  "h('option', { value: 'regenerate', selected: characterPrompt.imagePolicy === 'regenerate' }, '정확한 이미지가 없으면 장면별 자동 생성')");
ImageStudio_선택옵션고치기(
  "...sources.map(entry => h('option', { value: entry.id }, `${entry.name} (${entry.id})`))",
  "...sources.map(entry => h('option', { value: entry.id, selected: entry.id === source.id }, `${entry.name} (${entry.id})`))");
attentionBody=attentionBody.replace(
  "negative ? '현재 적용 중인 전체 Negative 프롬프트' : '현재 적용 중인 전체 Positive 외형 프롬프트'",
  "negative ? '현재 적용 중인 캐릭터 전용 Negative 프롬프트' : '현재 적용 중인 전체 Positive 외형 프롬프트'");
attentionBody=attentionBody.replace(
  "          promptTagAdder(h, value, save, `character:${activePromptPolarity}`),\n        ),",
  `          promptTagAdder(h, value, save, \`character:\${activePromptPolarity}\`),
          negative ? h('span', { class: 'wml-muted wml-small' }, '게임의 품질·인원·장면별 노출 방지 Negative는 유지하고, 이 캐릭터에 필요한 태그를 교체합니다.') : null,
        ),`);
attentionBody=attentionBody.replace('      const situationConfig = situationConfigForCharacter(character, characterId);',
  '      const situationConfig = host.planning ? ImageStudio_계획상황설정읽기(character, characterId) : situationConfigForCharacter(character, characterId);');
attentionBody=attentionBody.replace(
  "      const positiveGroups = [characterPositive, outfitPositive, ...(situationConfig ? promptGroups(state, character, characterId, situationConfig.prompts, situationConfig.outfitStates, situationConfig.dialogueRules, imageKey, 'positivePrompt') : [])].filter(Boolean);",
  "      const positiveGroups = [characterPositive, outfitPositive, ...(situationConfig ? promptGroups(state, character, characterId, situationConfig.prompts, situationConfig.outfitStates, situationConfig.dialogueRules, imageKey, 'positivePrompt') : []), ...ImageStudio_맥락상태묶음읽기(state, character, characterId, imageKey, 'positivePrompt')].filter(Boolean);");
attentionBody=attentionBody.replace(
  "      const negativeGroups = [characterNegative, outfitNegative, ...(situationConfig ? promptGroups(state, character, characterId, situationConfig.negativePrompts, situationConfig.outfitStates, situationConfig.dialogueRules, imageKey, 'negativePrompt') : [])].filter(Boolean);",
  "      const negativeGroups = [characterNegative, outfitNegative, ...(situationConfig ? promptGroups(state, character, characterId, situationConfig.negativePrompts, situationConfig.outfitStates, situationConfig.dialogueRules, imageKey, 'negativePrompt') : []), ...ImageStudio_맥락상태묶음읽기(state, character, characterId, imageKey, 'negativePrompt')].filter(Boolean);");
attentionBody=attentionBody.replace(
  "          return rememberLatestScenePrompt(applyPositionPreset(corrected, positionChoiceForImageKey(corrected.key)), state, character, characterId);",
  "          const compositionCorrected = ImageStudio_구도프롬프트직접적용하기(corrected, state, character, characterId);\n          const badGuestCorrected = ImageStudio_나쁜손님프롬프트직접적용하기(compositionCorrected, state, character, characterId);\n          return rememberLatestScenePrompt(applyPositionPreset(ImageStudio_맥락프롬프트직접적용하기(badGuestCorrected, state, character, characterId), positionChoiceForImageKey(badGuestCorrected.key)), state, character, characterId);");
const characterNegativeReplaceSource = [
  "          const negativePrompt = joinPrompt(`${characterNegative?.mode === 'replace'",
  '            ? characterNegativeTags',
  '            : joinPrompt(`${originalNegative}, ${characterNegativeTags}`)}, ${extraNegativeTags}`);',
].join('\n');
if (!attentionBody.includes(characterNegativeReplaceSource)) throw new Error('Character negative merge source not found');
attentionBody=attentionBody.replace(characterNegativeReplaceSource, [
  "          const sceneNegative = characterNegative?.mode === 'replace'",
  '            ? withoutPromptTags(originalNegative, nativeNegative)',
  '            : originalNegative;',
  '          const negativePrompt = joinPrompt(`${sceneNegative}, ${characterNegativeTags}, ${extraNegativeTags}`);',
].join('\n'));
for(const polarity of ['positivePrompt','negativePrompt']) {
  const section=polarity==='positivePrompt'?'prompts':'negativePrompts';
  const native=`promptGroups(state, character, characterId, situationConfig.${section}, situationConfig.outfitStates, situationConfig.dialogueRules, imageKey, '${polarity}')`;
  attentionBody=attentionBody.replace(native,`(host.planning ? ImageStudio_계획상태묶음읽기(state, character, characterId, situationConfig, imageKey, '${polarity}') : ${native})`);
}
attentionBody=attentionBody.replace('    function rememberLatestScenePrompt(result, state, character, characterId) {',
  '    function rememberLatestScenePrompt(result, state, character, characterId) {\n      if (host.planning) return result;');
// 설정 창의 생성 버튼은 검수 대기 결과를 만든 뒤 게임 이미지 적용을 보류합니다.
attentionBody=attentionBody.replaceAll("if (!result?.url) throw new Error('이미지 서버에서 결과를 받지 못했습니다.');",
  "if (result?.draft) { positionGeneration.message = '검수창에 이미지를 준비했습니다. 저장을 눌러 승인하세요.'; win?.refresh?.(); return true; }\n        if (!result?.url) throw new Error('이미지 서버에서 결과를 받지 못했습니다.');");
// 잔류 상태 생성기는 win 인자가 없으므로 그 구간에만 안전한 갱신을 사용합니다.
const residueStart=attentionBody.indexOf('async function regenerateResidueImage('),residueEnd=attentionBody.indexOf('\n    function ',residueStart);
attentionBody=attentionBody.slice(0,residueStart)+attentionBody.slice(residueStart,residueEnd).replace('win?.refresh?.();','')+attentionBody.slice(residueEnd);
const matchingSnapshotMarker='      return {\n        positiveGroups,\n        negativeGroups,';
if(!attentionBody.includes(matchingSnapshotMarker))throw Error('Matching context snapshot location not found');
attentionBody=attentionBody.replace(matchingSnapshotMarker,
  '      host.matchingContextSnapshot = {state,character,key:imageKey,groups:[...positiveGroups,...negativeGroups]};\n'+matchingSnapshotMarker);
attentionBody += `
host.connectModern = () => {
 ImageStudio_기본축키적용하기 = ImageStudio_이전기본축키만들기;
 host.modernKey = ImageStudio_기본축키적용하기;
 host.modernCompose = (result, context) => ImageStudio_맥락프롬프트직접적용하기(ImageStudio_기본축프롬프트적용하기(result), context.state, context.character, context.character?.id);
 host.renderLegacyExtras = (body, win) => {
  const all = SETTINGS_TABS.splice(0); SETTINGS_TABS.push(...all.filter(tab => tab.axis || tab.contextAxis));
  if (!SETTINGS_TABS.some(tab => tab.id === activeSettingsTab)) activeSettingsTab = SETTINGS_TABS[0].id;
  try { host.renderSettings(body, win); } finally { SETTINGS_TABS.splice(0, SETTINGS_TABS.length, ...all); }
 };
};
`;
const feature='function ImageStudio_상황프롬프트설치하기(baseApi,host) {\nconst api=ImageStudio_상황프롬프트Api만들기(baseApi,host);\n'+attentionBody+'\n'+fs.readFileSync(path.join(dir,'planner-prompts.js'),'utf8')+'\n'+fs.readFileSync(path.join(dir,'context-state-prompts.js'),'utf8')+'\n'+fs.readFileSync(path.join(dir,'prompt-tab-settings.js'),'utf8')+'\n'+fs.readFileSync(path.join(dir,'matching-context.js'),'utf8')+'\n'+fs.readFileSync(path.join(dir,'attention-upgrades.js'),'utf8')+'\n}\n';
let mod=fs.readFileSync(path.join(dir,'mod.wml.js'),'utf8');
mod=mod.replace('__ATTENTION_SYMBOLS__',JSON.stringify(JSON.parse(fs.readFileSync(path.join(dir,'pre7-symbols.json'),'utf8'))));
const result=fs.readFileSync(new URL('mod.wml.js', import.meta.url), 'utf8').split(/\r?\n/)[0] + '\n' + '// 생성 파일. source/build.mjs로 재생성합니다.\n'+fs.readFileSync(path.join(dir,'editor-api.js'),'utf8')+'\n'+fs.readFileSync(path.join(dir,'imagestudio-compatible-attention-image-prompt.js'),'utf8')+'\n'+feature+'\n'+fs.readFileSync(path.join(dir,'aip-modern.js'),'utf8')+'\n'+mod;
new vm.Script(result);
fs.writeFileSync(path.join(dir,'../mod.js'),Pre7_lazySetup(result));
console.log('Generated '+path.join(dir,'../mod.js'));

// pre7: loading a disabled mod must not initialize globals or change settings.
function Pre7_lazySetup(source){
  const at=source.indexOf('WML.define({');if(at<0)throw Error('WML definition missing');
  const prefix=source.slice(0,at);if(!prefix.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*/g,'').trim())return source;
  const header=prefix.match(/^(?:\s|\/\*[\s\S]*?\*\/|\/\/[^\n]*(?:\n|$))*/)[0];
  let found=false;
  const result=header+source.slice(at).replace(/((?:async\s+)?setup\([^)]*\)\s*\{)/,match=>{found=true;return match+'\n'+prefix+'\nObject.assign(globalThis,{ImageStudio_상황프롬프트Api만들기,ImageStudio_체위호환연결하기,ImageStudio_상황프롬프트설치하기});\n';});
  if(!found)throw Error('setup declaration missing');return result;
}
