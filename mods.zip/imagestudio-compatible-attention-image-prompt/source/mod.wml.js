// 호환성 패치 기준: imagestudio 1.31.7 (개정 기준, 버전 번호에 따른 실행 제한 없음)
WML.define({
  tags: ["image","prompt","needs-image-server"],
  id: 'imagestudio-compatible-attention-image-prompt',
  author: "Hina_Lover",
  name: { ko: '이미지 스튜디오 - 공통 프롬프트 편집기 호환 패치', en: 'ImageStudio · Prompt Editor' },
  version: "1.2.5",
  game: "2026-11-01", lang: 'ko',
  requires: ['imagestudio', 'attention-image-prompt'],
  requiresVersion: { 'attention-image-prompt': '>=1.79.0' },
  loadAfter: ['imagestudio', 'attention-image-prompt'],
  description: '캐릭터·의상·표정·구도·상태의 Positive/Negative 편집과 생성 조건을 제공합니다.',
  symbols: __ATTENTION_SYMBOLS__,
  setup(api) {
    const bridge = api.use('imagestudio').bridge;
    const extensions = bridge.extensions;
    const aip = api.use('attention-image-prompt');
    if (!aip?.editor?.render || !aip.editor.capabilities?.tabJson || !aip.editor.capabilities?.studioSelection)
      throw Error('탭별 JSON·이미지 선택 위임이 포함된 attention-image-prompt 1.79.0 이상을 함께 설치하고 게임을 새로고침하세요.');
    ImageStudio_Aip설정연결하기(aip);
    const host = {
      modern: aip.editor,
      external: globalThis.WML.status().loaded.includes('attention-image-prompt'),
      open: () => extensions.review.open(),
      generate: request => extensions.review.generate(request),
      renderSettings: null,
    };
    ImageStudio_상황프롬프트설치하기(api, host);
    host.connectModern();
    aip.editor.connect({ generate: request => extensions.review.generate(request) });
    const editor = {
      upgrades: host.upgrades,
      id: api.id, embeddedVersion: aip.editor.modVersion,
      render: (body, win) => ImageStudio_Aip편집기그리기(api, aip, host, body, win),
      axes: () => host.axes(), combinations: value => host.combinations(value),
      combinationSpace: value => host.combinationSpace(value),
      plan: (build, combination, archetypeId) => host.plan(build, combination, archetypeId),
      positionApplicable: (id, imageKey) => host.positionApplicable(id, imageKey),
      matchingContext: (imageKey, character) => host.matchingContext(imageKey, character),
      nativeAxisPrompt: (axis, id) => host.nativeAxisPrompt(axis,id),
      planningContext: () => host.planning ? {
        state: host.planning.state,
        character: host.planning.state?.characters?.[host.planning.state.primaryCharacterId],
      } : null,
    };
    extensions.registerEditor(editor);
    api.provide(editor);
    api.ui.settings((body, win) => editor.render(body, win));
    // 공통 편집기는 ImageStudio의 프롬프트 편집 버튼에서 엽니다.
  },
});
