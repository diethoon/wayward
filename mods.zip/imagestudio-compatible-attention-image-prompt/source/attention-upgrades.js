// attention 1.41.42의 의미 키·장비 동기화·표정 정합성을 분리 편집기에 선별 적용합니다.
// 원제작자 aaajjaaaadsfa. 게임 상태는 읽기만 하며 생성·검수·저장은 공통 본체에 맡깁니다.
const ImageStudio_이전상태키만들기 = keyWithState;
const ImageStudio_이전자세키만들기 = keyWithPosition;
const ImageStudio_이전프롬프트맥락읽기 = promptContext;
const ImageStudio_이전기본축키만들기 = ImageStudio_기본축키적용하기;
const ImageStudio_이전선택자세읽기 = selectedPositionChoice;
const ImageStudio_이전계획자세읽기 = positionChoiceForImageKey;
const ImageStudio_이전자세적용하기 = applyPositionPreset;
const ImageStudio_이전자세설정그리기 = renderPositionSettings;
const ImageStudio_이전전체JSON읽기 = ImageStudio_JSON전체읽기;
const ImageStudio_이전JSON불러오기 = importPromptSettings;
const ImageStudio_이전JSON갱신하기 = ImageStudio_JSON불러온뒤갱신하기;
const ImageStudio_이전매칭맥락읽기 = host.matchingContext;

// 구버전의 정확한 키만 별칭으로 연결합니다. 서로 다른 행동·장비를 기본 장면으로 합치지 않습니다.
const ImageStudio_이전키별칭 = new Map(Object.entries(api.settings.get().legacySituationKeys || {}));
function ImageStudio_이전키연결하기(before, after) {
  if (!before || before === after || ImageStudio_이전키별칭.get(before) === after) return;
  ImageStudio_이전키별칭.set(before, after);
  while (ImageStudio_이전키별칭.size > 5000) ImageStudio_이전키별칭.delete(ImageStudio_이전키별칭.keys().next().value);
  api.settings.set({ legacySituationKeys: Object.fromEntries(ImageStudio_이전키별칭) });
}
baseApi.use('imagestudio').extensions.registerKeyAdapter({ id: 'attention-semantic-keys', normalize(key) {
  return ImageStudio_이전키별칭.get(key) || key;
} });

function ImageStudio_현재인물읽기(character) {
  if (host.planning || !character) return character;
  const state = api.store.game();
  if (!state) return character;
  const id = character.id;
  if (!id) return character;
  return state?.characters?.[id] || character;
}
// 초상화가 기억한 오래된 character 객체를 장비 해제 후에도 다시 사용하지 않게 합니다.
for (const name of ['imageKey', 'imagePrompt']) baseApi.hook(name, { priority: 30000, before(args) {
  const current = ImageStudio_현재인물읽기(args[0]);
  if (current !== args[0]) return [current, ...args.slice(1)];
} });

// 1.41.42의 시각 상태 묶음 기준. 수갑·토이·부위 흔적·대화·콘텐츠 행동은 묶지 않습니다.
function ImageStudio_시각상태읽기(codes) {
  const active = new Set(codes), has = values => values.some(value => active.has(value));
  if (active.has('intoxication-blacked_out')) return 'unconscious';
  if (has(['energy-0', 'wellbeing-0', 'intoxication-sloppy'])) return 'exhausted';
  if ([...active].some(code => code.startsWith('intoxication-'))) return 'intoxicated';
  if (has(['expression-distressed','energy-1','mood-0','mood-1','wellbeing-1','wellbeing-2','trust-low','resentment-medium','resentment-high','drift-high','latitude-negative',
    'feeling-anger','feeling-contempt','feeling-disgust','feeling-sadness','feeling-shame','feeling-guilt','feeling-regret','feeling-humiliation',
    'drive-financial','drive-security','drive-social'])) return 'distressed';
  if ([...active].some(code => /^arousal-[1-4]$/.test(code)) || has(['allure-high','desire-high','feeling-tenderness','feeling-longing',
    'feeling-desire','feeling-arousal_buzz','drive-approval','drive-desire','drive-pride','drive-longing'])) return 'aroused';
  return 'other';
}
function ImageStudio_세부묶음사용하기() { return api.settings.get().groupSimilarDetailStates !== false; }
function ImageStudio_실제세부코드읽기(state, character, id) {
  const stats = id === state.primaryCharacterId ? effectiveHeroineStats(state) : character.stats || {};
  const codes = ['energy-' + band(stats.energy ?? 100), 'mood-' + band(stats.mood ?? 50), 'arousal-' + band(stats.arousal ?? 0)];
  if(id===state.primaryCharacterId){
    const relationship=relationshipPanelStatus(state);
    codes.push('wellbeing-'+band(100-(Number(wellbeingSignals(state)?.total)||0)));
    if(Number(relationship.trust)<30)codes.push('trust-low');
    if(Number(relationship.desire)>=60)codes.push('desire-high');
    if(Number(relationship.resentment)>=60)codes.push('resentment-high');
    else if(Number(relationship.resentment)>=35)codes.push('resentment-medium');
    if(Number(relationship.drift?.raw)>=35)codes.push('drift-high');
    if(Number(relationship.latitude?.raw)<0)codes.push('latitude-negative');
    const drive=Object.entries(heroineDriveCalc(state)||{}).sort((a,b)=>Number(b[1])-Number(a[1]))[0];
    if(drive&&Number(drive[1])>35)codes.push('drive-'+drive[0]);
  }
  if(Number(allureScore(character))>=60)codes.push('allure-high');
  const intoxication = intoxicationBand(character.intoxication?.level || 0);
  if (intoxication !== 'sober') codes.push('intoxication-' + intoxication);
  codes.push(...topFeelings(character,2).filter(feeling=>Number(feeling.intensity)>15).map(feeling=>'feeling-'+feeling.emotion));
  if(topFeelings(character,2).some(feeling=>Number(feeling.intensity)>=80&&/^(anger|contempt|disgust|sadness|shame|guilt|regret|humiliation|fear)$/.test(feeling.emotion)))codes.push('expression-distressed');
  return codes;
}
function ImageStudio_상황코드읽기(groups) {
  return [...new Set(groups.filter(group=>!['character','outfit','composition'].includes(group.id)).flatMap(group => {
    const codes = group.value?.codes || [];
    return group.id === 'detail' && ImageStudio_세부묶음사용하기()
      ? ['state-' + ImageStudio_시각상태읽기(codes)] : codes.map(code => group.id + '-' + code);
  }))].filter(code=>!['state-other','equipment-breast-jewelry-0','equipment-toy-none'].includes(code)
    &&!/^body-.+-(?:mouth|breasts|uterus|vulva|thighs)-0$/.test(code)).sort();
}
function ImageStudio_의미키만들기(key, groups) {
  const parts = String(key).split('__').filter(part => !/^(?:state|dialogue|character-reuse|character-regenerate|studio|aip)-/.test(part));
  const variant = parts.find(part => /^v-\d+$/.test(part));
  const base = parts.filter(part => !/^v-\d+$/.test(part));
  const codes = ImageStudio_상황코드읽기(groups);
  if (codes.length) base.push('aip-' + codes.map(code => code.replace(/[^a-zA-Z0-9_.:-]/g, '-')).join('_'));
  if (variant) base.push(variant);
  return base.join('__');
}
promptContext = function ImageStudio_프롬프트맥락갱신하기(state, character, characterId, key) {
  host.semanticCharacter = character;
  const context = ImageStudio_이전프롬프트맥락읽기(state, character, characterId, key);
  for(const field of ['positiveGroups','negativeGroups'])context[field]=context[field].map(group=>group.id?group:{...group,id:'detail'});
  if (!host.planning && state && character && !isResidueImageKey(key)) {
    const detail = context.positiveGroups.find(group=>group.id==='detail');
    const codes = ImageStudio_실제세부코드읽기(state,character,characterId);
    if (detail) detail.value = {...detail.value,codes:[...new Set([...detail.value.codes,...codes])]};
    else context.positiveGroups.push({id:'detail',label:'상세 상태',value:{codes,tags:[]}});
    const fake=Object.fromEntries(BAD_GUEST_FIELDS.map(field=>[field.key,'semantic-state']));
    const badguest=ImageStudio_나쁜손님프롬프트읽기(state,character,characterId,fake);
    if(badguest)context.positiveGroups.push({id:'badguest',label:'나쁜 손님 상태',value:{codes:badguest.codes,tags:[]}});
    const fluid=character.situationStats?.fluidState;
    if(fluid)for(const {part} of FLUID_PARTS){
      if(!partIsExposed('fluid.'+part+'.1',outfitIdFor(character,key),key,character))continue;
      const tier=part==='vulva'?vulvaTier(character,heroineDriveCalc(state)):fluidTier(part,fluid[part]);
      if(tier>0)context.positiveGroups.push({id:'body-'+part,label:'부위별 상태',value:{codes:[part+'-'+tier],tags:[]}});
    }
  }
  const jewelry = character?.situationStats?.jewelryState;
  host.matchingContextSnapshot={state,character,key,groups:[...context.positiveGroups,...context.negativeGroups]};
  if (!jewelry || isResidueImageKey(key)) return context;
  const stage = Number(jewelry.breasts?.stage) || 0, vibe = jewelry.vibe;
  const activeToy = vibe && !vibe.suspension && ['egg','penis'].includes(vibe.type) ? vibe.type : '';
  const settings = api.settings.get().equipmentPrompts || {};
  const codes = ['breast-jewelry-' + stage, 'toy-' + (activeToy || 'none')];
  if(Number(jewelry.vulva?.stage)>0)codes.push('vulva-jewelry-'+Number(jewelry.vulva.stage));
  const positive = activeToy ? settings[activeToy]?.positivePrompt ?? (activeToy === 'egg'
    ? 'egg vibrator, vibrator cord' : 'inserted dildo vibrator') : '';
  const negative = [stage === 3 ? '' : 'choker, heart-shaped choker', activeToy ? '' : 'vibrator, dildo',
    activeToy ? settings[activeToy]?.negativePrompt || '' : ''].filter(Boolean).join(', ');
  context.positiveGroups.push({ id: 'equipment', label: '현재 장비', value: { codes, tags: positive ? [positive] : [] } });
  context.negativeGroups.push({ id: 'equipment', label: '현재 장비', value: { codes, tags: negative ? [negative] : [] } });
  host.matchingContextSnapshot={state,character,key,groups:[...context.positiveGroups,...context.negativeGroups]};
  return context;
};
keyWithState = function ImageStudio_상태키만들기(key, signature, ...args) {
  const state = api.store.game();
  const character = host.semanticCharacter || host.planning?.state?.characters?.[host.planning.state.primaryCharacterId] || state?.characters?.[state.primaryCharacterId];
  if (!character || isResidueImageKey(key)) return key;
  const id = characterIdOf(state, character) || character.id || state.primaryCharacterId;
  const legacyAxis=ImageStudio_이전기본축키만들기(key);
  const legacyContext=ImageStudio_이전프롬프트맥락읽기(state,character,id,legacyAxis);
  const context = promptContext(state, character, id, key);
  const next = ImageStudio_의미키만들기(key, [...context.positiveGroups, ...context.negativeGroups]);
  const jewelry=character.situationStats?.jewelryState;
  const equipped=Number(jewelry?.breasts?.stage)>0||Number(jewelry?.vulva?.stage)>0||(jewelry?.vibe?.type&&!jewelry.vibe.suspension);
  if(!equipped&&(legacyContext.positiveGroups.length||legacyContext.negativeGroups.length)){
    const legacy=ImageStudio_이전상태키만들기(legacyAxis,combinedStateSignature(legacyContext.positiveGroups,legacyContext.negativeGroups),
      legacyContext.dialogue,legacyContext.characterPolicy,legacyContext.situational);
    ImageStudio_이전키연결하기(legacy,next);
  }
  return next;
};
// 장소·장면 문구 수정은 생성 해시로 관리하며 studio 문구 해시는 상황 키에서 제외합니다.
ImageStudio_기본축키적용하기 = key => String(key).split('__').filter(part => !part.startsWith('studio-')).join('__');

function ImageStudio_장비표정보정하기(result, character) {
  if (host.modern && !host.planning) return result;
  if (!result?.parts || !character || isResidueImageKey(result.key)) return result;
  const jewelry = character.situationStats?.jewelryState;
  const severe = topFeelings(character, 2).some(feeling => Number(feeling.intensity) >= 80
    && /^(anger|contempt|disgust|sadness|shame|guilt|regret|humiliation|fear)$/.test(feeling.emotion));
  const context = promptContext(api.store.game(), character, character.id, result.key);
  const detail = context.positiveGroups.filter(group => group.id === 'detail').flatMap(group => group.value.codes);
  const distressed = severe || ['exhausted','unconscious','distressed'].includes(ImageStudio_시각상태읽기(detail));
  const cheerful = new Set(['smile','gentle smile','bright smile','playful smile','content','cheerful','energetic','pleasure']);
  const parts = result.parts.map(part => ({ ...part, tags: promptTokens(part.tags).filter(tag => {
    const identity = promptTagIdentity(tag).spaced;
    if (distressed && ['장면','Scene','작업','Task','기분','Mood'].includes(part.label) && cheerful.has(identity)) return false;
    if (jewelry && Number(jewelry.breasts?.stage) !== 3 && /\bchoker\b/.test(identity)) return false;
    if (jewelry && [0,3].includes(Number(jewelry.breasts?.stage)||0) && /\bnipple (piercings?|rings?|jewelry)\b/.test(identity)) return false;
    if (jewelry && (!jewelry.vibe || jewelry.vibe.suspension) && /\b(vibrator|dildo)\b/.test(identity)) return false;
    return true;
  }).join(', ') }));
  const retained = new Set(parts.flatMap(part=>promptTokens(part.tags)).map(tag=>promptTagIdentity(tag).spaced));
  const removed = result.parts.flatMap(part=>promptTokens(part.tags)).filter(tag=>!retained.has(promptTagIdentity(tag).spaced));
  const prompt = withoutPromptTags(result.prompt,removed.join(', '));
  const stage=Number(jewelry?.breasts?.stage)||0, activeToy=jewelry?.vibe&&!jewelry.vibe.suspension&&['egg','penis'].includes(jewelry.vibe.type);
  const negativePrompt=joinPrompt(promptTokens(result.negativePrompt).filter(tag=>{
    const identity=promptTagIdentity(tag).spaced;
    if(stage===3&&['choker','heart-shaped choker'].includes(identity))return false;
    if([1,2].includes(stage)&&['piercing','nipple piercings','nipple rings'].includes(identity))return false;
    if(activeToy&&['vibrator','dildo'].includes(identity))return false;
    return true;
  }).join(', '));
  return { ...result, prompt, negativePrompt, parts, genParams: promptGenParams(prompt) };
}
baseApi.use('imagestudio').extensions.registerPromptProvider({ id: 'attention-equipment-expression', priority: 1000,
  compose(result, context) { return ImageStudio_장비표정보정하기(result, ImageStudio_현재인물읽기(context.character)); }
});
// H_Status 등이 공통 조립 뒤에 붙이는 장비 태그도 최종 출력에서 같은 기준으로 정리합니다.
baseApi.hook('imagePrompt',{priority:-3000000,after(result,[character]){
  return ImageStudio_장비표정보정하기(result,ImageStudio_현재인물읽기(character));
}});
// 구형 H_Status는 WML 디스패처 바깥에서 상태 태그를 덧붙입니다.
// 그 기존 함수를 그대로 이어 호출한 뒤 최종 결과만 정리하여 게임 로직과 훅을 보존합니다.
const ImageStudio_기존초상화프롬프트=baseApi.fn('imagePrompt');
baseApi.engine[baseApi.sym('imagePrompt')]=function ImageStudio_최종초상화프롬프트(...args){
  args[0]=ImageStudio_현재인물읽기(args[0]);
  return ImageStudio_장비표정보정하기(ImageStudio_기존초상화프롬프트(...args),args[0]);
};
function ImageStudio_매칭상태묶기(context) {
  if (!context || !ImageStudio_세부묶음사용하기()) return context;
  if(!Array.isArray(context.detail)&&!Array.isArray(context.emotions))return context;
  const detailCodes = context.detail || [];
  const generic = detailCodes.filter(code => /^(expression|energy|mood|arousal|wellbeing|intoxication|trust|desire|resentment|drift|latitude|feeling|drive|allure)-/.test(code));
  if(!generic.length&&detailCodes.some(code=>code.startsWith('visual-'))&&!(context.emotions||[]).length)return context;
  const bucket=ImageStudio_시각상태읽기([...generic,...(context.emotions||[]).map(value=>'feeling-'+value)]);
  return { ...context, rawEmotions:context.emotions, emotions:[],detail: [...detailCodes.filter(code => !generic.includes(code)&&!code.startsWith('visual-')), 'visual-' + bucket].sort() };
}
host.matchingContext = function ImageStudio_의미매칭맥락읽기(key, character) {
  return ImageStudio_매칭상태묶기(ImageStudio_이전매칭맥락읽기(key,character));
};

// 사람별 자세는 기존 프리셋 문구를 공통 원본으로 참조합니다. 문구 사본을 별도로 저장하지 않습니다.
const ImageStudio_기본사람자세 = ['none','standing','sitting','kneeling','lying-back','all-fours'];
const ImageStudio_사람위치목록 = { front: '앞', back: '뒤', left: '왼쪽', right: '오른쪽', above: '위', below: '아래' };
const ImageStudio_사람행동목록 = { watch: '관전', touch: '손으로 자극', kiss: '키스', oral: '구강', sex: '삽입' };
const ImageStudio_사람부위목록 = { body: '몸', mouth: '입', breasts: '가슴', vulva: '보지', anus: '항문', hands: '손' };
let ImageStudio_기본자세편집중 = false;
function ImageStudio_사람설정읽기() {
  const saved = api.settings.get().personDetails || {};
  const person = value => ({ pose: ImageStudio_기본사람자세.includes(value?.pose) ? value.pose : 'standing',
    location: Object.hasOwn(ImageStudio_사람위치목록, value?.location) ? value.location : 'front',
    action: Object.hasOwn(ImageStudio_사람행동목록, value?.action) ? value.action : 'watch',
    target: Object.hasOwn(ImageStudio_사람부위목록, value?.target) ? value.target : 'body' });
  return { enabled: saved.enabled === true, female: saved.female!=='none'&&ImageStudio_기본사람자세.includes(saved.female) ? saved.female : 'standing',
    men: Array.from({length: Math.max(1,Math.min(6,Number(saved.men?.length)||1))},(_,index)=>person(saved.men?.[index])) };
}
function ImageStudio_사람자세프롬프트읽기(id, male = false) {
  const prompt = positionPresetById(id)?.prompt || '';
  return male ? prompt.replace(/\b(woman|girl|female)\b/gi, 'man') : prompt;
}
function ImageStudio_사람프롬프트읽기(details) {
  const negative = [positionPresetById(details.female)?.negativePrompt || ''];
  const tags = ['woman: ' + ImageStudio_사람자세프롬프트읽기(details.female)];
  for (const [index, man] of details.men.entries()) {
    tags.push(`man ${index+1}: ${ImageStudio_사람자세프롬프트읽기(man.pose,true)}, ${man.location} of woman, ${man.action}, target ${man.target}`);
    negative.push(positionPresetById(man.pose)?.negativePrompt || '');
  }
  return { prompt: joinPrompt(tags.join(', ')), negativePrompt: joinPrompt(negative.join(', ')) };
}
selectedPositionChoice = function ImageStudio_선택사람자세읽기() {
  const choice = ImageStudio_이전선택자세읽기(), details = ImageStudio_사람설정읽기();
  if (ImageStudio_기본자세편집중 || !details.enabled || !latestScenePrompt) return choice;
  const selected = positionSelection.presetId;
  if (selected !== 'none' && ImageStudio_기본사람자세.includes(selected)) details.female = selected;
  const prompts = ImageStudio_사람프롬프트읽기(details);
  return { presetId: details.female, preset: { ...positionPresetById(details.female), id: details.female, name: '사람별 세부 조정', ...prompts },
    groupSlots: selectedPositionGroupSlots(), personDetails: details };
};
positionChoiceForImageKey=function ImageStudio_계획사람자세읽기(key){
  const choice=ImageStudio_이전계획자세읽기(key),details=ImageStudio_사람설정읽기();
  const explicit=host.planning?.combination?.promptPosition;
  if(!host.planning||!details.enabled||!explicit||explicit==='none'||!ImageStudio_기본사람자세.includes(explicit))return choice;
  details.female=explicit;
  return {presetId:explicit,preset:{...positionPresetById(explicit),...ImageStudio_사람프롬프트읽기(details)},personDetails:details,groupSlots:choice?.groupSlots||''};
};
keyWithPosition = function ImageStudio_자세의미키만들기(key, choice) {
  if (!choice?.preset || choice.preset.id === 'none') return stripPositionKey(key);
  const clean = stripPositionKey(key), variant = clean.match(/__v-\d+$/)?.[0] || '';
  const root = variant ? clean.slice(0,-variant.length) : clean;
  const details = choice.personDetails;
  const signature = details ? '-people-' + shortHash(JSON.stringify({female:details.female,men:details.men})) : '';
  const slots = choice.groupSlots ? '-slots-' + choice.groupSlots : '';
  const next = root + '__position-' + choice.preset.id + slots + signature + variant;
  ImageStudio_이전키연결하기(ImageStudio_이전자세키만들기(key,choice),next);
  return next;
};
applyPositionPreset = function ImageStudio_사람자세적용하기(result, choice) {
  const applied=ImageStudio_이전자세적용하기(result,choice);
  if (!choice?.personDetails || !applied?.parts) return applied;
  const removed=applied.parts.filter(part=>['성별','Gender','그룹','Group'].includes(part.label));
  const kept=applied.parts.filter(part=>!removed.includes(part));
  const count=choice.personDetails.men.length;
  const gender='1girl, '+(count===1?'1boy':count+'boys');
  const prompt=joinPrompt(withoutPromptTags(applied.prompt,removed.map(part=>part.tags).join(', '))+', '+gender);
  return {...applied,prompt,parts:[...kept,{label:'성별',tags:gender}],genParams:promptGenParams(prompt)};
};
function ImageStudio_사람설정그리기(h, win) {
  const details = ImageStudio_사람설정읽기();
  if (details.enabled && positionSelection.presetId !== 'none' && ImageStudio_기본사람자세.includes(positionSelection.presetId)) details.female = positionSelection.presetId;
  const save = () => { api.settings.set({personDetails:details});win.refresh(); };
  const select = (label, options, value, update, marker) => h('label',{style:'display:grid;gap:4px;min-width:0'},label,
    h('select',{'data-person-field':marker,style:'max-width:100%;background:#292524;color:#eee;padding:6px',onchange:event=>{update(event.currentTarget.value);save();}},
      ...Object.entries(options).map(([id,name])=>h('option',{value:id,selected:id===value},name))));
  const poses = Object.fromEntries(ImageStudio_기본사람자세.filter(id=>POSITION_PRESETS[id]).map(id=>[id,POSITION_PRESETS[id].name]));
  return h('section',{'data-person-details':'',style:'border:1px solid #57534e;padding:10px;margin:10px 0;border-radius:7px'},
    h('h3',{},'사람별 자세·위치·행동'),
    h('label',{},h('input',{type:'checkbox',checked:details.enabled,'data-person-enabled':'',onchange:event=>{details.enabled=event.currentTarget.checked;save();}}),' 수동 생성에 사람별 설정 사용'),
    h('p',{class:'wml-muted'},'아래 기본 자세 프롬프트 편집과 같은 Positive/Negative를 사용합니다. 수정하면 양쪽 미리보기에 반영됩니다.'),
    select('여성 자세',Object.fromEntries(Object.entries(poses).filter(([id])=>id!=='none')),details.female,value=>{details.female=value;positionSelection={...positionSelection,situationId:latestScenePrompt?.situationId||'',presetId:value};},'female'),
    select('남성 수',Object.fromEntries([1,2,3,4,5,6].map(count=>[count,count+'명'])),String(details.men.length),value=>{
      const previous=details.men;details.men=Array.from({length:Number(value)},(_,index)=>previous[index]||{pose:'standing',location:'front',action:'watch',target:'body'});
    },'count'),
    ...details.men.map((man,index)=>h('fieldset',{style:'display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin:10px 0'},h('legend',{},'남성 '+(index+1)),
      select('자세',poses,man.pose,value=>{man.pose=value;},'man-'+index+'-pose'),
      select('여성 기준 위치',ImageStudio_사람위치목록,man.location,value=>{man.location=value;},'man-'+index+'-location'),
      select('행동',ImageStudio_사람행동목록,man.action,value=>{man.action=value;},'man-'+index+'-action'),
      select('대상 부위',ImageStudio_사람부위목록,man.target,value=>{man.target=value;},'man-'+index+'-target'))),
    h('pre',{'data-person-preview':'',style:'white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px'},
      'Positive: '+ImageStudio_사람프롬프트읽기(details).prompt+'\nNegative: '+ImageStudio_사람프롬프트읽기(details).negativePrompt));
}
renderPositionSettings = function ImageStudio_사람별설정그리기(h,win) {
  // 기존 입력칸은 합성된 사람별 문구가 아닌 기본 자세 원문만 편집합니다.
  ImageStudio_기본자세편집중=true;
  let original;
  try { original=ImageStudio_이전자세설정그리기(h,win); } finally { ImageStudio_기본자세편집중=false; }
  return [ImageStudio_사람설정그리기(h,win),...original];
};

// 부위별 img2img는 기존 공통 검수 경로를 이용합니다. 참조 누락을 일반 생성으로 조용히 바꾸지 않습니다.
function ImageStudio_부위생성설정읽기() { return api.settings.get().hStatusGenerationModes || {}; }
function ImageStudio_부위키읽기(key) {
  if (!isResidueImageKey(key)) return '';
  if (key.startsWith('situation_vulva__')) return 'vulva';
  return FLUID_PARTS.find(({part})=>new RegExp('(?:__|_)'+part+'(?:__|_|$)').test(key))?.part || '';
}
host.prepareGeneration = async function ImageStudio_참조생성요청만들기(request) {
  const part = ImageStudio_부위키읽기(request.imageKey || request.key || '');
  const options = ImageStudio_부위생성설정읽기()[part];
  if (!part || options?.mode !== 'img2img') return request;
  let referenceKey=options.referenceKey?.trim()||request.referenceKey;
  if (!referenceKey) {
    const key=residueBaseImageKey(request.imageKey||request.key);
    const pieces=key.split('__');
    if (!['elena','mara','pippa'].includes(pieces[1])) {
      const context=currentWifePromptContext();
      const source=String(context.archetype?.basedOn||context.character?.generatedArchetype?.basedOn||context.character?.archetypeId||'');
      pieces[1]=['elena','mara','pippa'].includes(request.referenceSource)?request.referenceSource:source.match(/(?:^|_)(elena|mara|pippa)(?:_|$)/)?.[1]||'pippa';
    }
    referenceKey=pieces.join('__');
  }
  const reference=await baseApi.fn('imageLookup')(referenceKey,{nearest:false});
  if (!reference || reference.talentName!==referenceKey) throw Error('정확한 H_Status 기준 이미지를 찾지 못했습니다: '+referenceKey);
  return { ...request, referenceKey, referencePath:reference.imagePath,denoise: options.denoise ?? (part==='breasts'?0.4:0.28) };
};
function ImageStudio_업데이트설정그리기(body,win) {
  const panel=api.ui.h('details',{'data-attention-upgrades':'',style:'margin:10px 0;padding:10px;border:1px solid #57534e'},
    api.ui.h('summary',{},'상태 묶기 · 장비 프롬프트 · H_Status 부위별 img2img'));
  panel.append(api.ui.h('label',{},api.ui.h('input',{type:'checkbox',checked:ImageStudio_세부묶음사용하기(),'data-state-grouping':'',onchange:event=>{
    api.settings.set({groupSimilarDetailStates:event.currentTarget.checked});win.refresh();
  }}),' 비슷한 상세 상태를 대표 이미지로 묶기'));
  for(const type of ['egg','penis'])for(const field of ['positivePrompt','negativePrompt']) panel.append(api.ui.h('label',{style:'display:grid;margin:8px 0'},
    (type==='egg'?'에그 토이':'자지형 토이')+' '+field,
    api.ui.h('textarea',{'data-equipment-prompt':type+':'+field,value:api.settings.get().equipmentPrompts?.[type]?.[field] ?? (field==='positivePrompt'?(type==='egg'?'egg vibrator, vibrator cord':'inserted dildo vibrator'):''),
      onchange:event=>{const settings=api.settings.get().equipmentPrompts||{};api.settings.set({equipmentPrompts:{...settings,[type]:{...settings[type],[field]:event.currentTarget.value}}});}})));
  const modes=ImageStudio_부위생성설정읽기();
  for(const {part,label} of FLUID_PARTS){
    const options={mode:'text2img',referenceKey:'',denoise:part==='breasts'?0.4:0.28,...modes[part]};
    const save=()=>api.settings.set({hStatusGenerationModes:{...ImageStudio_부위생성설정읽기(),[part]:options}});
    panel.append(api.ui.h('fieldset',{style:'display:grid;gap:5px;margin:10px 0'},api.ui.h('legend',{},label),
      api.ui.h('select',{'data-hstatus-generation-mode':part,onchange:event=>{options.mode=event.currentTarget.value;save();}},
        ...['text2img','img2img'].map(mode=>api.ui.h('option',{value:mode,selected:options.mode===mode},mode))),
      api.ui.h('input',{'data-hstatus-reference':part,type:'text',value:options.referenceKey,placeholder:'비우면 원작의 같은 부위·상태 이미지 자동 참조',onchange:event=>{options.referenceKey=event.currentTarget.value;save();}}),
      api.ui.h('input',{'data-hstatus-denoise':part,type:'number',min:0.01,max:1,step:0.01,value:options.denoise,onchange:event=>{
        const value=Number(event.currentTarget.value);if(!Number.isFinite(value)||value<=0||value>1)throw Error('노이즈 강도는 0 초과 1 이하입니다.');options.denoise=value;save();
      }})));
  }
  body.prepend(panel);
}
const ImageStudio_업데이트이전편집그리기=host.renderSettings;
api.ui.settings((body,win)=>{ImageStudio_업데이트이전편집그리기(body,win);if (!host.modern) ImageStudio_업데이트설정그리기(body,win);});

// 새 설정도 기존 전체/탭 JSON과 함께 보존합니다. 구버전 기본 문구를 자동 치환하지 않습니다.
const ImageStudio_업데이트설정키=['groupSimilarDetailStates','equipmentPrompts','personDetails','hStatusGenerationModes','legacySituationKeys'];
const ImageStudio_이전탭JSON섹션읽기=ImageStudio_JSON탭섹션읽기;
ImageStudio_JSON탭섹션읽기=function ImageStudio_업데이트탭JSON섹션읽기(tab){
  const sections=ImageStudio_이전탭JSON섹션읽기(tab);
  return tab.id==='positions'?[...sections,'personDetails']:tab.id==='h-status'?[...sections,'equipmentPrompts','hStatusGenerationModes']:sections;
};
ImageStudio_JSON전체읽기=function ImageStudio_업데이트JSON읽기(){
  const settings=api.settings.get();return {...ImageStudio_이전전체JSON읽기(),version:18,...Object.fromEntries(ImageStudio_업데이트설정키.filter(key=>settings[key]!==undefined).map(key=>[key,settings[key]]))};
};
ImageStudio_JSON불러온뒤갱신하기=function ImageStudio_업데이트JSON갱신하기(...args){
  ImageStudio_이전키별칭.clear();
  for(const [key,value] of Object.entries(api.settings.get().legacySituationKeys||{}))ImageStudio_이전키별칭.set(key,value);
  return ImageStudio_이전JSON갱신하기(...args);
};
importPromptSettings=function ImageStudio_업데이트JSON불러오기(text){
  const parsed=JSON.parse(text);
  if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))throw Error('JSON 설정 객체가 필요합니다.');
  if(parsed.groupSimilarDetailStates!==undefined&&typeof parsed.groupSimilarDetailStates!=='boolean')throw Error('상태 묶기 설정은 true/false여야 합니다.');
  for(const section of ['equipmentPrompts','personDetails','hStatusGenerationModes','legacySituationKeys']){
    if(parsed[section]!==undefined&&(!parsed[section]||typeof parsed[section]!=='object'||Array.isArray(parsed[section])))throw Error('설정 객체가 올바르지 않습니다: '+section);
  }
  for(const [type,settings] of Object.entries(parsed.equipmentPrompts||{})){
    if(!['egg','penis'].includes(type)||!settings||typeof settings!=='object'||Array.isArray(settings)
      ||Object.entries(settings).some(([field,value])=>!['positivePrompt','negativePrompt'].includes(field)||typeof value!=='string'))throw Error('토이 프롬프트 설정이 올바르지 않습니다.');
  }
  if(Object.values(parsed.legacySituationKeys||{}).some(value=>typeof value!=='string'))throw Error('이전 이미지 키 별칭이 올바르지 않습니다.');
  if(parsed.personDetails){
    const value=parsed.personDetails;
    if(typeof value.enabled!=='boolean'||!ImageStudio_기본사람자세.includes(value.female)||!Array.isArray(value.men)||value.men.length<1||value.men.length>6
      ||value.men.some(man=>!ImageStudio_기본사람자세.includes(man?.pose)||!Object.hasOwn(ImageStudio_사람위치목록,man?.location)
        ||!Object.hasOwn(ImageStudio_사람행동목록,man?.action)||!Object.hasOwn(ImageStudio_사람부위목록,man?.target)))throw Error('사람별 자세 설정이 올바르지 않습니다.');
  }
  for(const [part,options] of Object.entries(parsed.hStatusGenerationModes||{})){
    if(!FLUID_PARTS.some(value=>value.part===part)||!['text2img','img2img'].includes(options?.mode)
      ||(options.referenceKey!==undefined&&typeof options.referenceKey!=='string')
      ||(options.denoise!==undefined&&(!Number.isFinite(options.denoise)||options.denoise<=0||options.denoise>1)))throw Error('부위별 생성 설정이 올바르지 않습니다: '+part);
  }
  const hasLegacy=Object.keys(parsed).some(key=>!ImageStudio_업데이트설정키.includes(key)&&!['format','version','scope','tabId'].includes(key));
  const base=hasLegacy?ImageStudio_이전JSON불러오기(text):{};
  return {...base,...Object.fromEntries(ImageStudio_업데이트설정키.filter(key=>parsed[key]!==undefined).map(key=>[key,parsed[key]]))};
};
host.upgrades={semanticKey:ImageStudio_의미키만들기,bucket:ImageStudio_시각상태읽기,correct:ImageStudio_장비표정보정하기,normalizeMatchingContext:ImageStudio_매칭상태묶기,
  personPrompts:ImageStudio_사람프롬프트읽기,prepare:host.prepareGeneration,exportSettings:ImageStudio_JSON전체읽기,importSettings:importPromptSettings};
