// 별도 attention-image-prompt가 적용한 체위 고정과 대응 필요 프롬프트를 ImageStudio의 게임 프롬프트에서 제거합니다.
// 저장된 설정과 다른 모드 파일은 변경하지 않습니다.
function ImageStudio_체위호환연결하기(api) {
  const snapshots = new WeakMap();
  const originalLabels = new Set(['장면', '자세', '작업', 'Scene', 'Pose', 'Action', '그룹', 'Group']);
  const protectedNegative = new Set(['cleavage', 'breasts out', 'nipples', 'ass', 'exposed ass', 'bottomless',
    'no panties', 'revealing clothing', 'bare shoulders', 'low neckline', 'short skirt', 'bare legs']);
  const ImageStudio_체위태그읽기 = value => String(value || '').split(',').map(tag => tag.trim()).filter(Boolean);
  const ImageStudio_체위태그비교하기 = tag => String(tag).toLowerCase().replaceAll('_', ' ').replace(/\s+/g, ' ').trim();
  const ImageStudio_노출방지Negative복원하기 = (result, snapshot) => {
    if (!snapshot) return result;
    const current = ImageStudio_체위태그읽기(result?.negativePrompt);
    const identities = new Set(current.map(ImageStudio_체위태그비교하기));
    for (const tag of ImageStudio_체위태그읽기(snapshot.negativePrompt)) {
      const identity = ImageStudio_체위태그비교하기(tag);
      if (protectedNegative.has(identity) && !identities.has(identity)) { current.push(tag); identities.add(identity); }
    }
    const negativePrompt = current.join(', ');
    return negativePrompt === result?.negativePrompt ? result : { ...result, negativePrompt };
  };
  const ImageStudio_대응필요프롬프트지우기 = result => {
    const removed = result.parts.filter(part => ['대응 필요 상황', 'Attention needed'].includes(String(part?.label || '')));
    if (!removed.length) return result;
    const parts = result.parts.filter(part => !removed.includes(part));
    const retained = new Set(parts.flatMap(part => ImageStudio_체위태그읽기(part.tags)).map(ImageStudio_체위태그비교하기));
    const blocked = new Set(removed.flatMap(part => ImageStudio_체위태그읽기(part.tags))
      .map(ImageStudio_체위태그비교하기).filter(tag => !retained.has(tag)));
    const prompt = ImageStudio_체위태그읽기(result.prompt)
      .filter(tag => !blocked.has(ImageStudio_체위태그비교하기(tag))).join(', ');
    return { ...result, prompt, parts, genParams: api.fn('promptGenParams')?.(prompt) || result.genParams };
  };
  api.hook('imagePrompt', {
    priority: 20000,
    after(result, [character]) {
      if (character && typeof character === 'object' && Array.isArray(result?.parts)) {
        snapshots.set(character, { ...result, parts: result.parts.map(part => ({ ...part })) });
      }
    }
  });
  return function ImageStudio_게임체위복원하기(result, character) {
    if (!Array.isArray(result?.parts)) return result;
    const snapshot = snapshots.get(character);
    result = ImageStudio_대응필요프롬프트지우기(result);
    result = ImageStudio_노출방지Negative복원하기(result, snapshot);
    const forced = result.parts.filter(part => String(part.label || '').startsWith('체위 프리셋 ·')
      || String(part.label || '').startsWith('추가 인원 배치 ·') || part.label === '성별·인원 유지');
    if (!forced.length) return result;
    if (!snapshot) throw new Error('ImageStudio could not restore the original scene prompt.');
    const kept = result.parts.filter(part => !forced.includes(part));
    const keptLabels = new Set(kept.map(part => part.label));
    const restored = snapshot.parts.filter(part => originalLabels.has(part.label) && !keptLabels.has(part.label));
    const parts = [...kept, ...restored];
    const retained = new Set(parts.flatMap(part => ImageStudio_체위태그읽기(part.tags)).map(ImageStudio_체위태그비교하기));
    const blocked = new Set(forced.flatMap(part => ImageStudio_체위태그읽기(part.tags))
      .map(ImageStudio_체위태그비교하기).filter(tag => !retained.has(tag)));
    const tags = ImageStudio_체위태그읽기(result.prompt).filter(tag => !blocked.has(ImageStudio_체위태그비교하기(tag)));
    for (const tag of restored.flatMap(part => ImageStudio_체위태그읽기(part.tags))) {
      if (!tags.some(existing => ImageStudio_체위태그비교하기(existing) === ImageStudio_체위태그비교하기(tag))) tags.push(tag);
    }
    const prompt = tags.join(', ');
    return { ...result, key: String(result.key || '').split('__').filter(part => !part.startsWith('position-')).join('__'),
      prompt, parts, genParams: api.fn('promptGenParams')?.(prompt) || result.genParams };
  };
}
