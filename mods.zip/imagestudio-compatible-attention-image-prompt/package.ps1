﻿# Version is numeric; game target is 2026-11-01; ZIP contains the stable mod ID folder.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$releaseRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$releaseSource = Get-Content -LiteralPath (Join-Path $releaseRoot 'mod.js') -Raw -Encoding UTF8
$releaseDefinition = $releaseSource.Substring($releaseSource.IndexOf('WML.define'))
$releaseId = [regex]::Match($releaseDefinition, 'id\s*:\s*[\x27\x22]([^\x27\x22]+)').Groups[1].Value
$releaseVersion = [regex]::Match($releaseDefinition, 'version\s*:\s*[\x27\x22]([^\x27\x22]+)').Groups[1].Value
if ($releaseId -ne (Split-Path $releaseRoot -Leaf) -or $releaseVersion -notmatch '^\d+\.\d+\.\d+$') { throw 'ID/folder or numeric version mismatch' }
$releaseZip = Join-Path $releaseRoot ($releaseId + '-' + $releaseVersion + '-20261101.zip')
$releaseFiles = @('README.md', 'mod.js', 'package.ps1', 'source/aip-modern.js', 'source/attention-upgrades.js', 'source/attention/README-original.md', 'source/attention/original.js', 'source/badguest-state.js', 'source/build.mjs', 'source/context-state-prompts.js', 'source/editor-api.js', 'source/imagestudio-compatible-attention-image-prompt.js', 'source/matching-context.js', 'source/mod.wml.js', 'source/planner-prompts.js', 'source/pre7-symbols.json', 'source/prompt-tab-settings.js', 'source/status-empty-defaults.js', 'tests/aip177-integration.mjs', 'tests/badguest-141.mjs', 'tests/outfit-prompts.mjs', 'tests/sleep-dialogue-cache.mjs')
if (Test-Path -LiteralPath $releaseZip) { throw 'Existing release is preserved. Bump mod version before packaging.' }
foreach ($releaseName in $releaseFiles) {
  if (!(Test-Path -LiteralPath (Join-Path $releaseRoot $releaseName) -PathType Leaf)) { throw ('Release file missing: ' + $releaseName) }
}
$releaseArchive = [IO.Compression.ZipFile]::Open($releaseZip, [IO.Compression.ZipArchiveMode]::Create, [Text.Encoding]::UTF8)
try { foreach ($releaseName in $releaseFiles) {
  $releasePath = [IO.Path]::GetFullPath((Join-Path $releaseRoot $releaseName))
  if (!$releasePath.StartsWith($releaseRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Path outside mod folder' }
  [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($releaseArchive, $releasePath, ($releaseId + '/' + $releaseName), [IO.Compression.CompressionLevel]::Optimal) | Out-Null
}} finally { $releaseArchive.Dispose() }
$releaseArchive = [IO.Compression.ZipFile]::OpenRead($releaseZip)
try {
 if ($releaseArchive.Entries.Count -ne $releaseFiles.Count) { throw 'ZIP count mismatch' }
 foreach ($releaseName in $releaseFiles) {
  $releaseEntry = $releaseArchive.GetEntry($releaseId + '/' + $releaseName)
  if (!$releaseEntry) { throw ('ZIP missing: ' + $releaseName) }
  $releaseInput = $releaseEntry.Open(); $releaseHash = [Security.Cryptography.SHA256]::Create()
  try { $releaseActual = ([BitConverter]::ToString($releaseHash.ComputeHash($releaseInput))).Replace('-', '') } finally { $releaseInput.Dispose(); $releaseHash.Dispose() }
  if ($releaseActual -ne (Get-FileHash -LiteralPath (Join-Path $releaseRoot $releaseName) -Algorithm SHA256).Hash) { throw ('ZIP differs: ' + $releaseName) }
 }
} finally { $releaseArchive.Dispose() }
Write-Output ('VERIFIED ' + $releaseZip)
