// 실행: node wml/mods/imagestudio-compatible-attention-image-prompt/tests/sleep-dialogue-cache.mjs [--mobile]
// 이전 배포 ZIP과 현재 생성본을 같은 상태/난수로 비교합니다. 이미지 서버·GPU·사용자 저장소는 사용하지 않습니다.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {registerHooks} from 'node:module';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const root=fileURLToPath(new URL('../../../../',import.meta.url)),mod=fileURLToPath(new URL('../',import.meta.url));
const definitions=[['attention-image-prompt_hl','attention-image-prompt(Edit_HL)-1.29.0.zip'],['imagestudio-compatible-attention-image-prompt','imagestudio-compatible-attention-image-prompt-1.1.4.zip']];
const old=definitions.map(([id,name])=>{
  const archive=path.join(root,'wml/mods',id,name);
  const command="$ProgressPreference='SilentlyContinue';Add-Type -AssemblyName System.IO.Compression.FileSystem;$z=[IO.Compression.ZipFile]::OpenRead('"+archive.replaceAll("'","''")+"');try{$s=[IO.StreamReader]::new($z.GetEntry('mod.js').Open());try{[Console]::Out.Write($s.ReadToEnd())}finally{$s.Dispose()}}finally{$z.Dispose()}";
  return {path:'/wml/mods/'+id+'/mod.js',body:execFileSync('powershell.exe',['-NoProfile','-EncodedCommand',Buffer.from(command,'utf16le').toString('base64')],{encoding:'utf8',maxBuffer:8e6})};
});
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
for(const [id]of definitions){
  const source=fs.readFileSync(path.join(root,'wml/mods',id,'mod.js'),'utf8');
  const start=source.indexOf('    const dialogueTextCache = new Map();'),end=source.indexOf('    function dialogueLogs(',start);
  assert.ok(start>0&&end>start);
  const normal=vm.runInNewContext(source.slice(start,end)+'\ndialogueText;');
  const values=[undefined,null,false,0,42,'','  안녕\n  WORLD\t','İ I ı i','é É','你好\n世界',...Array.from({length:5000},(_,i)=>'  text '+i+'\tTEXT  ')];
  for(const value of [...values,...values.slice().reverse()])assert.equal(normal(value),String(value||'').replace(/\s+/g,' ').trim().toLocaleLowerCase());
}
console.log('PASS normalization parity / Unicode / empty values / cache eviction / changed text');
// 출력을 만들지 않는 규칙 생략도 기간·장면·복장·Positive/Negative 판정 결과를 바꾸지 않습니다.
function dialogueFactory(source){
  const textStart=source.includes('    const dialogueTextCache = new Map();')?source.indexOf('    const dialogueTextCache = new Map();'):source.indexOf('    function dialogueText(value)');
  const text=source.slice(textStart,source.indexOf('    function dialogueLogs(',textStart));
  const start=source.indexOf('    function dialoguePromptState('),fn=source.slice(start,source.indexOf('    function shortHash(',start));
  return vm.runInNewContext(text+'\n'+fn+'\ndialoguePromptState;',{
    dialogueLogs:s=>s.proximity?s.log.filter(row=>row.coLocated!==false):s.log,
    cleanPrompt:v=>typeof v==='string'?v.trim():'',sceneFamilyKey:key=>String(key).split('__')[0],
    logImageKeyAt:(rows,index)=>rows[index]?.imageKey||'',outfitAllows:(allowed,outfit)=>allowed.includes(outfit),
    addPrompt:(result,id,value)=>{if(typeof value==='string'&&value.trim()&&!result.codes.includes(id)){result.codes.push(id);result.tags.push(value.trim());}},
  });
}
for(const [index,[id]]of definitions.entries()){
  const previous=dialogueFactory(old[index].body),current=dialogueFactory(fs.readFileSync(path.join(root,'wml/mods',id,'mod.js'),'utf8'));
  const rules=[{id:'a',text:'  HELLO world ',positivePrompt:' happy ',negativePrompt:'',duration:'minutes',minutes:10,outfitStates:['modest']},
    {id:'b',text:'안녕',positivePrompt:'',negativePrompt:' sad ',duration:'scene',minutes:10,outfitStates:['modest']},
    {id:'c',text:'world',positivePrompt:'   ',negativePrompt:'',duration:'minutes',minutes:10,outfitStates:['modest']}];
  for(const slot of [90,100,109,110,120])for(const proximity of [false,true])for(const field of ['positivePrompt','negativePrompt'])for(const outfit of ['modest','nude']){
    const state={slot,proximity,log:[{text:'hello\nWORLD',slot:100,imageKey:'idle__v-0',coLocated:false},{text:'안녕',slot:100,imageKey:'idle__v-0'}]};
    const args=[state,rules,'idle__v-1',field,outfit];assert.equal(JSON.stringify(current(...args)),JSON.stringify(previous(...args)));
  }
}
console.log('PASS dialogue Positive/Negative / blank fields / duration boundaries / scene / outfit / proximity parity');
const playUrl=new URL('../../../../MCP/lib/play.mjs',import.meta.url).href;
let beforeMode=false;
globalThis.__sleepDialogueBefore=()=>beforeMode;
const registration=registerHooks({load(url,context,next){
  const result=next(url,context);if(url!==playUrl)return result;
  const marker='    if (isBlocked(u, `http://127.0.0.1:${port}`))';assert.equal(String(result.source).split(marker).length,2);
  const pageMarker='  const page = await context.newPage();';
  const withRandom=String(result.source).replace(pageMarker,()=>pageMarker+`\n  await page.evaluateOnNewDocument(()=>{
    let seed=1138,draws=0,cryptoSeed=7331;
    const random=()=>{draws++;seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
    Math.random=random;
    crypto.getRandomValues=array=>{for(let i=0;i<array.length;i++){cryptoSeed=(Math.imul(cryptoSeed,1664525)+1013904223)>>>0;array[i]=cryptoSeed;}return array;};
    window.__sleepTestRandom={reset(){seed=1138;draws=0;cryptoSeed=7331;},draws:()=>draws};
  });`);
  return {...result,source:withRandom.replace(marker,()=>`    const previous=globalThis.__sleepDialogueBefore()?${JSON.stringify(old)}.find(item=>new URL(u).pathname===item.path):null;
    if(previous)req.respond({status:200,contentType:'text/javascript',body:previous.body}).catch(()=>{});
    else ${marker.trimStart()}`)};
}});
const {playStart,playEval,shutdown}=await import(playUrl);
const results={};let fixture;
try{
  for(const label of ['before','after']){
    beforeMode=label==='before';
    const started=await playStart({id:label,viewport:process.argv.includes('--mobile')?{width:390,height:844}:{width:1280,height:900}});
    assert.deepEqual(started.failed,[]);
    if(!fixture)fixture=(await playEval({id:label,timeoutMs:45000,code:`
      const d=WML.dev();d.store.get().newGame();let s=d.store.game();
      s={...s,slot:1529,day:1,phase:'bedroom',pendingEvent:null,activeScene:{},errandSession:undefined,customers:[]};
      s=d.fn('moveOccupant')(s,'player','bedroom');d.store.update(()=>s);
      // 처음 경쟁여관을 만드는 비용과 초기 난수는 측정 전에 같은 저장 상태에 담습니다.
      s=d.fn('worldTick')(s,{playerPresent:false});
      return s;
    `})).result;
    const code=`const d=WML.dev();let s=${JSON.stringify(fixture)};
      Date.now=()=>1793100000000;
      s={...s,pendingEvent:null,activeScene:{},errandSession:undefined,customers:[]};
      s=d.fn('moveOccupant')(s,'player','bedroom');d.store.update(()=>s);
      d.fn('Ju')(1138); // game_source로 확인한 본편 결정적 난수 시드 설정 함수
      __sleepTestRandom.reset();
      const start=performance.now();let next=d.fn('reduceGameAction')(s,{type:'sleep',underway:${process.argv.includes('--underway')}});
      if(${process.argv.includes('--underway')})next=d.fn('reduceGameAction')(next,{type:'wait',until:'done'});
      return {ms:Math.round(performance.now()-start),draws:__sleepTestRandom.draws(),state:next,seed:d.fn('BS')()};`;
    const response=await playEval({id:label,code,timeoutMs:45000});assert.equal(response.pageErrorsSoFar,0,JSON.stringify(response));
    results[label]=response.result;
    console.log(JSON.stringify({label,loaded:started.loaded.length,ms:response.result.ms,day:response.result.state.day,slot:response.result.state.slot,phase:response.result.state.phase,draws:response.result.draws,seed:response.result.seed,logs:response.result.state.log.length}));
  }
  const keys=Object.keys(results.before.state).filter(key=>JSON.stringify(results.before.state[key])!==JSON.stringify(results.after.state[key]));
  console.log(JSON.stringify({sameState:hash(results.before.state)===hash(results.after.state),changedKeys:keys}));
  if(keys.length){
    const differences=[];function diff(a,b,p){if(differences.length>=8||JSON.stringify(a)===JSON.stringify(b))return;if(!a||!b||typeof a!=='object'||typeof b!=='object'){differences.push({path:p,before:a,after:b});return;}for(const key of new Set([...Object.keys(a),...Object.keys(b)]))diff(a[key],b[key],p+'.'+key);}
    diff(results.before.state,results.after.state,'state');console.log(JSON.stringify({differences}));
  }
  assert.equal(hash(results.after.state),hash(results.before.state),'전체 수면 결과 일치: '+keys.join(', '));
  assert.equal(results.after.draws,results.before.draws);assert.equal(results.after.seed,results.before.seed);
  console.log('PASS same complete game state / log / native RNG / random draw count / no page errors');
}finally{
  const deadline=setTimeout(()=>process.exit(process.exitCode||0),5000);await shutdown();clearTimeout(deadline);registration.deregister();
  setTimeout(()=>process.exit(process.exitCode||0),200).unref();
}
