// 실행: node wml/mods/imagestudio-compatible-attention-image-prompt/tests/outfit-prompts.mjs [--mobile]
// 격리 게임에서 단독 attention 동시 사용/미사용을 검사합니다. GPU·실서버 요청은 하지 않습니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { playStart, playEval, playStop, shutdown } from '../../../../MCP/lib/play.mjs';

const session = 'editor-outfit-prompts';
const viewport = process.argv.includes('--mobile') ? { width: 390, height: 844 } : { width: 1500, height: 950 };
let listed = [];
vm.runInNewContext(fs.readFileSync(new URL('../../mods.js', import.meta.url), 'utf8'), {
  WML: { folders() {}, enable(values) { listed = values; } },
});
const disabled = Object.fromEntries(listed.map(value => [value.replace(/:off$/, ''), false]));

try {
  for (const external of [true]) {
    const started = await playStart({ id: session, viewport, mods: {
      ...disabled, 'addon-compat': true, imagestudio: true,
      'imagestudio-compatible-attention-image-prompt': true, 'attention-image-prompt': external,
    } });
    assert.deepEqual(started.failed, []);
    const response = await playEval({ id: session, timeoutMs: 30000, code: `
      let seed=1138;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
      const d=WML.dev(),b=WW_ImageStudioBridge;await b.ready();
      const before=JSON.stringify(d.store.game()),key='wml.mod.attention-image-prompt';
      const standaloneKey='wml.mod.attention-image-prompt';
      const standalone={outfitPrompts:{modest:{positivePrompt:'standalone_outfit_1138',negativePrompt:'standalone_negative_1138'}}};
      localStorage.setItem(standaloneKey,JSON.stringify(standalone));
      const selected={situation:['idle'],outfit:['modest'],room:['taproom'],mood:['default'],men:['0'],exposure:['none'],aftermath:['none'],variant:['0']};
      const original={...d.fn('outfitById')('modest')};
      const saved=JSON.parse(localStorage.getItem(key)||'{}');
      const state=d.store.game(),wife=d.fn('wife')(state);
      function build(exposure='none'){
        const detail=WW_ImageStudioPrompt.combinationSpace({});
        return b.randomSpace('elena',{...selected,exposure:[exposure]}).build(0n,detail.at(0n))[0];
      }
      function save(positive,negative){
        localStorage.setItem(key,JSON.stringify({...saved,outfitPrompts:{...saved.outfitPrompts,modest:{positivePrompt:positive,negativePrompt:negative}}}));
      }
      // 사용자가 사용하는 공통 편집기에서 저장한 값을 실제 생성까지 추적합니다.
      WW_ImageStudioPrompt.open();
      const root=()=>document.querySelector('[data-wwis-prompt-editor]');
      [...root().querySelectorAll('button')].find(button=>button.textContent==='의상 프롬프트').click();
      const source=root().querySelector('[data-outfit-prompt-source]');
      source.value='modest';source.dispatchEvent(new Event('change',{bubbles:true}));
      const positive=root().querySelector('[data-outfit-prompt="positive"]');
      positive.value='editor_outfit_1138';positive.dispatchEvent(new Event('change',{bubbles:true}));
      const negative=root().querySelector('[data-outfit-prompt="negative"]');
      negative.value='editor_negative_1138';negative.dispatchEvent(new Event('change',{bubbles:true}));
      const uiSaved=JSON.parse(localStorage.getItem(key)).outfitPrompts.modest;
      const first=build(),live=d.fn('imagePrompt')({...wife,outfit:'modest'},'taproom'),exposed=build('0100000');
      const firstKey=first.talentId;
      save('editor_changed_1138','editor_changed_negative_1138');
      const changed=build();
      save('','');
      const blank=build();
      // 검수 생성 요청에도 최종 프롬프트가 그대로 전달되는지 모의 서버로 확인합니다.
      const originalFetch=fetch,originalConnection=b.connection;let payload;
      b.connection=()=>({baseUrl:location.origin,comfyui:true});
      globalThis.fetch=(input,options={})=>{
        const pathname=new URL(String(input),location.href).pathname;
        if(pathname==='/api/studio/drafts')return Promise.resolve(new Response(JSON.stringify({supportsReviewDrafts:true,entries:[]})));
        if(pathname==='/api/image/generate'){
          payload=JSON.parse(options.body);
          return Promise.resolve(new Response(JSON.stringify({status:'completed',reviewOnly:true,draftId:'outfit-1138',imageUrl:'/mock-outfit.webp'})));
        }
        return originalFetch(input,options);
      };
      try{await WW_ImageStudioPrompt.generate({imageKey:changed.talentId,prompt:changed.prompt,negativePrompt:changed.negativePrompt});}
      finally{globalThis.fetch=originalFetch;b.connection=originalConnection;}
      localStorage.setItem(key,JSON.stringify(saved));
      return {external:WML.status().loaded.includes('attention-image-prompt'),uiSaved,first,live,exposed,changed,blank,payload,
        keyChanged:firstKey!==changed.talentId,standalonePreserved:JSON.stringify(JSON.parse(localStorage.getItem(standaloneKey)))===JSON.stringify(standalone),
        gamePreserved:before===JSON.stringify(d.store.game()),baseTags:original.imageTags};
    ` });
    assert.equal(response.error, undefined, JSON.stringify(response));
    assert.equal(response.pageErrorsSoFar, 0);
    const value = response.result;
    assert.equal(value.external, external);
    assert.deepEqual(value.uiSaved, { positivePrompt: 'editor_outfit_1138', negativePrompt: 'editor_negative_1138' });
    for (const prompt of [value.first, value.live, value.exposed]) {
      assert.match(prompt.prompt, /editor_outfit_1138/);
      assert.match(prompt.negativePrompt, /editor_negative_1138/);
      assert.doesNotMatch(prompt.prompt, /standalone_outfit_1138/);
    }
    assert.match(value.changed.prompt, /editor_changed_1138/);
    assert.doesNotMatch(value.changed.prompt, /editor_outfit_1138/);
    assert.doesNotMatch(value.blank.prompt, /editor_|standalone_outfit_1138/);
    assert.doesNotMatch(value.blank.negativePrompt, /editor_negative_1138|standalone_negative_1138/);
    // The current AIP editor adds its prompt fingerprint to the image key.
    assert.equal(value.keyChanged, true);
    assert.equal(value.payload.prompt, value.changed.prompt);
    assert.equal(value.payload.negativePrompt, value.changed.negativePrompt);
    // The modern editor uses the AIP settings store directly; there is no separate embedded outfit store.
    assert.equal(value.gamePreserved, true);
    console.log('PASS outfit override / live and conditional / exposure / edit and blank / request payload / settings and state preserved: external=' + external);
    await playStop({ id: session });
  }
} finally {
  await shutdown();
  setTimeout(() => process.exit(process.exitCode || 0), 200).unref();
}
