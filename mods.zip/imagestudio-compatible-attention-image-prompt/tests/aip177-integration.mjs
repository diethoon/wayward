// Isolated MCP browser only. node tests/aip177-integration.mjs [--mobile] [--zip]
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire,registerHooks} from 'node:module';
import {pathToFileURL} from 'node:url';
const require = createRequire(new URL('../../../../wayward-wml-ko_old/MCP/package.json',import.meta.url));
registerHooks({resolve(s,c,next){try{return next(s,c);}catch(e){if(e.code==='ERR_MODULE_NOT_FOUND'&&!s.startsWith('.')&&!s.includes(':'))return next(pathToFileURL(require.resolve(s)).href,c);throw e;}}});
const p=await import('../../../../MCP/lib/play.mjs');
const id='aip177',mobile=process.argv.includes('--mobile'),zip=process.argv.includes('--zip');
const call=async(fn,args)=>{const r=await p.playEval({id,timeoutMs:15000,code:'return ('+fn.toString()+')('+JSON.stringify(args??null)+');'});assert.equal(r.pageErrorsSoFar,0,JSON.stringify(r));return r.result;};
try{
 let loaded=await p.playStart({id,viewport:mobile?{width:390,height:844}:{width:1500,height:1000}});
 assert.deepEqual(loaded.failed,[]);
 await call(()=>{
  localStorage.setItem('wml.mod.attention-image-prompt',JSON.stringify({outfitPrompts:{modest:{positivePrompt:'aip_old_outfit',negativePrompt:'aip_old_negative'},linen_shift:{positivePrompt:'aip_only_outfit'}},sceneCandidatePools:{'task-idle':{additions:[{id:'add-177',prompt:'new_scene_candidate',name:'Test'}],selected:'add-177'}},gameDefaultPrompts:{positivePrompt:'quality_177',negativePrompt:'negative_177'},customTags:['aip_custom_177']}));
  localStorage.setItem('wml.mod.imagestudio-compatible-attention-image-prompt',JSON.stringify({outfitPrompts:{modest:{positivePrompt:'studio_preferred_outfit',negativePrompt:''}},nativeAxisPrompts:{room:{taproom:{positivePrompt:'studio_room_177',negativePrompt:'studio_room_negative'}}},unsupportedOriginal:{keep:'retained'}}));
  localStorage.removeItem('wml.mod.imagestudio-compatible-attention-image-prompt.before-aip-1770');
 });
 if(zip){
  const installed=await call(async()=>{
   const packages=[['attention-image-prompt','1.77.0-pre7.1'],['imagestudio-compatible-attention-image-prompt','1.2.0-pre7.1']];
   const append=Node.prototype.appendChild;Node.prototype.appendChild=function(node){if(node.tagName==='SCRIPT'&&packages.some(([id])=>node.src.endsWith('/'+id+'/mod.js'))){queueMicrotask(()=>node.dispatchEvent(new Event('error')));return node;}return append.call(this,node);};
   try{return await WML.install(await Promise.all(packages.map(async([id,v])=>({path:id+'.zip',blob:await(await fetch('wml/mods/'+id+'/'+id+'-'+v+'-20261101.zip')).blob()}))));}finally{Node.prototype.appendChild=append;}
  });assert.ok(installed.every(row=>row.mode==='browser'));
 }
 loaded=await p.playReload({id});assert.deepEqual(loaded.failed,[]);
 const result=await call(async()=>{
  const checks={},d=WML.dev(),b=WW_ImageStudioBridge,aip=WML.use('attention-image-prompt');
  const read=()=>JSON.parse(localStorage.getItem('wml.mod.attention-image-prompt'));
  const settings=read(),backup=JSON.parse(localStorage.getItem('wml.mod.imagestudio-compatible-attention-image-prompt.before-aip-1770'));
  checks.preferred=settings.outfitPrompts.modest.positivePrompt==='studio_preferred_outfit';
  checks.emptyPreserved=settings.outfitPrompts.modest.negativePrompt==='';
  checks.aipOnlyPreserved=settings.outfitPrompts.linen_shift.positivePrompt==='aip_only_outfit';
  checks.unknownPreserved=settings.unsupportedOriginal.keep==='retained';
  checks.backupExact=JSON.parse(backup.commonEditor).outfitPrompts.modest.positivePrompt==='studio_preferred_outfit'&&JSON.parse(backup.attention).outfitPrompts.modest.positivePrompt==='aip_old_outfit';
  d.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true});d.store.get().newGame();d.fn('store').setState({started:true,selectingArchetype:false,selectingBuilder:false,selectingPicks:false});
  const flush=()=>new Promise(r=>setTimeout(r,100));await flush();await b.ready();
  const gameBefore=JSON.stringify(d.store.game());
  const t=performance.now();WW_ImageStudioPrompt.open();const openMs=performance.now()-t;await flush();
  const root=()=>document.querySelector('[data-wwis-aip-editor]');
  checks.renderer=!!root()&&WW_ImageStudioPrompt.embeddedVersion==='1.77.0';checks.fastOpen=openMs<350;
  const click=label=>{const btn=[...root().querySelectorAll('button')].find(b=>b.textContent===label);if(!btn)throw Error('Missing button '+label);btn.click();};
  checks.newTabs=['장면 프롬프트','선택지 프롬프트','절정 프롬프트','임신 상태','생리 상태'].every(label=>[...root().querySelectorAll('button')].some(b=>b.textContent===label));
  click('의상 프롬프트');await flush();
  const source=root().querySelector('[data-outfit-prompt-source]');source.value='modest';source.dispatchEvent(new Event('change'));await flush();
  let input=root().querySelector('[data-outfit-prompt="positive"]');checks.migratedUi=input?.value==='studio_preferred_outfit';
  input.value='ui_edited_outfit_177';input.dispatchEvent(new Event('input',{bubbles:true}));
  const top=root().querySelector('[data-aip-custom-outfit-edit-half="topPrompt"]');top.value='ui_top_177';top.dispatchEvent(new Event('input',{bubbles:true}));
  checks.newPartEditor=read().outfitPrompts.modest.topPrompt==='ui_top_177';
  const live=()=>d.fn('imagePrompt')(d.fn('wife')(d.store.game()),'taproom');
  const liveRequest=live();checks.live=liveRequest.prompt.includes('ui_edited_outfit_177')&&liveRequest.prompt.includes('studio_room_177');
  const selected={situation:['idle'],outfit:['modest'],room:['taproom'],mood:['default'],men:['0'],exposure:['none'],aftermath:['none'],variant:['0']};
  const space=WW_ImageStudioPrompt.combinationSpace({});const planned=b.randomSpace('elena',selected).build(0n,space.at(0n))[0];
  checks.gameDefaultsLive=liveRequest.prompt.includes('quality_177')&&liveRequest.negativePrompt.includes('negative_177');
  checks.gameDefaultsPlanned=planned?.prompt.includes('quality_177')&&planned.negativePrompt.includes('negative_177');
  checks.planned=!!planned?.prompt.includes('ui_edited_outfit_177')&&planned.prompt.includes('studio_room_177');
  checks.sceneLive=liveRequest.prompt.includes('new_scene_candidate');checks.scenePlanned=planned.prompt.includes('new_scene_candidate');
  checks.noDuplicateScene=liveRequest.prompt.split('new_scene_candidate').length===2&&planned.prompt.split('new_scene_candidate').length===2;
  checks.emptyApplied=!liveRequest.negativePrompt.includes('aip_old_negative');
  checks.cameraSaved=aip.cameraController.set('task-idle',{shots:[{id:'test177',name:'Test',positive:'camera_test_177',negative:'camera_negative_177'}],selected:['test177'],removeTags:''}).ok;
  const cameraLive=live(),cameraPlan=b.randomSpace('elena',selected).build(0n,WW_ImageStudioPrompt.combinationSpace({}).at(0n))[0];
  checks.cameraLive=cameraLive.prompt.includes('camera_test_177')&&cameraLive.negativePrompt.includes('camera_negative_177');
  checks.cameraPlanned=cameraPlan.prompt.includes('camera_test_177')&&cameraPlan.negativePrompt.includes('camera_negative_177');
  checks.changedPlanKey=cameraPlan.talentId!==planned.talentId;
  const details=document.querySelector('[data-wwis-additional-prompts]');details.open=true;await flush();
  const extrasText=document.querySelector('[data-wwis-legacy-axes]')?.textContent;
  checks.additionalUi=!!document.querySelector('[data-wwis-legacy-axes] [data-native-axis-prompt-source]');
  click('선택지 프롬프트');await flush();checks.choiceUi=!!root().textContent.includes('선택지');
  click('장면 프롬프트');await flush();checks.sceneUi=!!root().textContent.includes('장면');
  checks.gameUnchanged=JSON.stringify(d.store.game())===gameBefore;
  // Host delegates to the existing review API and never starts a second AIP instance.
  const review=b.extensions.review,original=review.generate;let captured;
  review.generate=async request=>{captured=request;return {draft:true,draftId:'test177',url:'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg"/>'};};
  try{const generate=[...root().querySelectorAll('button')].find(b=>b.textContent==='현재 상황 이미지 생성');if(generate){generate.click();await flush();await flush();}}finally{review.generate=original;}
  checks.reviewRouted=!!captured?.prompt;
  // imageGenerate itself stays native for automatic gameplay; AIP calls use the attached host.
  checks.singleEditor=b.extensions.list().editor==='imagestudio-compatible-attention-image-prompt';
  return {checks,openMs,extrasText:extrasText?.slice(0,600),liveKey:liveRequest.key,plannedKey:planned?.talentId,live:liveRequest.prompt,planned:planned?.prompt};
 });
 const status=await p.playStatus({id});const report={mobile,zip,loaded:loaded.loaded.length,result,pageErrors:status.pageErrors};
 await call(()=>{document.querySelector('[data-wwis-additional-prompts]').open=false;const root=document.querySelector('[data-wwis-aip-editor]');[...root.querySelectorAll('button')].find(b=>b.textContent==='의상 프롬프트').click();});
 fs.writeFileSync(new URL('aip177-'+(zip?'zip-':'')+(mobile?'mobile':'pc')+'.jpg',import.meta.url),Buffer.from(await p.playScreenshot({id}),'base64'));
 assert.deepEqual((await p.playReload({id})).failed,[]);
 report.restart=await call(()=>{const s=JSON.parse(localStorage.getItem('wml.mod.attention-image-prompt'));return {edit:s.outfitPrompts.modest.positivePrompt==='ui_edited_outfit_177',empty:s.outfitPrompts.modest.negativePrompt==='',part:s.outfitPrompts.modest.topPrompt==='ui_top_177',camera:!!s.cameraSceneSettings['task-idle'],legacy:JSON.parse(localStorage.getItem('wml.mod.imagestudio-compatible-attention-image-prompt')).outfitPrompts.modest.positivePrompt==='studio_preferred_outfit'};});
 assert.ok(Object.values(report.restart).every(Boolean));
 console.log(JSON.stringify(report,null,2));assert.ok(Object.values(result.checks).every(Boolean),JSON.stringify(result.checks));assert.deepEqual(status.pageErrors,[]);
 fs.writeFileSync(new URL('aip177-'+(zip?'zip-':'')+(mobile?'mobile':'pc')+'.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
}finally{await p.shutdown();}
