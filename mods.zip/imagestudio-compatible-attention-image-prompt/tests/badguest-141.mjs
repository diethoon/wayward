// node --import ./version_up_ready2/implementation-runtime.mjs wml/mods/imagestudio-compatible-attention-image-prompt/tests/badguest-141.mjs --wml . [--mobile] [--zip]
// 격리 Chromium·실제 게임 API만 사용합니다. 사용자 저장/GPU/실서버에는 접근하지 않습니다.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {writeZip} from '../../../../wml/tools/zip.mjs';
import {checkMod} from '../../../../MCP/lib/check.mjs';
import {playStart,playEval,playReload,playStatus,playStop,shutdown} from '../../../../MCP/lib/play.mjs';
const dir=path.resolve(import.meta.dirname,'..'),root=path.resolve(dir,'../../..'),mobile=process.argv.includes('--mobile'),packaged=process.argv.includes('--zip');
const helper=fs.readFileSync(path.join(dir,'source/badguest-state.js'),'utf8'),contexts=fs.readFileSync(path.join(dir,'source/context-state-prompts.js'),'utf8');
const from=contexts.indexOf('function ImageStudio_동의상태판정하기('),to=contexts.indexOf('\nconst ImageStudio_흔적',from);
const functions=vm.runInNewContext(helper+'\n'+contexts.slice(from,to)+'\n({flags:ImageStudio_나쁜손님상태읽기,consent:ImageStudio_동의상태판정하기});',{
 api:{fn:()=>s=>s.room},ImageStudio_성적맥락인가:()=>true,ImageStudio_맥락장면읽기:()=>'',characterIdOf:(_s,c)=>c.id,
});
const character={id:'wife',currentTask:'idle'},effect={startedAtSlot:100,endsAtSlot:200},item={active:true,roomId:'back_room'};
const fixture=(data,extra={})=>({slot:150,room:'back_room',primaryCharacterId:'wife',characters:{wife:character},mods:{badguest:data},...extra});
const data={effects:{confusion:effect,aphrodisiac:effect,intoxicationFloor:effect},equipment:{restraint:item,blindfold:item,gag:item}},s=fixture(data);
const before=JSON.stringify(s);
for(const code of ['handcuffed','blindfolded','gagged','confused','drugged','intoxicated'])assert.equal(functions.flags(s,character,'wife')[code],true,code);
assert.equal(functions.flags(s,character,'other').confused,undefined,'other character');
assert.equal(functions.flags({...s,slot:200},character,'wife').confused,false,'expiry boundary');
assert.equal(functions.flags({...s,slot:99},character,'wife').confused,false,'future effect');
assert.equal(functions.flags({...s,room:'taproom'},character,'wife').gagged,false,'different room');
const residual=fixture({equipment:{gag:{active:false,roomId:'back_room',afterUntilSlot:160}}});
assert.equal(functions.flags(residual,character,'wife').gagged,true);
assert.equal(functions.flags({...residual,slot:160},character,'wife').gagged,false);
assert.equal(functions.consent(s,character,''),'confused');
assert.equal(functions.consent({...s,activeScene:{patron:{coercedSinceSlot:140}}},character,''),'coerced');
assert.equal(functions.consent({...s,activeScene:{patron:{badGuestForcedGroup:true}}},character,''),'forced_join');
assert.equal(functions.consent(s,{...character,currentTask:'sleeping'},''),'unconscious');
assert.equal(functions.consent(fixture({drugEffect:{...effect,type:'hallucinogen'}}),character,''),'hallucinated');
assert.equal(functions.consent(fixture({}),character,''),'voluntary');
assert.equal(JSON.stringify(s),before,'read-only flags');
const result={date:new Date().toISOString(),mobile,packaged,unit:true,static:checkMod(path.basename(dir)),modes:[]};
assert.deepEqual(result.static.errors,[]);
const badRoot=fs.existsSync(path.join(root,'wml/mods/badguest/mod.js'))?path.join(root,'wml/mods/badguest'):path.join(root,'wml/mods/badguest/badguest');
const temp=path.join(dir,'tests/.badguest-image-test-'+(mobile?'mobile':'pc')+'.zip');
const walk=(p,prefix='')=>fs.readdirSync(p,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(p,e.name),prefix+e.name+'/'):[{name:prefix+e.name,data:fs.readFileSync(path.join(p,e.name))}]);
const probe=String.raw`
 const d=WML.dev(),mod=globalThis.__WAYWARD_MODS__?.BadGuest,editor=WML.use('imagestudio-compatible-attention-image-prompt'),sleep=WML.use('sleep-actions');
 const expect=(ok,label)=>{if(!ok)throw Error(label)};
 expect(mod?.version==='1.4.1','BadGuest 1.4.1');expect(sleep.apiVersion>=14,'sleep API');
 d.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true});d.store.get().newGame();
 d.fn('store').setState({started:true,selectingArchetype:false,selectingBuilder:false,selectingPicks:false});
 await new Promise(r=>setTimeout(r,80));[...document.querySelectorAll('button')].find(b=>b.textContent.trim()==='건너뛰기')?.click();
 let s=structuredClone(d.store.game());s={...s,slot:1020,phase:'service',pendingEvent:undefined,activeScene:{},customers:[],tavern:{...s.tavern,backRoomReady:true}};
 s=d.fn('moveOccupant')(s,'player','taproom');s=d.fn('moveOccupant')(s,s.primaryCharacterId,'taproom');
 s.characters[s.primaryCharacterId]={...s.characters[s.primaryCharacterId],currentTask:'serving',busyUntilSlot:1020,locationUntilSlot:1020};
 const g=d.fn('makeCustomer')(s.slot,[],[],s.tavernReputation,s);g.id='image-141';g.name='호환 검사';g.status='seated';s=d.fn('addCustomer')(s,g,'taproom');
 s=mod.actions.execute(s,{command:'mark',customerId:g.id}).state;d.store.update(()=>s);
 const snapshot=mod.getProbabilitySnapshot();expect(snapshot.sleepActionsAvailable&&snapshot.effectivePatternWeights.infiltrator>0&&snapshot.effectiveSpecialActionWeights.sleepDrug>0,'sleep integration enabled');
 const record={...s,customers:[{...g,mistreatmentTonight:0}],patronRecords:[{name:g.name,mistreatmentCount:0}]};
 for(const arg of [g,g.name]){const out=d.fn('recordPatronMistreatment')(record,arg);expect(out.customers[0].mistreatmentTonight===1&&out.patronRecords[0].mistreatmentCount===1,'record argument');}
 const drugChecks=[];
 for(const [kind,code]of [['aphrodisiac','drugged'],['intoxication','intoxicated'],['confusion','confused']]){
   const dose=mod.actions.execute(structuredClone(s),{command:'drug-'+kind,customerId:g.id});
   d.store.update(()=>dose.state);const doseState=d.store.game(),dosePrompt=d.fn('imagePrompt')(d.fn('wife')(doseState),'taproom');
   expect(dosePrompt.imageMatching.badguest.includes(code),'actual drug '+kind);drugChecks.push(kind);
 }
 const sleepDose=mod.actions.execute(structuredClone(s),{command:'drug-sleep',customerId:g.id});
 expect(sleepDose.state!==s&&sleepDose.state.mods.badguest.sleepPotion.requests.length>0,'actual sleep potion');
 d.store.update(()=>s);
 s=mod.actions.execute(s,{command:'drinking-game-offer',customerId:g.id}).state;expect(s.pendingEvent?.type==='bad_guest_drinking_game_offer','offer');
 s=mod.actions.execute(s,{command:'drinking-game-loss'}).state;d.store.update(()=>s);
 const prompt=()=>{const state=d.store.game();return d.fn('imagePrompt')(d.fn('wife')(state),d.fn('wifeLocation')(state));};
 let p=prompt();expect(p.imageMatching.badguest.includes('confused')&&p.imageMatching.badguest.includes('blindfolded'),'loss matching');
 expect(p.imageMatching.detail.includes('context.consent.confused'),'loss consent');expect(!/spiral eyes|swirling pupils/.test(p.prompt),'confusion is not hallucination');
 expect(/blindfold/.test(p.prompt),'native blindfold retained');
 const settingsKey='wml.mod.attention-image-prompt',saved=JSON.parse(localStorage.getItem(settingsKey)||'{}');
 localStorage.setItem(settingsKey,JSON.stringify({...saved,contextStatePrompts:{...saved.contextStatePrompts,consent:{...saved.contextStatePrompts?.consent,confused:{positivePrompt:'user_confusion_141',negativePrompt:'user_negative_141'}}}}));
 p=prompt();expect(p.prompt.includes('user_confusion_141')&&p.negativePrompt.includes('user_negative_141'),'custom prompts retained');
 localStorage.setItem(settingsKey,JSON.stringify(saved));
 let equipped=structuredClone(s);for(const kind of ['restraint','blindfold','gag'])equipped.mods.badguest.equipment[kind]={...equipped.mods.badguest.equipment.blindfold,active:true,roomId:'back_room'};
 d.store.update(()=>equipped);p=prompt();for(const code of ['handcuffed','blindfolded','gagged'])expect(p.imageMatching.badguest.includes(code),'equipped '+code);
 expect(mod.imageEquipment(equipped,equipped.primaryCharacterId).gag,'native gear agrees');
 const mismatch=WW_ImageStudioBridge.selectionConflicts('elena',{'promptField:badguest.gagged':['badguest.gagged'],situation:['patron_blowjob']});expect(mismatch.some(t=>t.includes('입마개')),'manual gag conflict');
 equipped={...equipped,slot:equipped.slot+60};for(const kind of ['restraint','blindfold','gag'])equipped.mods.badguest.equipment[kind]={...equipped.mods.badguest.equipment[kind],active:false,afterUntilSlot:equipped.slot};
 equipped.activeScene={};d.store.update(()=>equipped);p=prompt();expect(!p.imageMatching.badguest.some(x=>['confused','blindfolded','gagged','handcuffed'].includes(x)),'expired state');
 const axes=editor.axes();expect(axes.some(a=>a.id==='promptField:badguest.confused')&&axes.some(a=>a.id==='promptField:badguest.intoxicated'),'new generation axes');
 const selected={situation:['idle'],outfit:['modest'],room:['taproom'],mood:['default'],men:['0'],exposure:['none'],aftermath:['none'],variant:['0']};
 const choices=editor.combinationSpace({'promptField:badguest.confused':['badguest.confused'],promptConsent:['confused']});
 const real=JSON.stringify(d.store.game()),planned=WW_ImageStudioBridge.randomSpace('elena',selected).build(0n,choices.at(0n))[0];
 expect(planned&&JSON.stringify(planned).includes('confused'),'planned confusion');expect(JSON.stringify(d.store.game())===real,'planning read only');
 // Sleeping/passed-out targets keep the existing unconscious context, not voluntary/confused.
 for(const task of ['sleeping','passed_out']){d.store.update(()=>({...s,characters:{...s.characters,[s.primaryCharacterId]:{...s.characters[s.primaryCharacterId],currentTask:task}}}));p=prompt();expect(p.imageMatching.detail.includes('context.consent.unconscious'),task+' context');}
 d.store.update(()=>s);let world=0;const stop=d.hook('worldTick',{before(){world++}});
 let ticking=JSON.parse(JSON.stringify(s));for(let i=0;i<60;i++)ticking=mod.actions.execute(ticking,{command:'drinking-game-advance'}).state;
 expect(ticking.slot===1080&&!ticking.mods.badguest.drinkingGame.active,'60 boundary');
 for(let i=0;i<5;i++)ticking=mod.actions.execute(ticking,{command:'drinking-game-advance'}).state;stop();
 expect(ticking.slot===1085&&!ticking.mods.badguest.drinkingGame&&world===65,'65 boundary');d.store.update(()=>ticking);
 await new Promise(r=>setTimeout(r,80));
 return {sleepAPI:sleep.apiVersion,nightVisit:WML.status().loaded.includes('sleep-actions-night-visit'),pattern:snapshot.effectivePatternWeights,record:true,drugs:drugChecks,sleepPotion:true,loss:true,customPrompts:true,equipment:true,expiry:true,planning:true,unconscious:true,time:true,world};
`;
try{
 writeZip(temp,walk(badRoot));
 for(const external of [true]){
  const row={external};result.modes.push(row);
  row.start=await playStart({fresh:true,mods:{'attention-image-prompt':external},viewport:mobile?{width:390,height:844}:{width:1440,height:1000}});
  assert.deepEqual(row.start.failed,[]);
  const installs=[{id:'badguest',file:path.relative(root,temp).replaceAll('\\','/')}];
  if(packaged)installs.push({id:path.basename(dir),file:'wml/mods/'+path.basename(dir)+'/imagestudio-compatible-attention-image-prompt-1.1.7-pre7.1.zip'});
  row.install=await playEval({code:`const packages=${JSON.stringify(installs)},append=Node.prototype.appendChild;Node.prototype.appendChild=function(node){if(node.tagName==='SCRIPT'&&packages.some(p=>node.src&&new URL(node.src,location.href).pathname.endsWith('/wml/mods/'+p.id+'/mod.js'))){queueMicrotask(()=>node.dispatchEvent(new Event('error')));return node;}return append.call(this,node);};try{return await WML.install(await Promise.all(packages.map(async p=>({path:p.id+'.zip',blob:await(await fetch(p.file)).blob()}))));}finally{Node.prototype.appendChild=append;}`});
  assert.ok(row.install.result.every(m=>m.mode==='browser'),'test must execute browser-installed copies');
  row.reload=await playReload({});assert.deepEqual(row.reload.failed,[]);assert.ok(row.reload.loaded.includes('badguest'));
  row.probe=await playEval({code:probe,timeoutMs:60000});row.status=await playStatus({});assert.deepEqual(row.status.pageErrors,[]);
  console.log('PASS',mobile?'mobile':'PC',packaged?'ZIP':'folder',external?'attention ON':'attention OFF',row.probe.result);
  await playStop({});
 }
}catch(error){result.error=String(error.stack||error);console.error(result.error);process.exitCode=1;}finally{
 fs.writeFileSync(path.join(dir,'tests/badguest-image-patch-'+(mobile?'mobile':'pc')+(packaged?'-zip':'')+'.json'),JSON.stringify(result,null,2)+'\n');
 if(fs.existsSync(temp))fs.unlinkSync(temp);await shutdown();
}
