// 호환성 패치 기준: imagestudio 1.31.7 (개정 기준, 버전 번호에 따른 실행 제한 없음)
// 생성 파일. source/build.mjs로 재생성합니다.
WML.define({
  tags: ["image","prompt","needs-image-server"],
  id: 'imagestudio-compatible-attention-image-prompt',
  author: "Hina_Lover",
  name: { ko: '이미지 스튜디오 - 공통 프롬프트 편집기 호환 패치', en: 'ImageStudio · Prompt Editor' },
  version: "1.2.5",
  game: "2026-11-01", lang: 'ko',
  requires: ['imagestudio', 'attention-image-prompt'],
  requiresVersion: { 'attention-image-prompt': '>=1.79.0' },
  loadAfter: ['imagestudio', 'attention-image-prompt'],
  description: '캐릭터·의상·표정·구도·상태의 Positive/Negative 편집과 생성 조건을 제공합니다.',
  symbols: {"effectiveHeroineStats":{"raw":{"2026-11-01":"Yoe"},"doc":"상세 상태 영역에 표시하는 주인공의 유효 기력 기분 흥분도 계산"},"relationshipPanelStatus":{"raw":{"2026-11-01":"vv"},"doc":"상세 상태 영역에 표시하는 신뢰 욕망 원망 이탈 허용 상태 계산"},"topFeelings":{"raw":{"2026-11-01":"i_"},"doc":"인물의 강한 감정을 세기 순서로 조회"},"wellbeingSignals":{"raw":{"2026-11-01":"Pv"},"doc":"상세 상태 영역의 심신 상태 저하 신호 계산"},"intoxicationBand":{"raw":{"2026-11-01":"Sn"},"doc":"취기 수치를 화면 표시 단계로 변환"},"imageLookup":{"raw":{"2026-11-01":"vy"},"doc":"이미지 키에 맞는 팩 항목 또는 가장 가까운 대체 항목 조회"},"outfitList":{"raw":{"2026-11-01":"Oi"},"doc":"기본 게임과 다른 모드가 함께 등록하는 의상 정의 목록","optional":true},"customWifeStore":{"raw":{"2026-11-01":"sd"},"doc":"사용자 생성 아내 등록 저장소와 아내 프롬프트 구성"},"wifeBuilderDefaults":{"raw":{"2026-11-01":"Yq"},"doc":"사용자 생성 아내 등록 저장소와 아내 프롬프트 구성"},"buildWifeArchetype":{"raw":{"2026-11-01":"SE"},"doc":"사용자 생성 아내 등록 저장소와 아내 프롬프트 구성"},"wifeArchetypeById":{"raw":{"2026-11-01":"$m"},"doc":"아내 archetype id로 기본 외형과 배경 정보 조회"},"wifePicker":{"raw":{"2026-11-01":"qit"},"doc":"새 게임에서 기본·사용자 아내를 선택하고 사용자 아내 생성기를 여는 화면"},"wifeBuilder":{"raw":{"2026-11-01":"elt"},"doc":"사용자 아내의 정보와 전체 외형 프롬프트를 편집하는 화면"},"wifePreviewBundle":{"raw":{"2026-11-01":"WL"},"doc":"사용자 아내 미리보기의 Positive·Negative 프롬프트 구성"},"wifeCharacterFromArchetype":{"raw":{"2026-11-01":"RZe"},"doc":"선택한 아내 원형으로 실제 게임 캐릭터를 생성"},"pauseMenu":{"raw":{"2026-11-01":"fit"},"doc":"일시 정지 메뉴 화면","optional":true},"imageVariantState":{"raw":{"2026-11-01":"NB"},"doc":"이미지 키별 생성 변형 목록과 현재 선택 인덱스 조회","optional":true},"saveImageVariantState":{"raw":{"2026-11-01":"Ip"},"doc":"이미지 키별 생성 변형 목록과 현재 선택 인덱스 저장","optional":true},"imageKeyParse":{"raw":{"2026-11-01":"rl"},"doc":"Image Studio conditional planner binding"}},
  setup(api) {
// 호환성 패치 기준: imagestudio 1.31.7 (개정 기준, 버전 번호에 따른 실행 제한 없음)
// 생성 파일. source/build.mjs로 재생성합니다.
function ImageStudio_상황프롬프트Api만들기(base, host) {
  const settingsKey = host.modern ? 'wml.mod.attention-image-prompt' : 'wml.mod.imagestudio-compatible-attention-image-prompt';
  const restorePosition = host.modern ? result => result : ImageStudio_체위호환연결하기(base);
  const settings = {
    get: (defaults = {}) => { if (host.planning?.settings) return { ...defaults, ...host.planning.settings }; try { return { ...defaults, ...JSON.parse(localStorage.getItem(settingsKey) || '{}') }; } catch { return { ...defaults }; } },
    set: patch => { const value = { ...settings.get(), ...patch }; localStorage.setItem(settingsKey, JSON.stringify(value)); return value; },
  };
  return { ...base, settings,
    store: { ...base.store, game: () => host.planning?.state || base.store.game() },
    fn: name => name === 'imageGenerate' ? request => host.generate(request) : base.fn(name),
    hook: (name, options) => {
      if (name === 'pauseMenu') return () => {};
      // 단독 attention이 켜져 있어도 공통 편집기의 의상 설정은 생성 전에 적용합니다.
      // 기존 의상 훅은 정의를 복제하여 프롬프트만 바꾸고 게임의 착용 상태는 유지합니다.
      if (host.external && !['imagePrompt', 'imageKey', ...(host.modern ? [] : ['imageLookup', 'outfitById'])].includes(name)) return () => {};
      if (name === 'imageKey') { host.keyHook = options.after; return () => { host.keyHook = null; }; }
      if (name === 'imagePrompt') {
        return globalThis.WW_ImageStudioBridge.extensions.registerPromptProvider({
          id: 'attention-editor', priority: -1000,
          key: (key, context) => host.modern && !host.planning ? host.modernKey?.(key) ?? key : host.keyHook?.(key, [context.character]) ?? key,
          compose(result, context) {
          if (host.modern && !host.planning) return host.modernCompose?.(result, context) ?? result;
          const args = [context.character, context.room];
          const unforced = restorePosition(result, args[0]);
          if (!host.planning) return options.after(unforced,args);
          const character = args[0], real = base.store.game();
          const id = character?.id || '__imagestudio_plan';
          const planned = { ...character, archetypeId: host.planning.archetypeId };
          host.planning.state = { ...real, primaryCharacterId:id, characters:{...real?.characters,[id]:planned} };
          let value = options.after(host.planning.raw || unforced, [planned,...args.slice(1)]);
          if (host.modern) value = host.modern.composePlan(value, planned, host.planning.state, context.room);
          host.planning.result = value || result;
          return value;
        } });
      }
      return base.hook(name, host.external ? { ...options, priority: -1000 } : options);
    },
    ui: { ...base.ui, settings: render => { host.renderSettings = render; },
      window: options => options.id === 'settings' ? host.open() : base.ui.window(options) },
  };
}


// 별도 attention-image-prompt가 적용한 체위 고정과 대응 필요 프롬프트를 ImageStudio의 게임 프롬프트에서 제거합니다.
// 저장된 설정과 다른 모드 파일은 변경하지 않습니다.
function ImageStudio_체위호환연결하기(api) {
  const snapshots = new WeakMap();
  const originalLabels = new Set(['장면', '자세', '작업', 'Scene', 'Pose', 'Action', '그룹', 'Group']);
  const protectedNegative = new Set(['cleavage', 'breasts out', 'nipples', 'ass', 'exposed ass', 'bottomless',
    'no panties', 'revealing clothing', 'bare shoulders', 'low neckline', 'short skirt', 'bare legs']);
  const ImageStudio_체위태그읽기 = value => String(value || '').split(',').map(tag => tag.trim()).filter(Boolean);
  const ImageStudio_체위태그비교하기 = tag => String(tag).toLowerCase().replaceAll('_', ' ').replace(/\s+/g, ' ').trim();
  const ImageStudio_노출방지Negative복원하기 = (result, snapshot) => {
    if (!snapshot) return result;
    const current = ImageStudio_체위태그읽기(result?.negativePrompt);
    const identities = new Set(current.map(ImageStudio_체위태그비교하기));
    for (const tag of ImageStudio_체위태그읽기(snapshot.negativePrompt)) {
      const identity = ImageStudio_체위태그비교하기(tag);
      if (protectedNegative.has(identity) && !identities.has(identity)) { current.push(tag); identities.add(identity); }
    }
    const negativePrompt = current.join(', ');
    return negativePrompt === result?.negativePrompt ? result : { ...result, negativePrompt };
  };
  const ImageStudio_대응필요프롬프트지우기 = result => {
    const removed = result.parts.filter(part => ['대응 필요 상황', 'Attention needed'].includes(String(part?.label || '')));
    if (!removed.length) return result;
    const parts = result.parts.filter(part => !removed.includes(part));
    const retained = new Set(parts.flatMap(part => ImageStudio_체위태그읽기(part.tags)).map(ImageStudio_체위태그비교하기));
    const blocked = new Set(removed.flatMap(part => ImageStudio_체위태그읽기(part.tags))
      .map(ImageStudio_체위태그비교하기).filter(tag => !retained.has(tag)));
    const prompt = ImageStudio_체위태그읽기(result.prompt)
      .filter(tag => !blocked.has(ImageStudio_체위태그비교하기(tag))).join(', ');
    return { ...result, prompt, parts, genParams: api.fn('promptGenParams')?.(prompt) || result.genParams };
  };
  api.hook('imagePrompt', {
    priority: 20000,
    after(result, [character]) {
      if (character && typeof character === 'object' && Array.isArray(result?.parts)) {
        snapshots.set(character, { ...result, parts: result.parts.map(part => ({ ...part })) });
      }
    }
  });
  return function ImageStudio_게임체위복원하기(result, character) {
    if (!Array.isArray(result?.parts)) return result;
    const snapshot = snapshots.get(character);
    result = ImageStudio_대응필요프롬프트지우기(result);
    result = ImageStudio_노출방지Negative복원하기(result, snapshot);
    const forced = result.parts.filter(part => String(part.label || '').startsWith('체위 프리셋 ·')
      || String(part.label || '').startsWith('추가 인원 배치 ·') || part.label === '성별·인원 유지');
    if (!forced.length) return result;
    if (!snapshot) throw new Error('ImageStudio could not restore the original scene prompt.');
    const kept = result.parts.filter(part => !forced.includes(part));
    const keptLabels = new Set(kept.map(part => part.label));
    const restored = snapshot.parts.filter(part => originalLabels.has(part.label) && !keptLabels.has(part.label));
    const parts = [...kept, ...restored];
    const retained = new Set(parts.flatMap(part => ImageStudio_체위태그읽기(part.tags)).map(ImageStudio_체위태그비교하기));
    const blocked = new Set(forced.flatMap(part => ImageStudio_체위태그읽기(part.tags))
      .map(ImageStudio_체위태그비교하기).filter(tag => !retained.has(tag)));
    const tags = ImageStudio_체위태그읽기(result.prompt).filter(tag => !blocked.has(ImageStudio_체위태그비교하기(tag)));
    for (const tag of restored.flatMap(part => ImageStudio_체위태그읽기(part.tags))) {
      if (!tags.some(existing => ImageStudio_체위태그비교하기(existing) === ImageStudio_체위태그비교하기(tag))) tags.push(tag);
    }
    const prompt = tags.join(', ');
    return { ...result, key: String(result.key || '').split('__').filter(part => !part.startsWith('position-')).join('__'),
      prompt, parts, genParams: api.fn('promptGenParams')?.(prompt) || result.genParams };
  };
}

function ImageStudio_상황프롬프트설치하기(baseApi,host) {
const api=ImageStudio_상황프롬프트Api만들기(baseApi,host);

    const effectiveHeroineStats = api.fn('effectiveHeroineStats');
    const relationshipPanelStatus = api.fn('relationshipPanelStatus');
    const topFeelings = api.fn('topFeelings');
    const wellbeingSignals = api.fn('wellbeingSignals');
    const intoxicationBand = api.fn('intoxicationBand');
    const heroineDriveCalc = api.fn('heroineDriveCalc');
    const allureScore = api.fn('allureScore');
    const joinPrompt = api.fn('promptJoin');
    const promptGenParams = api.fn('promptGenParams');
    const settingsStore = api.fn('settingsStore');
    const customWifeStore = api.fn('customWifeStore');
    const wifeBuilderDefaults = api.fn('wifeBuilderDefaults');
    const buildWifeArchetype = api.fn('buildWifeArchetype');
    const wifeArchetypeById = api.fn('wifeArchetypeById');
    const wifePreviewBundle = api.fn('wifePreviewBundle');
    const outfitById = api.fn('outfitById');
    const outfitList = api.has('outfitList') ? api.fn('outfitList') : null;
    const jsx = api.fn('jsx');
    const DEFAULT_WIFE_PREVIEW_NEGATIVE = String(wifePreviewBundle({
      id: '__attention_preview__',
      shortname: '__attention_preview__',
      imageBase: '',
    })?.negativePrompt || '').trim();
    const WIFE_PREVIEW_ONLY_NEGATIVE = 'nude, naked, breasts_out, nipples, lingerie, heavy armor, cloak hiding body, cropped, close-up';
    const previewOnlySuffix = `, ${WIFE_PREVIEW_ONLY_NEGATIVE}`;
    const DEFAULT_WIFE_CHARACTER_NEGATIVE = DEFAULT_WIFE_PREVIEW_NEGATIVE.endsWith(previewOnlySuffix)
      ? DEFAULT_WIFE_PREVIEW_NEGATIVE.slice(0, -previewOnlySuffix.length).trim()
      : DEFAULT_WIFE_PREVIEW_NEGATIVE;

    function normalizedWifeNegative(value) {
      const negative = String(value ?? '').trim();
      return negative === DEFAULT_WIFE_PREVIEW_NEGATIVE ? DEFAULT_WIFE_CHARACTER_NEGATIVE : negative;
    }

    const BAD_GUEST_FIELDS = [
      {
        key: 'badguest.handcuffed',
        label: '수갑 채움',
        value: 'hands_behind_back, wrists_bound_behind_back, handcuffed, metal_handcuffs, iron_chains, shackles, unable_to_move, struggling',
      },
      {
        key: 'badguest.blindfolded',
        label: '안대 착용',
        value: 'blindfolded, eyes covered, unable to see, tense posture',
      },
      {
        key: 'badguest.gagged',
        label: '입마개 착용',
        value: 'gagged, mouth gag, cloth gag, unable to speak',
      },
      {
        key: 'badguest.drugged',
        label: '미약 복용',
        value: 'drugged, dazed expression, unfocused eyes, flushed face, weak posture',
      },
      {
        key: 'badguest.hallucinated',
        label: '환각 상태',
        value: 'hypnotized, spiral eyes, swirling pupils, concentric spiral pupils, dazed smile, vacant expression, anime-style spiral eyes',
      },
    ];

    BAD_GUEST_FIELDS.push(
      {key:'badguest.confused',label:'착란·상대 오인',value:'dazed expression, unfocused gaze, confused expression'},
      {key:'badguest.intoxicated',label:'만취약 효과',value:'drunk, flushed face, unfocused eyes, unsteady posture'}
    );
    const DETAIL_FIELDS = [
      { key: 'status.energy.0', label: '기력 0–19', value: 'exhausted, weak posture, heavy eyelids' },
      { key: 'status.energy.1', label: '기력 20–39', value: 'tired, low energy' },
      { key: 'status.energy.2', label: '기력 40–59', value: '' },
      { key: 'status.energy.3', label: '기력 60–79', value: '' },
      { key: 'status.energy.4', label: '기력 80–100', value: '' },
      { key: 'status.mood.0', label: '기분 0–19', value: 'gloomy expression, deeply depressed' },
      { key: 'status.mood.1', label: '기분 20–39', value: 'sad expression, subdued mood' },
      { key: 'status.mood.2', label: '기분 40–59', value: '' },
      { key: 'status.mood.3', label: '기분 60–79', value: '' },
      { key: 'status.mood.4', label: '기분 80–100', value: '' },
      { key: 'status.arousal.0', label: '흥분도 0–19', value: '' },
      { key: 'status.arousal.1', label: '흥분도 20–39', value: 'slightly flushed, subtle arousal' },
      { key: 'status.arousal.2', label: '흥분도 40–59', value: 'flushed face, aroused' },
      { key: 'status.arousal.3', label: '흥분도 60–79', value: 'heavy breathing, highly aroused' },
      { key: 'status.arousal.4', label: '흥분도 80–100', value: 'deeply flushed, intense arousal, heavy breathing' },
      { key: 'status.wellbeing.0', label: '심신 상태 0–19', value: 'at the limit, physically and mentally exhausted' },
      { key: 'status.wellbeing.1', label: '심신 상태 20–39', value: 'unstable, visibly distressed' },
      { key: 'status.wellbeing.2', label: '심신 상태 40–59', value: 'weary, strained expression' },
      { key: 'status.wellbeing.3', label: '심신 상태 60–79', value: '' },
      { key: 'status.wellbeing.4', label: '심신 상태 80–100', value: '' },
      { key: 'status.allure.high', label: '주목도 60 이상', value: 'alluring pose, captivating presence' },
      { key: 'status.trust.low', label: '신뢰 30 미만', value: 'guarded expression, emotionally distant' },
      { key: 'status.desire.high', label: '애정·욕망 60 이상', value: 'longing gaze, affectionate expression' },
      { key: 'status.resentment.medium', label: '원망도 35–59', value: 'resentful expression' },
      { key: 'status.resentment.high', label: '원망도 60 이상', value: 'deep resentment, hostile expression' },
      { key: 'status.drift.high', label: '심적 이탈 35 이상', value: 'emotionally distant, averted gaze' },
      { key: 'status.latitude.negative', label: '허용 인식 0 미만', value: 'uneasy expression, conflicted' },
      { key: 'status.intoxication.tipsy', label: '취기 · 살짝 취함', value: 'tipsy, faint blush' },
      { key: 'status.intoxication.drunk', label: '취기 · 취함', value: 'drunk, flushed face, unsteady posture' },
      { key: 'status.intoxication.wasted', label: '취기 · 만취', value: 'heavily drunk, dazed expression, unsteady posture' },
      { key: 'status.intoxication.sloppy', label: '취기 · 몸을 못 가눔', value: 'extremely drunk, unfocused eyes, unable to stand steadily' },
      { key: 'status.intoxication.blacked_out', label: '취기 · 의식 없음', value: 'unconscious, limp body' },
      {
        key: 'status.feelings.map',
        label: '강한 감정 매핑',
        rows: 9,
        hint: '한 줄에 상태키=프롬프트. 강도 15를 넘는 상위 감정 2개에 적용합니다.',
        value: [
          'anger=angry expression',
          'contempt=contemptuous expression',
          'disgust=disgusted expression',
          'sadness=sad expression',
          'shame=embarrassed, downcast eyes',
          'guilt=guilty expression',
          'regret=regretful expression',
          'humiliation=humiliated expression',
          'tenderness=tender expression',
          'longing=yearning gaze',
          'desire=desirous expression',
          'arousal_buzz=flushed face',
        ].join('\n'),
      },
      {
        key: 'status.drives.map',
        label: '가장 강한 욕구 매핑',
        rows: 7,
        hint: '한 줄에 상태키=프롬프트. 수치 35를 넘는 가장 강한 욕구에 적용합니다.',
        value: [
          'financial=worried expression',
          'approval=seeking approval',
          'desire=longing gaze',
          'security=anxious expression',
          'social=lonely expression',
          'pride=proud posture',
          'longing=yearning expression',
        ].join('\n'),
      },
    ];

    const FLUID_PARTS = [
      {
        part: 'mouth', label: '입', statuses: ['없음', '흔적이 남음', '묻어 있음', '많이 묻어 있음', '넘쳐남'],
        values: ['', 'cum_in_mouth', 'cum_in_mouth, cum_on_tongue', 'cum_in_mouth, cum_on_tongue, cum_dripping_from_mouth', 'cum_in_mouth, cum_on_tongue, cum_dripping_from_mouth, excessive_cum'],
      },
      {
        part: 'breasts', label: '가슴', statuses: ['없음', '흔적이 남음', '묻어 있음', '많이 묻어 있음', '넘쳐남'],
        values: ['', 'cum_on_breasts', 'cum_on_breasts, cum_on_chest', 'cum_on_breasts, cum_on_chest, excessive_cum', 'cum_on_breasts, cum_on_chest, excessive_cum, dripping_cum'],
      },
      {
        part: 'uterus', label: '자궁', statuses: ['없음', '질내 잔류', '자궁 내 일부', '가득참', '넘쳐남'],
        values: ['', 'creampie', 'creampie, cum_in_pussy', 'creampie, cum_in_pussy, excessive_cum', 'creampie, cum_in_pussy, overflowing_creampie'],
      },
      {
        part: 'vulva', label: '보지', statuses: ['건조함', '은은하게 젖음', '애액이 맺힘', '허벅지 안쪽까지 흐름', '애액이 허벅지를 타고 흐름'],
        values: ['', 'slightly_wet_pussy', 'wet_pussy, pussy_juice', 'wet_pussy, pussy_juice, pussy_juice_dripping', 'wet_pussy, excessive_pussy_juice, pussy_juice_dripping'],
      },
      {
        part: 'thighs', label: '허벅지', statuses: ['없음', '흔적이 남음', '묻어 있음'],
        values: ['', 'cum_on_thighs', 'cum_on_thighs, cum_dripping_thighs'],
      },
    ];
    const FLUID_FIELDS = FLUID_PARTS.flatMap(({ part, label, statuses, values }) => statuses.map((status, tier) => ({
      key: `fluid.${part}.${tier}`,
      label: `${label} · ${status}`,
      value: values[tier],
    })));
    const JEWELRY_FIELDS = [
      { key: 'jewelry.breasts.0', label: '가슴 · 장신구 없음', value: '' },
      { key: 'jewelry.breasts.1', label: '가슴 · 좌측 유두 피어싱', value: 'nipple_piercing, single_nipple_piercing' },
      { key: 'jewelry.breasts.2', label: '가슴 · 양쪽 유두 피어싱', value: 'nipple_piercing, pierced_nipples' },
      { key: 'jewelry.breasts.3', label: '가슴 · 양쪽 유두 피어싱 · 하트 초커', value: 'nipple_piercing, pierced_nipples, heart_choker' },
      { key: 'jewelry.vulva.0', label: '보지 · 장신구 없음', value: '' },
      { key: 'jewelry.vulva.1', label: '보지 · 클리 피어싱', value: 'clitoris_piercing, genital_piercing' },
    ];
    const POSITION_PRESET_GROUPS = [
      {
        title: '기본 자세', presets: [
          { id: 'none', name: '적용 안함', prompt: '' },
          { id: 'standing', name: '서 있기', prompt: 'standing, full body' },
          { id: 'sitting', name: '마주 앉기', prompt: 'sitting, facing another' },
          { id: 'kneeling', name: '무릎 꿇기', prompt: 'kneeling, looking up' },
          { id: 'lying-back', name: '바로 눕기', prompt: 'lying on back, on bed' },
          { id: 'all-fours', name: '네발 자세', prompt: 'on all fours, ass up' },
          { id: 'close-embrace', name: '마주보고 밀착', prompt: 'face-to-face, close embrace, bodies pressed together, standing, arms around partner, intimate contact', negativePrompt: 'back-to-back, facing away, from behind, separated bodies' },
          { id: 'back-hug', name: '백허그', prompt: 'back hug, standing, embracing from behind, bodies pressed together, arms around waist', negativePrompt: 'face-to-face, front embrace, separated bodies' },
          { id: 'lap-back-hug', name: '무릎 위에서 백허그', prompt: "sitting on partner's lap, back hug, embracing from behind, bodies pressed together, seated, lap sitting", negativePrompt: 'standing, face-to-face, front embrace, separated bodies' },
        ],
      },
      {
        title: '삽입 체위', presets: [
          { id: 'missionary', name: '정상위', prompt: 'missionary position, vaginal sex, lying on back, legs spread, face-to-face' },
          { id: 'cowgirl', name: '기승위', prompt: 'cowgirl position, vaginal sex, girl on top, straddling, facing another' },
          { id: 'reverse-cowgirl', name: '역기승위', prompt: 'reverse cowgirl position, vaginal sex, girl on top, straddling, facing away' },
          { id: 'doggystyle', name: '후배위', prompt: 'doggystyle, vaginal sex, on all fours, sex from behind' },
          { id: 'spooning', name: '측위', prompt: 'spooning position, vaginal sex, lying on side, sex from behind' },
          { id: 'standing-sex', name: '입위', prompt: 'standing sex, vaginal sex, standing, sex from behind' },
          { id: 'mating-press', name: '굴곡위', prompt: 'mating press, vaginal sex, lying on back, legs raised' },
          { id: 'prone-bone', name: '복와위', prompt: 'prone bone, vaginal sex, lying face down, sex from behind' },
          { id: 'ekiben', name: '에키벤 (Ekiben)', prompt: 'ekiben position, standing sex, lifted girl, legs wrapped around partner, arms around neck, face-to-face, vaginal sex', negativePrompt: 'feet on ground, lying down, sitting, doggystyle' },
          { id: 'daisuki-hold', name: '다이스키 홀드 (Daisuki Hold)', prompt: 'daisuki hold, mating press, legs wrapped around partner, face-to-face, vaginal sex, lying on back', negativePrompt: 'from behind, standing, legs lowered, doggystyle' },
          { id: 'full-nelson', name: '풀 넬슨 (Full Nelson)', prompt: 'full nelson position, full nelson hold, seated sex, legs spread and raised, vaginal sex, restrained arms', negativePrompt: 'lying down, standing, arms free, doggystyle' },
          { id: 'double-penetration', name: '이중 삽입 (Double Penetration)', prompt: 'double penetration, vaginal and anal penetration, one penis in pussy, one penis in anus, group sex, 2boys', negativePrompt: 'single male, solo male, only vaginal penetration, only anal penetration' },
        ],
      },
      {
        title: '구강·손', presets: [
          { id: 'kneeling-fellatio', name: '무릎 구강성교', prompt: 'fellatio, kneeling, looking up' },
          { id: 'cunnilingus', name: '커닐링구스', prompt: 'cunnilingus, lying on back, legs spread' },
          { id: 'sixty-nine', name: '69', prompt: '(69 position:1.2), mutual oral sex, lying on side' },
          { id: 'seated-handjob', name: '앉은 수음', prompt: 'handjob, sitting, facing another' },
          { id: 'paizuri', name: '파이즈리', prompt: 'paizuri, breast press, kneeling, looking up' },
          { id: 'deep-throat', name: '깊이 빨기 (Deep Throat)', prompt: 'deepthroat, penis deep in throat, oral sex, kneeling, looking up', negativePrompt: 'shallow fellatio, licking penis, penis outside mouth' },
          { id: 'irrumatio-front', name: '이라마치오 (Throat Fuck in Front)', prompt: 'irrumatio, throat fucking, facefuck, standing male, kneeling girl, front view, penis in throat', negativePrompt: 'handjob only, shallow fellatio, penis outside mouth, from behind' },
          { id: 'upside-down-facefuck', name: '눕혀서 이라마치오 (Upside Down Facefuck)', prompt: 'upside-down facefuck, lying on back, head hanging off bed, inverted oral sex, throat fucking, penis in throat', negativePrompt: 'upright, kneeling, sitting, penis outside mouth' },
        ],
      },
    ];
    const POSITION_PRESETS = Object.fromEntries(POSITION_PRESET_GROUPS.flatMap(group => group.presets).map(preset => [preset.id, preset]));
    const GROUP_SLOT_OPTIONS = [
      { id: 'm', name: '입', prompt: '(positioned at her mouth:1.0), (fellatio:1.1), penis_in_mouth, oral_focus' },
      { id: 'h', name: '손', prompt: '(positioned at her side:1.0), (handjob:1.1), penis_in_hand, hand_focus' },
      { id: 'b', name: '가슴', prompt: '(positioned at her chest:1.0), (paizuri:1.1), breast_sex, breast_focus' },
      { id: 'x', name: '후방', prompt: '(positioned behind her:1.0), (sex_from_behind:1.1), doggystyle, rear_view' },
      { id: 'r', name: '마찰', prompt: '(pressed against her body:1.0), (penis_rubbing:1.1), grinding, body_contact' },
      { id: 'i', name: '질 삽입', prompt: '(positioned between her legs:1.0), (vaginal_sex:1.1), penis_in_pussy, penetration' },
      { id: 'a', name: '항문 삽입', prompt: '(positioned behind her:1.0), (anal_sex:1.1), penis_in_ass, anal_penetration' },
      { id: 'w', name: '관전', prompt: '(standing in background:0.95), (watching:1.05), voyeur, looking_at_sex' },
    ];
    const GROUP_SLOT_BY_ID = Object.fromEntries(GROUP_SLOT_OPTIONS.map(option => [option.id, option]));
    const POSITION_PART_LABELS = new Set(['장면', '자세', '작업', 'Scene', 'Pose', 'Action']);
    const COMPOSITION_TAB = {
      id: 'composition',
      title: '구도 프롬프트',
      note: '모든 ImageStudio 이미지에 공통으로 덧붙일 카메라 거리·시점·프레이밍 태그입니다. 상황 프리셋마다 Positive와 Negative를 따로 저장할 수 있습니다.',
      fields: [{
        key: 'composition.global',
        label: '전체 구도',
        rows: 4,
        hint: '예: full body, wide shot, eye-level view. 빈 값이면 기존 구도를 그대로 사용합니다.',
        value: '',
      }],
    };
    const FIELD_GROUPS = [
      { id: 'badguest', title: '나쁜 손님 모드용', note: 'badguest의 실제 수갑·약물 상태를 자동으로 읽습니다. 환각제는 소용돌이 눈 효과를 별도 이미지 상태로 만듭니다.', fields: BAD_GUEST_FIELDS },
      { id: 'detail', title: '상세 상태', note: 'mt-2 pt-2 border-t border-stone-800 영역의 구조화된 상태를 사용합니다.', fields: DETAIL_FIELDS },
      { id: 'h-status', title: 'H Status', note: 'ko-se-fluid-section의 부위·장신구 상태입니다. H Status가 없어도 이 모드는 정상 작동합니다.', fields: [...FLUID_FIELDS, ...JEWELRY_FIELDS] },
    ];
    const DIALOGUE_TAB = { id: 'dialogue', title: '대화 감지', note: 'text-sm 대화 영역에 원하는 문구가 포함되면 설정한 프롬프트를 추가합니다.' };
    const CHARACTER_TAB = { id: 'character', title: '아내 캐릭터', note: '현재 아내에게 적용 중인 전체 외형 프롬프트를 불러오거나 직접 수정해 기본 외형 묶음을 교체합니다.' };
    const OUTFIT_TAB = { id: 'outfit-prompts', title: '의상 프롬프트', note: '게임과 다른 모드가 등록한 의상의 전체 Positive·Negative 프롬프트를 불러와 교체합니다.' };
    const SITUATION_PRESET_TAB = { id: 'situation-presets', title: '상황 프리셋', note: '상황·상태·H Status·대화 프롬프트 묶음을 여러 개 저장하고 캐릭터별로 하나만 적용합니다.' };
    const POSITION_TAB = { id: 'positions', title: '장면별 세부 조정', note: '선택한 자세와 Positive·Negative는 검수용 수동 생성에만 사용합니다. 게임 중 장면에는 고정하지 않습니다.' };
    const DIAGNOSTICS_TAB = { id: 'diagnostics', title: '동작 진단', note: '모드 파일·이미지팩·이미지 생성기 연결과 최근 이미지 처리 기록을 확인합니다.' };
    const SETTINGS_TABS = [CHARACTER_TAB, OUTFIT_TAB, SITUATION_PRESET_TAB, COMPOSITION_TAB, POSITION_TAB, ...FIELD_GROUPS, DIALOGUE_TAB, DIAGNOSTICS_TAB];
    const LEGACY_SITUATION_PRESET_ID = 'default';
    const MAX_SITUATION_PRESETS = 50;
    const DEFAULT_PROMPTS = Object.fromEntries([...COMPOSITION_TAB.fields, ...FIELD_GROUPS.flatMap(group => group.fields)].map(field => [field.key, field.value]));
    const DEFAULT_NEGATIVE_PROMPTS = {
      ...Object.fromEntries(Object.keys(DEFAULT_PROMPTS).map(key => [key, ''])),
      'badguest.handcuffed': 'handcuffed boys, restrained boys, male handcuffs, male shackles, chains on male wrists, boys with bound hands, boys with hands tied, handcuffs on both genders, smile',
      'badguest.blindfolded': 'blindfolded boys, blindfolded male, eyes covered on male, blindfolds on both genders',
      'badguest.gagged': 'gagged boys, gagged male, mouth gag on male, gags on both genders',
      'badguest.drugged': 'drugged boys, dazed male, unconscious male',
      'badguest.hallucinated': 'normal pupils, sharp focused eyes, alert expression',
    };
// 내장 상황 프롬프트 코드의 DEFAULT_PROMPTS 생성 직후 실행합니다.
// 상세 상태는 빈 기본값으로 시작하고, 사용자가 입력한 문구만 적용합니다.
const ImageStudio_기존상태필드 = [...DETAIL_FIELDS];
const ImageStudio_기존상태Positive = Object.fromEntries(ImageStudio_기존상태필드.map(field => [field.key, field.value]));
const ImageStudio_기존상태Negative = Object.fromEntries(ImageStudio_기존상태필드.map(field => [field.key, DEFAULT_NEGATIVE_PROMPTS[field.key] || '']));
for (const field of ImageStudio_기존상태필드) {
  field.value = '';
  DEFAULT_PROMPTS[field.key] = '';
  DEFAULT_NEGATIVE_PROMPTS[field.key] = '';
}

function ImageStudio_기존상태기본값비우기(value, previous) {
  const next = value && typeof value === 'object' && !Array.isArray(value) ? { ...value } : {};
  for (const [key, oldDefault] of Object.entries(previous)) {
    if (!Object.prototype.hasOwnProperty.call(next, key) || next[key] === oldDefault) next[key] = '';
  }
  return next;
}

function ImageStudio_대응필요설정지우기(value, section) {
  const next = value && typeof value === 'object' && !Array.isArray(value) ? { ...value } : {};
  for (const key of Object.keys(next)) if (key.startsWith('attention.')) delete next[key];
  const previousHandcuff = next['restraint.handcuffed'];
  if (!Object.prototype.hasOwnProperty.call(next, 'badguest.handcuffed')) {
    if (section === 'outfitStates' && Array.isArray(previousHandcuff)) next['badguest.handcuffed'] = [...previousHandcuff];
    else if (typeof previousHandcuff === 'string' && previousHandcuff.trim()) next['badguest.handcuffed'] = previousHandcuff;
  }
  delete next['restraint.handcuffed'];
  return next;
}

function ImageStudio_상황프리셋이전하기(preset, emptyStatusDefaults) {
  if (!preset || typeof preset !== 'object' || Array.isArray(preset)) return preset;
  let prompts = ImageStudio_대응필요설정지우기(preset.prompts, 'prompts');
  let negativePrompts = ImageStudio_대응필요설정지우기(preset.negativePrompts, 'negativePrompts');
  if (emptyStatusDefaults) {
    prompts = ImageStudio_기존상태기본값비우기(prompts, ImageStudio_기존상태Positive);
    negativePrompts = ImageStudio_기존상태기본값비우기(negativePrompts, ImageStudio_기존상태Negative);
  }
  return {
    ...preset,
    prompts,
    negativePrompts,
    outfitStates: ImageStudio_대응필요설정지우기(preset.outfitStates, 'outfitStates'),
  };
}

const ImageStudio_상태설정 = api.settings.get({
  statusPromptsEmptyDefaultsV1: false, attentionPromptsRemovedV1: false,
  prompts: {}, negativePrompts: {}, outfitStates: {}, situationPresets: [],
});
if (!ImageStudio_상태설정.statusPromptsEmptyDefaultsV1 || !ImageStudio_상태설정.attentionPromptsRemovedV1) {
  const emptyStatusDefaults = !ImageStudio_상태설정.statusPromptsEmptyDefaultsV1;
  let prompts = ImageStudio_대응필요설정지우기(ImageStudio_상태설정.prompts, 'prompts');
  let negativePrompts = ImageStudio_대응필요설정지우기(ImageStudio_상태설정.negativePrompts, 'negativePrompts');
  if (emptyStatusDefaults) {
    prompts = ImageStudio_기존상태기본값비우기(prompts, ImageStudio_기존상태Positive);
    negativePrompts = ImageStudio_기존상태기본값비우기(negativePrompts, ImageStudio_기존상태Negative);
  }
  api.settings.set({
    prompts,
    negativePrompts,
    outfitStates: ImageStudio_대응필요설정지우기(ImageStudio_상태설정.outfitStates, 'outfitStates'),
    situationPresets: Array.isArray(ImageStudio_상태설정.situationPresets)
      ? ImageStudio_상태설정.situationPresets.map(preset => ImageStudio_상황프리셋이전하기(preset, emptyStatusDefaults))
      : ImageStudio_상태설정.situationPresets,
    statusPromptsEmptyDefaultsV1: true,
    attentionPromptsRemovedV1: true,
  });
}

    const OUTFIT_STATE_OPTIONS = [
      ['clothed', '일반 착의'],
      ['partial', '부분 착의·속옷'],
      ['nude', '나체·장신구만'],
    ];
    const EXPOSED_OUTFIT_STATE = ['exposed', '해당 부위가 노출된 경우'];
    const ALL_OUTFIT_STATES = OUTFIT_STATE_OPTIONS.map(([value]) => value);
    const EXPOSED_DEFAULT_PARTS = new Set(['breasts', 'thighs', 'vulva']);
    const usesExposedDefault = key => EXPOSED_DEFAULT_PARTS.has(String(key).match(/^(?:fluid|jewelry)\.([^.]+)/)?.[1]);
    const DEFAULT_OUTFIT_STATE_OVERRIDES = {
      'status.energy.3': ['partial', 'nude'],
      'fluid.uterus.0': ['nude', 'partial', 'clothed'],
      'fluid.uterus.1': [EXPOSED_OUTFIT_STATE[0]],
      'fluid.uterus.2': [EXPOSED_OUTFIT_STATE[0]],
      'fluid.uterus.3': [EXPOSED_OUTFIT_STATE[0]],
      'fluid.uterus.4': [EXPOSED_OUTFIT_STATE[0]],
    };
    const DEFAULT_OUTFIT_STATES = Object.fromEntries(Object.keys(DEFAULT_PROMPTS).map(key => [
      key,
      DEFAULT_OUTFIT_STATE_OVERRIDES[key]
        || (usesExposedDefault(key) ? [EXPOSED_OUTFIT_STATE[0]] : [...ALL_OUTFIT_STATES]),
    ]));
    const DEFAULT_DIALOGUE_RULES = [
      {
        id: 'dialogue-muzqz0av-1',
        text: '잠시 뒤 목덜미와 가슴 안쪽부터 설명하기 어려운 열기가 천천히 번지기 시작합니다',
        positivePrompt: 'blush, dazed expression', negativePrompt: '', duration: 'minutes', minutes: 120,
        outfitStates: [...ALL_OUTFIT_STATES],
      },
      {
        id: 'dialogue-muzxq0xh-2',
        text: '끝내 압박을 떨쳐내지 못하고 마십니다',
        positivePrompt: 'blush, dazed expression', negativePrompt: '', duration: 'minutes', minutes: 120,
        outfitStates: [...ALL_OUTFIT_STATES],
      },
      {
        id: 'dialogue-muzyywtf-3',
        text: '저항을 눌러 버리고',
        positivePrompt: 'tears, scared', negativePrompt: '', duration: 'scene', minutes: 10,
        outfitStates: [...ALL_OUTFIT_STATES],
      },
    ];
    const DEFAULT_FLUID_DECAY = { enabled: true, intervalMinutes: 120 };
    const DEFAULT_CHARACTER_PROMPT = { positivePrompt: '', negativePrompt: '', mode: 'replace', imagePolicy: 'reuse' };
    const BUILTIN_WIFE_PROMPT_SOURCES = [
      ['elena_farmgirl', '엘레나'], ['mara_citygirl', '마라'], ['pippa_waif', '피파'],
    ];
    const EXTRA_LINES_DIALOGUE_SOURCES = [
      ['elena_farmgirl', '엘레나 대사'], ['mara_citygirl', '마라 대사'], ['pippa_waif', '피파 대사'], ['', '추가 대사 사용 안 함'],
    ];
    const OUTFIT_COLOR_OPTIONS = [
      ['', '선택 안 함'], ['black', '검정'], ['white', '흰색'], ['gray', '회색'], ['silver', '은색'],
      ['beige', '베이지'], ['cream', '크림색'], ['brown', '갈색'], ['red', '빨강'], ['burgundy', '버건디'],
      ['orange', '주황'], ['yellow', '노랑'], ['green', '초록'], ['blue', '파랑'], ['navy', '남색'],
      ['purple', '보라'], ['pink', '분홍'], ['gold', '금색'],
    ];
    const PROMPT_TAG_KO = {
      masterpiece: '최고 수준 작품', 'best quality': '최고 품질', portrait: '인물화', 'upper body': '상반신', 'full body': '전신',
      'worst quality': '최저 품질', 'low quality': '낮은 품질', blurry: '흐릿함', 'bad anatomy': '잘못된 인체 구조',
      'extra limbs': '팔다리 추가', deformed: '기형', text: '문자', watermark: '워터마크', signature: '서명', ugly: '추함',
      duplicate: '중복 인물', morbid: '병적인 표현', mutilated: '훼손된 신체', '3d': '3D', realistic: '실사풍', photorealistic: '사진 같은 실사풍',
      '1girl': '여성 1명', '2girls': '여성 2명', 'multiple girls': '여성 여러 명', solo: '단독 인물', solo_focus: '한 인물에 초점',
      kisaragi_chihaya: '치하야',
      '1boy': '남성 1명', '2boys': '남성 2명', '3boys': '남성 3명', '4boys': '남성 4명', '5boys': '남성 5명',
      'long dark hair': '긴 짙은 머리', 'brown eyes': '갈색 눈', 'medium breasts': '중간 크기 가슴', 'slim waist': '잘록한 허리',
      'silver hair': '은빛 머리', 'green eyes': '초록색 눈', 'looking at viewer': '정면을 바라봄', 'looking at another': '다른 사람을 바라봄',
      faceless_male: '얼굴이 보이지 않는 남성', 'bright eyes': '생기 있는 눈', 'tired eyes': '피곤한 눈', 'soft eyes': '부드러운 눈빛',
      'white blouse': '흰 블라우스', 'buttoned up': '단추를 끝까지 잠금', 'high neckline': '목까지 올라오는 옷깃', 'long sleeves': '긴소매',
      'full-length skirt': '발목 길이 치마', apron: '앞치마', 'top button undone': '윗단추를 풀어 둠', 'collarbone visible': '쇄골이 보임',
      'fitted bodice': '몸에 맞는 보디스', 'knee-length skirt': '무릎 길이 치마', 'low neckline blouse': '깊게 파인 블라우스',
      cleavage: '가슴골', corset: '코르셋', 'skirt above knee': '무릎 위 치마', 'very low-cut top': '매우 깊게 파인 상의',
      'tight corset': '꽉 조인 코르셋', 'very short skirt': '매우 짧은 치마', 'bare shoulders': '드러난 어깨', 'bare legs': '맨다리',
      'lace lingerie': '레이스 란제리', 'see-through': '비치는 옷', stockings: '스타킹', 'garter belt': '가터벨트',
      nude: '나체', naked: '알몸', 'bare skin': '맨살', disheveled: '헝클어진 옷차림', 'pulled down': '아래로 내려간 옷',
      'exposed breasts': '드러난 가슴', 'skirt hiked up': '걷어 올린 치마', 'clothes pulled aside': '옆으로 젖힌 옷',
      'plain linen shift': '수수한 린넨 슈미즈', 'sleeves rolled up': '걷어 올린 소매', hair_up: '올림머리', nightshift: '잠옷',
      'bright smile': '환한 미소', cheerful: '쾌활함', energetic: '활기참', 'gentle smile': '부드러운 미소', content: '만족스러움',
      'calm expression': '차분한 표정', focused: '집중함', 'weary expression': '지친 표정', 'worried expression': '걱정스러운 표정',
      tense: '긴장함', 'furrowed brow': '찌푸린 눈썹', smile: '미소', interested: '관심을 보임', blush: '홍조',
      'playful smile': '장난스러운 미소', shy: '수줍음', flustered: '당황함', 'looking away': '시선을 돌림', surprised: '놀람',
      seductive: '유혹적인 분위기', 'half-lidded eyes': '게슴츠레한 눈', pleasure: '쾌감', 'closed eyes': '눈을 감음', closed_eyes: '눈을 감음',
      'lost in it': '쾌감에 몰입함', 'parted lips': '살짝 벌어진 입술', 'looking up': '올려다봄', tears: '눈물', drooling: '침 흘림',
      moaning: '신음함', panting: '헐떡임', nervous: '긴장함', gripping: '꽉 붙잡음', confident: '자신감 있음',
      'rolling hips': '허리를 움직임', sweating: '땀 흘림', intense: '격렬함', overwhelmed: '압도됨', messy: '흐트러짐',
      afterglow: '여운에 잠김', satisfied: '만족한 표정', scared: '두려워함', 'wide eyes': '눈을 크게 뜸', troubled: '심란함', downcast: '고개를 숙임',
      'tavern interior': '선술집 내부', 'wooden tables': '나무 탁자', candlelight: '촛불', 'medieval tavern background': '중세 선술집 배경',
      'warm candlelight': '따뜻한 촛불', 'upstairs hall': '위층 복도', 'narrow wood corridor': '좁은 나무 복도', 'single sconce': '벽등 하나',
      'low light': '어두운 조명', hallway: '복도', indoors: '실내', bedroom: '침실', bed: '침대', 'single candle': '촛불 하나',
      'intimate lighting': '은은하고 사적인 조명', private: '사적인 공간', kitchen: '부엌', hearth: '화덕', steam: '수증기', firelight: '불빛',
      'warm lighting': '따뜻한 조명', 'soft morning light': '부드러운 아침 햇빛', 'dim bedroom light': '어두운 침실 조명',
      '1girl in bathtub': '욕조 안 여성 1명', ass: '엉덩이', breasts_out: '가슴 노출', crossdressing: '이성 복장',
      'girl bathing': '목욕 중인 여성', 'girl in tub': '욕조 안 여성', nipples: '유두', 'otoko no ko': '여장 남성', pussy: '여성기',
      'round porcelain basin': '둥근 도자기 욕조', 'toilet bowl': '변기', toilet: '화장실 설비', '1girl only': '여성 1명만', '3girls': '여성 3명',
      'bad proportions': '잘못된 신체 비율', bald: '대머리', 'bare forearms': '드러난 팔뚝', beard: '수염', biting_own_lip: '자기 입술을 깨묾',
      'booming presence': '압도적인 존재감', bottomless: '하의 없음', 'boyish face': '소년 같은 얼굴', 'breath uneven': '고르지 않은 숨',
      'breathing hard': '거칠게 숨 쉼', 'broad shoulders': '넓은 어깨', 'bushy beard': '덥수룩한 수염', 'clean-shaven': '면도한 얼굴',
      'cloak hiding body': '몸을 가리는 망토', 'close-up': '클로즈업', 'crooked nose': '휘어진 코', cropped: '잘린 구도', crowd: '군중',
      'cum on clothes': '옷에 묻은 정액', 'cum on dress': '드레스에 묻은 정액', 'cum on floor': '바닥에 묻은 정액',
      'cum on furniture': '가구에 묻은 정액', 'cum on table': '탁자에 묻은 정액', 'curly brown hair': '곱슬 갈색 머리',
      'dark beard': '짙은 수염', 'deep-set eyes': '깊게 들어간 눈', dignified: '품위 있음', 'distracted expression': '집중이 흐트러진 표정',
      'eager expression': '적극적인 표정', 'exposed ass': '드러난 엉덩이', freckles: '주근깨', gangbang: '다인 성행위', 'gaunt face': '수척한 얼굴',
      'girl in water': '물속의 여성', 'girl partially submerged': '몸 일부를 물에 담근 여성', 'group sex': '집단 성행위',
      'half-closed eyes': '반쯤 감긴 눈', 'half-closed_eyes': '반쯤 감긴 눈', head_back: '고개를 뒤로 젖힘', 'heavy armor': '중갑',
      'heavyset man': '덩치 큰 남성', intimidating: '위압적임', 'jolly expression': '유쾌한 표정', 'kind eyes': '인자한 눈빛',
      'lean man': '마른 남성', 'legs trembling': '다리가 떨림', 'long beard': '긴 수염', 'male in dress': '드레스를 입은 남성',
      'male in lingerie': '란제리를 입은 남성', 'male wearing skirt': '치마를 입은 남성', 'man in sheer clothing': '비치는 옷을 입은 남성',
      'matching outfits': '맞춰 입은 옷', 'merchant clothes': '상인 복장', 'messy hair': '헝클어진 머리', mmf_threesome: '남성 2명과 여성 1명',
      'modest cleavage': '살짝 보이는 가슴골', moustache: '콧수염', 'multiple views': '여러 시점', 'narrow eyes': '가늘게 뜬 눈',
      'neutral expression': '중립적인 표정', nightgown: '잠옷 드레스', 'no panties': '팬티 없음', 'panties aside': '팬티를 옆으로 젖힘',
      'practical boots': '실용적인 부츠', 'revealing clothing': '노출이 많은 옷', 'rough face': '거친 얼굴', 'rough hands': '거친 손',
      'round face': '둥근 얼굴', 'sandy hair': '모래빛 머리', 'scars on face': '얼굴 흉터', 'self-pleasure': '자위',
      'sharp features': '날카로운 이목구비', 'simple medieval tavern dress': '수수한 중세 선술집 드레스', 'sitting in basin': '욕조 안에 앉음',
      skirt_lift: '치마를 들어 올림', 'slight flush': '옅은 홍조', 'split screen': '분할 화면', 'square jaw': '각진 턱',
      'staring at cum': '정액을 바라봄', 'stocky man': '다부진 남성', stubble: '짧은 수염', 'sturdy build': '튼튼한 체격',
      'tall thin man': '키 크고 마른 남성', 'thighs pressed together': '허벅지를 붙임', 'thin frame': '마른 체격', threesome: '3인 성행위',
      'tight expression': '긴장으로 굳은 표정', 'top pulled down': '상의가 아래로 내려감', 'traveler clothes': '여행자 복장',
      'troubled expression': '심란한 표정', 'weathered face': '풍파를 겪은 얼굴', 'white porcelain tub': '흰 도자기 욕조',
      'working class': '노동자 계층', wrinkled: '주름진',
      standing: '서 있음', relaxed: '편안함', sitting: '앉아 있음', on_bed: '침대 위', 'welcoming gesture': '반기는 손짓',
      'friendly smile': '친근한 미소', 'tavern entrance': '선술집 입구', 'listening attentively': '주의 깊게 들음', 'notepad in hand': '손에 주문장을 듦',
      'carrying tray': '쟁반을 나름', alcohol: '술', 'busy tavern': '붐비는 선술집', 'wiping table': '탁자를 닦음', cleaning: '청소 중',
      'stirring pot': '냄비를 저음', 'sleeping peacefully': '평온하게 잠듦', 'lying in bed': '침대에 누움', 'head on pillow': '베개에 머리를 댐',
      'blanket pulled up': '이불을 끌어올림', 'passed out': '의식을 잃음', 'drunk and sleeping': '취해 잠듦', 'mouth slightly open': '입을 살짝 벌림',
      'slack body': '축 늘어진 몸', 'limp limbs': '힘없이 늘어진 팔다리', 'unconscious at the bar': '술집에서 의식을 잃음', open_mouth: '입을 벌림',
      'flushed cheeks': '붉어진 볼', 'pink cheeks': '분홍빛 볼', 'slight smile': '옅은 미소', 'glassy eyes': '풀린 눈', unsteady: '비틀거림',
      'very drunk': '매우 취함', 'unfocused gaze': '초점 없는 시선', leaning: '기댐', 'slack mouth': '힘없이 벌어진 입', 'half-conscious': '반쯤 의식이 없음',
      slumped: '축 처짐', 'drooping eyelids': '감기는 눈꺼풀', 'head down on table': '탁자에 고개를 떨굼', limp: '축 늘어짐',
      'tense atmosphere': '긴장된 분위기', 'urgent situation': '긴급한 상황', 'alert expression': '경계하는 표정',
      'secret encounter': '비밀스러운 만남', 'furtive atmosphere': '은밀한 분위기', 'cautious expression': '조심스러운 표정',
      'tense confrontation': '긴장된 대치', 'defensive posture': '방어적인 자세', 'distressed expression': '괴로운 표정',
      exhausted: '기진맥진', 'weary expression': '지친 표정', 'slumped posture': '축 처진 자세',
      hands_behind_back: '양손을 등 뒤로', wrists_bound_behind_back: '손목을 등 뒤로 묶음', handcuffed: '수갑을 참',
      metal_handcuffs: '금속 수갑', iron_chains: '쇠사슬', shackles: '족쇄', unable_to_move: '움직일 수 없음', struggling: '몸부림침',
      'weak posture': '힘없는 자세', 'heavy eyelids': '무거운 눈꺼풀', tired: '피곤함', 'low energy': '기력 저하',
      'gloomy expression': '우울한 표정', 'deeply depressed': '심하게 침울함', 'sad expression': '슬픈 표정', 'subdued mood': '가라앉은 분위기',
      'slightly flushed': '살짝 붉어진 얼굴', 'subtle arousal': '은은한 흥분', 'flushed face': '붉어진 얼굴', aroused: '흥분함',
      'heavy breathing': '거친 숨', 'highly aroused': '매우 흥분함', 'deeply flushed': '짙게 붉어진 얼굴', 'intense arousal': '강한 흥분',
      'at the limit': '한계 상태', 'physically and mentally exhausted': '심신이 지침', unstable: '불안정함',
      'visibly distressed': '눈에 띄게 괴로워함', weary: '지침', 'strained expression': '힘겨운 표정',
      'alluring pose': '매혹적인 자세', 'captivating presence': '시선을 끄는 분위기', 'guarded expression': '경계하는 표정',
      'emotionally distant': '정서적으로 멀어짐', 'longing gaze': '갈망하는 눈빛', 'affectionate expression': '애정 어린 표정',
      'resentful expression': '원망하는 표정', 'deep resentment': '깊은 원망', 'hostile expression': '적대적인 표정',
      'averted gaze': '시선을 피함', 'uneasy expression': '불편한 표정', conflicted: '갈등함', tipsy: '살짝 취함',
      'faint blush': '옅은 홍조', drunk: '취함', 'unsteady posture': '비틀거리는 자세', 'heavily drunk': '만취함',
      'dazed expression': '멍한 표정', 'extremely drunk': '몸을 못 가눌 정도로 취함', 'unfocused eyes': '초점 없는 눈',
      'unable to stand steadily': '제대로 서지 못함', unconscious: '의식 없음', 'limp body': '축 늘어진 몸',
      'angry expression': '화난 표정', 'contemptuous expression': '경멸하는 표정', 'disgusted expression': '혐오하는 표정',
      embarrassed: '당황함', 'downcast eyes': '눈을 내리깜', 'guilty expression': '죄책감 어린 표정',
      'regretful expression': '후회하는 표정', 'humiliated expression': '굴욕적인 표정', 'tender expression': '다정한 표정',
      'yearning gaze': '그리워하는 눈빛', 'desirous expression': '욕망하는 표정', 'worried expression': '걱정스러운 표정',
      'seeking approval': '인정을 바람', 'anxious expression': '불안한 표정', 'lonely expression': '외로운 표정',
      'proud posture': '자부심 있는 자세', 'yearning expression': '갈망하는 표정',
      cum_in_mouth: '입 안에 정액', cum_on_tongue: '혀 위에 정액', cum_dripping_from_mouth: '입에서 정액이 흐름', excessive_cum: '많은 정액',
      cum_on_breasts: '가슴에 정액', cum_on_chest: '가슴팍에 정액', dripping_cum: '정액이 흘러내림',
      creampie: '질내 사정', cum_in_pussy: '질 안에 정액', overflowing_creampie: '질내 정액이 넘쳐흐름',
      slightly_wet_pussy: '살짝 젖은 보지', wet_pussy: '젖은 보지', pussy_juice: '애액', pussy_juice_dripping: '애액이 흘러내림',
      excessive_pussy_juice: '많은 애액', cum_on_thighs: '허벅지에 정액', cum_dripping_thighs: '허벅지로 정액이 흐름',
      nipple_piercing: '유두 피어싱', single_nipple_piercing: '한쪽 유두 피어싱', pierced_nipples: '양쪽 유두 피어싱',
      heart_choker: '하트 초커', clitoris_piercing: '클리토리스 피어싱', genital_piercing: '성기 피어싱',
    };
    const PROMPT_WORD_KO = {
      best: '최고', quality: '품질', portrait: '인물화', upper: '상부', full: '전체', body: '몸', girl: '여성', girls: '여성들', boy: '남성', boys: '남성들',
      solo: '단독', multiple: '여러', long: '긴', short: '짧은', dark: '짙은', light: '밝은', hair: '머리', eyes: '눈', eye: '눈',
      black: '검은', brown: '갈색', blond: '금발', blonde: '금발', red: '붉은', white: '흰', grey: '회색', gray: '회색', silver: '은빛', green: '초록색', blue: '파란색',
      medium: '중간 크기', large: '큰', huge: '매우 큰', gigantic: '거대한', breasts: '가슴', breast: '가슴', slim: '날씬한', waist: '허리',
      tall: '키 큰', petite: '아담한', slender: '가녀린', curvy: '굴곡진', athletic: '탄탄한', muscular: '근육질', build: '체형', figure: '몸매',
      young: '젊은', old: '나이 든', 'middle-aged': '중년', elderly: '노년', woman: '여성', man: '남성', female: '여성', male: '남성',
      smile: '미소', expression: '표정', cheerful: '쾌활한', calm: '차분한', focused: '집중한', worried: '걱정스러운', weary: '지친', tired: '피곤한',
      shy: '수줍은', blush: '홍조', scared: '두려운', tense: '긴장한', angry: '화난', gentle: '부드러운', soft: '부드러운', bright: '환한',
      happy: '행복한', sad: '슬픈', playful: '장난스러운', nervous: '긴장한', proud: '자부심 있는', affectionate: '다정한', lonely: '외로운',
      looking: '바라봄', viewer: '정면', down: '아래', up: '위', away: '다른 곳', another: '다른 사람', gaze: '시선', mouth: '입', lips: '입술',
      closed: '감은', open: '벌린', parted: '살짝 벌린', flushed: '붉어진', cheeks: '볼', tears: '눈물', drooling: '침 흘림',
      tavern: '선술집', interior: '내부', medieval: '중세', background: '배경', wooden: '나무', tables: '탁자', table: '탁자', candlelight: '촛불',
      room: '방', bedroom: '침실', kitchen: '부엌', bathhouse: '목욕탕', hallway: '복도', corridor: '복도', upstairs: '위층', indoors: '실내', private: '사적인 공간',
      candle: '촛불', sconce: '벽등', lighting: '조명', morning: '아침', dim: '어두운', warm: '따뜻한', firelight: '불빛', steam: '수증기',
      standing: '서 있음', sitting: '앉아 있음', lying: '누워 있음', kneeling: '무릎 꿇음', sleeping: '잠듦', relaxed: '편안함',
      carrying: '나름', tray: '쟁반', wiping: '닦음', cleaning: '청소', stirring: '저음', pot: '냄비', holding: '들고 있음',
      dress: '드레스', blouse: '블라우스', skirt: '치마', apron: '앞치마', corset: '코르셋', lingerie: '란제리', stockings: '스타킹',
      sleeves: '소매', neckline: '옷깃', bodice: '보디스', clothes: '옷', clothing: '옷차림', nude: '나체', naked: '알몸', bare: '드러난', skin: '피부',
      exposed: '드러난', pulled: '당겨진', aside: '옆으로 젖힘', hiked: '걷어 올림', disheveled: '헝클어진', button: '단추', undone: '풀림',
      drunk: '취함', unconscious: '의식 없음', exhausted: '기진맥진', struggling: '몸부림침', unable: '불가능', move: '움직임',
      handcuffed: '수갑을 참', handcuffs: '수갑', chains: '쇠사슬', shackles: '족쇄', bound: '묶임', wrists: '손목', hands: '손',
      piercing: '피어싱', pierced: '피어싱한', choker: '초커', cum: '정액', wet: '젖은', dripping: '흐름', excessive: '많은',
      masterpiece: '최고 수준 작품', blurry: '흐릿함', deformed: '기형', anatomy: '인체 구조', limbs: '팔다리', watermark: '워터마크', signature: '서명', text: '문자',
    };
    const TAG_CATEGORIES = [
      ['all', '전체'], ['quality', '품질'], ['character', '인물·외형'], ['outfit', '의상·노출'], ['mood', '기분·표정'],
      ['action', '행동·자세'], ['location', '장소·배경'], ['lighting', '조명·구도'], ['status', '상태·장신구'], ['custom', '사용자'], ['other', '기타'],
    ];
    const USER_VARIANT_START = 4;
    let activeSettingsTab = 'general';
    let activePromptPolarity = 'positive';
    let activeOutfitPromptId = '';
    let activeSituationPresetId = LEGACY_SITUATION_PRESET_ID;
    let settingsMessage = '';
    let dialogueRuleCounter = 0;
    let situationPresetCounter = 0;
    let activeTagTarget = null;
    let activeTagCategory = 'all';
    let wifeBuilderEnglishName = '';
    let wifeBuilderActivePromptSourceId = '';
    let wifeBuilderContextId = null;
    let currentWifeBuilderPromptState = null;
    let readingWifePromptSources = false;
    let pendingWifeBuilderTemplate = null;
    let residueVariantId = 0;
    let positionVariantId = 0;
    let latestScenePrompt = null;
    let positionSelection = { situationId: '', presetId: 'none', groupSlots: '' };
    const positionRandomChoices = new Map();
    const positionPlacementDrafts = new Map();
    const positionGeneratedResults = new Map();
    const positionGeneration = { running: false, message: '' };
    const diagnostics = {
      running: false,
      checkedAt: 0,
      checks: [],
      backend: null,
      lastLookup: null,
      lastGeneration: null,
    };

    function currentPrompts() {
      const saved = api.settings.get({ prompts: {} });
      return { ...DEFAULT_PROMPTS, ...(saved.prompts || {}) };
    }

    function currentNegativePrompts() {
      const saved = api.settings.get({ negativePrompts: {} });
      return { ...DEFAULT_NEGATIVE_PROMPTS, ...(saved.negativePrompts || {}) };
    }

    function normalizeCustomTags(value) {
      if (!Array.isArray(value)) return [];
      const tags = new Map();
      for (const entry of value) {
        const tag = String(entry?.tag || '').trim();
        const label = String(entry?.label || '').trim();
        if (tag && label) tags.set(tag.toLocaleLowerCase(), { tag, label });
      }
      return [...tags.values()];
    }

    function currentCustomTags() {
      return normalizeCustomTags(api.settings.get({ customTags: [] }).customTags);
    }

    function normalizeCharacterPrompt(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return { ...DEFAULT_CHARACTER_PROMPT };
      const wifeKey = typeof value.wifeKey === 'string' ? value.wifeKey.trim() : '';
      const sourceId = typeof value.sourceId === 'string' ? value.sourceId.trim() : '';
      return {
        positivePrompt: typeof value.positivePrompt === 'string' ? value.positivePrompt : '',
        negativePrompt: typeof value.negativePrompt === 'string' ? value.negativePrompt : '',
        mode: 'replace',
        imagePolicy: value.imagePolicy === 'regenerate' ? 'regenerate' : 'reuse',
        ...(wifeKey ? { wifeKey } : {}),
        ...(sourceId ? { sourceId } : {}),
      };
    }

    function currentCharacterPrompt() {
      return normalizeCharacterPrompt(api.settings.get({ characterPrompt: DEFAULT_CHARACTER_PROMPT }).characterPrompt);
    }

    function currentWifePromptContext(state = api.store.game(), characterId = state?.primaryCharacterId, character = state?.characters?.[characterId]) {
      const generated = character?.generatedArchetype;
      const archetype = generated ?? (character?.archetypeId ? wifeArchetypeById(character.archetypeId) : null);
      const wifeKey = String(generated?.attentionCustomWifeId || generated?.shortname || generated?.id
        || character?.archetypeId || characterId || '').trim();
      return {
        character,
        archetype,
        wifeKey,
        name: String(character?.name || archetype?.name || character?.shortname || characterId || '현재 아내').trim(),
      };
    }

    function promptFromWifeArchetype(archetype) {
      const registered = archetype?.attentionImagePrompt;
      const registeredNegative = registered && Object.prototype.hasOwnProperty.call(registered, 'negativePrompt');
      return normalizeCharacterPrompt({
        positivePrompt: String(registered?.positivePrompt || archetype?.imageBase || '').trim(),
        negativePrompt: normalizedWifeNegative(registeredNegative
          ? registered.negativePrompt
          : archetype?.attentionImageNegativeOverride ?? archetype?.imageNegative ?? ''),
        imagePolicy: registered?.imagePolicy,
      });
    }

    function characterPromptOverride(context = currentWifePromptContext()) {
      const saved = currentCharacterPrompt();
      if (saved.wifeKey) return saved.wifeKey === context.wifeKey ? saved : null;
      return saved.positivePrompt.trim() || saved.negativePrompt.trim() ? saved : null;
    }

    function currentWifeCharacterPrompt(context = currentWifePromptContext()) {
      return characterPromptOverride(context) || promptFromWifeArchetype(context.archetype);
    }

    function saveCurrentWifeCharacterPrompt(patch) {
      const context = currentWifePromptContext();
      const characterPrompt = normalizeCharacterPrompt({
        ...currentWifeCharacterPrompt(context),
        ...patch,
        wifeKey: context.wifeKey,
      });
      api.settings.set({ characterPrompt });
      publishCurrentWifePromptProfile();
      return characterPrompt;
    }

    function normalizeOutfitPrompts(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).flatMap(([rawId, prompt]) => {
        const id = String(rawId || '').trim();
        if (!id || id.length > 120 || ['__proto__', 'prototype', 'constructor'].includes(id)
          || !prompt || typeof prompt !== 'object' || Array.isArray(prompt)
          || typeof prompt.positivePrompt !== 'string' || typeof prompt.negativePrompt !== 'string') return [];
        return [[id, { positivePrompt: prompt.positivePrompt, negativePrompt: prompt.negativePrompt }]];
      }));
    }

    function currentOutfitPrompts() {
      return normalizeOutfitPrompts(api.settings.get({ outfitPrompts: {} }).outfitPrompts);
    }

    function outfitPromptSources() {
      const definitions = [];
      if (Array.isArray(outfitList)) definitions.push(...outfitList);
      try {
        const addonOutfits = globalThis.__WAYWARD_ADDON_API__?.outfits;
        if (Array.isArray(addonOutfits)) definitions.push(...addonOutfits);
        const registered = globalThis.__waywardOutfits?.list?.();
        if (Array.isArray(registered)) definitions.push(...registered);
      } catch { /* an optional outfit bridge must not block the settings window */ }
      const currentOutfitId = String(currentWifePromptContext().character?.outfit || '').trim();
      const currentOutfit = currentOutfitId ? outfitById(currentOutfitId) : null;
      if (currentOutfit) definitions.push(currentOutfit);
      const unique = new Map();
      for (const outfit of definitions) {
        const id = String(outfit?.id || '').trim();
        if (!id) continue;
        unique.set(id, {
          id,
          name: String(outfit.name || id),
          description: String(outfit.description || ''),
          positivePrompt: String(outfit.imageTags || ''),
          negativePrompt: String(outfit.negativeImageTags || ''),
        });
      }
      return [...unique.values()].sort((left, right) => left.name.localeCompare(right.name, 'ko'));
    }

    function outfitPromptValues(source, prompts = currentOutfitPrompts()) {
      return prompts[source.id] || { positivePrompt: source.positivePrompt, negativePrompt: source.negativePrompt };
    }

    function saveOutfitPromptField(outfitId, field, value) {
      const source = outfitPromptSources().find(entry => entry.id === outfitId);
      if (!source || !['positivePrompt', 'negativePrompt'].includes(field)) return;
      const prompts = currentOutfitPrompts();
      api.settings.set({
        outfitPrompts: {
          ...prompts,
          [outfitId]: { ...outfitPromptValues(source, prompts), [field]: String(value ?? '') },
        },
      });
    }

    function positionGroupCount(value) {
      return Math.max(0, Math.min(5, Number(String(value || '').match(/(?:^|__|\|)grp-(\d+)/)?.[1]) || 0));
    }

    function positionGroupSlots(value) {
      const count = positionGroupCount(value);
      const slots = String(value || '').match(/(?:^|__|\|)gslot-([mhbxriaw]+)/)?.[1] || '';
      return count && slots.length === count ? slots : '';
    }

    function normalizePositionPresetPrompts(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).flatMap(([presetId, prompt]) =>
        POSITION_PRESETS[presetId] && typeof prompt === 'string' ? [[presetId, prompt]] : []));
    }

    function currentPositionPresetPrompts() {
      return normalizePositionPresetPrompts(api.settings.get({ positionPresetPrompts: {} }).positionPresetPrompts);
    }

    function currentPositionPresetNegativePrompts() {
      return normalizePositionPresetPrompts(api.settings.get({ positionPresetNegativePrompts: {} }).positionPresetNegativePrompts);
    }

    function positionPresetById(presetId) {
      const preset = POSITION_PRESETS[presetId];
      if (!preset) return null;
      if (presetId === 'none') return { ...preset, prompt: '', negativePrompt: '' };
      const prompts = currentPositionPresetPrompts();
      const negatives = currentPositionPresetNegativePrompts();
      return {
        ...preset,
        prompt: Object.prototype.hasOwnProperty.call(prompts, presetId) ? prompts[presetId] : preset.prompt,
        negativePrompt: Object.prototype.hasOwnProperty.call(negatives, presetId) ? negatives[presetId] : preset.negativePrompt || '',
      };
    }

    function normalizePositionGroupPrompts(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).flatMap(([slotId, prompt]) =>
        GROUP_SLOT_BY_ID[slotId] && typeof prompt === 'string' ? [[slotId, prompt]] : []));
    }

    function currentPositionGroupPrompts() {
      return normalizePositionGroupPrompts(api.settings.get({ positionGroupPrompts: {} }).positionGroupPrompts);
    }

    function positionGroupPromptById(slotId) {
      const option = GROUP_SLOT_BY_ID[slotId];
      if (!option) return '';
      const prompts = currentPositionGroupPrompts();
      return Object.prototype.hasOwnProperty.call(prompts, slotId) ? prompts[slotId] : option.prompt;
    }

    function normalizeResiduePrompts(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      return Object.fromEntries(Object.entries(value).flatMap(([key, entry]) =>
        /^situation_(?:fluid|vulva)__/.test(key) && entry && typeof entry === 'object'
          && typeof entry.positivePrompt === 'string' && typeof entry.negativePrompt === 'string'
          ? [[key, { positivePrompt: entry.positivePrompt, negativePrompt: entry.negativePrompt }]]
          : []));
    }

    function currentResiduePrompts() {
      return normalizeResiduePrompts(api.settings.get({ residuePrompts: {} }).residuePrompts);
    }

    function isResidueImageKey(value) {
      return /^situation_(?:fluid|vulva)__/.test(String(value || ''));
    }

    function residueBaseImageKey(value) {
      const key = String(value || '');
      const match = key.match(/^(situation_(?:fluid|vulva)__.+)__v-(\d+)$/);
      return match && Number(match[2]) >= USER_VARIANT_START ? match[1] : key;
    }

    function normalizeResidueImageChoices(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      const normalized = {};
      for (const [rawKey, entry] of Object.entries(value)) {
        const imageKey = residueBaseImageKey(rawKey);
        if (!isResidueImageKey(imageKey) || !entry || typeof entry !== 'object') continue;
        const seen = new Set();
        const items = (Array.isArray(entry.items) ? entry.items : []).flatMap(item => {
          const key = String(item?.key || '');
          const url = String(item?.url || '').trim();
          if (!url || residueBaseImageKey(key) !== imageKey || key === imageKey || seen.has(key)) return [];
          seen.add(key);
          return [{ key, url, createdAt: Math.max(0, Number(item.createdAt) || Number(key.match(/__v-(\d+)$/)?.[1]) || 0) }];
        });
        const selected = items.some(item => item.key === entry.selected) ? entry.selected : '';
        if (items.length) normalized[imageKey] = { selected, items };
      }
      return normalized;
    }

    function currentResidueImageChoices() {
      return normalizeResidueImageChoices(api.settings.get({ residueImageChoices: {} }).residueImageChoices);
    }

    function saveResidueImageChoice(imageKey, item) {
      const choices = currentResidueImageChoices();
      const current = choices[imageKey] || { selected: '', items: [] };
      api.settings.set({
        residueImageChoices: {
          ...choices,
          [imageKey]: {
            selected: item.key,
            items: [item, ...current.items.filter(entry => entry.key !== item.key)],
          },
        },
      });
    }

    function selectResidueImage(imageKey, selected) {
      const choices = currentResidueImageChoices();
      const current = choices[imageKey];
      if (!current) return;
      api.settings.set({
        residueImageChoices: {
          ...choices,
          [imageKey]: { ...current, selected: current.items.some(item => item.key === selected) ? selected : '' },
        },
      });
      scheduleUiScan();
    }

    function wifeImageName(value) {
      const name = String(value || '').trim().toLocaleLowerCase()
        .replace(/['’]/g, '')
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '');
      return /[a-z]/.test(name) ? name : '';
    }

    function wifeDialogueArchetypeId(inputs) {
      if (!Object.prototype.hasOwnProperty.call(inputs || {}, '__attentionExtraLinesArchetypeId')) return EXTRA_LINES_DIALOGUE_SOURCES[0][0];
      const value = String(inputs.__attentionExtraLinesArchetypeId || '');
      return EXTRA_LINES_DIALOGUE_SOURCES.some(([id]) => id === value) ? value : '';
    }

    function wifeOutfitColors(inputs) {
      const saved = inputs?.__attentionImageOutfitColors;
      const valid = value => {
        const color = String(value || '');
        return OUTFIT_COLOR_OPTIONS.some(([id]) => id === color) ? color : '';
      };
      return {
        primary: valid(saved?.primary),
        secondary1: valid(saved?.secondary1),
        secondary2: valid(saved?.secondary2),
      };
    }

    function wifeOutfitColorPrompt(inputs) {
      const colors = wifeOutfitColors(inputs);
      const used = new Set();
      return [
        ['primary', 'clothing'], ['secondary1', 'trim'], ['secondary2', 'accents'],
      ].flatMap(([key, suffix]) => {
        const color = colors[key];
        if (!color || used.has(color)) return [];
        used.add(color);
        return [`${color} ${suffix}`];
      }).join(', ');
    }

    function applySavedWifeMetadata(archetype, inputs, fullPrompt, fullNegative) {
      if (!archetype || !inputs) return archetype;
      const marker = inputs.__attentionImagePromptArchetype;
      const normalizedMarker = normalizeCharacterPrompt(marker);
      const englishName = String(inputs.__attentionImageEnglishName || '').trim();
      const shortname = wifeImageName(inputs.__attentionImageShortname || englishName);
      let result = shortname || englishName ? {
        ...archetype,
        ...(shortname ? { shortname } : {}),
        ...(englishName ? { englishName } : {}),
      } : archetype;
      const rawPositivePrompt = joinPrompt(`${String(fullPrompt || inputs.customAppearance || '').trim()
        || normalizedMarker.positivePrompt}, ${wifeOutfitColorPrompt(inputs)}`);
      const hasStoredNegative = Object.prototype.hasOwnProperty.call(inputs, '__attentionImageNegativePrompt');
      const hasMarkerNegative = typeof marker?.negativePrompt === 'string';
      const hasNegativeOverride = fullNegative !== undefined || hasStoredNegative || hasMarkerNegative;
      const negativePrompt = normalizedWifeNegative(fullNegative !== undefined
        ? fullNegative
        : hasStoredNegative
          ? inputs.__attentionImageNegativePrompt
          : normalizedMarker.negativePrompt);
      const positivePrompt = withoutPromptTags(rawPositivePrompt, negativePrompt);
      result = {
        ...result,
        attentionExtraLinesArchetypeId: wifeDialogueArchetypeId(inputs),
        attentionImageOutfitColors: wifeOutfitColors(inputs),
      };
      if (positivePrompt || hasNegativeOverride) {
        const appliedPrompt = {
          positivePrompt,
          negativePrompt,
          mode: 'replace',
          imagePolicy: 'reuse',
        };
        result = {
          ...result,
          imageBase: positivePrompt || result.imageBase,
          attentionImagePrompt: appliedPrompt,
          ...(hasNegativeOverride ? { attentionImageNegativeOverride: negativePrompt } : {}),
        };
      }
      publishWifePromptProfile(result);
      return result;
    }

    function publishWifePromptProfile(archetype) {
      if (!archetype || typeof archetype !== 'object') return;
      const shortname = wifeImageName(archetype.shortname || archetype.englishName || archetype.id);
      const archetypeId = String(archetype.attentionCustomWifeId || archetype.id || shortname).trim();
      if (!shortname || !archetypeId) return;
      const positive = String(archetype.attentionImagePrompt?.positivePrompt || archetype.imageBase || '').trim()
        .replaceAll('\r\n', '\n');
      const negative = normalizedWifeNegative(archetype.attentionImageNegativeOverride
        ?? archetype.attentionImagePrompt?.negativePrompt
        ?? archetype.imageNegative
        ?? '');
      if (!positive && !negative) return;
      const parts = positive.split(/\n\s*\n/);
      const profile = {
        format: 1,
        profileVersion: 'attention-image-prompt-v1',
        archetypeId,
        shortname,
        positiveTags: String(parts.shift() || '').trim(),
        naturalDescription: parts.join('\n\n').trim(),
        negativeTags: negative,
        attentionImagePromptOwner: api.id,
      };
      const profiles = globalThis.__WAYWARD_CHARACTER_PROMPT_PROFILES__
        || (globalThis.__WAYWARD_CHARACTER_PROMPT_PROFILES__ = []);
      const at = profiles.findIndex(entry => entry?.attentionImagePromptOwner === api.id
        && (entry.archetypeId === archetypeId || entry.shortname === shortname));
      if (at >= 0) profiles[at] = profile;
      else profiles.push(profile);
    }

    function publishCurrentWifePromptProfile(state = api.store.game()) {
      const context = currentWifePromptContext(state);
      if (!context.archetype) return;
      const override = characterPromptOverride(context);
      publishWifePromptProfile({
        ...context.archetype,
        ...(context.character?.shortname ? { shortname: context.character.shortname } : {}),
        ...(context.wifeKey ? { attentionCustomWifeId: context.wifeKey } : {}),
        ...(override ? {
          imageBase: override.positivePrompt,
          attentionImagePrompt: override,
          attentionImageNegativeOverride: override.negativePrompt,
        } : {}),
      });
    }

    function promptList(value) {
      return String(value || '').split(',').map(tag => tag.trim()).filter(Boolean);
    }

    function promptIdentity(value) {
      return String(value || '').trim().toLocaleLowerCase().replaceAll('_', ' ').replace(/\s+/g, ' ');
    }

    function appearancePromptFacet(value) {
      const tag = promptIdentity(value);
      if (/\b(?:brown|blue|green|grey|black|yellow|orange|red|purple|pink|aqua) eyes\b/.test(tag)) return 'eyes';
      if (/\b(?:(?:light )?(?:brown|black|blonde|red|orange|grey|white|pink|purple|blue|green) hair|(?:very )?(?:long|short) hair|medium hair|straight hair|wavy hair|curly hair|messy hair|ponytail|low ponytail|single braid|twin braids|braided ponytail|single hair bun|double bun|low twintails|half updo)\b/.test(tag)) return 'hair';
      if (/\b(?:pale skin|tan|dark-skinned female|very dark skin)\b/.test(tag)) return 'skin';
      if (/\b(?:petite|skinny|curvy|plump|muscular female|mature female)\b/.test(tag)) return 'build';
      if (/\b(?:(?:medium|small|large|huge) breasts|flat chest)\b/.test(tag)) return 'bust';
      if (/\b(?:waist|hips|thighs)\b/.test(tag)) return 'figure';
      if (/\b(?:freckles|mole|scar|eyebrows)\b/.test(tag)) return 'marks';
      return '';
    }

    function generatedWifeBasePrompt(imageBase, customAppearance) {
      const full = String(imageBase || '').trim();
      const custom = String(customAppearance || '').trim().replace(/\s*,\s*$/, '');
      if (!custom) return full;
      const suffix = `, ${custom}`;
      return full.endsWith(suffix) ? full.slice(0, -suffix.length).trim() : full;
    }

    function rebaseWifePrompt(fullPrompt, previousBase, nextBase) {
      const full = promptList(fullPrompt);
      const previous = promptList(previousBase);
      const next = promptList(nextBase);
      const previousIds = new Set(previous.map(promptIdentity));
      const nextIds = new Set(next.map(promptIdentity));
      const facets = new Set([...previous, ...next].map(appearancePromptFacet).filter(Boolean));
      const changedFacets = new Set([...facets].filter(facet => {
        const before = previous.filter(tag => appearancePromptFacet(tag) === facet).map(promptIdentity).sort().join('|');
        const after = next.filter(tag => appearancePromptFacet(tag) === facet).map(promptIdentity).sort().join('|');
        return before !== after;
      }));
      const removedExact = new Set(previous
        .filter(tag => !appearancePromptFacet(tag) && !nextIds.has(promptIdentity(tag)))
        .map(promptIdentity));
      const retained = full.filter(tag => {
        const facet = appearancePromptFacet(tag);
        return facet ? !changedFacets.has(facet) : !removedExact.has(promptIdentity(tag));
      });
      const additions = next.filter(tag => {
        const facet = appearancePromptFacet(tag);
        return facet ? changedFacets.has(facet) : !previousIds.has(promptIdentity(tag));
      });
      return [...retained, ...additions]
        .filter((tag, index, list) => list.findIndex(other => promptIdentity(other) === promptIdentity(tag)) === index)
        .join(', ');
    }

    function wifePromptCleanup(value) {
      const removedCategories = new Set(['quality', 'location', 'lighting', 'mood', 'action']);
      const kept = [];
      const removed = [];
      for (const tag of promptList(value)) {
        const identity = promptTagIdentity(tag);
        const category = promptTagCategory(tag);
        const removableStatus = category === 'status'
          && !/\b(?:piercing|pierced|choker|tattoo|scar|freckles|mole)\b/.test(identity.spaced);
        const removableComposition = category === 'other'
          && /^(?:solo|solo focus|2girls|multiple girls|[2-9]boys?|group)$/.test(identity.spaced);
        (removedCategories.has(category) || removableStatus || removableComposition ? removed : kept).push(tag);
      }
      return { positivePrompt: kept.join(', '), removed };
    }

    function gameElement(type, properties, ...children) {
      const nextProps = { ...(properties || {}) };
      const key = nextProps.key;
      delete nextProps.key;
      const childNodes = children.flat().filter(child => child != null && child !== false);
      if (childNodes.length) nextProps.children = childNodes.length === 1 ? childNodes[0] : childNodes;
      return childNodes.length > 1 ? jsx.jsxs(type, nextProps, key) : jsx.jsx(type, nextProps, key);
    }

    function wifePromptSources() {
      const builtIn = BUILTIN_WIFE_PROMPT_SOURCES.map(([id, fallbackName]) => {
        const archetype = wifeArchetypeById(id);
        return archetype ? { id, name: archetype.name || fallbackName, archetype } : null;
      }).filter(Boolean);
      let custom;
      readingWifePromptSources = true;
      try {
        custom = (customWifeStore.getState().wives || []).map(entry => {
          try {
            const archetype = applySavedWifeMetadata(buildWifeArchetype(entry.inputs, entry.id), entry.inputs);
            return archetype ? { id: entry.id, name: archetype.name || entry.inputs?.name || '사용자 아내', archetype, custom: true } : null;
          } catch { return null; }
        }).filter(Boolean);
      } finally {
        readingWifePromptSources = false;
      }
      const sources = new Map([...builtIn, ...custom].map(source => [source.id, source]));
      for (const archetype of globalThis.WW_ImageStudioBridge?.wives?.() || []) {
        if (archetype?.id && !sources.has(archetype.id)) sources.set(archetype.id, {id:archetype.id,name:archetype.name || archetype.shortname || archetype.id,archetype,modded:true});
      }
      return [...sources.values()];
    }

    globalThis.WW_CustomWifeBridge = {
      list: () => wifePromptSources().filter(source => source.custom).map(source => ({
        id: source.archetype.shortname || source.id,
        entryId: source.id,
        name: source.name,
        archetype: source.archetype,
      })),
    };

    function wifePickerTools(props) {
      const h = gameElement;
      const sources = wifePromptSources();
      const customWives = sources.filter(source => source.custom);
      return h('div', {
        key: 'attention-image-prompt-wife-tools',
        'data-wml-ui': '',
        'data-attention-wife-tools': '',
        className: 'rounded-lg border border-stone-700 bg-stone-800/40 px-5 py-4 space-y-3',
      },
      customWives.length ? h('div', { className: 'space-y-2' },
        h('div', { className: 'text-xs uppercase tracking-wide text-stone-400' }, '사용자 아내'),
        ...customWives.map(source => h('div', {
          key: source.id,
          className: 'rounded border border-stone-600 bg-stone-900/50 p-2 transition-colors',
          'data-custom-wife-card': source.id,
        },
        h('button', {
          type: 'button',
          'data-custom-wife-select': source.id,
          className: 'w-full rounded px-2 py-2 text-left hover:bg-amber-950/30 transition-colors',
          onClick: () => props.onSelect(source.id, 'spouse', source.archetype),
        },
          h('strong', { className: 'text-amber-300' }, source.name),
          h('span', { className: 'block text-xs text-stone-500 mt-1' }, source.archetype.tagline || '사용자가 만든 아내')),
        h('div', { className: 'flex justify-end gap-2 border-t border-stone-800 pt-2' },
          h('button', {
            type: 'button',
            'data-custom-wife-edit': source.id,
            className: 'rounded bg-stone-700 px-3 py-1 text-xs text-stone-200 hover:bg-stone-600',
            onClick: () => props.onOpenBuilder(source.id),
          }, '수정'),
          h('button', {
            type: 'button',
            'data-custom-wife-delete': source.id,
            className: 'rounded bg-rose-950 px-3 py-1 text-xs text-rose-200 hover:bg-rose-900',
            onClick: () => {
              if (!window.confirm(`“${source.name}” 아내를 삭제할까요? 이 작업은 되돌릴 수 없습니다.`)) return;
              customWifeStore.getState().remove(source.id);
            },
          }, '삭제')),
        ))) : null,
      h('form', {
        className: 'border-t border-stone-700 pt-3 space-y-2',
        'data-add-wife-form': '',
        onSubmit: event => {
          event.preventDefault();
          const englishName = wifeBuilderEnglishName.trim();
          const shortname = wifeImageName(englishName);
          if (!shortname) return;
          pendingWifeBuilderTemplate = { englishName, shortname };
          wifeBuilderActivePromptSourceId = '';
          wifeBuilderContextId = null;
          props.onOpenBuilder();
        },
      },
        h('div', { className: 'text-xs uppercase tracking-wide text-stone-400' }, '새 아내 추가'),
        h('label', { className: 'grid gap-1 text-xs text-stone-500' }, '영문 이미지 이름',
          h('input', {
            type: 'text',
            required: true,
            pattern: '[A-Za-z][A-Za-z0-9 _-]*',
            defaultValue: wifeBuilderEnglishName,
            placeholder: '예: Alice Morgan',
            title: '영문자로 시작하고 영문, 숫자, 공백, 밑줄, 하이픈만 사용해 주세요.',
            'data-wife-english-name': '',
            className: 'bg-stone-900 border border-stone-700 rounded px-3 py-2 text-sm text-stone-200',
            onChange: event => { wifeBuilderEnglishName = event.currentTarget.value; },
          }),
        ),
        h('p', { className: 'text-xs text-stone-500' }, '외모 기준 캐릭터와 전체 프롬프트는 다음 생성창에서 선택하고 직접 수정할 수 있습니다.'),
        h('p', { className: 'text-xs text-stone-500' }, '영문 이미지 이름은 이미지 파일과 캐시를 찾는 이름 키로 저장됩니다.'),
        h('button', {
          type: 'submit',
          'data-add-wife-button': '',
          className: 'w-full rounded-lg bg-amber-700 hover:bg-amber-600 px-5 py-3 font-semibold text-white transition-colors',
        }, '아내 추가하기'),
      ));
    }

    function customizeWifeBuilder(result, props) {
      if (!result) return result;
      const contextId = props?.editId || '__new-wife__';
      if (wifeBuilderContextId !== contextId) {
        wifeBuilderContextId = contextId;
        wifeBuilderActivePromptSourceId = '';
      }
      const sources = wifePromptSources();
      const nodes = [];
      const collect = node => {
        if (Array.isArray(node)) { for (const child of node) collect(child); return; }
        if (!node || typeof node !== 'object') return;
        nodes.push(node);
        collect(node.props?.children);
      };
      collect(result);
      const baseSection = nodes.find(node => node.props?.title === '외모 기준 캐릭터');
      const appearanceSection = nodes.find(node => node.props?.title === '외모');
      const promptTextarea = nodes.find(node => node.type === 'textarea'
        && String(node.props?.placeholder || '').includes('hair ribbon'));
      if (!baseSection || !appearanceSection || !promptTextarea) return result;
      const baseSelect = (() => {
        const found = [];
        const walk = node => {
          if (Array.isArray(node)) { for (const child of node) walk(child); return; }
          if (!node || typeof node !== 'object') return;
          if (node.type === 'select') found.push(node);
          walk(node.props?.children);
        };
        walk(baseSection.props.children);
        return found[0];
      })();
      if (!baseSelect) return result;

      const sourcePrefix = 'attention-wife:';
      const nativeValue = String(baseSelect.props.value || '');
      const promptState = currentWifeBuilderPromptState;
      const promptInputs = promptState?.inputs || {};
      const updateBuilderInputs = patch => {
        if (!promptState?.inputs) return;
        Object.assign(promptState.inputs, patch);
        const positive = String(promptState.full || promptTextarea.props.value || '');
        promptTextarea.props.onChange({ target: { value: positive }, currentTarget: { value: positive } });
      };
      if (nativeValue) wifeBuilderActivePromptSourceId = '';
      if (!wifeBuilderActivePromptSourceId && !nativeValue) {
        const currentPrompt = String(promptState?.full || promptTextarea.props.value || '').trim();
        wifeBuilderActivePromptSourceId = sources.find(source =>
          String(source.archetype.imageBase || '').trim() === currentPrompt)?.id || '';
      }
      if (!sources.some(source => source.id === wifeBuilderActivePromptSourceId)) wifeBuilderActivePromptSourceId = '';
      const selectedValue = wifeBuilderActivePromptSourceId
        ? `${sourcePrefix}${wifeBuilderActivePromptSourceId}`
        : nativeValue;
      const nativeOptions = (Array.isArray(baseSelect.props.children)
        ? baseSelect.props.children : [baseSelect.props.children])
        .filter(option => option?.props?.value !== '');
      const replacementSelect = {
        ...baseSelect,
        props: {
          ...baseSelect.props,
          value: selectedValue,
          'data-wife-builder-base': '',
          onChange: event => {
            const value = String(event.target.value || '');
            if (value.startsWith(sourcePrefix)) {
              const source = sources.find(entry => entry.id === value.slice(sourcePrefix.length));
              if (!source) return;
              wifeBuilderActivePromptSourceId = source.id;
              if (promptState) {
                promptState.full = String(source.archetype.imageBase || '').trim();
                const sourceNegative = source.archetype.attentionImageNegativeOverride
                  ?? source.archetype.attentionImagePrompt?.negativePrompt
                  ?? joinPrompt(`${DEFAULT_WIFE_CHARACTER_NEGATIVE}, ${source.archetype.imageNegative || ''}`);
                promptState.negative = String(sourceNegative).trim();
                if (promptState.inputs) promptState.inputs.__attentionImageNegativePrompt = promptState.negative;
                promptState.needsPersist = false;
                promptState.userEdited = false;
              }
              baseSelect.props.onChange({ target: { value: '' }, currentTarget: { value: '' } });
              promptTextarea.props.onChange({ target: { value: source.archetype.imageBase || '' }, currentTarget: { value: source.archetype.imageBase || '' } });
              return;
            }
            wifeBuilderActivePromptSourceId = '';
            baseSelect.props.onChange(event);
          },
          children: [
            gameElement('option', { key: 'attention-wife-none-placeholder', value: '', disabled: true, hidden: true }, '기준 캐릭터를 선택하세요'),
            ...nativeOptions,
            gameElement('option', { key: 'attention-wife-divider', value: '__attention-divider__', disabled: true }, '── 기본·저장 캐릭터 ──'),
            ...sources.map(source => gameElement('option', {
              key: `${sourcePrefix}${source.id}`,
              value: `${sourcePrefix}${source.id}`,
            }, `${source.custom ? '저장한 아내' : '기본 캐릭터'} · ${source.name}`)),
          ],
        },
      };
      const noBaseCheckbox = gameElement('label', {
        key: 'attention-wife-no-base',
        className: 'flex items-center gap-2 text-sm text-stone-300 pb-2',
        'data-wife-no-base': '',
      },
      gameElement('input', {
        type: 'checkbox',
        checked: !nativeValue && !wifeBuilderActivePromptSourceId,
        onChange: event => {
          wifeBuilderActivePromptSourceId = '';
          if (event.target.checked) {
            baseSelect.props.onChange({ target: { value: '' }, currentTarget: { value: '' } });
            return;
          }
          const first = nativeOptions.find(option => option?.props?.value);
          if (first) baseSelect.props.onChange({ target: { value: first.props.value }, currentTarget: { value: first.props.value } });
        },
      }),
      '기준 캐릭터 없음');
      const metadataSelect = (label, data, value, options, onChange) => gameElement('label', {
        className: 'grid gap-1 text-xs text-stone-400',
      }, label, gameElement('select', {
        value,
        ...data,
        onChange,
        className: 'w-full rounded border border-stone-700 bg-stone-950 px-3 py-2 text-sm text-stone-200',
      }, ...options.map(([id, optionLabel]) => gameElement('option', { key: id || '__none', value: id }, optionLabel))));
      const outfitColors = wifeOutfitColors(promptInputs);
      const wifeMetadataEditor = gameElement('div', {
        key: 'attention-wife-metadata-editor',
        className: 'mt-3 pt-3 border-t border-stone-700 space-y-3',
        'data-wml-ui': '',
        'data-wife-metadata-editor': '',
      },
      gameElement('div', { className: 'text-sm font-medium text-stone-200' }, '추가 대사·의상 색상'),
      metadataSelect('추가 대사 모드에서 사용할 대사', { 'data-wife-dialogue-source': '' },
        wifeDialogueArchetypeId(promptInputs), EXTRA_LINES_DIALOGUE_SOURCES,
        event => updateBuilderInputs({ __attentionExtraLinesArchetypeId: event.target.value })),
      gameElement('p', { className: 'text-xs text-stone-500' },
        '엘레나·마라·피파 중 말투를 선택합니다. 기존 JSON에 선택값이 없으면 이전 동작과 같은 엘레나 대사를 사용합니다.'),
      gameElement('div', { className: 'grid grid-cols-1 sm:grid-cols-3 gap-2' },
        ...[
          ['primary', '주요 색상'], ['secondary1', '보조 색상 1'], ['secondary2', '보조 색상 2'],
        ].map(([key, label]) => metadataSelect(label, { 'data-wife-outfit-color': key }, outfitColors[key], OUTFIT_COLOR_OPTIONS,
          event => updateBuilderInputs({
            __attentionImageOutfitColors: { ...wifeOutfitColors(promptState?.inputs), [key]: event.target.value },
          })))),
      wifeOutfitColorPrompt(promptInputs)
        ? gameElement('p', { className: 'text-xs text-amber-300', 'data-wife-outfit-color-prompt': '' },
          `적용 태그: ${wifeOutfitColorPrompt(promptInputs)}`)
        : gameElement('p', { className: 'text-xs text-stone-500' }, '선택한 색상은 미리보기와 인게임 의상 프롬프트에 함께 추가됩니다.'));
      const promptCleanup = wifePromptCleanup(promptState?.full || promptTextarea.props.value || '');
      const promptCleanupWarning = promptState?.userEdited && promptCleanup.removed.length
        ? gameElement('div', {
          key: 'attention-wife-prompt-cleanup',
          className: 'mt-3 rounded border border-amber-700/70 bg-amber-950/30 p-3 space-y-2',
          'data-wife-prompt-cleanup': '',
        },
        gameElement('p', { className: 'text-sm font-medium text-amber-200' },
          `외형 외 태그 ${promptCleanup.removed.length}개가 감지되었습니다.`),
        gameElement('p', { className: 'text-xs text-stone-400' },
          `장면·행동·기분을 고정할 수 있는 태그: ${promptCleanup.removed.slice(0, 8).map(tag => translatedPromptTag(tag)).join(', ')}`),
        gameElement('button', {
          type: 'button',
          className: 'rounded bg-amber-800 px-3 py-1.5 text-xs font-medium text-white hover:bg-amber-700',
          'data-wife-prompt-cleanup-action': '',
          onClick: () => {
            if (!promptState) return;
            promptState.full = promptCleanup.positivePrompt;
            promptState.userEdited = false;
            promptState.needsPersist = false;
            const value = promptCleanup.positivePrompt;
            promptTextarea.props.onChange({ target: { value }, currentTarget: { value } });
          },
        }, '외형·의상 태그만 남기기'))
        : null;
      const negativeEditor = gameElement('div', {
        key: 'attention-wife-negative-editor',
        className: 'mt-3 pt-3 border-t border-stone-700',
        'data-wml-ui': '',
        'data-wife-negative-editor': '',
      },
      gameElement('div', { className: 'mb-2 text-sm font-medium text-stone-200' },
        '공통 Negative 프롬프트 (미리보기·인게임 기존 프롬프트 교체)'),
      gameElement('textarea', {
        value: promptState?.negative ?? DEFAULT_WIFE_CHARACTER_NEGATIVE,
        rows: 7,
        className: 'w-full rounded border border-stone-700 bg-stone-950 px-3 py-2 text-sm text-stone-200',
        placeholder: '미리보기와 인게임 모두에서 제외할 공통 Negative 프롬프트를 입력하세요.',
        'data-wife-negative-prompt': '',
        onChange: event => {
          if (!promptState) return;
          const value = event.target.value;
          promptState.negative = value;
          if (currentWifeBuilderPromptState?.id === promptState.id) {
            currentWifeBuilderPromptState.negative = value;
          }
          if (promptState.inputs) promptState.inputs.__attentionImageNegativePrompt = value;
          const positive = String(promptState.full || promptTextarea.props.value || '');
          promptTextarea.props.onChange({ target: { value: positive }, currentTarget: { value: positive } });
        },
      }));

      const visit = node => {
        if (Array.isArray(node)) return node.map(visit);
        if (node === baseSelect) return replacementSelect;
        if (typeof node === 'string') return node === '추가 프롬프트 태그'
          ? '전체 외형 프롬프트 (기존 프롬프트 교체)' : node;
        if (!node || typeof node !== 'object' || !node.props) return node;
        const children = visit(node.props.children);
        const nextProps = { ...node.props, children };
        if (node === baseSection) {
          const list = Array.isArray(children) ? children : [children];
          nextProps.children = [noBaseCheckbox, ...list];
        }
        if (node === appearanceSection) {
          const list = Array.isArray(children) ? children : [children];
          nextProps.children = [...list, promptCleanupWarning, wifeMetadataEditor, negativeEditor].filter(Boolean);
        }
        if (node === promptTextarea) {
          nextProps.rows = 7;
          nextProps.value = promptState?.full || promptTextarea.props.value || '';
          nextProps.placeholder = '선택한 캐릭터의 전체 프롬프트를 불러오거나 직접 입력하세요. 이 값이 기존 외형 프롬프트를 교체합니다.';
          nextProps['data-wife-full-prompt'] = '';
          nextProps.onChange = event => {
            if (promptState) {
              promptState.full = event.target.value;
              promptState.needsPersist = false;
              promptState.userEdited = true;
            }
            promptTextarea.props.onChange(event);
          };
        }
        return { ...node, props: nextProps };
      };
      if (promptState?.needsPersist && !promptState.persistScheduled) {
        promptState.persistScheduled = true;
        const value = promptState.full;
        queueMicrotask(() => promptTextarea.props.onChange({ target: { value }, currentTarget: { value } }));
      }
      return visit(result);
    }

    function addWifePickerTools(result, props) {
      let added = false;
      const visit = node => {
        if (Array.isArray(node)) return node.map(visit);
        if (!node || typeof node !== 'object' || !node.props) return node;
        const className = String(node.props.className || '');
        if (!added && className.includes('space-y-3') && className.includes('mb-6')) {
          added = true;
          const children = Array.isArray(node.props.children) ? node.props.children : [node.props.children];
          return { ...node, props: { ...node.props, children: [...children, wifePickerTools(props)] } };
        }
        if (node.props.children == null) return node;
        return { ...node, props: { ...node.props, children: visit(node.props.children) } };
      };
      return visit(result);
    }

    function normalizeOutfitStates(value) {
      if (Array.isArray(value)) return [...new Set(value.filter(state => ALL_OUTFIT_STATES.includes(state) || state === EXPOSED_OUTFIT_STATE[0]))];
      if (value === 'nude') return ['nude'];
      if (value === 'clothed') return ['clothed', 'partial'];
      return [...ALL_OUTFIT_STATES];
    }

    function currentOutfitStates() {
      const saved = api.settings.get({ outfitStates: {}, outfitModes: {} });
      const states = {};
      for (const key of Object.keys(DEFAULT_OUTFIT_STATES)) {
        states[key] = Object.prototype.hasOwnProperty.call(saved.outfitStates || {}, key)
          ? normalizeOutfitStates(saved.outfitStates[key])
          : Object.prototype.hasOwnProperty.call(saved.outfitModes || {}, key)
            ? normalizeOutfitStates(saved.outfitModes[key])
            : [...DEFAULT_OUTFIT_STATES[key]];
      }
      return states;
    }

    function migrateExposedOutfitDefaults() {
      const saved = api.settings.get({ outfitStates: {}, outfitExposureDefaultsV1: false });
      if (saved.outfitExposureDefaultsV1) return;
      const outfitStates = { ...(saved.outfitStates || {}) };
      for (const key of Object.keys(DEFAULT_OUTFIT_STATES).filter(usesExposedDefault)) {
        if (!Object.prototype.hasOwnProperty.call(outfitStates, key)) outfitStates[key] = [EXPOSED_OUTFIT_STATE[0]];
      }
      api.settings.set({ outfitStates, outfitExposureDefaultsV1: true });
    }
    migrateExposedOutfitDefaults();

    const FLUID_DECAY_PARTS = ['mouth', 'breasts', 'uterus'];
    const EXTERNAL_FLUID_TIER_VALUES = [0, 1, 3, 6, 10];

    function normalizeFluidDecaySettings(value) {
      return {
        enabled: value?.enabled !== false,
        intervalMinutes: Math.max(1, Math.min(1440, Math.floor(Number(value?.intervalMinutes) || DEFAULT_FLUID_DECAY.intervalMinutes))),
      };
    }

    function currentFluidDecaySettings() {
      return normalizeFluidDecaySettings(api.settings.get({ fluidDecay: DEFAULT_FLUID_DECAY }).fluidDecay);
    }

    function relaxedFluidValue(part, value, steps) {
      if (part === 'uterus') return Math.max(0, value - steps);
      return EXTERNAL_FLUID_TIER_VALUES[Math.max(0, externalFluidTier(value) - steps)];
    }

    function applyFluidDecay(state, reset = false) {
      const settings = currentFluidDecaySettings();
      if (!state || !settings.enabled || !state.characters) return state;
      const now = Math.max(0, Math.floor(Number(state.slot) || 0));
      const modData = state.mods?.[api.id] || {};
      const savedTrackers = modData.fluidDecay?.characters || {};
      const trackers = { ...savedTrackers };
      let characters = state.characters;
      let changed = false;

      for (const [characterId, character] of Object.entries(state.characters)) {
        const stats = character?.situationStats;
        if (!stats?.fluidState || typeof stats.fluidState !== 'object') continue;
        const savedCharacterTrackers = savedTrackers[characterId] || {};
        const characterTrackers = { ...savedCharacterTrackers };
        let fluidState = stats.fluidState;
        let fluidChanged = false;

        for (const part of FLUID_DECAY_PARTS) {
          const value = Math.max(0, Math.floor(Number(fluidState[part]) || 0));
          const saved = savedCharacterTrackers[part];
          const lastUpdatedSlot = Number(saved?.lastUpdatedSlot);
          const trackedValue = Number(saved?.value);
          let nextValue = value;
          let nextSlot = now;

          if (!reset && Number.isFinite(lastUpdatedSlot) && trackedValue === value && now >= lastUpdatedSlot) {
            const steps = Math.floor((now - lastUpdatedSlot) / settings.intervalMinutes);
            nextValue = steps > 0 ? relaxedFluidValue(part, value, steps) : value;
            nextSlot = steps > 0 ? lastUpdatedSlot + steps * settings.intervalMinutes : lastUpdatedSlot;
          }

          if (nextValue !== value) {
            if (!fluidChanged) fluidState = { ...fluidState };
            fluidState[part] = nextValue;
            fluidChanged = true;
          }
          if (saved?.value !== nextValue || saved?.lastUpdatedSlot !== nextSlot) {
            characterTrackers[part] = { value: nextValue, lastUpdatedSlot: nextSlot };
            changed = true;
          }
        }

        if (fluidChanged) {
          if (characters === state.characters) characters = { ...state.characters };
          characters[characterId] = {
            ...character,
            situationStats: {
              ...stats,
              fluidState,
              dailyInternalEjaculationCount: fluidState.uterus,
            },
          };
          changed = true;
        }
        if (trackers[characterId] !== characterTrackers) trackers[characterId] = characterTrackers;
      }

      if (!changed) return state;
      return {
        ...state,
        characters,
        mods: {
          ...(state.mods || {}),
          [api.id]: { ...modData, fluidDecay: { characters: trackers } },
        },
      };
    }

    function syncFluidDecay() {}
    api.store.subscribe(() => publishCurrentWifePromptProfile());
    publishCurrentWifePromptProfile();

    function normalizeDialogueRule(rule, index = 0) {
      if (!rule || typeof rule !== 'object') return null;
      const text = typeof rule.text === 'string' ? rule.text : '';
      const positivePrompt = typeof rule.positivePrompt === 'string' ? rule.positivePrompt : '';
      const negativePrompt = typeof rule.negativePrompt === 'string' ? rule.negativePrompt : '';
      return {
        id: typeof rule.id === 'string' && rule.id ? rule.id : `dialogue-import-${index + 1}-${shortHash(text)}`,
        text,
        positivePrompt,
        negativePrompt,
        duration: rule.duration === 'minutes' ? 'minutes' : 'scene',
        minutes: Math.max(1, Math.min(1440, Math.floor(Number(rule.minutes) || 10))),
        outfitStates: Object.prototype.hasOwnProperty.call(rule, 'outfitStates')
          ? normalizeOutfitStates(rule.outfitStates)
          : normalizeOutfitStates(rule.outfitMode),
      };
    }

    function currentDialogueRules() {
      const saved = api.settings.get({ dialogueRules: DEFAULT_DIALOGUE_RULES });
      return Array.isArray(saved.dialogueRules)
        ? saved.dialogueRules.map(normalizeDialogueRule).filter(Boolean)
        : DEFAULT_DIALOGUE_RULES.map(normalizeDialogueRule).filter(Boolean);
    }

    function normalizeSituationConfig(value) {
      const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
      return {
        prompts: { ...DEFAULT_PROMPTS, ...importedPrompts(source.prompts, DEFAULT_PROMPTS) },
        negativePrompts: { ...DEFAULT_NEGATIVE_PROMPTS, ...importedPrompts(source.negativePrompts, DEFAULT_NEGATIVE_PROMPTS) },
        outfitStates: { ...DEFAULT_OUTFIT_STATES, ...importedOutfitStates(source.outfitStates, source.outfitModes) },
        dialogueRules: Array.isArray(source.dialogueRules)
          ? source.dialogueRules.map(normalizeDialogueRule).filter(Boolean)
          : DEFAULT_DIALOGUE_RULES.map(normalizeDialogueRule).filter(Boolean),
      };
    }

    function normalizeSituationPresets(value) {
      if (!Array.isArray(value)) return [];
      const presets = [];
      const used = new Set([LEGACY_SITUATION_PRESET_ID]);
      for (const [index, entry] of value.slice(0, MAX_SITUATION_PRESETS).entries()) {
        if (!entry || typeof entry !== 'object' || Array.isArray(entry)) continue;
        let id = String(entry.id || '').trim();
        if (!/^[a-z0-9][a-z0-9_-]{0,79}$/i.test(id) || used.has(id)) id = `preset-${index + 1}-${shortHash(String(entry.name || index))}`;
        while (used.has(id)) id = `${id}-${presets.length + 1}`;
        used.add(id);
        presets.push({
          id,
          name: String(entry.name || '').trim().slice(0, 80) || `프리셋 ${presets.length + 1}`,
          ...normalizeSituationConfig(entry),
        });
      }
      return presets;
    }

    function currentSituationPresets() {
      return normalizeSituationPresets(api.settings.get({ situationPresets: [] }).situationPresets);
    }

    function legacySituationConfig() {
      return {
        id: LEGACY_SITUATION_PRESET_ID,
        name: '기본 프리셋',
        prompts: currentPrompts(),
        negativePrompts: currentNegativePrompts(),
        outfitStates: currentOutfitStates(),
        dialogueRules: currentDialogueRules(),
      };
    }

    function activeSituationConfig() {
      if (activeSituationPresetId === LEGACY_SITUATION_PRESET_ID) return legacySituationConfig();
      const preset = currentSituationPresets().find(entry => entry.id === activeSituationPresetId);
      if (preset) return preset;
      activeSituationPresetId = LEGACY_SITUATION_PRESET_ID;
      return legacySituationConfig();
    }

    function saveActiveSituationSection(section, value) {
      if (activeSituationPresetId === LEGACY_SITUATION_PRESET_ID) {
        api.settings.set({ [section]: value });
        return;
      }
      const presets = currentSituationPresets();
      if (!presets.some(entry => entry.id === activeSituationPresetId)) {
        activeSituationPresetId = LEGACY_SITUATION_PRESET_ID;
        api.settings.set({ [section]: value });
        return;
      }
      api.settings.set({
        situationPresets: presets.map(entry => entry.id === activeSituationPresetId ? { ...entry, [section]: value } : entry),
      });
    }

    function normalizeSituationPresetAssignments(value, presets = currentSituationPresets()) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
      const presetIds = new Set([LEGACY_SITUATION_PRESET_ID, ...presets.map(entry => entry.id)]);
      return Object.fromEntries(Object.entries(value).flatMap(([characterId, presetId]) => {
        const id = String(characterId || '').trim();
        const selected = String(presetId ?? '');
        return id && id.length <= 120 && (selected === '' || presetIds.has(selected)) ? [[id, selected]] : [];
      }));
    }

    function currentSituationPresetAssignments(presets = currentSituationPresets()) {
      return normalizeSituationPresetAssignments(api.settings.get({ situationPresetAssignments: {} }).situationPresetAssignments, presets);
    }

    function situationPresetCharacterKeys(character, characterId) {
      const generated = character?.generatedArchetype;
      return [...new Set([
        generated?.id, generated?.shortname, character?.wifeArchetypeId, character?.archetypeId,
        character?.shortname, character?.id, characterId,
      ].map(value => String(value || '').trim()).filter(Boolean))];
    }

    function situationConfigForCharacter(character, characterId) {
      const presets = currentSituationPresets();
      const assignments = currentSituationPresetAssignments(presets);
      const assignedCharacter = situationPresetCharacterKeys(character, characterId)
        .find(id => Object.prototype.hasOwnProperty.call(assignments, id));
      const presetId = assignedCharacter ? assignments[assignedCharacter] : LEGACY_SITUATION_PRESET_ID;
      if (!presetId) return null;
      return presetId === LEGACY_SITUATION_PRESET_ID
        ? legacySituationConfig()
        : presets.find(entry => entry.id === presetId) || legacySituationConfig();
    }

    function importedPrompts(source, defaults) {
      const imported = {};
      if (!source || typeof source !== 'object' || Array.isArray(source)) return imported;
      for (const key of Object.keys(defaults)) {
        if (Object.prototype.hasOwnProperty.call(source, key) && typeof source[key] === 'string') imported[key] = source[key];
      }
      return imported;
    }

    function importedOutfitStates(source, legacySource) {
      const imported = {};
      for (const key of Object.keys(DEFAULT_OUTFIT_STATES)) {
        if (source && typeof source === 'object' && !Array.isArray(source) && Object.prototype.hasOwnProperty.call(source, key)) {
          imported[key] = normalizeOutfitStates(source[key]);
        } else if (legacySource && typeof legacySource === 'object' && !Array.isArray(legacySource) && Object.prototype.hasOwnProperty.call(legacySource, key)) {
          imported[key] = normalizeOutfitStates(legacySource[key]);
        }
      }
      return imported;
    }

    function importPromptSettings(text) {
      const parsed = JSON.parse(text);
      const positive = importedPrompts(parsed?.prompts ?? parsed, DEFAULT_PROMPTS);
      const negative = importedPrompts(parsed?.negativePrompts, DEFAULT_NEGATIVE_PROMPTS);
      const outfitStates = importedOutfitStates(parsed?.outfitStates, parsed?.outfitModes);
      const hasDialogueRules = Array.isArray(parsed?.dialogueRules);
      const hasFluidDecay = parsed?.fluidDecay && typeof parsed.fluidDecay === 'object' && !Array.isArray(parsed.fluidDecay);
      const hasResiduePrompts = parsed?.residuePrompts && typeof parsed.residuePrompts === 'object' && !Array.isArray(parsed.residuePrompts);
      const hasCustomTags = Array.isArray(parsed?.customTags);
      const hasCharacterPrompt = parsed?.characterPrompt && typeof parsed.characterPrompt === 'object' && !Array.isArray(parsed.characterPrompt);
      const hasOutfitPrompts = parsed?.outfitPrompts && typeof parsed.outfitPrompts === 'object' && !Array.isArray(parsed.outfitPrompts);
      const hasNativeAxisPrompts = parsed?.nativeAxisPrompts && typeof parsed.nativeAxisPrompts === 'object' && !Array.isArray(parsed.nativeAxisPrompts);
      const hasContextStatePrompts = parsed?.contextStatePrompts && typeof parsed.contextStatePrompts === 'object' && !Array.isArray(parsed.contextStatePrompts);
      const hasPositionPresetPrompts = parsed?.positionPresetPrompts && typeof parsed.positionPresetPrompts === 'object' && !Array.isArray(parsed.positionPresetPrompts);
      const hasPositionPresetNegativePrompts = parsed?.positionPresetNegativePrompts && typeof parsed.positionPresetNegativePrompts === 'object' && !Array.isArray(parsed.positionPresetNegativePrompts);
      const hasPositionGroupPrompts = parsed?.positionGroupPrompts && typeof parsed.positionGroupPrompts === 'object' && !Array.isArray(parsed.positionGroupPrompts);
      const hasSituationPresets = Array.isArray(parsed?.situationPresets);
      const hasSituationPresetAssignments = parsed?.situationPresetAssignments && typeof parsed.situationPresetAssignments === 'object' && !Array.isArray(parsed.situationPresetAssignments);
      const situationPresets = hasSituationPresets ? normalizeSituationPresets(parsed.situationPresets) : currentSituationPresets();
      const wives = Array.isArray(parsed?.wives) ? parsed.wives.filter(entry =>
        entry && typeof entry === 'object'
        && typeof entry.id === 'string' && entry.id.trim()
        && entry.inputs && typeof entry.inputs === 'object' && !Array.isArray(entry.inputs)) : [];
      if (!Object.keys(positive).length && !Object.keys(negative).length && !Object.keys(outfitStates).length && !hasDialogueRules && !hasFluidDecay && !hasResiduePrompts && !hasCustomTags && !hasCharacterPrompt && !hasOutfitPrompts && !hasNativeAxisPrompts && !hasContextStatePrompts && !hasPositionPresetPrompts && !hasPositionPresetNegativePrompts && !hasPositionGroupPrompts && !hasSituationPresets && !hasSituationPresetAssignments && !wives.length) throw new Error('가져올 수 있는 설정 항목이 없습니다.');
      for (const entry of wives) {
        customWifeStore.getState().save({
          id: entry.id.trim(),
          inputs: { ...entry.inputs },
          ...(typeof entry.portraitKey === 'string' ? { portraitKey: entry.portraitKey } : {}),
          ...(typeof entry.portraitUrl === 'string' ? { portraitUrl: entry.portraitUrl } : {}),
        });
      }
      return {
        characterPrompt: hasCharacterPrompt ? normalizeCharacterPrompt(parsed.characterPrompt) : currentCharacterPrompt(),
        outfitPrompts: hasOutfitPrompts ? normalizeOutfitPrompts(parsed.outfitPrompts) : currentOutfitPrompts(),
        nativeAxisPrompts: hasNativeAxisPrompts ? ImageStudio_기본축설정정규화하기(parsed.nativeAxisPrompts) : ImageStudio_기본축설정읽기(),
        contextStatePrompts: hasContextStatePrompts ? ImageStudio_맥락상태설정정규화하기(parsed.contextStatePrompts) : ImageStudio_맥락상태설정읽기(),
        situationPresets,
        situationPresetAssignments: hasSituationPresetAssignments
          ? normalizeSituationPresetAssignments(parsed.situationPresetAssignments, situationPresets)
          : currentSituationPresetAssignments(situationPresets),
        positionPresetPrompts: hasPositionPresetPrompts ? normalizePositionPresetPrompts(parsed.positionPresetPrompts) : currentPositionPresetPrompts(),
        positionPresetNegativePrompts: hasPositionPresetNegativePrompts ? normalizePositionPresetPrompts(parsed.positionPresetNegativePrompts) : currentPositionPresetNegativePrompts(),
        positionGroupPrompts: hasPositionGroupPrompts ? normalizePositionGroupPrompts(parsed.positionGroupPrompts) : currentPositionGroupPrompts(),
        prompts: { ...currentPrompts(), ...positive },
        negativePrompts: { ...currentNegativePrompts(), ...negative },
        outfitStates: { ...currentOutfitStates(), ...outfitStates },
        dialogueRules: hasDialogueRules ? parsed.dialogueRules.map(normalizeDialogueRule).filter(Boolean) : currentDialogueRules(),
        fluidDecay: hasFluidDecay ? normalizeFluidDecaySettings(parsed.fluidDecay) : currentFluidDecaySettings(),
        residuePrompts: hasResiduePrompts ? normalizeResiduePrompts(parsed.residuePrompts) : currentResiduePrompts(),
        customTags: hasCustomTags ? normalizeCustomTags(parsed.customTags) : currentCustomTags(),
      };
    }

    function cleanPrompt(value) {
      return typeof value === 'string' ? value.trim() : '';
    }

    function parseMap(value) {
      const result = {};
      for (const line of String(value || '').split(/\r?\n/)) {
        const separator = line.indexOf('=');
        if (separator < 1) continue;
        const key = line.slice(0, separator).trim();
        const prompt = line.slice(separator + 1).trim();
        if (key && prompt) result[key] = prompt;
      }
      return result;
    }

    function band(value) {
      const number = Math.max(0, Math.min(100, Number(value) || 0));
      if (number < 20) return 0;
      if (number < 40) return 1;
      if (number < 60) return 2;
      if (number < 80) return 3;
      return 4;
    }

    function externalFluidTier(count) {
      if (count >= 10) return 4;
      if (count >= 6) return 3;
      if (count >= 3) return 2;
      if (count >= 1) return 1;
      return 0;
    }

    function fluidTier(part, count) {
      if (part === 'uterus') return Math.max(0, Math.min(4, Math.floor(Number(count) || 0)));
      if (part === 'thighs') return count >= 6 ? 2 : count >= 1 ? 1 : 0;
      return externalFluidTier(count);
    }

    function vulvaTier(character, drives) {
      const arousal = Math.max(0, Math.min(100, Number(character?.stats?.arousal) || 0));
      const desire = Math.max(0, Math.min(100, Number(drives?.desire) || 0));
      return band(arousal * 0.7 + desire * 0.3);
    }

    function characterIdOf(state, character) {
      for (const [id, candidate] of Object.entries(state.characters || {})) {
        if (candidate === character) return id;
        if (character?.id && candidate?.id === character.id) return id;
        if (character?.shortname && candidate?.shortname === character.shortname) return id;
      }
      return null;
    }

    function addPrompt(target, code, value) {
      const prompt = cleanPrompt(value);
      if (!prompt || target.codes.includes(code)) return;
      target.codes.push(code);
      target.tags.push(prompt);
    }

// BadGuest 1.4.1 effects/equipment 및 구 상태를 읽기만 합니다. 제작자 코어/저장은 변경하지 않습니다.
function ImageStudio_나쁜손님자료읽기(state) {
  return state?.mods?.badguest ?? state?.mods?.BadGuest ?? state?.mods?.['bad-guest'] ?? state?.modData?.BadGuest ?? {};
}

function ImageStudio_나쁜손님상태읽기(state, character, characterId) {
  if (characterId !== state?.primaryCharacterId) return {};
  const data = ImageStudio_나쁜손님자료읽기(state), slot = Number(state.slot) || 0;
  const active = effect => effect?.startedAtSlot != null && Number(effect.startedAtSlot) <= slot
    && (effect.endsAtSlot == null || slot < Number(effect.endsAtSlot));
  const modernEffects = data.effects && typeof data.effects === 'object';
  const modernEquipment = data.equipment && typeof data.equipment === 'object';
  const visible = item => !!item && (item.active === true || item.afterUntilSlot != null && slot < Number(item.afterUntilSlot));
  const room = modernEquipment ? api.fn('wifeLocation')(state) : null;
  const worn = kind => visible(data.equipment?.[kind]) && data.equipment[kind].roomId === room;
  const restraint = data.restraint, legacyVisible = visible(restraint);
  const legacyDrug = data.drugEffect, legacyActive = active(legacyDrug);
  const unconscious = ['sleeping','passed_out'].includes(character?.currentTask ?? character?.task);
  return {
    handcuffed: modernEquipment ? worn('restraint') : legacyVisible,
    blindfolded: modernEquipment ? worn('blindfold') : !!(legacyVisible && restraint.blindfolded
      || visible(data.blindfold) || data.blindfolded === true || character?.badGuestBlindfolded === true),
    gagged: modernEquipment ? worn('gag') : !!(legacyVisible && restraint.gagged
      || visible(data.gag) || data.gagged === true || character?.badGuestGagged === true),
    drugged: modernEffects ? active(data.effects.aphrodisiac) : Number(character?.badGuestDrugArousal) > 0
      || legacyActive && (!legacyDrug.type || legacyDrug.type === 'aphrodisiac'),
    hallucinated: !modernEffects && (Number(character?.badGuestHallucinatedUntilSlot) > slot
      || legacyActive && legacyDrug.type === 'hallucinogen'),
    confused: !unconscious && !!modernEffects && active(data.effects.confusion),
    intoxicated: !!modernEffects && active(data.effects.intoxicationFloor),
    unconscious,
  };
}

function ImageStudio_입마개상태인가(state, character, characterId) {
  return ImageStudio_나쁜손님상태읽기(state, character, characterId).gagged === true;
}

function ImageStudio_나쁜손님프롬프트읽기(state, character, characterId, prompts) {
  if (characterId !== state?.primaryCharacterId) return null;
  const flags = ImageStudio_나쁜손님상태읽기(state, character, characterId), result = { codes: [], tags: [] };
  for (const code of ['handcuffed','blindfolded','gagged','drugged','hallucinated','confused','intoxicated']) {
    if (flags[code]) addPrompt(result, code, prompts['badguest.' + code]);
  }
  return result.tags.length ? result : null;
}

    function detailPromptState(state, character, characterId, prompts, drives) {
      if (characterId !== state.primaryCharacterId) return null;
      const result = { codes: [], tags: [] };
      const stats = effectiveHeroineStats(state);
      const relationship = relationshipPanelStatus(state);
      const wellbeing = 100 - (Number(wellbeingSignals(state)?.total) || 0);
      const intoxication = intoxicationBand(character?.intoxication?.level || 0);

      for (const [name, value] of [['energy', stats.energy], ['mood', stats.mood], ['arousal', stats.arousal], ['wellbeing', wellbeing]]) {
        const tier = band(value);
        addPrompt(result, `${name}-${tier}`, prompts[`status.${name}.${tier}`]);
      }
      if (Number(allureScore(character)) >= 60) addPrompt(result, 'allure-high', prompts['status.allure.high']);
      if (Number(relationship.trust) < 30) addPrompt(result, 'trust-low', prompts['status.trust.low']);
      if (Number(relationship.desire) >= 60) addPrompt(result, 'desire-high', prompts['status.desire.high']);
      if (Number(relationship.resentment) >= 60) addPrompt(result, 'resentment-high', prompts['status.resentment.high']);
      else if (Number(relationship.resentment) >= 35) addPrompt(result, 'resentment-medium', prompts['status.resentment.medium']);
      if (Number(relationship.drift?.raw) >= 35) addPrompt(result, 'drift-high', prompts['status.drift.high']);
      if (Number(relationship.latitude?.raw) < 0) addPrompt(result, 'latitude-negative', prompts['status.latitude.negative']);
      if (intoxication !== 'sober') addPrompt(result, `intoxication-${intoxication}`, prompts[`status.intoxication.${intoxication}`]);

      const feelingPrompts = parseMap(prompts['status.feelings.map']);
      for (const feeling of topFeelings(character, 2)) {
        if (Number(feeling.intensity) > 15) addPrompt(result, `feeling-${feeling.emotion}`, feelingPrompts[feeling.emotion]);
      }
      const drivePrompts = parseMap(prompts['status.drives.map']);
      const strongestDrive = Object.entries(drives || {}).sort((left, right) => Number(right[1]) - Number(left[1]))[0];
      if (strongestDrive && Number(strongestDrive[1]) > 35) {
        addPrompt(result, `drive-${strongestDrive[0]}`, drivePrompts[strongestDrive[0]]);
      }
      return result.tags.length ? result : null;
    }

    function fluidPromptStates(character, prompts, drives) {
      const hStatus = character?.situationStats;
      const hasFluid = hStatus && typeof hStatus.fluidState === 'object';
      const hasJewelry = hStatus && typeof hStatus.jewelryState === 'object';
      if (!hasFluid && !hasJewelry) return [];
      const groups = [];
      for (const { part, label } of FLUID_PARTS) {
        const result = { codes: [], tags: [] };
        if (hasFluid) {
          const tier = part === 'vulva'
            ? vulvaTier(character, drives)
            : fluidTier(part, hStatus.fluidState?.[part]);
          addPrompt(result, `${part}-${tier}`, prompts[`fluid.${part}.${tier}`]);
        }
        if (hasJewelry && part === 'breasts') {
          const stage = Math.max(0, Math.min(3, Math.floor(Number(hStatus.jewelryState?.breasts?.stage) || 0)));
          addPrompt(result, `jewelry-breasts-${stage}`, prompts[`jewelry.breasts.${stage}`]);
        }
        if (hasJewelry && part === 'vulva') {
          const stage = Math.max(0, Math.min(1, Math.floor(Number(hStatus.jewelryState?.vulva?.stage) || 0)));
          addPrompt(result, `jewelry-vulva-${stage}`, prompts[`jewelry.vulva.${stage}`]);
        }
        if (result.tags.length) groups.push({ id: `body-${part}`, label: api.t({ ko: `부위별 상태 · ${label}`, en: `Body status · ${part}` }), value: result });
      }
      return groups;
    }

    const dialogueTextCache = new Map();
    function dialogueText(value) {
      const source = String(value || '');
      const cached = dialogueTextCache.get(source);
      if (cached !== undefined) return cached;
      const result = source.replace(/\s+/g, ' ').trim().toLocaleLowerCase();
      if (dialogueTextCache.size >= 4096) dialogueTextCache.delete(dialogueTextCache.keys().next().value);
      dialogueTextCache.set(source, result);
      return result;
    }

    function dialogueLogs(state) {
      const logs = Array.isArray(state.log) ? state.log.slice(-200) : [];
      return settingsStore?.getState?.().proximityMode === true
        ? logs.filter(entry => entry?.coLocated !== false)
        : logs;
    }

    function outfitIdFor(character, imageKey) {
      const keyOutfit = typeof imageKey === 'string'
        ? imageKey.match(/(?:^|__)outfit-(.+?)(?=__|$)/)?.[1]
        : '';
      return String(keyOutfit || character?.outfit || '').trim().toLocaleLowerCase();
    }

    const NUDE_OUTFITS = new Set(['nude', 'naked', 'slave_collar', 'ribbon_only', 'sx_naked', 'sx_chains']);
    const SKIRTLESS_OUTFITS = new Set(['his_shirt', 'lingerie', 'panties_only']);
    const PARTIAL_OUTFITS = new Set([
      'bath_linen_wrap', 'bath_shift', 'bath_towel', 'bath_bindings', 'bath_sheer_chemise',
      'linen_shift', 'barmaid_corset', 'wench_bodice', 'his_shirt', 'crop_blouse_skirt',
      'breast_band_skirt', 'strapless_thigh_boots', 'silk_robe', 'lingerie', 'pink_babydoll',
      'auburn_babydoll', 'satin_babydoll', 'sheer_chemise', 'sheer_nightgown', 'panties_only',
      'naked_apron',
    ]);

    function outfitStateOf(outfitId) {
      if (NUDE_OUTFITS.has(outfitId) || outfitId.endsWith('+nude')) return 'nude';
      return PARTIAL_OUTFITS.has(outfitId) ? 'partial' : 'clothed';
    }

    function exposureFlags(imageKey, character) {
      return ImageStudio_노출플래그읽기(imageKey, character);
    }

    function promptPart(key) {
      return String(key || '').match(/^(?:fluid|jewelry)\.([^.]+)/)?.[1] || '';
    }

    function partIsExposed(key, outfitId, imageKey, character) {
      const part = promptPart(key);
      if (!part) return false;
      if (part === 'mouth') return true;
      if (outfitStateOf(outfitId) === 'nude') return true;
      const exposed = exposureFlags(imageKey, character);
      if (part === 'breasts') return exposed.topPulledDown || exposed.topRemoved || outfitId === 'panties_only';
      if (part === 'thighs') return exposed.skirtUp || exposed.skirtRemoved
        || ['crop_blouse_skirt', 'breast_band_skirt', 'strapless_thigh_boots', 'lingerie', 'pink_babydoll', 'auburn_babydoll', 'satin_babydoll', 'panties_only'].includes(outfitId);
      if (part === 'uterus') return exposed.skirtUp || exposed.skirtRemoved
        || SKIRTLESS_OUTFITS.has(outfitId);
      return exposed.pantiesAside || exposed.pantiesRemoved;
    }

    function outfitAllows(states, outfitId, key = '', imageKey = '', character = null) {
      states = normalizeOutfitStates(states);
      if (ALL_OUTFIT_STATES.every(state => states.includes(state))) return true;
      return (!!outfitId && states.includes(outfitStateOf(outfitId)))
        || (states.includes(EXPOSED_OUTFIT_STATE[0]) && partIsExposed(key, outfitId, imageKey, character));
    }

    function promptsForOutfit(prompts, outfitStates, outfitId, imageKey, character) {
      return Object.fromEntries(Object.entries(prompts).map(([key, value]) => [
        key,
        outfitAllows(outfitStates[key], outfitId, key, imageKey, character) ? value : '',
      ]));
    }

    function sceneFamilyKey(imageKey) {
      if (typeof imageKey !== 'string') return '';
      return imageKey.split('__').filter((part, index) => index === 0
        || /^(?:scene|task|room|grp|gslot|focus)-/.test(part)).join('__');
    }

    function logImageKeyAt(logs, index) {
      for (let cursor = index; cursor >= 0; cursor -= 1) {
        if (typeof logs[cursor]?.imageKey === 'string') return logs[cursor].imageKey;
      }
      return '';
    }

    function dialoguePromptState(state, rules, imageKey, promptField, outfitId) {
      const logs = dialogueLogs(state);
      const currentScene = sceneFamilyKey(imageKey);
      const result = { codes: [], tags: [] };
      for (const rule of rules) {
        if (!cleanPrompt(rule[promptField])) continue;
        if (!outfitAllows(rule.outfitStates, outfitId)) continue;
        const wanted = dialogueText(rule.text);
        if (!wanted) continue;
        let matchIndex = -1;
        for (let index = logs.length - 1; index >= 0; index -= 1) {
          if (dialogueText(logs[index]?.text).includes(wanted)) {
            matchIndex = index;
            break;
          }
        }
        if (matchIndex < 0) continue;
        const entry = logs[matchIndex];
        const active = rule.duration === 'minutes'
          ? Number(state.slot) - Number(entry.slot) >= 0 && Number(state.slot) - Number(entry.slot) < rule.minutes
          : sceneFamilyKey(logImageKeyAt(logs, matchIndex)) === currentScene
            || (!logImageKeyAt(logs, matchIndex) && Number(entry.slot) === Number(state.slot));
        if (active) addPrompt(result, `dialogue-${rule.id}`, rule[promptField]);
      }
      return result.tags.length ? result : null;
    }

    function shortHash(value) {
      let hash = 2166136261;
      for (let index = 0; index < value.length; index += 1) {
        hash ^= value.charCodeAt(index);
        hash = Math.imul(hash, 16777619);
      }
      return (hash >>> 0).toString(36);
    }

    function promptGroups(state, character, characterId, prompts, outfitStates, dialogueRules, imageKey, promptField) {
      const drives = heroineDriveCalc(state);
      const outfitId = outfitIdFor(character, imageKey);
      const scopedPrompts = promptsForOutfit(prompts, outfitStates, outfitId, imageKey, character);
      const composition = { codes: [], tags: [] };
      addPrompt(composition, 'composition-global', scopedPrompts['composition.global']);
      return [
        { id: 'composition', label: api.t({ ko: '구도 프롬프트', en: 'Composition prompt' }), value: composition.tags.length ? composition : null },
        { id: 'badguest', label: api.t({ ko: '나쁜 손님 모드용', en: 'Bad Guest' }), value: ImageStudio_나쁜손님프롬프트읽기(state, character, characterId, scopedPrompts) },
        { label: api.t({ ko: '상세 상태', en: 'Detailed status' }), value: detailPromptState(state, character, characterId, scopedPrompts, drives) },
        ...fluidPromptStates(character, scopedPrompts, drives),
        { id: 'dialogue', label: api.t({ ko: '대화 감지', en: 'Dialogue match' }), value: dialoguePromptState(state, dialogueRules, imageKey, promptField, outfitId) },
      ].filter(group => group.value);
    }

    function characterPromptGroup(state, character, characterId, promptField) {
      if (characterId !== state.primaryCharacterId) return null;
      const registered = character?.generatedArchetype?.attentionImagePrompt;
      const override = characterPromptOverride(currentWifePromptContext(state, characterId, character));
      const characterPrompt = override || (registered ? {
        ...normalizeCharacterPrompt(registered),
        negativePrompt: normalizedWifeNegative(registered.negativePrompt),
      } : null);
      if (!characterPrompt) return null;
      const tags = promptTokens(characterPrompt[promptField]);
      const clearsBaseNegative = promptField === 'negativePrompt' && characterPrompt.mode === 'replace' && Boolean(registered);
      if (!tags.length && !clearsBaseNegative) return null;
      return {
        id: 'character',
        label: api.t({ ko: '아내 캐릭터', en: 'Wife character' }),
        mode: characterPrompt.mode,
        imagePolicy: characterPrompt.imagePolicy,
        value: { codes: [`character.${characterPrompt.mode}`], tags },
      };
    }

    function outfitPromptGroup(character, imageKey, promptField) {
      const rawId = outfitIdFor(character, imageKey);
      const canonicalId = String(outfitById(rawId)?.id || rawId || '').trim();
      const prompts = currentOutfitPrompts();
      const override = prompts[canonicalId] || prompts[rawId];
      if (!override) return null;
      return {
        id: 'outfit',
        label: api.t({ ko: '의상 프롬프트', en: 'Outfit prompt' }),
        mode: 'replace',
        value: { codes: [`outfit.${canonicalId || rawId}`], tags: promptTokens(override[promptField]) },
      };
    }

    function nativeCharacterNegative(character) {
      const archetype = character?.generatedArchetype
        ?? (character?.archetypeId ? wifeArchetypeById(character.archetypeId) : null);
      return String(archetype?.imageNegative || '').trim();
    }

    function promptContext(state, character, characterId, imageKey) {
      const situationConfig = host.planning ? ImageStudio_계획상황설정읽기(character, characterId) : situationConfigForCharacter(character, characterId);
      const characterPositive = characterPromptGroup(state, character, characterId, 'positivePrompt');
      const characterNegative = characterPromptGroup(state, character, characterId, 'negativePrompt');
      const outfitPositive = outfitPromptGroup(character, imageKey, 'positivePrompt');
      const outfitNegative = outfitPromptGroup(character, imageKey, 'negativePrompt');
      const positiveGroups = [characterPositive, outfitPositive, ...(situationConfig ? (host.planning ? ImageStudio_계획상태묶음읽기(state, character, characterId, situationConfig, imageKey, 'positivePrompt') : promptGroups(state, character, characterId, situationConfig.prompts, situationConfig.outfitStates, situationConfig.dialogueRules, imageKey, 'positivePrompt')) : []), ...ImageStudio_맥락상태묶음읽기(state, character, characterId, imageKey, 'positivePrompt')].filter(Boolean);
      const negativeGroups = [characterNegative, outfitNegative, ...(situationConfig ? (host.planning ? ImageStudio_계획상태묶음읽기(state, character, characterId, situationConfig, imageKey, 'negativePrompt') : promptGroups(state, character, characterId, situationConfig.negativePrompts, situationConfig.outfitStates, situationConfig.dialogueRules, imageKey, 'negativePrompt')) : []), ...ImageStudio_맥락상태묶음읽기(state, character, characterId, imageKey, 'negativePrompt')].filter(Boolean);
      host.matchingContextSnapshot = {state,character,key:imageKey,groups:[...positiveGroups,...negativeGroups]};
      return {
        positiveGroups,
        negativeGroups,
        dialogue: [...positiveGroups, ...negativeGroups].some(group => group.id === 'dialogue'),
        situational: [...positiveGroups, ...negativeGroups].some(group => group.id !== 'character'),
        characterPolicy: (characterPositive || characterNegative)?.imagePolicy || null,
      };
    }

    function stateSignature(groups) {
      return groups.flatMap(group => [...group.value.codes, ...group.value.tags]).join('|');
    }

    function combinedStateSignature(positiveGroups, negativeGroups) {
      const positive = stateSignature(positiveGroups);
      const negative = stateSignature(negativeGroups);
      return negative ? `positive:${positive}|negative:${negative}` : positive;
    }

    function keyWithState(key, signature, dialogue = false, characterPolicy = null, situational = false) {
      const kind = dialogue ? 'dialogue' : situational ? 'state' : characterPolicy ? `character-${characterPolicy}` : 'state';
      const suffix = `__${kind}-${shortHash(signature)}`;
      if (key.includes(suffix)) return key;
      const variant = key.match(/__v-\d+$/)?.[0] || '';
      return `${variant ? key.slice(0, -variant.length) : key}${suffix}${variant}`;
    }

    function ImageStudio_나쁜손님프롬프트직접적용하기(result, state, character, characterId) {
      if (!result || !Array.isArray(result.parts)) return result;
      const config = situationConfigForCharacter(character, characterId);
      if (!config) return result;
      const outfitId = outfitIdFor(character, result.key);
      const positiveValue = ImageStudio_나쁜손님프롬프트읽기(state, character, characterId,
        promptsForOutfit(config.prompts, config.outfitStates, outfitId, result.key, character));
      const negativeValue = ImageStudio_나쁜손님프롬프트읽기(state, character, characterId,
        promptsForOutfit(config.negativePrompts, config.outfitStates, outfitId, result.key, character));
      const positive = positiveValue ? [{ id: 'badguest', label: api.t({ ko: '나쁜 손님 모드용', en: 'Bad Guest' }), value: positiveValue }] : [];
      const negative = negativeValue ? [{ id: 'badguest', label: api.t({ ko: '나쁜 손님 모드용', en: 'Bad Guest' }), value: negativeValue }] : [];
      if (!positive.length && !negative.length) return result;
      const prompt = joinPrompt(`${result.prompt || ''}, ${positive.flatMap(group => group.value.tags).join(', ')}`);
      const negativePrompt = joinPrompt(`${result.negativePrompt || ''}, ${negative.flatMap(group => group.value.tags).join(', ')}`);
      return {
        ...result,
        key: keyWithState(result.key, combinedStateSignature(positive, negative), false, null, true),
        prompt,
        negativePrompt,
        parts: [...result.parts, ...positive.map(group => ({ label: group.label, tags: group.value.tags.join(', ') }))],
        genParams: promptGenParams(prompt),
      };
    }

    function ImageStudio_구도프롬프트직접적용하기(result, state, character, characterId) {
      if (!result || !Array.isArray(result.parts)) return result;
      const config = situationConfigForCharacter(character, characterId);
      if (!config) return result;
      const outfitId = outfitIdFor(character, result.key);
      const group = (source, code) => {
        const scoped = promptsForOutfit(source, config.outfitStates, outfitId, result.key, character);
        const value = { codes: [], tags: [] };
        addPrompt(value, code, scoped['composition.global']);
        return value.tags.length
          ? { id: 'composition', label: api.t({ ko: '구도 프롬프트', en: 'Composition prompt' }), value }
          : null;
      };
      const positive = group(config.prompts, 'composition-global');
      const negative = group(config.negativePrompts, 'composition-global-negative');
      if (!positive && !negative) return result;
      const prompt = joinPrompt(`${result.prompt || ''}, ${positive?.value.tags.join(', ') || ''}`);
      const negativePrompt = joinPrompt(`${result.negativePrompt || ''}, ${negative?.value.tags.join(', ') || ''}`);
      return {
        ...result,
        key: keyWithState(result.key, combinedStateSignature(positive ? [positive] : [], negative ? [negative] : []), false, null, true),
        prompt,
        negativePrompt,
        parts: [...result.parts, ...(positive ? [{ label: positive.label, tags: positive.value.tags.join(', ') }] : [])],
        genParams: promptGenParams(prompt),
      };
    }

    function stripPositionKey(value) {
      return String(value || '').split('__').filter(part => !part.startsWith('position-')).join('__');
    }

    function positionSituationId(value) {
      const parts = stripPositionKey(value).split('__');
      const base = parts.find(part => /^(?:scene|task|look)-/.test(part)) || '';
      if (!base) return '';
      const detailPrefixes = base.startsWith('scene-')
        ? ['grp-', 'gslot-', 'abed-', 'fin-']
        : base.startsWith('look-') ? ['reaction-'] : [];
      return [base, ...detailPrefixes.map(prefix => parts.find(part => part.startsWith(prefix))).filter(Boolean)].join('|');
    }

    function positionSituationLabel(value) {
      const [base, ...details] = String(value || '').split('|');
      if (!base) return '상황 정보 없음';
      const detailLabels = details.map(detail => {
        if (detail.startsWith('grp-')) return `추가 남성 ${detail.slice(4)}명`;
        if (detail.startsWith('gslot-')) return `배치 ${positionPlacementLabel(detail.slice(6))}`;
        if (detail === 'abed-1') return '함께 침대에 있음';
        if (detail.startsWith('fin-')) return `마무리 ${detail.slice(4).replaceAll('_', ' ')}`;
        if (detail.startsWith('reaction-')) return `반응 ${detail.slice(9).replaceAll('_', ' ')}`;
        return detail.replaceAll('_', ' ');
      });
      return [base.replace(/^(?:scene|task|look)-/, '').replaceAll('_', ' '), ...detailLabels].join(' · ');
    }

    function positionPlacementLabel(groupSlots) {
      return [...String(groupSlots || '')].map((slot, index) => `${index + 1}: ${GROUP_SLOT_BY_ID[slot]?.name || slot}`).join(' / ');
    }

    function positionPlacementPrompt(groupSlots) {
      const ordinals = ['first', 'second', 'third', 'fourth', 'fifth'];
      const people = [...String(groupSlots || '')].flatMap((slot, index) => {
        const prompt = positionGroupPromptById(slot);
        return prompt ? [`(${ordinals[index]} supporting man:1.0), ${prompt}`] : [];
      });
      return people.length
        ? ['(main couple centered:1.2)', '(female and primary partner clearly visible:1.15)', '(balanced multi-person composition:1.15)', 'group_sex', 'separate_bodies', '(supporting participants:1.0)', ...people].join(', ')
        : '';
    }

    function selectedPositionGroupSlots(scene = latestScenePrompt) {
      if (!scene) return '';
      const count = positionGroupCount(scene.situationId);
      if (!count) return '';
      const nativeSlots = positionGroupSlots(scene.result.key);
      const selected = positionSelection.situationId === scene.situationId ? positionSelection.groupSlots : '';
      const draft = positionPlacementDrafts.get(scene.situationId);
      return String(draft || selected || nativeSlots).padEnd(count, 'w').slice(0, count);
    }

    function positionChoiceForImageKey(imageKey) {
      if (!host.planning) return null;
      const explicit = host.planning?.combination?.promptPosition;
      if (!explicit || explicit === 'auto' || explicit === 'none') return null;
      const candidateIds = explicit && explicit !== 'auto'
        ? (ImageStudio_자세상황에맞는가(explicit, imageKey) ? [explicit] : [])
        : ImageStudio_장면자동자세후보읽기(imageKey);
      if (!candidateIds.length) return null;
      const cleanKey = stripPositionKey(imageKey);
      const signature = candidateIds.join(';');
      const cached = positionRandomChoices.get(cleanKey);
      const index = cached?.signature === signature
        ? cached.index % candidateIds.length
        : Math.floor(Math.random() * candidateIds.length);
      positionRandomChoices.set(cleanKey, { signature, index });
      const presetId = candidateIds[index];
      const preset = ImageStudio_자세프리셋장면맞춤(positionPresetById(presetId), imageKey);
      return preset ? { presetId, preset, groupSlots: positionGroupSlots(imageKey) } : null;
    }

    function keyWithPosition(imageKey, choice) {
      if (!choice?.preset) return stripPositionKey(imageKey);
      const cleanKey = stripPositionKey(imageKey);
      const variant = cleanKey.match(/__v-\d+$/)?.[0] || '';
      const root = variant ? cleanKey.slice(0, -variant.length) : cleanKey;
      const placement = positionPlacementPrompt(choice.groupSlots);
      const slots = choice.groupSlots ? `-slots-${choice.groupSlots}` : '';
      const negativeSignature = choice.preset.negativePrompt ? `|negative:${choice.preset.negativePrompt}` : '';
      const positionedKey = `${root}__position-${choice.preset.id}${slots}-${shortHash(`${choice.preset.id}|${choice.preset.prompt}|${placement}${negativeSignature}`)}${variant}`;
      const sameGeneratedPrompt = String(choice.imageKey || '').replace(/__v-\d+$/, '') === positionedKey.replace(/__v-\d+$/, '');
      return choice.sourceKey === cleanKey && sameGeneratedPrompt ? choice.imageKey : positionedKey;
    }

    function applyPositionPreset(result, choice) {
      const preset = choice?.preset;
      if (!preset || !result || !Array.isArray(result.parts)) return result;
      if (preset.id === 'none') return { ...result, key: stripPositionKey(result.key) };
      result = ImageStudio_장면자세정리하기(result, preset);
      const placement = positionPlacementPrompt(choice.groupSlots);
      const removed = result.parts.filter(part => String(part.label || '').startsWith('체위 프리셋 ·')
        || String(part.label || '').startsWith('추가 인원 배치 ·'));
      const kept = result.parts.filter(part => !removed.includes(part));
      const keptTags = new Set(promptTokens(kept.map(part => part.tags).join(', ')).map(tag => promptTagIdentity(tag).spaced));
      const removedOnly = promptTokens(removed.map(part => part.tags).join(', '))
        .filter(tag => !keptTags.has(promptTagIdentity(tag).spaced))
        .join(', ');
      const participantTags = kept.some(part => ['성별', 'Gender'].includes(part.label)) ? [] : promptTokens(removedOnly).filter(tag =>
        /^(?:\d+\s*(?:boys?|girls?)|solo(?: focus)?|multiple (?:boys|girls)|(?:mmf|mff) threesome|threesome|group sex|gangbang)$/.test(promptTagIdentity(tag).spaced));
      const parts = [
        ...kept,
        ...(participantTags.length ? [{ label: '성별·인원 유지', tags: participantTags.join(', ') }] : []),
        { label: `체위 프리셋 · ${preset.name}`, tags: preset.prompt },
        ...(placement ? [{ label: `추가 인원 배치 · ${positionPlacementLabel(choice.groupSlots)}`, tags: placement }] : []),
      ];
      const prompt = joinPrompt(`${withoutPromptTags(result.prompt, removedOnly)}, ${participantTags.join(', ')}, ${preset.prompt}, ${placement}`);
      const negativePrompt = joinPrompt(`${result.negativePrompt || ''}, ${preset.negativePrompt || ''}`);
      return {
        ...result,
        key: keyWithPosition(result.key, choice),
        prompt,
        negativePrompt,
        parts,
        genParams: promptGenParams(prompt),
      };
    }

    function rememberLatestScenePrompt(result, state, character, characterId) {
      if (host.planning) return result;
      if (characterId !== state.primaryCharacterId || !positionSituationId(result?.key)) return result;
      const situationId = positionSituationId(result.key);
      latestScenePrompt = {
        result,
        situationId,
        characterName: String(character?.name || character?.shortname || '').trim(),
      };
      const choice = positionChoiceForImageKey(result.key);
      const groupSlots = choice?.groupSlots || positionGroupSlots(result.key);
      if (positionGroupCount(situationId) && !positionPlacementDrafts.has(situationId)) {
        positionPlacementDrafts.set(situationId, groupSlots);
      }
      if (positionSelection.situationId !== situationId) {
        positionSelection = {
          situationId,
          presetId: choice?.presetId || 'none',
          groupSlots: positionPlacementDrafts.get(situationId) || groupSlots,
        };
      }
      return result;
    }

    function promptTokens(value) {
      return [...new Set(String(value || '').split(/\r?\n/).flatMap(line => {
        const prompt = line.includes('=') ? line.slice(line.indexOf('=') + 1) : line;
        return prompt.split(',');
      }).map(tag => tag.trim()).filter(Boolean))];
    }

    function withoutPromptTags(value, excluded) {
      const blocked = new Set(promptTokens(excluded).map(tag => promptTagIdentity(tag).spaced));
      if (!blocked.size) return String(value || '').trim();
      return promptTokens(value)
        .filter(tag => !blocked.has(promptTagIdentity(tag).spaced))
        .join(', ');
    }

    function promptTagIdentity(tag) {
      const raw = String(tag || '').trim();
      const weighted = raw.match(/^\((.+?):\s*([\d.]+)\)$/);
      const core = (weighted?.[1] || raw).trim();
      const normalized = core.toLocaleLowerCase();
      return { raw, core, normalized, spaced: normalized.replaceAll('_', ' ').replace(/\s+/g, ' '), weight: weighted?.[2] || '' };
    }

    function translatedPromptTag(tag, customTags = currentCustomTags()) {
      const identity = promptTagIdentity(tag);
      const custom = customTags.find(entry => promptTagIdentity(entry.tag).normalized === identity.normalized)?.label;
      const exact = custom
        || PROMPT_TAG_KO[identity.normalized]
        || PROMPT_TAG_KO[identity.spaced]
        || window.WML_I18N_DISPLAY?.[identity.normalized]
        || window.WML_I18N_DISPLAY?.[identity.spaced];
      const translated = exact || identity.spaced.split(' ').map(word => PROMPT_WORD_KO[word] || word).join(' ');
      return identity.weight ? `${translated} · 강조 ${identity.weight}` : translated;
    }

    function promptTagCategory(tag, customTags = currentCustomTags()) {
      const identity = promptTagIdentity(tag);
      if (customTags.some(entry => promptTagIdentity(entry.tag).normalized === identity.normalized)) return 'custom';
      const value = identity.spaced;
      if (/\b(?:quality|masterpiece|blurry|anatomy|limbs|deformed|watermark|signature|duplicate|mutilated|photorealistic|realistic|3d)\b/.test(value)) return 'quality';
      if (/\b(?:tavern|bedroom|bed|kitchen|hearth|bathhouse|hallway|corridor|indoors|entrance|room|table|tables|background)\b/.test(value)) return 'location';
      if (/\b(?:light|lighting|candlelight|firelight|sconce|portrait|upper body|full body|close-up|cropped|view|focus)\b/.test(value)) return 'lighting';
      if (/\b(?:dress|blouse|skirt|apron|corset|lingerie|stockings|garter|sleeves|neckline|bodice|clothes|clothing|nude|naked|bare skin|bare shoulders|bare legs|cleavage|panties|see-through|disheveled)\b/.test(value)) return 'outfit';
      if (/\b(?:smile|expression|cheerful|content|calm|worried|weary|tired|shy|blush|scared|tense|angry|gentle|playful|flustered|surprised|seductive|pleasure|nervous|confident|afterglow|satisfied|gaze|eyes|tears|moaning|panting|aroused|arousal|longing|resentment|uneasy|guilty|humiliated|lonely|proud)\b/.test(value)) return 'mood';
      if (/\b(?:handcuff|handcuffed|handcuffs|shackle|shackles|chain|chains|bound|unable|struggling|piercing|pierced|choker|cum|pussy juice|wet pussy|drunk|unconscious|exhausted|slumped|limp|wasted|intoxicated)\b/.test(value)) return 'status';
      if (/\b(?:girl|boy|woman|man|female|male|hair|eye|breast|waist|build|figure|bust|chest|hips|thighs|tall|short|petite|slim|slender|curvy|athletic|muscular|beard|face|freckles)\b/.test(value)) return 'character';
      if (/\b(?:standing|sitting|lying|kneeling|sleeping|looking|carrying|wiping|cleaning|stirring|holding|gripping|rolling|touching|kissing|riding|straddling|handjob|fellatio|sex|anal|dancing|gesture|posture|pose)\b/.test(value)) return 'action';
      return 'other';
    }

    function portraitTagLanguage() {
      return api.settings.get({ portraitTagLanguage: 'en' }).portraitTagLanguage === 'ko' ? 'ko' : 'en';
    }

    function translatedPromptText(value) {
      return String(value || '').split(',').map(tag => {
        const trimmed = tag.trim();
        return trimmed ? translatedPromptTag(trimmed) : '';
      }).filter(Boolean).join(', ');
    }

    function updatePortraitTagNode(node, language) {
      const attribute = 'data-attention-image-prompt-original';
      if (!node.hasAttribute(attribute)) node.setAttribute(attribute, node.textContent || '');
      const original = node.getAttribute(attribute) || '';
      const display = language === 'ko' ? translatedPromptText(original) : original;
      if (node.textContent !== display) node.textContent = display;
      node.title = language === 'ko' ? `영문: ${original}` : '한글 표시로 전환할 수 있습니다.';
    }

    function decoratePortraitPromptTags() {
      const headings = [...document.querySelectorAll('span.text-stone-500.font-bold')].filter(node =>
        ['원본 자동 태그 (+)', 'Original auto tags (+)', 'Original automatic tags (+)'].includes((node.textContent || '').trim()));
      const language = portraitTagLanguage();

      for (const heading of headings) {
        const partsRoot = heading.parentElement;
        const overlay = partsRoot?.parentElement;
        if (!partsRoot || !overlay) continue;

        let toggle = overlay.querySelector('[data-attention-image-prompt-language]');
        if (!toggle) {
          toggle = document.createElement('button');
          toggle.type = 'button';
          toggle.className = 'ml-2 rounded border border-stone-600 bg-stone-800 px-2 py-0.5 text-[11px] text-stone-300 hover:bg-stone-700 hover:text-white';
          toggle.setAttribute('data-attention-image-prompt-language', '');
          toggle.setAttribute('data-wml-ui', '');
          toggle.setAttribute('data-i18n-skip', '');
          toggle.addEventListener('click', event => {
            event.preventDefault();
            event.stopPropagation();
            api.settings.set({ portraitTagLanguage: portraitTagLanguage() === 'ko' ? 'en' : 'ko' });
            decoratePortraitPromptTags();
          });
          heading.insertAdjacentElement('afterend', toggle);
        }

        const toggleText = `태그 표시: ${language === 'ko' ? '한글' : '영문'}`;
        if (toggle.textContent !== toggleText) toggle.textContent = toggleText;
        toggle.title = language === 'ko' ? '영문 태그로 전환' : '한글 태그로 전환';
        const tagNodes = [
          ...partsRoot.querySelectorAll('div > span.text-stone-300'),
          ...overlay.querySelectorAll('div > span.text-stone-500.ml-3'),
        ];
        for (const node of new Set(tagNodes)) updatePortraitTagNode(node, language);
      }
    }

    async function copyText(tag) {
      let copied = false;
      try {
        if (navigator.clipboard?.writeText) {
          await navigator.clipboard.writeText(tag);
          copied = true;
        }
      } catch { /* use the selection fallback below */ }
      if (!copied) {
        const input = document.createElement('textarea');
        input.value = tag;
        input.style.cssText = 'position:fixed;left:-9999px;top:-9999px;';
        document.body.appendChild(input);
        input.select();
        try { copied = document.execCommand('copy'); } catch { copied = false; }
        input.remove();
      }
      return copied;
    }

    async function copyPromptTag(tag, win) {
      const copied = await copyText(tag);
      settingsMessage = copied ? `영문 프롬프트를 복사했습니다: ${tag}` : '클립보드 복사가 차단되었습니다.';
      win.refresh();
    }

    function addTagToActiveTarget(tag) {
      if (!activeTagTarget) return '';
      if (activeTagTarget.kind === 'character') {
        const characterPrompt = currentWifeCharacterPrompt();
        const field = activeTagTarget.polarity === 'negative' ? 'negativePrompt' : 'positivePrompt';
        saveCurrentWifeCharacterPrompt({ [field]: appendPromptTags(characterPrompt[field], tag), sourceId: '' });
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'outfit') {
        const source = outfitPromptSources().find(entry => entry.id === activeTagTarget.id);
        if (!source) return '';
        const field = activeTagTarget.polarity === 'negative' ? 'negativePrompt' : 'positivePrompt';
        saveOutfitPromptField(source.id, field, appendPromptTags(outfitPromptValues(source)[field], tag));
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'context-state') {
        const field = activeTagTarget.polarity === 'negative' ? 'negativePrompt' : 'positivePrompt';
        ImageStudio_맥락상태필드저장하기(activeTagTarget.axis, activeTagTarget.id, field,
          appendPromptTags(ImageStudio_맥락상태프롬프트읽기(activeTagTarget.axis, activeTagTarget.id, field), tag));
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'native-axis') {
        const settings = ImageStudio_기본축설정읽기();
        const prompt = settings[activeTagTarget.axis]?.[activeTagTarget.id] || {};
        const selectedPrompt = activeTagTarget.variant !== undefined ? {...prompt,...prompt.variants?.[activeTagTarget.variant]} : prompt;
        const field = activeTagTarget.polarity === 'negative' ? 'negativePrompt' : 'positivePrompt';
        const fallback = field === 'positivePrompt' ? (activeTagTarget.variant !== undefined ? ImageStudio_장면변형기본값.get(activeTagTarget.id+':'+activeTagTarget.variant) : undefined) ?? ImageStudio_기본축기본값[activeTagTarget.axis]?.get(activeTagTarget.id) ?? '' : '';
        ImageStudio_기본축필드저장하기(activeTagTarget.axis, activeTagTarget.id, field, appendPromptTags(selectedPrompt[field] ?? fallback, tag), activeTagTarget.variant);
        return activeTagTarget.label;
      }
      if (activeTagTarget.kind === 'field') {
        const setting = activeTagTarget.polarity === 'negative' ? 'negativePrompts' : 'prompts';
        const current = activeSituationConfig()[setting];
        saveActiveSituationSection(setting, { ...current, [activeTagTarget.key]: appendPromptTags(current[activeTagTarget.key], tag) });
        return activeTagTarget.label;
      }
      const field = activeTagTarget.polarity === 'negative' ? 'negativePrompt' : 'positivePrompt';
      saveActiveSituationSection('dialogueRules', activeSituationConfig().dialogueRules.map(rule => rule.id === activeTagTarget.id
        ? { ...rule, [field]: appendPromptTags(rule[field], tag) }
        : rule));
      return activeTagTarget.label;
    }

    async function useLibraryTag(tag, win) {
      const copied = await copyText(tag);
      const target = addTagToActiveTarget(tag);
      settingsMessage = target
        ? `${translatedPromptTag(tag)} 태그를 ${target}에 추가${copied ? '하고 영문을 복사' : ''}했습니다.`
        : copied ? `영문 프롬프트를 복사했습니다: ${tag}` : '클립보드 복사가 차단되었습니다.';
      win.refresh();
    }

    function allPromptTags(customTags = currentCustomTags()) {
      const characterPrompt = currentWifeCharacterPrompt();
      const configured = [
        characterPrompt.positivePrompt,
        characterPrompt.negativePrompt,
        ...Object.values(currentOutfitPrompts()).flatMap(prompt => [prompt.positivePrompt, prompt.negativePrompt]),
        ...Object.values(ImageStudio_기본축설정읽기()).flatMap(axis => Object.values(axis).flatMap(prompt => [prompt.positivePrompt, prompt.negativePrompt, ...Object.values(prompt.variants || {}).flatMap(row => [row.positivePrompt,row.negativePrompt])])),
        ...Object.values(ImageStudio_맥락상태설정읽기()).flatMap(axis => Object.values(axis).flatMap(prompt => [prompt.positivePrompt, prompt.negativePrompt])),
        ...Object.values(currentPrompts()),
        ...Object.values(currentNegativePrompts()),
        ...currentDialogueRules().flatMap(rule => [rule.positivePrompt, rule.negativePrompt]),
      ].flatMap(promptTokens);
      return [...new Set([...Object.keys(PROMPT_TAG_KO), ...customTags.map(entry => entry.tag), ...configured])].sort((left, right) =>
        translatedPromptTag(left, customTags).localeCompare(translatedPromptTag(right, customTags), 'ko'));
    }

    function saveCustomTag(label, tag, win) {
      label = String(label || '').trim();
      tag = String(tag || '').trim();
      if (!label || !tag) {
        settingsMessage = '한글 표시명과 영문 태그를 모두 입력해 주세요.';
        win.refresh();
        return;
      }
      const current = currentCustomTags().filter(entry => entry.tag.toLocaleLowerCase() !== tag.toLocaleLowerCase());
      api.settings.set({ customTags: [...current, { tag, label }] });
      settingsMessage = `사용자 태그를 저장했습니다: ${label} · ${tag}`;
      win.refresh();
    }

    function removeCustomTag(tag, win) {
      api.settings.set({ customTags: currentCustomTags().filter(entry => entry.tag.toLocaleLowerCase() !== tag.toLocaleLowerCase()) });
      settingsMessage = `사용자 태그를 삭제했습니다: ${tag}`;
      win.refresh();
    }

    function promptTagChips(h, value, win) {
      const tags = promptTokens(value);
      if (!tags.length) return null;
      return h('div', { style: 'display:flex;flex-wrap:wrap;gap:5px;margin-top:2px;' },
        h('span', { class: 'wml-muted wml-small', style: 'width:100%;' }, '한글 태그 · 클릭하면 영문 복사'),
        ...tags.map(tag => h('button', {
          type: 'button',
          title: `영문 복사: ${tag}`,
          'data-prompt-tag': tag,
          style: 'border:1px solid #57534e;border-radius:999px;background:#292524;color:#f5f5f4;padding:4px 8px;font-size:11px;cursor:pointer;',
          onclick: () => copyPromptTag(tag, win),
        }, translatedPromptTag(tag))),
      );
    }

    function appendPromptTags(current, added) {
      return [...new Set([...promptTokens(current), ...promptTokens(added)])].join(', ');
    }

    function promptTagAdder(h, value, onAdd, id) {
      let pending = '';
      const input = h('input', {
        type: 'text',
        placeholder: '영문 태그 · 쉼표로 여러 개 추가 가능',
        'data-prompt-tag-input': id,
        style: 'min-width:220px;flex:1;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:6px 8px;font:12px/1.4 ui-monospace,Consolas,monospace;',
        oninput: event => { pending = event.currentTarget.value; },
        onkeydown: event => {
          if (event.key !== 'Enter') return;
          event.preventDefault();
          const next = appendPromptTags(value, pending);
          if (next !== value) onAdd(next);
        },
      });
      return h('div', { style: 'display:flex;gap:6px;align-items:center;flex-wrap:wrap;' },
        input,
        h('button', {
          type: 'button',
          'data-prompt-tag-add': id,
          class: 'wml-btn',
          onclick: () => {
            const next = appendPromptTags(value, pending);
            if (next !== value) onAdd(next);
          },
        }, '태그 추가'),
      );
    }

    function outfitStateChecks(h, selected, onChange, id, allowExposed = false) {
      const options = allowExposed ? [...OUTFIT_STATE_OPTIONS, EXPOSED_OUTFIT_STATE] : OUTFIT_STATE_OPTIONS;
      return h('fieldset', { style: 'border:1px solid #57534e;border-radius:6px;padding:6px 8px;margin:0;' },
        h('legend', { class: 'wml-muted wml-small', style: 'padding:0 4px;' }, '적용할 옷 상태 · 복수 선택'),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px 12px;' },
          ...options.map(([value, label]) => h('label', { style: 'display:flex;align-items:center;gap:5px;font-size:12px;' },
            h('input', {
              type: 'checkbox',
              checked: selected.includes(value),
              'data-outfit-state': `${id}:${value}`,
              onchange: event => onChange(event.currentTarget.checked
                ? [...new Set([...selected, value])]
                : selected.filter(state => state !== value)),
            }),
            label,
          )),
        ),
      );
    }

    function renderSituationPresets(h, win) {
      const presets = currentSituationPresets();
      const active = activeSituationConfig();
      const assignments = currentSituationPresetAssignments(presets);
      const sources = wifePromptSources();
      const inputStyle = 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;';
      const options = [
        [LEGACY_SITUATION_PRESET_ID, '기본 프리셋'],
        ...presets.map(entry => [entry.id, entry.name]),
      ];
      const activeCustom = presets.find(entry => entry.id === active.id);
      return [
        h('div', { class: 'wml-section', style: 'display:grid;gap:8px;margin-bottom:10px;' },
          h('label', { style: 'display:grid;gap:4px;' },
            h('strong', { style: 'font-size:12px;' }, '편집할 프리셋'),
            h('select', {
              value: active.id,
              'data-situation-preset-editor': '',
              style: inputStyle,
              onchange: event => {
                activeSituationPresetId = event.currentTarget.value;
                activeTagTarget = null;
                win.refresh();
              },
            }, ...options.map(([id, name]) => h('option', { value: id, selected: id === active.id }, name))),
          ),
          activeCustom ? h('label', { style: 'display:grid;gap:4px;' },
            h('span', { class: 'wml-muted wml-small' }, '프리셋 이름'),
            h('input', {
              type: 'text', maxlength: 80, value: activeCustom.name,
              'data-situation-preset-name': activeCustom.id,
              style: inputStyle,
              onchange: event => {
                const name = String(event.currentTarget.value || '').trim().slice(0, 80);
                if (name) api.settings.set({ situationPresets: presets.map(entry => entry.id === activeCustom.id ? { ...entry, name } : entry) });
                win.refresh();
              },
            }),
          ) : null,
          h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;' },
            api.ui.button('현재 설정을 복제해 새 프리셋 추가', () => {
              if (presets.length >= MAX_SITUATION_PRESETS) return;
              situationPresetCounter += 1;
              const used = new Set(presets.map(entry => entry.id));
              let id = `preset-${Date.now().toString(36)}-${situationPresetCounter}`;
              while (used.has(id)) id = `${id}-${situationPresetCounter += 1}`;
              const name = `${active.name} 복사 ${presets.length + 1}`;
              api.settings.set({ situationPresets: [...presets, { id, name, ...normalizeSituationConfig(active) }] });
              activeSituationPresetId = id;
              activeTagTarget = null;
              settingsMessage = `${name} 프리셋을 만들었습니다.`;
              win.refresh();
            }, { primary: true, disabled: presets.length >= MAX_SITUATION_PRESETS }),
            activeCustom ? api.ui.button('현재 프리셋 삭제', () => {
              if (!window.confirm(`“${activeCustom.name}” 프리셋을 삭제할까요?`)) return;
              const nextAssignments = Object.fromEntries(Object.entries(assignments)
                .map(([characterId, presetId]) => [characterId, presetId === activeCustom.id ? '' : presetId]));
              api.settings.set({
                situationPresets: presets.filter(entry => entry.id !== activeCustom.id),
                situationPresetAssignments: nextAssignments,
              });
              activeSituationPresetId = LEGACY_SITUATION_PRESET_ID;
              activeTagTarget = null;
              settingsMessage = `${activeCustom.name} 프리셋을 삭제했습니다.`;
              win.refresh();
            }) : null,
          ),
          h('p', { class: 'wml-muted wml-small', style: 'margin:0;' }, '선택한 프리셋에서 바꾼 상황·상태·H Status·대화 설정은 모드 전용 저장소에 즉시 저장됩니다. 기본 프리셋은 기존 JSON 구조와 연결됩니다.'),
        ),
        h('div', { class: 'wml-section' },
          h('strong', { style: 'font-size:12px;' }, '캐릭터별 적용 프리셋'),
          h('p', { class: 'wml-muted wml-small', style: 'margin:4px 0 8px;' }, '각 캐릭터는 미적용 또는 하나의 프리셋만 선택할 수 있습니다.'),
          h('div', { style: 'display:grid;gap:7px;' }, ...sources.map(source => {
            const selected = Object.prototype.hasOwnProperty.call(assignments, source.id)
              ? assignments[source.id]
              : LEGACY_SITUATION_PRESET_ID;
            return h('label', { style: 'display:grid;grid-template-columns:minmax(120px,1fr) minmax(180px,2fr);align-items:center;gap:8px;' },
              h('span', { class: 'wml-small' }, source.name),
              h('select', {
                value: selected,
                'data-situation-preset-character': source.id,
                style: inputStyle,
                onchange: event => {
                  const next = { ...currentSituationPresetAssignments() };
                  const presetId = event.currentTarget.value;
                  if (presetId === LEGACY_SITUATION_PRESET_ID) delete next[source.id];
                  else next[source.id] = presetId;
                  api.settings.set({ situationPresetAssignments: next });
                  win.refresh();
                },
              },
              h('option', { value: '', selected: selected === '' }, '미적용'),
              ...options.map(([id, name]) => h('option', { value: id, selected: selected === id }, name))),
            );
          })),
        ),
      ];
    }

    function renderDialogueRules(h, win) {
      const rules = activeSituationConfig().dialogueRules;
      const inputStyle = 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;';
      const update = (id, patch) => {
        saveActiveSituationSection('dialogueRules', activeSituationConfig().dialogueRules.map(rule => rule.id === id ? { ...rule, ...patch } : rule));
        win.refresh();
      };
      const remove = id => {
        saveActiveSituationSection('dialogueRules', activeSituationConfig().dialogueRules.filter(rule => rule.id !== id));
        win.refresh();
      };
      return [
        ...rules.map((rule, index) => h('div', { class: 'wml-section', style: 'margin-bottom:10px;' },
          h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;' },
            h('strong', {}, `규칙 ${index + 1}`),
            api.ui.button('삭제', () => remove(rule.id)),
          ),
          h('label', { style: 'display:grid;gap:4px;margin-bottom:8px;' },
            h('span', { class: 'wml-muted wml-small' }, '감지할 대화 문구 · 포함 일치'),
            h('input', { type: 'text', value: rule.text, placeholder: '예: 절대로 놓아주지 않겠어', style: inputStyle, onchange: event => update(rule.id, { text: event.currentTarget.value }) }),
          ),
          h('label', { style: 'display:grid;gap:4px;margin-bottom:8px;' },
            h('span', { class: 'wml-muted wml-small' }, '추가할 Positive 프롬프트'),
            h('textarea', { rows: 2, value: rule.positivePrompt, spellcheck: false, style: `${inputStyle}resize:vertical;min-height:52px;`,
              onfocus: () => { activeTagTarget = { kind: 'dialogue', id: rule.id, polarity: 'positive', label: `대화 규칙 ${index + 1} Positive` }; },
              onchange: event => update(rule.id, { positivePrompt: event.currentTarget.value }) }),
            promptTagChips(h, rule.positivePrompt, win),
            promptTagAdder(h, rule.positivePrompt, value => update(rule.id, { positivePrompt: value }), `${rule.id}:positive`),
          ),
          h('label', { style: 'display:grid;gap:4px;margin-bottom:8px;' },
            h('span', { class: 'wml-muted wml-small' }, '추가할 Negative 프롬프트'),
            h('textarea', { rows: 2, value: rule.negativePrompt, spellcheck: false, style: `${inputStyle}resize:vertical;min-height:52px;`,
              onfocus: () => { activeTagTarget = { kind: 'dialogue', id: rule.id, polarity: 'negative', label: `대화 규칙 ${index + 1} Negative` }; },
              onchange: event => update(rule.id, { negativePrompt: event.currentTarget.value }) }),
            promptTagChips(h, rule.negativePrompt, win),
            promptTagAdder(h, rule.negativePrompt, value => update(rule.id, { negativePrompt: value }), `${rule.id}:negative`),
          ),
          h('div', { style: 'display:flex;align-items:end;gap:8px;flex-wrap:wrap;' },
            h('label', { style: 'display:grid;gap:4px;min-width:160px;flex:1;' },
              h('span', { class: 'wml-muted wml-small' }, '적용 유지 범위'),
              h('select', { value: rule.duration, 'data-dialogue-duration': rule.id, style: inputStyle, onchange: event => update(rule.id, { duration: event.currentTarget.value }) },
                h('option', { value: 'scene', selected: rule.duration === 'scene' }, '상황이 끝날 때까지'),
                h('option', { value: 'minutes', selected: rule.duration === 'minutes' }, '지정한 시간 동안'),
              ),
            ),
            outfitStateChecks(h, rule.outfitStates, states => update(rule.id, { outfitStates: states }), rule.id),
            rule.duration === 'minutes' ? h('label', { style: 'display:grid;gap:4px;width:110px;' },
              h('span', { class: 'wml-muted wml-small' }, '유지 시간(분)'),
              h('input', { type: 'number', min: 1, max: 1440, value: rule.minutes, style: inputStyle, onchange: event => update(rule.id, { minutes: Math.max(1, Math.min(1440, Math.floor(Number(event.currentTarget.value) || 1))) }) }),
            ) : null,
          ),
        )),
        rules.length ? null : h('p', { class: 'wml-muted wml-small' }, '등록된 대화 규칙이 없습니다.'),
        api.ui.button('대화 규칙 추가', () => {
          dialogueRuleCounter += 1;
          saveActiveSituationSection('dialogueRules', [...activeSituationConfig().dialogueRules, {
            id: `dialogue-${Date.now().toString(36)}-${dialogueRuleCounter}`,
            text: '',
            positivePrompt: '',
            negativePrompt: '',
            duration: 'scene',
            minutes: 10,
            outfitStates: [...ALL_OUTFIT_STATES],
          }]);
          win.refresh();
        }, { primary: true }),
      ];
    }

    function renderFluidDecaySettings(h, win) {
      const settings = currentFluidDecaySettings();
      const save = patch => {
        api.settings.set({ fluidDecay: { ...currentFluidDecaySettings(), ...patch } });
        syncFluidDecay(true);
        win.refresh();
      };
      return h('div', { class: 'wml-section', style: 'margin-bottom:10px;' },
        h('strong', { style: 'font-size:12px;' }, '정액 상태 자동 완화'),
        h('p', { class: 'wml-muted wml-small', style: 'margin:4px 0 8px;' }, '입·가슴·자궁의 정액 상태를 마지막 갱신부터 설정 시간마다 한 단계씩 낮추며, 실제 H-Status 값도 함께 갱신합니다.'),
        h('div', { style: 'display:flex;align-items:end;gap:12px;flex-wrap:wrap;' },
          h('label', { style: 'display:flex;align-items:center;gap:6px;font-size:12px;padding-bottom:7px;' },
            h('input', {
              type: 'checkbox',
              checked: settings.enabled,
              'data-fluid-decay-enabled': 'true',
              onchange: event => save({ enabled: event.currentTarget.checked }),
            }),
            '자동 완화 사용',
          ),
          h('label', { style: 'display:grid;gap:4px;width:150px;' },
            h('span', { class: 'wml-muted wml-small' }, '단계 완화 간격(분)'),
            h('input', {
              type: 'number', min: 1, max: 1440, value: settings.intervalMinutes,
              disabled: !settings.enabled,
              'data-fluid-decay-minutes': 'true',
              style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
              onchange: event => save({ intervalMinutes: Math.max(1, Math.min(1440, Math.floor(Number(event.currentTarget.value) || DEFAULT_FLUID_DECAY.intervalMinutes))) }),
            }),
          ),
        ),
      );
    }

    function residueCharacterKey(state, character, characterId) {
      const generated = character?.generatedArchetype;
      const direct = wifeImageName(generated?.shortname || generated?.id || character?.shortname);
      if (direct && !['elena_farmgirl', 'mara_citygirl', 'pippa_waif'].includes(direct)) return direct;
      for (const value of [direct, character?.id, characterId, character?.wifeArchetypeId, character?.archetypeId, generated?.basedOn]) {
        const match = String(value || '').toLocaleLowerCase().match(/(?:^|_)(elena|mara|pippa|hina)(?:_|$)/);
        if (match) return match[1];
      }
      return direct || wifeImageName(character?.id || characterId);
    }

    function residueImageKey(part) {
      const state = api.store.game();
      const characterId = state?.primaryCharacterId;
      const character = state?.characters?.[characterId];
      const characterKey = residueCharacterKey(state, character, characterId);
      if (!characterKey || !character) return '';
      const stats = character.situationStats || {};
      const fluidState = stats.fluidState || {};
      const jewelry = stats.jewelryState || {};
      const tier = part === 'vulva'
        ? Math.max(vulvaTier(character, heroineDriveCalc(state)), Math.max(0, Math.min(1, Math.floor(Number(jewelry.vulva?.stage) || 0))))
        : fluidTier(part, fluidState[part]);
      if (part === 'uterus') {
        const vaginalSex = Number(stats.eventCounts?.vaginalSex) || 0;
        const widthTier = vaginalSex >= 20 ? 2 : vaginalSex >= 5 ? 1 : 0;
        return `situation_fluid__${characterKey}__uterus__width-${widthTier}__stage-${tier}`;
      }
      if (part === 'breasts' && Number(jewelry.breasts?.stage) > 0) {
        const stage = Math.max(0, Math.min(3, Math.floor(Number(jewelry.breasts.stage) || 0)));
        return `situation_fluid__${characterKey}__breasts__stage-${tier}__jewelry-${jewelry.breasts.type || 'piercing'}-stage-${stage}`;
      }
      if (part === 'vulva') {
        const stage = Math.max(0, Math.min(1, Math.floor(Number(jewelry.vulva?.stage) || 0)));
        return `situation_vulva__${characterKey}__wetness-${tier}__jewelry-${stage}`;
      }
      return `situation_fluid__${characterKey}__${part}__stage-${tier}`;
    }

    async function residueBasePrompt(imageKey) {
      publishCurrentWifePromptProfile();
      const bridge = globalThis.__waywardSituationEventMod;
      return typeof bridge?.promptForImage === 'function' ? bridge.promptForImage(imageKey) : null;
    }

    async function regenerateResidueImage(imageKey, button = null) {
      const originalText = button?.textContent || '이미지 재생성';
      if (button) { button.disabled = true; button.textContent = '생성 중…'; }
      let requestKey = imageKey;
      try {
        if (!api.has('imageGenerate')) throw new Error('이미지 생성 기능을 찾지 못했습니다.');
        const prompt = await residueBasePrompt(imageKey);
        if (!prompt?.prompt) throw new Error('잔류 상태 기본 프롬프트를 불러오지 못했습니다.');
        const params = promptGenParams(prompt.prompt);
        residueVariantId = Math.max(Date.now(), residueVariantId + 1);
        requestKey = `${imageKey}__v-${residueVariantId}`;
        const result = await api.fn('imageGenerate')({
          imageKey: requestKey,
          prompt: prompt.prompt,
          negativePrompt: prompt.negativePrompt || '',
          workflow: prompt.workflow || 'illustrious',
          width: Number(prompt.width) || 1152,
          height: Number(prompt.height) || 896,
          steps: params?.steps,
          cfg: params?.cfg,
          loraStrength: params?.loraStrength,
          bypassCache: false,
          debug: { source: 'attention-image-prompt-residue' },
        });
        if (result?.draft) { positionGeneration.message = '검수창에 이미지를 준비했습니다. 저장을 눌러 승인하세요.';  return true; }
        if (!result?.url) throw new Error('이미지 서버에서 결과를 받지 못했습니다.');
        saveResidueImageChoice(imageKey, { key: requestKey, url: String(result.url), createdAt: Date.now() });
        window.dispatchEvent(new CustomEvent('wayward-image-connection297'));
        scheduleUiScan();
        if (button) button.textContent = '완료';
        return true;
      } catch (error) {
        console.warn('[attention-image-prompt] residue regeneration', error);
        if (diagnostics.lastGeneration?.key !== requestKey || diagnostics.lastGeneration.status === 'running') {
          diagnostics.lastGeneration = {
            at: Date.now(), key: requestKey, status: 'error', durationMs: 0, error: diagnosticText(error),
          };
        }
        if (button) button.textContent = '생성 실패';
        return false;
      } finally {
        if (button) setTimeout(() => { button.disabled = false; button.textContent = originalText; }, 1400);
      }
    }

    async function openResiduePromptEditor(imageKey, label) {
      const base = await residueBasePrompt(imageKey);
      const saved = currentResiduePrompts()[imageKey];
      let positivePrompt = saved?.positivePrompt ?? base?.prompt ?? '';
      let negativePrompt = saved?.negativePrompt ?? base?.negativePrompt ?? '';
      let message = base ? '' : '기본 프롬프트를 불러오지 못했습니다.';
      const win = api.ui.window({
        id: 'residue-prompt-editor', title: `잔류 상태 프롬프트 · ${label}`, width: 820, height: 700,
        render(body, windowHandle) {
          const h = api.ui.h;
          const inputStyle = 'width:100%;box-sizing:border-box;resize:vertical;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:8px;font:12px/1.5 ui-monospace,Consolas,monospace;';
          body.replaceChildren(h('div', {},
            h('p', { class: 'wml-muted wml-small', style: 'overflow-wrap:anywhere;' }, imageKey),
            h('label', { style: 'display:grid;gap:5px;margin-bottom:10px;' },
              h('strong', { style: 'font-size:12px;' }, '전체 Positive 프롬프트'),
              h('textarea', { rows: 12, value: positivePrompt, spellcheck: false, style: inputStyle, oninput: event => { positivePrompt = event.currentTarget.value; } }),
            ),
            h('label', { style: 'display:grid;gap:5px;margin-bottom:10px;' },
              h('strong', { style: 'font-size:12px;' }, '전체 Negative 프롬프트'),
              h('textarea', { rows: 8, value: negativePrompt, spellcheck: false, style: inputStyle, oninput: event => { negativePrompt = event.currentTarget.value; } }),
            ),
            h('div', { style: 'display:flex;gap:6px;flex-wrap:wrap;' },
              api.ui.button('저장', () => {
                if (!positivePrompt.trim()) { message = 'Positive 프롬프트는 비워 둘 수 없습니다.'; windowHandle.refresh(); return; }
                api.settings.set({ residuePrompts: { ...currentResiduePrompts(), [imageKey]: { positivePrompt, negativePrompt } } });
                message = '저장했습니다. 다음 재생성부터 적용됩니다.';
                windowHandle.refresh();
              }, { primary: true }),
              api.ui.button('기본값으로 복원', () => {
                const next = { ...currentResiduePrompts() };
                delete next[imageKey];
                api.settings.set({ residuePrompts: next });
                positivePrompt = base?.prompt || '';
                negativePrompt = base?.negativePrompt || '';
                message = '이 카드의 프롬프트를 기본값으로 복원했습니다.';
                windowHandle.refresh();
              }),
              api.ui.button('저장 후 재생성', async () => {
                if (!positivePrompt.trim()) { message = 'Positive 프롬프트는 비워 둘 수 없습니다.'; windowHandle.refresh(); return; }
                api.settings.set({ residuePrompts: { ...currentResiduePrompts(), [imageKey]: { positivePrompt, negativePrompt } } });
                message = await regenerateResidueImage(imageKey) ? '저장한 프롬프트로 이미지를 다시 생성했습니다.' : '재생성에 실패했습니다. 이미지 서버 연결을 확인해 주세요.';
                windowHandle.refresh();
              }),
            ),
            message ? h('p', { class: 'wml-note', style: 'margin-top:8px;' }, message) : null,
          ));
        },
      });
      win.refresh();
    }

    function openResidueImagePicker(imageKey, label) {
      const win = api.ui.window({
        id: 'residue-image-picker', title: `잔류 상태 이미지 선택 · ${label}`, width: 900, height: 720,
        render(body, windowHandle) {
          const h = api.ui.h;
          const entry = currentResidueImageChoices()[imageKey] || { selected: '', items: [] };
          const choose = selected => {
            selectResidueImage(imageKey, selected);
            windowHandle.refresh();
          };
          body.replaceChildren(h('div', {},
            h('p', { class: 'wml-note' }, '자동 이미지는 현재 상태의 기본 이미지를 사용합니다. 재생성한 이미지는 아래에서 골라 계속 사용할 수 있습니다.'),
            h('div', { style: 'margin:10px 0 14px;' },
              api.ui.button(entry.selected ? '자동 이미지 사용' : '자동 이미지 사용 중', () => choose(''), { primary: !entry.selected }),
            ),
            entry.items.length
              ? h('div', { style: 'display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:10px;' },
                ...entry.items.map(item => {
                  const selected = item.key === entry.selected;
                  return h('button', {
                    type: 'button',
                    title: selected ? '현재 선택된 이미지' : '이 이미지 사용',
                    'data-residue-image-choice': item.key,
                    onclick: () => choose(item.key),
                    style: `display:grid;gap:6px;text-align:left;border:2px solid ${selected ? '#f59e0b' : '#57534e'};border-radius:8px;background:#1c1917;color:#e7e5e4;padding:7px;cursor:pointer;`,
                  },
                  h('img', { src: item.url, alt: `${label} 재생성 이미지`, loading: 'lazy', style: 'width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:5px;background:#0c0a09;' }),
                  h('span', { style: 'font-size:11px;overflow-wrap:anywhere;' }, selected ? '선택됨' : new Date(item.createdAt).toLocaleString()));
                }))
              : h('p', { class: 'wml-muted wml-small' }, '아직 보존된 재생성 이미지가 없습니다.'),
          ));
        },
      });
      win.refresh();
    }

    function decorateResidueCards() {
      const sections = document.querySelectorAll('.ko-se-secret .ko-se-fluid-section');
      sections.forEach(section => {
        const cards = section.querySelectorAll('.ko-se-fluid-grid > .ko-se-fluid-card');
        cards.forEach((card, index) => {
          const partInfo = FLUID_PARTS[index];
          if (!partInfo) return;
          const imageKey = residueImageKey(partInfo.part);
          if (!imageKey) return;
          const previousKey = card.dataset.attentionResidueKey;
          card.dataset.attentionResidueKey = imageKey;
          const entry = currentResidueImageChoices()[imageKey] || { selected: '', items: [] };
          const selected = entry.items.find(item => item.key === entry.selected) || null;
          const image = card.querySelector('img.ko-se-fluid-image');
          if (image) {
            const currentSrc = image.getAttribute?.('src') || image.src;
            if (previousKey !== imageKey || (!image.dataset.attentionResidueSelected && (!selected || currentSrc !== selected.url))) {
              image.dataset.attentionResidueAutoSrc = currentSrc;
            }
            if (selected) {
              image.dataset.attentionResidueSelected = selected.key;
              if (currentSrc !== selected.url) image.src = selected.url;
            } else if (image.dataset.attentionResidueSelected) {
              const autoUrl = image.dataset.attentionResidueAutoSrc;
              delete image.dataset.attentionResidueSelected;
              if (autoUrl && currentSrc !== autoUrl) image.src = autoUrl;
            }
          }
          const existingControls = card.querySelector('[data-attention-residue-controls]');
          if (existingControls && previousKey !== imageKey) existingControls.remove();
          const existingPicker = card.querySelector('[data-attention-residue-select]');
          if (existingPicker) existingPicker.textContent = `이미지 선택 (${entry.items.length})`;
          if (card.querySelector('[data-attention-residue-controls],[data-ko-se-residue-settings],[data-ko-se-residue-regenerate]')) return;
          const controls = document.createElement('div');
          controls.dataset.attentionResidueControls = '';
          controls.dataset.wmlUi = '';
          controls.style.cssText = 'display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;padding:0 8px 8px;background:#0c0a09;';
          const button = (text, action) => {
            const element = document.createElement('button');
            element.type = 'button';
            element.textContent = text;
            element.style.cssText = 'flex:1;border:1px solid #57534e;border-radius:5px;background:#292524;color:#e7e5e4;padding:6px 8px;font-size:11px;cursor:pointer;';
            element.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); action(element); });
            return element;
          };
          const pickerButton = button(`이미지 선택 (${entry.items.length})`, () => openResidueImagePicker(imageKey, partInfo.label));
          pickerButton.dataset.attentionResidueSelect = '';
          controls.append(
            button('프롬프트 수정', () => openResiduePromptEditor(imageKey, partInfo.label)),
            button('이미지 재생성', element => regenerateResidueImage(imageKey, element)),
            pickerButton,
          );
          card.append(controls);
        });
      });
    }

    function ensureSecretTabCompatibility() {
      const portraitSelector = 'button[title*="초상화"],button[title*="Portrait"]';
      const modernBars = new Set([...document.querySelectorAll('#root button[title*="초상화"],#root button[title*="Portrait"]')].map(button => button.parentElement).filter(Boolean));
      const candidates = new Set([...modernBars, ...document.querySelectorAll('#root div.flex.flex-wrap.border-b')]);
      for (const bar of candidates) {
        const buttons = [...bar.children].filter(node => node.tagName === 'BUTTON');
        const portrait = bar.querySelector(portraitSelector);
        const status = modernBars.has(bar)
          ? buttons.find(node => node !== portrait && !node.hasAttribute('data-ko-se-secret-tab'))
          : buttons.find(node => /^(상태|Stats)$/.test(node.textContent.trim()));
        if (!status) continue;
        const secret = bar.querySelector('[data-ko-se-secret-tab]');
        if (secret && modernBars.has(bar)) {
          if (secret.previousElementSibling !== status) status.after(secret);
          secret.classList.add('flex-1', 'py-1.5', 'border-l', 'transition-colors');
          secret.classList.remove('px-2', 'desk:px-3', 'rounded-t', '-mb-px', 'border-b-2');
          secret.dataset.attentionSecretLayout = 'current';
          continue;
        }
        if (secret || bar.dataset.attentionSecretTabKick || !globalThis.__waywardSituationEventMod) continue;
        bar.dataset.attentionSecretTabKick = 'true';
        const originalClass = bar.className;
        const originalChildren = [...bar.children];
        bar.classList.add('flex-wrap', 'border-b');
        if (buttons[0] !== status) bar.insertBefore(status, buttons[0]);
        setTimeout(() => {
          if (!status.isConnected || status.parentElement !== bar) return;
          originalChildren.forEach(node => { if (node.parentElement === bar) bar.append(node); });
          const addedSecret = bar.querySelector('[data-ko-se-secret-tab]');
          if (addedSecret) bar.append(addedSecret);
          bar.className = originalClass;
          scheduleUiScan();
        }, 0);
      }
    }

    function renderCharacterPrompt(h, win) {
      const context = currentWifePromptContext();
      const override = characterPromptOverride(context);
      const characterPrompt = currentWifeCharacterPrompt(context);
      const sources = wifePromptSources();
      const negative = activePromptPolarity === 'negative';
      const field = negative ? 'negativePrompt' : 'positivePrompt';
      const value = characterPrompt[field];
      const save = next => {
        saveCurrentWifeCharacterPrompt({ [field]: next, sourceId: '' });
        win.refresh();
      };
      return [
        h('div', {
          'data-current-wife-character': context.wifeKey,
          class: 'wml-note',
          style: 'margin-bottom:10px;',
        }, `현재 아내 · ${context.name}${context.wifeKey ? ` (${context.wifeKey})` : ''}`),
        h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
          h('strong', { style: 'font-size:12px;' }, '외형 프롬프트 불러오기'),
          h('select', {
            value: override?.sourceId || '',
            'data-character-prompt-source': '',
            style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
            onchange: event => {
              const sourceId = event.currentTarget.value;
              const source = sources.find(entry => entry.id === sourceId);
              if (source) {
                const prompt = promptFromWifeArchetype(source.archetype);
                saveCurrentWifeCharacterPrompt({
                  positivePrompt: prompt.positivePrompt,
                  negativePrompt: prompt.negativePrompt,
                  sourceId,
                });
              } else {
                saveCurrentWifeCharacterPrompt({ sourceId: '' });
              }
              win.refresh();
            },
          },
          h('option', { value: '', selected: !override?.sourceId }, '현재 적용 중인 외형 · 직접 수정'),
          ...sources.map(source => h('option', { value: source.id, selected: source.id === override?.sourceId }, `${source.custom ? '사용자 아내' : source.modded ? '모드 아내' : '기본 캐릭터'} · ${source.name}`))),
          h('span', { class: 'wml-muted wml-small' }, '선택한 캐릭터의 전체 Positive·Negative 외형을 현재 아내에게 불러옵니다.'),
        ),
        !negative ? h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
          h('strong', { style: 'font-size:12px;' }, '기존 장면 이미지 처리'),
          h('select', {
            value: characterPrompt.imagePolicy,
            'data-character-image-policy': '',
            style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
            onchange: event => {
              saveCurrentWifeCharacterPrompt({ imagePolicy: event.currentTarget.value === 'regenerate' ? 'regenerate' : 'reuse' });
              win.refresh();
            },
          },
          h('option', { value: 'reuse', selected: characterPrompt.imagePolicy === 'reuse' }, '기존 이미지 우선 · 필요한 장면만 수동 생성'),
          h('option', { value: 'regenerate', selected: characterPrompt.imagePolicy === 'regenerate' }, '정확한 이미지가 없으면 장면별 자동 생성')),
          h('span', { class: 'wml-muted wml-small' }, '기존 이미지 우선은 대량 재생성을 막습니다. 초상화의 이미지 추가 버튼으로 만든 새 이미지에는 수정한 프롬프트가 적용됩니다.'),
        ) : null,
        h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
          h('strong', { style: 'font-size:12px;' }, negative ? '현재 적용 중인 캐릭터 전용 Negative 프롬프트' : '현재 적용 중인 전체 Positive 외형 프롬프트'),
          h('textarea', {
            rows: 5,
            value,
            spellcheck: false,
            'data-character-prompt': activePromptPolarity,
            style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:100px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
            onfocus: () => { activeTagTarget = { kind: 'character', polarity: activePromptPolarity, label: `아내 캐릭터 ${negative ? 'Negative' : 'Positive'}` }; },
            onchange: event => save(event.currentTarget.value),
          }),
          promptTagChips(h, value, win),
          promptTagAdder(h, value, save, `character:${activePromptPolarity}`),
          negative ? h('span', { class: 'wml-muted wml-small' }, '게임의 품질·인원·장면별 노출 방지 Negative는 유지하고, 이 캐릭터에 필요한 태그를 교체합니다.') : null,
        ),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;' },
          api.ui.button('현재 아내 원본 외형으로 복원', () => {
            api.settings.set({ characterPrompt: { ...DEFAULT_CHARACTER_PROMPT } });
            publishCurrentWifePromptProfile();
            win.refresh();
          }),
          h('span', { class: 'wml-muted wml-small' }, '수정값은 추가되지 않고 현재 아내의 기본 외형 묶음을 교체합니다.'),
        ),
      ];
    }

    function renderOutfitPrompt(h, win) {
      const sources = outfitPromptSources();
      if (!sources.length) return [h('p', { class: 'wml-note' }, '게임에 등록된 의상 정의를 찾지 못했습니다.')];
      const currentRawId = String(currentWifePromptContext().character?.outfit || '').trim();
      const currentId = String(outfitById(currentRawId)?.id || currentRawId);
      const source = sources.find(entry => entry.id === activeOutfitPromptId)
        || sources.find(entry => entry.id === currentId)
        || sources[0];
      activeOutfitPromptId = source.id;
      const prompts = currentOutfitPrompts();
      const overridden = Object.prototype.hasOwnProperty.call(prompts, source.id);
      const negative = activePromptPolarity === 'negative';
      const field = negative ? 'negativePrompt' : 'positivePrompt';
      const value = outfitPromptValues(source, prompts)[field];
      const save = next => {
        saveOutfitPromptField(source.id, field, next);
        win.refresh();
      };
      return [
        h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
          h('strong', { style: 'font-size:12px;' }, `등록된 의상 ${sources.length}개`),
          h('select', {
            value: source.id,
            'data-outfit-prompt-source': '',
            style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
            onchange: event => {
              activeOutfitPromptId = event.currentTarget.value;
              activeTagTarget = null;
              win.refresh();
            },
          }, ...sources.map(entry => h('option', { value: entry.id, selected: entry.id === source.id }, `${entry.name} (${entry.id})`))),
          h('span', { class: 'wml-muted wml-small' }, `현재 아내 착용: ${currentId || '확인되지 않음'} · ${overridden ? '수정값 적용 중' : '등록 원본 표시 중'}`),
        ),
        source.description ? h('p', { class: 'wml-note', style: 'margin-bottom:10px;' }, source.description) : null,
        h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
          h('strong', { style: 'font-size:12px;' }, negative ? '의상 전체 Negative 프롬프트' : '의상 전체 Positive 프롬프트'),
          h('textarea', {
            rows: 5,
            value,
            spellcheck: false,
            'data-outfit-prompt': activePromptPolarity,
            style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:100px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
            onfocus: () => { activeTagTarget = { kind: 'outfit', id: source.id, polarity: activePromptPolarity, label: `${source.name} ${negative ? 'Negative' : 'Positive'}` }; },
            onchange: event => save(event.currentTarget.value),
          }),
          promptTagChips(h, value, win),
          promptTagAdder(h, value, save, `outfit:${source.id}:${activePromptPolarity}`),
        ),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;' },
          api.ui.button('이 의상 원본 프롬프트로 복원', () => {
            const next = { ...currentOutfitPrompts() };
            delete next[source.id];
            api.settings.set({ outfitPrompts: next });
            win.refresh();
          }),
          h('span', { class: 'wml-muted wml-small' }, '기본 게임과 다른 모드 파일은 수정하지 않고 이 모드의 교체값만 저장합니다.'),
        ),
      ];
    }

    function renderTagLibrary(h, win) {
      const customTags = currentCustomTags();
      const tags = allPromptTags(customTags);
      const translate = tag => translatedPromptTag(tag, customTags);
      const categorizedTags = tags.map(tag => ({ tag, category: promptTagCategory(tag, customTags) }));
      const visibleTags = activeTagCategory === 'all'
        ? categorizedTags
        : categorizedTags.filter(entry => entry.category === activeTagCategory);
      const categoryCount = id => id === 'all' ? categorizedTags.length : categorizedTags.filter(entry => entry.category === id).length;
      let pendingLabel = '';
      let pendingTag = '';
      const add = () => saveCustomTag(pendingLabel, pendingTag, win);
      return h('aside', {
        'data-tag-library': '',
        class: 'wml-section',
        style: 'flex:1 1 270px;max-width:320px;min-width:250px;align-self:flex-start;position:sticky;top:0;height:calc(100vh - 160px);max-height:720px;overflow-y:auto;overscroll-behavior:contain;scrollbar-gutter:stable;',
      },
      h('h3', { style: 'margin:0 0 4px;' }, '전체 태그 라이브러리'),
      h('p', { class: 'wml-muted wml-small', style: 'margin:0 0 8px;' },
        activeTagTarget ? `현재 입력 대상 · ${activeTagTarget.label}` : '프롬프트 입력칸을 먼저 누르면 태그가 바로 추가됩니다.'),
      h('div', { style: 'display:grid;gap:6px;padding:8px;margin-bottom:8px;border:1px solid #57534e;border-radius:6px;background:#1c1917;' },
        h('strong', { style: 'font-size:12px;' }, '사용자 태그 추가'),
        h('input', {
          type: 'text',
          placeholder: '한글 표시명',
          'data-custom-tag-label': '',
          style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:6px 8px;',
          oninput: event => { pendingLabel = event.currentTarget.value; },
        }),
        h('input', {
          type: 'text',
          placeholder: '영문 프롬프트 태그',
          'data-custom-tag-english': '',
          style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:6px 8px;font-family:ui-monospace,Consolas,monospace;',
          oninput: event => { pendingTag = event.currentTarget.value; },
          onkeydown: event => { if (event.key === 'Enter') { event.preventDefault(); add(); } },
        }),
        h('button', { type: 'button', class: 'wml-btn', 'data-custom-tag-add': '', onclick: add }, '라이브러리에 추가'),
        ...customTags.map(entry => h('div', { style: 'display:flex;align-items:center;gap:5px;font-size:11px;' },
          h('span', { style: 'min-width:0;flex:1;overflow-wrap:anywhere;' }, `${entry.label} · ${entry.tag}`),
          h('button', {
            type: 'button', class: 'wml-btn', title: '사용자 태그 삭제',
            'data-custom-tag-remove': entry.tag,
            onclick: () => removeCustomTag(entry.tag, win),
          }, '삭제'),
        )),
      ),
      h('input', {
        type: 'search',
        placeholder: '한글 또는 영문 태그 검색',
        style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;margin-bottom:8px;',
        oninput: event => {
          const query = event.currentTarget.value.trim().toLocaleLowerCase();
          const library = event.currentTarget.closest('[data-tag-library]');
          for (const button of library.querySelectorAll('[data-library-tag]')) {
            button.hidden = query && !button.getAttribute('data-tag-search').includes(query);
          }
        },
      }),
      h('div', { 'data-tag-category-tabs': '', style: 'display:flex;flex-wrap:wrap;gap:5px;margin-bottom:8px;' },
        ...TAG_CATEGORIES.filter(([id]) => id === 'all' || categoryCount(id) > 0).map(([id, label]) => h('button', {
          type: 'button',
          class: 'wml-btn',
          'data-tag-category-option': id,
          'aria-pressed': activeTagCategory === id ? 'true' : 'false',
          style: activeTagCategory === id ? 'border-color:#d97706;color:#fef3c7;background:#451a03;' : '',
          onclick: () => { activeTagCategory = id; win.refresh(); },
        }, `${label} ${categoryCount(id)}`)),
      ),
      h('div', { class: 'wml-muted wml-small', style: 'margin:0 0 6px;', 'data-active-tag-category': activeTagCategory },
        `${TAG_CATEGORIES.find(([id]) => id === activeTagCategory)?.[1] || '전체'} 태그 · ${visibleTags.length}개`),
      h('div', { style: 'display:flex;flex-wrap:wrap;gap:5px;' },
        ...visibleTags.map(({ tag, category }) => h('button', {
          type: 'button',
          'data-library-tag': tag,
          'data-library-category': category,
          'data-tag-search': `${tag} ${translate(tag)}`.toLocaleLowerCase(),
          title: `${tag} · 클릭하면 복사${activeTagTarget ? ' 및 현재 항목에 추가' : ''}`,
          style: 'border:1px solid #57534e;border-radius:999px;background:#292524;color:#f5f5f4;padding:5px 8px;font-size:11px;cursor:pointer;text-align:left;',
          onclick: () => useLibraryTag(tag, win),
        }, translate(tag))),
      ));
    }

    function selectedPositionChoice() {
      if (positionSelection.situationId !== latestScenePrompt?.situationId) return null;
      const preset = positionPresetById(positionSelection.presetId);
      if (!preset) return null;
      return { presetId: preset.id, preset, groupSlots: selectedPositionGroupSlots() };
    }

    function nextPositionVariant(baseKey) {
      if (api.has('imageVariantState')) {
        try {
          const used = new Set((api.fn('imageVariantState')(baseKey)?.variants || [])
            .map(key => Number(String(key).match(/__v-(\d+)$/)?.[1]))
            .filter(Number.isFinite));
          let next = USER_VARIANT_START;
          while (used.has(next)) next += 1;
          return next;
        } catch (error) {
          console.warn('[attention-image-prompt] image variant lookup', error);
        }
      }
      positionVariantId = Math.max(Date.now(), positionVariantId + 1);
      return positionVariantId;
    }

    async function generatePositionImage(addVariant, win) {
      const choice = selectedPositionChoice();
      const preset = choice?.preset;
      if (!latestScenePrompt || !choice) {
        positionGeneration.message = '현재 상황과 체위 프리셋을 먼저 선택해 주세요.';
        win.refresh();
        return;
      }
      if (!api.has('imageGenerate')) {
        positionGeneration.message = '이미지 생성 기능을 찾지 못했습니다.';
        win.refresh();
        return;
      }
      positionGeneration.running = true;
      positionGeneration.message = '이미지 생성 중…';
      win.refresh();
      const scene = latestScenePrompt;
      const positioned = applyPositionPreset(scene.result, choice);
      const variant = addVariant ? nextPositionVariant(positioned.key) : null;
      const imageKey = addVariant
        ? /__v-\d+$/.test(positioned.key) ? positioned.key.replace(/__v-\d+$/, `__v-${variant}`) : `${positioned.key}__v-${variant}`
        : positioned.key;
      try {
        const params = positioned.genParams || promptGenParams(positioned.prompt);
        const result = await api.fn('imageGenerate')({
          imageKey,
          prompt: positioned.prompt,
          negativePrompt: positioned.negativePrompt || '',
          width: 1216,
          height: 832,
          steps: params?.steps,
          cfg: params?.cfg,
          loraStrength: params?.loraStrength,
          checkpoint: positioned.checkpoint,
          bypassCache: !addVariant,
          debug: { source: 'attention-image-prompt-position' },
        });
        if (result?.draft) { positionGeneration.message = '검수창에 이미지를 준비했습니다. 저장을 눌러 승인하세요.'; win?.refresh?.(); return true; }
        if (!result?.url) throw new Error('이미지 서버에서 결과를 받지 못했습니다.');
        positionGeneratedResults.set(positioned.key, result);
        positionGeneratedResults.set(imageKey, result);
        positionGeneration.message = addVariant
          ? `${preset.name} 체위 이미지를 추가하고 선택했습니다.`
          : `${preset.name} 체위 이미지로 재생성했습니다.`;
      } catch (error) {
        console.warn('[attention-image-prompt] position generation', error);
        positionGeneration.message = `생성 실패: ${error.message || error}`;
      } finally {
        positionGeneration.running = false;
        win.refresh();
      }
    }

    function renderPositionSettings(h, win) {
      const scene = latestScenePrompt;
      const selectedChoice = selectedPositionChoice();
      const selected = selectedChoice?.preset || null;
      const groupCount = scene ? positionGroupCount(scene.situationId) : 0;
      const nativeSlots = scene ? positionGroupSlots(scene.result.key) : '';
      const selectedSlots = selectedPositionGroupSlots(scene);
      return [
        h('div', { 'data-position-current': '', style: 'border:1px solid #57534e;border-radius:7px;padding:9px 10px;margin-bottom:10px;background:#1c1917;' },
          h('strong', { style: 'font-size:12px;' }, scene ? `현재 상황 · ${positionSituationLabel(scene.situationId)}` : '현재 상황을 확인할 수 없음'),
          h('p', { class: 'wml-muted wml-small', style: 'margin:4px 0 0;' }, scene
            ? '게임의 현재 장면을 사용합니다. 아래 자세 선택은 수동 생성에만 적용됩니다.'
            : '게임을 시작하고 초상화가 한 번 표시된 뒤 다시 열어 주세요.'),
        ),
        ...POSITION_PRESET_GROUPS.map(group => h('div', { style: 'margin-bottom:12px;' },
          h('strong', { style: 'display:block;font-size:12px;margin-bottom:6px;' }, group.title),
          h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;' },
            ...group.presets.map(basePreset => {
              const preset = positionPresetById(basePreset.id);
              return api.ui.button(preset.name, () => {
              if (!scene) return;
              positionSelection = { situationId: scene.situationId, presetId: preset.id, groupSlots: selectedSlots || nativeSlots };
              positionGeneration.message = `${preset.name} 프리셋을 선택했습니다.`;
              win.refresh();
              }, { primary: selected?.id === preset.id, disabled: !scene });
            }),
          ),
        )),
        groupCount ? h('div', { 'data-position-group-slots': selectedSlots, style: 'border:1px solid #44403c;border-radius:7px;padding:9px 10px;margin-bottom:10px;' },
          h('strong', { style: 'display:block;font-size:12px;margin-bottom:6px;' }, `추가 인원 배치 · ${groupCount}명`),
          h('div', { style: 'display:grid;gap:6px;' }, ...Array.from({ length: groupCount }, (_, index) => h('label', {
            style: 'display:grid;grid-template-columns:90px minmax(0,1fr);align-items:center;gap:7px;font-size:12px;',
          },
          h('span', {}, `추가 인원 ${index + 1}`),
          h('select', {
            value: selectedSlots[index],
            'data-position-group-slot': String(index),
            style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:6px 8px;',
            onchange: event => {
              const slots = [...selectedSlots];
              slots[index] = event.currentTarget.value;
              const groupSlots = slots.join('');
              positionPlacementDrafts.set(scene.situationId, groupSlots);
              positionSelection = { ...positionSelection, situationId: scene.situationId, groupSlots };
              positionGeneration.message = `추가 인원 ${index + 1}의 배치를 변경했습니다.`;
              win.refresh();
            },
          }, ...GROUP_SLOT_OPTIONS.map(option => h('option', { value: option.id, selected: selectedSlots[index] === option.id }, option.name)))))),
          h('p', { class: 'wml-muted wml-small', style: 'margin:7px 0 0;' }, '현재 이미지의 gslot 배치를 기본값으로 사용하며, 각 인원의 역할을 체위 조합에 함께 저장합니다.'),
        ) : null,
        h('details', { 'data-position-group-prompts': '', style: 'border:1px solid #44403c;border-radius:7px;padding:8px 10px;margin-bottom:10px;' },
          h('summary', { style: 'cursor:pointer;font-size:12px;font-weight:700;' }, '추가 인원 배치 프롬프트 편집 (SDXL)'),
          h('p', { class: 'wml-muted wml-small', style: 'margin:7px 0;' }, '기본 프롬프트는 원래 인물을 주 피사체로 유지하면서 추가 인원도 식별 가능한 보조 역할로 표현합니다.'),
          h('div', { style: 'display:grid;gap:8px;' }, ...GROUP_SLOT_OPTIONS.map(option => {
            const prompt = positionGroupPromptById(option.id);
            const customized = Object.prototype.hasOwnProperty.call(currentPositionGroupPrompts(), option.id);
            return h('label', { style: 'display:grid;gap:5px;font-size:12px;' },
              h('strong', {}, `${option.name} (${option.id})`),
              h('textarea', {
                rows: 3,
                value: prompt,
                spellcheck: false,
                'data-position-group-prompt': option.id,
                style: 'width:100%;box-sizing:border-box;resize:vertical;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
                onchange: event => {
                  api.settings.set({ positionGroupPrompts: { ...currentPositionGroupPrompts(), [option.id]: event.currentTarget.value } });
                  positionRandomChoices.clear();
                  positionGeneration.message = `${option.name} 배치 프롬프트를 수정했습니다.`;
                  win.refresh();
                },
              }),
              api.ui.button('기본값으로 복원', () => {
                const next = { ...currentPositionGroupPrompts() };
                delete next[option.id];
                api.settings.set({ positionGroupPrompts: next });
                positionRandomChoices.clear();
                positionGeneration.message = `${option.name} 배치 프롬프트를 기본값으로 복원했습니다.`;
                win.refresh();
              }, { disabled: !customized }),
            );
          })),
        ),
        selected?.id === 'none' ? h('p', { 'data-position-none': '', class: 'wml-note' }, '적용 안함: 자세 프롬프트를 추가하지 않고 현재 장면의 프롬프트를 사용합니다.') : selected ? h('div', { 'data-position-prompt': selected.id, style: 'border:1px solid #44403c;border-radius:7px;padding:9px 10px;margin-bottom:10px;' },
          h('strong', { style: 'font-size:12px;' }, `${selected.name} · 적용할 Positive 프롬프트`),
          h('textarea', {
            rows: 4,
            value: selected.prompt,
            spellcheck: false,
            'data-position-preset-prompt': selected.id,
            style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:88px;margin-top:6px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
            onchange: event => {
              api.settings.set({ positionPresetPrompts: { ...currentPositionPresetPrompts(), [selected.id]: event.currentTarget.value } });
              positionRandomChoices.clear();
              positionGeneration.message = `${selected.name} 프롬프트를 수정했습니다.`;
              win.refresh();
            },
          }),
          h('div', { style: 'margin-top:6px;' }, promptTagChips(h, selected.prompt, win)),
          h('strong', { style: 'display:block;font-size:12px;margin-top:10px;' }, `${selected.name} · 적용할 Negative 프롬프트`),
          h('textarea', {
            rows: 3,
            value: selected.negativePrompt || '',
            spellcheck: false,
            'data-position-preset-negative': selected.id,
            style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:70px;margin-top:6px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
            onchange: event => {
              api.settings.set({ positionPresetNegativePrompts: { ...currentPositionPresetNegativePrompts(), [selected.id]: event.currentTarget.value } });
              positionRandomChoices.clear();
              positionGeneration.message = `${selected.name} Negative 프롬프트를 수정했습니다.`;
              win.refresh();
            },
          }),
          selectedChoice?.groupSlots ? h('div', { style: 'margin-top:6px;' }, promptTagChips(h, positionPlacementPrompt(selectedChoice.groupSlots), win)) : null,
          api.ui.button('이 체위 Positive·Negative 기본값으로 복원', () => {
            const next = { ...currentPositionPresetPrompts() };
            const negativeNext = { ...currentPositionPresetNegativePrompts() };
            delete next[selected.id];
            delete negativeNext[selected.id];
            api.settings.set({ positionPresetPrompts: next, positionPresetNegativePrompts: negativeNext });
            positionRandomChoices.clear();
            positionGeneration.message = `${selected.name} 프롬프트를 기본값으로 복원했습니다.`;
            win.refresh();
          }, { disabled: !Object.prototype.hasOwnProperty.call(currentPositionPresetPrompts(), selected.id) && !Object.prototype.hasOwnProperty.call(currentPositionPresetNegativePrompts(), selected.id) }),
        ) : h('p', { class: 'wml-note' }, '체위명을 클릭하면 교체할 프롬프트 묶음을 확인할 수 있습니다.'),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;' },
          api.ui.button(positionGeneration.running ? '생성 중…' : '현재 이미지 재생성', () => {
            void generatePositionImage(false, win);
          }, { primary: true, disabled: !scene || !selected || positionGeneration.running }),
          api.ui.button('이미지 추가 생성', () => {
            void generatePositionImage(true, win);
          }, { disabled: !scene || !selected || positionGeneration.running }),
        ),
        positionGeneration.message ? h('p', { class: 'wml-note', style: 'margin-top:8px;' }, positionGeneration.message) : null,
      ];
    }

    function diagnosticText(value) {
      return String(value?.message || value || '').replace(/\s+/g, ' ').trim().slice(0, 240);
    }

    function diagnosticImageName(source) {
      try {
        const url = new URL(source, window.location.href);
        return decodeURIComponent(url.pathname.split('/').filter(Boolean).at(-1) || url.pathname).slice(0, 120);
      } catch {
        return String(source || '').split(/[/?#]/).filter(Boolean).at(-1)?.slice(0, 120) || '(주소 없음)';
      }
    }

    async function runDiagnostics(win, force = true) {
      if (diagnostics.running) return;
      diagnostics.running = true;
      diagnostics.checks = [];
      win?.refresh?.();
      const checks = [];
      const add = (status, title, detail, fix = '') => checks.push({ status, title, detail, fix });
      let backend = null;
      const previousGeneration = diagnostics.lastGeneration;
      let hStatusResidueTest = null;

      try {
        const wml = globalThis.WML?.status?.();
        if (!wml) {
          add('warn', 'WML 상태 정보 확인 불가', '현재 WML에서 모드 파일 상태를 읽을 수 없습니다.', 'WML 로더를 최신 버전으로 갱신한 뒤 새로고침하세요.');
        } else {
          const missing = Array.isArray(wml.missing) ? wml.missing : [];
          const failed = Array.isArray(wml.failed) ? wml.failed : [];
          if (missing.length) {
            const shown = missing.slice(0, 8).join(', ');
            add('warn', '등록된 모드 파일 누락', `${shown}${missing.length > 8 ? ` 외 ${missing.length - 8}개` : ''}`, '누락된 모드 폴더를 다시 설치하거나 모드목록_자동갱신.cmd로 목록을 갱신하세요.');
          } else {
            add('ok', 'WML 모드 파일', '등록된 모드에서 누락된 폴더가 발견되지 않았습니다.');
          }
          if (failed.length) {
            add('error', '모드 로드 오류', failed.slice(0, 5).map(entry => `${entry.id || '알 수 없음'}: ${diagnosticText(entry.error)}`).join(' / '), 'WML 모드 관리자에서 오류 표시를 확인하고 해당 모드를 다시 설치하거나 호환 버전을 사용하세요.');
          } else {
            add('ok', '모드 로드', 'WML이 기록한 모드 로드 오류가 없습니다.');
          }
          const related = ['h-status', 'badguest', 'imagestudio', 'image-ext', 'easygen'].filter(id => wml.loaded?.includes(id));
          add('info', '관련 모드', related.length ? `작동 중: ${related.join(', ')}` : '추가 연동 모드가 감지되지 않았습니다.', '`h-status`와 `badguest`는 해당 상태를 사용할 때만 필요합니다.');
        }

        const imageFunctions = ['imageKey', 'imagePrompt', 'imageLookup', 'imageGenerate'];
        const missingFunctions = imageFunctions.filter(name => !api.has(name));
        if (missingFunctions.length) {
          add('error', '이미지 기능 심볼 누락', missingFunctions.join(', '), '게임 버전과 WML 심볼 표를 맞춘 뒤 새로고침하세요.');
        } else {
          add('ok', '이미지 기능 연결', '이미지 키·프롬프트·조회·생성 함수를 모두 찾았습니다.');
        }

        const gameState = api.store.game();
        add(gameState ? 'ok' : 'warn', '게임 상태', gameState ? '현재 게임 상태를 읽을 수 있습니다.' : '아직 게임이 시작되지 않아 현재 장면을 확인할 수 없습니다.', gameState ? '' : '게임을 시작한 뒤 문제가 난 장면에서 다시 진단하세요.');

        const hStatusBridge = globalThis.__waywardSituationEventMod;
        const hStatusLoaded = globalThis.WML?.status?.()?.loaded?.includes('h-status');
        if (!hStatusBridge) {
          add(hStatusLoaded ? 'error' : 'info', 'H-Status 비밀 탭 연동', hStatusLoaded ? 'H-Status는 로드됐지만 연동 API를 찾지 못했습니다.' : 'H-Status가 활성화되지 않아 비밀 탭 검사를 생략합니다.', hStatusLoaded ? 'H-Status와 이 모드를 최신 버전으로 맞춘 뒤 새로고침하세요.' : '비밀 탭 기능을 사용할 때만 H-Status가 필요합니다.');
        } else {
          add('ok', 'H-Status 연동 API', hStatusBridge.version ? `연동 API ${hStatusBridge.version}` : '연동 API를 사용할 수 있습니다.');
          const secretTab = document.querySelector('#root [data-ko-se-secret-tab]');
          if (secretTab) {
            const currentLayout = secretTab.dataset.attentionSecretLayout === 'current'
              || !!secretTab.parentElement?.querySelector('button[title*="초상화"],button[title*="Portrait"]');
            add(currentLayout ? 'ok' : 'warn', 'H-Status 비밀 탭 위치', currentLayout ? '최신 아내 카드의 초상화·상태 탭 옆에 연결됐습니다.' : '구형 상세 상태 탭 위치에서 감지됐습니다.', currentLayout ? '' : '아내 카드가 표시된 상태에서 다시 진단하세요. 계속 구형 위치로 나오면 H-Status를 갱신하세요.');
          } else {
            add('error', 'H-Status 비밀 탭 없음', '현재 아내 카드에서 비밀 탭 버튼을 찾지 못했습니다.', '아내 카드가 보이는 게임 화면에서 다시 진단하고, H-Status와 이 모드를 최신 버전으로 맞추세요.');
          }
          const secretPanel = document.querySelector('.ko-se-secret');
          if (secretPanel) {
            const cards = [...secretPanel.querySelectorAll('.ko-se-fluid-section .ko-se-fluid-card')];
            const images = cards.map(card => card.querySelector('img.ko-se-fluid-image')).filter(Boolean);
            const ready = images.filter(image => image.complete && image.naturalWidth > 0).length;
            const broken = images.filter(image => image.complete && image.currentSrc && image.naturalWidth === 0).length;
            add(broken ? 'error' : cards.length >= FLUID_PARTS.length ? 'ok' : 'warn', 'H-Status 비밀 탭 잔류 카드', `카드 ${cards.length}개 · 표시 이미지 ${ready}개${broken ? ` · 로드 실패 ${broken}개` : ''}`, broken ? '이미지팩 파일과 이미지 서버의 저장 경로를 확인하세요.' : cards.length >= FLUID_PARTS.length ? '' : '비밀 탭을 다시 열고 카드가 모두 표시되는지 확인하세요.');
          } else {
            add('info', 'H-Status 비밀 탭 내용', '비밀 탭이 닫혀 있어 카드 DOM 검사는 생략했습니다.', '비밀 탭을 연 상태에서 다시 진단하면 카드와 이미지 로드 여부도 확인합니다.');
          }
          const imageKey = residueImageKey('mouth');
          if (!imageKey) {
            add('error', 'H-Status 잔류 이미지 키 생성 실패', '현재 아내의 이미지 이름 또는 상태값으로 잔류 이미지 키를 만들지 못했습니다.', '아내의 영문 이미지 이름과 H-Status 상태 데이터가 저장되어 있는지 확인하세요.');
          } else {
            try {
              const prompt = await residueBasePrompt(imageKey);
              if (prompt?.prompt) {
                hStatusResidueTest = { imageKey, prompt };
                add('ok', 'H-Status 잔류 이미지 프롬프트', `${imageKey} · Positive/Negative 전달 준비 완료`);
              } else {
                add('error', 'H-Status 잔류 프롬프트 누락', imageKey, '사용자 아내는 영문 이미지 이름과 전체 외형 프롬프트를 확인하세요. 기본 아내라면 H-Status 프롬프트 팩 파일도 확인하세요.');
              }
            } catch (error) {
              add('error', 'H-Status 잔류 프롬프트 확인 실패', diagnosticText(error), 'H-Status 프롬프트 팩 파일과 브라우저 콘솔 오류를 확인하세요.');
            }
          }
        }

        const prefs = settingsStore?.getState?.() || {};
        if (prefs.imageBackendMode === 'off') {
          add('error', '이미지 서버 설정 꺼짐', '게임 설정에서 이미지 백엔드 모드가 꺼져 있습니다.', '게임 설정의 이미지 생성 항목에서 자동 또는 사용자 지정 서버를 선택하세요.');
        }
        const offlineOnly = globalThis.__WW_STUDIO_OFFLINE_ONLY__;
        if (offlineOnly === true) {
          add('error', '게임 중 이미지 생성 꺼짐', '이미지 생성 도구가 오프라인 이미지팩만 사용하도록 설정되어 있습니다.', '이미지 생성 도구에서 “게임 플레이 중 이미지 생성”을 자동 또는 켬으로 바꾸세요.');
        } else if (offlineOnly === false) {
          add('ok', '게임 중 이미지 생성', '이미지 서버에 항상 요청하도록 설정되어 있습니다.');
        } else if (offlineOnly === 'auto') {
          add('info', '게임 중 이미지 생성', '서버가 연결되고 생성 가능한 경우에만 자동 요청합니다.');
        }

        try {
          if (force && api.has('imageBackendProbe') && prefs.imageBackendMode !== 'off') {
            const allowAutoProbe = api.has('imageAutoProbeAllowed') ? api.fn('imageAutoProbeAllowed')() : true;
            backend = await api.fn('imageBackendProbe')({
              mode: prefs.imageBackendMode,
              url: prefs.imageBackendUrl,
              allowAutoProbe,
            }, true);
          } else if (api.has('imageBackend')) {
            backend = api.fn('imageBackend')();
          }
        } catch (error) {
          add('error', '이미지 서버 재검색 실패', diagnosticText(error), '서버 주소와 WML 버전을 확인한 뒤 다시 진단하세요.');
        }
        diagnostics.backend = backend || null;

        if (!backend?.baseUrl) {
          add('error', '이미지 생성기 미연결', backend?.error ? diagnosticText(backend.error) : '연결된 이미지 서버를 찾지 못했습니다.', '이미지 생성 서버를 실행하고 게임 설정에서 주소를 확인한 뒤 “다시 진단”을 누르세요.');
        } else if (backend.comfyui !== true) {
          add('error', '이미지 엔진 응답 없음', `서버 ${backend.baseUrl}에는 연결됐지만 생성 엔진이 준비되지 않았습니다.`, 'ComfyUI 또는 선택한 이미지 공급자를 실행하고 서버의 모델 설정을 확인하세요.');
        } else {
          add('ok', '이미지 생성기 연결', `${backend.baseUrl}${backend.version ? ` · 서버 ${backend.version}` : ''}`);
        }

        if (force && backend?.baseUrl && typeof globalThis.fetch === 'function') {
          try {
            const timeout = globalThis.AbortSignal?.timeout?.(5000);
            const response = await globalThis.fetch(`${String(backend.baseUrl).replace(/\/+$/, '')}/api/image/health`, {
              credentials: 'omit',
              ...(timeout ? { signal: timeout } : {}),
            });
            const health = await response.json().catch(() => ({}));
            if (!response.ok || (health.comfyui && health.comfyui !== 'connected')) {
              add('error', '이미지 서버 상태 오류', `HTTP ${response.status}${health.provider ? ` · ${health.provider}` : ''}${health.comfyui ? ` · 엔진 ${health.comfyui}` : ''}`, '이미지 서버 창의 오류 로그와 모델·공급자 설정을 확인하세요.');
            } else {
              add('ok', '이미지 서버 상태 확인', `${health.provider || 'provider'} · 저장 이미지 ${Number(health.images) || 0}개`);
            }
            const queued = Number(health.jobs?.queued);
            if (Number.isFinite(queued)) {
              add(queued >= 60 ? 'warn' : 'info', '생성 대기열', `대기 ${queued}건`, queued >= 60 ? '대기열이 줄어든 뒤 다시 시도하거나 서버에서 불필요한 작업을 취소하세요.' : '');
            }
          } catch (error) {
            add('error', '이미지 서버 통신 실패', diagnosticText(error) || '상태 확인 요청에 응답하지 않았습니다.', '서버 실행 여부, 주소, 방화벽과 CORS 설정을 확인하세요.');
          }
        }

        if (force && api.has('imageGenerate') && backend?.baseUrl && backend.comfyui === true
          && prefs.imageBackendMode !== 'off' && offlineOnly !== true) {
          const imageKey = hStatusResidueTest?.imageKey || 'attention_image_prompt__diagnostic__v-1';
          const startedAt = Date.now();
          try {
            if (hStatusResidueTest) {
              if (await regenerateResidueImage(imageKey)) {
                add('ok', 'H-Status 비밀 탭 이미지 생성 성공', `${imageKey} · ${(Date.now() - startedAt).toLocaleString()}ms`);
              } else {
                add('error', 'H-Status 비밀 탭 이미지 생성 실패', `${imageKey} · 이미지 서버가 결과 URL을 반환하지 않았습니다.`, '이미지 서버 로그에서 H-Status 프롬프트 팩·모델·워크플로·저장 경로 오류를 확인하세요.');
              }
            } else {
              const result = await api.fn('imageGenerate')({
                imageKey,
                prompt: 'single red apple on a plain white table, centered composition, studio lighting, best quality',
                negativePrompt: 'worst quality, low quality, blurry, text, watermark',
                workflow: 'illustrious',
                width: 512,
                height: 512,
                bypassCache: true,
                debug: { source: 'attention-image-prompt-diagnostics' },
              });
              if (result?.url) {
                add('ok', '테스트 이미지 생성 성공', `512×512 · ${(Date.now() - startedAt).toLocaleString()}ms`);
              } else {
                add('error', '테스트 이미지 생성 실패', '이미지 서버가 결과 URL을 반환하지 않았습니다.', '이미지 서버 로그에서 모델·워크플로·저장 경로 오류를 확인하세요.');
              }
            }
          } catch (error) {
            add('error', hStatusResidueTest ? 'H-Status 비밀 탭 이미지 생성 실패' : '테스트 이미지 생성 실패', diagnosticText(error), '이미지 서버 로그에서 모델·워크플로·저장 경로 오류를 확인하세요.');
          } finally {
            if (residueBaseImageKey(diagnostics.lastGeneration?.key) === imageKey) diagnostics.lastGeneration = previousGeneration;
          }
        } else if (force) {
          add('info', hStatusResidueTest ? 'H-Status 비밀 탭 이미지 생성 생략' : '테스트 이미지 생성 생략', '이미지 생성기 연결과 게임 중 생성 설정이 준비되지 않았습니다.', '위 연결 오류를 해결한 뒤 다시 진단하세요.');
        }

        if (api.has('imageManifest')) {
          try {
            const manifest = await api.fn('imageManifest')();
            const count = Object.keys(manifest?.entries || {}).length;
            add(count ? 'ok' : backend?.comfyui ? 'info' : 'warn', '사용 가능한 이미지 목록', `${count.toLocaleString()}개`, count || backend?.comfyui ? '' : '이미지팩을 다시 설치하거나 이미지 서버를 연결하세요.');
          } catch (error) {
            add('warn', '이미지 목록 확인 실패', diagnosticText(error), '이미지팩 파일과 서버의 /api/pack 응답을 확인하세요.');
          }
        }

        const brokenImages = [...document.images].filter(image => image.complete && image.currentSrc && image.naturalWidth === 0);
        if (brokenImages.length) {
          add('error', '현재 화면 이미지 파일 로드 실패', `${brokenImages.length}개 · ${brokenImages.slice(0, 4).map(image => diagnosticImageName(image.currentSrc)).join(', ')}`, '해당 이미지팩 파일이 실제로 있는지 확인하고, 서버 이미지라면 서버의 images 경로와 접근 권한을 확인하세요.');
        } else {
          add('ok', '현재 화면 이미지 파일', '브라우저가 로드에 실패한 이미지가 없습니다.');
        }

        const matching = globalThis.WW_ImageStudioMatching?.last;
        const lookup = diagnostics.lastLookup;
        if (matching) {
          const detail = `${matching.key}${matching.resolvedKey ? ` → ${matching.resolvedKey}` : ''}`;
          const required = matching.required.map(item => item.label).join(', ') || '없음';
          if (matching.missing) {
            add('info', '최근 이미지 매칭: 이미지 없음', `${detail} · 필수 항목: ${required} · 후보 ${matching.candidates}개 · 없는 파일 ${matching.missingFiles}개`, '이미지 매칭 우선순위 설정의 필수 항목·유사 묶음과 보유 이미지 파일을 확인하세요.');
          } else {
            const labels = new Map(globalThis.WW_ImageStudioMatching.matcher.dimensions.map(([id, label]) => [id, label]));
            const statuses = {exact:'일치',similar:'유사',different:'불일치'};
            const points = Object.entries(matching.points).map(([id, value]) => `${labels.get(id) || id} ${value.toLocaleString()}점(${statuses[matching.matches[id]] || '정보 없음'})`).join(' · ');
            add('ok', '최근 이미지 매칭', `${detail} · 총점 ${matching.total.toLocaleString()}점 · 같은 조건의 변형 ${matching.variantCount}개 중 무작위 선택${matching.cached ? ' · 연속 조회 결과 재사용' : ''}`);
            add('info', '항목별 매칭 점수', points);
          }
          add('info', '매칭 조회 시간', `${matching.durationMs}ms · 후보 ${matching.candidates}개 · 파일 확인 ${matching.checkedFiles}개`);
        } else if (lookup) {
          const lookupDetail = `${lookup.key} · ${lookup.source}${lookup.resolvedKey ? ` → ${lookup.resolvedKey}` : ''}`;
          if (lookup.source === 'exact') add('ok', '최근 이미지 조회', `정확한 캐시 이미지를 찾았습니다: ${lookupDetail}`, '같은 이미지 키는 새로 생성하지 않습니다. 새 상태 프롬프트가 적용됐다면 키도 달라져야 합니다.');
          else if (lookup.source === 'vanilla-fallback') add('info', '최근 이미지 조회', `vanilla 파일명 규칙의 기본 이미지를 대신 사용했습니다: ${lookupDetail}`, '오프라인이거나 ImageStudio 대기열이 작업 중일 때 정상입니다.');
          else if (lookup.source === 'nearest-blocked') add('info', '최근 이미지 조회', `유사 이미지를 제외하고 새 생성을 요청했습니다: ${lookupDetail}`);
          else add('warn', '최근 이미지 조회', `사용 가능한 이미지를 찾지 못했습니다: ${lookupDetail}`, '아래 최근 생성 요청과 이미지 생성기 연결 결과를 함께 확인하세요.');
        } else {
          add('info', '최근 이미지 조회 기록 없음', '이 모드를 로드한 뒤 처리된 이미지 조회가 없습니다.', '문제가 난 장면이나 초상화를 한 번 표시한 뒤 다시 진단하세요.');
        }

        const generation = diagnostics.lastGeneration;
        if (!generation) {
          add('info', '최근 생성 요청 기록 없음', '이 모드를 통과한 이미지 생성 요청이 없습니다.', '문제를 재현한 뒤 다시 진단하세요. 조회 실패 후에도 기록이 없다면 게임 중 이미지 생성 설정이 꺼졌을 가능성이 큽니다.');
        } else if (generation.status === 'success') {
          add('ok', '최근 생성 요청 성공', `${generation.key} · ${generation.durationMs}ms`);
        } else if (generation.status === 'running') {
          add('info', '이미지 생성 진행 중', generation.key);
        } else {
          add('error', '최근 생성 요청 실패', `${generation.key}${generation.error ? ` · ${generation.error}` : ' · 서버가 이미지 URL을 반환하지 않았습니다.'}`, '이미지 서버 상태·대기열·서버 로그를 확인한 뒤 다시 생성하세요.');
        }
      } catch (error) {
        add('error', '진단기 실행 오류', diagnosticText(error), '페이지를 새로고침한 뒤 다시 시도하고, 계속되면 이 문구를 제보해 주세요.');
      } finally {
        diagnostics.running = false;
        diagnostics.checkedAt = Date.now();
        diagnostics.checks = checks;
        win?.refresh?.();
      }
    }

    function renderDiagnostics(h, win) {
      const colors = {
        ok: ['정상', '#86efac', '#052e16'],
        info: ['정보', '#93c5fd', '#172554'],
        warn: ['확인', '#fde68a', '#451a03'],
        error: ['오류', '#fca5a5', '#450a0a'],
      };
      return [
        h('div', { style: 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:10px;' },
          api.ui.button(diagnostics.running ? '진단 중…' : diagnostics.checkedAt ? '다시 진단' : '진단 실행', () => {
            void runDiagnostics(win, true);
          }, { primary: true, disabled: diagnostics.running }),
          h('span', { class: 'wml-muted wml-small' }, diagnostics.checkedAt
            ? `마지막 확인: ${new Date(diagnostics.checkedAt).toLocaleTimeString()} · 연결 시 테스트 이미지 1장 생성`
            : '실행 시 테스트 이미지 1장을 생성하며, H-Status 연동 시 현재 비밀 탭 잔류 이미지를 검사합니다.'),
        ),
        diagnostics.checks.length
          ? h('div', { 'data-attention-diagnostics': '', style: 'display:grid;gap:8px;' },
            ...diagnostics.checks.map(check => {
              const [label, color, background] = colors[check.status] || colors.info;
              return h('article', {
                'data-diagnostic-status': check.status,
                style: `border:1px solid ${color}55;border-radius:7px;padding:9px 10px;background:${background};`,
              },
              h('div', { style: 'display:flex;align-items:center;gap:7px;margin-bottom:3px;' },
                h('strong', { style: `font-size:11px;color:${color};` }, label),
                h('strong', { style: 'font-size:12px;' }, check.title),
              ),
              h('div', { class: 'wml-small', style: 'overflow-wrap:anywhere;' }, check.detail),
              check.fix ? h('div', { class: 'wml-small', style: 'margin-top:5px;color:#d6d3d1;' }, `해결 방법: ${check.fix}`) : null);
            }),
          )
          : h('p', { class: 'wml-note', 'data-attention-diagnostics-empty': '' }, '진단 실행을 누르면 현재 연결 상태와 최근 이미지 처리 기록을 확인합니다.'),
      ];
    }

    function renderSettings(body, win) {
      const h = api.ui.h;
      const field = (definition, prompts, outfitStates) => {
        const save = value => {
          const negative = activePromptPolarity === 'negative';
          const setting = negative ? 'negativePrompts' : 'prompts';
          const current = activeSituationConfig()[setting];
          saveActiveSituationSection(setting, { ...current, [definition.key]: value });
          win.refresh();
        };
        const input = h('textarea', {
          rows: definition.rows || 2,
          value: prompts[definition.key] || '',
          spellcheck: false,
          style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:52px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
          onfocus: () => {
            activeTagTarget = definition.key.endsWith('.map') ? null : {
              kind: 'field', key: definition.key, polarity: activePromptPolarity, label: definition.label,
            };
          },
          onchange: event => save(event.currentTarget.value),
        });
        return h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
          h('strong', { style: 'font-size:12px;' }, definition.label),
          definition.hint ? h('span', { class: 'wml-muted wml-small' }, definition.hint) : null,
          outfitStateChecks(h, outfitStates[definition.key], states => {
            saveActiveSituationSection('outfitStates', { ...activeSituationConfig().outfitStates, [definition.key]: states });
            win.refresh();
          }, definition.key, /^(?:fluid|jewelry)\./.test(definition.key)),
          input,
          promptTagChips(h, prompts[definition.key], win),
          definition.key.endsWith('.map') ? null : promptTagAdder(h, prompts[definition.key], save, definition.key),
        );
      };
      const situationConfig = activeSituationConfig();
      const prompts = activePromptPolarity === 'negative' ? situationConfig.negativePrompts : situationConfig.prompts;
      const outfitStates = situationConfig.outfitStates;
      const activeGroup = SETTINGS_TABS.find(group => group.id === activeSettingsTab) || SETTINGS_TABS[0];
      const fileInput = ImageStudio_JSON입력만들기(h, win, activeGroup);
      const content = [
        ['situation-presets', 'positions', 'diagnostics'].includes(activeGroup.id) ? null : h('p', { class: 'wml-note' }, activeGroup.id === 'character'
          ? '현재 아내의 전체 Positive·Negative 외형을 확인하고 교체합니다. 장면·의상·상태 프롬프트는 그대로 유지됩니다.'
          : activeGroup.id === 'outfit-prompts'
            ? '등록된 의상의 Positive·Negative를 확인하고 교체합니다. 수정된 의상은 기존 캐시와 다른 이미지 상황으로 생성됩니다.'
            : 'Positive와 Negative를 각각 설정할 수 있습니다. 빈 값은 해당 조건의 추가를 끕니다. 옷 상태 제한은 현재 이미지의 outfit 상태를 확인합니다.'),
        !['situation-presets', 'positions', 'dialogue', 'diagnostics'].includes(activeGroup.id) ? h('div', { style: 'display:flex;gap:6px;margin:10px 0 0;' },
          ...[['positive', 'Positive'], ['negative', 'Negative']].map(([id, label]) => api.ui.button(label, () => {
            activePromptPolarity = id;
            activeTagTarget = null;
            win.refresh();
          }, { primary: id === activePromptPolarity })),
        ) : null,
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;margin:10px 0;' },
          ...SETTINGS_TABS.map(group => api.ui.button(group.title, () => {
            activeSettingsTab = group.id;
            activeTagTarget = null;
            win.refresh();
            if (group.id === 'diagnostics' && !diagnostics.checkedAt) queueMicrotask(() => { void runDiagnostics(win, true); });
          }, { primary: group.id === activeGroup.id })),
        ),
        !['character', 'outfit-prompts', 'situation-presets', 'positions', 'diagnostics'].includes(activeGroup.id)
          ? h('div', { 'data-active-situation-preset': situationConfig.id, class: 'wml-note', style: 'margin-bottom:10px;' }, `편집 중인 상황 프리셋 · ${situationConfig.name}`)
          : null,
        h('section', { class: 'wml-section' },
          h('h3', { style: 'margin:0 0 6px;' }, activeGroup.title),
          h('p', { class: 'wml-muted wml-small' }, activeGroup.note),
          ...(activeGroup.id === 'diagnostics'
            ? renderDiagnostics(h, win)
            : activeGroup.id === 'situation-presets'
              ? renderSituationPresets(h, win)
            : activeGroup.id === 'positions'
              ? renderPositionSettings(h, win)
            : activeGroup.id === 'dialogue'
              ? renderDialogueRules(h, win)
              : activeGroup.id === 'character'
                ? renderCharacterPrompt(h, win)
                : activeGroup.id === 'outfit-prompts'
                  ? renderOutfitPrompt(h, win)
                : activeGroup.id === 'h-status'
                  ? [renderFluidDecaySettings(h, win), ...activeGroup.fields.map(definition => field(definition, prompts, outfitStates))]
                  : activeGroup.fields.map(definition => field(definition, prompts, outfitStates))),
        ),
        ...ImageStudio_JSON버튼그리기(h, win, activeGroup, fileInput),
        settingsMessage ? h('p', { class: 'wml-note', style: 'margin-top:8px;' }, settingsMessage) : null,
      ];
      body.replaceChildren(h('div', { style: 'display:flex;align-items:flex-start;gap:12px;flex-wrap:wrap;' },
        h('main', { style: 'min-width:0;flex:3 1 620px;' }, ...content),
        ['situation-presets', 'positions', 'diagnostics'].includes(activeGroup.id) ? null : renderTagLibrary(h, win),
      ));
    }

    function openSettingsWindow() {
      const win = api.ui.window({
        id: 'settings',
        title: '상황별 이미지 프롬프트 설정',
        width: 1080,
        height: 840,
        render: renderSettings,
      });
      const width = Math.max(320, Math.min(1080, window.innerWidth - 24));
      const height = Math.max(320, Math.min(840, window.innerHeight - 24));
      const raiseWindow = () => {
        win.el.style.setProperty('width', `${width}px`, 'important');
        win.el.style.setProperty('height', `${height}px`, 'important');
        win.el.style.setProperty('left', `${Math.max(8, (window.innerWidth - width) / 2)}px`, 'important');
        win.el.style.setProperty('top', `${Math.max(8, (window.innerHeight - height) / 2)}px`, 'important');
        win.el.style.setProperty('z-index', '2147483647', 'important');
      };
      raiseWindow();
      if (!win.el.__attentionImagePromptRaise) {
        win.el.__attentionImagePromptRaise = () => queueMicrotask(raiseWindow);
        win.el.addEventListener('pointerdown', win.el.__attentionImagePromptRaise);
      }
      win.refresh();
    }

    function addPauseSettingsButton(result) {
      let added = false;
      const visit = node => {
        if (Array.isArray(node)) return node.map(visit);
        if (!node || typeof node !== 'object' || !node.props) return node;
        const children = visit(node.props.children);
        const className = String(node.props.className || '');
        if (!added && className.includes('flex-col') && className.includes('gap-2')) {
          added = true;
          const list = (Array.isArray(children) ? children : [children]).filter(child => child != null);
          const paragraph = list.findIndex(child => child?.type === 'p');
          const insertAt = paragraph < 0 ? list.length : paragraph;
          const button = gameElement('button', {
            type: 'button',
            className: 'w-full px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-100 rounded text-sm border border-stone-700',
            'data-attention-image-prompt-settings': '',
            'data-wml-ui': '',
            'data-i18n-skip': '',
            onClick: event => {
              event.preventDefault();
              event.stopPropagation();
              openSettingsWindow();
            },
          }, '상황별 이미지 프롬프트 설정');
          return { ...node, props: { ...node.props, children: [...list.slice(0, insertAt), button, ...list.slice(insertAt)] } };
        }
        return { ...node, props: { ...node.props, children } };
      };
      return visit(result);
    }

    let uiScanQueued = false;
    function scheduleUiScan() {
      if (uiScanQueued) return;
      uiScanQueued = true;
      const scan = () => {
        uiScanQueued = false;
        decoratePortraitPromptTags();
        ensureSecretTabCompatibility();
        decorateResidueCards();
      };
      if (typeof window.requestAnimationFrame === 'function') window.requestAnimationFrame(scan);
      else queueMicrotask(scan);
    }

    api.ui.settings(renderSettings);
    if (api.has('pauseMenu')) {
      api.hook('pauseMenu', {
        after(result) { return addPauseSettingsButton(result); },
      });
    }
    decoratePortraitPromptTags();
    ensureSecretTabCompatibility();
    decorateResidueCards();
    const uiObserverRoot = document.getElementById('root') || document.body;
    if (uiObserverRoot && typeof MutationObserver !== 'undefined') {
      const uiObserver = new MutationObserver(scheduleUiScan);
      uiObserver.observe(uiObserverRoot, { childList: true, subtree: true });
      window.addEventListener('pagehide', () => uiObserver.disconnect(), { once: true });
    }

    api.hook('wifePicker', {
      after(result, [props]) {
        return result && props?.onSelect && props?.onOpenBuilder ? addWifePickerTools(result, props) : result;
      },
    });

    api.hook('wifeBuilderDefaults', {
      after(result) {
        const template = pendingWifeBuilderTemplate;
        pendingWifeBuilderTemplate = null;
        if (!result || !template) return result;
        wifeBuilderActivePromptSourceId = '';
        wifeBuilderContextId = null;
        currentWifeBuilderPromptState = null;
        return {
          ...result,
          __attentionImageEnglishName: template.englishName,
          __attentionImageShortname: template.shortname,
          __attentionImageNegativePrompt: DEFAULT_WIFE_CHARACTER_NEGATIVE,
          __attentionExtraLinesArchetypeId: EXTRA_LINES_DIALOGUE_SOURCES[0][0],
          __attentionImageOutfitColors: { primary: '', secondary1: '', secondary2: '' },
        };
      },
    });

    api.hook('wifeBuilder', {
      after(result, [props]) {
        return customizeWifeBuilder(result, props);
      },
    });

    api.hook('buildWifeArchetype', {
      after(result, [inputs, id]) {
        if (!result || !inputs || readingWifePromptSources) return applySavedWifeMetadata(result, inputs);
        const customAppearance = String(inputs.customAppearance || '').trim();
        const base = generatedWifeBasePrompt(result.imageBase, customAppearance);
        const previous = currentWifeBuilderPromptState?.id === id ? currentWifeBuilderPromptState : null;
        const full = previous && previous.base !== base
          ? rebaseWifePrompt(previous.full, previous.base, base)
          : customAppearance || previous?.full || base;
        const negative = normalizedWifeNegative(previous?.negative ?? (Object.prototype.hasOwnProperty.call(inputs, '__attentionImageNegativePrompt')
          ? String(inputs.__attentionImageNegativePrompt || '')
          : DEFAULT_WIFE_CHARACTER_NEGATIVE));
        inputs.__attentionImageNegativePrompt = negative;
        currentWifeBuilderPromptState = {
          id,
          base,
          full,
          negative,
          inputs,
          needsPersist: Boolean(customAppearance && full !== customAppearance),
          persistScheduled: false,
          userEdited: previous?.userEdited || false,
        };
        return applySavedWifeMetadata(result, inputs, full, negative);
      },
    });

    api.hook('wifeCharacterFromArchetype', {
      after(result, [archetype]) {
        const dialogueArchetypeId = String(archetype?.attentionExtraLinesArchetypeId || '');
        if (!result || !EXTRA_LINES_DIALOGUE_SOURCES.some(([id]) => id && id === dialogueArchetypeId)) return result;
        const generatedArchetype = result.generatedArchetype ? {
          ...result.generatedArchetype,
          id: dialogueArchetypeId,
          attentionCustomWifeId: archetype.id,
        } : result.generatedArchetype;
        return { ...result, archetypeId: dialogueArchetypeId, generatedArchetype };
      },
    });

    api.hook('wifePreviewBundle', {
      after(result, [archetype]) {
        if (!result || !archetype
          || !Object.prototype.hasOwnProperty.call(archetype, 'attentionImageNegativeOverride')) return result;
        const sharedNegative = normalizedWifeNegative(archetype.attentionImageNegativeOverride);
        const prompt = withoutPromptTags(result.prompt, sharedNegative);
        const parts = Array.isArray(result.parts) ? result.parts.map(part => ({
          ...part,
          tags: withoutPromptTags(part.tags, sharedNegative),
        })) : result.parts;
        return {
          ...result,
          prompt,
          negativePrompt: joinPrompt(`${sharedNegative}, ${WIFE_PREVIEW_ONLY_NEGATIVE}`),
          parts,
          genParams: promptGenParams(prompt),
        };
      },
    });

    if (api.has('imageGenerate')) {
      api.hook('imageGenerate', {
        priority: -20,
        before(args) {
          const request = args[0];
          if (!request || typeof request.imageKey !== 'string') return undefined;
          const imageKey = residueBaseImageKey(request.imageKey);
          const override = currentResiduePrompts()[imageKey];
          const reuseExactCache = isResidueImageKey(imageKey)
            && request.debug?.source === 'wayward-situation'
            && request.bypassCache === true;
          if (!override && !reuseExactCache) return undefined;
          return [{
            ...request,
            ...(reuseExactCache ? { bypassCache: false } : {}),
            ...(override ? {
              prompt: override.positivePrompt.trim() || request.prompt,
              negativePrompt: override.negativePrompt,
            } : {}),
          }, ...args.slice(1)];
        },
        async around(next, request, ...args) {
          if (!request || typeof request.imageKey !== 'string') return next(request, ...args);
          const generated = request.bypassCache !== true ? positionGeneratedResults.get(request.imageKey) : null;
          if (generated) return generated;
          const startedAt = Date.now();
          const trace = { at: startedAt, key: request.imageKey, status: 'running', durationMs: 0, error: '' };
          diagnostics.lastGeneration = trace;
          try {
            const result = await next(request, ...args);
            if (result?.url && request.imageKey.includes('__position-')) {
              positionGeneratedResults.set(request.imageKey, result);
            }
            diagnostics.lastGeneration = {
              ...trace,
              status: result?.url ? 'success' : 'empty',
              durationMs: Date.now() - startedAt,
            };
            return result;
          } catch (error) {
            diagnostics.lastGeneration = {
              ...trace,
              status: 'error',
              durationMs: Date.now() - startedAt,
              error: diagnosticText(error),
            };
            throw error;
          }
        },
      });
    }

    api.hook('outfitById', {
      after(result, [requestedId]) {
        if (!result) return result;
        const prompts = currentOutfitPrompts();
        const override = prompts[String(result.id || '')] || prompts[String(requestedId || '')];
        if (!override) return result;
        return {
          ...result,
          imageTags: override.positivePrompt,
          negativeImageTags: override.negativePrompt,
          // The original half-tags would reintroduce the old prompt during partial exposure.
          halves: undefined,
        };
      },
    });

    function Attention_확장키기본형으로바꾸기(imageKey) {
      const prefixes = ['state-', 'dialogue-', 'position-', 'character-reuse-', 'character-regenerate-', 'studio-'];
      return String(imageKey || '').split('__').filter(part => !prefixes.some(prefix => part.startsWith(prefix))).join('__');
    }

    function Attention_팩정확이미지읽기(imageKey) {
      for (const pack of globalThis.__WAYWARD_IMAGE_PACKS__ || []) {
        const entries = pack?.entries;
        if (!entries || typeof entries !== 'object') continue;
        const direct = entries[imageKey];
        if (direct?.talentName === imageKey) return direct;
        const found = Object.values(entries).find(entry => entry?.talentName === imageKey);
        if (found) return found;
      }
      return null;
    }

    async function Attention_생성불가확인하기(imageKey) {
      if (imageKey.includes('__character-reuse-')) return true;
      if (globalThis.__WW_STUDIO_OFFLINE_ONLY__ === true) return true;
      const probe = globalThis.WW_ImageStudioBridge?.generationUnavailable;
      if (typeof probe !== 'function') return false;
      try { return await probe(); } catch { return true; }
    }

    function Attention_정확한이미지필요확인하기(imageKey) {
      const variant = Number(imageKey.match(/__v-(\d+)$/)?.[1]);
      const characterKey = imageKey.includes('__character-reuse-') || imageKey.includes('__character-regenerate-');
      return isResidueImageKey(imageKey)
        || imageKey.includes('__state-')
        || imageKey.includes('__dialogue-')
        || imageKey.includes('__position-')
        || imageKey.includes('__character-regenerate-')
        || (characterKey && variant >= USER_VARIANT_START);
    }

    api.hook('imageLookup', {
      async around(next, imageKey, ...args) {
        const lookupArgs = args.slice();
        if (globalThis.__WW_STUDIO_OFFLINE_ONLY__ === true) {
          lookupArgs[0] = { ...(lookupArgs[0] || {}), nearest: true };
        }
        const result = await next(imageKey, ...lookupArgs);
        if (typeof imageKey !== 'string') return result;
        const exactOnly = Attention_정확한이미지필요확인하기(imageKey);
        let resolved = result;
        let source = result?.talentName === imageKey ? 'exact' : result ? 'nearest' : 'missing';
        if (exactOnly && result?.talentName !== imageKey) {
          resolved = null;
          if (result) source = 'nearest-blocked';
        }
        // 확장 조건의 정확한 이미지가 없고 생성할 수 없을 때만 vanilla 파일명 규칙으로 후퇴합니다.
        // 자세·대화·사용자 프롬프트 서명을 모두 제거하여 부분 확장 키가 vanilla보다 앞서지 않게 합니다.
        if (!resolved && exactOnly && await Attention_생성불가확인하기(imageKey)) {
          const baseKey = Attention_확장키기본형으로바꾸기(imageKey);
          if (baseKey !== imageKey) {
            let fallback = Attention_팩정확이미지읽기(baseKey);
            const exactBaseArgs = lookupArgs.slice();
            exactBaseArgs[0] = { ...(exactBaseArgs[0] || {}), nearest: false };
            if (!fallback) fallback = await next(baseKey, ...exactBaseArgs);
            if (!fallback) {
              const nearestBaseArgs = lookupArgs.slice();
              nearestBaseArgs[0] = { ...(nearestBaseArgs[0] || {}), nearest: true };
              fallback = await next(baseKey, ...nearestBaseArgs);
            }
            if (fallback) {
              resolved = fallback;
              source = 'vanilla-fallback';
            }
          }
        }
        diagnostics.lastLookup = {
          at: Date.now(),
          key: imageKey.slice(0, 240),
          source,
          resolvedKey: typeof resolved?.talentName === 'string' ? resolved.talentName.slice(0, 240) : '',
        };
        return resolved;
      },
    });

    api.hook('imageKey', {
      after(result, [character]) {
        const state = api.store.game();
        if (!state || !character || typeof result !== 'string') return result;
        const characterId = characterIdOf(state, character);
        if (!characterId) return result;
        const axisKey = ImageStudio_기본축키적용하기(result);
        const { positiveGroups, negativeGroups, dialogue, characterPolicy, situational } = promptContext(state, character, characterId, axisKey);
        const stateKey = positiveGroups.length || negativeGroups.length
          ? keyWithState(axisKey, combinedStateSignature(positiveGroups, negativeGroups), dialogue, characterPolicy, situational)
          : axisKey;
        return keyWithPosition(stateKey, positionChoiceForImageKey(stateKey));
      },
    });

    api.hook('imagePrompt', {
      after(result, [character]) {
        ImageStudio_기본축프롬프트기록하기(result);
        result = ImageStudio_기본축프롬프트적용하기(result);
        const state = api.store.game();
        if (!state || !character || !result || !Array.isArray(result.parts)) return result;
        const characterId = characterIdOf(state, character);
        if (!characterId) return result;

        if (host.external && !host.planning) {
          const outfitNegative = outfitPromptGroup(character,result.key,'negativePrompt');
          const corrected = outfitNegative ? {...result,negativePrompt:joinPrompt(result.negativePrompt + ', ' + outfitNegative.value.tags.join(', '))} : result;
          const compositionCorrected = ImageStudio_구도프롬프트직접적용하기(corrected, state, character, characterId);
          const badGuestCorrected = ImageStudio_나쁜손님프롬프트직접적용하기(compositionCorrected, state, character, characterId);
          return rememberLatestScenePrompt(applyPositionPreset(ImageStudio_맥락프롬프트직접적용하기(badGuestCorrected, state, character, characterId), positionChoiceForImageKey(badGuestCorrected.key)), state, character, characterId);
        }
        const nativeNegative = nativeCharacterNegative(character);
        const originalNegative = joinPrompt(`${result.negativePrompt || ''}, ${nativeNegative}`);
        const { positiveGroups, negativeGroups, dialogue, characterPolicy, situational } = promptContext(state, character, characterId, result.key);
        let augmented;
        if (!positiveGroups.length && !negativeGroups.length) {
          augmented = originalNegative === result.negativePrompt ? result : { ...result, negativePrompt: originalNegative };
        } else {
          const characterPositive = positiveGroups.find(group => group.id === 'character');
          const characterNegative = negativeGroups.find(group => group.id === 'character');
          const extraPositiveGroups = positiveGroups.filter(group => !['character', 'outfit'].includes(group.id));
          const extraNegativeGroups = negativeGroups.filter(group => group.id !== 'character');
          const extraTags = extraPositiveGroups.flatMap(group => group.value.tags).join(', ');
          const extraNegativeTags = extraNegativeGroups.flatMap(group => group.value.tags).join(', ');
          let basePartFound = false;
          const baseParts = result.parts.map(part => {
            if (!characterPositive || !['기본', 'Base'].includes(part.label)) return part;
            basePartFound = true;
            const characterTags = characterPositive.value.tags.join(', ');
            return {
              ...part,
              tags: characterPositive.mode === 'replace' ? characterTags : joinPrompt(`${part.tags || ''}, ${characterTags}`),
            };
          });
          const positiveParts = [
            ...baseParts,
            ...(!characterPositive || basePartFound ? [] : [{ label: characterPositive.label, tags: characterPositive.value.tags.join(', ') }]),
            ...extraPositiveGroups.map(group => ({ label: group.label, tags: group.value.tags.join(', ') })),
          ];
          const characterNegativeTags = characterNegative?.value.tags.join(', ') || '';
          const separatedPositiveParts = characterNegativeTags ? positiveParts.map(part => ({
            ...part,
            tags: withoutPromptTags(part.tags, characterNegativeTags),
          })) : positiveParts;
          const prompt = characterPositive && basePartFound
            ? joinPrompt(separatedPositiveParts.map(part => part.tags).join(', '))
            : withoutPromptTags(
              joinPrompt(`${result.prompt}, ${characterPositive?.value.tags.join(', ') || ''}, ${extraTags}`),
              characterNegativeTags,
            );
          const sceneNegative = characterNegative?.mode === 'replace'
            ? withoutPromptTags(originalNegative, nativeNegative)
            : originalNegative;
          const negativePrompt = joinPrompt(`${sceneNegative}, ${characterNegativeTags}, ${extraNegativeTags}`);
          const signature = combinedStateSignature(positiveGroups, negativeGroups);
          augmented = {
            ...result,
            key: keyWithState(result.key, signature, dialogue, characterPolicy, situational),
            prompt,
            negativePrompt,
            parts: separatedPositiveParts,
            genParams: promptGenParams(prompt),
          };
        }
        return rememberLatestScenePrompt(
          applyPositionPreset(augmented, positionChoiceForImageKey(augmented.key)),
          state,
          character,
          characterId,
        );
      },
    });
  
host.connectModern = () => {
 ImageStudio_기본축키적용하기 = ImageStudio_이전기본축키만들기;
 host.modernKey = ImageStudio_기본축키적용하기;
 host.modernCompose = (result, context) => ImageStudio_맥락프롬프트직접적용하기(ImageStudio_기본축프롬프트적용하기(result), context.state, context.character, context.character?.id);
 host.renderLegacyExtras = (body, win) => {
  const all = SETTINGS_TABS.splice(0); SETTINGS_TABS.push(...all.filter(tab => tab.axis || tab.contextAxis));
  if (!SETTINGS_TABS.some(tab => tab.id === activeSettingsTab)) activeSettingsTab = SETTINGS_TABS[0].id;
  try { host.renderSettings(body, win); } finally { SETTINGS_TABS.splice(0, SETTINGS_TABS.length, ...all); }
 };
};

// 내장 attention 설정과 같은 클로저에서 실행합니다. 실제 게임 상태는 수정하지 않습니다.
const ImageStudio_계획설정자료 = new WeakMap();
const ImageStudio_기본축탭목록 = [
  {
    id: 'native-situation-prompts', axis: 'situation', title: '장면/작업 프롬프트',
    note: '조건부 생성의 장면·작업 ID별 기본 Positive를 교체하고 추가 Negative를 설정합니다.', fields: [],
  },
  {
    id: 'native-room-prompts', axis: 'room', title: '장소 프롬프트',
    note: '조건부 생성의 장소 ID별 기본 Positive를 교체하고 추가 Negative를 설정합니다.', fields: [],
  },
  {
    id: 'native-mood-prompts', axis: 'mood', title: '기분 프롬프트',
    note: '조건부 생성의 기분 ID별 기본 Positive를 교체하고 추가 Negative를 설정합니다.', fields: [],
  },
  {
    id: 'native-men-prompts', axis: 'men', title: '남성 수 프롬프트',
    note: '화면의 전체 남성 수별 인원 Positive를 교체하고 추가 Negative를 설정합니다. 조건부 생성의 인원 조건과 같은 기준을 사용합니다.', fields: [],
  },
  {
    id: 'native-roles-prompts', axis: 'roles', title: '남성별 역할 조합 프롬프트',
    note: 'gslot 역할 조합별 그룹 Positive를 교체하고 추가 Negative를 설정합니다. 장면 자체의 행동과 장면별 세부 조정은 별도로 적용됩니다.', fields: [],
  },
  {
    id: 'native-exposure-prompts', axis: 'exposure', title: '노출 상태 프롬프트',
    note: '게임의 정규 exp 코드로 같은 노출 상태를 합칩니다. 정규 코드에 저장한 편집값을 우선하며 예전 코드의 값은 설정에 보존합니다. Positive를 교체하고 추가 Negative를 설정하며 의상·장면의 기본 Negative는 유지됩니다.', fields: [],
  },
];
const ImageStudio_기본축기본값 = Object.fromEntries(ImageStudio_기본축탭목록.map(tab => [tab.axis, new Map()]));
const ImageStudio_장면변형기본값 = new Map();
const ImageStudio_장면변형선택값 = new Map();
const ImageStudio_추가기분기본값 = new Map([
  ['aroused', 'aroused, flushed face, heavy breathing, parted lips'],
  ['enjoying', 'pleasure, blush, half-closed eyes, open mouth, relaxed expression'],
  ['relieved', 'relieved, soft eyes, faint smile, relaxed eyebrows'],
  ['nervous', 'nervous, furrowed brow, wide-eyed, tense expression, sweatdrop'],
]);
for (const [id, prompt] of ImageStudio_추가기분기본값) ImageStudio_기본축기본값.mood.set(id, prompt);
const ImageStudio_기본축선택값 = Object.fromEntries(ImageStudio_기본축탭목록.map(tab => [tab.axis, '']));
const ImageStudio_이미지키해석하기 = key => api.fn('imageKeyParse')(ImageStudio_노출키정규화하기(key));
const ImageStudio_노출팩목록 = new WeakMap();

function ImageStudio_노출항목ID읽기(id) {
  return ImageStudio_노출코드정규화하기(String(id)) || 'none';
}
function ImageStudio_노출플래그읽기(imageKey,character) {
  const fields=['bodiceUnlaced','topPulledDown','topRemoved','skirtUp','skirtRemoved','pantiesAside','pantiesRemoved'];
  const specified=String(imageKey || '').match(/(?:^|__)exp-([01]{7})(?=__|$)/)?.[1];
  const raw=specified || fields.map(field=>character?.exposure?.[field]===true?'1':'0').join('');
  const code=ImageStudio_노출코드정규화하기(raw) || '0000000';
  return Object.fromEntries(fields.map((field,index)=>[field,code[index]==='1']));
}

SETTINGS_TABS.splice(2, 0, ...ImageStudio_기본축탭목록);

function ImageStudio_기본축설정정규화하기(value) {
  const result = Object.fromEntries(ImageStudio_기본축탭목록.map(tab => [tab.axis, {}]));
  if (!value || typeof value !== 'object' || Array.isArray(value)) return result;
  for (const axis of Object.keys(result)) {
    const source = value[axis];
    if (!source || typeof source !== 'object' || Array.isArray(source)) continue;
    for (const [rawId, prompt] of Object.entries(source)) {
      const id = String(rawId || '').trim();
      if (!id || id.length > 160 || ['__proto__', 'prototype', 'constructor'].includes(id)
        || !prompt || typeof prompt !== 'object' || Array.isArray(prompt)) continue;
      const normalized = {};
      if (typeof prompt.positivePrompt === 'string') normalized.positivePrompt = prompt.positivePrompt;
      if (typeof prompt.negativePrompt === 'string' && (axis === 'exposure' || prompt.negativePrompt.trim())) normalized.negativePrompt = prompt.negativePrompt;
      if (axis === 'situation' && prompt.variants && typeof prompt.variants === 'object' && !Array.isArray(prompt.variants)) {
        const variants = {};
        for (const variant of ['0','1','2','3']) {
          const row = prompt.variants[variant];
          if (!row || typeof row !== 'object' || Array.isArray(row)) continue;
          const entry = {};
          for (const field of ['positivePrompt','negativePrompt']) if (typeof row[field] === 'string') entry[field] = row[field];
          if (Object.keys(entry).length) variants[variant] = entry;
        }
        if (Object.keys(variants).length) normalized.variants = variants;
      }
      if (Object.keys(normalized).length) result[axis][id] = normalized;
    }
  }
  // 읽기 별칭만 만듭니다. 같은 필드는 정규 코드의 값을 우선하며, 옛 ID와 그 원문은 삭제하지 않습니다.
  for(const id of Object.keys(result.exposure).sort()){
    const canonical=ImageStudio_노출항목ID읽기(id);
    if(canonical!==id)result.exposure[canonical]={...result.exposure[id],...result.exposure[canonical]};
  }
  return result;
}

function ImageStudio_기본축설정읽기() {
  return ImageStudio_기본축설정정규화하기(api.settings.get({ nativeAxisPrompts: {} }).nativeAxisPrompts);
}
host.nativeAxisPrompt = (axis,id) => ImageStudio_기본축설정읽기()[axis]?.[axis==='exposure'?ImageStudio_노출항목ID읽기(id):id];

function ImageStudio_기본축항목읽기(axis) {
  const entries = globalThis.WW_ImageStudioBridge?.axes?.()?.[axis] || [];
  const saved = ImageStudio_기본축설정읽기()[axis] || {};
  const defaults = ImageStudio_기본축기본값[axis] || new Map();
  const canonicalId = id => axis === 'exposure' ? ImageStudio_노출항목ID읽기(id) : String(id);
  const byId = new Map(entries.map(entry => [canonicalId(entry.value), {
    id: canonicalId(entry.value), label: String(entry.label || entry.value), description: String(entry.description || ''),
  }]));
  const known = [...defaults.keys(), ...Object.keys(saved)];
  // 현재 이미지팩에만 있는 상태도 본체의 조건부 목록과 같은 기준으로 표시합니다.
  if(axis==='exposure')for(const pack of globalThis.WW_ImageStudioBridge?.packs?.() || []){
    if(!ImageStudio_노출팩목록.has(pack))ImageStudio_노출팩목록.set(pack,[...new Set(Object.values(pack.entries || {})
      .map(entry=>entry.talentName?.match(/__exp-([01]{7})(?=__|$)/)?.[1] || 'none'))]);
    known.push(...ImageStudio_노출팩목록.get(pack));
  }
  for (const rawId of known) {
    const id=canonicalId(rawId);
    if (!byId.has(id)) byId.set(id, { id, label: id, description: '' });
  }
  return [...byId.values()];
}

function ImageStudio_기본축키값읽기(imageKey) {
  let parsed;
  try { parsed = ImageStudio_이미지키해석하기(String(imageKey || '')); } catch { return {}; }
  if (!parsed) return {};
  return {
    situation: String(parsed.scene || parsed.task || ''),
    room: parsed.room ? String(parsed.room) + (parsed.abed ? ' (침대 위)' : '') : '',
    mood: String(parsed.mood || 'default'),
    men: parsed.groupBoys ? String(parsed.groupBoys + 1) : parsed.task || ['self_pleasure', 'bath_solo'].includes(parsed.scene) ? '0' : '1',
    roles: String(parsed.groupSlots || ''),
    exposure: String(parsed.exposure || 'none'),
  };
}

function ImageStudio_기본축부분찾기(parts, axis, hasScene) {
  const labels = axis === 'situation'
    ? hasScene ? ['장면', 'Scene'] : ['작업', 'Task', '자세', 'Pose', 'Action']
    : axis === 'room' ? ['장소', 'Location']
    : axis === 'mood' ? ['기분', 'Mood']
    : axis === 'men' ? ['성별', 'Gender']
    : axis === 'roles' ? ['그룹', 'Group'] : ['노출도', 'Exposure'];
  return parts.findIndex(part => labels.includes(String(part?.label || '')));
}

function ImageStudio_기본축프롬프트기록하기(result) {
  if (!result || !Array.isArray(result.parts)) return result;
  const values = ImageStudio_기본축키값읽기(result.key);
  const parsed = (() => { try { return ImageStudio_이미지키해석하기(String(result.key || '')); } catch { return null; } })();
  const situationIndex = ImageStudio_기본축부분찾기(result.parts, 'situation', Boolean(parsed?.scene));
  if (values.situation && situationIndex >= 0) {
    const identity = values.situation + ':' + String(parsed?.variant || 0);
    if (!ImageStudio_장면변형기본값.has(identity)) ImageStudio_장면변형기본값.set(identity, String(result.parts[situationIndex].tags || ''));
  }
  for (const axis of Object.keys(ImageStudio_기본축기본값)) {
    const id = values[axis];
    if (!id) continue;
    const index = ImageStudio_기본축부분찾기(result.parts, axis, Boolean(parsed?.scene));
    const tags = index >= 0 ? String(result.parts[index]?.tags || '') : '';
    if (!ImageStudio_기본축기본값[axis].has(id) || (!ImageStudio_기본축기본값[axis].get(id) && tags)) {
      ImageStudio_기본축기본값[axis].set(id, tags);
    }
  }
  return result;
}

function ImageStudio_기본축수정목록읽기(imageKey) {
  const values = ImageStudio_기본축키값읽기(imageKey);
  const settings = ImageStudio_기본축설정읽기();
  return Object.entries(values).flatMap(([axis, id]) => {
    if (!id) return [];
    const saved = settings[axis]?.[id];
    if (saved) {
      const variant = axis === 'situation' ? String(ImageStudio_이미지키해석하기(imageKey)?.variant || 0) : '';
      const override = axis === 'situation' ? saved.variants?.[variant] : null;
      const prompt = Object.fromEntries(Object.entries(axis === 'situation' ? { ...saved, ...override } : saved).filter(([key]) => key !== 'variants'));
      return Object.keys(prompt).length ? [{ axis, id, ...(override ? { variant } : {}), prompt }] : [];
    }
    const builtIn = axis === 'mood' ? ImageStudio_추가기분기본값.get(id) : '';
    return builtIn ? [{ axis, id, prompt: { positivePrompt: builtIn } }] : [];
  });
}

function ImageStudio_기본축키적용하기(imageKey) {
  const clean = String(imageKey || '').split('__').filter(part => !part.startsWith('studio-')).join('__');
  const entries = ImageStudio_기본축수정목록읽기(clean);
  if (!entries.length) return clean;
  const signature = JSON.stringify(entries.map(entry => [entry.axis, entry.id, entry.prompt]));
  const variant = clean.match(/__v-\d+$/)?.[0] || '';
  const root = variant ? clean.slice(0, -variant.length) : clean;
  return `${root}__studio-${shortHash(signature)}${variant}`;
}

function ImageStudio_기본축프롬프트적용하기(result) {
  if (!result || !Array.isArray(result.parts)) return result;
  const entries = ImageStudio_기본축수정목록읽기(result.key);
  if (!entries.length) return { ...result, key: ImageStudio_기본축키적용하기(result.key) };
  const parsed = (() => { try { return ImageStudio_이미지키해석하기(String(result.key || '')); } catch { return null; } })();
  let parts = result.parts.map(part => ({ ...part }));
  let prompt = String(result.prompt || '');
  let negativePrompt = String(result.negativePrompt || '');
  for (const entry of entries) {
    if (Object.prototype.hasOwnProperty.call(entry.prompt, 'positivePrompt')) {
      const index = ImageStudio_기본축부분찾기(parts, entry.axis, Boolean(parsed?.scene));
      const replacement = String(entry.prompt.positivePrompt || '');
      if (index >= 0) {
        const otherTags = new Set(parts.filter((_, partIndex) => partIndex !== index)
          .flatMap(part => promptTokens(part.tags)).map(tag => promptTagIdentity(tag).spaced));
        const removable = promptTokens(parts[index].tags).filter(tag => !otherTags.has(promptTagIdentity(tag).spaced));
        prompt = joinPrompt(`${withoutPromptTags(prompt, removable.join(', '))}, ${replacement}`);
        if (replacement.trim()) parts[index] = { ...parts[index], tags: replacement };
        else parts.splice(index, 1);
      } else if (replacement.trim()) {
        const tab = ImageStudio_기본축탭목록.find(item => item.axis === entry.axis);
        parts.push({ label: tab?.title.replace(' 프롬프트', '') || entry.axis, tags: replacement });
        prompt = joinPrompt(`${prompt}, ${replacement}`);
      }
    }
    if (entry.prompt.negativePrompt) negativePrompt = joinPrompt(`${negativePrompt}, ${entry.prompt.negativePrompt}`);
  }
  return {
    ...result,
    key: ImageStudio_기본축키적용하기(result.key),
    prompt,
    negativePrompt,
    parts,
    genParams: promptGenParams(prompt),
  };
}

function ImageStudio_기본축필드저장하기(axis, id, field, value, variant) {
  if(axis==='exposure')id=ImageStudio_노출항목ID읽기(id);
  const settings = ImageStudio_기본축설정읽기();
  const axisPrompts = { ...settings[axis] };
  const prompt = { ...(axisPrompts[id] || {}) };
  if (axis === 'situation' && variant !== undefined) {
    const variants = { ...prompt.variants };
    variants[String(variant)] = { ...variants[String(variant)], [field]: String(value ?? '') };
    axisPrompts[id] = { ...prompt, variants };
    api.settings.set({ nativeAxisPrompts: { ...settings, [axis]: axisPrompts } });
    return;
  }
  if (axis !== 'exposure' && field === 'negativePrompt' && !String(value || '').trim()) delete prompt[field];
  else prompt[field] = String(value ?? '');
  if (Object.keys(prompt).length) axisPrompts[id] = prompt;
  else delete axisPrompts[id];
  api.settings.set({ nativeAxisPrompts: { ...settings, [axis]: axisPrompts } });
}

function ImageStudio_기본축프롬프트그리기(h, win, tab) {
  const sources = ImageStudio_기본축항목읽기(tab.axis);
  if (!sources.length) return [h('p', { class: 'wml-note' }, '게임에서 조건 목록을 읽지 못했습니다.')];
  const source = sources.find(entry => entry.id === ImageStudio_기본축선택값[tab.axis]) || sources[0];
  ImageStudio_기본축선택값[tab.axis] = source.id;
  const prompts = ImageStudio_기본축설정읽기();
  const commonOverride = prompts[tab.axis]?.[source.id] || {};
  const variant = tab.axis === 'situation' ? ImageStudio_장면변형선택값.get(source.id) || '0' : undefined;
  const override = variant !== undefined ? { ...commonOverride, ...commonOverride.variants?.[variant] } : commonOverride;
  const negative = activePromptPolarity === 'negative';
  const field = negative ? 'negativePrompt' : 'positivePrompt';
  const nativeValue = (variant !== undefined ? ImageStudio_장면변형기본값.get(source.id + ':' + variant) : undefined)
    ?? ImageStudio_기본축기본값[tab.axis]?.get(source.id) ?? '';
  const customized = Object.prototype.hasOwnProperty.call(override, field);
  const value = customized ? override[field] : negative ? '' : nativeValue;
  const save = next => { ImageStudio_기본축필드저장하기(tab.axis, source.id, field, next, variant); win.refresh(); };
  const inputStyle = 'width:100%;box-sizing:border-box;resize:vertical;min-height:100px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;';
  return [
    h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
      h('strong', { style: 'font-size:12px;' }, `${tab.title.replace(' 프롬프트', '')} ${sources.length}개`),
      h('select', {
        value: source.id,
        'data-native-axis-prompt-source': tab.axis,
        style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
        onchange: event => { ImageStudio_기본축선택값[tab.axis] = event.currentTarget.value; activeTagTarget = null; win.refresh(); },
      }, ...sources.map(entry => h('option', { value: entry.id, selected: entry.id === source.id }, `${entry.label} (${entry.id})`))),
      h('span', { class: 'wml-muted wml-small' }, customized ? '이 항목의 수정값을 표시 중입니다.' : negative ? '축별 기본 Negative는 없습니다. 입력한 태그를 전체 Negative에 추가합니다.' : '게임의 대표 기본 프롬프트를 표시 중입니다.'),
    ),
    source.description ? h('p', { class: 'wml-note', style: 'margin-bottom:10px;' }, source.description) : null,
    variant !== undefined ? h('div', { 'data-native-situation-variants': source.id, style: 'display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px;' },
      ...['0','1','2','3'].map(id => {
        const button = api.ui.button('v-' + id, () => { ImageStudio_장면변형선택값.set(source.id,id); activeTagTarget = null; win.refresh(); }, { primary: variant === id });
        button.dataset.nativeSituationVariant = id;return button;
      })) : null,
    h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
      h('strong', { style: 'font-size:12px;' }, negative ? '추가 Negative 프롬프트' : '교체할 Positive 프롬프트'),
      h('textarea', {
        rows: 5, value, spellcheck: false,
        'data-native-axis-prompt': `${tab.axis}:${activePromptPolarity}`,
        style: inputStyle,
        onfocus: () => { activeTagTarget = { kind: 'native-axis', axis: tab.axis, id: source.id, variant, polarity: activePromptPolarity, label: `${source.label}${variant !== undefined ? ' v-' + variant : ''} ${negative ? 'Negative' : 'Positive'}` }; },
        onchange: event => save(event.currentTarget.value),
      }),
      promptTagChips(h, value, win),
      promptTagAdder(h, value, save, `native:${tab.axis}:${source.id}:${activePromptPolarity}`),
    ),
    h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;' },
      api.ui.button('이 항목을 게임 기본값으로 복원', () => {
        const settings = ImageStudio_기본축설정읽기();
        const axisPrompts = { ...settings[tab.axis] };
        if (variant !== undefined) {
          const current = axisPrompts[source.id] || {}, variants = { ...current.variants };
          delete variants[variant];
          if (Object.hasOwn(current,'positivePrompt') || Object.hasOwn(current,'negativePrompt')) variants[variant] = { positivePrompt: nativeValue, negativePrompt: '' };
          axisPrompts[source.id] = { ...current, variants };
          if (!Object.keys(variants).length && !Object.hasOwn(current,'positivePrompt') && !Object.hasOwn(current,'negativePrompt')) delete axisPrompts[source.id];
        } else {
          delete axisPrompts[source.id];
          // 사용자가 이 상태의 복원을 명시한 경우에만 같은 상태의 예전 편집값도 함께 해제합니다.
          if(tab.axis==='exposure')for(const id of Object.keys(axisPrompts))if(ImageStudio_노출항목ID읽기(id)===source.id)delete axisPrompts[id];
        }
        api.settings.set({ nativeAxisPrompts: { ...settings, [tab.axis]: axisPrompts } });
        win.refresh();
      }, { disabled: variant !== undefined ? !commonOverride.variants?.[variant] && !Object.hasOwn(commonOverride,'positivePrompt') && !Object.hasOwn(commonOverride,'negativePrompt') : !Object.prototype.hasOwnProperty.call(prompts[tab.axis] || {}, source.id) }),
      h('span', { class: 'wml-muted wml-small' }, variant !== undefined ? '선택한 장면과 변형 번호에만 적용합니다. 일상 작업의 일반 생성은 v-0을 사용합니다.' : '같은 조건 ID에 공통 적용됩니다. 독립된 기본 태그가 없는 항목은 빈 값으로 표시됩니다.'),
    ),
  ];
}

const ImageStudio_원본설정그리기 = renderSettings;
function ImageStudio_확장설정그리기(body, win) {
  ImageStudio_원본설정그리기(body, win);
  const tab = ImageStudio_기본축탭목록.find(item => item.id === activeSettingsTab);
  if (!tab) return;
  body.querySelector('[data-active-situation-preset]')?.remove();
  const introduction = body.querySelector('main > p.wml-note');
  if (introduction) introduction.textContent = tab.axis === 'situation'
    ? '선택한 장면과 v-0~v-3 번호별 Positive를 교체하고 추가 Negative를 설정합니다. 다른 번호의 프롬프트는 유지합니다.'
    : '선택한 조건 ID의 Positive를 교체하고 추가 Negative를 설정합니다. 수정값은 같은 조건 ID를 사용하는 생성에 공통 적용됩니다.';
  const section = body.querySelector('main > section.wml-section');
  if (section) section.append(...ImageStudio_기본축프롬프트그리기(api.ui.h, win, tab).filter(Boolean));
}

api.ui.settings(ImageStudio_확장설정그리기);

host.positionApplicable = ImageStudio_자세상황에맞는가;

const ImageStudio_삽입자세우선순위 = ['missionary', 'doggystyle', 'spooning', 'mating-press', 'prone-bone', 'standing-sex', 'ekiben', 'daisuki-hold', 'full-nelson', 'double-penetration'];
const ImageStudio_기승자세우선순위 = ['cowgirl', 'reverse-cowgirl'];
const ImageStudio_구강손자세우선순위 = new Map([
  ['blowjob', ['kneeling-fellatio', 'deep-throat', 'irrumatio-front', 'upside-down-facefuck']],
  ['deepthroat', ['deep-throat', 'irrumatio-front', 'upside-down-facefuck']], ['clean_with_mouth', ['kneeling-fellatio']],
  ['cum_in_mouth', ['kneeling-fellatio', 'deep-throat']], ['patron_blowjob', ['kneeling-fellatio', 'deep-throat', 'irrumatio-front', 'upside-down-facefuck']],
  ['patron_deepthroat', ['deep-throat', 'irrumatio-front', 'upside-down-facefuck']],
  ['patron_blowjob_climax', ['kneeling-fellatio', 'deep-throat', 'irrumatio-front']], ['patron_blowjob_swallow', ['kneeling-fellatio', 'deep-throat']],
  ['cunnilingus', ['cunnilingus']], ['patron_cunnilingus', ['cunnilingus']], ['sixty_nine', ['sixty-nine']],
  ['bath_attendant_handjob', ['seated-handjob']], ['handjob', ['seated-handjob']], ['patron_handjob', ['seated-handjob']],
  ['patron_handjob_finish', ['seated-handjob']], ['patron_handjob_climax', ['seated-handjob']],
  ['titfuck', ['paizuri']], ['patron_titfuck', ['paizuri']],
]);

function ImageStudio_장면상황Id읽기(imageKey) {
  const part = String(imageKey || '').split('__').find(value => /^(?:scene|task)-/.test(value));
  return part?.replace(/^(?:scene|task)-/, '') || '';
}

function ImageStudio_장면자동자세후보읽기(imageKey) {
  const situation = ImageStudio_장면상황Id읽기(imageKey);
  if (!situation) return [];
  let priority = [];
  if (['riding', 'patron_riding'].includes(situation)) priority = ImageStudio_기승자세우선순위;
  else if (/^(?:patron_)?(?:sex|anal)(?:_|$)/.test(situation) || ['sex', 'anal'].includes(situation)) priority = ImageStudio_삽입자세우선순위;
  else if (['standing_sex', 'patron_standing_sex'].includes(situation)) priority = ['standing-sex'];
  else priority = ImageStudio_구강손자세우선순위.get(situation) || [];
  const compatiblePriority = priority.filter(id => ImageStudio_자세상황에맞는가(id, imageKey));
  if (compatiblePriority.length) return compatiblePriority;
  return Object.keys(POSITION_PRESETS).filter(id => ImageStudio_자세상황에맞는가(id, imageKey));
}

function ImageStudio_자세프리셋장면맞춤(preset, imageKey) {
  if (!preset || preset.id === 'double-penetration' || !/^(?:patron_)?anal(?:_|$)/.test(ImageStudio_장면상황Id읽기(imageKey))) return preset;
  return { ...preset, prompt: String(preset.prompt || '').replaceAll('vaginal sex', 'anal sex') };
}

function ImageStudio_장면자세정리하기(result, preset) {
  if (!Array.isArray(result?.parts)) return result;
  const 자세태그 = /^(?:standing|sitting|seated|on chair|kneeling|looking up|lying(?: on (?:back|side)| face down)?|on (?:all )?fours|all fours|ass up|bent over|legs (?:spread|raised)|straddling|girl on top|facing (?:another|away)|face to face|sex from behind|standing sex|rear view)$/;
  const 행위태그 = /^(?:vaginal sex|anal sex|fellatio|cunnilingus|handjob|paizuri|breast press|mutual oral sex|69 position)$/;
  const 행위교체 = !['standing', 'sitting', 'kneeling', 'lying-back', 'all-fours'].includes(preset?.id);
  const removed = [];
  const parts = result.parts.flatMap(part => {
    if (!POSITION_PART_LABELS.has(part.label)) return [part];
    const kept = promptTokens(part.tags).filter(tag => {
      const normalized = promptTagIdentity(tag).spaced;
      const conflict = 자세태그.test(normalized) || (행위교체 && 행위태그.test(normalized));
      if (conflict) removed.push(tag);
      return !conflict;
    });
    return kept.length ? [{ ...part, tags: kept.join(', ') }] : [];
  });
  return removed.length ? { ...result, prompt: withoutPromptTags(result.prompt, removed.join(', ')), parts } : result;
}

function ImageStudio_추가조건목록읽기() {
  if (host.planning?.axes) return host.planning.axes;
  const auto = { value: 'auto', label: '자동 · 추가 지정 없음' };
  const axes = [
    { id: 'promptPreset', label: '상황 프리셋', section: '프롬프트 세부 조건', items: [auto, legacySituationConfig(), ...currentSituationPresets()].map(item => item.value ? item : { value: item.id, label: item.name }) },
    { id: 'promptPosition', label: '자세 / 체위 · 장면별 적용', section: '프롬프트 세부 조건', items: [{value:'auto',label:'적용 안함 · 자세 추가 없음'}, ...Object.values(POSITION_PRESETS).filter(item=>item.id!=='none').map(item => ({ value: item.id, label: item.name, description: '이 자세와 어울리는 장면에만 적용됩니다.' }))] },
  ];
  for (const group of FIELD_GROUPS) {
    const families = new Map();
    for (const field of group.fields) {
      const family = field.key.startsWith('badguest.') || field.key.endsWith('.map') ? field.key : field.key.split('.').slice(0, -1).join('.');
      const id = 'promptField:' + family;
      if (!families.has(id)) families.set(id, { id, family, group: group.id, label: field.label.replace(/ · .*$| [0-9].*$/, ''), section: group.id === 'h-status' ? '추가 장면/작업' : group.title + ' · 세부 조건', items: [auto] });
      const axis = families.get(id);
      if (field.key.endsWith('.map')) {
        const maps = [currentPrompts(),currentNegativePrompts(), ...currentSituationPresets().flatMap(preset => [preset.prompts,preset.negativePrompts])];
        const keys = [...new Set(maps.flatMap(prompts => Object.keys(parseMap(prompts?.[field.key]))))];
        for (const key of keys) axis.items.push({ value: field.key + ':' + key, label: field.label + ' · ' + key });
      } else axis.items.push({ value: field.key, label: field.label });
    }
    axes.push(...families.values());
  }
  axes.push({ id: 'promptDialogue', label: '대화 감지 규칙', section: '대화 · 세부 조건', items: [auto, ...[legacySituationConfig(), ...currentSituationPresets()].flatMap(config => config.dialogueRules || []).filter((rule, index, rules) => rules.findIndex(other => other.id === rule.id) === index).map(rule => ({ value: rule.id, label: rule.text }))] });
  axes.push(...ImageStudio_맥락조건축읽기(auto));
  return axes;
}
function ImageStudio_추가조건공간읽기(selected = {}) {
  const settings = api.settings.get();
  const axes = ImageStudio_추가조건목록읽기();
  const dimensions = [];
  let count = 1n;
  for (const axis of axes) {
    const valid = new Set(axis.items.map(item => item.value));
    const values = Array.isArray(selected[axis.id]) && selected[axis.id].length ? selected[axis.id] : ['auto'];
    const choices = [...new Set(values)].filter(value => valid.has(value));
    if (!choices.length) throw Error(axis.label + '에서 유효한 세부 조건을 선택해 주세요.');
    dimensions.push({ id: axis.id, choices });
    count *= BigInt(choices.length);
  }
  return { count, at(index) {
    if (index < 0n || index >= count) throw Error('세부 조건 조합 인덱스가 범위를 벗어났습니다.');
    const values = [];
    for (let position = dimensions.length - 1; position >= 0; position--) {
      const { id, choices } = dimensions[position], size = BigInt(choices.length);
      values[position] = choices[Number(index % size)]; index /= size;
    }
    const combination = Object.fromEntries(dimensions.map(({id}, position) => [id,values[position]]));
    ImageStudio_계획설정자료.set(combination,{settings,axes});
    return combination;
  } };
}
function ImageStudio_추가조건조합읽기(selected = {}) {
  const space = ImageStudio_추가조건공간읽기(selected);
  if (space.count > 120000n) throw Error('세부 조건 조합이 120,000개를 넘었습니다. 선택을 줄여 주세요.');
  return Array.from({length:Number(space.count)}, (_, index) => space.at(BigInt(index)));
}
function ImageStudio_계획상황설정읽기(character, characterId) {
  const id = host.planning?.combination?.promptPreset;
  if (!id || id === 'auto') return situationConfigForCharacter(character, characterId);
  return id === 'default' ? legacySituationConfig() : currentSituationPresets().find(preset => preset.id === id) || legacySituationConfig();
}
function ImageStudio_상태코드읽기(value) {
  const [key,mapKey] = value.split(':');
  if (mapKey) return (key === 'status.feelings.map' ? 'feeling-' : 'drive-') + mapKey;
  if (key.startsWith('badguest.')) return key.slice(9);
  if (key.startsWith('jewelry.')) return key.replaceAll('.','-');
  return key.split('.').slice(1).join('-');
}
function ImageStudio_계획상태묶음읽기(state, character, characterId, config, imageKey, polarity) {
  if (!config) return [];
  const source = polarity === 'positivePrompt' ? config.prompts : config.negativePrompts;
  let groups = promptGroups(state, character, characterId, source, config.outfitStates, config.dialogueRules, imageKey, polarity);
  const combination = host.planning?.combination || {};
  const fields = ImageStudio_추가조건목록읽기().filter(axis => axis.family && combination[axis.id] && combination[axis.id] !== 'auto');
  // 명시한 영역은 자동 판정 대신 선택한 세부 상태로 구성합니다.
  const explicit = new Set(fields.map(axis => axis.group));
  if (host.planning && polarity === 'positivePrompt') {
    host.planning.gagged = fields.some(axis => combination[axis.id] === 'badguest.gagged')
      || (!explicit.has('badguest') && ImageStudio_입마개상태인가(state, character, characterId));
  }
  const bodyParts = new Set(fields.filter(axis => axis.group === 'h-status').map(axis => axis.family.split('.')[1]));
  groups = groups.filter(group => !(explicit.has('badguest') && group.id === 'badguest')
    && !(explicit.has('detail') && group.label === api.t({ko:'상세 상태',en:'Detailed status'}))
    && ![...bodyParts].some(part => group.id === 'body-' + part)
    && !(combination.promptDialogue && combination.promptDialogue !== 'auto' && group.id === 'dialogue'));
  const manual = new Map();
  for (const axis of fields) {
    const value = combination[axis.id], separator = value.indexOf(':'), key = separator < 0 ? value : value.slice(0, separator);
    const tags = separator < 0 ? source?.[key] || '' : parseMap(source?.[key])[value.slice(separator + 1)] || '';
    if (!outfitAllows(config.outfitStates?.[key] || DEFAULT_OUTFIT_STATES[key] || ALL_OUTFIT_STATES, outfitIdFor(character,imageKey),key,imageKey,character)) continue;
    const part = axis.family.split('.')[1];
    const id = axis.group === 'h-status' ? 'body-' + part : axis.group;
    const label = axis.group === 'badguest' ? api.t({ko:'나쁜 손님 모드용',en:'Bad Guest'}) : axis.group === 'detail' ? api.t({ko:'상세 상태',en:'Detailed status'}) : api.t({ko:'부위별 상태 · '+(FLUID_PARTS.find(entry=>entry.part===part)?.label || part),en:'Body status · '+part});
    if (!manual.has(id)) manual.set(id,{id,label,value:{codes:[],tags:[]}});
    addPrompt(manual.get(id).value,ImageStudio_상태코드읽기(value),tags);
  }
  groups.push(...[...manual.values()].filter(group=>group.value.tags.length));
  if (combination.promptDialogue && combination.promptDialogue !== 'auto') {
    const rule = [...(config.dialogueRules || []),...currentDialogueRules(),...currentSituationPresets().flatMap(preset => preset.dialogueRules || [])].find(rule => rule.id === combination.promptDialogue);
    if (rule && outfitAllows(rule.outfitStates || ALL_OUTFIT_STATES,outfitIdFor(character,imageKey),'',imageKey,character)) {
      const value={codes:[],tags:[]};addPrompt(value,'dialogue-'+rule.id,rule[polarity]);
      if(value.tags.length) groups.push({id:'dialogue',label:api.t({ko:'대화 감지',en:'Dialogue match'}),value});
    }
  }
  const order = group => group.id === 'dialogue' ? 100 : group.id === 'badguest' ? 0 : group.label === api.t({ko:'상세 상태',en:'Detailed status'}) ? 1 : 2 + FLUID_PARTS.findIndex(part => group.id === 'body-' + part.part);
  return groups.sort((left,right)=>order(left)-order(right));
}
function ImageStudio_계획프롬프트추가하기(build, combination, archetypeId) {
  const previous = host.planning;
  const planning = { combination, archetypeId, ...ImageStudio_계획설정자료.get(combination), state: null, raw: null, result: null };
  host.planning = planning;
  try {
    const items = build();
    if (!items.length) return [];
    if (!planning.result) throw Error('조건부 이미지의 프롬프트를 읽지 못했습니다. 게임과 ImageStudio 버전을 확인해 주세요.');
    const result = planning.result;
    const explicit = Object.entries(combination).filter(([,value]) => value !== 'auto');
    return items.map(item => ({ ...item, talentId: result.key, prompt: result.prompt, negativePrompt: result.negativePrompt, ImageStudioParts: result.parts,
      debug: { ...item.debug, imageMatching: globalThis.WW_ImageStudioMatching?.metadata?.(result.key) || host.matchingContext?.(result.key, host.planning.state?.characters?.[host.planning.state.primaryCharacterId]) },
      ImageStudioGagged: planning.gagged === true,
      ...result.genParams, contextSummary: item.contextSummary + (explicit.length ? ' · ' + explicit.map(([axis,value]) => axis + '=' + value).join(' ') : '') }));
  } finally { host.planning = previous; }
}
host.axes = ImageStudio_추가조건목록읽기;
host.combinations = ImageStudio_추가조건조합읽기;
host.combinationSpace = ImageStudio_추가조건공간읽기;
host.plan = ImageStudio_계획프롬프트추가하기;
baseApi.hook('imagePrompt', { priority: 10000, after(result) { if (host.planning) host.planning.raw = result; } });

// 내장 프롬프트 편집기와 같은 클로저에서 동의·흔적·임신·출산 상태를 이미지 조건으로 만듭니다.
const ImageStudio_맥락상태축목록 = [
  {
    id: 'consent', planningId: 'promptConsent', tabId: 'context-consent', title: '동의·강요 상태',
    note: '현재 성적 장면의 명시적 상태값으로 자발·망설임·강요·강제 합류·미약·환각·착란·만취약·의식 없음 상태를 구분합니다. 호감도 같은 추정 수치는 사용하지 않습니다.',
    values: [
      ['not_applicable', '적용 안 함', '성적 장면이 아니거나 이 조건을 사용하지 않습니다.'],
      ['voluntary', '자발적 참여', '강요·약물·의식 없음 기록이 없는 현재 성적 장면입니다.'],
      ['hesitant', '망설이며 참여', '거절·정체·압박 기록은 있지만 강제 진행 기록은 없는 현재 성적 장면입니다.'],
      ['coerced', '거절 뒤 강요', '현재 손님 장면에 coercedSinceSlot이 기록된 상태입니다.'],
      ['forced_join', '강제 합류', '현재 그룹 장면에 badGuestForcedJoinIds 또는 badGuestForcedGroup이 기록된 상태입니다.'],
      ['drugged', '미약 영향', 'BadGuest의 effects.aphrodisiac이 활성화되었거나 구 badGuestDrugArousal 값이 0보다 큰 상태입니다.'],
      ['hallucinated', '환각 상태', '구 badguest 환각제 효과가 활성화된 상태입니다.'],
      ['confused', '착란·상대 오인', 'BadGuest의 effects.confusion이 활성화되어 상대를 다른 인물로 오인합니다.'],
      ['intoxicated', '만취약 영향', 'BadGuest의 effects.intoxicationFloor가 활성화된 상태입니다.'],
      ['unconscious', '의식 없음', '그녀가 sleeping 또는 passed_out 상태인 성적 장면입니다.'],
    ],
  },
  {
    id: 'residue', planningId: 'promptResidue', tabId: 'context-residue', title: '사정 후 체액 흔적',
    note: 'aftermathTags의 정액 흔적을 읽습니다. 사정 뒤 다른 성행위가 계속되어도 현재 장면 프롬프트와 이미지 키에 흔적을 유지합니다.',
    values: [
      ['none', '흔적 없음', '별도 체액 흔적을 사용하지 않습니다.'],
      ['face', '얼굴의 흔적', 'cum_on_face 상태입니다.'],
      ['hands', '손의 흔적', 'cum_on_hands 상태입니다.'],
      ['chest', '가슴의 흔적', 'cum_on_chest 상태입니다.'],
      ['body', '몸의 흔적', 'cum_on_body 상태입니다.'],
      ['thighs', '허벅지에 흐르는 흔적', 'cum_dripping_thighs 상태입니다.'],
      ['mixed', '여러 부위 흔적', '수동 생성에서 여러 부위 흔적을 한 장에 지정합니다.'],
    ],
  },
  {
    id: 'pregnancy', planningId: 'promptPregnancy', tabId: 'context-pregnancy', title: '임신·산후 상태',
    note: '임신·출산 모드와 창관 임신 연동의 conceptionDay를 읽어 초기·중기·후기를 나누고, 출산 당일에는 산후 상태를 적용합니다. 게임의 임신 기간이나 규칙은 바꾸지 않습니다.',
    values: [
      ['none', '임신 상태 없음', '임신·산후 프롬프트를 사용하지 않습니다.'],
      ['early', '임신 초기', '수정일 당일과 다음 날입니다.'],
      ['middle', '임신 중기', '수정 후 2일째입니다.'],
      ['late', '임신 후기', '수정 후 3일째부터 출산 전까지입니다.'],
      ['postpartum', '출산 당일·산후', '해당 인물의 출산 기록이 현재 날짜에 생성된 상태입니다.'],
    ],
  },
  {
    id: 'life_event', planningId: 'promptLifeEvent', tabId: 'context-life-event', title: '출산·아이 처치 장면',
    note: '임신 모드가 실제로 띄운 출산 직후·아이 처치 상의·입양·부모님 위탁 알림에서만 장면을 적용합니다.',
    values: [
      ['none', '별도 사건 없음', '출산·아이 처치 사건 프롬프트를 사용하지 않습니다.'],
      ['birth', '출산 직후', 'wc2_pregnancy_reaction의 birth 알림입니다.'],
      ['child_discussion', '아이 처치 상의', '입양 또는 부모님 위탁을 결정하기 전의 상의 알림입니다.'],
      ['child_adoption', '입양 장면', '아이 처치 결과가 adopted인 알림입니다.'],
      ['child_parents', '부모님께 맡기는 장면', '아이 처치 결과가 parents인 알림입니다.'],
    ],
  },
];

const ImageStudio_맥락상태기본값 = {
  consent: {
    voluntary: { positivePrompt: 'eager expression, relaxed posture, reciprocating, looking at partner', negativePrompt: 'tears, scared, distressed expression' },
    hesitant: { positivePrompt: 'uncertain expression, nervous, tense posture, looking away', negativePrompt: 'eager expression, broad smile' },
    coerced: { positivePrompt: 'distressed expression, unwilling, tears, defensive posture', negativePrompt: 'smile, eager expression, relaxed expression' },
    forced_join: { positivePrompt: 'distressed expression, overwhelmed, frightened, defensive posture', negativePrompt: 'smile, eager expression, relaxed expression' },
    drugged: { positivePrompt: 'dazed expression, unfocused gaze, weak posture', negativePrompt: 'alert expression, confident expression' },
    hallucinated: { positivePrompt: 'hypnotized, spiral eyes, swirling pupils, concentric spiral pupils, dazed smile, vacant expression, anime-style spiral eyes', negativePrompt: 'normal pupils, sharp focused eyes, alert expression' },
    confused: { positivePrompt: 'dazed expression, unfocused gaze, confused expression', negativePrompt: 'alert expression, sharp focused eyes' },
    intoxicated: { positivePrompt: 'drunk, flushed face, unsteady posture', negativePrompt: 'alert expression' },
    unconscious: { positivePrompt: 'unconscious, limp body, closed eyes', negativePrompt: 'open eyes, alert expression, smile' },
  },
  residue: {
    face: { positivePrompt: 'cum on face', negativePrompt: '' },
    hands: { positivePrompt: 'cum on hands', negativePrompt: '' },
    chest: { positivePrompt: 'cum on chest, semen on breasts', negativePrompt: '' },
    body: { positivePrompt: 'cum on body', negativePrompt: '' },
    thighs: { positivePrompt: 'cum dripping down thighs, semen on thighs', negativePrompt: '' },
    mixed: { positivePrompt: 'cum on face, cum on chest, cum on body, cum dripping down thighs', negativePrompt: '' },
  },
  pregnancy: {
    early: { positivePrompt: '', negativePrompt: '' },
    middle: { positivePrompt: '', negativePrompt: '' },
    late: { positivePrompt: '', negativePrompt: '' },
    postpartum: { positivePrompt: 'postpartum woman, exhausted, resting', negativePrompt: '' },
  },
  life_event: {
    birth: { positivePrompt: 'childbirth aftermath, newborn baby, exhausted mother, resting in bed, clothed', negativePrompt: 'nsfw, sex, erotic, nude' },
    child_discussion: { positivePrompt: 'serious family discussion, newborn baby, conflicted expression, clothed', negativePrompt: 'nsfw, sex, erotic, nude' },
    child_adoption: { positivePrompt: 'newborn baby, adoption handoff, bittersweet expression, clothed', negativePrompt: 'nsfw, sex, erotic, nude' },
    child_parents: { positivePrompt: 'newborn baby, grandparents receiving baby, family farewell, clothed', negativePrompt: 'nsfw, sex, erotic, nude' },
  },
};

const ImageStudio_맥락상태선택값 = Object.fromEntries(ImageStudio_맥락상태축목록.map(axis => [axis.id, '']));
const ImageStudio_맥락상태탭목록 = ImageStudio_맥락상태축목록.map(axis => ({
  id: axis.tabId, title: axis.title, note: axis.note, fields: [], contextAxis: axis.id,
}));
SETTINGS_TABS.splice(SETTINGS_TABS.findIndex(tab => tab.id === 'dialogue'), 0, ...ImageStudio_맥락상태탭목록);

function ImageStudio_맥락상태설정정규화하기(value) {
  const result = Object.fromEntries(ImageStudio_맥락상태축목록.map(axis => [axis.id, {}]));
  if (!value || typeof value !== 'object' || Array.isArray(value)) return result;
  for (const axis of ImageStudio_맥락상태축목록) {
    const source = value[axis.id];
    if (!source || typeof source !== 'object' || Array.isArray(source)) continue;
    const allowed = new Set(axis.values.map(([id]) => id));
    for (const [rawId, prompt] of Object.entries(source)) {
      const id = String(rawId || '').trim();
      if (!allowed.has(id) || !prompt || typeof prompt !== 'object' || Array.isArray(prompt)) continue;
      const normalized = {};
      if (typeof prompt.positivePrompt === 'string') normalized.positivePrompt = prompt.positivePrompt;
      if (typeof prompt.negativePrompt === 'string') normalized.negativePrompt = prompt.negativePrompt;
      if (Object.keys(normalized).length) result[axis.id][id] = normalized;
    }
  }
  return result;
}

function ImageStudio_맥락상태설정읽기() {
  return ImageStudio_맥락상태설정정규화하기(api.settings.get({ contextStatePrompts: {} }).contextStatePrompts);
}

function ImageStudio_맥락상태프롬프트읽기(axisId, valueId, field) {
  const saved = ImageStudio_맥락상태설정읽기()[axisId]?.[valueId];
  if (saved && Object.prototype.hasOwnProperty.call(saved, field)) return String(saved[field] || '');
  return String(ImageStudio_맥락상태기본값[axisId]?.[valueId]?.[field] || '');
}

function ImageStudio_맥락상태필드저장하기(axisId, valueId, field, value) {
  const settings = ImageStudio_맥락상태설정읽기();
  const axis = { ...settings[axisId] };
  axis[valueId] = { ...(axis[valueId] || {}), [field]: String(value ?? '') };
  api.settings.set({ contextStatePrompts: { ...settings, [axisId]: axis } });
}

function ImageStudio_맥락상태항목초기화하기(axisId, valueId) {
  const settings = ImageStudio_맥락상태설정읽기();
  const axis = { ...settings[axisId] };
  delete axis[valueId];
  api.settings.set({ contextStatePrompts: { ...settings, [axisId]: axis } });
}

function ImageStudio_맥락장면읽기(imageKey) {
  try {
    const parsed = ImageStudio_이미지키해석하기(String(imageKey || ''));
    return String(parsed?.scene || parsed?.task || '');
  } catch {
    return String(imageKey || '').split('__').find(part => /^(?:scene|task)-/.test(part))?.replace(/^(?:scene|task)-/, '') || '';
  }
}

function ImageStudio_성적맥락인가(imageKey, state) {
  const situation = ImageStudio_맥락장면읽기(imageKey);
  if (state?.activeScene?.sex || state?.activeScene?.patron) return true;
  if (!situation) return false;
  if (situation.startsWith('patron_')) return !['patron_chatting', 'patron_flirting'].includes(situation);
  return /(?:sex|anal|blowjob|deepthroat|handjob|titfuck|cunnilingus|fingered|grinding|riding|thigh_job|sixty_nine|facial|finish|cum_in_mouth|groped|kissing|mutual_touching|breast_worship)/.test(situation);
}

function ImageStudio_동의상태판정하기(state, character, imageKey) {
  if (!ImageStudio_성적맥락인가(imageKey, state)) return 'not_applicable';
  const situation = ImageStudio_맥락장면읽기(imageKey);
  if (['sleeping','passed_out'].includes(character?.currentTask ?? character?.task) || situation === 'passed_out') return 'unconscious';
  const patron = state?.activeScene?.patron;
  const flags = ImageStudio_나쁜손님상태읽기(state, character, characterIdOf(state, character));
  if (patron) {
    if (patron.badGuestForcedGroup || (Array.isArray(patron.badGuestForcedJoinIds) && patron.badGuestForcedJoinIds.length)) return 'forced_join';
    if (patron.coercedSinceSlot != null) return 'coerced';
    if (flags.confused) return 'confused';
    if (flags.hallucinated) return 'hallucinated';
    if (flags.drugged) return 'drugged';
    if (flags.intoxicated) return 'intoxicated';
    if (patron.hasBeenRefused || Number(patron.stalled) > 0 || Number(patron.pressureLevel) > 0 || patron.lastResponse === 'refuse') return 'hesitant';
  }
  if (flags.confused) return 'confused';
  if (flags.hallucinated) return 'hallucinated';
  if (flags.drugged) return 'drugged';
  if (flags.intoxicated) return 'intoxicated';
  return 'voluntary';
}

const ImageStudio_흔적상태대응표 = new Map([
  ['cum_on_face', 'face'], ['cum_on_hands', 'hands'], ['cum_on_chest', 'chest'],
  ['cum_on_body', 'body'], ['cum_dripping_thighs', 'thighs'],
]);

function ImageStudio_흔적상태판정하기(character, imageKey) {
  const situation = ImageStudio_맥락장면읽기(imageKey);
  if (situation.includes('bath')) return [];
  const values = [...new Set((Array.isArray(character?.aftermathTags) ? character.aftermathTags : [])
    .map(tag => ImageStudio_흔적상태대응표.get(String(tag))).filter(Boolean))];
  return values;
}

function ImageStudio_임신기록읽기(state, character, characterId) {
  const main = state?.wc2PregnancyBirthMode265;
  if (characterId === state?.primaryCharacterId || character === state?.characters?.[state?.primaryCharacterId]) {
    return { pregnancy: main?.pregnancy || null, births: main?.birthLog || [] };
  }
  const keys = [characterId, character?.id, character?.workerId, character?.shortname].filter(Boolean).map(String);
  const workers = state?.waywardBrothelPregnancyV1?.workers || {};
  const workerId = keys.find(key => workers[key]);
  const events = state?.waywardBrothelPregnancyV1?.events || [];
  return workerId ? { pregnancy: workers[workerId]?.pregnancy || null, births: events.filter(event => event.workerId === workerId && event.type === 'birth') } : { pregnancy: null, births: [] };
}

function ImageStudio_임신상태판정하기(state, character, characterId) {
  const record = ImageStudio_임신기록읽기(state, character, characterId);
  const day = Number(state?.day) || 1;
  if (record.pregnancy && Number.isFinite(Number(record.pregnancy.conceptionDay))) {
    const elapsed = Math.max(0, day - Number(record.pregnancy.conceptionDay));
    return elapsed <= 1 ? 'early' : elapsed === 2 ? 'middle' : 'late';
  }
  return record.births.some(entry => Number(entry?.day) === day) ? 'postpartum' : 'none';
}

function ImageStudio_아이처치기록읽기(state, alert) {
  const reference = alert?.childDisposition;
  if (!reference?.recordId) return null;
  if (reference.source === 'brothel-pregnancy') return state?.waywardBrothelPregnancyV1?.events?.find(entry => entry.id === reference.recordId)?.childDisposition || null;
  return state?.wc2PregnancyBirthMode265?.birthLog?.find(entry => entry.id === reference.recordId)?.childDisposition || null;
}

function ImageStudio_생활사건판정하기(state, character, characterId) {
  const alert = state?.pendingEvent?.alert;
  const mainCharacter = characterId === state?.primaryCharacterId || character === state?.characters?.[state?.primaryCharacterId];
  if (alert?.kind === 'wc2_pregnancy_reaction' && alert?.pregnancyPaternityNotice?.type === 'birth') return mainCharacter ? 'birth' : 'none';
  if (alert?.kind !== 'wc2_child_disposition') return 'none';
  if (alert.childDisposition?.source === 'brothel-pregnancy') {
    const keys = [characterId, character?.id, character?.workerId, character?.shortname].filter(Boolean).map(String);
    if (!keys.includes(String(alert.childDisposition.workerId || ''))) return 'none';
  } else if (!mainCharacter) return 'none';
  if (alert.childDisposition?.phase === 'question') return 'child_discussion';
  const disposition = ImageStudio_아이처치기록읽기(state, alert);
  return disposition?.status === 'adopted' ? 'child_adoption' : disposition?.status === 'parents' ? 'child_parents' : 'child_discussion';
}

function ImageStudio_맥락상태값읽기(axisId, state, character, characterId, imageKey) {
  const explicit = host.planning?.combination?.[ImageStudio_맥락상태축목록.find(axis => axis.id === axisId)?.planningId];
  if (explicit && explicit !== 'auto') return axisId === 'residue' ? explicit === 'none' ? [] : [explicit] : explicit;
  if (host.planning) return axisId === 'residue' ? [] : axisId === 'consent' ? 'not_applicable' : 'none';
  if (axisId === 'consent') return ImageStudio_동의상태판정하기(state, character, imageKey);
  if (axisId === 'residue') return ImageStudio_흔적상태판정하기(character, imageKey);
  if (axisId === 'pregnancy') return ImageStudio_임신상태판정하기(state, character, characterId);
  return ImageStudio_생활사건판정하기(state, character, characterId);
}

function ImageStudio_맥락상태묶음읽기(state, character, characterId, imageKey, promptField) {
  const groups = [];
  for (const axis of ImageStudio_맥락상태축목록) {
    let values = ImageStudio_맥락상태값읽기(axis.id, state, character, characterId, imageKey);
    values = Array.isArray(values) ? values : [values];
    values = values.filter(value => value && !['none', 'not_applicable'].includes(value));
    if (!values.length) continue;
    const tags = values.flatMap(value => promptTokens(ImageStudio_맥락상태프롬프트읽기(axis.id, value, promptField)));
    if (!tags.length) continue;
    groups.push({
      id: `context-${axis.id}`,
      label: axis.title,
      value: { codes: values.map(value => `context.${axis.id}.${value}`), tags },
    });
  }
  return groups;
}

function ImageStudio_맥락프롬프트직접적용하기(result, state, character, characterId) {
  if (!result || !Array.isArray(result.parts)) return result;
  const positive = ImageStudio_맥락상태묶음읽기(state, character, characterId, result.key, 'positivePrompt');
  const negative = ImageStudio_맥락상태묶음읽기(state, character, characterId, result.key, 'negativePrompt');
  if (!positive.length && !negative.length) return result;
  const prompt = joinPrompt(`${result.prompt || ''}, ${positive.flatMap(group => group.value.tags).join(', ')}`);
  const negativePrompt = joinPrompt(`${result.negativePrompt || ''}, ${negative.flatMap(group => group.value.tags).join(', ')}`);
  return {
    ...result,
    key: keyWithState(result.key, combinedStateSignature(positive, negative), false, null, true),
    prompt,
    negativePrompt,
    parts: [...result.parts, ...positive.map(group => ({ label: group.label, tags: group.value.tags.join(', ') }))],
    genParams: promptGenParams(prompt),
  };
}

function ImageStudio_맥락조건축읽기(auto) {
  return ImageStudio_맥락상태축목록.map(axis => ({
    id: axis.planningId,
    label: axis.title,
    section: axis.id === 'life_event' ? '추가 장면/작업' : '상황 인식 · 세부 조건',
    items: [auto, ...axis.values.map(([value, label, description]) => ({ value, label, description }))],
  }));
}

function ImageStudio_맥락프롬프트그리기(h, win, tab) {
  const axis = ImageStudio_맥락상태축목록.find(item => item.id === tab.contextAxis);
  const candidates = axis.values.filter(([id]) => !['none', 'not_applicable'].includes(id));
  const selected = candidates.find(([id]) => id === ImageStudio_맥락상태선택값[axis.id]) || candidates[0];
  ImageStudio_맥락상태선택값[axis.id] = selected[0];
  const [valueId, label, description] = selected;
  const field = activePromptPolarity === 'negative' ? 'negativePrompt' : 'positivePrompt';
  const settings = ImageStudio_맥락상태설정읽기();
  const customized = Object.prototype.hasOwnProperty.call(settings[axis.id]?.[valueId] || {}, field);
  const value = ImageStudio_맥락상태프롬프트읽기(axis.id, valueId, field);
  const save = next => { ImageStudio_맥락상태필드저장하기(axis.id, valueId, field, next); win.refresh(); };
  return [
    h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
      h('strong', { style: 'font-size:12px;' }, `${axis.title} ${candidates.length}개`),
      h('select', {
        value: valueId, 'data-context-state-source': axis.id,
        style: 'width:100%;box-sizing:border-box;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;',
        onchange: event => { ImageStudio_맥락상태선택값[axis.id] = event.currentTarget.value; activeTagTarget = null; win.refresh(); },
      }, ...candidates.map(([id, itemLabel]) => h('option', { value: id, selected: id === valueId }, `${itemLabel} (${id})`))),
      h('span', { class: 'wml-muted wml-small' }, customized ? '이 항목의 수정값을 표시 중입니다.' : '내장 기본값을 표시 중입니다.'),
    ),
    h('p', { class: 'wml-note', style: 'margin-bottom:10px;' }, description),
    h('label', { style: 'display:grid;gap:4px;margin-bottom:10px;' },
      h('strong', { style: 'font-size:12px;' }, activePromptPolarity === 'negative' ? '추가 Negative 프롬프트' : '추가 Positive 프롬프트'),
      h('textarea', {
        rows: 5, value, spellcheck: false, 'data-context-state-prompt': `${axis.id}:${activePromptPolarity}`,
        style: 'width:100%;box-sizing:border-box;resize:vertical;min-height:100px;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font:12px/1.45 ui-monospace,Consolas,monospace;',
        onfocus: () => { activeTagTarget = { kind: 'context-state', axis: axis.id, id: valueId, polarity: activePromptPolarity, label: `${label} ${activePromptPolarity}` }; },
        onchange: event => save(event.currentTarget.value),
      }),
      promptTagChips(h, value, win),
      promptTagAdder(h, value, save, `context:${axis.id}:${valueId}:${activePromptPolarity}`),
    ),
    h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;' },
      api.ui.button('이 항목을 내장 기본값으로 복원', () => { ImageStudio_맥락상태항목초기화하기(axis.id, valueId); win.refresh(); }, { disabled: !settings[axis.id]?.[valueId] }),
      h('span', { class: 'wml-muted wml-small' }, '판정 기준은 위 설명대로 고정되며, 이미지에 보낼 Positive·Negative 문구는 여기서 직접 지정합니다.'),
    ),
  ];
}

const ImageStudio_맥락원본설정그리기 = ImageStudio_확장설정그리기;
function ImageStudio_맥락확장설정그리기(body, win) {
  ImageStudio_맥락원본설정그리기(body, win);
  const tab = ImageStudio_맥락상태탭목록.find(item => item.id === activeSettingsTab);
  if (!tab) return;
  body.querySelector('[data-active-situation-preset]')?.remove();
  const introduction = body.querySelector('main > p.wml-note');
  if (introduction) introduction.textContent = '게임 상태 판정은 설명된 명시적 값만 사용합니다. 각 결과에 보낼 Positive·Negative 프롬프트는 직접 수정할 수 있습니다.';
  const section = body.querySelector('main > section.wml-section');
  if (section) section.append(...ImageStudio_맥락프롬프트그리기(api.ui.h, win, tab).filter(Boolean));
}
api.ui.settings(ImageStudio_맥락확장설정그리기);

// 내장 프롬프트 편집기와 같은 클로저에서 탭별 JSON 범위를 관리합니다.
function ImageStudio_JSON전체읽기() {
  const presets = currentSituationPresets();
  return {
    format: 'wayward-state-image-prompts', version: 17,
    wives: (customWifeStore.getState().wives || []).map(entry => ({
      id: entry.id, inputs: { ...entry.inputs },
      ...(typeof entry.portraitKey === 'string' ? { portraitKey: entry.portraitKey } : {}),
      ...(typeof entry.portraitUrl === 'string' ? { portraitUrl: entry.portraitUrl } : {}),
    })),
    characterPrompt: currentCharacterPrompt(), outfitPrompts: currentOutfitPrompts(),
    nativeAxisPrompts: ImageStudio_기본축설정읽기(),
    contextStatePrompts: ImageStudio_맥락상태설정읽기(),
    situationPresets: presets, situationPresetAssignments: currentSituationPresetAssignments(presets),
    positionPresetPrompts: currentPositionPresetPrompts(), positionPresetNegativePrompts: currentPositionPresetNegativePrompts(),
    positionGroupPrompts: currentPositionGroupPrompts(),
    prompts: currentPrompts(), negativePrompts: currentNegativePrompts(), outfitStates: currentOutfitStates(),
    dialogueRules: currentDialogueRules(), fluidDecay: currentFluidDecaySettings(),
    residuePrompts: currentResiduePrompts(), customTags: currentCustomTags(),
  };
}

function ImageStudio_JSON탭섹션읽기(tab) {
  if (tab.id === 'character') return ['wives', 'characterPrompt'];
  if (tab.id === 'outfit-prompts') return ['outfitPrompts'];
  if (tab.id === 'situation-presets') return ['situationPresets', 'situationPresetAssignments'];
  if (tab.id === 'positions') return ['positionPresetPrompts', 'positionPresetNegativePrompts', 'positionGroupPrompts'];
  if (tab.id === 'dialogue') return ['dialogueRules'];
  if (tab.id === COMPOSITION_TAB.id || FIELD_GROUPS.some(group => group.id === tab.id)) return [
    'prompts', 'negativePrompts', 'outfitStates', ...(tab.id === 'h-status' ? ['fluidDecay', 'residuePrompts'] : []),
  ];
  return [];
}

function ImageStudio_JSON탭읽기(tab) {
  const data = { format: 'wayward-state-image-prompts', version: 17, scope: 'tab', tabId: tab.id };
  if (tab.axis) return { ...data, nativeAxisPrompts: { [tab.axis]: ImageStudio_기본축설정읽기()[tab.axis] } };
  if (tab.contextAxis) return { ...data, contextStatePrompts: { [tab.contextAxis]: ImageStudio_맥락상태설정읽기()[tab.contextAxis] } };
  const all = ImageStudio_JSON전체읽기();
  const config = activeSituationConfig();
  for (const section of ImageStudio_JSON탭섹션읽기(tab)) {
    const value = ['prompts', 'negativePrompts', 'outfitStates', 'dialogueRules'].includes(section) ? config[section] : all[section];
    data[section] = ['prompts', 'negativePrompts', 'outfitStates'].includes(section)
      ? Object.fromEntries(tab.fields.map(field => [field.key, value[field.key]])) : value;
  }
  return data;
}

function ImageStudio_JSON불러온뒤갱신하기(syncDecay = false) {
  publishCurrentWifePromptProfile();
  activeTagTarget = null;
  if (syncDecay) syncFluidDecay(true);
}

function ImageStudio_JSON탭불러오기(parsed, tab) {
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw Error('JSON 설정 객체가 필요합니다.');
  if (parsed.scope === 'tab' && parsed.tabId !== tab.id) throw Error('다른 탭의 JSON입니다. 해당 탭에서 불러오세요.');
  if (tab.axis) {
    const source = parsed.nativeAxisPrompts?.[tab.axis];
    if (!source || typeof source !== 'object' || Array.isArray(source)) throw Error('해당 탭의 프롬프트가 없습니다.');
    const normalized = ImageStudio_기본축설정정규화하기({ [tab.axis]: source });
    if (Object.keys(source).length && !Object.keys(normalized[tab.axis]).length) throw Error('올바른 프롬프트 항목이 없습니다.');
    api.settings.set({ nativeAxisPrompts: { ...ImageStudio_기본축설정읽기(), [tab.axis]: normalized[tab.axis] } });
  } else if (tab.contextAxis) {
    const source = parsed.contextStatePrompts?.[tab.contextAxis];
    if (!source || typeof source !== 'object' || Array.isArray(source)) throw Error('해당 탭의 프롬프트가 없습니다.');
    const normalized = ImageStudio_맥락상태설정정규화하기({ [tab.contextAxis]: source });
    if (Object.keys(source).length && !Object.keys(normalized[tab.contextAxis]).length) throw Error('올바른 프롬프트 항목이 없습니다.');
    api.settings.set({ contextStatePrompts: { ...ImageStudio_맥락상태설정읽기(), [tab.contextAxis]: normalized[tab.contextAxis] } });
  } else {
    const sections = ImageStudio_JSON탭섹션읽기(tab);
    const filtered = Object.fromEntries(sections.filter(section => Object.prototype.hasOwnProperty.call(parsed, section))
      .map(section => [section, parsed[section]]));
    // 필드형 탭은 편집 중인 프리셋의 해당 키만 합칩니다.
    if (tab.id === COMPOSITION_TAB.id || FIELD_GROUPS.some(group => group.id === tab.id) || tab.id === 'dialogue') {
      const config = activeSituationConfig();
      const changes = {};
      const allowed = new Set((tab.fields || []).map(field => field.key));
      for (const section of ['prompts', 'negativePrompts', 'outfitStates']) {
        if (!Object.prototype.hasOwnProperty.call(filtered, section)) continue;
        const imported = section === 'outfitStates' ? importedOutfitStates(filtered[section], parsed.outfitModes)
          : importedPrompts(filtered[section], section === 'prompts' ? DEFAULT_PROMPTS : DEFAULT_NEGATIVE_PROMPTS);
        const entries = Object.entries(imported).filter(([key]) => allowed.has(key));
        if (entries.length) changes[section] = { ...config[section], ...Object.fromEntries(entries) };
      }
      if (Array.isArray(filtered.dialogueRules)) changes.dialogueRules = filtered.dialogueRules.map(normalizeDialogueRule).filter(Boolean);
      const extras = {};
      for (const [section, normalize] of [['fluidDecay', normalizeFluidDecaySettings], ['residuePrompts', normalizeResiduePrompts]]) {
        const value = filtered[section];
        if (value && typeof value === 'object' && !Array.isArray(value)) extras[section] = normalize(value);
      }
      for(const section of ['equipmentPrompts','hStatusGenerationModes'])if(Object.prototype.hasOwnProperty.call(filtered,section)){
        extras[section]=importPromptSettings(JSON.stringify({[section]:filtered[section]}))[section];
      }
      if (!Object.keys(changes).length && !Object.keys(extras).length) throw Error('해당 탭에 불러올 설정이 없습니다.');
      for (const [section, value] of Object.entries(changes)) saveActiveSituationSection(section, value);
      if (Object.keys(extras).length) api.settings.set(extras);
    } else {
      // 기존 가져오기 검증·정규화를 재사용하되 다른 탭은 입력과 저장 양쪽에서 제외합니다.
      const imported = importPromptSettings(JSON.stringify(filtered));
      api.settings.set(Object.fromEntries(sections.filter(section => section !== 'wives' && section in filtered)
        .map(section => [section, imported[section]])));
      if (tab.id === 'situation-presets') activeSituationPresetId = LEGACY_SITUATION_PRESET_ID;
    }
  }
  ImageStudio_JSON불러온뒤갱신하기(tab.id === 'h-status');
}

function ImageStudio_JSON탭초기화하기(tab) {
  if (tab.axis) api.settings.set({ nativeAxisPrompts: { ...ImageStudio_기본축설정읽기(), [tab.axis]: {} } });
  else if (tab.contextAxis) api.settings.set({ contextStatePrompts: { ...ImageStudio_맥락상태설정읽기(), [tab.contextAxis]: {} } });
  else if (tab.id === 'character') api.settings.set({ characterPrompt: { ...DEFAULT_CHARACTER_PROMPT } });
  else if (tab.id === 'outfit-prompts') api.settings.set({ outfitPrompts: {} });
  else if (tab.id === 'situation-presets') {
    api.settings.set({ situationPresets: [], situationPresetAssignments: {} });
    activeSituationPresetId = LEGACY_SITUATION_PRESET_ID;
  } else if (tab.id === 'positions') {
    api.settings.set({ positionPresetPrompts: {}, positionPresetNegativePrompts: {}, positionGroupPrompts: {}, personDetails: undefined });
    positionSelection = { situationId: latestScenePrompt?.situationId || '', presetId: 'none', groupSlots: '' };
    positionRandomChoices.clear(); positionPlacementDrafts.clear(); positionGeneratedResults.clear();
  } else if (tab.id === 'dialogue') {
    saveActiveSituationSection('dialogueRules', DEFAULT_DIALOGUE_RULES.map(rule => ({ ...rule, outfitStates: [...rule.outfitStates] })));
  } else if (tab.id === COMPOSITION_TAB.id || FIELD_GROUPS.some(group => group.id === tab.id)) {
    if(tab.id==='h-status')api.settings.set({equipmentPrompts:undefined,hStatusGenerationModes:undefined});
    const config = activeSituationConfig();
    for (const [section, defaults] of [['prompts', DEFAULT_PROMPTS], ['negativePrompts', DEFAULT_NEGATIVE_PROMPTS], ['outfitStates', DEFAULT_OUTFIT_STATES]]) {
      saveActiveSituationSection(section, { ...config[section], ...Object.fromEntries(tab.fields.map(field => [field.key, defaults[field.key]])) });
    }
    if (tab.id === 'h-status') api.settings.set({ fluidDecay: { ...DEFAULT_FLUID_DECAY }, residuePrompts: {} });
  }
  ImageStudio_JSON불러온뒤갱신하기(tab.id === 'h-status');
}

function ImageStudio_JSON입력만들기(h, win, tab) {
  const input = h('input', {
    type: 'file', accept: '.json,application/json', style: 'display:none;', 'data-prompt-json-input': '',
    onchange: async () => {
      const file = input.files?.[0];
      if (!file) return;
      const scope = input.dataset.promptJsonScope;
      try {
        const text = await file.text();
        if (scope === 'tab') ImageStudio_JSON탭불러오기(JSON.parse(text), tab);
        else { api.settings.set(importPromptSettings(text)); ImageStudio_JSON불러온뒤갱신하기(true); }
        settingsMessage = `${file.name || '파일'}에서 ${scope === 'tab' ? tab.title : '전체'} 설정을 불러왔습니다.`;
      } catch (error) { settingsMessage = `불러오기 실패: ${error.message || error}`; }
      input.value = '';
      win.refresh();
    },
  });
  return input;
}

function ImageStudio_JSON버튼그리기(h, win, tab, input) {
  const editable = tab.id !== 'diagnostics';
  const ImageStudio_JSON파일내보내기 = async scope => {
    try {
      const data = scope === 'tab' ? ImageStudio_JSON탭읽기(tab) : ImageStudio_JSON전체읽기();
      await api.saveFile(scope === 'tab' ? `wayward-prompts-${tab.id}.json` : 'wayward-state-image-prompts.json', JSON.stringify(data, null, 2), 'application/json');
      settingsMessage = `${scope === 'tab' ? tab.title : '전체'} 설정을 JSON 파일로 내보냈습니다.`;
    } catch (error) { settingsMessage = `내보내기 실패: ${error.message || error}`; }
    win.refresh();
  };
  const ImageStudio_JSON파일선택하기 = scope => { input.dataset.promptJsonScope = scope; input.click(); };
  return [
    h('div', { class: 'wml-section', 'data-prompt-json-actions': tab.id, style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-top:10px;' },
      api.ui.button('전체 json 내보내기', () => { void ImageStudio_JSON파일내보내기('all'); }),
      api.ui.button('전체 json 불러오기', () => ImageStudio_JSON파일선택하기('all')),
      api.ui.button('해당 탭 json 내보내기', () => { void ImageStudio_JSON파일내보내기('tab'); }, { disabled: !editable }),
      api.ui.button('해당 탭 json 불러오기', () => ImageStudio_JSON파일선택하기('tab'), { disabled: !editable }),
      api.ui.button('해당 탭 프롬프트 초기화하기', () => {
        ImageStudio_JSON탭초기화하기(tab);
        settingsMessage = `${tab.title}의 프롬프트를 초기화했습니다.`;
        win.refresh();
      }, { disabled: !editable }), input,
    ),
    editable ? h('p', { class: 'wml-muted wml-small', style: 'margin:4px 0;' },
      '탭 작업은 해당 탭의 모든 항목을 대상으로 합니다. 나쁜 손님 모드용·상세 상태·H Status·대화는 편집 중인 상황 프리셋에 적용됩니다. 아내 탭 초기화는 외형 수정값을 복원하며 등록된 사용자 아내는 보존합니다.') : null,
  ];
}

// Runs inside the prompt editor closure, where real and planned state codes are available.
host.matchingContext = function ImageStudio_매칭맥락읽기(key, suppliedCharacter) {
  const state=api.store.game();
  const character=(host.planning&&suppliedCharacter?.id?state?.characters?.[suppliedCharacter.id]:null)||suppliedCharacter||state?.characters?.[state.primaryCharacterId];
  if(!state||!character)return null;
  const characterId=characterIdOf(state,character)||character.id||state.primaryCharacterId;
  const snapshot=host.matchingContextSnapshot;
  const base=value=>String(value).split('__').filter(part=>!['state-','dialogue-','position-','character-reuse-','character-regenerate-','studio-'].some(prefix=>part.startsWith(prefix))).join('__');
  const groups=snapshot?.state===state&&snapshot.character===character&&base(snapshot.key)===base(key)?snapshot.groups:(()=>{const context=promptContext(state,character,characterId,key);return [...context.positiveGroups,...context.negativeGroups];})();
  const codes=[...new Set(groups.flatMap(group=>group.value?.codes||[]))];
  const fakePrompts=Object.fromEntries(BAD_GUEST_FIELDS.map(field=>[field.key,'matching-state']));
  const actualBadGuest=ImageStudio_나쁜손님프롬프트읽기(state,character,characterId,fakePrompts)?.codes||[];
  const planned=host.planning?.combination;
  const manualBadGuest=planned&&Object.keys(planned).some(id=>id.startsWith('promptField:badguest.'));
  const badguest=manualBadGuest?groups.filter(group=>group.id==='badguest').flatMap(group=>group.value.codes):actualBadGuest;
  const emotions=host.planning?codes.filter(code=>code.startsWith('feeling-')).map(code=>code.slice(8))
    :topFeelings(character,2).filter(feeling=>Number(feeling.intensity)>15).map(feeling=>feeling.emotion);
  const pregnancy=ImageStudio_맥락상태값읽기('pregnancy',state,character,characterId,key)||'none';
  const detail=codes.filter(code=>!code.startsWith('character.')&&!code.startsWith('outfit.')&&!code.startsWith('feeling-')
    &&!code.startsWith('context.pregnancy.')&&!badguest.includes(code));
  return {version:1,emotions:[...new Set(emotions)].sort(),badguest:[...new Set(badguest)].sort(),
    pregnancy:Array.isArray(pregnancy)?pregnancy[0]||'none':pregnancy,detail:[...new Set(detail)].sort()};
};

// attention 1.41.42의 의미 키·장비 동기화·표정 정합성을 분리 편집기에 선별 적용합니다.
// 원제작자 aaajjaaaadsfa. 게임 상태는 읽기만 하며 생성·검수·저장은 공통 본체에 맡깁니다.
const ImageStudio_이전상태키만들기 = keyWithState;
const ImageStudio_이전자세키만들기 = keyWithPosition;
const ImageStudio_이전프롬프트맥락읽기 = promptContext;
const ImageStudio_이전기본축키만들기 = ImageStudio_기본축키적용하기;
const ImageStudio_이전선택자세읽기 = selectedPositionChoice;
const ImageStudio_이전계획자세읽기 = positionChoiceForImageKey;
const ImageStudio_이전자세적용하기 = applyPositionPreset;
const ImageStudio_이전자세설정그리기 = renderPositionSettings;
const ImageStudio_이전전체JSON읽기 = ImageStudio_JSON전체읽기;
const ImageStudio_이전JSON불러오기 = importPromptSettings;
const ImageStudio_이전JSON갱신하기 = ImageStudio_JSON불러온뒤갱신하기;
const ImageStudio_이전매칭맥락읽기 = host.matchingContext;

// 구버전의 정확한 키만 별칭으로 연결합니다. 서로 다른 행동·장비를 기본 장면으로 합치지 않습니다.
const ImageStudio_이전키별칭 = new Map(Object.entries(api.settings.get().legacySituationKeys || {}));
function ImageStudio_이전키연결하기(before, after) {
  if (!before || before === after || ImageStudio_이전키별칭.get(before) === after) return;
  ImageStudio_이전키별칭.set(before, after);
  while (ImageStudio_이전키별칭.size > 5000) ImageStudio_이전키별칭.delete(ImageStudio_이전키별칭.keys().next().value);
  api.settings.set({ legacySituationKeys: Object.fromEntries(ImageStudio_이전키별칭) });
}
baseApi.use('imagestudio').extensions.registerKeyAdapter({ id: 'attention-semantic-keys', normalize(key) {
  return ImageStudio_이전키별칭.get(key) || key;
} });

function ImageStudio_현재인물읽기(character) {
  if (host.planning || !character) return character;
  const state = api.store.game();
  if (!state) return character;
  const id = character.id;
  if (!id) return character;
  return state?.characters?.[id] || character;
}
// 초상화가 기억한 오래된 character 객체를 장비 해제 후에도 다시 사용하지 않게 합니다.
for (const name of ['imageKey', 'imagePrompt']) baseApi.hook(name, { priority: 30000, before(args) {
  const current = ImageStudio_현재인물읽기(args[0]);
  if (current !== args[0]) return [current, ...args.slice(1)];
} });

// 1.41.42의 시각 상태 묶음 기준. 수갑·토이·부위 흔적·대화·콘텐츠 행동은 묶지 않습니다.
function ImageStudio_시각상태읽기(codes) {
  const active = new Set(codes), has = values => values.some(value => active.has(value));
  if (active.has('intoxication-blacked_out')) return 'unconscious';
  if (has(['energy-0', 'wellbeing-0', 'intoxication-sloppy'])) return 'exhausted';
  if ([...active].some(code => code.startsWith('intoxication-'))) return 'intoxicated';
  if (has(['expression-distressed','energy-1','mood-0','mood-1','wellbeing-1','wellbeing-2','trust-low','resentment-medium','resentment-high','drift-high','latitude-negative',
    'feeling-anger','feeling-contempt','feeling-disgust','feeling-sadness','feeling-shame','feeling-guilt','feeling-regret','feeling-humiliation',
    'drive-financial','drive-security','drive-social'])) return 'distressed';
  if ([...active].some(code => /^arousal-[1-4]$/.test(code)) || has(['allure-high','desire-high','feeling-tenderness','feeling-longing',
    'feeling-desire','feeling-arousal_buzz','drive-approval','drive-desire','drive-pride','drive-longing'])) return 'aroused';
  return 'other';
}
function ImageStudio_세부묶음사용하기() { return api.settings.get().groupSimilarDetailStates !== false; }
function ImageStudio_실제세부코드읽기(state, character, id) {
  const stats = id === state.primaryCharacterId ? effectiveHeroineStats(state) : character.stats || {};
  const codes = ['energy-' + band(stats.energy ?? 100), 'mood-' + band(stats.mood ?? 50), 'arousal-' + band(stats.arousal ?? 0)];
  if(id===state.primaryCharacterId){
    const relationship=relationshipPanelStatus(state);
    codes.push('wellbeing-'+band(100-(Number(wellbeingSignals(state)?.total)||0)));
    if(Number(relationship.trust)<30)codes.push('trust-low');
    if(Number(relationship.desire)>=60)codes.push('desire-high');
    if(Number(relationship.resentment)>=60)codes.push('resentment-high');
    else if(Number(relationship.resentment)>=35)codes.push('resentment-medium');
    if(Number(relationship.drift?.raw)>=35)codes.push('drift-high');
    if(Number(relationship.latitude?.raw)<0)codes.push('latitude-negative');
    const drive=Object.entries(heroineDriveCalc(state)||{}).sort((a,b)=>Number(b[1])-Number(a[1]))[0];
    if(drive&&Number(drive[1])>35)codes.push('drive-'+drive[0]);
  }
  if(Number(allureScore(character))>=60)codes.push('allure-high');
  const intoxication = intoxicationBand(character.intoxication?.level || 0);
  if (intoxication !== 'sober') codes.push('intoxication-' + intoxication);
  codes.push(...topFeelings(character,2).filter(feeling=>Number(feeling.intensity)>15).map(feeling=>'feeling-'+feeling.emotion));
  if(topFeelings(character,2).some(feeling=>Number(feeling.intensity)>=80&&/^(anger|contempt|disgust|sadness|shame|guilt|regret|humiliation|fear)$/.test(feeling.emotion)))codes.push('expression-distressed');
  return codes;
}
function ImageStudio_상황코드읽기(groups) {
  return [...new Set(groups.filter(group=>!['character','outfit','composition'].includes(group.id)).flatMap(group => {
    const codes = group.value?.codes || [];
    return group.id === 'detail' && ImageStudio_세부묶음사용하기()
      ? ['state-' + ImageStudio_시각상태읽기(codes)] : codes.map(code => group.id + '-' + code);
  }))].filter(code=>!['state-other','equipment-breast-jewelry-0','equipment-toy-none'].includes(code)
    &&!/^body-.+-(?:mouth|breasts|uterus|vulva|thighs)-0$/.test(code)).sort();
}
function ImageStudio_의미키만들기(key, groups) {
  const parts = String(key).split('__').filter(part => !/^(?:state|dialogue|character-reuse|character-regenerate|studio|aip)-/.test(part));
  const variant = parts.find(part => /^v-\d+$/.test(part));
  const base = parts.filter(part => !/^v-\d+$/.test(part));
  const codes = ImageStudio_상황코드읽기(groups);
  if (codes.length) base.push('aip-' + codes.map(code => code.replace(/[^a-zA-Z0-9_.:-]/g, '-')).join('_'));
  if (variant) base.push(variant);
  return base.join('__');
}
promptContext = function ImageStudio_프롬프트맥락갱신하기(state, character, characterId, key) {
  host.semanticCharacter = character;
  const context = ImageStudio_이전프롬프트맥락읽기(state, character, characterId, key);
  for(const field of ['positiveGroups','negativeGroups'])context[field]=context[field].map(group=>group.id?group:{...group,id:'detail'});
  if (!host.planning && state && character && !isResidueImageKey(key)) {
    const detail = context.positiveGroups.find(group=>group.id==='detail');
    const codes = ImageStudio_실제세부코드읽기(state,character,characterId);
    if (detail) detail.value = {...detail.value,codes:[...new Set([...detail.value.codes,...codes])]};
    else context.positiveGroups.push({id:'detail',label:'상세 상태',value:{codes,tags:[]}});
    const fake=Object.fromEntries(BAD_GUEST_FIELDS.map(field=>[field.key,'semantic-state']));
    const badguest=ImageStudio_나쁜손님프롬프트읽기(state,character,characterId,fake);
    if(badguest)context.positiveGroups.push({id:'badguest',label:'나쁜 손님 상태',value:{codes:badguest.codes,tags:[]}});
    const fluid=character.situationStats?.fluidState;
    if(fluid)for(const {part} of FLUID_PARTS){
      if(!partIsExposed('fluid.'+part+'.1',outfitIdFor(character,key),key,character))continue;
      const tier=part==='vulva'?vulvaTier(character,heroineDriveCalc(state)):fluidTier(part,fluid[part]);
      if(tier>0)context.positiveGroups.push({id:'body-'+part,label:'부위별 상태',value:{codes:[part+'-'+tier],tags:[]}});
    }
  }
  const jewelry = character?.situationStats?.jewelryState;
  host.matchingContextSnapshot={state,character,key,groups:[...context.positiveGroups,...context.negativeGroups]};
  if (!jewelry || isResidueImageKey(key)) return context;
  const stage = Number(jewelry.breasts?.stage) || 0, vibe = jewelry.vibe;
  const activeToy = vibe && !vibe.suspension && ['egg','penis'].includes(vibe.type) ? vibe.type : '';
  const settings = api.settings.get().equipmentPrompts || {};
  const codes = ['breast-jewelry-' + stage, 'toy-' + (activeToy || 'none')];
  if(Number(jewelry.vulva?.stage)>0)codes.push('vulva-jewelry-'+Number(jewelry.vulva.stage));
  const positive = activeToy ? settings[activeToy]?.positivePrompt ?? (activeToy === 'egg'
    ? 'egg vibrator, vibrator cord' : 'inserted dildo vibrator') : '';
  const negative = [stage === 3 ? '' : 'choker, heart-shaped choker', activeToy ? '' : 'vibrator, dildo',
    activeToy ? settings[activeToy]?.negativePrompt || '' : ''].filter(Boolean).join(', ');
  context.positiveGroups.push({ id: 'equipment', label: '현재 장비', value: { codes, tags: positive ? [positive] : [] } });
  context.negativeGroups.push({ id: 'equipment', label: '현재 장비', value: { codes, tags: negative ? [negative] : [] } });
  host.matchingContextSnapshot={state,character,key,groups:[...context.positiveGroups,...context.negativeGroups]};
  return context;
};
keyWithState = function ImageStudio_상태키만들기(key, signature, ...args) {
  const state = api.store.game();
  const character = host.semanticCharacter || host.planning?.state?.characters?.[host.planning.state.primaryCharacterId] || state?.characters?.[state.primaryCharacterId];
  if (!character || isResidueImageKey(key)) return key;
  const id = characterIdOf(state, character) || character.id || state.primaryCharacterId;
  const legacyAxis=ImageStudio_이전기본축키만들기(key);
  const legacyContext=ImageStudio_이전프롬프트맥락읽기(state,character,id,legacyAxis);
  const context = promptContext(state, character, id, key);
  const next = ImageStudio_의미키만들기(key, [...context.positiveGroups, ...context.negativeGroups]);
  const jewelry=character.situationStats?.jewelryState;
  const equipped=Number(jewelry?.breasts?.stage)>0||Number(jewelry?.vulva?.stage)>0||(jewelry?.vibe?.type&&!jewelry.vibe.suspension);
  if(!equipped&&(legacyContext.positiveGroups.length||legacyContext.negativeGroups.length)){
    const legacy=ImageStudio_이전상태키만들기(legacyAxis,combinedStateSignature(legacyContext.positiveGroups,legacyContext.negativeGroups),
      legacyContext.dialogue,legacyContext.characterPolicy,legacyContext.situational);
    ImageStudio_이전키연결하기(legacy,next);
  }
  return next;
};
// 장소·장면 문구 수정은 생성 해시로 관리하며 studio 문구 해시는 상황 키에서 제외합니다.
ImageStudio_기본축키적용하기 = key => String(key).split('__').filter(part => !part.startsWith('studio-')).join('__');

function ImageStudio_장비표정보정하기(result, character) {
  if (host.modern && !host.planning) return result;
  if (!result?.parts || !character || isResidueImageKey(result.key)) return result;
  const jewelry = character.situationStats?.jewelryState;
  const severe = topFeelings(character, 2).some(feeling => Number(feeling.intensity) >= 80
    && /^(anger|contempt|disgust|sadness|shame|guilt|regret|humiliation|fear)$/.test(feeling.emotion));
  const context = promptContext(api.store.game(), character, character.id, result.key);
  const detail = context.positiveGroups.filter(group => group.id === 'detail').flatMap(group => group.value.codes);
  const distressed = severe || ['exhausted','unconscious','distressed'].includes(ImageStudio_시각상태읽기(detail));
  const cheerful = new Set(['smile','gentle smile','bright smile','playful smile','content','cheerful','energetic','pleasure']);
  const parts = result.parts.map(part => ({ ...part, tags: promptTokens(part.tags).filter(tag => {
    const identity = promptTagIdentity(tag).spaced;
    if (distressed && ['장면','Scene','작업','Task','기분','Mood'].includes(part.label) && cheerful.has(identity)) return false;
    if (jewelry && Number(jewelry.breasts?.stage) !== 3 && /\bchoker\b/.test(identity)) return false;
    if (jewelry && [0,3].includes(Number(jewelry.breasts?.stage)||0) && /\bnipple (piercings?|rings?|jewelry)\b/.test(identity)) return false;
    if (jewelry && (!jewelry.vibe || jewelry.vibe.suspension) && /\b(vibrator|dildo)\b/.test(identity)) return false;
    return true;
  }).join(', ') }));
  const retained = new Set(parts.flatMap(part=>promptTokens(part.tags)).map(tag=>promptTagIdentity(tag).spaced));
  const removed = result.parts.flatMap(part=>promptTokens(part.tags)).filter(tag=>!retained.has(promptTagIdentity(tag).spaced));
  const prompt = withoutPromptTags(result.prompt,removed.join(', '));
  const stage=Number(jewelry?.breasts?.stage)||0, activeToy=jewelry?.vibe&&!jewelry.vibe.suspension&&['egg','penis'].includes(jewelry.vibe.type);
  const negativePrompt=joinPrompt(promptTokens(result.negativePrompt).filter(tag=>{
    const identity=promptTagIdentity(tag).spaced;
    if(stage===3&&['choker','heart-shaped choker'].includes(identity))return false;
    if([1,2].includes(stage)&&['piercing','nipple piercings','nipple rings'].includes(identity))return false;
    if(activeToy&&['vibrator','dildo'].includes(identity))return false;
    return true;
  }).join(', '));
  return { ...result, prompt, negativePrompt, parts, genParams: promptGenParams(prompt) };
}
baseApi.use('imagestudio').extensions.registerPromptProvider({ id: 'attention-equipment-expression', priority: 1000,
  compose(result, context) { return ImageStudio_장비표정보정하기(result, ImageStudio_현재인물읽기(context.character)); }
});
// H_Status 등이 공통 조립 뒤에 붙이는 장비 태그도 최종 출력에서 같은 기준으로 정리합니다.
baseApi.hook('imagePrompt',{priority:-3000000,after(result,[character]){
  return ImageStudio_장비표정보정하기(result,ImageStudio_현재인물읽기(character));
}});
// 구형 H_Status는 WML 디스패처 바깥에서 상태 태그를 덧붙입니다.
// 그 기존 함수를 그대로 이어 호출한 뒤 최종 결과만 정리하여 게임 로직과 훅을 보존합니다.
const ImageStudio_기존초상화프롬프트=baseApi.fn('imagePrompt');
baseApi.engine[baseApi.sym('imagePrompt')]=function ImageStudio_최종초상화프롬프트(...args){
  args[0]=ImageStudio_현재인물읽기(args[0]);
  return ImageStudio_장비표정보정하기(ImageStudio_기존초상화프롬프트(...args),args[0]);
};
function ImageStudio_매칭상태묶기(context) {
  if (!context || !ImageStudio_세부묶음사용하기()) return context;
  if(!Array.isArray(context.detail)&&!Array.isArray(context.emotions))return context;
  const detailCodes = context.detail || [];
  const generic = detailCodes.filter(code => /^(expression|energy|mood|arousal|wellbeing|intoxication|trust|desire|resentment|drift|latitude|feeling|drive|allure)-/.test(code));
  if(!generic.length&&detailCodes.some(code=>code.startsWith('visual-'))&&!(context.emotions||[]).length)return context;
  const bucket=ImageStudio_시각상태읽기([...generic,...(context.emotions||[]).map(value=>'feeling-'+value)]);
  return { ...context, rawEmotions:context.emotions, emotions:[],detail: [...detailCodes.filter(code => !generic.includes(code)&&!code.startsWith('visual-')), 'visual-' + bucket].sort() };
}
host.matchingContext = function ImageStudio_의미매칭맥락읽기(key, character) {
  return ImageStudio_매칭상태묶기(ImageStudio_이전매칭맥락읽기(key,character));
};

// 사람별 자세는 기존 프리셋 문구를 공통 원본으로 참조합니다. 문구 사본을 별도로 저장하지 않습니다.
const ImageStudio_기본사람자세 = ['none','standing','sitting','kneeling','lying-back','all-fours'];
const ImageStudio_사람위치목록 = { front: '앞', back: '뒤', left: '왼쪽', right: '오른쪽', above: '위', below: '아래' };
const ImageStudio_사람행동목록 = { watch: '관전', touch: '손으로 자극', kiss: '키스', oral: '구강', sex: '삽입' };
const ImageStudio_사람부위목록 = { body: '몸', mouth: '입', breasts: '가슴', vulva: '보지', anus: '항문', hands: '손' };
let ImageStudio_기본자세편집중 = false;
function ImageStudio_사람설정읽기() {
  const saved = api.settings.get().personDetails || {};
  const person = value => ({ pose: ImageStudio_기본사람자세.includes(value?.pose) ? value.pose : 'standing',
    location: Object.hasOwn(ImageStudio_사람위치목록, value?.location) ? value.location : 'front',
    action: Object.hasOwn(ImageStudio_사람행동목록, value?.action) ? value.action : 'watch',
    target: Object.hasOwn(ImageStudio_사람부위목록, value?.target) ? value.target : 'body' });
  return { enabled: saved.enabled === true, female: saved.female!=='none'&&ImageStudio_기본사람자세.includes(saved.female) ? saved.female : 'standing',
    men: Array.from({length: Math.max(1,Math.min(6,Number(saved.men?.length)||1))},(_,index)=>person(saved.men?.[index])) };
}
function ImageStudio_사람자세프롬프트읽기(id, male = false) {
  const prompt = positionPresetById(id)?.prompt || '';
  return male ? prompt.replace(/\b(woman|girl|female)\b/gi, 'man') : prompt;
}
function ImageStudio_사람프롬프트읽기(details) {
  const negative = [positionPresetById(details.female)?.negativePrompt || ''];
  const tags = ['woman: ' + ImageStudio_사람자세프롬프트읽기(details.female)];
  for (const [index, man] of details.men.entries()) {
    tags.push(`man ${index+1}: ${ImageStudio_사람자세프롬프트읽기(man.pose,true)}, ${man.location} of woman, ${man.action}, target ${man.target}`);
    negative.push(positionPresetById(man.pose)?.negativePrompt || '');
  }
  return { prompt: joinPrompt(tags.join(', ')), negativePrompt: joinPrompt(negative.join(', ')) };
}
selectedPositionChoice = function ImageStudio_선택사람자세읽기() {
  const choice = ImageStudio_이전선택자세읽기(), details = ImageStudio_사람설정읽기();
  if (ImageStudio_기본자세편집중 || !details.enabled || !latestScenePrompt) return choice;
  const selected = positionSelection.presetId;
  if (selected !== 'none' && ImageStudio_기본사람자세.includes(selected)) details.female = selected;
  const prompts = ImageStudio_사람프롬프트읽기(details);
  return { presetId: details.female, preset: { ...positionPresetById(details.female), id: details.female, name: '사람별 세부 조정', ...prompts },
    groupSlots: selectedPositionGroupSlots(), personDetails: details };
};
positionChoiceForImageKey=function ImageStudio_계획사람자세읽기(key){
  const choice=ImageStudio_이전계획자세읽기(key),details=ImageStudio_사람설정읽기();
  const explicit=host.planning?.combination?.promptPosition;
  if(!host.planning||!details.enabled||!explicit||explicit==='none'||!ImageStudio_기본사람자세.includes(explicit))return choice;
  details.female=explicit;
  return {presetId:explicit,preset:{...positionPresetById(explicit),...ImageStudio_사람프롬프트읽기(details)},personDetails:details,groupSlots:choice?.groupSlots||''};
};
keyWithPosition = function ImageStudio_자세의미키만들기(key, choice) {
  if (!choice?.preset || choice.preset.id === 'none') return stripPositionKey(key);
  const clean = stripPositionKey(key), variant = clean.match(/__v-\d+$/)?.[0] || '';
  const root = variant ? clean.slice(0,-variant.length) : clean;
  const details = choice.personDetails;
  const signature = details ? '-people-' + shortHash(JSON.stringify({female:details.female,men:details.men})) : '';
  const slots = choice.groupSlots ? '-slots-' + choice.groupSlots : '';
  const next = root + '__position-' + choice.preset.id + slots + signature + variant;
  ImageStudio_이전키연결하기(ImageStudio_이전자세키만들기(key,choice),next);
  return next;
};
applyPositionPreset = function ImageStudio_사람자세적용하기(result, choice) {
  const applied=ImageStudio_이전자세적용하기(result,choice);
  if (!choice?.personDetails || !applied?.parts) return applied;
  const removed=applied.parts.filter(part=>['성별','Gender','그룹','Group'].includes(part.label));
  const kept=applied.parts.filter(part=>!removed.includes(part));
  const count=choice.personDetails.men.length;
  const gender='1girl, '+(count===1?'1boy':count+'boys');
  const prompt=joinPrompt(withoutPromptTags(applied.prompt,removed.map(part=>part.tags).join(', '))+', '+gender);
  return {...applied,prompt,parts:[...kept,{label:'성별',tags:gender}],genParams:promptGenParams(prompt)};
};
function ImageStudio_사람설정그리기(h, win) {
  const details = ImageStudio_사람설정읽기();
  if (details.enabled && positionSelection.presetId !== 'none' && ImageStudio_기본사람자세.includes(positionSelection.presetId)) details.female = positionSelection.presetId;
  const save = () => { api.settings.set({personDetails:details});win.refresh(); };
  const select = (label, options, value, update, marker) => h('label',{style:'display:grid;gap:4px;min-width:0'},label,
    h('select',{'data-person-field':marker,style:'max-width:100%;background:#292524;color:#eee;padding:6px',onchange:event=>{update(event.currentTarget.value);save();}},
      ...Object.entries(options).map(([id,name])=>h('option',{value:id,selected:id===value},name))));
  const poses = Object.fromEntries(ImageStudio_기본사람자세.filter(id=>POSITION_PRESETS[id]).map(id=>[id,POSITION_PRESETS[id].name]));
  return h('section',{'data-person-details':'',style:'border:1px solid #57534e;padding:10px;margin:10px 0;border-radius:7px'},
    h('h3',{},'사람별 자세·위치·행동'),
    h('label',{},h('input',{type:'checkbox',checked:details.enabled,'data-person-enabled':'',onchange:event=>{details.enabled=event.currentTarget.checked;save();}}),' 수동 생성에 사람별 설정 사용'),
    h('p',{class:'wml-muted'},'아래 기본 자세 프롬프트 편집과 같은 Positive/Negative를 사용합니다. 수정하면 양쪽 미리보기에 반영됩니다.'),
    select('여성 자세',Object.fromEntries(Object.entries(poses).filter(([id])=>id!=='none')),details.female,value=>{details.female=value;positionSelection={...positionSelection,situationId:latestScenePrompt?.situationId||'',presetId:value};},'female'),
    select('남성 수',Object.fromEntries([1,2,3,4,5,6].map(count=>[count,count+'명'])),String(details.men.length),value=>{
      const previous=details.men;details.men=Array.from({length:Number(value)},(_,index)=>previous[index]||{pose:'standing',location:'front',action:'watch',target:'body'});
    },'count'),
    ...details.men.map((man,index)=>h('fieldset',{style:'display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin:10px 0'},h('legend',{},'남성 '+(index+1)),
      select('자세',poses,man.pose,value=>{man.pose=value;},'man-'+index+'-pose'),
      select('여성 기준 위치',ImageStudio_사람위치목록,man.location,value=>{man.location=value;},'man-'+index+'-location'),
      select('행동',ImageStudio_사람행동목록,man.action,value=>{man.action=value;},'man-'+index+'-action'),
      select('대상 부위',ImageStudio_사람부위목록,man.target,value=>{man.target=value;},'man-'+index+'-target'))),
    h('pre',{'data-person-preview':'',style:'white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px'},
      'Positive: '+ImageStudio_사람프롬프트읽기(details).prompt+'\nNegative: '+ImageStudio_사람프롬프트읽기(details).negativePrompt));
}
renderPositionSettings = function ImageStudio_사람별설정그리기(h,win) {
  // 기존 입력칸은 합성된 사람별 문구가 아닌 기본 자세 원문만 편집합니다.
  ImageStudio_기본자세편집중=true;
  let original;
  try { original=ImageStudio_이전자세설정그리기(h,win); } finally { ImageStudio_기본자세편집중=false; }
  return [ImageStudio_사람설정그리기(h,win),...original];
};

// 부위별 img2img는 기존 공통 검수 경로를 이용합니다. 참조 누락을 일반 생성으로 조용히 바꾸지 않습니다.
function ImageStudio_부위생성설정읽기() { return api.settings.get().hStatusGenerationModes || {}; }
function ImageStudio_부위키읽기(key) {
  if (!isResidueImageKey(key)) return '';
  if (key.startsWith('situation_vulva__')) return 'vulva';
  return FLUID_PARTS.find(({part})=>new RegExp('(?:__|_)'+part+'(?:__|_|$)').test(key))?.part || '';
}
host.prepareGeneration = async function ImageStudio_참조생성요청만들기(request) {
  const part = ImageStudio_부위키읽기(request.imageKey || request.key || '');
  const options = ImageStudio_부위생성설정읽기()[part];
  if (!part || options?.mode !== 'img2img') return request;
  let referenceKey=options.referenceKey?.trim()||request.referenceKey;
  if (!referenceKey) {
    const key=residueBaseImageKey(request.imageKey||request.key);
    const pieces=key.split('__');
    if (!['elena','mara','pippa'].includes(pieces[1])) {
      const context=currentWifePromptContext();
      const source=String(context.archetype?.basedOn||context.character?.generatedArchetype?.basedOn||context.character?.archetypeId||'');
      pieces[1]=['elena','mara','pippa'].includes(request.referenceSource)?request.referenceSource:source.match(/(?:^|_)(elena|mara|pippa)(?:_|$)/)?.[1]||'pippa';
    }
    referenceKey=pieces.join('__');
  }
  const reference=await baseApi.fn('imageLookup')(referenceKey,{nearest:false});
  if (!reference || reference.talentName!==referenceKey) throw Error('정확한 H_Status 기준 이미지를 찾지 못했습니다: '+referenceKey);
  return { ...request, referenceKey, referencePath:reference.imagePath,denoise: options.denoise ?? (part==='breasts'?0.4:0.28) };
};
function ImageStudio_업데이트설정그리기(body,win) {
  const panel=api.ui.h('details',{'data-attention-upgrades':'',style:'margin:10px 0;padding:10px;border:1px solid #57534e'},
    api.ui.h('summary',{},'상태 묶기 · 장비 프롬프트 · H_Status 부위별 img2img'));
  panel.append(api.ui.h('label',{},api.ui.h('input',{type:'checkbox',checked:ImageStudio_세부묶음사용하기(),'data-state-grouping':'',onchange:event=>{
    api.settings.set({groupSimilarDetailStates:event.currentTarget.checked});win.refresh();
  }}),' 비슷한 상세 상태를 대표 이미지로 묶기'));
  for(const type of ['egg','penis'])for(const field of ['positivePrompt','negativePrompt']) panel.append(api.ui.h('label',{style:'display:grid;margin:8px 0'},
    (type==='egg'?'에그 토이':'자지형 토이')+' '+field,
    api.ui.h('textarea',{'data-equipment-prompt':type+':'+field,value:api.settings.get().equipmentPrompts?.[type]?.[field] ?? (field==='positivePrompt'?(type==='egg'?'egg vibrator, vibrator cord':'inserted dildo vibrator'):''),
      onchange:event=>{const settings=api.settings.get().equipmentPrompts||{};api.settings.set({equipmentPrompts:{...settings,[type]:{...settings[type],[field]:event.currentTarget.value}}});}})));
  const modes=ImageStudio_부위생성설정읽기();
  for(const {part,label} of FLUID_PARTS){
    const options={mode:'text2img',referenceKey:'',denoise:part==='breasts'?0.4:0.28,...modes[part]};
    const save=()=>api.settings.set({hStatusGenerationModes:{...ImageStudio_부위생성설정읽기(),[part]:options}});
    panel.append(api.ui.h('fieldset',{style:'display:grid;gap:5px;margin:10px 0'},api.ui.h('legend',{},label),
      api.ui.h('select',{'data-hstatus-generation-mode':part,onchange:event=>{options.mode=event.currentTarget.value;save();}},
        ...['text2img','img2img'].map(mode=>api.ui.h('option',{value:mode,selected:options.mode===mode},mode))),
      api.ui.h('input',{'data-hstatus-reference':part,type:'text',value:options.referenceKey,placeholder:'비우면 원작의 같은 부위·상태 이미지 자동 참조',onchange:event=>{options.referenceKey=event.currentTarget.value;save();}}),
      api.ui.h('input',{'data-hstatus-denoise':part,type:'number',min:0.01,max:1,step:0.01,value:options.denoise,onchange:event=>{
        const value=Number(event.currentTarget.value);if(!Number.isFinite(value)||value<=0||value>1)throw Error('노이즈 강도는 0 초과 1 이하입니다.');options.denoise=value;save();
      }})));
  }
  body.prepend(panel);
}
const ImageStudio_업데이트이전편집그리기=host.renderSettings;
api.ui.settings((body,win)=>{ImageStudio_업데이트이전편집그리기(body,win);if (!host.modern) ImageStudio_업데이트설정그리기(body,win);});

// 새 설정도 기존 전체/탭 JSON과 함께 보존합니다. 구버전 기본 문구를 자동 치환하지 않습니다.
const ImageStudio_업데이트설정키=['groupSimilarDetailStates','equipmentPrompts','personDetails','hStatusGenerationModes','legacySituationKeys'];
const ImageStudio_이전탭JSON섹션읽기=ImageStudio_JSON탭섹션읽기;
ImageStudio_JSON탭섹션읽기=function ImageStudio_업데이트탭JSON섹션읽기(tab){
  const sections=ImageStudio_이전탭JSON섹션읽기(tab);
  return tab.id==='positions'?[...sections,'personDetails']:tab.id==='h-status'?[...sections,'equipmentPrompts','hStatusGenerationModes']:sections;
};
ImageStudio_JSON전체읽기=function ImageStudio_업데이트JSON읽기(){
  const settings=api.settings.get();return {...ImageStudio_이전전체JSON읽기(),version:18,...Object.fromEntries(ImageStudio_업데이트설정키.filter(key=>settings[key]!==undefined).map(key=>[key,settings[key]]))};
};
ImageStudio_JSON불러온뒤갱신하기=function ImageStudio_업데이트JSON갱신하기(...args){
  ImageStudio_이전키별칭.clear();
  for(const [key,value] of Object.entries(api.settings.get().legacySituationKeys||{}))ImageStudio_이전키별칭.set(key,value);
  return ImageStudio_이전JSON갱신하기(...args);
};
importPromptSettings=function ImageStudio_업데이트JSON불러오기(text){
  const parsed=JSON.parse(text);
  if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))throw Error('JSON 설정 객체가 필요합니다.');
  if(parsed.groupSimilarDetailStates!==undefined&&typeof parsed.groupSimilarDetailStates!=='boolean')throw Error('상태 묶기 설정은 true/false여야 합니다.');
  for(const section of ['equipmentPrompts','personDetails','hStatusGenerationModes','legacySituationKeys']){
    if(parsed[section]!==undefined&&(!parsed[section]||typeof parsed[section]!=='object'||Array.isArray(parsed[section])))throw Error('설정 객체가 올바르지 않습니다: '+section);
  }
  for(const [type,settings] of Object.entries(parsed.equipmentPrompts||{})){
    if(!['egg','penis'].includes(type)||!settings||typeof settings!=='object'||Array.isArray(settings)
      ||Object.entries(settings).some(([field,value])=>!['positivePrompt','negativePrompt'].includes(field)||typeof value!=='string'))throw Error('토이 프롬프트 설정이 올바르지 않습니다.');
  }
  if(Object.values(parsed.legacySituationKeys||{}).some(value=>typeof value!=='string'))throw Error('이전 이미지 키 별칭이 올바르지 않습니다.');
  if(parsed.personDetails){
    const value=parsed.personDetails;
    if(typeof value.enabled!=='boolean'||!ImageStudio_기본사람자세.includes(value.female)||!Array.isArray(value.men)||value.men.length<1||value.men.length>6
      ||value.men.some(man=>!ImageStudio_기본사람자세.includes(man?.pose)||!Object.hasOwn(ImageStudio_사람위치목록,man?.location)
        ||!Object.hasOwn(ImageStudio_사람행동목록,man?.action)||!Object.hasOwn(ImageStudio_사람부위목록,man?.target)))throw Error('사람별 자세 설정이 올바르지 않습니다.');
  }
  for(const [part,options] of Object.entries(parsed.hStatusGenerationModes||{})){
    if(!FLUID_PARTS.some(value=>value.part===part)||!['text2img','img2img'].includes(options?.mode)
      ||(options.referenceKey!==undefined&&typeof options.referenceKey!=='string')
      ||(options.denoise!==undefined&&(!Number.isFinite(options.denoise)||options.denoise<=0||options.denoise>1)))throw Error('부위별 생성 설정이 올바르지 않습니다: '+part);
  }
  const hasLegacy=Object.keys(parsed).some(key=>!ImageStudio_업데이트설정키.includes(key)&&!['format','version','scope','tabId'].includes(key));
  const base=hasLegacy?ImageStudio_이전JSON불러오기(text):{};
  return {...base,...Object.fromEntries(ImageStudio_업데이트설정키.filter(key=>parsed[key]!==undefined).map(key=>[key,parsed[key]]))};
};
host.upgrades={semanticKey:ImageStudio_의미키만들기,bucket:ImageStudio_시각상태읽기,correct:ImageStudio_장비표정보정하기,normalizeMatchingContext:ImageStudio_매칭상태묶기,
  personPrompts:ImageStudio_사람프롬프트읽기,prepare:host.prepareGeneration,exportSettings:ImageStudio_JSON전체읽기,importSettings:importPromptSettings};

}

// AIP 1.77 UI uses the original instance and storage. Legacy-only axes remain in this adapter.
function ImageStudio_Aip설정연결하기(aip) {
  const key = 'wml.mod.attention-image-prompt';
  const legacyKey = 'wml.mod.imagestudio-compatible-attention-image-prompt';
  const read = text => { const value = JSON.parse(text || '{}'); if (!value || Array.isArray(value) || typeof value !== 'object') throw Error('프롬프트 설정 객체가 올바르지 않습니다.'); return value; };
  const existing = read(localStorage.getItem(key));
  if (existing.imageStudioMigration177?.complete) return;
  const oldText = localStorage.getItem(legacyKey), legacy = read(oldText);
  const merge = (fallback, preferred) => {
    if (Array.isArray(preferred)) {
      if (preferred.length && preferred.every(row => row && typeof row.id === 'string') && Array.isArray(fallback)) {
        const rows = new Map(fallback.filter(row => row?.id).map(row => [row.id, row]));
        for (const row of preferred) rows.set(row.id, merge(rows.get(row.id), row));
        return [...rows.values()];
      }
      return preferred;
    }
    if (!preferred || typeof preferred !== 'object') return preferred;
    const result = fallback && typeof fallback === 'object' && !Array.isArray(fallback) ? { ...fallback } : {};
    for (const [id, value] of Object.entries(preferred)) {
      if (['__proto__', 'constructor', 'prototype', 'migration'].includes(id)) continue;
      result[id] = merge(result[id], value);
    }
    return result;
  };
  const backupKey = legacyKey + '.before-aip-1770';
  if (localStorage.getItem(backupKey) === null) localStorage.setItem(backupKey, JSON.stringify({
    attention: aip.editor.initialSettings, commonEditor: oldText,
  }));
  const settings = merge(existing, legacy);
  settings.imageStudioMigration177 = { complete: true, version: 1, backupKey };
  localStorage.setItem(key, JSON.stringify(settings));
  aip.editor.reload();
}

function ImageStudio_Aip편집기그리기(api, aip, host, body, win) {
  const h = api.ui.h;
  const style = h('style', {}, `
    [data-wwis-aip-editor] [data-aip-settings] .aip-outfit-layout { grid-template-columns:minmax(0,1fr); }
    [data-wwis-aip-editor] [data-aip-settings] .aip-outfit-preview { position:static; }
    [data-wwis-aip-editor] [data-aip-settings] .aip-outfit-editor textarea {
      width:100%; max-width:100%; min-width:0; box-sizing:border-box;
      min-height:160px!important; resize:vertical;
    }
  `);
  const modern = h('div', { 'data-wwis-aip-editor': aip.editor.modVersion });
  const extra = h('div', { 'data-wwis-legacy-axes': '' });
  const details = h('details', { 'data-wwis-additional-prompts': '', open: host.additionalOpen === true },
    h('summary', {}, 'ImageStudio 추가 조건 · 장소 / 기분 / 인원 / 노출 / 모드 상태'), extra);
  const modernWin = { ...win, refresh: () => { aip.editor.render(modern, modernWin); } };
  const legacyWin = { ...win, refresh: () => host.renderLegacyExtras(extra, legacyWin) };
  body.replaceChildren(style, modern, details);
  aip.editor.render(modern, modernWin);
  details.addEventListener('toggle', () => { host.additionalOpen = details.open; if (details.open && !extra.childNodes.length) legacyWin.refresh(); });
  if (details.open) legacyWin.refresh();
}

// 호환성 패치 기준: imagestudio 1.31.7 (개정 기준, 버전 번호에 따른 실행 제한 없음)

Object.assign(globalThis,{ImageStudio_상황프롬프트Api만들기,ImageStudio_체위호환연결하기,ImageStudio_상황프롬프트설치하기});

    const bridge = api.use('imagestudio').bridge;
    const extensions = bridge.extensions;
    const aip = api.use('attention-image-prompt');
    if (!aip?.editor?.render || !aip.editor.capabilities?.tabJson || !aip.editor.capabilities?.studioSelection)
      throw Error('탭별 JSON·이미지 선택 위임이 포함된 attention-image-prompt 1.79.0 이상을 함께 설치하고 게임을 새로고침하세요.');
    ImageStudio_Aip설정연결하기(aip);
    const host = {
      modern: aip.editor,
      external: globalThis.WML.status().loaded.includes('attention-image-prompt'),
      open: () => extensions.review.open(),
      generate: request => extensions.review.generate(request),
      renderSettings: null,
    };
    ImageStudio_상황프롬프트설치하기(api, host);
    host.connectModern();
    aip.editor.connect({ generate: request => extensions.review.generate(request) });
    const editor = {
      upgrades: host.upgrades,
      id: api.id, embeddedVersion: aip.editor.modVersion,
      render: (body, win) => ImageStudio_Aip편집기그리기(api, aip, host, body, win),
      axes: () => host.axes(), combinations: value => host.combinations(value),
      combinationSpace: value => host.combinationSpace(value),
      plan: (build, combination, archetypeId) => host.plan(build, combination, archetypeId),
      positionApplicable: (id, imageKey) => host.positionApplicable(id, imageKey),
      matchingContext: (imageKey, character) => host.matchingContext(imageKey, character),
      nativeAxisPrompt: (axis, id) => host.nativeAxisPrompt(axis,id),
      planningContext: () => host.planning ? {
        state: host.planning.state,
        character: host.planning.state?.characters?.[host.planning.state.primaryCharacterId],
      } : null,
    };
    extensions.registerEditor(editor);
    api.provide(editor);
    api.ui.settings((body, win) => editor.render(body, win));
    // 공통 편집기는 ImageStudio의 프롬프트 편집 버튼에서 엽니다.
  },
});
