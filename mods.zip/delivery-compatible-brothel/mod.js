// 호환성 패치 기준: delivery 5.3.2 / brothel 3.10.0 (개정 기준, 버전 번호에 따른 실행 제한 없음)
WML.define({
  tags: ["content"],
  id:'delivery-compatible-brothel',
  author: "Hina_Lover",
  name:"배달의 민족 - 창관 호환 패치",
  version: "1.0.6",game:"2026-11-01",requires:['delivery','brothel'],
  description:"창부가 배달을 할 수 있게 됩니다. 출장 배정, 서비스 요금·급료 기록과 정상 귀환 정산을 연결합니다.",
  symbols:{
    "DeliveryGameShell": {"raw":{"2026-11-01":"Iit"}},
    "DeliveryLocationPanel": {"raw":{"2026-11-01":"hat"}},
    "DeliveryDayEnd": {"raw":{"2026-11-01":"xm"},"doc":"Defers tavern closing while delegated delivery service is unfinished."}
  },
  setup(api){
    const brothel=globalThis.__waywardBrothelPublic,delivery=globalThis.__waywardDeliveryAddon;
    if(!brothel?.assign||!brothel?.service||!delivery)throw Error('Brothel 3.6.0과 Delivery 5.3.0을 함께 설치하세요.');
    const OWNER=api.id,SITE='delivery_site',React=api.fn('React'),JSX=api.fn('jsx');
    function DeliveryBrothel_세션읽기(state){const session=state?.deliveryAddon?.activeDelivery;return session?.who==='brothel'?session:null}
    function DeliveryBrothel_불가이유읽기(state,id){
      if(!state?.deliveryAddon?.pendingOffer)return'배달 주문이 없습니다.';
      if(state.deliveryAddon.activeDelivery||state.errandSession)return'다른 배달이나 외출이 진행 중입니다.';
      if(state.pendingEvent&&state.pendingEvent.alert?.kind!=='delivery:order')return'진행 중인 선택을 먼저 해결하세요.';
      const offer=state.deliveryAddon.pendingOffer,stock={food:state.readyFood,beer:state.supplies?.beer,wine:state.supplies?.wine};
      if(Object.entries(offer.order).some(([key,count])=>(stock[key]??0)<count))return'주문 재고가 부족합니다.';
      return brothel.unavailable(state,id);
    }
    function DeliveryBrothel_출발하기(state,action){
      const reason=DeliveryBrothel_불가이유읽기(state,action.workerId);
      if(reason)return api.fn('log')(state,`[매춘부 배달] ${reason}`);
      const offer=structuredClone(state.deliveryAddon.pendingOffer),worker=brothel.workers(state).find(item=>item.id===action.workerId);
      let next=brothel.assign(state,[worker.id],{owner:OWNER,location:SITE,task:'배달 출장',situation:`${offer.destination}으로 배달 중입니다. 최소 30분 후 귀환합니다.`});
      const weight=delivery.getSettings().hotelSexWeight,stage=weight>0&&Math.random()<Math.min(1,weight/2)?'sex_patron':null;
      const session={id:offer.id,who:'brothel',workerId:worker.id,workerName:worker.name,characterId:worker.id,offer,
        startSlot:state.slot,returnAtSlot:state.slot+30,location:SITE,customerIds:[],serviceStage:stage,serviceDone:false,
        customer:{id:`${offer.id}:brothel-client`,name:offer.requester,boldness:40,walletGold:stage?brothel.fee(state,stage):0}};
      next={...next,readyFood:next.readyFood-offer.order.food,supplies:{...next.supplies,beer:next.supplies.beer-offer.order.beer,wine:next.supplies.wine-offer.order.wine},
        pendingEvent:undefined,alertQueue:(next.alertQueue??[]).filter(alert=>alert.kind!=='delivery:order'),
        deliveryAddon:{...next.deliveryAddon,pendingOffer:undefined,activeDelivery:session,activeDeliveryId:session.id}};
      return api.fn('log')(next,`[매춘부 배달] ${worker.name}을(를) ${offer.destination}으로 보냈습니다. 주문 대금 ${offer.totalPrice}골드 · 왕복 최소 30분. 성적 서비스가 이루어지면 손님이 별도 서비스 요금을 내며 급료·업소 수입을 기록합니다.`);
    }
    function DeliveryBrothel_진행하기(state){
      const original=DeliveryBrothel_세션읽기(state);if(!original)return state;
      let next=state,session=original;
      if(!state.mods?.brothel?.assignments?.[session.workerId]){
        next=brothel.assign(next,[session.workerId],{owner:OWNER,location:SITE,task:'배달 출장',situation:`${session.offer.destination}에서 배달을 진행하고 있습니다.`});
      }
      if(next.pendingEvent)return next;
      if(!session.serviceDone&&next.slot>=session.startSlot+15){
        if(session.serviceStage)next=brothel.service(next,session.workerId,session.customer,session.serviceStage,{owner:OWNER});
        session={...session,serviceDone:true};next={...next,deliveryAddon:{...next.deliveryAddon,activeDelivery:session}};
      }
      if(next.slot<session.returnAtSlot)return next;
      next=brothel.release(next,OWNER);
      if(next.deliveryAddon.lastSettledDeliveryId===session.id)return{...next,deliveryAddon:{...next.deliveryAddon,activeDelivery:undefined,activeDeliveryId:undefined}};
      next=api.fn('waitressIncome')(next,'service',session.offer.itemPrice);
      next=api.fn('waitressIncome')(next,'errands',session.offer.fee);
      const rep=next.tavernReputation;
      next={...next,tavernReputation:{...rep,renown:Math.min(100,(rep.renown??0)+session.offer.renown)},
        deliveryAddon:{...next.deliveryAddon,activeDelivery:undefined,activeDeliveryId:undefined,lastSettledDeliveryId:session.id,lastRollSlot:next.slot,
          lastReceipt:{id:session.id,who:'brothel',workerId:session.workerId,workerName:session.workerName,destination:session.offer.destination,completed:true,
            basePayment:session.offer.totalPrice,totalPayment:session.offer.totalPrice,bonus:null}}};
      return api.fn('log')(next,`[매춘부 배달] ${session.workerName}이(가) 홀로 돌아왔습니다. ${session.offer.destination} 주문 대금 ${session.offer.totalPrice}골드 · 명성 +${session.offer.renown}를 한 번 정산했습니다. 서비스 수입은 별도로 집계됩니다.`);
    }
    api.actions.register('delivery/send-brothel-worker',DeliveryBrothel_출발하기,{label:'매춘부를 보내기'});
    api.hook('worldTick',{priority:-400,around(next,state,...args){return DeliveryBrothel_진행하기(next(DeliveryBrothel_진행하기(state),...args))}});
    api.hook('DeliveryDayEnd',{priority:-400,around(next,state,...args){return DeliveryBrothel_세션읽기(state)?state:next(state,...args)}});
    api.hook('reduceGameAction',{priority:-400,around(next,state,action,...args){
      if(DeliveryBrothel_세션읽기(state)&&['end_day','sleep','go_to_bed_early'].includes(action.type))return api.fn('log')(state,'매춘부가 배달에서 돌아온 뒤 마감하세요.');
      return next(state,action,...args);
    }});
    function DeliveryBrothel_선택그리기(){
      const state=api.fn('store')(root=>root.state),[selected,setSelected]=React.useState(''),workers=brothel.workers(state);
      const inputStyle={backgroundColor:'#000',color:'#fff',colorScheme:'dark',border:'1px solid #78716c',borderRadius:'4px',padding:'5px',maxWidth:'100%'};
      const optionStyle={backgroundColor:'#000',color:'#fff'};
      const id=workers.some(worker=>worker.id===selected)?selected:workers.find(worker=>!brothel.unavailable(state,worker.id))?.id??workers[0]?.id;
      const reason=id?DeliveryBrothel_불가이유읽기(state,id):'고용 중인 매춘부가 없습니다.';
      return JSX.jsxs('div',{'data-delivery-brothel-choice':true,className:'mt-2 p-3 rounded border border-rose-800',children:[
        JSX.jsx('select',{'aria-label':'배달할 매춘부',style:inputStyle,value:id??'',onChange:event=>setSelected(event.target.value),children:workers.map(worker=>JSX.jsx('option',{style:optionStyle,value:worker.id,children:`${worker.name}${brothel.unavailable(state,worker.id)?' · 배정 불가':''}`},worker.id))}),
        JSX.jsx('button',{type:'button','aria-label':'매춘부를 보내기',className:'w-full mt-2 p-2 rounded bg-stone-800',disabled:!!reason,
          onClick:()=>api.store.dispatch({type:'delivery/send-brothel-worker',workerId:id}),children:'매춘부를 보내기'}),
        JSX.jsx('small',{className:'block text-xs text-amber-200',children:reason||'최소 30분 · 주문 대금 지급 · 성적 서비스는 손님에게 별도 요금 청구'})]});
    }
    // Delivery의 주문 컴포넌트를 같은 React 렌더 과정에서 확장합니다.
    function DeliveryBrothel_주문그리기({original,originalProps}){
      const result=original(originalProps);if(!React.isValidElement(result))return result;
      const section=result.props.children;if(!React.isValidElement(section))return result;
      const children=React.Children.toArray(section.props.children);children.splice(Math.max(0,children.findIndex(child=>child.key==='delivery/decline')),0,JSX.jsx(DeliveryBrothel_선택그리기,{},'brothel-choice'));
      return React.cloneElement(result,{},React.cloneElement(section,{},...children));
    }
    function DeliveryBrothel_주문찾기(element){
      if(!React.isValidElement(element))return element;
      if(typeof element.type==='function'&&element.type.name==='Delivery_주문창')return JSX.jsx(DeliveryBrothel_주문그리기,{original:element.type,originalProps:element.props},element.key);
      if(!element.props.children)return element;
      return React.cloneElement(element,{},...React.Children.toArray(element.props.children).map(DeliveryBrothel_주문찾기));
    }
    api.hook('DeliveryGameShell',{priority:-400,after:DeliveryBrothel_주문찾기});
    api.hook('ActionPanel',{priority:-400,after(result){
      const session=DeliveryBrothel_세션읽기(api.store.game());if(!session)return result;
      return JSX.jsxs(React.Fragment,{children:[result,JSX.jsxs('section',{'data-delivery-brothel-active':true,className:'p-3 border border-rose-900 rounded',children:[
        JSX.jsx('p',{children:`${session.workerName} · ${session.offer.destination} 배달 중 · 귀환까지 ${Math.max(0,session.returnAtSlot-api.store.game().slot)}분`}),
        JSX.jsx('button',{type:'button',disabled:!!api.store.game().pendingEvent,onClick:()=>api.store.dispatch({type:'wait',minutes:15}),children:'15분 기다리기'})]})]});
    }});
    api.hook('DeliveryLocationPanel',{priority:-400,after(result){
      const session=DeliveryBrothel_세션읽기(api.store.game());if(!session||!React.isValidElement(result))return result;
      return React.cloneElement(result,{},...React.Children.toArray(result.props.children),JSX.jsx('p',{'data-delivery-brothel-worker':true,className:'text-xs text-rose-200',children:`배달장소 · 매춘부 ${session.workerName}`}));
    }});
    globalThis.__waywardWifeViewLegacyGuard?.register(OWNER,api,state=>!!DeliveryBrothel_세션읽기(state)||delivery.ownsOrder(state));
    let writing=false;
    api.store.subscribe(()=>{if(writing||!api.store.get().started)return;const state=api.store.game(),next=DeliveryBrothel_진행하기(state);if(next!==state){writing=true;try{api.store.update(current=>current===state?next:current)}finally{writing=false}}});
    globalThis.__waywardDeliveryBrothel={send:id=>{const before=api.store.game();api.store.dispatch({type:'delivery/send-brothel-worker',workerId:id});return api.store.game().deliveryAddon?.activeDelivery?.workerId===id&&before!==api.store.game()},unavailable:DeliveryBrothel_불가이유읽기};
  }
});
