import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire,registerHooks} from 'node:module';
import {pathToFileURL} from 'node:url';
const require=createRequire(new URL('../../../../MCP/package.json',import.meta.url));
registerHooks({resolve(name,context,next){try{return next(name,context);}catch(error){
  if(error.code==='ERR_MODULE_NOT_FOUND'&&!name.startsWith('.')&&!name.includes(':'))return next(pathToFileURL(require.resolve(name)).href,context);
  throw error;
}}});
const play=await import('../../../../MCP/lib/play.mjs');
const mobile=process.argv.includes('--mobile');
const old=process.argv.includes('--old');
const version=old?'1.0.0':fs.readFileSync(new URL('../source/mod.wml.js',import.meta.url),'utf8').match(/version:\s*'([^']+)'/)[1];
const defaults=Object.fromEntries([...fs.readFileSync(new URL('../../mods.js',import.meta.url),'utf8').matchAll(/^\s*"([^":]+)"/gm)].map(row=>[row[1],false]));
const call=async fn=>{
  const response=await play.playEval({id:'minute-redraw',code:'return ('+fn.toString()+')('+JSON.stringify(version)+');'});
  assert.equal(response.pageErrorsSoFar,0);return response.result;
};
try{
  const start=await play.playStart({id:'minute-redraw',mods:defaults,viewport:mobile?{width:390,height:844}:{width:1500,height:1000}});
  assert.deepEqual(start.failed,[]);
  await call(async version=>{
    const append=Node.prototype.appendChild;
    Node.prototype.appendChild=function(node){if(node.tagName==='SCRIPT'&&node.src.endsWith('/image-search-customize/mod.js')){queueMicrotask(()=>node.dispatchEvent(new Event('error')));return node;}return append.call(this,node);};
    try{return await WML.install([{path:'search.zip',blob:await(await fetch('wml/mods/image-search-customize/image-search-customize-'+version+'-20261101.zip')).blob()}]);}
    finally{Node.prototype.appendChild=append;}
  });
  assert.deepEqual((await play.playReload({id:'minute-redraw'})).failed,[]);
  const result=await call(async()=>{
    const d=WML.dev();d.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true,imageBackendMode:'off'});d.store.get().newGame();
    const key='pippa__task-idle__outfit-modest__room-taproom__v-0';
    d.hook('bh',{replace:async()=>({entries:{[key]:{talentName:key,imagePath:'clock-fixture.webp',imageType:'portrait',source:'server'}}})});
    d.hook('yh',{replace:()=>({baseUrl:'',comfyui:false})});
    const originalFetch=window.fetch;
    window.fetch=(url,options)=>options?.method==='HEAD'?Promise.resolve(new Response(null,{status:200})):originalFetch(url,options);
    const epoch=async()=>{await WW_ImageStudioMatching.resolve(key);return WW_ImageStudioMatching.last.drawEpoch;};
    d.actions.register('dev/no-time',state=>({...state}));
    d.actions.register('dev/minute',state=>({...state,slot:state.slot+1}));
    const first=await epoch();
    for(let i=0;i<20;i++)d.store.dispatch({type:'dev/no-time'});
    const afterClicks=await epoch();
    d.store.dispatch({type:'dev/minute'});const afterMinute=await epoch();
    d.store.dispatch({type:'dev/no-time'});const afterSameMinute=await epoch();
    d.store.update(state=>({...state,slot:state.slot+10}));const afterJump=await epoch();
    d.store.update(state=>({...state,slot:state.slot-1}));const afterRewind=await epoch();
    const win=WW_ImageStudioMatching.open();
    document.querySelector('[data-match-tab="aftermath"]').click();
    const section=()=>document.querySelector('[data-match-content="aftermath"]');
    const required=()=>section().querySelector('[data-match-check="required"]');
    const ui={required:required().checked,labels:section().textContent.includes('흔적 없음 (none)')&&section().textContent.includes('땀·홍조 (sweat)')&&section().textContent.includes('몸의 체액 (messy)')&&section().textContent.includes('얼굴의 체액 (facial)'),current:!!section().querySelector('[data-match-aftermath-current]')};
    required().click();required().click();
    const stored=JSON.parse(localStorage.getItem('wml.mod.imagestudio.image-matching'));
    WW_ImageStudioMatching.set(stored);win.refresh();
    ui.savedFalse=required().checked===false&&WW_ImageStudioMatching.get().rules.aftermath.required===false;
    required().click();
    section().querySelector('[data-match-groups]').value='none | sweat';
    section().querySelector('[data-match-save-groups]').click();
    ui.noneGroup=WW_ImageStudioMatching.get().rules.aftermath.groups.some(row=>row.includes('none')&&row.includes('sweat'));
    ui.width=section().getBoundingClientRect().width;ui.viewport=innerWidth;
    win.close();
    window.fetch=originalFetch;
    return {first,afterClicks,afterMinute,afterSameMinute,afterJump,afterRewind,ui};
  });
  assert.equal(result.afterClicks,result.first,'Zero-minute actions redrew the image');
  assert.equal(result.afterMinute,result.first+1);
  assert.equal(result.afterSameMinute,result.afterMinute);
  assert.equal(result.afterJump,result.afterMinute+1);
  assert.equal(result.afterRewind,result.afterJump+1);
  assert.equal(result.ui.required,false);assert.equal(result.ui.labels,true);assert.equal(result.ui.current,true);assert.equal(result.ui.savedFalse,true);assert.equal(result.ui.noneGroup,true);assert.ok(result.ui.width<=result.ui.viewport);
  const legacy=await call(()=>{
    const previous=WW_ImageStudioMatching.defaults();previous.version=2;previous.enabled=false;
    for(const row of Object.values(previous.rules))row.required=true;
    previous.rules.scene.required=false;previous.rules.outfit.required=false;previous.rules.room.exact=12345;
    const text=JSON.stringify(previous);localStorage.setItem('wml.mod.imagestudio.image-matching',text);return text;
  });
  assert.deepEqual((await play.playReload({id:'minute-redraw'})).failed,[]);
  const migration=await call(()=>({config:WW_ImageStudioMatching.get(),backup:localStorage.getItem('wml.mod.imagestudio.image-matching.before-required-v3')}));
  assert.equal(migration.backup,legacy);assert.equal(migration.config.version,3);assert.equal(migration.config.enabled,false);
  assert.deepEqual(Object.keys(migration.config.rules).filter(id=>migration.config.rules[id].required),['scene','outfit']);
  assert.equal(migration.config.rules.room.exact,12345);
  fs.writeFileSync(new URL('minute-redraw-'+(mobile?'mobile':'pc')+'.json',import.meta.url),JSON.stringify({version,mobile,...result,migration},null,2)+'\n');
  console.log(JSON.stringify(result));
}finally{await play.shutdown();}
