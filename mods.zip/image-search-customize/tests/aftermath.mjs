import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const source=fs.readFileSync(new URL('../source/image-matching.js',import.meta.url),'utf8');
const matcher=vm.runInNewContext(source+'\nImageStudio_매칭엔진만들기();');
const key=(task,trace)=>'iroha__task-'+task+'__outfit-modest__room-taproom'+(trace==='none'?'':'__aft-'+trace)+'__v-0';
let assertions=0;
for(const task of ['idle','serving','cleaning']){
  for(const request of ['none','sweat','messy','facial']){
    for(const candidate of ['none','sweat','messy','facial']){
      const strict=matcher.defaults();strict.rules.aftermath.required=true;
      const score=matcher.score(matcher.describe(key(task,request)),matcher.describe(key(task,candidate)),strict);
      assert.equal(score!==null,request===candidate);assertions++;
    }
  }
}
const config=matcher.defaults();
assert.equal(config.rules.aftermath.required,false);
assert.ok(matcher.score(matcher.describe(key('idle','none')),matcher.describe(key('idle','none').replace('__v-0','__aft-none__v-0')),config));
config.rules.aftermath.required=false;
const saved=matcher.normalize(JSON.parse(JSON.stringify(config)));
assert.equal(saved.rules.aftermath.required,false,'Explicit saved preference must survive');
assert.ok(matcher.score(matcher.describe(key('idle','none')),matcher.describe(key('idle','messy')),saved));
config.rules.aftermath.required=true;config.rules.aftermath.groups=[['none','sweat']];
assert.ok(matcher.score(matcher.describe(key('idle','none')),matcher.describe(key('idle','sweat')),config));
assert.equal(matcher.score(matcher.describe(key('idle','none')),matcher.describe(key('idle','messy')),config),null);
console.log('Passed '+assertions+' daily-task trace pairs, none alias, saved preferences and explicit similarity');
for(const version of [1,2]){
  const previous=JSON.parse(JSON.stringify(matcher.defaults()));previous.version=version;
  previous.enabled=false;previous.rules.scene.required=false;
  for(const id of ['room','exposure','aftermath'])previous.rules[id].required=true;
  previous.rules.room.exact=12345;previous.wifeOutfits.iroha=[['modest','nightshift']];
  const migrated=matcher.normalize(previous);
  assert.equal(migrated.version,3);
  assert.deepEqual(Array.from(Object.keys(migrated.rules).filter(id=>migrated.rules[id].required)),['scene','outfit']);
  assert.equal(migrated.enabled,false);assert.equal(migrated.rules.room.exact,12345);
  assert.equal(JSON.stringify(migrated.wifeOutfits),JSON.stringify(previous.wifeOutfits));
  assert.equal(JSON.stringify(matcher.normalize(JSON.parse(JSON.stringify(migrated)))),JSON.stringify(migrated));
}
const loose=matcher.defaults(),request=matcher.describe(key('idle','none'));
assert.ok(matcher.score(request,matcher.describe(key('idle','messy').replace('room-taproom','room-bedroom').replace('__aft-','__exp-0111101__aft-')),loose));
assert.equal(matcher.score(request,matcher.describe(key('idle','none').replace('outfit-modest','outfit-nude')),loose),null);
assert.equal(matcher.score(request,matcher.describe(key('idle','none').replace('task-idle','task-cooking')),loose),null);
console.log('Passed v1/v2 policy migration, retained settings and two-condition filtering');
