// 실행: node wml/mods/imagestudio/tests/exposure-normalization.mjs [--mobile]
// seed=1138. 격리 저장소에서 노출 코드·조건 목록·계획·기존 이미지 조회를 확인하며 GPU와 실제 파일은 변경하지 않습니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { playStart, playEval, playReload, shutdown } from '../../../../MCP/lib/play.mjs';

const mobile = process.argv.includes('--mobile');
const source = fs.readFileSync(new URL('../source/image-matching.js', import.meta.url), 'utf8');
const pure = vm.runInNewContext(source + '\n({code:ImageStudio_노출코드정규화하기,key:ImageStudio_노출키정규화하기,matcher:ImageStudio_매칭엔진만들기()});');
const aliases = {
  '1100000': '0100000', '0010000': '0110000', '0011000': '0111000',
  '0010100': '0111100', '0010101': '0111101', '1101010': '0101010',
  '0000100': '0001100', '0000101': '0001101', '0100100': '0101100',
};
const base = 'elena__task-idle__outfit-modest__room-taproom';
const config = pure.matcher.defaults();
config.rules.exposure.required = true;
config.rules.exposure.allowSimilar = false;

// 제시된 9개와 전체 128개 비트 조합을 확인합니다. 잘못된 코드는 임의 보정하지 않습니다.
for (const [oldCode, code] of Object.entries(aliases)) {
  assert.equal(pure.code(oldCode), code);
  const request = pure.matcher.describe(base + '__exp-' + code + '__v-0');
  const entry = { talentName: base + '__exp-' + oldCode + '__v-1', imagePath: 'original-' + oldCode + '.png' };
  const selected = pure.matcher.ImageStudio_정확이미지고르기(request, [entry], config);
  assert.equal(selected?.entry, entry);
  assert.equal(selected.score.matches.exposure, 'exact');
}
const allCodes = Array.from({ length: 128 }, (_, index) => index.toString(2).padStart(7, '0'));
assert.equal(new Set(allCodes.map(pure.code)).size, 36);
assert.ok(allCodes.every(code => pure.code(pure.code(code)) === pure.code(code)));
assert.equal(pure.code('not-valid'), 'not-valid');
assert.equal(pure.key(base + '__exp-0000000__v-0'), base + '__v-0');
assert.equal(pure.key(base + '__exp-invalid__v-0'), base + '__exp-invalid__v-0');
const familyRows = ['0010000', '0110000'].map((code, index) => ({ talentName: base + '__exp-' + code + '__v-' + index, imagePath: index + '.png' }));
assert.equal(pure.matcher.choose(pure.matcher.describe(familyRows[0].talentName), familyRows, config).familyCount, 1);
console.log('PASS 9 aliases / 128 combinations -> 36 states / strict exact match / shared variant family / original entry preserved');

try {
  const started = await playStart({ viewport: mobile ? { width: 390, height: 844 } : { width: 1500, height: 1000 } });
  assert.deepEqual(started.failed, []);
  const result = await playEval({ timeoutMs: 30000, code: `
    let seed=1138;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
    const d=WML.dev(),b=WW_ImageStudioBridge,m=WW_ImageStudioMatching,aliases=${JSON.stringify(aliases)};
    const before=JSON.stringify(d.store.game()),fields=['bodiceUnlaced','topPulledDown','topRemoved','skirtUp','skirtRemoved','pantiesAside','pantiesRemoved'];
    const normal=code=>b.extensions.normalizeKey('elena__task-idle__outfit-modest__room-taproom__exp-'+code+'__v-0');
    const gameDifferences=[];
    for(let i=0;i<128;i++){
      const code=i.toString(2).padStart(7,'0'),exposure=Object.fromEntries(fields.map((field,index)=>[field,code[index]==='1']));
      const actual=normal(code).match(/__exp-([01]{7})(?=__|$)/)?.[1];
      if(actual!==d.fn('Ote')(exposure))gameDifferences.push(code);
    }
    const axes=b.axes().exposure.map(item=>item.value);
    const presetCanonical=axes.every(code=>code==='none'||normal(code).includes('__exp-'+code+'__'));
    const selected={situation:['idle'],outfit:['modest'],room:['taproom'],mood:['default'],men:['0'],exposure:['1100000','0100000'],aftermath:['none'],variant:['0']};
    const space=b.randomSpace('elena',selected),listed=await b.list('elena',selected);
    const planned=space.build(0n,WW_ImageStudioPrompt.combinationSpace({}).at(0n));
    const planCanonical=planned.length===1&&planned[0].talentId.includes('__exp-0100000__');
    const base=${JSON.stringify(base)},rawKey=base+'__exp-1100000__v-0',canonicalKey=base+'__exp-0100000__v-0';
    const identityEqual=b.identity(rawKey)===b.identity(canonicalKey);
    const sourceCount=b.randomSpace('elena',selected,[rawKey,canonicalKey]).count.toString();
    const rebuilt=b.fromKey('elena',rawKey,selected);
    const fromKeyCanonical=rebuilt?.talentId.includes('__exp-0100000__');
    const savedBridge={packs:b.packs,ready:b.ready,connection:b.connection,fetch};
    const metadata={emotions:[],badguest:[],pregnancy:'none',detail:[]};
    const entry={talentName:rawKey,imagePath:'exposure-legacy-original.png',matching:metadata};
    let lookup;
    b.packs=()=>[{entries:{legacy:entry}}];b.ready=()=>Promise.resolve();b.connection=()=>({baseUrl:null,comfyui:false});
    globalThis.fetch=(input,options)=>options?.method==='HEAD'?Promise.resolve(new Response(null,{status:200})):savedBridge.fetch(input,options);
    try {
      m.refresh();const found=await m.resolve(canonicalKey,metadata,'exact');
      lookup={sameEntry:found?.entry===entry,key:found?.entry.talentName,path:found?.entry.imagePath};
    }finally{b.packs=savedBridge.packs;b.ready=savedBridge.ready;b.connection=savedBridge.connection;globalThis.fetch=savedBridge.fetch;m.refresh();}
    await b.ready();
    const rawSet=new Set(['none',...Object.keys(aliases),...Object.values(aliases)]);
    for(const pack of b.packs())for(const entry of Object.values(pack.entries||{}))rawSet.add(entry.talentName?.match(/__exp-([01]{7})(?=__|$)/)?.[1]||'none');
    const canonicalSet=new Set([...rawSet].map(code=>code==='none'?'none':normal(code).match(/__exp-([01]{7})(?=__|$)/)?.[1]||'none'));
    localStorage.setItem('ww-image-studio-conditions-v2',JSON.stringify({ichika:{selected:{exposure:['1100000','0100000','0010000','0110000']}}}));
    return {gameDifferences,axes,presetCanonical,spaceCount:space.count.toString(),listed:listed.length,planCanonical,identityEqual,sourceCount,fromKeyCanonical,lookup,canonicalCount:canonicalSet.size,unchanged:before===JSON.stringify(d.store.game())};
  ` });
  assert.equal(result.pageErrorsSoFar, 0);
  const check = result.result;
  assert.deepEqual(check.gameDifferences, []);
  assert.equal(check.presetCanonical, true);
  assert.equal(check.axes.length, 14);
  assert.equal(check.spaceCount, '1');
  assert.equal(check.listed, 1);
  assert.equal(check.planCanonical, true);
  assert.equal(check.identityEqual, true);
  assert.equal(check.sourceCount, '1');
  assert.equal(check.fromKeyCanonical, true);
  assert.equal(check.lookup.sameEntry, true);
  assert.match(check.lookup.key, /__exp-1100000__/);
  assert.equal(check.lookup.path, 'exposure-legacy-original.png');
  assert.equal(check.canonicalCount, 36);
  assert.equal(check.unchanged, true);
  console.log('PASS native Jee agreement / 14 canonical presets / duplicate plan count / identities / source cloning / existing alias file lookup');

  // 실제 팩을 읽는 조건부 생성 창에서 45개 표기가 36개 상태로 합쳐지는지 확인합니다.
  await playReload({});
  const ui = await playEval({ timeoutMs: 30000, code: `
    const wait=()=>new Promise(resolve=>setTimeout(resolve,40));
    await WW_ImageStudioBridge.ready();
    WW_ImageStudio.open();await new Promise(resolve=>setTimeout(resolve,300));
    const button=[...document.querySelectorAll('#wwis-people button')].find(button=>/이치카|ichika/i.test(button.textContent));
    if(!button)throw Error('Ichika selector missing');button.click();await new Promise(resolve=>setTimeout(resolve,300));
    document.querySelector('#wwis-conditional').click();
    for(let i=0;i<150;i++){
      if(document.querySelectorAll('input[data-axis="exposure"]').length===36)break;
      await wait();
      if(!document.querySelector('input[data-axis="exposure"]'))document.querySelector('#wwis-conditional')?.click();
    }
    const inputs=[...document.querySelectorAll('input[data-axis="exposure"]')];
    const values=inputs.map(input=>input.dataset.value),checked=inputs.filter(input=>input.checked).map(input=>input.dataset.value);
    const first=inputs.find(input=>input.checked);first.dispatchEvent(new Event('change'));
    const saved=JSON.parse(localStorage.getItem('ww-image-studio-conditions-v2')).ichika.selected.exposure;
    return {count:values.length,unique:new Set(values).size,aliases:values.filter(code=>Object.hasOwn(${JSON.stringify(aliases)},code)),checked,saved};
  ` });
  assert.equal(ui.pageErrorsSoFar, 0);
  assert.equal(ui.result.count, 36, JSON.stringify(ui.result));
  assert.equal(ui.result.unique, 36);
  assert.deepEqual(ui.result.aliases, []);
  assert.deepEqual(ui.result.checked.sort(), ['0100000', '0110000']);
  assert.deepEqual(ui.result.saved.sort(), ['0100000', '0110000']);
  console.log('PASS real conditional UI: 36 unique states / 9 aliases removed / saved selections migrated');
} finally {
  await shutdown();
}
