// 실행: node wml/mods/imagestudio/tests/lookup-fastpath.mjs [--mobile]
// 키 우선 조회가 정확 조건·변형 추첨·메타데이터·파일 확인을 우회하지 않는지 검사합니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {playStart,playEval,shutdown} from '../../../../MCP/lib/play.mjs';

const source=fs.readFileSync(new URL('../source/image-matching.js',import.meta.url),'utf8');
const create=()=>vm.runInNewContext(source+'\nImageStudio_매칭엔진만들기();');
const key='elena__task-idle__outfit-modest__room-taproom__v-0';
const meta={emotions:[],badguest:[],pregnancy:'none',detail:[]};
const rows=Array.from({length:8},(_,i)=>({talentName:key.replace('__v-0','__v-'+i),imagePath:'variant-'+i+'.webp',matching:meta}));
rows.push({talentName:key.replace('__v-0','__v-10'),imagePath:'wrong-meta.webp',matching:{...meta,pregnancy:'early'}});
rows.push({talentName:key.replace('__v-0','__studio-other__v-0'),imagePath:'wrong-extra.webp',matching:meta});
rows.push({talentName:key.replace('outfit-modest','outfit-nude'),imagePath:'wrong-outfit.webp',matching:meta});
rows.push({talentName:key.replace('__v-0','__cid-other__v-0'),imagePath:'other-instance.webp',matching:meta,createdAt:200});
for(const context of [{},meta,{...meta,detail:['unknown']},{...meta,pregnancy:'early'}])for(const draw of [0,.3,.7,.999]){
  const fast=create(),reference=create(),config=fast.defaults(),req=fast.describe(key,context),index=fast.ImageStudio_후보색인만들기(rows);
  const direct=fast.ImageStudio_정확키후보읽기(index,req);
  const actual=fast.ImageStudio_정확이미지고르기(req,direct,config,()=>null,()=>draw)
    ||fast.ImageStudio_정확이미지고르기(req,fast.ImageStudio_색인후보읽기(index,req,config),config,()=>null,()=>draw);
  const expected=reference.ImageStudio_정확이미지고르기(reference.describe(key,context),reference.ImageStudio_색인후보읽기(reference.ImageStudio_후보색인만들기(rows),reference.describe(key,context),config),config,()=>null,()=>draw);
  assert.equal(actual?.entry,expected?.entry);
  for(const field of ['familyCount','variantCount','familyProbability','passedCount'])assert.equal(actual?.[field],expected?.[field],field);
}
// 서로 다른 캐릭터 인스턴스만 남았을 때의 기존 최신 묶음 선택도 유지합니다.
const m=create(),config=m.defaults(),other=rows.filter(row=>row.talentName.includes('__cid-'));
assert.equal(m.ImageStudio_정확이미지고르기(m.describe(key,meta),m.ImageStudio_색인후보읽기(m.ImageStudio_후보색인만들기(other),m.describe(key,meta),config),config).entry,other[0]);
const full='elena__task-idle__outfit-modest__room-taproom__aip-state-distressed_fluid-mouth-1_jewel-breasts-2_toy-vibe-egg_talk-benchmark-example__v-0';
const compact=m.ImageStudio_이전짧은키읽기(full),short={talentName:compact,imagePath:'short.webp',matching:meta};
assert.notEqual(compact,full);
const direct=m.ImageStudio_정확키후보읽기(m.ImageStudio_후보색인만들기([short]),m.describe(full,meta));
assert.equal(m.ImageStudio_정확이미지고르기(m.describe(full,meta),direct,config).entry.imagePath,'short.webp');
assert.equal(m.ImageStudio_정확이미지고르기(m.describe(full,{...meta,pregnancy:'early'}),direct,config),null);
console.log('PASS exact variants and metadata / other instance fallback / short-key compatibility without relaxing conditions');

let listed=[];vm.runInNewContext(fs.readFileSync(new URL('../../mods.js',import.meta.url),'utf8'),{WML:{folders(){},enable:value=>listed=value}});
const mods=Object.fromEntries(listed.map(value=>[value.replace(/:off$/,''),false]));
try{
  const started=await playStart({mods:{...mods,'addon-compat':true,imagestudio:true,'attention-image-prompt':true,'imagestudio-compatible-attention-image-prompt':true},viewport:process.argv.includes('--mobile')?{width:390,height:844}:{width:1500,height:950}});
  assert.deepEqual(started.failed,[]);
  const response=await playEval({code:`
    const d=WML.dev(),bridge=WW_ImageStudioBridge,matching=WW_ImageStudioMatching,before=JSON.stringify(d.store.game()),key=${JSON.stringify(key)},full=${JSON.stringify(full)},meta=${JSON.stringify(meta)};
    const settings=d.fn('settingsStore').getState();settings.set({imageBackendMode:'auto'});
    bridge.ready=()=>Promise.resolve();bridge.connection=()=>({baseUrl:null,comfyui:false});
    let rows=${JSON.stringify(rows.slice(0,8))},heads=0,missing=false;bridge.packs=()=>[pack];let pack;
    const update=values=>{pack={entries:Object.fromEntries(values.map((value,i)=>[i,value]))};matching.refresh();};
    const originalFetch=fetch;globalThis.fetch=(input,options)=>options?.method==='HEAD'?(heads++,Promise.resolve(new Response(null,{status:missing?404:200}))):originalFetch(input,options);
    try{
      update(rows);const first=await matching.resolve(key,meta),firstPath=first.entry.imagePath;
      const firstHeads=heads;for(let i=0;i<20;i++)await matching.resolve(key,meta);const cachedHeads=heads-firstHeads;
      const wrongMeta=await matching.resolve(key,{...meta,pregnancy:'late'});
      const compact=matching.matcher.ImageStudio_이전짧은키읽기(full);update([{talentName:compact,imagePath:'short.webp',matching:meta}]);
      const compatible=await matching.resolve(full,meta),mismatch=await matching.resolve(full,{...meta,pregnancy:'early'});
      update([{talentName:key,imagePath:'deleted.webp',matching:meta}]);missing=true;const gone=await matching.resolve(key,meta);missing=false;
      update([{talentName:key,imagePath:'replacement.webp',matching:meta}]);const refreshed=await matching.resolve(key,meta);
      const defaults=matching.get();matching.set({...defaults,enabled:false});let passed=0;const stop=d.hook('Yp',{priority:-1000,around(){passed++;return {talentName:key,imagePath:'bypass.webp'};}});const bypass=await d.fn('Yp')(key);stop();
      return {variants:!!firstPath,cachedHeads,wrongMeta:!wrongMeta,short:compatible?.entry.talentName===compact,mismatch:!mismatch,gone:!gone,refresh:refreshed?.entry.imagePath==='replacement.webp',bypass:bypass.imagePath==='bypass.webp'&&passed===1,unchanged:before===JSON.stringify(d.store.game())};
    }finally{globalThis.fetch=originalFetch;}
  `});
  assert.equal(response.pageErrorsSoFar,0,JSON.stringify(response));
  assert.deepEqual(response.result,{variants:true,cachedHeads:0,wrongMeta:true,short:true,mismatch:true,gone:true,refresh:true,bypass:true,unchanged:true});
  console.log('PASS actual lookup / cached HEAD / strict short-key metadata / deleted files / replacement / disabled matching / unchanged game');
}finally{await shutdown();setTimeout(()=>process.exit(process.exitCode||0),200).unref();}
