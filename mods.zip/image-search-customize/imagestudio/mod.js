// 생성 파일. source/build.mjs로 재생성합니다.
// H_Status 기존 데이터와 ImageStudio의 캐릭터 설정을 연결합니다.
WML.define({
  id: "imagestudio",
  author: "Hina_Lover",
  name: "이미지 스튜디오",
  version: "1.31.20",
  game: "2026-11-01",
  lang: 'ko',
  backup: { indexedDB: ['wml.mod.imagestudio.usage'] },
  role: 'scene-prompt',
  description: "SDXL·Anima·NovelAI 생성 방식과 공통 대기열·검수·저장·캐시·이미지팩, 상황·프롬프트 확장 등록을 제공합니다.",
  requires: ["addon-compat"],
  loadAfter: ["newwife-hina", "attention-image-prompt"],
  conflicts: [],
  symbols: {
    "imagePlanner": {"raw":{"2026-11-01":"Uat"},"doc":"Image Studio conditional planner binding"},
    "imagePlannerAppend": {"raw":{"2026-11-01":"mu"},"doc":"Image Studio conditional planner binding"},
    "imageKeyParse": {"raw":{"2026-11-01":"rl"},"doc":"Image Studio conditional planner binding"},
    "imageArchetypeCharacter": {"raw":{"2026-11-01":"Fat"},"doc":"Image Studio conditional planner binding"},
    "imageMoods": {"raw":{"2026-11-01":"Mat"},"doc":"Image Studio conditional planner binding"},
    "imageTasks": {"raw":{"2026-11-01":"Dat"},"doc":"Image Studio conditional planner binding"},
    "imageEscalationScenes": {"raw":{"2026-11-01":"Rat"},"doc":"Image Studio conditional planner binding"},
    "imageSexScenes": {"raw":{"2026-11-01":"GB"},"doc":"Image Studio conditional planner binding"},
    "imageAfters": {"raw":{"2026-11-01":"Oat"},"doc":"Image Studio conditional planner binding"},
    "imageSexExposures": {"raw":{"2026-11-01":"UB"},"doc":"Image Studio conditional planner binding"},
    "imageEscalationExposures": {"raw":{"2026-11-01":"Pat"},"doc":"Image Studio conditional planner binding"},
    "imageTaskExposures": {"raw":{"2026-11-01":"qB"},"doc":"Image Studio conditional planner binding"},
    "imageGroupSlots": {"raw":{"2026-11-01":"VB"},"doc":"Image Studio conditional planner binding"},
    "imageRooms": {"raw":{"2026-11-01":"Za"},"doc":"Image Studio conditional planner binding"},
    "imageFloorOutfits": {"raw":{"2026-11-01":"ene"},"doc":"Image Studio conditional planner binding"},
    "imageBathOutfits": {"raw":{"2026-11-01":"ene"},"doc":"Image Studio conditional planner binding"},
    "sceneFamily": {"raw":{"2026-11-01":"df"},"doc":"Image Studio conditional planner binding"},
    "sceneDisallowsGroup": {"raw":{"2026-11-01":"lye"},"doc":"Image Studio conditional planner binding"},
    "imageUsageInitialState": {"raw":{"2026-11-01":"fc"},"doc":"Fresh game state factory; ImageStudio usage session marker"},
    "imageUsagePortraitPanel": {"raw":{"2026-11-01":"rv"},"doc":"Gameplay portrait panel; observe real scene prompt demand only"},
    "imageStudioAutonomousActions": {"raw":{"2026-11-01":"D2"},"doc":"아내의 자발 행동 후보 배열 () -> actions"},
    "imageStudioDailyOutfit": {"raw":{"2026-11-01":"tq"},"doc":"등장·기상 후 아내의 자발적 일상복 선택 (state, stats?) -> outfitId"},
    "imageStudioCoverOutfit": {"raw":{"2026-11-01":"XU"},"doc":"아내의 자발적 가림용 평상복 변경 (state, reason) -> {state,target}"},
    "imageStudioApplyOutfitResponse": {"raw":{"2026-11-01":"L0"},"doc":"대화 응답의 의상/노출/장면 변경 적용 (state,response) -> state"},
    "imageStudioTryOutfit": {"raw":{"2026-11-01":"GXe"},"doc":"옷가게에서 플레이어가 선택한 의상 시착 (state,outfitId) -> state"},
    "topFeelings": {"raw":{"2026-11-01":"i_"},"doc":"인물의 강한 감정을 세기 순서로 조회"},
    "imageLookup": {"raw":{"2026-11-01":"vy"},"doc":"이미지 키에 맞는 팩 항목 또는 가장 가까운 대체 항목 조회"},
    "imageEntryUrl": {"raw":{"2026-11-01":"o_"},"doc":"이미지팩 항목의 실제 표시 URL"}
  },

  setup(wmlApi) {
// 생성 파일. source/build.mjs로 재생성합니다.
// H_Status 기존 데이터와 ImageStudio의 캐릭터 설정을 연결합니다.
function ImageStudio_HStatus연결만들기(api, bridge) {
  let loading = null;
  async function ImageStudio_HStatus목록읽기() {
    if (!globalThis.__WW_IMAGESTUDIO_H_STATUS_TEMPLATES__) {
      if (!loading) loading = api.loadScript('h-status-situation-prompts.js').finally(() => { loading = null; });
      await loading;
    }
    const data = globalThis.__WW_IMAGESTUDIO_H_STATUS_TEMPLATES__;
    if (data?.format !== 1 || !Array.isArray(data.branches)) throw Error('H_Status 공통 프롬프트 파일을 불러오지 못했습니다. 모드 ZIP을 다시 설치하세요.');
    return data;
  }
  async function ImageStudio_HStatus계획만들기(characterId, branchIds, options = {}, progress = () => {}) {
    if (!/^[a-z0-9][a-z0-9_-]{0,99}$/.test(characterId) || characterId === 'patron') throw Error('올바른 캐릭터를 선택하세요.');
    const data = await ImageStudio_HStatus목록읽기();
    const requested = new Set(Array.isArray(branchIds) ? branchIds : []);
    const branches = data.branches.filter(branch => requested.has(branch.id));
    if (!branches.length || branches.length !== requested.size) throw Error('생성할 H_Status 이미지 묶음을 하나 이상 선택하세요.');
    const source = options.source || (data.sources.some(item => item.id === characterId) ? characterId : data.defaultSource);
    if (!data.sources.some(item => item.id === source)) throw Error('상황 프롬프트 기준을 확인하세요.');
    let profile = options.profile;
    if (!profile) {
      const baseUrl = bridge.connection()?.baseUrl;
      if (!baseUrl) throw Error('이미지 서버에 연결하세요.');
      const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 8000);
      try {
        const response = await fetch(baseUrl + '/api/generation/settings', { credentials: 'omit', signal: controller.signal });
        const body = await response.json();
        if (!response.ok) throw Error(body.error || `외형 설정 읽기 실패 (HTTP ${response.status})`);
        profile = body.characters?.find(item => item.id === characterId);
      } finally { clearTimeout(timer); }
      if (!profile) profile = bridge.characters()?.characters?.find(item => item.id === characterId);
    }
    if (!profile?.prompt?.trim()) throw Error('선택한 캐릭터의 외형 프롬프트가 없습니다. 새로운 캐릭터 찾기 또는 이미지 생성 방식 지정에서 등록하세요.');
    const items = [], counts = {}, total = branches.reduce((sum, branch) => sum + branch.count, 0);
    progress({ current: 0, total, stage: 'h-status-plan', label: 'H_Status 프롬프트 준비', unit: '장' });
    for (const branch of branches) {
      const entries = Object.entries(branch.entries), override = branch.overrides[source] || {};
      if (entries.length !== branch.count) throw Error(`${branch.label} 프롬프트 수가 다릅니다.`);
      counts[branch.id] = entries.length;
      for (const [key, base] of entries) {
        const entry = override[key] || base;
        const prompt = entry.prompt.includes(data.characterPlaceholder)
          ? entry.prompt.replaceAll(data.characterPlaceholder, profile.prompt.trim())
          : [entry.prompt, profile.prompt.trim()].filter(Boolean).join(', ');
        const talentId = key.replaceAll(data.characterIdPlaceholder, characterId);
        if (prompt.includes('{{') || talentId.includes('{{')) throw Error('캐릭터 프롬프트 자리표시자가 남아 있습니다.');
        let item = { talentId, prompt,
          negativePrompt: [entry.negativePrompt, profile.negativePrompt?.trim()].filter(Boolean).join(', '),
          workflow: entry.workflow || 'illustrious', imageType: 'portrait',
          width: Number(entry.width) || 1152, height: Number(entry.height) || 896,
          steps: Number(entry.steps) || undefined, cfg: Number(entry.cfg) || undefined, weight: branch.weight };
        // 부위별 설정은 개별 검수와 일괄 생성에 같은 참조 선택 규칙을 적용합니다.
        const upgrade=bridge.extensions?.editor?.upgrades;
        if(upgrade?.prepare) item=await upgrade.prepare({...item,imageKey:talentId,referenceSource:source});
        items.push(item);
        if (items.length % 100 === 0) {
          progress({ current: items.length, total, stage: 'h-status-plan', label: 'H_Status 프롬프트 준비', unit: '장' });
          await new Promise(resolve => setTimeout(resolve, 0));
        }
      }
    }
    progress({ current: items.length, total, stage: 'h-status-plan', label: 'H_Status 프롬프트 준비', unit: '장' });
    return { character: { id: characterId, name: profile.name || characterId }, source, counts, total: items.length, items };
  }
  return { hStatusCatalogue: ImageStudio_HStatus목록읽기, hStatusPlan: ImageStudio_HStatus계획만들기 };
}

async function ImageStudio_HStatus설정그리기({ box, bridge, characterId, name, selection, isCurrent, isBusy, setBusy, taskProgress, setMessage, buildPack }) {
  box.textContent = 'H_Status 공통 프롬프트 목록을 읽는 중…';
  let data;
  try { data = await bridge.hStatusCatalogue(); }
  catch (error) { if (isCurrent()) box.textContent = String(error?.message || error); return; }
  if (!isCurrent()) return;
  const h = (tag, text, props = {}) => Object.assign(document.createElement(tag), props, text == null ? {} : { textContent: text });
  const title = h('h3', `${name} · H_Status용 이미지 생성`);
  const note = h('p', '상황·의상·구도는 원본 H_Status 팩을 사용하고, 외형과 네거티브는 ImageStudio의 캐릭터 설정을 사용합니다. 생성 시 H_Status 모드를 켤 필요는 없습니다.', { className: 'wwis-dim' });
  const source = h('select', null, { id: 'wwis-h-status-source' });
  for (const item of data.sources) source.append(h('option', item.name, { value: item.id }));
  source.value = selection.source || (data.sources.some(item => item.id === characterId) ? characterId : data.defaultSource);
  source.onchange = () => { selection.source = source.value; };
  const sourceRow = h('label', '상황 프롬프트 기준 ');
  sourceRow.append(source);
  const help = h('p', '기준 캐릭터의 외형은 사용하지 않습니다. 원본 팩 사이에 남아 있는 구도·배경 차이만 선택합니다.', { className: 'wwis-dim' });
  const choices = h('div'), estimate = h('p', null, { id: 'wwis-h-status-estimate' });
  for (const branch of data.branches) {
    const row = h('label', null, { className: 'wwis-row' });
    const input = h('input', null, { type: 'checkbox', checked: (selection.branches || ['status', 'info']).includes(branch.id) });
    input.dataset.wwisHStatusBranch = branch.id;
    row.append(input, document.createTextNode(`${branch.label} · ${branch.count.toLocaleString()}장`)); choices.append(row);
  }
  const selected = () => [...choices.querySelectorAll('input:checked')].map(input => input.dataset.wwisHStatusBranch);
  const total = () => data.branches.reduce((sum, branch) => sum + (selected().includes(branch.id) ? branch.count : 0), 0);
  const enqueue = h('button', '선택 묶음 대기열 추가', { id: 'wwis-h-status-enqueue', disabled: isBusy() });
  const pack = h('button', 'H_Status용 이미지팩 만들기', { id: 'wwis-h-status-pack', disabled: isBusy() });
  const buttons = h('div', null, { className: 'wwis-row' }); buttons.append(enqueue, pack);
  const message = h('p', '기본 선택은 상태 10장 + 비밀 탭 상세 53장입니다. 기존 캐시와 대기 중인 같은 이미지는 서버에서 제외합니다.', { id: 'wwis-h-status-message', className: 'wwis-dim' });
  const update = () => { selection.branches = selected(); estimate.textContent = `${name} · 선택 ${total().toLocaleString()}장`; enqueue.disabled = isBusy() || !total(); pack.disabled = isBusy(); };
  choices.addEventListener('change', update);
  box.replaceChildren(title, note, sourceRow, help, choices, estimate, buttons, message);
  update();
  taskProgress.paint('generation');
  pack.onclick = async () => {
    if (isBusy() || typeof buildPack !== 'function') return;
    pack.disabled = true;
    try { message.textContent = await buildPack(characterId); }
    catch (error) { message.textContent = `팩 생성 실패: ${String(error?.message || error)}`; }
    finally { update(); }
  };
  enqueue.onclick = async () => {
    if (isBusy()) return;
    const branchIds = selected(), templateSource = source.value;
    if (!branchIds.length) { message.textContent = '생성할 묶음을 선택하세요.'; return; }
    setBusy(true); enqueue.disabled = true;
    source.disabled = true; choices.querySelectorAll('input').forEach(input => { input.disabled = true; });
    let failed = false, resultText = '';
    try {
      taskProgress.update('generation', { restart: true, stage: 'h-status-connection', label: 'H_Status 생성 준비', current: 0, total: null });
      await bridge.ready?.();
      const connection = bridge.connection?.();
      if (!connection?.baseUrl || connection.comfyui !== true) throw Error('이미지 서버와 선택한 생성 방식의 연결을 확인하세요.');
      const healthResponse = await fetch(connection.baseUrl + '/api/image/health', { credentials: 'omit', signal: AbortSignal.timeout(8000) });
      const health = await healthResponse.json();
      if (!healthResponse.ok || !health.capabilities?.includes('h-status-character-keys')) throw Error('H_Status 캐릭터별 LoRA를 지원하는 서버가 필요합니다. 생성 중인 작업이 끝나면 이 모드 폴더의 Start_ImageStudio.cmd로 서버를 다시 실행하세요.');
      const plan = await bridge.hStatusPlan(characterId, branchIds, { source: templateSource }, value => taskProgress.update('generation', value));
      const report = value => {
        const detail = `서버 접수 ${(value.accepted || 0).toLocaleString()}장 · 캐시 보유 ${(value.alreadyCached || 0).toLocaleString()}장 · 이미 대기 중 ${(value.alreadyQueued || 0).toLocaleString()}장`;
        taskProgress.update('generation', { stage: 'h-status-queue', label: 'H_Status 대기열 전송', current: value.sent, total: plan.total, unit: '장', detail });
        message.textContent = detail;
      };
      report({ sent: 0 });
      const result = await bridge.enqueue(plan.items, report);
      report({ sent: plan.total, ...result });
      resultText = `${name}: 새로 추가 ${(result.accepted || 0).toLocaleString()}장 · 캐시 보유 ${(result.alreadyCached || 0).toLocaleString()}장 · 이미 대기 중 ${(result.alreadyQueued || 0).toLocaleString()}장`;
    } catch (error) { failed = true; resultText = `추가 실패: ${String(error?.message || error)}`; }
    finally {
      setBusy(false); source.disabled = false;
      choices.querySelectorAll('input').forEach(input => { input.disabled = false; }); update();
      message.textContent = resultText; setMessage(resultText);
      taskProgress.finish('generation', resultText, failed);
    }
  };
}

// 공통 자세·장면 적합성. 편집기를 꺼도 같은 기준으로 이미지를 비교합니다.
const ImageStudio_자세상황목록 = (() => {
  const 목록 = value => new Set(value.trim().split(/\s+/));
  const 일반성관계 = 목록('sex sex_rough patron_sex patron_sex_climax patron_sex_finish patron_sex_finish_pullout');
  const 항문성교 = 목록('anal patron_anal patron_anal_climax patron_anal_finish patron_anal_finish_pullout');
  const 구강성교 = 목록('blowjob deepthroat clean_with_mouth cum_in_mouth patron_blowjob patron_deepthroat patron_blowjob_climax patron_blowjob_swallow');
  const 손자극 = 목록('bath_attendant_handjob handjob patron_handjob patron_handjob_finish patron_handjob_climax');
  const 가슴자극 = 목록('titfuck patron_titfuck');
  const 여성기구강 = 목록('cunnilingus patron_cunnilingus');
  const 마주밀착 = 목록('patron_chatting patron_flirting kissing patron_touching patron_bold patron_intimate grinding mutual_touching patron_mutual_touching patron_moment_sit_on_lap');
  const 뒤밀착 = 목록('patron_flirting kissing groped_ass groped_tits patron_touching patron_bold patron_groping patron_intimate grinding lap_dance mutual_touching patron_grinding patron_lap_dance patron_mutual_touching patron_moment_pose_dance');
  const 무릎뒤밀착 = 목록('patron_groping_lap patron_intimate_lap patron_moment_sit_on_lap patron_lap_dance lap_dance');
  const 합치기 = (...sets) => new Set(sets.flatMap(set => [...set]));
  return new Map([
    ['standing', 목록('idle greeting taking_order serving cleaning cooking bathing at_market away bath_attendant patron_flirting kissing groped_ass groped_tits bath_attendant_wash_chest bath_attendant_wash_body bath_with_patron patron_touching patron_bold patron_groping patron_intimate grinding lap_dance mutual_touching breast_worship patron_grinding patron_lap_dance patron_mutual_touching patron_breast_worship patron_moment_cleavage patron_moment_flash_tits patron_moment_lift_skirt patron_moment_show_tongue patron_moment_twirl patron_moment_pose_dance patron_rubbing patron_rubbing_finish patron_rubbing_climax thigh_job patron_thigh_job standing_sex patron_standing_sex')],
    ['sitting', 목록('patron_chatting patron_flirting kissing groped_ass groped_tits bath_attendant bath_attendant_wash_chest bath_attendant_wash_body bath_with_patron patron_touching patron_bold patron_groping patron_groping_lap patron_intimate patron_intimate_lap fingered grinding lap_dance mutual_touching breast_worship anal_fingering patron_grinding patron_lap_dance patron_mutual_touching patron_breast_worship patron_moment_cleavage patron_moment_flash_tits patron_moment_lift_skirt patron_moment_sit_on_lap patron_moment_show_tongue patron_rubbing patron_rubbing_finish patron_rubbing_climax thigh_job patron_thigh_job patron_self_stroke')],
    ['kneeling', 합치기(구강성교, 손자극, 가슴자극, 목록('facial patron_facial breast_worship patron_breast_worship'))],
    ['lying-back', 합치기(일반성관계, 항문성교, 여성기구강, 목록('passed_out resting sleeping self_pleasure fingered anal_fingering patron_intimate patron_intimate_lap finish_on_stomach finish_on_chest'))],
    ['all-fours', 합치기(일반성관계, 항문성교, 목록('fingered anal_fingering finish_on_back'))],
    ['close-embrace', 마주밀착],
    ['back-hug', 뒤밀착],
    ['lap-back-hug', 무릎뒤밀착],
    ['missionary', 합치기(일반성관계, 항문성교)],
    ['cowgirl', 합치기(일반성관계, 목록('riding patron_riding'))],
    ['reverse-cowgirl', 합치기(일반성관계, 목록('riding patron_riding'))],
    ['doggystyle', 합치기(일반성관계, 항문성교)],
    ['spooning', 합치기(일반성관계, 항문성교)],
    ['standing-sex', 합치기(일반성관계, 항문성교, 목록('standing_sex patron_standing_sex'))],
    ['mating-press', 합치기(일반성관계, 항문성교)],
    ['prone-bone', 합치기(일반성관계, 항문성교)],
    ['ekiben', 합치기(일반성관계, 항문성교)],
    ['daisuki-hold', 합치기(일반성관계, 항문성교)],
    ['full-nelson', 합치기(일반성관계, 항문성교)],
    ['double-penetration', 합치기(일반성관계, 항문성교)],
    ['kneeling-fellatio', 구강성교],
    ['deep-throat', 구강성교],
    ['irrumatio-front', 구강성교],
    ['upside-down-facefuck', 구강성교],
    ['cunnilingus', 여성기구강],
    ['sixty-nine', 목록('sixty_nine')],
    ['seated-handjob', 손자극],
    ['paizuri', 가슴자극],
  ]);
})();

function ImageStudio_자세상황에맞는가(presetId, imageKey) {
  if (!presetId || presetId === 'auto') return true;
  const part = String(imageKey || '').split('__').find(value => /^(?:scene|task)-/.test(value));
  const situation = part?.replace(/^(?:scene|task)-/, '') || '';
  if (!situation || !ImageStudio_자세상황목록.get(presetId)?.has(situation)) return false;
  if (presetId === 'double-penetration') {
    const count = Math.max(0, Math.min(5, Number(String(imageKey).match(/(?:^|__|\|)grp-(\d+)/)?.[1]) || 0));
    const rawSlots = String(imageKey).match(/(?:^|__|\|)gslot-([mhbxriaw]+)/)?.[1] || '';
    const slots = count && rawSlots.length === count ? rawSlots : '';
    if (!slots) return false;
    return /^(?:patron_)?anal(?:_|$)/.test(situation) ? slots.includes('i') : slots.includes('a');
  }
  return true;
}

// 공통 확장 계약 v1. 상황 조회와 프롬프트 조립은 동기 함수이며 게임 상태를 변경하지 않습니다.
function ImageStudio_확장등록창구만들기(api) {
  const contexts = new Map();
  const providers = new Map();
  const adapters = new Map();
  const plans = new WeakMap();
  let editor = null;
  let review = null;
  let planning = null;

  // 같은 ID의 이중 등록은 로드 순서에 따라 결과가 달라지므로 즉시 거부합니다.
  function ImageStudio_확장등록하기(target, definition, method) {
    if (!definition || !/^[a-z][a-z0-9_-]+$/.test(definition.id || '') || typeof definition[method] !== 'function') {
      throw Error('ImageStudio 확장 ID 또는 함수가 올바르지 않습니다: ' + method);
    }
    if (target.has(definition.id)) throw Error('ImageStudio 확장 ID 중복: ' + definition.id);
    target.set(definition.id, definition);
    globalThis.WW_ImageStudioMatching?.refresh?.();
    return () => { target.delete(definition.id); globalThis.WW_ImageStudioMatching?.refresh?.(); };
  }
  function ImageStudio_확장키정규화하기(key) {
    let result = ImageStudio_노출키정규화하기(key);
    for (const adapter of adapters.values()) {
      result = adapter.normalize(result);
      if (typeof result !== 'string') throw Error('이미지 키 어댑터는 문자열을 반환해야 합니다: ' + adapter.id);
    }
    return ImageStudio_노출키정규화하기(result);
  }
  function ImageStudio_확장맥락읽기(key, character, room) {
    const planned = editor?.planningContext?.();
    const state = planned?.state || api.store.game();
    const value = {
      version: 1, mode: planning ? 'planning' : 'live', key, character: planned?.character || character,
      room, state, selection: planning?.combination || {}, archetypeId: planning?.archetypeId,
    };
    const situations = {};
    for (const source of contexts.values()) {
      const situation = source.read(Object.freeze({ ...value }));
      if (situation && typeof situation.then === 'function') throw Error('상황 조회는 동기 함수여야 합니다: ' + source.id);
      situations[source.id] = situation;
    }
    return Object.freeze({ ...value, situations: Object.freeze(situations) });
  }
  function ImageStudio_확장프롬프트적용하기(result, character, room) {
    if (!result?.key) return result;
    const context = ImageStudio_확장맥락읽기(result.key, character, room);
    let value = result;
    for (const provider of [...providers.values()].sort((left, right) => (left.priority || 0) - (right.priority || 0) || left.id.localeCompare(right.id))) {
      const next = provider.compose(value, context);
      if (next && typeof next.then === 'function') throw Error('프롬프트 조립은 동기 함수여야 합니다: ' + provider.id);
      if (next !== undefined) value = next;
    }
    value = { ...value, key: ImageStudio_확장키정규화하기(value.key) };
    if (planning) planning.result = value;
    return value;
  }
  function ImageStudio_확장축읽기() {
    const axes = [...(editor?.axes?.() || [])];
    for (const provider of providers.values()) axes.push(...(provider.axes?.() || []));
    const ids = axes.map(axis => axis.id);
    if (new Set(ids).size !== ids.length) throw Error('ImageStudio 확장 조건 ID 중복');
    return axes;
  }
  // 편집기의 원래 조합 객체를 보존하여 WeakMap에 보관된 설정 스냅샷도 유지합니다.
  function ImageStudio_확장조합공간읽기(selected = {}) {
    const base = editor?.combinationSpace?.(selected) || { count: 1n, at: () => ({}) };
    const dimensions = [];
    for (const provider of providers.values()) for (const axis of provider.axes?.() || []) {
      const available = new Set(axis.items.map(item => String(item.value)));
      const choices = [...new Set(selected[axis.id] || [axis.defaultValue || 'auto'])];
      if (!choices.length || choices.some(choice => !available.has(String(choice)))) throw Error('확장 생성 조건 오류: ' + axis.id);
      dimensions.push({ id: axis.id, choices });
    }
    const extraCount = dimensions.reduce((total, axis) => total * BigInt(axis.choices.length), 1n);
    return { count: base.count * extraCount, at(index) {
      index = BigInt(index);
      if (index < 0n || index >= base.count * extraCount) throw Error('확장 조합 인덱스 범위 오류');
      const original = base.at(index / extraCount);
      const combination = { ...original };
      let extra = index % extraCount;
      for (const axis of [...dimensions].reverse()) {
        combination[axis.id] = axis.choices[Number(extra % BigInt(axis.choices.length))];
        extra /= BigInt(axis.choices.length);
      }
      plans.set(combination, original);
      return combination;
    } };
  }
  function ImageStudio_확장계획만들기(build, combination = {}, archetypeId) {
    const previous = planning;
    const scope = { combination, archetypeId, result: null, baseKey: null };
    planning = scope;
    try {
      const context = ImageStudio_확장맥락읽기('', null, null);
      for (const provider of providers.values()) {
        if (typeof provider.valid !== 'function') continue;
        const valid = provider.valid(context);
        if (valid && typeof valid.then === 'function') throw Error('생성 조합 검사는 동기 함수여야 합니다: ' + provider.id);
        if (valid === false) return [];
      }
      const items = editor?.plan ? editor.plan(build, plans.get(combination) || combination, archetypeId) : build();
      if (!scope.result) return items;
      const result = scope.result;
      return items.map(item => ({ ...item, ImageStudioBaseKey: scope.baseKey || item.talentId, talentId: result.key, prompt: result.prompt, negativePrompt: result.negativePrompt,
        ImageStudioParts: result.parts, ...result.genParams,
        debug: { ...item.debug, imageMatching: globalThis.WW_ImageStudioMatching?.metadata?.(result.key) || item.debug?.imageMatching } }));
    } finally { planning = previous; }
  }
  function ImageStudio_편집기등록하기(definition) {
    if (editor) throw Error('공통 프롬프트 편집기가 이미 등록되어 있습니다: ' + editor.id);
    if (!definition?.id || typeof definition.render !== 'function') throw Error('공통 프롬프트 편집기 등록 형식 오류');
    editor = definition;
    return () => { if (editor === definition) editor = null; };
  }
  function ImageStudio_기본매칭맥락읽기(key, suppliedCharacter) {
    const state = api.store.game();
    const character = suppliedCharacter || state?.characters?.[state.primaryCharacterId];
    if (!character) return null;
    // 표정 태그 편집을 끈 경우에도 실제 감정은 매칭의 공통 입력으로 유지합니다.
    const emotions = api.fn('topFeelings')(character, 2)
      .filter(feeling => Number(feeling.intensity) > 15).map(feeling => feeling.emotion);
    return { version: 1, emotions: [...new Set(emotions)].sort(), badguest: null, pregnancy: null, detail: null };
  }
  const extensions = {
    version: 1,
    positionApplicable: ImageStudio_자세상황에맞는가,
    registerContextProvider: definition => ImageStudio_확장등록하기(contexts, definition, 'read'),
    registerPromptProvider: definition => ImageStudio_확장등록하기(providers, definition, 'compose'),
    registerKeyAdapter: definition => ImageStudio_확장등록하기(adapters, definition, 'normalize'),
    registerEditor: ImageStudio_편집기등록하기,
    normalizeKey: ImageStudio_확장키정규화하기,
    normalizeMatchingContext: context => editor?.upgrades?.normalizeMatchingContext?.(context) || context,
    compose: ImageStudio_확장프롬프트적용하기,
    context: ImageStudio_확장맥락읽기,
    setReview: value => { review = value; },
    get editor() { return editor; },
    get review() { return review; },
    list: () => ({ version: 1, editor: editor?.id || null, contexts: [...contexts.keys()], prompts: [...providers.keys()], keys: [...adapters.keys()] }),
  };
  // 이전 호환 모드가 사용하는 전역 API도 같은 등록 창구를 통하도록 유지합니다.
  globalThis.WW_ImageStudioPrompt = {
    open: () => review.open(), generate: request => review.generate(request), refresh: () => review.refresh(),
    isBusy: () => review?.isBusy?.() || false,
    axes: ImageStudio_확장축읽기,
    combinationSpace: ImageStudio_확장조합공간읽기,
    combinations: selected => {
      const space = ImageStudio_확장조합공간읽기(selected);
      if (space.count > 120000n) throw Error('세부 조건 조합이 120,000개를 넘었습니다.');
      return Array.from({ length: Number(space.count) }, (_, index) => space.at(BigInt(index)));
    },
    plan: ImageStudio_확장계획만들기,
    positionApplicable: ImageStudio_자세상황에맞는가,
    matchingContext: (key, character) => editor?.matchingContext?.(key, character) || ImageStudio_기본매칭맥락읽기(key, character),
    get embeddedVersion() { return editor?.embeddedVersion || null; },
  };
  api.hook('imagePrompt', { priority: -500000, after(result, [character, room]) {
    return ImageStudio_확장프롬프트적용하기(result, character, room);
  } });
  api.hook('imageKey', { priority: -500000, after(result, [character, room]) {
    if (typeof result !== 'string') return;
    if (planning && !planning.baseKey) planning.baseKey = result;
    const context = ImageStudio_확장맥락읽기(result, character, room);
    for (const provider of [...providers.values()].sort((left, right) => (left.priority || 0) - (right.priority || 0) || left.id.localeCompare(right.id))) {
      if (provider.key) result = provider.key(result, context);
    }
    return ImageStudio_확장키정규화하기(result);
  } });
  return extensions;
}

// 게임의 xy → Kee → Jee와 같은 우선순위입니다. 탈의가 하위 단계를 포함하며 팬티 제거는 옆으로 젖힘보다 우선합니다.
// 기본 상태는 exp 키를 생략하므로 빈 문자열을 반환합니다. 잘못된 형식은 보정하지 않고 기존 검증에 넘깁니다.
function ImageStudio_노출코드정규화하기(value) {
  if(!value||value==='none'||value==='0000000')return '';
  if(!/^[01]{7}$/.test(value))return value;
  const top=value[2]==='1'?'011':value[1]==='1'?'010':value[0]==='1'?'100':'000';
  const skirt=value[4]==='1'?'11':value[3]==='1'?'10':'00';
  const panties=value[6]==='1'?'01':value[5]==='1'?'10':'00';
  return top+skirt+panties;
}
function ImageStudio_노출키정규화하기(key) {
  if(typeof key!=='string')return key;
  return key.replace(/__exp-([01]{7})(?=__|$)/g,(_,code)=>{
    const normalized=ImageStudio_노출코드정규화하기(code);
    return normalized?'__exp-'+normalized:'';
  });
}


// 각 모드에 포함되는 설정 UI. 게임 HTML의 메뉴와 DOM만 사용합니다.
(() => {
  if (globalThis.__waywardPauseSettingsUiFactory?.version === 1) return;
  const entries = new Map(), windows = new Map();
  const legacyButtons = '[data-wc2-preg-menu],[data-wc2-customer-menu],.ww-brothel-menu-button,[data-bad-guest-settings-launch],[data-ww-image-studio-menu]';
  let queued = false, theme = null;
  const cssValues = new Map(), cssProbe = document.createElement('div').style;

  function ModNativeUI_요소만들기(tag, props, ...children) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(props || {})) {
      if (value == null || value === false) continue;
      if (key === 'class') node.className = value;
      else if (key === 'style') node.style.cssText = value;
      else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2).toLowerCase(), value);
      else if (key in node && key !== 'list') node[key] = value;
      else node.setAttribute(key, value === true ? '' : String(value));
    }
    for (const child of children.flat()) if (child != null && child !== false) node.append(child.nodeType ? child : String(child));
    return node;
  }
  // WML 0.9.5 owns pause-menu placement through api.ui.pauseSettings.
  function ModNativeUI_메뉴찾기() { return []; }
  function ModNativeUI_스타일지정하기(node, property, value) {
    const key = property + ':' + value;
    if (!cssValues.has(key)) { cssProbe.setProperty(property, value); cssValues.set(key, cssProbe.getPropertyValue(property)); }
    if (node.style.getPropertyValue(property) !== cssValues.get(key) || node.style.getPropertyPriority(property) !== 'important') node.style.setProperty(property, value, 'important');
  }
  function ModNativeUI_테마읽기(button) {
    const native = getComputedStyle(button || document.getElementById('root') || document.body);
    const channels = (native.backgroundColor.match(/[\d.]+/g) || [28, 25, 23]).slice(0, 3).map(Number);
    const luminance = Math.max(.09, Math.min(.22, (Math.max(...channels) + Math.min(...channels)) / 510));
    return { font: native.fontFamily || 'sans-serif', background: `hsl(32 52% ${Math.round(luminance * 100 + 4)}%)`,
      foreground: 'hsl(40 78% 88%)', border: 'hsl(32 55% 34%)', radius: native.borderRadius || '6px' };
  }
  function ModNativeUI_버튼색칠하기(button, settings) {
    const colors = theme = ModNativeUI_테마읽기(settings);
    for (const [key, value] of Object.entries({ background: colors.background, color: colors.foreground,
      'border-color': colors.border, 'border-width': '1px', 'border-style': 'solid', 'border-radius': colors.radius,
      width: '100%', padding: '8px 16px', 'font-family': colors.font, 'font-size': '14px', cursor: 'pointer' })) ModNativeUI_스타일지정하기(button, key, value);
  }
  function ModNativeUI_앞으로올리기(node) {
    ModNativeUI_스타일지정하기(node, 'z-index', '2147483647');
    if (node.parentElement === document.body && node.nextElementSibling) document.body.append(node);
  }
  function ModNativeUI_정리하기() {
    for (const { list, settings } of ModNativeUI_메뉴찾기()) {
      let anchor = settings;
      for (const [owner, entry] of entries) {
        const official = [...list.querySelectorAll('[data-wml-pause-entry]')].find(node => node.dataset.wmlPauseEntry === owner);
        if (official) {
          for (const old of [...list.children]) if (old !== official &&
            (old.dataset.waywardNativeSettings === owner || entry.legacyButton && old.matches(entry.legacyButton))) old.remove();
          anchor = official;
          continue;
        }
        let button = [...list.children].find(node => node.dataset.waywardNativeSettings === owner);
        if (!button && entry.legacyButton) button = list.querySelector(entry.legacyButton);
        if (!button) {
          button = ModNativeUI_요소만들기('button', { type: 'button', class: settings.className,
            'data-wayward-native-settings': owner, ...entry.attributes,
            class: `${settings.className} ${entry.attributes?.class || ''}`.trim() }, entry.label);
          button.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); entry.onClick?.();
            queueMicrotask(() => entry.windowSelector && document.querySelectorAll(entry.windowSelector).forEach(ModNativeUI_앞으로올리기)); });
          list.append(button);
        }
        button.dataset.waywardNativeSettings = owner;
        // 이 표시는 새 로더의 기존 버튼 정렬과도 같은 순서를 유지하게 합니다.
        // 구형 로더에서는 사용하지 않아도 HTML 메뉴가 직접 처리됩니다.
        button.dataset.wmlModSettings = owner;
        ModNativeUI_버튼색칠하기(button, settings);
        if (button.textContent !== entry.label) button.textContent = entry.label;
        if (anchor.nextElementSibling !== button) anchor.after(button);
        anchor = button;
      }
      const panel = list.parentElement;
      if (panel.style.maxHeight !== 'calc(100dvh - 32px)') panel.style.maxHeight = 'calc(100dvh - 32px)';
      if (panel.style.overflowY !== 'auto') panel.style.overflowY = 'auto';
    }
    for (const entry of entries.values()) if (entry.windowSelector) {
      for (const panel of document.querySelectorAll(entry.windowSelector)) {
        ModNativeUI_스타일지정하기(panel, 'z-index', '2147483647');
      }
    }
  }
  function ModNativeUI_정리예약하기() {
    if (queued) return;
    queued = true;
    queueMicrotask(() => { queued = false; ModNativeUI_정리하기(); });
  }
  function ModNativeUI_버튼만들기(label, onClick, options = {}) {
    return ModNativeUI_요소만들기('button', { type: 'button', class: 'wayward-native-button',
      title: options.title, disabled: options.disabled, onclick: onClick,
      style: options.primary ? 'background:#78350f;color:#fef3c7' : '' }, label);
  }
  function ModNativeUI_창열기(owner, options) {
    const id = `${owner}:${options.id || 'settings'}`;
    if (windows.has(id)) { const prior = windows.get(id); prior.focus(); return prior; }
    const colors = theme || ModNativeUI_테마읽기();
    const width = Math.min(options.width || 520, Math.max(280, innerWidth - 16));
    const height = Math.min(options.height || 440, Math.max(160, innerHeight - 16));
    const title = ModNativeUI_요소만들기('strong', {}, options.title || owner);
    const body = ModNativeUI_요소만들기('div', { class: 'wayward-native-window-body' });
    const node = ModNativeUI_요소만들기('section', { class: 'wayward-native-window', role: 'region',
      'aria-label': options.title || owner, 'data-wml-ui': owner, 'data-wayward-native-window': id,
      style: `left:${Math.max(8, (innerWidth - width) / 2)}px;top:${Math.max(8, (innerHeight - height) / 3)}px;width:${width}px;height:${height}px;font-family:${colors.font}` });
    let removeBack = null;
    function ModNativeUI_창닫기() { node.remove(); windows.delete(id); removeBack?.(); options.onClose?.(); }
    const bar = ModNativeUI_요소만들기('header', { class: 'wayward-native-window-title' }, title,
      ModNativeUI_버튼만들기('✕', ModNativeUI_창닫기, { title: '닫기' }));
    node.append(bar, body);
    const handle = { el: node, body, owner, close: ModNativeUI_창닫기,
      focus: () => {
        ModNativeUI_앞으로올리기(node); windows.delete(id); windows.set(id, handle);
        if (typeof options.onBack === 'function') {
          removeBack?.(); removeBack = options.onBack(() => { handle.close(); return true; });
        }
      }, setTitle: value => { title.textContent = value; },
      refresh: () => { body.replaceChildren(); options.render?.(body, handle); } };
    node.addEventListener('pointerdown', handle.focus);
    bar.addEventListener('pointerdown', event => {
      if (event.button !== 0 || event.target.closest('button')) return;
      event.preventDefault();
      const x = event.clientX - node.offsetLeft, y = event.clientY - node.offsetTop;
      const move = next => { node.style.left = Math.max(0, Math.min(innerWidth - 80, next.clientX - x)) + 'px'; node.style.top = Math.max(0, Math.min(innerHeight - 40, next.clientY - y)) + 'px'; };
      const stop = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', stop); };
      window.addEventListener('pointermove', move); window.addEventListener('pointerup', stop, { once: true });
    });
    windows.set(id, handle); document.body.append(node); handle.focus(); handle.refresh();
    return handle;
  }
  const style = ModNativeUI_요소만들기('style', { 'data-wayward-native-ui': '1' });
  style.textContent = `
    .wayward-native-window{position:fixed;display:flex;flex-direction:column;font-size:14px;max-width:calc(100vw - 16px);max-height:calc(100dvh - 16px);min-width:280px;min-height:160px;resize:both;overflow:hidden;background:#1c1917;color:#e7e5e4;border:1px solid #92400e;border-radius:9px;box-shadow:0 14px 44px #000c}
    .wayward-native-window-title{display:flex;align-items:center;gap:8px;padding:8px 10px;background:#292524;border-bottom:1px solid #44403c;cursor:move;touch-action:none}.wayward-native-window-title strong{flex:1;font-size:14px}.wayward-native-window-body{flex:1;overflow:auto;padding:12px}
    .wayward-native-button{border:1px solid #57534e;border-radius:6px;padding:6px 10px;background:#292524;color:#e7e5e4;cursor:pointer;font:inherit}.wayward-native-button:disabled{opacity:.45;cursor:default}
    .wayward-native-window .wml-muted{color:#a8a29e}.wayward-native-window .wml-note{color:#fde68a}.wayward-native-window .wml-small{font-size:12px}
    @media(max-width:640px){.wayward-native-window{left:8px!important;top:8px!important;width:calc(100vw - 16px)!important;height:calc(100dvh - 16px)!important;resize:none}}
  `;
  document.head.append(style);
  const observer = new MutationObserver(ModNativeUI_정리예약하기);
  observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'hidden', 'class'] });
  window.addEventListener('keydown', event => {
    if (event.key !== 'Escape' || !windows.size) return;
    [...windows.values()].at(-1).close(); event.preventDefault(); event.stopImmediatePropagation();
  }, true);
  window.addEventListener('pagehide', () => observer.disconnect(), { once: true });
  function ModNativeUI_연결하기(base, config) {
    const owner = config.id, raw = name => config.bindings?.[base.game]?.[name] || name;
    const resolve = name => {
      const candidate = raw(name);
      if (base.engine && candidate in base.engine) return candidate;
      return base.sym(name);
    };
    const registerMenu = options => { entries.set(owner, options); return base.ui.pauseSettings({ ...options, attributes: { ...options.attributes, 'data-wayward-native-settings': owner }, onClick: () => { options.onClick?.(); queueMicrotask(() => options.windowSelector && document.querySelectorAll(options.windowSelector).forEach(ModNativeUI_앞으로올리기)); } }); };
    const ui = { ...base.ui,
      h: ModNativeUI_요소만들기, button: ModNativeUI_버튼만들기,
      window: options => ModNativeUI_창열기(owner, { ...options, onBack: base.onBack }),
      settings: render => {
        base.ui.settings(render);
        registerMenu({ label: config.label, onClick: () => ModNativeUI_창열기(owner,
          { id: 'settings', title: config.label, render, onBack: base.onBack }) }); ModNativeUI_정리예약하기();
      },
      menuSettings: registerMenu,
    };
    const facade = { ...base, ui,
      fn: name => base.engine?.[resolve(name)], sym: resolve,
      has: name => { try { return !!resolve(name); } catch { return false; } },
      hook: (name, options) => base.hook(resolve(name), options),
      onBack: typeof base.onBack === 'function' ? base.onBack : () => () => {},
    };
    if (config.legacy) ui.menuSettings(config.legacy);
    return facade;
  }
  globalThis.__waywardPauseSettingsUiFactory = { version: 1, connect: ModNativeUI_연결하기 };
})();

// Fast loops can process up to 250 items before yielding; heavy prompts yield
// sooner after 40 ms so the cancel button and browser rendering stay responsive.
function ImageStudio_계산묶음만들기(report, signal) {
  let previous = 0, deadline = performance.now() + 40;
  const checkCancelled = () => { if (signal?.aborted) throw new DOMException('조합 계산을 취소했습니다.', 'AbortError'); };
  return completed => {
    checkCancelled();
    if (completed - previous < 250 && performance.now() < deadline) return null;
    report(completed);
    checkCancelled();
    previous = completed;
    // A message task avoids nested timers' minimum delay without prioritizing
    // our continuation above other mods' timers and UI events.
    const pause = typeof MessageChannel === 'function' ? new Promise(resolve => {
      const channel = new MessageChannel();
      channel.port1.onmessage = () => { channel.port1.close(); channel.port2.close(); resolve(); };
      channel.port2.postMessage(null);
    }) : new Promise(resolve => setTimeout(resolve, 0));
    return pause.then(() => {
      checkCancelled();
      deadline = performance.now() + 40;
    });
  };
}

// Shared task display. Counters come from completed work, never a timer.
function ImageStudio_진행표시만들기(content, overlay) {
  const tasks = new Map();
  let timer = null;
  const count = value => value == null ? null : BigInt(value);
  const number = value => value.toLocaleString('ko-KR');
  const duration = seconds => {
    seconds = Math.max(0, Math.floor(seconds));
    return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`;
  };
  function paint(kind) {
    const task = tasks.get(kind);
    const anchor = content.querySelector(kind === 'cache' ? '#wwis-cache-sync, #wwis-character-cache-sync' : '#wwis-h-status-enqueue, #wwis-enqueue-new')?.parentElement;
    if (!task || !anchor) return;
    let node = content.querySelector(`#wwis-${kind}-progress`);
    if (!node) {
      node = document.createElement('div');
      node.id = `wwis-${kind}-progress`;
      node.className = 'wwis-task-progress';
      node.innerHTML = '<strong data-title></strong><progress max="1000"></progress><div data-counts></div><div data-detail class="wwis-dim"></div><div data-time class="wwis-dim"></div>';
      anchor.after(node);
    }
    node.dataset.stage = task.stage;
    node.dataset.status = task.running ? 'running' : task.cancelled ? 'cancelled' : task.error ? 'error' : 'done';
    const setText = (selector, text) => { const target = node.querySelector(selector); if (target.textContent !== text) target.textContent = text; };
    setText('[data-title]', task.label);
    const current = count(task.current), total = count(task.total), unit = task.unit || '개';
    const bar = node.querySelector('progress');
    bar.setAttribute('aria-label', task.label);
    if (current !== null && total !== null) {
      const scaled = total > 0n ? Number(current * 1000n / total) : task.running ? 0 : 1000;
      bar.value = Math.max(0, Math.min(1000, scaled));
      const remaining = total > current ? total - current : 0n;
      setText('[data-counts]', `${number(current)} / ${number(total)}${unit} (${(bar.value / 10).toFixed(1)}%) · 남은 ${number(remaining)}${unit}`);
      node.dataset.current = String(current); node.dataset.total = String(total);
    } else {
      if (task.running) bar.removeAttribute('value'); else bar.value = 0;
      setText('[data-counts]', task.running ? '처리 건수를 확인하는 중…' : '');
      delete node.dataset.current; delete node.dataset.total;
    }
    setText('[data-detail]', task.detail || '');
    const now = task.finishedAt || performance.now();
    const elapsed = (now - task.startedAt) / 1000;
    const phaseElapsed = (now - task.stageStartedAt) / 1000;
    let eta = '';
    if (task.running && current > 0n && total > current && phaseElapsed >= 0.2) {
      const seconds = Number(total - current) / Number(current) * phaseElapsed;
      if (Number.isFinite(seconds) && seconds < 365 * 86400) eta = ` · 예상 남은 시간 ${duration(seconds)}`;
    }
    setText('[data-time]', `경과 ${duration(elapsed)}${eta}`);
  }
  function update(kind, next) {
    const previous = tasks.get(kind), now = performance.now();
    const continuing = previous?.running && !next.restart;
    tasks.set(kind, { ...next, running: true,
      startedAt: continuing ? previous.startedAt : now,
      stageStartedAt: continuing && previous.stage === next.stage ? previous.stageStartedAt : now });
    paint(kind);
    if (!timer) timer = setInterval(() => { if (!overlay.hidden) for (const key of tasks.keys()) paint(key); }, 500);
  }
  function finish(kind, detail, error = false, cancelled = false) {
    const task = tasks.get(kind);
    if (!task) return;
    Object.assign(task, { running: false, finishedAt: performance.now(), error, detail, cancelled,
      label: cancelled ? '조합 계산 · 취소됨' : error ? '처리 실패 · 마지막으로 확인한 진행 상태' : task.label + ' · 완료' });
    paint(kind);
    if (![...tasks.values()].some(item => item.running)) { clearInterval(timer); timer = null; }
  }
  return { update, finish, paint };
}

async function ImageStudio_캐시진행응답읽기(response, onProgress) {
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `HTTP ${response.status}`);
  }
  if (!response.headers.get('Content-Type')?.includes('application/x-ndjson')) {
    onProgress({ phase: 'legacy' });
    return response.json();
  }
  const reader = response.body.getReader(), decoder = new TextDecoder();
  let pending = '', result = null;
  const line = value => {
    if (!value.trim()) return;
    const event = JSON.parse(value);
    if (event.type === 'error') throw new Error(event.error);
    if (event.type === 'progress') onProgress(event);
    else if (event.type === 'result') result = event.result;
  };
  try {
    while (true) {
      const chunk = await reader.read();
      pending += decoder.decode(chunk.value || new Uint8Array(), { stream: !chunk.done });
      let newline;
      while ((newline = pending.indexOf('\n')) >= 0) { line(pending.slice(0, newline)); pending = pending.slice(newline + 1); }
      if (chunk.done) break;
    }
    line(pending);
    if (!result) throw new Error('캐시 초기화의 완료 응답을 받지 못했습니다. 서버 상태를 확인해 주세요.');
    return result;
  } catch (error) { await reader.cancel().catch(() => {}); throw error; }
  finally { reader.releaseLock(); }
}

// 공통 검수·저장 UI. 편집기는 확장 등록 창구에서 선택적으로 연결합니다.
async function ImageStudio_서버지원오류읽기(baseUrl, feature) {
  let version = '';
  try {
    const response = await fetch(String(baseUrl).replace(/\/+$/, '') + '/api/image/health', { credentials: 'omit', signal: AbortSignal.timeout(2500) });
    const health = await response.json();
    if (typeof health.version === 'string') version = ` · 서버 ${health.version}`;
  } catch { /* 연결된 주소와 정확한 실행 파일은 계속 안내합니다. */ }
  return `${feature} API를 지원하지 않는 서버에 연결되어 있습니다.\n연결 주소: ${baseUrl}${version}\n실행 파일: wml\\mods\\imagestudio\\Start_ImageStudio.cmd\n진행 중인 생성이 끝난 뒤 공통 서버 0.7.2로 다시 실행하고 창을 열어 주세요.`;
}
function ImageStudio_프롬프트검수연결하기(api) {
  const host = globalThis.WW_ImageStudioPrompt;
  let panel = null, editorRoot = null, reviewRoot = null, currentDraft = '', drafts = [], directory = '', generating = false;
  let selectedRequest = null, generationEpoch = 0;
  let preparation = null;
  const h = api.ui.h;
  const style = h('style', { 'data-imagestudio-prompt-review-style': '' });
  style.textContent = `.wwis-prompt-layout{display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:16px;align-items:start;max-width:100%}.wwis-prompt-editor{min-width:0;overflow-wrap:anywhere}.wwis-review{min-width:0;position:sticky;top:0;border:1px solid #92400e;border-radius:8px;padding:12px;background:#151312;box-sizing:border-box}.wwis-review input,.wwis-review textarea,.wwis-review select{box-sizing:border-box;width:100%;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:5px;padding:6px;font:12px/1.4 sans-serif}.wwis-review textarea{resize:vertical;min-height:80px}.wwis-review label{display:grid;gap:4px;margin:8px 0}.wwis-review img{display:block;width:100%;max-height:440px;object-fit:contain;background:#0c0a09;margin:10px 0}.wwis-review-actions{display:grid;grid-template-columns:1fr 1fr 1.7fr;gap:5px}.wwis-review-actions button{min-width:0;font-size:12px;padding:7px 3px}.wwis-review-note{font-size:12px;white-space:pre-line;overflow-wrap:anywhere;color:#d6d3d1}@media(max-width:900px){.wwis-prompt-layout{grid-template-columns:1fr}.wwis-review{position:static}.wwis-prompt-editor main{flex-basis:100%!important}.wwis-prompt-editor aside{width:100%!important;max-width:100%!important}.wwis-review img{max-height:50vh}}`;
  style.textContent += '.wwis-review img[hidden]{display:none}.wwis-review summary{cursor:pointer;margin:8px 0;color:#fbbf24}.wwis-specific-builder[hidden]{display:none}.wwis-specific-builder{margin:8px 0;padding:8px;border:1px solid #44403c;border-radius:6px;background:#0c0a09}.wwis-specific-builder fieldset{border:1px solid #292524;border-radius:5px;margin:8px 0;padding:5px 8px}.wwis-specific-builder legend{color:#fbbf24;font-size:12px;padding:0 4px}.wwis-specific-builder label{font-size:11px}.wwis-specific-builder button{width:100%;margin-top:7px}';
  document.head.append(style);

  function ImageStudio_서버읽기() {
    const backend = globalThis.WW_ImageStudioBridge?.connection?.();
    if (!backend?.baseUrl) throw Error('이미지 서버를 연결한 뒤 검수용 생성을 사용하세요.');
    return String(backend.baseUrl).replace(/\/+$/, '');
  }
  async function ImageStudio_서버요청하기(route, method = 'GET', body) {
    const response = await fetch(ImageStudio_서버읽기() + route, { method, credentials: 'omit',
      headers: body ? { 'Content-Type': 'application/json' } : {}, ...(body ? { body: JSON.stringify(body) } : {}) });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw Error(response.status === 404 ? await ImageStudio_서버지원오류읽기(ImageStudio_서버읽기(), '검수') : data.error || `HTTP ${response.status}`);
    return data;
  }
  function ImageStudio_메시지보이기(message) {
    const note = reviewRoot?.querySelector('[data-wwis-review-message]');
    if (note) note.textContent = message;
  }
  function ImageStudio_현재장면읽기() {
    const state = api.store.game();
    if (!state) return null;
    const character = api.fn('wife')(state);
    const room = api.fn('imageRoom')(api.fn('wifeLocation')(state));
    return api.fn('imagePrompt')(character, room);
  }
  function ImageStudio_입력채우기(request) {
    if (!reviewRoot || !request) return;
    selectedRequest = { ...request };
    reviewRoot.querySelector('[data-wwis-review-key]').value = request.imageKey || request.key || '';
    reviewRoot.querySelector('[data-wwis-review-positive]').value = request.prompt || '';
    reviewRoot.querySelector('[data-wwis-review-negative]').value = request.negativePrompt || '';
  }
  function ImageStudio_특정장면폼만들기(current) {
    const bridge = globalThis.WW_ImageStudioBridge;
    const baseAxes = bridge?.axes?.() || {};
    const promptAxes = host.axes?.() || [];
    const currentAxes = bridge?.keyAxes?.(current?.key || current?.imageKey || '') || {};
    const currentWife = bridge?.currentWife?.();
    const characters = bridge?.characters?.().characters || [];
    const characterItems = characters.length
      ? characters.map(character => ({ value: character.id, label: character.name || character.id }))
      : (baseAxes.character || []);
    const specialSituations = [
      { value: '__imagestudio_h_status_blank', label: 'H_Status 이미지 생성(빈거)', kind: 'special', baseSituation: 'idle' },
      { value: '__imagestudio_life_birth', label: '출산 장면', kind: 'special', baseSituation: 'idle', lifeEvent: 'birth' },
      { value: '__imagestudio_life_discussion', label: '아이 처치 상의', kind: 'special', baseSituation: 'idle', lifeEvent: 'child_discussion' },
      { value: '__imagestudio_life_adoption', label: '입양 장면', kind: 'special', baseSituation: 'idle', lifeEvent: 'child_adoption' },
      { value: '__imagestudio_life_parents', label: '부모님께 맡기는 장면', kind: 'special', baseSituation: 'idle', lifeEvent: 'child_parents' },
    ];
    const groups = new Map([
      ['character', { label: '캐릭터', axes: [] }], ['outfit', { label: '의상', axes: [] }],
      ['place', { label: '장소', axes: [] }], ['scene', { label: '장면', axes: [] }],
      ['emotion', { label: '감정 상태', axes: [] }],
    ]);
    const baseDefinitions = [
      { id: 'character', label: "여성 캐릭터", items: characterItems },
      { id: 'mood', label: '기분', items: baseAxes.mood || [] },
      { id: 'outfit', label: '의상', items: baseAxes.outfit || [] },
      { id: 'exposure', label: '의상 및 노출 상태', items: baseAxes.exposure || [] },
      { id: 'room', label: '장소', items: baseAxes.room || [] },
      { id: 'aftermath', label: '장소에 남은 체액 흔적', items: baseAxes.aftermath || [] },
      { id: 'situation', label: '장면 / 작업', items: [...(baseAxes.situation || []), ...specialSituations] },
      { id: 'men', label: '남성 수 프롬프트', items: baseAxes.men || [] },
      { id: 'roles', label: '남성별 역할 조합', items: baseAxes.roles || [] },
    ];
    const baseGroup = id => ['character', 'mood'].includes(id) ? 'character'
      : ['outfit', 'exposure'].includes(id) ? 'outfit' : ['room', 'aftermath'].includes(id) ? 'place' : 'scene';
    for (const axis of baseDefinitions) groups.get(baseGroup(axis.id)).axes.push({ ...axis, kind: 'base' });
    const promptGroup = axis => axis.id === 'promptPregnancy' ? 'character'
      : axis.id === 'promptResidue' || axis.group === 'badguest' && axis.family !== 'badguest.drugged' ? 'outfit'
      : axis.id === 'promptConsent' || axis.group === 'detail' || axis.family === 'badguest.drugged' ? 'emotion' : 'scene';
    for (const axis of promptAxes) {
      if (axis.id === 'promptLifeEvent') continue;
      groups.get(promptGroup(axis)).axes.push({ ...axis, kind: 'prompt' });
    }
    const controls = [];
    const fieldsets = [];
    const defaultValue = axis => axis.id === 'character' ? currentWife || currentAxes.character
      : axis.id === 'men' ? currentAxes.men || '0'
      : axis.id === 'roles' ? currentAxes.roles || '' : axis.kind === 'base' ? currentAxes[axis.id] : 'auto';
    for (const [groupId, group] of groups) {
      const fields = [];
      for (const axis of group.axes) {
        if (!axis.items?.length) continue;
        const select = h('select', { 'data-wwis-specific-axis': axis.id, 'data-wwis-specific-kind': axis.kind });
        for (const item of axis.items) select.append(h('option', { value: item.value, title: item.description || '' }, item.label || item.value));
        const initial = defaultValue(axis);
        if ([...select.options].some(option => option.value === String(initial))) select.value = String(initial);
        controls.push({ axis, select });
        fields.push(h('label', {}, axis.label, select));
      }
      if (fields.length) fieldsets.push(h('fieldset', { 'data-wwis-specific-group': groupId }, h('legend', {}, group.label), ...fields));
    }
    const situationControl = controls.find(control => control.axis.id === 'situation')?.select;
    const menControl = controls.find(control => control.axis.id === 'men')?.select;
    const rolesControl = controls.find(control => control.axis.id === 'roles')?.select;
    const ImageStudio_남성역할선택갱신하기 = () => {
      if (!rolesControl) return;
      const roleCount = Math.max(0, Number(menControl?.value || 0) - 1);
      for (const option of rolesControl.options) option.disabled = roleCount < 1 || [...option.value].length !== roleCount;
      rolesControl.disabled = roleCount < 1;
      if (roleCount > 0 && rolesControl.selectedOptions[0]?.disabled) {
        const available = [...rolesControl.options].find(option => !option.disabled);
        if (available) rolesControl.value = available.value;
      }
    };
    let menChanged = false;
    menControl?.addEventListener('change', () => { menChanged = true; ImageStudio_남성역할선택갱신하기(); });
    situationControl?.addEventListener('change', () => {
      if (menChanged || !menControl) return;
      const special = specialSituations.find(item => item.value === situationControl.value);
      const item = special || baseAxes.situation?.find(entry => entry.value === situationControl.value);
      const solo = item?.kind === 'task' || item?.kind === 'special' || ['self_pleasure', 'bath_solo'].includes(situationControl.value);
      if ([...menControl.options].some(option => option.value === (solo ? '0' : '1'))) menControl.value = solo ? '0' : '1';
      ImageStudio_남성역할선택갱신하기();
    });
    ImageStudio_남성역할선택갱신하기();
    const message = h('p', { class: 'wwis-review-note', role: 'status', 'data-wwis-specific-message': '' },
      '자동 자세는 장면에 맞는 후보를 같은 확률로 하나 고릅니다. 맞는 후보가 없으면 게임의 기존 자세를 유지합니다.');
    const conflicts = h('p', {
      class: 'wwis-review-note', hidden: true, 'data-wwis-specific-conflicts': '',
      style: 'color:#fb923c;white-space:pre-line;margin-top:4px;',
    });
    const showConflicts = reasons => {
      const items = [...new Set((reasons || []).map(reason => String(reason || '').trim()).filter(Boolean))];
      conflicts.textContent = items.map(reason => `• ${reason}`).join('\n');
      conflicts.hidden = !items.length;
    };
    const form = h('div', { class: 'wwis-specific-builder', hidden: true, 'data-wwis-specific-builder': '' }, ...fieldsets, message, conflicts);
    form.append(api.ui.button('선택한 조건으로 프롬프트 만들기', () => {
      try {
        showConflicts([]);
        const value = id => controls.find(control => control.axis.id === id)?.select.value || '';
        const wife = value('character');
        if (!wife) throw Error("여성 캐릭터를 선택하세요.");
        const selected = {};
        for (const { axis, select } of controls.filter(control => control.axis.kind === 'base' && !['character', 'situation'].includes(control.axis.id))) selected[axis.id] = [select.value];
        const special = specialSituations.find(item => item.value === value('situation'));
        const baseSituation = special?.baseSituation || value('situation');
        selected.situation = [baseSituation];
        const selectedPosition = value('promptPosition');
        const men = Number(value('men'));
        if (selectedPosition === 'double-penetration' && men < 2) throw Error('이중 삽입은 남성 수 프롬프트를 2명 이상으로 선택하세요.');
        const requiredRole = selectedPosition === 'double-penetration'
          ? (/^(?:patron_)?anal(?:_|$)/.test(baseSituation) ? 'i' : 'a') : '';
        const selectedRole = value('roles');
        if (men > 1 && !selectedRole) throw Error('남성별 역할 조합을 선택하세요.');
        if (requiredRole && !selectedRole.includes(requiredRole)) throw Error('이중 삽입 자세에 맞는 남성별 역할 조합을 선택하세요.');
        selected.roles = men > 1 ? [selectedRole] : (baseAxes.roles || []).map(item => String(item.value));
        selected.variant ||= ['0'];
        const promptSelected = Object.fromEntries(controls.filter(control => control.axis.kind === 'prompt')
          .map(({ axis, select }) => [axis.id, [select.value]]));
        if (special?.lifeEvent) promptSelected.promptLifeEvent = [special.lifeEvent];
        const details = host.combinationSpace(promptSelected);
        const space = bridge?.randomSpace?.(wife, selected);
        if (!space?.count) {
          const reasons = bridge?.selectionConflicts?.(wife, selected);
          showConflicts(reasons?.length ? reasons : ['선택한 기본 조건 사이에 게임이 지원하지 않는 조합이 있습니다.']);
          throw Error('이 조합으로 만들 수 있는 장면이 없습니다. 장면에 맞는 장소·의상·노출 상태를 선택하세요.');
        }
        const items = space.build(0n, details.at(0n));
        const item = items?.[0];
        if (!item) {
          showConflicts(bridge?.selectionConflicts?.(wife, selected));
          throw Error('선택한 조합의 프롬프트를 만들지 못했습니다. 조건을 확인하세요.');
        }
        const request = { ...item, imageKey: item.imageKey || item.key || item.talentId, talentId: item.talentId || item.key };
        ImageStudio_입력채우기(request);
        message.textContent = `프롬프트를 만들었습니다: ${request.imageKey}`;
      } catch (error) { message.textContent = String(error.message || error); }
    }));
    return form;
  }
  async function ImageStudio_검수목록갱신하기() {
    const data = await ImageStudio_서버요청하기('/api/studio/drafts');
    drafts = data.entries || []; directory = data.defaultDirectory || directory;
    if (!drafts.some(entry => entry.id === currentDraft)) currentDraft = drafts.at(-1)?.id || '';
    ImageStudio_검수선택보이기();
  }
  function ImageStudio_검수선택보이기() {
    if (!reviewRoot) return;
    const select = reviewRoot.querySelector('[data-wwis-review-select]');
    select.replaceChildren(...drafts.map((entry, index) => h('option', { value: entry.id }, `${index + 1}. ${entry.saved ? '저장 완료 · ' : ''}${entry.talentName}`)));
    if (!drafts.length) select.append(h('option', { value: '' }, '검수 대기 이미지 없음'));
    select.value = currentDraft;
    const entry = drafts.find(item => item.id === currentDraft), image = reviewRoot.querySelector('[data-wwis-review-image]');
    image.hidden = !entry;
    if (entry) { image.src = ImageStudio_서버읽기() + entry.imageUrl; image.alt = entry.talentName + ' · 검수 대기'; }
    else image.removeAttribute('src');
    for (const button of reviewRoot.querySelectorAll('[data-wwis-review-action]')) button.disabled = !entry || generating;
    reviewRoot.querySelector('[data-wwis-review-generate]').disabled = generating;
    if (entry?.saved) ImageStudio_메시지보이기(`저장 완료: ${entry.saved.absolutePath}`);
  }
  async function ImageStudio_검수생성하기(request) {
    if (generating) throw Error('검수용 이미지를 생성 중입니다.');
    const connection = globalThis.WW_ImageStudioBridge?.connection?.();
    if (!connection?.baseUrl || connection.comfyui !== true) throw Error('생성 가능한 이미지 서버를 연결하세요.');
    if (!request?.prompt?.trim()) throw Error('Positive 프롬프트를 입력하거나 현재 장면을 불러오세요.');
    generating = true; const epoch = ++generationEpoch;
    ImageStudio_입력채우기(request); ImageStudio_검수선택보이기(); ImageStudio_메시지보이기('검수용 이미지 생성 중… 승인 전에는 게임 이미지로 저장하지 않습니다.');
    try {
      // 편집기 버튼과 검수창 직접 입력이 같은 부위별 참조 설정을 사용합니다.
      const prepare = globalThis.WW_ImageStudioBridge?.extensions?.editor?.upgrades?.prepare;
      if (prepare) request = await prepare(request);
      const key = request.imageKey || request.key;
      if (!key) throw Error('이미지 키를 지정하세요.');
      const capability = await ImageStudio_서버요청하기('/api/studio/drafts');
      if (capability.supportsReviewDrafts !== true) throw Error('검수 전 저장 기능을 지원하는 서버로 다시 실행하세요.');
      if (request.referenceKey && capability.supportsImg2img !== true) throw Error('부위별 img2img를 지원하는 공통 서버 0.7.2로 재시작하세요.');
      let job = await ImageStudio_서버요청하기('/api/image/generate', 'POST', { ...request,
        debug: { ...request.debug, imageMatching: request.debug?.imageMatching || globalThis.WW_ImageStudioMatching?.metadata?.(key) },
        talentId: request.talentId || key, talentName: request.talentName || key, imageType: 'portrait',
        reviewOnly: true, bulk: true, bypassCache: false, promptHash: undefined, seed: request.seed ?? 1138 });
      const started = Date.now();
      while (['queued', 'processing'].includes(job.status)) {
        if (Date.now() - started > 20 * 60 * 1000) throw Error('생성 대기 시간이 길어졌습니다. 서버 검수 목록을 다시 확인하세요.');
        await new Promise(resolve => setTimeout(resolve, 1200));
        job = await ImageStudio_서버요청하기('/api/image/status/' + encodeURIComponent(job.promptId));
      }
      if (job.status !== 'completed' || !job.reviewOnly || !job.draftId) throw Error(job.error || '서버가 검수 전 저장 기능을 지원하지 않습니다. 포함된 서버로 다시 실행하세요.');
      currentDraft = job.draftId; await ImageStudio_검수목록갱신하기();
      ImageStudio_메시지보이기('생성 완료. 이미지를 확인한 뒤 저장하거나 삭제하세요.');
      return { draft: true, draftId: job.draftId, url: ImageStudio_서버읽기() + job.imageUrl };
    } catch (error) { ImageStudio_메시지보이기(String(error.message || error)); throw error; }
    finally { if (epoch === generationEpoch) generating = false; ImageStudio_검수선택보이기(); }
  }
  async function ImageStudio_선택그림저장하기(named = false) {
    const entry = drafts.find(item => item.id === currentDraft);
    if (!entry) return;
    let body = {};
    if (named) {
      const savedName = entry.talentName.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').slice(0, 120) + (entry.mime === 'image/webp' ? '.webp' : entry.mime === 'image/jpeg' ? '.jpg' : '.png');
      const pathInput = h('input', { 'data-wwis-review-directory': '', value: directory, placeholder: 'C:\\...\\images 또는 원하는 저장 폴더' });
      const nameInput = h('input', { 'data-wwis-review-filename': '', value: savedName });
      const form = h('div', { 'data-wwis-review-save-as': '' }, h('label', {}, '저장 경로 · 이미지 서버가 실행되는 PC', pathInput), h('label', {}, '파일 이름', nameInput));
      form.append(api.ui.button('지정한 경로에 저장', async () => {
        try {
          const result = await ImageStudio_서버요청하기('/api/studio/drafts/' + entry.id + '/save', 'POST', { directory: pathInput.value, filename: nameInput.value });
          form.remove(); await ImageStudio_검수목록갱신하기(); ImageStudio_메시지보이기(`저장 완료: ${result.absolutePath}`);
          api.fn('imagePackReset')?.();
        } catch (error) { ImageStudio_메시지보이기(String(error.message || error)); }
      }), api.ui.button('취소', () => form.remove()));
      reviewRoot.querySelector('[data-wwis-review-save-as]')?.remove(); reviewRoot.append(form); return;
    }
    try {
      const result = await ImageStudio_서버요청하기('/api/studio/drafts/' + entry.id + '/save', 'POST', body);
      await ImageStudio_검수목록갱신하기(); ImageStudio_메시지보이기(`승인 저장 완료: ${result.absolutePath}`); api.fn('imagePackReset')?.();
    } catch (error) { ImageStudio_메시지보이기(String(error.message || error)); }
  }
  function ImageStudio_검수창그리기(root) {
    let current = null;
    try { current = selectedRequest || ImageStudio_현재장면읽기(); } catch { /* 게임 시작 전에도 설정을 편집할 수 있습니다. */ }
    const key = h('input', { 'data-wwis-review-key': '', value: current?.imageKey || current?.key || '' });
    const positive = h('textarea', { 'data-wwis-review-positive': '', rows: 5, value: current?.prompt || '' });
    const negative = h('textarea', { 'data-wwis-review-negative': '', rows: 3, value: current?.negativePrompt || '' });
    for (const input of [key, positive, negative]) input.addEventListener('input', () => {
      selectedRequest = { ...selectedRequest, imageKey: key.value, prompt: positive.value, negativePrompt: negative.value };
    });
    const select = h('select', { 'data-wwis-review-select': '', onchange: event => { currentDraft = event.currentTarget.value; ImageStudio_검수선택보이기(); } });
    const specific = ImageStudio_특정장면폼만들기(current);
    root.replaceChildren(h('h3', {}, '검수창'),
      h('p', { class: 'wwis-review-note' }, '미저장 결과는 서버 RAM에 임시 보관합니다. 저장에 성공하면 원본 RAM과 검수 대기 항목을 정리합니다. 저장 파일은 유지되며, 서버를 종료하면 미저장 결과는 사라집니다.'),
      api.ui.button('현재 장면 프롬프트 불러오기', () => ImageStudio_입력채우기(ImageStudio_현재장면읽기())),
      api.ui.button('특정 장면 프롬프트 만들기', () => { specific.hidden = !specific.hidden; }),
      specific,
      h('details', {}, h('summary', {}, '생성 프롬프트와 이미지 키'), h('label', {}, '이미지 키', key), h('label', {}, '생성할 Positive', positive), h('label', {}, '생성할 Negative', negative)),
      h('button', { type: 'button', class: 'wayward-native-button', 'data-wwis-review-generate': '', onclick: async () => {
        try { await ImageStudio_검수생성하기({ ...selectedRequest, imageKey: key.value.trim(), prompt: positive.value, negativePrompt: negative.value }); } catch { /* 오류는 검수창에 표시합니다. */ }
      } }, '검수용 이미지 만들기'), h('label', {}, '검수 대기 이미지', select),
      h('img', { hidden: true, 'data-wwis-review-image': '' }),
      h('div', { class: 'wwis-review-actions' },
        h('button', { type: 'button', class: 'wayward-native-button', disabled: true, 'data-wwis-review-action': 'save', onclick: () => ImageStudio_선택그림저장하기() }, '저장'),
        h('button', { type: 'button', class: 'wayward-native-button', disabled: true, 'data-wwis-review-action': 'delete', onclick: async () => {
          try { await ImageStudio_서버요청하기('/api/studio/drafts/' + currentDraft, 'DELETE'); await ImageStudio_검수목록갱신하기(); ImageStudio_메시지보이기('검수 대기 이미지를 삭제했습니다. 이미 저장한 파일은 유지됩니다.'); } catch (error) { ImageStudio_메시지보이기(String(error.message || error)); }
        } }, '삭제'),
        h('button', { type: 'button', class: 'wayward-native-button', disabled: true, 'data-wwis-review-action': 'save-as', onclick: () => ImageStudio_선택그림저장하기(true) }, '다른 이름으로 저장')),
      h('p', { class: 'wwis-review-note', role: 'status', 'data-wwis-review-message': '' }, '검수용 이미지를 생성하세요.'));
    if (current) selectedRequest = { ...current };
    ImageStudio_검수목록갱신하기().catch(error => ImageStudio_메시지보이기(String(error.message || error)));
  }
  function ImageStudio_편집창열기() {
    if (panel && editorRoot?.isConnected) { panel.focus?.(); return panel; }
    preparation?.abort();
    const controller = new AbortController(); preparation = controller;
    panel = api.ui.window({ id: 'prompt-review', title: '프롬프트 편집 · 검수 · ImageStudio', width: 1450, height: 870,
      render(body, win) {
        let dirty = false, needsRefresh = false;
        const refreshed = new Set();
        const progress = h('p', { role: 'status', 'data-wwis-defaults-progress': '' }, '기본 프롬프트를 준비합니다. 편집과 창 닫기는 계속 사용할 수 있습니다.');
        editorRoot = h('section', { class: 'wwis-prompt-editor', 'data-wwis-prompt-editor': '' });
        reviewRoot = h('aside', { class: 'wwis-review', 'data-wwis-review': '' });
        const jump = h('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;' },
          api.ui.button('프롬프트 설정으로 이동', () => editorRoot.scrollIntoView({ block: 'start' })),
          api.ui.button('검수창으로 이동', () => reviewRoot.scrollIntoView({ block: 'start' })));
        body.replaceChildren(jump, progress, h('div', { class: 'wwis-prompt-layout' }, editorRoot, reviewRoot));
        const localEditor = editorRoot;
        localEditor.addEventListener('input', event => { if (event.target.matches('input,textarea')) dirty = true; });
        const editorWin = { ...win, refresh: () => {
          if (controller.signal.aborted || !localEditor.isConnected) return;
          dirty = false; needsRefresh = false;
          if (globalThis.WW_ImageStudioBridge.extensions.editor) globalThis.WW_ImageStudioBridge.extensions.editor.render(localEditor, editorWin);
          else localEditor.replaceChildren(h('p', {}, '공통 프롬프트 편집기를 사용하려면 imagestudio-compatible-attention-image-prompt를 켜세요. 생성·검수·저장은 이 창에서 계속 사용할 수 있습니다.'));
        } };
        const priority = () => { const select = localEditor.querySelector('[data-native-axis-prompt-source]'); return select ? { axis: select.dataset.nativeAxisPromptSource, id: select.value } : null; };
        const refreshIfSafe = () => {
          const active = document.activeElement;
          const editing = localEditor.contains(active) && active.matches('input,textarea,select,[contenteditable="true"]');
          if (needsRefresh && !dirty && !editing) editorWin.refresh();
        };
        localEditor.addEventListener('focusout', () => { setTimeout(refreshIfSafe, 0); });
        editorWin.refresh(); ImageStudio_검수창그리기(reviewRoot);
        const collect = globalThis.WW_ImageStudioBridge?.collectPromptDefaults;
        Promise.resolve(collect?.({ signal: controller.signal, priority, onProgress: status => {
          if (controller.signal.aborted || !localEditor.isConnected) return;
          progress.dataset.complete = String(status.complete);
          progress.textContent = status.complete ? status.failed ? '일부 기본 프롬프트를 준비하지 못했습니다.' : '기본 프롬프트 준비 완료'
            : `기본 프롬프트 준비 중 · ${status.done} / ${status.total} · 준비 중인 기본값은 잠시 비어 있을 수 있습니다. 입력한 내용은 유지됩니다.`;
          const selected = priority(), key = selected && `${selected.axis}:${selected.id}`;
          if (status.complete || status.priorityReady && !refreshed.has(key)) {
            if (key) refreshed.add(key);
            needsRefresh = true; refreshIfSafe();
          }
        } })).then(success => {
          if (!controller.signal.aborted && !success) progress.textContent = '기본 프롬프트 준비를 완료하지 못했습니다. 창을 다시 열어 재시도하세요.';
        }).catch(error => { if (!controller.signal.aborted) progress.textContent = '기본 프롬프트 준비 실패: ' + String(error.message || error); });
      }, onClose: () => { controller.abort(); if (preparation === controller) { preparation = null; panel = null; editorRoot = null; reviewRoot = null; } } });
    return panel;
  }
  const overlay = document.getElementById('wwis-overlay');
  overlay?.addEventListener('click', event => { if (event.target.closest('#wwis-prompt-edit')) ImageStudio_편집창열기(); });
  api.onBack(() => { if (!panel) return false; panel.close(); return true; });
  return { open: ImageStudio_편집창열기, generate: ImageStudio_검수생성하기, refresh: ImageStudio_검수목록갱신하기, isBusy: () => generating };
}

// 플레이 중 이미지 요구와 최종 게임 프롬프트를 새 게임별로 기록합니다.
function ImageStudio_사용통계연결하기(api) {
  const databaseName = 'wml.mod.imagestudio.usage';
  const sessions = new Map(), dirtySessions = new Set(), pending = [], startup = [], memoryEvents = [];
  let database = null, initialized = false, activeId = '', rendering = 0, timer = null, saving = Promise.resolve();
  let storageError = '', panel = null, body = null, selectedId = '', category = 'image', characterFilter = '', search = '', viewEpoch = 0;
  const h = api.ui.h;
  // 기존 사용자는 수집을 계속합니다. 끄더라도 이미 저장한 게임별 기록은 보존합니다.
  let usageEnabled = api.settings.get({ usageStatisticsEnabled: true }).usageStatisticsEnabled !== false;

  function ImageStudio_통계사용체크박스만들기() {
    return h('label', { class: 'wwis-usage-toggle' }, h('input', {
      type: 'checkbox', checked: usageEnabled, 'data-wwis-usage-enabled': '',
      onchange: event => {
        api.settings.set({ usageStatisticsEnabled: event.target.checked });
        usageEnabled = event.target.checked;
        ImageStudio_현재게임연결하기();
        // 재개 후 첫 요구는 중지 직전과 같은 이미지여도 새로운 요구로 집계합니다.
        const session = sessions.get(activeId);
        if (usageEnabled && session) {
          session.lastByCharacter = {}; dirtySessions.add(activeId);
        }
        void ImageStudio_사용기록저장하기().catch(() => {});
        void ImageStudio_통계화면그리기();
      },
    }), '이미지 사용 통계 사용');
  }

  function ImageStudio_기록식별자만들기() {
    return globalThis.crypto?.randomUUID?.() || Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
  }
  function ImageStudio_기록표식읽기(state) { return state?.mods?.imagestudio?.usageSession; }
  function ImageStudio_기록표식넣기(state, origin) {
    const marker = { id: ImageStudio_기록식별자만들기(), startedAt: new Date().toISOString(), origin };
    return { ...state, mods: { ...state.mods, imagestudio: { ...state.mods?.imagestudio, usageSession: marker } } };
  }
  function ImageStudio_저장오류알리기(error) {
    storageError = '브라우저 기록 저장 실패: ' + String(error?.message || error) + '. 미저장 기록은 이 창을 닫기 전에 JSON으로 저장하세요.';
    console.warn('[imagestudio] ' + storageError);
    body?.querySelector('[data-wwis-usage-status]')?.replaceChildren(storageError);
  }
  function ImageStudio_요청결과기다리기(request) {
    return new Promise((resolve, reject) => { request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error); });
  }
  function ImageStudio_트랜잭션기다리기(transaction) {
    return new Promise((resolve, reject) => { transaction.oncomplete = resolve; transaction.onabort = () => reject(transaction.error || Error('기록 트랜잭션 중단')); transaction.onerror = () => {}; });
  }
  async function ImageStudio_기록저장소열기() {
    try {
      const request = indexedDB.open(databaseName, 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        db.createObjectStore('sessions', { keyPath: 'id' });
        const events = db.createObjectStore('events', { keyPath: 'id' });
        events.createIndex('sessionId', 'sessionId');
      };
      request.onblocked = () => ImageStudio_저장오류알리기(Error('다른 게임 창이 기록 저장소를 사용 중입니다'));
      database = await ImageStudio_요청결과기다리기(request);
      database.onversionchange = () => { database.close(); ImageStudio_저장오류알리기(Error('기록 저장소가 변경되었습니다. 게임을 새로고침하세요')); };
      const transaction = database.transaction('sessions', 'readonly');
      for (const session of await ImageStudio_요청결과기다리기(transaction.objectStore('sessions').getAll())) sessions.set(session.id, session);
    } catch (error) { database = null; ImageStudio_저장오류알리기(error); }
    initialized = true;
    ImageStudio_현재게임연결하기();
    for (const entry of startup.splice(0)) ImageStudio_사용요청기록하기(entry);
  }
  function ImageStudio_세션확보하기(marker, state) {
    let session = sessions.get(marker.id);
    if (!session) {
      const wife = state?.characters?.[state.primaryCharacterId];
      session = { ...marker, characterName: wife?.name || wife?.shortname || '', firstDay: state?.day ?? null,
        lastDay: state?.day ?? null, count: 0, lastByCharacter: {}, updatedAt: marker.startedAt };
      sessions.set(marker.id, session); dirtySessions.add(marker.id); ImageStudio_저장예약하기();
    }
    return session;
  }
  function ImageStudio_현재게임연결하기() {
    const outer = api.store.get(), state = outer?.state;
    if (!outer?.started || !state) { activeId = ''; return; }
    if (!usageEnabled) { activeId = ImageStudio_기록표식읽기(state)?.id || ''; return; }
    let marker = ImageStudio_기록표식읽기(state);
    if (!marker?.id) {
      api.store.update(current => ImageStudio_기록표식읽기(current)?.id ? current : ImageStudio_기록표식넣기(current, 'attached'));
      marker = ImageStudio_기록표식읽기(api.store.game());
    }
    activeId = marker.id;
    if (initialized) ImageStudio_세션확보하기(marker, api.store.game());
  }
  function ImageStudio_저장예약하기() {
    if (timer !== null) return;
    timer = setTimeout(() => { timer = null; void ImageStudio_사용기록저장하기().catch(() => {}); }, 150);
  }
  function ImageStudio_사용기록저장하기() {
    if (timer !== null) { clearTimeout(timer); timer = null; }
    saving = saving.catch(() => {}).then(async () => {
      await ready;
      while (pending.length || dirtySessions.size) {
        const events = pending.splice(0), ids = [...dirtySessions]; dirtySessions.clear();
        if (!database) { memoryEvents.push(...events); break; }
        try {
          const transaction = database.transaction(['sessions', 'events'], 'readwrite');
          const done = ImageStudio_트랜잭션기다리기(transaction);
          for (const id of ids) transaction.objectStore('sessions').put(sessions.get(id));
          for (const event of events) transaction.objectStore('events').put(event);
          await done;
          storageError = '';
        } catch (error) {
          pending.unshift(...events); ids.forEach(id => dirtySessions.add(id)); ImageStudio_저장오류알리기(error); throw error;
        }
      }
    });
    return saving;
  }
  function ImageStudio_사용요청기록하기(entry) {
    if (!initialized) { startup.push(entry); return; }
    const session = ImageStudio_세션확보하기(entry.marker, entry.state);
    const characterId = entry.characterId || entry.axes.character || 'unknown';
    // 같은 구성의 연속 렌더는 한 번. A→B→A로 돌아오면 새 요구로 집계합니다.
    if (session.lastByCharacter[characterId] === entry.key) return;
    session.lastByCharacter[characterId] = entry.key;
    session.count++; session.lastDay = entry.day; session.updatedAt = entry.recordedAt;
    const { marker, state, ...event } = entry;
    pending.push({ ...event, id: ImageStudio_기록식별자만들기(), sessionId: marker.id, sequence: session.count });
    dirtySessions.add(marker.id); ImageStudio_저장예약하기();
  }
  function ImageStudio_게임프롬프트기록하기(result, args) {
    if (!usageEnabled || !rendering || !result?.key || !api.store.get()?.started) return;
    const state = api.store.game(), marker = ImageStudio_기록표식읽기(state), character = args[0];
    if (!marker?.id) return;
    const parsed = api.fn('imageKeyParse')(result.key) || {};
    const axes = { character: parsed.character || character?.archetypeId || 'unknown',
      outfit: parsed.outfit || character?.outfit || 'unknown',
      situation: parsed.scene || parsed.task || (parsed.lookFocus ? 'look:' + parsed.lookFocus + ':' + (parsed.lookReaction || '') : character?.sceneOverride || character?.currentTask || 'unknown'),
      room: parsed.room || args[1] || 'unknown', exposure: parsed.exposure || 'none', variant: parsed.variant ?? 0,
      mood: parsed.mood || 'default', aftermath: parsed.aftermath || 'none',
      groupBoys: parsed.groupBoys ?? null, groupSlots: parsed.groupSlots || '', abed: !!parsed.abed, finishOutfit: parsed.finishOutfit || '' };
    ImageStudio_사용요청기록하기({ marker, state, key: String(result.key), axes, characterId: character?.id || parsed.characterId || '',
      characterName: character?.name || character?.shortname || axes.character, day: state.day ?? null, slot: state.slot ?? null,
      phase: state.phase || '', recordedAt: new Date().toISOString(), prompt: result.prompt || '', negativePrompt: result.negativePrompt || '',
      genParams: result.genParams ? JSON.parse(JSON.stringify(result.genParams)) : null, checkpoint: result.checkpoint || '' });
  }
  async function ImageStudio_사용통계읽기(id = activeId) {
    await ready;
    await ImageStudio_사용기록저장하기().catch(() => {});
    let events = memoryEvents.filter(event => event.sessionId === id);
    if (database) {
      events = await ImageStudio_요청결과기다리기(database.transaction('events', 'readonly').objectStore('events').index('sessionId').getAll(id));
    }
    const combined = new Map([...events, ...pending.filter(event => event.sessionId === id)].map(event => [event.id, event]));
    return { schemaVersion: 1, modVersion: '1.11.0', exportedAt: new Date().toISOString(),
      metric: '게임 이미지 구성의 연속 중복을 제외한 요구 횟수. 생성 성공·실제 파일 표시·노출 시간과는 별도입니다.',
      storageError, session: sessions.has(id) ? { ...sessions.get(id), lastByCharacter: undefined } : null,
      events: [...combined.values()].sort((a, b) => a.sequence - b.sequence) };
  }
  function ImageStudio_통계행만들기(events, mode) {
    const groups = new Map();
    for (const event of events) {
      const value = mode === 'image' ? event.key : event.axes[mode] || 'unknown';
      let row = groups.get(value);
      if (!row) { row = { value, count: 0, firstDay: event.day, lastDay: event.day, sample: event }; groups.set(value, row); }
      row.count++; row.lastDay = event.day; row.sample = event;
    }
    return [...groups.values()].sort((a, b) => b.count - a.count || a.value.localeCompare(b.value)).map(row => ({ ...row, share: events.length ? row.count * 100 / events.length : 0 }));
  }
  function ImageStudio_통계Csv만들기(rows) {
    const cell = value => '"' + String(value ?? '').replace(/^[=+@\-\t\r]/, match => "'" + match).replaceAll('"', '""') + '"';
    return '\uFEFF' + rows.map(row => row.map(cell).join(',')).join('\r\n') + '\r\n';
  }
  function ImageStudio_항목이름읽기(axis, value) {
    if (axis === 'character') return value;
    return globalThis.WW_ImageStudioHelp?.label?.(axis, value) || value;
  }
  function ImageStudio_필터적용하기(events) {
    const query = search.trim().toLocaleLowerCase();
    return events.filter(event => (!characterFilter || event.axes.character === characterFilter) && (!query ||
      [event.key, event.characterName, ...Object.entries(event.axes).map(([axis, value]) => ImageStudio_항목이름읽기(axis, String(value)))].join(' ').toLocaleLowerCase().includes(query)));
  }
  async function ImageStudio_통계파일저장하기(format) {
    try {
      const data = await ImageStudio_사용통계읽기(selectedId), events = ImageStudio_필터적용하기(data.events);
      const name = 'imagestudio-usage-' + selectedId + '-' + new Date().toISOString().replace(/[:.]/g, '-');
      let file, type;
      if (format === 'json') {
        data.statistics = Object.fromEntries(['image','outfit','situation','room'].map(mode => [mode, ImageStudio_통계행만들기(data.events, mode).map(({ sample, ...row }) => row)]));
        file = JSON.stringify(data, null, 2); type = 'application/json';
      } else if (format === 'log') {
        file = ImageStudio_통계Csv만들기([['게임 ID','순번','기록 시각','게임 일차','게임 시각','인물','인물 ID','이미지 키','의상','상황','장소','Positive','Negative'],
          ...events.map(event => [event.sessionId,event.sequence,event.recordedAt,event.day,event.slot,event.characterName,event.characterId,event.key,event.axes.outfit,event.axes.situation,event.axes.room,event.prompt,event.negativePrompt])]); type = 'text/csv;charset=utf-8';
      } else {
        file = ImageStudio_통계Csv만들기([['게임 ID','집계 기준','항목 키','표시 이름','요구 횟수','비율(%)','첫 일차','마지막 일차'],
          ...ImageStudio_통계행만들기(events, category).map(row => [selectedId,category,row.value,ImageStudio_항목이름읽기(category === 'image' ? 'key' : category,row.value),row.count,row.share.toFixed(2),row.firstDay,row.lastDay])]); type = 'text/csv;charset=utf-8';
      }
      await api.saveFile(name + (format === 'json' ? '.json' : format === 'log' ? '-log.csv' : '-' + category + '.csv'), file, type);
      body?.querySelector('[data-wwis-usage-status]')?.replaceChildren(storageError || '파일 저장 요청을 전달했습니다.');
    } catch (error) { body?.querySelector('[data-wwis-usage-status]')?.replaceChildren('파일 저장 실패: ' + String(error?.message || error)); }
  }
  async function ImageStudio_통계화면그리기() {
    const epoch = ++viewEpoch;
    try {
      await ready;
      if (!body) return;
      if (!sessions.has(selectedId)) selectedId = sessions.has(activeId) ? activeId : [...sessions.keys()].at(-1) || '';
      const data = await ImageStudio_사용통계읽기(selectedId);
      if (!body || epoch !== viewEpoch) return;
      const allEvents = data.events, events = ImageStudio_필터적용하기(allEvents), rows = ImageStudio_통계행만들기(events, category);
      const select = h('select', { 'data-wwis-usage-session': '', 'aria-label': '게임 기록', onchange: event => { selectedId = event.target.value; characterFilter = ''; void ImageStudio_통계화면그리기(); } });
      for (const session of [...sessions.values()].sort((a, b) => b.startedAt.localeCompare(a.startedAt))) {
        select.append(h('option', { value: session.id }, `${session.id === activeId ? '현재 · ' : ''}${new Date(session.startedAt).toLocaleString('ko-KR')} · ${session.characterName} · ${session.origin === 'new-game' ? '새 게임' : '설치/불러오기 이후'} · ${session.count}회 · ${session.id.slice(0,8)}`));
      }
      select.value = selectedId;
      const grouping = h('select', { 'data-wwis-usage-category': '', 'aria-label': '집계 기준', onchange: event => { category = event.target.value; void ImageStudio_통계화면그리기(); } },
        ...[['image','이미지별'],['outfit','복장별'],['situation','상황별'],['room','장소별']].map(([value, label]) => h('option', { value }, label)));
      grouping.value = category;
      const characters = h('select', { 'data-wwis-usage-character': '', 'aria-label': '인물 필터', onchange: event => { characterFilter = event.target.value; void ImageStudio_통계화면그리기(); } }, h('option', { value: '' }, '모든 인물'));
      for (const value of [...new Set(allEvents.map(event => event.axes.character))].sort()) characters.append(h('option', { value }, allEvents.find(event => event.axes.character === value).characterName + ' · ' + value));
      characters.value = characterFilter;
      const input = h('input', { type: 'search', value: search, placeholder: '이미지 키·복장·상황 검색', 'aria-label': '기록 검색', 'data-wwis-usage-search': '' });
      const submit = () => { search = input.value; void ImageStudio_통계화면그리기(); };
      input.onkeydown = event => { if (event.key === 'Enter') submit(); };
      const tableBody = h('tbody');
      for (const row of rows.slice(0, 200)) {
        const sample = row.sample, label = category === 'image' ? `${sample.characterName} · ${ImageStudio_항목이름읽기('outfit', sample.axes.outfit)} · ${ImageStudio_항목이름읽기('situation', sample.axes.situation)} · ${ImageStudio_항목이름읽기('room', sample.axes.room)}` : ImageStudio_항목이름읽기(category, row.value);
        tableBody.append(h('tr', {}, h('td', {}, label, h('code', {}, row.value)), h('td', {}, row.count.toLocaleString()), h('td', {}, row.share.toFixed(1) + '%'), h('td', {}, `${row.firstDay ?? '?'} → ${row.lastDay ?? '?'}`)));
      }
      const logs = h('details', { 'data-wwis-usage-log': '' }, h('summary', {}, `프롬프트 기록 로그 · 최근 ${Math.min(events.length, 100)}회`));
      for (const event of events.slice(-100).reverse()) logs.append(h('details', {}, h('summary', {}, `#${event.sequence} · ${event.day ?? '?'}일 / ${event.slot ?? '?'}분 · ${event.characterName} · ${ImageStudio_항목이름읽기('situation', event.axes.situation)} · ${ImageStudio_항목이름읽기('outfit', event.axes.outfit)}`),
        h('code', {}, event.key), h('p', {}, '요구 시각: ' + new Date(event.recordedAt).toLocaleString('ko-KR')), h('strong', {}, 'Positive'), h('pre', {}, event.prompt), h('strong', {}, 'Negative'), h('pre', {}, event.negativePrompt)));
      const exportButton = (label, format) => h('button', { type: 'button', class: 'wayward-native-button', disabled: !data.session, 'data-wwis-usage-export': format, onclick: () => { void ImageStudio_통계파일저장하기(format); } }, label);
      body.classList.add('wwis-usage');
      body.replaceChildren(ImageStudio_통계사용체크박스만들기(),
        h('p', { class: 'wml-muted' }, usageEnabled
          ? '켜짐: 플레이 중 이미지 요구를 새 게임별로 기록합니다. 같은 이미지의 연속 요구는 한 번만 집계합니다.'
          : '꺼짐: 새 이미지 사용 기록을 수집하지 않습니다. 기존 기록은 조회·내보내기할 수 있습니다.'),
        h('div', { class: 'wwis-usage-controls' }, select, api.ui.button('현재 게임', () => { selectedId = activeId; characterFilter = ''; search = ''; void ImageStudio_통계화면그리기(); }), api.ui.button('새로고침', () => { void ImageStudio_통계화면그리기(); })),
        h('p', {}, data.session ? `${data.session.origin === 'attached' ? '설치/불러오기 이후 수집 · ' : ''}총 요구 ${data.session.count.toLocaleString()}회 · 고유 이미지 ${new Set(allEvents.map(event => event.key)).size.toLocaleString()}개 · 필터 적용 ${events.length.toLocaleString()}회` : '새 게임을 시작하면 이미지 요구 기록이 쌓입니다.'),
        h('div', { class: 'wwis-usage-controls' }, grouping, characters, input, api.ui.button('검색', submit)),
        h('div', { class: 'wwis-usage-controls' }, exportButton('전체 통계·로그 JSON 저장', 'json'), exportButton('현재 통계 CSV 저장', 'csv'), exportButton('현재 로그 CSV 저장', 'log')),
        h('p', { role: 'status', 'data-wwis-usage-status': '' }, storageError || '브라우저에 자동 저장합니다. 이미지 서버가 없어도 사용할 수 있습니다.'),
        h('div', { class: 'wwis-usage-table' }, h('table', {}, h('thead', {}, h('tr', {}, ...['항목','요구 횟수','비율','첫→마지막 일차'].map(label => h('th', {}, label)))), tableBody)),
        events.length ? logs : h('p', {}, '이 조건에 해당하는 이미지 요구 기록이 없습니다.'),
        h('details', { class: 'wml-muted' }, h('summary', {}, '집계·저장 기준'),
          h('p', {}, '이미지 구성 A→B→A는 3회, 같은 구성의 연속 렌더는 1회입니다. 캐시/오프라인에서도 기록하며 계획·검수창의 계산은 제외합니다. 생성 성공·실제 파일 표시·노출 시간을 측정하는 통계는 아닙니다.'),
          h('p', {}, 'JSON은 선택한 게임의 전체 통계와 로그, CSV는 현재 인물·검색 필터를 적용합니다. 표는 상위 200개, 화면 로그는 최근 100회이며 파일에는 전체를 담습니다. 세이브 불러오기/되돌리기는 같은 게임의 누적 기록을 되감지 않습니다. 기록은 이 브라우저에 보관됩니다. 다른 PC에는 JSON 또는 WML 백업으로 보관하세요.'),
          data.session ? h('code', {}, '게임 기록 ID: ' + data.session.id) : ''));
    } catch (error) { if (body && epoch === viewEpoch) body.replaceChildren(ImageStudio_통계사용체크박스만들기(), h('p', { role: 'status' }, '통계 읽기 실패: ' + String(error?.message || error)), api.ui.button('다시 읽기', () => { void ImageStudio_통계화면그리기(); })); }
  }
  function ImageStudio_통계창열기() {
    selectedId = activeId; search = ''; characterFilter = '';
    panel = api.ui.window({ id: 'usage-statistics', title: '이미지별 사용 통계 · ImageStudio', width: 1150, height: 800,
      render(root) { body = root; root.replaceChildren(h('p', {}, '기록을 읽는 중입니다…')); void ImageStudio_통계화면그리기(); },
      onClose() { body = null; panel = null; viewEpoch++; } });
    return panel;
  }
  const style = h('style', { 'data-wwis-usage-style': '' });
  style.textContent = '.wwis-usage{overflow-wrap:anywhere}.wwis-usage-toggle{display:flex;align-items:center;gap:8px;margin:0 0 12px;padding:10px;border:1px solid #57534e;border-radius:7px;cursor:pointer}.wwis-usage-controls{display:flex;flex-wrap:wrap;gap:8px;margin:12px 0}.wwis-usage select,.wwis-usage input{min-width:0;max-width:100%;background:#292524;color:#e7e5e4;border:1px solid #57534e;border-radius:5px;padding:7px;font:inherit}.wwis-usage-table{max-width:100%;overflow:auto}.wwis-usage table{width:100%;border-collapse:collapse;font-size:13px}.wwis-usage th,.wwis-usage td{padding:9px;text-align:left;vertical-align:top;border-bottom:1px solid #44403c}.wwis-usage td:not(:first-child){white-space:nowrap}.wwis-usage td:first-child{min-width:160px}.wwis-usage code{display:block;font-size:11px;color:#a8a29e;overflow-wrap:anywhere;word-break:break-all}.wwis-usage pre{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.5 sans-serif;background:#0c0a09;padding:8px;border-radius:5px}.wwis-usage details{margin:10px 0}.wwis-usage summary{cursor:pointer;color:#fbbf24}@media(max-width:640px){.wwis-usage-controls>select,.wwis-usage-controls>input{flex:1 1 100%}.wwis-usage table{font-size:12px}.wwis-usage th,.wwis-usage td{padding:6px}}';
  document.head.append(style);
  // 새 게임 상태를 만드는 함수에 표식을 붙입니다. 기존 세이브는 연결 시점부터 기록합니다.
  api.hook('imageUsageInitialState', { priority: -1000000, after: state => usageEnabled ? ImageStudio_기록표식넣기(state, 'new-game') : state });
  ImageStudio_현재게임연결하기();
  const stop = api.store.subscribe(ImageStudio_현재게임연결하기);
  api.hook('imageUsagePortraitPanel', { around(next, ...args) { rendering++; try { return next(...args); } finally { rendering--; } } });
  api.hook('imagePrompt', { priority: -1000000, after: ImageStudio_게임프롬프트기록하기 });
  const ready = ImageStudio_기록저장소열기();
  api.backup?.beforeExport?.(async () => { await ImageStudio_사용기록저장하기(); if (storageError) throw Error(storageError); });
  document.getElementById('wwis-overlay')?.addEventListener('click', event => { if (event.target.closest('#wwis-usage-statistics')) ImageStudio_통계창열기(); });
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') void ImageStudio_사용기록저장하기().catch(() => {}); });
  window.addEventListener('pagehide', () => { stop(); void ImageStudio_사용기록저장하기().catch(() => {}); }, { once: true });
  globalThis.WW_ImageStudioUsage = { open: ImageStudio_통계창열기, snapshot: ImageStudio_사용통계읽기, flush: ImageStudio_사용기록저장하기,
    sessions: async () => { await ready; return [...sessions.values()].map(({ lastByCharacter, ...session }) => ({ ...session })); },
    summarize: ImageStudio_통계행만들기, csv: ImageStudio_통계Csv만들기, ready, databaseName };
}

// 이미지 스튜디오 — WML 포팅판
// 원본: imagestudio.src_v1.js (md5 59ec45a9f83466ff38d543cc4c35a2da), 9-30 한글판 모드 매니저용 애드온.
// 원본에서 고친 곳 7군데: imagestudio-current.fixes.json
// 원본 코드는 아래 setup() 안에서 그대로 실행돼요. 게임 함수 연결은 addon-compat 모드가 해 줘요.

Object.assign(globalThis,{ImageStudio_HStatus연결만들기,ImageStudio_HStatus설정그리기,ImageStudio_자세상황목록,ImageStudio_자세상황에맞는가,ImageStudio_확장등록창구만들기,ImageStudio_노출코드정규화하기,ImageStudio_노출키정규화하기,ImageStudio_계산묶음만들기,ImageStudio_진행표시만들기,ImageStudio_캐시진행응답읽기,ImageStudio_서버지원오류읽기,ImageStudio_프롬프트검수연결하기,ImageStudio_사용통계연결하기});

    const api = globalThis.__waywardPauseSettingsUiFactory.connect(wmlApi, {"id":"imagestudio","label":"이미지 스튜디오","bindings":{"2026-10-04":{"store":"ae","settingsStore":"At","React":"Z","jsx":"u","ActionButton":"Ze","ActionPanel":"aO","wife":"_","updateWife":"O","updateCharacter":"nn","log":"N","tick":"Jt","intoxLabel":"In","playerId":"fe","wifeId":"Re","locationOf":"$e","wifeLocation":"_e","playerLocation":"bt","moveOccupant":"Pt","patronScene":"Y","playerSexScene":"Le","setScene":"MV","patronSceneLocation":"tt","isSexualStage":"it","sceneDef":"ls","sceneOutfitState":"bx","garmentWorn":"vr","exposureSummary":"nf","patronWatchChoices":"Xae","patronChoice":"tNe","startPlayerSex":"_p","playerSexEvent":"Fl","ensureHusbandLed":"F8","addJoinedPatron":"nfe","joinSlots":"NH","registerAlert":"nr","queueAlert":"gn","drainAlerts":"gl","imagePrompt":"r8","imageKey":"s8","imageKeyOf":"n8","imageDescriptor":"o8","makeCustomer":"ff","addCustomer":"Ka","carryToBed":"RDe","talkToWife":"EF","actionTimes":"Oo","addFeeling":"we","addIdentityStrainFromPatronAct":"Kf","getCustomerLocation":"Yn","getEffectiveAttributes":"B","heroineConditioningMax":"QX","heroineDriveCalc":"si","moveWife":"pt","outfits":"fh","patronControlCustomerLocation":"ht","wifeById":"ul","wifePreview":"gue","reduceGameAction":"wT","brothelLog":"hs","decisionCategories":"bo","decisionResolve":"G$e","manaMax":"ms","minuteTick":"gp","recordPlayerTone":"Rt","wives":"mh","imageBackend":"Eh","brothelCustomerBusy":"XO","buildPatronMoveCandidates":"Phe","ejectCustomer":"Q5","endPatronInteraction":"jt","finishBackRoomService":"xF","forceAttemptChance":"Ppe","patronControlAcquaintanceStop":"_Ie","patronControlAttemptRoll":"Iy","patronControlBackRoomOpen":"Tr","patronControlBareForPushIn":"O5","patronControlChooseMove":"Yhe","patronControlCoercionEscape":"cpe","patronControlFavorTable":"h3","patronControlHerBackRoomProposal":"ipe","patronControlIntentEvolve":"z$","patronControlJoinerComfort":"wh","patronControlJoinerPushIn":"jIe","patronControlLineUp":"Gce","patronControlLungePlan":"Vre","patronControlMortifyingCheck":"b$","patronControlMoveCustomer":"Yt","patronControlNaturalEnd":"hI","patronControlPatronBackRoomProposal":"ape","patronControlPatronDrift":"Kbe","patronControlPlayerAway":"Tt","patronControlPositionWeights":"Fhe","patronControlPrivateSession":"wpe","patronControlPrivateSessionInfo":"a0","patronControlPushIn":"qce","patronControlPushInAnalReaction":"p6","patronControlPushInReaction":"R6","patronControlRelentChance":"Bpe","patronControlRequestTable":"E2e","patronControlSelfEscalationRoll":"Qre","patronControlShameStop":"dpe","patronControlSlotFree":"kS","patronControlSmallRequest":"R2e","patronControlStageLabel":"hG","patronControlStrengthContest":"Za","patronControlTacticTable":"lIe","patronControlUndressAttempt":"AIe","patronControlVerbalAsk":"$5e","patronControlWitnessesFor":"Ks","patronControlYieldRoll":"pB","playerActionPublicRefusal":"Rs","processPatronGroupJoin":"BS","processPatronGroupParticipants":"WS","processPatronInteractionTick":"R7","recordPatronMistreatment":"yl","recordPatronReach":"K5e","resolvePatronEscalation":"ub","resolvePatronForce":"gB","rotatePatronGroupAfterPrimary":"Gie","selectPatronTactic":"gIe","startPatronInteraction":"Go","transitionPatronStage":"Dn","evaluateIntimacy":"Pe","getMaritalDrift":"E4","getPatronAttachment":"Uo","nudgeRelationship":"Mo","recordAffection":"Iw","recordIntimateHistory":"Wd","recordPatronBoundary":"Qi","brothelRoomLabels":"bO","imageRoom":"lue","waitressAlternative":"u$","waitressAvailable":"Bd","waitressChooseOrder":"Jle","waitressConsume":"_w","waitressIncome":"Qt","waitressMissing":"CP","waitressPrice":"d$","waitressRecordDrink":"vw","waitressRecordWord":"VB","playerActionRespond":"P1e","playerActionTopicFatigue":"GY","playerActionTouchedOut":"er","promptJoin":"J6","promptRoomFilter":"$de","promptGenParams":"q6","outfitById":"Ot","saveSlotInfo":"Mb","listDayStarts":"ZI","saveDayStart":"UDe","wifePortraits":"z6e","resentment":"Ue","marriageBond":"VT","wakeUp":"FI","gameOverScreen":"HLe","allureScore":"Ir","normalVisitRoll":"nhe","lodgingChance":"IB","worldTick":"Dp","hotkeyAction":"sG","confirmAction":"N4e","busyTask":"X0","imageManifest":"Wb","imageServerUrl":"Cs","imageGenerate":"LPe","imageQueue":"g6e","imageBackendProbe":"JU","imageBackendForget":"UD","imagePackReset":"qD","imageAutoProbeAllowed":"KU","imagePlanner":"r6e","imagePlannerAppend":"Dc","imageKeyParse":"fp","imageArchetypeCharacter":"n6e","imageMoods":"QLe","imageTasks":"JLe","imageEscalationScenes":"KLe","imageSexScenes":"SO","imageAfters":"XLe","imageSexExposures":"TO","imageEscalationExposures":"ZLe","imageTaskExposures":"$O","imageGroupSlots":"IO","imageRooms":"M_","imageFloorOutfits":"hS","imageBathOutfits":"cS","sceneFamily":"au","sceneDisallowsGroup":"Zne"}, "2026-11-01": {"store":"ae","settingsStore":"at","React":"J","jsx":"u","ActionButton":"ht","ActionPanel":"SB","wife":"_","updateWife":"C","updateCharacter":"rn","log":"j","tick":"Jt","intoxLabel":"Sn","playerId":"ge","wifeId":"Ee","locationOf":"Ae","wifeLocation":"we","playerLocation":"vt","moveOccupant":"Ht","patronScene":"U","playerSexScene":"Be","setScene":"dK","patronSceneLocation":"Je","isSexualStage":"ct","sceneDef":"Sr","sceneOutfitState":"KMe","garmentWorn":"Zr","exposureSummary":"_g","patronWatchChoices":"Dbe","patronChoice":"uZ","startPlayerSex":"uh","playerSexEvent":"Kl","ensureHusbandLed":"ihe","addJoinedPatron":"C3e","joinSlots":"eU","registerAlert":"ar","queueAlert":"_n","drainAlerts":"oi","imagePrompt":"DR","imageKey":"zz","imageKeyOf":"CR","imageDescriptor":"RR","makeCustomer":"Ag","addCustomer":"Fi","carryToBed":"r5e","talkToWife":"gee","actionTimes":"tn","addFeeling":"Se","addIdentityStrainFromPatronAct":"Qf","getCustomerLocation":"Jn","getEffectiveAttributes":"B","heroineConditioningMax":"eue","heroineDriveCalc":"il","moveWife":"Nt","outfits":"Oi","patronControlCustomerLocation":"et","wifeById":"$m","wifePreview":"WL","reduceGameAction":"p5","brothelLog":"ds","decisionCategories":"Ho","decisionResolve":"DFe","manaMax":"Ys","minuteTick":"ry","recordPlayerTone":"qn","wives":"kr","imageBackend":"yh","brothelCustomerBusy":"z5","buildPatronMoveCandidates":"Zve","ejectCustomer":"HR","endPatronInteraction":"Rt","finishBackRoomService":"IV","forceAttemptChance":"iIe","patronControlAcquaintanceStop":"OUe","patronControlAttemptRoll":"g0","patronControlBackRoomOpen":"xS","patronControlBareForPushIn":"Q2","patronControlChooseMove":"sxe","patronControlCoercionEscape":"YOe","patronControlFavorTable":"wY","patronControlHerBackRoomProposal":"dGe","patronControlIntentEvolve":"AC","patronControlJoinerComfort":"ch","patronControlJoinerPushIn":"KUe","patronControlLineUp":"ADe","patronControlLungePlan":"s8e","patronControlMortifyingCheck":"b_","patronControlMoveCustomer":"lo","patronControlNaturalEnd":"GC","patronControlPatronBackRoomProposal":"cGe","patronControlPatronDrift":"NHe","patronControlPlayerAway":"yt","patronControlPositionWeights":"rxe","patronControlPrivateSession":"ZJ","patronControlPrivateSessionInfo":"Nh","patronControlPushIn":"jDe","patronControlPushInAnalReaction":"N9","patronControlPushInReaction":"wz","patronControlRelentChance":"mIe","patronControlRequestTable":"JGe","patronControlSelfEscalationRoll":"l8e","patronControlShameStop":"WOe","patronControlSlotFree":"G$","patronControlSmallRequest":"QGe","patronControlStageLabel":"Ote","patronControlStrengthContest":"el","patronControlTacticTable":"$Ue","patronControlUndressAttempt":"zUe","patronControlVerbalAsk":"A7e","patronControlWitnessesFor":"hs","patronControlYieldRoll":"Xq","playerActionPublicRefusal":"ir","processPatronGroupJoin":"gN","processPatronGroupParticipants":"XS","processPatronInteractionTick":"cZ","recordPatronMistreatment":"yl","recordPatronReach":"bPe","resolvePatronEscalation":"_b","resolvePatronForce":"Zq","rotatePatronGroupAfterPrimary":"jle","selectPatronTactic":"MUe","startPatronInteraction":"Xo","transitionPatronStage":"js","evaluateIntimacy":"We","getMaritalDrift":"i4","getPatronAttachment":"Uo","nudgeRelationship":"ko","recordAffection":"Iw","recordIntimateHistory":"Om","recordPatronBoundary":"tl","brothelRoomLabels":"LB","imageRoom":"ER","waitressAlternative":"JA","waitressAvailable":"zr","waitressChooseOrder":"uTe","waitressConsume":"v_","waitressIncome":"vo","waitressMissing":"K7","waitressPrice":"zv","waitressRecordDrink":"ox","waitressRecordWord":"vK","playerActionRespond":"IWe","playerActionTopicFatigue":"sX","playerActionTouchedOut":"er","promptJoin":"Yz","promptRoomFilter":"uMe","promptGenParams":"Dz","outfitById":"Ot","saveSlotInfo":"Bk","listDayStarts":"h$","saveDayStart":"y5e","wifePortraits":"Uit","resentment":"qe","marriageBond":"dA","wakeUp":"vD","gameOverScreen":"kat","allureScore":"aa","normalVisitRoll":"wTe","lodgingChance":"mK","worldTick":"py","hotkeyAction":"KG","confirmAction":"NYe","busyTask":"sv","imageManifest":"bh","imageServerUrl":"es","imageGenerate":"xst","imageQueue":"eit","imageBackendProbe":"FD","imageBackendForget":"iM","imagePackReset":"t_","imageAutoProbeAllowed":"eoe","imagePlanner":"Uat","imagePlannerAppend":"mu","imageKeyParse":"rl","imageArchetypeCharacter":"Fat","imageMoods":"Mat","imageTasks":"Dat","imageEscalationScenes":"Rat","imageSexScenes":"GB","imageAfters":"Oat","imageSexExposures":"UB","imageEscalationExposures":"Pat","imageTaskExposures":"qB","imageGroupSlots":"VB","imageRooms":"Za","imageFloorOutfits":"ene","imageBathOutfits":"ene","sceneFamily":"df","sceneDisallowsGroup":"lye"}}});
    // ---- 현재 게임에 맞춘 보정 ----
    // What the 9-30 mod manager changed inside the game for the Image Studio, redone as WML hooks.
    const LG = globalThis.__WML_LEGACY__;
    const raw = LG.name, G = LG.get;            // old 9-30 name -> current name / current value
    // 최초 실행은 게임의 이미지 생성 설정을 따릅니다. 저장한 오프라인 전용 선택은 첫 이미지 조회 전부터 유지합니다.
    if (globalThis.__WW_STUDIO_OFFLINE_ONLY__ === undefined) {
      try { globalThis.__WW_STUDIO_OFFLINE_ONLY__ = localStorage.getItem('ww-image-studio-offline-only-v1') === 'true'; }
      catch { globalThis.__WW_STUDIO_OFFLINE_ONLY__ = false; }
    }
    const offline = () => !!globalThis.__WW_STUDIO_OFFLINE_ONLY__;
    const outfitLockKey = 'ww-image-studio-lock-wife-outfit-v1';
    if (globalThis.__WW_STUDIO_LOCK_WIFE_OUTFIT__ === undefined) {
      try { globalThis.__WW_STUDIO_LOCK_WIFE_OUTFIT__ = localStorage.getItem(outfitLockKey) === 'true'; }
      catch { globalThis.__WW_STUDIO_LOCK_WIFE_OUTFIT__ = false; }
    }
    const outfitLocked = () => !!globalThis.__WW_STUDIO_LOCK_WIFE_OUTFIT__;
    const lockOutfitDefinition = api.fn('outfitById');
    const lockWifeLocation = api.fn('wifeLocation');
    const bathContext = (state, character) => ['bathhouse', 'bathroom'].includes(lockWifeLocation(state))
      || character?.currentTask === 'bathing' || String(character?.sceneOverride || '').startsWith('bath_');
    const ordinaryLockedOutfit = (state, character, outfit = character?.outfit) => {
      const wear = lockOutfitDefinition(outfit)?.wear;
      return outfit && wear !== 'sleep' && wear !== 'bath'
        && !(['naked', 'nude'].includes(outfit) && bathContext(state, character)) ? outfit : null;
    };
    const rememberLockedOutfit = (state, characterId, outfit) => {
      if (!outfit) return state;
      const stored = state.mods?.imagestudio?.outfitLock;
      if (stored?.characterId === characterId && stored.outfit === outfit) return state;
      return { ...state, mods: { ...state.mods, imagestudio: { ...state.mods?.imagestudio, outfitLock: { characterId, outfit } } } };
    };
    // 착용 결과를 되돌리지 않고, 지시·시착으로 바뀐 평상복을 다음 자동 선택의 기준으로 기록합니다.
    function rememberChangedOutfit(state, result, characterId) {
      const before = state?.characters?.[characterId], after = result?.characters?.[characterId];
      if (!before || !after) return result;
      const stored = state.mods?.imagestudio?.outfitLock;
      const previous = stored?.characterId === characterId ? stored.outfit : null;
      const target = ordinaryLockedOutfit(result, after) || previous || ordinaryLockedOutfit(state, before)
        || ordinaryLockedOutfit(state, before, before.outfitBeforeBath);
      return rememberLockedOutfit(result, characterId, target);
    }
    // 명시적 지시·시착으로 잠옷/목욕복을 선택한 경우에도 이전 평상복으로 되돌리지 않습니다.
    function rememberRequestedOutfit(state, result, outfit) {
      const characterId = state?.primaryCharacterId;
      return outfit && result?.characters?.[characterId]?.outfit === outfit
        ? rememberLockedOutfit(result, characterId, outfit) : result;
    }
    function setOutfitLock(value) {
      const changed = outfitLocked() !== !!value;
      globalThis.__WW_STUDIO_LOCK_WIFE_OUTFIT__ = !!value;
      if (!changed) return;
      api.store.update(state => {
        if (!state?.characters?.[state.primaryCharacterId]) return state;
        const { outfitLock, ...settings } = state.mods?.imagestudio || {};
        const next = { ...state, mods: { ...state.mods, imagestudio: settings } };
        const wife = next.characters?.[next.primaryCharacterId];
        return value ? rememberLockedOutfit(next, next.primaryCharacterId, ordinaryLockedOutfit(next, wife)
          || ordinaryLockedOutfit(next, wife, wife?.outfitBeforeBath)) : next;
      });
    }
    
    // 1. "offline only": the game makes no image/video generation calls (cached images are still shown)
    api.hook(raw('qMe'), { before: () => (offline() ? { cancel: true, value: Promise.resolve(null) } : undefined) });
    const GUARDED = new Set(['/api/video/check', '/api/image/generate', '/api/video/generate']);
    api.hook(raw('Is'), { before: ([path]) => (offline() && GUARDED.has(path) ? { cancel: true, value: null } : undefined) });
    api.hook(raw('I3e'), { before: () => (offline() ? { cancel: true, value: undefined } : undefined) });
    api.hook('updateWife', { priority: 10000, around(next, state, updater) {
      if (!outfitLocked()) return next(state, updater);
      return rememberChangedOutfit(state, next(state, updater), state?.primaryCharacterId);
    } });
    api.hook('updateCharacter', { priority: 10000, around(next, state, characterId, updater) {
      if (!outfitLocked() || characterId !== state?.primaryCharacterId) return next(state, characterId, updater);
      return rememberChangedOutfit(state, next(state, characterId, updater), characterId);
    } });

    // 자발적 환복은 실행 후보에서 제외하여 실제 환복과 다른 로그·제안을 만들지 않습니다.
    const voluntaryOutfitActions = new Set(['security_cover_up', 'desire_dress_bolder', 'afternoon_try_on']);
    api.hook('imageStudioAutonomousActions', { after(result) {
      return outfitLocked() ? result.filter(action => !voluntaryOutfitActions.has(action.id)) : result;
    } });
    api.hook('imageStudioDailyOutfit', { before: ([state]) => {
      if (!outfitLocked()) return;
      const characterId = state?.primaryCharacterId, character = state?.characters?.[characterId];
      const stored = state?.mods?.imagestudio?.outfitLock;
      const outfit = ordinaryLockedOutfit(state, character)
        || (stored?.characterId === characterId ? stored.outfit : null)
        || ordinaryLockedOutfit(state, character, character?.outfitBeforeBath);
      if (outfit) return { cancel: true, value: outfit };
    } });
    // 피로로 쉬러 가는 도중의 자발적 평상복 변경만 중단하고 휴식 자체는 유지합니다.
    api.hook('imageStudioCoverOutfit', { before: ([state]) => outfitLocked()
      ? { cancel: true, value: { state, target: null } } : undefined });
    api.hook('imageStudioApplyOutfitResponse', { after(result, [state, response]) {
      return outfitLocked() ? rememberRequestedOutfit(state, result, response?.outfitChange) : result;
    } });
    api.hook('imageStudioTryOutfit', { after(result, [state, outfit]) {
      return outfitLocked() ? rememberRequestedOutfit(state, result, outfit) : result;
    } });
    
    // 2. the random-generation window can open on a chosen wife (it starts on the first wife of the list)
    api.hook(raw('gPe'), {
      around(next, props, ...rest) {
        const order = G('dd'), want = props && props.initialWife, at = want ? order.indexOf(want) : -1;
        if (at <= 0) return next(props, ...rest);
        order.splice(at, 1); order.unshift(want);
        try { return next(props, ...rest); } finally { order.splice(order.indexOf(want), 1); order.splice(at, 0, want); }
      },
    });
    
    // 4. the complete bridge the studio talks to. The old installer injected
    // axes()/fromKey() into the game bundle; a WML port must provide them itself.
    const imagePlanner = api.fn('imagePlanner');
    const appendImagePlan = api.fn('imagePlannerAppend');
    const parseImageKey = key => api.fn('imageKeyParse')(ImageStudio_노출키정규화하기(key));
    const archetypeCharacter = api.fn('imageArchetypeCharacter');
    const imageMoods = api.fn('imageMoods');
    const imageTasks = [...new Set([...api.fn('imageTasks'), 'resting', 'sleeping'])];
    const imageEscalations = api.fn('imageEscalationScenes');
    const imageSexScenes = api.fn('imageSexScenes');
    const imageAfters = api.fn('imageAfters');
    const imageSexExposures = api.fn('imageSexExposures');
    const imageEscalationExposures = api.fn('imageEscalationExposures');
    const imageTaskExposures = api.fn('imageTaskExposures');
    const imageGroupSlots = api.fn('imageGroupSlots');
    // Stable planner lists physical locations; imageRoom maps them to supported image backgrounds.
    const imageRooms = [...new Set(api.fn('imageRooms').map(room => api.fn('imageRoom')(room)))];
    const imageFloorOutfits = api.fn('imageFloorOutfits').filter(id => api.fn('outfitById')(id)?.wear !== 'bath');
    const imageBathOutfits = [...api.fn('imageBathOutfits').filter(id => api.fn('outfitById')(id)?.wear === 'bath'), 'nude'];
    const imageServerUrl = api.fn('imageServerUrl');
    const sceneFamily = api.fn('sceneFamily');
    const sceneDisallowsGroup = api.fn('sceneDisallowsGroup');
    const outfitRegistry = api.fn('outfits');
    
    const EXPOSURE_FIELDS = ['bodiceUnlaced', 'topPulledDown', 'topRemoved', 'skirtUp', 'skirtRemoved', 'pantiesAside', 'pantiesRemoved'];
    const EXPOSURE_LABELS = ['상의 끈 풀기', '상의를 내려 가슴 노출', '상의 벗기기', '치마 걷어 올리기', '치마 벗기기', '팬티 옆으로 젖히기', '팬티 벗기기'];
    const TASK_LABELS = {
      idle: '대기 중', greeting: '손님 맞이', taking_order: '주문 받기', serving: '서빙', cleaning: '청소',
      cooking: '요리', resting: '휴식', sleeping: '수면', composing: '마음 추스르기', bathing: '목욕', passed_out: '의식을 잃음',
    };
    const SCENE_LABELS = {
      patron_chatting: '손님과 대화', patron_flirting: '손님과 추파', patron_touching: '가벼운 스킨십', patron_bold: '대담한 스킨십',
      patron_groping: '몸 더듬기', patron_groping_lap: '무릎 위에서 몸 더듬기', patron_intimate: '친밀한 접촉', patron_intimate_lap: '무릎 위 친밀한 접촉',
      patron_handjob: '손으로 자극', patron_handjob_finish: '손으로 자극 · 마무리', patron_handjob_climax: '손으로 자극 · 절정',
      patron_blowjob: '구강 성교', patron_deepthroat: '목 깊숙이 애무', patron_blowjob_climax: '구강 성교 · 절정', patron_blowjob_swallow: '정액 삼키기',
      patron_rubbing: '성기 비비기', patron_rubbing_finish: '성기 비비기 · 마무리', patron_rubbing_climax: '성기 비비기 · 절정',
      patron_sex: '손님과 성관계', patron_sex_climax: '손님과 성관계 · 절정', patron_sex_finish: '손님과 성관계 · 내부 사정',
      patron_sex_finish_pullout: '손님과 성관계 · 외부 사정', patron_riding: '손님 위에 올라타기', patron_standing_sex: '손님과 서서 성관계',
      patron_anal: '손님과 항문 성교', patron_anal_climax: '손님과 항문 성교 · 절정', patron_anal_finish: '항문 성교 · 내부 사정',
      patron_anal_finish_pullout: '항문 성교 · 외부 사정', patron_cunnilingus: '손님에게 여성기 애무받기', patron_mutual_touching: '손님과 서로 애무',
      patron_titfuck: '가슴으로 손님 자극', patron_breast_worship: '손님의 가슴 애무', patron_facial: '손님이 얼굴에 사정', patron_self_stroke: '손님의 자위 보기',
      patron_thigh_job: '허벅지로 비비기(스마타)',
      bath_solo: '혼자 목욕', bath_attendant: '목욕 시중', bath_attendant_wash_chest: '목욕 시중 · 가슴 씻기', bath_attendant_wash_body: '목욕 시중 · 몸 씻기',
      bath_attendant_handjob: '목욕 중 손으로 자극', bath_with_patron: '손님과 목욕', kissing: '입맞춤', groped_ass: '엉덩이 만지기', groped_tits: '가슴 만지기',
      grinding: '몸 비비기', lap_dance: '무릎 위 춤', thigh_job: '허벅지로 애무', handjob: '손으로 애무', fingered: '손가락으로 애무받기',
      mutual_touching: '서로 애무', blowjob: '입으로 애무', deepthroat: '목 깊숙이 애무', cunnilingus: '여성기 구강 애무', face_sitting: '얼굴 위에 앉기',
      sixty_nine: '서로 구강 애무', breast_worship: '가슴 애무', titfuck: '가슴으로 애무', sex: '성관계', riding: '위에 올라타기',
      standing_sex: '서서 성관계', sex_rough: '거친 성관계', anal_fingering: '항문을 손가락으로 애무', anal: '항문 성교', self_pleasure: '자위',
      facial: '얼굴에 사정', finish_on_stomach: '배에 사정', finish_on_chest: '가슴에 사정', finish_on_back: '등에 사정', clean_with_mouth: '입으로 닦기', cum_in_mouth: '입 안에 사정',
      patron_moment_cleavage: '가슴골 보여주기', patron_moment_flash_tits: '가슴 드러내기', patron_moment_lift_skirt: '치마 걷어 올리기',
      patron_moment_sit_on_lap: '무릎 위에 앉기', patron_moment_show_tongue: '혀 내밀기', patron_moment_twirl: '몸 돌려 보이기', patron_moment_pose_dance: '춤추며 포즈 취하기',
    };
    const ROOM_LABELS = { taproom: '홀', back_room: '뒷방', bedroom: '침실', bathhouse: '목욕탕', 'bedroom (침대 위)': '침실 · 침대 위' };
    const MOOD_LABELS = {
      default: '기본 표정', smile: '미소', shy: '수줍음', scared: '겁먹음', worried: '걱정',
      aroused: '흥분함', enjoying: '즐기는 중', relieved: '안도함', nervous: '긴장함',
    };
    const ADDITIONAL_MOOD_PROMPTS = Object.freeze({
      aroused: 'aroused, flushed face, heavy breathing, parted lips',
      enjoying: 'pleasure, blush, half-closed eyes, open mouth, relaxed expression',
      relieved: 'relieved, soft eyes, faint smile, relaxed eyebrows',
      nervous: 'nervous, furrowed brow, wide-eyed, tense expression, sweatdrop',
    });
    const ADDITIONAL_MOODS = Object.keys(ADDITIONAL_MOOD_PROMPTS);
    for (const mood of ADDITIONAL_MOODS) if (!imageMoods.includes(mood)) imageMoods.push(mood);
    const AFTER_LABELS = { none: '없음', sweat: '땀과 홍조', messy: '몸에 흔적', facial: '얼굴에 흔적' };
    const ROLE_LABELS = { m: '입', h: '손', b: '가슴', x: '뒤쪽', r: '비비기', i: '질 삽입', a: '항문 삽입', w: '지켜보기' };
    const AXIS_HELP = {
      character: '같은 조건으로 이미지를 만들 대상입니다. 여러 명을 고르면 인물마다 별도 프롬프트와 이미지 키를 만듭니다.',
      situation: "게임이 실제로 사용하는 작업·접촉·성행위 키입니다. 손님 장면과 당신 장면은 서로 다른 키라 별도로 선택합니다.",
      outfit: '게임 의상 정의에서 읽었습니다. 의상 이름 아래 설명은 게임 내 실제 외형 설명이며, 목욕 전용 의상은 목욕 장면에서만 사용합니다.',
      room: '장면의 배경입니다. 침실의 “침대 위”는 별도 이미지 키(abed-1)이므로 일반 침실과 따로 셉니다.',
      mood: '표정 변형입니다. 기본 표정은 mood 키가 없는 원본 구도입니다.',
      men: '완성 이미지에 등장하는 전체 남성 수입니다. 그룹 장면의 grp-N은 추가 합류 인원이라 화면 인원은 N+1명입니다.',
      roles: '그룹 장면에서 추가 남성이 맡는 위치를 왼쪽부터 기록한 gslot 키입니다. 남성 수가 0~1명이면 이 조건은 사용하지 않습니다.',
      exposure: '게임이 사용하는 7자리 exp 코드로 정규화하여 같은 노출 상태를 한 번만 표시합니다. 순서는 상의 끈·상의 내림·상의 제거·치마 올림·치마 제거·팬티 옆으로·팬티 제거입니다. 기존 이미지팩의 중복 표기도 같은 상태로 인식합니다.',
      aftermath: '일상 작업 이미지에 남는 사후 상태입니다. 성행위의 사정 방식은 장면 키나 마무리 의상(fin)으로 별도 처리됩니다.',
      variant: '같은 장면의 프롬프트 변형입니다. 장면마다 v-0~v-3을 편집할 수 있으며 일상 작업의 일반 생성은 v-0을 사용합니다.',
    };
    
    const unique = values => [...new Set(values.filter(value => value !== undefined && value !== null && value !== ''))];
    const exposureKey = value => ImageStudio_노출코드정규화하기(value ? EXPOSURE_FIELDS.map(field => value[field] ? '1' : '0').join('') : '') || 'none';
    const exposureObject = value => {
      const normalized = ImageStudio_노출코드정규화하기(value);
      if (!normalized) return undefined;
      return Object.fromEntries(EXPOSURE_FIELDS.map((field, index) => [field, normalized[index] === '1']));
    };
    const outfitDef = id => (Array.isArray(outfitRegistry) ? outfitRegistry.find(item => item?.id === id) : null);
    const plainLabel = value => String(value).replace(/[_:-]+/g, ' ').replace(/\b\w/g, char => char.toUpperCase());
    const roleText = value => [...String(value)].map((code, index) => `추가 남성 ${index + 1}: ${ROLE_LABELS[code] || code}`).join(' · ');
    const exposureText = value => value === 'none' ? '노출 상태를 따로 지정하지 않습니다.' : EXPOSURE_FIELDS.map((field, index) => value[index] === '1' ? EXPOSURE_LABELS[index] : '').filter(Boolean).join(' · ');
    const ImageStudio_태그목록읽기 = value => String(value || '').split(',').map(tag => tag.trim()).filter(Boolean);
    const ImageStudio_태그식별자읽기 = value => String(value || '').toLowerCase().replaceAll('_', ' ').replace(/\s+/g, ' ').trim();
    const ImageStudio_태그합치기 = (...values) => {
      const result = [], seen = new Set();
      for (const tag of values.flatMap(ImageStudio_태그목록읽기)) {
        const identity = ImageStudio_태그식별자읽기(tag);
        if (!identity || seen.has(identity)) continue;
        seen.add(identity); result.push(tag);
      }
      return result.join(', ');
    };
    const ImageStudio_짧은해시읽기 = value => {
      let hash = 2166136261;
      for (let index = 0; index < value.length; index += 1) { hash ^= value.charCodeAt(index); hash = Math.imul(hash, 16777619); }
      return (hash >>> 0).toString(36);
    };
    const ImageStudio_이미지기분읽기 = (talentId, parsed) => parsed?.mood
      || String(talentId || '').split('__').find(part => part.startsWith('mood-'))?.slice(5)
      || undefined;
    function ImageStudio_추가기분설정읽기(mood) {
      const saved = globalThis.WW_ImageStudioBridge?.extensions?.editor?.nativeAxisPrompt?.('mood', mood);
      return {
        positivePrompt: saved && Object.prototype.hasOwnProperty.call(saved, 'positivePrompt')
          ? String(saved.positivePrompt || '') : ADDITIONAL_MOOD_PROMPTS[mood] || '',
        negativePrompt: String(saved?.negativePrompt || ''),
      };
    }
    function ImageStudio_추가기분결과적용하기(item, mood) {
      if (!item || !ADDITIONAL_MOOD_PROMPTS[mood]) return item;
      const { positivePrompt, negativePrompt } = ImageStudio_추가기분설정읽기(mood);
      const sourceParts = Array.isArray(item.ImageStudioParts) ? item.ImageStudioParts : [];
      const moodParts = sourceParts.filter(part => ['기분', 'Mood'].includes(String(part?.label || '')));
      const otherTags = new Set(sourceParts.filter(part => !moodParts.includes(part))
        .flatMap(part => ImageStudio_태그목록읽기(part.tags)).map(ImageStudio_태그식별자읽기));
      const removed = new Set(moodParts.flatMap(part => ImageStudio_태그목록읽기(part.tags))
        .map(ImageStudio_태그식별자읽기).filter(tag => !otherTags.has(tag)));
      const prompt = ImageStudio_태그합치기(
        ImageStudio_태그목록읽기(item.prompt).filter(tag => !removed.has(ImageStudio_태그식별자읽기(tag))).join(', '),
        positivePrompt,
      );
      const negative = ImageStudio_태그합치기(item.negativePrompt, negativePrompt);
      const variant = String(item.talentId || '').match(/__v-\d+$/)?.[0] || '';
      const withoutVariant = variant ? String(item.talentId).slice(0, -variant.length) : String(item.talentId || '');
      const root = withoutVariant.split('__').filter(part => !part.startsWith('mood-') && !part.startsWith('studio-')).join('__');
      const signature = ImageStudio_짧은해시읽기(JSON.stringify([mood, positivePrompt, negativePrompt]));
      const { ImageStudioParts, ...clean } = item;
      return { ...clean, talentId: `${root}__mood-${mood}__studio-${signature}${variant}`, prompt, negativePrompt: negative };
    }
    
    const imageStudioHelp = {
      axis: axis => AXIS_HELP[axis] || (axis.startsWith('prompt') ? '프롬프트 수정의 설정을 사용합니다. 같은 항목에서 여러 값을 선택하면 각각 별도 조합으로 만들고, 지정하지 않으면 자동으로 처리합니다.' : ''),
      label(axis, value) {
        value = String(value);
        if (axis === 'situation') return TASK_LABELS[value] || SCENE_LABELS[value] || plainLabel(value);
        if (axis === 'outfit') return outfitDef(value)?.name || plainLabel(value);
        if (axis === 'room') return ROOM_LABELS[value] || plainLabel(value);
        if (axis === 'mood') return MOOD_LABELS[value] || plainLabel(value);
        if (axis === 'men') return value === '0' ? '남성 없음' : `남성 ${value}명`;
        if (axis === 'roles') return `gslot-${value} · ${roleText(value)}`;
        if (axis === 'exposure') return value === 'none' ? '노출 지정 없음' : `exp-${value}`;
        if (axis === 'aftermath') return AFTER_LABELS[value] || plainLabel(value);
        if (axis === 'variant') return value === '0' ? 'v-0 · 기본 구도' : `v-${value} · 구도 변형 ${value}`;
        return value;
      },
      describe(axis, value) {
        value = String(value);
        if (axis === 'situation') {
          if (TASK_LABELS[value]) return '일상 작업 이미지입니다. 남성 역할 조건은 적용되지 않습니다.';
          if (value.startsWith('patron_') || value === 'bath_with_patron' || value.startsWith('bath_attendant')) return '손님과 진행되는 장면입니다. 남성 수가 2명 이상이면 선택한 그룹 역할 조합을 함께 적용합니다.';
          if (value === 'self_pleasure' || value === 'bath_solo') return '남성이 등장하지 않는 단독 장면입니다.';
          return "당신과 진행되는 장면입니다. 장면이 그룹 구성을 지원할 때만 추가 남성 역할이 적용됩니다.";
        }
        if (axis === 'outfit') {
          const item = outfitDef(value); return item ? `${item.description || '게임에 등록된 의상입니다.'}${Number.isFinite(item.boldnessScore) ? ` · 대담함 ${item.boldnessScore}` : ''}` : '이미지 팩에서 발견한 의상 키입니다.';
        }
        if (axis === 'room') return value.includes('(침대 위)') ? '침실 배경 중 침대 위에서 진행되는 patron 장면 전용 키입니다.' : `${ROOM_LABELS[value] || value} 배경에서 만들 수 있는 조합만 남깁니다.`;
        if (axis === 'mood') return value === 'default' ? '별도의 mood 키를 붙이지 않아 게임의 기본 표정을 사용합니다.' : `${MOOD_LABELS[value] || value} 표정을 이미지 키와 프롬프트에 반영합니다.`;
        if (axis === 'men') return value === '0' ? '일상 작업·목욕·자위처럼 남성이 보이지 않는 장면입니다.' : value === '1' ? "당신 또는 손님 한 명만 등장하는 기본 장면입니다." : `기본 상대 1명과 추가 합류자 ${Number(value) - 1}명이 등장하는 그룹 장면입니다.`;
        if (axis === 'roles') return `${roleText(value)}. 역할 문자 수와 추가 합류 인원 수가 일치하는 조합에만 사용됩니다.`;
        if (axis === 'exposure') return `${exposureText(value)}${value === 'none' ? '' : ` · 7자리 키 ${value}`}`;
        if (axis === 'aftermath') return value === 'none' ? '땀이나 체액 흔적을 별도로 추가하지 않습니다.' : `${AFTER_LABELS[value] || value} 상태를 일상 이미지 프롬프트에 남깁니다.`;
        if (axis === 'variant') return value === '0' ? '게임이 기본으로 요청하는 첫 번째 카메라 구도입니다.' : '같은 상황·의상·장소를 유지하면서 카메라 구도만 바꿉니다.';
        return '';
      },
    };
    globalThis.WW_ImageStudioHelp = Object.freeze(imageStudioHelp);
    
    function refreshImageStudioOutfits() {
      if (!Array.isArray(outfitRegistry)) return;
      for (const item of outfitRegistry) {
        if (!item?.id) continue;
        const target = item.wear === 'bath' ? imageBathOutfits : imageFloorOutfits;
        if (Array.isArray(target) && !target.includes(item.id)) target.push(item.id);
      }
    }
    
    // Read the effective registry: direct WML registrations may never enter
    // __WAYWARD_WIFE_ADDONS__, and inherited prompt fields live on the presets.
    function imageStudio_collectWives() {
      const characters = new Map();
      let skipped = 0;
      for (const wife of G('Zl') || []) {
        if (!wife || typeof wife !== 'object') { skipped++; continue; }
        const id = String(wife.shortname || '').trim().toLowerCase();
        if (!/^[a-z0-9][a-z0-9_-]{0,99}$/.test(id) || id === 'patron') { skipped++; continue; }
        if (characters.has(id)) { skipped++; continue; }
        const prompt = String(wife.imageBase || '').trim();
        const negativePrompt = String(wife.imageNegative || '').trim();
        characters.set(id, {
          id, name: String(wife.name || id).trim().slice(0, 100) || id,
          prompt, negativePrompt, originalPrompt: prompt, originalNegativePrompt: negativePrompt,
        });
      }
      return { characters: [...characters.values()], skipped };
    }
    
    function imageStudioAxes() {
      refreshImageStudioOutfits();
      const item = (axis, value, extra = {}) => ({ value: String(value), label: imageStudioHelp.label(axis, value), description: imageStudioHelp.describe(axis, value), ...extra });
      const situations = [
        ...imageTasks.map(value => item('situation', value, { kind: 'task' })),
        ...imageEscalations.map(value => item('situation', value, { kind: 'scene' })),
        ...imageSexScenes.map(value => item('situation', value, { kind: 'scene' })),
      ];
      const outfits = unique(outfitRegistry.map(entry => entry?.id)).map(value => item('outfit', value));
      const rooms = unique([...imageRooms, 'bathhouse', 'bedroom (침대 위)']).map(value => item('room', value));
      const moods = unique([...imageMoods.map(value => value || 'default'), ...ADDITIONAL_MOODS]).map(value => item('mood', value));
      const groups = unique(imageGroupSlots.map(group => group?.slots));
      const men = unique(['0', '1', ...imageGroupSlots.map(group => String((Number(group?.boys) || 0) + 1))]).sort((a, b) => Number(a) - Number(b));
      const exposures = unique(['none', ...imageSexExposures.map(exposureKey), ...imageEscalationExposures.map(exposureKey), ...imageTaskExposures.map(exposureKey)]);
      return {
        character: unique(G('dd')).map(value => item('character', value)),
        situation: [...new Map(situations.map(entry => [entry.value, entry])).values()],
        outfit: outfits,
        room: rooms,
        mood: moods,
        men: men.map(value => item('men', value)),
        roles: groups.map(value => item('roles', value)),
        exposure: exposures.map(value => item('exposure', value)),
        aftermath: unique(imageAfters.map(value => value || 'none')).map(value => item('aftermath', value)),
        variant: ['0', '1', '2', '3'].map(value => item('variant', value)),
      };
    }

    // Captured with every mod disabled; live registries can contain mod additions.
    const ImageStudio_바닐라ID목록 = new Map(Object.entries({"character":["elena","mara","pippa"],"situation":["anal","anal_fingering","at_market","away","bath_attendant","bath_attendant_handjob","bath_attendant_wash_body","bath_attendant_wash_chest","bath_solo","bath_with_patron","bathing","blowjob","breast_worship","clean_with_mouth","cleaning","composing","cooking","cum_in_mouth","cunnilingus","deepthroat","face_sitting","facial","fingered","finish_on_back","finish_on_chest","finish_on_stomach","greeting","grinding","groped_ass","groped_tits","handjob","idle","kissing","lap_dance","mutual_touching","passed_out","patron_anal","patron_anal_climax","patron_anal_finish","patron_anal_finish_pullout","patron_blowjob","patron_blowjob_climax","patron_blowjob_swallow","patron_bold","patron_breast_worship","patron_chatting","patron_cunnilingus","patron_deepthroat","patron_facial","patron_flirting","patron_grinding","patron_groping","patron_groping_lap","patron_handjob","patron_handjob_climax","patron_handjob_finish","patron_intimate","patron_intimate_lap","patron_lap_dance","patron_moment_cleavage","patron_moment_flash_tits","patron_moment_lift_skirt","patron_moment_pose_dance","patron_moment_show_tongue","patron_moment_sit_on_lap","patron_moment_twirl","patron_mutual_touching","patron_riding","patron_rubbing","patron_rubbing_climax","patron_rubbing_finish","patron_self_stroke","patron_sex","patron_sex_climax","patron_sex_finish","patron_sex_finish_pullout","patron_standing_sex","patron_thigh_job","patron_titfuck","patron_touching","resting","riding","self_pleasure","serving","sex","sex_rough","sixty_nine","sleeping","standing_sex","taking_order","thigh_job","titfuck"],"outfit":["auburn_babydoll","barmaid_corset","bath_bindings","bath_gown","bath_linen_wrap","bath_sheer_chemise","bath_shift","bath_towel","breast_band_skirt","crop_blouse_skirt","his_shirt","linen_shift","lingerie","modest","nightshift","nude","panties_only","patched_sundress","peasant_smock","pink_babydoll","satin_babydoll","serving_dress","sheer_chemise","sheer_nightgown","silk_robe","slave_collar","strapless_thigh_boots","wench_bodice"],"room":["back_room","bathhouse","bedroom","bedroom (침대 위)","taproom"],"mood":["default","scared","shy","smile","worried"],"men":["0","1","2","3","4","5"],"roles":["b","bx","h","hb","hbx","hh","hhb","hhbx","hhx","hx","m","mh","mhh","x"],"aftermath":["facial","messy","none","sweat"],"variant":["0","1","2","3"]}).map(([axis,values]) => [axis,new Set(values)]));
    function ImageStudio_조건ID출처읽기(axis, value) {
      const id = String(value);
      if (axis === 'exposure') return id === 'none' || /^[01]{7}$/.test(id) ? 'vanilla' : 'mod';
      return ImageStudio_바닐라ID목록.get(axis)?.has(id) ? 'vanilla' : 'mod';
    }

    let ImageStudio_기본프롬프트수집완료 = false;
    let ImageStudio_기본프롬프트작업 = null, ImageStudio_기본프롬프트실행 = null;
    function ImageStudio_기본프롬프트상태읽기() {
      const work = ImageStudio_기본프롬프트작업;
      return { done: work?.done || 0, total: work?.total || 0, failed: work?.failed || 0, complete: ImageStudio_기본프롬프트수집완료 };
    }
    function ImageStudio_기본프롬프트양보하기(signal) {
      return new Promise(resolve => {
        let timer, frame;
        const finish = () => { cancelAnimationFrame(frame); clearTimeout(timer); signal?.removeEventListener('abort', finish); resolve(); };
        if (signal?.aborted) return finish();
        signal?.addEventListener('abort', finish, { once: true });
        frame = requestAnimationFrame(() => { timer = setTimeout(finish, 0); });
      });
    }
    async function ImageStudio_기본프롬프트수집하기({ signal, priority, onProgress } = {}) {
      if (ImageStudio_기본프롬프트실행) {
        await ImageStudio_기본프롬프트실행;
        if (signal?.aborted) return false;
        return ImageStudio_기본프롬프트수집하기({ signal, priority, onProgress });
      }
      if (ImageStudio_기본프롬프트수집완료) {
        const previous = ImageStudio_기본프롬프트작업;
        if (previous?.failedJobs.length) {
          previous.jobs.push(...previous.failedJobs.splice(0)); previous.done = previous.total - previous.jobs.length; previous.failed = 0;
          ImageStudio_기본프롬프트수집완료 = false;
        } else { onProgress?.(ImageStudio_기본프롬프트상태읽기()); return true; }
      }
      const work = ImageStudio_기본프롬프트작업 ||= ImageStudio_기본프롬프트작업만들기();
      if (!work) return false;
      const matches = (job, selected) => selected && (job.axis === selected.axis && job.id === selected.id
        || selected.axis === 'men' && job.axis === 'roles' && String(Number(job.options.group?.boys || 0) + 1) === selected.id);
      const task = (async () => {
        while (work.jobs.length && !signal?.aborted) {
          // 창이 그려진 뒤 계산하며 각 묶음 사이에 실제 프레임/입력 처리를 허용합니다.
          await ImageStudio_기본프롬프트양보하기(signal);
          if (signal?.aborted) break;
          const start = performance.now(), selected = priority?.();
          // 다른 계획 작업이 프레임 사이에 전역 플래너 상태를 바꿀 수 있어 묶음마다 초기화합니다.
          imagePlanner({ kinds: [], maxEntries: 1 });
          do {
            const preferred = work.jobs.findIndex(job => matches(job, selected));
            const [job] = work.jobs.splice(preferred < 0 ? 0 : preferred, 1);
            try { appendImagePlan(new Map(), work.template, job.options, work.archetypeId); }
            catch (error) { work.failed++; work.failedJobs.push(job); console.warn('[imagestudio] 기본 축 프롬프트 대표값 수집 실패', job.options, error); }
            work.done++;
          } while (work.jobs.length && !signal?.aborted && performance.now() - start < 8);
          ImageStudio_기본프롬프트수집완료 = !work.jobs.length;
          onProgress?.({ ...ImageStudio_기본프롬프트상태읽기(), priorityReady: !!selected && !work.jobs.some(job => matches(job, selected)) });
        }
        return ImageStudio_기본프롬프트수집완료 && !work.failed;
      })();
      ImageStudio_기본프롬프트실행 = task;
      try { return await task; } finally { if (ImageStudio_기본프롬프트실행 === task) ImageStudio_기본프롬프트실행 = null; }
    }
    // Only the live registry defines characters. The old cPe ID table is gone.
    function ImageStudio_캐릭터원형ID읽기(value) {
      const id = String(value || '').trim();
      if (!id) return null;
      const preset = (G('Zl') || []).find(entry => entry && (entry.shortname === id || entry.id === id));
      return preset?.id || null;
    }
    function ImageStudio_기본프롬프트작업만들기() {
      refreshImageStudioOutfits();
      const wife = globalThis.WW_ImageStudioBridge?.currentWife?.()
        || imageStudio_collectWives().characters[0]?.id
        || unique(G('dd'))[0];
      const archetypeId = ImageStudio_캐릭터원형ID읽기(wife);
      if (!archetypeId) return false;
      const template = archetypeCharacter(archetypeId);
      const floorOutfit = imageFloorOutfits.find(id => outfitDef(id)) || imageFloorOutfits[0] || unique(outfitRegistry.map(entry => entry?.id))[0];
      const bathOutfit = imageBathOutfits.find(id => outfitDef(id)) || imageBathOutfits[0];
      if (!template || !floorOutfit) return false;
      const jobs = [];
      const append = (options, axis = 'situation', id = options.task || options.scene || options.patronScene || '') => jobs.push({ options, axis, id: String(id) });
      const situations = [
        ...imageTasks.map(value => ({ value, kind: 'task' })),
        ...imageEscalations.map(value => ({ value, kind: 'scene' })),
        ...imageSexScenes.map(value => ({ value, kind: 'scene' })),
      ];
      for (const { value, kind } of situations) {
        const bath = value === 'bathing' || value.startsWith('bath_');
        const common = { outfit: bath ? bathOutfit : floorOutfit, room: bath ? 'bathhouse' : value === 'sleeping' ? 'bedroom' : 'taproom', variant: 0 };
        if (!common.outfit) continue;
        for (const variant of [0,1,2,3]) append({ ...common, variant, ...(kind === 'task' ? { task: value } : value.startsWith('patron_') ? { patronScene: value } : { scene: value }) });
      }
      for (const room of unique([...imageRooms, 'bathhouse', 'bedroom (침대 위)'])) {
        if (room === 'bathhouse') {
          if (bathOutfit) append({ outfit: bathOutfit, room: 'bathhouse', task: 'bathing', variant: 0 }, 'room', room);
        } else if (room.includes('(침대 위)')) {
          append({ outfit: floorOutfit, room: 'bedroom', patronScene: 'patron_chatting', abed: true, variant: 0 }, 'room', room);
        } else append({ outfit: floorOutfit, room, task: room === 'bedroom' ? 'sleeping' : 'idle', variant: 0 }, 'room', room);
      }
      for (const mood of unique([...imageMoods.map(value => value || 'default'), ...ADDITIONAL_MOODS])) {
        append({ outfit: floorOutfit, room: 'taproom', task: 'idle', mood: mood === 'default' ? undefined : mood, variant: 0 }, 'mood', mood);
      }
      append({ outfit: floorOutfit, room: 'taproom', patronScene: 'patron_chatting', variant: 0 }, 'men', '0');
      for (const group of imageGroupSlots) {
        append({ outfit: floorOutfit, room: 'taproom', patronScene: 'patron_groping', group, variant: 0 }, 'roles', group.slots);
      }
      for (const exposure of unique([...imageSexExposures, ...imageEscalationExposures, ...imageTaskExposures].map(exposureKey))) {
        append({ outfit: floorOutfit, room: 'taproom', task: 'idle', exposure: exposureObject(exposure), variant: 0 }, 'exposure', exposure);
      }
      return { template, archetypeId, jobs, total: jobs.length, done: 0, failed: 0, failedJobs: [] };
    }
    
    const setOf = (selected, axis, fallback = []) => new Set((Array.isArray(selected?.[axis]) && selected[axis].length ? selected[axis] : fallback)
      .map(value => axis === 'exposure' ? ImageStudio_노출코드정규화하기(String(value)) || 'none' : String(value)));
    const soloScenes = new Set(['self_pleasure', 'bath_solo']);
    const finishScenes = new Set(['facial', 'patron_facial']);
    const finishOutfits = [undefined, 'clothed', 'disheveled', 'exposed', 'hiked', 'nude'];
    const ImageStudio_입마개조건축 = 'promptField:badguest.gagged';
    const ImageStudio_입사용장면 = new Set([
      'blowjob', 'deepthroat', 'sixty_nine', 'clean_with_mouth', 'cum_in_mouth',
      'patron_blowjob', 'patron_deepthroat', 'patron_blowjob_climax', 'patron_blowjob_swallow',
    ]);
    const ImageStudio_입사용자세 = new Set([
      'kneeling-fellatio', 'deep-throat', 'irrumatio-front', 'upside-down-facefuck', 'sixty-nine',
    ]);
    const ImageStudio_입마개선택됨 = selected => setOf(selected, ImageStudio_입마개조건축).has('badguest.gagged');
    const ImageStudio_입마개조합인가 = combination => combination?.[ImageStudio_입마개조건축] === 'badguest.gagged';
    const ImageStudio_입마개와충돌하는가 = (options, combination, gagged = ImageStudio_입마개조합인가(combination)) => {
      if (!gagged) return false;
      const situation = options?.patronScene || options?.scene || options?.task || '';
      return ImageStudio_입사용장면.has(situation)
        || String(options?.group?.slots || '').includes('m')
        || ImageStudio_입사용자세.has(combination?.promptPosition);
    };
    const roomSpec = value => ({ room: String(value).replace(' (침대 위)', ''), abed: String(value).includes('(침대 위)') });
    const sleepwearCombinationAllowed = (situation, outfit, room) => outfitDef(outfit)?.wear !== 'sleep'
      || room === 'bedroom' || situation === 'sleeping' || situation === 'passed_out';
    
    function matchesImageStudioSelection(talentId, selected) {
      const parsed = parseImageKey(talentId);
      if (!parsed) return false;
      const situation = parsed.scene || parsed.task;
      const room = parsed.room + (parsed.abed ? ' (침대 위)' : '');
      const men = parsed.groupBoys ? String(parsed.groupBoys + 1) : parsed.task || soloScenes.has(parsed.scene) ? '0' : '1';
      const checks = [
        ['situation', situation], ['outfit', parsed.outfit], ['room', room], ['mood', ImageStudio_이미지기분읽기(talentId, parsed) || 'default'],
        ['men', men], ['exposure', parsed.exposure || 'none'], ['aftermath', parsed.aftermath || 'none'], ['variant', String(parsed.variant || 0)],
      ];
      if (checks.some(([axis, value]) => !setOf(selected, axis).has(String(value)))) return false;
      return !parsed.groupSlots || setOf(selected, 'roles').has(parsed.groupSlots);
    }
    
    function groupsForSituation(situation, kind, men, roles) {
      if (kind === 'task') return [];
      const supported = kind === 'sex'
        ? situation.startsWith('patron_') || !sceneDisallowsGroup(situation)
        : sceneFamily(situation) === 'grope';
      if (!supported) return [];
      return imageGroupSlots.filter(group => men.has(String((Number(group?.boys) || 0) + 1)) && roles.has(String(group?.slots || '')));
    }

    // Explain an empty planner result with the same constraints used by
    // ImageStudio_랜덤구성공간읽기. The review UI displays every returned item
    // below the generic error instead of making the user guess which axes clash.
    function ImageStudio_구성충돌읽기(wife, selected = {}) {
      refreshImageStudioOutfits();
      const conflicts = [];
      const add = message => { if (message && !conflicts.includes(message)) conflicts.push(message); };
      const values = axis => [...setOf(selected, axis)];
      const label = (axis, value) => imageStudioHelp.label(axis, String(value));
      const situations = values('situation');
      const outfits = values('outfit');
      const rooms = values('room');
      const men = setOf(selected, 'men');
      const roles = setOf(selected, 'roles');
      const exposures = values('exposure');
      const afters = values('aftermath');
      const variants = values('variant');
      const gagged = ImageStudio_입마개선택됨(selected);
      const archetypeId = ImageStudio_캐릭터원형ID읽기(wife);
      if (!wife || !archetypeId || !archetypeCharacter(archetypeId)) add("선택한 여성 캐릭터의 이미지 프롬프트 정의를 찾을 수 없습니다.");
      if (!situations.length) add('장면/작업을 선택하세요.');
      if (!outfits.length) add('의상을 선택하세요.');
      if (!rooms.length) add('장소를 선택하세요.');
      if (gagged) {
        for (const role of roles) if (role.includes('m')) add(`입마개 착용 상태에서는 남성별 역할 조합 “${label('roles', role)}”의 입 배치를 사용할 수 없습니다.`);
        for (const position of values('promptPosition')) if (ImageStudio_입사용자세.has(position)) add(`입마개 착용 상태에서는 입을 사용하는 자세 “${position}”를 사용할 수 없습니다.`);
      }

      for (const situation of situations) {
        const situationLabel = label('situation', situation);
        const kind = imageTasks.includes(situation) ? 'task' : imageEscalations.includes(situation) ? 'escalation' : imageSexScenes.includes(situation) ? 'sex' : null;
        if (!kind) {
          add(`장면/작업 “${situationLabel}”은 현재 게임의 이미지 장면 목록에 없습니다.`);
          continue;
        }
        if (gagged && ImageStudio_입사용장면.has(situation)) add(`입마개 착용 상태에서는 그녀가 입을 사용하는 “${situationLabel}” 장면을 생성할 수 없습니다.`);
        const bath = situation === 'bathing' || situation.startsWith('bath_');
        for (const rawRoom of rooms) {
          const { room, abed } = roomSpec(rawRoom);
          const roomLabel = label('room', rawRoom);
          if (bath && room !== 'bathhouse') add(`목욕 장면 “${situationLabel}”은 장소를 “목욕탕”으로 선택해야 합니다. 현재 장소: “${roomLabel}”.`);
          if (!bath && room === 'bathhouse') add(`장면 “${situationLabel}”은 목욕 장면이 아니어서 장소 “목욕탕”과 함께 사용할 수 없습니다.`);
          if (abed && (room !== 'bedroom' || !situation.startsWith('patron_'))) add(`장소 “침실 · 침대 위”는 손님 장면(patron)에서만 사용할 수 있습니다. 현재 장면: “${situationLabel}”.`);
        }
        for (const outfit of outfits) {
          const definition = outfitDef(outfit);
          const outfitLabel = label('outfit', outfit);
          if (!definition) add(`의상 “${outfitLabel}”의 게임 의상 정의를 찾을 수 없습니다.`);
          else if (bath && definition.wear !== 'bath') add(`목욕 장면 “${situationLabel}”에는 목욕 전용 의상이 필요합니다. 현재 의상 “${outfitLabel}”은 일반 의상입니다.`);
          else if (!bath && definition.wear === 'bath') add(`목욕 전용 의상 “${outfitLabel}”은 장면 “${situationLabel}”에서 사용할 수 없습니다.`);
          for (const rawRoom of rooms) if (!sleepwearCombinationAllowed(situation, outfit, roomSpec(rawRoom).room)) {
            add(`잠옷 “${outfitLabel}”은 깨어 있는 상태로 장소 “${label('room', rawRoom)}”에서 입을 수 없습니다. 원본 게임은 이곳으로 이동할 때 근무복으로 자동 환복합니다. 침실을 선택하거나 의상을 바꾸세요. 수면·실신 장면은 예외입니다.`);
          }
        }

        const validExposures = new Set(['none', ...(kind === 'task' ? imageTaskExposures : kind === 'escalation' ? imageEscalationExposures : imageSexExposures).map(exposureKey)]);
        for (const exposure of exposures) if (!validExposures.has(exposure)) {
          add(`노출 상태 “${label('exposure', exposure)}”은 장면 “${situationLabel}”에서 지원되지 않습니다.`);
        }

        const baseMen = kind === 'task' || soloScenes.has(situation) ? '0' : '1';
        const includeBase = men.has(baseMen);
        const groups = groupsForSituation(situation, kind, men, roles);
        if (!includeBase && !groups.length) {
          const selectedMen = [...men].map(value => label('men', value)).join(', ') || '선택 없음';
          const requestedGroup = [...men].some(value => Number(value) > 1);
          const groupSupported = kind === 'sex'
            ? situation.startsWith('patron_') || !sceneDisallowsGroup(situation)
            : kind === 'escalation' && sceneFamily(situation) === 'grope';
          const groupCounts = imageGroupSlots.filter(group => men.has(String((Number(group?.boys) || 0) + 1)));
          if (requestedGroup && !groupSupported) add(`장면 “${situationLabel}”은 여러 남성이 등장하는 그룹 구성을 지원하지 않습니다. 현재 남성 수: ${selectedMen}.`);
          else if (requestedGroup && !groupCounts.length) add(`현재 남성 수(${selectedMen})에 해당하는 그룹 역할 조합이 게임에 없습니다.`);
          else if (requestedGroup) add(`현재 남성 수(${selectedMen})와 선택한 남성별 역할 조합이 서로 맞지 않습니다.`);
          else add(`장면 “${situationLabel}”의 기본 남성 수는 ${label('men', baseMen)}입니다. 현재 선택: ${selectedMen}.`);
        }

        const validAfters = new Set(unique(imageAfters.map(value => value || 'none')));
        if (kind === 'task') {
          for (const aftermath of afters) if (!validAfters.has(aftermath)) add(`사후 상태 “${label('aftermath', aftermath)}”은 일상 작업 이미지에서 지원되지 않습니다.`);
        } else {
          for (const aftermath of afters) if (aftermath !== 'none') add(`사후 상태 “${label('aftermath', aftermath)}”은 일상 작업 이미지 전용이라 장면 “${situationLabel}”과 함께 사용할 수 없습니다.`);
        }
        for (const variant of variants) {
          if (!Number.isFinite(Number(variant))) add(`구도 변형 “${variant}”은 올바른 숫자가 아닙니다.`);
          else if (kind === 'task' && Number(variant) !== 0) add(`일상 작업 “${situationLabel}”은 기본 구도(v-0)만 지원합니다. 현재 선택: ${label('variant', variant)}.`);
        }
      }
      return conflicts;
    }
    
    function appendStudioImage(target, template, archetypeId, options, selected = {}, combinations = null) {
      const before = target.size;
      const prompt = globalThis.WW_ImageStudioPrompt;
      const additionalMood = ADDITIONAL_MOOD_PROMPTS[options?.mood] ? options.mood : null;
      const nativeOptions = additionalMood ? { ...options, mood: undefined } : options;
      if (prompt?.plan) {
        for (const combination of combinations || prompt.combinations(selected)) {
          if (ImageStudio_입마개와충돌하는가(options, combination)) continue;
          const items = prompt.plan(() => { const temporary = new Map(); appendImagePlan(temporary, template, nativeOptions, archetypeId); return [...temporary.values()]; },combination,archetypeId);
          for (const source of items) {
            if (ImageStudio_입마개와충돌하는가(options, combination, source?.ImageStudioGagged === true)) continue;
            const { ImageStudioGagged, ...cleanSource } = source;
            const item = additionalMood ? ImageStudio_추가기분결과적용하기(cleanSource, additionalMood) : cleanSource;
            target.set(item.talentId,item);
          }
        }
      } else if (additionalMood) {
        const temporary = new Map(); appendImagePlan(temporary, template, nativeOptions, archetypeId);
        for (const source of temporary.values()) {
          const item = ImageStudio_추가기분결과적용하기(source, additionalMood);
          target.set(item.talentId,item);
        }
      } else appendImagePlan(target, template, nativeOptions, archetypeId);
      if (target.size > 120000) throw new Error('생성 후보가 120,000장을 넘었습니다. 상황·의상·노출 조건을 더 좁혀 주세요.');
      return target.size > before;
    }
    
    // 프롬프트를 만들지 않고 유효한 기본 구성의 크기와 인덱스만 보관합니다.
    function ImageStudio_랜덤구성공간읽기(wife, selected = {}, sourceKeys = null) {
      refreshImageStudioOutfits();
      const archetypeId = ImageStudio_캐릭터원형ID읽기(wife);
      if (!archetypeId) return { count: 0n, error: '캐릭터 정의 없음', at() { throw new RangeError('캐릭터 정의 없음'); }, build() { return []; } };
      const template = archetypeCharacter(archetypeId);
      const blocks = [];
      let count = 0n;
      if (sourceKeys) {
        // 예전 exp 표기만 다른 원본 구성은 한 번만 추첨합니다. 실제 이미지 파일과 팩 항목은 변경하지 않습니다.
        for (const key of new Set(sourceKeys.map(ImageStudio_노출키정규화하기))) {
          const parsed = parseImageKey(key);
          if (!parsed?.outfit || !parsed.room || (!parsed.scene && !parsed.task)) continue;
          if (!sleepwearCombinationAllowed(parsed.scene || parsed.task, parsed.outfit, parsed.room)) continue;
          const group = parsed.groupBoys && parsed.groupSlots
            ? imageGroupSlots.find(item => Number(item.boys) === parsed.groupBoys && item.slots === parsed.groupSlots) || {boys:parsed.groupBoys,slots:parsed.groupSlots}
            : undefined;
          blocks.push({ end: ++count, options: {
            outfit:parsed.outfit,room:parsed.room,mood:ImageStudio_이미지기분읽기(key, parsed),exposure:exposureObject(parsed.exposure),
            aftermath:parsed.aftermath,finish:parsed.finishOutfit,variant:parsed.variant || 0,abed:parsed.abed,group,
            ...(parsed.scene ? parsed.scene.startsWith('patron_') ? {patronScene:parsed.scene} : {scene:parsed.scene} : {task:parsed.task}),
          } });
        }
      } else {
        const axes = imageStudioAxes(), all = axis => axes[axis].map(entry => String(entry.value));
        const situations = setOf(selected,'situation',all('situation')), outfits = setOf(selected,'outfit',all('outfit'));
        const rooms = [...setOf(selected,'room',all('room'))].map(roomSpec);
        const moods = [...setOf(selected,'mood',all('mood'))].map(value => value === 'default' ? undefined : value);
        const men = setOf(selected,'men',all('men')), roles = setOf(selected,'roles',all('roles'));
        const exposures = setOf(selected,'exposure',all('exposure')), afters = setOf(selected,'aftermath',all('aftermath'));
        const variants = [...setOf(selected,'variant',all('variant'))].map(Number).filter(Number.isFinite);
        for (const situation of situations) {
          const kind = imageTasks.includes(situation) ? 'task' : imageEscalations.includes(situation) ? 'escalation' : imageSexScenes.includes(situation) ? 'sex' : null;
          if (!kind) continue;
          const bath = situation === 'bathing' || situation.startsWith('bath_');
          const validExposures = new Set(['none',...(kind === 'task' ? imageTaskExposures : kind === 'escalation' ? imageEscalationExposures : imageSexExposures).map(exposureKey)]);
          const exposureValues = [...exposures].filter(value => validExposures.has(value));
          const baseMen = kind === 'task' || soloScenes.has(situation) ? '0' : '1', includeBase = men.has(baseMen);
          const groups = groupsForSituation(situation,kind,men,roles);
          const sceneVariants = kind !== 'task' ? variants : variants.includes(0) ? [0] : [];
          const arrangements = kind === 'task'
            ? includeBase ? [...afters].filter(value => unique(imageAfters.map(item => item || 'none')).includes(value)).map(value => ({aftermath:value === 'none' ? undefined : value})) : []
            : afters.has('none') ? [
              ...(includeBase ? (kind === 'sex' && finishScenes.has(situation) ? finishOutfits : [undefined]).map(finish => ({finish})) : []),
              ...groups.map(group => ({group})),
            ] : [];
          const dimensions = [moods,exposureValues,sceneVariants,arrangements];
          const size = dimensions.reduce((product, values) => product * BigInt(values.length), 1n);
          if (!size) continue;
          for (const {room,abed} of rooms) {
            if (bath !== (room === 'bathhouse') || abed && (room !== 'bedroom' || !situation.startsWith('patron_'))) continue;
            for (const outfit of outfits) {
              if (bath !== (outfitDef(outfit)?.wear === 'bath')) continue;
              if (!sleepwearCombinationAllowed(situation, outfit, room)) continue;
              count += size;
              blocks.push({end:count,size,dimensions,options:{outfit,room,abed,...(kind === 'task' ? {task:situation} : situation.startsWith('patron_') ? {patronScene:situation} : {scene:situation})}});
            }
          }
        }
      }
      function ImageStudio_인덱스구성읽기(index) {
        if (index < 0n || index >= count) throw Error('랜덤 구성 인덱스가 범위를 벗어났습니다.');
        let low = 0, high = blocks.length - 1;
        while (low < high) { const middle = (low + high) >>> 1; if (index < blocks[middle].end) high = middle; else low = middle + 1; }
        const block = blocks[low];
        if (!block.dimensions) return block.options;
        let offset = index - (low ? blocks[low - 1].end : 0n);
        const values = [];
        for (let axis = block.dimensions.length - 1; axis >= 0; axis--) {
          const choices = block.dimensions[axis], size = BigInt(choices.length);
          values[axis] = choices[Number(offset % size)]; offset /= size;
        }
        return {...block.options,mood:values[0],exposure:exposureObject(values[1]),variant:values[2],...values[3]};
      }
      return { count, at:ImageStudio_인덱스구성읽기, build(index, combination) {
        imagePlanner({kinds:[],maxEntries:1});
        const output = new Map();
        appendStudioImage(output,template,archetypeId,ImageStudio_인덱스구성읽기(index),selected,[combination]);
        return [...output.values()].filter(item => matchesImageStudioSelection(item.ImageStudioBaseKey || item.talentId,selected));
      } };
    }

    async function listStudioImages(wife, selected = {}, progress = () => {}, signal) {
      const checkCancelled = () => { if (signal?.aborted) throw new DOMException('조합 계산을 취소했습니다.', 'AbortError'); };
      checkCancelled();
      refreshImageStudioOutfits();
      // Clear the native planner's module-scoped scene/key-only switches before
      // calling its single-entry builder directly.
      imagePlanner({ kinds: [], maxEntries: 1 });
      const axes = imageStudioAxes();
      const all = axis => axes[axis].map(entry => String(entry.value));
      const situations = setOf(selected, 'situation', all('situation'));
      const outfits = setOf(selected, 'outfit', all('outfit'));
      const rooms = [...setOf(selected, 'room', all('room'))].map(roomSpec);
      const moods = [...setOf(selected, 'mood', all('mood'))].map(value => value === 'default' ? undefined : value);
      const men = setOf(selected, 'men', all('men'));
      const roles = setOf(selected, 'roles', all('roles'));
      const exposures = setOf(selected, 'exposure', all('exposure'));
      const afters = setOf(selected, 'aftermath', all('aftermath'));
      const variants = [...setOf(selected, 'variant', all('variant'))].map(Number).filter(Number.isFinite);
      const detailSpace = globalThis.WW_ImageStudioPrompt?.combinationSpace?.(selected);
      const combinations = detailSpace ? null : globalThis.WW_ImageStudioPrompt?.combinations?.(selected);
      const detailCount = detailSpace?.count ?? BigInt(combinations?.length || 1);
      if (detailCount > 120000n) throw new Error('세부 조건 조합이 120,000개를 넘었습니다. 선택을 줄여 주세요.');
      const archetypeId = ImageStudio_캐릭터원형ID읽기(wife);
      if (!archetypeId) return [];
      const template = archetypeCharacter(archetypeId);
      const output = new Map();
      let situationIndex = 0;
      let processed = 0;
      const total = ImageStudio_랜덤구성공간읽기(wife, selected).count * detailCount;
      const report = () => progress({ current: processed, total: total.toString(), candidates: output.size });
      report();
      const checkpoint = ImageStudio_계산묶음만들기(report, signal);
      async function append(options) {
        for (let detailIndex = 0n; detailIndex < detailCount; detailIndex++) {
          checkCancelled();
          const combination = detailSpace ? detailSpace.at(detailIndex) : combinations?.[Number(detailIndex)] || null;
          appendStudioImage(output, template, archetypeId, options, selected, combination ? [combination] : null);
          const pause = checkpoint(++processed);
          if (pause) await pause;
        }
      }
    
      for (const situation of situations) {
        checkCancelled();
        const kind = imageTasks.includes(situation) ? 'task' : imageEscalations.includes(situation) ? 'escalation' : imageSexScenes.includes(situation) ? 'sex' : null;
        if (!kind) continue;
        const bath = situation === 'bathing' || situation.startsWith('bath_');
        const validExposures = new Set(['none', ...(kind === 'task' ? imageTaskExposures : kind === 'escalation' ? imageEscalationExposures : imageSexExposures).map(exposureKey)]);
        const exposureValues = [...exposures].filter(value => validExposures.has(value));
        const baseMen = kind === 'task' || soloScenes.has(situation) ? '0' : '1';
        const includeBase = men.has(baseMen);
        const groups = groupsForSituation(situation, kind, men, roles);
        const sceneVariants = kind !== 'task' ? variants : variants.includes(0) ? [0] : [];
        const aftermathValues = kind === 'task' ? [...afters].filter(value => unique(imageAfters.map(item => item || 'none')).includes(value)) : afters.has('none') ? [undefined] : [];
        const finishes = kind === 'sex' && finishScenes.has(situation) ? finishOutfits : [undefined];
    
        for (const { room, abed } of rooms) {
          if (bath !== (room === 'bathhouse')) continue;
          if (abed && (room !== 'bedroom' || !situation.startsWith('patron_'))) continue;
          for (const outfit of outfits) {
            const definition = outfitDef(outfit);
            if (bath !== (definition?.wear === 'bath')) continue;
            if (!sleepwearCombinationAllowed(situation, outfit, room)) continue;
            for (const mood of moods) for (const exposure of exposureValues) for (const variant of sceneVariants) {
              const common = { outfit, room, mood, exposure: exposureObject(exposure), variant, abed };
              if (kind === 'task') {
                if (!includeBase) continue;
                for (const aftermath of aftermathValues) await append({ ...common, task: situation, aftermath: aftermath === 'none' ? undefined : aftermath });
                continue;
              }
              const scenePart = situation.startsWith('patron_') ? { patronScene: situation } : { scene: situation };
              if (includeBase) for (const finish of finishes) await append({ ...common, ...scenePart, finish });
              for (const group of groups) await append({ ...common, ...scenePart, group, variant });
            }
          }
        }
        if (++situationIndex % 2 === 0) await G('d3')();
      }
      report();
      checkCancelled();
      return [...output.values()].filter(item => matchesImageStudioSelection(item.ImageStudioBaseKey || item.talentId, selected));
    }
    
    function imageFromKey(wife, talentId, selected = {}, all = false, combination = null) {
      const parsed = parseImageKey(talentId);
      if (!parsed || !parsed.outfit || !parsed.room || (!parsed.scene && !parsed.task)) return null;
      imagePlanner({ kinds: [], maxEntries: 1 });
      const archetypeId = ImageStudio_캐릭터원형ID읽기(wife);
      if (!archetypeId) return all ? [] : null;
      const template = archetypeCharacter(archetypeId);
      const group = parsed.groupBoys && parsed.groupSlots
        ? imageGroupSlots.find(item => Number(item.boys) === parsed.groupBoys && item.slots === parsed.groupSlots) || { boys: parsed.groupBoys, slots: parsed.groupSlots }
        : undefined;
      const options = {
        outfit: parsed.outfit, room: parsed.room, mood: ImageStudio_이미지기분읽기(talentId, parsed), exposure: exposureObject(parsed.exposure),
        aftermath: parsed.aftermath, finish: parsed.finishOutfit, variant: parsed.variant || 0, abed: parsed.abed, group,
        ...(parsed.scene ? (parsed.scene.startsWith('patron_') ? { patronScene: parsed.scene } : { scene: parsed.scene }) : { task: parsed.task }),
      };
      const result = new Map();
      appendStudioImage(result, template, archetypeId, options, selected, combination ? [combination] : null);
      return all ? [...result.values()] : [...result.values()][0] || null;
    }
    
    function imageStudioKeyAxes(talentId) {
      const parsed = parseImageKey(talentId);
      if (!parsed) return null;
      const solo = parsed.kind === 'task' || soloScenes.has(parsed.scene);
      return {
        character: parsed.character,
        characterId: parsed.characterId || 'none',
        kind: parsed.kind,
        situation: parsed.scene || parsed.task || parsed.lookFocus || 'none',
        lookReaction: parsed.lookReaction || 'none',
        outfit: parsed.outfit,
        room: parsed.room + (parsed.abed ? ' (침대 위)' : ''),
        mood: ImageStudio_이미지기분읽기(talentId, parsed) || 'default',
        men: parsed.groupBoys ? String(parsed.groupBoys + 1) : solo ? '0' : '1',
        roles: parsed.groupSlots || 'none',
        exposure: parsed.exposure || 'none',
        aftermath: parsed.aftermath || 'none',
        variant: String(parsed.variant || 0),
        finish: parsed.finishOutfit || 'none',
        promptSignature: String(talentId).split('__').filter(part => /^(?:position|state|dialogue|character|studio)-/.test(part)).join('__'),
      };
    }
    
    function imageStudioIdentity(talentId, includePromptSignature = true) {
      const axes = imageStudioKeyAxes(talentId);
      if (!axes) return `raw\u001f${talentId}`;
      return [
        axes.character, axes.characterId, axes.kind, axes.situation, axes.lookReaction,
        axes.outfit, axes.room, axes.mood, axes.men, axes.roles, axes.exposure,
        axes.aftermath, axes.variant, axes.finish,
        ...(includePromptSignature ? [axes.promptSignature] : []),
      ].join('\u001f');
    }
    
    // Per-HTTP-request size, NOT a queue capacity. 20,000 items use 80 chunks.
    const STUDIO_QUEUE_CHUNK = 250;
    const waitForQueueRetry = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));
    async function enqueueStudioImages(items, progress = () => {}) {
      if (!Array.isArray(items) || !items.length) return { accepted: 0, alreadyCached: 0, alreadyQueued: 0, jobId: null };
      const endpoint = imageServerUrl('/api/batch/enqueue');
      if (!endpoint) throw new Error('이미지 생성 서버에 연결되어 있지 않습니다.');
      // Old servers replaced the entire queue per chunk. Check before the first
      // write so a not-yet-restarted server cannot lose ongoing generation work.
      const statusResponse = await fetch(imageServerUrl('/api/batch/status'), { credentials: 'omit' });
      const status = await statusResponse.json().catch(() => ({}));
      if (!statusResponse.ok) throw new Error(status.error || '이미지 서버의 대기열 상태를 확인할 수 없습니다.');
      if (status.enqueueMode !== 'append') throw new Error('이미지 서버 업데이트 적용이 필요합니다. 생성 중인 작업이 있다면 완료 후 서버 창을 닫고 Start_ImageStudio.cmd로 다시 시작해 주세요. 구버전 서버는 250개씩 받을 때 기존 대기열을 덮어씁니다.');
      let jobId = `studio-${new Date().toISOString().replace(/[:.]/g, '-')}-${globalThis.crypto?.randomUUID?.() || Math.random().toString(36).slice(2)}`;
      const chunks = Math.ceil(items.length / STUDIO_QUEUE_CHUNK);
      let accepted = 0, alreadyCached = 0, alreadyQueued = 0;
      for (let offset = 0, chunk = 1; offset < items.length; offset += STUDIO_QUEUE_CHUNK, chunk++) {
        const slice = items.slice(offset, offset + STUDIO_QUEUE_CHUNK);
        const payload = JSON.stringify({ items: slice, jobId, start: offset + slice.length >= items.length });
        let response = null, failure = null;
        for (let attempt = 1; attempt <= 3; attempt++) {
          try {
            response = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'omit', body: payload });
            failure = null;
            break;
          } catch (error) {
            failure = error;
            if (attempt < 3) await waitForQueueRetry(attempt * 250);
          }
        }
        if (!response) throw new Error(`이미지 대기열 ${chunk}/${chunks} 전송에 실패했습니다. 서버 연결과 Start_ImageStudio 창을 확인해 주세요. (${failure?.message || '네트워크 오류'})`);
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(body.error || `이미지 서버가 대기열 ${chunk}/${chunks} 등록을 거부했습니다 (HTTP ${response.status})`);
        if (body.jobId) jobId = body.jobId;
        accepted += Number(body.accepted) || 0;
        alreadyCached += Number(body.alreadyCached) || 0;
        alreadyQueued += Number(body.alreadyQueued) || 0;
        progress({ sent: Math.min(offset + slice.length, items.length), total: items.length, chunk, chunks, accepted, alreadyCached, alreadyQueued });
      }
      return { accepted, alreadyCached, alreadyQueued, jobId };
    }

    let ImageStudio_생성상태캐시 = { at: 0, unavailable: false };
    async function ImageStudio_생성불가확인하기() {
      if (offline()) return true;
      if (globalThis.WW_ImageStudio?.isBusy?.() || globalThis.WW_ImageStudioPrompt?.isBusy?.()) return true;
      const connection = G('ph')();
      if (!connection?.baseUrl || connection.comfyui !== true) return true;
      const now = Date.now();
      if (now - ImageStudio_생성상태캐시.at < 1000) return ImageStudio_생성상태캐시.unavailable;
      try {
        const response = await fetch(imageServerUrl('/api/batch/status'), {
          credentials: 'omit', signal: globalThis.AbortSignal?.timeout?.(2000),
        });
        const status = await response.json().catch(() => ({}));
        const unavailable = !response.ok || status.running === true || (Number(status.total) > Number(status.done) && status.paused !== true);
        ImageStudio_생성상태캐시 = { at: now, unavailable };
        return unavailable;
      } catch {
        ImageStudio_생성상태캐시 = { at: now, unavailable: true };
        return true;
      }
    }
    
    globalThis.WW_ImageStudioBridge = {
      characters: imageStudio_collectWives,
      wives: () => G('Zl') || [],
      ready: () => G('cb')(),
      packs: () => globalThis.__WAYWARD_IMAGE_PACKS__ || [],
      currentWife: () => {
        try {
          const state = G('re').getState().state;
          const wife = state.characters[state.primaryCharacterId];
          return wife.shortname || (wife.archetypeId && wife.archetypeId.split('_')[0]) || null;
        } catch { return null; }
      },
      connection: (...a) => G('ph')(...a),
      setOfflineOnly: value => { globalThis.__WW_STUDIO_OFFLINE_ONLY__ = !!value; G('ND')(); },
      setOutfitLock,
      openRandom: wife => {
        const mount = document.createElement('div');
        document.body.append(mount);
        const root = G('i9').createRoot(mount);
        const close = () => { root.unmount(); mount.remove(); };
        root.render(G('u').jsx(G('gPe'), { onClose: close, initialWife: wife }));
      },
      axes: imageStudioAxes,
      collectPromptDefaults: ImageStudio_기본프롬프트수집하기,
      promptDefaultsStatus: ImageStudio_기본프롬프트상태읽기,
      fromKey: imageFromKey,
      keyAxes: imageStudioKeyAxes,
      identity: imageStudioIdentity,
      enqueue: enqueueStudioImages,
      generationUnavailable: ImageStudio_생성불가확인하기,
      weight: (...a) => G('iPe')(...a),
      list: listStudioImages,
      randomSpace: ImageStudio_랜덤구성공간읽기,
      idOrigin: ImageStudio_조건ID출처읽기,
      selectionConflicts: ImageStudio_구성충돌읽기,
    };
    const extensions = ImageStudio_확장등록창구만들기(api);
    globalThis.WW_ImageStudioBridge.extensions = extensions;
    api.provide({ version: 1, extensions, bridge: globalThis.WW_ImageStudioBridge });
    Object.assign(globalThis.WW_ImageStudioBridge, ImageStudio_HStatus연결만들기(api, globalThis.WW_ImageStudioBridge));
    // ---- 원본 애드온 ----
/* Wayward Image Studio — game-aware conditional planner for wayward-imagegen. */
(function () {
  'use strict';
  if (window.WW_ImageStudio) return;

  const names = {
    elena: '엘레나', mara: '마라', pippa: '피파',
    ...Object.fromEntries((window.__WAYWARD_WIFE_ADDONS__ || []).map(wife => [wife.shortname, wife.name])),
  };
  const axisDefs = [
    ['character', '인물'], ['situation', '장면/작업'], ['outfit', '의상'], ['room', '장소'],
    ['mood', '기분'], ['men', '화면의 전체 남성 수'], ['roles', '추가 남성별 역할 조합'],
    ['exposure', '노출 상태 / exp 키'], ['aftermath', '사후 상태'], ['variant', '구도 변형'],
  ];
  const situationGroupDefs = [
    ['daily', '일상'],
    ['contact_husband', "성적 접촉 (애무까지) · 당신"],
    ['contact_patron', '성적 접촉 (애무까지) · 손님'],
    ['contact_solo', '성적 접촉 (애무까지) · 혼자/기타'],
    ['sex_husband', "성행위 (성기를 꺼내서 하는 행위) · 당신"],
    ['sex_patron', '성행위 (성기를 꺼내서 하는 행위) · 손님'],
    ['sex_solo', '성행위 (성기를 꺼내서 하는 행위) · 혼자/기타'],
    ['climax_husband', "절정 (사정 장면) · 당신"],
    ['climax_patron', '절정 (사정 장면) · 손님'],
    ['climax_solo', '절정 (사정 장면) · 혼자/기타'],
    ['other', '기타'],
  ];
  const dailySituations = new Set([
    'idle', 'greeting', 'taking_order', 'serving', 'cleaning', 'cooking', 'passed_out', 'bathing',
    'resting', 'sleeping', 'at_market', 'composing', 'away', 'bath_solo', 'bath_attendant',
    'patron_chatting', 'patron_flirting',
  ]);
  const contactSituations = new Set([
    'kissing', 'groped_ass', 'groped_tits', 'bath_attendant_wash_chest', 'bath_attendant_wash_body',
    'bath_with_patron', 'patron_touching', 'patron_bold', 'patron_groping', 'patron_groping_lap',
    'patron_intimate', 'patron_intimate_lap', 'fingered', 'grinding', 'lap_dance', 'mutual_touching',
    'breast_worship', 'anal_fingering', 'patron_grinding', 'patron_lap_dance',
    'patron_mutual_touching', 'patron_breast_worship',
  ]);
  const sexSituations = new Set([
    'self_pleasure', 'bath_attendant_handjob', 'handjob', 'blowjob', 'titfuck', 'sex', 'sex_rough',
    'anal', 'clean_with_mouth', 'patron_handjob', 'patron_blowjob', 'patron_sex', 'patron_rubbing',
    'thigh_job', 'deepthroat', 'cunnilingus', 'face_sitting', 'sixty_nine', 'riding', 'standing_sex',
    'patron_thigh_job', 'patron_deepthroat', 'patron_cunnilingus', 'patron_self_stroke',
    'patron_titfuck', 'patron_riding', 'patron_standing_sex', 'patron_anal',
  ]);
  const climaxSituations = new Set([
    'facial', 'finish_on_stomach', 'finish_on_chest', 'finish_on_back', 'cum_in_mouth',
    'patron_rubbing_finish', 'patron_rubbing_climax', 'patron_facial', 'patron_handjob_finish',
    'patron_handjob_climax', 'patron_blowjob_climax', 'patron_sex_climax', 'patron_anal_climax',
    'patron_anal_finish', 'patron_anal_finish_pullout', 'patron_sex_finish',
    'patron_sex_finish_pullout', 'patron_blowjob_swallow',
  ]);
  function situationGroup(value, kind) {
    value = String(value);
    if (kind === 'task' || dailySituations.has(value)) return 'daily';
    const stage = climaxSituations.has(value) ? 'climax'
      : contactSituations.has(value) || value.startsWith('patron_moment_') ? 'contact'
      : sexSituations.has(value) ? 'sex' : '';
    if (!stage) return 'other';
    const partner = value.startsWith('patron_') || value === 'bath_with_patron' || value.startsWith('bath_attendant') ? 'patron'
      : value === 'self_pleasure' || value === 'bath_solo' ? 'solo' : 'husband';
    return `${stage}_${partner}`;
  }
  const moodLabels = { default: '기본 표정', smile: '미소', shy: '수줍음', scared: '두려움', worried: '걱정' };
  const exposureFields = ['상의 끈 풀림', '상의 내림', '상의 제거', '치마 올림', '치마 제거', '속옷 옆으로', '속옷 제거'];
  const roleLabels = { m: '입', h: '손', b: '가슴', x: '뒤/삽입', r: '비비기', i: '질 삽입', a: '항문 삽입', w: '지켜보기' };
  const aftermathLabels = { none: '없음', sweat: '땀/홍조', messy: '몸에 흔적', facial: '얼굴에 흔적' };

  const style = document.createElement('style');
  style.textContent = `#wwis-overlay{position:fixed;inset:0;z-index:2147483001;background:#000b;display:grid;place-items:center;font:13px/1.45 sans-serif;color:#e7e5e4}#wwis-overlay[hidden]{display:none}#wwis-panel{box-sizing:border-box;width:min(1040px,96vw);max-height:94vh;overflow:auto;background:#1c1917;border:1px solid #78716c;border-radius:12px;padding:18px}#wwis-panel button,#wwis-panel select,#wwis-panel input,#wwis-panel textarea{box-sizing:border-box;font:inherit;background:#292524;color:#e7e5e4;border:1px solid #57534e;border-radius:5px;padding:5px}#wwis-panel textarea{width:100%;min-height:64px;resize:vertical}#wwis-panel button{cursor:pointer}#wwis-panel button:hover{border-color:#f59e0b}#wwis-panel button:disabled{opacity:.5;cursor:default}#wwis-panel input[type=checkbox],#wwis-panel input[type=radio]{padding:0;accent-color:#f59e0b}.wwis-mode{display:flex;align-items:center;gap:8px;margin:12px 0 8px;padding:9px 10px;border:1px solid #57534e;border-radius:7px;cursor:pointer}.wwis-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:8px 0}.wwis-random-enqueue{display:inline-flex;align-items:center;gap:6px;flex-wrap:wrap}.wwis-random-enqueue label{display:inline-flex;align-items:center;gap:4px}.wwis-random-enqueue input{width:68px}.wwis-card{border:1px solid #44403c;border-radius:7px;padding:10px;margin:10px 0}.wwis-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:5px;max-height:210px;overflow:auto}.wwis-grid label{display:flex;gap:5px;align-items:flex-start}.wwis-dim{color:#a8a29e;font-size:12px}.wwis-counts{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}.wwis-counts div{min-width:0;overflow-wrap:anywhere}.wwis-audit-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:5px 12px;margin-top:8px}.wwis-audit-grid div{min-width:0;overflow-wrap:anywhere}#wwis-panel h2{margin:0;color:#fbbf24;font-size:20px}#wwis-panel h3{margin:0 0 6px;font-size:14px}.wwis-axis-actions{display:inline-flex;gap:5px;margin-left:8px}.wwis-axis-actions button{font-size:11px;padding:2px 5px}.wwis-source{padding:10px;background:#0c0a09;border:1px solid #57534e;border-radius:7px}.wwis-situation-groups{display:grid;gap:8px;margin-top:8px}.wwis-situation-group{border:1px solid #44403c;border-radius:6px;padding:8px;background:#0c0a0955}.wwis-situation-group-head{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:6px}.wwis-situation-group-head strong{color:#fbbf24}.wwis-situation-group-head button{font-size:11px;padding:2px 5px}.wwis-situation-group .wwis-grid{max-height:180px}.wwis-settings-launch{width:100%;padding:10px!important;border-color:#a16207!important;background:#33240f!important;font-weight:700}.wwis-settings-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px 12px}.wwis-settings-grid label{display:grid;gap:4px}.wwis-settings-grid .wwis-wide{grid-column:1/-1}.wwis-engine-choice{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.wwis-engine-choice label{padding:10px;border:1px solid #57534e;border-radius:7px;background:#211e1b}.wwis-character-row,.wwis-lora-row{padding:9px;border:1px solid #44403c;border-radius:7px;margin:7px 0;background:#151312}.wwis-character-head,.wwis-lora-row{display:flex;align-items:center;gap:7px;flex-wrap:wrap}.wwis-character-head input[data-field=name]{flex:1}.wwis-character-row textarea{margin-top:6px}.wwis-setting-status{padding:8px 10px;border-left:3px solid #a16207;background:#0c0a09}@media(max-width:760px){.wwis-settings-grid,.wwis-engine-choice{grid-template-columns:1fr}.wwis-settings-grid .wwis-wide{grid-column:auto}}`;
  // Suppress the same shortcut when the standalone prompt mod is also active.
  style.textContent += '\n.wwis-task-progress{margin:10px 0;padding:12px;border:1px solid #a16207;border-radius:7px;background:#211b10;overflow-wrap:anywhere}.wwis-task-progress progress{display:block;width:100%;height:18px;margin:7px 0;accent-color:#fbbf24}.wwis-task-progress[data-status=error]{border-color:#ef4444}.wwis-task-progress[data-status=done]{border-color:#4d7c0f}';
  style.textContent += '\n.wwis-generation-toolbar{position:sticky;top:0;z-index:2;padding:8px 0;background:#1c1917}.wwis-generation-toolbar [data-dirty=true]{color:#fbbf24}.wwis-unsaved-prompt{position:absolute;inset:0;display:grid;place-items:center;padding:12px;background:#0009;z-index:3}.wwis-unsaved-prompt section{box-sizing:border-box;width:min(480px,100%);padding:18px;border:1px solid #a16207;border-radius:10px;background:#1c1917;color:#e7e5e4}.wwis-unsaved-prompt p{line-height:1.5}';
  style.textContent += '\n.wwis-unsaved-prompt button{font:inherit;cursor:pointer;padding:8px 10px;border:1px solid #78716c;border-radius:5px;background:#292524;color:#e7e5e4}.wwis-unsaved-prompt button:hover,.wwis-unsaved-prompt button:focus-visible{outline:2px solid #fbbf24;outline-offset:2px}.wwis-unsaved-prompt #wwis-unsaved-save{background:#78350f;border-color:#b45309}';

  document.head.append(style);

  const overlay = document.createElement('div');
  overlay.id = 'wwis-overlay';
  overlay.hidden = true;
  overlay.innerHTML = `<div id="wwis-panel"><div class="wwis-row" style="justify-content:space-between"><h2>이미지 스튜디오</h2><button id="wwis-close">닫기</button></div><label class="wwis-mode"><input id="wwis-offline-only" type="checkbox">게임 플레이 중 오프라인 이미지팩만 사용 (자동 이미지 생성 끔)</label><label class="wwis-mode" title="디버깅용: 자발적 평상복 선택·환복만 일시 중단합니다. 당신이 지시해 수락한 환복과 옷가게 시착은 허용하며, 목욕·취침용 환복은 기존대로 진행합니다."><input id="wwis-lock-wife-outfit" type="checkbox">그녀가 자발적으로 옷을 갈아입지 못하게</label><div id="wwis-content"></div></div>`;
  document.body.append(overlay);

  const content = overlay.querySelector('#wwis-content');
  const state = { wife: '', catalogue: [], catalogueVerified: false, catalogueWarning: '', selected: {}, options: {}, conditionalOpen: false, hStatusOpen: false, cloneSource: '', duplicateMode: 'composition', busy: false, message: '', lastPlan: null, randomCount: 10, packResults: {}, packBusy: new Set(), discoverBusy: false, discoveryMessage: '' };
  const bridge = () => window.WW_ImageStudioBridge;
  const hStatusSelections = {};
  const taskProgress = ImageStudio_진행표시만들기(content, overlay);
  let cacheBusy = false, cacheMessage = '';
  let generationSettingsEditor = null, generationSettingsLoad = null;

  // 생성 방식 설정은 명시적으로 저장합니다. 다른 화면의 자동 갱신이 편집 내용을 덮지 않게 합니다.
  function ImageStudio_생성설정종료하기() {
    generationSettingsLoad = null;
    const editor = generationSettingsEditor;
    generationSettingsEditor = null;
    editor?.observer.disconnect();
    editor?.prompt?.remove();
    overlay.querySelector('#wwis-panel').inert = false;
    content.inert = false;
    // 취소한 토큰을 포함한 입력값은 닫힌 화면의 DOM에도 남기지 않습니다.
    if (editor) content.replaceChildren();
  }

  // 닫기·배경·뒤로 가기를 같은 확인 창으로 처리합니다. 저장 실패 시 화면과 입력값을 유지합니다.
  function ImageStudio_생성설정나가기(onLeave) {
    const editor = generationSettingsEditor;
    if (editor?.saving) {
      editor.update();
      return;
    }
    if (!editor?.dirty()) {
      ImageStudio_생성설정종료하기();
      onLeave();
      return;
    }
    if (editor.prompt) return;
    const previousFocus = document.activeElement;
    const prompt = document.createElement('div');
    prompt.id = 'wwis-unsaved-prompt';
    prompt.className = 'wwis-unsaved-prompt';
    prompt.innerHTML = `<section role="alert" aria-labelledby="wwis-unsaved-title"><strong id="wwis-unsaved-title">저장하지 않은 변경사항이 있습니다.</strong><p>이미지 생성 방식 설정을 저장하고 나갈까요?</p><div class="wwis-row"><button id="wwis-unsaved-save">저장 후 나가기</button><button id="wwis-unsaved-discard">저장 안 하고 나가기</button><button id="wwis-unsaved-continue">계속 수정</button></div></section>`;
    editor.prompt = prompt;
    overlay.append(prompt);
    overlay.querySelector('#wwis-panel').inert = true;
    const dismiss = () => {
      prompt.remove(); editor.prompt = null;
      overlay.querySelector('#wwis-panel').inert = false;
      if (previousFocus?.isConnected) previousFocus.focus();
    };
    prompt.querySelector('#wwis-unsaved-continue').onclick = dismiss;
    prompt.addEventListener('keydown', event => {
      if (event.key !== 'Tab') return;
      const buttons = [...prompt.querySelectorAll('button')];
      if (event.shiftKey && document.activeElement === buttons[0]) {
        buttons.at(-1).focus(); event.preventDefault();
      } else if (!event.shiftKey && document.activeElement === buttons.at(-1)) {
        buttons[0].focus(); event.preventDefault();
      }
    });
    prompt.querySelector('#wwis-unsaved-discard').onclick = () => {
      dismiss(); ImageStudio_생성설정종료하기(); onLeave();
    };
    prompt.querySelector('#wwis-unsaved-save').onclick = async () => {
      dismiss();
      if (await editor.save()) { ImageStudio_생성설정종료하기(); onLeave(); }
    };
    prompt.querySelector('#wwis-unsaved-continue').focus();
  }

  window.addEventListener('beforeunload', event => {
    if (!generationSettingsEditor?.dirty()) return;
    event.preventDefault(); event.returnValue = '';
  });
  content.addEventListener('input', () => generationSettingsEditor?.update());
  content.addEventListener('change', () => generationSettingsEditor?.update());
  let planningController = null;
  const checkPlanningCancelled = signal => { if (signal?.aborted) throw new DOMException('조합 계산을 취소했습니다.', 'AbortError'); };
  function waitForPlanning(promise, signal) {
    if (!signal) return promise;
    return new Promise((resolve, reject) => {
      const abort = () => reject(new DOMException('조합 계산을 취소했습니다.', 'AbortError'));
      signal.addEventListener('abort', abort, { once: true });
      Promise.resolve(promise).then(resolve, reject).finally(() => signal.removeEventListener('abort', abort));
      if (signal.aborted) abort();
    });
  }
  function paintPlanningCancel() {
    const button = content.querySelector('#wwis-plan-cancel');
    if (!button) return;
    button.hidden = !planningController;
    button.style.display = planningController ? '' : 'none';
    button.disabled = !!planningController?.signal.aborted;
    button.textContent = planningController?.signal.aborted ? '취소하는 중…' : '취소하기';
  }
  const generationProgress = value => {
    if (typeof value === 'string') { setMessage(value); return; }
    taskProgress.update('generation', value);
  };
  let cataloguePending = null, catalogueLoadedAt = 0;
  async function imageStudio_requestJson(url, options = {}) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    try {
      const response = await fetch(url, { ...options, signal: controller.signal });
      const body = await response.json();
      return { response, body };
    } finally { clearTimeout(timer); }
  }
  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
  const offlineKey = 'ww-image-studio-offline-only-v1';
  const conditionsKey = 'ww-image-studio-conditions-v2';
  let savedConditions = {};
  try {
    const saved = JSON.parse(localStorage.getItem(conditionsKey) || '{}');
    if (saved && typeof saved === 'object' && !Array.isArray(saved)) savedConditions = saved;
  } catch (_) {}

  function defaultsFor(axis, values, wife) {
    if (axis.startsWith('prompt')) return ['auto'];
    if (axis === 'character') return [wife];
    if (axis === 'men') return ['0', '1'];
    if (axis === 'exposure' || axis === 'aftermath') return ['none'];
    if (axis === 'variant') return ['0'];
    return values;
  }
  function restoreConditions(wife) {
    const saved = savedConditions[wife];
    state.selected = {};
    state.cloneSource = typeof saved?.cloneSource === 'string' ? saved.cloneSource : '';
    state.duplicateMode = saved?.duplicateMode === 'prompt-key' ? 'prompt-key' : 'composition';
    for (const [axis,values] of Object.entries(saved?.selected || {})) if (Array.isArray(values)) {
      state.selected[axis] = new Set(values.filter(value => typeof value === 'string')
        .map(value => axis === 'exposure' ? ImageStudio_노출코드정규화하기(value) || 'none' : value));
    }
  }
  function saveConditions() {
    if (!state.wife) return;
    savedConditions[state.wife] = {
      cloneSource: state.cloneSource,
      duplicateMode: state.duplicateMode,
      selected: Object.fromEntries(axisDefs.map(([axis]) => [axis, [...(state.selected[axis] || [])]])),
    };
    try { localStorage.setItem(conditionsKey, JSON.stringify(savedConditions)); } catch (_) {}
  }

  let offlineOnly = false;
  try { offlineOnly = localStorage.getItem(offlineKey) === 'true'; } catch (_) {}
  const offlineCheck = overlay.querySelector('#wwis-offline-only');
  offlineCheck.checked = offlineOnly;
  const applyOfflineOnly = () => { bridge()?.setOfflineOnly?.(offlineOnly); };
  offlineCheck.onchange = () => {
    offlineOnly = offlineCheck.checked;
    try { localStorage.setItem(offlineKey, String(offlineOnly)); } catch (_) {}
    applyOfflineOnly();
  };
  applyOfflineOnly();
  let lockWifeOutfit = false;
  try { lockWifeOutfit = localStorage.getItem(outfitLockKey) === 'true'; } catch (_) {}
  const outfitLockCheck = overlay.querySelector('#wwis-lock-wife-outfit');
  outfitLockCheck.checked = lockWifeOutfit;
  const applyOutfitLock = () => { bridge()?.setOutfitLock?.(lockWifeOutfit); };
  outfitLockCheck.onchange = () => {
    lockWifeOutfit = outfitLockCheck.checked;
    try { localStorage.setItem(outfitLockKey, String(lockWifeOutfit)); } catch (_) {}
    applyOutfitLock();
  };
  applyOutfitLock();

  const field = (key, prefix) => key.split('__').find(part => part.startsWith(prefix + '-'))?.slice(prefix.length + 1) || '';
  const situation = key => field(key, 'scene') || field(key, 'task') || '기타';
  const roomOf = key => (field(key, 'room') || '기타') + (field(key, 'abed') ? ' (침대 위)' : '');
  const signature = key => key.includes('__') ? key.slice(key.indexOf('__')) : key;
  const partnerOf = value => value.startsWith('patron_') || value === 'bath_with_patron' || value.startsWith('bath_attendant') ? 'patron'
    : value === 'self_pleasure' || value === 'bath_solo' || ['idle', 'greeting', 'taking_order', 'serving', 'cleaning', 'cooking', 'passed_out', 'bathing', 'sleeping', 'resting'].includes(value) ? 'solo' : 'husband';
  const menOf = key => {
    const group = Number(field(key, 'grp'));
    if (Number.isInteger(group) && group > 0) return String(group + 1);
    return field(key, 'task') || partnerOf(situation(key)) === 'solo' ? '0' : '1';
  };
  // --- 조건 창을 열 때만 이미지 목록의 추가 조건을 수집합니다. ---
  // 목록이 갱신되면 배열 참조가 바뀝니다. 같은 목록은 다시 읽거나 정규화하지 않습니다.
  // 기본 조건은 매번 별도로 합쳐서, 새 의상·확장 등록과 편집한 이름은 즉시 반영합니다.
  let catalogueAxesSource = null, catalogueAxes = null;
  function axesWithCatalogue(base) {
    const axes = Object.fromEntries(Object.entries(base).map(([axis, items]) => [axis, items.map(item => ({ ...item }))]));
    // 프리셋과 이미지팩 모두 같은 대표 코드로 합친 뒤 목록에 넣습니다.
    axes.exposure = [...new Map(axes.exposure.map(item => {
      const value = ImageStudio_노출코드정규화하기(item.value) || 'none';
      return [value, { ...item, value }];
    })).values()];
    const known = Object.fromEntries(Object.entries(axes)
      .map(([axis, items]) => [axis, new Set(items.map(item => String(item.value)))]));
    const add = (axis, value, extra = {}) => {
      if (axis === 'exposure') value = ImageStudio_노출코드정규화하기(value) || 'none';
      if (!value || known[axis].has(String(value))) return;
      known[axis].add(String(value));
      axes[axis].push({ value: String(value), ...extra });
    };

    if (catalogueAxesSource !== state.catalogue) {
      const collected = new Map(Object.keys(axes).map(axis => [axis, new Map()]));
      const collect = (axis, value, extra = {}) => {
        if (axis === 'exposure') value = ImageStudio_노출코드정규화하기(value) || 'none';
        if (value && !collected.get(axis).has(String(value))) {
          collected.get(axis).set(String(value), { value: String(value), ...extra });
        }
      };
      for (const entry of state.catalogue) {
        const key = entry.talentName;
        if (!key?.includes('__')) continue;
        // 각 키를 한 번만 나눕니다. 같은 필드가 반복되면 기존 field()와 같이 첫 값을 사용합니다.
        const fields = Object.create(null);
        for (const part of key.split('__')) {
          const separator = part.indexOf('-');
          if (separator < 0) continue;
          const id = part.slice(0, separator);
          if (!Object.prototype.hasOwnProperty.call(fields, id)) fields[id] = part.slice(separator + 1);
        }
        const moment = fields.scene || fields.task || '기타';
        if (moment !== '기타') collect('situation', moment, { kind: fields.task ? 'task' : 'scene' });
        collect('outfit', fields.outfit);
        collect('room', (fields.room || '기타') + (fields.abed ? ' (침대 위)' : ''));
        collect('mood', fields.mood || 'default');
        const group = Number(fields.grp);
        const men = Number.isInteger(group) && group > 0 ? String(group + 1)
          : fields.task || partnerOf(moment) === 'solo' ? '0' : '1';
        collect('men', men);
        collect('roles', fields.gslot);
        collect('exposure', fields.exp || 'none');
        collect('aftermath', fields.aft || 'none');
        if (/^[0-3]$/.test(fields.v)) collect('variant', fields.v);
      }
      catalogueAxes = [...collected].map(([axis, items]) => [axis, [...items.values()]]);
      catalogueAxesSource = state.catalogue;
    }
    for (const [axis, items] of catalogueAxes) {
      for (const { value, ...extra } of items) add(axis, value, extra);
    }
    return axes;
  }
  function matchesSelection(key, selected) {
    const has = (axis, value) => valuesOf(selected, axis).includes(String(value));
    const roles = field(key, 'gslot');
    return has('situation', situation(key)) && has('outfit', field(key, 'outfit')) && has('room', roomOf(key))
      && has('mood', field(key, 'mood') || 'default') && has('men', menOf(key))
      && (!roles || has('roles', roles)) && has('exposure', ImageStudio_노출코드정규화하기(field(key, 'exp')) || 'none')
      && has('aftermath', field(key, 'aft') || 'none') && has('variant', field(key, 'v') || '0');
  }
  const setMessage = text => {
    state.message = text;
    const node = content.querySelector('#wwis-message');
    if (node) node.textContent = text;
  };

  function loadCatalogue(force = false) {
    if (cataloguePending) return cataloguePending;
    if (!force && catalogueLoadedAt && Date.now() - catalogueLoadedAt < 30000) return Promise.resolve();
    cataloguePending = imageStudio_loadCatalogue().finally(() => { cataloguePending = null; });
    return cataloguePending;
  }
  async function imageStudio_loadCatalogue() {
    globalThis.WW_ImageStudioMatching?.refresh?.();
    const b = bridge();
    let readyTimer;
    try {
      await Promise.race([b?.ready?.(), new Promise((_, reject) => {
        readyTimer = setTimeout(() => reject(new Error('이미지팩 초기화 응답 시간 초과. 서버 상태를 확인한 뒤 다시 확인을 눌러 주세요.')), 8000);
      })]);
    } finally { clearTimeout(readyTimer); }
    const packs = (b?.packs() || []).slice();
    const url = b?.connection()?.baseUrl;
    if (url) try {
      const { response, body } = await imageStudio_requestJson(url + '/api/pack', { credentials: 'omit' });
      if (response.ok) packs.push(body);
    } catch (_) {}
    packs.sort((a, b) => (a.priority || 0) - (b.priority || 0) || String(a.generatedAt).localeCompare(String(b.generatedAt)));
    // 집계·조건 목록·파일 대조에 앞서 일반 이미지 범위만 선택합니다.
    const candidates = packs.flatMap(pack => Object.values(pack.entries || {}))
      .filter(entry => entry?.talentName && typeof entry.imagePath === 'string');
    const normalizePath = path => path.replace(/\\/g, '/').replace(/^\.\//, '');
    let missingPaths = null;
    state.catalogueVerified = false;
    state.catalogueWarning = '';
    if (url) try {
      const paths = [...new Set(candidates.map(entry => normalizePath(entry.imagePath)))];
      const missing = new Set();
      for (let offset = 0; offset < paths.length; offset += 2000) {
        const { response, body: result } = await imageStudio_requestJson(url + '/api/image-cache/verify', {
          method: 'POST', credentials: 'omit', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ paths: paths.slice(offset, offset + 2000), refresh: offset === 0 }),
        });
        if (!response.ok) throw new Error('file verification unavailable');
        if (!Array.isArray(result.missing) || result.missing.some(path => typeof path !== 'string')) throw new Error('invalid file verification');
        result.missing.forEach(path => missing.add(normalizePath(path)));
      }
      missingPaths = missing;
      state.catalogueVerified = true;
    } catch (_) {
      state.catalogueWarning = '실제 파일을 확인하지 못해 이미지팩에 등록된 수를 표시합니다. 최신 이미지 서버를 다시 실행한 뒤 확인해 주세요.';
    }
    const merged = new Map();
    for (const entry of candidates) {
      if (!missingPaths || !missingPaths.has(normalizePath(entry.imagePath))) merged.set(entry.talentName, entry);
    }
    state.catalogue = [...merged.values()];
    catalogueLoadedAt = Date.now();
  }

  function counts() {
    const mine = state.catalogue.filter(entry => entry.talentName?.startsWith(state.wife + '__'));
    const group = fn => Object.entries(mine.reduce((result, entry) => {
      const key = fn(entry.talentName); result[key] = (result[key] || 0) + 1; return result;
    }, {})).sort((a, b) => b[1] - a[1]);
    return {
      total: mine.length,
      situation: group(situation), room: group(roomOf),
      outfit: group(key => field(key, 'outfit') || '기타'),
      mood: group(key => moodLabels[field(key, 'mood') || 'default'] || field(key, 'mood')),
    };
  }

  function choose(wife) {
    state.wife = wife; state.conditionalOpen = false; state.hStatusOpen = false; state.options = {}; state.lastPlan = null;
    restoreConditions(wife); render(); void refresh();
  }
  async function refresh(force = false) {
    try {
      await loadCatalogue(force);
      if (state.wife && content.querySelector('#wwis-generation') && !state.busy) render();
    } catch (error) { setMessage(`이미지 목록을 읽지 못했습니다: ${error?.message || error}`); }
  }

  function imageStudio_refreshWifeNames() {
    const roster = bridge()?.characters?.();
    for (const character of roster?.characters || []) names[character.id] = character.name;
    return roster;
  }

  async function imageStudio_discoverWives(onCharacter = () => {}, onStatus = () => {}) {
    if (state.discoverBusy) return;
    state.discoverBusy = true;
    const activeButton = content.querySelector('#wwis-discover-wives');
    if (activeButton) activeButton.disabled = true;
    const report = { found: 0, added: 0, existing: 0, skipped: 0, failed: [] };
    const status = message => { state.discoveryMessage = message; onStatus(message); };
    try {
      const roster = imageStudio_refreshWifeNames();
      if (!roster) throw new Error('캐릭터 목록 연결을 찾지 못했습니다. 게임을 새로고침해 주세요.');
      report.found = roster.characters.length;
      report.skipped = roster.skipped;
      const characters = roster.characters.filter(character => {
        if (character.originalPrompt) return true;
        report.skipped++; return false;
      });
      if (!characters.length) { status(`등록할 캐릭터 외형 프롬프트가 없습니다. 제외 ${report.skipped}명.`); return report; }
      const url = bridge()?.connection()?.baseUrl;
      if (!url) throw new Error(`게임에서 ${report.found}명을 찾았습니다. 서버에 저장하려면 Start_ImageStudio.cmd를 실행한 뒤 다시 탐색해 주세요.`);
      status(`캐릭터 ${characters.length}명을 한 번에 확인하는 중…`);
      const batch = await imageStudio_requestJson(url + '/api/generation/characters/discover-batch', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'omit',
        body: JSON.stringify({ characters }),
      });
      if (batch.response.ok) {
        for (const item of batch.body.results) {
          if (item.added) report.added++; else report.existing++;
          onCharacter(item.character);
        }
      } else if (batch.response.status !== 404) throw new Error(batch.body.error || `HTTP ${batch.response.status}`);
      // Compatibility with earlier servers. A timeout stops the scan instead
      // of repeating the same eight-second wait for every remaining wife.
      if (batch.response.status === 404)
      for (const [index, character] of characters.entries()) {
        status(`캐릭터를 찾고 등록하는 중… ${index + 1}/${characters.length} · ${character.name}`);
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 8000);
        try {
          const response = await fetch(url + '/api/generation/characters/discover', {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'omit',
            signal: controller.signal, body: JSON.stringify(character),
          });
          const body = await response.json().catch(() => ({}));
          if (!response.ok) throw new Error(response.status === 404
            ? '실행 중인 서버가 캐릭터 등록 API를 지원하지 않습니다. Start_ImageStudio.cmd로 다시 시작해 주세요.'
            : body.error || `HTTP ${response.status}`);
          if (body.added) report.added++; else report.existing++;
          onCharacter(body.character || character);
        } catch (error) {
          report.failed.push(`${character.name}: ${error?.name === 'AbortError' ? '서버 응답 시간 초과' : error?.message || error}`);
          if (error?.name === 'AbortError' || error instanceof TypeError) break;
        } finally { clearTimeout(timer); }
      }
      status(`탐색 ${report.found}명 · 새로 추가 ${report.added}명 · 기존 유지 ${report.existing}명 · 제외 ${report.skipped}명 · 실패 ${report.failed.length}명. ${report.added ? '추가한 캐릭터 설정을 저장하고 즉시 적용했습니다.' : '기존 인물 설정을 유지했습니다.'}${report.failed.length ? ` 실패 항목은 다시 탐색하면 재시도합니다. ${report.failed.join(' / ')}` : ''}`);
      return report;
    } catch (error) { status(error?.name === 'AbortError' ? '서버 응답 시간이 초과됐습니다. 실행 중인 캐시 작업과 이미지 서버 창을 확인한 뒤 다시 탐색해 주세요.' : String(error?.message || error)); return report; }
    finally {
      state.discoverBusy = false;
      const activeButton = content.querySelector('#wwis-discover-wives');
      if (activeButton) activeButton.disabled = false;
    }
  }
  bridge().discoverWives = imageStudio_discoverWives;

  async function showGenerationSettings() {
    const load = {};
    generationSettingsLoad = load;
    const url = bridge()?.connection()?.baseUrl;
    if (!url) {
      content.innerHTML = `<div class="wwis-row"><button id="wwis-settings-back">← 인물 선택</button></div><p class="wwis-setting-status">이미지 생성 서버에 연결해 주세요. Start_ImageStudio.cmd를 먼저 실행해야 설정을 저장할 수 있습니다.</p>`;
      content.querySelector('#wwis-settings-back').onclick = render;
      return;
    }
    content.innerHTML = '<p class="wwis-setting-status">이미지 생성 설정을 읽는 중…</p>';
    let settings;
    try {
      const response = await fetch(url + '/api/generation/settings', { credentials: 'omit' });
      const body = await response.json().catch(() => ({}));
      if (generationSettingsLoad !== load || overlay.hidden) return;
      if (!response.ok) throw new Error(response.status === 404
        ? await ImageStudio_서버지원오류읽기(url, '생성 방식 설정')
        : body.error || `HTTP ${response.status}`);
      settings = body;
    } catch (error) {
      if (generationSettingsLoad !== load || overlay.hidden) return;
      content.innerHTML = `<div class="wwis-row"><button id="wwis-settings-back">← 인물 선택</button></div><p class="wwis-setting-status">${escapeHtml(error?.message || error)}</p>`;
      content.querySelector('#wwis-settings-back').onclick = render;
      return;
    }

    const sdxlSizeSupported = Number.isFinite(settings.sdxlWidth) && Number.isFinite(settings.sdxlHeight);
    const wifeLorasSupported = Number(settings.version) >= 15;
    const promptBatchSupported = Number(settings.version) >= 16;
    const promptBatchMax = Number(settings.version) >= 17 ? 128 : 16;
    const animaFolderSupported = typeof settings.animaSaveToIllustrious === 'boolean';
    const naiSupported = Number(settings.version) >= 19;
    const naiOptions = (values, selected) => values.map(value => `<option value="${escapeHtml(value)}" ${value === selected ? 'selected' : ''}>${escapeHtml(value)}</option>`).join('');
    content.innerHTML = `
      <div class="wwis-row wwis-generation-toolbar"><button id="wwis-settings-back">← 인물 선택</button><strong>이미지 생성 방식 지정</strong><button id="wwis-save-generation-top">설정 저장</button><span id="wwis-settings-unsaved" role="status"></span></div>
      <div class="wwis-card">
        <h3>이미지 생성 방식</h3>
        <div class="wwis-engine-choice">
          <label><span><input type="radio" name="wwis-provider" value="sdxl" ${settings.imageProvider === 'sdxl' ? 'checked' : ''}> <strong>SDXL · 기본 형태</strong></span><span class="wwis-dim">Illustrious 체크포인트와 선택 LoRA로 기존 Wayward 프롬프트를 생성합니다.</span></label>
          <label><span><input type="radio" name="wwis-provider" value="anima" ${settings.imageProvider === 'anima' ? 'checked' : ''}> <strong>Anima</strong></span><span class="wwis-dim">Anima UNET + Qwen 텍스트 인코더 + VAE + 여러 LoRA를 사용합니다.</span></label>
          <label><span><input type="radio" name="wwis-provider" value="nai" ${settings.imageProvider === 'nai' ? 'checked' : ''} ${naiSupported ? '' : 'disabled'}> <strong>NovelAI (NAI)</strong></span><span class="wwis-dim">NovelAI API로 생성합니다. ComfyUI와 로컬 GPU 없이 사용할 수 있습니다.</span></label>
        </div>
        <p class="wwis-dim">여기서 고른 방식은 일반 생성·검수 생성·조건부 대기열에 적용됩니다.</p>
        ${naiSupported ? '' : '<p class="wwis-setting-status">NAI를 사용하려면 이미지 서버를 종료한 뒤 Start_ImageStudio.cmd로 다시 실행하고 이 창을 다시 열어 주세요.</p>'}
      </div>
      <div class="wwis-card" id="wwis-comfy-settings">
        <h3>ComfyUI 설정</h3>
        <div class="wwis-settings-grid">
          <label class="wwis-wide">ComfyUI 주소<input id="wwis-comfy-url" value="${escapeHtml(settings.comfyUrl)}" placeholder="http://127.0.0.1:8188"></label>
          <label class="wwis-wide">동시 프롬프트 전달 개수<select id="wwis-prompt-batch-size" ${promptBatchSupported ? '' : 'disabled'}>${Array.from({ length: promptBatchMax }, (_, index) => index + 1).map(count => `<option value="${count}" ${count === (Number(settings.promptBatchSize) || 1) ? 'selected' : ''}>${count}개</option>`).join('')}</select></label>
          <label class="wwis-wide">ComfyUI models 폴더<input id="wwis-models-directory" value="${escapeHtml(settings.modelsDirectory)}" placeholder="...\\ComfyUI-Shared\\models"></label>
        </div>
        <p class="wwis-dim">대량·조건부 대기열에서 서로 다른 장면을 최대 선택 개수만큼 묶어 한 모델로 생성합니다. 같은 모델·LoRA·해상도·샘플러를 쓰는 항목만 묶으며, 일반·검수창의 단일 요청은 한 장을 생성합니다. 기본값은 1입니다. VRAM이 부족하면 이번 실행의 배치 크기를 줄여 재시도합니다.</p>
        <p id="wwis-prompt-batch-status" class="wwis-setting-status">${promptBatchSupported ? '동시 프롬프트 생성 지원을 확인하는 중…' : '동시 프롬프트 설정에는 포함된 서버 0.4.1이 필요합니다. wml\\mods\\imagestudio\\Start_ImageStudio.cmd로 서버를 다시 실행하고 이 창을 다시 열어 주세요.'}</p>
        <p class="wwis-dim">Windows의 RTX 50 계열에서 Anima 실행 중 ComfyUI가 종료되면 Comfy Desktop 실행 옵션에 <code>--disable-dynamic-vram --disable-async-offload --disable-cuda-malloc --lowvram --reserve-vram 1</code>을 사용하세요. 이 PC에서는 해당 안정 설정으로 실제 Anima 생성까지 확인했습니다.</p>
        <div class="wwis-row"><button id="wwis-pick-models">폴더 선택</button><button id="wwis-refresh-resources">모델 목록 다시 읽기</button><span id="wwis-resource-status" class="wwis-dim">모델 목록을 확인하지 않았습니다.</span></div>
      </div>
      <div class="wwis-card" id="wwis-sdxl-settings">
        <h3>SDXL · 기본 형태</h3>
        <div class="wwis-settings-grid">
          <label class="wwis-wide">체크포인트<input id="wwis-sdxl-checkpoint" list="wwis-checkpoints" value="${escapeHtml(settings.sdxlCheckpoint)}"></label>
          <label class="wwis-wide">공통 LoRA (빈 값이면 사용 안 함)<input id="wwis-sdxl-lora" list="wwis-loras" value="${escapeHtml(settings.sdxlLora)}"></label>
          <label>LoRA 강도<input id="wwis-sdxl-lora-strength" type="number" step="0.05" value="${escapeHtml(settings.sdxlLoraStrength)}"></label>
          <label>Steps<input id="wwis-sdxl-steps" type="number" min="1" max="150" value="${escapeHtml(settings.sdxlSteps)}"></label>
          <label>CFG<input id="wwis-sdxl-cfg" type="number" min="0" max="100" step="0.1" value="${escapeHtml(settings.sdxlCfg)}"></label>
          <label>Clip skip<input id="wwis-sdxl-clip-skip" type="number" max="0" value="${escapeHtml(settings.sdxlClipSkip)}"></label>
          <label>Sampler<input id="wwis-sdxl-sampler" value="${escapeHtml(settings.sdxlSampler)}"></label>
          <label>Scheduler<input id="wwis-sdxl-scheduler" value="${escapeHtml(settings.sdxlScheduler)}"></label>
          <label>가로 (px)<input id="wwis-sdxl-width" type="number" min="64" max="4096" step="8" value="${escapeHtml(settings.sdxlWidth ?? 1024)}"></label>
          <label>세로 (px)<input id="wwis-sdxl-height" type="number" min="64" max="4096" step="8" value="${escapeHtml(settings.sdxlHeight ?? 1024)}"></label>
          <p class="wwis-wide wwis-dim">기본 1024 × 1024 px. 64~4096 px 범위에서 8 px 단위로 저장하며, 새로 생성하는 일반 이미지와 조건부 대기열에 적용됩니다.</p>
          ${sdxlSizeSupported ? '' : '<p class="wwis-wide wwis-setting-status">현재 서버는 SDXL 이미지 크기 설정을 지원하지 않습니다. 이미지 서버 창을 종료하고 Start_ImageStudio.cmd로 다시 실행해 주세요.</p>'}
          <label class="wwis-wide">공통 기본 프롬프트<textarea id="wwis-sdxl-positive">${escapeHtml(settings.sdxlPositivePrompt)}</textarea></label>
          <label class="wwis-wide">공통 네거티브 프롬프트<textarea id="wwis-sdxl-negative">${escapeHtml(settings.sdxlNegativePrompt)}</textarea></label>
        </div>
      </div>
      <div class="wwis-card" id="wwis-nai-settings">
        <h3>NovelAI (NAI)</h3>
        <p class="wwis-dim">NovelAI 계정 설정 → Account → Get Persistent API Token에서 발급한 토큰을 입력하세요. 생성 시 구독 사용량 또는 Anlas가 소모될 수 있습니다.</p>
        <div class="wwis-settings-grid">
          <label class="wwis-wide">Persistent API Token<input id="wwis-nai-token" type="password" autocomplete="new-password" spellcheck="false" placeholder="${settings.naiTokenConfigured ? '저장된 토큰 사용 · 교체할 때만 입력' : 'NovelAI API 토큰 입력'}"></label>
          <label class="wwis-wide"><span><input id="wwis-nai-token-clear" type="checkbox"> 저장된 토큰 삭제</span></label>
          <label class="wwis-wide">모델<select id="wwis-nai-model">${naiOptions(settings.naiModels || ['nai-diffusion-5-full'], settings.naiModel || 'nai-diffusion-5-full')}</select></label>
          <label>가로 (px)<input id="wwis-nai-width" type="number" min="64" max="2048" step="64" value="${escapeHtml(settings.naiWidth ?? 832)}"></label>
          <label>세로 (px)<input id="wwis-nai-height" type="number" min="64" max="2048" step="64" value="${escapeHtml(settings.naiHeight ?? 1216)}"></label>
          <label>Steps<input id="wwis-nai-steps" type="number" min="1" max="50" value="${escapeHtml(settings.naiSteps ?? 28)}"></label>
          <label>Prompt Guidance<input id="wwis-nai-scale" type="number" min="0" max="10" step="0.1" value="${escapeHtml(settings.naiScale ?? 6.5)}"></label>
          <label>Sampler<select id="wwis-nai-sampler">${naiOptions(settings.naiSamplers || ['k_euler_ancestral'], settings.naiSampler || 'k_euler_ancestral')}</select></label>
          <label>Noise Schedule<select id="wwis-nai-schedule">${naiOptions(settings.naiNoiseSchedules || ['karras'], settings.naiNoiseSchedule || 'karras')}</select></label>
          <label class="wwis-wide">공통 기본 프롬프트<textarea id="wwis-nai-positive">${escapeHtml(settings.naiCommonPrompt || '')}</textarea></label>
          <label class="wwis-wide">작가·스타일 프롬프트<textarea id="wwis-nai-artist">${escapeHtml(settings.naiArtistPrompt || '')}</textarea></label>
          <label class="wwis-wide">공통 네거티브 프롬프트<textarea id="wwis-nai-negative">${escapeHtml(settings.naiNegativePrompt || '')}</textarea></label>
        </div>
        <p class="wwis-dim">게임의 인물·장면 프롬프트에 위 공통·작가 태그를 더합니다. SDXL·Anima의 공통 프롬프트와 LoRA는 적용하지 않습니다. 기준 이미지를 사용하는 img2img에는 SDXL 또는 Anima를 선택하세요.</p>
        <p class="wwis-dim">대기열은 한 장씩 생성합니다. 토큰은 이 PC의 이미지 서버 설정에 저장하며 화면에는 다시 표시하지 않습니다. 설정 파일을 다른 사람에게 공유하지 마세요.</p>
        <div class="wwis-row"><button id="wwis-nai-check">저장된 토큰 연결 확인</button><span id="wwis-nai-status" class="wwis-dim">${settings.naiTokenConfigured ? '토큰이 저장되어 있습니다.' : '토큰을 입력하고 아래 설정 저장을 눌러 주세요.'}</span></div>
      </div>
      <div class="wwis-card" id="wwis-anima-settings">
        <h3>Anima</h3>
        <p class="wwis-dim">체크포인트 칸이 아니라 아래 세 파일을 각각 불러오는 Anima 전용 워크플로입니다. GGUF 텍스트 인코더를 쓰면 ComfyUI-GGUF 노드가 필요합니다.</p>
        <div class="wwis-settings-grid">
          <label class="wwis-wide"><span><input id="wwis-anima-save-illustrious" type="checkbox" ${settings.animaSaveToIllustrious === true ? 'checked' : ''} ${animaFolderSupported ? '' : 'disabled'}> 생성 이미지를 illustrious 폴더에 저장</span><span class="wwis-dim">선택하면 images/illustrious/characters/[캐릭터]에 저장합니다. 해제하면 images/anima/characters/[캐릭터]에 저장합니다. 생성 모델과 캐시 구분은 Anima로 유지되며 기존 파일은 이동하지 않습니다.</span></label>
          ${animaFolderSupported ? '' : '<p class="wwis-setting-status wwis-wide">저장 폴더 선택에는 서버 0.4.7이 필요합니다. 이 모드 폴더의 Start_ImageStudio.cmd로 서버를 다시 실행하고 이 창을 다시 열어 주세요.</p>'}
          <label class="wwis-wide">Anima 모델 (diffusion_models)<input id="wwis-anima-model" list="wwis-diffusion-models" value="${escapeHtml(settings.model)}"></label>
          <label class="wwis-wide">Qwen 텍스트 인코더<input id="wwis-anima-clip" list="wwis-text-encoders" value="${escapeHtml(settings.clip)}"></label>
          <label>텍스트 인코더 장치<select id="wwis-anima-clip-device"><option value="cpu" ${settings.clipDevice !== 'default' ? 'selected' : ''}>CPU (8GB VRAM 권장)</option><option value="default" ${settings.clipDevice === 'default' ? 'selected' : ''}>GPU / 자동</option></select></label>
          <label class="wwis-wide">VAE<input id="wwis-anima-vae" list="wwis-vaes" value="${escapeHtml(settings.vae)}"></label>
          <label class="wwis-wide">Anima LoRA 폴더<input id="wwis-anima-lora-directory" value="${escapeHtml(settings.loraDirectory)}"></label>
          <label>가로<input id="wwis-anima-width" type="number" min="64" max="4096" step="16" value="${escapeHtml(settings.width)}"></label>
          <label>세로<input id="wwis-anima-height" type="number" min="64" max="4096" step="16" value="${escapeHtml(settings.height)}"></label>
          <label>Steps<input id="wwis-anima-steps" type="number" min="1" max="150" value="${escapeHtml(settings.steps)}"></label>
          <label>CFG<input id="wwis-anima-cfg" type="number" min="0" max="100" step="0.1" value="${escapeHtml(settings.cfg)}"></label>
          <label>Sampler<input id="wwis-anima-sampler" value="${escapeHtml(settings.sampler)}"></label>
          <label>Scheduler<input id="wwis-anima-scheduler" value="${escapeHtml(settings.scheduler)}"></label>
          <label class="wwis-wide">공통 기본 프롬프트<textarea id="wwis-anima-positive">${escapeHtml(settings.positivePrompt)}</textarea></label>
          <label class="wwis-wide">공통 네거티브 프롬프트<textarea id="wwis-anima-negative">${escapeHtml(settings.negativePrompt)}</textarea></label>
        </div>
        <div class="wwis-row"><strong>Anima LoRA</strong><button id="wwis-add-lora">+ LoRA 추가</button></div>
        <div id="wwis-anima-lora-rows"></div>
      </div>
      <div class="wwis-card">
        <div class="wwis-row"><h3 style="margin:0">캐릭터 기본 프롬프트</h3><button id="wwis-discover-wives">새로운 캐릭터 찾기</button><button id="wwis-add-character">+ 캐릭터 추가</button></div>
        <p class="wwis-dim">게임에 등록된 캐릭터의 이름과 외형 프롬프트를 찾아 서버에 자동 저장합니다. 기존 인물 설정과 이 화면에서 수정 중인 값은 유지합니다.</p>
        <p id="wwis-discovery-status" class="wwis-dim" role="status"></p>
        <p class="wwis-dim">Anima 생성 시 게임의 기존 인물 외형 태그를 이 값으로 교체합니다. 장면·의상·표정·장소 태그는 유지됩니다.</p>
        <p class="wwis-dim">캐릭터별 LoRA는 SDXL·Anima에 따로 저장하며 일반 생성·검수 생성·조건부 대기열에 적용됩니다. 별도 지정은 공통 LoRA를 대체하고, 공통에 추가는 두 목록을 함께 사용합니다. 빈 별도 목록과 사용 안 함은 LoRA를 끕니다.</p>
        ${wifeLorasSupported ? '' : "<p class=\"wwis-setting-status\">캐릭터별 LoRA를 지정하려면 서버를 종료하고 Start_ImageStudio.cmd로 서버 0.3.2를 다시 실행한 뒤 이 창을 다시 열어 주세요.</p>"}
        <div id="wwis-character-rows"></div>
      </div>
      <datalist id="wwis-checkpoints"></datalist><datalist id="wwis-loras"></datalist><datalist id="wwis-diffusion-models"></datalist><datalist id="wwis-text-encoders"></datalist><datalist id="wwis-vaes"></datalist>
      <div class="wwis-row"><button id="wwis-save-generation" class="wwis-settings-launch">설정 저장 및 즉시 적용</button></div>
      <p id="wwis-settings-status" class="wwis-setting-status">설정을 바꾼 뒤 저장해 주세요.</p>`;

    const byId = id => content.querySelector('#' + id);
    const inputValue = id => byId(id)?.value ?? '';
    const numberValue = (id, fallback) => {
      const value = Number(inputValue(id));
      return Number.isFinite(value) ? value : fallback;
    };
    const updateProviderVisibility = () => {
      const provider = content.querySelector('input[name="wwis-provider"]:checked')?.value || 'sdxl';
      byId('wwis-sdxl-settings').hidden = provider !== 'sdxl';
      byId('wwis-anima-settings').hidden = provider !== 'anima';
      byId('wwis-nai-settings').hidden = provider !== 'nai';
      byId('wwis-comfy-settings').hidden = provider === 'nai';
      for (const group of content.querySelectorAll('[data-wife-engine]')) group.hidden = group.dataset.wifeEngine !== provider;
    };
    for (const radio of content.querySelectorAll('input[name="wwis-provider"]')) radio.onchange = updateProviderVisibility;
    updateProviderVisibility();
    byId('wwis-nai-check').onclick = async () => {
      const status = byId('wwis-nai-status'), button = byId('wwis-nai-check');
      status.textContent = '저장된 토큰의 연결을 확인하는 중…'; button.disabled = true;
      try {
        const response = await fetch(url + '/api/nai/check', { method: 'POST', credentials: 'omit' });
        const body = await response.json();
        if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
        status.textContent = body.active ? 'NovelAI 연결 확인 · 활성 구독입니다.' : 'NovelAI 연결 확인 · 활성 구독이 없습니다.';
      } catch (error) { status.textContent = `연결 확인 실패: ${error?.message || error}`; }
      finally { button.disabled = false; }
    };

    const addLoraRow = lora => {
      const row = document.createElement('div'); row.className = 'wwis-lora-row';
      row.innerHTML = `<label><input data-field="enabled" type="checkbox" ${lora?.enabled ? 'checked' : ''}> 사용</label><input data-field="name" list="wwis-loras" value="${escapeHtml(lora?.name || '')}" placeholder="LoRA 파일명" style="flex:1;min-width:220px"><label>강도 <input data-field="strength" type="number" step="0.05" value="${escapeHtml(lora?.strength ?? 1)}" style="width:82px"></label><button data-remove>삭제</button>`;
      row.querySelector('[data-remove]').onclick = () => row.remove();
      byId('wwis-anima-lora-rows').append(row);
    };
    for (const lora of settings.loras || []) addLoraRow(lora);
    byId('wwis-add-lora').onclick = () => addLoraRow({ name: '', enabled: true, strength: 1 });

    function ImageStudio_아내LoRA항목추가하기(target, lora = {}) {
      const row = document.createElement('div'); row.className = 'wwis-lora-row';
      row.innerHTML = `<label><input data-field="enabled" type="checkbox" ${lora.enabled !== false ? 'checked' : ''}> 사용</label><input data-field="name" list="wwis-loras" value="${escapeHtml(lora.name || '')}" placeholder="LoRA 파일명" style="flex:1;min-width:120px"><label>강도 <input data-field="strength" type="number" min="-20" max="20" step="0.05" value="${escapeHtml(lora.strength ?? 1)}" style="width:72px"></label><button data-lora-remove>삭제</button>`;
      row.querySelector('[data-lora-remove]').onclick = () => row.remove(); target.append(row);
    }
    function ImageStudio_아내LoRA목록읽기(row, engine) {
      return [...row.querySelectorAll(`[data-wife-loras="${engine}"] .wwis-lora-row`)].map(item => ({
        name: item.querySelector('[data-field=name]').value.trim(), enabled: item.querySelector('[data-field=enabled]').checked,
        strength: Number(item.querySelector('[data-field=strength]').value) || 0,
      })).filter(item => item.name);
    }
    const addCharacterRow = character => {
      const row = document.createElement('div'); row.className = 'wwis-character-row';
      row.innerHTML = `<div class="wwis-character-head"><input data-field="id" value="${escapeHtml(character?.id || '')}" placeholder="id (예: hina)" style="width:120px"><input data-field="name" value="${escapeHtml(character?.name || '')}" placeholder="표시 이름"><button data-remove>삭제</button></div><label class="wwis-dim">기본 프롬프트<textarea data-field="prompt">${escapeHtml(character?.prompt || '')}</textarea></label><label class="wwis-dim">캐릭터 네거티브 프롬프트<textarea data-field="negativePrompt">${escapeHtml(character?.negativePrompt || '')}</textarea></label><input data-field="originalPrompt" type="hidden" value="${escapeHtml(character?.originalPrompt || '')}"><input data-field="originalNegativePrompt" type="hidden" value="${escapeHtml(character?.originalNegativePrompt || '')}">`;
      row.querySelector('[data-remove]').onclick = () => row.remove();
      const loraBox = document.createElement('details');
      loraBox.innerHTML = "<summary>캐릭터별 LoRA 설정</summary>" + (wifeLorasSupported ? '' : "<p class=\"wwis-setting-status\" data-wife-lora-unavailable>현재 연결된 서버가 캐릭터별 LoRA를 지원하지 않아 선택을 잠갔어요. 이미지 서버를 종료하고 Start_ImageStudio.cmd로 서버 0.3.2를 실행한 뒤, 이 설정 창을 닫았다가 다시 열어 주세요.</p>");
      for (const engine of ['sdxl', 'anima']) {
        const group = document.createElement('fieldset'); group.dataset.wifeEngine = engine;
        group.disabled = !wifeLorasSupported; group.style.cssText = 'border:0;padding:8px 0;min-width:0';
        const mode = character?.[engine + 'LoraMode'] || 'inherit';
        group.innerHTML = `<label>${engine === 'sdxl' ? 'SDXL' : 'Anima'} LoRA 적용 <select data-field="${engine}LoraMode">${[['inherit','공통 LoRA 사용'],['replace',"이 캐릭터의 LoRA만 사용"],['append','공통 LoRA에 추가'],['none','LoRA 사용 안 함']].map(([value,label]) => `<option value="${value}" ${mode === value ? 'selected' : ''}>${label}</option>`).join('')}</select></label><div data-wife-lora-editor><div data-wife-loras="${engine}"></div><button data-lora-add>+ LoRA 추가</button></div><p class="wwis-dim">${engine === 'sdxl' ? 'SDXL용 LoRA를 지정하세요. 모델과 텍스트 인코더에 같은 강도를 적용합니다.' : 'Anima용 LoRA를 지정하세요. 공통의 속도 LoRA를 유지하려면 공통에 추가를 선택하세요.'}</p>`;
        const list = group.querySelector('[data-wife-loras]'), select = group.querySelector('select');
        for (const lora of character?.[engine + 'Loras'] || []) ImageStudio_아내LoRA항목추가하기(list, lora);
        const update = () => { group.querySelector('[data-wife-lora-editor]').hidden = !['replace','append'].includes(select.value); };
        select.onchange = () => { if (['replace','append'].includes(select.value) && !list.children.length) ImageStudio_아내LoRA항목추가하기(list); update(); };
        group.querySelector('[data-lora-add]').onclick = () => ImageStudio_아내LoRA항목추가하기(list);
        update(); loraBox.append(group);
      }
      row.append(loraBox);
      byId('wwis-character-rows').append(row);
      updateProviderVisibility();
    };
    for (const character of settings.characters || []) addCharacterRow(character);
    byId('wwis-add-character').onclick = () => addCharacterRow({ id: '', name: '', prompt: '', negativePrompt: '' });
    const characterRows = byId('wwis-character-rows');
    const discoveryButton = byId('wwis-discover-wives');
    discoveryButton.disabled = state.discoverBusy;
    discoveryButton.onclick = async () => {
      discoveryButton.disabled = true;
      await imageStudio_discoverWives(character => {
        if (!characterRows.isConnected) return;
        const existingRow = [...characterRows.children].find(row => row.querySelector('[data-field=id]').value.trim().toLowerCase() === character.id);
        if (!existingRow) addCharacterRow(character);
        else for (const field of ['originalPrompt', 'originalNegativePrompt']) {
          const input = existingRow.querySelector(`[data-field=${field}]`);
          if (!input.value && character[field]) input.value = character[field];
        }
      }, message => {
        if (characterRows.isConnected) byId('wwis-discovery-status').textContent = message;
      });
      discoveryButton.disabled = false;
    };

    const fillDatalist = (id, values) => {
      const list = byId(id); list.textContent = '';
      for (const value of values || []) { const option = document.createElement('option'); option.value = value; list.append(option); }
    };
    const refreshResources = async () => {
      const status = byId('wwis-resource-status'); status.textContent = '모델 목록을 읽는 중…';
      try {
        const query = new URLSearchParams({ comfyUrl: inputValue('wwis-comfy-url'), modelsDirectory: inputValue('wwis-models-directory') });
        const response = await fetch(url + '/api/generation/resources?' + query, { credentials: 'omit' });
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
        fillDatalist('wwis-checkpoints', body.checkpoints); fillDatalist('wwis-loras', body.loras);
        fillDatalist('wwis-diffusion-models', body.diffusionModels); fillDatalist('wwis-text-encoders', body.textEncoders); fillDatalist('wwis-vaes', body.vaes);
        status.textContent = `${body.source === 'comfyui' ? 'ComfyUI 원격 목록' : 'models 폴더'} · 체크포인트 ${(body.checkpoints || []).length} · LoRA ${(body.loras || []).length} · Anima 모델 ${(body.diffusionModels || []).length} · 인코더 ${(body.textEncoders || []).length} · VAE ${(body.vaes || []).length}`;
      } catch (error) { status.textContent = `모델 목록을 읽지 못했습니다: ${error?.message || error}`; }
    };
    const refreshPromptBatchSupport = async () => {
      if (!promptBatchSupported) return;
      const status = byId('wwis-prompt-batch-status');
      try {
        const response = await fetch(url + '/api/generation/prompt-batch-support?' + new URLSearchParams({ comfyUrl: inputValue('wwis-comfy-url') }), { credentials: 'omit' });
        const body = await response.json();
        if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
        status.textContent = body.supported ? `동시 프롬프트 생성 노드가 연결되었습니다. 1~${promptBatchMax}개를 설정하고 저장하세요.${promptBatchMax < 128 ? ' 128개 설정은 기존 서버를 종료하고 wml\\mods\\imagestudio\\Start_ImageStudio.cmd로 포함된 서버 0.4.1을 실행하세요.' : ' 이전 16개용 노드는 Install_ComfyUI_PromptBatch.cmd로 갱신한 뒤 ComfyUI를 재시작하세요.'}`
          : body.reachable ? '2개 이상에는 포함된 노드 설치가 필요합니다. wml\\mods\\imagestudio\\Install_ComfyUI_PromptBatch.cmd를 실행하고 ComfyUI를 재시작하세요. 1개는 기존 방식으로 작동합니다.'
          : 'ComfyUI에 연결할 수 없어 동시 프롬프트 지원을 확인하지 못했습니다.';
      } catch (error) { status.textContent = `동시 프롬프트 지원을 확인하지 못했습니다: ${error?.message || error}`; }
    };
    byId('wwis-refresh-resources').onclick = () => { void refreshResources(); void refreshPromptBatchSupport(); };
    byId('wwis-comfy-url').addEventListener('change', () => { void refreshPromptBatchSupport(); });
    byId('wwis-pick-models').onclick = async () => {
      const status = byId('wwis-resource-status'); status.textContent = '폴더 선택 창을 기다리는 중…';
      try {
        const response = await fetch(url + '/api/generation/select-models-folder', { method: 'POST', credentials: 'omit' });
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
        if (body.cancelled) { status.textContent = '폴더 선택을 취소했습니다.'; return; }
        byId('wwis-models-directory').value = body.modelsDirectory;
        byId('wwis-anima-lora-directory').value = body.modelsDirectory.replace(/[\\/]$/, '') + '\\loras';
        await refreshResources();
      } catch (error) { status.textContent = `폴더를 선택하지 못했습니다: ${error?.message || error}`; }
    };

    const saveGenerationSettings = async () => {
      if (generationSettingsEditor?.saving) return false;
      const status = byId('wwis-settings-status'); status.textContent = '설정을 저장하는 중…';
      if (state.discoverBusy) {
        status.textContent = "그녀 탐색이 끝난 뒤 설정을 저장해 주세요.";
        return false;
      }
      if (!sdxlSizeSupported && (numberValue('wwis-sdxl-width', 1024) !== 1024 || numberValue('wwis-sdxl-height', 1024) !== 1024)) {
        status.textContent = 'SDXL 이미지 크기를 저장하려면 이미지 서버 창을 종료하고 Start_ImageStudio.cmd로 다시 실행한 뒤 이 설정 화면을 다시 열어 주세요.';
        return false;
      }
      const loras = [...content.querySelectorAll('#wwis-anima-lora-rows .wwis-lora-row')].map(row => ({
        enabled: row.querySelector('[data-field=enabled]').checked,
        name: row.querySelector('[data-field=name]').value.trim(),
        strength: Number(row.querySelector('[data-field=strength]').value) || 0,
      })).filter(lora => lora.name);
      const characters = [...content.querySelectorAll('#wwis-character-rows .wwis-character-row')].map(row => ({
        id: row.querySelector('[data-field=id]').value.trim().toLowerCase(),
        name: row.querySelector('[data-field=name]').value.trim(),
        prompt: row.querySelector('[data-field=prompt]').value.trim(),
        negativePrompt: row.querySelector('[data-field=negativePrompt]').value.trim(),
        originalPrompt: row.querySelector('[data-field=originalPrompt]').value,
        originalNegativePrompt: row.querySelector('[data-field=originalNegativePrompt]').value,
        sdxlLoraMode: row.querySelector('[data-field=sdxlLoraMode]').value,
        sdxlLoras: ImageStudio_아내LoRA목록읽기(row, 'sdxl'),
        animaLoraMode: row.querySelector('[data-field=animaLoraMode]').value,
        animaLoras: ImageStudio_아내LoRA목록읽기(row, 'anima'),
      })).filter(character => character.id);
      const next = {
        ...settings,
        imageProvider: content.querySelector('input[name="wwis-provider"]:checked')?.value || 'sdxl',
        ...(naiSupported ? {
          naiToken: inputValue('wwis-nai-token'), naiTokenClear: byId('wwis-nai-token-clear').checked,
          naiModel: inputValue('wwis-nai-model'), naiWidth: numberValue('wwis-nai-width', 832), naiHeight: numberValue('wwis-nai-height', 1216),
          naiSteps: numberValue('wwis-nai-steps', 28), naiScale: numberValue('wwis-nai-scale', 6.5),
          naiSampler: inputValue('wwis-nai-sampler'), naiNoiseSchedule: inputValue('wwis-nai-schedule'),
          naiCommonPrompt: inputValue('wwis-nai-positive'), naiArtistPrompt: inputValue('wwis-nai-artist'), naiNegativePrompt: inputValue('wwis-nai-negative'),
        } : {}),
        ...(animaFolderSupported ? { animaSaveToIllustrious: byId('wwis-anima-save-illustrious').checked } : {}),
        comfyUrl: inputValue('wwis-comfy-url'), modelsDirectory: inputValue('wwis-models-directory'),
        ...(promptBatchSupported ? { promptBatchSize: numberValue('wwis-prompt-batch-size', 1) } : {}),
        sdxlCheckpoint: inputValue('wwis-sdxl-checkpoint'), sdxlLora: inputValue('wwis-sdxl-lora'),
        sdxlLoraStrength: numberValue('wwis-sdxl-lora-strength', 1), sdxlSteps: numberValue('wwis-sdxl-steps', 9),
        sdxlCfg: numberValue('wwis-sdxl-cfg', 1.5), sdxlClipSkip: numberValue('wwis-sdxl-clip-skip', -2),
        sdxlSampler: inputValue('wwis-sdxl-sampler'), sdxlScheduler: inputValue('wwis-sdxl-scheduler'),
        sdxlWidth: numberValue('wwis-sdxl-width', 1024), sdxlHeight: numberValue('wwis-sdxl-height', 1024),
        sdxlPositivePrompt: inputValue('wwis-sdxl-positive'), sdxlNegativePrompt: inputValue('wwis-sdxl-negative'),
        model: inputValue('wwis-anima-model'), clip: inputValue('wwis-anima-clip'), clipDevice: inputValue('wwis-anima-clip-device'), vae: inputValue('wwis-anima-vae'),
        loraDirectory: inputValue('wwis-anima-lora-directory'), width: numberValue('wwis-anima-width', 832), height: numberValue('wwis-anima-height', 1216),
        steps: numberValue('wwis-anima-steps', 30), cfg: numberValue('wwis-anima-cfg', 4),
        sampler: inputValue('wwis-anima-sampler'), scheduler: inputValue('wwis-anima-scheduler'),
        positivePrompt: inputValue('wwis-anima-positive'), negativePrompt: inputValue('wwis-anima-negative'), loras, characters,
      };
      const editor = generationSettingsEditor;
      editor.saving = true;
      // 저장 중에는 입력과 중복 저장을 막습니다. 응답 전에는 나가거나 미저장 표시를 지우지 않습니다.
      content.inert = true;
      editor.update();
      try {
        const response = await fetch(url + '/api/generation/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, credentials: 'omit', signal: AbortSignal.timeout(15000), body: JSON.stringify(next) });
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
        settings = body.settings;
        if (naiSupported) {
          byId('wwis-nai-token').value = '';
          byId('wwis-nai-token').placeholder = settings.naiTokenConfigured ? '저장된 토큰 사용 · 교체할 때만 입력' : 'NovelAI API 토큰 입력';
          byId('wwis-nai-token-clear').checked = false;
          byId('wwis-nai-status').textContent = settings.naiTokenConfigured ? '토큰이 저장되어 있습니다.' : '저장된 토큰이 없습니다.';
        }
        byId('wwis-sdxl-width').value = settings.sdxlWidth ?? 1024;
        byId('wwis-sdxl-height').value = settings.sdxlHeight ?? 1024;
        byId('wwis-prompt-batch-size').value = settings.promptBatchSize ?? 1;
        status.textContent = settings.imageProvider === 'nai'
          ? `NovelAI 설정을 저장하고 즉시 적용했습니다. ${settings.naiWidth} × ${settings.naiHeight} px · ${settings.naiModel} · 한 장씩 생성합니다.`
          : `${settings.imageProvider === 'anima' ? 'Anima' : 'SDXL · 기본 형태'} 설정을 저장하고 즉시 적용했습니다.${promptBatchSupported ? ` 동시 프롬프트: 최대 ${settings.promptBatchSize}개.` : ''}${settings.imageProvider === 'sdxl' ? ` 이미지 크기: ${settings.sdxlWidth ?? 1024} × ${settings.sdxlHeight ?? 1024} px.` : animaFolderSupported ? ` 저장 폴더: images/${settings.animaSaveToIllustrious ? 'illustrious' : 'anima'}.` : ''}`;
        editor.baseline = editor.snapshot();
        return true;
      } catch (error) {
        status.textContent = `설정을 저장하지 못했습니다: ${error?.message || error}`;
        status.scrollIntoView({ block: 'nearest' });
        return false;
      } finally {
        editor.saving = false;
        content.inert = false;
        editor.update();
      }
    };
    byId('wwis-save-generation').onclick = saveGenerationSettings;
    byId('wwis-save-generation-top').onclick = saveGenerationSettings;
    byId('wwis-settings-back').onclick = () => ImageStudio_생성설정나가기(render);

    // 동적 캐릭터·LoRA 행과 숨겨진 다른 엔진의 입력도 비교합니다. 값을 되돌리면 변경 없음으로 처리합니다.
    const editor = {
      baseline: '', saving: false, prompt: null, save: saveGenerationSettings,
      snapshot: () => JSON.stringify([...content.querySelectorAll('input,select,textarea')].map(input =>
        [input.id, input.dataset.field || '', input.type, input.value, input.checked || false])),
      dirty: () => editor.snapshot() !== editor.baseline,
      update: () => {
        if (generationSettingsEditor !== editor) return;
        const dirty = editor.dirty();
        const indicator = byId('wwis-settings-unsaved');
        const message = editor.saving ? '저장하는 중…' : dirty ? '저장되지 않은 변경사항이 있습니다.' : '모든 변경사항이 저장되어 있습니다.';
        if (indicator.textContent !== message) indicator.textContent = message;
        indicator.dataset.dirty = String(dirty);
        for (const id of ['wwis-save-generation', 'wwis-save-generation-top']) byId(id).disabled = editor.saving;
      },
      observer: new MutationObserver(() => editor.update()),
    };
    editor.baseline = editor.snapshot();
    generationSettingsEditor = editor;
    generationSettingsLoad = null;
    editor.observer.observe(content, { childList: true, subtree: true });
    editor.update();
    if (settings.imageProvider !== 'nai') {
      void refreshResources();
      void refreshPromptBatchSupport();
    }
  }

  function render() {
    if (generationSettingsEditor) return;
    generationSettingsLoad = null;
    imageStudio_refreshWifeNames();
    const settingsButton = '<button class="wwis-settings-launch" id="wwis-generation-settings">⚙ 이미지 생성 방식 지정</button><button class="wwis-settings-launch" id="wwis-prompt-edit" style="margin-top:8px">프롬프트 수정</button><button class="wwis-settings-launch" id="wwis-usage-statistics" style="margin-top:8px">이미지별 사용 통계</button>';
    if (!state.wife) {
      content.innerHTML = `${settingsButton}<div class="wwis-row"><button id="wwis-cache-sync">전체 이미지 캐시 초기화</button></div><p class="wwis-dim">전체 캐시를 실제 파일과 다시 대조하여 누락 항목과 변경된 경로를 정리합니다.</p><p id="wwis-cache-sync-result" class="wwis-dim" role="status"></p><p>인물을 선택하세요.</p><div class="wwis-row" id="wwis-people"></div><p class="wwis-dim">현재 캐릭터와 무관하게 여러 인물을 한 번에 조건부 생성할 수 있습니다.</p>`;
      content.querySelector('#wwis-generation-settings').onclick = () => { void showGenerationSettings(); };
      content.querySelector('#wwis-cache-sync').onclick = () => { void syncImageCache(); };
      content.querySelector('#wwis-cache-sync').disabled = cacheBusy;
      content.querySelector('#wwis-cache-sync-result').textContent = cacheMessage;
      taskProgress.paint('cache');
      const discoveryRow = document.createElement('div'); discoveryRow.className = 'wwis-row';
      const discoveryButton = document.createElement('button'); discoveryButton.id = 'wwis-discover-wives';
      discoveryButton.textContent = '새로운 캐릭터 찾기'; discoveryButton.disabled = state.discoverBusy;
      const discoveryStatus = document.createElement('p'); discoveryStatus.id = 'wwis-discovery-status';
      discoveryStatus.className = 'wwis-dim'; discoveryStatus.setAttribute('role', 'status');
      discoveryStatus.textContent = state.discoveryMessage || '게임에 등록된 캐릭터의 이름과 외형 프롬프트를 찾아 서버에 자동 저장합니다.';
      discoveryRow.append(discoveryButton);
      const cacheRow = content.querySelector('#wwis-cache-sync').parentElement;
      cacheRow.before(discoveryRow, discoveryStatus);
      discoveryButton.onclick = async () => {
        discoveryButton.disabled = true;
        await imageStudio_discoverWives(undefined, message => {
          if (discoveryStatus.isConnected) discoveryStatus.textContent = message;
        });
        discoveryButton.disabled = false;
        if (content.querySelector('#wwis-people')) render();
      };
      const row = content.querySelector('#wwis-people');
      const current = bridge()?.currentWife();
      for (const [id, label] of Object.entries(names)) {
        const button = document.createElement('button'); button.textContent = label + (current === id ? " · 현재 캐릭터" : '');
        button.onclick = () => choose(id); row.append(button);
      }
      return;
    }
    const summary = counts();
    content.innerHTML = `${settingsButton}<div class="wwis-row"><button id="wwis-back">← 인물 선택</button><strong>${names[state.wife] || state.wife}</strong><span>보유 이미지 ${summary.total.toLocaleString()}장</span><button id="wwis-refresh">다시 확인</button></div><div class="wwis-card wwis-counts" id="wwis-counts"></div><div class="wwis-card"><div class="wwis-row"><button id="wwis-random">▶ 전체 랜덤 생성</button><button id="wwis-conditional">▶ 조건부 생성</button></div><div id="wwis-generation"></div></div><div class="wwis-card" id="wwis-pack-card"><h3>이미지 팩 생성</h3><div class="wwis-row"><button id="wwis-pack">팩 만들기</button></div><p class="wwis-dim">images/illustrious/characters/ 아래의 일반 이미지만 취합합니다. situation 폴더는 제외합니다. 특정 그녀의 일반 이미지를 취합하여 &quot;images-[그녀 이름]-custom.js&quot;로 파일을 생성합니다. 실제 게임 인식을 위해서는 뒤의 custom을 지우고, images-[그녀 이름]-1.js 또는 images-[그녀 이름]-2.js로 변경해주세요.</p><p class="wwis-dim">캐시와 기존 이미지팩의 조건 기록을 실제 파일과 대조합니다. 같은 조건은 최신 생성 이미지 한 장을 선택하며, 조건 기록이 없는 파일은 제외합니다. 현재 게임은 번호 1과 2만 읽습니다. 기존 번호 팩이 있다면 먼저 백업한 뒤 교체하세요. JS 파일은 게임 HTML 옆에 두고 images 폴더도 함께 유지해야 합니다.</p><div class="wwis-dim" id="wwis-pack-result" role="status"></div></div><p id="wwis-message" role="status">${state.message}</p>`;
    const countLabel = content.querySelector('.wwis-row > span');
    if (countLabel) countLabel.textContent = `${state.catalogueVerified ? '보유 이미지' : '등록 이미지'} ${summary.total.toLocaleString()}장`;
    if (state.catalogueWarning) {
      const warning = document.createElement('p');
      warning.className = 'wwis-dim'; warning.textContent = state.catalogueWarning;
      content.querySelector('.wwis-row').after(warning);
    }
    content.querySelector('#wwis-pack-result').textContent = state.packResults[state.wife] || '';
    content.querySelector('#wwis-pack').disabled = state.packBusy.has(state.wife);
    content.querySelector('#wwis-generation-settings').onclick = () => { void showGenerationSettings(); };
    const countBox = content.querySelector('#wwis-counts');
    for (const [key, label] of [['situation', '장면/작업'], ['room', '장소'], ['outfit', '의상'], ['mood', '기분']]) {
      const column = document.createElement('div'), heading = document.createElement('strong'); heading.textContent = label; column.append(heading);
      for (const [value, count] of summary[key].slice(0, 16)) { const line = document.createElement('div'); line.textContent = `${value}: ${count.toLocaleString()}`; column.append(line); }
      countBox.append(column);
    }
    content.querySelector('#wwis-back').onclick = () => { state.wife = ''; state.conditionalOpen = false; state.hStatusOpen = false; render(); };
    content.querySelector('#wwis-refresh').onclick = () => { void refresh(true); };
    const characterCacheButton = document.createElement('button');
    characterCacheButton.id = 'wwis-character-cache-sync';
    characterCacheButton.textContent = '이미지 캐시 초기화';
    characterCacheButton.title = `${names[state.wife] || state.wife}의 캐시만 실제 파일과 다시 대조합니다.`;
    characterCacheButton.disabled = cacheBusy;
    characterCacheButton.onclick = () => { void syncImageCache(state.wife); };
    content.querySelector('#wwis-refresh').after(characterCacheButton);
    const cacheResult = document.createElement('p');
    cacheResult.id = 'wwis-cache-sync-result'; cacheResult.className = 'wwis-dim';
    cacheResult.setAttribute('role', 'status'); cacheResult.textContent = cacheMessage;
    characterCacheButton.parentElement.after(cacheResult);
    taskProgress.paint('cache');
    content.querySelector('#wwis-random').onclick = () => {
      overlay.hidden = true;
      if (bridge()?.openRandom) bridge().openRandom(state.wife);
      else { overlay.hidden = false; setMessage('WML에서 이미지 스튜디오 연결을 불러오지 못했습니다. 모드 관리 창에서 이미지 스튜디오를 껐다 켜고 게임을 새로 시작해 주세요.'); }
    };
    content.querySelector('#wwis-conditional').onclick = () => { void showConditional(); };
    const hStatusButton = document.createElement('button');
    hStatusButton.id = 'wwis-h-status'; hStatusButton.textContent = '▶ H_status용 이미지 생성';
    content.querySelector('#wwis-conditional').after(hStatusButton);
    hStatusButton.onclick = () => { if (!state.busy) void ImageStudio_HStatus설정열기(); };
    content.querySelector('#wwis-pack').onclick = () => { void buildPack(); };
    if (state.hStatusOpen) void ImageStudio_HStatus설정열기();
    else if (state.conditionalOpen) void showConditional();
  }

  async function ImageStudio_HStatus설정열기() {
    const box = content.querySelector('#wwis-generation'), characterId = state.wife;
    state.hStatusOpen = true; state.conditionalOpen = false;
    const regularPack = content.querySelector('#wwis-pack-card'); if (regularPack) regularPack.hidden = true;
    await ImageStudio_HStatus설정그리기({ box, bridge: bridge(), characterId, name: names[characterId] || characterId,
      selection: hStatusSelections[characterId] ||= {},
      isCurrent: () => box.isConnected && state.wife === characterId && state.hStatusOpen,
      isBusy: () => state.busy,
      setBusy: value => {
        state.busy = value;
        for (const id of ['wwis-back', 'wwis-refresh', 'wwis-random', 'wwis-conditional', 'wwis-h-status', 'wwis-generation-settings', 'wwis-prompt-edit']) {
          const button = content.querySelector('#' + id); if (button) button.disabled = value;
        }
      }, taskProgress, setMessage, buildPack: buildHStatusPack });
  }

  function optionLabel(axis, item, includeId = true) {
    const value = String(item.value);
    if(axis==='room'&&value==='bedroom (침대 위)')return '침실 · 침대 위' + (includeId ? ' (bedroom, abed=1)' : '');
    let label = item.label || '';
    if (axis === 'situation' && situationGroup(value, item.kind) === 'contact_patron') {
      label = label.replace(/^(?:Patron[\s:_-]*|손님(?:과|의|에게서?|이)?\s*)/i, '');
    }
    if (label) return label + (includeId ? ` (${value})` : '');
    if (axis === 'character') return names[value] || value;
    if (axis === 'mood') return moodLabels[value] || value;
    if (axis === 'aftermath') return `${value} — ${aftermathLabels[value] || value}`;
    if (axis === 'exposure') {
      if (value === 'none') return '없음 (exp 키 없음)';
      const active = [...value].map((bit, index) => bit === '1' ? exposureFields[index] : '').filter(Boolean);
      return `exp-${value} — ${active.join(' · ') || '노출 없음'}`;
    }
    if (axis === 'roles') return `gslot-${value} — ${[...value].map((code, index) => `남성 ${index + 1}: ${roleLabels[code] || code}`).join(', ')}`;
    return value;
  }

  async function showConditional() {
    const box = content.querySelector('#wwis-generation'), wife = state.wife;
    state.hStatusOpen = false;
    const regularPack = content.querySelector('#wwis-pack-card'); if (regularPack) regularPack.hidden = false;
    state.conditionalOpen = true; box.textContent = '게임의 이미지 조건 목록을 읽는 중…';
    const b = bridge();
    if (!b?.axes || !b?.list) { box.textContent = 'WML 조건 생성 연결을 불러오지 못했습니다. 모드 관리 창에서 이미지 스튜디오를 껐다 켜고 게임을 새로 시작해 주세요.'; return; }
    let promptAxes;
    try {
      promptAxes = globalThis.WW_ImageStudioPrompt?.axes?.() || [];
      for (const extra of promptAxes) if (!axisDefs.some(([axis]) => axis === extra.id)) axisDefs.push([extra.id,extra.label]);
      // Conditions come from the game. File verification updates separately
      // and must never prevent this panel from opening.
      state.options = axesWithCatalogue(b.axes());
      for (const extra of promptAxes) state.options[extra.id] = extra.items;
    }
    catch (error) { box.textContent = `이미지 조건을 읽지 못했습니다: ${error?.message || error}`; return; }
    if (!box.isConnected || state.wife !== wife) return;
    for (const [axis] of axisDefs) {
      const values = (state.options[axis] || []).map(item => String(item.value));
      if (!state.selected[axis]) state.selected[axis] = new Set(defaultsFor(axis, values, wife));
      else state.selected[axis] = new Set([...state.selected[axis]].filter(value => values.includes(value)));
      if (axis.startsWith('prompt') && !state.selected[axis].size) state.selected[axis].add('auto');
    }

    box.innerHTML = `<div class="wwis-source"><div class="wwis-row"><label>구성 원본 <select id="wwis-source"><option value="">직접 선택한 조건 조합</option></select></label></div><p class="wwis-dim">원본 인물을 고르면 그 인물이 실제로 보유한 구성 키만 대상 인물의 프롬프트로 다시 만듭니다. 외형만 대상 인물로 바뀌며, 대상에 이미 같은 구성이 있으면 선택한 중복 기준에 따라 제외됩니다.</p></div><details id="wwis-details" open><summary>세부 조건 <span id="wwis-actions"></span></summary><div id="wwis-axes"></div></details><div class="wwis-row"><button id="wwis-enqueue-new">선택 조건 중 미중복 파일 대기열에 추가</button><span class="wwis-random-enqueue"><button id="wwis-enqueue-random">선택 조건 중 임의의 조합 대기열에 추가</button><label>수량 <input id="wwis-random-count" type="number" min="1" max="120000" step="1" value="${state.randomCount}"></label></span></div><p class="wwis-dim">만들 구도(v-0~v-3)를 직접 선택합니다. 첫 버튼은 팩·로컬 캐시의 중복을 뺀 전체 조합을 만듭니다. 두 번째 버튼은 조합을 먼저 추첨하고 뽑힌 프롬프트만 계산하며, 중복은 다른 조합으로 보충합니다. 탐색 한도나 후보 부족으로 수량을 채우지 못하면 확보한 수량과 이유를 표시합니다.</p><div class="wwis-card"><strong>보유/중복 검사</strong><div class="wwis-row"><label>중복 기준 <select id="wwis-duplicate-mode"><option value="composition">기본 구성</option><option value="prompt-key">프롬프트 키 포함</option></select></label></div><p class="wwis-dim">기본 구성은 인물·장면/작업·의상·장소·기분·남성 수(grp)·역할(gslot)·노출(exp)·사후 상태(aft)·구도(v)·침대·마무리 상태를 비교합니다. 현재 상태나 프롬프트 수정으로 붙은 서명이 달라도 같은 구성은 보유로 처리합니다. 자세·상태·대화 등 프롬프트 서명별로 새 이미지를 만들려면 “프롬프트 키 포함”을 선택하세요.</p><div id="wwis-duplicate-report" class="wwis-dim">아직 검사하지 않았습니다.</div></div>`;
    const source = box.querySelector('#wwis-source');
    for (const [id, label] of Object.entries(names)) source.add(new Option(label, id));
    source.value = state.cloneSource;
    source.onchange = () => { state.cloneSource = source.value; selectionChanged(); };
    const duplicateMode = box.querySelector('#wwis-duplicate-mode');
    duplicateMode.value = state.duplicateMode;
    duplicateMode.onchange = () => { state.duplicateMode = duplicateMode.value; selectionChanged(); };

    const actions = box.querySelector('#wwis-actions');
    for (const [label, all] of [['모두 선택', true], ['모두 해제', false]]) {
      const button = document.createElement('button'); button.textContent = label; button.style.marginLeft = '5px';
      button.onclick = event => {
        event.preventDefault(); event.stopPropagation();
        for (const [axis] of axisDefs) setAxisSelection(axis, all ? state.options[axis].map(item => String(item.value)) : axis.startsWith('prompt') ? ['auto'] : []);
        selectionChanged();
      };
      actions.append(button);
    }

    const axesHost = box.querySelector('#wwis-axes');
    const extraSections = new Map();
    const extraNote = document.createElement('p'); extraNote.className = 'wwis-dim';
    extraNote.textContent = '프롬프트 세부 조건은 아래 접힌 영역에서 고릅니다. 같은 항목에서 여러 값을 선택하면 각각 별도 조합으로 생성합니다. 자세·체위는 어울리는 장면에만 적용되고, 맞지 않는 장면에서는 원래 장면 프롬프트를 유지합니다. 명시한 나쁜 손님 모드용·상세 상태 영역은 자동 판정 대신 선택값을 사용합니다. H Status와 출산 후 처치 장면은 추가 장면/작업에 모아 표시하며, H Status와 대화의 착의 조건도 적용합니다.';
    const idGuide = document.createElement('span'); idGuide.className = 'wwis-id-guide';
    idGuide.append(document.createTextNode('제목 옆의 주황 글씨는 게임에서 인식하는 ID이며, '));
    const vanillaGuide = document.createElement('span'); vanillaGuide.className = 'wwis-id-guide-vanilla'; vanillaGuide.textContent = '바닐라ID는 주황';
    const modGuide = document.createElement('span'); modGuide.className = 'wwis-id-guide-mod'; modGuide.textContent = '모드ID는 노란색입니다';
    idGuide.append(vanillaGuide, document.createTextNode(', '), modGuide);
    extraNote.append(document.createElement('br'), idGuide);
    axesHost.append(extraNote);
    function setAxisSelection(axis, values) {
      state.selected[axis] = new Set(values.map(String));
      for (const input of axesHost.querySelectorAll(`input[type="checkbox"][data-axis="${axis}"]`)) {
        input.checked = state.selected[axis].has(input.dataset.value);
      }
    }
    function selectionChanged() { state.lastPlan = null; saveConditions(); renderDuplicateAudit(null); }
    for (const [axis, label] of axisDefs) {
      const card = document.createElement('div'); card.className = 'wwis-card';
      const extra = promptAxes.find(extra => extra.id === axis);
      const heading = document.createElement('strong'); heading.textContent = label;
      const axisActions = document.createElement('span'); axisActions.className = 'wwis-axis-actions';
      for (const [text, all] of [['모두 선택', true], ['모두 해제', false]]) {
        const button = document.createElement('button'); button.type = 'button'; button.textContent = text;
        button.onclick = event => {
          event.preventDefault(); event.stopPropagation();
          setAxisSelection(axis, all ? state.options[axis].map(item => String(item.value)) : axis.startsWith('prompt') ? ['auto'] : []);
          selectionChanged();
        };
        axisActions.append(button);
      }
      card.append(heading, axisActions);
      const grid = document.createElement('div'); grid.className = axis === 'situation' ? 'wwis-situation-groups' : 'wwis-grid';
      const appendOption = (item, host, groupId = '') => {
        const value = String(item.value), row = document.createElement('label'), input = document.createElement('input');
        input.type = 'checkbox'; input.dataset.axis = axis; input.dataset.value = value; input.checked = state.selected[axis].has(value);
        input.dataset.idOrigin = b.idOrigin(axis,value);
        if (groupId) input.dataset.situationGroup = groupId;
        input.onchange = () => {
          if (input.checked) {
            if (axis.startsWith('prompt') && value !== 'auto' && state.selected[axis].size === 1 && state.selected[axis].has('auto')) state.selected[axis].delete('auto');
            state.selected[axis].add(value);
          } else state.selected[axis].delete(value);
          if (axis.startsWith('prompt')) setAxisSelection(axis,state.selected[axis].size ? [...state.selected[axis]] : ['auto']);
          selectionChanged();
        };
        row.append(input, document.createTextNode(optionLabel(axis, item, false))); host.append(row);
      };
      if (axis === 'situation') {
        for (const [groupId, groupLabel] of situationGroupDefs) {
          const items = state.options[axis].filter(item => situationGroup(item.value, item.kind) === groupId);
          if (!items.length) continue;
          const group = document.createElement('div'); group.className = 'wwis-situation-group';
          const groupHead = document.createElement('div'); groupHead.className = 'wwis-situation-group-head';
          const groupTitle = document.createElement('strong'); groupTitle.textContent = `${groupLabel} (${items.length})`; groupHead.append(groupTitle);
          const values = items.map(item => String(item.value));
          for (const [text, all] of [['그룹 선택', true], ['그룹 해제', false]]) {
            const button = document.createElement('button'); button.type = 'button'; button.textContent = text;
            button.onclick = event => {
              event.preventDefault(); event.stopPropagation();
              for (const value of values) all ? state.selected[axis].add(value) : state.selected[axis].delete(value);
              setAxisSelection(axis, [...state.selected[axis]]); selectionChanged();
            };
            groupHead.append(button);
          }
          const groupGrid = document.createElement('div'); groupGrid.className = 'wwis-grid';
          for (const item of items) appendOption(item, groupGrid, groupId);
          group.append(groupHead, groupGrid); grid.append(group);
        }
      } else {
        for (const item of state.options[axis]) appendOption(item, grid);
      }
      card.append(grid);
      if (extra) {
        if (!extraSections.has(extra.section)) {
          const section = document.createElement('details'); section.className = 'wwis-card'; section.dataset.promptSection = extra.section;
          const summary = document.createElement('summary'); summary.textContent = extra.section; section.append(summary); axesHost.append(section); extraSections.set(extra.section,section);
        }
        extraSections.get(extra.section).append(card);
      } else axesHost.append(card);
    }
    const randomCount = box.querySelector('#wwis-random-count');
    randomCount.onchange = () => {
      state.randomCount = Math.max(1, Math.min(120000, Math.floor(Number(randomCount.value) || 1)));
      randomCount.value = String(state.randomCount);
    };
    box.querySelector('#wwis-enqueue-new').onclick = () => { void enqueueSelection(); };
    box.querySelector('#wwis-enqueue-random').onclick = () => { randomCount.onchange(); void enqueueSelection(state.randomCount); };
    box.querySelector('#wwis-enqueue-new').disabled = state.busy;
    box.querySelector('#wwis-enqueue-random').disabled = state.busy;
    const cancelButton = document.createElement('button');
    cancelButton.id = 'wwis-plan-cancel'; cancelButton.textContent = '취소하기';
    cancelButton.style.cssText = 'margin-top:8px;display:none';
    cancelButton.onclick = () => { planningController?.abort(); paintPlanningCancel(); };
    box.querySelector('#wwis-enqueue-new').parentElement.after(cancelButton);
    paintPlanningCancel();
    taskProgress.paint('generation');
  }

  const valuesOf = (selected, axis) => {
    const values = selected[axis];
    const list = values instanceof Set ? [...values] : Array.isArray(values) ? values : [];
    return axis === 'exposure' ? [...new Set(list.map(value => ImageStudio_노출코드정규화하기(value) || 'none'))] : list;
  };
  const selectionForBridge = selected => Object.fromEntries(axisDefs.filter(([axis]) => axis !== 'character').map(([axis]) => [axis, valuesOf(selected, axis)]));

  const createDuplicateAudit = () => Object.fromEntries(axisDefs.map(([axis]) => [axis, new Map()]));
  function recordDuplicateAudit(audit, talentId) {
    const axes = bridge()?.keyAxes?.(talentId);
    if (!axes) return;
    for (const [axis] of axisDefs) {
      const value = String(axes[axis] ?? 'none'), counts = audit[axis];
      counts.set(value, (counts.get(value) || 0) + 1);
    }
  }
  const imageIdentity = talentId => bridge()?.identity?.(talentId) || talentId;
  function ImageStudio_보유식별자읽기(talentId, duplicateMode) {
    return bridge()?.identity?.(talentId, duplicateMode === 'prompt-key') || talentId;
  }

  function auditValueLabel(axis, value) {
    const item = (state.options[axis] || []).find(entry => String(entry.value) === String(value));
    if (item) return optionLabel(axis, item);
    if (axis === 'roles') return value === 'none' ? '추가 역할 없음' : `gslot-${value}`;
    if (axis === 'exposure') return value === 'none' ? '노출 지정 없음' : `exp-${value}`;
    if (axis === 'variant') return `v-${value}`;
    if (axis === 'men') return `${value}명`;
    return value;
  }

  function renderDuplicateAudit(plan) {
    const node = content.querySelector('#wwis-duplicate-report');
    if (!node) return;
    node.replaceChildren();
    if (!plan) { node.textContent = '조건이 바뀌었습니다. 다음 대기열 추가 때 다시 검사합니다.'; return; }
    const summary = document.createElement('div');
    summary.textContent = `${plan.sampling ? '무작위로 검사한 범위에서 ' : ''}${plan.duplicateMode === 'prompt-key' ? '프롬프트 키 포함' : '기본 구성'} 기준 보유 ${plan.ownedDuplicates.toLocaleString()}장 · 계획 안의 동일 키 ${plan.plannedDuplicates.toLocaleString()}장 · 대기열 후보 ${plan.queue.length.toLocaleString()}장${ImageStudio_랜덤검사안내읽기(plan)}`;
    node.append(summary);
    if (!plan.ownedDuplicates) return;
    const grid = document.createElement('div'); grid.className = 'wwis-audit-grid';
    for (const [axis, label] of axisDefs) {
      const entries = [...plan.duplicateAudit[axis].entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
      if (!entries.length) continue;
      const row = document.createElement('div');
      const shown = entries.slice(0, 6).map(([value, count]) => `${auditValueLabel(axis, value)} ${count.toLocaleString()}장`);
      row.textContent = `${label}: ${shown.join(' · ')}${entries.length > 6 ? ` · 그 외 ${entries.length - 6}종` : ''}`;
      grid.append(row);
    }
    node.append(grid);
  }

  async function buildPlanFor(selected, cloneSource, progress = () => {}, duplicateMode = 'composition', signal) {
    checkPlanningCancelled(signal);
    await waitForPlanning(loadCatalogue(), signal);
    checkPlanningCancelled(signal);
    const targets = valuesOf(selected, 'character');
    if (!targets.length) throw new Error('생성할 인물을 한 명 이상 선택해 주세요.');
    for (const [axis, label] of axisDefs) if (axis !== 'character' && !axis.startsWith('prompt') && !valuesOf(selected, axis).length) throw new Error(`${label}에서 한 개 이상 선택해 주세요.`);
    const held = new Set(state.catalogue.map(entry => ImageStudio_보유식별자읽기(entry.talentName, duplicateMode)));
    const sourceTalentIds = cloneSource ? state.catalogue.filter(entry => entry.talentName?.startsWith(cloneSource + '__')).map(entry => entry.talentName) : [];
    const sourceKeys = cloneSource ? new Set(sourceTalentIds.map(signature)) : null;
    if (sourceKeys && !sourceKeys.size) throw new Error(`${names[cloneSource] || cloneSource}의 원본 구성 키를 찾지 못했습니다.`);
    const queue = [], seen = new Set(), duplicateAudit = createDuplicateAudit();
    let candidates = 0, ownedDuplicates = 0, plannedDuplicates = 0, outsideSource = 0;
    const include = item => {
      checkPlanningCancelled(signal);
      candidates++;
      const identity = imageIdentity(item.talentId);
      if (held.has(ImageStudio_보유식별자읽기(item.talentId, duplicateMode))) { ownedDuplicates++; recordDuplicateAudit(duplicateAudit, item.talentId); return; }
      if (seen.has(identity)) { plannedDuplicates++; return; }
      seen.add(identity); queue.push({ ...item, weight: bridge().weight(item.talentId) });
    };
    const detail = () => `큐 후보 ${queue.length.toLocaleString()}장 · 보유 중복 ${ownedDuplicates.toLocaleString()}장 · 계획 중복 ${plannedDuplicates.toLocaleString()}장`;
    if (sourceKeys) {
      if (!bridge().fromKey) throw new Error('WML 구성 복제 연결을 불러오지 못했습니다. 모드 관리 창에서 이미지 스튜디오를 껐다 켜고 게임을 새로 시작해 주세요.');
      const filtered = sourceTalentIds.filter(key => matchesSelection(key, selected));
      const details = globalThis.WW_ImageStudioPrompt?.combinationSpace?.(selectionForBridge(selected));
      const detailCount = details?.count ?? 1n;
      if (detailCount > 120000n) throw new Error('세부 조건 조합이 120,000개를 넘었습니다. 선택을 줄여 주세요.');
      let processed = 0;
      const report = () => progress({ stage: 'clone', label: '원본 구성 확인', current: processed, total: (BigInt(filtered.length * targets.length) * detailCount).toString(), detail: detail() });
      report();
      const checkpoint = ImageStudio_계산묶음만들기(report, signal);
      for (const target of targets) {
        for (let index = 0; index < filtered.length; index++) {
          for (let detailIndex = 0n; detailIndex < detailCount; detailIndex++) {
            checkPlanningCancelled(signal);
            const talentId = target + signature(filtered[index]);
            const items = bridge().fromKey(target, talentId, selectionForBridge(selected), true, details?.at(detailIndex));
            if (!items?.length) outsideSource++;
            for (const item of items || []) include(item);
            const pause = checkpoint(++processed);
            if (pause) await pause;
          }
        }
      }
      report();
      queue.sort((a, b) => (b.weight || 0) - (a.weight || 0) || a.talentId.localeCompare(b.talentId));
      return { queue, candidates, duplicates: ownedDuplicates + plannedDuplicates, ownedDuplicates, plannedDuplicates, duplicateAudit, outsideSource, sourceCount: sourceKeys.size, duplicateMode };
    }
    for (const [targetIndex, target] of targets.entries()) {
      checkPlanningCancelled(signal);
      const label = `${names[target] || target} · 인물 ${targetIndex + 1}/${targets.length}`;
      progress({ stage: `plan-${targetIndex}`, label: `${label} · 전체 조합 계산`, current: 0, total: null });
      const items = await waitForPlanning(bridge().list(target, selectionForBridge(selected), status => { checkPlanningCancelled(signal); progress({
        stage: `plan-${targetIndex}`, label: `${label} · 전체 조합 계산`, current: status.current, total: status.total,
        detail: `프롬프트 후보 ${status.candidates.toLocaleString()}장`,
      }); }, signal), signal);
      checkPlanningCancelled(signal);
      const report = current => progress({ stage: `duplicates-${targetIndex}`, label: `${label} · 보유/중복 확인`, current, total: items.length, detail: detail() });
      report(0);
      const checkpoint = ImageStudio_계산묶음만들기(report, signal);
      for (let index = 0; index < items.length; index++) {
        include(items[index]);
        const pause = checkpoint(index + 1);
        if (pause) await pause;
      }
      report(items.length);
    }
    queue.sort((a, b) => (b.weight || 0) - (a.weight || 0) || a.talentId.localeCompare(b.talentId));
    return { queue, candidates, duplicates: ownedDuplicates + plannedDuplicates, ownedDuplicates, plannedDuplicates, duplicateAudit, outsideSource, sourceCount: sourceKeys?.size || 0, duplicateMode };
  }

  const buildPlan = () => buildPlanFor(state.selected, state.cloneSource, generationProgress, state.duplicateMode);

  function ImageStudio_랜덤정수뽑기(limit) {
    if (limit <= 0n) throw Error('추첨할 조합이 없습니다.');
    if (limit === 1n) return 0n;
    const bits = (limit - 1n).toString(2).length;
    let value;
    do {
      value = 0n;
      for (let remaining = bits; remaining > 0; remaining -= 26) {
        const width = Math.min(26,remaining);
        value = (value << BigInt(width)) | BigInt(Math.floor(Math.random() * 2 ** width));
      }
    } while (value >= limit);
    return value;
  }

  async function ImageStudio_랜덤생성계획하기(selected, cloneSource, requested, progress = () => {}, duplicateMode = 'composition', signal) {
    checkPlanningCancelled(signal);
    selected = Object.fromEntries(Object.keys(selected).map(axis => [axis,valuesOf(selected,axis)]));
    const bridgeSelected = Object.fromEntries(Object.entries(selected).filter(([axis]) => axis !== 'character'));
    const targets = valuesOf(selected,'character');
    if (!targets.length) throw Error('생성할 인물을 한 명 이상 선택해 주세요.');
    for (const [axis,label] of axisDefs) if (axis !== 'character' && !axis.startsWith('prompt') && !valuesOf(selected,axis).length) throw Error(`${label}에서 한 개 이상 선택해 주세요.`);
    const b = bridge(), prompt = globalThis.WW_ImageStudioPrompt;
    if (!b?.randomSpace || !prompt?.combinationSpace) throw Error('랜덤 생성 연결을 불러오지 못했습니다. 게임을 새로고침해 주세요.');
    requested = Math.max(1,Math.min(120000,Math.floor(Number(requested) || 1)));
    await waitForPlanning(loadCatalogue(), signal);
    checkPlanningCancelled(signal);
    const held = new Set(state.catalogue.map(entry => ImageStudio_보유식별자읽기(entry.talentName,duplicateMode)));
    const sourceKeys = cloneSource ? [...new Set(state.catalogue.filter(entry => entry.talentName?.startsWith(cloneSource + '__')).map(entry => entry.talentName))] : null;
    if (sourceKeys && !sourceKeys.length) throw Error(`${names[cloneSource] || cloneSource}의 원본 구성 키를 찾지 못했습니다.`);
    const filteredSources = sourceKeys?.filter(key => matchesSelection(key,selected));
    const details = prompt.combinationSpace(bridgeSelected), spaces = [];
    let baseCount = 0n;
    for (const wife of targets) {
      checkPlanningCancelled(signal);
      const space = b.randomSpace(wife,bridgeSelected,filteredSources);
      if (!space.count) continue;
      baseCount += space.count; spaces.push({wife,space,end:baseCount});
    }
    const total = baseCount * details.count, swaps = new Map(), seen = new Set(), queue = [], duplicateAudit = createDuplicateAudit();
    let remaining = total, attempts = 0, candidates = 0, ownedDuplicates = 0, plannedDuplicates = 0, outsideSource = 0;
    const attemptLimit = Math.min(300000,Math.max(2000,requested * 20));
    let stopReason = '';
    const report = () => progress({ stage: 'random', label: '랜덤 생성 목표 확보', current: queue.length, total: requested, unit: '장',
      detail: `${attempts.toLocaleString()}개 조합 검사 · 보유 중복 ${ownedDuplicates.toLocaleString()}장 · 계획 중복 ${plannedDuplicates.toLocaleString()}장 · 전체 후보 공간 ${total.toLocaleString()}개` });
    report();
    const checkpoint = ImageStudio_계산묶음만들기(report, signal);
    while (remaining && queue.length < requested) {
      checkPlanningCancelled(signal);
      if (attempts >= attemptLimit) { stopReason = 'attempts'; break; }
      // 느린 프롬프트도 목표 수량까지 계속합니다. 화면 응답과 취소는 checkpoint에서 처리합니다.
      // 전체 배열 대신 방문한 슬롯만 기록하는 비복원 추첨입니다.
      const position = ImageStudio_랜덤정수뽑기(remaining), last = remaining - 1n;
      const slot = swaps.get(position) ?? position;
      if (position !== last) swaps.set(position,swaps.get(last) ?? last);
      swaps.delete(last); remaining = last; attempts++;
      const baseIndex = slot / details.count, detailIndex = slot % details.count;
      let low = 0, high = spaces.length - 1;
      while (low < high) { const middle = (low + high) >>> 1; if (baseIndex < spaces[middle].end) high = middle; else low = middle + 1; }
      const entry = spaces[low], offset = baseIndex - (low ? spaces[low - 1].end : 0n);
      const items = entry.space.build(offset,details.at(detailIndex)); candidates += items.length;
      if (!items.length) outsideSource++;
      for (const item of items) {
        if (held.has(ImageStudio_보유식별자읽기(item.talentId,duplicateMode))) { ownedDuplicates++; recordDuplicateAudit(duplicateAudit,item.talentId); continue; }
        const identity = imageIdentity(item.talentId);
        if (seen.has(identity)) { plannedDuplicates++; continue; }
        seen.add(identity); queue.push({...item,weight:b.weight(item.talentId)});
        if (queue.length >= requested) break;
      }
      const pause = checkpoint(attempts);
      if (pause) await pause;
    }
    report();
    checkPlanningCancelled(signal);
    queue.sort((a,b) => (b.weight || 0) - (a.weight || 0) || a.talentId.localeCompare(b.talentId));
    return {queue,candidates,ownedDuplicates,plannedDuplicates,duplicates:ownedDuplicates + plannedDuplicates,duplicateAudit,outsideSource,sourceCount:sourceKeys?.length || 0,duplicateMode,
      sampling:{requested,attempts,slotCount:total.toString(),exhausted:remaining === 0n,limited:!!stopReason,stopReason}};
  }

  function ImageStudio_랜덤검사안내읽기(plan) {
    const sample = plan.sampling;
    if (!sample) return '';
    const reason = sample.limited ? ' · 탐색 한도에 도달했습니다. 미보유 후보가 더 없다는 뜻은 아닙니다. 조건을 좁히거나 다시 추첨할 수 있습니다.'
      : plan.queue.length < sample.requested ? ' · 선택한 조합을 모두 확인했으며 요청 수량을 채울 미중복 후보가 부족합니다.' : '';
    return ` · 랜덤 요청 ${sample.requested.toLocaleString()}장 중 ${plan.queue.length.toLocaleString()}장 확보 · ${sample.attempts.toLocaleString()}개 조합 검사${reason}`;
  }

  async function enqueueSelection(randomCount = null) {
    if (state.busy) return;
    const b = bridge(), url = b?.connection()?.baseUrl;
    if (!url) { setMessage('이미지 생성 서버에 연결해 주세요.'); return; }
    if (!b.connection()?.comfyui) { setMessage('이미지 서버와 선택한 생성 방식의 연결을 확인한 뒤 시작해 주세요.'); return; }
    state.busy = true; setMessage('선택 조합과 중복을 확인하는 중…');
    const controller = new AbortController();
    planningController = controller;
    paintPlanningCancel();
    const selected = Object.fromEntries(Object.entries(state.selected).map(([axis, values]) => [axis, valuesOf(state.selected, axis)]));
    const cloneSource = state.cloneSource, duplicateMode = state.duplicateMode;
    taskProgress.update('generation', { restart: true, stage: 'catalogue', label: '보유 이미지 목록 확인', current: 0, total: null });
    const busyButtons = ['wwis-enqueue-new', 'wwis-enqueue-random', 'wwis-back', 'wwis-refresh', 'wwis-conditional', 'wwis-random', 'wwis-h-status', 'wwis-generation-settings', 'wwis-prompt-edit'];
    for (const id of busyButtons) { const button = content.querySelector('#' + id); if (button) button.disabled = true; }
    let failed = false, cancelled = false;
    try {
      const plan = randomCount === null ? await buildPlanFor(selected, cloneSource, generationProgress, duplicateMode, controller.signal) : await ImageStudio_랜덤생성계획하기(selected, cloneSource, randomCount, generationProgress, duplicateMode, controller.signal);
      await waitForPlanning(new Promise(resolve => setTimeout(resolve, 0)), controller.signal);
      checkPlanningCancelled(controller.signal);
      state.lastPlan = plan; renderDuplicateAudit(plan);
      const sourceText = cloneSource ? ` · 원본 ${plan.sourceCount.toLocaleString()}개 구성과 비교` : '';
      if (!plan.queue.length) { setMessage(`${plan.sampling?.limited ? '탐색한 범위에서 새로 만들 이미지를 찾지 못했습니다.' : '새로 만들 이미지가 없습니다.'} 선택한 기준으로 보유 ${plan.ownedDuplicates.toLocaleString()}장, 계획 내 동일 키 ${plan.plannedDuplicates.toLocaleString()}장을 확인했습니다${ImageStudio_랜덤검사안내읽기(plan)}${sourceText}.`); return; }
      const queue = plan.queue;
      planningController = null;
      paintPlanningCancel();
      setMessage(`${queue.length.toLocaleString()}장을 대기열로 보내는 중…`);
      const report = progress => {
        const detail = `서버 접수 ${(progress.accepted || 0).toLocaleString()}장 · 서버 캐시 중복 ${(progress.alreadyCached || 0).toLocaleString()}장 · 기존 큐 중복 ${(progress.alreadyQueued || 0).toLocaleString()}장`;
        taskProgress.update('generation', { stage: 'queue', label: '서버 큐로 전송', current: progress.sent, total: queue.length, unit: '장', detail });
        setMessage(`${queue.length.toLocaleString()}장 중 ${progress.sent.toLocaleString()}장을 서버에 전달했습니다. ${detail}`);
      };
      report({ sent: 0 });
      const result = await b.enqueue(queue, report);
      report({ sent: queue.length, ...result });
      state.lastPlan = null;
      const randomText = ImageStudio_랜덤검사안내읽기(plan);
      const queuedText = result.alreadyQueued ? `, 중복 전송 ${result.alreadyQueued.toLocaleString()}장` : '';
      setMessage(`${result.accepted.toLocaleString()}장을 대기열에 추가했습니다. 선택한 기준으로 보유 ${plan.ownedDuplicates.toLocaleString()}장, 계획 내 동일 키 ${plan.plannedDuplicates.toLocaleString()}장, 서버 캐시 중복 ${result.alreadyCached.toLocaleString()}장${queuedText}을 제외했습니다${randomText}${sourceText}.`);
    } catch (error) {
      cancelled = error?.name === 'AbortError';
      failed = !cancelled;
      if (cancelled) state.lastPlan = null;
      setMessage(cancelled ? '조합 계산을 취소했습니다. 이번 작업은 서버 대기열에 추가하지 않았습니다.' : String(error?.message || error));
    }
    finally {
      planningController = null;
      paintPlanningCancel();
      state.busy = false;
      taskProgress.finish('generation', state.message, failed, cancelled);
      for (const id of busyButtons) { const button = content.querySelector('#' + id); if (button) button.disabled = false; }
    }
  }

  async function syncImageCache(character = null) {
    if (cacheBusy) return;
    const url = bridge()?.connection()?.baseUrl;
    const button = content.querySelector(character ? '#wwis-character-cache-sync' : '#wwis-cache-sync');
    const result = content.querySelector('#wwis-cache-sync-result');
    if (!url) { result.textContent = '이미지 생성 서버에 연결해 주세요. Start_ImageStudio.cmd를 먼저 실행하세요.'; return; }
    const scopeLabel = character ? `${names[character] || character} 이미지 캐시 초기화` : '전체 이미지 캐시 초기화';
    cacheBusy = true;
    button.disabled = true; result.textContent = cacheMessage = '실제 파일과 캐시를 대조하는 중…';
    taskProgress.update('cache', { restart: true, stage: 'connect', label: scopeLabel + ' · 서버 연결', current: 0, total: null });
    let failed = false;
    try {
      const endpoint = character ? '/api/image-cache/sync-character?progress=1&character=' + encodeURIComponent(character) : '/api/image-cache/sync?progress=1';
      const response = await fetch(url + endpoint, { method: 'POST', credentials: 'omit' });
      if (character && response.status === 404) throw new Error("캐릭터별 캐시 초기화를 지원하는 새 이미지 서버로 다시 실행해 주세요.");
      const body = await ImageStudio_캐시진행응답읽기(response, progress => {
        const labels = { scan: '이미지 폴더 목록 읽기', check: '캐시 항목 대조', save: '변경 사항 저장', legacy: '캐시 대조 · 기존 서버 응답 대기' };
        taskProgress.update('cache', { stage: progress.phase, label: scopeLabel + ' · ' + (labels[progress.phase] || progress.phase),
          current: progress.processed ?? 0, total: ['check', 'save'].includes(progress.phase) ? progress.total : null,
          detail: progress.phase === 'legacy' ? '실제 처리 건수 표시는 서버 0.4.5 이상에서 지원합니다.' : `유지 ${(progress.kept || 0).toLocaleString()}개 · 경로 복원 ${(progress.relinked || 0).toLocaleString()}개 · 누락 ${(progress.missing || 0).toLocaleString()}개` });
      });
      state.lastPlan = null;
      taskProgress.update('cache', { stage: 'catalogue', label: scopeLabel + ' · 화면 목록 갱신', current: 0, total: null });
      await loadCatalogue(true);
      cacheMessage = `${scopeLabel}: ${body.before.toLocaleString()}개 → ${body.after.toLocaleString()}개 · WebP 경로 ${(body.relinked || 0).toLocaleString()}개를 다시 연결하고 파일이 없는 항목 ${body.removed.toLocaleString()}개를 제거했습니다.${body.backupPath ? ` 기존 캐시 백업: ${body.backupPath}` : ''} 이미 제거된 항목은 모드 폴더의 Repair_WebP_Cache.cmd로 백업에서 복원할 수 있습니다.`;
      if (state.wife && !state.busy) render();
      taskProgress.update('cache', { stage: 'complete', label: scopeLabel, current: body.before, total: body.before });
    } catch (error) { failed = true; cacheMessage = `${scopeLabel}에 실패했습니다: ${error?.message || error}`; }
    finally {
      cacheBusy = false;
      taskProgress.finish('cache', cacheMessage, failed);
      const liveResult = content.querySelector('#wwis-cache-sync-result'), liveButton = content.querySelector('#wwis-cache-sync, #wwis-character-cache-sync');
      if (liveResult) liveResult.textContent = cacheMessage;
      if (liveButton) liveButton.disabled = false;
    }
  }

  async function buildPack() {
    const url = bridge()?.connection()?.baseUrl;
    if (!url) { setMessage('이미지 생성 서버에 연결해 주세요.'); return; }
    const wife = state.wife;
    if (state.packBusy.has(wife)) return;
    state.packBusy.add(wife);
    const setResult = text => {
      state.packResults[wife] = text;
      const node = state.wife === wife && content.querySelector('#wwis-pack-result');
      if (node) node.textContent = text;
    };
    setResult('팩 생성 중…');
    content.querySelector('#wwis-pack').disabled = true;
    try {
      const capability = await fetch(url + '/api/custom-pack/capabilities', { credentials: 'omit' });
      if (!capability.ok) throw new Error('일반 팩 생성을 지원하는 서버가 필요합니다. 진행 중인 생성을 마친 뒤 Start_ImageStudio.cmd로 서버를 다시 시작해 주세요.');
      const scope = await capability.json();
      if (scope.directory !== 'illustrious/characters/') throw new Error('현재 서버의 일반 팩 생성 범위를 확인할 수 없습니다. 최신 ImageStudio 서버로 다시 시작해 주세요.');
      const response = await fetch(url + '/api/custom-pack/build', { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'omit', body: JSON.stringify({ wife }) });
      if (response.status === 404) throw new Error('현재 실행 중인 서버에 팩 생성 API가 없습니다. 업데이트한 Start_ImageStudio.cmd로 서버를 다시 시작해 주세요.');
      const body = await response.json(); if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
      setResult(`${body.images.toLocaleString()}개 조건 · 없는 파일 ${body.missingFiles.toLocaleString()}개 제외 · 조건 미등록 파일 ${body.unindexedFiles.toLocaleString()}개 제외 · 생성 파일: ${body.file} · 파일명을 번호 팩으로 변경한 뒤 게임을 새로고침하세요.${body.backupPath ? ` 이전 custom 팩 백업: ${body.backupPath}` : ''}${body.warnings?.length ? ` · 참고: ${body.warnings.join(' / ')}` : ''}`);
      await loadCatalogue();
    } catch (error) { setResult(String(error?.message || error)); }
    finally {
      state.packBusy.delete(wife);
      const button = state.wife === wife && content.querySelector('#wwis-pack');
      if (button) button.disabled = false;
    }
  }

  async function buildHStatusPack(character = state.wife) {
    const url = bridge()?.connection()?.baseUrl;
    if (!url) throw new Error('이미지 생성 서버에 연결해 주세요.');
    const response = await fetch(url + '/api/h-status-pack/build', { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'omit', body: JSON.stringify({ character }) });
    if (response.status === 404) throw new Error('현재 실행 중인 서버에 H_Status 팩 생성 API가 없습니다. 업데이트한 Start_ImageStudio.cmd로 서버를 다시 시작해 주세요.');
    const body = await response.json();
    if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
    try {
      const key = 'h-status-image-pack-characters-v1';
      const saved = JSON.parse(localStorage.getItem(key) || '[]');
      localStorage.setItem(key, JSON.stringify([...new Set([...(Array.isArray(saved) ? saved : []), character])]));
    } catch (_) {}
    await loadCatalogue(true);
    return `${body.images.toLocaleString()}개 H_Status 이미지 · 없는 파일 ${body.missingFiles.toLocaleString()}개 제외 · 생성 파일: ${body.file}${body.backupPath ? ` · 이전 팩 백업: ${body.backupPath}` : ''} · 게임을 새로고침하면 적용됩니다.`;
  }

  const openStudio = () => { overlay.hidden = false; if (!state.busy && !generationSettingsEditor && !generationSettingsLoad) { render(); void refresh(); } };
  const closeStudio = () => ImageStudio_생성설정나가기(() => { overlay.hidden = true; });
  overlay.querySelector('#wwis-close').onclick = closeStudio;
  overlay.onclick = event => { if (event.target === overlay) closeStudio(); };
  window.addEventListener('keydown', event => {
    if (event.key !== 'Escape' || overlay.hidden) return;
    if (generationSettingsEditor?.prompt) generationSettingsEditor.prompt.querySelector('#wwis-unsaved-continue').click();
    else closeStudio();
    event.preventDefault(); event.stopImmediatePropagation();
  }, true);
  api.onBack?.(() => {
    if (overlay.hidden) return false;
    if (generationSettingsEditor?.prompt) generationSettingsEditor.prompt.querySelector('#wwis-unsaved-continue').click();
    else closeStudio();
    return true;
  });
  window.WW_ImageStudio = { open: openStudio, isBusy: () => state.busy };
  // 현재 본체는 게임에서 /api/batch/enqueue로 직접 전송합니다.
  // 지원하지 않는 옛 /api/planner/* 릴레이와 주기적인 전체 목록 순회는 실행하지 않습니다.
})();

    // ---- 원본 뒤에 붙인 코드 ----
    // Put Image Studio in the game's pause menu. The pause panel is identified by
    // its stable layout: the first button under the heading is the amber Resume
    // button. This avoids depending on translated game text.
    const wwImageStudioOriginalOpen = globalThis.WW_ImageStudio?.open?.bind(globalThis.WW_ImageStudio);
    if (wwImageStudioOriginalOpen) {
      globalThis.WW_ImageStudio.open = (...args) => {
        const result = wwImageStudioOriginalOpen(...args);
        const overlay = document.getElementById('wwis-overlay');
        if (overlay) {
          // Other mods may raise the pause panel. Keep the studio above it and move
          // it to the end of <body> so equal stacking contexts cannot cover it.
          overlay.style.setProperty('z-index', '2147483647', 'important');
          document.body.append(overlay);
        }
        queueMicrotask(wwDecorateImageStudio);
        return result;
      };
    }
    
    // OutfitQueue v8.6 proved that a large image planner is much easier to use
    // when every engine key has a Korean name, a visible explanation, selection
    // counts and local filtering. Keep Image Studio's own planner, but present its
    // axes with the same level of guidance.
    const wwImageStudioUiStyle = document.createElement('style');
    wwImageStudioUiStyle.textContent = `
    #wwis-panel{width:min(1180px,97vw);background:linear-gradient(180deg,#1c1917,#151312);box-shadow:0 24px 80px #000b}
    #wwis-panel>.wwis-row:first-child{position:sticky;top:-18px;z-index:5;margin:-18px -18px 12px;padding:16px 18px 12px;background:#1c1917ee;border-bottom:1px solid #44403c;backdrop-filter:blur(8px)}
    #wwis-panel .wwis-card{background:#1c191799;border-color:#57534e}
    #wwis-panel .wwis-axis-card{padding:12px;border-color:#57534e;background:#171412}
    #wwis-panel .wwis-axis-card>strong{color:#fbbf24;font-size:14px}
    #wwis-panel .wwis-axis-count{display:inline-flex;margin-left:7px;padding:1px 7px;border:1px solid #53645d;border-radius:999px;background:#1d342e;color:#a7f3d0;font-size:11px;font-weight:600}
    #wwis-panel .wwis-axis-help{margin:7px 0 9px;color:#b9b4ae;font-size:12px;line-height:1.55}
    #wwis-panel .wwis-axis-filter{box-sizing:border-box;width:100%;margin:0 0 9px;padding:7px 9px;background:#0c0a09;border-color:#57534e}
    #wwis-panel .wwis-grid{grid-template-columns:repeat(auto-fill,minmax(245px,1fr));gap:7px;max-height:330px;padding:2px}
    #wwis-panel .wwis-option-row{box-sizing:border-box;min-height:58px;padding:7px 8px;border:1px solid #3f3a36;border-radius:6px;background:#211e1b;cursor:pointer;transition:border-color .15s,background .15s}
    #wwis-panel .wwis-option-row:hover{border-color:#a16207;background:#29231d}
    #wwis-panel .wwis-option-row:has(input:checked){border-color:#92702f;background:#302719}
    #wwis-panel .wwis-option-row input{flex:0 0 auto;margin-top:3px}
    #wwis-panel .wwis-option-copy{display:flex;min-width:0;flex-direction:column;gap:2px}
    #wwis-panel .wwis-option-heading{display:flex;flex-wrap:wrap;align-items:baseline;gap:2px 6px;min-width:0}
    #wwis-panel .wwis-option-title{color:#f5f5f4;font-size:12px;font-weight:650;overflow-wrap:anywhere}
    #wwis-panel .wwis-option-id{color:#fb923c;font-family:inherit;font-size:10.5px;font-weight:400;line-height:1.4;overflow-wrap:anywhere;min-width:0;white-space:normal}
    #wwis-panel .wwis-option-id[data-id-origin="mod"]{color:#facc15}
    #wwis-panel .wwis-id-guide{color:#facc15}
    #wwis-panel .wwis-id-guide-vanilla{color:#fb923c}
    #wwis-panel .wwis-id-guide-mod{color:#facc15}
    #wwis-panel .wwis-option-help{color:#a8a29e;font-size:10.5px;line-height:1.4;overflow-wrap:anywhere}
    #wwis-panel .wwis-guide{margin:10px 0;padding:11px 12px;border:1px solid #3f6259;border-radius:8px;background:#10231f;color:#d6eee7}
    #wwis-panel .wwis-guide>strong{display:block;margin-bottom:7px;color:#6ee7b7;font-size:14px}
    #wwis-panel .wwis-guide-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px}
    #wwis-panel .wwis-guide-grid div{padding:8px;border-radius:6px;background:#0b1816;color:#b8d8d0;font-size:11px;line-height:1.5}
    #wwis-panel .wwis-guide-grid b{display:block;color:#e4f7f1;font-size:12px;margin-bottom:2px}
    #wwis-panel .wwis-situation-group{background:#0c0a0988}
    #wwis-panel .wwis-situation-group .wwis-grid{max-height:300px}
    @media(max-width:760px){#wwis-panel .wwis-guide-grid{grid-template-columns:1fr}#wwis-panel .wwis-grid{grid-template-columns:1fr}}
    `;
    document.head.append(wwImageStudioUiStyle);
    
    function wwUpdateImageStudioCounts() {
      const overlay = document.getElementById('wwis-overlay');
      if (!overlay) return;
      for (const card of overlay.querySelectorAll('.wwis-axis-card')) {
        const inputs = [...card.querySelectorAll('input[type="checkbox"][data-axis]')];
        const count = card.querySelector('.wwis-axis-count');
        const next = `${inputs.filter(input => input.checked).length} / ${inputs.length} 선택`;
        // textContent replaces the text node even when the string is unchanged.
        // Because this panel is watched by a childList observer, writing the same
        // value on every pass would schedule decoration forever and freeze the UI.
        if (count && count.textContent !== next) count.textContent = next;
      }
    }
    
    function wwDecorateImageStudio() {
      const overlay = document.getElementById('wwis-overlay');
      const helper = globalThis.WW_ImageStudioHelp;
      if (!overlay || !helper) return;
      overlay.dataset.wmlUi = 'imagestudio';
      const axesHost = overlay.querySelector('#wwis-axes');
      if (!axesHost) return;
    
      const details = overlay.querySelector('#wwis-details');
      if (details && !details.previousElementSibling?.classList.contains('wwis-guide')) {
        const guide = document.createElement('section');
        guide.className = 'wwis-guide';
        guide.innerHTML = `<strong>조건 생성 사용법</strong><div class="wwis-guide-grid"><div><b>1. 구성 원본</b>다른 캐릭터를 고르면 그 인물이 실제로 보유한 이미지 키만 같은 조건으로 다시 만듭니다.</div><div><b>2. 조건의 교집합</b>각 칸에서 선택한 값끼리 가능한 조합만 만듭니다. 빈 칸이 하나라도 있으면 생성하지 않습니다.</div><div><b>3. 중복 제외</b>이미지 팩과 로컬 서버 캐시의 기본 구성을 비교한 뒤 없는 이미지만 대기열에 보냅니다. 프롬프트 서명까지 구분할 수도 있습니다.</div></div>`;
        details.before(guide);
      }
    
      for (const card of axesHost.querySelectorAll('.wwis-card:not(details)')) {
        const inputs = [...card.querySelectorAll('input[type="checkbox"][data-axis]')];
        if (!inputs.length) continue;
        const axis = inputs[0].dataset.axis;
        if (!card.dataset.wwEnhanced) {
          card.dataset.wwEnhanced = axis;
          card.classList.add('wwis-axis-card');
          const heading = card.querySelector(':scope > strong');
          const count = document.createElement('span');
          count.className = 'wwis-axis-count';
          heading?.after(count);
          const help = document.createElement('p');
          help.className = 'wwis-axis-help';
          help.textContent = helper.axis(axis);
          const actions = card.querySelector(':scope > .wwis-axis-actions');
          (actions || count).after(help);
    
          if (inputs.length >= 8) {
            const filter = document.createElement('input');
            filter.type = 'search';
            filter.className = 'wwis-axis-filter';
            filter.placeholder = '이 조건 안에서 검색';
            filter.setAttribute('aria-label', `${heading?.textContent || axis} 검색`);
            filter.addEventListener('input', () => {
              const query = filter.value.trim().toLocaleLowerCase('ko');
              for (const row of card.querySelectorAll('label.wwis-option-row')) row.hidden = !!query && !row.textContent.toLocaleLowerCase('ko').includes(query);
            });
            help.after(filter);
          }
        }
    
        for (const input of inputs) {
          const row = input.closest('label');
          if (!row || row.querySelector('.wwis-option-copy')) continue;
          row.classList.add('wwis-option-row');
          const current = [...row.childNodes].filter(node => node.nodeType === Node.TEXT_NODE).map(node => node.textContent).join(' ').trim();
          for (const node of [...row.childNodes]) if (node.nodeType === Node.TEXT_NODE) node.remove();
          const copy = document.createElement('span');
          copy.className = 'wwis-option-copy';
          const title = document.createElement('span');
          title.className = 'wwis-option-title';
          title.textContent = current || helper.label(input.dataset.axis, input.dataset.value);
          const heading = document.createElement('span');
          heading.className = 'wwis-option-heading';
          // The Korean runtime translates ordinary text nodes, including raw IDs.
          // CODE is its explicit skip boundary; retain the exact selectable value.
          const id = document.createElement('code');
          id.className = 'wwis-option-id';
          id.dataset.idOrigin = input.dataset.idOrigin;
          id.setAttribute('translate', 'no');
          id.dataset.i18nSkip = '';
          const value = input.dataset.value;
          id.textContent = '[' + (input.dataset.axis === 'room' && value === 'bedroom (침대 위)' ? 'bedroom, abed=1' : value) + ']';
          heading.append(title, id);
          const sexualGroup = /^(contact|sex|climax)_/.test(input.dataset.situationGroup || '');
          const description = sexualGroup ? '' : helper.describe(input.dataset.axis, input.dataset.value);
          copy.append(heading);
          if (description) {
            const small = document.createElement('small');
            small.className = 'wwis-option-help';
            small.textContent = description;
            copy.append(small);
            row.title = description;
          }
          row.append(copy);
        }
      }
      wwUpdateImageStudioCounts();
    }
    
    const wwImageStudioOverlay = document.getElementById('wwis-overlay');
    let wwImageStudioDecorateQueued = false;
    function wwScheduleImageStudioDecoration() {
      if (wwImageStudioDecorateQueued) return;
      wwImageStudioDecorateQueued = true;
      queueMicrotask(() => {
        wwImageStudioDecorateQueued = false;
        wwDecorateImageStudio();
      });
    }
    const wwImageStudioUiObserver = new MutationObserver(wwScheduleImageStudioDecoration);
    if (wwImageStudioOverlay) {
      wwImageStudioUiObserver.observe(wwImageStudioOverlay, { childList: true, subtree: true });
      wwImageStudioOverlay.addEventListener('change', () => queueMicrotask(wwUpdateImageStudioCounts));
      wwImageStudioOverlay.addEventListener('click', () => queueMicrotask(wwUpdateImageStudioCounts));
    }
    
    extensions.setReview(ImageStudio_프롬프트검수연결하기(api));
    ImageStudio_사용통계연결하기(api);

    try { api.ui.pauseSettings?.({label:{ko:'이미지 스튜디오',en:'ImageStudio settings'},attributes:{'data-ww-image-studio-menu':'1'},onClick:()=>globalThis.WW_ImageStudio?.open?.()}); } catch (error) { console.warn("[imagestudio] 공통 설정 메뉴 등록 실패: 기존 직접 삽입 방식으로 계속합니다.", error); }
    api.ui.menuSettings({ label: '이미지 스튜디오', onClick: () => globalThis.WW_ImageStudio?.open?.(),
      windowSelector:'#wwis-overlay', attributes: { 'data-ww-image-studio-menu': '1' } });
    window.addEventListener('pagehide', () => {
      wwImageStudioUiObserver.disconnect();
    }, { once: true });
  },
});
