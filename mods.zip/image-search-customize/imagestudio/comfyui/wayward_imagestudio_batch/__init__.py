"""Independent prompt conditioning in one ComfyUI sampler batch (Anima / SDXL).

Native ComfyUI encodes each entry's model conditions first. In particular Anima
processes its own Qwen/T5 IDs and weights before we stack the resulting tensors.
The patch belongs to a ModelPatcher clone; no global functions are replaced.
"""
import json
import math
import uuid

import torch
import comfy.samplers

SLOT = "wwis_prompt_batch_slot"


def stack_model_conditions(entries, batch_size):
    if len(entries) != batch_size:
        raise ValueError("ImageStudio prompt count does not match the latent batch")
    ordered = sorted(entries, key=lambda entry: entry.get(SLOT, -1))
    if [entry.get(SLOT) for entry in ordered] != list(range(batch_size)):
        raise ValueError("ImageStudio prompt batch slots are missing or duplicated")
    first = ordered[0]
    if any(any(key in entry for key in ("mask", "area", "control", "hooks", "gligen", "timestep_start", "timestep_end")) for entry in ordered):
        raise ValueError("ImageStudio prompt batch supports plain text conditioning only")
    keys = set(first["model_conds"])
    if any(set(entry["model_conds"]) != keys for entry in ordered):
        raise ValueError("ImageStudio batch conditioning types differ")
    stacked = {}
    for key in keys:
        values = [entry["model_conds"][key] for entry in ordered]
        base = values[0]
        if not all(base.can_concat(value) for value in values[1:]):
            raise ValueError("ImageStudio batch token lengths are incompatible; use a smaller batch")
        # Cross-attention repeats token sequences to their LCM, preserving
        # attention weights. Bound that exact padding instead of truncating text.
        if base.__class__.__name__ == "CONDCrossAttn":
            length = math.lcm(*(value.cond.shape[1] for value in values))
            if length > 8192:
                raise ValueError("ImageStudio batch token lengths require too much padding")
        stacked[key] = base._copy_with(base.concat(values[1:]))
    merged = first.copy()
    merged.pop(SLOT, None)
    merged["model_conds"] = stacked
    merged["uuid"] = uuid.uuid4()
    return [merged]


class ImageStudioMultiPrompt:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "model": ("MODEL",), "clip": ("CLIP",),
            "prompts_json": ("STRING", {"multiline": True, "default": "[]"}),
        }}

    RETURN_TYPES = ("MODEL", "CONDITIONING", "CONDITIONING")
    RETURN_NAMES = ("model", "positive", "negative")
    FUNCTION = "encode"
    CATEGORY = "ImageStudio"

    @torch.inference_mode()
    def encode(self, model, clip, prompts_json):
        prompts = json.loads(prompts_json)
        if not isinstance(prompts, list) or not 1 <= len(prompts) <= 128:
            raise ValueError("ImageStudio accepts 1 to 128 distinct prompts")
        positive, negative = [], []
        for index, prompt in enumerate(prompts):
            if not isinstance(prompt, dict) or not isinstance(prompt.get("positive"), str) or not isinstance(prompt.get("negative"), str):
                raise ValueError("Each ImageStudio prompt needs positive and negative text")
            for polarity, target in (("positive", positive), ("negative", negative)):
                encoded = clip.encode_from_tokens_scheduled(clip.tokenize(prompt[polarity]))
                if len(encoded) != 1:
                    raise ValueError("ImageStudio prompt batch does not support scheduled conditioning")
                tensor, metadata = encoded[0]
                if tensor.shape[0] != 1:
                    raise ValueError("Each ImageStudio input must encode one prompt")
                target.append([tensor, {**metadata, SLOT: index}])
        if "sampler_calc_cond_batch_function" in model.model_options:
            raise ValueError("ImageStudio cannot replace another sampler conditioning patch")
        patched = model.clone()
        cached_key, cached_conditions = None, None

        def calculate(args):
            nonlocal cached_key, cached_conditions
            size = args["input"].shape[0]
            if size != len(prompts):
                raise ValueError("ImageStudio latent batch size must match the prompt count")
            conditions = args["conds"]
            signature = tuple(None if branch is None else tuple(id(entry) for entry in branch) for branch in conditions)
            if signature != cached_key:
                cached_conditions = [None if branch is None else stack_model_conditions(branch, size) for branch in conditions]
                cached_key = signature
            return comfy.samplers.calc_cond_batch(args["model"], cached_conditions, args["input"], args["sigma"], args["model_options"])

        patched.set_model_sampler_calc_cond_batch_function(calculate)
        return patched, positive, negative


NODE_CLASS_MAPPINGS = {"ImageStudioMultiPrompt": ImageStudioMultiPrompt}
NODE_DISPLAY_NAME_MAPPINGS = {"ImageStudioMultiPrompt": "ImageStudio · Multi Prompt Batch (1–128)"}
