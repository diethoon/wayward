﻿param([string]$ComfyUIRoot, [switch]$LocateOnly)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)

function Test-ComfySourceRoot([string]$Directory) {
    if (-not $Directory) { return $false }
    foreach ($taskMarker in @('main.py', 'nodes.py', 'folder_paths.py')) {
        if (-not (Test-Path -LiteralPath (Join-Path $Directory $taskMarker) -PathType Leaf)) { return $false }
    }
    foreach ($taskMarker in @('comfy', 'custom_nodes')) {
        if (-not (Test-Path -LiteralPath (Join-Path $Directory $taskMarker) -PathType Container)) { return $false }
    }
    return $true
}

function Find-ComfySourceRoot([string]$SelectedPath) {
    if (-not $SelectedPath -or -not (Test-Path -LiteralPath $SelectedPath)) { return }
    $taskCursor = (Get-Item -LiteralPath $SelectedPath).FullName
    if (Test-Path -LiteralPath $taskCursor -PathType Leaf) { $taskCursor = [IO.Path]::GetDirectoryName($taskCursor) }
    for ($taskDepth = 0; $taskDepth -lt 20 -and $taskCursor; $taskDepth++) {
        if (Test-ComfySourceRoot $taskCursor) { return $taskCursor }
        $taskParent = [IO.Path]::GetDirectoryName($taskCursor)
        if ($taskParent -eq $taskCursor) { break }
        $taskCursor = $taskParent
    }
}

function Get-NodeDigest([string]$File) {
    $taskHash = [Security.Cryptography.SHA256]::Create()
    $taskStream = [IO.File]::OpenRead($File)
    try { return [BitConverter]::ToString($taskHash.ComputeHash($taskStream)) }
    finally { $taskStream.Dispose(); $taskHash.Dispose() }
}

function Get-DetectedComfyRoots {
    $taskRunningRoots = @()
    try {
        foreach ($taskProcess in Get-CimInstance Win32_Process -Filter "Name LIKE 'python%'" -ErrorAction Stop) {
            if ($taskProcess.CommandLine -notmatch '(?:^|[\\/\s])main\.py(?:\s|"|$)') { continue }
            $taskFoundRoot = Find-ComfySourceRoot $taskProcess.ExecutablePath
            if (-not $taskFoundRoot -and $taskProcess.ExecutablePath) {
                $taskCursor = Split-Path -LiteralPath $taskProcess.ExecutablePath
                for ($taskDepth = 0; $taskDepth -lt 5 -and $taskCursor; $taskDepth++) {
                    $taskCandidate = Join-Path $taskCursor 'ComfyUI'
                    if (Test-ComfySourceRoot $taskCandidate) { $taskFoundRoot = $taskCandidate; break }
                    $taskCursor = [IO.Path]::GetDirectoryName($taskCursor)
                }
            }
            if ($taskFoundRoot) { $taskRunningRoots += $taskFoundRoot }
        }
    } catch { Write-Host '실행 중인 프로세스를 읽지 못해 설치 경로를 확인합니다.' }
    if ($taskRunningRoots.Count) { return @($taskRunningRoots | Sort-Object -Unique) }
    $taskInstalledRoots = @()
    $taskInstalls = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'Comfy-Desktop\ComfyUI-Installs'
    if (Test-Path -LiteralPath $taskInstalls -PathType Container) {
        foreach ($taskInstall in Get-ChildItem -LiteralPath $taskInstalls -Directory) {
            foreach ($taskCandidate in @($taskInstall.FullName, (Join-Path $taskInstall.FullName 'ComfyUI'))) {
                if (Test-ComfySourceRoot $taskCandidate) { $taskInstalledRoots += $taskCandidate }
            }
        }
    }
    return @($taskInstalledRoots | Sort-Object -Unique)
}

try {
    $taskComfyRoot = Find-ComfySourceRoot $ComfyUIRoot
    if ($ComfyUIRoot -and -not $taskComfyRoot) {
        throw "선택한 경로는 ComfyUI 실행 루트가 아닙니다: $ComfyUIRoot`nmain.py, nodes.py, folder_paths.py, comfy, custom_nodes가 모두 있는 폴더가 필요합니다. _pyrepl, docutils, 개별 노드 폴더는 실행 루트가 아닙니다. 경로 인자 없이 설치기를 다시 실행하면 실행 중인 ComfyUI를 자동으로 찾습니다."
    }
    if (-not $taskComfyRoot) {
        $taskDetected = @(Get-DetectedComfyRoots)
        if ($taskDetected.Count -eq 1) {
            $taskComfyRoot = $taskDetected[0]
            Write-Host 'ComfyUI 실행 루트를 자동으로 찾았습니다.'
        } elseif ($LocateOnly) {
            throw 'ComfyUI 루트를 하나로 정할 수 없습니다. -ComfyUIRoot에 소스 폴더를 지정하세요.'
        } else {
            Add-Type -AssemblyName System.Windows.Forms
            $taskFolderDialog = New-Object System.Windows.Forms.FolderBrowserDialog
            $taskFolderDialog.Description = 'ComfyUI 실행 루트를 선택하세요. main.py, nodes.py, folder_paths.py와 comfy, custom_nodes가 모두 있어야 합니다.'
            $taskFolderDialog.ShowNewFolderButton = $false
            if ($taskDetected.Count) { $taskFolderDialog.SelectedPath = $taskDetected[0] }
            if ($taskFolderDialog.ShowDialog() -ne 'OK') { Write-Host '취소했습니다.'; exit 0 }
            $taskComfyRoot = Find-ComfySourceRoot $taskFolderDialog.SelectedPath
            if (-not $taskComfyRoot) { throw '선택한 폴더에서 ComfyUI 실행 루트를 찾지 못했습니다. 설치기를 다시 실행해 ComfyUI 소스 폴더를 선택하세요.' }
        }
    }
    $taskNodeSource = Join-Path $PSScriptRoot 'wayward_imagestudio_batch\__init__.py'
    if (-not (Test-Path -LiteralPath $taskNodeSource -PathType Leaf)) { throw '설치할 노드 파일이 없습니다. ImageStudio 배포 ZIP을 완전히 풀어 주세요.' }
    $taskNodeTarget = Join-Path $taskComfyRoot 'custom_nodes\wayward_imagestudio_batch'
    $taskNodeFile = Join-Path $taskNodeTarget '__init__.py'
    Write-Host "ComfyUI 루트: $taskComfyRoot"
    Write-Host "설치할 파일: $taskNodeFile"
    if ($LocateOnly) { return }
    $taskConfirmation = Read-Host '이 노드만 설치/업데이트하려면 YES를 입력하세요'
    if ($taskConfirmation.Trim() -ine 'YES') { Write-Host '취소했습니다.'; exit 0 }
    New-Item -ItemType Directory -Path $taskNodeTarget -Force | Out-Null
    if (Test-Path -LiteralPath $taskNodeFile) {
        Copy-Item -LiteralPath $taskNodeFile -Destination ($taskNodeFile + '.previous') -Force
    }
    Copy-Item -LiteralPath $taskNodeSource -Destination $taskNodeFile -Force
    if ((Get-NodeDigest $taskNodeSource) -ne (Get-NodeDigest $taskNodeFile)) { throw '설치한 파일의 검증에 실패했습니다.' }
    Write-Host '설치 완료. ComfyUI를 재시작하고 Start_ImageStudio.cmd로 이미지 서버를 실행하세요.'
    Write-Host '게임 새로고침 후 이미지 생성 방식 지정에서 노드 연결 완료를 확인하세요.'
} catch {
    Write-Host ("설치 실패: " + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
