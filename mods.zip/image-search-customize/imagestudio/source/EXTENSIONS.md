# ImageStudio 확장 계약 v1

본체 1.26.0부터 `api.use('imagestudio').extensions` 또는 `WW_ImageStudioBridge.extensions`로 접근합니다. 모드는 본체를 `requires`와 `loadAfter`에 선언합니다. 등록 함수는 해당 등록을 해제하는 함수를 돌려줍니다. 같은 종류의 ID 중복은 오류입니다.

## 상황과 프롬프트

```js
const extensions = api.use('imagestudio').extensions;
extensions.registerContextProvider({
  id: 'example-scene',
  read(context) {
    // mode: live / planning. planning에서 실제 현재 장면을 섞지 않습니다.
    return context.mode === 'live' ? api.use('example-content').context(context.character) : null;
  },
});
extensions.registerPromptProvider({
  id: 'example-scene', priority: 100,
  compose(result, context) {
    const scene = context.situations['example-scene'];
    if (!scene) return result;
    return { ...result, prompt: result.prompt + ', scene tags' };
  },
  key(key, context) { return key; },
});
```

`context`는 `version`, `mode`, `key`, `character`, `room`, `state`, `selection`, `archetypeId`, `situations`를 제공합니다. 조회·조립 함수는 **동기·읽기 전용**입니다. 행동 실행, 시간 진행, 게임 상태 저장, 임의 능력치 보정, 미리보기로 인한 실제 장면 선택을 하지 않습니다. 원본 입력을 고치지 않고 새 프롬프트 객체를 반환합니다. `undefined` 반환은 유지입니다. 비동기 함수는 오류로 처리합니다.

공통 편집기 제공자는 priority -1000, 콘텐츠 장면 제공자는 보통 100입니다. 프롬프트 제공자는 priority 오름차순과 같은 순위의 ID 순서로 실행합니다. 본체는 WML의 imagePrompt/imageKey priority -500000에서 조립하고, 매칭 메타데이터는 그 다음에 수집합니다. 최종 프롬프트에서 생성 매개변수를 다시 계산해야 하는 제공자는 `promptGenParams`를 사용합니다.

## 생성 조건과 계획

제공자의 `axes()`는 `{id, label, items:[{value,label}], defaultValue?}` 배열을 반환할 수 있습니다. 제공자 축은 공통 편집기 축과 함께 조건부 생성과 특정 장면 생성에 표시됩니다. 기본 선택은 `auto`이며 해당 값을 items에 포함해야 합니다. 축 ID가 중복되면 오류입니다.

`WW_ImageStudioPrompt.combinationSpace(selected)`는 `{count:BigInt, at(index)}`를 제공합니다. 편집기의 설정 스냅샷과 확장 조건을 함께 보존합니다. `plan(build, combination, archetypeId)` 안에서 생성 계획만 계산하고 실제 저장 상태는 바꾸지 않습니다. 제공자가 바꾼 최종 키와 프롬프트는 대기열 항목에 반영됩니다. `ImageStudioBaseKey`는 원래 기본 선택 조건 검사에만 사용합니다. 예를 들어 기본 idle 구성으로 새 콘텐츠 행동을 생성해도 결과를 다시 idle 조건으로 필터링해 버리지 않습니다.

## 이미지 키와 매칭

`registerKeyAdapter({id, normalize(key)})`로 과거 키를 읽기 정규화합니다. 정규화는 결정적이며 게임 상태를 읽거나 저장하지 않습니다. 이미지 파일·원본 캐시를 다시 쓰지 않습니다.

새 콘텐츠 키는 바닐라 필드를 보존하며 `__mod-<콘텐츠ID>__action-<의미ID>`로 구분합니다. `task`에도 읽을 수 있는 행동 ID를 사용합니다. 매칭 본체는 mod/action이 다른 후보를 가중치 설정과 관계없이 제외합니다. 행동 번호를 다른 의미로 추측하거나 모르는 모드의 해시를 행동으로 복원하지 않습니다. 기존 AIP의 `content` 해시 필드는 이 mod 필드와 별개입니다.

캐시·오프라인 팩에 남은 이전 키도 동일한 어댑터를 통해 후보로 비교합니다. 디스크 이름의 일부가 잘렸다면 전체 키를 가진 캐시/팩을 사용합니다. 어댑터 등록·해제 시 매칭 목록은 갱신합니다.

## 편집기와 검수

`registerEditor({id,render,axes,combinationSpace,plan,matchingContext,upgrades,nativeAxisPrompt,planningContext,embeddedVersion})`는 공통 편집기를 한 개 등록합니다. 검수 엔진은 `extensions.review`의 `open/generate/refresh/isBusy`로 제공하며, 편집기는 검수·저장 구현을 복사하지 않습니다. 본체의 `WW_ImageStudioPrompt` 전역은 기존 연결 모드의 API 호환을 위해 유지합니다.

본체 1.28.0부터 편집기의 선택적 `upgrades.normalizeMatchingContext(context)`를 통해 요청과 후보의 상세 상태를 같은 기준으로 묶습니다. 입력을 바꾸지 않는 동기 함수이며, 이미 묶은 값을 다시 받아도 결과가 같아야 합니다. 알 수 없는 메타데이터를 실제 상태로 추측하지 않습니다. 프롬프트 문구는 상황 키에 포함하지 않으며, 생성 서버는 최종 문구와 참조 이미지·노이즈 강도를 별도의 생성 해시로 구별합니다.

선택적 비동기 `upgrades.prepare(request)`는 H_Status의 부위별 생성 설정과 정확한 기준 이미지 조회를 적용합니다. 개별 검수와 H_Status 일괄 계획이 이를 공유합니다. 참조 이미지가 없으면 오류를 반환하며 게임 상태를 변경하지 않습니다.

자세와 장면의 공통 적합성 판정은 `extensions.positionApplicable(id,key)`에 있습니다. 편집기를 꺼도 본체의 매칭 기준이 유지됩니다. 등록 현황은 `extensions.list()`로 확인합니다.
