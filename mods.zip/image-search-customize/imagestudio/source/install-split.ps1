# 미리보기: powershell -NoProfile -File wml/mods/imagestudio/source/install-split.ps1
# 정식판에서는 독립 AIP와 공통 편집기 호환 모드를 함께 사용합니다. 적용은 -Apply.
param([switch]$Apply)
$ErrorActionPreference = 'Stop'
$studioModRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$studioGameRoot = (Resolve-Path -LiteralPath (Join-Path $studioModRoot '..\..\..')).Path
$studioList = Join-Path $studioGameRoot 'wml\mods\mods.js'
$studioBefore = Get-Content -LiteralPath $studioList -Raw -Encoding UTF8
$studioAfter = $studioBefore
foreach ($studioId in @('attention-image-prompt','imagestudio','imagestudio-compatible-attention-image-prompt')) {
    if (!(Test-Path -LiteralPath (Join-Path $studioGameRoot ('wml\mods\'+$studioId+'\mod.js')))) { throw ('Missing mod: '+$studioId) }
    $studioAfter = $studioAfter.Replace(('"'+$studioId+':off"'),('"'+$studioId+'"'))
    if ($studioAfter -notmatch ('"'+[regex]::Escape($studioId)+'"')) {
        $studioAfter = [regex]::Replace($studioAfter,'\]\);',('  "'+$studioId+'",'+[Environment]::NewLine+']);'),1)
    }
}
if ($Apply -and $studioBefore -ne $studioAfter) { Set-Content -LiteralPath $studioList -Value $studioAfter -Encoding UTF8 -NoNewline }
[PSCustomObject]@{List=$studioList; Changed=($studioBefore -ne $studioAfter); Applied=[bool]$Apply}
