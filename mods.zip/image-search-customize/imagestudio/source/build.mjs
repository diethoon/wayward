// 실행: node wml/mods/imagestudio/source/build.mjs
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
const dir=path.dirname(fileURLToPath(import.meta.url));
let mod=fs.readFileSync(path.join(dir,'mod.wml.js'),'utf8');
const vanillaIds=JSON.parse(fs.readFileSync(path.join(dir,'vanilla-ids.json'),'utf8'));
mod=mod.replace('__IMAGE_STUDIO_VANILLA_IDS__',JSON.stringify(vanillaIds.axes));
mod=mod.replace(/  symbols: ([^\n]+),\r?\n/, (match,symbols)=>'  symbols: '+JSON.stringify({...JSON.parse(symbols),...{"topFeelings":{"raw":{"2026-11-01":"i_"},"doc":"topFeelings"},"imageLookup":{"raw":{"2026-11-01":"vy"},"doc":"imageLookup"},"imageEntryUrl":{"raw":{"2026-11-01":"o_"},"doc":"imageEntryUrl"}}})+',\n');
mod=mod.replace('// 각 모드에 포함되는 설정 UI.',fs.readFileSync(path.join(dir,'h-status-images.js'),'utf8')+'\n// 각 모드에 포함되는 설정 UI.');
const sources=['h-status-images.js','matching-positions.js','extensions.js','image-key-normalization.js','native-ui.js','task-progress.js','prompt-review.js','usage-statistics.js'];
const result='// 생성 파일. source/build.mjs로 재생성합니다.\n'+sources.map(name=>fs.readFileSync(path.join(dir,name),'utf8')).join('\n')+'\n'+mod;
new vm.Script(result);
fs.writeFileSync(path.join(dir,'../mod.js'),Pre7_lazySetup(result));
console.log('Generated '+path.join(dir,'../mod.js'));

// pre7: loading a disabled mod must not initialize globals or change settings.
function Pre7_lazySetup(source){
  const at=source.indexOf('WML.define({');if(at<0)throw Error('WML definition missing');
  const prefix=source.slice(0,at);if(!prefix.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*/g,'').trim())return source;
  const header=prefix.match(/^(?:\s|\/\*[\s\S]*?\*\/|\/\/[^\n]*(?:\n|$))*/)[0];
  let found=false;
  const result=header+source.slice(at).replace(/((?:async\s+)?setup\([^)]*\)\s*\{)/,match=>{found=true;return match+'\n'+prefix+'\nObject.assign(globalThis,{ImageStudio_HStatus연결만들기,ImageStudio_HStatus설정그리기,ImageStudio_자세상황목록,ImageStudio_자세상황에맞는가,ImageStudio_확장등록창구만들기,ImageStudio_노출코드정규화하기,ImageStudio_노출키정규화하기,ImageStudio_계산묶음만들기,ImageStudio_진행표시만들기,ImageStudio_캐시진행응답읽기,ImageStudio_서버지원오류읽기,ImageStudio_프롬프트검수연결하기,ImageStudio_사용통계연결하기});\n';});
  if(!found)throw Error('setup declaration missing');return result;
}
