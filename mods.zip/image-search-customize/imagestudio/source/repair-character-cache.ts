// Approved one-time recovery: merge mislabeled *2 shards without changing image files.
// Run from game root with Bun. Default is read-only; --apply requires the server stopped.
import fs from 'node:fs';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import { CharacterCacheIndex, cacheCharacter } from '../backend/wayward-imagegen/src/cache/characterCacheIndex.ts';

const root = path.resolve(process.cwd(),'images'), apply = process.argv.includes('--apply');
const hash = (data: Buffer|string) => createHash('sha256').update(data).digest('hex');
const stamp = new Date().toISOString().replace(/[:.]/g,'-');
const backup = path.join(root,'.state','cache-backups','approved-character-merge-'+stamp);
const plans = ['hina','ichika','mika'].map(character => {
  const target = path.join(root,`.image-cache_${character}.json`), source = path.join(root,`.image-cache_${character}2.json`);
  const targetBytes = fs.readFileSync(target), sourceBytes = fs.readFileSync(source);
  const a = JSON.parse(targetBytes.toString()), b = JSON.parse(sourceBytes.toString());
  if(a.version!==1||b.version!==1||!a.entries||!b.entries)throw Error('Invalid cache schema');
  const entries = {...a.entries};let added=0,duplicates=0;
  for(const [key,entry] of Object.entries({...a.entries,...b.entries})) {
    if(cacheCharacter(entry as any)!==character)throw Error('Unexpected character in '+character+': '+key);
  }
  for(const [key,entry] of Object.entries(b.entries)) {
    if(Object.hasOwn(entries,key)) { if(!isDeepStrictEqual(entries[key],entry))throw Error('Conflicting duplicate: '+key);duplicates++; }
    else {entries[key]=entry;added++;}
  }
  if(fs.existsSync(source+'.bak'))throw Error('Backup name already exists: '+source+'.bak');
  return {character,target,source,targetBytes,sourceBytes,entries,added,duplicates,before:Object.keys(a.entries).length,sourceCount:Object.keys(b.entries).length};
});
const summary = plans.map(({character,before,sourceCount,added,duplicates,entries})=>({character,before,sourceCount,added,duplicates,after:Object.keys(entries).length}));
console.log(JSON.stringify({apply,summary,added:plans.reduce((n,p)=>n+p.added,0),duplicates:plans.reduce((n,p)=>n+p.duplicates,0)}));
if(!apply)process.exit(0);
let online=false;
try { await fetch('http://127.0.0.1:8189/api/image/health',{signal:AbortSignal.timeout(1500)});online=true; }catch{}
if(online)throw Error('Stop the image server before applying cache recovery');
fs.mkdirSync(backup,{recursive:true});
for(const plan of plans)for(const [file,bytes] of [[plan.target,plan.targetBytes],[plan.source,plan.sourceBytes]] as const) {
  const destination=path.join(backup,path.basename(file));
  fs.copyFileSync(file,destination,fs.constants.COPYFILE_EXCL);
  if(hash(fs.readFileSync(destination))!==hash(bytes))throw Error('Backup verification failed');
}
const staged = plans.map(plan=>({plan,temp:plan.target+'.repair-'+randomUUID()+'.tmp'}));
const committed:typeof plans=[],retired:typeof plans=[];
try {
  for(const {plan,temp} of staged) {
    if(hash(fs.readFileSync(plan.target))!==hash(plan.targetBytes)||hash(fs.readFileSync(plan.source))!==hash(plan.sourceBytes))throw Error('Cache changed since inspection');
    fs.writeFileSync(temp,JSON.stringify({version:1,entries:plan.entries}),{flag:'wx'});
    if(!isDeepStrictEqual(JSON.parse(fs.readFileSync(temp,'utf8')).entries,plan.entries))throw Error('Staged cache verification failed');
  }
  for(const {plan,temp} of staged) {
    if(hash(fs.readFileSync(plan.target))!==hash(plan.targetBytes)||hash(fs.readFileSync(plan.source))!==hash(plan.sourceBytes))throw Error('Cache changed before commit');
    fs.renameSync(temp,plan.target);committed.push(plan);
  }
  for(const plan of plans){fs.renameSync(plan.source,plan.source+'.bak');retired.push(plan);}
  const loaded=new CharacterCacheIndex(root).load().entries;
  for(const plan of plans)for(const [key,entry] of Object.entries(plan.entries))if(!isDeepStrictEqual(loaded[key],entry))throw Error('Reload mismatch: '+key);
  const result={completedAt:new Date().toISOString(),backup,summary,totalLoaded:Object.keys(loaded).length,
    files:plans.map(plan=>({target:plan.target,sha256:hash(fs.readFileSync(plan.target)),retired:plan.source+'.bak',originalSha256:hash(plan.sourceBytes)}))};
  fs.writeFileSync(path.join(backup,'result.json'),JSON.stringify(result,null,2)+'\n');
  fs.writeFileSync(path.resolve('wml/mods/imagestudio/cache-recovery-result.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result));
}catch(error){
  for(const plan of retired.reverse())fs.renameSync(plan.source+'.bak',plan.source);
  for(const plan of committed)fs.copyFileSync(path.join(backup,path.basename(plan.target)),plan.target);
  throw error;
}finally{for(const {temp} of staged)if(fs.existsSync(temp))fs.unlinkSync(temp);}
