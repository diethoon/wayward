// Refresh the provenance reference from an isolated game with every mod disabled.
// Run at the game root: node wml/mods/imagestudio/source/collect-vanilla-ids.mjs
import fs from 'node:fs';
import assert from 'node:assert/strict';
import { gameIndex } from '../../../../MCP/lib/game.mjs';
import { playStart, playEval, shutdown } from '../../../../MCP/lib/play.mjs';
import { readModSymbols } from '../../../tools/symbols-lib.mjs';
const mods = Object.fromEntries([...fs.readFileSync('wml/mods/mods.js','utf8').matchAll(/^\s*"([^":]+)(?::off)?"/gm)].map(m=>[m[1],false]));
const tasks = [...new Set([...gameIndex('ko').module.matchAll(/currentTask\s*[:=]+\s*["']([a-z_]+)["']/g)].map(m=>m[1]))];
const symbols=readModSymbols(fs.readFileSync(new URL('./mod.wml.js',import.meta.url),'utf8'));
const raw=Object.fromEntries(Object.entries(symbols).map(([name,value])=>[name,value.raw?.['2026-11-01']]));
try {
  const started = await playStart({id:'vanilla-ids',mods});
  assert.deepEqual(started.loaded,[]);
  const {result} = await playEval({id:'vanilla-ids',code:`
    const fn = WML.dev().fn, raw=${JSON.stringify(raw)}, groups = fn(raw.imageGroupSlots);
    return {character:fn('wives').map(wife=>wife.shortname),situation:[...new Set([...fn(raw.imageSexScenes),...fn(raw.imageEscalationScenes),...${JSON.stringify(tasks)},...fn(raw.imageTasks)])],
      outfit:fn('outfits').map(outfit=>outfit.id),room:[...fn(raw.imageRooms).map(room=>fn('imageRoom')(room)),'bedroom (침대 위)'],mood:fn(raw.imageMoods).map(value=>value||'default'),
      men:[...new Set(['0','1',...groups.map(group=>String(group.boys+1))])],roles:[...new Set(groups.map(group=>group.slots))],
      aftermath:fn(raw.imageAfters).map(value=>value||'none'),variant:['0','1','2','3']};
  `});
  const axes = Object.fromEntries(Object.entries(result).map(([axis,values])=>[axis,[...new Set(values)].sort()]));
  fs.writeFileSync(new URL('./vanilla-ids.json',import.meta.url),JSON.stringify({game:'2026-11-01',axes},null,2)+'\n');
  console.log(JSON.stringify(Object.fromEntries(Object.entries(axes).map(([axis,values])=>[axis,values.length]))));
} finally {await shutdown();}
process.exit(0);
