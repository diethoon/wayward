// 이미지 스튜디오 — WML 포팅판
// 원본: imagestudio.src_v1.js (md5 59ec45a9f83466ff38d543cc4c35a2da), 9-30 한글판 모드 매니저용 애드온.
// 원본에서 고친 곳 7군데: imagestudio-current.fixes.json
// 원본 코드는 아래 setup() 안에서 그대로 실행돼요. 게임 함수 연결은 addon-compat 모드가 해 줘요.
WML.define({
  id: "imagestudio",
  author: "Hina_Lover",
  name: "이미지 스튜디오",
  version: "1.31.20",
  game: "2026-11-01",
  lang: 'ko',
  backup: { indexedDB: ['wml.mod.imagestudio.usage'] },
  role: 'scene-prompt',
  description: "SDXL·Anima·NovelAI 생성 방식과 공통 대기열·검수·저장·캐시·이미지팩, 상황·프롬프트 확장 등록을 제공합니다.",
  requires: ["addon-compat"],
  loadAfter: ["newwife-hina", "attention-image-prompt"],
  conflicts: [],
  symbols: {
    "imagePlanner": {"raw":{"2026-11-01":"Uat"},"doc":"Image Studio conditional planner binding"},
    "imagePlannerAppend": {"raw":{"2026-11-01":"mu"},"doc":"Image Studio conditional planner binding"},
    "imageKeyParse": {"raw":{"2026-11-01":"rl"},"doc":"Image Studio conditional planner binding"},
    "imageArchetypeCharacter": {"raw":{"2026-11-01":"Fat"},"doc":"Image Studio conditional planner binding"},
    "imageMoods": {"raw":{"2026-11-01":"Mat"},"doc":"Image Studio conditional planner binding"},
    "imageTasks": {"raw":{"2026-11-01":"Dat"},"doc":"Image Studio conditional planner binding"},
    "imageEscalationScenes": {"raw":{"2026-11-01":"Rat"},"doc":"Image Studio conditional planner binding"},
    "imageSexScenes": {"raw":{"2026-11-01":"GB"},"doc":"Image Studio conditional planner binding"},
    "imageAfters": {"raw":{"2026-11-01":"Oat"},"doc":"Image Studio conditional planner binding"},
    "imageSexExposures": {"raw":{"2026-11-01":"UB"},"doc":"Image Studio conditional planner binding"},
    "imageEscalationExposures": {"raw":{"2026-11-01":"Pat"},"doc":"Image Studio conditional planner binding"},
    "imageTaskExposures": {"raw":{"2026-11-01":"qB"},"doc":"Image Studio conditional planner binding"},
    "imageGroupSlots": {"raw":{"2026-11-01":"VB"},"doc":"Image Studio conditional planner binding"},
    "imageRooms": {"raw":{"2026-11-01":"Za"},"doc":"Image Studio conditional planner binding"},
    "imageFloorOutfits": {"raw":{"2026-11-01":"ene"},"doc":"Image Studio conditional planner binding"},
    "imageBathOutfits": {"raw":{"2026-11-01":"ene"},"doc":"Image Studio conditional planner binding"},
    "sceneFamily": {"raw":{"2026-11-01":"df"},"doc":"Image Studio conditional planner binding"},
    "sceneDisallowsGroup": {"raw":{"2026-11-01":"lye"},"doc":"Image Studio conditional planner binding"},
    "imageUsageInitialState": {"raw":{"2026-11-01":"fc"},"doc":"Fresh game state factory; ImageStudio usage session marker"},
    "imageUsagePortraitPanel": {"raw":{"2026-11-01":"rv"},"doc":"Gameplay portrait panel; observe real scene prompt demand only"},
    "imageStudioAutonomousActions": {"raw":{"2026-11-01":"D2"},"doc":"아내의 자발 행동 후보 배열 () -> actions"},
    "imageStudioDailyOutfit": {"raw":{"2026-11-01":"tq"},"doc":"등장·기상 후 아내의 자발적 일상복 선택 (state, stats?) -> outfitId"},
    "imageStudioCoverOutfit": {"raw":{"2026-11-01":"XU"},"doc":"아내의 자발적 가림용 평상복 변경 (state, reason) -> {state,target}"},
    "imageStudioApplyOutfitResponse": {"raw":{"2026-11-01":"L0"},"doc":"대화 응답의 의상/노출/장면 변경 적용 (state,response) -> state"},
    "imageStudioTryOutfit": {"raw":{"2026-11-01":"GXe"},"doc":"옷가게에서 플레이어가 선택한 의상 시착 (state,outfitId) -> state"},
    "topFeelings": {"raw":{"2026-11-01":"i_"},"doc":"인물의 강한 감정을 세기 순서로 조회"},
    "imageLookup": {"raw":{"2026-11-01":"vy"},"doc":"이미지 키에 맞는 팩 항목 또는 가장 가까운 대체 항목 조회"},
    "imageEntryUrl": {"raw":{"2026-11-01":"o_"},"doc":"이미지팩 항목의 실제 표시 URL"}
  },

  setup(wmlApi) {
    const api = globalThis.__waywardPauseSettingsUiFactory.connect(wmlApi, {"id":"imagestudio","label":"이미지 스튜디오","bindings":{"2026-10-04":{"store":"ae","settingsStore":"At","React":"Z","jsx":"u","ActionButton":"Ze","ActionPanel":"aO","wife":"_","updateWife":"O","updateCharacter":"nn","log":"N","tick":"Jt","intoxLabel":"In","playerId":"fe","wifeId":"Re","locationOf":"$e","wifeLocation":"_e","playerLocation":"bt","moveOccupant":"Pt","patronScene":"Y","playerSexScene":"Le","setScene":"MV","patronSceneLocation":"tt","isSexualStage":"it","sceneDef":"ls","sceneOutfitState":"bx","garmentWorn":"vr","exposureSummary":"nf","patronWatchChoices":"Xae","patronChoice":"tNe","startPlayerSex":"_p","playerSexEvent":"Fl","ensureHusbandLed":"F8","addJoinedPatron":"nfe","joinSlots":"NH","registerAlert":"nr","queueAlert":"gn","drainAlerts":"gl","imagePrompt":"r8","imageKey":"s8","imageKeyOf":"n8","imageDescriptor":"o8","makeCustomer":"ff","addCustomer":"Ka","carryToBed":"RDe","talkToWife":"EF","actionTimes":"Oo","addFeeling":"we","addIdentityStrainFromPatronAct":"Kf","getCustomerLocation":"Yn","getEffectiveAttributes":"B","heroineConditioningMax":"QX","heroineDriveCalc":"si","moveWife":"pt","outfits":"fh","patronControlCustomerLocation":"ht","wifeById":"ul","wifePreview":"gue","reduceGameAction":"wT","brothelLog":"hs","decisionCategories":"bo","decisionResolve":"G$e","manaMax":"ms","minuteTick":"gp","recordPlayerTone":"Rt","wives":"mh","imageBackend":"Eh","brothelCustomerBusy":"XO","buildPatronMoveCandidates":"Phe","ejectCustomer":"Q5","endPatronInteraction":"jt","finishBackRoomService":"xF","forceAttemptChance":"Ppe","patronControlAcquaintanceStop":"_Ie","patronControlAttemptRoll":"Iy","patronControlBackRoomOpen":"Tr","patronControlBareForPushIn":"O5","patronControlChooseMove":"Yhe","patronControlCoercionEscape":"cpe","patronControlFavorTable":"h3","patronControlHerBackRoomProposal":"ipe","patronControlIntentEvolve":"z$","patronControlJoinerComfort":"wh","patronControlJoinerPushIn":"jIe","patronControlLineUp":"Gce","patronControlLungePlan":"Vre","patronControlMortifyingCheck":"b$","patronControlMoveCustomer":"Yt","patronControlNaturalEnd":"hI","patronControlPatronBackRoomProposal":"ape","patronControlPatronDrift":"Kbe","patronControlPlayerAway":"Tt","patronControlPositionWeights":"Fhe","patronControlPrivateSession":"wpe","patronControlPrivateSessionInfo":"a0","patronControlPushIn":"qce","patronControlPushInAnalReaction":"p6","patronControlPushInReaction":"R6","patronControlRelentChance":"Bpe","patronControlRequestTable":"E2e","patronControlSelfEscalationRoll":"Qre","patronControlShameStop":"dpe","patronControlSlotFree":"kS","patronControlSmallRequest":"R2e","patronControlStageLabel":"hG","patronControlStrengthContest":"Za","patronControlTacticTable":"lIe","patronControlUndressAttempt":"AIe","patronControlVerbalAsk":"$5e","patronControlWitnessesFor":"Ks","patronControlYieldRoll":"pB","playerActionPublicRefusal":"Rs","processPatronGroupJoin":"BS","processPatronGroupParticipants":"WS","processPatronInteractionTick":"R7","recordPatronMistreatment":"yl","recordPatronReach":"K5e","resolvePatronEscalation":"ub","resolvePatronForce":"gB","rotatePatronGroupAfterPrimary":"Gie","selectPatronTactic":"gIe","startPatronInteraction":"Go","transitionPatronStage":"Dn","evaluateIntimacy":"Pe","getMaritalDrift":"E4","getPatronAttachment":"Uo","nudgeRelationship":"Mo","recordAffection":"Iw","recordIntimateHistory":"Wd","recordPatronBoundary":"Qi","brothelRoomLabels":"bO","imageRoom":"lue","waitressAlternative":"u$","waitressAvailable":"Bd","waitressChooseOrder":"Jle","waitressConsume":"_w","waitressIncome":"Qt","waitressMissing":"CP","waitressPrice":"d$","waitressRecordDrink":"vw","waitressRecordWord":"VB","playerActionRespond":"P1e","playerActionTopicFatigue":"GY","playerActionTouchedOut":"er","promptJoin":"J6","promptRoomFilter":"$de","promptGenParams":"q6","outfitById":"Ot","saveSlotInfo":"Mb","listDayStarts":"ZI","saveDayStart":"UDe","wifePortraits":"z6e","resentment":"Ue","marriageBond":"VT","wakeUp":"FI","gameOverScreen":"HLe","allureScore":"Ir","normalVisitRoll":"nhe","lodgingChance":"IB","worldTick":"Dp","hotkeyAction":"sG","confirmAction":"N4e","busyTask":"X0","imageManifest":"Wb","imageServerUrl":"Cs","imageGenerate":"LPe","imageQueue":"g6e","imageBackendProbe":"JU","imageBackendForget":"UD","imagePackReset":"qD","imageAutoProbeAllowed":"KU","imagePlanner":"r6e","imagePlannerAppend":"Dc","imageKeyParse":"fp","imageArchetypeCharacter":"n6e","imageMoods":"QLe","imageTasks":"JLe","imageEscalationScenes":"KLe","imageSexScenes":"SO","imageAfters":"XLe","imageSexExposures":"TO","imageEscalationExposures":"ZLe","imageTaskExposures":"$O","imageGroupSlots":"IO","imageRooms":"M_","imageFloorOutfits":"hS","imageBathOutfits":"cS","sceneFamily":"au","sceneDisallowsGroup":"Zne"}, "2026-11-01": {"store":"ae","settingsStore":"at","React":"J","jsx":"u","ActionButton":"ht","ActionPanel":"SB","wife":"_","updateWife":"C","updateCharacter":"rn","log":"j","tick":"Jt","intoxLabel":"Sn","playerId":"ge","wifeId":"Ee","locationOf":"Ae","wifeLocation":"we","playerLocation":"vt","moveOccupant":"Ht","patronScene":"U","playerSexScene":"Be","setScene":"dK","patronSceneLocation":"Je","isSexualStage":"ct","sceneDef":"Sr","sceneOutfitState":"KMe","garmentWorn":"Zr","exposureSummary":"_g","patronWatchChoices":"Dbe","patronChoice":"uZ","startPlayerSex":"uh","playerSexEvent":"Kl","ensureHusbandLed":"ihe","addJoinedPatron":"C3e","joinSlots":"eU","registerAlert":"ar","queueAlert":"_n","drainAlerts":"oi","imagePrompt":"DR","imageKey":"zz","imageKeyOf":"CR","imageDescriptor":"RR","makeCustomer":"Ag","addCustomer":"Fi","carryToBed":"r5e","talkToWife":"gee","actionTimes":"tn","addFeeling":"Se","addIdentityStrainFromPatronAct":"Qf","getCustomerLocation":"Jn","getEffectiveAttributes":"B","heroineConditioningMax":"eue","heroineDriveCalc":"il","moveWife":"Nt","outfits":"Oi","patronControlCustomerLocation":"et","wifeById":"$m","wifePreview":"WL","reduceGameAction":"p5","brothelLog":"ds","decisionCategories":"Ho","decisionResolve":"DFe","manaMax":"Ys","minuteTick":"ry","recordPlayerTone":"qn","wives":"kr","imageBackend":"yh","brothelCustomerBusy":"z5","buildPatronMoveCandidates":"Zve","ejectCustomer":"HR","endPatronInteraction":"Rt","finishBackRoomService":"IV","forceAttemptChance":"iIe","patronControlAcquaintanceStop":"OUe","patronControlAttemptRoll":"g0","patronControlBackRoomOpen":"xS","patronControlBareForPushIn":"Q2","patronControlChooseMove":"sxe","patronControlCoercionEscape":"YOe","patronControlFavorTable":"wY","patronControlHerBackRoomProposal":"dGe","patronControlIntentEvolve":"AC","patronControlJoinerComfort":"ch","patronControlJoinerPushIn":"KUe","patronControlLineUp":"ADe","patronControlLungePlan":"s8e","patronControlMortifyingCheck":"b_","patronControlMoveCustomer":"lo","patronControlNaturalEnd":"GC","patronControlPatronBackRoomProposal":"cGe","patronControlPatronDrift":"NHe","patronControlPlayerAway":"yt","patronControlPositionWeights":"rxe","patronControlPrivateSession":"ZJ","patronControlPrivateSessionInfo":"Nh","patronControlPushIn":"jDe","patronControlPushInAnalReaction":"N9","patronControlPushInReaction":"wz","patronControlRelentChance":"mIe","patronControlRequestTable":"JGe","patronControlSelfEscalationRoll":"l8e","patronControlShameStop":"WOe","patronControlSlotFree":"G$","patronControlSmallRequest":"QGe","patronControlStageLabel":"Ote","patronControlStrengthContest":"el","patronControlTacticTable":"$Ue","patronControlUndressAttempt":"zUe","patronControlVerbalAsk":"A7e","patronControlWitnessesFor":"hs","patronControlYieldRoll":"Xq","playerActionPublicRefusal":"ir","processPatronGroupJoin":"gN","processPatronGroupParticipants":"XS","processPatronInteractionTick":"cZ","recordPatronMistreatment":"yl","recordPatronReach":"bPe","resolvePatronEscalation":"_b","resolvePatronForce":"Zq","rotatePatronGroupAfterPrimary":"jle","selectPatronTactic":"MUe","startPatronInteraction":"Xo","transitionPatronStage":"js","evaluateIntimacy":"We","getMaritalDrift":"i4","getPatronAttachment":"Uo","nudgeRelationship":"ko","recordAffection":"Iw","recordIntimateHistory":"Om","recordPatronBoundary":"tl","brothelRoomLabels":"LB","imageRoom":"ER","waitressAlternative":"JA","waitressAvailable":"zr","waitressChooseOrder":"uTe","waitressConsume":"v_","waitressIncome":"vo","waitressMissing":"K7","waitressPrice":"zv","waitressRecordDrink":"ox","waitressRecordWord":"vK","playerActionRespond":"IWe","playerActionTopicFatigue":"sX","playerActionTouchedOut":"er","promptJoin":"Yz","promptRoomFilter":"uMe","promptGenParams":"Dz","outfitById":"Ot","saveSlotInfo":"Bk","listDayStarts":"h$","saveDayStart":"y5e","wifePortraits":"Uit","resentment":"qe","marriageBond":"dA","wakeUp":"vD","gameOverScreen":"kat","allureScore":"aa","normalVisitRoll":"wTe","lodgingChance":"mK","worldTick":"py","hotkeyAction":"KG","confirmAction":"NYe","busyTask":"sv","imageManifest":"bh","imageServerUrl":"es","imageGenerate":"xst","imageQueue":"eit","imageBackendProbe":"FD","imageBackendForget":"iM","imagePackReset":"t_","imageAutoProbeAllowed":"eoe","imagePlanner":"Uat","imagePlannerAppend":"mu","imageKeyParse":"rl","imageArchetypeCharacter":"Fat","imageMoods":"Mat","imageTasks":"Dat","imageEscalationScenes":"Rat","imageSexScenes":"GB","imageAfters":"Oat","imageSexExposures":"UB","imageEscalationExposures":"Pat","imageTaskExposures":"qB","imageGroupSlots":"VB","imageRooms":"Za","imageFloorOutfits":"ene","imageBathOutfits":"ene","sceneFamily":"df","sceneDisallowsGroup":"lye"}}});
    // ---- 현재 게임에 맞춘 보정 ----
    // What the 9-30 mod manager changed inside the game for the Image Studio, redone as WML hooks.
    const LG = globalThis.__WML_LEGACY__;
    const raw = LG.name, G = LG.get;            // old 9-30 name -> current name / current value
    // 최초 실행은 게임의 이미지 생성 설정을 따릅니다. 저장한 오프라인 전용 선택은 첫 이미지 조회 전부터 유지합니다.
    if (globalThis.__WW_STUDIO_OFFLINE_ONLY__ === undefined) {
      try { globalThis.__WW_STUDIO_OFFLINE_ONLY__ = localStorage.getItem('ww-image-studio-offline-only-v1') === 'true'; }
      catch { globalThis.__WW_STUDIO_OFFLINE_ONLY__ = false; }
    }
    const offline = () => !!globalThis.__WW_STUDIO_OFFLINE_ONLY__;
    const outfitLockKey = 'ww-image-studio-lock-wife-outfit-v1';
    if (globalThis.__WW_STUDIO_LOCK_WIFE_OUTFIT__ === undefined) {
      try { globalThis.__WW_STUDIO_LOCK_WIFE_OUTFIT__ = localStorage.getItem(outfitLockKey) === 'true'; }
      catch { globalThis.__WW_STUDIO_LOCK_WIFE_OUTFIT__ = false; }
    }
    const outfitLocked = () => !!globalThis.__WW_STUDIO_LOCK_WIFE_OUTFIT__;
    const lockOutfitDefinition = api.fn('outfitById');
    const lockWifeLocation = api.fn('wifeLocation');
    const bathContext = (state, character) => ['bathhouse', 'bathroom'].includes(lockWifeLocation(state))
      || character?.currentTask === 'bathing' || String(character?.sceneOverride || '').startsWith('bath_');
    const ordinaryLockedOutfit = (state, character, outfit = character?.outfit) => {
      const wear = lockOutfitDefinition(outfit)?.wear;
      return outfit && wear !== 'sleep' && wear !== 'bath'
        && !(['naked', 'nude'].includes(outfit) && bathContext(state, character)) ? outfit : null;
    };
    const rememberLockedOutfit = (state, characterId, outfit) => {
      if (!outfit) return state;
      const stored = state.mods?.imagestudio?.outfitLock;
      if (stored?.characterId === characterId && stored.outfit === outfit) return state;
      return { ...state, mods: { ...state.mods, imagestudio: { ...state.mods?.imagestudio, outfitLock: { characterId, outfit } } } };
    };
    // 착용 결과를 되돌리지 않고, 지시·시착으로 바뀐 평상복을 다음 자동 선택의 기준으로 기록합니다.
    function rememberChangedOutfit(state, result, characterId) {
      const before = state?.characters?.[characterId], after = result?.characters?.[characterId];
      if (!before || !after) return result;
      const stored = state.mods?.imagestudio?.outfitLock;
      const previous = stored?.characterId === characterId ? stored.outfit : null;
      const target = ordinaryLockedOutfit(result, after) || previous || ordinaryLockedOutfit(state, before)
        || ordinaryLockedOutfit(state, before, before.outfitBeforeBath);
      return rememberLockedOutfit(result, characterId, target);
    }
    // 명시적 지시·시착으로 잠옷/목욕복을 선택한 경우에도 이전 평상복으로 되돌리지 않습니다.
    function rememberRequestedOutfit(state, result, outfit) {
      const characterId = state?.primaryCharacterId;
      return outfit && result?.characters?.[characterId]?.outfit === outfit
        ? rememberLockedOutfit(result, characterId, outfit) : result;
    }
    function setOutfitLock(value) {
      const changed = outfitLocked() !== !!value;
      globalThis.__WW_STUDIO_LOCK_WIFE_OUTFIT__ = !!value;
      if (!changed) return;
      api.store.update(state => {
        if (!state?.characters?.[state.primaryCharacterId]) return state;
        const { outfitLock, ...settings } = state.mods?.imagestudio || {};
        const next = { ...state, mods: { ...state.mods, imagestudio: settings } };
        const wife = next.characters?.[next.primaryCharacterId];
        return value ? rememberLockedOutfit(next, next.primaryCharacterId, ordinaryLockedOutfit(next, wife)
          || ordinaryLockedOutfit(next, wife, wife?.outfitBeforeBath)) : next;
      });
    }
    
    // 1. "offline only": the game makes no image/video generation calls (cached images are still shown)
    api.hook(raw('qMe'), { before: () => (offline() ? { cancel: true, value: Promise.resolve(null) } : undefined) });
    const GUARDED = new Set(['/api/video/check', '/api/image/generate', '/api/video/generate']);
    api.hook(raw('Is'), { before: ([path]) => (offline() && GUARDED.has(path) ? { cancel: true, value: null } : undefined) });
    api.hook(raw('I3e'), { before: () => (offline() ? { cancel: true, value: undefined } : undefined) });
    api.hook('updateWife', { priority: 10000, around(next, state, updater) {
      if (!outfitLocked()) return next(state, updater);
      return rememberChangedOutfit(state, next(state, updater), state?.primaryCharacterId);
    } });
    api.hook('updateCharacter', { priority: 10000, around(next, state, characterId, updater) {
      if (!outfitLocked() || characterId !== state?.primaryCharacterId) return next(state, characterId, updater);
      return rememberChangedOutfit(state, next(state, characterId, updater), characterId);
    } });

    // 자발적 환복은 실행 후보에서 제외하여 실제 환복과 다른 로그·제안을 만들지 않습니다.
    const voluntaryOutfitActions = new Set(['security_cover_up', 'desire_dress_bolder', 'afternoon_try_on']);
    api.hook('imageStudioAutonomousActions', { after(result) {
      return outfitLocked() ? result.filter(action => !voluntaryOutfitActions.has(action.id)) : result;
    } });
    api.hook('imageStudioDailyOutfit', { before: ([state]) => {
      if (!outfitLocked()) return;
      const characterId = state?.primaryCharacterId, character = state?.characters?.[characterId];
      const stored = state?.mods?.imagestudio?.outfitLock;
      const outfit = ordinaryLockedOutfit(state, character)
        || (stored?.characterId === characterId ? stored.outfit : null)
        || ordinaryLockedOutfit(state, character, character?.outfitBeforeBath);
      if (outfit) return { cancel: true, value: outfit };
    } });
    // 피로로 쉬러 가는 도중의 자발적 평상복 변경만 중단하고 휴식 자체는 유지합니다.
    api.hook('imageStudioCoverOutfit', { before: ([state]) => outfitLocked()
      ? { cancel: true, value: { state, target: null } } : undefined });
    api.hook('imageStudioApplyOutfitResponse', { after(result, [state, response]) {
      return outfitLocked() ? rememberRequestedOutfit(state, result, response?.outfitChange) : result;
    } });
    api.hook('imageStudioTryOutfit', { after(result, [state, outfit]) {
      return outfitLocked() ? rememberRequestedOutfit(state, result, outfit) : result;
    } });
    
    // 2. the random-generation window can open on a chosen wife (it starts on the first wife of the list)
    api.hook(raw('gPe'), {
      around(next, props, ...rest) {
        const order = G('dd'), want = props && props.initialWife, at = want ? order.indexOf(want) : -1;
        if (at <= 0) return next(props, ...rest);
        order.splice(at, 1); order.unshift(want);
        try { return next(props, ...rest); } finally { order.splice(order.indexOf(want), 1); order.splice(at, 0, want); }
      },
    });
    
    // 4. the complete bridge the studio talks to. The old installer injected
    // axes()/fromKey() into the game bundle; a WML port must provide them itself.
    const imagePlanner = api.fn('imagePlanner');
    const appendImagePlan = api.fn('imagePlannerAppend');
    const parseImageKey = key => api.fn('imageKeyParse')(ImageStudio_노출키정규화하기(key));
    const archetypeCharacter = api.fn('imageArchetypeCharacter');
    const imageMoods = api.fn('imageMoods');
    const imageTasks = [...new Set([...api.fn('imageTasks'), 'resting', 'sleeping'])];
    const imageEscalations = api.fn('imageEscalationScenes');
    const imageSexScenes = api.fn('imageSexScenes');
    const imageAfters = api.fn('imageAfters');
    const imageSexExposures = api.fn('imageSexExposures');
    const imageEscalationExposures = api.fn('imageEscalationExposures');
    const imageTaskExposures = api.fn('imageTaskExposures');
    const imageGroupSlots = api.fn('imageGroupSlots');
    // Stable planner lists physical locations; imageRoom maps them to supported image backgrounds.
    const imageRooms = [...new Set(api.fn('imageRooms').map(room => api.fn('imageRoom')(room)))];
    const imageFloorOutfits = api.fn('imageFloorOutfits').filter(id => api.fn('outfitById')(id)?.wear !== 'bath');
    const imageBathOutfits = [...api.fn('imageBathOutfits').filter(id => api.fn('outfitById')(id)?.wear === 'bath'), 'nude'];
    const imageServerUrl = api.fn('imageServerUrl');
    const sceneFamily = api.fn('sceneFamily');
    const sceneDisallowsGroup = api.fn('sceneDisallowsGroup');
    const outfitRegistry = api.fn('outfits');
    
    const EXPOSURE_FIELDS = ['bodiceUnlaced', 'topPulledDown', 'topRemoved', 'skirtUp', 'skirtRemoved', 'pantiesAside', 'pantiesRemoved'];
    const EXPOSURE_LABELS = ['상의 끈 풀기', '상의를 내려 가슴 노출', '상의 벗기기', '치마 걷어 올리기', '치마 벗기기', '팬티 옆으로 젖히기', '팬티 벗기기'];
    const TASK_LABELS = {
      idle: '대기 중', greeting: '손님 맞이', taking_order: '주문 받기', serving: '서빙', cleaning: '청소',
      cooking: '요리', resting: '휴식', sleeping: '수면', composing: '마음 추스르기', bathing: '목욕', passed_out: '의식을 잃음',
    };
    const SCENE_LABELS = {
      patron_chatting: '손님과 대화', patron_flirting: '손님과 추파', patron_touching: '가벼운 스킨십', patron_bold: '대담한 스킨십',
      patron_groping: '몸 더듬기', patron_groping_lap: '무릎 위에서 몸 더듬기', patron_intimate: '친밀한 접촉', patron_intimate_lap: '무릎 위 친밀한 접촉',
      patron_handjob: '손으로 자극', patron_handjob_finish: '손으로 자극 · 마무리', patron_handjob_climax: '손으로 자극 · 절정',
      patron_blowjob: '구강 성교', patron_deepthroat: '목 깊숙이 애무', patron_blowjob_climax: '구강 성교 · 절정', patron_blowjob_swallow: '정액 삼키기',
      patron_rubbing: '성기 비비기', patron_rubbing_finish: '성기 비비기 · 마무리', patron_rubbing_climax: '성기 비비기 · 절정',
      patron_sex: '손님과 성관계', patron_sex_climax: '손님과 성관계 · 절정', patron_sex_finish: '손님과 성관계 · 내부 사정',
      patron_sex_finish_pullout: '손님과 성관계 · 외부 사정', patron_riding: '손님 위에 올라타기', patron_standing_sex: '손님과 서서 성관계',
      patron_anal: '손님과 항문 성교', patron_anal_climax: '손님과 항문 성교 · 절정', patron_anal_finish: '항문 성교 · 내부 사정',
      patron_anal_finish_pullout: '항문 성교 · 외부 사정', patron_cunnilingus: '손님에게 여성기 애무받기', patron_mutual_touching: '손님과 서로 애무',
      patron_titfuck: '가슴으로 손님 자극', patron_breast_worship: '손님의 가슴 애무', patron_facial: '손님이 얼굴에 사정', patron_self_stroke: '손님의 자위 보기',
      patron_thigh_job: '허벅지로 비비기(스마타)',
      bath_solo: '혼자 목욕', bath_attendant: '목욕 시중', bath_attendant_wash_chest: '목욕 시중 · 가슴 씻기', bath_attendant_wash_body: '목욕 시중 · 몸 씻기',
      bath_attendant_handjob: '목욕 중 손으로 자극', bath_with_patron: '손님과 목욕', kissing: '입맞춤', groped_ass: '엉덩이 만지기', groped_tits: '가슴 만지기',
      grinding: '몸 비비기', lap_dance: '무릎 위 춤', thigh_job: '허벅지로 애무', handjob: '손으로 애무', fingered: '손가락으로 애무받기',
      mutual_touching: '서로 애무', blowjob: '입으로 애무', deepthroat: '목 깊숙이 애무', cunnilingus: '여성기 구강 애무', face_sitting: '얼굴 위에 앉기',
      sixty_nine: '서로 구강 애무', breast_worship: '가슴 애무', titfuck: '가슴으로 애무', sex: '성관계', riding: '위에 올라타기',
      standing_sex: '서서 성관계', sex_rough: '거친 성관계', anal_fingering: '항문을 손가락으로 애무', anal: '항문 성교', self_pleasure: '자위',
      facial: '얼굴에 사정', finish_on_stomach: '배에 사정', finish_on_chest: '가슴에 사정', finish_on_back: '등에 사정', clean_with_mouth: '입으로 닦기', cum_in_mouth: '입 안에 사정',
      patron_moment_cleavage: '가슴골 보여주기', patron_moment_flash_tits: '가슴 드러내기', patron_moment_lift_skirt: '치마 걷어 올리기',
      patron_moment_sit_on_lap: '무릎 위에 앉기', patron_moment_show_tongue: '혀 내밀기', patron_moment_twirl: '몸 돌려 보이기', patron_moment_pose_dance: '춤추며 포즈 취하기',
    };
    const ROOM_LABELS = { taproom: '홀', back_room: '뒷방', bedroom: '침실', bathhouse: '목욕탕', 'bedroom (침대 위)': '침실 · 침대 위' };
    const MOOD_LABELS = {
      default: '기본 표정', smile: '미소', shy: '수줍음', scared: '겁먹음', worried: '걱정',
      aroused: '흥분함', enjoying: '즐기는 중', relieved: '안도함', nervous: '긴장함',
    };
    const ADDITIONAL_MOOD_PROMPTS = Object.freeze({
      aroused: 'aroused, flushed face, heavy breathing, parted lips',
      enjoying: 'pleasure, blush, half-closed eyes, open mouth, relaxed expression',
      relieved: 'relieved, soft eyes, faint smile, relaxed eyebrows',
      nervous: 'nervous, furrowed brow, wide-eyed, tense expression, sweatdrop',
    });
    const ADDITIONAL_MOODS = Object.keys(ADDITIONAL_MOOD_PROMPTS);
    for (const mood of ADDITIONAL_MOODS) if (!imageMoods.includes(mood)) imageMoods.push(mood);
    const AFTER_LABELS = { none: '없음', sweat: '땀과 홍조', messy: '몸에 흔적', facial: '얼굴에 흔적' };
    const ROLE_LABELS = { m: '입', h: '손', b: '가슴', x: '뒤쪽', r: '비비기', i: '질 삽입', a: '항문 삽입', w: '지켜보기' };
    const AXIS_HELP = {
      character: '같은 조건으로 이미지를 만들 대상입니다. 여러 명을 고르면 인물마다 별도 프롬프트와 이미지 키를 만듭니다.',
      situation: "게임이 실제로 사용하는 작업·접촉·성행위 키입니다. 손님 장면과 당신 장면은 서로 다른 키라 별도로 선택합니다.",
      outfit: '게임 의상 정의에서 읽었습니다. 의상 이름 아래 설명은 게임 내 실제 외형 설명이며, 목욕 전용 의상은 목욕 장면에서만 사용합니다.',
      room: '장면의 배경입니다. 침실의 “침대 위”는 별도 이미지 키(abed-1)이므로 일반 침실과 따로 셉니다.',
      mood: '표정 변형입니다. 기본 표정은 mood 키가 없는 원본 구도입니다.',
      men: '완성 이미지에 등장하는 전체 남성 수입니다. 그룹 장면의 grp-N은 추가 합류 인원이라 화면 인원은 N+1명입니다.',
      roles: '그룹 장면에서 추가 남성이 맡는 위치를 왼쪽부터 기록한 gslot 키입니다. 남성 수가 0~1명이면 이 조건은 사용하지 않습니다.',
      exposure: '게임이 사용하는 7자리 exp 코드로 정규화하여 같은 노출 상태를 한 번만 표시합니다. 순서는 상의 끈·상의 내림·상의 제거·치마 올림·치마 제거·팬티 옆으로·팬티 제거입니다. 기존 이미지팩의 중복 표기도 같은 상태로 인식합니다.',
      aftermath: '일상 작업 이미지에 남는 사후 상태입니다. 성행위의 사정 방식은 장면 키나 마무리 의상(fin)으로 별도 처리됩니다.',
      variant: '같은 장면의 프롬프트 변형입니다. 장면마다 v-0~v-3을 편집할 수 있으며 일상 작업의 일반 생성은 v-0을 사용합니다.',
    };
    
    const unique = values => [...new Set(values.filter(value => value !== undefined && value !== null && value !== ''))];
    const exposureKey = value => ImageStudio_노출코드정규화하기(value ? EXPOSURE_FIELDS.map(field => value[field] ? '1' : '0').join('') : '') || 'none';
    const exposureObject = value => {
      const normalized = ImageStudio_노출코드정규화하기(value);
      if (!normalized) return undefined;
      return Object.fromEntries(EXPOSURE_FIELDS.map((field, index) => [field, normalized[index] === '1']));
    };
    const outfitDef = id => (Array.isArray(outfitRegistry) ? outfitRegistry.find(item => item?.id === id) : null);
    const plainLabel = value => String(value).replace(/[_:-]+/g, ' ').replace(/\b\w/g, char => char.toUpperCase());
    const roleText = value => [...String(value)].map((code, index) => `추가 남성 ${index + 1}: ${ROLE_LABELS[code] || code}`).join(' · ');
    const exposureText = value => value === 'none' ? '노출 상태를 따로 지정하지 않습니다.' : EXPOSURE_FIELDS.map((field, index) => value[index] === '1' ? EXPOSURE_LABELS[index] : '').filter(Boolean).join(' · ');
    const ImageStudio_태그목록읽기 = value => String(value || '').split(',').map(tag => tag.trim()).filter(Boolean);
    const ImageStudio_태그식별자읽기 = value => String(value || '').toLowerCase().replaceAll('_', ' ').replace(/\s+/g, ' ').trim();
    const ImageStudio_태그합치기 = (...values) => {
      const result = [], seen = new Set();
      for (const tag of values.flatMap(ImageStudio_태그목록읽기)) {
        const identity = ImageStudio_태그식별자읽기(tag);
        if (!identity || seen.has(identity)) continue;
        seen.add(identity); result.push(tag);
      }
      return result.join(', ');
    };
    const ImageStudio_짧은해시읽기 = value => {
      let hash = 2166136261;
      for (let index = 0; index < value.length; index += 1) { hash ^= value.charCodeAt(index); hash = Math.imul(hash, 16777619); }
      return (hash >>> 0).toString(36);
    };
    const ImageStudio_이미지기분읽기 = (talentId, parsed) => parsed?.mood
      || String(talentId || '').split('__').find(part => part.startsWith('mood-'))?.slice(5)
      || undefined;
    function ImageStudio_추가기분설정읽기(mood) {
      const saved = globalThis.WW_ImageStudioBridge?.extensions?.editor?.nativeAxisPrompt?.('mood', mood);
      return {
        positivePrompt: saved && Object.prototype.hasOwnProperty.call(saved, 'positivePrompt')
          ? String(saved.positivePrompt || '') : ADDITIONAL_MOOD_PROMPTS[mood] || '',
        negativePrompt: String(saved?.negativePrompt || ''),
      };
    }
    function ImageStudio_추가기분결과적용하기(item, mood) {
      if (!item || !ADDITIONAL_MOOD_PROMPTS[mood]) return item;
      const { positivePrompt, negativePrompt } = ImageStudio_추가기분설정읽기(mood);
      const sourceParts = Array.isArray(item.ImageStudioParts) ? item.ImageStudioParts : [];
      const moodParts = sourceParts.filter(part => ['기분', 'Mood'].includes(String(part?.label || '')));
      const otherTags = new Set(sourceParts.filter(part => !moodParts.includes(part))
        .flatMap(part => ImageStudio_태그목록읽기(part.tags)).map(ImageStudio_태그식별자읽기));
      const removed = new Set(moodParts.flatMap(part => ImageStudio_태그목록읽기(part.tags))
        .map(ImageStudio_태그식별자읽기).filter(tag => !otherTags.has(tag)));
      const prompt = ImageStudio_태그합치기(
        ImageStudio_태그목록읽기(item.prompt).filter(tag => !removed.has(ImageStudio_태그식별자읽기(tag))).join(', '),
        positivePrompt,
      );
      const negative = ImageStudio_태그합치기(item.negativePrompt, negativePrompt);
      const variant = String(item.talentId || '').match(/__v-\d+$/)?.[0] || '';
      const withoutVariant = variant ? String(item.talentId).slice(0, -variant.length) : String(item.talentId || '');
      const root = withoutVariant.split('__').filter(part => !part.startsWith('mood-') && !part.startsWith('studio-')).join('__');
      const signature = ImageStudio_짧은해시읽기(JSON.stringify([mood, positivePrompt, negativePrompt]));
      const { ImageStudioParts, ...clean } = item;
      return { ...clean, talentId: `${root}__mood-${mood}__studio-${signature}${variant}`, prompt, negativePrompt: negative };
    }
    
    const imageStudioHelp = {
      axis: axis => AXIS_HELP[axis] || (axis.startsWith('prompt') ? '프롬프트 수정의 설정을 사용합니다. 같은 항목에서 여러 값을 선택하면 각각 별도 조합으로 만들고, 지정하지 않으면 자동으로 처리합니다.' : ''),
      label(axis, value) {
        value = String(value);
        if (axis === 'situation') return TASK_LABELS[value] || SCENE_LABELS[value] || plainLabel(value);
        if (axis === 'outfit') return outfitDef(value)?.name || plainLabel(value);
        if (axis === 'room') return ROOM_LABELS[value] || plainLabel(value);
        if (axis === 'mood') return MOOD_LABELS[value] || plainLabel(value);
        if (axis === 'men') return value === '0' ? '남성 없음' : `남성 ${value}명`;
        if (axis === 'roles') return `gslot-${value} · ${roleText(value)}`;
        if (axis === 'exposure') return value === 'none' ? '노출 지정 없음' : `exp-${value}`;
        if (axis === 'aftermath') return AFTER_LABELS[value] || plainLabel(value);
        if (axis === 'variant') return value === '0' ? 'v-0 · 기본 구도' : `v-${value} · 구도 변형 ${value}`;
        return value;
      },
      describe(axis, value) {
        value = String(value);
        if (axis === 'situation') {
          if (TASK_LABELS[value]) return '일상 작업 이미지입니다. 남성 역할 조건은 적용되지 않습니다.';
          if (value.startsWith('patron_') || value === 'bath_with_patron' || value.startsWith('bath_attendant')) return '손님과 진행되는 장면입니다. 남성 수가 2명 이상이면 선택한 그룹 역할 조합을 함께 적용합니다.';
          if (value === 'self_pleasure' || value === 'bath_solo') return '남성이 등장하지 않는 단독 장면입니다.';
          return "당신과 진행되는 장면입니다. 장면이 그룹 구성을 지원할 때만 추가 남성 역할이 적용됩니다.";
        }
        if (axis === 'outfit') {
          const item = outfitDef(value); return item ? `${item.description || '게임에 등록된 의상입니다.'}${Number.isFinite(item.boldnessScore) ? ` · 대담함 ${item.boldnessScore}` : ''}` : '이미지 팩에서 발견한 의상 키입니다.';
        }
        if (axis === 'room') return value.includes('(침대 위)') ? '침실 배경 중 침대 위에서 진행되는 patron 장면 전용 키입니다.' : `${ROOM_LABELS[value] || value} 배경에서 만들 수 있는 조합만 남깁니다.`;
        if (axis === 'mood') return value === 'default' ? '별도의 mood 키를 붙이지 않아 게임의 기본 표정을 사용합니다.' : `${MOOD_LABELS[value] || value} 표정을 이미지 키와 프롬프트에 반영합니다.`;
        if (axis === 'men') return value === '0' ? '일상 작업·목욕·자위처럼 남성이 보이지 않는 장면입니다.' : value === '1' ? "당신 또는 손님 한 명만 등장하는 기본 장면입니다." : `기본 상대 1명과 추가 합류자 ${Number(value) - 1}명이 등장하는 그룹 장면입니다.`;
        if (axis === 'roles') return `${roleText(value)}. 역할 문자 수와 추가 합류 인원 수가 일치하는 조합에만 사용됩니다.`;
        if (axis === 'exposure') return `${exposureText(value)}${value === 'none' ? '' : ` · 7자리 키 ${value}`}`;
        if (axis === 'aftermath') return value === 'none' ? '땀이나 체액 흔적을 별도로 추가하지 않습니다.' : `${AFTER_LABELS[value] || value} 상태를 일상 이미지 프롬프트에 남깁니다.`;
        if (axis === 'variant') return value === '0' ? '게임이 기본으로 요청하는 첫 번째 카메라 구도입니다.' : '같은 상황·의상·장소를 유지하면서 카메라 구도만 바꿉니다.';
        return '';
      },
    };
    globalThis.WW_ImageStudioHelp = Object.freeze(imageStudioHelp);
    
    function refreshImageStudioOutfits() {
      if (!Array.isArray(outfitRegistry)) return;
      for (const item of outfitRegistry) {
        if (!item?.id) continue;
        const target = item.wear === 'bath' ? imageBathOutfits : imageFloorOutfits;
        if (Array.isArray(target) && !target.includes(item.id)) target.push(item.id);
      }
    }
    
    // Read the effective registry: direct WML registrations may never enter
    // __WAYWARD_WIFE_ADDONS__, and inherited prompt fields live on the presets.
    function imageStudio_collectWives() {
      const characters = new Map();
      let skipped = 0;
      for (const wife of G('Zl') || []) {
        if (!wife || typeof wife !== 'object') { skipped++; continue; }
        const id = String(wife.shortname || '').trim().toLowerCase();
        if (!/^[a-z0-9][a-z0-9_-]{0,99}$/.test(id) || id === 'patron') { skipped++; continue; }
        if (characters.has(id)) { skipped++; continue; }
        const prompt = String(wife.imageBase || '').trim();
        const negativePrompt = String(wife.imageNegative || '').trim();
        characters.set(id, {
          id, name: String(wife.name || id).trim().slice(0, 100) || id,
          prompt, negativePrompt, originalPrompt: prompt, originalNegativePrompt: negativePrompt,
        });
      }
      return { characters: [...characters.values()], skipped };
    }
    
    function imageStudioAxes() {
      refreshImageStudioOutfits();
      const item = (axis, value, extra = {}) => ({ value: String(value), label: imageStudioHelp.label(axis, value), description: imageStudioHelp.describe(axis, value), ...extra });
      const situations = [
        ...imageTasks.map(value => item('situation', value, { kind: 'task' })),
        ...imageEscalations.map(value => item('situation', value, { kind: 'scene' })),
        ...imageSexScenes.map(value => item('situation', value, { kind: 'scene' })),
      ];
      const outfits = unique(outfitRegistry.map(entry => entry?.id)).map(value => item('outfit', value));
      const rooms = unique([...imageRooms, 'bathhouse', 'bedroom (침대 위)']).map(value => item('room', value));
      const moods = unique([...imageMoods.map(value => value || 'default'), ...ADDITIONAL_MOODS]).map(value => item('mood', value));
      const groups = unique(imageGroupSlots.map(group => group?.slots));
      const men = unique(['0', '1', ...imageGroupSlots.map(group => String((Number(group?.boys) || 0) + 1))]).sort((a, b) => Number(a) - Number(b));
      const exposures = unique(['none', ...imageSexExposures.map(exposureKey), ...imageEscalationExposures.map(exposureKey), ...imageTaskExposures.map(exposureKey)]);
      return {
        character: unique(G('dd')).map(value => item('character', value)),
        situation: [...new Map(situations.map(entry => [entry.value, entry])).values()],
        outfit: outfits,
        room: rooms,
        mood: moods,
        men: men.map(value => item('men', value)),
        roles: groups.map(value => item('roles', value)),
        exposure: exposures.map(value => item('exposure', value)),
        aftermath: unique(imageAfters.map(value => value || 'none')).map(value => item('aftermath', value)),
        variant: ['0', '1', '2', '3'].map(value => item('variant', value)),
      };
    }

    // Captured with every mod disabled; live registries can contain mod additions.
    const ImageStudio_바닐라ID목록 = new Map(Object.entries(__IMAGE_STUDIO_VANILLA_IDS__).map(([axis,values]) => [axis,new Set(values)]));
    function ImageStudio_조건ID출처읽기(axis, value) {
      const id = String(value);
      if (axis === 'exposure') return id === 'none' || /^[01]{7}$/.test(id) ? 'vanilla' : 'mod';
      return ImageStudio_바닐라ID목록.get(axis)?.has(id) ? 'vanilla' : 'mod';
    }

    let ImageStudio_기본프롬프트수집완료 = false;
    let ImageStudio_기본프롬프트작업 = null, ImageStudio_기본프롬프트실행 = null;
    function ImageStudio_기본프롬프트상태읽기() {
      const work = ImageStudio_기본프롬프트작업;
      return { done: work?.done || 0, total: work?.total || 0, failed: work?.failed || 0, complete: ImageStudio_기본프롬프트수집완료 };
    }
    function ImageStudio_기본프롬프트양보하기(signal) {
      return new Promise(resolve => {
        let timer, frame;
        const finish = () => { cancelAnimationFrame(frame); clearTimeout(timer); signal?.removeEventListener('abort', finish); resolve(); };
        if (signal?.aborted) return finish();
        signal?.addEventListener('abort', finish, { once: true });
        frame = requestAnimationFrame(() => { timer = setTimeout(finish, 0); });
      });
    }
    async function ImageStudio_기본프롬프트수집하기({ signal, priority, onProgress } = {}) {
      if (ImageStudio_기본프롬프트실행) {
        await ImageStudio_기본프롬프트실행;
        if (signal?.aborted) return false;
        return ImageStudio_기본프롬프트수집하기({ signal, priority, onProgress });
      }
      if (ImageStudio_기본프롬프트수집완료) {
        const previous = ImageStudio_기본프롬프트작업;
        if (previous?.failedJobs.length) {
          previous.jobs.push(...previous.failedJobs.splice(0)); previous.done = previous.total - previous.jobs.length; previous.failed = 0;
          ImageStudio_기본프롬프트수집완료 = false;
        } else { onProgress?.(ImageStudio_기본프롬프트상태읽기()); return true; }
      }
      const work = ImageStudio_기본프롬프트작업 ||= ImageStudio_기본프롬프트작업만들기();
      if (!work) return false;
      const matches = (job, selected) => selected && (job.axis === selected.axis && job.id === selected.id
        || selected.axis === 'men' && job.axis === 'roles' && String(Number(job.options.group?.boys || 0) + 1) === selected.id);
      const task = (async () => {
        while (work.jobs.length && !signal?.aborted) {
          // 창이 그려진 뒤 계산하며 각 묶음 사이에 실제 프레임/입력 처리를 허용합니다.
          await ImageStudio_기본프롬프트양보하기(signal);
          if (signal?.aborted) break;
          const start = performance.now(), selected = priority?.();
          // 다른 계획 작업이 프레임 사이에 전역 플래너 상태를 바꿀 수 있어 묶음마다 초기화합니다.
          imagePlanner({ kinds: [], maxEntries: 1 });
          do {
            const preferred = work.jobs.findIndex(job => matches(job, selected));
            const [job] = work.jobs.splice(preferred < 0 ? 0 : preferred, 1);
            try { appendImagePlan(new Map(), work.template, job.options, work.archetypeId); }
            catch (error) { work.failed++; work.failedJobs.push(job); console.warn('[imagestudio] 기본 축 프롬프트 대표값 수집 실패', job.options, error); }
            work.done++;
          } while (work.jobs.length && !signal?.aborted && performance.now() - start < 8);
          ImageStudio_기본프롬프트수집완료 = !work.jobs.length;
          onProgress?.({ ...ImageStudio_기본프롬프트상태읽기(), priorityReady: !!selected && !work.jobs.some(job => matches(job, selected)) });
        }
        return ImageStudio_기본프롬프트수집완료 && !work.failed;
      })();
      ImageStudio_기본프롬프트실행 = task;
      try { return await task; } finally { if (ImageStudio_기본프롬프트실행 === task) ImageStudio_기본프롬프트실행 = null; }
    }
    // Only the live registry defines characters. The old cPe ID table is gone.
    function ImageStudio_캐릭터원형ID읽기(value) {
      const id = String(value || '').trim();
      if (!id) return null;
      const preset = (G('Zl') || []).find(entry => entry && (entry.shortname === id || entry.id === id));
      return preset?.id || null;
    }
    function ImageStudio_기본프롬프트작업만들기() {
      refreshImageStudioOutfits();
      const wife = globalThis.WW_ImageStudioBridge?.currentWife?.()
        || imageStudio_collectWives().characters[0]?.id
        || unique(G('dd'))[0];
      const archetypeId = ImageStudio_캐릭터원형ID읽기(wife);
      if (!archetypeId) return false;
      const template = archetypeCharacter(archetypeId);
      const floorOutfit = imageFloorOutfits.find(id => outfitDef(id)) || imageFloorOutfits[0] || unique(outfitRegistry.map(entry => entry?.id))[0];
      const bathOutfit = imageBathOutfits.find(id => outfitDef(id)) || imageBathOutfits[0];
      if (!template || !floorOutfit) return false;
      const jobs = [];
      const append = (options, axis = 'situation', id = options.task || options.scene || options.patronScene || '') => jobs.push({ options, axis, id: String(id) });
      const situations = [
        ...imageTasks.map(value => ({ value, kind: 'task' })),
        ...imageEscalations.map(value => ({ value, kind: 'scene' })),
        ...imageSexScenes.map(value => ({ value, kind: 'scene' })),
      ];
      for (const { value, kind } of situations) {
        const bath = value === 'bathing' || value.startsWith('bath_');
        const common = { outfit: bath ? bathOutfit : floorOutfit, room: bath ? 'bathhouse' : value === 'sleeping' ? 'bedroom' : 'taproom', variant: 0 };
        if (!common.outfit) continue;
        for (const variant of [0,1,2,3]) append({ ...common, variant, ...(kind === 'task' ? { task: value } : value.startsWith('patron_') ? { patronScene: value } : { scene: value }) });
      }
      for (const room of unique([...imageRooms, 'bathhouse', 'bedroom (침대 위)'])) {
        if (room === 'bathhouse') {
          if (bathOutfit) append({ outfit: bathOutfit, room: 'bathhouse', task: 'bathing', variant: 0 }, 'room', room);
        } else if (room.includes('(침대 위)')) {
          append({ outfit: floorOutfit, room: 'bedroom', patronScene: 'patron_chatting', abed: true, variant: 0 }, 'room', room);
        } else append({ outfit: floorOutfit, room, task: room === 'bedroom' ? 'sleeping' : 'idle', variant: 0 }, 'room', room);
      }
      for (const mood of unique([...imageMoods.map(value => value || 'default'), ...ADDITIONAL_MOODS])) {
        append({ outfit: floorOutfit, room: 'taproom', task: 'idle', mood: mood === 'default' ? undefined : mood, variant: 0 }, 'mood', mood);
      }
      append({ outfit: floorOutfit, room: 'taproom', patronScene: 'patron_chatting', variant: 0 }, 'men', '0');
      for (const group of imageGroupSlots) {
        append({ outfit: floorOutfit, room: 'taproom', patronScene: 'patron_groping', group, variant: 0 }, 'roles', group.slots);
      }
      for (const exposure of unique([...imageSexExposures, ...imageEscalationExposures, ...imageTaskExposures].map(exposureKey))) {
        append({ outfit: floorOutfit, room: 'taproom', task: 'idle', exposure: exposureObject(exposure), variant: 0 }, 'exposure', exposure);
      }
      return { template, archetypeId, jobs, total: jobs.length, done: 0, failed: 0, failedJobs: [] };
    }
    
    const setOf = (selected, axis, fallback = []) => new Set((Array.isArray(selected?.[axis]) && selected[axis].length ? selected[axis] : fallback)
      .map(value => axis === 'exposure' ? ImageStudio_노출코드정규화하기(String(value)) || 'none' : String(value)));
    const soloScenes = new Set(['self_pleasure', 'bath_solo']);
    const finishScenes = new Set(['facial', 'patron_facial']);
    const finishOutfits = [undefined, 'clothed', 'disheveled', 'exposed', 'hiked', 'nude'];
    const ImageStudio_입마개조건축 = 'promptField:badguest.gagged';
    const ImageStudio_입사용장면 = new Set([
      'blowjob', 'deepthroat', 'sixty_nine', 'clean_with_mouth', 'cum_in_mouth',
      'patron_blowjob', 'patron_deepthroat', 'patron_blowjob_climax', 'patron_blowjob_swallow',
    ]);
    const ImageStudio_입사용자세 = new Set([
      'kneeling-fellatio', 'deep-throat', 'irrumatio-front', 'upside-down-facefuck', 'sixty-nine',
    ]);
    const ImageStudio_입마개선택됨 = selected => setOf(selected, ImageStudio_입마개조건축).has('badguest.gagged');
    const ImageStudio_입마개조합인가 = combination => combination?.[ImageStudio_입마개조건축] === 'badguest.gagged';
    const ImageStudio_입마개와충돌하는가 = (options, combination, gagged = ImageStudio_입마개조합인가(combination)) => {
      if (!gagged) return false;
      const situation = options?.patronScene || options?.scene || options?.task || '';
      return ImageStudio_입사용장면.has(situation)
        || String(options?.group?.slots || '').includes('m')
        || ImageStudio_입사용자세.has(combination?.promptPosition);
    };
    const roomSpec = value => ({ room: String(value).replace(' (침대 위)', ''), abed: String(value).includes('(침대 위)') });
    const sleepwearCombinationAllowed = (situation, outfit, room) => outfitDef(outfit)?.wear !== 'sleep'
      || room === 'bedroom' || situation === 'sleeping' || situation === 'passed_out';
    
    function matchesImageStudioSelection(talentId, selected) {
      const parsed = parseImageKey(talentId);
      if (!parsed) return false;
      const situation = parsed.scene || parsed.task;
      const room = parsed.room + (parsed.abed ? ' (침대 위)' : '');
      const men = parsed.groupBoys ? String(parsed.groupBoys + 1) : parsed.task || soloScenes.has(parsed.scene) ? '0' : '1';
      const checks = [
        ['situation', situation], ['outfit', parsed.outfit], ['room', room], ['mood', ImageStudio_이미지기분읽기(talentId, parsed) || 'default'],
        ['men', men], ['exposure', parsed.exposure || 'none'], ['aftermath', parsed.aftermath || 'none'], ['variant', String(parsed.variant || 0)],
      ];
      if (checks.some(([axis, value]) => !setOf(selected, axis).has(String(value)))) return false;
      return !parsed.groupSlots || setOf(selected, 'roles').has(parsed.groupSlots);
    }
    
    function groupsForSituation(situation, kind, men, roles) {
      if (kind === 'task') return [];
      const supported = kind === 'sex'
        ? situation.startsWith('patron_') || !sceneDisallowsGroup(situation)
        : sceneFamily(situation) === 'grope';
      if (!supported) return [];
      return imageGroupSlots.filter(group => men.has(String((Number(group?.boys) || 0) + 1)) && roles.has(String(group?.slots || '')));
    }

    // Explain an empty planner result with the same constraints used by
    // ImageStudio_랜덤구성공간읽기. The review UI displays every returned item
    // below the generic error instead of making the user guess which axes clash.
    function ImageStudio_구성충돌읽기(wife, selected = {}) {
      refreshImageStudioOutfits();
      const conflicts = [];
      const add = message => { if (message && !conflicts.includes(message)) conflicts.push(message); };
      const values = axis => [...setOf(selected, axis)];
      const label = (axis, value) => imageStudioHelp.label(axis, String(value));
      const situations = values('situation');
      const outfits = values('outfit');
      const rooms = values('room');
      const men = setOf(selected, 'men');
      const roles = setOf(selected, 'roles');
      const exposures = values('exposure');
      const afters = values('aftermath');
      const variants = values('variant');
      const gagged = ImageStudio_입마개선택됨(selected);
      const archetypeId = ImageStudio_캐릭터원형ID읽기(wife);
      if (!wife || !archetypeId || !archetypeCharacter(archetypeId)) add("선택한 여성 캐릭터의 이미지 프롬프트 정의를 찾을 수 없습니다.");
      if (!situations.length) add('장면/작업을 선택하세요.');
      if (!outfits.length) add('의상을 선택하세요.');
      if (!rooms.length) add('장소를 선택하세요.');
      if (gagged) {
        for (const role of roles) if (role.includes('m')) add(`입마개 착용 상태에서는 남성별 역할 조합 “${label('roles', role)}”의 입 배치를 사용할 수 없습니다.`);
        for (const position of values('promptPosition')) if (ImageStudio_입사용자세.has(position)) add(`입마개 착용 상태에서는 입을 사용하는 자세 “${position}”를 사용할 수 없습니다.`);
      }

      for (const situation of situations) {
        const situationLabel = label('situation', situation);
        const kind = imageTasks.includes(situation) ? 'task' : imageEscalations.includes(situation) ? 'escalation' : imageSexScenes.includes(situation) ? 'sex' : null;
        if (!kind) {
          add(`장면/작업 “${situationLabel}”은 현재 게임의 이미지 장면 목록에 없습니다.`);
          continue;
        }
        if (gagged && ImageStudio_입사용장면.has(situation)) add(`입마개 착용 상태에서는 그녀가 입을 사용하는 “${situationLabel}” 장면을 생성할 수 없습니다.`);
        const bath = situation === 'bathing' || situation.startsWith('bath_');
        for (const rawRoom of rooms) {
          const { room, abed } = roomSpec(rawRoom);
          const roomLabel = label('room', rawRoom);
          if (bath && room !== 'bathhouse') add(`목욕 장면 “${situationLabel}”은 장소를 “목욕탕”으로 선택해야 합니다. 현재 장소: “${roomLabel}”.`);
          if (!bath && room === 'bathhouse') add(`장면 “${situationLabel}”은 목욕 장면이 아니어서 장소 “목욕탕”과 함께 사용할 수 없습니다.`);
          if (abed && (room !== 'bedroom' || !situation.startsWith('patron_'))) add(`장소 “침실 · 침대 위”는 손님 장면(patron)에서만 사용할 수 있습니다. 현재 장면: “${situationLabel}”.`);
        }
        for (const outfit of outfits) {
          const definition = outfitDef(outfit);
          const outfitLabel = label('outfit', outfit);
          if (!definition) add(`의상 “${outfitLabel}”의 게임 의상 정의를 찾을 수 없습니다.`);
          else if (bath && definition.wear !== 'bath') add(`목욕 장면 “${situationLabel}”에는 목욕 전용 의상이 필요합니다. 현재 의상 “${outfitLabel}”은 일반 의상입니다.`);
          else if (!bath && definition.wear === 'bath') add(`목욕 전용 의상 “${outfitLabel}”은 장면 “${situationLabel}”에서 사용할 수 없습니다.`);
          for (const rawRoom of rooms) if (!sleepwearCombinationAllowed(situation, outfit, roomSpec(rawRoom).room)) {
            add(`잠옷 “${outfitLabel}”은 깨어 있는 상태로 장소 “${label('room', rawRoom)}”에서 입을 수 없습니다. 원본 게임은 이곳으로 이동할 때 근무복으로 자동 환복합니다. 침실을 선택하거나 의상을 바꾸세요. 수면·실신 장면은 예외입니다.`);
          }
        }

        const validExposures = new Set(['none', ...(kind === 'task' ? imageTaskExposures : kind === 'escalation' ? imageEscalationExposures : imageSexExposures).map(exposureKey)]);
        for (const exposure of exposures) if (!validExposures.has(exposure)) {
          add(`노출 상태 “${label('exposure', exposure)}”은 장면 “${situationLabel}”에서 지원되지 않습니다.`);
        }

        const baseMen = kind === 'task' || soloScenes.has(situation) ? '0' : '1';
        const includeBase = men.has(baseMen);
        const groups = groupsForSituation(situation, kind, men, roles);
        if (!includeBase && !groups.length) {
          const selectedMen = [...men].map(value => label('men', value)).join(', ') || '선택 없음';
          const requestedGroup = [...men].some(value => Number(value) > 1);
          const groupSupported = kind === 'sex'
            ? situation.startsWith('patron_') || !sceneDisallowsGroup(situation)
            : kind === 'escalation' && sceneFamily(situation) === 'grope';
          const groupCounts = imageGroupSlots.filter(group => men.has(String((Number(group?.boys) || 0) + 1)));
          if (requestedGroup && !groupSupported) add(`장면 “${situationLabel}”은 여러 남성이 등장하는 그룹 구성을 지원하지 않습니다. 현재 남성 수: ${selectedMen}.`);
          else if (requestedGroup && !groupCounts.length) add(`현재 남성 수(${selectedMen})에 해당하는 그룹 역할 조합이 게임에 없습니다.`);
          else if (requestedGroup) add(`현재 남성 수(${selectedMen})와 선택한 남성별 역할 조합이 서로 맞지 않습니다.`);
          else add(`장면 “${situationLabel}”의 기본 남성 수는 ${label('men', baseMen)}입니다. 현재 선택: ${selectedMen}.`);
        }

        const validAfters = new Set(unique(imageAfters.map(value => value || 'none')));
        if (kind === 'task') {
          for (const aftermath of afters) if (!validAfters.has(aftermath)) add(`사후 상태 “${label('aftermath', aftermath)}”은 일상 작업 이미지에서 지원되지 않습니다.`);
        } else {
          for (const aftermath of afters) if (aftermath !== 'none') add(`사후 상태 “${label('aftermath', aftermath)}”은 일상 작업 이미지 전용이라 장면 “${situationLabel}”과 함께 사용할 수 없습니다.`);
        }
        for (const variant of variants) {
          if (!Number.isFinite(Number(variant))) add(`구도 변형 “${variant}”은 올바른 숫자가 아닙니다.`);
          else if (kind === 'task' && Number(variant) !== 0) add(`일상 작업 “${situationLabel}”은 기본 구도(v-0)만 지원합니다. 현재 선택: ${label('variant', variant)}.`);
        }
      }
      return conflicts;
    }
    
    function appendStudioImage(target, template, archetypeId, options, selected = {}, combinations = null) {
      const before = target.size;
      const prompt = globalThis.WW_ImageStudioPrompt;
      const additionalMood = ADDITIONAL_MOOD_PROMPTS[options?.mood] ? options.mood : null;
      const nativeOptions = additionalMood ? { ...options, mood: undefined } : options;
      if (prompt?.plan) {
        for (const combination of combinations || prompt.combinations(selected)) {
          if (ImageStudio_입마개와충돌하는가(options, combination)) continue;
          const items = prompt.plan(() => { const temporary = new Map(); appendImagePlan(temporary, template, nativeOptions, archetypeId); return [...temporary.values()]; },combination,archetypeId);
          for (const source of items) {
            if (ImageStudio_입마개와충돌하는가(options, combination, source?.ImageStudioGagged === true)) continue;
            const { ImageStudioGagged, ...cleanSource } = source;
            const item = additionalMood ? ImageStudio_추가기분결과적용하기(cleanSource, additionalMood) : cleanSource;
            target.set(item.talentId,item);
          }
        }
      } else if (additionalMood) {
        const temporary = new Map(); appendImagePlan(temporary, template, nativeOptions, archetypeId);
        for (const source of temporary.values()) {
          const item = ImageStudio_추가기분결과적용하기(source, additionalMood);
          target.set(item.talentId,item);
        }
      } else appendImagePlan(target, template, nativeOptions, archetypeId);
      if (target.size > 120000) throw new Error('생성 후보가 120,000장을 넘었습니다. 상황·의상·노출 조건을 더 좁혀 주세요.');
      return target.size > before;
    }
    
    // 프롬프트를 만들지 않고 유효한 기본 구성의 크기와 인덱스만 보관합니다.
    function ImageStudio_랜덤구성공간읽기(wife, selected = {}, sourceKeys = null) {
      refreshImageStudioOutfits();
      const archetypeId = ImageStudio_캐릭터원형ID읽기(wife);
      if (!archetypeId) return { count: 0n, error: '캐릭터 정의 없음', at() { throw new RangeError('캐릭터 정의 없음'); }, build() { return []; } };
      const template = archetypeCharacter(archetypeId);
      const blocks = [];
      let count = 0n;
      if (sourceKeys) {
        // 예전 exp 표기만 다른 원본 구성은 한 번만 추첨합니다. 실제 이미지 파일과 팩 항목은 변경하지 않습니다.
        for (const key of new Set(sourceKeys.map(ImageStudio_노출키정규화하기))) {
          const parsed = parseImageKey(key);
          if (!parsed?.outfit || !parsed.room || (!parsed.scene && !parsed.task)) continue;
          if (!sleepwearCombinationAllowed(parsed.scene || parsed.task, parsed.outfit, parsed.room)) continue;
          const group = parsed.groupBoys && parsed.groupSlots
            ? imageGroupSlots.find(item => Number(item.boys) === parsed.groupBoys && item.slots === parsed.groupSlots) || {boys:parsed.groupBoys,slots:parsed.groupSlots}
            : undefined;
          blocks.push({ end: ++count, options: {
            outfit:parsed.outfit,room:parsed.room,mood:ImageStudio_이미지기분읽기(key, parsed),exposure:exposureObject(parsed.exposure),
            aftermath:parsed.aftermath,finish:parsed.finishOutfit,variant:parsed.variant || 0,abed:parsed.abed,group,
            ...(parsed.scene ? parsed.scene.startsWith('patron_') ? {patronScene:parsed.scene} : {scene:parsed.scene} : {task:parsed.task}),
          } });
        }
      } else {
        const axes = imageStudioAxes(), all = axis => axes[axis].map(entry => String(entry.value));
        const situations = setOf(selected,'situation',all('situation')), outfits = setOf(selected,'outfit',all('outfit'));
        const rooms = [...setOf(selected,'room',all('room'))].map(roomSpec);
        const moods = [...setOf(selected,'mood',all('mood'))].map(value => value === 'default' ? undefined : value);
        const men = setOf(selected,'men',all('men')), roles = setOf(selected,'roles',all('roles'));
        const exposures = setOf(selected,'exposure',all('exposure')), afters = setOf(selected,'aftermath',all('aftermath'));
        const variants = [...setOf(selected,'variant',all('variant'))].map(Number).filter(Number.isFinite);
        for (const situation of situations) {
          const kind = imageTasks.includes(situation) ? 'task' : imageEscalations.includes(situation) ? 'escalation' : imageSexScenes.includes(situation) ? 'sex' : null;
          if (!kind) continue;
          const bath = situation === 'bathing' || situation.startsWith('bath_');
          const validExposures = new Set(['none',...(kind === 'task' ? imageTaskExposures : kind === 'escalation' ? imageEscalationExposures : imageSexExposures).map(exposureKey)]);
          const exposureValues = [...exposures].filter(value => validExposures.has(value));
          const baseMen = kind === 'task' || soloScenes.has(situation) ? '0' : '1', includeBase = men.has(baseMen);
          const groups = groupsForSituation(situation,kind,men,roles);
          const sceneVariants = kind !== 'task' ? variants : variants.includes(0) ? [0] : [];
          const arrangements = kind === 'task'
            ? includeBase ? [...afters].filter(value => unique(imageAfters.map(item => item || 'none')).includes(value)).map(value => ({aftermath:value === 'none' ? undefined : value})) : []
            : afters.has('none') ? [
              ...(includeBase ? (kind === 'sex' && finishScenes.has(situation) ? finishOutfits : [undefined]).map(finish => ({finish})) : []),
              ...groups.map(group => ({group})),
            ] : [];
          const dimensions = [moods,exposureValues,sceneVariants,arrangements];
          const size = dimensions.reduce((product, values) => product * BigInt(values.length), 1n);
          if (!size) continue;
          for (const {room,abed} of rooms) {
            if (bath !== (room === 'bathhouse') || abed && (room !== 'bedroom' || !situation.startsWith('patron_'))) continue;
            for (const outfit of outfits) {
              if (bath !== (outfitDef(outfit)?.wear === 'bath')) continue;
              if (!sleepwearCombinationAllowed(situation, outfit, room)) continue;
              count += size;
              blocks.push({end:count,size,dimensions,options:{outfit,room,abed,...(kind === 'task' ? {task:situation} : situation.startsWith('patron_') ? {patronScene:situation} : {scene:situation})}});
            }
          }
        }
      }
      function ImageStudio_인덱스구성읽기(index) {
        if (index < 0n || index >= count) throw Error('랜덤 구성 인덱스가 범위를 벗어났습니다.');
        let low = 0, high = blocks.length - 1;
        while (low < high) { const middle = (low + high) >>> 1; if (index < blocks[middle].end) high = middle; else low = middle + 1; }
        const block = blocks[low];
        if (!block.dimensions) return block.options;
        let offset = index - (low ? blocks[low - 1].end : 0n);
        const values = [];
        for (let axis = block.dimensions.length - 1; axis >= 0; axis--) {
          const choices = block.dimensions[axis], size = BigInt(choices.length);
          values[axis] = choices[Number(offset % size)]; offset /= size;
        }
        return {...block.options,mood:values[0],exposure:exposureObject(values[1]),variant:values[2],...values[3]};
      }
      return { count, at:ImageStudio_인덱스구성읽기, build(index, combination) {
        imagePlanner({kinds:[],maxEntries:1});
        const output = new Map();
        appendStudioImage(output,template,archetypeId,ImageStudio_인덱스구성읽기(index),selected,[combination]);
        return [...output.values()].filter(item => matchesImageStudioSelection(item.ImageStudioBaseKey || item.talentId,selected));
      } };
    }

    async function listStudioImages(wife, selected = {}, progress = () => {}, signal) {
      const checkCancelled = () => { if (signal?.aborted) throw new DOMException('조합 계산을 취소했습니다.', 'AbortError'); };
      checkCancelled();
      refreshImageStudioOutfits();
      // Clear the native planner's module-scoped scene/key-only switches before
      // calling its single-entry builder directly.
      imagePlanner({ kinds: [], maxEntries: 1 });
      const axes = imageStudioAxes();
      const all = axis => axes[axis].map(entry => String(entry.value));
      const situations = setOf(selected, 'situation', all('situation'));
      const outfits = setOf(selected, 'outfit', all('outfit'));
      const rooms = [...setOf(selected, 'room', all('room'))].map(roomSpec);
      const moods = [...setOf(selected, 'mood', all('mood'))].map(value => value === 'default' ? undefined : value);
      const men = setOf(selected, 'men', all('men'));
      const roles = setOf(selected, 'roles', all('roles'));
      const exposures = setOf(selected, 'exposure', all('exposure'));
      const afters = setOf(selected, 'aftermath', all('aftermath'));
      const variants = [...setOf(selected, 'variant', all('variant'))].map(Number).filter(Number.isFinite);
      const detailSpace = globalThis.WW_ImageStudioPrompt?.combinationSpace?.(selected);
      const combinations = detailSpace ? null : globalThis.WW_ImageStudioPrompt?.combinations?.(selected);
      const detailCount = detailSpace?.count ?? BigInt(combinations?.length || 1);
      if (detailCount > 120000n) throw new Error('세부 조건 조합이 120,000개를 넘었습니다. 선택을 줄여 주세요.');
      const archetypeId = ImageStudio_캐릭터원형ID읽기(wife);
      if (!archetypeId) return [];
      const template = archetypeCharacter(archetypeId);
      const output = new Map();
      let situationIndex = 0;
      let processed = 0;
      const total = ImageStudio_랜덤구성공간읽기(wife, selected).count * detailCount;
      const report = () => progress({ current: processed, total: total.toString(), candidates: output.size });
      report();
      const checkpoint = ImageStudio_계산묶음만들기(report, signal);
      async function append(options) {
        for (let detailIndex = 0n; detailIndex < detailCount; detailIndex++) {
          checkCancelled();
          const combination = detailSpace ? detailSpace.at(detailIndex) : combinations?.[Number(detailIndex)] || null;
          appendStudioImage(output, template, archetypeId, options, selected, combination ? [combination] : null);
          const pause = checkpoint(++processed);
          if (pause) await pause;
        }
      }
    
      for (const situation of situations) {
        checkCancelled();
        const kind = imageTasks.includes(situation) ? 'task' : imageEscalations.includes(situation) ? 'escalation' : imageSexScenes.includes(situation) ? 'sex' : null;
        if (!kind) continue;
        const bath = situation === 'bathing' || situation.startsWith('bath_');
        const validExposures = new Set(['none', ...(kind === 'task' ? imageTaskExposures : kind === 'escalation' ? imageEscalationExposures : imageSexExposures).map(exposureKey)]);
        const exposureValues = [...exposures].filter(value => validExposures.has(value));
        const baseMen = kind === 'task' || soloScenes.has(situation) ? '0' : '1';
        const includeBase = men.has(baseMen);
        const groups = groupsForSituation(situation, kind, men, roles);
        const sceneVariants = kind !== 'task' ? variants : variants.includes(0) ? [0] : [];
        const aftermathValues = kind === 'task' ? [...afters].filter(value => unique(imageAfters.map(item => item || 'none')).includes(value)) : afters.has('none') ? [undefined] : [];
        const finishes = kind === 'sex' && finishScenes.has(situation) ? finishOutfits : [undefined];
    
        for (const { room, abed } of rooms) {
          if (bath !== (room === 'bathhouse')) continue;
          if (abed && (room !== 'bedroom' || !situation.startsWith('patron_'))) continue;
          for (const outfit of outfits) {
            const definition = outfitDef(outfit);
            if (bath !== (definition?.wear === 'bath')) continue;
            if (!sleepwearCombinationAllowed(situation, outfit, room)) continue;
            for (const mood of moods) for (const exposure of exposureValues) for (const variant of sceneVariants) {
              const common = { outfit, room, mood, exposure: exposureObject(exposure), variant, abed };
              if (kind === 'task') {
                if (!includeBase) continue;
                for (const aftermath of aftermathValues) await append({ ...common, task: situation, aftermath: aftermath === 'none' ? undefined : aftermath });
                continue;
              }
              const scenePart = situation.startsWith('patron_') ? { patronScene: situation } : { scene: situation };
              if (includeBase) for (const finish of finishes) await append({ ...common, ...scenePart, finish });
              for (const group of groups) await append({ ...common, ...scenePart, group, variant });
            }
          }
        }
        if (++situationIndex % 2 === 0) await G('d3')();
      }
      report();
      checkCancelled();
      return [...output.values()].filter(item => matchesImageStudioSelection(item.ImageStudioBaseKey || item.talentId, selected));
    }
    
    function imageFromKey(wife, talentId, selected = {}, all = false, combination = null) {
      const parsed = parseImageKey(talentId);
      if (!parsed || !parsed.outfit || !parsed.room || (!parsed.scene && !parsed.task)) return null;
      imagePlanner({ kinds: [], maxEntries: 1 });
      const archetypeId = ImageStudio_캐릭터원형ID읽기(wife);
      if (!archetypeId) return all ? [] : null;
      const template = archetypeCharacter(archetypeId);
      const group = parsed.groupBoys && parsed.groupSlots
        ? imageGroupSlots.find(item => Number(item.boys) === parsed.groupBoys && item.slots === parsed.groupSlots) || { boys: parsed.groupBoys, slots: parsed.groupSlots }
        : undefined;
      const options = {
        outfit: parsed.outfit, room: parsed.room, mood: ImageStudio_이미지기분읽기(talentId, parsed), exposure: exposureObject(parsed.exposure),
        aftermath: parsed.aftermath, finish: parsed.finishOutfit, variant: parsed.variant || 0, abed: parsed.abed, group,
        ...(parsed.scene ? (parsed.scene.startsWith('patron_') ? { patronScene: parsed.scene } : { scene: parsed.scene }) : { task: parsed.task }),
      };
      const result = new Map();
      appendStudioImage(result, template, archetypeId, options, selected, combination ? [combination] : null);
      return all ? [...result.values()] : [...result.values()][0] || null;
    }
    
    function imageStudioKeyAxes(talentId) {
      const parsed = parseImageKey(talentId);
      if (!parsed) return null;
      const solo = parsed.kind === 'task' || soloScenes.has(parsed.scene);
      return {
        character: parsed.character,
        characterId: parsed.characterId || 'none',
        kind: parsed.kind,
        situation: parsed.scene || parsed.task || parsed.lookFocus || 'none',
        lookReaction: parsed.lookReaction || 'none',
        outfit: parsed.outfit,
        room: parsed.room + (parsed.abed ? ' (침대 위)' : ''),
        mood: ImageStudio_이미지기분읽기(talentId, parsed) || 'default',
        men: parsed.groupBoys ? String(parsed.groupBoys + 1) : solo ? '0' : '1',
        roles: parsed.groupSlots || 'none',
        exposure: parsed.exposure || 'none',
        aftermath: parsed.aftermath || 'none',
        variant: String(parsed.variant || 0),
        finish: parsed.finishOutfit || 'none',
        promptSignature: String(talentId).split('__').filter(part => /^(?:position|state|dialogue|character|studio)-/.test(part)).join('__'),
      };
    }
    
    function imageStudioIdentity(talentId, includePromptSignature = true) {
      const axes = imageStudioKeyAxes(talentId);
      if (!axes) return `raw\u001f${talentId}`;
      return [
        axes.character, axes.characterId, axes.kind, axes.situation, axes.lookReaction,
        axes.outfit, axes.room, axes.mood, axes.men, axes.roles, axes.exposure,
        axes.aftermath, axes.variant, axes.finish,
        ...(includePromptSignature ? [axes.promptSignature] : []),
      ].join('\u001f');
    }
    
    // Per-HTTP-request size, NOT a queue capacity. 20,000 items use 80 chunks.
    const STUDIO_QUEUE_CHUNK = 250;
    const waitForQueueRetry = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));
    async function enqueueStudioImages(items, progress = () => {}) {
      if (!Array.isArray(items) || !items.length) return { accepted: 0, alreadyCached: 0, alreadyQueued: 0, jobId: null };
      const endpoint = imageServerUrl('/api/batch/enqueue');
      if (!endpoint) throw new Error('이미지 생성 서버에 연결되어 있지 않습니다.');
      // Old servers replaced the entire queue per chunk. Check before the first
      // write so a not-yet-restarted server cannot lose ongoing generation work.
      const statusResponse = await fetch(imageServerUrl('/api/batch/status'), { credentials: 'omit' });
      const status = await statusResponse.json().catch(() => ({}));
      if (!statusResponse.ok) throw new Error(status.error || '이미지 서버의 대기열 상태를 확인할 수 없습니다.');
      if (status.enqueueMode !== 'append') throw new Error('이미지 서버 업데이트 적용이 필요합니다. 생성 중인 작업이 있다면 완료 후 서버 창을 닫고 Start_ImageStudio.cmd로 다시 시작해 주세요. 구버전 서버는 250개씩 받을 때 기존 대기열을 덮어씁니다.');
      let jobId = `studio-${new Date().toISOString().replace(/[:.]/g, '-')}-${globalThis.crypto?.randomUUID?.() || Math.random().toString(36).slice(2)}`;
      const chunks = Math.ceil(items.length / STUDIO_QUEUE_CHUNK);
      let accepted = 0, alreadyCached = 0, alreadyQueued = 0;
      for (let offset = 0, chunk = 1; offset < items.length; offset += STUDIO_QUEUE_CHUNK, chunk++) {
        const slice = items.slice(offset, offset + STUDIO_QUEUE_CHUNK);
        const payload = JSON.stringify({ items: slice, jobId, start: offset + slice.length >= items.length });
        let response = null, failure = null;
        for (let attempt = 1; attempt <= 3; attempt++) {
          try {
            response = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'omit', body: payload });
            failure = null;
            break;
          } catch (error) {
            failure = error;
            if (attempt < 3) await waitForQueueRetry(attempt * 250);
          }
        }
        if (!response) throw new Error(`이미지 대기열 ${chunk}/${chunks} 전송에 실패했습니다. 서버 연결과 Start_ImageStudio 창을 확인해 주세요. (${failure?.message || '네트워크 오류'})`);
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(body.error || `이미지 서버가 대기열 ${chunk}/${chunks} 등록을 거부했습니다 (HTTP ${response.status})`);
        if (body.jobId) jobId = body.jobId;
        accepted += Number(body.accepted) || 0;
        alreadyCached += Number(body.alreadyCached) || 0;
        alreadyQueued += Number(body.alreadyQueued) || 0;
        progress({ sent: Math.min(offset + slice.length, items.length), total: items.length, chunk, chunks, accepted, alreadyCached, alreadyQueued });
      }
      return { accepted, alreadyCached, alreadyQueued, jobId };
    }

    let ImageStudio_생성상태캐시 = { at: 0, unavailable: false };
    async function ImageStudio_생성불가확인하기() {
      if (offline()) return true;
      if (globalThis.WW_ImageStudio?.isBusy?.() || globalThis.WW_ImageStudioPrompt?.isBusy?.()) return true;
      const connection = G('ph')();
      if (!connection?.baseUrl || connection.comfyui !== true) return true;
      const now = Date.now();
      if (now - ImageStudio_생성상태캐시.at < 1000) return ImageStudio_생성상태캐시.unavailable;
      try {
        const response = await fetch(imageServerUrl('/api/batch/status'), {
          credentials: 'omit', signal: globalThis.AbortSignal?.timeout?.(2000),
        });
        const status = await response.json().catch(() => ({}));
        const unavailable = !response.ok || status.running === true || (Number(status.total) > Number(status.done) && status.paused !== true);
        ImageStudio_생성상태캐시 = { at: now, unavailable };
        return unavailable;
      } catch {
        ImageStudio_생성상태캐시 = { at: now, unavailable: true };
        return true;
      }
    }
    
    globalThis.WW_ImageStudioBridge = {
      characters: imageStudio_collectWives,
      wives: () => G('Zl') || [],
      ready: () => G('cb')(),
      packs: () => globalThis.__WAYWARD_IMAGE_PACKS__ || [],
      currentWife: () => {
        try {
          const state = G('re').getState().state;
          const wife = state.characters[state.primaryCharacterId];
          return wife.shortname || (wife.archetypeId && wife.archetypeId.split('_')[0]) || null;
        } catch { return null; }
      },
      connection: (...a) => G('ph')(...a),
      setOfflineOnly: value => { globalThis.__WW_STUDIO_OFFLINE_ONLY__ = !!value; G('ND')(); },
      setOutfitLock,
      openRandom: wife => {
        const mount = document.createElement('div');
        document.body.append(mount);
        const root = G('i9').createRoot(mount);
        const close = () => { root.unmount(); mount.remove(); };
        root.render(G('u').jsx(G('gPe'), { onClose: close, initialWife: wife }));
      },
      axes: imageStudioAxes,
      collectPromptDefaults: ImageStudio_기본프롬프트수집하기,
      promptDefaultsStatus: ImageStudio_기본프롬프트상태읽기,
      fromKey: imageFromKey,
      keyAxes: imageStudioKeyAxes,
      identity: imageStudioIdentity,
      enqueue: enqueueStudioImages,
      generationUnavailable: ImageStudio_생성불가확인하기,
      weight: (...a) => G('iPe')(...a),
      list: listStudioImages,
      randomSpace: ImageStudio_랜덤구성공간읽기,
      idOrigin: ImageStudio_조건ID출처읽기,
      selectionConflicts: ImageStudio_구성충돌읽기,
    };
    const extensions = ImageStudio_확장등록창구만들기(api);
    globalThis.WW_ImageStudioBridge.extensions = extensions;
    api.provide({ version: 1, extensions, bridge: globalThis.WW_ImageStudioBridge });
    Object.assign(globalThis.WW_ImageStudioBridge, ImageStudio_HStatus연결만들기(api, globalThis.WW_ImageStudioBridge));
    // ---- 원본 애드온 ----
/* Wayward Image Studio — game-aware conditional planner for wayward-imagegen. */
(function () {
  'use strict';
  if (window.WW_ImageStudio) return;

  const names = {
    elena: '엘레나', mara: '마라', pippa: '피파',
    ...Object.fromEntries((window.__WAYWARD_WIFE_ADDONS__ || []).map(wife => [wife.shortname, wife.name])),
  };
  const axisDefs = [
    ['character', '인물'], ['situation', '장면/작업'], ['outfit', '의상'], ['room', '장소'],
    ['mood', '기분'], ['men', '화면의 전체 남성 수'], ['roles', '추가 남성별 역할 조합'],
    ['exposure', '노출 상태 / exp 키'], ['aftermath', '사후 상태'], ['variant', '구도 변형'],
  ];
  const situationGroupDefs = [
    ['daily', '일상'],
    ['contact_husband', "성적 접촉 (애무까지) · 당신"],
    ['contact_patron', '성적 접촉 (애무까지) · 손님'],
    ['contact_solo', '성적 접촉 (애무까지) · 혼자/기타'],
    ['sex_husband', "성행위 (성기를 꺼내서 하는 행위) · 당신"],
    ['sex_patron', '성행위 (성기를 꺼내서 하는 행위) · 손님'],
    ['sex_solo', '성행위 (성기를 꺼내서 하는 행위) · 혼자/기타'],
    ['climax_husband', "절정 (사정 장면) · 당신"],
    ['climax_patron', '절정 (사정 장면) · 손님'],
    ['climax_solo', '절정 (사정 장면) · 혼자/기타'],
    ['other', '기타'],
  ];
  const dailySituations = new Set([
    'idle', 'greeting', 'taking_order', 'serving', 'cleaning', 'cooking', 'passed_out', 'bathing',
    'resting', 'sleeping', 'at_market', 'composing', 'away', 'bath_solo', 'bath_attendant',
    'patron_chatting', 'patron_flirting',
  ]);
  const contactSituations = new Set([
    'kissing', 'groped_ass', 'groped_tits', 'bath_attendant_wash_chest', 'bath_attendant_wash_body',
    'bath_with_patron', 'patron_touching', 'patron_bold', 'patron_groping', 'patron_groping_lap',
    'patron_intimate', 'patron_intimate_lap', 'fingered', 'grinding', 'lap_dance', 'mutual_touching',
    'breast_worship', 'anal_fingering', 'patron_grinding', 'patron_lap_dance',
    'patron_mutual_touching', 'patron_breast_worship',
  ]);
  const sexSituations = new Set([
    'self_pleasure', 'bath_attendant_handjob', 'handjob', 'blowjob', 'titfuck', 'sex', 'sex_rough',
    'anal', 'clean_with_mouth', 'patron_handjob', 'patron_blowjob', 'patron_sex', 'patron_rubbing',
    'thigh_job', 'deepthroat', 'cunnilingus', 'face_sitting', 'sixty_nine', 'riding', 'standing_sex',
    'patron_thigh_job', 'patron_deepthroat', 'patron_cunnilingus', 'patron_self_stroke',
    'patron_titfuck', 'patron_riding', 'patron_standing_sex', 'patron_anal',
  ]);
  const climaxSituations = new Set([
    'facial', 'finish_on_stomach', 'finish_on_chest', 'finish_on_back', 'cum_in_mouth',
    'patron_rubbing_finish', 'patron_rubbing_climax', 'patron_facial', 'patron_handjob_finish',
    'patron_handjob_climax', 'patron_blowjob_climax', 'patron_sex_climax', 'patron_anal_climax',
    'patron_anal_finish', 'patron_anal_finish_pullout', 'patron_sex_finish',
    'patron_sex_finish_pullout', 'patron_blowjob_swallow',
  ]);
  function situationGroup(value, kind) {
    value = String(value);
    if (kind === 'task' || dailySituations.has(value)) return 'daily';
    const stage = climaxSituations.has(value) ? 'climax'
      : contactSituations.has(value) || value.startsWith('patron_moment_') ? 'contact'
      : sexSituations.has(value) ? 'sex' : '';
    if (!stage) return 'other';
    const partner = value.startsWith('patron_') || value === 'bath_with_patron' || value.startsWith('bath_attendant') ? 'patron'
      : value === 'self_pleasure' || value === 'bath_solo' ? 'solo' : 'husband';
    return `${stage}_${partner}`;
  }
  const moodLabels = { default: '기본 표정', smile: '미소', shy: '수줍음', scared: '두려움', worried: '걱정' };
  const exposureFields = ['상의 끈 풀림', '상의 내림', '상의 제거', '치마 올림', '치마 제거', '속옷 옆으로', '속옷 제거'];
  const roleLabels = { m: '입', h: '손', b: '가슴', x: '뒤/삽입', r: '비비기', i: '질 삽입', a: '항문 삽입', w: '지켜보기' };
  const aftermathLabels = { none: '없음', sweat: '땀/홍조', messy: '몸에 흔적', facial: '얼굴에 흔적' };

  const style = document.createElement('style');
  style.textContent = `#wwis-overlay{position:fixed;inset:0;z-index:2147483001;background:#000b;display:grid;place-items:center;font:13px/1.45 sans-serif;color:#e7e5e4}#wwis-overlay[hidden]{display:none}#wwis-panel{box-sizing:border-box;width:min(1040px,96vw);max-height:94vh;overflow:auto;background:#1c1917;border:1px solid #78716c;border-radius:12px;padding:18px}#wwis-panel button,#wwis-panel select,#wwis-panel input,#wwis-panel textarea{box-sizing:border-box;font:inherit;background:#292524;color:#e7e5e4;border:1px solid #57534e;border-radius:5px;padding:5px}#wwis-panel textarea{width:100%;min-height:64px;resize:vertical}#wwis-panel button{cursor:pointer}#wwis-panel button:hover{border-color:#f59e0b}#wwis-panel button:disabled{opacity:.5;cursor:default}#wwis-panel input[type=checkbox],#wwis-panel input[type=radio]{padding:0;accent-color:#f59e0b}.wwis-mode{display:flex;align-items:center;gap:8px;margin:12px 0 8px;padding:9px 10px;border:1px solid #57534e;border-radius:7px;cursor:pointer}.wwis-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:8px 0}.wwis-random-enqueue{display:inline-flex;align-items:center;gap:6px;flex-wrap:wrap}.wwis-random-enqueue label{display:inline-flex;align-items:center;gap:4px}.wwis-random-enqueue input{width:68px}.wwis-card{border:1px solid #44403c;border-radius:7px;padding:10px;margin:10px 0}.wwis-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:5px;max-height:210px;overflow:auto}.wwis-grid label{display:flex;gap:5px;align-items:flex-start}.wwis-dim{color:#a8a29e;font-size:12px}.wwis-counts{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}.wwis-counts div{min-width:0;overflow-wrap:anywhere}.wwis-audit-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:5px 12px;margin-top:8px}.wwis-audit-grid div{min-width:0;overflow-wrap:anywhere}#wwis-panel h2{margin:0;color:#fbbf24;font-size:20px}#wwis-panel h3{margin:0 0 6px;font-size:14px}.wwis-axis-actions{display:inline-flex;gap:5px;margin-left:8px}.wwis-axis-actions button{font-size:11px;padding:2px 5px}.wwis-source{padding:10px;background:#0c0a09;border:1px solid #57534e;border-radius:7px}.wwis-situation-groups{display:grid;gap:8px;margin-top:8px}.wwis-situation-group{border:1px solid #44403c;border-radius:6px;padding:8px;background:#0c0a0955}.wwis-situation-group-head{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:6px}.wwis-situation-group-head strong{color:#fbbf24}.wwis-situation-group-head button{font-size:11px;padding:2px 5px}.wwis-situation-group .wwis-grid{max-height:180px}.wwis-settings-launch{width:100%;padding:10px!important;border-color:#a16207!important;background:#33240f!important;font-weight:700}.wwis-settings-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px 12px}.wwis-settings-grid label{display:grid;gap:4px}.wwis-settings-grid .wwis-wide{grid-column:1/-1}.wwis-engine-choice{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.wwis-engine-choice label{padding:10px;border:1px solid #57534e;border-radius:7px;background:#211e1b}.wwis-character-row,.wwis-lora-row{padding:9px;border:1px solid #44403c;border-radius:7px;margin:7px 0;background:#151312}.wwis-character-head,.wwis-lora-row{display:flex;align-items:center;gap:7px;flex-wrap:wrap}.wwis-character-head input[data-field=name]{flex:1}.wwis-character-row textarea{margin-top:6px}.wwis-setting-status{padding:8px 10px;border-left:3px solid #a16207;background:#0c0a09}@media(max-width:760px){.wwis-settings-grid,.wwis-engine-choice{grid-template-columns:1fr}.wwis-settings-grid .wwis-wide{grid-column:auto}}`;
  // Suppress the same shortcut when the standalone prompt mod is also active.
  style.textContent += '\n.wwis-task-progress{margin:10px 0;padding:12px;border:1px solid #a16207;border-radius:7px;background:#211b10;overflow-wrap:anywhere}.wwis-task-progress progress{display:block;width:100%;height:18px;margin:7px 0;accent-color:#fbbf24}.wwis-task-progress[data-status=error]{border-color:#ef4444}.wwis-task-progress[data-status=done]{border-color:#4d7c0f}';
  style.textContent += '\n.wwis-generation-toolbar{position:sticky;top:0;z-index:2;padding:8px 0;background:#1c1917}.wwis-generation-toolbar [data-dirty=true]{color:#fbbf24}.wwis-unsaved-prompt{position:absolute;inset:0;display:grid;place-items:center;padding:12px;background:#0009;z-index:3}.wwis-unsaved-prompt section{box-sizing:border-box;width:min(480px,100%);padding:18px;border:1px solid #a16207;border-radius:10px;background:#1c1917;color:#e7e5e4}.wwis-unsaved-prompt p{line-height:1.5}';
  style.textContent += '\n.wwis-unsaved-prompt button{font:inherit;cursor:pointer;padding:8px 10px;border:1px solid #78716c;border-radius:5px;background:#292524;color:#e7e5e4}.wwis-unsaved-prompt button:hover,.wwis-unsaved-prompt button:focus-visible{outline:2px solid #fbbf24;outline-offset:2px}.wwis-unsaved-prompt #wwis-unsaved-save{background:#78350f;border-color:#b45309}';

  document.head.append(style);

  const overlay = document.createElement('div');
  overlay.id = 'wwis-overlay';
  overlay.hidden = true;
  overlay.innerHTML = `<div id="wwis-panel"><div class="wwis-row" style="justify-content:space-between"><h2>이미지 스튜디오</h2><button id="wwis-close">닫기</button></div><label class="wwis-mode"><input id="wwis-offline-only" type="checkbox">게임 플레이 중 오프라인 이미지팩만 사용 (자동 이미지 생성 끔)</label><label class="wwis-mode" title="디버깅용: 자발적 평상복 선택·환복만 일시 중단합니다. 당신이 지시해 수락한 환복과 옷가게 시착은 허용하며, 목욕·취침용 환복은 기존대로 진행합니다."><input id="wwis-lock-wife-outfit" type="checkbox">그녀가 자발적으로 옷을 갈아입지 못하게</label><div id="wwis-content"></div></div>`;
  document.body.append(overlay);

  const content = overlay.querySelector('#wwis-content');
  const state = { wife: '', catalogue: [], catalogueVerified: false, catalogueWarning: '', selected: {}, options: {}, conditionalOpen: false, hStatusOpen: false, cloneSource: '', duplicateMode: 'composition', busy: false, message: '', lastPlan: null, randomCount: 10, packResults: {}, packBusy: new Set(), discoverBusy: false, discoveryMessage: '' };
  const bridge = () => window.WW_ImageStudioBridge;
  const hStatusSelections = {};
  const taskProgress = ImageStudio_진행표시만들기(content, overlay);
  let cacheBusy = false, cacheMessage = '';
  let generationSettingsEditor = null, generationSettingsLoad = null;

  // 생성 방식 설정은 명시적으로 저장합니다. 다른 화면의 자동 갱신이 편집 내용을 덮지 않게 합니다.
  function ImageStudio_생성설정종료하기() {
    generationSettingsLoad = null;
    const editor = generationSettingsEditor;
    generationSettingsEditor = null;
    editor?.observer.disconnect();
    editor?.prompt?.remove();
    overlay.querySelector('#wwis-panel').inert = false;
    content.inert = false;
    // 취소한 토큰을 포함한 입력값은 닫힌 화면의 DOM에도 남기지 않습니다.
    if (editor) content.replaceChildren();
  }

  // 닫기·배경·뒤로 가기를 같은 확인 창으로 처리합니다. 저장 실패 시 화면과 입력값을 유지합니다.
  function ImageStudio_생성설정나가기(onLeave) {
    const editor = generationSettingsEditor;
    if (editor?.saving) {
      editor.update();
      return;
    }
    if (!editor?.dirty()) {
      ImageStudio_생성설정종료하기();
      onLeave();
      return;
    }
    if (editor.prompt) return;
    const previousFocus = document.activeElement;
    const prompt = document.createElement('div');
    prompt.id = 'wwis-unsaved-prompt';
    prompt.className = 'wwis-unsaved-prompt';
    prompt.innerHTML = `<section role="alert" aria-labelledby="wwis-unsaved-title"><strong id="wwis-unsaved-title">저장하지 않은 변경사항이 있습니다.</strong><p>이미지 생성 방식 설정을 저장하고 나갈까요?</p><div class="wwis-row"><button id="wwis-unsaved-save">저장 후 나가기</button><button id="wwis-unsaved-discard">저장 안 하고 나가기</button><button id="wwis-unsaved-continue">계속 수정</button></div></section>`;
    editor.prompt = prompt;
    overlay.append(prompt);
    overlay.querySelector('#wwis-panel').inert = true;
    const dismiss = () => {
      prompt.remove(); editor.prompt = null;
      overlay.querySelector('#wwis-panel').inert = false;
      if (previousFocus?.isConnected) previousFocus.focus();
    };
    prompt.querySelector('#wwis-unsaved-continue').onclick = dismiss;
    prompt.addEventListener('keydown', event => {
      if (event.key !== 'Tab') return;
      const buttons = [...prompt.querySelectorAll('button')];
      if (event.shiftKey && document.activeElement === buttons[0]) {
        buttons.at(-1).focus(); event.preventDefault();
      } else if (!event.shiftKey && document.activeElement === buttons.at(-1)) {
        buttons[0].focus(); event.preventDefault();
      }
    });
    prompt.querySelector('#wwis-unsaved-discard').onclick = () => {
      dismiss(); ImageStudio_생성설정종료하기(); onLeave();
    };
    prompt.querySelector('#wwis-unsaved-save').onclick = async () => {
      dismiss();
      if (await editor.save()) { ImageStudio_생성설정종료하기(); onLeave(); }
    };
    prompt.querySelector('#wwis-unsaved-continue').focus();
  }

  window.addEventListener('beforeunload', event => {
    if (!generationSettingsEditor?.dirty()) return;
    event.preventDefault(); event.returnValue = '';
  });
  content.addEventListener('input', () => generationSettingsEditor?.update());
  content.addEventListener('change', () => generationSettingsEditor?.update());
  let planningController = null;
  const checkPlanningCancelled = signal => { if (signal?.aborted) throw new DOMException('조합 계산을 취소했습니다.', 'AbortError'); };
  function waitForPlanning(promise, signal) {
    if (!signal) return promise;
    return new Promise((resolve, reject) => {
      const abort = () => reject(new DOMException('조합 계산을 취소했습니다.', 'AbortError'));
      signal.addEventListener('abort', abort, { once: true });
      Promise.resolve(promise).then(resolve, reject).finally(() => signal.removeEventListener('abort', abort));
      if (signal.aborted) abort();
    });
  }
  function paintPlanningCancel() {
    const button = content.querySelector('#wwis-plan-cancel');
    if (!button) return;
    button.hidden = !planningController;
    button.style.display = planningController ? '' : 'none';
    button.disabled = !!planningController?.signal.aborted;
    button.textContent = planningController?.signal.aborted ? '취소하는 중…' : '취소하기';
  }
  const generationProgress = value => {
    if (typeof value === 'string') { setMessage(value); return; }
    taskProgress.update('generation', value);
  };
  let cataloguePending = null, catalogueLoadedAt = 0;
  async function imageStudio_requestJson(url, options = {}) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    try {
      const response = await fetch(url, { ...options, signal: controller.signal });
      const body = await response.json();
      return { response, body };
    } finally { clearTimeout(timer); }
  }
  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
  const offlineKey = 'ww-image-studio-offline-only-v1';
  const conditionsKey = 'ww-image-studio-conditions-v2';
  let savedConditions = {};
  try {
    const saved = JSON.parse(localStorage.getItem(conditionsKey) || '{}');
    if (saved && typeof saved === 'object' && !Array.isArray(saved)) savedConditions = saved;
  } catch (_) {}

  function defaultsFor(axis, values, wife) {
    if (axis.startsWith('prompt')) return ['auto'];
    if (axis === 'character') return [wife];
    if (axis === 'men') return ['0', '1'];
    if (axis === 'exposure' || axis === 'aftermath') return ['none'];
    if (axis === 'variant') return ['0'];
    return values;
  }
  function restoreConditions(wife) {
    const saved = savedConditions[wife];
    state.selected = {};
    state.cloneSource = typeof saved?.cloneSource === 'string' ? saved.cloneSource : '';
    state.duplicateMode = saved?.duplicateMode === 'prompt-key' ? 'prompt-key' : 'composition';
    for (const [axis,values] of Object.entries(saved?.selected || {})) if (Array.isArray(values)) {
      state.selected[axis] = new Set(values.filter(value => typeof value === 'string')
        .map(value => axis === 'exposure' ? ImageStudio_노출코드정규화하기(value) || 'none' : value));
    }
  }
  function saveConditions() {
    if (!state.wife) return;
    savedConditions[state.wife] = {
      cloneSource: state.cloneSource,
      duplicateMode: state.duplicateMode,
      selected: Object.fromEntries(axisDefs.map(([axis]) => [axis, [...(state.selected[axis] || [])]])),
    };
    try { localStorage.setItem(conditionsKey, JSON.stringify(savedConditions)); } catch (_) {}
  }

  let offlineOnly = false;
  try { offlineOnly = localStorage.getItem(offlineKey) === 'true'; } catch (_) {}
  const offlineCheck = overlay.querySelector('#wwis-offline-only');
  offlineCheck.checked = offlineOnly;
  const applyOfflineOnly = () => { bridge()?.setOfflineOnly?.(offlineOnly); };
  offlineCheck.onchange = () => {
    offlineOnly = offlineCheck.checked;
    try { localStorage.setItem(offlineKey, String(offlineOnly)); } catch (_) {}
    applyOfflineOnly();
  };
  applyOfflineOnly();
  let lockWifeOutfit = false;
  try { lockWifeOutfit = localStorage.getItem(outfitLockKey) === 'true'; } catch (_) {}
  const outfitLockCheck = overlay.querySelector('#wwis-lock-wife-outfit');
  outfitLockCheck.checked = lockWifeOutfit;
  const applyOutfitLock = () => { bridge()?.setOutfitLock?.(lockWifeOutfit); };
  outfitLockCheck.onchange = () => {
    lockWifeOutfit = outfitLockCheck.checked;
    try { localStorage.setItem(outfitLockKey, String(lockWifeOutfit)); } catch (_) {}
    applyOutfitLock();
  };
  applyOutfitLock();

  const field = (key, prefix) => key.split('__').find(part => part.startsWith(prefix + '-'))?.slice(prefix.length + 1) || '';
  const situation = key => field(key, 'scene') || field(key, 'task') || '기타';
  const roomOf = key => (field(key, 'room') || '기타') + (field(key, 'abed') ? ' (침대 위)' : '');
  const signature = key => key.includes('__') ? key.slice(key.indexOf('__')) : key;
  const partnerOf = value => value.startsWith('patron_') || value === 'bath_with_patron' || value.startsWith('bath_attendant') ? 'patron'
    : value === 'self_pleasure' || value === 'bath_solo' || ['idle', 'greeting', 'taking_order', 'serving', 'cleaning', 'cooking', 'passed_out', 'bathing', 'sleeping', 'resting'].includes(value) ? 'solo' : 'husband';
  const menOf = key => {
    const group = Number(field(key, 'grp'));
    if (Number.isInteger(group) && group > 0) return String(group + 1);
    return field(key, 'task') || partnerOf(situation(key)) === 'solo' ? '0' : '1';
  };
  // --- 조건 창을 열 때만 이미지 목록의 추가 조건을 수집합니다. ---
  // 목록이 갱신되면 배열 참조가 바뀝니다. 같은 목록은 다시 읽거나 정규화하지 않습니다.
  // 기본 조건은 매번 별도로 합쳐서, 새 의상·확장 등록과 편집한 이름은 즉시 반영합니다.
  let catalogueAxesSource = null, catalogueAxes = null;
  function axesWithCatalogue(base) {
    const axes = Object.fromEntries(Object.entries(base).map(([axis, items]) => [axis, items.map(item => ({ ...item }))]));
    // 프리셋과 이미지팩 모두 같은 대표 코드로 합친 뒤 목록에 넣습니다.
    axes.exposure = [...new Map(axes.exposure.map(item => {
      const value = ImageStudio_노출코드정규화하기(item.value) || 'none';
      return [value, { ...item, value }];
    })).values()];
    const known = Object.fromEntries(Object.entries(axes)
      .map(([axis, items]) => [axis, new Set(items.map(item => String(item.value)))]));
    const add = (axis, value, extra = {}) => {
      if (axis === 'exposure') value = ImageStudio_노출코드정규화하기(value) || 'none';
      if (!value || known[axis].has(String(value))) return;
      known[axis].add(String(value));
      axes[axis].push({ value: String(value), ...extra });
    };

    if (catalogueAxesSource !== state.catalogue) {
      const collected = new Map(Object.keys(axes).map(axis => [axis, new Map()]));
      const collect = (axis, value, extra = {}) => {
        if (axis === 'exposure') value = ImageStudio_노출코드정규화하기(value) || 'none';
        if (value && !collected.get(axis).has(String(value))) {
          collected.get(axis).set(String(value), { value: String(value), ...extra });
        }
      };
      for (const entry of state.catalogue) {
        const key = entry.talentName;
        if (!key?.includes('__')) continue;
        // 각 키를 한 번만 나눕니다. 같은 필드가 반복되면 기존 field()와 같이 첫 값을 사용합니다.
        const fields = Object.create(null);
        for (const part of key.split('__')) {
          const separator = part.indexOf('-');
          if (separator < 0) continue;
          const id = part.slice(0, separator);
          if (!Object.prototype.hasOwnProperty.call(fields, id)) fields[id] = part.slice(separator + 1);
        }
        const moment = fields.scene || fields.task || '기타';
        if (moment !== '기타') collect('situation', moment, { kind: fields.task ? 'task' : 'scene' });
        collect('outfit', fields.outfit);
        collect('room', (fields.room || '기타') + (fields.abed ? ' (침대 위)' : ''));
        collect('mood', fields.mood || 'default');
        const group = Number(fields.grp);
        const men = Number.isInteger(group) && group > 0 ? String(group + 1)
          : fields.task || partnerOf(moment) === 'solo' ? '0' : '1';
        collect('men', men);
        collect('roles', fields.gslot);
        collect('exposure', fields.exp || 'none');
        collect('aftermath', fields.aft || 'none');
        if (/^[0-3]$/.test(fields.v)) collect('variant', fields.v);
      }
      catalogueAxes = [...collected].map(([axis, items]) => [axis, [...items.values()]]);
      catalogueAxesSource = state.catalogue;
    }
    for (const [axis, items] of catalogueAxes) {
      for (const { value, ...extra } of items) add(axis, value, extra);
    }
    return axes;
  }
  function matchesSelection(key, selected) {
    const has = (axis, value) => valuesOf(selected, axis).includes(String(value));
    const roles = field(key, 'gslot');
    return has('situation', situation(key)) && has('outfit', field(key, 'outfit')) && has('room', roomOf(key))
      && has('mood', field(key, 'mood') || 'default') && has('men', menOf(key))
      && (!roles || has('roles', roles)) && has('exposure', ImageStudio_노출코드정규화하기(field(key, 'exp')) || 'none')
      && has('aftermath', field(key, 'aft') || 'none') && has('variant', field(key, 'v') || '0');
  }
  const setMessage = text => {
    state.message = text;
    const node = content.querySelector('#wwis-message');
    if (node) node.textContent = text;
  };

  function loadCatalogue(force = false) {
    if (cataloguePending) return cataloguePending;
    if (!force && catalogueLoadedAt && Date.now() - catalogueLoadedAt < 30000) return Promise.resolve();
    cataloguePending = imageStudio_loadCatalogue().finally(() => { cataloguePending = null; });
    return cataloguePending;
  }
  async function imageStudio_loadCatalogue() {
    globalThis.WW_ImageStudioMatching?.refresh?.();
    const b = bridge();
    let readyTimer;
    try {
      await Promise.race([b?.ready?.(), new Promise((_, reject) => {
        readyTimer = setTimeout(() => reject(new Error('이미지팩 초기화 응답 시간 초과. 서버 상태를 확인한 뒤 다시 확인을 눌러 주세요.')), 8000);
      })]);
    } finally { clearTimeout(readyTimer); }
    const packs = (b?.packs() || []).slice();
    const url = b?.connection()?.baseUrl;
    if (url) try {
      const { response, body } = await imageStudio_requestJson(url + '/api/pack', { credentials: 'omit' });
      if (response.ok) packs.push(body);
    } catch (_) {}
    packs.sort((a, b) => (a.priority || 0) - (b.priority || 0) || String(a.generatedAt).localeCompare(String(b.generatedAt)));
    // 집계·조건 목록·파일 대조에 앞서 일반 이미지 범위만 선택합니다.
    const candidates = packs.flatMap(pack => Object.values(pack.entries || {}))
      .filter(entry => entry?.talentName && typeof entry.imagePath === 'string');
    const normalizePath = path => path.replace(/\\/g, '/').replace(/^\.\//, '');
    let missingPaths = null;
    state.catalogueVerified = false;
    state.catalogueWarning = '';
    if (url) try {
      const paths = [...new Set(candidates.map(entry => normalizePath(entry.imagePath)))];
      const missing = new Set();
      for (let offset = 0; offset < paths.length; offset += 2000) {
        const { response, body: result } = await imageStudio_requestJson(url + '/api/image-cache/verify', {
          method: 'POST', credentials: 'omit', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ paths: paths.slice(offset, offset + 2000), refresh: offset === 0 }),
        });
        if (!response.ok) throw new Error('file verification unavailable');
        if (!Array.isArray(result.missing) || result.missing.some(path => typeof path !== 'string')) throw new Error('invalid file verification');
        result.missing.forEach(path => missing.add(normalizePath(path)));
      }
      missingPaths = missing;
      state.catalogueVerified = true;
    } catch (_) {
      state.catalogueWarning = '실제 파일을 확인하지 못해 이미지팩에 등록된 수를 표시합니다. 최신 이미지 서버를 다시 실행한 뒤 확인해 주세요.';
    }
    const merged = new Map();
    for (const entry of candidates) {
      if (!missingPaths || !missingPaths.has(normalizePath(entry.imagePath))) merged.set(entry.talentName, entry);
    }
    state.catalogue = [...merged.values()];
    catalogueLoadedAt = Date.now();
  }

  function counts() {
    const mine = state.catalogue.filter(entry => entry.talentName?.startsWith(state.wife + '__'));
    const group = fn => Object.entries(mine.reduce((result, entry) => {
      const key = fn(entry.talentName); result[key] = (result[key] || 0) + 1; return result;
    }, {})).sort((a, b) => b[1] - a[1]);
    return {
      total: mine.length,
      situation: group(situation), room: group(roomOf),
      outfit: group(key => field(key, 'outfit') || '기타'),
      mood: group(key => moodLabels[field(key, 'mood') || 'default'] || field(key, 'mood')),
    };
  }

  function choose(wife) {
    state.wife = wife; state.conditionalOpen = false; state.hStatusOpen = false; state.options = {}; state.lastPlan = null;
    restoreConditions(wife); render(); void refresh();
  }
  async function refresh(force = false) {
    try {
      await loadCatalogue(force);
      if (state.wife && content.querySelector('#wwis-generation') && !state.busy) render();
    } catch (error) { setMessage(`이미지 목록을 읽지 못했습니다: ${error?.message || error}`); }
  }

  function imageStudio_refreshWifeNames() {
    const roster = bridge()?.characters?.();
    for (const character of roster?.characters || []) names[character.id] = character.name;
    return roster;
  }

  async function imageStudio_discoverWives(onCharacter = () => {}, onStatus = () => {}) {
    if (state.discoverBusy) return;
    state.discoverBusy = true;
    const activeButton = content.querySelector('#wwis-discover-wives');
    if (activeButton) activeButton.disabled = true;
    const report = { found: 0, added: 0, existing: 0, skipped: 0, failed: [] };
    const status = message => { state.discoveryMessage = message; onStatus(message); };
    try {
      const roster = imageStudio_refreshWifeNames();
      if (!roster) throw new Error('캐릭터 목록 연결을 찾지 못했습니다. 게임을 새로고침해 주세요.');
      report.found = roster.characters.length;
      report.skipped = roster.skipped;
      const characters = roster.characters.filter(character => {
        if (character.originalPrompt) return true;
        report.skipped++; return false;
      });
      if (!characters.length) { status(`등록할 캐릭터 외형 프롬프트가 없습니다. 제외 ${report.skipped}명.`); return report; }
      const url = bridge()?.connection()?.baseUrl;
      if (!url) throw new Error(`게임에서 ${report.found}명을 찾았습니다. 서버에 저장하려면 Start_ImageStudio.cmd를 실행한 뒤 다시 탐색해 주세요.`);
      status(`캐릭터 ${characters.length}명을 한 번에 확인하는 중…`);
      const batch = await imageStudio_requestJson(url + '/api/generation/characters/discover-batch', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'omit',
        body: JSON.stringify({ characters }),
      });
      if (batch.response.ok) {
        for (const item of batch.body.results) {
          if (item.added) report.added++; else report.existing++;
          onCharacter(item.character);
        }
      } else if (batch.response.status !== 404) throw new Error(batch.body.error || `HTTP ${batch.response.status}`);
      // Compatibility with earlier servers. A timeout stops the scan instead
      // of repeating the same eight-second wait for every remaining wife.
      if (batch.response.status === 404)
      for (const [index, character] of characters.entries()) {
        status(`캐릭터를 찾고 등록하는 중… ${index + 1}/${characters.length} · ${character.name}`);
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 8000);
        try {
          const response = await fetch(url + '/api/generation/characters/discover', {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'omit',
            signal: controller.signal, body: JSON.stringify(character),
          });
          const body = await response.json().catch(() => ({}));
          if (!response.ok) throw new Error(response.status === 404
            ? '실행 중인 서버가 캐릭터 등록 API를 지원하지 않습니다. Start_ImageStudio.cmd로 다시 시작해 주세요.'
            : body.error || `HTTP ${response.status}`);
          if (body.added) report.added++; else report.existing++;
          onCharacter(body.character || character);
        } catch (error) {
          report.failed.push(`${character.name}: ${error?.name === 'AbortError' ? '서버 응답 시간 초과' : error?.message || error}`);
          if (error?.name === 'AbortError' || error instanceof TypeError) break;
        } finally { clearTimeout(timer); }
      }
      status(`탐색 ${report.found}명 · 새로 추가 ${report.added}명 · 기존 유지 ${report.existing}명 · 제외 ${report.skipped}명 · 실패 ${report.failed.length}명. ${report.added ? '추가한 캐릭터 설정을 저장하고 즉시 적용했습니다.' : '기존 인물 설정을 유지했습니다.'}${report.failed.length ? ` 실패 항목은 다시 탐색하면 재시도합니다. ${report.failed.join(' / ')}` : ''}`);
      return report;
    } catch (error) { status(error?.name === 'AbortError' ? '서버 응답 시간이 초과됐습니다. 실행 중인 캐시 작업과 이미지 서버 창을 확인한 뒤 다시 탐색해 주세요.' : String(error?.message || error)); return report; }
    finally {
      state.discoverBusy = false;
      const activeButton = content.querySelector('#wwis-discover-wives');
      if (activeButton) activeButton.disabled = false;
    }
  }
  bridge().discoverWives = imageStudio_discoverWives;

  async function showGenerationSettings() {
    const load = {};
    generationSettingsLoad = load;
    const url = bridge()?.connection()?.baseUrl;
    if (!url) {
      content.innerHTML = `<div class="wwis-row"><button id="wwis-settings-back">← 인물 선택</button></div><p class="wwis-setting-status">이미지 생성 서버에 연결해 주세요. Start_ImageStudio.cmd를 먼저 실행해야 설정을 저장할 수 있습니다.</p>`;
      content.querySelector('#wwis-settings-back').onclick = render;
      return;
    }
    content.innerHTML = '<p class="wwis-setting-status">이미지 생성 설정을 읽는 중…</p>';
    let settings;
    try {
      const response = await fetch(url + '/api/generation/settings', { credentials: 'omit' });
      const body = await response.json().catch(() => ({}));
      if (generationSettingsLoad !== load || overlay.hidden) return;
      if (!response.ok) throw new Error(response.status === 404
        ? await ImageStudio_서버지원오류읽기(url, '생성 방식 설정')
        : body.error || `HTTP ${response.status}`);
      settings = body;
    } catch (error) {
      if (generationSettingsLoad !== load || overlay.hidden) return;
      content.innerHTML = `<div class="wwis-row"><button id="wwis-settings-back">← 인물 선택</button></div><p class="wwis-setting-status">${escapeHtml(error?.message || error)}</p>`;
      content.querySelector('#wwis-settings-back').onclick = render;
      return;
    }

    const sdxlSizeSupported = Number.isFinite(settings.sdxlWidth) && Number.isFinite(settings.sdxlHeight);
    const wifeLorasSupported = Number(settings.version) >= 15;
    const promptBatchSupported = Number(settings.version) >= 16;
    const promptBatchMax = Number(settings.version) >= 17 ? 128 : 16;
    const animaFolderSupported = typeof settings.animaSaveToIllustrious === 'boolean';
    const naiSupported = Number(settings.version) >= 19;
    const naiOptions = (values, selected) => values.map(value => `<option value="${escapeHtml(value)}" ${value === selected ? 'selected' : ''}>${escapeHtml(value)}</option>`).join('');
    content.innerHTML = `
      <div class="wwis-row wwis-generation-toolbar"><button id="wwis-settings-back">← 인물 선택</button><strong>이미지 생성 방식 지정</strong><button id="wwis-save-generation-top">설정 저장</button><span id="wwis-settings-unsaved" role="status"></span></div>
      <div class="wwis-card">
        <h3>이미지 생성 방식</h3>
        <div class="wwis-engine-choice">
          <label><span><input type="radio" name="wwis-provider" value="sdxl" ${settings.imageProvider === 'sdxl' ? 'checked' : ''}> <strong>SDXL · 기본 형태</strong></span><span class="wwis-dim">Illustrious 체크포인트와 선택 LoRA로 기존 Wayward 프롬프트를 생성합니다.</span></label>
          <label><span><input type="radio" name="wwis-provider" value="anima" ${settings.imageProvider === 'anima' ? 'checked' : ''}> <strong>Anima</strong></span><span class="wwis-dim">Anima UNET + Qwen 텍스트 인코더 + VAE + 여러 LoRA를 사용합니다.</span></label>
          <label><span><input type="radio" name="wwis-provider" value="nai" ${settings.imageProvider === 'nai' ? 'checked' : ''} ${naiSupported ? '' : 'disabled'}> <strong>NovelAI (NAI)</strong></span><span class="wwis-dim">NovelAI API로 생성합니다. ComfyUI와 로컬 GPU 없이 사용할 수 있습니다.</span></label>
        </div>
        <p class="wwis-dim">여기서 고른 방식은 일반 생성·검수 생성·조건부 대기열에 적용됩니다.</p>
        ${naiSupported ? '' : '<p class="wwis-setting-status">NAI를 사용하려면 이미지 서버를 종료한 뒤 Start_ImageStudio.cmd로 다시 실행하고 이 창을 다시 열어 주세요.</p>'}
      </div>
      <div class="wwis-card" id="wwis-comfy-settings">
        <h3>ComfyUI 설정</h3>
        <div class="wwis-settings-grid">
          <label class="wwis-wide">ComfyUI 주소<input id="wwis-comfy-url" value="${escapeHtml(settings.comfyUrl)}" placeholder="http://127.0.0.1:8188"></label>
          <label class="wwis-wide">동시 프롬프트 전달 개수<select id="wwis-prompt-batch-size" ${promptBatchSupported ? '' : 'disabled'}>${Array.from({ length: promptBatchMax }, (_, index) => index + 1).map(count => `<option value="${count}" ${count === (Number(settings.promptBatchSize) || 1) ? 'selected' : ''}>${count}개</option>`).join('')}</select></label>
          <label class="wwis-wide">ComfyUI models 폴더<input id="wwis-models-directory" value="${escapeHtml(settings.modelsDirectory)}" placeholder="...\\ComfyUI-Shared\\models"></label>
        </div>
        <p class="wwis-dim">대량·조건부 대기열에서 서로 다른 장면을 최대 선택 개수만큼 묶어 한 모델로 생성합니다. 같은 모델·LoRA·해상도·샘플러를 쓰는 항목만 묶으며, 일반·검수창의 단일 요청은 한 장을 생성합니다. 기본값은 1입니다. VRAM이 부족하면 이번 실행의 배치 크기를 줄여 재시도합니다.</p>
        <p id="wwis-prompt-batch-status" class="wwis-setting-status">${promptBatchSupported ? '동시 프롬프트 생성 지원을 확인하는 중…' : '동시 프롬프트 설정에는 포함된 서버 0.4.1이 필요합니다. wml\\mods\\imagestudio\\Start_ImageStudio.cmd로 서버를 다시 실행하고 이 창을 다시 열어 주세요.'}</p>
        <p class="wwis-dim">Windows의 RTX 50 계열에서 Anima 실행 중 ComfyUI가 종료되면 Comfy Desktop 실행 옵션에 <code>--disable-dynamic-vram --disable-async-offload --disable-cuda-malloc --lowvram --reserve-vram 1</code>을 사용하세요. 이 PC에서는 해당 안정 설정으로 실제 Anima 생성까지 확인했습니다.</p>
        <div class="wwis-row"><button id="wwis-pick-models">폴더 선택</button><button id="wwis-refresh-resources">모델 목록 다시 읽기</button><span id="wwis-resource-status" class="wwis-dim">모델 목록을 확인하지 않았습니다.</span></div>
      </div>
      <div class="wwis-card" id="wwis-sdxl-settings">
        <h3>SDXL · 기본 형태</h3>
        <div class="wwis-settings-grid">
          <label class="wwis-wide">체크포인트<input id="wwis-sdxl-checkpoint" list="wwis-checkpoints" value="${escapeHtml(settings.sdxlCheckpoint)}"></label>
          <label class="wwis-wide">공통 LoRA (빈 값이면 사용 안 함)<input id="wwis-sdxl-lora" list="wwis-loras" value="${escapeHtml(settings.sdxlLora)}"></label>
          <label>LoRA 강도<input id="wwis-sdxl-lora-strength" type="number" step="0.05" value="${escapeHtml(settings.sdxlLoraStrength)}"></label>
          <label>Steps<input id="wwis-sdxl-steps" type="number" min="1" max="150" value="${escapeHtml(settings.sdxlSteps)}"></label>
          <label>CFG<input id="wwis-sdxl-cfg" type="number" min="0" max="100" step="0.1" value="${escapeHtml(settings.sdxlCfg)}"></label>
          <label>Clip skip<input id="wwis-sdxl-clip-skip" type="number" max="0" value="${escapeHtml(settings.sdxlClipSkip)}"></label>
          <label>Sampler<input id="wwis-sdxl-sampler" value="${escapeHtml(settings.sdxlSampler)}"></label>
          <label>Scheduler<input id="wwis-sdxl-scheduler" value="${escapeHtml(settings.sdxlScheduler)}"></label>
          <label>가로 (px)<input id="wwis-sdxl-width" type="number" min="64" max="4096" step="8" value="${escapeHtml(settings.sdxlWidth ?? 1024)}"></label>
          <label>세로 (px)<input id="wwis-sdxl-height" type="number" min="64" max="4096" step="8" value="${escapeHtml(settings.sdxlHeight ?? 1024)}"></label>
          <p class="wwis-wide wwis-dim">기본 1024 × 1024 px. 64~4096 px 범위에서 8 px 단위로 저장하며, 새로 생성하는 일반 이미지와 조건부 대기열에 적용됩니다.</p>
          ${sdxlSizeSupported ? '' : '<p class="wwis-wide wwis-setting-status">현재 서버는 SDXL 이미지 크기 설정을 지원하지 않습니다. 이미지 서버 창을 종료하고 Start_ImageStudio.cmd로 다시 실행해 주세요.</p>'}
          <label class="wwis-wide">공통 기본 프롬프트<textarea id="wwis-sdxl-positive">${escapeHtml(settings.sdxlPositivePrompt)}</textarea></label>
          <label class="wwis-wide">공통 네거티브 프롬프트<textarea id="wwis-sdxl-negative">${escapeHtml(settings.sdxlNegativePrompt)}</textarea></label>
        </div>
      </div>
      <div class="wwis-card" id="wwis-nai-settings">
        <h3>NovelAI (NAI)</h3>
        <p class="wwis-dim">NovelAI 계정 설정 → Account → Get Persistent API Token에서 발급한 토큰을 입력하세요. 생성 시 구독 사용량 또는 Anlas가 소모될 수 있습니다.</p>
        <div class="wwis-settings-grid">
          <label class="wwis-wide">Persistent API Token<input id="wwis-nai-token" type="password" autocomplete="new-password" spellcheck="false" placeholder="${settings.naiTokenConfigured ? '저장된 토큰 사용 · 교체할 때만 입력' : 'NovelAI API 토큰 입력'}"></label>
          <label class="wwis-wide"><span><input id="wwis-nai-token-clear" type="checkbox"> 저장된 토큰 삭제</span></label>
          <label class="wwis-wide">모델<select id="wwis-nai-model">${naiOptions(settings.naiModels || ['nai-diffusion-5-full'], settings.naiModel || 'nai-diffusion-5-full')}</select></label>
          <label>가로 (px)<input id="wwis-nai-width" type="number" min="64" max="2048" step="64" value="${escapeHtml(settings.naiWidth ?? 832)}"></label>
          <label>세로 (px)<input id="wwis-nai-height" type="number" min="64" max="2048" step="64" value="${escapeHtml(settings.naiHeight ?? 1216)}"></label>
          <label>Steps<input id="wwis-nai-steps" type="number" min="1" max="50" value="${escapeHtml(settings.naiSteps ?? 28)}"></label>
          <label>Prompt Guidance<input id="wwis-nai-scale" type="number" min="0" max="10" step="0.1" value="${escapeHtml(settings.naiScale ?? 6.5)}"></label>
          <label>Sampler<select id="wwis-nai-sampler">${naiOptions(settings.naiSamplers || ['k_euler_ancestral'], settings.naiSampler || 'k_euler_ancestral')}</select></label>
          <label>Noise Schedule<select id="wwis-nai-schedule">${naiOptions(settings.naiNoiseSchedules || ['karras'], settings.naiNoiseSchedule || 'karras')}</select></label>
          <label class="wwis-wide">공통 기본 프롬프트<textarea id="wwis-nai-positive">${escapeHtml(settings.naiCommonPrompt || '')}</textarea></label>
          <label class="wwis-wide">작가·스타일 프롬프트<textarea id="wwis-nai-artist">${escapeHtml(settings.naiArtistPrompt || '')}</textarea></label>
          <label class="wwis-wide">공통 네거티브 프롬프트<textarea id="wwis-nai-negative">${escapeHtml(settings.naiNegativePrompt || '')}</textarea></label>
        </div>
        <p class="wwis-dim">게임의 인물·장면 프롬프트에 위 공통·작가 태그를 더합니다. SDXL·Anima의 공통 프롬프트와 LoRA는 적용하지 않습니다. 기준 이미지를 사용하는 img2img에는 SDXL 또는 Anima를 선택하세요.</p>
        <p class="wwis-dim">대기열은 한 장씩 생성합니다. 토큰은 이 PC의 이미지 서버 설정에 저장하며 화면에는 다시 표시하지 않습니다. 설정 파일을 다른 사람에게 공유하지 마세요.</p>
        <div class="wwis-row"><button id="wwis-nai-check">저장된 토큰 연결 확인</button><span id="wwis-nai-status" class="wwis-dim">${settings.naiTokenConfigured ? '토큰이 저장되어 있습니다.' : '토큰을 입력하고 아래 설정 저장을 눌러 주세요.'}</span></div>
      </div>
      <div class="wwis-card" id="wwis-anima-settings">
        <h3>Anima</h3>
        <p class="wwis-dim">체크포인트 칸이 아니라 아래 세 파일을 각각 불러오는 Anima 전용 워크플로입니다. GGUF 텍스트 인코더를 쓰면 ComfyUI-GGUF 노드가 필요합니다.</p>
        <div class="wwis-settings-grid">
          <label class="wwis-wide"><span><input id="wwis-anima-save-illustrious" type="checkbox" ${settings.animaSaveToIllustrious === true ? 'checked' : ''} ${animaFolderSupported ? '' : 'disabled'}> 생성 이미지를 illustrious 폴더에 저장</span><span class="wwis-dim">선택하면 images/illustrious/characters/[캐릭터]에 저장합니다. 해제하면 images/anima/characters/[캐릭터]에 저장합니다. 생성 모델과 캐시 구분은 Anima로 유지되며 기존 파일은 이동하지 않습니다.</span></label>
          ${animaFolderSupported ? '' : '<p class="wwis-setting-status wwis-wide">저장 폴더 선택에는 서버 0.4.7이 필요합니다. 이 모드 폴더의 Start_ImageStudio.cmd로 서버를 다시 실행하고 이 창을 다시 열어 주세요.</p>'}
          <label class="wwis-wide">Anima 모델 (diffusion_models)<input id="wwis-anima-model" list="wwis-diffusion-models" value="${escapeHtml(settings.model)}"></label>
          <label class="wwis-wide">Qwen 텍스트 인코더<input id="wwis-anima-clip" list="wwis-text-encoders" value="${escapeHtml(settings.clip)}"></label>
          <label>텍스트 인코더 장치<select id="wwis-anima-clip-device"><option value="cpu" ${settings.clipDevice !== 'default' ? 'selected' : ''}>CPU (8GB VRAM 권장)</option><option value="default" ${settings.clipDevice === 'default' ? 'selected' : ''}>GPU / 자동</option></select></label>
          <label class="wwis-wide">VAE<input id="wwis-anima-vae" list="wwis-vaes" value="${escapeHtml(settings.vae)}"></label>
          <label class="wwis-wide">Anima LoRA 폴더<input id="wwis-anima-lora-directory" value="${escapeHtml(settings.loraDirectory)}"></label>
          <label>가로<input id="wwis-anima-width" type="number" min="64" max="4096" step="16" value="${escapeHtml(settings.width)}"></label>
          <label>세로<input id="wwis-anima-height" type="number" min="64" max="4096" step="16" value="${escapeHtml(settings.height)}"></label>
          <label>Steps<input id="wwis-anima-steps" type="number" min="1" max="150" value="${escapeHtml(settings.steps)}"></label>
          <label>CFG<input id="wwis-anima-cfg" type="number" min="0" max="100" step="0.1" value="${escapeHtml(settings.cfg)}"></label>
          <label>Sampler<input id="wwis-anima-sampler" value="${escapeHtml(settings.sampler)}"></label>
          <label>Scheduler<input id="wwis-anima-scheduler" value="${escapeHtml(settings.scheduler)}"></label>
          <label class="wwis-wide">공통 기본 프롬프트<textarea id="wwis-anima-positive">${escapeHtml(settings.positivePrompt)}</textarea></label>
          <label class="wwis-wide">공통 네거티브 프롬프트<textarea id="wwis-anima-negative">${escapeHtml(settings.negativePrompt)}</textarea></label>
        </div>
        <div class="wwis-row"><strong>Anima LoRA</strong><button id="wwis-add-lora">+ LoRA 추가</button></div>
        <div id="wwis-anima-lora-rows"></div>
      </div>
      <div class="wwis-card">
        <div class="wwis-row"><h3 style="margin:0">캐릭터 기본 프롬프트</h3><button id="wwis-discover-wives">새로운 캐릭터 찾기</button><button id="wwis-add-character">+ 캐릭터 추가</button></div>
        <p class="wwis-dim">게임에 등록된 캐릭터의 이름과 외형 프롬프트를 찾아 서버에 자동 저장합니다. 기존 인물 설정과 이 화면에서 수정 중인 값은 유지합니다.</p>
        <p id="wwis-discovery-status" class="wwis-dim" role="status"></p>
        <p class="wwis-dim">Anima 생성 시 게임의 기존 인물 외형 태그를 이 값으로 교체합니다. 장면·의상·표정·장소 태그는 유지됩니다.</p>
        <p class="wwis-dim">캐릭터별 LoRA는 SDXL·Anima에 따로 저장하며 일반 생성·검수 생성·조건부 대기열에 적용됩니다. 별도 지정은 공통 LoRA를 대체하고, 공통에 추가는 두 목록을 함께 사용합니다. 빈 별도 목록과 사용 안 함은 LoRA를 끕니다.</p>
        ${wifeLorasSupported ? '' : "<p class=\"wwis-setting-status\">캐릭터별 LoRA를 지정하려면 서버를 종료하고 Start_ImageStudio.cmd로 서버 0.3.2를 다시 실행한 뒤 이 창을 다시 열어 주세요.</p>"}
        <div id="wwis-character-rows"></div>
      </div>
      <datalist id="wwis-checkpoints"></datalist><datalist id="wwis-loras"></datalist><datalist id="wwis-diffusion-models"></datalist><datalist id="wwis-text-encoders"></datalist><datalist id="wwis-vaes"></datalist>
      <div class="wwis-row"><button id="wwis-save-generation" class="wwis-settings-launch">설정 저장 및 즉시 적용</button></div>
      <p id="wwis-settings-status" class="wwis-setting-status">설정을 바꾼 뒤 저장해 주세요.</p>`;

    const byId = id => content.querySelector('#' + id);
    const inputValue = id => byId(id)?.value ?? '';
    const numberValue = (id, fallback) => {
      const value = Number(inputValue(id));
      return Number.isFinite(value) ? value : fallback;
    };
    const updateProviderVisibility = () => {
      const provider = content.querySelector('input[name="wwis-provider"]:checked')?.value || 'sdxl';
      byId('wwis-sdxl-settings').hidden = provider !== 'sdxl';
      byId('wwis-anima-settings').hidden = provider !== 'anima';
      byId('wwis-nai-settings').hidden = provider !== 'nai';
      byId('wwis-comfy-settings').hidden = provider === 'nai';
      for (const group of content.querySelectorAll('[data-wife-engine]')) group.hidden = group.dataset.wifeEngine !== provider;
    };
    for (const radio of content.querySelectorAll('input[name="wwis-provider"]')) radio.onchange = updateProviderVisibility;
    updateProviderVisibility();
    byId('wwis-nai-check').onclick = async () => {
      const status = byId('wwis-nai-status'), button = byId('wwis-nai-check');
      status.textContent = '저장된 토큰의 연결을 확인하는 중…'; button.disabled = true;
      try {
        const response = await fetch(url + '/api/nai/check', { method: 'POST', credentials: 'omit' });
        const body = await response.json();
        if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
        status.textContent = body.active ? 'NovelAI 연결 확인 · 활성 구독입니다.' : 'NovelAI 연결 확인 · 활성 구독이 없습니다.';
      } catch (error) { status.textContent = `연결 확인 실패: ${error?.message || error}`; }
      finally { button.disabled = false; }
    };

    const addLoraRow = lora => {
      const row = document.createElement('div'); row.className = 'wwis-lora-row';
      row.innerHTML = `<label><input data-field="enabled" type="checkbox" ${lora?.enabled ? 'checked' : ''}> 사용</label><input data-field="name" list="wwis-loras" value="${escapeHtml(lora?.name || '')}" placeholder="LoRA 파일명" style="flex:1;min-width:220px"><label>강도 <input data-field="strength" type="number" step="0.05" value="${escapeHtml(lora?.strength ?? 1)}" style="width:82px"></label><button data-remove>삭제</button>`;
      row.querySelector('[data-remove]').onclick = () => row.remove();
      byId('wwis-anima-lora-rows').append(row);
    };
    for (const lora of settings.loras || []) addLoraRow(lora);
    byId('wwis-add-lora').onclick = () => addLoraRow({ name: '', enabled: true, strength: 1 });

    function ImageStudio_아내LoRA항목추가하기(target, lora = {}) {
      const row = document.createElement('div'); row.className = 'wwis-lora-row';
      row.innerHTML = `<label><input data-field="enabled" type="checkbox" ${lora.enabled !== false ? 'checked' : ''}> 사용</label><input data-field="name" list="wwis-loras" value="${escapeHtml(lora.name || '')}" placeholder="LoRA 파일명" style="flex:1;min-width:120px"><label>강도 <input data-field="strength" type="number" min="-20" max="20" step="0.05" value="${escapeHtml(lora.strength ?? 1)}" style="width:72px"></label><button data-lora-remove>삭제</button>`;
      row.querySelector('[data-lora-remove]').onclick = () => row.remove(); target.append(row);
    }
    function ImageStudio_아내LoRA목록읽기(row, engine) {
      return [...row.querySelectorAll(`[data-wife-loras="${engine}"] .wwis-lora-row`)].map(item => ({
        name: item.querySelector('[data-field=name]').value.trim(), enabled: item.querySelector('[data-field=enabled]').checked,
        strength: Number(item.querySelector('[data-field=strength]').value) || 0,
      })).filter(item => item.name);
    }
    const addCharacterRow = character => {
      const row = document.createElement('div'); row.className = 'wwis-character-row';
      row.innerHTML = `<div class="wwis-character-head"><input data-field="id" value="${escapeHtml(character?.id || '')}" placeholder="id (예: hina)" style="width:120px"><input data-field="name" value="${escapeHtml(character?.name || '')}" placeholder="표시 이름"><button data-remove>삭제</button></div><label class="wwis-dim">기본 프롬프트<textarea data-field="prompt">${escapeHtml(character?.prompt || '')}</textarea></label><label class="wwis-dim">캐릭터 네거티브 프롬프트<textarea data-field="negativePrompt">${escapeHtml(character?.negativePrompt || '')}</textarea></label><input data-field="originalPrompt" type="hidden" value="${escapeHtml(character?.originalPrompt || '')}"><input data-field="originalNegativePrompt" type="hidden" value="${escapeHtml(character?.originalNegativePrompt || '')}">`;
      row.querySelector('[data-remove]').onclick = () => row.remove();
      const loraBox = document.createElement('details');
      loraBox.innerHTML = "<summary>캐릭터별 LoRA 설정</summary>" + (wifeLorasSupported ? '' : "<p class=\"wwis-setting-status\" data-wife-lora-unavailable>현재 연결된 서버가 캐릭터별 LoRA를 지원하지 않아 선택을 잠갔어요. 이미지 서버를 종료하고 Start_ImageStudio.cmd로 서버 0.3.2를 실행한 뒤, 이 설정 창을 닫았다가 다시 열어 주세요.</p>");
      for (const engine of ['sdxl', 'anima']) {
        const group = document.createElement('fieldset'); group.dataset.wifeEngine = engine;
        group.disabled = !wifeLorasSupported; group.style.cssText = 'border:0;padding:8px 0;min-width:0';
        const mode = character?.[engine + 'LoraMode'] || 'inherit';
        group.innerHTML = `<label>${engine === 'sdxl' ? 'SDXL' : 'Anima'} LoRA 적용 <select data-field="${engine}LoraMode">${[['inherit','공통 LoRA 사용'],['replace',"이 캐릭터의 LoRA만 사용"],['append','공통 LoRA에 추가'],['none','LoRA 사용 안 함']].map(([value,label]) => `<option value="${value}" ${mode === value ? 'selected' : ''}>${label}</option>`).join('')}</select></label><div data-wife-lora-editor><div data-wife-loras="${engine}"></div><button data-lora-add>+ LoRA 추가</button></div><p class="wwis-dim">${engine === 'sdxl' ? 'SDXL용 LoRA를 지정하세요. 모델과 텍스트 인코더에 같은 강도를 적용합니다.' : 'Anima용 LoRA를 지정하세요. 공통의 속도 LoRA를 유지하려면 공통에 추가를 선택하세요.'}</p>`;
        const list = group.querySelector('[data-wife-loras]'), select = group.querySelector('select');
        for (const lora of character?.[engine + 'Loras'] || []) ImageStudio_아내LoRA항목추가하기(list, lora);
        const update = () => { group.querySelector('[data-wife-lora-editor]').hidden = !['replace','append'].includes(select.value); };
        select.onchange = () => { if (['replace','append'].includes(select.value) && !list.children.length) ImageStudio_아내LoRA항목추가하기(list); update(); };
        group.querySelector('[data-lora-add]').onclick = () => ImageStudio_아내LoRA항목추가하기(list);
        update(); loraBox.append(group);
      }
      row.append(loraBox);
      byId('wwis-character-rows').append(row);
      updateProviderVisibility();
    };
    for (const character of settings.characters || []) addCharacterRow(character);
    byId('wwis-add-character').onclick = () => addCharacterRow({ id: '', name: '', prompt: '', negativePrompt: '' });
    const characterRows = byId('wwis-character-rows');
    const discoveryButton = byId('wwis-discover-wives');
    discoveryButton.disabled = state.discoverBusy;
    discoveryButton.onclick = async () => {
      discoveryButton.disabled = true;
      await imageStudio_discoverWives(character => {
        if (!characterRows.isConnected) return;
        const existingRow = [...characterRows.children].find(row => row.querySelector('[data-field=id]').value.trim().toLowerCase() === character.id);
        if (!existingRow) addCharacterRow(character);
        else for (const field of ['originalPrompt', 'originalNegativePrompt']) {
          const input = existingRow.querySelector(`[data-field=${field}]`);
          if (!input.value && character[field]) input.value = character[field];
        }
      }, message => {
        if (characterRows.isConnected) byId('wwis-discovery-status').textContent = message;
      });
      discoveryButton.disabled = false;
    };

    const fillDatalist = (id, values) => {
      const list = byId(id); list.textContent = '';
      for (const value of values || []) { const option = document.createElement('option'); option.value = value; list.append(option); }
    };
    const refreshResources = async () => {
      const status = byId('wwis-resource-status'); status.textContent = '모델 목록을 읽는 중…';
      try {
        const query = new URLSearchParams({ comfyUrl: inputValue('wwis-comfy-url'), modelsDirectory: inputValue('wwis-models-directory') });
        const response = await fetch(url + '/api/generation/resources?' + query, { credentials: 'omit' });
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
        fillDatalist('wwis-checkpoints', body.checkpoints); fillDatalist('wwis-loras', body.loras);
        fillDatalist('wwis-diffusion-models', body.diffusionModels); fillDatalist('wwis-text-encoders', body.textEncoders); fillDatalist('wwis-vaes', body.vaes);
        status.textContent = `${body.source === 'comfyui' ? 'ComfyUI 원격 목록' : 'models 폴더'} · 체크포인트 ${(body.checkpoints || []).length} · LoRA ${(body.loras || []).length} · Anima 모델 ${(body.diffusionModels || []).length} · 인코더 ${(body.textEncoders || []).length} · VAE ${(body.vaes || []).length}`;
      } catch (error) { status.textContent = `모델 목록을 읽지 못했습니다: ${error?.message || error}`; }
    };
    const refreshPromptBatchSupport = async () => {
      if (!promptBatchSupported) return;
      const status = byId('wwis-prompt-batch-status');
      try {
        const response = await fetch(url + '/api/generation/prompt-batch-support?' + new URLSearchParams({ comfyUrl: inputValue('wwis-comfy-url') }), { credentials: 'omit' });
        const body = await response.json();
        if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
        status.textContent = body.supported ? `동시 프롬프트 생성 노드가 연결되었습니다. 1~${promptBatchMax}개를 설정하고 저장하세요.${promptBatchMax < 128 ? ' 128개 설정은 기존 서버를 종료하고 wml\\mods\\imagestudio\\Start_ImageStudio.cmd로 포함된 서버 0.4.1을 실행하세요.' : ' 이전 16개용 노드는 Install_ComfyUI_PromptBatch.cmd로 갱신한 뒤 ComfyUI를 재시작하세요.'}`
          : body.reachable ? '2개 이상에는 포함된 노드 설치가 필요합니다. wml\\mods\\imagestudio\\Install_ComfyUI_PromptBatch.cmd를 실행하고 ComfyUI를 재시작하세요. 1개는 기존 방식으로 작동합니다.'
          : 'ComfyUI에 연결할 수 없어 동시 프롬프트 지원을 확인하지 못했습니다.';
      } catch (error) { status.textContent = `동시 프롬프트 지원을 확인하지 못했습니다: ${error?.message || error}`; }
    };
    byId('wwis-refresh-resources').onclick = () => { void refreshResources(); void refreshPromptBatchSupport(); };
    byId('wwis-comfy-url').addEventListener('change', () => { void refreshPromptBatchSupport(); });
    byId('wwis-pick-models').onclick = async () => {
      const status = byId('wwis-resource-status'); status.textContent = '폴더 선택 창을 기다리는 중…';
      try {
        const response = await fetch(url + '/api/generation/select-models-folder', { method: 'POST', credentials: 'omit' });
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
        if (body.cancelled) { status.textContent = '폴더 선택을 취소했습니다.'; return; }
        byId('wwis-models-directory').value = body.modelsDirectory;
        byId('wwis-anima-lora-directory').value = body.modelsDirectory.replace(/[\\/]$/, '') + '\\loras';
        await refreshResources();
      } catch (error) { status.textContent = `폴더를 선택하지 못했습니다: ${error?.message || error}`; }
    };

    const saveGenerationSettings = async () => {
      if (generationSettingsEditor?.saving) return false;
      const status = byId('wwis-settings-status'); status.textContent = '설정을 저장하는 중…';
      if (state.discoverBusy) {
        status.textContent = "그녀 탐색이 끝난 뒤 설정을 저장해 주세요.";
        return false;
      }
      if (!sdxlSizeSupported && (numberValue('wwis-sdxl-width', 1024) !== 1024 || numberValue('wwis-sdxl-height', 1024) !== 1024)) {
        status.textContent = 'SDXL 이미지 크기를 저장하려면 이미지 서버 창을 종료하고 Start_ImageStudio.cmd로 다시 실행한 뒤 이 설정 화면을 다시 열어 주세요.';
        return false;
      }
      const loras = [...content.querySelectorAll('#wwis-anima-lora-rows .wwis-lora-row')].map(row => ({
        enabled: row.querySelector('[data-field=enabled]').checked,
        name: row.querySelector('[data-field=name]').value.trim(),
        strength: Number(row.querySelector('[data-field=strength]').value) || 0,
      })).filter(lora => lora.name);
      const characters = [...content.querySelectorAll('#wwis-character-rows .wwis-character-row')].map(row => ({
        id: row.querySelector('[data-field=id]').value.trim().toLowerCase(),
        name: row.querySelector('[data-field=name]').value.trim(),
        prompt: row.querySelector('[data-field=prompt]').value.trim(),
        negativePrompt: row.querySelector('[data-field=negativePrompt]').value.trim(),
        originalPrompt: row.querySelector('[data-field=originalPrompt]').value,
        originalNegativePrompt: row.querySelector('[data-field=originalNegativePrompt]').value,
        sdxlLoraMode: row.querySelector('[data-field=sdxlLoraMode]').value,
        sdxlLoras: ImageStudio_아내LoRA목록읽기(row, 'sdxl'),
        animaLoraMode: row.querySelector('[data-field=animaLoraMode]').value,
        animaLoras: ImageStudio_아내LoRA목록읽기(row, 'anima'),
      })).filter(character => character.id);
      const next = {
        ...settings,
        imageProvider: content.querySelector('input[name="wwis-provider"]:checked')?.value || 'sdxl',
        ...(naiSupported ? {
          naiToken: inputValue('wwis-nai-token'), naiTokenClear: byId('wwis-nai-token-clear').checked,
          naiModel: inputValue('wwis-nai-model'), naiWidth: numberValue('wwis-nai-width', 832), naiHeight: numberValue('wwis-nai-height', 1216),
          naiSteps: numberValue('wwis-nai-steps', 28), naiScale: numberValue('wwis-nai-scale', 6.5),
          naiSampler: inputValue('wwis-nai-sampler'), naiNoiseSchedule: inputValue('wwis-nai-schedule'),
          naiCommonPrompt: inputValue('wwis-nai-positive'), naiArtistPrompt: inputValue('wwis-nai-artist'), naiNegativePrompt: inputValue('wwis-nai-negative'),
        } : {}),
        ...(animaFolderSupported ? { animaSaveToIllustrious: byId('wwis-anima-save-illustrious').checked } : {}),
        comfyUrl: inputValue('wwis-comfy-url'), modelsDirectory: inputValue('wwis-models-directory'),
        ...(promptBatchSupported ? { promptBatchSize: numberValue('wwis-prompt-batch-size', 1) } : {}),
        sdxlCheckpoint: inputValue('wwis-sdxl-checkpoint'), sdxlLora: inputValue('wwis-sdxl-lora'),
        sdxlLoraStrength: numberValue('wwis-sdxl-lora-strength', 1), sdxlSteps: numberValue('wwis-sdxl-steps', 9),
        sdxlCfg: numberValue('wwis-sdxl-cfg', 1.5), sdxlClipSkip: numberValue('wwis-sdxl-clip-skip', -2),
        sdxlSampler: inputValue('wwis-sdxl-sampler'), sdxlScheduler: inputValue('wwis-sdxl-scheduler'),
        sdxlWidth: numberValue('wwis-sdxl-width', 1024), sdxlHeight: numberValue('wwis-sdxl-height', 1024),
        sdxlPositivePrompt: inputValue('wwis-sdxl-positive'), sdxlNegativePrompt: inputValue('wwis-sdxl-negative'),
        model: inputValue('wwis-anima-model'), clip: inputValue('wwis-anima-clip'), clipDevice: inputValue('wwis-anima-clip-device'), vae: inputValue('wwis-anima-vae'),
        loraDirectory: inputValue('wwis-anima-lora-directory'), width: numberValue('wwis-anima-width', 832), height: numberValue('wwis-anima-height', 1216),
        steps: numberValue('wwis-anima-steps', 30), cfg: numberValue('wwis-anima-cfg', 4),
        sampler: inputValue('wwis-anima-sampler'), scheduler: inputValue('wwis-anima-scheduler'),
        positivePrompt: inputValue('wwis-anima-positive'), negativePrompt: inputValue('wwis-anima-negative'), loras, characters,
      };
      const editor = generationSettingsEditor;
      editor.saving = true;
      // 저장 중에는 입력과 중복 저장을 막습니다. 응답 전에는 나가거나 미저장 표시를 지우지 않습니다.
      content.inert = true;
      editor.update();
      try {
        const response = await fetch(url + '/api/generation/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, credentials: 'omit', signal: AbortSignal.timeout(15000), body: JSON.stringify(next) });
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
        settings = body.settings;
        if (naiSupported) {
          byId('wwis-nai-token').value = '';
          byId('wwis-nai-token').placeholder = settings.naiTokenConfigured ? '저장된 토큰 사용 · 교체할 때만 입력' : 'NovelAI API 토큰 입력';
          byId('wwis-nai-token-clear').checked = false;
          byId('wwis-nai-status').textContent = settings.naiTokenConfigured ? '토큰이 저장되어 있습니다.' : '저장된 토큰이 없습니다.';
        }
        byId('wwis-sdxl-width').value = settings.sdxlWidth ?? 1024;
        byId('wwis-sdxl-height').value = settings.sdxlHeight ?? 1024;
        byId('wwis-prompt-batch-size').value = settings.promptBatchSize ?? 1;
        status.textContent = settings.imageProvider === 'nai'
          ? `NovelAI 설정을 저장하고 즉시 적용했습니다. ${settings.naiWidth} × ${settings.naiHeight} px · ${settings.naiModel} · 한 장씩 생성합니다.`
          : `${settings.imageProvider === 'anima' ? 'Anima' : 'SDXL · 기본 형태'} 설정을 저장하고 즉시 적용했습니다.${promptBatchSupported ? ` 동시 프롬프트: 최대 ${settings.promptBatchSize}개.` : ''}${settings.imageProvider === 'sdxl' ? ` 이미지 크기: ${settings.sdxlWidth ?? 1024} × ${settings.sdxlHeight ?? 1024} px.` : animaFolderSupported ? ` 저장 폴더: images/${settings.animaSaveToIllustrious ? 'illustrious' : 'anima'}.` : ''}`;
        editor.baseline = editor.snapshot();
        return true;
      } catch (error) {
        status.textContent = `설정을 저장하지 못했습니다: ${error?.message || error}`;
        status.scrollIntoView({ block: 'nearest' });
        return false;
      } finally {
        editor.saving = false;
        content.inert = false;
        editor.update();
      }
    };
    byId('wwis-save-generation').onclick = saveGenerationSettings;
    byId('wwis-save-generation-top').onclick = saveGenerationSettings;
    byId('wwis-settings-back').onclick = () => ImageStudio_생성설정나가기(render);

    // 동적 캐릭터·LoRA 행과 숨겨진 다른 엔진의 입력도 비교합니다. 값을 되돌리면 변경 없음으로 처리합니다.
    const editor = {
      baseline: '', saving: false, prompt: null, save: saveGenerationSettings,
      snapshot: () => JSON.stringify([...content.querySelectorAll('input,select,textarea')].map(input =>
        [input.id, input.dataset.field || '', input.type, input.value, input.checked || false])),
      dirty: () => editor.snapshot() !== editor.baseline,
      update: () => {
        if (generationSettingsEditor !== editor) return;
        const dirty = editor.dirty();
        const indicator = byId('wwis-settings-unsaved');
        const message = editor.saving ? '저장하는 중…' : dirty ? '저장되지 않은 변경사항이 있습니다.' : '모든 변경사항이 저장되어 있습니다.';
        if (indicator.textContent !== message) indicator.textContent = message;
        indicator.dataset.dirty = String(dirty);
        for (const id of ['wwis-save-generation', 'wwis-save-generation-top']) byId(id).disabled = editor.saving;
      },
      observer: new MutationObserver(() => editor.update()),
    };
    editor.baseline = editor.snapshot();
    generationSettingsEditor = editor;
    generationSettingsLoad = null;
    editor.observer.observe(content, { childList: true, subtree: true });
    editor.update();
    if (settings.imageProvider !== 'nai') {
      void refreshResources();
      void refreshPromptBatchSupport();
    }
  }

  function render() {
    if (generationSettingsEditor) return;
    generationSettingsLoad = null;
    imageStudio_refreshWifeNames();
    const settingsButton = '<button class="wwis-settings-launch" id="wwis-generation-settings">⚙ 이미지 생성 방식 지정</button><button class="wwis-settings-launch" id="wwis-prompt-edit" style="margin-top:8px">프롬프트 수정</button><button class="wwis-settings-launch" id="wwis-usage-statistics" style="margin-top:8px">이미지별 사용 통계</button>';
    if (!state.wife) {
      content.innerHTML = `${settingsButton}<div class="wwis-row"><button id="wwis-cache-sync">전체 이미지 캐시 초기화</button></div><p class="wwis-dim">전체 캐시를 실제 파일과 다시 대조하여 누락 항목과 변경된 경로를 정리합니다.</p><p id="wwis-cache-sync-result" class="wwis-dim" role="status"></p><p>인물을 선택하세요.</p><div class="wwis-row" id="wwis-people"></div><p class="wwis-dim">현재 캐릭터와 무관하게 여러 인물을 한 번에 조건부 생성할 수 있습니다.</p>`;
      content.querySelector('#wwis-generation-settings').onclick = () => { void showGenerationSettings(); };
      content.querySelector('#wwis-cache-sync').onclick = () => { void syncImageCache(); };
      content.querySelector('#wwis-cache-sync').disabled = cacheBusy;
      content.querySelector('#wwis-cache-sync-result').textContent = cacheMessage;
      taskProgress.paint('cache');
      const discoveryRow = document.createElement('div'); discoveryRow.className = 'wwis-row';
      const discoveryButton = document.createElement('button'); discoveryButton.id = 'wwis-discover-wives';
      discoveryButton.textContent = '새로운 캐릭터 찾기'; discoveryButton.disabled = state.discoverBusy;
      const discoveryStatus = document.createElement('p'); discoveryStatus.id = 'wwis-discovery-status';
      discoveryStatus.className = 'wwis-dim'; discoveryStatus.setAttribute('role', 'status');
      discoveryStatus.textContent = state.discoveryMessage || '게임에 등록된 캐릭터의 이름과 외형 프롬프트를 찾아 서버에 자동 저장합니다.';
      discoveryRow.append(discoveryButton);
      const cacheRow = content.querySelector('#wwis-cache-sync').parentElement;
      cacheRow.before(discoveryRow, discoveryStatus);
      discoveryButton.onclick = async () => {
        discoveryButton.disabled = true;
        await imageStudio_discoverWives(undefined, message => {
          if (discoveryStatus.isConnected) discoveryStatus.textContent = message;
        });
        discoveryButton.disabled = false;
        if (content.querySelector('#wwis-people')) render();
      };
      const row = content.querySelector('#wwis-people');
      const current = bridge()?.currentWife();
      for (const [id, label] of Object.entries(names)) {
        const button = document.createElement('button'); button.textContent = label + (current === id ? " · 현재 캐릭터" : '');
        button.onclick = () => choose(id); row.append(button);
      }
      return;
    }
    const summary = counts();
    content.innerHTML = `${settingsButton}<div class="wwis-row"><button id="wwis-back">← 인물 선택</button><strong>${names[state.wife] || state.wife}</strong><span>보유 이미지 ${summary.total.toLocaleString()}장</span><button id="wwis-refresh">다시 확인</button></div><div class="wwis-card wwis-counts" id="wwis-counts"></div><div class="wwis-card"><div class="wwis-row"><button id="wwis-random">▶ 전체 랜덤 생성</button><button id="wwis-conditional">▶ 조건부 생성</button></div><div id="wwis-generation"></div></div><div class="wwis-card" id="wwis-pack-card"><h3>이미지 팩 생성</h3><div class="wwis-row"><button id="wwis-pack">팩 만들기</button></div><p class="wwis-dim">images/illustrious/characters/ 아래의 일반 이미지만 취합합니다. situation 폴더는 제외합니다. 특정 그녀의 일반 이미지를 취합하여 &quot;images-[그녀 이름]-custom.js&quot;로 파일을 생성합니다. 실제 게임 인식을 위해서는 뒤의 custom을 지우고, images-[그녀 이름]-1.js 또는 images-[그녀 이름]-2.js로 변경해주세요.</p><p class="wwis-dim">캐시와 기존 이미지팩의 조건 기록을 실제 파일과 대조합니다. 같은 조건은 최신 생성 이미지 한 장을 선택하며, 조건 기록이 없는 파일은 제외합니다. 현재 게임은 번호 1과 2만 읽습니다. 기존 번호 팩이 있다면 먼저 백업한 뒤 교체하세요. JS 파일은 게임 HTML 옆에 두고 images 폴더도 함께 유지해야 합니다.</p><div class="wwis-dim" id="wwis-pack-result" role="status"></div></div><p id="wwis-message" role="status">${state.message}</p>`;
    const countLabel = content.querySelector('.wwis-row > span');
    if (countLabel) countLabel.textContent = `${state.catalogueVerified ? '보유 이미지' : '등록 이미지'} ${summary.total.toLocaleString()}장`;
    if (state.catalogueWarning) {
      const warning = document.createElement('p');
      warning.className = 'wwis-dim'; warning.textContent = state.catalogueWarning;
      content.querySelector('.wwis-row').after(warning);
    }
    content.querySelector('#wwis-pack-result').textContent = state.packResults[state.wife] || '';
    content.querySelector('#wwis-pack').disabled = state.packBusy.has(state.wife);
    content.querySelector('#wwis-generation-settings').onclick = () => { void showGenerationSettings(); };
    const countBox = content.querySelector('#wwis-counts');
    for (const [key, label] of [['situation', '장면/작업'], ['room', '장소'], ['outfit', '의상'], ['mood', '기분']]) {
      const column = document.createElement('div'), heading = document.createElement('strong'); heading.textContent = label; column.append(heading);
      for (const [value, count] of summary[key].slice(0, 16)) { const line = document.createElement('div'); line.textContent = `${value}: ${count.toLocaleString()}`; column.append(line); }
      countBox.append(column);
    }
    content.querySelector('#wwis-back').onclick = () => { state.wife = ''; state.conditionalOpen = false; state.hStatusOpen = false; render(); };
    content.querySelector('#wwis-refresh').onclick = () => { void refresh(true); };
    const characterCacheButton = document.createElement('button');
    characterCacheButton.id = 'wwis-character-cache-sync';
    characterCacheButton.textContent = '이미지 캐시 초기화';
    characterCacheButton.title = `${names[state.wife] || state.wife}의 캐시만 실제 파일과 다시 대조합니다.`;
    characterCacheButton.disabled = cacheBusy;
    characterCacheButton.onclick = () => { void syncImageCache(state.wife); };
    content.querySelector('#wwis-refresh').after(characterCacheButton);
    const cacheResult = document.createElement('p');
    cacheResult.id = 'wwis-cache-sync-result'; cacheResult.className = 'wwis-dim';
    cacheResult.setAttribute('role', 'status'); cacheResult.textContent = cacheMessage;
    characterCacheButton.parentElement.after(cacheResult);
    taskProgress.paint('cache');
    content.querySelector('#wwis-random').onclick = () => {
      overlay.hidden = true;
      if (bridge()?.openRandom) bridge().openRandom(state.wife);
      else { overlay.hidden = false; setMessage('WML에서 이미지 스튜디오 연결을 불러오지 못했습니다. 모드 관리 창에서 이미지 스튜디오를 껐다 켜고 게임을 새로 시작해 주세요.'); }
    };
    content.querySelector('#wwis-conditional').onclick = () => { void showConditional(); };
    const hStatusButton = document.createElement('button');
    hStatusButton.id = 'wwis-h-status'; hStatusButton.textContent = '▶ H_status용 이미지 생성';
    content.querySelector('#wwis-conditional').after(hStatusButton);
    hStatusButton.onclick = () => { if (!state.busy) void ImageStudio_HStatus설정열기(); };
    content.querySelector('#wwis-pack').onclick = () => { void buildPack(); };
    if (state.hStatusOpen) void ImageStudio_HStatus설정열기();
    else if (state.conditionalOpen) void showConditional();
  }

  async function ImageStudio_HStatus설정열기() {
    const box = content.querySelector('#wwis-generation'), characterId = state.wife;
    state.hStatusOpen = true; state.conditionalOpen = false;
    const regularPack = content.querySelector('#wwis-pack-card'); if (regularPack) regularPack.hidden = true;
    await ImageStudio_HStatus설정그리기({ box, bridge: bridge(), characterId, name: names[characterId] || characterId,
      selection: hStatusSelections[characterId] ||= {},
      isCurrent: () => box.isConnected && state.wife === characterId && state.hStatusOpen,
      isBusy: () => state.busy,
      setBusy: value => {
        state.busy = value;
        for (const id of ['wwis-back', 'wwis-refresh', 'wwis-random', 'wwis-conditional', 'wwis-h-status', 'wwis-generation-settings', 'wwis-prompt-edit']) {
          const button = content.querySelector('#' + id); if (button) button.disabled = value;
        }
      }, taskProgress, setMessage, buildPack: buildHStatusPack });
  }

  function optionLabel(axis, item, includeId = true) {
    const value = String(item.value);
    if(axis==='room'&&value==='bedroom (침대 위)')return '침실 · 침대 위' + (includeId ? ' (bedroom, abed=1)' : '');
    let label = item.label || '';
    if (axis === 'situation' && situationGroup(value, item.kind) === 'contact_patron') {
      label = label.replace(/^(?:Patron[\s:_-]*|손님(?:과|의|에게서?|이)?\s*)/i, '');
    }
    if (label) return label + (includeId ? ` (${value})` : '');
    if (axis === 'character') return names[value] || value;
    if (axis === 'mood') return moodLabels[value] || value;
    if (axis === 'aftermath') return `${value} — ${aftermathLabels[value] || value}`;
    if (axis === 'exposure') {
      if (value === 'none') return '없음 (exp 키 없음)';
      const active = [...value].map((bit, index) => bit === '1' ? exposureFields[index] : '').filter(Boolean);
      return `exp-${value} — ${active.join(' · ') || '노출 없음'}`;
    }
    if (axis === 'roles') return `gslot-${value} — ${[...value].map((code, index) => `남성 ${index + 1}: ${roleLabels[code] || code}`).join(', ')}`;
    return value;
  }

  async function showConditional() {
    const box = content.querySelector('#wwis-generation'), wife = state.wife;
    state.hStatusOpen = false;
    const regularPack = content.querySelector('#wwis-pack-card'); if (regularPack) regularPack.hidden = false;
    state.conditionalOpen = true; box.textContent = '게임의 이미지 조건 목록을 읽는 중…';
    const b = bridge();
    if (!b?.axes || !b?.list) { box.textContent = 'WML 조건 생성 연결을 불러오지 못했습니다. 모드 관리 창에서 이미지 스튜디오를 껐다 켜고 게임을 새로 시작해 주세요.'; return; }
    let promptAxes;
    try {
      promptAxes = globalThis.WW_ImageStudioPrompt?.axes?.() || [];
      for (const extra of promptAxes) if (!axisDefs.some(([axis]) => axis === extra.id)) axisDefs.push([extra.id,extra.label]);
      // Conditions come from the game. File verification updates separately
      // and must never prevent this panel from opening.
      state.options = axesWithCatalogue(b.axes());
      for (const extra of promptAxes) state.options[extra.id] = extra.items;
    }
    catch (error) { box.textContent = `이미지 조건을 읽지 못했습니다: ${error?.message || error}`; return; }
    if (!box.isConnected || state.wife !== wife) return;
    for (const [axis] of axisDefs) {
      const values = (state.options[axis] || []).map(item => String(item.value));
      if (!state.selected[axis]) state.selected[axis] = new Set(defaultsFor(axis, values, wife));
      else state.selected[axis] = new Set([...state.selected[axis]].filter(value => values.includes(value)));
      if (axis.startsWith('prompt') && !state.selected[axis].size) state.selected[axis].add('auto');
    }

    box.innerHTML = `<div class="wwis-source"><div class="wwis-row"><label>구성 원본 <select id="wwis-source"><option value="">직접 선택한 조건 조합</option></select></label></div><p class="wwis-dim">원본 인물을 고르면 그 인물이 실제로 보유한 구성 키만 대상 인물의 프롬프트로 다시 만듭니다. 외형만 대상 인물로 바뀌며, 대상에 이미 같은 구성이 있으면 선택한 중복 기준에 따라 제외됩니다.</p></div><details id="wwis-details" open><summary>세부 조건 <span id="wwis-actions"></span></summary><div id="wwis-axes"></div></details><div class="wwis-row"><button id="wwis-enqueue-new">선택 조건 중 미중복 파일 대기열에 추가</button><span class="wwis-random-enqueue"><button id="wwis-enqueue-random">선택 조건 중 임의의 조합 대기열에 추가</button><label>수량 <input id="wwis-random-count" type="number" min="1" max="120000" step="1" value="${state.randomCount}"></label></span></div><p class="wwis-dim">만들 구도(v-0~v-3)를 직접 선택합니다. 첫 버튼은 팩·로컬 캐시의 중복을 뺀 전체 조합을 만듭니다. 두 번째 버튼은 조합을 먼저 추첨하고 뽑힌 프롬프트만 계산하며, 중복은 다른 조합으로 보충합니다. 탐색 한도나 후보 부족으로 수량을 채우지 못하면 확보한 수량과 이유를 표시합니다.</p><div class="wwis-card"><strong>보유/중복 검사</strong><div class="wwis-row"><label>중복 기준 <select id="wwis-duplicate-mode"><option value="composition">기본 구성</option><option value="prompt-key">프롬프트 키 포함</option></select></label></div><p class="wwis-dim">기본 구성은 인물·장면/작업·의상·장소·기분·남성 수(grp)·역할(gslot)·노출(exp)·사후 상태(aft)·구도(v)·침대·마무리 상태를 비교합니다. 현재 상태나 프롬프트 수정으로 붙은 서명이 달라도 같은 구성은 보유로 처리합니다. 자세·상태·대화 등 프롬프트 서명별로 새 이미지를 만들려면 “프롬프트 키 포함”을 선택하세요.</p><div id="wwis-duplicate-report" class="wwis-dim">아직 검사하지 않았습니다.</div></div>`;
    const source = box.querySelector('#wwis-source');
    for (const [id, label] of Object.entries(names)) source.add(new Option(label, id));
    source.value = state.cloneSource;
    source.onchange = () => { state.cloneSource = source.value; selectionChanged(); };
    const duplicateMode = box.querySelector('#wwis-duplicate-mode');
    duplicateMode.value = state.duplicateMode;
    duplicateMode.onchange = () => { state.duplicateMode = duplicateMode.value; selectionChanged(); };

    const actions = box.querySelector('#wwis-actions');
    for (const [label, all] of [['모두 선택', true], ['모두 해제', false]]) {
      const button = document.createElement('button'); button.textContent = label; button.style.marginLeft = '5px';
      button.onclick = event => {
        event.preventDefault(); event.stopPropagation();
        for (const [axis] of axisDefs) setAxisSelection(axis, all ? state.options[axis].map(item => String(item.value)) : axis.startsWith('prompt') ? ['auto'] : []);
        selectionChanged();
      };
      actions.append(button);
    }

    const axesHost = box.querySelector('#wwis-axes');
    const extraSections = new Map();
    const extraNote = document.createElement('p'); extraNote.className = 'wwis-dim';
    extraNote.textContent = '프롬프트 세부 조건은 아래 접힌 영역에서 고릅니다. 같은 항목에서 여러 값을 선택하면 각각 별도 조합으로 생성합니다. 자세·체위는 어울리는 장면에만 적용되고, 맞지 않는 장면에서는 원래 장면 프롬프트를 유지합니다. 명시한 나쁜 손님 모드용·상세 상태 영역은 자동 판정 대신 선택값을 사용합니다. H Status와 출산 후 처치 장면은 추가 장면/작업에 모아 표시하며, H Status와 대화의 착의 조건도 적용합니다.';
    const idGuide = document.createElement('span'); idGuide.className = 'wwis-id-guide';
    idGuide.append(document.createTextNode('제목 옆의 주황 글씨는 게임에서 인식하는 ID이며, '));
    const vanillaGuide = document.createElement('span'); vanillaGuide.className = 'wwis-id-guide-vanilla'; vanillaGuide.textContent = '바닐라ID는 주황';
    const modGuide = document.createElement('span'); modGuide.className = 'wwis-id-guide-mod'; modGuide.textContent = '모드ID는 노란색입니다';
    idGuide.append(vanillaGuide, document.createTextNode(', '), modGuide);
    extraNote.append(document.createElement('br'), idGuide);
    axesHost.append(extraNote);
    function setAxisSelection(axis, values) {
      state.selected[axis] = new Set(values.map(String));
      for (const input of axesHost.querySelectorAll(`input[type="checkbox"][data-axis="${axis}"]`)) {
        input.checked = state.selected[axis].has(input.dataset.value);
      }
    }
    function selectionChanged() { state.lastPlan = null; saveConditions(); renderDuplicateAudit(null); }
    for (const [axis, label] of axisDefs) {
      const card = document.createElement('div'); card.className = 'wwis-card';
      const extra = promptAxes.find(extra => extra.id === axis);
      const heading = document.createElement('strong'); heading.textContent = label;
      const axisActions = document.createElement('span'); axisActions.className = 'wwis-axis-actions';
      for (const [text, all] of [['모두 선택', true], ['모두 해제', false]]) {
        const button = document.createElement('button'); button.type = 'button'; button.textContent = text;
        button.onclick = event => {
          event.preventDefault(); event.stopPropagation();
          setAxisSelection(axis, all ? state.options[axis].map(item => String(item.value)) : axis.startsWith('prompt') ? ['auto'] : []);
          selectionChanged();
        };
        axisActions.append(button);
      }
      card.append(heading, axisActions);
      const grid = document.createElement('div'); grid.className = axis === 'situation' ? 'wwis-situation-groups' : 'wwis-grid';
      const appendOption = (item, host, groupId = '') => {
        const value = String(item.value), row = document.createElement('label'), input = document.createElement('input');
        input.type = 'checkbox'; input.dataset.axis = axis; input.dataset.value = value; input.checked = state.selected[axis].has(value);
        input.dataset.idOrigin = b.idOrigin(axis,value);
        if (groupId) input.dataset.situationGroup = groupId;
        input.onchange = () => {
          if (input.checked) {
            if (axis.startsWith('prompt') && value !== 'auto' && state.selected[axis].size === 1 && state.selected[axis].has('auto')) state.selected[axis].delete('auto');
            state.selected[axis].add(value);
          } else state.selected[axis].delete(value);
          if (axis.startsWith('prompt')) setAxisSelection(axis,state.selected[axis].size ? [...state.selected[axis]] : ['auto']);
          selectionChanged();
        };
        row.append(input, document.createTextNode(optionLabel(axis, item, false))); host.append(row);
      };
      if (axis === 'situation') {
        for (const [groupId, groupLabel] of situationGroupDefs) {
          const items = state.options[axis].filter(item => situationGroup(item.value, item.kind) === groupId);
          if (!items.length) continue;
          const group = document.createElement('div'); group.className = 'wwis-situation-group';
          const groupHead = document.createElement('div'); groupHead.className = 'wwis-situation-group-head';
          const groupTitle = document.createElement('strong'); groupTitle.textContent = `${groupLabel} (${items.length})`; groupHead.append(groupTitle);
          const values = items.map(item => String(item.value));
          for (const [text, all] of [['그룹 선택', true], ['그룹 해제', false]]) {
            const button = document.createElement('button'); button.type = 'button'; button.textContent = text;
            button.onclick = event => {
              event.preventDefault(); event.stopPropagation();
              for (const value of values) all ? state.selected[axis].add(value) : state.selected[axis].delete(value);
              setAxisSelection(axis, [...state.selected[axis]]); selectionChanged();
            };
            groupHead.append(button);
          }
          const groupGrid = document.createElement('div'); groupGrid.className = 'wwis-grid';
          for (const item of items) appendOption(item, groupGrid, groupId);
          group.append(groupHead, groupGrid); grid.append(group);
        }
      } else {
        for (const item of state.options[axis]) appendOption(item, grid);
      }
      card.append(grid);
      if (extra) {
        if (!extraSections.has(extra.section)) {
          const section = document.createElement('details'); section.className = 'wwis-card'; section.dataset.promptSection = extra.section;
          const summary = document.createElement('summary'); summary.textContent = extra.section; section.append(summary); axesHost.append(section); extraSections.set(extra.section,section);
        }
        extraSections.get(extra.section).append(card);
      } else axesHost.append(card);
    }
    const randomCount = box.querySelector('#wwis-random-count');
    randomCount.onchange = () => {
      state.randomCount = Math.max(1, Math.min(120000, Math.floor(Number(randomCount.value) || 1)));
      randomCount.value = String(state.randomCount);
    };
    box.querySelector('#wwis-enqueue-new').onclick = () => { void enqueueSelection(); };
    box.querySelector('#wwis-enqueue-random').onclick = () => { randomCount.onchange(); void enqueueSelection(state.randomCount); };
    box.querySelector('#wwis-enqueue-new').disabled = state.busy;
    box.querySelector('#wwis-enqueue-random').disabled = state.busy;
    const cancelButton = document.createElement('button');
    cancelButton.id = 'wwis-plan-cancel'; cancelButton.textContent = '취소하기';
    cancelButton.style.cssText = 'margin-top:8px;display:none';
    cancelButton.onclick = () => { planningController?.abort(); paintPlanningCancel(); };
    box.querySelector('#wwis-enqueue-new').parentElement.after(cancelButton);
    paintPlanningCancel();
    taskProgress.paint('generation');
  }

  const valuesOf = (selected, axis) => {
    const values = selected[axis];
    const list = values instanceof Set ? [...values] : Array.isArray(values) ? values : [];
    return axis === 'exposure' ? [...new Set(list.map(value => ImageStudio_노출코드정규화하기(value) || 'none'))] : list;
  };
  const selectionForBridge = selected => Object.fromEntries(axisDefs.filter(([axis]) => axis !== 'character').map(([axis]) => [axis, valuesOf(selected, axis)]));

  const createDuplicateAudit = () => Object.fromEntries(axisDefs.map(([axis]) => [axis, new Map()]));
  function recordDuplicateAudit(audit, talentId) {
    const axes = bridge()?.keyAxes?.(talentId);
    if (!axes) return;
    for (const [axis] of axisDefs) {
      const value = String(axes[axis] ?? 'none'), counts = audit[axis];
      counts.set(value, (counts.get(value) || 0) + 1);
    }
  }
  const imageIdentity = talentId => bridge()?.identity?.(talentId) || talentId;
  function ImageStudio_보유식별자읽기(talentId, duplicateMode) {
    return bridge()?.identity?.(talentId, duplicateMode === 'prompt-key') || talentId;
  }

  function auditValueLabel(axis, value) {
    const item = (state.options[axis] || []).find(entry => String(entry.value) === String(value));
    if (item) return optionLabel(axis, item);
    if (axis === 'roles') return value === 'none' ? '추가 역할 없음' : `gslot-${value}`;
    if (axis === 'exposure') return value === 'none' ? '노출 지정 없음' : `exp-${value}`;
    if (axis === 'variant') return `v-${value}`;
    if (axis === 'men') return `${value}명`;
    return value;
  }

  function renderDuplicateAudit(plan) {
    const node = content.querySelector('#wwis-duplicate-report');
    if (!node) return;
    node.replaceChildren();
    if (!plan) { node.textContent = '조건이 바뀌었습니다. 다음 대기열 추가 때 다시 검사합니다.'; return; }
    const summary = document.createElement('div');
    summary.textContent = `${plan.sampling ? '무작위로 검사한 범위에서 ' : ''}${plan.duplicateMode === 'prompt-key' ? '프롬프트 키 포함' : '기본 구성'} 기준 보유 ${plan.ownedDuplicates.toLocaleString()}장 · 계획 안의 동일 키 ${plan.plannedDuplicates.toLocaleString()}장 · 대기열 후보 ${plan.queue.length.toLocaleString()}장${ImageStudio_랜덤검사안내읽기(plan)}`;
    node.append(summary);
    if (!plan.ownedDuplicates) return;
    const grid = document.createElement('div'); grid.className = 'wwis-audit-grid';
    for (const [axis, label] of axisDefs) {
      const entries = [...plan.duplicateAudit[axis].entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
      if (!entries.length) continue;
      const row = document.createElement('div');
      const shown = entries.slice(0, 6).map(([value, count]) => `${auditValueLabel(axis, value)} ${count.toLocaleString()}장`);
      row.textContent = `${label}: ${shown.join(' · ')}${entries.length > 6 ? ` · 그 외 ${entries.length - 6}종` : ''}`;
      grid.append(row);
    }
    node.append(grid);
  }

  async function buildPlanFor(selected, cloneSource, progress = () => {}, duplicateMode = 'composition', signal) {
    checkPlanningCancelled(signal);
    await waitForPlanning(loadCatalogue(), signal);
    checkPlanningCancelled(signal);
    const targets = valuesOf(selected, 'character');
    if (!targets.length) throw new Error('생성할 인물을 한 명 이상 선택해 주세요.');
    for (const [axis, label] of axisDefs) if (axis !== 'character' && !axis.startsWith('prompt') && !valuesOf(selected, axis).length) throw new Error(`${label}에서 한 개 이상 선택해 주세요.`);
    const held = new Set(state.catalogue.map(entry => ImageStudio_보유식별자읽기(entry.talentName, duplicateMode)));
    const sourceTalentIds = cloneSource ? state.catalogue.filter(entry => entry.talentName?.startsWith(cloneSource + '__')).map(entry => entry.talentName) : [];
    const sourceKeys = cloneSource ? new Set(sourceTalentIds.map(signature)) : null;
    if (sourceKeys && !sourceKeys.size) throw new Error(`${names[cloneSource] || cloneSource}의 원본 구성 키를 찾지 못했습니다.`);
    const queue = [], seen = new Set(), duplicateAudit = createDuplicateAudit();
    let candidates = 0, ownedDuplicates = 0, plannedDuplicates = 0, outsideSource = 0;
    const include = item => {
      checkPlanningCancelled(signal);
      candidates++;
      const identity = imageIdentity(item.talentId);
      if (held.has(ImageStudio_보유식별자읽기(item.talentId, duplicateMode))) { ownedDuplicates++; recordDuplicateAudit(duplicateAudit, item.talentId); return; }
      if (seen.has(identity)) { plannedDuplicates++; return; }
      seen.add(identity); queue.push({ ...item, weight: bridge().weight(item.talentId) });
    };
    const detail = () => `큐 후보 ${queue.length.toLocaleString()}장 · 보유 중복 ${ownedDuplicates.toLocaleString()}장 · 계획 중복 ${plannedDuplicates.toLocaleString()}장`;
    if (sourceKeys) {
      if (!bridge().fromKey) throw new Error('WML 구성 복제 연결을 불러오지 못했습니다. 모드 관리 창에서 이미지 스튜디오를 껐다 켜고 게임을 새로 시작해 주세요.');
      const filtered = sourceTalentIds.filter(key => matchesSelection(key, selected));
      const details = globalThis.WW_ImageStudioPrompt?.combinationSpace?.(selectionForBridge(selected));
      const detailCount = details?.count ?? 1n;
      if (detailCount > 120000n) throw new Error('세부 조건 조합이 120,000개를 넘었습니다. 선택을 줄여 주세요.');
      let processed = 0;
      const report = () => progress({ stage: 'clone', label: '원본 구성 확인', current: processed, total: (BigInt(filtered.length * targets.length) * detailCount).toString(), detail: detail() });
      report();
      const checkpoint = ImageStudio_계산묶음만들기(report, signal);
      for (const target of targets) {
        for (let index = 0; index < filtered.length; index++) {
          for (let detailIndex = 0n; detailIndex < detailCount; detailIndex++) {
            checkPlanningCancelled(signal);
            const talentId = target + signature(filtered[index]);
            const items = bridge().fromKey(target, talentId, selectionForBridge(selected), true, details?.at(detailIndex));
            if (!items?.length) outsideSource++;
            for (const item of items || []) include(item);
            const pause = checkpoint(++processed);
            if (pause) await pause;
          }
        }
      }
      report();
      queue.sort((a, b) => (b.weight || 0) - (a.weight || 0) || a.talentId.localeCompare(b.talentId));
      return { queue, candidates, duplicates: ownedDuplicates + plannedDuplicates, ownedDuplicates, plannedDuplicates, duplicateAudit, outsideSource, sourceCount: sourceKeys.size, duplicateMode };
    }
    for (const [targetIndex, target] of targets.entries()) {
      checkPlanningCancelled(signal);
      const label = `${names[target] || target} · 인물 ${targetIndex + 1}/${targets.length}`;
      progress({ stage: `plan-${targetIndex}`, label: `${label} · 전체 조합 계산`, current: 0, total: null });
      const items = await waitForPlanning(bridge().list(target, selectionForBridge(selected), status => { checkPlanningCancelled(signal); progress({
        stage: `plan-${targetIndex}`, label: `${label} · 전체 조합 계산`, current: status.current, total: status.total,
        detail: `프롬프트 후보 ${status.candidates.toLocaleString()}장`,
      }); }, signal), signal);
      checkPlanningCancelled(signal);
      const report = current => progress({ stage: `duplicates-${targetIndex}`, label: `${label} · 보유/중복 확인`, current, total: items.length, detail: detail() });
      report(0);
      const checkpoint = ImageStudio_계산묶음만들기(report, signal);
      for (let index = 0; index < items.length; index++) {
        include(items[index]);
        const pause = checkpoint(index + 1);
        if (pause) await pause;
      }
      report(items.length);
    }
    queue.sort((a, b) => (b.weight || 0) - (a.weight || 0) || a.talentId.localeCompare(b.talentId));
    return { queue, candidates, duplicates: ownedDuplicates + plannedDuplicates, ownedDuplicates, plannedDuplicates, duplicateAudit, outsideSource, sourceCount: sourceKeys?.size || 0, duplicateMode };
  }

  const buildPlan = () => buildPlanFor(state.selected, state.cloneSource, generationProgress, state.duplicateMode);

  function ImageStudio_랜덤정수뽑기(limit) {
    if (limit <= 0n) throw Error('추첨할 조합이 없습니다.');
    if (limit === 1n) return 0n;
    const bits = (limit - 1n).toString(2).length;
    let value;
    do {
      value = 0n;
      for (let remaining = bits; remaining > 0; remaining -= 26) {
        const width = Math.min(26,remaining);
        value = (value << BigInt(width)) | BigInt(Math.floor(Math.random() * 2 ** width));
      }
    } while (value >= limit);
    return value;
  }

  async function ImageStudio_랜덤생성계획하기(selected, cloneSource, requested, progress = () => {}, duplicateMode = 'composition', signal) {
    checkPlanningCancelled(signal);
    selected = Object.fromEntries(Object.keys(selected).map(axis => [axis,valuesOf(selected,axis)]));
    const bridgeSelected = Object.fromEntries(Object.entries(selected).filter(([axis]) => axis !== 'character'));
    const targets = valuesOf(selected,'character');
    if (!targets.length) throw Error('생성할 인물을 한 명 이상 선택해 주세요.');
    for (const [axis,label] of axisDefs) if (axis !== 'character' && !axis.startsWith('prompt') && !valuesOf(selected,axis).length) throw Error(`${label}에서 한 개 이상 선택해 주세요.`);
    const b = bridge(), prompt = globalThis.WW_ImageStudioPrompt;
    if (!b?.randomSpace || !prompt?.combinationSpace) throw Error('랜덤 생성 연결을 불러오지 못했습니다. 게임을 새로고침해 주세요.');
    requested = Math.max(1,Math.min(120000,Math.floor(Number(requested) || 1)));
    await waitForPlanning(loadCatalogue(), signal);
    checkPlanningCancelled(signal);
    const held = new Set(state.catalogue.map(entry => ImageStudio_보유식별자읽기(entry.talentName,duplicateMode)));
    const sourceKeys = cloneSource ? [...new Set(state.catalogue.filter(entry => entry.talentName?.startsWith(cloneSource + '__')).map(entry => entry.talentName))] : null;
    if (sourceKeys && !sourceKeys.length) throw Error(`${names[cloneSource] || cloneSource}의 원본 구성 키를 찾지 못했습니다.`);
    const filteredSources = sourceKeys?.filter(key => matchesSelection(key,selected));
    const details = prompt.combinationSpace(bridgeSelected), spaces = [];
    let baseCount = 0n;
    for (const wife of targets) {
      checkPlanningCancelled(signal);
      const space = b.randomSpace(wife,bridgeSelected,filteredSources);
      if (!space.count) continue;
      baseCount += space.count; spaces.push({wife,space,end:baseCount});
    }
    const total = baseCount * details.count, swaps = new Map(), seen = new Set(), queue = [], duplicateAudit = createDuplicateAudit();
    let remaining = total, attempts = 0, candidates = 0, ownedDuplicates = 0, plannedDuplicates = 0, outsideSource = 0;
    const attemptLimit = Math.min(300000,Math.max(2000,requested * 20));
    let stopReason = '';
    const report = () => progress({ stage: 'random', label: '랜덤 생성 목표 확보', current: queue.length, total: requested, unit: '장',
      detail: `${attempts.toLocaleString()}개 조합 검사 · 보유 중복 ${ownedDuplicates.toLocaleString()}장 · 계획 중복 ${plannedDuplicates.toLocaleString()}장 · 전체 후보 공간 ${total.toLocaleString()}개` });
    report();
    const checkpoint = ImageStudio_계산묶음만들기(report, signal);
    while (remaining && queue.length < requested) {
      checkPlanningCancelled(signal);
      if (attempts >= attemptLimit) { stopReason = 'attempts'; break; }
      // 느린 프롬프트도 목표 수량까지 계속합니다. 화면 응답과 취소는 checkpoint에서 처리합니다.
      // 전체 배열 대신 방문한 슬롯만 기록하는 비복원 추첨입니다.
      const position = ImageStudio_랜덤정수뽑기(remaining), last = remaining - 1n;
      const slot = swaps.get(position) ?? position;
      if (position !== last) swaps.set(position,swaps.get(last) ?? last);
      swaps.delete(last); remaining = last; attempts++;
      const baseIndex = slot / details.count, detailIndex = slot % details.count;
      let low = 0, high = spaces.length - 1;
      while (low < high) { const middle = (low + high) >>> 1; if (baseIndex < spaces[middle].end) high = middle; else low = middle + 1; }
      const entry = spaces[low], offset = baseIndex - (low ? spaces[low - 1].end : 0n);
      const items = entry.space.build(offset,details.at(detailIndex)); candidates += items.length;
      if (!items.length) outsideSource++;
      for (const item of items) {
        if (held.has(ImageStudio_보유식별자읽기(item.talentId,duplicateMode))) { ownedDuplicates++; recordDuplicateAudit(duplicateAudit,item.talentId); continue; }
        const identity = imageIdentity(item.talentId);
        if (seen.has(identity)) { plannedDuplicates++; continue; }
        seen.add(identity); queue.push({...item,weight:b.weight(item.talentId)});
        if (queue.length >= requested) break;
      }
      const pause = checkpoint(attempts);
      if (pause) await pause;
    }
    report();
    checkPlanningCancelled(signal);
    queue.sort((a,b) => (b.weight || 0) - (a.weight || 0) || a.talentId.localeCompare(b.talentId));
    return {queue,candidates,ownedDuplicates,plannedDuplicates,duplicates:ownedDuplicates + plannedDuplicates,duplicateAudit,outsideSource,sourceCount:sourceKeys?.length || 0,duplicateMode,
      sampling:{requested,attempts,slotCount:total.toString(),exhausted:remaining === 0n,limited:!!stopReason,stopReason}};
  }

  function ImageStudio_랜덤검사안내읽기(plan) {
    const sample = plan.sampling;
    if (!sample) return '';
    const reason = sample.limited ? ' · 탐색 한도에 도달했습니다. 미보유 후보가 더 없다는 뜻은 아닙니다. 조건을 좁히거나 다시 추첨할 수 있습니다.'
      : plan.queue.length < sample.requested ? ' · 선택한 조합을 모두 확인했으며 요청 수량을 채울 미중복 후보가 부족합니다.' : '';
    return ` · 랜덤 요청 ${sample.requested.toLocaleString()}장 중 ${plan.queue.length.toLocaleString()}장 확보 · ${sample.attempts.toLocaleString()}개 조합 검사${reason}`;
  }

  async function enqueueSelection(randomCount = null) {
    if (state.busy) return;
    const b = bridge(), url = b?.connection()?.baseUrl;
    if (!url) { setMessage('이미지 생성 서버에 연결해 주세요.'); return; }
    if (!b.connection()?.comfyui) { setMessage('이미지 서버와 선택한 생성 방식의 연결을 확인한 뒤 시작해 주세요.'); return; }
    state.busy = true; setMessage('선택 조합과 중복을 확인하는 중…');
    const controller = new AbortController();
    planningController = controller;
    paintPlanningCancel();
    const selected = Object.fromEntries(Object.entries(state.selected).map(([axis, values]) => [axis, valuesOf(state.selected, axis)]));
    const cloneSource = state.cloneSource, duplicateMode = state.duplicateMode;
    taskProgress.update('generation', { restart: true, stage: 'catalogue', label: '보유 이미지 목록 확인', current: 0, total: null });
    const busyButtons = ['wwis-enqueue-new', 'wwis-enqueue-random', 'wwis-back', 'wwis-refresh', 'wwis-conditional', 'wwis-random', 'wwis-h-status', 'wwis-generation-settings', 'wwis-prompt-edit'];
    for (const id of busyButtons) { const button = content.querySelector('#' + id); if (button) button.disabled = true; }
    let failed = false, cancelled = false;
    try {
      const plan = randomCount === null ? await buildPlanFor(selected, cloneSource, generationProgress, duplicateMode, controller.signal) : await ImageStudio_랜덤생성계획하기(selected, cloneSource, randomCount, generationProgress, duplicateMode, controller.signal);
      await waitForPlanning(new Promise(resolve => setTimeout(resolve, 0)), controller.signal);
      checkPlanningCancelled(controller.signal);
      state.lastPlan = plan; renderDuplicateAudit(plan);
      const sourceText = cloneSource ? ` · 원본 ${plan.sourceCount.toLocaleString()}개 구성과 비교` : '';
      if (!plan.queue.length) { setMessage(`${plan.sampling?.limited ? '탐색한 범위에서 새로 만들 이미지를 찾지 못했습니다.' : '새로 만들 이미지가 없습니다.'} 선택한 기준으로 보유 ${plan.ownedDuplicates.toLocaleString()}장, 계획 내 동일 키 ${plan.plannedDuplicates.toLocaleString()}장을 확인했습니다${ImageStudio_랜덤검사안내읽기(plan)}${sourceText}.`); return; }
      const queue = plan.queue;
      planningController = null;
      paintPlanningCancel();
      setMessage(`${queue.length.toLocaleString()}장을 대기열로 보내는 중…`);
      const report = progress => {
        const detail = `서버 접수 ${(progress.accepted || 0).toLocaleString()}장 · 서버 캐시 중복 ${(progress.alreadyCached || 0).toLocaleString()}장 · 기존 큐 중복 ${(progress.alreadyQueued || 0).toLocaleString()}장`;
        taskProgress.update('generation', { stage: 'queue', label: '서버 큐로 전송', current: progress.sent, total: queue.length, unit: '장', detail });
        setMessage(`${queue.length.toLocaleString()}장 중 ${progress.sent.toLocaleString()}장을 서버에 전달했습니다. ${detail}`);
      };
      report({ sent: 0 });
      const result = await b.enqueue(queue, report);
      report({ sent: queue.length, ...result });
      state.lastPlan = null;
      const randomText = ImageStudio_랜덤검사안내읽기(plan);
      const queuedText = result.alreadyQueued ? `, 중복 전송 ${result.alreadyQueued.toLocaleString()}장` : '';
      setMessage(`${result.accepted.toLocaleString()}장을 대기열에 추가했습니다. 선택한 기준으로 보유 ${plan.ownedDuplicates.toLocaleString()}장, 계획 내 동일 키 ${plan.plannedDuplicates.toLocaleString()}장, 서버 캐시 중복 ${result.alreadyCached.toLocaleString()}장${queuedText}을 제외했습니다${randomText}${sourceText}.`);
    } catch (error) {
      cancelled = error?.name === 'AbortError';
      failed = !cancelled;
      if (cancelled) state.lastPlan = null;
      setMessage(cancelled ? '조합 계산을 취소했습니다. 이번 작업은 서버 대기열에 추가하지 않았습니다.' : String(error?.message || error));
    }
    finally {
      planningController = null;
      paintPlanningCancel();
      state.busy = false;
      taskProgress.finish('generation', state.message, failed, cancelled);
      for (const id of busyButtons) { const button = content.querySelector('#' + id); if (button) button.disabled = false; }
    }
  }

  async function syncImageCache(character = null) {
    if (cacheBusy) return;
    const url = bridge()?.connection()?.baseUrl;
    const button = content.querySelector(character ? '#wwis-character-cache-sync' : '#wwis-cache-sync');
    const result = content.querySelector('#wwis-cache-sync-result');
    if (!url) { result.textContent = '이미지 생성 서버에 연결해 주세요. Start_ImageStudio.cmd를 먼저 실행하세요.'; return; }
    const scopeLabel = character ? `${names[character] || character} 이미지 캐시 초기화` : '전체 이미지 캐시 초기화';
    cacheBusy = true;
    button.disabled = true; result.textContent = cacheMessage = '실제 파일과 캐시를 대조하는 중…';
    taskProgress.update('cache', { restart: true, stage: 'connect', label: scopeLabel + ' · 서버 연결', current: 0, total: null });
    let failed = false;
    try {
      const endpoint = character ? '/api/image-cache/sync-character?progress=1&character=' + encodeURIComponent(character) : '/api/image-cache/sync?progress=1';
      const response = await fetch(url + endpoint, { method: 'POST', credentials: 'omit' });
      if (character && response.status === 404) throw new Error("캐릭터별 캐시 초기화를 지원하는 새 이미지 서버로 다시 실행해 주세요.");
      const body = await ImageStudio_캐시진행응답읽기(response, progress => {
        const labels = { scan: '이미지 폴더 목록 읽기', check: '캐시 항목 대조', save: '변경 사항 저장', legacy: '캐시 대조 · 기존 서버 응답 대기' };
        taskProgress.update('cache', { stage: progress.phase, label: scopeLabel + ' · ' + (labels[progress.phase] || progress.phase),
          current: progress.processed ?? 0, total: ['check', 'save'].includes(progress.phase) ? progress.total : null,
          detail: progress.phase === 'legacy' ? '실제 처리 건수 표시는 서버 0.4.5 이상에서 지원합니다.' : `유지 ${(progress.kept || 0).toLocaleString()}개 · 경로 복원 ${(progress.relinked || 0).toLocaleString()}개 · 누락 ${(progress.missing || 0).toLocaleString()}개` });
      });
      state.lastPlan = null;
      taskProgress.update('cache', { stage: 'catalogue', label: scopeLabel + ' · 화면 목록 갱신', current: 0, total: null });
      await loadCatalogue(true);
      cacheMessage = `${scopeLabel}: ${body.before.toLocaleString()}개 → ${body.after.toLocaleString()}개 · WebP 경로 ${(body.relinked || 0).toLocaleString()}개를 다시 연결하고 파일이 없는 항목 ${body.removed.toLocaleString()}개를 제거했습니다.${body.backupPath ? ` 기존 캐시 백업: ${body.backupPath}` : ''} 이미 제거된 항목은 모드 폴더의 Repair_WebP_Cache.cmd로 백업에서 복원할 수 있습니다.`;
      if (state.wife && !state.busy) render();
      taskProgress.update('cache', { stage: 'complete', label: scopeLabel, current: body.before, total: body.before });
    } catch (error) { failed = true; cacheMessage = `${scopeLabel}에 실패했습니다: ${error?.message || error}`; }
    finally {
      cacheBusy = false;
      taskProgress.finish('cache', cacheMessage, failed);
      const liveResult = content.querySelector('#wwis-cache-sync-result'), liveButton = content.querySelector('#wwis-cache-sync, #wwis-character-cache-sync');
      if (liveResult) liveResult.textContent = cacheMessage;
      if (liveButton) liveButton.disabled = false;
    }
  }

  async function buildPack() {
    const url = bridge()?.connection()?.baseUrl;
    if (!url) { setMessage('이미지 생성 서버에 연결해 주세요.'); return; }
    const wife = state.wife;
    if (state.packBusy.has(wife)) return;
    state.packBusy.add(wife);
    const setResult = text => {
      state.packResults[wife] = text;
      const node = state.wife === wife && content.querySelector('#wwis-pack-result');
      if (node) node.textContent = text;
    };
    setResult('팩 생성 중…');
    content.querySelector('#wwis-pack').disabled = true;
    try {
      const capability = await fetch(url + '/api/custom-pack/capabilities', { credentials: 'omit' });
      if (!capability.ok) throw new Error('일반 팩 생성을 지원하는 서버가 필요합니다. 진행 중인 생성을 마친 뒤 Start_ImageStudio.cmd로 서버를 다시 시작해 주세요.');
      const scope = await capability.json();
      if (scope.directory !== 'illustrious/characters/') throw new Error('현재 서버의 일반 팩 생성 범위를 확인할 수 없습니다. 최신 ImageStudio 서버로 다시 시작해 주세요.');
      const response = await fetch(url + '/api/custom-pack/build', { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'omit', body: JSON.stringify({ wife }) });
      if (response.status === 404) throw new Error('현재 실행 중인 서버에 팩 생성 API가 없습니다. 업데이트한 Start_ImageStudio.cmd로 서버를 다시 시작해 주세요.');
      const body = await response.json(); if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
      setResult(`${body.images.toLocaleString()}개 조건 · 없는 파일 ${body.missingFiles.toLocaleString()}개 제외 · 조건 미등록 파일 ${body.unindexedFiles.toLocaleString()}개 제외 · 생성 파일: ${body.file} · 파일명을 번호 팩으로 변경한 뒤 게임을 새로고침하세요.${body.backupPath ? ` 이전 custom 팩 백업: ${body.backupPath}` : ''}${body.warnings?.length ? ` · 참고: ${body.warnings.join(' / ')}` : ''}`);
      await loadCatalogue();
    } catch (error) { setResult(String(error?.message || error)); }
    finally {
      state.packBusy.delete(wife);
      const button = state.wife === wife && content.querySelector('#wwis-pack');
      if (button) button.disabled = false;
    }
  }

  async function buildHStatusPack(character = state.wife) {
    const url = bridge()?.connection()?.baseUrl;
    if (!url) throw new Error('이미지 생성 서버에 연결해 주세요.');
    const response = await fetch(url + '/api/h-status-pack/build', { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'omit', body: JSON.stringify({ character }) });
    if (response.status === 404) throw new Error('현재 실행 중인 서버에 H_Status 팩 생성 API가 없습니다. 업데이트한 Start_ImageStudio.cmd로 서버를 다시 시작해 주세요.');
    const body = await response.json();
    if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
    try {
      const key = 'h-status-image-pack-characters-v1';
      const saved = JSON.parse(localStorage.getItem(key) || '[]');
      localStorage.setItem(key, JSON.stringify([...new Set([...(Array.isArray(saved) ? saved : []), character])]));
    } catch (_) {}
    await loadCatalogue(true);
    return `${body.images.toLocaleString()}개 H_Status 이미지 · 없는 파일 ${body.missingFiles.toLocaleString()}개 제외 · 생성 파일: ${body.file}${body.backupPath ? ` · 이전 팩 백업: ${body.backupPath}` : ''} · 게임을 새로고침하면 적용됩니다.`;
  }

  const openStudio = () => { overlay.hidden = false; if (!state.busy && !generationSettingsEditor && !generationSettingsLoad) { render(); void refresh(); } };
  const closeStudio = () => ImageStudio_생성설정나가기(() => { overlay.hidden = true; });
  overlay.querySelector('#wwis-close').onclick = closeStudio;
  overlay.onclick = event => { if (event.target === overlay) closeStudio(); };
  window.addEventListener('keydown', event => {
    if (event.key !== 'Escape' || overlay.hidden) return;
    if (generationSettingsEditor?.prompt) generationSettingsEditor.prompt.querySelector('#wwis-unsaved-continue').click();
    else closeStudio();
    event.preventDefault(); event.stopImmediatePropagation();
  }, true);
  api.onBack?.(() => {
    if (overlay.hidden) return false;
    if (generationSettingsEditor?.prompt) generationSettingsEditor.prompt.querySelector('#wwis-unsaved-continue').click();
    else closeStudio();
    return true;
  });
  window.WW_ImageStudio = { open: openStudio, isBusy: () => state.busy };
  // 현재 본체는 게임에서 /api/batch/enqueue로 직접 전송합니다.
  // 지원하지 않는 옛 /api/planner/* 릴레이와 주기적인 전체 목록 순회는 실행하지 않습니다.
})();

    // ---- 원본 뒤에 붙인 코드 ----
    // Put Image Studio in the game's pause menu. The pause panel is identified by
    // its stable layout: the first button under the heading is the amber Resume
    // button. This avoids depending on translated game text.
    const wwImageStudioOriginalOpen = globalThis.WW_ImageStudio?.open?.bind(globalThis.WW_ImageStudio);
    if (wwImageStudioOriginalOpen) {
      globalThis.WW_ImageStudio.open = (...args) => {
        const result = wwImageStudioOriginalOpen(...args);
        const overlay = document.getElementById('wwis-overlay');
        if (overlay) {
          // Other mods may raise the pause panel. Keep the studio above it and move
          // it to the end of <body> so equal stacking contexts cannot cover it.
          overlay.style.setProperty('z-index', '2147483647', 'important');
          document.body.append(overlay);
        }
        queueMicrotask(wwDecorateImageStudio);
        return result;
      };
    }
    
    // OutfitQueue v8.6 proved that a large image planner is much easier to use
    // when every engine key has a Korean name, a visible explanation, selection
    // counts and local filtering. Keep Image Studio's own planner, but present its
    // axes with the same level of guidance.
    const wwImageStudioUiStyle = document.createElement('style');
    wwImageStudioUiStyle.textContent = `
    #wwis-panel{width:min(1180px,97vw);background:linear-gradient(180deg,#1c1917,#151312);box-shadow:0 24px 80px #000b}
    #wwis-panel>.wwis-row:first-child{position:sticky;top:-18px;z-index:5;margin:-18px -18px 12px;padding:16px 18px 12px;background:#1c1917ee;border-bottom:1px solid #44403c;backdrop-filter:blur(8px)}
    #wwis-panel .wwis-card{background:#1c191799;border-color:#57534e}
    #wwis-panel .wwis-axis-card{padding:12px;border-color:#57534e;background:#171412}
    #wwis-panel .wwis-axis-card>strong{color:#fbbf24;font-size:14px}
    #wwis-panel .wwis-axis-count{display:inline-flex;margin-left:7px;padding:1px 7px;border:1px solid #53645d;border-radius:999px;background:#1d342e;color:#a7f3d0;font-size:11px;font-weight:600}
    #wwis-panel .wwis-axis-help{margin:7px 0 9px;color:#b9b4ae;font-size:12px;line-height:1.55}
    #wwis-panel .wwis-axis-filter{box-sizing:border-box;width:100%;margin:0 0 9px;padding:7px 9px;background:#0c0a09;border-color:#57534e}
    #wwis-panel .wwis-grid{grid-template-columns:repeat(auto-fill,minmax(245px,1fr));gap:7px;max-height:330px;padding:2px}
    #wwis-panel .wwis-option-row{box-sizing:border-box;min-height:58px;padding:7px 8px;border:1px solid #3f3a36;border-radius:6px;background:#211e1b;cursor:pointer;transition:border-color .15s,background .15s}
    #wwis-panel .wwis-option-row:hover{border-color:#a16207;background:#29231d}
    #wwis-panel .wwis-option-row:has(input:checked){border-color:#92702f;background:#302719}
    #wwis-panel .wwis-option-row input{flex:0 0 auto;margin-top:3px}
    #wwis-panel .wwis-option-copy{display:flex;min-width:0;flex-direction:column;gap:2px}
    #wwis-panel .wwis-option-heading{display:flex;flex-wrap:wrap;align-items:baseline;gap:2px 6px;min-width:0}
    #wwis-panel .wwis-option-title{color:#f5f5f4;font-size:12px;font-weight:650;overflow-wrap:anywhere}
    #wwis-panel .wwis-option-id{color:#fb923c;font-family:inherit;font-size:10.5px;font-weight:400;line-height:1.4;overflow-wrap:anywhere;min-width:0;white-space:normal}
    #wwis-panel .wwis-option-id[data-id-origin="mod"]{color:#facc15}
    #wwis-panel .wwis-id-guide{color:#facc15}
    #wwis-panel .wwis-id-guide-vanilla{color:#fb923c}
    #wwis-panel .wwis-id-guide-mod{color:#facc15}
    #wwis-panel .wwis-option-help{color:#a8a29e;font-size:10.5px;line-height:1.4;overflow-wrap:anywhere}
    #wwis-panel .wwis-guide{margin:10px 0;padding:11px 12px;border:1px solid #3f6259;border-radius:8px;background:#10231f;color:#d6eee7}
    #wwis-panel .wwis-guide>strong{display:block;margin-bottom:7px;color:#6ee7b7;font-size:14px}
    #wwis-panel .wwis-guide-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px}
    #wwis-panel .wwis-guide-grid div{padding:8px;border-radius:6px;background:#0b1816;color:#b8d8d0;font-size:11px;line-height:1.5}
    #wwis-panel .wwis-guide-grid b{display:block;color:#e4f7f1;font-size:12px;margin-bottom:2px}
    #wwis-panel .wwis-situation-group{background:#0c0a0988}
    #wwis-panel .wwis-situation-group .wwis-grid{max-height:300px}
    @media(max-width:760px){#wwis-panel .wwis-guide-grid{grid-template-columns:1fr}#wwis-panel .wwis-grid{grid-template-columns:1fr}}
    `;
    document.head.append(wwImageStudioUiStyle);
    
    function wwUpdateImageStudioCounts() {
      const overlay = document.getElementById('wwis-overlay');
      if (!overlay) return;
      for (const card of overlay.querySelectorAll('.wwis-axis-card')) {
        const inputs = [...card.querySelectorAll('input[type="checkbox"][data-axis]')];
        const count = card.querySelector('.wwis-axis-count');
        const next = `${inputs.filter(input => input.checked).length} / ${inputs.length} 선택`;
        // textContent replaces the text node even when the string is unchanged.
        // Because this panel is watched by a childList observer, writing the same
        // value on every pass would schedule decoration forever and freeze the UI.
        if (count && count.textContent !== next) count.textContent = next;
      }
    }
    
    function wwDecorateImageStudio() {
      const overlay = document.getElementById('wwis-overlay');
      const helper = globalThis.WW_ImageStudioHelp;
      if (!overlay || !helper) return;
      overlay.dataset.wmlUi = 'imagestudio';
      const axesHost = overlay.querySelector('#wwis-axes');
      if (!axesHost) return;
    
      const details = overlay.querySelector('#wwis-details');
      if (details && !details.previousElementSibling?.classList.contains('wwis-guide')) {
        const guide = document.createElement('section');
        guide.className = 'wwis-guide';
        guide.innerHTML = `<strong>조건 생성 사용법</strong><div class="wwis-guide-grid"><div><b>1. 구성 원본</b>다른 캐릭터를 고르면 그 인물이 실제로 보유한 이미지 키만 같은 조건으로 다시 만듭니다.</div><div><b>2. 조건의 교집합</b>각 칸에서 선택한 값끼리 가능한 조합만 만듭니다. 빈 칸이 하나라도 있으면 생성하지 않습니다.</div><div><b>3. 중복 제외</b>이미지 팩과 로컬 서버 캐시의 기본 구성을 비교한 뒤 없는 이미지만 대기열에 보냅니다. 프롬프트 서명까지 구분할 수도 있습니다.</div></div>`;
        details.before(guide);
      }
    
      for (const card of axesHost.querySelectorAll('.wwis-card:not(details)')) {
        const inputs = [...card.querySelectorAll('input[type="checkbox"][data-axis]')];
        if (!inputs.length) continue;
        const axis = inputs[0].dataset.axis;
        if (!card.dataset.wwEnhanced) {
          card.dataset.wwEnhanced = axis;
          card.classList.add('wwis-axis-card');
          const heading = card.querySelector(':scope > strong');
          const count = document.createElement('span');
          count.className = 'wwis-axis-count';
          heading?.after(count);
          const help = document.createElement('p');
          help.className = 'wwis-axis-help';
          help.textContent = helper.axis(axis);
          const actions = card.querySelector(':scope > .wwis-axis-actions');
          (actions || count).after(help);
    
          if (inputs.length >= 8) {
            const filter = document.createElement('input');
            filter.type = 'search';
            filter.className = 'wwis-axis-filter';
            filter.placeholder = '이 조건 안에서 검색';
            filter.setAttribute('aria-label', `${heading?.textContent || axis} 검색`);
            filter.addEventListener('input', () => {
              const query = filter.value.trim().toLocaleLowerCase('ko');
              for (const row of card.querySelectorAll('label.wwis-option-row')) row.hidden = !!query && !row.textContent.toLocaleLowerCase('ko').includes(query);
            });
            help.after(filter);
          }
        }
    
        for (const input of inputs) {
          const row = input.closest('label');
          if (!row || row.querySelector('.wwis-option-copy')) continue;
          row.classList.add('wwis-option-row');
          const current = [...row.childNodes].filter(node => node.nodeType === Node.TEXT_NODE).map(node => node.textContent).join(' ').trim();
          for (const node of [...row.childNodes]) if (node.nodeType === Node.TEXT_NODE) node.remove();
          const copy = document.createElement('span');
          copy.className = 'wwis-option-copy';
          const title = document.createElement('span');
          title.className = 'wwis-option-title';
          title.textContent = current || helper.label(input.dataset.axis, input.dataset.value);
          const heading = document.createElement('span');
          heading.className = 'wwis-option-heading';
          // The Korean runtime translates ordinary text nodes, including raw IDs.
          // CODE is its explicit skip boundary; retain the exact selectable value.
          const id = document.createElement('code');
          id.className = 'wwis-option-id';
          id.dataset.idOrigin = input.dataset.idOrigin;
          id.setAttribute('translate', 'no');
          id.dataset.i18nSkip = '';
          const value = input.dataset.value;
          id.textContent = '[' + (input.dataset.axis === 'room' && value === 'bedroom (침대 위)' ? 'bedroom, abed=1' : value) + ']';
          heading.append(title, id);
          const sexualGroup = /^(contact|sex|climax)_/.test(input.dataset.situationGroup || '');
          const description = sexualGroup ? '' : helper.describe(input.dataset.axis, input.dataset.value);
          copy.append(heading);
          if (description) {
            const small = document.createElement('small');
            small.className = 'wwis-option-help';
            small.textContent = description;
            copy.append(small);
            row.title = description;
          }
          row.append(copy);
        }
      }
      wwUpdateImageStudioCounts();
    }
    
    const wwImageStudioOverlay = document.getElementById('wwis-overlay');
    let wwImageStudioDecorateQueued = false;
    function wwScheduleImageStudioDecoration() {
      if (wwImageStudioDecorateQueued) return;
      wwImageStudioDecorateQueued = true;
      queueMicrotask(() => {
        wwImageStudioDecorateQueued = false;
        wwDecorateImageStudio();
      });
    }
    const wwImageStudioUiObserver = new MutationObserver(wwScheduleImageStudioDecoration);
    if (wwImageStudioOverlay) {
      wwImageStudioUiObserver.observe(wwImageStudioOverlay, { childList: true, subtree: true });
      wwImageStudioOverlay.addEventListener('change', () => queueMicrotask(wwUpdateImageStudioCounts));
      wwImageStudioOverlay.addEventListener('click', () => queueMicrotask(wwUpdateImageStudioCounts));
    }
    
    extensions.setReview(ImageStudio_프롬프트검수연결하기(api));
    ImageStudio_사용통계연결하기(api);

    try { api.ui.pauseSettings?.({label:{ko:'이미지 스튜디오',en:'ImageStudio settings'},attributes:{'data-ww-image-studio-menu':'1'},onClick:()=>globalThis.WW_ImageStudio?.open?.()}); } catch (error) { console.warn("[imagestudio] 공통 설정 메뉴 등록 실패: 기존 직접 삽입 방식으로 계속합니다.", error); }
    api.ui.menuSettings({ label: '이미지 스튜디오', onClick: () => globalThis.WW_ImageStudio?.open?.(),
      windowSelector:'#wwis-overlay', attributes: { 'data-ww-image-studio-menu': '1' } });
    window.addEventListener('pagehide', () => {
      wwImageStudioUiObserver.disconnect();
    }, { once: true });
  },
});
