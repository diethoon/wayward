// 게임의 xy → Kee → Jee와 같은 우선순위입니다. 탈의가 하위 단계를 포함하며 팬티 제거는 옆으로 젖힘보다 우선합니다.
// 기본 상태는 exp 키를 생략하므로 빈 문자열을 반환합니다. 잘못된 형식은 보정하지 않고 기존 검증에 넘깁니다.
function ImageStudio_노출코드정규화하기(value) {
  if(!value||value==='none'||value==='0000000')return '';
  if(!/^[01]{7}$/.test(value))return value;
  const top=value[2]==='1'?'011':value[1]==='1'?'010':value[0]==='1'?'100':'000';
  const skirt=value[4]==='1'?'11':value[3]==='1'?'10':'00';
  const panties=value[6]==='1'?'01':value[5]==='1'?'10':'00';
  return top+skirt+panties;
}
function ImageStudio_노출키정규화하기(key) {
  if(typeof key!=='string')return key;
  return key.replace(/__exp-([01]{7})(?=__|$)/g,(_,code)=>{
    const normalized=ImageStudio_노출코드정규화하기(code);
    return normalized?'__exp-'+normalized:'';
  });
}

