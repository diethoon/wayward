// Fast loops can process up to 250 items before yielding; heavy prompts yield
// sooner after 40 ms so the cancel button and browser rendering stay responsive.
function ImageStudio_계산묶음만들기(report, signal) {
  let previous = 0, deadline = performance.now() + 40;
  const checkCancelled = () => { if (signal?.aborted) throw new DOMException('조합 계산을 취소했습니다.', 'AbortError'); };
  return completed => {
    checkCancelled();
    if (completed - previous < 250 && performance.now() < deadline) return null;
    report(completed);
    checkCancelled();
    previous = completed;
    // A message task avoids nested timers' minimum delay without prioritizing
    // our continuation above other mods' timers and UI events.
    const pause = typeof MessageChannel === 'function' ? new Promise(resolve => {
      const channel = new MessageChannel();
      channel.port1.onmessage = () => { channel.port1.close(); channel.port2.close(); resolve(); };
      channel.port2.postMessage(null);
    }) : new Promise(resolve => setTimeout(resolve, 0));
    return pause.then(() => {
      checkCancelled();
      deadline = performance.now() + 40;
    });
  };
}

// Shared task display. Counters come from completed work, never a timer.
function ImageStudio_진행표시만들기(content, overlay) {
  const tasks = new Map();
  let timer = null;
  const count = value => value == null ? null : BigInt(value);
  const number = value => value.toLocaleString('ko-KR');
  const duration = seconds => {
    seconds = Math.max(0, Math.floor(seconds));
    return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`;
  };
  function paint(kind) {
    const task = tasks.get(kind);
    const anchor = content.querySelector(kind === 'cache' ? '#wwis-cache-sync, #wwis-character-cache-sync' : '#wwis-h-status-enqueue, #wwis-enqueue-new')?.parentElement;
    if (!task || !anchor) return;
    let node = content.querySelector(`#wwis-${kind}-progress`);
    if (!node) {
      node = document.createElement('div');
      node.id = `wwis-${kind}-progress`;
      node.className = 'wwis-task-progress';
      node.innerHTML = '<strong data-title></strong><progress max="1000"></progress><div data-counts></div><div data-detail class="wwis-dim"></div><div data-time class="wwis-dim"></div>';
      anchor.after(node);
    }
    node.dataset.stage = task.stage;
    node.dataset.status = task.running ? 'running' : task.cancelled ? 'cancelled' : task.error ? 'error' : 'done';
    const setText = (selector, text) => { const target = node.querySelector(selector); if (target.textContent !== text) target.textContent = text; };
    setText('[data-title]', task.label);
    const current = count(task.current), total = count(task.total), unit = task.unit || '개';
    const bar = node.querySelector('progress');
    bar.setAttribute('aria-label', task.label);
    if (current !== null && total !== null) {
      const scaled = total > 0n ? Number(current * 1000n / total) : task.running ? 0 : 1000;
      bar.value = Math.max(0, Math.min(1000, scaled));
      const remaining = total > current ? total - current : 0n;
      setText('[data-counts]', `${number(current)} / ${number(total)}${unit} (${(bar.value / 10).toFixed(1)}%) · 남은 ${number(remaining)}${unit}`);
      node.dataset.current = String(current); node.dataset.total = String(total);
    } else {
      if (task.running) bar.removeAttribute('value'); else bar.value = 0;
      setText('[data-counts]', task.running ? '처리 건수를 확인하는 중…' : '');
      delete node.dataset.current; delete node.dataset.total;
    }
    setText('[data-detail]', task.detail || '');
    const now = task.finishedAt || performance.now();
    const elapsed = (now - task.startedAt) / 1000;
    const phaseElapsed = (now - task.stageStartedAt) / 1000;
    let eta = '';
    if (task.running && current > 0n && total > current && phaseElapsed >= 0.2) {
      const seconds = Number(total - current) / Number(current) * phaseElapsed;
      if (Number.isFinite(seconds) && seconds < 365 * 86400) eta = ` · 예상 남은 시간 ${duration(seconds)}`;
    }
    setText('[data-time]', `경과 ${duration(elapsed)}${eta}`);
  }
  function update(kind, next) {
    const previous = tasks.get(kind), now = performance.now();
    const continuing = previous?.running && !next.restart;
    tasks.set(kind, { ...next, running: true,
      startedAt: continuing ? previous.startedAt : now,
      stageStartedAt: continuing && previous.stage === next.stage ? previous.stageStartedAt : now });
    paint(kind);
    if (!timer) timer = setInterval(() => { if (!overlay.hidden) for (const key of tasks.keys()) paint(key); }, 500);
  }
  function finish(kind, detail, error = false, cancelled = false) {
    const task = tasks.get(kind);
    if (!task) return;
    Object.assign(task, { running: false, finishedAt: performance.now(), error, detail, cancelled,
      label: cancelled ? '조합 계산 · 취소됨' : error ? '처리 실패 · 마지막으로 확인한 진행 상태' : task.label + ' · 완료' });
    paint(kind);
    if (![...tasks.values()].some(item => item.running)) { clearInterval(timer); timer = null; }
  }
  return { update, finish, paint };
}

async function ImageStudio_캐시진행응답읽기(response, onProgress) {
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `HTTP ${response.status}`);
  }
  if (!response.headers.get('Content-Type')?.includes('application/x-ndjson')) {
    onProgress({ phase: 'legacy' });
    return response.json();
  }
  const reader = response.body.getReader(), decoder = new TextDecoder();
  let pending = '', result = null;
  const line = value => {
    if (!value.trim()) return;
    const event = JSON.parse(value);
    if (event.type === 'error') throw new Error(event.error);
    if (event.type === 'progress') onProgress(event);
    else if (event.type === 'result') result = event.result;
  };
  try {
    while (true) {
      const chunk = await reader.read();
      pending += decoder.decode(chunk.value || new Uint8Array(), { stream: !chunk.done });
      let newline;
      while ((newline = pending.indexOf('\n')) >= 0) { line(pending.slice(0, newline)); pending = pending.slice(newline + 1); }
      if (chunk.done) break;
    }
    line(pending);
    if (!result) throw new Error('캐시 초기화의 완료 응답을 받지 못했습니다. 서버 상태를 확인해 주세요.');
    return result;
  } catch (error) { await reader.cancel().catch(() => {}); throw error; }
  finally { reader.releaseLock(); }
}
