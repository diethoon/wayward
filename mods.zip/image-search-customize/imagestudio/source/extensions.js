// 공통 확장 계약 v1. 상황 조회와 프롬프트 조립은 동기 함수이며 게임 상태를 변경하지 않습니다.
function ImageStudio_확장등록창구만들기(api) {
  const contexts = new Map();
  const providers = new Map();
  const adapters = new Map();
  const plans = new WeakMap();
  let editor = null;
  let review = null;
  let planning = null;

  // 같은 ID의 이중 등록은 로드 순서에 따라 결과가 달라지므로 즉시 거부합니다.
  function ImageStudio_확장등록하기(target, definition, method) {
    if (!definition || !/^[a-z][a-z0-9_-]+$/.test(definition.id || '') || typeof definition[method] !== 'function') {
      throw Error('ImageStudio 확장 ID 또는 함수가 올바르지 않습니다: ' + method);
    }
    if (target.has(definition.id)) throw Error('ImageStudio 확장 ID 중복: ' + definition.id);
    target.set(definition.id, definition);
    globalThis.WW_ImageStudioMatching?.refresh?.();
    return () => { target.delete(definition.id); globalThis.WW_ImageStudioMatching?.refresh?.(); };
  }
  function ImageStudio_확장키정규화하기(key) {
    let result = ImageStudio_노출키정규화하기(key);
    for (const adapter of adapters.values()) {
      result = adapter.normalize(result);
      if (typeof result !== 'string') throw Error('이미지 키 어댑터는 문자열을 반환해야 합니다: ' + adapter.id);
    }
    return ImageStudio_노출키정규화하기(result);
  }
  function ImageStudio_확장맥락읽기(key, character, room) {
    const planned = editor?.planningContext?.();
    const state = planned?.state || api.store.game();
    const value = {
      version: 1, mode: planning ? 'planning' : 'live', key, character: planned?.character || character,
      room, state, selection: planning?.combination || {}, archetypeId: planning?.archetypeId,
    };
    const situations = {};
    for (const source of contexts.values()) {
      const situation = source.read(Object.freeze({ ...value }));
      if (situation && typeof situation.then === 'function') throw Error('상황 조회는 동기 함수여야 합니다: ' + source.id);
      situations[source.id] = situation;
    }
    return Object.freeze({ ...value, situations: Object.freeze(situations) });
  }
  function ImageStudio_확장프롬프트적용하기(result, character, room) {
    if (!result?.key) return result;
    const context = ImageStudio_확장맥락읽기(result.key, character, room);
    let value = result;
    for (const provider of [...providers.values()].sort((left, right) => (left.priority || 0) - (right.priority || 0) || left.id.localeCompare(right.id))) {
      const next = provider.compose(value, context);
      if (next && typeof next.then === 'function') throw Error('프롬프트 조립은 동기 함수여야 합니다: ' + provider.id);
      if (next !== undefined) value = next;
    }
    value = { ...value, key: ImageStudio_확장키정규화하기(value.key) };
    if (planning) planning.result = value;
    return value;
  }
  function ImageStudio_확장축읽기() {
    const axes = [...(editor?.axes?.() || [])];
    for (const provider of providers.values()) axes.push(...(provider.axes?.() || []));
    const ids = axes.map(axis => axis.id);
    if (new Set(ids).size !== ids.length) throw Error('ImageStudio 확장 조건 ID 중복');
    return axes;
  }
  // 편집기의 원래 조합 객체를 보존하여 WeakMap에 보관된 설정 스냅샷도 유지합니다.
  function ImageStudio_확장조합공간읽기(selected = {}) {
    const base = editor?.combinationSpace?.(selected) || { count: 1n, at: () => ({}) };
    const dimensions = [];
    for (const provider of providers.values()) for (const axis of provider.axes?.() || []) {
      const available = new Set(axis.items.map(item => String(item.value)));
      const choices = [...new Set(selected[axis.id] || [axis.defaultValue || 'auto'])];
      if (!choices.length || choices.some(choice => !available.has(String(choice)))) throw Error('확장 생성 조건 오류: ' + axis.id);
      dimensions.push({ id: axis.id, choices });
    }
    const extraCount = dimensions.reduce((total, axis) => total * BigInt(axis.choices.length), 1n);
    return { count: base.count * extraCount, at(index) {
      index = BigInt(index);
      if (index < 0n || index >= base.count * extraCount) throw Error('확장 조합 인덱스 범위 오류');
      const original = base.at(index / extraCount);
      const combination = { ...original };
      let extra = index % extraCount;
      for (const axis of [...dimensions].reverse()) {
        combination[axis.id] = axis.choices[Number(extra % BigInt(axis.choices.length))];
        extra /= BigInt(axis.choices.length);
      }
      plans.set(combination, original);
      return combination;
    } };
  }
  function ImageStudio_확장계획만들기(build, combination = {}, archetypeId) {
    const previous = planning;
    const scope = { combination, archetypeId, result: null, baseKey: null };
    planning = scope;
    try {
      const context = ImageStudio_확장맥락읽기('', null, null);
      for (const provider of providers.values()) {
        if (typeof provider.valid !== 'function') continue;
        const valid = provider.valid(context);
        if (valid && typeof valid.then === 'function') throw Error('생성 조합 검사는 동기 함수여야 합니다: ' + provider.id);
        if (valid === false) return [];
      }
      const items = editor?.plan ? editor.plan(build, plans.get(combination) || combination, archetypeId) : build();
      if (!scope.result) return items;
      const result = scope.result;
      return items.map(item => ({ ...item, ImageStudioBaseKey: scope.baseKey || item.talentId, talentId: result.key, prompt: result.prompt, negativePrompt: result.negativePrompt,
        ImageStudioParts: result.parts, ...result.genParams,
        debug: { ...item.debug, imageMatching: globalThis.WW_ImageStudioMatching?.metadata?.(result.key) || item.debug?.imageMatching } }));
    } finally { planning = previous; }
  }
  function ImageStudio_편집기등록하기(definition) {
    if (editor) throw Error('공통 프롬프트 편집기가 이미 등록되어 있습니다: ' + editor.id);
    if (!definition?.id || typeof definition.render !== 'function') throw Error('공통 프롬프트 편집기 등록 형식 오류');
    editor = definition;
    return () => { if (editor === definition) editor = null; };
  }
  function ImageStudio_기본매칭맥락읽기(key, suppliedCharacter) {
    const state = api.store.game();
    const character = suppliedCharacter || state?.characters?.[state.primaryCharacterId];
    if (!character) return null;
    // 표정 태그 편집을 끈 경우에도 실제 감정은 매칭의 공통 입력으로 유지합니다.
    const emotions = api.fn('topFeelings')(character, 2)
      .filter(feeling => Number(feeling.intensity) > 15).map(feeling => feeling.emotion);
    return { version: 1, emotions: [...new Set(emotions)].sort(), badguest: null, pregnancy: null, detail: null };
  }
  const extensions = {
    version: 1,
    positionApplicable: ImageStudio_자세상황에맞는가,
    registerContextProvider: definition => ImageStudio_확장등록하기(contexts, definition, 'read'),
    registerPromptProvider: definition => ImageStudio_확장등록하기(providers, definition, 'compose'),
    registerKeyAdapter: definition => ImageStudio_확장등록하기(adapters, definition, 'normalize'),
    registerEditor: ImageStudio_편집기등록하기,
    normalizeKey: ImageStudio_확장키정규화하기,
    normalizeMatchingContext: context => editor?.upgrades?.normalizeMatchingContext?.(context) || context,
    compose: ImageStudio_확장프롬프트적용하기,
    context: ImageStudio_확장맥락읽기,
    setReview: value => { review = value; },
    get editor() { return editor; },
    get review() { return review; },
    list: () => ({ version: 1, editor: editor?.id || null, contexts: [...contexts.keys()], prompts: [...providers.keys()], keys: [...adapters.keys()] }),
  };
  // 이전 호환 모드가 사용하는 전역 API도 같은 등록 창구를 통하도록 유지합니다.
  globalThis.WW_ImageStudioPrompt = {
    open: () => review.open(), generate: request => review.generate(request), refresh: () => review.refresh(),
    isBusy: () => review?.isBusy?.() || false,
    axes: ImageStudio_확장축읽기,
    combinationSpace: ImageStudio_확장조합공간읽기,
    combinations: selected => {
      const space = ImageStudio_확장조합공간읽기(selected);
      if (space.count > 120000n) throw Error('세부 조건 조합이 120,000개를 넘었습니다.');
      return Array.from({ length: Number(space.count) }, (_, index) => space.at(BigInt(index)));
    },
    plan: ImageStudio_확장계획만들기,
    positionApplicable: ImageStudio_자세상황에맞는가,
    matchingContext: (key, character) => editor?.matchingContext?.(key, character) || ImageStudio_기본매칭맥락읽기(key, character),
    get embeddedVersion() { return editor?.embeddedVersion || null; },
  };
  api.hook('imagePrompt', { priority: -500000, after(result, [character, room]) {
    return ImageStudio_확장프롬프트적용하기(result, character, room);
  } });
  api.hook('imageKey', { priority: -500000, after(result, [character, room]) {
    if (typeof result !== 'string') return;
    if (planning && !planning.baseKey) planning.baseKey = result;
    const context = ImageStudio_확장맥락읽기(result, character, room);
    for (const provider of [...providers.values()].sort((left, right) => (left.priority || 0) - (right.priority || 0) || left.id.localeCompare(right.id))) {
      if (provider.key) result = provider.key(result, context);
    }
    return ImageStudio_확장키정규화하기(result);
  } });
  return extensions;
}
