// 공통 검수·저장 UI. 편집기는 확장 등록 창구에서 선택적으로 연결합니다.
async function ImageStudio_서버지원오류읽기(baseUrl, feature) {
  let version = '';
  try {
    const response = await fetch(String(baseUrl).replace(/\/+$/, '') + '/api/image/health', { credentials: 'omit', signal: AbortSignal.timeout(2500) });
    const health = await response.json();
    if (typeof health.version === 'string') version = ` · 서버 ${health.version}`;
  } catch { /* 연결된 주소와 정확한 실행 파일은 계속 안내합니다. */ }
  return `${feature} API를 지원하지 않는 서버에 연결되어 있습니다.\n연결 주소: ${baseUrl}${version}\n실행 파일: wml\\mods\\imagestudio\\Start_ImageStudio.cmd\n진행 중인 생성이 끝난 뒤 공통 서버 0.7.2로 다시 실행하고 창을 열어 주세요.`;
}
function ImageStudio_프롬프트검수연결하기(api) {
  const host = globalThis.WW_ImageStudioPrompt;
  let panel = null, editorRoot = null, reviewRoot = null, currentDraft = '', drafts = [], directory = '', generating = false;
  let selectedRequest = null, generationEpoch = 0;
  let preparation = null;
  const h = api.ui.h;
  const style = h('style', { 'data-imagestudio-prompt-review-style': '' });
  style.textContent = `.wwis-prompt-layout{display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:16px;align-items:start;max-width:100%}.wwis-prompt-editor{min-width:0;overflow-wrap:anywhere}.wwis-review{min-width:0;position:sticky;top:0;border:1px solid #92400e;border-radius:8px;padding:12px;background:#151312;box-sizing:border-box}.wwis-review input,.wwis-review textarea,.wwis-review select{box-sizing:border-box;width:100%;background:#0c0a09;color:#f5f5f4;border:1px solid #57534e;border-radius:5px;padding:6px;font:12px/1.4 sans-serif}.wwis-review textarea{resize:vertical;min-height:80px}.wwis-review label{display:grid;gap:4px;margin:8px 0}.wwis-review img{display:block;width:100%;max-height:440px;object-fit:contain;background:#0c0a09;margin:10px 0}.wwis-review-actions{display:grid;grid-template-columns:1fr 1fr 1.7fr;gap:5px}.wwis-review-actions button{min-width:0;font-size:12px;padding:7px 3px}.wwis-review-note{font-size:12px;white-space:pre-line;overflow-wrap:anywhere;color:#d6d3d1}@media(max-width:900px){.wwis-prompt-layout{grid-template-columns:1fr}.wwis-review{position:static}.wwis-prompt-editor main{flex-basis:100%!important}.wwis-prompt-editor aside{width:100%!important;max-width:100%!important}.wwis-review img{max-height:50vh}}`;
  style.textContent += '.wwis-review img[hidden]{display:none}.wwis-review summary{cursor:pointer;margin:8px 0;color:#fbbf24}.wwis-specific-builder[hidden]{display:none}.wwis-specific-builder{margin:8px 0;padding:8px;border:1px solid #44403c;border-radius:6px;background:#0c0a09}.wwis-specific-builder fieldset{border:1px solid #292524;border-radius:5px;margin:8px 0;padding:5px 8px}.wwis-specific-builder legend{color:#fbbf24;font-size:12px;padding:0 4px}.wwis-specific-builder label{font-size:11px}.wwis-specific-builder button{width:100%;margin-top:7px}';
  document.head.append(style);

  function ImageStudio_서버읽기() {
    const backend = globalThis.WW_ImageStudioBridge?.connection?.();
    if (!backend?.baseUrl) throw Error('이미지 서버를 연결한 뒤 검수용 생성을 사용하세요.');
    return String(backend.baseUrl).replace(/\/+$/, '');
  }
  async function ImageStudio_서버요청하기(route, method = 'GET', body) {
    const response = await fetch(ImageStudio_서버읽기() + route, { method, credentials: 'omit',
      headers: body ? { 'Content-Type': 'application/json' } : {}, ...(body ? { body: JSON.stringify(body) } : {}) });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw Error(response.status === 404 ? await ImageStudio_서버지원오류읽기(ImageStudio_서버읽기(), '검수') : data.error || `HTTP ${response.status}`);
    return data;
  }
  function ImageStudio_메시지보이기(message) {
    const note = reviewRoot?.querySelector('[data-wwis-review-message]');
    if (note) note.textContent = message;
  }
  function ImageStudio_현재장면읽기() {
    const state = api.store.game();
    if (!state) return null;
    const character = api.fn('wife')(state);
    const room = api.fn('imageRoom')(api.fn('wifeLocation')(state));
    return api.fn('imagePrompt')(character, room);
  }
  function ImageStudio_입력채우기(request) {
    if (!reviewRoot || !request) return;
    selectedRequest = { ...request };
    reviewRoot.querySelector('[data-wwis-review-key]').value = request.imageKey || request.key || '';
    reviewRoot.querySelector('[data-wwis-review-positive]').value = request.prompt || '';
    reviewRoot.querySelector('[data-wwis-review-negative]').value = request.negativePrompt || '';
  }
  function ImageStudio_특정장면폼만들기(current) {
    const bridge = globalThis.WW_ImageStudioBridge;
    const baseAxes = bridge?.axes?.() || {};
    const promptAxes = host.axes?.() || [];
    const currentAxes = bridge?.keyAxes?.(current?.key || current?.imageKey || '') || {};
    const currentWife = bridge?.currentWife?.();
    const characters = bridge?.characters?.().characters || [];
    const characterItems = characters.length
      ? characters.map(character => ({ value: character.id, label: character.name || character.id }))
      : (baseAxes.character || []);
    const specialSituations = [
      { value: '__imagestudio_h_status_blank', label: 'H_Status 이미지 생성(빈거)', kind: 'special', baseSituation: 'idle' },
      { value: '__imagestudio_life_birth', label: '출산 장면', kind: 'special', baseSituation: 'idle', lifeEvent: 'birth' },
      { value: '__imagestudio_life_discussion', label: '아이 처치 상의', kind: 'special', baseSituation: 'idle', lifeEvent: 'child_discussion' },
      { value: '__imagestudio_life_adoption', label: '입양 장면', kind: 'special', baseSituation: 'idle', lifeEvent: 'child_adoption' },
      { value: '__imagestudio_life_parents', label: '부모님께 맡기는 장면', kind: 'special', baseSituation: 'idle', lifeEvent: 'child_parents' },
    ];
    const groups = new Map([
      ['character', { label: '캐릭터', axes: [] }], ['outfit', { label: '의상', axes: [] }],
      ['place', { label: '장소', axes: [] }], ['scene', { label: '장면', axes: [] }],
      ['emotion', { label: '감정 상태', axes: [] }],
    ]);
    const baseDefinitions = [
      { id: 'character', label: "여성 캐릭터", items: characterItems },
      { id: 'mood', label: '기분', items: baseAxes.mood || [] },
      { id: 'outfit', label: '의상', items: baseAxes.outfit || [] },
      { id: 'exposure', label: '의상 및 노출 상태', items: baseAxes.exposure || [] },
      { id: 'room', label: '장소', items: baseAxes.room || [] },
      { id: 'aftermath', label: '장소에 남은 체액 흔적', items: baseAxes.aftermath || [] },
      { id: 'situation', label: '장면 / 작업', items: [...(baseAxes.situation || []), ...specialSituations] },
      { id: 'men', label: '남성 수 프롬프트', items: baseAxes.men || [] },
      { id: 'roles', label: '남성별 역할 조합', items: baseAxes.roles || [] },
    ];
    const baseGroup = id => ['character', 'mood'].includes(id) ? 'character'
      : ['outfit', 'exposure'].includes(id) ? 'outfit' : ['room', 'aftermath'].includes(id) ? 'place' : 'scene';
    for (const axis of baseDefinitions) groups.get(baseGroup(axis.id)).axes.push({ ...axis, kind: 'base' });
    const promptGroup = axis => axis.id === 'promptPregnancy' ? 'character'
      : axis.id === 'promptResidue' || axis.group === 'badguest' && axis.family !== 'badguest.drugged' ? 'outfit'
      : axis.id === 'promptConsent' || axis.group === 'detail' || axis.family === 'badguest.drugged' ? 'emotion' : 'scene';
    for (const axis of promptAxes) {
      if (axis.id === 'promptLifeEvent') continue;
      groups.get(promptGroup(axis)).axes.push({ ...axis, kind: 'prompt' });
    }
    const controls = [];
    const fieldsets = [];
    const defaultValue = axis => axis.id === 'character' ? currentWife || currentAxes.character
      : axis.id === 'men' ? currentAxes.men || '0'
      : axis.id === 'roles' ? currentAxes.roles || '' : axis.kind === 'base' ? currentAxes[axis.id] : 'auto';
    for (const [groupId, group] of groups) {
      const fields = [];
      for (const axis of group.axes) {
        if (!axis.items?.length) continue;
        const select = h('select', { 'data-wwis-specific-axis': axis.id, 'data-wwis-specific-kind': axis.kind });
        for (const item of axis.items) select.append(h('option', { value: item.value, title: item.description || '' }, item.label || item.value));
        const initial = defaultValue(axis);
        if ([...select.options].some(option => option.value === String(initial))) select.value = String(initial);
        controls.push({ axis, select });
        fields.push(h('label', {}, axis.label, select));
      }
      if (fields.length) fieldsets.push(h('fieldset', { 'data-wwis-specific-group': groupId }, h('legend', {}, group.label), ...fields));
    }
    const situationControl = controls.find(control => control.axis.id === 'situation')?.select;
    const menControl = controls.find(control => control.axis.id === 'men')?.select;
    const rolesControl = controls.find(control => control.axis.id === 'roles')?.select;
    const ImageStudio_남성역할선택갱신하기 = () => {
      if (!rolesControl) return;
      const roleCount = Math.max(0, Number(menControl?.value || 0) - 1);
      for (const option of rolesControl.options) option.disabled = roleCount < 1 || [...option.value].length !== roleCount;
      rolesControl.disabled = roleCount < 1;
      if (roleCount > 0 && rolesControl.selectedOptions[0]?.disabled) {
        const available = [...rolesControl.options].find(option => !option.disabled);
        if (available) rolesControl.value = available.value;
      }
    };
    let menChanged = false;
    menControl?.addEventListener('change', () => { menChanged = true; ImageStudio_남성역할선택갱신하기(); });
    situationControl?.addEventListener('change', () => {
      if (menChanged || !menControl) return;
      const special = specialSituations.find(item => item.value === situationControl.value);
      const item = special || baseAxes.situation?.find(entry => entry.value === situationControl.value);
      const solo = item?.kind === 'task' || item?.kind === 'special' || ['self_pleasure', 'bath_solo'].includes(situationControl.value);
      if ([...menControl.options].some(option => option.value === (solo ? '0' : '1'))) menControl.value = solo ? '0' : '1';
      ImageStudio_남성역할선택갱신하기();
    });
    ImageStudio_남성역할선택갱신하기();
    const message = h('p', { class: 'wwis-review-note', role: 'status', 'data-wwis-specific-message': '' },
      '자동 자세는 장면에 맞는 후보를 같은 확률로 하나 고릅니다. 맞는 후보가 없으면 게임의 기존 자세를 유지합니다.');
    const conflicts = h('p', {
      class: 'wwis-review-note', hidden: true, 'data-wwis-specific-conflicts': '',
      style: 'color:#fb923c;white-space:pre-line;margin-top:4px;',
    });
    const showConflicts = reasons => {
      const items = [...new Set((reasons || []).map(reason => String(reason || '').trim()).filter(Boolean))];
      conflicts.textContent = items.map(reason => `• ${reason}`).join('\n');
      conflicts.hidden = !items.length;
    };
    const form = h('div', { class: 'wwis-specific-builder', hidden: true, 'data-wwis-specific-builder': '' }, ...fieldsets, message, conflicts);
    form.append(api.ui.button('선택한 조건으로 프롬프트 만들기', () => {
      try {
        showConflicts([]);
        const value = id => controls.find(control => control.axis.id === id)?.select.value || '';
        const wife = value('character');
        if (!wife) throw Error("여성 캐릭터를 선택하세요.");
        const selected = {};
        for (const { axis, select } of controls.filter(control => control.axis.kind === 'base' && !['character', 'situation'].includes(control.axis.id))) selected[axis.id] = [select.value];
        const special = specialSituations.find(item => item.value === value('situation'));
        const baseSituation = special?.baseSituation || value('situation');
        selected.situation = [baseSituation];
        const selectedPosition = value('promptPosition');
        const men = Number(value('men'));
        if (selectedPosition === 'double-penetration' && men < 2) throw Error('이중 삽입은 남성 수 프롬프트를 2명 이상으로 선택하세요.');
        const requiredRole = selectedPosition === 'double-penetration'
          ? (/^(?:patron_)?anal(?:_|$)/.test(baseSituation) ? 'i' : 'a') : '';
        const selectedRole = value('roles');
        if (men > 1 && !selectedRole) throw Error('남성별 역할 조합을 선택하세요.');
        if (requiredRole && !selectedRole.includes(requiredRole)) throw Error('이중 삽입 자세에 맞는 남성별 역할 조합을 선택하세요.');
        selected.roles = men > 1 ? [selectedRole] : (baseAxes.roles || []).map(item => String(item.value));
        selected.variant ||= ['0'];
        const promptSelected = Object.fromEntries(controls.filter(control => control.axis.kind === 'prompt')
          .map(({ axis, select }) => [axis.id, [select.value]]));
        if (special?.lifeEvent) promptSelected.promptLifeEvent = [special.lifeEvent];
        const details = host.combinationSpace(promptSelected);
        const space = bridge?.randomSpace?.(wife, selected);
        if (!space?.count) {
          const reasons = bridge?.selectionConflicts?.(wife, selected);
          showConflicts(reasons?.length ? reasons : ['선택한 기본 조건 사이에 게임이 지원하지 않는 조합이 있습니다.']);
          throw Error('이 조합으로 만들 수 있는 장면이 없습니다. 장면에 맞는 장소·의상·노출 상태를 선택하세요.');
        }
        const items = space.build(0n, details.at(0n));
        const item = items?.[0];
        if (!item) {
          showConflicts(bridge?.selectionConflicts?.(wife, selected));
          throw Error('선택한 조합의 프롬프트를 만들지 못했습니다. 조건을 확인하세요.');
        }
        const request = { ...item, imageKey: item.imageKey || item.key || item.talentId, talentId: item.talentId || item.key };
        ImageStudio_입력채우기(request);
        message.textContent = `프롬프트를 만들었습니다: ${request.imageKey}`;
      } catch (error) { message.textContent = String(error.message || error); }
    }));
    return form;
  }
  async function ImageStudio_검수목록갱신하기() {
    const data = await ImageStudio_서버요청하기('/api/studio/drafts');
    drafts = data.entries || []; directory = data.defaultDirectory || directory;
    if (!drafts.some(entry => entry.id === currentDraft)) currentDraft = drafts.at(-1)?.id || '';
    ImageStudio_검수선택보이기();
  }
  function ImageStudio_검수선택보이기() {
    if (!reviewRoot) return;
    const select = reviewRoot.querySelector('[data-wwis-review-select]');
    select.replaceChildren(...drafts.map((entry, index) => h('option', { value: entry.id }, `${index + 1}. ${entry.saved ? '저장 완료 · ' : ''}${entry.talentName}`)));
    if (!drafts.length) select.append(h('option', { value: '' }, '검수 대기 이미지 없음'));
    select.value = currentDraft;
    const entry = drafts.find(item => item.id === currentDraft), image = reviewRoot.querySelector('[data-wwis-review-image]');
    image.hidden = !entry;
    if (entry) { image.src = ImageStudio_서버읽기() + entry.imageUrl; image.alt = entry.talentName + ' · 검수 대기'; }
    else image.removeAttribute('src');
    for (const button of reviewRoot.querySelectorAll('[data-wwis-review-action]')) button.disabled = !entry || generating;
    reviewRoot.querySelector('[data-wwis-review-generate]').disabled = generating;
    if (entry?.saved) ImageStudio_메시지보이기(`저장 완료: ${entry.saved.absolutePath}`);
  }
  async function ImageStudio_검수생성하기(request) {
    if (generating) throw Error('검수용 이미지를 생성 중입니다.');
    const connection = globalThis.WW_ImageStudioBridge?.connection?.();
    if (!connection?.baseUrl || connection.comfyui !== true) throw Error('생성 가능한 이미지 서버를 연결하세요.');
    if (!request?.prompt?.trim()) throw Error('Positive 프롬프트를 입력하거나 현재 장면을 불러오세요.');
    generating = true; const epoch = ++generationEpoch;
    ImageStudio_입력채우기(request); ImageStudio_검수선택보이기(); ImageStudio_메시지보이기('검수용 이미지 생성 중… 승인 전에는 게임 이미지로 저장하지 않습니다.');
    try {
      // 편집기 버튼과 검수창 직접 입력이 같은 부위별 참조 설정을 사용합니다.
      const prepare = globalThis.WW_ImageStudioBridge?.extensions?.editor?.upgrades?.prepare;
      if (prepare) request = await prepare(request);
      const key = request.imageKey || request.key;
      if (!key) throw Error('이미지 키를 지정하세요.');
      const capability = await ImageStudio_서버요청하기('/api/studio/drafts');
      if (capability.supportsReviewDrafts !== true) throw Error('검수 전 저장 기능을 지원하는 서버로 다시 실행하세요.');
      if (request.referenceKey && capability.supportsImg2img !== true) throw Error('부위별 img2img를 지원하는 공통 서버 0.7.2로 재시작하세요.');
      let job = await ImageStudio_서버요청하기('/api/image/generate', 'POST', { ...request,
        debug: { ...request.debug, imageMatching: request.debug?.imageMatching || globalThis.WW_ImageStudioMatching?.metadata?.(key) },
        talentId: request.talentId || key, talentName: request.talentName || key, imageType: 'portrait',
        reviewOnly: true, bulk: true, bypassCache: false, promptHash: undefined, seed: request.seed ?? 1138 });
      const started = Date.now();
      while (['queued', 'processing'].includes(job.status)) {
        if (Date.now() - started > 20 * 60 * 1000) throw Error('생성 대기 시간이 길어졌습니다. 서버 검수 목록을 다시 확인하세요.');
        await new Promise(resolve => setTimeout(resolve, 1200));
        job = await ImageStudio_서버요청하기('/api/image/status/' + encodeURIComponent(job.promptId));
      }
      if (job.status !== 'completed' || !job.reviewOnly || !job.draftId) throw Error(job.error || '서버가 검수 전 저장 기능을 지원하지 않습니다. 포함된 서버로 다시 실행하세요.');
      currentDraft = job.draftId; await ImageStudio_검수목록갱신하기();
      ImageStudio_메시지보이기('생성 완료. 이미지를 확인한 뒤 저장하거나 삭제하세요.');
      return { draft: true, draftId: job.draftId, url: ImageStudio_서버읽기() + job.imageUrl };
    } catch (error) { ImageStudio_메시지보이기(String(error.message || error)); throw error; }
    finally { if (epoch === generationEpoch) generating = false; ImageStudio_검수선택보이기(); }
  }
  async function ImageStudio_선택그림저장하기(named = false) {
    const entry = drafts.find(item => item.id === currentDraft);
    if (!entry) return;
    let body = {};
    if (named) {
      const savedName = entry.talentName.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').slice(0, 120) + (entry.mime === 'image/webp' ? '.webp' : entry.mime === 'image/jpeg' ? '.jpg' : '.png');
      const pathInput = h('input', { 'data-wwis-review-directory': '', value: directory, placeholder: 'C:\\...\\images 또는 원하는 저장 폴더' });
      const nameInput = h('input', { 'data-wwis-review-filename': '', value: savedName });
      const form = h('div', { 'data-wwis-review-save-as': '' }, h('label', {}, '저장 경로 · 이미지 서버가 실행되는 PC', pathInput), h('label', {}, '파일 이름', nameInput));
      form.append(api.ui.button('지정한 경로에 저장', async () => {
        try {
          const result = await ImageStudio_서버요청하기('/api/studio/drafts/' + entry.id + '/save', 'POST', { directory: pathInput.value, filename: nameInput.value });
          form.remove(); await ImageStudio_검수목록갱신하기(); ImageStudio_메시지보이기(`저장 완료: ${result.absolutePath}`);
          api.fn('imagePackReset')?.();
        } catch (error) { ImageStudio_메시지보이기(String(error.message || error)); }
      }), api.ui.button('취소', () => form.remove()));
      reviewRoot.querySelector('[data-wwis-review-save-as]')?.remove(); reviewRoot.append(form); return;
    }
    try {
      const result = await ImageStudio_서버요청하기('/api/studio/drafts/' + entry.id + '/save', 'POST', body);
      await ImageStudio_검수목록갱신하기(); ImageStudio_메시지보이기(`승인 저장 완료: ${result.absolutePath}`); api.fn('imagePackReset')?.();
    } catch (error) { ImageStudio_메시지보이기(String(error.message || error)); }
  }
  function ImageStudio_검수창그리기(root) {
    let current = null;
    try { current = selectedRequest || ImageStudio_현재장면읽기(); } catch { /* 게임 시작 전에도 설정을 편집할 수 있습니다. */ }
    const key = h('input', { 'data-wwis-review-key': '', value: current?.imageKey || current?.key || '' });
    const positive = h('textarea', { 'data-wwis-review-positive': '', rows: 5, value: current?.prompt || '' });
    const negative = h('textarea', { 'data-wwis-review-negative': '', rows: 3, value: current?.negativePrompt || '' });
    for (const input of [key, positive, negative]) input.addEventListener('input', () => {
      selectedRequest = { ...selectedRequest, imageKey: key.value, prompt: positive.value, negativePrompt: negative.value };
    });
    const select = h('select', { 'data-wwis-review-select': '', onchange: event => { currentDraft = event.currentTarget.value; ImageStudio_검수선택보이기(); } });
    const specific = ImageStudio_특정장면폼만들기(current);
    root.replaceChildren(h('h3', {}, '검수창'),
      h('p', { class: 'wwis-review-note' }, '미저장 결과는 서버 RAM에 임시 보관합니다. 저장에 성공하면 원본 RAM과 검수 대기 항목을 정리합니다. 저장 파일은 유지되며, 서버를 종료하면 미저장 결과는 사라집니다.'),
      api.ui.button('현재 장면 프롬프트 불러오기', () => ImageStudio_입력채우기(ImageStudio_현재장면읽기())),
      api.ui.button('특정 장면 프롬프트 만들기', () => { specific.hidden = !specific.hidden; }),
      specific,
      h('details', {}, h('summary', {}, '생성 프롬프트와 이미지 키'), h('label', {}, '이미지 키', key), h('label', {}, '생성할 Positive', positive), h('label', {}, '생성할 Negative', negative)),
      h('button', { type: 'button', class: 'wayward-native-button', 'data-wwis-review-generate': '', onclick: async () => {
        try { await ImageStudio_검수생성하기({ ...selectedRequest, imageKey: key.value.trim(), prompt: positive.value, negativePrompt: negative.value }); } catch { /* 오류는 검수창에 표시합니다. */ }
      } }, '검수용 이미지 만들기'), h('label', {}, '검수 대기 이미지', select),
      h('img', { hidden: true, 'data-wwis-review-image': '' }),
      h('div', { class: 'wwis-review-actions' },
        h('button', { type: 'button', class: 'wayward-native-button', disabled: true, 'data-wwis-review-action': 'save', onclick: () => ImageStudio_선택그림저장하기() }, '저장'),
        h('button', { type: 'button', class: 'wayward-native-button', disabled: true, 'data-wwis-review-action': 'delete', onclick: async () => {
          try { await ImageStudio_서버요청하기('/api/studio/drafts/' + currentDraft, 'DELETE'); await ImageStudio_검수목록갱신하기(); ImageStudio_메시지보이기('검수 대기 이미지를 삭제했습니다. 이미 저장한 파일은 유지됩니다.'); } catch (error) { ImageStudio_메시지보이기(String(error.message || error)); }
        } }, '삭제'),
        h('button', { type: 'button', class: 'wayward-native-button', disabled: true, 'data-wwis-review-action': 'save-as', onclick: () => ImageStudio_선택그림저장하기(true) }, '다른 이름으로 저장')),
      h('p', { class: 'wwis-review-note', role: 'status', 'data-wwis-review-message': '' }, '검수용 이미지를 생성하세요.'));
    if (current) selectedRequest = { ...current };
    ImageStudio_검수목록갱신하기().catch(error => ImageStudio_메시지보이기(String(error.message || error)));
  }
  function ImageStudio_편집창열기() {
    if (panel && editorRoot?.isConnected) { panel.focus?.(); return panel; }
    preparation?.abort();
    const controller = new AbortController(); preparation = controller;
    panel = api.ui.window({ id: 'prompt-review', title: '프롬프트 편집 · 검수 · ImageStudio', width: 1450, height: 870,
      render(body, win) {
        let dirty = false, needsRefresh = false;
        const refreshed = new Set();
        const progress = h('p', { role: 'status', 'data-wwis-defaults-progress': '' }, '기본 프롬프트를 준비합니다. 편집과 창 닫기는 계속 사용할 수 있습니다.');
        editorRoot = h('section', { class: 'wwis-prompt-editor', 'data-wwis-prompt-editor': '' });
        reviewRoot = h('aside', { class: 'wwis-review', 'data-wwis-review': '' });
        const jump = h('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;' },
          api.ui.button('프롬프트 설정으로 이동', () => editorRoot.scrollIntoView({ block: 'start' })),
          api.ui.button('검수창으로 이동', () => reviewRoot.scrollIntoView({ block: 'start' })));
        body.replaceChildren(jump, progress, h('div', { class: 'wwis-prompt-layout' }, editorRoot, reviewRoot));
        const localEditor = editorRoot;
        localEditor.addEventListener('input', event => { if (event.target.matches('input,textarea')) dirty = true; });
        const editorWin = { ...win, refresh: () => {
          if (controller.signal.aborted || !localEditor.isConnected) return;
          dirty = false; needsRefresh = false;
          if (globalThis.WW_ImageStudioBridge.extensions.editor) globalThis.WW_ImageStudioBridge.extensions.editor.render(localEditor, editorWin);
          else localEditor.replaceChildren(h('p', {}, '공통 프롬프트 편집기를 사용하려면 imagestudio-compatible-attention-image-prompt를 켜세요. 생성·검수·저장은 이 창에서 계속 사용할 수 있습니다.'));
        } };
        const priority = () => { const select = localEditor.querySelector('[data-native-axis-prompt-source]'); return select ? { axis: select.dataset.nativeAxisPromptSource, id: select.value } : null; };
        const refreshIfSafe = () => {
          const active = document.activeElement;
          const editing = localEditor.contains(active) && active.matches('input,textarea,select,[contenteditable="true"]');
          if (needsRefresh && !dirty && !editing) editorWin.refresh();
        };
        localEditor.addEventListener('focusout', () => { setTimeout(refreshIfSafe, 0); });
        editorWin.refresh(); ImageStudio_검수창그리기(reviewRoot);
        const collect = globalThis.WW_ImageStudioBridge?.collectPromptDefaults;
        Promise.resolve(collect?.({ signal: controller.signal, priority, onProgress: status => {
          if (controller.signal.aborted || !localEditor.isConnected) return;
          progress.dataset.complete = String(status.complete);
          progress.textContent = status.complete ? status.failed ? '일부 기본 프롬프트를 준비하지 못했습니다.' : '기본 프롬프트 준비 완료'
            : `기본 프롬프트 준비 중 · ${status.done} / ${status.total} · 준비 중인 기본값은 잠시 비어 있을 수 있습니다. 입력한 내용은 유지됩니다.`;
          const selected = priority(), key = selected && `${selected.axis}:${selected.id}`;
          if (status.complete || status.priorityReady && !refreshed.has(key)) {
            if (key) refreshed.add(key);
            needsRefresh = true; refreshIfSafe();
          }
        } })).then(success => {
          if (!controller.signal.aborted && !success) progress.textContent = '기본 프롬프트 준비를 완료하지 못했습니다. 창을 다시 열어 재시도하세요.';
        }).catch(error => { if (!controller.signal.aborted) progress.textContent = '기본 프롬프트 준비 실패: ' + String(error.message || error); });
      }, onClose: () => { controller.abort(); if (preparation === controller) { preparation = null; panel = null; editorRoot = null; reviewRoot = null; } } });
    return panel;
  }
  const overlay = document.getElementById('wwis-overlay');
  overlay?.addEventListener('click', event => { if (event.target.closest('#wwis-prompt-edit')) ImageStudio_편집창열기(); });
  api.onBack(() => { if (!panel) return false; panel.close(); return true; });
  return { open: ImageStudio_편집창열기, generate: ImageStudio_검수생성하기, refresh: ImageStudio_검수목록갱신하기, isBusy: () => generating };
}
