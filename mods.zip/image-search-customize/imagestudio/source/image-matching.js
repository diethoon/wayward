// 게임의 xy → Kee → Jee와 같은 우선순위입니다. 탈의가 하위 단계를 포함하며 팬티 제거는 옆으로 젖힘보다 우선합니다.
// 기본 상태는 exp 키를 생략하므로 빈 문자열을 반환합니다. 잘못된 형식은 보정하지 않고 기존 검증에 넘깁니다.
function ImageStudio_노출코드정규화하기(value) {
  if(!value||value==='none'||value==='0000000')return '';
  if(!/^[01]{7}$/.test(value))return value;
  const top=value[2]==='1'?'011':value[1]==='1'?'010':value[0]==='1'?'100':'000';
  const skirt=value[4]==='1'?'11':value[3]==='1'?'10':'00';
  const panties=value[6]==='1'?'01':value[5]==='1'?'10':'00';
  return top+skirt+panties;
}
function ImageStudio_노출키정규화하기(key) {
  if(typeof key!=='string')return key;
  return key.replace(/__exp-([01]{7})(?=__|$)/g,(_,code)=>{
    const normalized=ImageStudio_노출코드정규화하기(code);
    return normalized?'__exp-'+normalized:'';
  });
}

// Pure matcher shared by the game hooks, settings preview and regression tests.
function ImageStudio_매칭엔진만들기(positionApplicable=()=>true, normalizeKey=key=>key) {
  const dimensions = [
    ['scene','장면',10000,8000,true],['outfit','복장',6000,5000,true],['group','남자 그룹 역할',5000,5000,false],
    ['room','장소',4000,4000,true],['exposure','세부 복장(노출) 상태',3200,3200,true],['aftermath','흔적',1000,1000,false],
    ['position','세부 자세(모드)',3000,3000,false],['mood','기분',1000,1000,false],['badguest','나쁜 손님 모드 상태',500,500,false],
    ['pregnancy','임신 상태(임신모드)',500,500,false],['detail','세부 상황(모드)',1000,1000,false],
  ];
  const sceneGroups = [['idle','resting'],['greeting','taking_order'],['bathing','bath_solo'],['passed_out','sleeping'],
    ['patron_chatting','patron_flirting'],['mutual_touching','grinding'],
    ['patron_groping','grinding'],['patron_touching','patron_intimate'],['patron_bold','patron_groping'],
    ['patron_moment_sit_on_lap','patron_groping_lap','patron_intimate_lap'],['sex','sex_rough'],
    ['patron_blowjob','patron_deepthroat'],['groped_ass','patron_groping'],['groped_tits','patron_groping'],['grinding','patron_rubbing']];
  const counterparts = ['kissing','groped_ass','groped_tits','fingered','handjob','blowjob','deepthroat','titfuck','sex','riding',
    'standing_sex','sex_rough','anal','facial','cunnilingus','breast_worship','mutual_touching','grinding','lap_dance','thigh_job',
    'finish_on_stomach','finish_on_chest','finish_on_back','sixty_nine'];
  for (const id of counterparts) sceneGroups.push([id,'patron_'+id]);
  // 사용자가 지정한 36개 번호: 상의 4단계 × 치마 3단계 × 팬티 3단계 순서입니다.
  const exposureStates=[];
  for(const [top,topLabel] of [['000','정상'],['100','앞섶 풀림'],['010','가슴 노출'],['011','탈의']])
    for(const [skirt,skirtLabel] of [['00','정상'],['10','걷어 올림'],['11','탈의']])
      for(const [panties,pantiesLabel] of [['00','정상'],['10','옆으로 젖힘'],['01','탈의']])
        exposureStates.push({number:exposureStates.length+1,value:top+skirt+panties,label:`상의 ${topLabel} / 치마 ${skirtLabel} / 팬티 ${pantiesLabel}`});
  const exposurePairs=[[1,2],[2,3],[4,5],[10,11],[11,12],[13,14],[19,20],[20,21],[22,23],[28,29],[29,30],[31,32]];
  const exposureFields=[['bodiceUnlaced','앞섶 풀림',200,0],['topPulledDown','가슴 노출',500,-1000],['topRemoved','상의 탈의',500,-1000],
    ['skirtUp','치마 걷어 올림',600,-1200],['skirtRemoved','치마 탈의',600,-1200],
    ['pantiesAside','팬티 옆으로 젖힘',400,-800],['pantiesRemoved','팬티 탈의',400,-800]];
  const exposureValue=value=>ImageStudio_노출코드정규화하기(value)||'0000000';
  // A pair is explicit, never transitively closed through a shared member.
  const defaultGroups = {
    scene: sceneGroups, outfit:[['lingerie','satin_babydoll'],['sheer_chemise','sheer_nightgown']],
    room:[['bedroom','bedroom-bed','guest_room','guest_room-bed'],['taproom','back_room']],
    position:[['scene:riding','cowgirl','reverse-cowgirl','double-penetration'],
      ['missionary','ekiben','daisuki-hold','double-penetration'],['scene:sex','full-nelson','doggystyle','double-penetration'],
      ['scene:blowjob','scene:deepthroat','kneeling-fellatio','deep-throat','irrumatio-front','upside-down-facefuck'],
      ['scene:sixty_nine','sixty-nine'],['cunnilingus','scene:patron_cunnilingus','scene:cunnilingus','scene:blowjob']],
    mood:[['shy','scared','worried','nervous'],['aroused','enjoying']],
    exposure:exposurePairs.map(pair=>pair.map(number=>exposureStates[number-1].value)),
  };
  const clone = value => JSON.parse(JSON.stringify(value));
  function defaults() {
    return {version:2,enabled:true,order:dimensions.map(([id])=>id),wifeOutfits:{},rules:Object.fromEntries(dimensions.map(([id,,exact,similar,required])=>[id,id==='exposure'?{
      required:true,allowSimilar:true,groups:clone(defaultGroups.exposure),
      bitScores:Object.fromEntries(exposureFields.map(([field,,match,mismatch])=>[field,{match,mismatch}])),
    }:{
      required,allowSimilar:true,exact,similar,groups:clone(defaultGroups[id] || []),
      ...(id==='group'?{rolePenalty:500,fewerPenalty:500}:{}),
      ...(id==='aftermath'?{extraPenalty:2000,typePenalty:500}:{}),...(id==='mood'?{emotionBonus:300}:{}),
    }]))};
  }
  const safeId = s => typeof s==='string' && s.length<=150 && !['__proto__','constructor','prototype'].includes(s) && /^[a-zA-Z0-9_:.-]+$/.test(s);
  function groupList(value,axis) {
    if (!Array.isArray(value)||value.length>500) throw Error('유사 묶음은 500줄 이하의 배열이어야 합니다.');
    return value.map(row=>{
      if(!Array.isArray(row)||row.length<2||row.length>100)throw Error('유사 묶음은 올바른 항목 ID를 2개 이상 포함해야 합니다.');
      if(axis==='exposure'&&row.some(id=>id!=='none'&&!/^[01]{7}$/.test(id)))throw Error('노출 묶음에는 7자리 코드 또는 none을 입력하세요.');
      const ids=[...new Set(row.map(id=>axis==='exposure'?exposureValue(id):axis==='room'&&id==='bedroom (침대 위)'?'bedroom-bed':id))];
      if(ids.length<2||!ids.every(safeId))throw Error('유사 묶음은 서로 다른 항목 ID를 2개 이상 포함해야 합니다.');
      return ids;
    });
  }
  function normalize(value) {
    if(!value || ![1,2].includes(value.version) || !value.rules || typeof value.rules!=='object')throw Error('이미지 매칭 설정 형식(version 1 또는 2)이 아닙니다.');
    const result=defaults(), ids=dimensions.map(([id])=>id);
    // 토글이 없던 기존 설정은 켜짐을 유지하고, 명시적으로 저장한 꺼짐은 보존합니다.
    if(value.enabled!==undefined){if(typeof value.enabled!=='boolean')throw Error('이미지 탐색 체계 사용 여부는 체크박스 값이어야 합니다.');result.enabled=value.enabled;}
    if(!Array.isArray(value.order)||value.order.length!==ids.length||new Set(value.order).size!==ids.length||value.order.some(id=>!ids.includes(id)))throw Error('우선순위에는 모든 탭이 한 번씩 있어야 합니다.');
    result.order=[...value.order];
    for(const id of ids){const row=value.rules[id];if(!row||typeof row!=='object')throw Error('누락된 탭: '+id);
      // 구버전의 다른 매칭 설정은 보존하고 노출 정책만 이번 사용자 지정값으로 한 번 이전합니다.
      if(id==='exposure'&&value.version===1)continue;
      for(const key of ['required','allowSimilar']){if(typeof row[key]!=='boolean')throw Error('체크박스 설정 오류: '+id);result.rules[id][key]=row[key];}
      for(const key of Object.keys(result.rules[id]).filter(key=>typeof result.rules[id][key]==='number')){
        if(!Number.isFinite(row[key])||row[key]<0||row[key]>1000000)throw Error('점수는 0~1,000,000 사이의 숫자여야 합니다: '+id);result.rules[id][key]=row[key];}
      result.rules[id].groups=groupList(row.groups,id);
      if(id==='exposure')for(const [field] of exposureFields){
        const points=row.bitScores?.[field];
        if(!points||!Number.isFinite(points.match)||points.match<0||points.match>1000000
          ||!Number.isFinite(points.mismatch)||points.mismatch>0||points.mismatch< -1000000)throw Error('노출 비트별 점수 오류: '+field);
        result.rules[id].bitScores[field]={match:points.match,mismatch:points.mismatch};
      }
    }
    if(value.wifeOutfits && (typeof value.wifeOutfits!=='object'||Array.isArray(value.wifeOutfits)))throw Error("캐릭터별 복장 설정 오류");
    for(const [wife,groups] of Object.entries(value.wifeOutfits||{})){if(!safeId(wife)||Object.keys(result.wifeOutfits).length>=200)throw Error("그녀 ID 오류");result.wifeOutfits[wife]=groupList(groups);}
    return result;
  }
  const field=(key,id)=>String(key||'').split('__').find(s=>s.startsWith(id+'-'))?.slice(id.length+1)||'';
  const solo=new Set(['self_pleasure','bath_solo','patron_self_stroke']);
  const positions=['standing','sitting','kneeling','lying-back','all-fours','close-embrace','back-hug','lap-back-hug','missionary',
    'cowgirl','reverse-cowgirl','doggystyle','spooning','standing-sex','mating-press','prone-bone','ekiben','daisuki-hold','full-nelson',
    'double-penetration','kneeling-fellatio','cunnilingus','sixty-nine','seated-handjob','paizuri','deep-throat','irrumatio-front','upside-down-facefuck'].sort((a,b)=>b.length-a.length);
  const setList = value => Array.isArray(value) ? [...new Set(value.filter(x=>typeof x==='string'&&x.length<200))].sort() : null;
  function describe(key,meta={}) {
    key=ImageStudio_노출키정규화하기(normalizeKey(key));
    const parts=String(key||'').split('__'),values=new Map(parts.slice(1).map(part=>{const dash=part.indexOf('-');return [part.slice(0,dash),part.slice(dash+1)];}).reverse());
    const ImageStudio_키필드읽기=id=>values.get(id)||'';
    const task=ImageStudio_키필드읽기('task'),scene=ImageStudio_키필드읽기('scene'),look=ImageStudio_키필드읽기('look');
    const room=ImageStudio_키필드읽기('room'),group=Number(ImageStudio_키필드읽기('grp'))||0;
    const rawPosition=ImageStudio_키필드읽기('position');
    const position=positions.find(id=>rawPosition===id||rawPosition.startsWith(id+'-'))||rawPosition;
    return {key,character:parts[0],scene:scene||task||(look?'look:'+look+':'+ImageStudio_키필드읽기('reaction'):''),
      kind:scene?'scene':task?'task':'look',outfit:ImageStudio_키필드읽기('outfit'),room:room+(ImageStudio_키필드읽기('abed')==='1'?'-bed':''),
      exposure:(ImageStudio_키필드읽기('exp')||'0000000'),aftermath:ImageStudio_키필드읽기('aft'),groupSlots:rawPosition.match(/-slots-([a-z]+)-/)?.[1]||ImageStudio_키필드읽기('gslot'),
      men:task||solo.has(scene)?0:group>0?group+1:1,mood:ImageStudio_키필드읽기('mood')||'default',
      position:typeof meta.position==='string'?meta.position:position||(/^(?:patron_)?(?:riding|sex|sex_rough|blowjob|deepthroat|cunnilingus|sixty_nine)$/.test(scene)?'scene:'+scene.replace(/^patron_/,''):''),
      emotions:setList(meta.emotions),badguest:setList(meta.badguest),pregnancy:typeof meta.pregnancy==='string'?meta.pregnancy:null,
      detail:setList(meta.detail),variant:Number(ImageStudio_키필드읽기('v'))||0,finish:ImageStudio_키필드읽기('fin'),cid:ImageStudio_키필드읽기('cid'),
      content:ImageStudio_키필드읽기('mod'),action:ImageStudio_키필드읽기('action')};
  }
  const sameSet=(a,b)=>a!==null&&b!==null&&JSON.stringify(a)===JSON.stringify(b);
  const shared=(a,b)=>a&&b?a.filter(x=>b.includes(x)).length:0;
  function relation(id,a,b,config,wife) {
    if(id==='exposure'){a=exposureValue(a);b=exposureValue(b);}
    if(a!==null&&b!==null&&a===b)return 'exact';
    const rule=config.rules[id];if(!rule.allowSimilar||a===null||b===null)return 'different';
    const groups=id==='outfit'&&Object.hasOwn(config.wifeOutfits,wife)?config.wifeOutfits[wife]:rule.groups;
    return groups.some(row=>row.includes(a)&&row.includes(b))?'similar':'different';
  }
  // 0=0과 1=1 모두 일치입니다. 불일치 시 가산을 없애고 지정된 음수 점수를 적용합니다.
  function ImageStudio_노출점수읽기(requestCode,candidateCode,rule){
    const a=exposureValue(requestCode),b=exposureValue(candidateCode);
    const bits=exposureFields.map(([field],index)=>rule.bitScores[field][a[index]===b[index]?'match':'mismatch']);
    const top=bits[0]+bits[1]+bits[2],skirt=bits[3]+bits[4],panties=bits[5]+bits[6];
    return {bits,top,skirt,panties,total:top+skirt+panties};
  }
  function score(request,candidate,config) {
    if(!request.character||request.character!==candidate.character||!candidate.scene||!candidate.outfit||!candidate.room)return null;
    // 콘텐츠와 행동은 확장의 의미 식별값입니다. 가중치를 낮춰도 다른 행동 그림으로 대체하지 않습니다.
    if(request.content!==candidate.content||request.action!==candidate.action)return null;
    if(candidate.position&&!candidate.position.startsWith('scene:')&&!positionApplicable(candidate.position,candidate.key))return null;
    const points={},matches={};let exposurePoints;
    for(const [id] of dimensions){const rule=config.rules[id];let status='different',value=0;
      if(id==='group'){
        const a=[...request.groupSlots],b=[...candidate.groupSlots];
        const counts=s=>s.reduce((m,c)=>(m[c]=(m[c]||0)+1,m),{}),ac=counts(a),bc=counts(b);
        const missing=Object.keys(ac).reduce((n,c)=>n+Math.max(0,ac[c]-(bc[c]||0)),0);
        const extra=Object.keys(bc).reduce((n,c)=>n+Math.max(0,bc[c]-(ac[c]||0)),0);
        const diff=Math.max(missing,extra),fewer=Math.max(0,request.men-candidate.men);
        status=!diff&&request.men===candidate.men?'exact':'different';
        value=status==='exact'?rule.exact:rule.allowSimilar?rule.exact-diff*rule.rolePenalty-fewer*rule.fewerPenalty:0;
        if(status!=='exact'&&rule.allowSimilar)status='similar';
      }else if(id==='exposure'){
        // 마무리 복장(fin)은 같은 경우만 인정하며, exp 유사는 등록된 쌍 안에서만 통과합니다.
        status=request.finish===candidate.finish?relation(id,request.exposure,candidate.exposure,config,request.character):'different';
        exposurePoints=ImageStudio_노출점수읽기(request.exposure,candidate.exposure,rule);value=exposurePoints.total;
      }else if(id==='aftermath'){
        status=relation(id,request.aftermath,candidate.aftermath,config,request.character);
        if(status==='exact')value=rule.exact;
        else if(!request.aftermath&&candidate.aftermath)value=-rule.extraPenalty;
        else if(request.aftermath&&candidate.aftermath)value=-rule.typePenalty;
      }else if(id==='badguest'||id==='detail'){
        const a=request[id],b=candidate[id];status=sameSet(a,b)?'exact':a!==null&&b!==null&&shared(a,b)>0&&rule.allowSimilar?'similar':'different';
        value=id==='badguest'?(status==='different'?0:rule.exact*shared(a,b)):status==='exact'&&a?.length?rule.exact:0;
      }else{
        status=relation(id,request[id],candidate[id],config,request.character);
        value=status==='exact'?rule.exact:status==='similar'?rule.similar:0;
        if(id==='mood')value+=rule.emotionBonus*shared(request.emotions,candidate.emotions);
      }
      if(rule.required&&status==='different')return null;
      points[id]=value;matches[id]=status;
    }
    return {total:Object.values(points).reduce((sum,n)=>sum+n,0),points,matches,exposure:exposurePoints};
  }
  const variantFamily=key=>String(ImageStudio_노출키정규화하기(normalizeKey(key))).replace(/__v-\d+(?=__|$)/g,'');
  const descriptors=new WeakMap(),compatibilityKeys=new WeakMap(),emptyMetadata={};
  function ImageStudio_후보상태읽기(entry,metadata=()=>null) {
    const rawSource=entry.matching||entry.debug?.imageMatching||metadata(entry.talentName)||emptyMetadata;
    const source=globalThis.WW_ImageStudioBridge?.extensions?.normalizeMatchingContext?.(rawSource)||rawSource;
    const normalizedKey=ImageStudio_노출키정규화하기(normalizeKey(compatibilityKeys.get(entry)||entry.talentName));
    let cached=descriptors.get(entry);
    if(!cached||cached.key!==normalizedKey||cached.source!==source){cached={key:normalizedKey,source,spec:describe(normalizedKey,source)};descriptors.set(entry,cached);}
    return cached.spec;
  }
  function ImageStudio_후보색인만들기(entries) {
    const characters=new Map();
    for(const entry of entries){
      if(typeof entry?.talentName!=='string'||typeof entry.imagePath!=='string'||!entry.imagePath||/\.(mp4|webm)$/i.test(entry.imagePath))continue;
      const separator=entry.talentName.indexOf('__'),character=separator<0?entry.talentName:entry.talentName.slice(0,separator);
      if(!characters.has(character))characters.set(character,{rows:[],axes:null,families:null,names:null});
      characters.get(character).rows.push(entry);
    }
    return characters;
  }
  // attention-image-prompt 1.41.77 (aaajjaaaadsfa)의 정확 키 우선 조회를 공통 매칭에 맞게 연결합니다.
  // 변형·메타데이터·필수 조건 검증과 추첨은 기존 함수를 그대로 거칩니다.
  function ImageStudio_정확키후보읽기(index,request) {
    const bucket=index.get(request.character);if(!bucket)return [];
    if(!bucket.families){
      bucket.families=new Map();bucket.names=new Map();
      for(const entry of bucket.rows){
        const family=variantFamily(entry.talentName);
        if(!bucket.families.has(family))bucket.families.set(family,[]);
        bucket.families.get(family).push(entry);
        if(!bucket.names.has(entry.talentName))bucket.names.set(entry.talentName,[]);
        bucket.names.get(entry.talentName).push(entry);
      }
    }
    const exact=bucket.families.get(variantFamily(request.key))||[];
    if(exact.length)return exact;
    const compact=ImageStudio_이전짧은키읽기(request.key);
    if(compact===request.key)return [];
    return (bucket.names.get(compact)||[]).map(entry=>{
      // 해시를 계산한 전체 키를 검증에 사용하고, 표시·파일 조회에는 실제 저장 키를 유지합니다.
      const compatible={...entry};compatibilityKeys.set(compatible,request.key);return compatible;
    });
  }
  // 1.41.24~1.41.77의 생성용 짧은 키를 읽기 호환으로만 계산합니다. 새 저장 규칙은 바꾸지 않습니다.
  function ImageStudio_이전짧은키읽기(key) {
    if(key.length<=120||key.includes('__aipk-')||!/__(?:scene|task|look)-/.test(key))return key;
    const hash=value=>{let n=2166136261;for(let i=0;i<value.length;i++){n^=value.charCodeAt(i);n=Math.imul(n,16777619);}return (n>>>0).toString(36);};
    const parts=key.split('__'),owner=parts[0],name=owner.length<=50?owner:owner.slice(0,40)+'-'+hash(owner);
    const situation=parts.find(part=>/^(?:scene|task|look)-/.test(part)).slice(0,42),variant=(key.match(/__v-\d+/)?.[0]||'').slice(0,20);
    return name+'__'+situation+'__aipk-'+hash(key)+hash([...key].reverse().join(''))+variant;
  }
  function ImageStudio_색인후보읽기(index,request,config) {
    const bucket=index.get(request.character);if(!bucket)return [];
    if(!bucket.axes){
      bucket.axes=Object.fromEntries(['scene','outfit','room'].map(id=>[id,new Map()]));
      // 축 분류에는 키만 필요합니다. 모든 이미지의 설정·감정 메타데이터를 미리 정규화하지 않습니다.
      for(const entry of bucket.rows){const spec=describe(entry.talentName);
        for(const [id,axis] of Object.entries(bucket.axes)){if(!axis.has(spec[id]))axis.set(spec[id],[]);axis.get(spec[id]).push(entry);}}
    }
    // 필수 축별 허용 목록은 기존 유사 조건·아내별 의상 설정으로 읽습니다.
    // 가장 작은 목록의 순서를 유지해야 기존 추첨의 묶음·변형 순서도 유지됩니다.
    let rows=bucket.rows;
    const required=[];
    for(const [id,axis] of Object.entries(bucket.axes))if(config.rules[id].required){
      const allowed=[...axis].filter(([value])=>relation(id,request[id],value,config,request.character)!=='different').flatMap(([,entries])=>entries);
      if(!allowed.length)return [];
      required.push(allowed);
      if(allowed.length<rows.length)rows=allowed;
    }
    // 다른 필수 축에도 속하는 항목만 상세 조건·점수 계산으로 넘깁니다.
    // 항목 객체의 소속 여부로 비교하므로 이미지 키·조건을 다시 정규화하지 않습니다.
    const memberships=required.filter(allowed=>allowed!==rows&&allowed.length<bucket.rows.length).map(allowed=>new Set(allowed));
    return memberships.length?rows.filter(entry=>memberships.every(allowed=>allowed.has(entry))):rows;
  }
  function choose(request,entries,config,metadata=()=>null,random=Math.random,options={}) {
    // 필수 조건으로 통과 여부를 정하고, 확률 점수의 크기로 후보를 잘라내지 않습니다.
    const passed=[],imageIdentity=options.imageIdentity || (entry=>entry.imagePath);
    for(const entry of entries){if(!entry||typeof entry.talentName!=='string'||typeof entry.imagePath!=='string'||!entry.imagePath||entry.talentName.split('__')[0]!==request.character||/\.(mp4|webm)$/i.test(entry.imagePath))continue;
      const spec=ImageStudio_후보상태읽기(entry,metadata);
      const result=score(request,spec,config);if(!result)continue;
      const optionalScore=dimensions.filter(([id])=>!config.rules[id].required).reduce((sum,[id])=>sum+result.points[id],0);
      // 노출은 사용자 요청으로 필수 판정과 확률 점수를 함께 사용합니다. 다른 필수 항목 점수는 확률에서 제외합니다.
      const lotteryScore=optionalScore+(config.rules.exposure.required?result.points.exposure:0);
      passed.push({entry,spec,score:result,optionalScore,lotteryScore});
    }
    if(!passed.length)return null;
    // 최근 5개 파일을 우선 제외합니다. 모두 제외되면 필수 통과 후보 전체로 돌아갑니다.
    const recent=new Set(options.recent || []),unseen=passed.filter(item=>!recent.has(imageIdentity(item.entry)));
    const pool=unseen.length?unseen:passed,historyFallback=!unseen.length&&recent.size>0,families=new Map();
    for(const item of pool){
      const {entry}=item;
      const family=variantFamily(entry.talentName);
      if(!families.has(family))families.set(family,[]);
      families.get(family).push(item);
    }
    // 같은 묶음의 변형 수는 가중치에 곱하지 않습니다. 메타데이터가 다른 변형은 최고 추첨 점수를 대표값으로 씁니다.
    const groups=[...families].map(([id,variants])=>{
      const representative=variants.reduce((best,item)=>!best||item.lotteryScore>best.lotteryScore?item:best,null);
      return {id,variants,optionalScore:representative.optionalScore,lotteryScore:representative.lotteryScore};
    });
    let minimum=Infinity,maximum=-Infinity;
    for(const group of groups){minimum=Math.min(minimum,group.lotteryScore);maximum=Math.max(maximum,group.lotteryScore);}
    for(const group of groups)group.weight=maximum===minimum?1:1+0.5*(group.lotteryScore-minimum)/(maximum-minimum);
    const totalWeight=groups.reduce((sum,group)=>sum+group.weight,0);
    let draw=random()*totalWeight,selected=groups.at(-1);
    for(const group of groups){draw-=group.weight;if(draw<0){selected=group;break;}}
    const variants=selected.variants,item=variants[Math.floor(random()*variants.length)];
    return {...item,variantCount:variants.length,familyCount:groups.length,eligibleCount:pool.length,passedCount:passed.length,
      excludedRecent:passed.length-unseen.length,historyFallback,familyWeight:selected.weight,familyProbability:selected.weight/totalWeight,
      familyOptionalScore:selected.optionalScore,familyLotteryScore:selected.lotteryScore,weightMinimum:1,weightMaximum:maximum===minimum?1:1.5};
  }
  // 생성 허용 시에는 점수와 유사 묶음을 사용하지 않습니다. 변형 번호와 인물 인스턴스 ID는 재사용 조건에서 제외합니다.
  // 키로 표현되지 않는 현재 상태가 있으면 이미지에도 같은 기록이 있어야 합니다. 기록 누락을 일치로 추정하지 않습니다.
  function ImageStudio_정확조건인가(request,candidate) {
    const fields=['character','kind','scene','outfit','room','exposure','aftermath','men','position','mood','finish','content','action'];
    if(fields.some(id=>request[id]!==candidate[id]))return false;
    if([...request.groupSlots].sort().join('')!==[...candidate.groupSlots].sort().join(''))return false;
    for(const id of ['emotions','badguest','detail'])if(request[id]!==null&&!sameSet(request[id],candidate[id]))return false;
    if(request.pregnancy!==null&&request.pregnancy!==candidate.pregnancy)return false;
    // 대화·의미 상태 등의 확장 전용 조건도 같아야 합니다. 과거 자세 키에 남은 문구 해시도 그대로 비교합니다.
    const parsed=new Set(['scene','task','look','reaction','outfit','room','abed','exp','aft','gslot','grp','mood','fin','mod','action','cid','v']);
    const extra=key=>String(key).split('__').slice(1).filter(part=>!parsed.has(part.slice(0,part.indexOf('-')))).sort();
    return JSON.stringify(extra(request.key))===JSON.stringify(extra(candidate.key));
  }
  function ImageStudio_정확이미지고르기(request,entries,config,metadata=()=>null,random=Math.random) {
    const exact=entries.filter(entry=>entry?.imagePath&&!/\.(mp4|webm)$/i.test(entry.imagePath)
      &&ImageStudio_정확조건인가(request,ImageStudio_후보상태읽기(entry,metadata)));
    if(!exact.length)return null;
    // 생성 ON의 기존 정확 일치 규칙은 유지합니다. 요청 묶음이 없으면 최신 정확 묶음의 변형을 재사용합니다.
    let family=variantFamily(request.key);
    if(!exact.some(entry=>variantFamily(entry.talentName)===family)){
      let newest=null;
      for(const entry of exact)if(!newest||(entry.createdAt||0)>(newest.createdAt||0)
        ||((entry.createdAt||0)===(newest.createdAt||0)&&String(entry.imagePath).localeCompare(String(newest.imagePath))<0))newest=entry;
      family=variantFamily(newest.talentName);
    }
    return choose(request,exact.filter(entry=>variantFamily(entry.talentName)===family),config,metadata,random);
  }
  return {dimensions,defaults,normalize,describe,score,choose,relation,field,exposureStates,exposureFields,ImageStudio_노출점수읽기,
    ImageStudio_후보색인만들기,ImageStudio_정확키후보읽기,ImageStudio_이전짧은키읽기,ImageStudio_색인후보읽기,ImageStudio_정확조건인가,ImageStudio_정확이미지고르기};
}

function ImageStudio_이미지매칭연결하기(api) {
  const matcher=ImageStudio_매칭엔진만들기((id,key)=>globalThis.WW_ImageStudioPrompt?.positionApplicable?.(id,key)??true,
    key=>globalThis.WW_ImageStudioBridge?.extensions?.normalizeKey(key)??key),storageKey='wml.mod.imagestudio.image-matching';
  let config=matcher.defaults(),settingsError='',windowHandle=null,body=null,tab='scene',wife='',status='',catalogue=null,pending=null,revision=0,packSources=[],serverUrl='',serverGeneration=0;
  const metadata=new Map(),decisions=new Map(),decisionRequests=new Map(),serverPacks=new Map(),serverRequests=new Map(),serverTimes=new Map(),fileChecks=new Map(),h=api.ui.h;
  const recentImages=[],shownDecisions=new WeakSet(),drawListeners=new Set();
  let drawEpoch=0;
  const ImageStudio_이미지주소읽기=entry=>api.fn('imageEntryUrl')(entry);
  const ImageStudio_표시파일식별하기=entry=>new URL(ImageStudio_이미지주소읽기(entry),location.href).href;
  function ImageStudio_추첨갱신하기(resetHistory=false){
    drawEpoch++;decisions.clear();decisionRequests.clear();
    if(resetHistory)recentImages.length=0;
    for(const listener of drawListeners)listener();
  }
  function ImageStudio_표시기록추가하기(candidate,mode){
    if(mode!=='similar'||candidate.drawEpoch!==drawEpoch||shownDecisions.has(candidate))return;
    shownDecisions.add(candidate);
    const identity=ImageStudio_표시파일식별하기(candidate.entry),previous=recentImages.indexOf(identity);
    if(previous>=0)recentImages.splice(previous,1);
    recentImages.unshift(identity);recentImages.length=Math.min(5,recentImages.length);
  }
  try{
    const saved=localStorage.getItem(storageKey);
    if(saved){
      const previous=JSON.parse(saved);config=matcher.normalize(previous);
      if(previous.version===1){
        const backupKey=storageKey+'.before-exposure-v2';
        if(localStorage.getItem(backupKey)===null)localStorage.setItem(backupKey,saved);
        localStorage.setItem(storageKey,JSON.stringify(config));
        status='기존 설정을 보존하고 노출 필수 조건·유사 쌍·비트별 점수를 적용했습니다.';
      }
    }
  }catch(error){settingsError='저장된 설정을 읽지 못해 기본값을 사용합니다: '+error.message;}
  const placeholder='data:image/svg+xml;charset=utf-8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="832" height="1216" viewBox="0 0 832 1216"><rect width="832" height="1216" fill="#292524"/><text x="416" y="608" text-anchor="middle" font-family="sans-serif" font-size="34" fill="#a8a29e">이미지 없음</text></svg>');
  function ImageStudio_탐색체계표시맞추기(){
    const checkbox=document.getElementById('wwis-image-matching-enabled');
    if(checkbox)checkbox.checked=config.enabled;
    const note=document.getElementById('wwis-image-matching-status');
    if(note)note.textContent=config.enabled?'켜짐: 이미지 매칭·추첨 설정을 사용합니다.':'꺼짐: 기본 이미지 탐색을 사용합니다. 매칭·추첨 설정은 보존합니다.';
    const generationNote=document.getElementById('wwis-generation-matching-note');
    if(generationNote)generationNote.textContent=config.enabled
      ?'이미지 생성을 끄거나 위 항목을 체크하면 조건 계산식이 적용되어 유사하지만 다른 이미지가 나올 수도 있습니다. 생성이 켜져 있으면 정확한 조건의 이미지가 없을 때 새로 생성합니다.'
      :'이미지 탐색 체계가 꺼져 있어 기본 이미지 탐색을 사용합니다. 자동 이미지 생성 여부는 위 체크박스로 별도 지정합니다.';
  }
  function save(next){const normalized=matcher.normalize(next);localStorage.setItem(storageKey,JSON.stringify(normalized));config=normalized;revision++;ImageStudio_탐색체계표시맞추기();ImageStudio_추첨갱신하기();status='저장했습니다. 다음 이미지 조회부터 적용됩니다.';settingsError='';return config;}
  function capture(key,character){if(typeof key!=='string')return;
    const value=globalThis.WW_ImageStudioPrompt?.matchingContext?.(key,character);if(value)metadata.set(key,value);
    if(metadata.size>10000)metadata.delete(metadata.keys().next().value);
  }
  // 서버 목록의 주기적 갱신만으로 같은 화면의 추첨 결과를 바꾸지 않습니다.
  function ImageStudio_목록비우기(){catalogue=null;revision++;}
  function ImageStudio_서버목록갱신하기(character){
    const url=globalThis.WW_ImageStudioBridge?.connection?.()?.baseUrl||'';
    if(url!==serverUrl){serverUrl=url;serverGeneration++;serverPacks.clear();serverRequests.clear();serverTimes.clear();ImageStudio_목록비우기();}
    if(!url)return null;
    if(serverRequests.has(character))return serverRequests.get(character);
    if(Date.now()-(serverTimes.get(character)||0)<30000)return null;
    const generation=serverGeneration;
    const request=Promise.resolve().then(async()=>{
      try{
        const response=await fetch(url+'/api/pack?characters='+encodeURIComponent(character),{credentials:'omit',signal:AbortSignal.timeout(2000)});
        if(!response.ok)return;
        const pack=await response.json();if(serverGeneration!==generation||!pack.entries||typeof pack.entries!=='object')return;
        // generatedAt은 조회 시각일 수 있습니다. 선택에 사용되는 실제 항목 내용으로 비교합니다.
        const previous=serverPacks.get(character);
        const signature=JSON.stringify(pack.entries);
        if(previous?.signature===signature)return;
        serverPacks.set(character,{...pack,priority:1,source:'server',signature});ImageStudio_목록비우기();
      }catch{}finally{if(serverGeneration===generation){serverTimes.set(character,Date.now());if(serverRequests.get(character)===request)serverRequests.delete(character);}}
    });
    serverRequests.set(character,request);return request;
  }
  async function entries(){
    const bridge=globalThis.WW_ImageStudioBridge;
    const sources=bridge?.packs?.()||[];
    if(catalogue&&sources.length===packSources.length&&sources.every((pack,index)=>pack===packSources[index]))return catalogue;
    if(pending)return pending;
    pending=(async()=>{
      await bridge?.ready?.();packSources=[...(bridge?.packs?.()||[])];
      const packs=[...packSources,...serverPacks.values()].sort((a,b)=>(b.priority||0)-(a.priority||0)||String(b.generatedAt||'').localeCompare(String(a.generatedAt||'')));
      const rows=[],duplicates=new Map();
      for(const pack of packs)for(const entry of Object.values(pack.entries||{}))if(entry?.talentName&&entry.imagePath){
        const value=pack.source==='server'?{...entry,source:'server'}:entry;
        // 같은 키라도 다른 파일·상태·주소는 누락 파일의 대체 후보이므로 보존합니다.
        const previous=duplicates.get(value.talentName);
        if(previous&&previous.imagePath===value.imagePath&&JSON.stringify(previous.matching||previous.debug?.imageMatching||null)===JSON.stringify(value.matching||value.debug?.imageMatching||null)
          &&ImageStudio_표시파일식별하기(previous)===ImageStudio_표시파일식별하기(value))continue;
        if(!previous)duplicates.set(value.talentName,value);
        rows.push(value);
      }
      catalogue=matcher.ImageStudio_후보색인만들기(rows);return catalogue;
    })().finally(()=>pending=null);return pending;
  }
  async function ImageStudio_선택파일확인하기(entry){
    const url=new URL(ImageStudio_이미지주소읽기(entry),location.href).href,cached=fileChecks.get(url);
    if(cached&&Date.now()-cached.at<30000)return cached.promise;
    const promise=(async()=>{
      if(url.startsWith('file:'))return new Promise(resolve=>{
        const image=new Image(),timer=setTimeout(()=>ImageStudio_파일확인마치기(null),1000);
        const ImageStudio_파일확인마치기=value=>{clearTimeout(timer);image.onload=null;image.onerror=null;resolve(value);};
        image.onload=()=>ImageStudio_파일확인마치기(true);image.onerror=()=>ImageStudio_파일확인마치기(false);image.src=url;
      });
      try{const response=await fetch(url,{method:'HEAD',credentials:'omit',signal:AbortSignal.timeout(1000)});
        return response.ok?true:[404,410].includes(response.status)?false:null;
      }catch{return null;}
    })();
    const record={at:Date.now(),promise};fileChecks.set(url,record);
    promise.then(value=>{record.value=value;if(value===null&&fileChecks.get(url)===record)fileChecks.delete(url);});
    if(fileChecks.size>5000)fileChecks.delete(fileChecks.keys().next().value);
    return promise;
  }
  // 사용자 설정과 서버의 일시적인 연결 실패를 구분합니다. 생성 허용 중 서버가 바빠도 유사 이미지로 대체하지 않습니다.
  function ImageStudio_선택방식읽기(){
    return globalThis.__WW_STUDIO_OFFLINE_ONLY__===true||api.fn('settingsStore').getState().imageBackendMode==='off'?'similar':'exact';
  }
  async function resolve(key,provided,mode=ImageStudio_선택방식읽기()){
    if(!config.enabled)return null;
    const rawContext=provided||metadata.get(key)||{};
    const context=globalThis.WW_ImageStudioBridge?.extensions?.normalizeMatchingContext?.(rawContext)||rawContext;
    const started=performance.now(),request=matcher.describe(key,context),settings=config,epoch=drawEpoch;
    const identity=JSON.stringify([key,context,mode,epoch]),cached=decisions.get(identity);
    function ImageStudio_추첨결과알리기(record,cacheHit){
      const candidate=record.value;
      globalThis.WW_ImageStudioMatching.last={key,mode,resolvedKey:candidate?.entry.talentName||'',total:candidate?.score.total??null,
        points:candidate?.score.points||{},matches:candidate?.score.matches||{},variantCount:candidate?.variantCount||0,
        familyCount:candidate?.familyCount||0,familyWeight:candidate?.familyWeight??null,familyProbability:candidate?.familyProbability??null,
        optionalScore:candidate?.familyOptionalScore??null,lotteryScore:candidate?.familyLotteryScore??null,
        exposurePoints:candidate?.score.exposure||null,weightMaximum:candidate?.weightMaximum??null,
        passedCount:candidate?.passedCount||0,excludedRecent:candidate?.excludedRecent||0,historyFallback:!!candidate?.historyFallback,drawEpoch:epoch,
        required:matcher.dimensions.filter(([id])=>settings.rules[id].required).map(([id,label])=>({id,label})),cached:cacheHit,missing:!candidate,
        durationMs:Math.round(performance.now()-started),candidates:record.candidates,checkedFiles:record.checked,missingFiles:record.missing};
      return candidate;
    }
    if(cached)return ImageStudio_추첨결과알리기(cached,true);
    // 동시에 들어온 초상화·조회 요청은 한 번의 추첨을 공유합니다.
    if(decisionRequests.has(identity))return decisionRequests.get(identity);
    const task=(async()=>{
      const update=ImageStudio_서버목록갱신하기(request.character);
      let index=await entries(),candidate=null,checked=0,missing=0,count=0,waited=false;
      const deadline=performance.now()+2000;
      while(true){
        const available=entries=>{const seen=new Set();return entries.filter(entry=>{
          const check=fileChecks.get(ImageStudio_표시파일식별하기(entry));
          if(check?.value===false&&Date.now()-check.at<30000)return false;
          if(seen.has(entry.talentName))return false;seen.add(entry.talentName);return true;
        });};
        let rows=mode==='exact'?available(matcher.ImageStudio_정확키후보읽기(index,request)):[];
        candidate=rows.length?matcher.ImageStudio_정확이미지고르기(request,rows,settings):null;
        if(!candidate){
          rows=available(matcher.ImageStudio_색인후보읽기(index,request,settings));
          candidate=mode==='exact'?matcher.ImageStudio_정확이미지고르기(request,rows,settings):matcher.choose(request,rows,settings,
          key=>metadata.get(key),Math.random,{recent:recentImages,imageIdentity:ImageStudio_표시파일식별하기});
        }
        count=rows.length;
        if(!candidate){if(update&&!waited){waited=true;await update;index=await entries();continue;}break;}
        checked++;if(await ImageStudio_선택파일확인하기(candidate.entry)!==false)break;
        missing++;candidate=null;if(performance.now()>=deadline)break;
      }
      if(candidate)candidate={...candidate,drawEpoch:epoch};
      const record={value:candidate,candidates:count,checked,missing};
      // 결과가 있는 화면은 시간 경과로 만료시키지 않습니다. 누락은 새 팩이 도착한 다음 다시 확인할 수 있습니다.
      if(settings===config&&epoch===drawEpoch&&candidate)decisions.set(identity,record);
      if(decisions.size>500)decisions.delete(decisions.keys().next().value);
      return ImageStudio_추첨결과알리기(record,false);
    })();
    decisionRequests.set(identity,task);
    try{return await task;}finally{if(decisionRequests.get(identity)===task)decisionRequests.delete(identity);}
  }
  const supported=key=>{if(typeof key!=='string')return false;const row=matcher.describe(key);return !!(row.character&&row.scene&&row.outfit&&row.room);};
  // The outermost hook owns every fallback, so the old nearest lookup cannot bypass required clothing/room rules.
  api.hook('imageLookup',{priority:-2000000,async around(next,key,...args){
    if(!config.enabled||!supported(key))return next(key,...args);
    const candidate=await resolve(key);
    return config.enabled?candidate?.entry||null:next(key,...args);
  }});
  api.hook('imagePrompt',{priority:-2000000,after(result,[character]){if(config.enabled&&result?.key){capture(result.key,character);if(metadata.has(result.key))return {...result,imageMatching:metadata.get(result.key)};}}});
  api.hook('imageGenerate',{priority:-2000000,async around(next,request){
    if(!config.enabled)return next(request);
    const meta=request.debug?.imageMatching||metadata.get(request.imageKey);const value={...request,debug:{...request.debug,...(meta?{imageMatching:meta}:{})}};
    // 생성 함수 내부의 두 번째 조회에도 같은 맥락을 전달합니다. 외부 모드가 debug로 제공한 경우도 포함합니다.
    if(meta){metadata.set(request.imageKey,meta);if(metadata.size>10000)metadata.delete(metadata.keys().next().value);}
    const send=async()=>{const result=await next(value);if(result?.fresh){ImageStudio_목록비우기();serverTimes.delete(matcher.describe(request.imageKey).character);fileChecks.clear();}return result;};
    if(request.bulk||request.bypassCache||!supported(request.imageKey))return send();
    let mode=ImageStudio_선택방식읽기(),epoch=drawEpoch,candidate=await resolve(request.imageKey,meta,mode);
    // 파일 확인 중 행동이 바뀌어도 게임의 동일 키 요청 대기열에 이전 추첨 결과가 남지 않게 합니다.
    while(config.enabled&&mode==='similar'&&epoch!==drawEpoch){epoch=drawEpoch;mode=ImageStudio_선택방식읽기();candidate=await resolve(request.imageKey,meta,mode);}
    if(!config.enabled)return next(request);
    if(candidate){ImageStudio_표시기록추가하기(candidate,mode);return {url:ImageStudio_이미지주소읽기(candidate.entry),key:candidate.entry.talentName,fresh:false};}
    const missing=()=>({url:placeholder,key:request.imageKey,fresh:false,imageMatchingMissing:true});
    if(mode==='similar')return missing();
    try{
      const bridge=globalThis.WW_ImageStudioBridge,connection=bridge?.connection?.();
      if(globalThis.__WW_STUDIO_OFFLINE_ONLY__===true||!connection?.baseUrl||connection.comfyui!==true)return missing();
      if(await bridge.generationUnavailable?.())return missing();
      const result=await send();
      return result?.url?result:missing();
    }catch{return missing();}
  }});
  function ImageStudio_매칭목록새로읽기(){ImageStudio_목록비우기();ImageStudio_추첨갱신하기();serverGeneration++;serverPacks.clear();serverRequests.clear();serverTimes.clear();fileChecks.clear();prepared.clear();}
  api.hook('imagePackReset',{after:ImageStudio_매칭목록새로읽기});
  // WML은 바닐라와 등록된 모드 행동이 모두 끝난 뒤 관찰자를 호출합니다.
  // 미리보기·단순 렌더·서버 응답은 게임 행동으로 세지 않습니다.
  const stopActions=api.actions.observe(()=>ImageStudio_추첨갱신하기());
  const stopStore=api.store.subscribe((current,previous)=>{
    const session=root=>root?.state?.mods?.imagestudio?.usageSession?.id || '';
    if(current.started!==previous.started||session(current)!==session(previous))ImageStudio_추첨갱신하기(true);
    else if((current.undoStack?.length||0)<(previous.undoStack?.length||0))ImageStudio_추첨갱신하기();
  });
  // 행동 번호는 요청 효과만 다시 실행합니다. 표시 부품과 기존 이미지 요소는 유지합니다.
  const ImageStudio_추첨구독하기=listener=>{drawListeners.add(listener);return()=>drawListeners.delete(listener);};
  const ImageStudio_화면추첨번호읽기=()=>config.enabled&&ImageStudio_선택방식읽기()==='similar'?drawEpoch+1:0;
  const prepared=new Map();
  function prepare(url){
    if(prepared.has(url))return prepared.get(url);
    const promise=new Promise(resolve=>{
      const image=new Image();let done=false;
      const finish=value=>{if(done)return;done=true;clearTimeout(timer);image.onload=null;image.onerror=null;resolve(value);};
      const timer=setTimeout(()=>finish(null),10000);
      image.onload=()=>{Promise.resolve(image.decode?.()).then(()=>finish(true),()=>finish(false));};
      image.onerror=()=>finish(false);image.src=url;
    });
    prepared.set(url,promise);promise.then(value=>{if(value!==true)prepared.delete(url);});
    if(prepared.size>24)prepared.delete(prepared.keys().next().value);
    return promise;
  }
  const nativeLoad=api.fn('sv');
  async function loadPortrait(request){
    for(let attempt=0;attempt<3;attempt++){
      const result=await nativeLoad(request);if(!result?.url)return result;
      if(result.fresh)prepared.delete(result.url);
      const ready=await prepare(result.url);if(ready)return result;
      if(ready===null||!config.enabled||request.bypassCache)return {...result,url:placeholder,imageMatchingMissing:true};
      const url=new URL(result.url,location.href).href;
      fileChecks.set(url,{at:Date.now(),value:false,promise:Promise.resolve(false)});decisions.clear();
    }
    return {url:placeholder,key:request.imageKey,fresh:false,imageMatchingMissing:true};
  }
  const portrait=ImageStudio_표시패널만들기(api,{subscribe:ImageStudio_추첨구독하기,snapshot:ImageStudio_화면추첨번호읽기,load:loadPortrait});
  api.hook('imageUsagePortraitPanel',{replace:portrait});
  window.addEventListener('pagehide',()=>{stopActions();stopStore();drawListeners.clear();},{once:true});
  function axes(){const base=globalThis.WW_ImageStudioBridge?.axes?.()||{};const detail=globalThis.WW_ImageStudioPrompt?.axes?.()||[];
    const position=(detail.find(axis=>axis.id==='promptPosition')?.items||[]).filter(x=>x.value!=='auto');
    const result={scene:base.situation||[],outfit:base.outfit||[],room:[...(base.room||[]).map(x=>x.value==='bedroom (침대 위)'?{...x,value:'bedroom-bed',label:'침실 · 침대 위'}:{...x}),{value:'guest_room',label:'객실 (과거 매칭용 ID)'},{value:'guest_room-bed',label:'객실 - 침대 위 (과거 매칭용 ID)'}],position:[...position,...(base.situation||[]).map(x=>({value:'scene:'+x.value.replace(/^patron_/,''),label:'장면: '+x.label}))],mood:base.mood||[],
      exposure:matcher.exposureStates.map(row=>({value:row.value,label:row.number+'. '+row.label}))};
    for(const [id,label] of [['resting','휴식 중'],['sleeping','수면 중']])if(!result.scene.some(row=>row.value===id))result.scene.push({value:id,label});
    return result;
  }
  const labels={rolePenalty:'역할 하나 불일치 감점',fewerPenalty:'부족한 남자 1명당 감점',extraPenalty:'요청에 없는 흔적 감점',typePenalty:'흔적 종류 불일치 감점',emotionBonus:'모드 감정 1개 일치 가산'};
  function render(){if(!body)return;body.classList.add('wwis-matching');const rule=config.rules[tab],currentAxes=axes();
    const title=matcher.dimensions.find(([id])=>id===tab)[1];
    const nav=h('div',{class:'wwis-match-tabs',role:'tablist'});
    for(const [i,id] of config.order.entries())nav.append(h('button',{type:'button',role:'tab','aria-selected':String(id===tab),'data-match-tab':id,onclick:()=>{tab=id;wife='';render();}},`${i+1}. ${matcher.dimensions.find(([key])=>key===id)[1]}`));
    const check=(key,text,note)=>h('div',{},h('label',{},h('input',{type:'checkbox',checked:rule[key],'data-match-check':key,onchange:event=>{const next=structuredClone(config);next.rules[tab][key]=event.target.checked;try{save(next);render();}catch(e){status=e.message;render();}}}),text),h('p',{class:'wwis-dim'},note));
    const content=h('section',{'data-match-content':tab},
      check('required','필수 항목 (불일치 이미지 제외)','이미지 생성이 꺼져 있을 때 이 항목이 일치하지 않으면 후보에서 제외합니다. 유사 항목을 허용한 경우 등록된 유사 항목까지 인정합니다. 후보가 없으면 “이미지 없음”을 표시합니다. 생성이 켜져 있으면 모든 조건의 정확 일치 이미지를 찾고, 없으면 새로 생성합니다.'),
      check('allowSimilar','유사 항목 허용 여부','끄면 유사 묶음이나 부분 일치 점수를 사용하지 않습니다. 필수 항목에서는 완전 일치만 통과합니다. 유사 관계는 같은 줄 안에서만 적용되며 다른 줄로 연쇄 확장하지 않습니다.'),
      h('h3',{},title),h('p',{'data-match-lottery-note':''},'이미지 생성이 꺼져 있으면 필수 조건을 통과한 모든 묶음에서 추첨합니다. 비필수 점수와 노출 비트 점수를 가중치 1~1.5로 환산하고, 묶음을 먼저 뽑은 뒤 변형을 균등하게 고릅니다. 다른 필수 항목의 점수와 탭 순서는 확률에 더하지 않습니다. 최근 표시한 5개 파일은 제외하며, 남는 후보가 없으면 최근 이미지도 다시 허용합니다. 게임 행동 후 다시 추첨하고 같은 화면의 재표시는 시간 제한 없이 유지합니다.'),
      h('div',{class:'wwis-match-row'},h('button',{type:'button','data-match-move':'up',disabled:config.order.indexOf(tab)===0,onclick:()=>move(-1)},'탭 순서 ↑'),h('button',{type:'button','data-match-move':'down',disabled:config.order.indexOf(tab)===config.order.length-1,onclick:()=>move(1)},'탭 순서 ↓')));
    for(const key of ['exact',...(['scene','outfit','room','position','mood'].includes(tab)?['similar']:[]),...Object.keys(labels)].filter(key=>Object.hasOwn(rule,key))){const input=h('input',{type:'number',min:0,max:1000000,step:1,value:rule[key],'data-match-number':key,onchange:event=>{try{if(event.target.value.trim()==='')throw Error('점수를 입력하세요.');const next=structuredClone(config);next.rules[tab][key]=Number(event.target.value);save(next);statusNode();}catch(error){status=error.message;statusNode();}}});content.append(h('label',{class:'wwis-match-row'},labels[key]||(key==='exact'?'완전 일치 점수':'유사 항목 일치 점수'),input));}
    if(tab==='exposure'){
      const maximum=matcher.ImageStudio_노출점수읽기('0000000','0000000',rule);
      content.append(h('h4',{},`완전 일치 ${maximum.total}점 · 상의 ${maximum.top} / 치마 ${maximum.skirt} / 팬티 ${maximum.panties}`),
        h('p',{class:'wwis-dim'},'0=0과 1=1 모두 일치입니다. 불일치 시 일치 가산 대신 아래 음수 점수를 적용합니다. 앞섶 풀림 불일치는 기본 0점입니다.'));
      const grid=h('div',{class:'wwis-exposure-points'},h('strong',{},'항목'),h('strong',{},'일치'),h('strong',{},'불일치'));
      for(const [field,label] of matcher.exposureFields){
        grid.append(h('span',{},label));
        for(const kind of ['match','mismatch'])grid.append(h('input',{type:'number',step:1,min:kind==='match'?0:-1000000,max:kind==='match'?1000000:0,
          value:rule.bitScores[field][kind],'aria-label':label+' '+(kind==='match'?'일치 점수':'불일치 점수'),'data-match-exposure-score':field+':'+kind,
          onchange:event=>{try{
            if(event.target.value.trim()==='')throw Error('점수를 입력하세요.');
            const next=structuredClone(config);next.rules.exposure.bitScores[field][kind]=Number(event.target.value);save(next);render();
          }catch(error){status=error.message;statusNode();}}}));
      }
      content.append(grid);
    }
    const notes={group:'역할은 순서가 아닌 종류별 개수로 비교합니다. 완전 일치 5,000점에서 역할 차이와 부족한 남자 수만큼 감점합니다. 남자가 더 많은 후보에는 추가 인원 감점이 없습니다.',exposure:'게임 규칙으로 정규화한 상의 3자리·치마 2자리·팬티 2자리를 비교합니다. 기본은 필수이며 완전 일치 또는 아래 등록된 유사 쌍만 통과합니다. 유사 관계는 연쇄 확장하지 않습니다. 노출이 필수일 때 마무리 복장(fin)이 다르면 통과하지 않습니다. 예: exp-0010000과 exp-0110000은 같은 상의 탈의 상태입니다.',aftermath:'요청의 흔적이 후보에 없으면 0점입니다. 요청에 없는 흔적은 감점하고, 양쪽의 종류가 다르면 종류 불일치 감점을 적용합니다.',position:'“장면:” 항목은 추가 자세가 없는 기본 장면을 뜻합니다. 이중 삽입처럼 여러 줄에 있는 항목도 다른 줄의 모든 자세를 서로 연결하지 않습니다.',badguest:'확인 가능한 상태 1개가 일치할 때마다 가산합니다. 과거 이미지에 상태 정보가 없으면 추측하지 않으며, 필수로 설정한 경우 제외합니다.',pregnancy:'임신 없음·초기·중기·후기·산후 상태가 일치할 때 가산합니다. 과거 이미지에 상태 정보가 없으면 점수를 주지 않습니다.',detail:'확인 가능한 모드 세부 상황 코드 목록이 일치하면 가산합니다. 감정·나쁜 손님·임신 항목은 각 전용 탭에서 계산합니다.',mood:'기본 기분의 일치·유사 점수에 더해, 기록된 모드 감정이 일치할 때마다 별도 가산합니다.'};
    if(notes[tab])content.append(h('p',{class:'wwis-dim'},notes[tab]));
    if(currentAxes[tab]){
      let groups=rule.groups;
      if(tab==='outfit'){
        const wives=globalThis.WW_ImageStudioBridge?.wives?.()||[];
        const select=h('select',{'data-match-wife':'',onchange:event=>{wife=event.target.value;render();}},h('option',{value:''},"전체 그녀 공통"));
        for(const row of wives){const id=row.shortname||row.id;select.append(h('option',{value:id},row.name||id));}select.value=wife;
        content.append(h('label',{class:'wwis-match-row'},"캐릭터별 유사 복장",select));
        if(wife){const own=Object.hasOwn(config.wifeOutfits,wife);groups=own?config.wifeOutfits[wife]:rule.groups;
          content.append(h('p',{class:'wwis-dim'},own?"이 캐릭터의 별도 목록을 사용합니다.":"공통 목록을 사용 중입니다. 아래 목록을 저장하면 이 캐릭터에게만 적용합니다."),h('button',{type:'button','data-match-inherit':'',onclick:()=>{const next=structuredClone(config);delete next.wifeOutfits[wife];save(next);render();}},"이 캐릭터는 공통 목록 사용"));
        }
      }
      const options=currentAxes[tab];
      const editor=h('textarea',{'data-match-groups':'',rows:Math.max(4,Math.min(12,groups.length+1))});
      editor.value=groups.map(row=>row.join(' | ')).join('\n');
      content.append(h('h4',{},'유사 항목 묶음'),h('p',{class:'wwis-dim'},tab==='exposure'?'한 줄이 한 묶음입니다. 36개 목록의 번호 또는 7자리 코드를 | 로 구분합니다. 예: 1 | 2. 서로 다른 줄을 이어 붙이지 않습니다.':'한 줄이 한 묶음입니다. 항목 ID를 | 로 구분합니다. 아래 목록에서 조건부 생성의 한글 이름과 ID를 확인하세요. 같은 이름의 다른 항목은 반드시 ID로 구분합니다.'),editor,
        h('button',{type:'button','data-match-save-groups':'',onclick:()=>{try{
          const names=new Map();for(const item of options)for(const label of [item.value,item.label,item.label.replace(/\s*\([^)]*\)\s*/g,'')]){if(!names.has(label))names.set(label,new Set());names.get(label).add(item.value);}
          const rows=editor.value.split(/\r?\n/).map(s=>s.trim()).filter(Boolean).map(line=>line.split('|').map(s=>{const v=s.trim();
            if(tab==='exposure'&&/^\d{1,2}$/.test(v)){const entry=matcher.exposureStates[Number(v)-1];if(!entry)throw Error('노출 번호는 1~36입니다.');return entry.value;}
            if(/^[a-z0-9_:.-]+$/.test(v))return v;const tagged=v.match(/\(([a-z0-9_:.-]+)\)$/);if(tagged&&options.some(item=>item.value===tagged[1]))return tagged[1];const ids=names.get(v);if(ids?.size===1)return [...ids][0];if(ids?.size>1)throw Error('같은 이름의 ID가 여러 개입니다. ID로 입력하세요: '+v+' — '+[...ids].join(', '));throw Error('알 수 없는 이름: '+v);}));
          const next=structuredClone(config);if(tab==='outfit'&&wife)next.wifeOutfits[wife]=rows;else next.rules[tab].groups=rows;save(next);render();
        }catch(error){status=error.message;statusNode();}}},'유사 목록 저장'),
        h('details',{},h('summary',{},'사용 가능한 항목 이름·ID'),h('div',{class:'wwis-match-options'},...options.map(item=>h('div',{},item.label+' ('+item.value+')')))));
    }
    const importInput=h('input',{type:'file',accept:'.json,application/json',hidden:true,'data-match-import-file':'',onchange:async event=>{try{const file=event.target.files?.[0];if(!file)return;if(file.size>2000000)throw Error('설정 파일은 2MB 이하여야 합니다.');save(JSON.parse(await file.text()));render();}catch(error){status=error.message;statusNode();}finally{event.target.value='';}}});
    body.replaceChildren(h('p',{},'이미지 생성을 끄거나 오프라인 이미지팩 전용을 체크하면 조건 계산식이 적용되어 유사하지만 다른 이미지가 나올 수도 있습니다. 이때 필수 조건을 먼저 검사한 뒤 가중치로 비교합니다. 캐릭터가 다른 이미지는 항상 제외합니다. 이전 프롬프트 해시만으로는 세부 상태를 복원할 수 없어 해당 정보가 없는 이미지에는 가산하지 않습니다.'),nav,content,
      h('div',{class:'wwis-match-row'},h('button',{type:'button','data-match-reset':'',onclick:()=>{save(matcher.defaults());wife='';render();}},'기본 설정으로 초기화'),
        h('button',{type:'button','data-match-export':'',onclick:async()=>{try{await api.saveFile('imagestudio-image-matching.json',JSON.stringify(config,null,2),'application/json');status='매칭 설정을 내보냈습니다.';}catch(error){status='내보내기 실패: '+error.message;}statusNode();}},'설정 내보내기'),
        h('button',{type:'button','data-match-import':'',onclick:()=>importInput.click()},'설정 불러오기')),importInput,h('p',{'data-match-status':'',role:'status'},settingsError||status));
  }
  function statusNode(){const node=body?.querySelector('[data-match-status]');if(node)node.textContent=settingsError||status;}
  function move(delta){const next=structuredClone(config),i=next.order.indexOf(tab);[next.order[i],next.order[i+delta]]=[next.order[i+delta],next.order[i]];save(next);render();}
  function open(){windowHandle=api.ui.window({id:'image-matching',title:'이미지 매칭·추첨 설정',width:1000,height:820,render(root){body=root;render();},onClose(){body=null;windowHandle=null;}});return windowHandle;}
  const style=h('style',{});style.textContent='.wwis-matching{overflow-wrap:anywhere}.wwis-match-tabs,.wwis-match-row{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:10px 0}.wwis-match-tabs button[aria-selected=true]{border:1px solid #d97706!important;background:#78350f!important;color:#fde68a!important;font-weight:bold!important}.wwis-matching input[type=number]{width:120px}.wwis-matching textarea{display:block;width:100%;box-sizing:border-box;min-height:120px}.wwis-matching input,.wwis-matching select,.wwis-matching textarea{max-width:100%;min-width:0;background:#292524;color:#e7e5e4;border:1px solid #78716c;padding:6px;font:inherit}.wwis-match-options{font-size:12px}.wwis-matching button{cursor:pointer;padding:7px}.wwis-matching section>div:first-child{margin-top:12px}@media(max-width:600px){.wwis-match-tabs button{flex:1 1 44%}.wwis-match-row select{width:100%}}';document.head.append(style);
  style.textContent+='.wwis-exposure-points{display:grid;grid-template-columns:minmax(100px,1fr) minmax(55px,90px) minmax(55px,90px);gap:8px;align-items:center;max-width:100%;margin:12px 0}.wwis-matching .wwis-exposure-points input{width:100%;box-sizing:border-box;min-width:0}';
  document.getElementById('wwis-overlay')?.addEventListener('click',event=>{if(event.target.closest('#wwis-image-matching'))open();});
  api.onBack?.(()=>{if(!windowHandle)return false;windowHandle.close();return true;});
  globalThis.WW_ImageStudioMatching={open,get:()=>structuredClone(config),set:save,defaults:matcher.defaults,resolve,refresh:ImageStudio_매칭목록새로읽기,matcher,capture,metadata:key=>metadata.get(key),last:null};
  // 화면 배치와 저장 설정을 연결합니다. 저장 실패 시 기존 체크 상태와 설정을 유지합니다.
  const enabledCheck=document.getElementById('wwis-image-matching-enabled');
  if(enabledCheck)enabledCheck.onchange=()=>{
    try{save({...config,enabled:enabledCheck.checked});}
    catch(error){ImageStudio_탐색체계표시맞추기();settingsError='이미지 탐색 체계 설정 저장 실패: '+error.message;const note=document.getElementById('wwis-image-matching-status');if(note)note.textContent=settingsError;}
  };
  ImageStudio_탐색체계표시맞추기();
}
