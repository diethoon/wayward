// 실행: node wml/mods/imagestudio/source/build-h-status-prompts.mjs
// 기존 사용자 프롬프트를 복사·정규화합니다. 새 상황 문구를 작성하지 않습니다.
import fs from 'node:fs';
import vm from 'node:vm';
import crypto from 'node:crypto';
const modDir = new URL('../', import.meta.url);
const sourceDir = new URL('../../h-status/', import.meta.url);
const characters = ['elena', 'mara', 'pippa'];
const settingsSource = fs.readFileSync(new URL('backend/wayward-imagegen/src/routes/generationSettings.ts', modDir), 'utf8');
const originals = vm.runInNewContext('(' + settingsSource.match(/const ORIGINAL_CHARACTERS: CharacterPrompt\[\] = (\[[\s\S]*?\n\])/)[1] + ')');
const normalize = tag => tag.trim().toLowerCase().replace(/\s+/g, ' ');
const output = { format: 1, characterPlaceholder: '{{character_prompt}}', characterIdPlaceholder: '{{character_id}}',
  source: 'H_Status 1.6.5 / Situation Full 1.6.2.bug1014a1', defaultSource: 'elena',
  sources: [{ id: 'elena', name: '엘레나 기준' }, { id: 'mara', name: '마라 기준' }, { id: 'pippa', name: '피파 기준' }],
  branches: [], sourceFiles: [] };
for (const [id, label, expected, weight] of [
  ['status', '상태 오버레이', 10, 1000], ['info', '비밀 탭 상세', 53, 900],
  ['observation', '관찰 장면', 5400, 500], ['event', '이벤트 장면', 5400, 400],
]) {
  const branch = { id, label, count: expected, weight, entries: {}, overrides: {} };
  for (const character of characters) {
    const file = `prompts-situation-${character}-${id}.js`;
    const source = fs.readFileSync(new URL(file, sourceDir), 'utf8'), window = {};
    vm.runInNewContext(source, { window });
    const pack = window.__WAYWARD_SITUATION_PROMPT_PACKS__?.[0];
    if (!pack?.identityDetached || Object.keys(pack.entries).length !== expected) throw Error('Unexpected source pack: ' + file);
    const profile = originals.find(item => item.id === character);
    const identityTags = new Set(profile.prompt.split(',').map(normalize));
    const identityNegativeTags = new Set(profile.negativePrompt.split(',').map(normalize).filter(tag => !['child', 'loli'].includes(tag)));
    if (identityNegativeTags.has('makeup heavy')) identityNegativeTags.add('heavy makeup');
    let removed = 0, removedNegative = 0;
    const overrides = {};
    for (const [key, original] of Object.entries(pack.entries)) {
      if (!key.includes(`__${character}__`)) throw Error('Unexpected image key: ' + key);
      const genericKey = key.replace(`__${character}__`, '__{{character_id}}__');
      // Identity-detached packs normally need no removal. Match complete tags
      // only, preserving scene, clothing, pose, anatomy and negative safeguards.
      const prompt = original.prompt.split(',').filter(tag => {
        if (!identityTags.has(normalize(tag))) return true;
        removed++; return false;
      }).join(',');
      const negativePrompt = original.negativePrompt.split(',').filter(tag => {
        if (!identityNegativeTags.has(normalize(tag))) return true;
        removedNegative++; return false;
      }).join(',');
      const entry = { ...original, prompt, negativePrompt };
      if (character === 'elena') branch.entries[genericKey] = entry;
      else if (JSON.stringify(branch.entries[genericKey]) !== JSON.stringify(entry)) overrides[genericKey] = entry;
    }
    if (character !== 'elena') branch.overrides[character] = overrides;
    output.sourceFiles.push({ file, sha256: crypto.createHash('sha256').update(source).digest('hex'), count: expected, removedIdentityTags: removed, removedIdentityNegativeTags: removedNegative });
  }
  output.branches.push(branch);
}
const text = '// 생성 파일. 기존 H_Status 프롬프트의 외형·이미지 키 분리본. source/build-h-status-prompts.mjs로 재생성합니다.\n'
  + 'globalThis.__WW_IMAGESTUDIO_H_STATUS_TEMPLATES__ = ' + JSON.stringify(output, null, 2) + ';\n';
fs.writeFileSync(new URL('h-status-situation-prompts.js', modDir), text);
console.log(JSON.stringify({ file: 'h-status-situation-prompts.js', bytes: Buffer.byteLength(text), branches: output.branches.map(({ id, count, overrides }) => ({ id, count, overrides: Object.fromEntries(Object.entries(overrides).map(([id, value]) => [id, Object.keys(value).length])) })) }));
