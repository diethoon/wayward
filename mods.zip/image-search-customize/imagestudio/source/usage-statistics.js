// 플레이 중 이미지 요구와 최종 게임 프롬프트를 새 게임별로 기록합니다.
function ImageStudio_사용통계연결하기(api) {
  const databaseName = 'wml.mod.imagestudio.usage';
  const sessions = new Map(), dirtySessions = new Set(), pending = [], startup = [], memoryEvents = [];
  let database = null, initialized = false, activeId = '', rendering = 0, timer = null, saving = Promise.resolve();
  let storageError = '', panel = null, body = null, selectedId = '', category = 'image', characterFilter = '', search = '', viewEpoch = 0;
  const h = api.ui.h;
  // 기존 사용자는 수집을 계속합니다. 끄더라도 이미 저장한 게임별 기록은 보존합니다.
  let usageEnabled = api.settings.get({ usageStatisticsEnabled: true }).usageStatisticsEnabled !== false;

  function ImageStudio_통계사용체크박스만들기() {
    return h('label', { class: 'wwis-usage-toggle' }, h('input', {
      type: 'checkbox', checked: usageEnabled, 'data-wwis-usage-enabled': '',
      onchange: event => {
        api.settings.set({ usageStatisticsEnabled: event.target.checked });
        usageEnabled = event.target.checked;
        ImageStudio_현재게임연결하기();
        // 재개 후 첫 요구는 중지 직전과 같은 이미지여도 새로운 요구로 집계합니다.
        const session = sessions.get(activeId);
        if (usageEnabled && session) {
          session.lastByCharacter = {}; dirtySessions.add(activeId);
        }
        void ImageStudio_사용기록저장하기().catch(() => {});
        void ImageStudio_통계화면그리기();
      },
    }), '이미지 사용 통계 사용');
  }

  function ImageStudio_기록식별자만들기() {
    return globalThis.crypto?.randomUUID?.() || Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
  }
  function ImageStudio_기록표식읽기(state) { return state?.mods?.imagestudio?.usageSession; }
  function ImageStudio_기록표식넣기(state, origin) {
    const marker = { id: ImageStudio_기록식별자만들기(), startedAt: new Date().toISOString(), origin };
    return { ...state, mods: { ...state.mods, imagestudio: { ...state.mods?.imagestudio, usageSession: marker } } };
  }
  function ImageStudio_저장오류알리기(error) {
    storageError = '브라우저 기록 저장 실패: ' + String(error?.message || error) + '. 미저장 기록은 이 창을 닫기 전에 JSON으로 저장하세요.';
    console.warn('[imagestudio] ' + storageError);
    body?.querySelector('[data-wwis-usage-status]')?.replaceChildren(storageError);
  }
  function ImageStudio_요청결과기다리기(request) {
    return new Promise((resolve, reject) => { request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error); });
  }
  function ImageStudio_트랜잭션기다리기(transaction) {
    return new Promise((resolve, reject) => { transaction.oncomplete = resolve; transaction.onabort = () => reject(transaction.error || Error('기록 트랜잭션 중단')); transaction.onerror = () => {}; });
  }
  async function ImageStudio_기록저장소열기() {
    try {
      const request = indexedDB.open(databaseName, 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        db.createObjectStore('sessions', { keyPath: 'id' });
        const events = db.createObjectStore('events', { keyPath: 'id' });
        events.createIndex('sessionId', 'sessionId');
      };
      request.onblocked = () => ImageStudio_저장오류알리기(Error('다른 게임 창이 기록 저장소를 사용 중입니다'));
      database = await ImageStudio_요청결과기다리기(request);
      database.onversionchange = () => { database.close(); ImageStudio_저장오류알리기(Error('기록 저장소가 변경되었습니다. 게임을 새로고침하세요')); };
      const transaction = database.transaction('sessions', 'readonly');
      for (const session of await ImageStudio_요청결과기다리기(transaction.objectStore('sessions').getAll())) sessions.set(session.id, session);
    } catch (error) { database = null; ImageStudio_저장오류알리기(error); }
    initialized = true;
    ImageStudio_현재게임연결하기();
    for (const entry of startup.splice(0)) ImageStudio_사용요청기록하기(entry);
  }
  function ImageStudio_세션확보하기(marker, state) {
    let session = sessions.get(marker.id);
    if (!session) {
      const wife = state?.characters?.[state.primaryCharacterId];
      session = { ...marker, characterName: wife?.name || wife?.shortname || '', firstDay: state?.day ?? null,
        lastDay: state?.day ?? null, count: 0, lastByCharacter: {}, updatedAt: marker.startedAt };
      sessions.set(marker.id, session); dirtySessions.add(marker.id); ImageStudio_저장예약하기();
    }
    return session;
  }
  function ImageStudio_현재게임연결하기() {
    const outer = api.store.get(), state = outer?.state;
    if (!outer?.started || !state) { activeId = ''; return; }
    if (!usageEnabled) { activeId = ImageStudio_기록표식읽기(state)?.id || ''; return; }
    let marker = ImageStudio_기록표식읽기(state);
    if (!marker?.id) {
      api.store.update(current => ImageStudio_기록표식읽기(current)?.id ? current : ImageStudio_기록표식넣기(current, 'attached'));
      marker = ImageStudio_기록표식읽기(api.store.game());
    }
    activeId = marker.id;
    if (initialized) ImageStudio_세션확보하기(marker, api.store.game());
  }
  function ImageStudio_저장예약하기() {
    if (timer !== null) return;
    timer = setTimeout(() => { timer = null; void ImageStudio_사용기록저장하기().catch(() => {}); }, 150);
  }
  function ImageStudio_사용기록저장하기() {
    if (timer !== null) { clearTimeout(timer); timer = null; }
    saving = saving.catch(() => {}).then(async () => {
      await ready;
      while (pending.length || dirtySessions.size) {
        const events = pending.splice(0), ids = [...dirtySessions]; dirtySessions.clear();
        if (!database) { memoryEvents.push(...events); break; }
        try {
          const transaction = database.transaction(['sessions', 'events'], 'readwrite');
          const done = ImageStudio_트랜잭션기다리기(transaction);
          for (const id of ids) transaction.objectStore('sessions').put(sessions.get(id));
          for (const event of events) transaction.objectStore('events').put(event);
          await done;
          storageError = '';
        } catch (error) {
          pending.unshift(...events); ids.forEach(id => dirtySessions.add(id)); ImageStudio_저장오류알리기(error); throw error;
        }
      }
    });
    return saving;
  }
  function ImageStudio_사용요청기록하기(entry) {
    if (!initialized) { startup.push(entry); return; }
    const session = ImageStudio_세션확보하기(entry.marker, entry.state);
    const characterId = entry.characterId || entry.axes.character || 'unknown';
    // 같은 구성의 연속 렌더는 한 번. A→B→A로 돌아오면 새 요구로 집계합니다.
    if (session.lastByCharacter[characterId] === entry.key) return;
    session.lastByCharacter[characterId] = entry.key;
    session.count++; session.lastDay = entry.day; session.updatedAt = entry.recordedAt;
    const { marker, state, ...event } = entry;
    pending.push({ ...event, id: ImageStudio_기록식별자만들기(), sessionId: marker.id, sequence: session.count });
    dirtySessions.add(marker.id); ImageStudio_저장예약하기();
  }
  function ImageStudio_게임프롬프트기록하기(result, args) {
    if (!usageEnabled || !rendering || !result?.key || !api.store.get()?.started) return;
    const state = api.store.game(), marker = ImageStudio_기록표식읽기(state), character = args[0];
    if (!marker?.id) return;
    const parsed = api.fn('imageKeyParse')(result.key) || {};
    const axes = { character: parsed.character || character?.archetypeId || 'unknown',
      outfit: parsed.outfit || character?.outfit || 'unknown',
      situation: parsed.scene || parsed.task || (parsed.lookFocus ? 'look:' + parsed.lookFocus + ':' + (parsed.lookReaction || '') : character?.sceneOverride || character?.currentTask || 'unknown'),
      room: parsed.room || args[1] || 'unknown', exposure: parsed.exposure || 'none', variant: parsed.variant ?? 0,
      mood: parsed.mood || 'default', aftermath: parsed.aftermath || 'none',
      groupBoys: parsed.groupBoys ?? null, groupSlots: parsed.groupSlots || '', abed: !!parsed.abed, finishOutfit: parsed.finishOutfit || '' };
    ImageStudio_사용요청기록하기({ marker, state, key: String(result.key), axes, characterId: character?.id || parsed.characterId || '',
      characterName: character?.name || character?.shortname || axes.character, day: state.day ?? null, slot: state.slot ?? null,
      phase: state.phase || '', recordedAt: new Date().toISOString(), prompt: result.prompt || '', negativePrompt: result.negativePrompt || '',
      genParams: result.genParams ? JSON.parse(JSON.stringify(result.genParams)) : null, checkpoint: result.checkpoint || '' });
  }
  async function ImageStudio_사용통계읽기(id = activeId) {
    await ready;
    await ImageStudio_사용기록저장하기().catch(() => {});
    let events = memoryEvents.filter(event => event.sessionId === id);
    if (database) {
      events = await ImageStudio_요청결과기다리기(database.transaction('events', 'readonly').objectStore('events').index('sessionId').getAll(id));
    }
    const combined = new Map([...events, ...pending.filter(event => event.sessionId === id)].map(event => [event.id, event]));
    return { schemaVersion: 1, modVersion: '1.11.0', exportedAt: new Date().toISOString(),
      metric: '게임 이미지 구성의 연속 중복을 제외한 요구 횟수. 생성 성공·실제 파일 표시·노출 시간과는 별도입니다.',
      storageError, session: sessions.has(id) ? { ...sessions.get(id), lastByCharacter: undefined } : null,
      events: [...combined.values()].sort((a, b) => a.sequence - b.sequence) };
  }
  function ImageStudio_통계행만들기(events, mode) {
    const groups = new Map();
    for (const event of events) {
      const value = mode === 'image' ? event.key : event.axes[mode] || 'unknown';
      let row = groups.get(value);
      if (!row) { row = { value, count: 0, firstDay: event.day, lastDay: event.day, sample: event }; groups.set(value, row); }
      row.count++; row.lastDay = event.day; row.sample = event;
    }
    return [...groups.values()].sort((a, b) => b.count - a.count || a.value.localeCompare(b.value)).map(row => ({ ...row, share: events.length ? row.count * 100 / events.length : 0 }));
  }
  function ImageStudio_통계Csv만들기(rows) {
    const cell = value => '"' + String(value ?? '').replace(/^[=+@\-\t\r]/, match => "'" + match).replaceAll('"', '""') + '"';
    return '\uFEFF' + rows.map(row => row.map(cell).join(',')).join('\r\n') + '\r\n';
  }
  function ImageStudio_항목이름읽기(axis, value) {
    if (axis === 'character') return value;
    return globalThis.WW_ImageStudioHelp?.label?.(axis, value) || value;
  }
  function ImageStudio_필터적용하기(events) {
    const query = search.trim().toLocaleLowerCase();
    return events.filter(event => (!characterFilter || event.axes.character === characterFilter) && (!query ||
      [event.key, event.characterName, ...Object.entries(event.axes).map(([axis, value]) => ImageStudio_항목이름읽기(axis, String(value)))].join(' ').toLocaleLowerCase().includes(query)));
  }
  async function ImageStudio_통계파일저장하기(format) {
    try {
      const data = await ImageStudio_사용통계읽기(selectedId), events = ImageStudio_필터적용하기(data.events);
      const name = 'imagestudio-usage-' + selectedId + '-' + new Date().toISOString().replace(/[:.]/g, '-');
      let file, type;
      if (format === 'json') {
        data.statistics = Object.fromEntries(['image','outfit','situation','room'].map(mode => [mode, ImageStudio_통계행만들기(data.events, mode).map(({ sample, ...row }) => row)]));
        file = JSON.stringify(data, null, 2); type = 'application/json';
      } else if (format === 'log') {
        file = ImageStudio_통계Csv만들기([['게임 ID','순번','기록 시각','게임 일차','게임 시각','인물','인물 ID','이미지 키','의상','상황','장소','Positive','Negative'],
          ...events.map(event => [event.sessionId,event.sequence,event.recordedAt,event.day,event.slot,event.characterName,event.characterId,event.key,event.axes.outfit,event.axes.situation,event.axes.room,event.prompt,event.negativePrompt])]); type = 'text/csv;charset=utf-8';
      } else {
        file = ImageStudio_통계Csv만들기([['게임 ID','집계 기준','항목 키','표시 이름','요구 횟수','비율(%)','첫 일차','마지막 일차'],
          ...ImageStudio_통계행만들기(events, category).map(row => [selectedId,category,row.value,ImageStudio_항목이름읽기(category === 'image' ? 'key' : category,row.value),row.count,row.share.toFixed(2),row.firstDay,row.lastDay])]); type = 'text/csv;charset=utf-8';
      }
      await api.saveFile(name + (format === 'json' ? '.json' : format === 'log' ? '-log.csv' : '-' + category + '.csv'), file, type);
      body?.querySelector('[data-wwis-usage-status]')?.replaceChildren(storageError || '파일 저장 요청을 전달했습니다.');
    } catch (error) { body?.querySelector('[data-wwis-usage-status]')?.replaceChildren('파일 저장 실패: ' + String(error?.message || error)); }
  }
  async function ImageStudio_통계화면그리기() {
    const epoch = ++viewEpoch;
    try {
      await ready;
      if (!body) return;
      if (!sessions.has(selectedId)) selectedId = sessions.has(activeId) ? activeId : [...sessions.keys()].at(-1) || '';
      const data = await ImageStudio_사용통계읽기(selectedId);
      if (!body || epoch !== viewEpoch) return;
      const allEvents = data.events, events = ImageStudio_필터적용하기(allEvents), rows = ImageStudio_통계행만들기(events, category);
      const select = h('select', { 'data-wwis-usage-session': '', 'aria-label': '게임 기록', onchange: event => { selectedId = event.target.value; characterFilter = ''; void ImageStudio_통계화면그리기(); } });
      for (const session of [...sessions.values()].sort((a, b) => b.startedAt.localeCompare(a.startedAt))) {
        select.append(h('option', { value: session.id }, `${session.id === activeId ? '현재 · ' : ''}${new Date(session.startedAt).toLocaleString('ko-KR')} · ${session.characterName} · ${session.origin === 'new-game' ? '새 게임' : '설치/불러오기 이후'} · ${session.count}회 · ${session.id.slice(0,8)}`));
      }
      select.value = selectedId;
      const grouping = h('select', { 'data-wwis-usage-category': '', 'aria-label': '집계 기준', onchange: event => { category = event.target.value; void ImageStudio_통계화면그리기(); } },
        ...[['image','이미지별'],['outfit','복장별'],['situation','상황별'],['room','장소별']].map(([value, label]) => h('option', { value }, label)));
      grouping.value = category;
      const characters = h('select', { 'data-wwis-usage-character': '', 'aria-label': '인물 필터', onchange: event => { characterFilter = event.target.value; void ImageStudio_통계화면그리기(); } }, h('option', { value: '' }, '모든 인물'));
      for (const value of [...new Set(allEvents.map(event => event.axes.character))].sort()) characters.append(h('option', { value }, allEvents.find(event => event.axes.character === value).characterName + ' · ' + value));
      characters.value = characterFilter;
      const input = h('input', { type: 'search', value: search, placeholder: '이미지 키·복장·상황 검색', 'aria-label': '기록 검색', 'data-wwis-usage-search': '' });
      const submit = () => { search = input.value; void ImageStudio_통계화면그리기(); };
      input.onkeydown = event => { if (event.key === 'Enter') submit(); };
      const tableBody = h('tbody');
      for (const row of rows.slice(0, 200)) {
        const sample = row.sample, label = category === 'image' ? `${sample.characterName} · ${ImageStudio_항목이름읽기('outfit', sample.axes.outfit)} · ${ImageStudio_항목이름읽기('situation', sample.axes.situation)} · ${ImageStudio_항목이름읽기('room', sample.axes.room)}` : ImageStudio_항목이름읽기(category, row.value);
        tableBody.append(h('tr', {}, h('td', {}, label, h('code', {}, row.value)), h('td', {}, row.count.toLocaleString()), h('td', {}, row.share.toFixed(1) + '%'), h('td', {}, `${row.firstDay ?? '?'} → ${row.lastDay ?? '?'}`)));
      }
      const logs = h('details', { 'data-wwis-usage-log': '' }, h('summary', {}, `프롬프트 기록 로그 · 최근 ${Math.min(events.length, 100)}회`));
      for (const event of events.slice(-100).reverse()) logs.append(h('details', {}, h('summary', {}, `#${event.sequence} · ${event.day ?? '?'}일 / ${event.slot ?? '?'}분 · ${event.characterName} · ${ImageStudio_항목이름읽기('situation', event.axes.situation)} · ${ImageStudio_항목이름읽기('outfit', event.axes.outfit)}`),
        h('code', {}, event.key), h('p', {}, '요구 시각: ' + new Date(event.recordedAt).toLocaleString('ko-KR')), h('strong', {}, 'Positive'), h('pre', {}, event.prompt), h('strong', {}, 'Negative'), h('pre', {}, event.negativePrompt)));
      const exportButton = (label, format) => h('button', { type: 'button', class: 'wayward-native-button', disabled: !data.session, 'data-wwis-usage-export': format, onclick: () => { void ImageStudio_통계파일저장하기(format); } }, label);
      body.classList.add('wwis-usage');
      body.replaceChildren(ImageStudio_통계사용체크박스만들기(),
        h('p', { class: 'wml-muted' }, usageEnabled
          ? '켜짐: 플레이 중 이미지 요구를 새 게임별로 기록합니다. 같은 이미지의 연속 요구는 한 번만 집계합니다.'
          : '꺼짐: 새 이미지 사용 기록을 수집하지 않습니다. 기존 기록은 조회·내보내기할 수 있습니다.'),
        h('div', { class: 'wwis-usage-controls' }, select, api.ui.button('현재 게임', () => { selectedId = activeId; characterFilter = ''; search = ''; void ImageStudio_통계화면그리기(); }), api.ui.button('새로고침', () => { void ImageStudio_통계화면그리기(); })),
        h('p', {}, data.session ? `${data.session.origin === 'attached' ? '설치/불러오기 이후 수집 · ' : ''}총 요구 ${data.session.count.toLocaleString()}회 · 고유 이미지 ${new Set(allEvents.map(event => event.key)).size.toLocaleString()}개 · 필터 적용 ${events.length.toLocaleString()}회` : '새 게임을 시작하면 이미지 요구 기록이 쌓입니다.'),
        h('div', { class: 'wwis-usage-controls' }, grouping, characters, input, api.ui.button('검색', submit)),
        h('div', { class: 'wwis-usage-controls' }, exportButton('전체 통계·로그 JSON 저장', 'json'), exportButton('현재 통계 CSV 저장', 'csv'), exportButton('현재 로그 CSV 저장', 'log')),
        h('p', { role: 'status', 'data-wwis-usage-status': '' }, storageError || '브라우저에 자동 저장합니다. 이미지 서버가 없어도 사용할 수 있습니다.'),
        h('div', { class: 'wwis-usage-table' }, h('table', {}, h('thead', {}, h('tr', {}, ...['항목','요구 횟수','비율','첫→마지막 일차'].map(label => h('th', {}, label)))), tableBody)),
        events.length ? logs : h('p', {}, '이 조건에 해당하는 이미지 요구 기록이 없습니다.'),
        h('details', { class: 'wml-muted' }, h('summary', {}, '집계·저장 기준'),
          h('p', {}, '이미지 구성 A→B→A는 3회, 같은 구성의 연속 렌더는 1회입니다. 캐시/오프라인에서도 기록하며 계획·검수창의 계산은 제외합니다. 생성 성공·실제 파일 표시·노출 시간을 측정하는 통계는 아닙니다.'),
          h('p', {}, 'JSON은 선택한 게임의 전체 통계와 로그, CSV는 현재 인물·검색 필터를 적용합니다. 표는 상위 200개, 화면 로그는 최근 100회이며 파일에는 전체를 담습니다. 세이브 불러오기/되돌리기는 같은 게임의 누적 기록을 되감지 않습니다. 기록은 이 브라우저에 보관됩니다. 다른 PC에는 JSON 또는 WML 백업으로 보관하세요.'),
          data.session ? h('code', {}, '게임 기록 ID: ' + data.session.id) : ''));
    } catch (error) { if (body && epoch === viewEpoch) body.replaceChildren(ImageStudio_통계사용체크박스만들기(), h('p', { role: 'status' }, '통계 읽기 실패: ' + String(error?.message || error)), api.ui.button('다시 읽기', () => { void ImageStudio_통계화면그리기(); })); }
  }
  function ImageStudio_통계창열기() {
    selectedId = activeId; search = ''; characterFilter = '';
    panel = api.ui.window({ id: 'usage-statistics', title: '이미지별 사용 통계 · ImageStudio', width: 1150, height: 800,
      render(root) { body = root; root.replaceChildren(h('p', {}, '기록을 읽는 중입니다…')); void ImageStudio_통계화면그리기(); },
      onClose() { body = null; panel = null; viewEpoch++; } });
    return panel;
  }
  const style = h('style', { 'data-wwis-usage-style': '' });
  style.textContent = '.wwis-usage{overflow-wrap:anywhere}.wwis-usage-toggle{display:flex;align-items:center;gap:8px;margin:0 0 12px;padding:10px;border:1px solid #57534e;border-radius:7px;cursor:pointer}.wwis-usage-controls{display:flex;flex-wrap:wrap;gap:8px;margin:12px 0}.wwis-usage select,.wwis-usage input{min-width:0;max-width:100%;background:#292524;color:#e7e5e4;border:1px solid #57534e;border-radius:5px;padding:7px;font:inherit}.wwis-usage-table{max-width:100%;overflow:auto}.wwis-usage table{width:100%;border-collapse:collapse;font-size:13px}.wwis-usage th,.wwis-usage td{padding:9px;text-align:left;vertical-align:top;border-bottom:1px solid #44403c}.wwis-usage td:not(:first-child){white-space:nowrap}.wwis-usage td:first-child{min-width:160px}.wwis-usage code{display:block;font-size:11px;color:#a8a29e;overflow-wrap:anywhere;word-break:break-all}.wwis-usage pre{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.5 sans-serif;background:#0c0a09;padding:8px;border-radius:5px}.wwis-usage details{margin:10px 0}.wwis-usage summary{cursor:pointer;color:#fbbf24}@media(max-width:640px){.wwis-usage-controls>select,.wwis-usage-controls>input{flex:1 1 100%}.wwis-usage table{font-size:12px}.wwis-usage th,.wwis-usage td{padding:6px}}';
  document.head.append(style);
  // 새 게임 상태를 만드는 함수에 표식을 붙입니다. 기존 세이브는 연결 시점부터 기록합니다.
  api.hook('imageUsageInitialState', { priority: -1000000, after: state => usageEnabled ? ImageStudio_기록표식넣기(state, 'new-game') : state });
  ImageStudio_현재게임연결하기();
  const stop = api.store.subscribe(ImageStudio_현재게임연결하기);
  api.hook('imageUsagePortraitPanel', { around(next, ...args) { rendering++; try { return next(...args); } finally { rendering--; } } });
  api.hook('imagePrompt', { priority: -1000000, after: ImageStudio_게임프롬프트기록하기 });
  const ready = ImageStudio_기록저장소열기();
  api.backup?.beforeExport?.(async () => { await ImageStudio_사용기록저장하기(); if (storageError) throw Error(storageError); });
  document.getElementById('wwis-overlay')?.addEventListener('click', event => { if (event.target.closest('#wwis-usage-statistics')) ImageStudio_통계창열기(); });
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') void ImageStudio_사용기록저장하기().catch(() => {}); });
  window.addEventListener('pagehide', () => { stop(); void ImageStudio_사용기록저장하기().catch(() => {}); }, { once: true });
  globalThis.WW_ImageStudioUsage = { open: ImageStudio_통계창열기, snapshot: ImageStudio_사용통계읽기, flush: ImageStudio_사용기록저장하기,
    sessions: async () => { await ready; return [...sessions.values()].map(({ lastByCharacter, ...session }) => ({ ...session })); },
    summarize: ImageStudio_통계행만들기, csv: ImageStudio_통계Csv만들기, ready, databaseName };
}
