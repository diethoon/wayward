# 미리보기: powershell -NoProfile -File wml/mods/imagestudio/source/game-root-sync.ps1
# 적용: 같은 명령에 -Apply. 정식판 공식 서버/설정/키/캐시는 보존합니다.
param([switch]$Apply)
$ErrorActionPreference = 'Stop'
$studioModRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$studioGameRoot = (Resolve-Path -LiteralPath (Join-Path $studioModRoot '..\..\..')).Path
$studioSource = Join-Path $studioModRoot 'Start_ImageStudio.cmd'
$studioTargets = @((Join-Path $studioGameRoot 'Start_ImageStudio.cmd'), (Join-Path $studioModRoot 'game-root\Start_ImageStudio.cmd'))
foreach ($studioTarget in $studioTargets) {
    $studioChanged = !(Test-Path -LiteralPath $studioTarget) -or (Get-FileHash -LiteralPath $studioSource).Hash -ne (Get-FileHash -LiteralPath $studioTarget).Hash
    if ($Apply -and $studioChanged) { Copy-Item -LiteralPath $studioSource -Destination $studioTarget }
    [PSCustomObject]@{Target=$studioTarget; Changed=$studioChanged; Applied=[bool]($Apply -and $studioChanged)}
}
