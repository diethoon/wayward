// 공통 자세·장면 적합성. 편집기를 꺼도 같은 기준으로 이미지를 비교합니다.
const ImageStudio_자세상황목록 = (() => {
  const 목록 = value => new Set(value.trim().split(/\s+/));
  const 일반성관계 = 목록('sex sex_rough patron_sex patron_sex_climax patron_sex_finish patron_sex_finish_pullout');
  const 항문성교 = 목록('anal patron_anal patron_anal_climax patron_anal_finish patron_anal_finish_pullout');
  const 구강성교 = 목록('blowjob deepthroat clean_with_mouth cum_in_mouth patron_blowjob patron_deepthroat patron_blowjob_climax patron_blowjob_swallow');
  const 손자극 = 목록('bath_attendant_handjob handjob patron_handjob patron_handjob_finish patron_handjob_climax');
  const 가슴자극 = 목록('titfuck patron_titfuck');
  const 여성기구강 = 목록('cunnilingus patron_cunnilingus');
  const 마주밀착 = 목록('patron_chatting patron_flirting kissing patron_touching patron_bold patron_intimate grinding mutual_touching patron_mutual_touching patron_moment_sit_on_lap');
  const 뒤밀착 = 목록('patron_flirting kissing groped_ass groped_tits patron_touching patron_bold patron_groping patron_intimate grinding lap_dance mutual_touching patron_grinding patron_lap_dance patron_mutual_touching patron_moment_pose_dance');
  const 무릎뒤밀착 = 목록('patron_groping_lap patron_intimate_lap patron_moment_sit_on_lap patron_lap_dance lap_dance');
  const 합치기 = (...sets) => new Set(sets.flatMap(set => [...set]));
  return new Map([
    ['standing', 목록('idle greeting taking_order serving cleaning cooking bathing at_market away bath_attendant patron_flirting kissing groped_ass groped_tits bath_attendant_wash_chest bath_attendant_wash_body bath_with_patron patron_touching patron_bold patron_groping patron_intimate grinding lap_dance mutual_touching breast_worship patron_grinding patron_lap_dance patron_mutual_touching patron_breast_worship patron_moment_cleavage patron_moment_flash_tits patron_moment_lift_skirt patron_moment_show_tongue patron_moment_twirl patron_moment_pose_dance patron_rubbing patron_rubbing_finish patron_rubbing_climax thigh_job patron_thigh_job standing_sex patron_standing_sex')],
    ['sitting', 목록('patron_chatting patron_flirting kissing groped_ass groped_tits bath_attendant bath_attendant_wash_chest bath_attendant_wash_body bath_with_patron patron_touching patron_bold patron_groping patron_groping_lap patron_intimate patron_intimate_lap fingered grinding lap_dance mutual_touching breast_worship anal_fingering patron_grinding patron_lap_dance patron_mutual_touching patron_breast_worship patron_moment_cleavage patron_moment_flash_tits patron_moment_lift_skirt patron_moment_sit_on_lap patron_moment_show_tongue patron_rubbing patron_rubbing_finish patron_rubbing_climax thigh_job patron_thigh_job patron_self_stroke')],
    ['kneeling', 합치기(구강성교, 손자극, 가슴자극, 목록('facial patron_facial breast_worship patron_breast_worship'))],
    ['lying-back', 합치기(일반성관계, 항문성교, 여성기구강, 목록('passed_out resting sleeping self_pleasure fingered anal_fingering patron_intimate patron_intimate_lap finish_on_stomach finish_on_chest'))],
    ['all-fours', 합치기(일반성관계, 항문성교, 목록('fingered anal_fingering finish_on_back'))],
    ['close-embrace', 마주밀착],
    ['back-hug', 뒤밀착],
    ['lap-back-hug', 무릎뒤밀착],
    ['missionary', 합치기(일반성관계, 항문성교)],
    ['cowgirl', 합치기(일반성관계, 목록('riding patron_riding'))],
    ['reverse-cowgirl', 합치기(일반성관계, 목록('riding patron_riding'))],
    ['doggystyle', 합치기(일반성관계, 항문성교)],
    ['spooning', 합치기(일반성관계, 항문성교)],
    ['standing-sex', 합치기(일반성관계, 항문성교, 목록('standing_sex patron_standing_sex'))],
    ['mating-press', 합치기(일반성관계, 항문성교)],
    ['prone-bone', 합치기(일반성관계, 항문성교)],
    ['ekiben', 합치기(일반성관계, 항문성교)],
    ['daisuki-hold', 합치기(일반성관계, 항문성교)],
    ['full-nelson', 합치기(일반성관계, 항문성교)],
    ['double-penetration', 합치기(일반성관계, 항문성교)],
    ['kneeling-fellatio', 구강성교],
    ['deep-throat', 구강성교],
    ['irrumatio-front', 구강성교],
    ['upside-down-facefuck', 구강성교],
    ['cunnilingus', 여성기구강],
    ['sixty-nine', 목록('sixty_nine')],
    ['seated-handjob', 손자극],
    ['paizuri', 가슴자극],
  ]);
})();

function ImageStudio_자세상황에맞는가(presetId, imageKey) {
  if (!presetId || presetId === 'auto') return true;
  const part = String(imageKey || '').split('__').find(value => /^(?:scene|task)-/.test(value));
  const situation = part?.replace(/^(?:scene|task)-/, '') || '';
  if (!situation || !ImageStudio_자세상황목록.get(presetId)?.has(situation)) return false;
  if (presetId === 'double-penetration') {
    const count = Math.max(0, Math.min(5, Number(String(imageKey).match(/(?:^|__|\|)grp-(\d+)/)?.[1]) || 0));
    const rawSlots = String(imageKey).match(/(?:^|__|\|)gslot-([mhbxriaw]+)/)?.[1] || '';
    const slots = count && rawSlots.length === count ? rawSlots : '';
    if (!slots) return false;
    return /^(?:patron_)?anal(?:_|$)/.test(situation) ? slots.includes('i') : slots.includes('a');
  }
  return true;
}
