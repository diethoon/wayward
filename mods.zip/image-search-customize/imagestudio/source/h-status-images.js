// H_Status 기존 데이터와 ImageStudio의 캐릭터 설정을 연결합니다.
function ImageStudio_HStatus연결만들기(api, bridge) {
  let loading = null;
  async function ImageStudio_HStatus목록읽기() {
    if (!globalThis.__WW_IMAGESTUDIO_H_STATUS_TEMPLATES__) {
      if (!loading) loading = api.loadScript('h-status-situation-prompts.js').finally(() => { loading = null; });
      await loading;
    }
    const data = globalThis.__WW_IMAGESTUDIO_H_STATUS_TEMPLATES__;
    if (data?.format !== 1 || !Array.isArray(data.branches)) throw Error('H_Status 공통 프롬프트 파일을 불러오지 못했습니다. 모드 ZIP을 다시 설치하세요.');
    return data;
  }
  async function ImageStudio_HStatus계획만들기(characterId, branchIds, options = {}, progress = () => {}) {
    if (!/^[a-z0-9][a-z0-9_-]{0,99}$/.test(characterId) || characterId === 'patron') throw Error('올바른 캐릭터를 선택하세요.');
    const data = await ImageStudio_HStatus목록읽기();
    const requested = new Set(Array.isArray(branchIds) ? branchIds : []);
    const branches = data.branches.filter(branch => requested.has(branch.id));
    if (!branches.length || branches.length !== requested.size) throw Error('생성할 H_Status 이미지 묶음을 하나 이상 선택하세요.');
    const source = options.source || (data.sources.some(item => item.id === characterId) ? characterId : data.defaultSource);
    if (!data.sources.some(item => item.id === source)) throw Error('상황 프롬프트 기준을 확인하세요.');
    let profile = options.profile;
    if (!profile) {
      const baseUrl = bridge.connection()?.baseUrl;
      if (!baseUrl) throw Error('이미지 서버에 연결하세요.');
      const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 8000);
      try {
        const response = await fetch(baseUrl + '/api/generation/settings', { credentials: 'omit', signal: controller.signal });
        const body = await response.json();
        if (!response.ok) throw Error(body.error || `외형 설정 읽기 실패 (HTTP ${response.status})`);
        profile = body.characters?.find(item => item.id === characterId);
      } finally { clearTimeout(timer); }
      if (!profile) profile = bridge.characters()?.characters?.find(item => item.id === characterId);
    }
    if (!profile?.prompt?.trim()) throw Error('선택한 캐릭터의 외형 프롬프트가 없습니다. 새로운 캐릭터 찾기 또는 이미지 생성 방식 지정에서 등록하세요.');
    const items = [], counts = {}, total = branches.reduce((sum, branch) => sum + branch.count, 0);
    progress({ current: 0, total, stage: 'h-status-plan', label: 'H_Status 프롬프트 준비', unit: '장' });
    for (const branch of branches) {
      const entries = Object.entries(branch.entries), override = branch.overrides[source] || {};
      if (entries.length !== branch.count) throw Error(`${branch.label} 프롬프트 수가 다릅니다.`);
      counts[branch.id] = entries.length;
      for (const [key, base] of entries) {
        const entry = override[key] || base;
        const prompt = entry.prompt.includes(data.characterPlaceholder)
          ? entry.prompt.replaceAll(data.characterPlaceholder, profile.prompt.trim())
          : [entry.prompt, profile.prompt.trim()].filter(Boolean).join(', ');
        const talentId = key.replaceAll(data.characterIdPlaceholder, characterId);
        if (prompt.includes('{{') || talentId.includes('{{')) throw Error('캐릭터 프롬프트 자리표시자가 남아 있습니다.');
        let item = { talentId, prompt,
          negativePrompt: [entry.negativePrompt, profile.negativePrompt?.trim()].filter(Boolean).join(', '),
          workflow: entry.workflow || 'illustrious', imageType: 'portrait',
          width: Number(entry.width) || 1152, height: Number(entry.height) || 896,
          steps: Number(entry.steps) || undefined, cfg: Number(entry.cfg) || undefined, weight: branch.weight };
        // 부위별 설정은 개별 검수와 일괄 생성에 같은 참조 선택 규칙을 적용합니다.
        const upgrade=bridge.extensions?.editor?.upgrades;
        if(upgrade?.prepare) item=await upgrade.prepare({...item,imageKey:talentId,referenceSource:source});
        items.push(item);
        if (items.length % 100 === 0) {
          progress({ current: items.length, total, stage: 'h-status-plan', label: 'H_Status 프롬프트 준비', unit: '장' });
          await new Promise(resolve => setTimeout(resolve, 0));
        }
      }
    }
    progress({ current: items.length, total, stage: 'h-status-plan', label: 'H_Status 프롬프트 준비', unit: '장' });
    return { character: { id: characterId, name: profile.name || characterId }, source, counts, total: items.length, items };
  }
  return { hStatusCatalogue: ImageStudio_HStatus목록읽기, hStatusPlan: ImageStudio_HStatus계획만들기 };
}

async function ImageStudio_HStatus설정그리기({ box, bridge, characterId, name, selection, isCurrent, isBusy, setBusy, taskProgress, setMessage, buildPack }) {
  box.textContent = 'H_Status 공통 프롬프트 목록을 읽는 중…';
  let data;
  try { data = await bridge.hStatusCatalogue(); }
  catch (error) { if (isCurrent()) box.textContent = String(error?.message || error); return; }
  if (!isCurrent()) return;
  const h = (tag, text, props = {}) => Object.assign(document.createElement(tag), props, text == null ? {} : { textContent: text });
  const title = h('h3', `${name} · H_Status용 이미지 생성`);
  const note = h('p', '상황·의상·구도는 원본 H_Status 팩을 사용하고, 외형과 네거티브는 ImageStudio의 캐릭터 설정을 사용합니다. 생성 시 H_Status 모드를 켤 필요는 없습니다.', { className: 'wwis-dim' });
  const source = h('select', null, { id: 'wwis-h-status-source' });
  for (const item of data.sources) source.append(h('option', item.name, { value: item.id }));
  source.value = selection.source || (data.sources.some(item => item.id === characterId) ? characterId : data.defaultSource);
  source.onchange = () => { selection.source = source.value; };
  const sourceRow = h('label', '상황 프롬프트 기준 ');
  sourceRow.append(source);
  const help = h('p', '기준 캐릭터의 외형은 사용하지 않습니다. 원본 팩 사이에 남아 있는 구도·배경 차이만 선택합니다.', { className: 'wwis-dim' });
  const choices = h('div'), estimate = h('p', null, { id: 'wwis-h-status-estimate' });
  for (const branch of data.branches) {
    const row = h('label', null, { className: 'wwis-row' });
    const input = h('input', null, { type: 'checkbox', checked: (selection.branches || ['status', 'info']).includes(branch.id) });
    input.dataset.wwisHStatusBranch = branch.id;
    row.append(input, document.createTextNode(`${branch.label} · ${branch.count.toLocaleString()}장`)); choices.append(row);
  }
  const selected = () => [...choices.querySelectorAll('input:checked')].map(input => input.dataset.wwisHStatusBranch);
  const total = () => data.branches.reduce((sum, branch) => sum + (selected().includes(branch.id) ? branch.count : 0), 0);
  const enqueue = h('button', '선택 묶음 대기열 추가', { id: 'wwis-h-status-enqueue', disabled: isBusy() });
  const pack = h('button', 'H_Status용 이미지팩 만들기', { id: 'wwis-h-status-pack', disabled: isBusy() });
  const buttons = h('div', null, { className: 'wwis-row' }); buttons.append(enqueue, pack);
  const message = h('p', '기본 선택은 상태 10장 + 비밀 탭 상세 53장입니다. 기존 캐시와 대기 중인 같은 이미지는 서버에서 제외합니다.', { id: 'wwis-h-status-message', className: 'wwis-dim' });
  const update = () => { selection.branches = selected(); estimate.textContent = `${name} · 선택 ${total().toLocaleString()}장`; enqueue.disabled = isBusy() || !total(); pack.disabled = isBusy(); };
  choices.addEventListener('change', update);
  box.replaceChildren(title, note, sourceRow, help, choices, estimate, buttons, message);
  update();
  taskProgress.paint('generation');
  pack.onclick = async () => {
    if (isBusy() || typeof buildPack !== 'function') return;
    pack.disabled = true;
    try { message.textContent = await buildPack(characterId); }
    catch (error) { message.textContent = `팩 생성 실패: ${String(error?.message || error)}`; }
    finally { update(); }
  };
  enqueue.onclick = async () => {
    if (isBusy()) return;
    const branchIds = selected(), templateSource = source.value;
    if (!branchIds.length) { message.textContent = '생성할 묶음을 선택하세요.'; return; }
    setBusy(true); enqueue.disabled = true;
    source.disabled = true; choices.querySelectorAll('input').forEach(input => { input.disabled = true; });
    let failed = false, resultText = '';
    try {
      taskProgress.update('generation', { restart: true, stage: 'h-status-connection', label: 'H_Status 생성 준비', current: 0, total: null });
      await bridge.ready?.();
      const connection = bridge.connection?.();
      if (!connection?.baseUrl || connection.comfyui !== true) throw Error('이미지 서버와 선택한 생성 방식의 연결을 확인하세요.');
      const healthResponse = await fetch(connection.baseUrl + '/api/image/health', { credentials: 'omit', signal: AbortSignal.timeout(8000) });
      const health = await healthResponse.json();
      if (!healthResponse.ok || !health.capabilities?.includes('h-status-character-keys')) throw Error('H_Status 캐릭터별 LoRA를 지원하는 서버가 필요합니다. 생성 중인 작업이 끝나면 이 모드 폴더의 Start_ImageStudio.cmd로 서버를 다시 실행하세요.');
      const plan = await bridge.hStatusPlan(characterId, branchIds, { source: templateSource }, value => taskProgress.update('generation', value));
      const report = value => {
        const detail = `서버 접수 ${(value.accepted || 0).toLocaleString()}장 · 캐시 보유 ${(value.alreadyCached || 0).toLocaleString()}장 · 이미 대기 중 ${(value.alreadyQueued || 0).toLocaleString()}장`;
        taskProgress.update('generation', { stage: 'h-status-queue', label: 'H_Status 대기열 전송', current: value.sent, total: plan.total, unit: '장', detail });
        message.textContent = detail;
      };
      report({ sent: 0 });
      const result = await bridge.enqueue(plan.items, report);
      report({ sent: plan.total, ...result });
      resultText = `${name}: 새로 추가 ${(result.accepted || 0).toLocaleString()}장 · 캐시 보유 ${(result.alreadyCached || 0).toLocaleString()}장 · 이미 대기 중 ${(result.alreadyQueued || 0).toLocaleString()}장`;
    } catch (error) { failed = true; resultText = `추가 실패: ${String(error?.message || error)}`; }
    finally {
      setBusy(false); source.disabled = false;
      choices.querySelectorAll('input').forEach(input => { input.disabled = false; }); update();
      message.textContent = resultText; setMessage(resultText);
      taskProgress.finish('generation', resultText, failed);
    }
  };
}
