# 실행: powershell -NoProfile -ExecutionPolicy Bypass -File wml/mods/imagestudio/source/package.ps1
# Version is numeric; game target is 2026-11-01; ZIP contains the stable mod ID folder.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$releaseRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$releaseSource = Get-Content -LiteralPath (Join-Path $releaseRoot 'mod.js') -Raw -Encoding UTF8
$releaseDefinition = $releaseSource.Substring($releaseSource.IndexOf('WML.define'))
$releaseId = [regex]::Match($releaseDefinition, 'id\s*:\s*[\x27\x22]([^\x27\x22]+)').Groups[1].Value
$releaseVersion = [regex]::Match($releaseDefinition, 'version\s*:\s*[\x27\x22]([^\x27\x22]+)').Groups[1].Value
if ($releaseId -ne (Split-Path $releaseRoot -Leaf) -or $releaseVersion -notmatch '^\d+\.\d+\.\d+$') { throw 'ID/folder or numeric version mismatch' }
$releaseZip = Join-Path $releaseRoot ($releaseId + '-' + $releaseVersion + '-20261101.zip')
$releaseFiles = @('CONDITIONAL_ID_AUDIT.md', 'H_STATUS_PROMPTS.md', 'Install_ComfyUI_PromptBatch.cmd', 'README.md', 'Repair_WebP_Cache.cmd', 'Split_Image_Cache.cmd', 'Start_ImageStudio.cmd', 'backend/wayward-imagegen/LICENSE', 'backend/wayward-imagegen/README.md', 'backend/wayward-imagegen/package.json', 'backend/wayward-imagegen/src/batch/queue.ts', 'backend/wayward-imagegen/src/batch/routes.ts', 'backend/wayward-imagegen/src/cache/cacheStore.ts', 'backend/wayward-imagegen/src/cache/characterCacheIndex.ts', 'backend/wayward-imagegen/src/cache/hitStore.ts', 'backend/wayward-imagegen/src/cache/packProjection.ts', 'backend/wayward-imagegen/src/cache/paths.ts', 'backend/wayward-imagegen/src/cache/webpRelink.ts', 'backend/wayward-imagegen/src/characterLoras.ts', 'backend/wayward-imagegen/src/checkWebp.ts', 'backend/wayward-imagegen/src/cli.ts', 'backend/wayward-imagegen/src/comfy/client.ts', 'backend/wayward-imagegen/src/comfy/jobRunner.ts', 'backend/wayward-imagegen/src/comfy/media.ts', 'backend/wayward-imagegen/src/comfy/reference.ts', 'backend/wayward-imagegen/src/comfy/workflows/index.ts', 'backend/wayward-imagegen/src/config.ts', 'backend/wayward-imagegen/src/doctor.ts', 'backend/wayward-imagegen/src/http/body.ts', 'backend/wayward-imagegen/src/http/cors.ts', 'backend/wayward-imagegen/src/http/router.ts', 'backend/wayward-imagegen/src/http/static.ts', 'backend/wayward-imagegen/src/nai/client.ts', 'backend/wayward-imagegen/src/naming.ts', 'backend/wayward-imagegen/src/prompts/character.ts', 'backend/wayward-imagegen/src/repairWebpCache.ts', 'backend/wayward-imagegen/src/routes/catalogue.ts', 'backend/wayward-imagegen/src/routes/customPack.ts', 'backend/wayward-imagegen/src/routes/export.ts', 'backend/wayward-imagegen/src/routes/generationSettings.ts', 'backend/wayward-imagegen/src/routes/image.ts', 'backend/wayward-imagegen/src/routes/review.ts', 'backend/wayward-imagegen/src/routes/studioDrafts.ts', 'backend/wayward-imagegen/src/routes/video.ts', 'backend/wayward-imagegen/src/server.ts', 'backend/wayward-imagegen/src/sharp.d.ts', 'backend/wayward-imagegen/src/splitImageCache.ts', 'backend/wayward-imagegen/ui/index.html', 'backend/wayward-imagegen/wayward-imagegen.config.json', 'comfyui/install.ps1', 'comfyui/wayward_imagestudio_batch/__init__.py', 'game-root/Start_ImageStudio.cmd', 'h-status-situation-prompts.js', 'mod.js', 'reports/easygen-comparison-20261022.md', 'reports/lookup-1.31.10-20261026.json', 'reports/prompt-open-20261030.json', 'reports/prompt-open-responsive-20261030-mobile.json', 'reports/prompt-open-responsive-20261030.json', 'source/EXTENSIONS.md', 'source/build-h-status-prompts.mjs', 'source/build.mjs', 'source/collect-vanilla-ids.mjs', 'source/extensions.js', 'source/game-root-sync.ps1', 'source/h-status-images.js', 'source/image-key-normalization.js', 'source/install-split.ps1', 'source/matching-positions.js', 'source/mod.wml.js', 'source/native-ui.js', 'source/package.ps1', 'source/prompt-review.js', 'source/repair-character-cache.ts', 'source/task-progress.js', 'source/usage-statistics.js', 'source/vanilla-ids.json', 'tests/attention-upgrades.mjs', 'tests/extension-valid.mjs', 'tests/img2img.ts', 'tests/novelai.ts', 'tests/prompt-open-profile.mjs', 'tests/prompt-open-responsive.mjs', 'tests/prompt-split.mjs', 'tests/random-queue.mjs', 'tests/server-extension-discovery.test.ts', 'tests/h-status-storage.test.ts', 'tests/settings-unsaved.ts', 'tests/voluntary-outfit-lock.mjs')
if (Test-Path -LiteralPath $releaseZip) { throw 'Existing release is preserved. Bump mod version before packaging.' }
$releaseArchive = [IO.Compression.ZipFile]::Open($releaseZip, [IO.Compression.ZipArchiveMode]::Create, [Text.Encoding]::UTF8)
try { foreach ($releaseName in $releaseFiles) {
  $releasePath = [IO.Path]::GetFullPath((Join-Path $releaseRoot $releaseName))
  if (!$releasePath.StartsWith($releaseRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Path outside mod folder' }
  [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($releaseArchive, $releasePath, ($releaseId + '/' + $releaseName), [IO.Compression.CompressionLevel]::Optimal) | Out-Null
}} finally { $releaseArchive.Dispose() }
$releaseArchive = [IO.Compression.ZipFile]::OpenRead($releaseZip)
try {
 if ($releaseArchive.Entries.Count -ne $releaseFiles.Count) { throw 'ZIP count mismatch' }
 foreach ($releaseName in $releaseFiles) {
  $releaseEntry = $releaseArchive.GetEntry($releaseId + '/' + $releaseName)
  if (!$releaseEntry) { throw ('ZIP missing: ' + $releaseName) }
  $releaseInput = $releaseEntry.Open(); $releaseHash = [Security.Cryptography.SHA256]::Create()
  try { $releaseActual = ([BitConverter]::ToString($releaseHash.ComputeHash($releaseInput))).Replace('-', '') } finally { $releaseInput.Dispose(); $releaseHash.Dispose() }
  if ($releaseActual -ne (Get-FileHash -LiteralPath (Join-Path $releaseRoot $releaseName) -Algorithm SHA256).Hash) { throw ('ZIP differs: ' + $releaseName) }
 }
} finally { $releaseArchive.Dispose() }
Write-Output ('VERIFIED ' + $releaseZip)
