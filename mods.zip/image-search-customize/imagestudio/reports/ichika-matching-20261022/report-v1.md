# 이치카 이미지팩 매칭 점수 30건

계산일: 2026-10-22 · seed 1138 · 각 상황별 6건 · 실제 팩 전체에서 최상위 이미지 선택

- 기본 점수·필수 조건 사용. 사용자의 브라우저 저장 설정은 읽지 않음.
- 캐릭터 이치카, 요청 장소 홀(taproom), 행동 5종 × 6건.
- 의상은 각 행동의 홀 이미지가 실제 팩에 존재하며 현재 편집기에 있는 일반 의상에서 추첨. 목욕복·잠옷 제외.
- 노출·표정·흔적·편집기 추가 상태를 seed 1138로 추첨. 자세는 장면에 맞는 선택지만 허용.
- 출산 사건과 별도 보여주기 행동은 고정해 홀의 요청 행동을 유지. 편집기에서 선택지가 자동뿐인 축은 자동 유지.
- 입력 선택과 실제 매칭 메타데이터를 구분. 프롬프트 상태가 조건·설정에 따라 적용되지 않을 수 있음.
- 메뉴 질문은 `taking_order`(주문 받기), 대화는 `patron_chatting`, 가벼운 접촉은 `patron_touching`으로 해석했습니다.
- 이치카 JS 팩만 비교합니다. 이미지 서버의 별도 캐시와 H_Status 전용 팩은 포함하지 않았습니다.
- 변형 선택은 별도의 seed 1138 난수열을 사용했습니다. 게임 실행 중의 실제 난수 결과와는 달라질 수 있습니다.
- 동일 요청 재사용 시간(30초)은 이번 독립 점수 실험에 적용하지 않았습니다.

팩 항목 28,010개 → 실제 파일이 있는 중복 제거 후보 28,010개. 파일 누락 0개, 기타 제외 0개.
추가 상태 메타데이터가 있는 후보: 13,813개.

## 30개 점수

| 상황 | 1 | 2 | 3 | 4 | 5 | 6 | 평균 |
|---|---:|---:|---:|---:|---:|---:|---:|
| 대기 | 30,500 | 29,500 | 29,000 | 32,000 | 29,000 | 32,500 | 30,416.67 |
| 서빙 | 32,000 | 26,000 | 28,000 | 31,000 | 31,000 | 29,500 | 29,583.33 |
| 메뉴 질문(주문 받기) | 27,000 | 32,000 | 30,000 | 32,000 | 28,000 | 29,000 | 29,666.67 |
| 대화하기 | 31,000 | 31,000 | 28,000 | 30,000 | 31,000 | 30,000 | 30,166.67 |
| 가벼운 접촉 | 32,000 | 31,000 | 31,000 | 26,500 | 30,000 | 30,000 | 30,083.33 |

## 무작위 요청과 실제 선택 이미지

| 번호 | 상황 | 요청 의상 → 선택 의상 | 요청 표정 → 선택 표정 | 요청 노출 → 선택 노출 | 선택 장소 | 총점 |
|---:|---|---|---|---|---|---:|
| 1 | 대기 1 | 적갈색 베이비돌 → 적갈색 베이비돌 | 미소 → 미소 | 0000000 → 0000000 | 홀 | 30,500 |
| 2 | 대기 2 | 비치는 잠옷 → 비치는 잠옷 | 미소 → 기본 표정 | 0100000 → 0100000 | 홀 | 29,500 |
| 3 | 대기 3 | 앞섶을 끈으로 여미는 드레스 → 앞섶을 끈으로 여미는 드레스 | 걱정 → 기본 표정 | 0111100 → 0111100 | 홀 | 29,000 |
| 4 | 대기 4 | 농부의 작업복 → 농부의 작업복 | 안도함 → 수줍음 | 0101010 → 0101010 | 홀 | 32,000 |
| 5 | 대기 5 | 기워 입은 여름 원피스 → 기워 입은 여름 원피스 | 기본 표정 → 걱정 | 0111101 → 0111101 | 홀 | 29,000 |
| 6 | 대기 6 | 목줄과 쇠사슬 → 목줄과 쇠사슬 | 흥분함 → 기본 표정 | 0101100 → 0101100 | 홀 | 32,500 |
| 7 | 서빙 1 | 주점 종업원의 코르셋 → 주점 종업원의 코르셋 | 걱정 → 기본 표정 | 0001101 → 0001101 | 홀 | 32,000 |
| 8 | 서빙 2 | 나체 → 나체 | 수줍음 → 수줍음 | 0111000 → 0000000 | 홀 | 26,000 |
| 9 | 서빙 3 | 수수한 작업복 → 수수한 작업복 | 긴장함 → 기본 표정 | 0001100 → 0001100 | 홀 | 28,000 |
| 10 | 서빙 4 | 짧은 블라우스와 미니스커트 → 짧은 블라우스와 미니스커트 | 흥분함 → 기본 표정 | 0111101 → 0111101 | 홀 | 31,000 |
| 11 | 서빙 5 | 레이스 란제리 → 레이스 란제리 | 즐기는 중 → 기본 표정 | 0111100 → 0111100 | 홀 | 31,000 |
| 12 | 서빙 6 | 당신의 셔츠 → 당신의 셔츠 | 수줍음 → 수줍음 | 1000000 → 0000000 | 홀 | 29,500 |
| 13 | 메뉴 질문(주문 받기) 1 | 나체 → 나체 | 흥분함 → 수줍음 | 1000000 → 0000000 | 홀 | 27,000 |
| 14 | 메뉴 질문(주문 받기) 2 | 끈 없는 미니 원피스와 허벅지 부츠 → 끈 없는 미니 원피스와 허벅지 부츠 | 긴장함 → 기본 표정 | 0101010 → 0101010 | 홀 | 32,000 |
| 15 | 메뉴 질문(주문 받기) 3 | 수수한 작업복 → 수수한 작업복 | 긴장함 → 걱정 | 0000000 → 0000000 | 홀 | 30,000 |
| 16 | 메뉴 질문(주문 받기) 4 | 짧은 블라우스와 미니스커트 → 짧은 블라우스와 미니스커트 | 긴장함 → 기본 표정 | 0001010 → 0001010 | 홀 | 32,000 |
| 17 | 메뉴 질문(주문 받기) 5 | 짧은 블라우스와 미니스커트 → 짧은 블라우스와 미니스커트 | 수줍음 → 기본 표정 | 0101010 → 0101010 | 홀 | 28,000 |
| 18 | 메뉴 질문(주문 받기) 6 | 몸을 감싸는 상의와 골반에 걸치는 치마 → 몸을 감싸는 상의와 골반에 걸치는 치마 | 미소 → 기본 표정 | 0111100 → 0111100 | 홀 | 29,000 |
| 19 | 대화하기 1 | 비단 가운 → 비단 가운 | 미소 → 기본 표정 | 0100000 → 0000000 | 홀 | 31,000 |
| 20 | 대화하기 2 | 새틴 베이비돌 → 새틴 베이비돌 | 즐기는 중 → 기본 표정 | 1000000 → 0000000 | 홀 | 31,000 |
| 21 | 대화하기 3 | 비단 가운 → 비단 가운 | 긴장함 → 수줍음 | 0111101 → 0000000 | 홀 | 28,000 |
| 22 | 대화하기 4 | 비단 가운 → 비단 가운 | 겁먹음 → 기본 표정 | 0001010 → 0000000 | 홀 | 30,000 |
| 23 | 대화하기 5 | 몸을 감싸는 상의와 골반에 걸치는 치마 → 몸을 감싸는 상의와 골반에 걸치는 치마 | 즐기는 중 → 기본 표정 | 0100000 → 0000000 | 뒷방 | 31,000 |
| 24 | 대화하기 6 | 레이스 란제리 → 레이스 란제리 | 안도함 → 기본 표정 | 0110000 → 0000000 | 뒷방 | 30,000 |
| 25 | 가벼운 접촉 1 | 기워 입은 여름 원피스 → 기워 입은 여름 원피스 | 안도함 → 걱정 | 0100000 → 0100000 | 홀 | 32,000 |
| 26 | 가벼운 접촉 2 | 비단 가운 → 비단 가운 | 안도함 → 기본 표정 | 0100000 → 0000000 | 홀 | 31,000 |
| 27 | 가벼운 접촉 3 | 새틴 베이비돌 → 새틴 베이비돌 | 흥분함 → 미소 | 0001010 → 0101010 | 뒷방 | 31,000 |
| 28 | 가벼운 접촉 4 | 나체 → 나체 | 걱정 → 기본 표정 | 0101100 → 0000000 | 홀 | 26,500 |
| 29 | 가벼운 접촉 5 | 레이스 란제리 → 레이스 란제리 | 흥분함 → 수줍음 | 0001101 → 0000001 | 뒷방 | 30,000 |
| 30 | 가벼운 접촉 6 | 몸을 감싸는 상의와 골반에 걸치는 치마 → 몸을 감싸는 상의와 골반에 걸치는 치마 | 안도함 → 기본 표정 | 0101010 → 0100000 | 홀 | 30,000 |

## 항목별 점수와 추가 상태

노출 숫자는 상의 끈 풀림·상의 내려감·상의 벗음·치마 올라감·치마 벗음·속옷 옆으로·속옷 벗음의 7개 비트입니다.
0점은 동일 상태라고 확인됐다는 뜻이 아닙니다. 이미지에 정보가 없거나 상태가 다르면 해당 규칙에 따라 0점일 수 있습니다.

### 01. 대기 1 — 30,500점

통과 후보 50개. 총점 동점 1개 → 항목 우선순위까지 동점 1개 → 1개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | idle | idle |
| 복장 | 6,000 | exact | auburn_babydoll | auburn_babydoll |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0000000 | 0000000 |
| 흔적 | 1,000 | exact | facial | facial |
| 세부 자세(모드) | 0 | different |  | standing |
| 기분 | 1,000 | exact | smile; 감정 없음 | smile; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | drugged, handcuffed | 없음 |
| 임신 상태(임신모드) | 500 | exact | none | none |
| 세부 상황(모드) | 0 | different | context.consent.forced_join, context.residue.hands, dialogue-dialogue-muzxq0xh-2, mouth-2 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 기본 프리셋 (default)
- 자세 / 체위 · 장면별 적용: 적용 안함 · 자세 추가 없음 (auto)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 자동 · 추가 지정 없음 (auto)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 미약 복용 (badguest.drugged)
- 환각 상태: 자동 · 추가 지정 없음 (auto)
- 기력: 자동 · 추가 지정 없음 (auto)
- 기분: 기분 0–19 (status.mood.0)
- 흥분도: 자동 · 추가 지정 없음 (auto)
- 심신 상태: 심신 상태 80–100 (status.wellbeing.4)
- 주목도: 주목도 60 이상 (status.allure.high)
- 신뢰: 신뢰 30 미만 (status.trust.low)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 자동 · 추가 지정 없음 (auto)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 허용 인식 0 미만 (status.latitude.negative)
- 취기: 자동 · 추가 지정 없음 (auto)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 묻어 있음 (fluid.mouth.2)
- 가슴: 자동 · 추가 지정 없음 (auto)
- 자궁: 자동 · 추가 지정 없음 (auto)
- 보지: 보지 · 애액이 맺힘 (fluid.vulva.2)
- 허벅지: 자동 · 추가 지정 없음 (auto)
- 가슴: 가슴 · 양쪽 유두 피어싱 (jewelry.breasts.2)
- 보지: 자동 · 추가 지정 없음 (auto)
- 대화 감지 규칙: 끝내 압박을 떨쳐내지 못하고 마십니다 (dialogue-muzxq0xh-2)
- 동의·강요 상태: 강제 합류 (forced_join)
- 사정 후 체액 흔적: 손의 흔적 (hands)
- 임신·산후 상태: 임신 상태 없음 (none)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-idle__outfit-auburn_babydoll__room-taproom__mood-smile__aft-facial__dialogue-wv1w4w__v-0`

**선택 이미지 키**

`ichika__task-idle__outfit-auburn_babydoll__room-taproom__mood-smile__aft-facial__state-16vfnir__character-reuse-yo0w6i__studio-o2pxi__position-standing-125hyxm__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-idle_outfit-auburn_babydoll_room-taproom_mood-smile_aft-facial_state-16vfnir_character-reuse-yo_portrait_1792401282726.webp`

### 02. 대기 2 — 29,500점

통과 후보 124개. 총점 동점 5개 → 항목 우선순위까지 동점 1개 → 1개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | idle | idle |
| 복장 | 6,000 | exact | sheer_nightgown | sheer_nightgown |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0100000 | 0100000 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 0 | different |  | standing |
| 기분 | 0 | different | smile; 감정 없음 | default; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | blindfolded, hallucinated, handcuffed | 없음 |
| 임신 상태(임신모드) | 500 | exact | none | none |
| 세부 상황(모드) | 0 | different | breasts-1, context.consent.voluntary, context.residue.hands, jewelry-breasts-1, mouth-4 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 적용 안함 · 자세 추가 없음 (auto)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 안대 착용 (badguest.blindfolded)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 40–59 (status.energy.2)
- 기분: 기분 0–19 (status.mood.0)
- 흥분도: 흥분도 80–100 (status.arousal.4)
- 심신 상태: 심신 상태 0–19 (status.wellbeing.0)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 신뢰 30 미만 (status.trust.low)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 원망도 60 이상 (status.resentment.high)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 취기 · 만취 (status.intoxication.wasted)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 넘쳐남 (fluid.mouth.4)
- 가슴: 가슴 · 흔적이 남음 (fluid.breasts.1)
- 자궁: 자궁 · 없음 (fluid.uterus.0)
- 보지: 보지 · 허벅지 안쪽까지 흐름 (fluid.vulva.3)
- 허벅지: 허벅지 · 없음 (fluid.thighs.0)
- 가슴: 가슴 · 좌측 유두 피어싱 (jewelry.breasts.1)
- 보지: 보지 · 장신구 없음 (jewelry.vulva.0)
- 대화 감지 규칙: 자동 · 추가 지정 없음 (auto)
- 동의·강요 상태: 자발적 참여 (voluntary)
- 사정 후 체액 흔적: 손의 흔적 (hands)
- 임신·산후 상태: 임신 상태 없음 (none)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-idle__outfit-sheer_nightgown__room-taproom__mood-smile__exp-0100000__state-bdia33__v-0`

**선택 이미지 키**

`ichika__task-idle__outfit-sheer_nightgown__room-taproom__exp-0100000__state-16vfnir__character-reuse-yo0w6i__studio-o2pxi__position-standing-125hyxm__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-idle_outfit-sheer_nightgown_room-taproom_exp-0100000_state-16vfnir_character-reuse-yo0w6i_studi_portrait_1792407881542.webp`

### 03. 대기 3 — 29,000점

통과 후보 167개. 총점 동점 6개 → 항목 우선순위까지 동점 5개 → 2개 구성 묶음 중 선택 묶음의 변형 4개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | idle | idle |
| 복장 | 6,000 | exact | serving_dress | serving_dress |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0111100 | 0111100 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 0 | different |  | standing |
| 기분 | 0 | different | worried; 감정 없음 | default; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | blindfolded, drugged, gagged, handcuffed | 없음 |
| 임신 상태(임신모드) | 0 | different | early | none |
| 세부 상황(모드) | 0 | different | breasts-4, context.consent.drugged, context.residue.body, dialogue-dialogue-muzyywtf-3, jewelry-breasts-2 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 기본 프리셋 (default)
- 자세 / 체위 · 장면별 적용: 적용 안함 · 자세 추가 없음 (auto)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 안대 착용 (badguest.blindfolded)
- 입마개 착용: 입마개 착용 (badguest.gagged)
- 미약 복용: 미약 복용 (badguest.drugged)
- 환각 상태: 자동 · 추가 지정 없음 (auto)
- 기력: 자동 · 추가 지정 없음 (auto)
- 기분: 기분 40–59 (status.mood.2)
- 흥분도: 흥분도 80–100 (status.arousal.4)
- 심신 상태: 심신 상태 40–59 (status.wellbeing.2)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 원망도 35–59 (status.resentment.medium)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 취기 · 취함 (status.intoxication.drunk)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 자동 · 추가 지정 없음 (auto)
- 가슴: 가슴 · 넘쳐남 (fluid.breasts.4)
- 자궁: 자궁 · 없음 (fluid.uterus.0)
- 보지: 보지 · 애액이 허벅지를 타고 흐름 (fluid.vulva.4)
- 허벅지: 자동 · 추가 지정 없음 (auto)
- 가슴: 가슴 · 양쪽 유두 피어싱 (jewelry.breasts.2)
- 보지: 보지 · 장신구 없음 (jewelry.vulva.0)
- 대화 감지 규칙: 저항을 눌러 버리고 (dialogue-muzyywtf-3)
- 동의·강요 상태: 미약 영향 (drugged)
- 사정 후 체액 흔적: 몸의 흔적 (body)
- 임신·산후 상태: 임신 초기 (early)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-idle__outfit-serving_dress__room-taproom__mood-worried__exp-0111100__dialogue-digb6__v-0`

**선택 이미지 키**

`ichika__task-idle__outfit-serving_dress__room-taproom__exp-0111100__state-16vfnir__character-reuse-yo0w6i__studio-o2pxi__position-standing-125hyxm__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-idle_outfit-serving_dress_room-taproom_exp-0111100_state-16vfnir_character-reuse-yo0w6i_studio-_portrait_1792405301477.webp`

### 04. 대기 4 — 32,000점

통과 후보 125개. 총점 동점 3개 → 항목 우선순위까지 동점 3개 → 3개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | idle | idle |
| 복장 | 6,000 | exact | peasant_smock | peasant_smock |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0101010 | 0101010 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact | standing | standing |
| 기분 | 0 | different | relieved; 감정 없음 | shy; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | handcuffed | 없음 |
| 임신 상태(임신모드) | 0 | different | early | none |
| 세부 상황(모드) | 0 | different | breasts-2, context.residue.body, jewelry-breasts-2, mouth-2, vulva-2 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 서 있기 (standing)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 자동 · 추가 지정 없음 (auto)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 자동 · 추가 지정 없음 (auto)
- 기력: 기력 0–19 (status.energy.0)
- 기분: 자동 · 추가 지정 없음 (auto)
- 흥분도: 흥분도 60–79 (status.arousal.3)
- 심신 상태: 심신 상태 20–39 (status.wellbeing.1)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 신뢰 30 미만 (status.trust.low)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 자동 · 추가 지정 없음 (auto)
- 심적 이탈: 자동 · 추가 지정 없음 (auto)
- 허용 인식: 허용 인식 0 미만 (status.latitude.negative)
- 취기: 취기 · 살짝 취함 (status.intoxication.tipsy)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 묻어 있음 (fluid.mouth.2)
- 가슴: 가슴 · 묻어 있음 (fluid.breasts.2)
- 자궁: 자동 · 추가 지정 없음 (auto)
- 보지: 보지 · 애액이 맺힘 (fluid.vulva.2)
- 허벅지: 허벅지 · 없음 (fluid.thighs.0)
- 가슴: 가슴 · 양쪽 유두 피어싱 (jewelry.breasts.2)
- 보지: 보지 · 장신구 없음 (jewelry.vulva.0)
- 대화 감지 규칙: 자동 · 추가 지정 없음 (auto)
- 동의·강요 상태: 적용 안 함 (not_applicable)
- 사정 후 체액 흔적: 몸의 흔적 (body)
- 임신·산후 상태: 임신 초기 (early)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-idle__outfit-peasant_smock__room-taproom__exp-0101010__state-swp6lp__position-standing-125hyxm__mood-relieved__studio-1br0gfa__v-0`

**선택 이미지 키**

`ichika__task-idle__outfit-peasant_smock__room-taproom__mood-shy__exp-0101010__state-16vfnir__character-reuse-yo0w6i__studio-o2pxi__position-standing-125hyxm__v-2`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-idle_outfit-peasant_smock_room-taproom_mood-shy_exp-0101010_state-16vfnir_character-reuse-yo0w6_portrait_1792437521911.webp`

### 05. 대기 5 — 29,000점

통과 후보 153개. 총점 동점 2개 → 항목 우선순위까지 동점 1개 → 1개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | idle | idle |
| 복장 | 6,000 | exact | patched_sundress | patched_sundress |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0111101 | 0111101 |
| 흔적 | 1,000 | exact | sweat | sweat |
| 세부 자세(모드) | 0 | different |  | standing |
| 기분 | 0 | different | default; 감정 없음 | worried; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | blindfolded, gagged, hallucinated, handcuffed | 없음 |
| 임신 상태(임신모드) | 0 | different | postpartum | none |
| 세부 상황(모드) | 0 | different | breasts-2, context.consent.voluntary, context.residue.hands, dialogue-dialogue-muzqz0av-1, jewelry-breasts-1, mouth-2, thighs-1, uterus-3 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 기본 프리셋 (default)
- 자세 / 체위 · 장면별 적용: 적용 안함 · 자세 추가 없음 (auto)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 안대 착용 (badguest.blindfolded)
- 입마개 착용: 입마개 착용 (badguest.gagged)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 40–59 (status.energy.2)
- 기분: 기분 20–39 (status.mood.1)
- 흥분도: 흥분도 20–39 (status.arousal.1)
- 심신 상태: 심신 상태 60–79 (status.wellbeing.3)
- 주목도: 주목도 60 이상 (status.allure.high)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 자동 · 추가 지정 없음 (auto)
- 심적 이탈: 자동 · 추가 지정 없음 (auto)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 취기 · 의식 없음 (status.intoxication.blacked_out)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 묻어 있음 (fluid.mouth.2)
- 가슴: 가슴 · 묻어 있음 (fluid.breasts.2)
- 자궁: 자궁 · 가득참 (fluid.uterus.3)
- 보지: 보지 · 건조함 (fluid.vulva.0)
- 허벅지: 허벅지 · 흔적이 남음 (fluid.thighs.1)
- 가슴: 가슴 · 좌측 유두 피어싱 (jewelry.breasts.1)
- 보지: 보지 · 장신구 없음 (jewelry.vulva.0)
- 대화 감지 규칙: 잠시 뒤 목덜미와 가슴 안쪽부터 설명하기 어려운 열기가 천천히 번지기 시작합니다 (dialogue-muzqz0av-1)
- 동의·강요 상태: 자발적 참여 (voluntary)
- 사정 후 체액 흔적: 손의 흔적 (hands)
- 임신·산후 상태: 출산 당일·산후 (postpartum)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-idle__outfit-patched_sundress__room-taproom__exp-0111101__aft-sweat__dialogue-1o8z8nq__v-0`

**선택 이미지 키**

`ichika__task-idle__outfit-patched_sundress__room-taproom__mood-worried__exp-0111101__aft-sweat__state-16vfnir__character-reuse-yo0w6i__studio-o2pxi__position-standing-125hyxm__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-idle_outfit-patched_sundress_room-taproom_mood-worried_exp-0111101_aft-sweat_state-16vfnir_char_portrait_1792395826935.webp`

### 06. 대기 6 — 32,500점

통과 후보 30개. 총점 동점 1개 → 항목 우선순위까지 동점 1개 → 1개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | idle | idle |
| 복장 | 6,000 | exact | slave_collar | slave_collar |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0101100 | 0101100 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact | standing | standing |
| 기분 | 0 | different | aroused; 감정 없음 | default; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | gagged | 없음 |
| 임신 상태(임신모드) | 500 | exact | none | none |
| 세부 상황(모드) | 0 | different | context.consent.drugged, context.residue.face, dialogue-dialogue-muzqz0av-1, jewelry-breasts-1, uterus-2, vulva-2 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 서 있기 (standing)
- 수갑 채움: 자동 · 추가 지정 없음 (auto)
- 안대 착용: 자동 · 추가 지정 없음 (auto)
- 입마개 착용: 입마개 착용 (badguest.gagged)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 자동 · 추가 지정 없음 (auto)
- 기력: 기력 60–79 (status.energy.3)
- 기분: 기분 40–59 (status.mood.2)
- 흥분도: 흥분도 40–59 (status.arousal.2)
- 심신 상태: 심신 상태 40–59 (status.wellbeing.2)
- 주목도: 주목도 60 이상 (status.allure.high)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 자동 · 추가 지정 없음 (auto)
- 원망도: 자동 · 추가 지정 없음 (auto)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 허용 인식 0 미만 (status.latitude.negative)
- 취기: 취기 · 만취 (status.intoxication.wasted)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 자동 · 추가 지정 없음 (auto)
- 가슴: 자동 · 추가 지정 없음 (auto)
- 자궁: 자궁 · 자궁 내 일부 (fluid.uterus.2)
- 보지: 보지 · 애액이 맺힘 (fluid.vulva.2)
- 허벅지: 허벅지 · 없음 (fluid.thighs.0)
- 가슴: 가슴 · 좌측 유두 피어싱 (jewelry.breasts.1)
- 보지: 보지 · 장신구 없음 (jewelry.vulva.0)
- 대화 감지 규칙: 잠시 뒤 목덜미와 가슴 안쪽부터 설명하기 어려운 열기가 천천히 번지기 시작합니다 (dialogue-muzqz0av-1)
- 동의·강요 상태: 미약 영향 (drugged)
- 사정 후 체액 흔적: 얼굴의 흔적 (face)
- 임신·산후 상태: 임신 상태 없음 (none)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-idle__outfit-slave_collar__room-taproom__exp-0101100__dialogue-125rb8e__position-standing-125hyxm__mood-aroused__studio-ihk16a__v-0`

**선택 이미지 키**

`ichika__task-idle__outfit-slave_collar__room-taproom__exp-0101100__state-16vfnir__character-reuse-yo0w6i__studio-o2pxi__position-standing-125hyxm__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-idle_outfit-slave_collar_room-taproom_exp-0101100_state-16vfnir_character-reuse-yo0w6i_studio-o_portrait_1792412620216.webp`

### 07. 서빙 1 — 32,000점

통과 후보 90개. 총점 동점 2개 → 항목 우선순위까지 동점 1개 → 1개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | serving | serving |
| 복장 | 6,000 | exact | barmaid_corset | barmaid_corset |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0001101 | 0001101 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact | standing | standing |
| 기분 | 0 | different | worried; 감정 없음 | default; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | drugged, hallucinated | 없음 |
| 임신 상태(임신모드) | 0 | different | middle | none |
| 세부 상황(모드) | 0 | different | context.consent.unconscious, context.residue.face, mouth-4, thighs-2, uterus-2, vulva-1 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 기본 프리셋 (default)
- 자세 / 체위 · 장면별 적용: 서 있기 (standing)
- 수갑 채움: 자동 · 추가 지정 없음 (auto)
- 안대 착용: 자동 · 추가 지정 없음 (auto)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 미약 복용 (badguest.drugged)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 80–100 (status.energy.4)
- 기분: 기분 20–39 (status.mood.1)
- 흥분도: 흥분도 0–19 (status.arousal.0)
- 심신 상태: 자동 · 추가 지정 없음 (auto)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 신뢰 30 미만 (status.trust.low)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 자동 · 추가 지정 없음 (auto)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 취기 · 의식 없음 (status.intoxication.blacked_out)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 넘쳐남 (fluid.mouth.4)
- 가슴: 가슴 · 묻어 있음 (fluid.breasts.2)
- 자궁: 자궁 · 자궁 내 일부 (fluid.uterus.2)
- 보지: 보지 · 은은하게 젖음 (fluid.vulva.1)
- 허벅지: 허벅지 · 묻어 있음 (fluid.thighs.2)
- 가슴: 가슴 · 양쪽 유두 피어싱 (jewelry.breasts.2)
- 보지: 보지 · 장신구 없음 (jewelry.vulva.0)
- 대화 감지 규칙: 자동 · 추가 지정 없음 (auto)
- 동의·강요 상태: 의식 없음 (unconscious)
- 사정 후 체액 흔적: 얼굴의 흔적 (face)
- 임신·산후 상태: 임신 중기 (middle)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-serving__outfit-barmaid_corset__room-taproom__mood-worried__exp-0001101__state-1iur2g6__position-standing-125hyxm__v-0`

**선택 이미지 키**

`ichika__task-serving__outfit-barmaid_corset__room-taproom__exp-0001101__state-16vfnir__character-reuse-yo0w6i__studio-1u4sod8__position-standing-125hyxm__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-serving_outfit-barmaid_corset_room-taproom_exp-0001101_state-16vfnir_character-reuse-yo0w6i_stu_portrait_1792414840923.webp`

### 08. 서빙 2 — 26,000점

통과 후보 8개. 총점 동점 2개 → 항목 우선순위까지 동점 2개 → 1개 구성 묶음 중 선택 묶음의 변형 2개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | serving | serving |
| 복장 | 6,000 | exact | nude | nude |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 0 | similar | 0111000 | 0000000 |
| 흔적 | 0 | different | messy |  |
| 세부 자세(모드) | 0 | different |  | standing |
| 기분 | 1,000 | exact | shy; 감정 없음 | shy; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | blindfolded, hallucinated | 없음 |
| 임신 상태(임신모드) | 0 | different | early | none |
| 세부 상황(모드) | 0 | different | breasts-3, context.consent.unconscious, context.residue.chest, dialogue-dialogue-muzqz0av-1, thighs-2, vulva-2 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 기본 프리셋 (default)
- 자세 / 체위 · 장면별 적용: 적용 안함 · 자세 추가 없음 (auto)
- 수갑 채움: 자동 · 추가 지정 없음 (auto)
- 안대 착용: 안대 착용 (badguest.blindfolded)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 40–59 (status.energy.2)
- 기분: 기분 60–79 (status.mood.3)
- 흥분도: 흥분도 20–39 (status.arousal.1)
- 심신 상태: 심신 상태 40–59 (status.wellbeing.2)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 자동 · 추가 지정 없음 (auto)
- 심적 이탈: 자동 · 추가 지정 없음 (auto)
- 허용 인식: 허용 인식 0 미만 (status.latitude.negative)
- 취기: 자동 · 추가 지정 없음 (auto)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 없음 (fluid.mouth.0)
- 가슴: 가슴 · 많이 묻어 있음 (fluid.breasts.3)
- 자궁: 자동 · 추가 지정 없음 (auto)
- 보지: 보지 · 애액이 맺힘 (fluid.vulva.2)
- 허벅지: 허벅지 · 묻어 있음 (fluid.thighs.2)
- 가슴: 자동 · 추가 지정 없음 (auto)
- 보지: 자동 · 추가 지정 없음 (auto)
- 대화 감지 규칙: 잠시 뒤 목덜미와 가슴 안쪽부터 설명하기 어려운 열기가 천천히 번지기 시작합니다 (dialogue-muzqz0av-1)
- 동의·강요 상태: 의식 없음 (unconscious)
- 사정 후 체액 흔적: 가슴의 흔적 (chest)
- 임신·산후 상태: 임신 초기 (early)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-serving__outfit-nude__room-taproom__mood-shy__exp-0111000__aft-messy__dialogue-svk1vi__v-0`

**선택 이미지 키**

`ichika__task-serving__outfit-nude__room-taproom__mood-shy__state-16vfnir__character-reuse-yo0w6i__studio-1u4sod8__position-standing-125hyxm__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-serving_outfit-nude_room-taproom_mood-shy_state-16vfnir_character-reuse-yo0w6i_studio-1u4sod8_p_portrait_1792428162187.webp`

### 09. 서빙 3 — 28,000점

통과 후보 94개. 총점 동점 3개 → 항목 우선순위까지 동점 1개 → 1개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | serving | serving |
| 복장 | 6,000 | exact | modest | modest |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0001100 | 0001100 |
| 흔적 | 0 | different | facial |  |
| 세부 자세(모드) | 0 | different |  | standing |
| 기분 | 0 | different | nervous; 감정 없음 | default; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | blindfolded, hallucinated, handcuffed | 없음 |
| 임신 상태(임신모드) | 0 | different | middle | none |
| 세부 상황(모드) | 0 | different | context.consent.hesitant, context.residue.thighs, dialogue-dialogue-muzxq0xh-2, mouth-3 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 기본 프리셋 (default)
- 자세 / 체위 · 장면별 적용: 적용 안함 · 자세 추가 없음 (auto)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 안대 착용 (badguest.blindfolded)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 60–79 (status.energy.3)
- 기분: 기분 60–79 (status.mood.3)
- 흥분도: 흥분도 40–59 (status.arousal.2)
- 심신 상태: 심신 상태 60–79 (status.wellbeing.3)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 원망도 60 이상 (status.resentment.high)
- 심적 이탈: 자동 · 추가 지정 없음 (auto)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 취기 · 취함 (status.intoxication.drunk)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 많이 묻어 있음 (fluid.mouth.3)
- 가슴: 자동 · 추가 지정 없음 (auto)
- 자궁: 자궁 · 없음 (fluid.uterus.0)
- 보지: 보지 · 애액이 맺힘 (fluid.vulva.2)
- 허벅지: 자동 · 추가 지정 없음 (auto)
- 가슴: 가슴 · 좌측 유두 피어싱 (jewelry.breasts.1)
- 보지: 보지 · 장신구 없음 (jewelry.vulva.0)
- 대화 감지 규칙: 끝내 압박을 떨쳐내지 못하고 마십니다 (dialogue-muzxq0xh-2)
- 동의·강요 상태: 망설이며 참여 (hesitant)
- 사정 후 체액 흔적: 허벅지에 흐르는 흔적 (thighs)
- 임신·산후 상태: 임신 중기 (middle)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-serving__outfit-modest__room-taproom__exp-0001100__aft-facial__dialogue-15snmuf__mood-nervous__studio-knx9r4__v-0`

**선택 이미지 키**

`ichika__task-serving__outfit-modest__room-taproom__exp-0001100__state-14m1446__state-9d04ah__studio-1u4sod8__position-standing-125hyxm__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-serving_outfit-modest_room-taproom_exp-0001100_state-14m1446_state-9d04ah_studio-1u4sod8_positi_portrait_1792424082787.webp`

### 10. 서빙 4 — 31,000점

통과 후보 65개. 총점 동점 1개 → 항목 우선순위까지 동점 1개 → 1개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | serving | serving |
| 복장 | 6,000 | exact | crop_blouse_skirt | crop_blouse_skirt |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0111101 | 0111101 |
| 흔적 | 0 | different | messy |  |
| 세부 자세(모드) | 3,000 | exact | standing | standing |
| 기분 | 0 | different | aroused; 감정 없음 | default; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | gagged, hallucinated, handcuffed | 없음 |
| 임신 상태(임신모드) | 0 | different | early | none |
| 세부 상황(모드) | 0 | different | breasts-4, jewelry-breasts-3, uterus-3 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 서 있기 (standing)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 자동 · 추가 지정 없음 (auto)
- 입마개 착용: 입마개 착용 (badguest.gagged)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 20–39 (status.energy.1)
- 기분: 기분 80–100 (status.mood.4)
- 흥분도: 흥분도 80–100 (status.arousal.4)
- 심신 상태: 자동 · 추가 지정 없음 (auto)
- 주목도: 주목도 60 이상 (status.allure.high)
- 신뢰: 신뢰 30 미만 (status.trust.low)
- 애정·욕망: 자동 · 추가 지정 없음 (auto)
- 원망도: 원망도 35–59 (status.resentment.medium)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 취기 · 만취 (status.intoxication.wasted)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 없음 (fluid.mouth.0)
- 가슴: 가슴 · 넘쳐남 (fluid.breasts.4)
- 자궁: 자궁 · 가득참 (fluid.uterus.3)
- 보지: 보지 · 건조함 (fluid.vulva.0)
- 허벅지: 자동 · 추가 지정 없음 (auto)
- 가슴: 가슴 · 양쪽 유두 피어싱 · 하트 초커 (jewelry.breasts.3)
- 보지: 보지 · 장신구 없음 (jewelry.vulva.0)
- 대화 감지 규칙: 자동 · 추가 지정 없음 (auto)
- 동의·강요 상태: 적용 안 함 (not_applicable)
- 사정 후 체액 흔적: 자동 · 추가 지정 없음 (auto)
- 임신·산후 상태: 임신 초기 (early)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-serving__outfit-crop_blouse_skirt__room-taproom__exp-0111101__aft-messy__state-g7ouwi__position-standing-125hyxm__mood-aroused__studio-ihk16a__v-0`

**선택 이미지 키**

`ichika__task-serving__outfit-crop_blouse_skirt__room-taproom__exp-0111101__state-16vfnir__character-reuse-yo0w6i__studio-1u4sod8__position-standing-125hyxm__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-serving_outfit-crop_blouse_skirt_room-taproom_exp-0111101_state-16vfnir_character-reuse-yo0w6i__portrait_1792413880975.webp`

### 11. 서빙 5 — 31,000점

통과 후보 109개. 총점 동점 1개 → 항목 우선순위까지 동점 1개 → 1개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | serving | serving |
| 복장 | 6,000 | exact | lingerie | lingerie |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0111100 | 0111100 |
| 흔적 | 0 | different | sweat |  |
| 세부 자세(모드) | 3,000 | exact | standing | standing |
| 기분 | 0 | different | enjoying; 감정 없음 | default; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | blindfolded, drugged, hallucinated, handcuffed | 없음 |
| 임신 상태(임신모드) | 0 | different | middle | none |
| 세부 상황(모드) | 0 | different | breasts-2, context.residue.thighs, jewelry-breasts-2, mouth-2, uterus-1 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 서 있기 (standing)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 안대 착용 (badguest.blindfolded)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 미약 복용 (badguest.drugged)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 0–19 (status.energy.0)
- 기분: 기분 20–39 (status.mood.1)
- 흥분도: 흥분도 80–100 (status.arousal.4)
- 심신 상태: 심신 상태 80–100 (status.wellbeing.4)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 원망도 35–59 (status.resentment.medium)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 자동 · 추가 지정 없음 (auto)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 묻어 있음 (fluid.mouth.2)
- 가슴: 가슴 · 묻어 있음 (fluid.breasts.2)
- 자궁: 자궁 · 질내 잔류 (fluid.uterus.1)
- 보지: 보지 · 허벅지 안쪽까지 흐름 (fluid.vulva.3)
- 허벅지: 자동 · 추가 지정 없음 (auto)
- 가슴: 가슴 · 양쪽 유두 피어싱 (jewelry.breasts.2)
- 보지: 보지 · 장신구 없음 (jewelry.vulva.0)
- 대화 감지 규칙: 자동 · 추가 지정 없음 (auto)
- 동의·강요 상태: 자동 · 추가 지정 없음 (auto)
- 사정 후 체액 흔적: 허벅지에 흐르는 흔적 (thighs)
- 임신·산후 상태: 임신 중기 (middle)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-serving__outfit-lingerie__room-taproom__exp-0111100__aft-sweat__state-g1r2gj__position-standing-125hyxm__mood-enjoying__studio-x4ha9l__v-0`

**선택 이미지 키**

`ichika__task-serving__outfit-lingerie__room-taproom__exp-0111100__state-16vfnir__character-reuse-yo0w6i__studio-1u4sod8__position-standing-125hyxm__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-serving_outfit-lingerie_room-taproom_exp-0111100_state-16vfnir_character-reuse-yo0w6i_studio-1u_portrait_1792423001146.webp`

### 12. 서빙 6 — 29,500점

통과 후보 34개. 총점 동점 1개 → 항목 우선순위까지 동점 1개 → 1개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | serving | serving |
| 복장 | 6,000 | exact | his_shirt | his_shirt |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 2,000 | similar | 1000000 | 0000000 |
| 흔적 | 1,000 | exact | sweat | sweat |
| 세부 자세(모드) | 0 | different |  | standing |
| 기분 | 1,000 | exact | shy; 감정 없음 | shy; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | gagged, hallucinated, handcuffed | 없음 |
| 임신 상태(임신모드) | 500 | exact | none | none |
| 세부 상황(모드) | 0 | different | context.consent.unconscious, dialogue-dialogue-muzxq0xh-2, uterus-3 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 적용 안함 · 자세 추가 없음 (auto)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 자동 · 추가 지정 없음 (auto)
- 입마개 착용: 입마개 착용 (badguest.gagged)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 20–39 (status.energy.1)
- 기분: 기분 0–19 (status.mood.0)
- 흥분도: 흥분도 80–100 (status.arousal.4)
- 심신 상태: 심신 상태 20–39 (status.wellbeing.1)
- 주목도: 주목도 60 이상 (status.allure.high)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 자동 · 추가 지정 없음 (auto)
- 원망도: 자동 · 추가 지정 없음 (auto)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 취기 · 만취 (status.intoxication.wasted)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 없음 (fluid.mouth.0)
- 가슴: 가슴 · 흔적이 남음 (fluid.breasts.1)
- 자궁: 자궁 · 가득참 (fluid.uterus.3)
- 보지: 자동 · 추가 지정 없음 (auto)
- 허벅지: 자동 · 추가 지정 없음 (auto)
- 가슴: 자동 · 추가 지정 없음 (auto)
- 보지: 보지 · 클리 피어싱 (jewelry.vulva.1)
- 대화 감지 규칙: 끝내 압박을 떨쳐내지 못하고 마십니다 (dialogue-muzxq0xh-2)
- 동의·강요 상태: 의식 없음 (unconscious)
- 사정 후 체액 흔적: 자동 · 추가 지정 없음 (auto)
- 임신·산후 상태: 자동 · 추가 지정 없음 (auto)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-serving__outfit-his_shirt__room-taproom__mood-shy__exp-1000000__aft-sweat__dialogue-137txxz__v-0`

**선택 이미지 키**

`ichika__task-serving__outfit-his_shirt__room-taproom__mood-shy__aft-sweat__state-16vfnir__character-reuse-yo0w6i__studio-1u4sod8__position-standing-125hyxm__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-serving_outfit-his_shirt_room-taproom_mood-shy_aft-sweat_state-16vfnir_character-reuse-yo0w6i_s_portrait_1792409742369.webp`

### 13. 메뉴 질문(주문 받기) 1 — 27,000점

통과 후보 14개. 총점 동점 7개 → 항목 우선순위까지 동점 7개 → 4개 구성 묶음 중 선택 묶음의 변형 2개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | taking_order | taking_order |
| 복장 | 6,000 | exact | nude | nude |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 2,000 | similar | 1000000 | 0000000 |
| 흔적 | 0 | different | facial |  |
| 세부 자세(모드) | 0 | different |  | standing |
| 기분 | 0 | different | aroused; 감정 없음 | shy; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | drugged | 없음 |
| 임신 상태(임신모드) | 0 | different | middle | none |
| 세부 상황(모드) | 0 | different | breasts-2, context.residue.chest, dialogue-dialogue-muzxq0xh-2, jewelry-breasts-2, jewelry-vulva-1, thighs-2, vulva-3 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 적용 안함 · 자세 추가 없음 (auto)
- 수갑 채움: 자동 · 추가 지정 없음 (auto)
- 안대 착용: 자동 · 추가 지정 없음 (auto)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 미약 복용 (badguest.drugged)
- 환각 상태: 자동 · 추가 지정 없음 (auto)
- 기력: 기력 80–100 (status.energy.4)
- 기분: 기분 40–59 (status.mood.2)
- 흥분도: 자동 · 추가 지정 없음 (auto)
- 심신 상태: 자동 · 추가 지정 없음 (auto)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 원망도 60 이상 (status.resentment.high)
- 심적 이탈: 자동 · 추가 지정 없음 (auto)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 취기 · 살짝 취함 (status.intoxication.tipsy)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 없음 (fluid.mouth.0)
- 가슴: 가슴 · 묻어 있음 (fluid.breasts.2)
- 자궁: 자궁 · 없음 (fluid.uterus.0)
- 보지: 보지 · 허벅지 안쪽까지 흐름 (fluid.vulva.3)
- 허벅지: 허벅지 · 묻어 있음 (fluid.thighs.2)
- 가슴: 가슴 · 양쪽 유두 피어싱 (jewelry.breasts.2)
- 보지: 보지 · 클리 피어싱 (jewelry.vulva.1)
- 대화 감지 규칙: 끝내 압박을 떨쳐내지 못하고 마십니다 (dialogue-muzxq0xh-2)
- 동의·강요 상태: 적용 안 함 (not_applicable)
- 사정 후 체액 흔적: 가슴의 흔적 (chest)
- 임신·산후 상태: 임신 중기 (middle)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-taking_order__outfit-nude__room-taproom__exp-1000000__aft-facial__dialogue-1tkb8x0__mood-aroused__studio-ihk16a__v-0`

**선택 이미지 키**

`ichika__task-taking_order__outfit-nude__room-taproom__mood-shy__state-16vfnir__character-reuse-yo0w6i__studio-1712m17__position-standing-125hyxm__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-taking_order_outfit-nude_room-taproom_mood-shy_state-16vfnir_character-reuse-yo0w6i_studio-1712_portrait_1792428581937.webp`

### 14. 메뉴 질문(주문 받기) 2 — 32,000점

통과 후보 116개. 총점 동점 1개 → 항목 우선순위까지 동점 1개 → 1개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | taking_order | taking_order |
| 복장 | 6,000 | exact | strapless_thigh_boots | strapless_thigh_boots |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0101010 | 0101010 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact | standing | standing |
| 기분 | 0 | different | nervous; 감정 없음 | default; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | gagged, handcuffed | 없음 |
| 임신 상태(임신모드) | 0 | different | postpartum | none |
| 세부 상황(모드) | 0 | different | context.consent.voluntary, context.residue.hands, dialogue-dialogue-muzyywtf-3, jewelry-breasts-3, jewelry-vulva-1, mouth-4, thighs-2, uterus-3, vulva-1 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 서 있기 (standing)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 자동 · 추가 지정 없음 (auto)
- 입마개 착용: 입마개 착용 (badguest.gagged)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 자동 · 추가 지정 없음 (auto)
- 기력: 기력 80–100 (status.energy.4)
- 기분: 기분 60–79 (status.mood.3)
- 흥분도: 흥분도 80–100 (status.arousal.4)
- 심신 상태: 심신 상태 60–79 (status.wellbeing.3)
- 주목도: 주목도 60 이상 (status.allure.high)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 자동 · 추가 지정 없음 (auto)
- 원망도: 원망도 60 이상 (status.resentment.high)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 허용 인식 0 미만 (status.latitude.negative)
- 취기: 취기 · 몸을 못 가눔 (status.intoxication.sloppy)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 넘쳐남 (fluid.mouth.4)
- 가슴: 자동 · 추가 지정 없음 (auto)
- 자궁: 자궁 · 가득참 (fluid.uterus.3)
- 보지: 보지 · 은은하게 젖음 (fluid.vulva.1)
- 허벅지: 허벅지 · 묻어 있음 (fluid.thighs.2)
- 가슴: 가슴 · 양쪽 유두 피어싱 · 하트 초커 (jewelry.breasts.3)
- 보지: 보지 · 클리 피어싱 (jewelry.vulva.1)
- 대화 감지 규칙: 저항을 눌러 버리고 (dialogue-muzyywtf-3)
- 동의·강요 상태: 자발적 참여 (voluntary)
- 사정 후 체액 흔적: 손의 흔적 (hands)
- 임신·산후 상태: 출산 당일·산후 (postpartum)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-taking_order__outfit-strapless_thigh_boots__room-taproom__exp-0101010__dialogue-npthvt__position-standing-125hyxm__mood-nervous__studio-knx9r4__v-0`

**선택 이미지 키**

`ichika__task-taking_order__outfit-strapless_thigh_boots__room-taproom__exp-0101010__state-16vfnir__character-reuse-yo0w6i__studio-1712m17__position-standing-125hyxm__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-taking_order_outfit-strapless_thigh_boots_room-taproom_exp-0101010_state-16vfnir_character-reus_portrait_1792418981384.webp`

### 15. 메뉴 질문(주문 받기) 3 — 30,000점

통과 후보 134개. 총점 동점 2개 → 항목 우선순위까지 동점 2개 → 2개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | taking_order | taking_order |
| 복장 | 6,000 | exact | modest | modest |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0000000 | 0000000 |
| 흔적 | 1,000 | exact | facial | facial |
| 세부 자세(모드) | 0 | different |  | standing |
| 기분 | 1,000 | similar | nervous; 감정 없음 | worried; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | drugged, handcuffed | 없음 |
| 임신 상태(임신모드) | 0 | different | postpartum | none |
| 세부 상황(모드) | 0 | different | context.consent.forced_join, context.residue.chest, dialogue-dialogue-muzyywtf-3, mouth-1 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 기본 프리셋 (default)
- 자세 / 체위 · 장면별 적용: 적용 안함 · 자세 추가 없음 (auto)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 자동 · 추가 지정 없음 (auto)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 미약 복용 (badguest.drugged)
- 환각 상태: 자동 · 추가 지정 없음 (auto)
- 기력: 자동 · 추가 지정 없음 (auto)
- 기분: 기분 60–79 (status.mood.3)
- 흥분도: 자동 · 추가 지정 없음 (auto)
- 심신 상태: 자동 · 추가 지정 없음 (auto)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 신뢰 30 미만 (status.trust.low)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 원망도 60 이상 (status.resentment.high)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 자동 · 추가 지정 없음 (auto)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 흔적이 남음 (fluid.mouth.1)
- 가슴: 가슴 · 많이 묻어 있음 (fluid.breasts.3)
- 자궁: 자동 · 추가 지정 없음 (auto)
- 보지: 보지 · 애액이 맺힘 (fluid.vulva.2)
- 허벅지: 허벅지 · 없음 (fluid.thighs.0)
- 가슴: 가슴 · 양쪽 유두 피어싱 · 하트 초커 (jewelry.breasts.3)
- 보지: 보지 · 클리 피어싱 (jewelry.vulva.1)
- 대화 감지 규칙: 저항을 눌러 버리고 (dialogue-muzyywtf-3)
- 동의·강요 상태: 강제 합류 (forced_join)
- 사정 후 체액 흔적: 가슴의 흔적 (chest)
- 임신·산후 상태: 출산 당일·산후 (postpartum)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-taking_order__outfit-modest__room-taproom__aft-facial__dialogue-5tal87__mood-nervous__studio-knx9r4__v-0`

**선택 이미지 키**

`ichika__task-taking_order__outfit-modest__room-taproom__mood-worried__aft-facial__state-14m1446__state-9d04ah__studio-1712m17__position-standing-125hyxm__v-1`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-taking_order_outfit-modest_room-taproom_mood-worried_aft-facial_state-14m1446_state-9d04ah_stud_portrait_1792433382324.webp`

### 16. 메뉴 질문(주문 받기) 4 — 32,000점

통과 후보 107개. 총점 동점 1개 → 항목 우선순위까지 동점 1개 → 1개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | taking_order | taking_order |
| 복장 | 6,000 | exact | crop_blouse_skirt | crop_blouse_skirt |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0001010 | 0001010 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact | standing | standing |
| 기분 | 0 | different | nervous; 감정 없음 | default; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | blindfolded, hallucinated | 없음 |
| 임신 상태(임신모드) | 0 | different | middle | none |
| 세부 상황(모드) | 0 | different | context.consent.drugged, context.residue.hands, dialogue-dialogue-muzxq0xh-2, mouth-4, thighs-1, uterus-2, vulva-1 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 서 있기 (standing)
- 수갑 채움: 자동 · 추가 지정 없음 (auto)
- 안대 착용: 안대 착용 (badguest.blindfolded)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 60–79 (status.energy.3)
- 기분: 기분 60–79 (status.mood.3)
- 흥분도: 흥분도 80–100 (status.arousal.4)
- 심신 상태: 심신 상태 60–79 (status.wellbeing.3)
- 주목도: 주목도 60 이상 (status.allure.high)
- 신뢰: 신뢰 30 미만 (status.trust.low)
- 애정·욕망: 자동 · 추가 지정 없음 (auto)
- 원망도: 자동 · 추가 지정 없음 (auto)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 취기 · 만취 (status.intoxication.wasted)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 넘쳐남 (fluid.mouth.4)
- 가슴: 가슴 · 묻어 있음 (fluid.breasts.2)
- 자궁: 자궁 · 자궁 내 일부 (fluid.uterus.2)
- 보지: 보지 · 은은하게 젖음 (fluid.vulva.1)
- 허벅지: 허벅지 · 흔적이 남음 (fluid.thighs.1)
- 가슴: 가슴 · 장신구 없음 (jewelry.breasts.0)
- 보지: 자동 · 추가 지정 없음 (auto)
- 대화 감지 규칙: 끝내 압박을 떨쳐내지 못하고 마십니다 (dialogue-muzxq0xh-2)
- 동의·강요 상태: 미약 영향 (drugged)
- 사정 후 체액 흔적: 손의 흔적 (hands)
- 임신·산후 상태: 임신 중기 (middle)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-taking_order__outfit-crop_blouse_skirt__room-taproom__exp-0001010__dialogue-6ebvxy__position-standing-125hyxm__mood-nervous__studio-knx9r4__v-0`

**선택 이미지 키**

`ichika__task-taking_order__outfit-crop_blouse_skirt__room-taproom__exp-0001010__state-16vfnir__character-reuse-yo0w6i__studio-1712m17__position-standing-125hyxm__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-taking_order_outfit-crop_blouse_skirt_room-taproom_exp-0001010_state-16vfnir_character-reuse-yo_portrait_1792417660490.webp`

### 17. 메뉴 질문(주문 받기) 5 — 28,000점

통과 후보 107개. 총점 동점 1개 → 항목 우선순위까지 동점 1개 → 1개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | taking_order | taking_order |
| 복장 | 6,000 | exact | crop_blouse_skirt | crop_blouse_skirt |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0101010 | 0101010 |
| 흔적 | 0 | different | sweat |  |
| 세부 자세(모드) | 0 | different |  | standing |
| 기분 | 0 | different | shy; 감정 없음 | default; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | hallucinated, handcuffed | 없음 |
| 임신 상태(임신모드) | 0 | different | late | none |
| 세부 상황(모드) | 0 | different | breasts-1, context.consent.hesitant, context.residue.mixed, dialogue-dialogue-muzqz0av-1, jewelry-vulva-1, mouth-1, thighs-2, vulva-3 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 적용 안함 · 자세 추가 없음 (auto)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 자동 · 추가 지정 없음 (auto)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 40–59 (status.energy.2)
- 기분: 기분 0–19 (status.mood.0)
- 흥분도: 흥분도 80–100 (status.arousal.4)
- 심신 상태: 심신 상태 60–79 (status.wellbeing.3)
- 주목도: 주목도 60 이상 (status.allure.high)
- 신뢰: 신뢰 30 미만 (status.trust.low)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 원망도 60 이상 (status.resentment.high)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 취기 · 취함 (status.intoxication.drunk)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 흔적이 남음 (fluid.mouth.1)
- 가슴: 가슴 · 흔적이 남음 (fluid.breasts.1)
- 자궁: 자궁 · 없음 (fluid.uterus.0)
- 보지: 보지 · 허벅지 안쪽까지 흐름 (fluid.vulva.3)
- 허벅지: 허벅지 · 묻어 있음 (fluid.thighs.2)
- 가슴: 자동 · 추가 지정 없음 (auto)
- 보지: 보지 · 클리 피어싱 (jewelry.vulva.1)
- 대화 감지 규칙: 잠시 뒤 목덜미와 가슴 안쪽부터 설명하기 어려운 열기가 천천히 번지기 시작합니다 (dialogue-muzqz0av-1)
- 동의·강요 상태: 망설이며 참여 (hesitant)
- 사정 후 체액 흔적: 여러 부위 흔적 (mixed)
- 임신·산후 상태: 임신 후기 (late)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-taking_order__outfit-crop_blouse_skirt__room-taproom__mood-shy__exp-0101010__aft-sweat__dialogue-1mrhtyt__v-0`

**선택 이미지 키**

`ichika__task-taking_order__outfit-crop_blouse_skirt__room-taproom__exp-0101010__state-16vfnir__character-reuse-yo0w6i__studio-1712m17__position-standing-125hyxm__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-taking_order_outfit-crop_blouse_skirt_room-taproom_exp-0101010_state-16vfnir_character-reuse-yo_portrait_1792416340267.webp`

### 18. 메뉴 질문(주문 받기) 6 — 29,000점

통과 후보 108개. 총점 동점 4개 → 항목 우선순위까지 동점 4개 → 1개 구성 묶음 중 선택 묶음의 변형 4개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | taking_order | taking_order |
| 복장 | 6,000 | exact | wench_bodice | wench_bodice |
| 남자 그룹 역할 | 5,000 | exact | 0명 / 없음 | 0명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0111100 | 0111100 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 0 | different |  | standing |
| 기분 | 0 | different | smile; 감정 없음 | default; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | blindfolded, gagged | 없음 |
| 임신 상태(임신모드) | 0 | different | late | none |
| 세부 상황(모드) | 0 | different | context.consent.forced_join, context.residue.hands, dialogue-dialogue-muzqz0av-1, jewelry-breasts-2, mouth-1, thighs-2, uterus-1 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 적용 안함 · 자세 추가 없음 (auto)
- 수갑 채움: 자동 · 추가 지정 없음 (auto)
- 안대 착용: 안대 착용 (badguest.blindfolded)
- 입마개 착용: 입마개 착용 (badguest.gagged)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 자동 · 추가 지정 없음 (auto)
- 기력: 기력 20–39 (status.energy.1)
- 기분: 기분 40–59 (status.mood.2)
- 흥분도: 흥분도 0–19 (status.arousal.0)
- 심신 상태: 심신 상태 80–100 (status.wellbeing.4)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 신뢰 30 미만 (status.trust.low)
- 애정·욕망: 자동 · 추가 지정 없음 (auto)
- 원망도: 자동 · 추가 지정 없음 (auto)
- 심적 이탈: 자동 · 추가 지정 없음 (auto)
- 허용 인식: 허용 인식 0 미만 (status.latitude.negative)
- 취기: 취기 · 만취 (status.intoxication.wasted)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 흔적이 남음 (fluid.mouth.1)
- 가슴: 자동 · 추가 지정 없음 (auto)
- 자궁: 자궁 · 질내 잔류 (fluid.uterus.1)
- 보지: 보지 · 은은하게 젖음 (fluid.vulva.1)
- 허벅지: 허벅지 · 묻어 있음 (fluid.thighs.2)
- 가슴: 가슴 · 양쪽 유두 피어싱 (jewelry.breasts.2)
- 보지: 보지 · 장신구 없음 (jewelry.vulva.0)
- 대화 감지 규칙: 잠시 뒤 목덜미와 가슴 안쪽부터 설명하기 어려운 열기가 천천히 번지기 시작합니다 (dialogue-muzqz0av-1)
- 동의·강요 상태: 강제 합류 (forced_join)
- 사정 후 체액 흔적: 손의 흔적 (hands)
- 임신·산후 상태: 임신 후기 (late)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__task-taking_order__outfit-wench_bodice__room-taproom__mood-smile__exp-0111100__dialogue-17p7omp__v-0`

**선택 이미지 키**

`ichika__task-taking_order__outfit-wench_bodice__room-taproom__exp-0111100__state-16vfnir__character-reuse-yo0w6i__studio-1712m17__position-standing-125hyxm__v-2`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\task-taking_order_outfit-wench_bodice_room-taproom_exp-0111100_state-16vfnir_character-reuse-yo0w6i__portrait_1792444662310.webp`

### 19. 대화하기 1 — 31,000점

통과 후보 20개. 총점 동점 7개 → 항목 우선순위까지 동점 7개 → 6개 구성 묶음 중 선택 묶음의 변형 2개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | patron_chatting | patron_chatting |
| 복장 | 6,000 | exact | silk_robe | silk_robe |
| 남자 그룹 역할 | 5,000 | exact | 1명 / 없음 | 1명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 2,000 | similar | 0100000 | 0000000 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact |  |  |
| 기분 | 0 | different | smile; 감정 없음 | default; 감정 기록 없음 |
| 나쁜 손님 모드 상태 | 0 | different | blindfolded, gagged, hallucinated | 기록 없음 |
| 임신 상태(임신모드) | 0 | different | early | 기록 없음 |
| 세부 상황(모드) | 0 | different | breasts-3, context.consent.forced_join, context.residue.mixed, dialogue-dialogue-muzqz0av-1 | 기록 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 적용 안함 · 자세 추가 없음 (auto)
- 수갑 채움: 자동 · 추가 지정 없음 (auto)
- 안대 착용: 안대 착용 (badguest.blindfolded)
- 입마개 착용: 입마개 착용 (badguest.gagged)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 자동 · 추가 지정 없음 (auto)
- 기분: 기분 0–19 (status.mood.0)
- 흥분도: 흥분도 80–100 (status.arousal.4)
- 심신 상태: 심신 상태 60–79 (status.wellbeing.3)
- 주목도: 주목도 60 이상 (status.allure.high)
- 신뢰: 신뢰 30 미만 (status.trust.low)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 원망도 60 이상 (status.resentment.high)
- 심적 이탈: 자동 · 추가 지정 없음 (auto)
- 허용 인식: 허용 인식 0 미만 (status.latitude.negative)
- 취기: 취기 · 의식 없음 (status.intoxication.blacked_out)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 자동 · 추가 지정 없음 (auto)
- 가슴: 가슴 · 많이 묻어 있음 (fluid.breasts.3)
- 자궁: 자동 · 추가 지정 없음 (auto)
- 보지: 보지 · 은은하게 젖음 (fluid.vulva.1)
- 허벅지: 허벅지 · 흔적이 남음 (fluid.thighs.1)
- 가슴: 가슴 · 장신구 없음 (jewelry.breasts.0)
- 보지: 보지 · 장신구 없음 (jewelry.vulva.0)
- 대화 감지 규칙: 잠시 뒤 목덜미와 가슴 안쪽부터 설명하기 어려운 열기가 천천히 번지기 시작합니다 (dialogue-muzqz0av-1)
- 동의·강요 상태: 강제 합류 (forced_join)
- 사정 후 체액 흔적: 여러 부위 흔적 (mixed)
- 임신·산후 상태: 임신 초기 (early)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__scene-patron_chatting__outfit-silk_robe__room-taproom__mood-smile__exp-0100000__dialogue-wok0x3__v-0`

**선택 이미지 키**

`ichika__scene-patron_chatting__outfit-silk_robe__room-taproom__character-reuse-1hcvgnt__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\scene-patron_chatting_outfit-silk_robe_room-taproom_character-reuse-1hcvgnt_v-0_portrait_1792134790839.webp`

### 20. 대화하기 2 — 31,000점

통과 후보 94개. 총점 동점 2개 → 항목 우선순위까지 동점 2개 → 2개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | patron_chatting | patron_chatting |
| 복장 | 6,000 | exact | satin_babydoll | satin_babydoll |
| 남자 그룹 역할 | 5,000 | exact | 1명 / 없음 | 1명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 2,000 | similar | 1000000 | 0000000 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact | sitting | sitting |
| 기분 | 0 | different | enjoying; 감정 없음 | default; 감정 기록 없음 |
| 나쁜 손님 모드 상태 | 0 | different | drugged, gagged, hallucinated, handcuffed | 기록 없음 |
| 임신 상태(임신모드) | 0 | different | late | 기록 없음 |
| 세부 상황(모드) | 0 | different | context.consent.unconscious, dialogue-dialogue-muzqz0av-1, thighs-1 | 기록 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 기본 프리셋 (default)
- 자세 / 체위 · 장면별 적용: 마주 앉기 (sitting)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 자동 · 추가 지정 없음 (auto)
- 입마개 착용: 입마개 착용 (badguest.gagged)
- 미약 복용: 미약 복용 (badguest.drugged)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 자동 · 추가 지정 없음 (auto)
- 기분: 기분 0–19 (status.mood.0)
- 흥분도: 흥분도 0–19 (status.arousal.0)
- 심신 상태: 심신 상태 20–39 (status.wellbeing.1)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 신뢰 30 미만 (status.trust.low)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 원망도 35–59 (status.resentment.medium)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 취기 · 몸을 못 가눔 (status.intoxication.sloppy)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 없음 (fluid.mouth.0)
- 가슴: 가슴 · 흔적이 남음 (fluid.breasts.1)
- 자궁: 자궁 · 없음 (fluid.uterus.0)
- 보지: 보지 · 허벅지 안쪽까지 흐름 (fluid.vulva.3)
- 허벅지: 허벅지 · 흔적이 남음 (fluid.thighs.1)
- 가슴: 가슴 · 양쪽 유두 피어싱 (jewelry.breasts.2)
- 보지: 보지 · 장신구 없음 (jewelry.vulva.0)
- 대화 감지 규칙: 잠시 뒤 목덜미와 가슴 안쪽부터 설명하기 어려운 열기가 천천히 번지기 시작합니다 (dialogue-muzqz0av-1)
- 동의·강요 상태: 의식 없음 (unconscious)
- 사정 후 체액 흔적: 흔적 없음 (none)
- 임신·산후 상태: 임신 후기 (late)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__scene-patron_chatting__outfit-satin_babydoll__room-taproom__exp-1000000__dialogue-sfssju__position-sitting-r68ijm__mood-enjoying__studio-x4ha9l__v-0`

**선택 이미지 키**

`ichika__scene-patron_chatting__outfit-satin_babydoll__room-taproom__character-reuse-1hcvgnt__position-sitting-r68ijm__v-3`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\scene-patron_chatting_outfit-satin_babydoll_room-taproom_character-reuse-1hcvgnt_position-sitting-r6_portrait_1792235590421.webp`

### 21. 대화하기 3 — 28,000점

통과 후보 20개. 총점 동점 2개 → 항목 우선순위까지 동점 2개 → 1개 구성 묶음 중 선택 묶음의 변형 2개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | patron_chatting | patron_chatting |
| 복장 | 6,000 | exact | silk_robe | silk_robe |
| 남자 그룹 역할 | 5,000 | exact | 1명 / 없음 | 1명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | -2,000 | similar | 0111101 | 0000000 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact | close-embrace | close-embrace |
| 기분 | 1,000 | similar | nervous; 감정 없음 | shy; 감정 기록 없음 |
| 나쁜 손님 모드 상태 | 0 | different | drugged, gagged, handcuffed | 기록 없음 |
| 임신 상태(임신모드) | 0 | different | middle | 기록 없음 |
| 세부 상황(모드) | 0 | different | breasts-1, context.consent.forced_join, context.residue.body, mouth-4, uterus-1, vulva-4 | 기록 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 마주보고 밀착 (close-embrace)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 자동 · 추가 지정 없음 (auto)
- 입마개 착용: 입마개 착용 (badguest.gagged)
- 미약 복용: 미약 복용 (badguest.drugged)
- 환각 상태: 자동 · 추가 지정 없음 (auto)
- 기력: 기력 80–100 (status.energy.4)
- 기분: 기분 60–79 (status.mood.3)
- 흥분도: 흥분도 40–59 (status.arousal.2)
- 심신 상태: 심신 상태 60–79 (status.wellbeing.3)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 자동 · 추가 지정 없음 (auto)
- 원망도: 원망도 60 이상 (status.resentment.high)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 취기 · 몸을 못 가눔 (status.intoxication.sloppy)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 넘쳐남 (fluid.mouth.4)
- 가슴: 가슴 · 흔적이 남음 (fluid.breasts.1)
- 자궁: 자궁 · 질내 잔류 (fluid.uterus.1)
- 보지: 보지 · 애액이 허벅지를 타고 흐름 (fluid.vulva.4)
- 허벅지: 자동 · 추가 지정 없음 (auto)
- 가슴: 가슴 · 장신구 없음 (jewelry.breasts.0)
- 보지: 자동 · 추가 지정 없음 (auto)
- 대화 감지 규칙: 자동 · 추가 지정 없음 (auto)
- 동의·강요 상태: 강제 합류 (forced_join)
- 사정 후 체액 흔적: 몸의 흔적 (body)
- 임신·산후 상태: 임신 중기 (middle)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__scene-patron_chatting__outfit-silk_robe__room-taproom__exp-0111101__state-12aqrms__position-close-embrace-f08y0h__mood-nervous__studio-knx9r4__v-2`

**선택 이미지 키**

`ichika__scene-patron_chatting__outfit-silk_robe__room-taproom__mood-shy__character-reuse-1hcvgnt__position-close-embrace-f08y0h__v-3`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\scene-patron_chatting_outfit-silk_robe_room-taproom_mood-shy_character-reuse-1hcvgnt_position-close-_portrait_1792228983402.webp`

### 22. 대화하기 4 — 30,000점

통과 후보 20개. 총점 동점 2개 → 항목 우선순위까지 동점 2개 → 1개 구성 묶음 중 선택 묶음의 변형 2개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | patron_chatting | patron_chatting |
| 복장 | 6,000 | exact | silk_robe | silk_robe |
| 남자 그룹 역할 | 5,000 | exact | 1명 / 없음 | 1명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 1,000 | similar | 0001010 | 0000000 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact | sitting | sitting |
| 기분 | 0 | different | scared; 감정 없음 | default; 감정 기록 없음 |
| 나쁜 손님 모드 상태 | 0 | different | blindfolded, handcuffed | 기록 없음 |
| 임신 상태(임신모드) | 0 | different | none | 기록 없음 |
| 세부 상황(모드) | 0 | different | context.residue.chest, thighs-1, vulva-4 | 기록 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 마주 앉기 (sitting)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 안대 착용 (badguest.blindfolded)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 자동 · 추가 지정 없음 (auto)
- 기력: 기력 80–100 (status.energy.4)
- 기분: 기분 80–100 (status.mood.4)
- 흥분도: 자동 · 추가 지정 없음 (auto)
- 심신 상태: 심신 상태 60–79 (status.wellbeing.3)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 자동 · 추가 지정 없음 (auto)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 자동 · 추가 지정 없음 (auto)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 자동 · 추가 지정 없음 (auto)
- 가슴: 가슴 · 넘쳐남 (fluid.breasts.4)
- 자궁: 자궁 · 없음 (fluid.uterus.0)
- 보지: 보지 · 애액이 허벅지를 타고 흐름 (fluid.vulva.4)
- 허벅지: 허벅지 · 흔적이 남음 (fluid.thighs.1)
- 가슴: 가슴 · 좌측 유두 피어싱 (jewelry.breasts.1)
- 보지: 자동 · 추가 지정 없음 (auto)
- 대화 감지 규칙: 자동 · 추가 지정 없음 (auto)
- 동의·강요 상태: 자동 · 추가 지정 없음 (auto)
- 사정 후 체액 흔적: 가슴의 흔적 (chest)
- 임신·산후 상태: 임신 상태 없음 (none)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__scene-patron_chatting__outfit-silk_robe__room-taproom__mood-scared__exp-0001010__state-1v4pkry__position-sitting-r68ijm__v-1`

**선택 이미지 키**

`ichika__scene-patron_chatting__outfit-silk_robe__room-taproom__character-reuse-1hcvgnt__position-sitting-r68ijm__v-2`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\scene-patron_chatting_outfit-silk_robe_room-taproom_character-reuse-1hcvgnt_position-sitting-r68ijm__portrait_1792212530924.webp`

### 23. 대화하기 5 — 31,000점

통과 후보 68개. 총점 동점 12개 → 항목 우선순위까지 동점 12개 → 8개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | patron_chatting | patron_chatting |
| 복장 | 6,000 | exact | wench_bodice | wench_bodice |
| 남자 그룹 역할 | 5,000 | exact | 1명 / 없음 | 1명 / 없음 |
| 장소 | 4,000 | similar | taproom | back_room |
| 세부 복장(노출) 상태 | 2,000 | similar | 0100000 | 0000000 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact | sitting | sitting |
| 기분 | 0 | different | enjoying; 감정 없음 | default; 감정 기록 없음 |
| 나쁜 손님 모드 상태 | 0 | different | drugged, gagged, hallucinated, handcuffed | 기록 없음 |
| 임신 상태(임신모드) | 0 | different | postpartum | 기록 없음 |
| 세부 상황(모드) | 0 | different | breasts-4, context.residue.body, dialogue-dialogue-muzxq0xh-2, mouth-4 | 기록 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 기본 프리셋 (default)
- 자세 / 체위 · 장면별 적용: 마주 앉기 (sitting)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 자동 · 추가 지정 없음 (auto)
- 입마개 착용: 입마개 착용 (badguest.gagged)
- 미약 복용: 미약 복용 (badguest.drugged)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 0–19 (status.energy.0)
- 기분: 기분 80–100 (status.mood.4)
- 흥분도: 흥분도 60–79 (status.arousal.3)
- 심신 상태: 심신 상태 60–79 (status.wellbeing.3)
- 주목도: 주목도 60 이상 (status.allure.high)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 자동 · 추가 지정 없음 (auto)
- 원망도: 원망도 60 이상 (status.resentment.high)
- 심적 이탈: 자동 · 추가 지정 없음 (auto)
- 허용 인식: 허용 인식 0 미만 (status.latitude.negative)
- 취기: 취기 · 살짝 취함 (status.intoxication.tipsy)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 넘쳐남 (fluid.mouth.4)
- 가슴: 가슴 · 넘쳐남 (fluid.breasts.4)
- 자궁: 자궁 · 자궁 내 일부 (fluid.uterus.2)
- 보지: 보지 · 허벅지 안쪽까지 흐름 (fluid.vulva.3)
- 허벅지: 허벅지 · 흔적이 남음 (fluid.thighs.1)
- 가슴: 가슴 · 장신구 없음 (jewelry.breasts.0)
- 보지: 자동 · 추가 지정 없음 (auto)
- 대화 감지 규칙: 끝내 압박을 떨쳐내지 못하고 마십니다 (dialogue-muzxq0xh-2)
- 동의·강요 상태: 자동 · 추가 지정 없음 (auto)
- 사정 후 체액 흔적: 몸의 흔적 (body)
- 임신·산후 상태: 출산 당일·산후 (postpartum)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__scene-patron_chatting__outfit-wench_bodice__room-taproom__exp-0100000__dialogue-4o6b6o__position-sitting-r68ijm__mood-enjoying__studio-x4ha9l__v-0`

**선택 이미지 키**

`ichika__scene-patron_chatting__outfit-wench_bodice__room-back_room__character-reuse-1hcvgnt__position-sitting-r68ijm__v-3`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\scene-patron_chatting_outfit-wench_bodice_room-back_room_character-reuse-1hcvgnt_position-sitting-r6_portrait_1792239081675.webp`

### 24. 대화하기 6 — 30,000점

통과 후보 94개. 총점 동점 14개 → 항목 우선순위까지 동점 14개 → 9개 구성 묶음 중 선택 묶음의 변형 2개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | patron_chatting | patron_chatting |
| 복장 | 6,000 | exact | lingerie | lingerie |
| 남자 그룹 역할 | 5,000 | exact | 1명 / 없음 | 1명 / 없음 |
| 장소 | 4,000 | similar | taproom | back_room |
| 세부 복장(노출) 상태 | 1,000 | similar | 0110000 | 0000000 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact |  |  |
| 기분 | 0 | different | relieved; 감정 없음 | default; 감정 기록 없음 |
| 나쁜 손님 모드 상태 | 0 | different | drugged, hallucinated | 기록 없음 |
| 임신 상태(임신모드) | 0 | different | none | 기록 없음 |
| 세부 상황(모드) | 0 | different | breasts-3, context.consent.hesitant, dialogue-dialogue-muzyywtf-3, jewelry-breasts-1, mouth-3, uterus-3 | 기록 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 적용 안함 · 자세 추가 없음 (auto)
- 수갑 채움: 자동 · 추가 지정 없음 (auto)
- 안대 착용: 자동 · 추가 지정 없음 (auto)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 미약 복용 (badguest.drugged)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 40–59 (status.energy.2)
- 기분: 기분 40–59 (status.mood.2)
- 흥분도: 흥분도 0–19 (status.arousal.0)
- 심신 상태: 심신 상태 20–39 (status.wellbeing.1)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 신뢰 30 미만 (status.trust.low)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 원망도 60 이상 (status.resentment.high)
- 심적 이탈: 자동 · 추가 지정 없음 (auto)
- 허용 인식: 허용 인식 0 미만 (status.latitude.negative)
- 취기: 취기 · 몸을 못 가눔 (status.intoxication.sloppy)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 많이 묻어 있음 (fluid.mouth.3)
- 가슴: 가슴 · 많이 묻어 있음 (fluid.breasts.3)
- 자궁: 자궁 · 가득참 (fluid.uterus.3)
- 보지: 보지 · 애액이 맺힘 (fluid.vulva.2)
- 허벅지: 허벅지 · 없음 (fluid.thighs.0)
- 가슴: 가슴 · 좌측 유두 피어싱 (jewelry.breasts.1)
- 보지: 보지 · 장신구 없음 (jewelry.vulva.0)
- 대화 감지 규칙: 저항을 눌러 버리고 (dialogue-muzyywtf-3)
- 동의·강요 상태: 망설이며 참여 (hesitant)
- 사정 후 체액 흔적: 자동 · 추가 지정 없음 (auto)
- 임신·산후 상태: 임신 상태 없음 (none)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__scene-patron_chatting__outfit-lingerie__room-taproom__exp-0110000__dialogue-lke5x__mood-relieved__studio-1br0gfa__v-0`

**선택 이미지 키**

`ichika__scene-patron_chatting__outfit-lingerie__room-back_room__character-reuse-1hcvgnt__v-1`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\scene-patron_chatting_outfit-lingerie_room-back_room_character-reuse-1hcvgnt_v-1_portrait_1792184876124.webp`

### 25. 가벼운 접촉 1 — 32,000점

통과 후보 71개. 총점 동점 2개 → 항목 우선순위까지 동점 2개 → 2개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | patron_touching | patron_touching |
| 복장 | 6,000 | exact | patched_sundress | patched_sundress |
| 남자 그룹 역할 | 5,000 | exact | 1명 / 없음 | 1명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 3,000 | exact | 0100000 | 0100000 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact | sitting | sitting |
| 기분 | 0 | different | relieved; 감정 없음 | worried; 감정 기록 없음 |
| 나쁜 손님 모드 상태 | 0 | different | blindfolded, hallucinated, handcuffed | 기록 없음 |
| 임신 상태(임신모드) | 0 | different | late | 기록 없음 |
| 세부 상황(모드) | 0 | different | breasts-3, context.consent.forced_join, context.residue.chest, dialogue-dialogue-muzxq0xh-2, jewelry-breasts-2, mouth-1 | 기록 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 마주 앉기 (sitting)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 안대 착용 (badguest.blindfolded)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 20–39 (status.energy.1)
- 기분: 자동 · 추가 지정 없음 (auto)
- 흥분도: 자동 · 추가 지정 없음 (auto)
- 심신 상태: 자동 · 추가 지정 없음 (auto)
- 주목도: 주목도 60 이상 (status.allure.high)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 자동 · 추가 지정 없음 (auto)
- 원망도: 자동 · 추가 지정 없음 (auto)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 취기 · 취함 (status.intoxication.drunk)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 흔적이 남음 (fluid.mouth.1)
- 가슴: 가슴 · 많이 묻어 있음 (fluid.breasts.3)
- 자궁: 자궁 · 넘쳐남 (fluid.uterus.4)
- 보지: 보지 · 애액이 허벅지를 타고 흐름 (fluid.vulva.4)
- 허벅지: 허벅지 · 흔적이 남음 (fluid.thighs.1)
- 가슴: 가슴 · 양쪽 유두 피어싱 (jewelry.breasts.2)
- 보지: 보지 · 클리 피어싱 (jewelry.vulva.1)
- 대화 감지 규칙: 끝내 압박을 떨쳐내지 못하고 마십니다 (dialogue-muzxq0xh-2)
- 동의·강요 상태: 강제 합류 (forced_join)
- 사정 후 체액 흔적: 가슴의 흔적 (chest)
- 임신·산후 상태: 임신 후기 (late)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__scene-patron_touching__outfit-patched_sundress__room-taproom__exp-0100000__dialogue-18i0sjw__position-sitting-r68ijm__mood-relieved__studio-1br0gfa__v-2`

**선택 이미지 키**

`ichika__scene-patron_touching__outfit-patched_sundress__room-taproom__mood-worried__exp-0100000__character-reuse-1hcvgnt__position-sitting-r68ijm__v-3`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\scene-patron_touching_outfit-patched_sundress_room-taproom_mood-worried_exp-0100000_character-reuse-_portrait_1792220510435.webp`

### 26. 가벼운 접촉 2 — 31,000점

통과 후보 15개. 총점 동점 2개 → 항목 우선순위까지 동점 2개 → 1개 구성 묶음 중 선택 묶음의 변형 2개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | patron_touching | patron_touching |
| 복장 | 6,000 | exact | silk_robe | silk_robe |
| 남자 그룹 역할 | 5,000 | exact | 1명 / 없음 | 1명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 2,000 | similar | 0100000 | 0000000 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact | standing | standing |
| 기분 | 0 | different | relieved; 감정 없음 | default; 감정 기록 없음 |
| 나쁜 손님 모드 상태 | 0 | different | blindfolded, hallucinated | 기록 없음 |
| 임신 상태(임신모드) | 0 | different | none | 기록 없음 |
| 세부 상황(모드) | 0 | different | breasts-3, context.consent.hesitant, context.residue.hands, jewelry-breasts-2, mouth-2 | 기록 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 자동 · 추가 지정 없음 (auto)
- 자세 / 체위 · 장면별 적용: 서 있기 (standing)
- 수갑 채움: 자동 · 추가 지정 없음 (auto)
- 안대 착용: 안대 착용 (badguest.blindfolded)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 0–19 (status.energy.0)
- 기분: 자동 · 추가 지정 없음 (auto)
- 흥분도: 흥분도 20–39 (status.arousal.1)
- 심신 상태: 심신 상태 20–39 (status.wellbeing.1)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 신뢰 30 미만 (status.trust.low)
- 애정·욕망: 자동 · 추가 지정 없음 (auto)
- 원망도: 원망도 35–59 (status.resentment.medium)
- 심적 이탈: 심적 이탈 35 이상 (status.drift.high)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 취기 · 몸을 못 가눔 (status.intoxication.sloppy)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 묻어 있음 (fluid.mouth.2)
- 가슴: 가슴 · 많이 묻어 있음 (fluid.breasts.3)
- 자궁: 자궁 · 넘쳐남 (fluid.uterus.4)
- 보지: 보지 · 은은하게 젖음 (fluid.vulva.1)
- 허벅지: 허벅지 · 묻어 있음 (fluid.thighs.2)
- 가슴: 가슴 · 양쪽 유두 피어싱 (jewelry.breasts.2)
- 보지: 보지 · 클리 피어싱 (jewelry.vulva.1)
- 대화 감지 규칙: 자동 · 추가 지정 없음 (auto)
- 동의·강요 상태: 망설이며 참여 (hesitant)
- 사정 후 체액 흔적: 손의 흔적 (hands)
- 임신·산후 상태: 임신 상태 없음 (none)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__scene-patron_touching__outfit-silk_robe__room-taproom__exp-0100000__state-vu5ryx__position-standing-125hyxm__mood-relieved__studio-1br0gfa__v-2`

**선택 이미지 키**

`ichika__scene-patron_touching__outfit-silk_robe__room-taproom__character-reuse-1hcvgnt__position-standing-125hyxm__v-2`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\scene-patron_touching_outfit-silk_robe_room-taproom_character-reuse-1hcvgnt_position-standing-125hyx_portrait_1792216193263.webp`

### 27. 가벼운 접촉 3 — 31,000점

통과 후보 116개. 총점 동점 3개 → 항목 우선순위까지 동점 3개 → 3개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | patron_touching | patron_touching |
| 복장 | 6,000 | exact | satin_babydoll | satin_babydoll |
| 남자 그룹 역할 | 5,000 | exact | 1명 / 없음 | 1명 / 없음 |
| 장소 | 4,000 | similar | taproom | back_room |
| 세부 복장(노출) 상태 | 2,000 | similar | 0001010 | 0101010 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact |  |  |
| 기분 | 0 | different | aroused; 감정 없음 | smile; 감정 기록 없음 |
| 나쁜 손님 모드 상태 | 0 | different | blindfolded, drugged, gagged | 기록 없음 |
| 임신 상태(임신모드) | 0 | different | postpartum | 기록 없음 |
| 세부 상황(모드) | 0 | different | dialogue-dialogue-muzqz0av-1, mouth-4 | 기록 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 기본 프리셋 (default)
- 자세 / 체위 · 장면별 적용: 적용 안함 · 자세 추가 없음 (auto)
- 수갑 채움: 자동 · 추가 지정 없음 (auto)
- 안대 착용: 안대 착용 (badguest.blindfolded)
- 입마개 착용: 입마개 착용 (badguest.gagged)
- 미약 복용: 미약 복용 (badguest.drugged)
- 환각 상태: 자동 · 추가 지정 없음 (auto)
- 기력: 기력 20–39 (status.energy.1)
- 기분: 자동 · 추가 지정 없음 (auto)
- 흥분도: 자동 · 추가 지정 없음 (auto)
- 심신 상태: 심신 상태 0–19 (status.wellbeing.0)
- 주목도: 주목도 60 이상 (status.allure.high)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 자동 · 추가 지정 없음 (auto)
- 원망도: 원망도 35–59 (status.resentment.medium)
- 심적 이탈: 자동 · 추가 지정 없음 (auto)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 자동 · 추가 지정 없음 (auto)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 넘쳐남 (fluid.mouth.4)
- 가슴: 가슴 · 묻어 있음 (fluid.breasts.2)
- 자궁: 자궁 · 없음 (fluid.uterus.0)
- 보지: 자동 · 추가 지정 없음 (auto)
- 허벅지: 자동 · 추가 지정 없음 (auto)
- 가슴: 가슴 · 양쪽 유두 피어싱 (jewelry.breasts.2)
- 보지: 자동 · 추가 지정 없음 (auto)
- 대화 감지 규칙: 잠시 뒤 목덜미와 가슴 안쪽부터 설명하기 어려운 열기가 천천히 번지기 시작합니다 (dialogue-muzqz0av-1)
- 동의·강요 상태: 자동 · 추가 지정 없음 (auto)
- 사정 후 체액 흔적: 자동 · 추가 지정 없음 (auto)
- 임신·산후 상태: 출산 당일·산후 (postpartum)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__scene-patron_touching__outfit-satin_babydoll__room-taproom__exp-0001010__dialogue-zpalpq__mood-aroused__studio-ihk16a__v-2`

**선택 이미지 키**

`ichika__scene-patron_touching__outfit-satin_babydoll__room-back_room__mood-smile__exp-0101010__character-reuse-1hcvgnt__v-0`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\scene-patron_touching_outfit-satin_babydoll_room-back_room_mood-smile_exp-0101010_character-reuse-1h_portrait_1792116241277.webp`

### 28. 가벼운 접촉 4 — 26,500점

통과 후보 6개. 총점 동점 1개 → 항목 우선순위까지 동점 1개 → 1개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | patron_touching | patron_touching |
| 복장 | 6,000 | exact | nude | nude |
| 남자 그룹 역할 | 5,000 | exact | 1명 / 없음 | 1명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 0 | similar | 0101100 | 0000000 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 0 | different | back-hug | close-embrace |
| 기분 | 0 | different | worried; 감정 없음 | default; 감정 없음 |
| 나쁜 손님 모드 상태 | 0 | different | blindfolded | 없음 |
| 임신 상태(임신모드) | 500 | exact | none | none |
| 세부 상황(모드) | 0 | different | context.consent.voluntary, dialogue-dialogue-muzxq0xh-2, jewelry-breasts-1, mouth-3, thighs-2, uterus-2, vulva-3 | 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 기본 프리셋 (default)
- 자세 / 체위 · 장면별 적용: 백허그 (back-hug)
- 수갑 채움: 자동 · 추가 지정 없음 (auto)
- 안대 착용: 안대 착용 (badguest.blindfolded)
- 입마개 착용: 자동 · 추가 지정 없음 (auto)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 자동 · 추가 지정 없음 (auto)
- 기력: 기력 20–39 (status.energy.1)
- 기분: 기분 0–19 (status.mood.0)
- 흥분도: 흥분도 20–39 (status.arousal.1)
- 심신 상태: 심신 상태 80–100 (status.wellbeing.4)
- 주목도: 주목도 60 이상 (status.allure.high)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 원망도 35–59 (status.resentment.medium)
- 심적 이탈: 자동 · 추가 지정 없음 (auto)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 취기 · 의식 없음 (status.intoxication.blacked_out)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 많이 묻어 있음 (fluid.mouth.3)
- 가슴: 자동 · 추가 지정 없음 (auto)
- 자궁: 자궁 · 자궁 내 일부 (fluid.uterus.2)
- 보지: 보지 · 허벅지 안쪽까지 흐름 (fluid.vulva.3)
- 허벅지: 허벅지 · 묻어 있음 (fluid.thighs.2)
- 가슴: 가슴 · 좌측 유두 피어싱 (jewelry.breasts.1)
- 보지: 보지 · 장신구 없음 (jewelry.vulva.0)
- 대화 감지 규칙: 끝내 압박을 떨쳐내지 못하고 마십니다 (dialogue-muzxq0xh-2)
- 동의·강요 상태: 자발적 참여 (voluntary)
- 사정 후 체액 흔적: 흔적 없음 (none)
- 임신·산후 상태: 자동 · 추가 지정 없음 (auto)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__scene-patron_touching__outfit-nude__room-taproom__mood-worried__exp-0101100__dialogue-42k1j7__position-back-hug-1yr9jp5__v-3`

**선택 이미지 키**

`ichika__scene-patron_touching__outfit-nude__room-taproom__character-reuse-yo0w6i__position-close-embrace-f08y0h__v-3`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\scene-patron_touching_outfit-nude_room-taproom_character-reuse-yo0w6i_position-close-embrace-f08y0h__portrait_1792263004013.webp`

### 29. 가벼운 접촉 5 — 30,000점

통과 후보 116개. 총점 동점 1개 → 항목 우선순위까지 동점 1개 → 1개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | patron_touching | patron_touching |
| 복장 | 6,000 | exact | lingerie | lingerie |
| 남자 그룹 역할 | 5,000 | exact | 1명 / 없음 | 1명 / 없음 |
| 장소 | 4,000 | similar | taproom | back_room |
| 세부 복장(노출) 상태 | 1,000 | similar | 0001101 | 0000001 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact | standing | standing |
| 기분 | 0 | different | aroused; 감정 없음 | shy; 감정 기록 없음 |
| 나쁜 손님 모드 상태 | 0 | different | gagged, hallucinated | 기록 없음 |
| 임신 상태(임신모드) | 0 | different | none | 기록 없음 |
| 세부 상황(모드) | 0 | different | context.consent.coerced, jewelry-vulva-1, mouth-2, vulva-4 | 기록 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 기본 프리셋 (default)
- 자세 / 체위 · 장면별 적용: 서 있기 (standing)
- 수갑 채움: 자동 · 추가 지정 없음 (auto)
- 안대 착용: 자동 · 추가 지정 없음 (auto)
- 입마개 착용: 입마개 착용 (badguest.gagged)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 0–19 (status.energy.0)
- 기분: 기분 20–39 (status.mood.1)
- 흥분도: 흥분도 0–19 (status.arousal.0)
- 심신 상태: 심신 상태 60–79 (status.wellbeing.3)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 원망도 35–59 (status.resentment.medium)
- 심적 이탈: 자동 · 추가 지정 없음 (auto)
- 허용 인식: 허용 인식 0 미만 (status.latitude.negative)
- 취기: 취기 · 만취 (status.intoxication.wasted)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 묻어 있음 (fluid.mouth.2)
- 가슴: 가슴 · 넘쳐남 (fluid.breasts.4)
- 자궁: 자궁 · 없음 (fluid.uterus.0)
- 보지: 보지 · 애액이 허벅지를 타고 흐름 (fluid.vulva.4)
- 허벅지: 자동 · 추가 지정 없음 (auto)
- 가슴: 가슴 · 좌측 유두 피어싱 (jewelry.breasts.1)
- 보지: 보지 · 클리 피어싱 (jewelry.vulva.1)
- 대화 감지 규칙: 자동 · 추가 지정 없음 (auto)
- 동의·강요 상태: 거절 뒤 강요 (coerced)
- 사정 후 체액 흔적: 자동 · 추가 지정 없음 (auto)
- 임신·산후 상태: 임신 상태 없음 (none)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__scene-patron_touching__outfit-lingerie__room-taproom__exp-0001101__state-zterq8__position-standing-125hyxm__mood-aroused__studio-ihk16a__v-0`

**선택 이미지 키**

`ichika__scene-patron_touching__outfit-lingerie__room-back_room__mood-shy__exp-0000001__character-reuse-1hcvgnt__position-standing-125hyxm__v-3`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\scene-patron_touching_outfit-lingerie_room-back_room_mood-shy_exp-0000001_character-reuse-1hcvgnt_po_portrait_1792223874265.webp`

### 30. 가벼운 접촉 6 — 30,000점

통과 후보 52개. 총점 동점 1개 → 항목 우선순위까지 동점 1개 → 1개 구성 묶음 중 선택 묶음의 변형 1개.

| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |
|---|---:|---|---|---|
| 장면 | 10,000 | exact | patron_touching | patron_touching |
| 복장 | 6,000 | exact | wench_bodice | wench_bodice |
| 남자 그룹 역할 | 5,000 | exact | 1명 / 없음 | 1명 / 없음 |
| 장소 | 4,000 | exact | taproom | taproom |
| 세부 복장(노출) 상태 | 1,000 | similar | 0101010 | 0100000 |
| 흔적 | 1,000 | exact |  |  |
| 세부 자세(모드) | 3,000 | exact | back-hug | back-hug |
| 기분 | 0 | different | relieved; 감정 없음 | default; 감정 기록 없음 |
| 나쁜 손님 모드 상태 | 0 | different | blindfolded, gagged, hallucinated, handcuffed | 기록 없음 |
| 임신 상태(임신모드) | 0 | different | middle | 기록 없음 |
| 세부 상황(모드) | 0 | different | context.consent.hallucinated, dialogue-dialogue-muzyywtf-3, jewelry-breasts-2, mouth-4, thighs-2 | 기록 없음 |

**편집기에서 무작위로 선택한 값**

- 상황 프리셋: 기본 프리셋 (default)
- 자세 / 체위 · 장면별 적용: 백허그 (back-hug)
- 수갑 채움: 수갑 채움 (badguest.handcuffed)
- 안대 착용: 안대 착용 (badguest.blindfolded)
- 입마개 착용: 입마개 착용 (badguest.gagged)
- 미약 복용: 자동 · 추가 지정 없음 (auto)
- 환각 상태: 환각 상태 (badguest.hallucinated)
- 기력: 기력 20–39 (status.energy.1)
- 기분: 기분 80–100 (status.mood.4)
- 흥분도: 흥분도 40–59 (status.arousal.2)
- 심신 상태: 심신 상태 0–19 (status.wellbeing.0)
- 주목도: 자동 · 추가 지정 없음 (auto)
- 신뢰: 자동 · 추가 지정 없음 (auto)
- 애정·욕망: 애정·욕망 60 이상 (status.desire.high)
- 원망도: 원망도 60 이상 (status.resentment.high)
- 심적 이탈: 자동 · 추가 지정 없음 (auto)
- 허용 인식: 자동 · 추가 지정 없음 (auto)
- 취기: 자동 · 추가 지정 없음 (auto)
- 강한 감정 매핑: 자동 · 추가 지정 없음 (auto)
- 가장 강한 욕구 매핑: 자동 · 추가 지정 없음 (auto)
- 입: 입 · 넘쳐남 (fluid.mouth.4)
- 가슴: 자동 · 추가 지정 없음 (auto)
- 자궁: 자궁 · 없음 (fluid.uterus.0)
- 보지: 자동 · 추가 지정 없음 (auto)
- 허벅지: 허벅지 · 묻어 있음 (fluid.thighs.2)
- 가슴: 가슴 · 양쪽 유두 피어싱 (jewelry.breasts.2)
- 보지: 보지 · 장신구 없음 (jewelry.vulva.0)
- 대화 감지 규칙: 저항을 눌러 버리고 (dialogue-muzyywtf-3)
- 동의·강요 상태: 환각 상태 (hallucinated)
- 사정 후 체액 흔적: 흔적 없음 (none)
- 임신·산후 상태: 임신 중기 (middle)
- 출산·아이 처치 장면: 별도 사건 없음 (none)
- 맘껏 보여주기 행동: 추가하지 않음 · 플레이 중에는 현재 장면 (auto)
- 보여주기 자신감: 보통 (auto)
- 보여주기 그림 변형: 기본 변형 (auto)

**요청 키**

`ichika__scene-patron_touching__outfit-wench_bodice__room-taproom__exp-0101010__dialogue-1vsc0ca__position-back-hug-1yr9jp5__mood-relieved__studio-1br0gfa__v-2`

**선택 이미지 키**

`ichika__scene-patron_touching__outfit-wench_bodice__room-taproom__exp-0100000__character-reuse-1hcvgnt__position-back-hug-1yr9jp5__v-3`

**실제 파일 경로**

`C:\Users\user\Documents\wayward\images\illustrious\characters\ichika\scene-patron_touching_outfit-wench_bodice_room-taproom_exp-0100000_character-reuse-1hcvgnt_position-_portrait_1792229538639.webp`

## 설정과 재현

필수 조건: 장면·의상·장소. 유사 조건 허용. 홀과 뒷방은 기본 설정에서 유사 장소이며 둘 다 4,000점입니다.
그 때문에 홀 요청에 뒷방 이미지가 선택될 수 있습니다. 이 결과를 홀 이미지로 다시 제한하거나 점수를 보정하지 않았습니다.

입력과 추첨 코드는 inputs-v1.json, 계산 결과는 results-v1.json에 있습니다.
재계산: `node wml/mods/imagestudio/reports/ichika-matching-20261022/calculate-v1.mjs`

추가 검증: 실제 게임 브라우저의 매칭 엔진에서도 30건 모두 선택 이미지 키·총점·항목별 점수·변형 수가 일치했습니다. 페이지 오류는 0건이며, 선택된 이미지 30개는 모두 서로 다른 파일입니다.
