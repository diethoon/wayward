// 실행: node wml/mods/imagestudio/reports/ichika-matching-20261022/calculate-v1.mjs
// seed 1138. 기록된 요청과 실제 팩을 비교하며 게임 코드·설정·이미지는 변경하지 않습니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const gameRoot = new URL('../../../../../', import.meta.url);
const inputFile = new URL('./inputs-v1.json', import.meta.url);
const resultFile = new URL('./results-v1.json', import.meta.url);
const reportFile = new URL('./report-v1.md', import.meta.url);
const packFiles = ['images-ichika-1.js'];
const input = JSON.parse(fs.readFileSync(inputFile, 'utf8'));
const matcherFile = new URL('wml/mods/imagestudio/source/image-matching.js', gameRoot);
const positionFile = new URL('wml/mods/imagestudio/source/matching-positions.js', gameRoot);
let randomState = 1138;

function IchikaAudit_무작위수읽기() {
  randomState = (Math.imul(1664525, randomState) + 1013904223) >>> 0;
  return randomState / 4294967296;
}

function IchikaAudit_해시읽기(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

// 현재 게임에 들어 있는 순수 매칭 엔진과 자세 적합성 규칙을 그대로 사용합니다.
const context = {};
vm.createContext(context);
vm.runInContext(fs.readFileSync(positionFile, 'utf8') + '\n' + fs.readFileSync(matcherFile, 'utf8') +
  '\nglobalThis.matcher=ImageStudio_매칭엔진만들기(ImageStudio_자세상황에맞는가);', context);
const matcher = context.matcher;
assert.equal(input.rows.length, 30);
const config = matcher.normalize(input.config);
const dimensions = matcher.dimensions.map(([id, label]) => ({ id, label }));

// 팩 우선순위를 보존하고 실제 파일이 있는 정지 이미지만 후보로 남깁니다.
const packs = [];
for (const file of packFiles) {
  const sandbox = { window: {} };
  vm.runInNewContext(fs.readFileSync(new URL(file, gameRoot), 'utf8'), sandbox);
  packs.push(...sandbox.window.__WAYWARD_IMAGE_PACKS__);
}
packs.sort((a, b) => (b.priority || 0) - (a.priority || 0) ||
  String(b.generatedAt || '').localeCompare(String(a.generatedAt || '')));
const unique = new Map();
let rawCount = 0, missingFiles = 0, invalidRows = 0;
for (const pack of packs) {
  for (const entry of Object.values(pack.entries || {})) {
    rawCount += 1;
    if (!entry?.talentName?.startsWith('ichika__') || !entry.imagePath || /\.(mp4|webm)$/i.test(entry.imagePath)) {
      invalidRows += 1; continue;
    }
    if (!fs.existsSync(new URL('images/' + entry.imagePath, gameRoot))) {
      missingFiles += 1; continue;
    }
    if (!unique.has(entry.talentName)) unique.set(entry.talentName, entry);
  }
}
const entries = [...unique.values()];
const descriptors = entries.map(entry => ({
  entry, spec: matcher.describe(entry.talentName, entry.matching || entry.debug?.imageMatching || {})
}));
const family = key => key.replace(/__v-\d+(?=__|$)/g, '');
const compare = (a, b) => {
  if (a.score.total !== b.score.total) return b.score.total - a.score.total;
  for (const id of config.order) {
    if (a.score.points[id] !== b.score.points[id]) return b.score.points[id] - a.score.points[id];
  }
  return 0;
};

// 각 요청을 팩 전체와 대조하고 동점 및 우선순위까지 계산합니다.
const rows = [];
for (const request of input.rows) {
  const spec = matcher.describe(request.key, request.metadata);
  const valid = [];
  for (const item of descriptors) {
    const score = matcher.score(spec, item.spec, config);
    if (score) valid.push({ ...item, score });
  }
  valid.sort(compare);
  const chosen = matcher.choose(spec, entries, config, () => null, IchikaAudit_무작위수읽기);
  assert.ok(chosen, 'No image for request ' + request.id);
  assert.equal(chosen.score.total, valid[0].score.total);
  assert.equal(compare(chosen, valid[0]), 0);
  assert.equal(Object.values(chosen.score.points).reduce((sum, value) => sum + value, 0), chosen.score.total);
  assert.ok(fs.existsSync(new URL('images/' + chosen.entry.imagePath, gameRoot)));
  const totalTies = valid.filter(item => item.score.total === chosen.score.total);
  const rankTies = valid.filter(item => compare(item, chosen) === 0);
  const selected = {
    key: chosen.entry.talentName, imagePath: chosen.entry.imagePath,
    metadata: chosen.entry.matching || chosen.entry.debug?.imageMatching || null,
    spec: chosen.spec, score: chosen.score,
    variantCount: chosen.variantCount,
    selectedFamilyCount: rankTies.filter(item => family(item.entry.talentName) === family(chosen.entry.talentName)).length
  };
  assert.equal(selected.variantCount, selected.selectedFamilyCount);
  rows.push({
    id: request.id, scene: request.scene, label: request.label, sample: request.sample,
    request: spec, metadata: request.metadata, selection: request.selection,
    selected, candidateCount: valid.length, excludedCount: entries.length - valid.length,
    totalTieCount: totalTies.length, priorityTieCount: rankTies.length,
    tiedFamilies: new Set(rankTies.map(item => family(item.entry.talentName))).size
  });
}

const summary = input.scenes.map(([scene, label]) => {
  const selected = rows.filter(row => row.scene === scene);
  return { scene, label, scores: selected.map(row => row.selected.score.total),
    mean: selected.reduce((sum, row) => sum + row.selected.score.total, 0) / selected.length,
    backRoomSelections: selected.filter(row => row.selected.spec.room === 'back_room').length };
});
const result = {
  date: '2026-10-22', character: 'ichika', seed: input.seed,
  source: 'actual image packs; current pure matching engine; default configuration; existing files only',
  hashes: { matcher: IchikaAudit_해시읽기(matcherFile), positions: IchikaAudit_해시읽기(positionFile),
    inputs: IchikaAudit_해시읽기(inputFile), packs: Object.fromEntries(packFiles.map(file => [file, IchikaAudit_해시읽기(new URL(file, gameRoot))])) },
  counts: { raw: rawCount, candidates: entries.length, missingFiles, invalidRows,
    metadataPresent: entries.filter(entry => entry.matching || entry.debug?.imageMatching).length,
    backRoomSelections: rows.filter(row => row.selected.spec.room === 'back_room').length },
  config: input.config, dimensions, summary, rows
};
fs.writeFileSync(resultFile, JSON.stringify(result, null, 2) + '\n');

// 표에는 총점과 실제 선택 결과를, 아래 상세에는 11개 항목의 계산을 남깁니다.
const fmt = value => value.toLocaleString('ko-KR', { maximumFractionDigits: 2 });
const valueLabel = (axis, value) => input.baseAxes[axis]?.find(item => item.value === value)?.label || value || '없음';
const roomLabel = value => ({ taproom: '홀', back_room: '뒷방' }[value] || value);
const list = value => value === null || value === undefined ? '기록 없음' : Array.isArray(value) ? value.join(', ') || '없음' : String(value);
const lines = [
  '# 이치카 이미지팩 매칭 점수 30건', '',
  '계산일: 2026-10-22 · seed 1138 · 각 상황별 6건 · 실제 팩 전체에서 최상위 이미지 선택', '',
  ...input.notes.map(note => '- ' + note),
  '- 메뉴 질문은 `taking_order`(주문 받기), 대화는 `patron_chatting`, 가벼운 접촉은 `patron_touching`으로 해석했습니다.',
  '- 이치카 JS 팩만 비교합니다. 이미지 서버의 별도 캐시와 H_Status 전용 팩은 포함하지 않았습니다.',
  '- 변형 선택은 별도의 seed 1138 난수열을 사용했습니다. 게임 실행 중의 실제 난수 결과와는 달라질 수 있습니다.',
  '- 동일 요청 재사용 시간(30초)은 이번 독립 점수 실험에 적용하지 않았습니다.', '',
  `팩 항목 ${fmt(rawCount)}개 → 실제 파일이 있는 중복 제거 후보 ${fmt(entries.length)}개. 파일 누락 ${fmt(missingFiles)}개, 기타 제외 ${fmt(invalidRows)}개.`,
  `추가 상태 메타데이터가 있는 후보: ${fmt(result.counts.metadataPresent)}개.`, '',
  '## 30개 점수', '',
  '| 상황 | 1 | 2 | 3 | 4 | 5 | 6 | 평균 |',
  '|---|---:|---:|---:|---:|---:|---:|---:|'
];
for (const row of summary) lines.push(`| ${row.label} | ${row.scores.map(fmt).join(' | ')} | ${fmt(row.mean)} |`);
lines.push('', '## 무작위 요청과 실제 선택 이미지', '',
  '| 번호 | 상황 | 요청 의상 → 선택 의상 | 요청 표정 → 선택 표정 | 요청 노출 → 선택 노출 | 선택 장소 | 총점 |',
  '|---:|---|---|---|---|---|---:|');
for (const row of rows) {
  const a = row.request, b = row.selected.spec;
  lines.push(`| ${row.id} | ${row.label} ${row.sample} | ${valueLabel('outfit', a.outfit)} → ${valueLabel('outfit', b.outfit)} | ${valueLabel('mood', a.mood)} → ${valueLabel('mood', b.mood)} | ${a.exposure} → ${b.exposure} | ${roomLabel(b.room)} | ${fmt(row.selected.score.total)} |`);
}
lines.push('', '## 항목별 점수와 추가 상태', '',
  '노출 숫자는 상의 끈 풀림·상의 내려감·상의 벗음·치마 올라감·치마 벗음·속옷 옆으로·속옷 벗음의 7개 비트입니다.',
  '0점은 동일 상태라고 확인됐다는 뜻이 아닙니다. 이미지에 정보가 없거나 상태가 다르면 해당 규칙에 따라 0점일 수 있습니다.', '');
for (const row of rows) {
  const a = row.request, b = row.selected.spec;
  lines.push(`### ${String(row.id).padStart(2, '0')}. ${row.label} ${row.sample} — ${fmt(row.selected.score.total)}점`, '',
    `통과 후보 ${fmt(row.candidateCount)}개. 총점 동점 ${fmt(row.totalTieCount)}개 → 항목 우선순위까지 동점 ${fmt(row.priorityTieCount)}개 → ${row.tiedFamilies}개 구성 묶음 중 선택 묶음의 변형 ${row.selected.variantCount}개.`, '',
    '| 점수 항목 | 점수 | 판정 | 요청 | 선택 이미지 |', '|---|---:|---|---|---|');
  for (const { id, label } of dimensions) {
    const requestValue = id === 'group' ? `${a.men}명 / ${a.groupSlots || '없음'}` : id === 'mood' ? `${a.mood}; 감정 ${list(a.emotions)}` : a[id];
    const candidateValue = id === 'group' ? `${b.men}명 / ${b.groupSlots || '없음'}` : id === 'mood' ? `${b.mood}; 감정 ${list(b.emotions)}` : b[id];
    lines.push(`| ${label} | ${fmt(row.selected.score.points[id])} | ${row.selected.score.matches[id]} | ${list(requestValue)} | ${list(candidateValue)} |`);
  }
  lines.push('', '**편집기에서 무작위로 선택한 값**', '');
  for (const axis of input.editorAxes) {
    const value = row.selection[axis.id];
    const item = axis.items.find(item => item.value === value);
    lines.push(`- ${axis.label}: ${item?.label || value} (${value})`);
  }
  lines.push('', '**요청 키**', '', '`' + input.rows.find(item => item.id === row.id).key + '`', '',
    '**선택 이미지 키**', '', '`' + row.selected.key + '`', '',
    '**실제 파일 경로**', '', '`' + fileURLToPath(new URL('images/' + row.selected.imagePath, gameRoot)) + '`', '');
}
lines.push('## 설정과 재현', '',
  '필수 조건: 장면·의상·장소. 유사 조건 허용. 홀과 뒷방은 기본 설정에서 유사 장소이며 둘 다 4,000점입니다.',
  '그 때문에 홀 요청에 뒷방 이미지가 선택될 수 있습니다. 이 결과를 홀 이미지로 다시 제한하거나 점수를 보정하지 않았습니다.', '',
  '입력과 추첨 코드는 inputs-v1.json, 계산 결과는 results-v1.json에 있습니다.',
  '재계산: `node wml/mods/imagestudio/reports/ichika-matching-20261022/calculate-v1.mjs`', '');
fs.writeFileSync(reportFile, lines.join('\n'));
console.log(JSON.stringify({ counts: result.counts, summary, selected: rows.map(row => ({
  id: row.id, total: row.selected.score.total, outfit: row.request.outfit, mood: row.request.mood,
  exposure: row.request.exposure, room: row.selected.spec.room, points: row.selected.score.points,
  variants: row.selected.variantCount
})) }, null, 2));
