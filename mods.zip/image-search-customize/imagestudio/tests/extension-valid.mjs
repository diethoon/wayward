import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

test('prompt providers can exclude invalid conditional combinations',()=>{
  const hooks={};
  const context={globalThis:null,ImageStudio_노출키정규화하기:value=>value,
    ImageStudio_자세상황에맞는가:()=>true,ImageStudio_기본매칭맥락읽기:()=>null,
    console};context.globalThis=context;
  vm.runInNewContext(fs.readFileSync(new URL('../source/extensions.js',import.meta.url),'utf8'),context);
  const api={store:{game:()=>({})},hook:(name,value)=>{hooks[name]=value;},fn:()=>()=>[]};
  const extensions=context.ImageStudio_확장등록창구만들기(api);
  extensions.registerEditor({id:'test',render(){},planningContext:()=>({state:{}}),combinationSpace:()=>({count:1n,at:()=>({})}),plan:build=>build()});
  extensions.registerPromptProvider({id:'filter',compose:value=>value,valid:ctx=>ctx.selection.allowed===true});
  assert.equal(context.WW_ImageStudioPrompt.plan(()=>[{talentId:'base'}],{allowed:false}).length,0);
  assert.equal(context.WW_ImageStudioPrompt.plan(()=>[{talentId:'base'}],{allowed:true})[0].talentId,'base');
});
