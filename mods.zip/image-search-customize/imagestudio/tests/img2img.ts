// 실행: bun wml/mods/imagestudio/tests/img2img.ts
// 모의 ComfyUI에 실제 서버 요청을 보내 참조 전송·VAE 연결·캐시 격리와 오류를 확인합니다. GPU는 사용하지 않습니다.
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { resolveConfig } from '../backend/wayward-imagegen/src/config.ts'
import { startServer } from '../backend/wayward-imagegen/src/server.ts'

const testDirectory = path.resolve(import.meta.dir)
const temporary = fs.mkdtempSync(path.join(testDirectory, '.img2img-'))
const graphs: any[] = [], uploads: string[] = []
const mock = Bun.serve({ port: 0, async fetch(request) {
  const route = new URL(request.url).pathname
  if (route === '/upload/image') {
    const form = await request.formData(), file = form.get('image') as File
    uploads.push(file.name)
    return Response.json({ name: file.name })
  }
  if (route === '/prompt') {
    graphs.push((await request.json()).prompt)
    return Response.json({ prompt_id: 'mock-' + graphs.length })
  }
  if (route === '/queue') return Response.json({ queue_running: [], queue_pending: [] })
  return Response.json({})
} })
const config = resolveConfig([], temporary)
Object.assign(config, { host: '127.0.0.1', port: 0, comfyUrl: mock.url.origin, imagesDir: path.join(temporary,'images'),
  stateDir: path.join(temporary,'state'), imageProvider:'illustrious',maxDiskGb:0,maxImagesPerHour:0,sdxlWidth:1024,sdxlHeight:1024 })
let server: Awaited<ReturnType<typeof startServer>> | undefined
try {
  fs.mkdirSync(config.imagesDir,{recursive:true})
  const reference=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9ZlmsAAAAASUVORK5CYII=','base64')
  fs.writeFileSync(path.join(config.imagesDir,'reference.png'),reference)
  server=await startServer(config)
  server.cache.add({talentName:'situation_fluid__elena__mouth__0',imageType:'portrait',promptHash:'ref',
    imagePath:'reference.png',prompt:'reference',workflow:'illustrious'})
  const url='http://127.0.0.1:'+server.port
  const generate=async(patch:Record<string,unknown>={})=>{
    const response=await fetch(url+'/api/image/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
      talentId:'situation_fluid__elena__mouth__1',prompt:'test',negativePrompt:'blur',referenceKey:'situation_fluid__elena__mouth__0',
      denoise:0.28,reviewOnly:true,seed:1138,...patch})})
    return {status:response.status,body:await response.json()}
  }
  const first=await generate();assert.equal(first.status,200,JSON.stringify(first))
  assert.equal(graphs.length,1);assert.equal(uploads.length,1)
  assert.equal(graphs[0].wwis_reference_load.class_type,'LoadImage')
  assert.equal(graphs[0].wwis_reference_encode.class_type,'VAEEncode')
  assert.deepEqual(graphs[0].wwis_reference_encode.inputs.pixels,['wwis_reference_scale',0])
  assert.equal(graphs[0].wwis_reference_scale.inputs.width,1024)
  assert.deepEqual(graphs[0]['1536'].inputs.latent_image,['wwis_reference_encode',0])
  assert.equal(graphs[0]['1536'].inputs.denoise,0.28)
  assert.deepEqual(graphs[0].wwis_reference_encode.inputs.vae,graphs[0]['1291'].inputs.vae)
  assert.deepEqual(fs.readFileSync(path.join(config.imagesDir,'reference.png')),reference)
  const same=await generate();assert.equal(same.body.promptId,first.body.promptId)
  const changed=await generate({denoise:0.4});assert.notEqual(changed.body.promptId,first.body.promptId)
  assert.equal((await generate({referenceKey:'missing'})).status,404)
  assert.equal((await generate({denoise:1.5})).status,400)
  assert.equal((await generate({referenceKey:'../reference.png'})).status,404)
  assert.equal((await generate({referenceKey:'missing',referencePath:'../reference.png'})).status,400)
  const packOnly=await generate({referenceKey:'original-pack-key',referencePath:'reference.png',talentId:'pack-only-target'})
  assert.equal(packOnly.status,200,'캐시가 없는 이미지팩도 참조할 수 있습니다.')
  config.imageProvider='anima'
  const anima=await generate({talentId:'situation_fluid__elena__mouth__2'})
  assert.equal(anima.status,200,JSON.stringify(anima))
  const graph=graphs.at(-1)
  assert.deepEqual(graph['97'].inputs.latent_image,['wwis_reference_encode',0])
  assert.deepEqual(graph.wwis_reference_encode.inputs.vae,['93',0])
  assert.equal(graph['97'].inputs.denoise,0.28)
  const beforeBatch=graphs.length
  const enqueue=await fetch(url+'/api/batch/enqueue',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
    items:[{talentId:'situation_fluid__elena__mouth__batch',prompt:'batch',referenceKey:'situation_fluid__elena__mouth__0',denoise:0.4}],start:true})})
  assert.equal(enqueue.status,200,await enqueue.text())
  for(let index=0;index<100&&graphs.length===beforeBatch;index++)await new Promise(resolve=>setTimeout(resolve,10))
  assert.equal(graphs.length,beforeBatch+1,JSON.stringify(server.batch.status()))
  assert.equal(graphs.at(-1)['97'].inputs.denoise,0.4)
  assert.deepEqual(graphs.at(-1)['97'].inputs.latent_image,['wwis_reference_encode',0])
  server.batch.clear()
  const drafts=await(await fetch(url+'/api/studio/drafts')).json()
  assert.equal(drafts.supportsImg2img,true)
  assert.equal(Object.values(server.cache.entries).length,1,'승인 전 생성 결과는 캐시에 저장하지 않습니다.')
  console.log('PASS SDXL / Anima img2img: upload, VAE, denoise, dedup, pack references, validation, review-only cache, persistent batch')
} finally {
  await server?.close();mock.stop(true)
  assert.ok(temporary.startsWith(testDirectory+path.sep));fs.rmSync(temporary,{recursive:true,force:true})
}
