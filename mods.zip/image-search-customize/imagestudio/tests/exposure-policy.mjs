// 실행: node wml/mods/imagestudio/tests/exposure-policy.mjs [--mobile]
// seed=1138. 36×36 필수 통과 행렬, 자리별 점수, 확률, 구설정 보존과 실제 설정 화면을 검사합니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {playStart,playEval,playReload,playStatus,shutdown} from '../../../../MCP/lib/play.mjs';

const source=fs.readFileSync(new URL('../source/image-matching.js',import.meta.url),'utf8');
const matcher=vm.runInNewContext(source+'\nImageStudio_매칭엔진만들기();');
const config=matcher.defaults();
const base='elena__task-idle__outfit-modest__room-taproom';
const codes=[];
for(const top of ['000','100','010','011'])for(const skirt of ['00','10','11'])for(const panties of ['00','10','01'])codes.push(top+skirt+panties);
const pairs=[[1,2],[2,3],[4,5],[10,11],[11,12],[13,14],[19,20],[20,21],[22,23],[28,29],[29,30],[31,32]];
const spec=code=>matcher.describe(base+'__exp-'+code+'__v-0');
assert.equal(config.version,2);assert.equal(config.rules.exposure.required,true);
assert.equal(config.rules.exposure.allowSimilar,true);
assert.deepEqual(JSON.parse(JSON.stringify(matcher.exposureStates.map(row=>row.value))),codes);
assert.deepEqual(JSON.parse(JSON.stringify(config.rules.exposure.groups)),pairs.map(pair=>pair.map(number=>codes[number-1])));
let allowed=0;
for(let a=1;a<=36;a++)for(let b=1;b<=36;b++){
  const expected=a===b||pairs.some(pair=>pair.includes(a)&&pair.includes(b));
  const score=matcher.score(spec(codes[a-1]),spec(codes[b-1]),config);
  assert.equal(!!score,expected,'state '+a+' -> '+b);
  if(score){allowed++;assert.equal(score.matches.exposure,a===b?'exact':'similar');}
}
assert.equal(allowed,60);
for(const [a,b] of [[1,3],[10,12],[19,21],[28,30],[4,6],[28,31]])assert.equal(matcher.score(spec(codes[a-1]),spec(codes[b-1]),config),null);
const strict=structuredClone(config);strict.rules.exposure.allowSimilar=false;
assert.equal(matcher.score(spec(codes[0]),spec(codes[1]),strict),null);
const finished=spec(codes[0]);finished.finish='nude';
assert.equal(matcher.score(spec(codes[0]),finished,config),null);
console.log('PASS 1296 exposure pairs: 36 exact + 24 directed similar / no transitive pairs / no omitted pairs / strict fin');

// 일치·불일치 항목을 대입한 기대값으로 각 자리와 총점을 확인합니다. 0=0도 가산합니다.
const pointCases=[
 ['0000000','0000000',1200,1200,800,3200],
 ['0000000','1000000',1000,1200,800,3000],
 ['0000000','0100000',-300,1200,800,1700],
 ['0100000','0110000',-300,1200,800,1700],
 ['0000000','0001000',1200,-600,800,1400],
 ['0001000','0001100',1200,-600,800,1400],
 ['0000000','0000010',1200,1200,-400,2000],
 ['0000000','0000001',1200,1200,-400,2000],
 ['0000010','0000001',1200,1200,-1600,800],
 ['0000000','0111101',-1800,-2400,-400,-4600],
];
for(const [a,b,top,skirt,panties,total] of pointCases){
 const points=matcher.ImageStudio_노출점수읽기(a,b,config.rules.exposure);
 assert.deepEqual([points.top,points.skirt,points.panties,points.total],[top,skirt,panties,total]);
}
const exact={talentName:base+'__v-0',imagePath:'exact.png'};
const near={talentName:base+'__exp-0000010__v-0',imagePath:'near.png'};
const no={talentName:base+'__exp-0111101__v-0',imagePath:'not-allowed.png'};
const first=matcher.choose(spec(codes[0]),[near,exact,no],config,()=>null,()=>0);
const last=matcher.choose(spec(codes[0]),[near,exact,no],config,()=>null,()=>0.999);
assert.equal(first.entry,near);assert.equal(first.familyWeight,1);assert.equal(last.entry,exact);assert.equal(last.familyWeight,1.5);
assert.equal(first.score.points.exposure,2000);assert.equal(last.score.points.exposure,3200);
assert.equal(first.familyOptionalScore,last.familyOptionalScore);
assert.equal(last.familyLotteryScore-first.familyLotteryScore,1200);
assert.equal(matcher.choose(spec(codes[0]),[exact,no],config,()=>null,()=>0,{recent:['exact.png']}).entry,exact);
assert.equal(matcher.ImageStudio_정확이미지고르기(spec(codes[0]),[near],config),null);
assert.equal(matcher.score(spec('0110000'),spec('0010000'),config).points.exposure,3200);
console.log('PASS 7-bit rewards and penalties / 3200, 2000, 800 examples / required exposure affects capped lottery / exact generation unchanged / recent fallback stays required');

const legacy=JSON.parse(JSON.stringify(config));legacy.version=1;
legacy.rules.exposure={required:false,allowSimilar:true,exact:3000,similar:3000,differencePenalty:1000,groups:[]};
legacy.rules.room.exact=4321;legacy.rules.mood.emotionBonus=1138;legacy.order.reverse();
const original=JSON.stringify(legacy),migrated=matcher.normalize(legacy);
assert.equal(JSON.stringify(legacy),original);assert.equal(migrated.version,2);
assert.deepEqual(JSON.parse(JSON.stringify(migrated.rules.exposure)),JSON.parse(JSON.stringify(config.rules.exposure)));
for(const id of Object.keys(config.rules).filter(id=>id!=='exposure'))assert.deepEqual(JSON.parse(JSON.stringify(migrated.rules[id])),legacy.rules[id]);
assert.deepEqual(JSON.parse(JSON.stringify(migrated.order)),legacy.order);
const custom=JSON.parse(JSON.stringify(migrated));custom.rules.exposure.required=false;
custom.rules.exposure.bitScores.bodiceUnlaced.match=300;custom.rules.exposure.groups=[['0000000','0000010']];
assert.equal(matcher.normalize(custom).rules.exposure.required,false);
assert.equal(matcher.normalize(custom).rules.exposure.bitScores.bodiceUnlaced.match,300);
const invalid=structuredClone(custom);invalid.rules.exposure.bitScores.topRemoved.mismatch=1;
assert.throws(()=>matcher.normalize(invalid),/노출 비트별 점수/);
assert.equal(matcher.normalize({...custom,rules:{...custom.rules,exposure:{...custom.rules.exposure,groups:[['none','0000010']]}}}).rules.exposure.groups[0][0],'0000000');
console.log('PASS v1 -> v2 migration preserves other settings / v2 custom values persist / invalid points rejected / none alias');

const mobile=process.argv.includes('--mobile');
try{
 const started=await playStart({viewport:mobile?{width:390,height:844}:{width:1500,height:1000}});assert.deepEqual(started.failed,[]);
 let value=await playEval({code:`localStorage.setItem('wml.mod.imagestudio.image-matching',${JSON.stringify(original)});return true;`});
 assert.equal(value.pageErrorsSoFar,0);await playReload({});
 value=await playEval({timeoutMs:30000,code:`
  const m=WW_ImageStudioMatching,key='wml.mod.imagestudio.image-matching',checks={};
  checks.migratedOnce=m.get().version===2&&m.get().rules.exposure.required&&m.get().rules.exposure.groups.length===12;
  checks.originalBackedUp=localStorage.getItem(key+'.before-exposure-v2')===${JSON.stringify(original)};
  checks.otherSettingsPreserved=m.get().rules.room.exact===4321&&m.get().rules.mood.emotionBonus===1138;
  m.open();document.querySelector('[data-match-tab="exposure"]').click();
  checks.requiredChecked=document.querySelector('[data-match-check="required"]').checked;
  checks.allBitsEditable=document.querySelectorAll('[data-match-exposure-score]').length===14;
  checks.all36Listed=document.querySelectorAll('.wwis-match-options>div').length===36;
  checks.allPairsListed=document.querySelector('[data-match-groups]').value.trim().split('\\n').length===12;
  const grid=document.querySelector('.wwis-exposure-points'),bounds=grid.getBoundingClientRect();
  checks.mobileFits=bounds.width>0&&bounds.right<=innerWidth+1;
  checks.maximumShown=document.querySelector('[data-match-content="exposure"]').textContent.includes('완전 일치 3200점');
  const input=document.querySelector('[data-match-exposure-score="bodiceUnlaced:match"]');input.value='300';input.dispatchEvent(new Event('change',{bubbles:true}));
  checks.editUpdatesTotal=m.get().rules.exposure.bitScores.bodiceUnlaced.match===300&&document.querySelector('[data-match-content="exposure"]').textContent.includes('완전 일치 3300점');
  const groups=document.querySelector('[data-match-groups]');groups.value='1 | 2\\n2 | 3';document.querySelector('[data-match-save-groups]').click();
  checks.numberInputStoredAsCodes=JSON.stringify(m.get().rules.exposure.groups)===JSON.stringify([['0000000','0000010'],['0000010','0000001']]);
  const required=document.querySelector('[data-match-check="required"]');required.click();
  checks.newPreferenceEditable=m.get().rules.exposure.required===false;
  return checks;
 `});
 assert.equal(value.pageErrorsSoFar,0,JSON.stringify(value));assert.ok(!value.error,value.error);
 assert.deepEqual(Object.entries(value.result).filter(([,passed])=>passed!==true),[],JSON.stringify(value.result));
 await playReload({});
 const persisted=await playEval({code:`const m=WW_ImageStudioMatching;return {required:m.get().rules.exposure.required,points:m.get().rules.exposure.bitScores.bodiceUnlaced.match,groups:m.get().rules.exposure.groups,backup:localStorage.getItem('wml.mod.imagestudio.image-matching.before-exposure-v2')};`});
 assert.equal(persisted.result.required,false);assert.equal(persisted.result.points,300);
 assert.deepEqual(persisted.result.groups,[['0000000','0000010'],['0000010','0000001']]);assert.equal(persisted.result.backup,original);
 assert.deepEqual((await playStatus({})).pageErrors,[]);
 console.log('PASS',Object.keys(value.result).length,'migration / backup / settings UI checks plus reload preservation',mobile?'(390px)':'(PC)');
}finally{await shutdown();setTimeout(()=>process.exit(process.exitCode||0),200).unref();}
