// 실행: node wml/mods/imagestudio/tests/prompt-split.mjs
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { playStart, playEval, playReload, playStop } from '../../../../MCP/lib/play.mjs';

const session = 'imagestudio-prompt-split';
const viewport = process.argv.includes('--mobile') ? { width: 390, height: 844 } : { width: 1500, height: 950 };
const extra = ['imagestudio-compatible-attention-image-prompt', 'show-me-mod', 'imagestudio-compatible-show_me_mod'];
let listed;
vm.runInNewContext(fs.readFileSync(new URL('../../mods.js', import.meta.url), 'utf8'), { WML: { enable: values => { listed = values; } } });
const disabled = Object.fromEntries([...listed.map(value => value.replace(/:off$/, '')), ...extra].map(id => [id, false]));
const selected = { situation: ['idle'], outfit: ['modest'], room: ['taproom'], mood: ['default'], men: ['0'], exposure: ['none'], aftermath: ['none'], variant: ['0'] };

async function ImageStudioTest_실행하기(code) {
  const value = await playEval({ id: session, code, timeoutMs: 30000 });
  assert.ok(!value.error, value.error);
  assert.equal(value.pageErrorsSoFar, 0, JSON.stringify(value));
  return value.result;
}
async function ImageStudioTest_시작하기(enabled, setup = '') {
  await playStart({ id: session, viewport, mods: { ...disabled, 'addon-compat': true, imagestudio: true, ...enabled } });
  await ImageStudioTest_실행하기(`localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify(extra)})); ${setup} return true;`);
  await playReload({ id: session });
  const status = await ImageStudioTest_실행하기(`return {failed:WML.status().failed,loaded:WML.status().loaded};`);
  assert.deepEqual(status.failed, []);
  return status;
}

try {
  // 본체 단독: 편집기가 없어도 계획·검수 창이 열립니다.
  await ImageStudioTest_시작하기({});
  let result = await ImageStudioTest_실행하기(`
    let seed=1138; Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
    const before=JSON.stringify(WML.dev().store.game());
    const space=WW_ImageStudioBridge.randomSpace('elena',${JSON.stringify(selected)});
    const details=WW_ImageStudioPrompt.combinationSpace({});const items=space.build(0n,details.at(0n));
    WW_ImageStudioPrompt.open();
    return {registry:WW_ImageStudioBridge.extensions.list(),items:items.length,review:!!document.querySelector('[data-wwis-review]'),
      message:document.querySelector('[data-wwis-prompt-editor]').textContent,unchanged:before===JSON.stringify(WML.dev().store.game()),
      invalidPose:WW_ImageStudioPrompt.positionApplicable('cowgirl','elena__scene-blowjob__outfit-modest__room-bedroom__v-0')};
  `);
  assert.equal(result.registry.editor, null);
  assert.equal(result.items, 1);
  assert.equal(result.review, true);
  assert.equal(result.unchanged, true);
  assert.equal(result.invalidPose, false);
  assert.match(result.message, /편집기를 사용하려면/);
  console.log('PASS core only: plan / review / unchanged game state');

  // 생성/승인 API 연결만 가짜 응답으로 확인합니다. GPU 요청과 실제 파일 쓰기는 하지 않습니다.
  result = await ImageStudioTest_실행하기(`
    const originalFetch=fetch,originalConnection=WW_ImageStudioBridge.connection;
    let entries=[],payload=null,saved=false;
    const respond=value=>Promise.resolve(new Response(JSON.stringify(value),{headers:{'Content-Type':'application/json'}}));
    WW_ImageStudioBridge.connection=()=>({baseUrl:location.origin,comfyui:true});
    globalThis.fetch=(input,options={})=>{
      const path=new URL(String(input),location.href).pathname;
      if(path==='/api/studio/drafts')return respond({supportsReviewDrafts:true,entries,defaultDirectory:'test-only'});
      if(path==='/api/image/generate'){
        payload=JSON.parse(options.body);entries=[{id:'split-test',talentName:payload.talentId,imageUrl:'/missing-test.webp',mime:'image/webp'}];
        return respond({status:'completed',reviewOnly:true,draftId:'split-test',imageUrl:'/missing-test.webp'});
      }
      if(path==='/api/studio/drafts/split-test/save'){saved=true;entries=[];return respond({absolutePath:'test-only.webp'});}
      return originalFetch(input,options);
    };
    try{
      await WW_ImageStudioPrompt.generate({imageKey:'elena__task-idle__outfit-modest__room-taproom__v-0',prompt:'test prompt'});
      document.querySelector('[data-wwis-review-action="save"]').click();
      for(let i=0;i<50&&!document.querySelector('[data-wwis-review-message]').textContent.includes('승인 저장 완료');i++)await new Promise(resolve=>setTimeout(resolve,10));
      return {saved,reviewOnly:payload.reviewOnly,seed:payload.seed,bulk:payload.bulk,message:document.querySelector('[data-wwis-review-message]').textContent};
    }finally{globalThis.fetch=originalFetch;WW_ImageStudioBridge.connection=originalConnection;}
  `);
  assert.equal(result.saved, true);
  assert.equal(result.reviewOnly, true);
  assert.equal(result.seed, 1138);
  assert.equal(result.bulk, true);
  assert.match(result.message, /승인 저장 완료/);
  console.log('PASS review generation / approval API contract (mock, no GPU or file writes)');

  // 이전 설정은 그대로 두고 새 저장소에 복사한 뒤, 이후 새 설정을 덮어쓰지 않습니다.
  const legacy = { nativeAxisPrompts: { situation: { idle: { positivePrompt: 'split_positive_1138', negativePrompt: 'split_negative_1138' } } }, customMigrationMarker: 1138 };
  await ImageStudioTest_시작하기({ [extra[0]]: true }, `
    localStorage.removeItem('wml.mod.${extra[0]}');
    localStorage.setItem('wml.mod.attention-image-prompt',JSON.stringify(${JSON.stringify(legacy)}));
  `);
  result = await ImageStudioTest_실행하기(`
    const d=WML.dev(),s=d.store.game(),before=JSON.stringify(s),c=d.fn('wife')(s);
    const live=d.fn('imagePrompt')(c,'taproom');
    const details=WW_ImageStudioPrompt.combinationSpace({});
    const item=WW_ImageStudioBridge.randomSpace('elena',${JSON.stringify(selected)}).build(0n,details.at(0n))[0];
    WW_ImageStudioPrompt.open();
    return {legacy:JSON.parse(localStorage.getItem('wml.mod.attention-image-prompt')),saved:JSON.parse(localStorage.getItem('wml.mod.${extra[0]}')),
      livePositive:live.prompt.includes('split_positive_1138'),liveNegative:live.negativePrompt.includes('split_negative_1138'),
      planPositive:item.prompt.includes('split_positive_1138'),planNegative:item.negativePrompt.includes('split_negative_1138'),
      editor:document.querySelector('[data-wwis-prompt-editor]').textContent.length,unchanged:before===JSON.stringify(d.store.game())};
  `);
  assert.deepEqual(result.legacy, legacy);
  assert.equal(result.saved.customMigrationMarker, 1138);
  for (const name of ['livePositive', 'liveNegative', 'planPositive', 'planNegative', 'unchanged']) assert.equal(result[name], true, name);
  assert.ok(result.editor > 1000);
  await ImageStudioTest_실행하기(`const key='wml.mod.${extra[0]}';const saved=JSON.parse(localStorage.getItem(key));saved.customMigrationMarker=2276;localStorage.setItem(key,JSON.stringify(saved));return true;`);
  await playReload({ id: session });
  assert.equal(await ImageStudioTest_실행하기(`return JSON.parse(localStorage.getItem('wml.mod.${extra[0]}')).customMigrationMarker;`), 2276);
  console.log('PASS migration: original preserved / custom settings / no repeated overwrite');

  // 새 제공자는 원본 7개 행동 × 자신감 3단계 × 변형 4개를 순서대로 구성합니다.
  await ImageStudioTest_시작하기(Object.fromEntries(extra.map(id => [id, true])));
  result = await ImageStudioTest_실행하기(`
    const before=JSON.stringify(WML.dev().store.game());
    const base=WW_ImageStudioBridge.randomSpace('elena',${JSON.stringify(selected)});
    const actions=WML.use('show-me-mod').actions,keys=[],bad=[];
    for(const action of actions)for(const tier of ['low','mid','high'])for(const variant of ['0','1','2','3']){
      const details=WW_ImageStudioPrompt.combinationSpace({promptShowMeAction:[action],promptShowMeTier:[tier],promptShowMeVariant:[variant]});
      const items=base.build(0n,details.at(0n));
      if(items.length!==1||items[0].ImageStudioParts.filter(part=>part.label==='맘껏 보여주기').length!==1)bad.push([action,tier,variant]);
      if(items[0])keys.push(items[0].talentId);
    }
    const plain=base.build(0n,WW_ImageStudioPrompt.combinationSpace({}).at(0n))[0];
    const m=WW_ImageStudioMatching.matcher,cfg=m.defaults();cfg.rules.scene.required=false;
    const a=m.describe(keys[0]),b=m.describe(keys[0].replaceAll('show-tongue','show-anus'));
    const old='elena__task-idle__outfit-modest__room-taproom__v-3|ca_0_ask_low_abc_V0';
    const projected=WW_ImageStudioBridge.extensions.normalizeKey(old);
    const legacyRows=[0,1].map(variant=>({talentName:old.replace('_V0','_V'+variant),imagePath:'fixture-'+variant+'.webp'}));
    const oldChoice=m.choose(m.describe(projected),legacyRows,cfg,()=>null,()=>0);
    return {count:keys.length,unique:new Set(keys).size,bad,plain:plain.talentId,unchanged:before===JSON.stringify(WML.dev().store.game()),
      crossAction:m.score(a,b,cfg),crossOwner:m.score(a,m.describe(plain.talentId),cfg),self:!!m.score(a,a,cfg),
      oldSpec:m.describe(old),legacyVariants:oldChoice?.variantCount,projected:projected,registry:WW_ImageStudioBridge.extensions.list()};
  `);
  assert.equal(result.count, 84);
  assert.equal(result.unique, 84);
  assert.deepEqual(result.bad, []);
  assert.equal(result.unchanged, true);
  assert.equal(result.crossAction, null);
  assert.equal(result.crossOwner, null);
  assert.equal(result.self, true);
  assert.equal(result.oldSpec.variant, 0);
  assert.equal(result.oldSpec.content, 'show-me-mod');
  assert.equal(result.legacyVariants, 2);
  assert.match(result.plain, /task-idle/);
  console.log('PASS show-me: 84 plans / one prompt part / strict action matching / legacy keys / no state changes');

  // 실제 행동은 원본 선택 처리로 실행하고, 그림 조회는 행동을 다시 실행하지 않습니다.
  result = await ImageStudioTest_실행하기(`
    const d=WML.dev(),s=structuredClone(d.store.game()),id=s.primaryCharacterId;
    s.activeScene={};s.phase='prep';s.characters[id]={...s.characters[id],
      stats:{...s.characters[id].stats,mood:100,energy:100,arousal:60},
      relationship:{...s.characters[id].relationship,trust:100,resentment:0}};
    d.store.update(()=>s);const out=d.fn('d7')(s,'bdca_ask_0');d.store.update(()=>out);
    const c=d.fn('wife')(out),before=JSON.stringify(out),scene=WML.use('show-me-mod').context(c);
    const prompt=d.fn('imagePrompt')(c,'taproom'),key=d.fn('imageKey')(c,'taproom');
    const plan=WW_ImageStudioBridge.randomSpace('elena',${JSON.stringify(selected)}).build(0n,WW_ImageStudioPrompt.combinationSpace({}).at(0n));
    return {scene,key,promptKey:prompt.key,parts:prompt.parts.filter(part=>part.label==='맘껏 보여주기').length,
      unchanged:before===JSON.stringify(d.store.game()),ordinaryPlan:plan[0].talentId,log:out.log.slice(-2)};
  `);
  assert.ok(result.scene);
  assert.equal(result.parts, 1);
  assert.equal(result.key, result.promptKey);
  assert.equal(result.unchanged, true);
  assert.match(result.ordinaryPlan, /task-idle/);
  assert.ok(result.log.length);
  console.log('PASS live action / imageKey consistency / no active scene leakage into ordinary plans');

  // 표시가 좁은 화면에서도 편집/검수 창과 제공자 선택지를 실제 DOM으로 확인합니다.
  result = await ImageStudioTest_실행하기(`
    WW_ImageStudioPrompt.open();
    [...document.querySelectorAll('button')].find(button=>button.textContent==='특정 장면 프롬프트 만들기').click();
    const controls=[...document.querySelectorAll('[data-wwis-specific-axis]')].map(element=>element.dataset.wwisSpecificAxis);
    return {controls,review:!!document.querySelector('[data-wwis-review]')};
  `);
  assert.ok(result.controls.includes('promptShowMeAction'));
  assert.equal(result.review, true);
  console.log('PASS combined editor / review UI / show-me selectors');

  // 콘텐츠 연결은 선택 사항인 공통 편집기를 요구하지 않습니다.
  await ImageStudioTest_시작하기({ 'show-me-mod': true, 'imagestudio-compatible-show_me_mod': true });
  result = await ImageStudioTest_실행하기(`
    const space=WW_ImageStudioBridge.randomSpace('elena',${JSON.stringify(selected)});
    const details=WW_ImageStudioPrompt.combinationSpace({promptShowMeAction:['show-tongue'],promptShowMeTier:['mid'],promptShowMeVariant:['0']});
    const items=space.build(0n,details.at(0n));
    return {editor:WW_ImageStudioBridge.extensions.list().editor,key:items[0]?.talentId,parts:items[0]?.ImageStudioParts?.filter(part=>part.label==='맘껏 보여주기').length};
  `);
  assert.equal(result.editor, null);
  assert.equal(result.parts, 1);
  assert.match(result.key, /task-show_me_mod-show-tongue/);
  console.log('PASS show-me compatibility without the optional prompt editor');
} finally {
  await playStop({ id: session });
  // MCP 평가 도우미의 제한시간 타이머가 남아도 닫힌 시험 프로세스가 오래 머물지 않게 합니다.
  setTimeout(() => process.exit(process.exitCode || 0), 200).unref();
}
