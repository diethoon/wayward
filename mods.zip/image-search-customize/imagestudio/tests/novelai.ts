// 실행: bun wml/mods/imagestudio/tests/novelai.ts [--ui] [--mobile]
// 가짜 NAI 응답과 임시 저장소만 사용합니다. 실제 토큰·과금·GPU·사용자 이미지는 사용하지 않습니다.
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { createRequire } from 'node:module'
import { deflateRawSync } from 'node:zlib'
import { resolveConfig } from '../backend/wayward-imagegen/src/config.ts'
import { startServer } from '../backend/wayward-imagegen/src/server.ts'
import { NovelAI_PNG읽기 } from '../backend/wayward-imagegen/src/nai/client.ts'

const testDirectory = path.resolve(import.meta.dir)
const temporary = fs.mkdtempSync(path.join(testDirectory, '.novelai-'))
const require = createRequire(new URL('../backend/wayward-imagegen/package.json', import.meta.url))
const sharp = require('sharp')
const png = await sharp({ create: { width: 16, height: 16, channels: 4, background: '#7397bd' } }).png().toBuffer()
const originalFetch = globalThis.fetch
const payloads: any[] = []
let forcedStatus = 0, responseFormat = 'zip', comfyCalls = 0, active = 0, maximumActive = 0
let gate: Promise<void> | null = null
let releaseGate: (() => void) | undefined
let server: Awaited<ReturnType<typeof startServer>> | undefined
let uiSettings: Record<string, unknown>

/** 실제 ZIP 규격의 CRC·파일 목록으로 stored/deflate 응답을 만들어 파서를 검증합니다. */
function NovelAITest_ZIP만들기(bytes: Buffer, method = 8): Buffer {
  let crc = 0xffffffff
  for (const byte of bytes) {
    crc ^= byte
    for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0)
  }
  crc = (crc ^ 0xffffffff) >>> 0
  const name = Buffer.from('image_0.png')
  const data = method === 8 ? deflateRawSync(bytes) : bytes
  const local = Buffer.alloc(30), central = Buffer.alloc(46), end = Buffer.alloc(22)
  local.writeUInt32LE(0x04034b50); local.writeUInt16LE(20, 4); local.writeUInt16LE(method, 8)
  local.writeUInt32LE(crc, 14); local.writeUInt32LE(data.length, 18); local.writeUInt32LE(bytes.length, 22); local.writeUInt16LE(name.length, 26)
  central.writeUInt32LE(0x02014b50); central.writeUInt16LE(20, 6); central.writeUInt16LE(method, 10)
  central.writeUInt32LE(crc, 16); central.writeUInt32LE(data.length, 20); central.writeUInt32LE(bytes.length, 24); central.writeUInt16LE(name.length, 28)
  end.writeUInt32LE(0x06054b50); end.writeUInt16LE(1, 8); end.writeUInt16LE(1, 10)
  end.writeUInt32LE(central.length + name.length, 12); end.writeUInt32LE(local.length + name.length + data.length, 16)
  return Buffer.concat([local, name, data, central, name, end])
}

// 테스트 프로세스의 외부 API는 모두 가로챕니다. 허용한 로컬 시험 서버 외 네트워크는 실패합니다.
globalThis.fetch = (async (input: any, options: any = {}) => {
  const url = String(input)
  if (url.startsWith('https://image.novelai.net/')) {
    assert.equal(options.headers.Authorization, 'Bearer test-nai-secret')
    if (url.endsWith('/user/subscription')) return Response.json({ active: true, tier: 3 })
    assert.ok(url.endsWith('/ai/generate-image'))
    payloads.push(JSON.parse(options.body))
    active++; maximumActive = Math.max(maximumActive, active)
    try {
      if (gate) await gate
      if (forcedStatus) return new Response('test-nai-secret rejected', { status: forcedStatus })
      if (responseFormat === 'bad') return new Response('invalid output')
      if (responseFormat === 'json') return Response.json({ images: [{ image: png.toString('base64') }] })
      if (responseFormat === 'png') return new Response(png, { headers: { 'content-type': 'image/png' } })
      return new Response(NovelAITest_ZIP만들기(png), { headers: { 'content-type': 'application/zip' } })
    } finally { active-- }
  }
  if (url.startsWith('http://127.0.0.1:1/')) { comfyCalls++; return new Response('', { status: 503 }) }
  if (server && url.startsWith(`http://127.0.0.1:${server.port}/`)) return originalFetch(input, options)
  throw new Error('시험에서 허용하지 않은 네트워크 요청: ' + url)
}) as typeof fetch

/** 제한 시간을 두고 실제 API 작업이 끝날 때까지 상태를 확인합니다. */
async function NovelAITest_완료기다리기(promptId: string) {
  for (let index = 0; index < 200; index++) {
    const job = server!.jobs.get(promptId)!
    if (job.status === 'completed' || job.status === 'error') return job
    await new Promise(resolve => setTimeout(resolve, 10))
  }
  throw new Error('NAI 모의 생성 시간 초과')
}

try {
  // 1. 빈 응답과 손상된 ZIP을 거부하고 세 가지 정상 이미지 형식을 읽습니다.
  assert.deepEqual(NovelAI_PNG읽기(NovelAITest_ZIP만들기(png)), png)
  assert.deepEqual(NovelAI_PNG읽기(NovelAITest_ZIP만들기(png, 0)), png)
  assert.deepEqual(NovelAI_PNG읽기(png), png)
  for (const bytes of [Buffer.alloc(0), Buffer.from('bad'), NovelAITest_ZIP만들기(png).subarray(0, 50)])
    assert.throws(() => NovelAI_PNG읽기(bytes))

  const config = resolveConfig([], temporary)
  Object.assign(config, { host: '127.0.0.1', port: 0, comfyUrl: 'http://127.0.0.1:1',
    imagesDir: path.join(temporary, 'images'), stateDir: path.join(temporary, 'state'),
    imageProvider: 'sdxl', naiToken: '', webp: true, requireWebp: true, maxDiskGb: 0, maxImagesPerHour: 0 })
  server = await startServer(config)
  const url = `http://127.0.0.1:${server.port}`
  const api = async (route: string, body?: unknown, method = 'POST') => {
    const response = await fetch(url + route, body === undefined ? {} : { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
    return { status: response.status, body: await response.json() as any }
  }
  const initial = (await api('/api/generation/settings')).body
  assert.equal(initial.version, 19)
  assert.equal(initial.naiToken, undefined)
  assert.equal((await api('/api/generation/settings', { ...initial, imageProvider: 'nai' }, 'PUT')).status, 400)
  const saved = await api('/api/generation/settings', { ...initial, imageProvider: 'nai', naiToken: 'test-nai-secret',
    naiCommonPrompt: 'common', naiArtistPrompt: 'style', naiNegativePrompt: 'nai negative',
    sdxlPositivePrompt: 'sdxl must not leak', sdxlNegativePrompt: 'sdxl negative', promptBatchSize: 4 }, 'PUT')
  assert.equal(saved.status, 200, JSON.stringify(saved))
  assert.equal(saved.body.settings.naiTokenConfigured, true)
  assert.ok(!JSON.stringify(saved.body).includes('test-nai-secret'))
  uiSettings = saved.body.settings
  await api('/api/generation/settings', { ...uiSettings, naiToken: '' }, 'PUT')
  assert.equal(config.naiToken, 'test-nai-secret', '화면 빈칸은 저장한 토큰을 유지합니다.')
  for (const change of [{ naiWidth: 833 }, { naiHeight: 0 }, { naiSteps: 0 }, { naiScale: 11 }, { naiModel: 'invalid' }])
    assert.equal((await api('/api/generation/settings', { ...uiSettings, ...change }, 'PUT')).status, 400)
  const beforeHealth = comfyCalls
  const health = await api('/api/image/health')
  assert.equal(health.status, 200)
  assert.equal(health.body.comfyui, 'connected', '기존 게임 연결 프로토콜도 준비 상태로 해석해야 합니다.')
  assert.equal(health.body.imageProvider, 'nai')
  assert.equal(health.body.comfyuiRequired, false)
  assert.equal(comfyCalls, beforeHealth)
  assert.equal((await api('/api/nai/check', {})).body.active, true)
  console.log('PASS 설정 검증·토큰 비노출/보존·구독 연결 확인·ComfyUI 없이 health 준비')

  // 2. 같은 요청은 한 번만 생성하고, 프롬프트·모델·크기·시드와 WebP 저장을 확인합니다.
  const body = { talentId: 'elena__task-idle__v-8', prompt: 'adult woman, resting', negativePrompt: 'blur', seed: 1138 }
  const [first, duplicate] = await Promise.all([api('/api/image/generate', body), api('/api/image/generate', body)])
  assert.equal(first.body.promptId, duplicate.body.promptId)
  const finished = await NovelAITest_완료기다리기(first.body.promptId)
  assert.equal(finished.status, 'completed', finished.error)
  assert.equal(finished.workflow, 'nai')
  assert.match(finished.media!.relativePath, /^nai\/characters\/elena\/.+\.webp$/)
  assert.equal(payloads.length, 1)
  assert.equal(payloads[0].input, 'common, style, adult woman, resting')
  assert.equal(payloads[0].parameters.negative_prompt, 'nai negative, blur')
  assert.equal(payloads[0].parameters.seed, 1138)
  assert.equal(payloads[0].parameters.width, 832)
  assert.equal(payloads[0].parameters.n_samples, 1)
  assert.equal(payloads[0].parameters.params_version, 4)
  assert.equal(payloads[0].parameters.v4_prompt.caption.base_caption, payloads[0].input)
  assert.equal((await api('/api/image/generate', body)).body.cached, true)
  const cacheText = JSON.stringify(server.cache.entries)
  assert.ok(!cacheText.includes('test-nai-secret'))
  assert.equal(Object.values(server.cache.entries)[0].genParams?.seed, 1138)
  const pack = await api('/api/pack')
  assert.ok(pack.body.entries[body.talentId])
  assert.equal((await fetch(url + '/images/' + finished.media!.relativePath)).status, 200)
  const sameKey = first.body.promptId
  for (const change of [{ naiModel: 'nai-diffusion-4-5-full' }, { naiWidth: 896 }, { naiSampler: 'k_euler' }, { naiNoiseSchedule: 'native' }]) {
    await api('/api/generation/settings', { ...uiSettings, ...change }, 'PUT')
    const next = await api('/api/image/generate', body)
    assert.notEqual(next.body.promptId, sameKey)
    assert.equal((await NovelAITest_완료기다리기(next.body.promptId)).status, 'completed')
  }
  await api('/api/generation/settings', uiSettings, 'PUT')
  console.log('PASS 실제 API 경로의 중복 방지·시드·NAI 프롬프트·설정별 캐시·WebP·팩 조회')

  // 3. 검수 결과는 승인 전 디스크·캐시에 넣지 않습니다. NAI도 기존 승인 저장을 사용합니다.
  for (const format of ['json', 'png']) {
    responseFormat = format
    const count = server.cache.size
    const review = await api('/api/image/generate', { ...body, talentId: 'mara__review-' + format, reviewOnly: true })
    const job = await NovelAITest_완료기다리기(review.body.promptId)
    assert.equal(job.status, 'completed', job.error)
    assert.equal(server.cache.size, count)
    assert.ok(job.draftId)
    assert.equal((await fetch(url + '/api/studio/drafts/' + job.draftId + '/image')).status, 200)
    const approval = await api('/api/studio/drafts/' + job.draftId + '/save', {})
    assert.equal(approval.status, 200)
    assert.match(approval.body.absolutePath, /nai[\\/]characters[\\/]mara/)
    assert.equal(server.cache.size, count + 1)
  }
  responseFormat = 'zip'
  const beforeReference = payloads.length
  assert.equal((await api('/api/image/generate', { ...body, referenceKey: 'missing', denoise: 0.3 })).status, 501)
  assert.equal(payloads.length, beforeReference, '지원하지 않는 참조 생성은 NAI로 전송하지 않습니다.')
  console.log('PASS JSON/PNG 응답·검수/승인 저장·img2img 명시 오류')

  // 4. 기존 대기열도 ComfyUI 배치 크기와 무관하게 NAI 요청을 한 장씩 처리합니다.
  const beforeBatch = payloads.length, beforeComfy = comfyCalls
  const enqueue = await api('/api/batch/enqueue', { items: [1, 2].map(index => ({
    talentId: 'pippa__nai-batch-' + index, prompt: 'adult woman, sitting', negativePrompt: 'blur' })), start: true })
  assert.equal(enqueue.status, 200)
  for (let index = 0; index < 200 && server.batch.status().done < 2; index++) await new Promise(resolve => setTimeout(resolve, 10))
  assert.equal(server.batch.status().completed, 2, JSON.stringify(server.batch.status()))
  assert.equal(payloads.length, beforeBatch + 2)
  assert.equal(comfyCalls, beforeComfy)
  assert.equal(maximumActive, 1)
  const countBeforeCache = payloads.length
  const interactive = await api('/api/image/generate', { talentId: 'pippa__nai-batch-1', prompt: 'adult woman, sitting', negativePrompt: 'blur' })
  assert.equal(interactive.body.cached, true, '일반 생성과 대기열은 같은 해시를 사용합니다.')
  assert.equal(payloads.length, countBeforeCache)
  console.log('PASS 조건부 대기열 직렬 생성·ComfyUI 미호출·일반 생성과 캐시 공유')

  // 5. 대기 취소·인증/제한/응답 오류에서 재전송과 잘못된 저장을 막습니다.
  gate = new Promise(resolve => { releaseGate = resolve })
  const running = await api('/api/image/generate', { ...body, talentId: 'elena__cancel-running', bulk: true })
  const waiting = await api('/api/image/generate', { ...body, talentId: 'elena__cancel-queued', bulk: true })
  assert.equal((await api('/api/image/cancel', { promptId: waiting.body.promptId })).body.cancelled, true)
  releaseGate!(); gate = null
  await NovelAITest_완료기다리기(running.body.promptId)
  assert.equal(server.jobs.get(waiting.body.promptId)!.status, 'error')
  for (const errorStatus of [401, 429]) {
    forcedStatus = errorStatus
    const before = payloads.length
    const failed = await api('/api/image/generate', { ...body, talentId: 'elena__error-' + errorStatus, reviewOnly: true })
    const job = await NovelAITest_완료기다리기(failed.body.promptId)
    assert.equal(job.status, 'error')
    assert.match(job.error!, new RegExp(String(errorStatus)))
    assert.ok(!job.error!.includes('test-nai-secret'))
    assert.equal(payloads.length, before + 1)
  }
  forcedStatus = 0; responseFormat = 'bad'
  const invalid = await api('/api/image/generate', { ...body, talentId: 'elena__invalid-output', reviewOnly: true })
  assert.equal((await NovelAITest_완료기다리기(invalid.body.promptId)).status, 'error')
  responseFormat = 'zip'

  // 6. 서버 재시작 뒤 설정·토큰을 복원하고 SDXL 전환 및 토큰 삭제를 확인합니다.
  await server.close()
  const restored = resolveConfig([], temporary)
  Object.assign(restored, { ...config, naiToken: '', imageProvider: 'sdxl', port: 0 })
  server = await startServer(restored)
  assert.equal(restored.imageProvider, 'nai')
  assert.equal(restored.naiToken, 'test-nai-secret')
  const updatedUrl = `http://127.0.0.1:${server.port}`
  const response = await fetch(updatedUrl + '/api/generation/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...uiSettings, imageProvider: 'sdxl', naiTokenClear: true }) })
  assert.equal(response.status, 200)
  assert.equal(restored.naiToken, '')
  assert.equal(restored.imageProvider, 'sdxl')
  console.log('PASS 대기 취소·오류/비정상 이미지·자동 재전송 없음·재시작 보존·방식 전환·토큰 삭제')
} finally {
  globalThis.fetch = originalFetch
  releaseGate?.()
  await server?.close()
  assert.ok(temporary.startsWith(testDirectory + path.sep))
  fs.rmSync(temporary, { recursive: true, force: true })
}

if (process.argv.includes('--ui')) {
  const { playStart, playEval, playStop, playScreenshot } = await import('../../../../MCP/lib/play.mjs')
  const session = 'imagestudio-nai-' + (process.argv.includes('--mobile') ? 'mobile' : 'desktop')
  try {
    await playStart({ id: session, viewport: process.argv.includes('--mobile') ? { width: 390, height: 844 } : { width: 1500, height: 950 },
      mods: { 'addon-compat': true, imagestudio: true } })
    const result = await playEval({ id: session, timeoutMs: 30000, code: `
      const settings = ${JSON.stringify(uiSettings!)};
      const originalFetch = fetch;
      WW_ImageStudioBridge.connection = () => ({ baseUrl: location.origin, comfyui: true });
      let saves = [], checks = 0;
      globalThis.fetch = async (input, options = {}) => {
        const route = String(input);
        if (route.endsWith('/api/generation/settings')) {
          if (options.method === 'PUT') {
            const body = JSON.parse(options.body); saves.push(body);
            Object.assign(settings, body); delete settings.naiToken;
          }
          return Response.json(options.method === 'PUT' ? {settings} : settings);
        }
        if (route.endsWith('/api/nai/check')) { checks++; return Response.json({connected:true,active:true}); }
        return originalFetch(input, options);
      };
      WW_ImageStudio.open();
      document.querySelector('#wwis-generation-settings').click();
      for(let index=0;index<100&&!document.querySelector('#wwis-nai-token');index++) await new Promise(resolve=>setTimeout(resolve,10));
      const radio = document.querySelector('input[name=wwis-provider][value=nai]');
      const token = document.querySelector('#wwis-nai-token');
      const initialToken = token.value, password = token.type;
      const initialVisible = !document.querySelector('#wwis-nai-settings').hidden && document.querySelector('#wwis-comfy-settings').hidden;
      token.value = 'ui-test-token';
      await document.querySelector('#wwis-save-generation').onclick();
      await document.querySelector('#wwis-nai-check').onclick();
      const savedTokenCleared = token.value === '';
      document.querySelector('input[name=wwis-provider][value=sdxl]').click();
      const switched = document.querySelector('#wwis-nai-settings').hidden && !document.querySelector('#wwis-comfy-settings').hidden;
      radio.click();
      const status = document.querySelector('#wwis-settings-status').textContent;
      return {initialToken,password,initialVisible,switched,savedTokenCleared,checks,provider:saves[0].imageProvider,
        tokenSent:saves[0].naiToken==='ui-test-token',status,failed:WML.status().failed};
    ` })
    assert.ok(!result.error, result.error)
    assert.equal(result.pageErrorsSoFar, 0, JSON.stringify(result))
    const value = result.result
    assert.deepEqual(value.failed, [])
    assert.equal(value.initialToken, '')
    assert.equal(value.password, 'password')
    for (const key of ['initialVisible', 'switched', 'savedTokenCleared', 'tokenSent']) assert.equal(value[key], true, key)
    assert.equal(value.provider, 'nai')
    assert.equal(value.checks, 1)
    assert.match(value.status, /NovelAI 설정을 저장/)
    const shotDirectory = path.join(testDirectory, '../.maintenance')
    fs.mkdirSync(shotDirectory, { recursive: true })
    await playEval({ id: session, code: `document.querySelector('#wwis-nai-settings').scrollIntoView({block:'start'}); return true;` })
    const shot = await playScreenshot({ id: session })
    fs.writeFileSync(path.join(shotDirectory, 'nai-settings-' + (process.argv.includes('--mobile') ? 'mobile' : 'desktop') + '.jpg'), Buffer.from(shot, 'base64'))
    console.log('PASS 실제 게임 설정 화면: NAI 선택·토큰 입력/비노출·저장·연결 확인·방식 전환')
  } finally {
    await playStop({ id: session })
    // MCP 평가 도우미가 남긴 제한시간 타이머는 닫힌 시험 프로세스에서 기다리지 않습니다.
    setTimeout(() => process.exit(process.exitCode || 0), 200).unref()
  }
}
