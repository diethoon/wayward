import fs from 'node:fs';
import assert from 'node:assert/strict';
import {registerHooks,createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const legacy=createRequire(new URL('../../../../wayward-wml-ko_old/MCP/package.json',import.meta.url));
registerHooks({resolve(s,c,n){try{return n(s,c);}catch(e){if(e.code==='ERR_MODULE_NOT_FOUND')return n(pathToFileURL(legacy.resolve(s)).href,c);throw e;}}});
const {playStart,playEval,shutdown}=await import('../../../../MCP/lib/play.mjs');
try{
 const start=await playStart({viewport:process.argv.includes('--mobile')?{width:390,height:844}:{width:1500,height:950}});assert.deepEqual(start.failed,[]);
 const result=await playEval({timeoutMs:30000,code:`
 const d=WML.dev(),b=WW_ImageStudioBridge,m=WW_ImageStudioMatching,sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const key='elena__task-idle__outfit-modest__room-taproom__v-0';
 const entries=Object.fromEntries(Array.from({length:8},(_,i)=>[i,{talentName:key.replace('__v-0','__v-'+i),imagePath:'display-'+i+'.svg'}]));
 b.packs=()=>[{entries}];const pack={entries};b.packs=()=>[pack];b.ready=()=>Promise.resolve();b.connection=()=>({baseUrl:null,comfyui:false});
 globalThis.__WW_STUDIO_OFFLINE_ONLY__=true;
 d.fn('settingsStore').getState().set({imageBackendMode:'off',ageAffirmed:true,contentAcknowledged:true});
 d.hook('bee',{priority:-9000000,replace:()=>key});
 d.hook(WML.status().modSymbols.imagestudio.imageEntryUrl,{priority:-9000000,replace:entry=>'data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="832" height="1216"><rect width="832" height="1216" fill="rgb('+Number(entry.imagePath.match(/display-(\\d+)/)?.[1])*25+',40,60)"/></svg>')});
 const conf=m.get();for(const id of ['scene','outfit','room','exposure'])conf.rules[id].required=false;m.set(conf);
 d.store.get().newGame();d.fn('store').setState({started:true,selectingArchetype:false,selectingBuilder:false,selectingPicks:false});await sleep(100);
 [...document.querySelectorAll('button')].find(b=>b.textContent==='건너뛰기')?.click();await sleep(500);
 const img=()=>[...document.querySelectorAll('#root img')].find(e=>e.src.startsWith('data:image/svg+xml,'));
 if(!img())throw Error('portrait missing '+document.body.innerText.slice(0,500));
 const initial=img(),url=initial.src,Native=Image;let releases=[];
 globalThis.Image=class extends Native{decode(){return new Promise(resolve=>releases.push(()=>super.decode().then(resolve)));}};
 d.store.dispatch({type:'wait',minutes:1});await sleep(150);
 const held=img()===initial&&img().src===url,waiting=releases.length>0;
 for(const release of releases)release();await sleep(300);
 const switched=img()===initial&&img().src!==url&&img().complete;
 globalThis.Image=Native;
 const after=img().src;d.store.dispatch({type:'wait',minutes:1});await sleep(300);
 const next=img()===initial&&img().src!==after;
 m.refresh();await sleep(200);releases=[];
 globalThis.Image=class extends Native{decode(){return new Promise(resolve=>releases.push(()=>super.decode().then(resolve)));}};
 d.store.dispatch({type:'wait',minutes:1});await sleep(100);
 d.store.dispatch({type:'wait',minutes:1});await sleep(100);
 const count=releases.length;
 const reversed=[...releases].reverse();reversed.shift()?.();await sleep(100);const latest=img().src;
 for(const release of reversed){release();await sleep(100);}
 await sleep(150);globalThis.Image=Native;
 return {held,waiting,switched,next,raceStable:count>=2&&img()===initial&&img().src===latest,errors:__wmlTest.errors};
 `});console.log(JSON.stringify(result));assert.equal(result.pageErrorsSoFar,0);for(const k of ['held','waiting','switched','next','raceStable'])assert.equal(result.result[k],true,k);
 const cache=await playEval({code:`
 const m=WW_ImageStudioMatching,b=WW_ImageStudioBridge,d=WML.dev(),sleep=ms=>new Promise(r=>setTimeout(r,ms));
 const key='mari__task-idle__outfit-modest__room-taproom__v-0',row={talentName:key,imagePath:'display-1.svg'};
 let serverRow=row,clock=Date.now,offset=0,builds=0,rows=0;const original=m.matcher.ImageStudio_후보색인만들기;
 m.matcher.ImageStudio_후보색인만들기=values=>{builds++;rows=values.length;return original(values);};
 const pack={entries:{one:row,two:{...row}}};b.packs=()=>[pack];b.connection=()=>({baseUrl:location.origin+'/fixture',comfyui:false});
 const fetchBefore=fetch;globalThis.fetch=(input,options)=>String(input).includes('/fixture/api/pack?')?Promise.resolve(new Response(JSON.stringify({entries:{one:serverRow}}),{status:200})):fetchBefore(input,options);
 Date.now=()=>clock()+offset;
 try{
 m.refresh();await m.resolve(key);await sleep(50);await m.resolve(key+'__test-1');const initial=builds,compacted=rows;
 offset+=31000;await m.resolve(key+'__test-2');await sleep(50);await m.resolve(key+'__test-3');const same=builds===initial;
 serverRow={...row,imagePath:'display-2.svg'};offset+=31000;await m.resolve(key+'__test-4');await sleep(50);await m.resolve(key+'__test-5');
 return {same,changed:builds>initial,compacted};
 }finally{Date.now=clock;globalThis.fetch=fetchBefore;}
 `});console.log(JSON.stringify(cache));assert.equal(cache.pageErrorsSoFar,0);assert.equal(cache.result.same,true);assert.equal(cache.result.changed,true);assert.equal(cache.result.compacted,1);
}finally{await shutdown();setTimeout(()=>process.exit(process.exitCode||0),200).unref();}
