// 실행: node wml/mods/imagestudio/tests/attention-upgrades.mjs [--mobile]
// 기본 모드 조합의 격리 저장소에서 장비 해제·의미 키·프리셋·사람별 편집·검수 요청을 검사합니다. seed=1138.
import assert from 'node:assert/strict';
import { playStart, playEval, playStatus, shutdown } from '../../../../MCP/lib/play.mjs';
const mobile=process.argv.includes('--mobile');
try {
  const started=await playStart({viewport:mobile?{width:390,height:844}:{width:1500,height:1000}});
  assert.deepEqual(started.failed,[]);
  const value=await playEval({timeoutMs:30000,code:`
    let seed=1138;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
    const dev=WML.dev(),editor=WML.use('imagestudio-compatible-attention-image-prompt'),upgrade=editor.upgrades;
    const settingsKey='wml.mod.imagestudio-compatible-attention-image-prompt';
    const change=patch=>localStorage.setItem(settingsKey,JSON.stringify({...JSON.parse(localStorage.getItem(settingsKey)||'{}'),...patch}));
    dev.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true});
    dev.store.get().newGame();dev.fn('store').setState({started:true,selectingArchetype:false,selectingBuilder:false,selectingPicks:false});
    const flush=()=>new Promise(resolve=>setTimeout(resolve,70));
    await flush();[...document.querySelectorAll('button')].find(button=>button.textContent==='건너뛰기')?.click();await flush();
    const id=dev.store.game().primaryCharacterId,checks={};
    const setCharacter=update=>dev.store.update(state=>({...state,characters:{...state.characters,[id]:update(state.characters[id])}}));
    const read=character=>dev.fn('imagePrompt')(character||dev.fn('wife')(dev.store.game()),'taproom');
    setCharacter(character=>({...character,situationStats:{...character.situationStats,jewelryState:{breasts:{stage:3},vibe:{type:'egg'}}}}));
    const stale=structuredClone(dev.fn('wife')(dev.store.game())),worn=read();
    setCharacter(character=>({...character,situationStats:{...character.situationStats,jewelryState:{breasts:{stage:0},vibe:{type:'egg',suspension:true}}}}));
    const before=JSON.stringify(dev.store.game()),removed=read(stale);
    checks.wornToy=/vibrator/.test(worn.prompt);
    checks.removedToy=!/vibrator|dildo/.test(removed.prompt);
    checks.removedChoker=!/choker/.test(removed.prompt);
    checks.absentEquipmentNegative=/vibrator/.test(removed.negativePrompt)&&/choker/.test(removed.negativePrompt);
    checks.changedSituationKey=worn.key!==removed.key;
    checks.noGameStateWrites=before===JSON.stringify(dev.store.game());
    const first=removed.key;
    change({outfitPrompts:{modest:{positivePrompt:'blue coat',negativePrompt:'red coat'}}});const edited=read();
    change({outfitPrompts:{modest:{positivePrompt:'green coat',negativePrompt:'orange coat'}}});const editedAgain=read();
    checks.promptTextDoesNotChangeKey=first===edited.key&&edited.key===editedAgain.key;
    checks.promptEditStillApplied=/green coat/.test(editedAgain.prompt)&&/orange coat/.test(editedAgain.negativePrompt);
    const key='elena__task-idle__outfit-modest__room-taproom__v-0';
    const group=codes=>[{id:'detail',value:{codes,tags:['custom prompt']}}];
    checks.groupedVisualState=upgrade.semanticKey(key,group(['energy-0','feeling-anger']))===upgrade.semanticKey(key,group(['energy-0','feeling-sadness']));
    change({groupSimilarDetailStates:false});
    checks.exactStateOption=upgrade.semanticKey(key,group(['energy-0','feeling-anger']))!==upgrade.semanticKey(key,group(['energy-0','feeling-sadness']));
    change({groupSimilarDetailStates:true});
    const normalized=upgrade.normalizeMatchingContext({emotions:['anger'],detail:['energy-0','feeling-anger']});
    checks.groupingIsIdempotent=JSON.stringify(normalized)===JSON.stringify(upgrade.normalizeMatchingContext(normalized));
    checks.unknownMetadataNotInvented=JSON.stringify(upgrade.normalizeMatchingContext({}))==='{}';
    const fake={key,prompt:'smile, standing, custom extension',negativePrompt:'',parts:[{label:'작업',tags:'smile, standing'}]};
    const distressed={...dev.fn('wife')(dev.store.game()),feelings:[{emotion:'anger',intensity:90}]};
    const corrected=upgrade.correct(fake,distressed);
    checks.expressionConflict=!/smile/.test(corrected.prompt)&&/standing/.test(corrected.prompt);
    checks.externalPromptPreserved=/custom extension/.test(corrected.prompt);
    const preset={positionPresetPrompts:{standing:'custom standing, relaxed'},positionPresetNegativePrompts:{standing:'bad posture'}};
    const imported=upgrade.importSettings(JSON.stringify({format:'wayward-state-image-prompts',version:13,...preset}));
    checks.legacyPresetTextPreserved=imported.positionPresetPrompts.standing===preset.positionPresetPrompts.standing
      &&imported.positionPresetNegativePrompts.standing===preset.positionPresetNegativePrompts.standing;
    change(preset);read();WW_ImageStudioPrompt.open();await flush();
    [...document.querySelectorAll('[data-wwis-prompt-editor] button')].find(button=>button.textContent==='장면별 세부 조정').click();await flush();
    document.querySelector('[data-person-enabled]').click();await flush();
    const female=document.querySelector('[data-person-field="female"]');female.value='standing';female.dispatchEvent(new Event('change',{bubbles:true}));await flush();
    const basic=document.querySelector('[data-position-preset-prompt="standing"]');
    checks.basicPromptEditorRetained=!!basic;
    if(basic){basic.value='synchronized standing';basic.dispatchEvent(new Event('change',{bubbles:true}));await flush();}
    checks.peoplePreviewSynchronized=document.querySelector('[data-person-preview]')?.textContent.includes('synchronized standing');
    checks.basicEditorRemainsPlain=document.querySelector('[data-position-preset-prompt="standing"]')?.value==='synchronized standing';
    const count=document.querySelector('[data-person-field="count"]');count.value='3';count.dispatchEvent(new Event('change',{bubbles:true}));await flush();
    checks.multiplePeople=document.querySelectorAll('[data-person-field$="-location"]').length===3;
    checks.exportNewSettings=upgrade.exportSettings().personDetails.men.length===3;
    const bounds=document.querySelector('[data-person-details]').getBoundingClientRect();
    checks.mobileFits=bounds.width>0&&bounds.right<=innerWidth+1;
    change({hStatusGenerationModes:{mouth:{mode:'img2img',referenceKey:'situation_fluid__elena__mouth__0',denoise:0.28}}});
    const unhook=dev.hook(WML.status().modSymbols.imagestudio.imageLookup,{priority:-4000000,around(next,key,...args){
      if(key==='situation_fluid__elena__mouth__0')return {talentName:key,imagePath:'reference.png'};
      return next(key,...args);
    }});
    try{
      const request=await upgrade.prepare({imageKey:'situation_fluid__elena__mouth__1',prompt:'mouth'});
      checks.img2imgPrepared=request.referenceKey==='situation_fluid__elena__mouth__0'&&request.denoise===0.28&&request.referencePath==='reference.png';
      const ordinary=await upgrade.prepare({imageKey:key,prompt:'ordinary'});
      checks.ordinaryGenerationUnchanged=!ordinary.referenceKey;
      const template=globalThis.__WW_IMAGESTUDIO_H_STATUS_TEMPLATES__;
      try{
        globalThis.__WW_IMAGESTUDIO_H_STATUS_TEMPLATES__={format:1,defaultSource:'elena',sources:[{id:'elena'}],
          characterPlaceholder:'{{character}}',characterIdPlaceholder:'{{id}}',branches:[{id:'test-mouth',label:'입',count:1,weight:1,
          entries:{'situation_fluid__{{id}}__mouth__1':{prompt:'{{character}}, mouth'}},overrides:{}}]};
        const plan=await WW_ImageStudioBridge.hStatusPlan('elena',['test-mouth'],{source:'elena',profile:{prompt:'test character'}});
        checks.bulkImg2imgPrepared=plan.items.length===1&&plan.items[0].referenceKey===request.referenceKey
          &&plan.items[0].referencePath===request.referencePath&&plan.items[0].denoise===request.denoise;
      }finally{globalThis.__WW_IMAGESTUDIO_H_STATUS_TEMPLATES__=template;}
      const originalFetch=fetch,originalConnection=WW_ImageStudioBridge.connection;
      let payload;
      WW_ImageStudioBridge.connection=()=>({baseUrl:location.origin,comfyui:true});
      globalThis.fetch=(input,options={})=>{
        const route=new URL(String(input),location.href).pathname;
        const respond=body=>Promise.resolve(new Response(JSON.stringify(body),{headers:{'Content-Type':'application/json'}}));
        if(route==='/api/studio/drafts')return respond({supportsReviewDrafts:true,supportsImg2img:true,entries:[]});
        if(route==='/api/image/generate'){
          payload=JSON.parse(options.body);
          return respond({status:'completed',reviewOnly:true,draftId:'reference-test',imageUrl:'/missing-test.webp'});
        }
        return originalFetch(input,options);
      };
      try{
        await WW_ImageStudioPrompt.generate({imageKey:'situation_fluid__elena__mouth__1',prompt:'mouth'});
        checks.directReviewImg2imgPrepared=payload.referenceKey===request.referenceKey&&payload.referencePath===request.referencePath
          &&payload.denoise===request.denoise&&payload.reviewOnly===true;
      }finally{globalThis.fetch=originalFetch;WW_ImageStudioBridge.connection=originalConnection;}
    }finally{unhook();}
    return {checks,detail:{worn:worn.prompt,removed:removed.prompt,first,edited:edited.key,bounds:{left:bounds.left,right:bounds.right}}};
  `});
  assert.equal(value.pageErrorsSoFar,0,JSON.stringify(value));
  const failures=Object.entries(value.result.checks).filter(([,passed])=>passed!==true);
  assert.deepEqual(failures,[],JSON.stringify(value.result));
  assert.deepEqual((await playStatus({})).pageErrors,[]);
  console.log('PASS',Object.keys(value.result.checks).length,'equipment / semantic key / grouping / preset / people UI / img2img checks',mobile?'(390px)':'(PC)');
} finally { await shutdown();setTimeout(()=>process.exit(process.exitCode||0),200).unref(); }
