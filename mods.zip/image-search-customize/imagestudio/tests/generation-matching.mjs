// 실행: node wml/mods/imagestudio/tests/generation-matching.mjs [--mobile]
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { playStart, playEval, playReload, playStop } from '../../../../MCP/lib/play.mjs';

const session = 'imagestudio-generation-matching';
const viewport = process.argv.includes('--mobile') ? { width: 390, height: 844 } : { width: 1500, height: 950 };
const editor = 'imagestudio-compatible-attention-image-prompt';
const source = fs.readFileSync(new URL('../source/image-matching.js', import.meta.url), 'utf8');
const matcher = vm.runInNewContext(source + '\nImageStudio_매칭엔진만들기();');
const config = matcher.defaults();
// 토글 도입 전 설정과 명시적으로 저장한 꺼짐을 구분하며 잘못된 값은 거부합니다.
const legacyConfig = { ...config }; delete legacyConfig.enabled;
assert.equal(matcher.normalize(legacyConfig).enabled, true);
assert.equal(matcher.normalize({ ...config, enabled: false }).enabled, false);
assert.throws(() => matcher.normalize({ ...config, enabled: 'false' }), /체크박스/);
const key = 'elena__task-idle__outfit-modest__room-taproom__v-0';
const context = { emotions: ['happy'], badguest: [], pregnancy: 'none', detail: [] };
const spec = matcher.describe(key, context);
let seed = 1138;
const random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
let listed;
vm.runInNewContext(fs.readFileSync(new URL('../../mods.js', import.meta.url), 'utf8'), { WML: { folders() {}, enable: values => { listed = values; } } });
const disabled = Object.fromEntries([...listed.map(value => value.replace(/:off$/, '')), editor].map(id => [id, false]));

// 1. 정확 일치는 비필수 항목·추가 조건도 확인하며, 변형 번호만 달라진 이미지는 재사용합니다.
const entry = { talentName: key.replace('__v-0', '__v-7'), imagePath: 'test.png', matching: context };
assert.equal(matcher.ImageStudio_정확이미지고르기(spec, [entry], config)?.entry, entry);
for (const [original, replacement] of [
  ['task-idle', 'task-resting'], ['outfit-modest', 'outfit-lingerie'], ['room-taproom', 'room-back_room'],
  ['__v-0', '__mood-shy__v-0'], ['__v-0', '__exp-0100000__v-0'], ['__v-0', '__aft-sweat__v-0'],
  ['__v-0', '__position-standing-prompt1__v-0'], ['__v-0', '__studio-prompt1__v-0'],
]) {
  const other = { ...entry, talentName: key.replace(original, replacement) };
  assert.equal(matcher.ImageStudio_정확이미지고르기(spec, [other], config), null, replacement);
}
for (const changed of [{ emotions: [] }, { badguest: ['state1'] }, { pregnancy: 'early' }, { detail: ['state2'] }]) {
  assert.equal(matcher.ImageStudio_정확이미지고르기(spec, [{ ...entry, matching: { ...context, ...changed } }], config), null);
}
assert.equal(matcher.ImageStudio_정확이미지고르기(spec, [{ ...entry, matching: undefined }], config), null);
const similar = { ...entry, talentName: key.replace('__v-0', '__mood-shy__v-0') };
assert.equal(matcher.choose(spec, [similar], config)?.entry, similar);
const variants = Array.from({ length: 6 }, (_, index) => ({ ...entry, talentName: key.replace('__v-0', '__v-' + index) }));
assert.ok(new Set(Array.from({ length: 30 }, () => matcher.ImageStudio_정확이미지고르기(spec, variants, config, () => null, random).entry.talentName)).size > 1);
console.log('PASS exact conditions / missing metadata / similar score / variant selection (seed 1138)');

async function ImageStudioTest_실행하기(code) {
  const value = await playEval({ id: session, code, timeoutMs: 30000 });
  assert.ok(!value.error, value.error);
  assert.equal(value.pageErrorsSoFar, 0, JSON.stringify(value));
  return value.result;
}

try {
  // 2. 빈 시험 저장소의 기본값과 안내를 확인합니다. 실제 사용자의 저장소를 열지 않습니다.
  await playStart({ id: session, viewport, mods: { ...disabled, 'addon-compat': true, imagestudio: true } });
  let result = await ImageStudioTest_실행하기(`
    WW_ImageStudio.open(); WW_ImageStudioMatching.open();
    return {failed:WML.status().failed,offline:__WW_STUDIO_OFFLINE_ONLY__,checked:document.querySelector('#wwis-offline-only').checked,
      note:document.querySelector('#wwis-generation-matching-note').textContent,
      matching:document.querySelector('.wwis-matching').textContent};
  `);
  assert.deepEqual(result.failed, []);
  assert.equal(result.offline, false);
  assert.equal(result.checked, false);
  assert.match(result.note, /조건 계산식/);
  assert.match(result.note, /유사하지만 다른 이미지/);
  assert.match(result.matching, /생성이 켜져 있으면/);
  console.log('PASS fresh default / gameplay explanation / matching settings explanation');

  // 3. 같은 시험을 본체 단독과 공통 편집기를 켠 상태에서 실행합니다.
  for (const withEditor of [false, true]) {
    if (withEditor) {
      await playStart({ id: session, viewport, mods: { ...disabled, 'addon-compat': true, imagestudio: true, 'attention-image-prompt':true, [editor]: true } });
      await ImageStudioTest_실행하기(`localStorage.setItem('wml.folders',JSON.stringify([${JSON.stringify(editor)}])); return true;`);
      await playReload({ id: session });
    }
    assert.equal(await ImageStudioTest_실행하기('return WW_ImageStudioBridge.extensions.list().editor;'), withEditor ? editor : null);
    result = await ImageStudioTest_실행하기(`
      const d=WML.dev(),settings=__WML_LEGACY__.get('Rt'),before=JSON.stringify(d.store.game());
      const bridge=WW_ImageStudioBridge,matching=WW_ImageStudioMatching;
      const saved={packs:bridge.packs,connection:bridge.connection,ready:bridge.ready,unavailable:bridge.generationUnavailable,fetch,mode:settings.getState().imageBackendMode,offline:__WW_STUDIO_OFFLINE_ONLY__};
      const key=${JSON.stringify(key)},context=${JSON.stringify(context)};
      const exactEntry={talentName:key.replace('__v-0','__v-5'),imagePath:'matching-test-exact.png',matching:context};
      const near={talentName:key.replace('__v-0','__mood-shy__v-0'),imagePath:'matching-test-near.png',matching:context};
      let packs=[],calls=0,lastRequest=null,failGeneration=false;
      const unhook=d.hook('imageGenerate',{priority:-1999999,around(next,request){calls++;lastRequest=request;return Promise.resolve(failGeneration?null:{url:'data:image/png;base64,test-generated',fresh:true});}});
      bridge.ready=()=>Promise.resolve();bridge.packs=()=>packs;
      bridge.connection=()=>({baseUrl:location.origin,comfyui:true});bridge.generationUnavailable=async()=>false;
      globalThis.fetch=(input,options={})=>{
        if(options.method==='HEAD')return Promise.resolve(new Response(null,{status:String(input).includes('missing-file')?404:200}));
        if(String(input).includes('/api/pack?'))return Promise.resolve(new Response('{"entries":{}}',{headers:{'Content-Type':'application/json'}}));
        return saved.fetch(input,options);
      };
      const choose=async(rows,mode,offline)=>{
        packs=[{entries:Object.fromEntries(rows.map((entry,index)=>[index,entry]))}];matching.refresh();
        settings.getState().set({imageBackendMode:mode});globalThis.__WW_STUDIO_OFFLINE_ONLY__=offline;
        const previous=calls,value=await d.fn('imageGenerate')({imageKey:key,prompt:'test',debug:{imageMatching:context}});
        return {url:value.url,missing:!!value.imageMatchingMissing,calls:calls-previous,mode:matching.last.mode};
      };
      try {
        const exact=await choose([exactEntry],'auto',false);
        const generate=await choose([near],'auto',false);
        const sentMetadata=JSON.stringify(lastRequest.debug.imageMatching)===JSON.stringify(context);
        const lookup=await d.fn('vy')(key);
        const secondLookupMissing=lookup===null;
        const missingFile=await choose([{...exactEntry,imagePath:'missing-file.png'}],'auto',false);
        failGeneration=true;
        const failedGeneration=await choose([near],'auto',false);
        failGeneration=false;
        const off=await choose([near],'off',false);
        const offline=await choose([near],'auto',true);
        const noFallback=await choose([],'off',false);
        bridge.generationUnavailable=async()=>true;
        const busy=await choose([near],'auto',false);
        bridge.generationUnavailable=async()=>false;
        bridge.connection=()=>({baseUrl:null,comfyui:false});
        const disconnected=await choose([near],'auto',false);
        bridge.connection=()=>({baseUrl:location.origin,comfyui:true});
        await choose([near],'off',false);
        settings.getState().set({imageBackendMode:'auto'});
        const start=calls,switched=await d.fn('imageGenerate')({imageKey:key,prompt:'test',debug:{imageMatching:context}});
        return {exact,generate,missingFile,failedGeneration,off,offline,noFallback,busy,disconnected,sentMetadata,secondLookupMissing,switched:switched.fresh&&calls===start+1,unchanged:before===JSON.stringify(d.store.game()),failed:WML.status().failed};
      } finally {
        unhook();bridge.packs=saved.packs;bridge.connection=saved.connection;bridge.ready=saved.ready;bridge.generationUnavailable=saved.unavailable;globalThis.fetch=saved.fetch;
        globalThis.__WW_STUDIO_OFFLINE_ONLY__=saved.offline;settings.getState().set({imageBackendMode:saved.mode});matching.refresh();
      }
    `);
    assert.deepEqual(result.failed, []);
    assert.equal(result.exact.calls, 0);
    assert.match(result.exact.url, /matching-test-exact/);
    assert.equal(result.exact.mode, 'exact');
    assert.equal(result.generate.calls, 1);
    assert.equal(result.missingFile.calls, 1);
    assert.equal(result.failedGeneration.calls, 1);
    assert.equal(result.failedGeneration.missing, true);
    assert.equal(result.sentMetadata, true);
    assert.equal(result.secondLookupMissing, true);
    for (const state of ['off', 'offline']) {
      assert.equal(result[state].calls, 0);
      assert.equal(result[state].mode, 'similar');
      assert.match(result[state].url, /matching-test-near/);
    }
    for (const state of ['noFallback', 'busy', 'disconnected']) {
      assert.equal(result[state].calls, 0);
      assert.equal(result[state].missing, true);
    }
    assert.equal(result.switched, true);
    assert.equal(result.unchanged, true);
    console.log('PASS ' + (withEditor ? 'with editor' : 'core only') + ': exact reuse / generation / off / offline / unavailable / mode cache / unchanged game');
  }

  // 4. 바닐라 함수 자체를 실행해 최고점·동점·최신 이미지·변형 번호 가산·증가 카운터를 확인합니다.
  result = await ImageStudioTest_실행하기(`
    const d=WML.dev(),parse=d.fn('rl'),index=d.fn('jot'),choose=d.fn('VD'),lookup=d.fn('Eot'),score=d.fn('Oot');
    const key=${JSON.stringify(key)},same={talentName:key,imagePath:'old.png',createdAt:1},newer={...same,imagePath:'new.png',createdAt:2};
    const rows=index([same,newer]);
    const request=parse(key),first={entry:{imagePath:'first.png'},spec:parse(key.replace('__v-0','__v-1'))};
    const second={entry:{imagePath:'second.png'},spec:{...first.spec}};
    const far={...first.spec,variant:3},near={...first.spec,variant:1};
    const counter1=d.fn('ey')(),counter2=d.fn('ey')();
    return {latest:lookup(rows,key).entry.imagePath,tied:choose(request,[first,second]).imagePath,
      closer:score(request,near)>score(request,far),counterDelta:counter2-counter1};
  `);
  assert.deepEqual(result, { latest: 'new.png', tied: 'first.png', closer: true, counterDelta: 1 });
  console.log('PASS vanilla: newest exact / first tied best / variant proximity / sequential counter');

  // 5. 탐색 체계 토글은 설정을 보존하면서 실제 조회·생성 훅을 기본 경로로 넘깁니다.
  result = await ImageStudioTest_실행하기(`
    WW_ImageStudio.open();
    const matching=WW_ImageStudioMatching,d=WML.dev(),check=document.querySelector('#wwis-image-matching-enabled');
    const order=document.querySelector('#wwis-lock-wife-outfit').closest('label').nextElementSibling.contains(check);
    const previous=matching.get();
    const changed={...previous,rules:{...previous.rules,mood:{...previous.rules.mood,exact:1234}}};
    matching.set(changed);
    check.checked=false;check.dispatchEvent(new Event('change'));
    let lookups=0,generations=0;
    const removeLookup=d.hook('Yp',{priority:-1999999,around(){lookups++;return {imagePath:'toggle-default.png'};}});
    const removeGenerate=d.hook('imageGenerate',{priority:-1999999,around(){generations++;return {url:'toggle-default.png',fresh:false};}});
    try{
      const entry=await d.fn('Yp')(${JSON.stringify(key)});
      const generated=await d.fn('imageGenerate')({imageKey:${JSON.stringify(key)}});
      return {order,enabled:matching.get().enabled,stored:JSON.parse(localStorage.getItem('wml.mod.imagestudio.image-matching')).enabled,
        score:matching.get().rules.mood.exact,entry:entry.imagePath,generated:generated.url,lookups,generations,
        resolved:await matching.resolve(${JSON.stringify(key)}),note:document.querySelector('#wwis-image-matching-status').textContent};
    }finally{removeLookup();removeGenerate();}
  `);
  assert.equal(result.order, true);
  assert.equal(result.enabled, false);
  assert.equal(result.stored, false);
  assert.equal(result.score, 1234);
  assert.equal(result.entry, 'toggle-default.png');
  assert.equal(result.generated, 'toggle-default.png');
  assert.equal(result.lookups, 1);
  assert.equal(result.generations, 1);
  assert.equal(result.resolved, null);
  assert.match(result.note, /기본 이미지 탐색/);
  console.log('PASS matching checkbox placement / bypass / preserved scoring');

  // 6. 실제 초상화의 프롬프트 요구를 발생시켜 통계 중지·재개와 기존 기록 보존을 확인합니다.
  result = await ImageStudioTest_실행하기(`
    const d=WML.dev(),React=d.fn('React'),mount=document.createElement('div');
    document.body.append(mount);
    const root=__WML_LEGACY__.get('i9').createRoot(mount);
    d.store.get().newGame();
    d.store.set({started:true,selectingArchetype:false,selectingBuilder:false,selectingPicks:false});
    await WW_ImageStudioUsage.ready;
    const wife=d.store.game().characters[d.store.game().primaryCharacterId];
    let requestKey='elena__task-idle__outfit-modest__room-taproom__studio-usage-toggle-a__v-0',sequence=0;
    const stopPrompt=d.hook('imagePrompt',{priority:1000000,replace:()=>({key:requestKey,prompt:'usage toggle test',negativePrompt:''})});
    const stopPortrait=d.hook('rv',{priority:1000000,around:()=>{d.fn('imagePrompt')(wife,'taproom');return null;}});
    const draw=async()=>{root.render(React.createElement(d.fn('rv'),{key:++sequence}));await new Promise(resolve=>setTimeout(resolve,80));};
    const read=async()=>{const data=await WW_ImageStudioUsage.snapshot();return data.events.filter(event=>event.key.includes('__studio-usage-toggle-'));};
    const checkbox=()=>document.querySelector('[data-wwis-usage-enabled]');
    const set=async enabled=>{checkbox().checked=enabled;checkbox().dispatchEvent(new Event('change'));await new Promise(resolve=>setTimeout(resolve,80));};
    try{
      WW_ImageStudioUsage.open();await new Promise(resolve=>setTimeout(resolve,80));
      const top=checkbox().closest('label').parentElement.firstElementChild.contains(checkbox());
      const defaultOn=checkbox().checked;
      await draw();const before=await read();
      await set(false);requestKey=requestKey.replace('toggle-a','toggle-b');await draw();const paused=await read();
      const oldRecordsVisible=!!document.querySelector('[data-wwis-usage-export=json]');
      await set(true);await draw();const resumed=await read();
      await set(false);
      return {top,defaultOn,before:before.length,paused:paused.length,resumed:resumed.length,oldRecordsVisible,
        preserved:before.every(entry=>resumed.some(next=>entry.id===next.id)),stored:JSON.parse(localStorage.getItem('wml.mod.imagestudio')).usageStatisticsEnabled};
    }finally{root.unmount();mount.remove();stopPrompt();stopPortrait();}
  `);
  assert.equal(result.top, true);
  assert.equal(result.defaultOn, true);
  assert(result.before > 0);
  assert.equal(result.paused, result.before);
  assert(result.resumed > result.paused);
  assert.equal(result.oldRecordsVisible, true);
  assert.equal(result.preserved, true);
  assert.equal(result.stored, false);
  console.log('PASS usage checkbox placement / stop / resume / preserved history');

  // 7. 체크 상태와 사용자 점수는 다시 불러온 초기 조회부터 보존됩니다.
  await ImageStudioTest_실행하기(`WW_ImageStudio.open();const check=document.querySelector('#wwis-offline-only');check.checked=true;check.dispatchEvent(new Event('change'));return true;`);
  await playReload({ id: session });
  result = await ImageStudioTest_실행하기(`return {offline:__WW_STUDIO_OFFLINE_ONLY__,stored:localStorage.getItem('ww-image-studio-offline-only-v1'),checked:document.querySelector('#wwis-offline-only').checked};`);
  assert.deepEqual(result, { offline: true, stored: 'true', checked: true });
  result = await ImageStudioTest_실행하기(`
    WW_ImageStudioUsage.open();await new Promise(resolve=>setTimeout(resolve,80));
    return {matching:WW_ImageStudioMatching.get().enabled,checked:document.querySelector('#wwis-image-matching-enabled').checked,
      score:WW_ImageStudioMatching.get().rules.mood.exact,usage:document.querySelector('[data-wwis-usage-enabled]').checked};
  `);
  assert.deepEqual(result, { matching: false, checked: false, score: 1234, usage: false });
  console.log('PASS saved offline preference survives reload');
} finally {
  await playStop({ id: session });
}
