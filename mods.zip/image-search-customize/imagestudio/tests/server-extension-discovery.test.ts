import { test, expect } from 'bun:test'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { registerCompatibilityExtensions } from '../backend/wayward-imagegen/src/server.ts'

test('server discovers both compatibility folder naming orders', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'imagestudio-extension-discovery-'))
  try {
    for (const name of ['imagestudio-compatible-animal', 'ranch-compatible-imagestudio']) {
      const files = path.join(root, name, 'files')
      fs.mkdirSync(files, { recursive: true })
      fs.writeFileSync(path.join(files, 'server.ts'),
        `export const extensionApiVersion=1; export function registerImageStudioExtension(){}`)
    }
    fs.mkdirSync(path.join(root, 'unrelated-compatible-mod', 'files'), { recursive: true })
    fs.writeFileSync(path.join(root, 'unrelated-compatible-mod', 'files', 'server.ts'),
      `export const extensionApiVersion=1; export function registerImageStudioExtension(){throw Error('must not load')}`)
    const loaded = await registerCompatibilityExtensions({} as never, {} as never, {} as never, root)
    expect(loaded).toEqual(['imagestudio-compatible-animal', 'ranch-compatible-imagestudio'])
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})
