import { test, expect } from 'bun:test'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { saveImage } from '../backend/wayward-imagegen/src/comfy/media.ts'
import { CacheStore } from '../backend/wayward-imagegen/src/cache/cacheStore.ts'
import { buildHStatusPack } from '../backend/wayward-imagegen/src/routes/customPack.ts'
import type { Config } from '../backend/wayward-imagegen/src/config.ts'

const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aZu0AAAAASUVORK5CYII=', 'base64')

test('H_Status saves each branch and builds a character pack including existing flat paths', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'studio-h-status-storage-'))
  try {
    const imagesDir = path.join(root, 'images')
    const modDir = path.join(root, 'wml/mods/h-status')
    fs.mkdirSync(modDir, { recursive: true })
    fs.mkdirSync(imagesDir, { recursive: true })
    fs.writeFileSync(path.join(modDir, 'mod.js'), '// isolated fixture')
    const cache = new CacheStore({ imagesDir, repairConvertedPaths: false, migrateLegacy: false }).load()
    for (const character of ['hina', 'mari']) {
      for (const kind of ['fluid', 'vulva', 'status', 'observation', 'event']) {
        const branch = ['fluid', 'vulva'].includes(kind) ? 'info' : kind
        const talentName = `situation_${kind}__${character}__fixture-${kind}`
        const media = await saveImage({ imagesDir, bytes: png, talentName, imageType: 'portrait', workflow: 'anima', characters: [character], now: () => 123 })
        expect(media.relativePath.startsWith(`illustrious/situation/${branch}/${character}/`)).toBe(true)
        expect(fs.readFileSync(media.absolutePath)).toEqual(png)
        cache.add({ talentName, imagePath: media.relativePath, imageType: 'portrait', promptHash: kind, prompt: 'fixture', workflow: 'anima' })
      }
    }
    const legacy = 'illustrious/situation/hina/legacy.png'
    fs.mkdirSync(path.dirname(path.join(imagesDir, legacy)), { recursive: true })
    fs.writeFileSync(path.join(imagesDir, legacy), png)
    cache.add({ talentName: 'situation_status__hina__legacy', imagePath: legacy, imageType: 'portrait', promptHash: 'legacy', prompt: 'fixture', workflow: 'illustrious' })
    const config = { stateDir: path.join(root, 'state') } as Config
    expect(buildHStatusPack(config, cache, 'hina').images).toBe(6)
    expect(buildHStatusPack(config, cache, 'mari').images).toBe(5)
    expect(fs.readFileSync(path.join(modDir, 'images-situation-hina.js'), 'utf8')).not.toContain('__mari__')
    const restored = new CacheStore({ imagesDir, repairConvertedPaths: false, migrateLegacy: false }).load()
    expect(buildHStatusPack(config, restored, 'hina').images).toBe(6)
    expect(fs.existsSync(path.join(imagesDir, legacy))).toBe(true)
    const normal = await saveImage({ imagesDir, bytes: png, talentName: 'hina__task-idle__outfit-modest', imageType: 'portrait', workflow: 'illustrious', characters: ['hina'] })
    expect(normal.relativePath.startsWith('illustrious/characters/hina/')).toBe(true)
    const upper = await saveImage({ imagesDir, bytes: png, talentName: 'SITUATION_FLUID__HINA__fixture', imageType: 'portrait', workflow: 'illustrious', characters: ['hina'] })
    expect(upper.relativePath.startsWith('illustrious/situation/info/hina/')).toBe(true)
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})

test('legacy unknown-folder migration uses branches and preserves destination collisions', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'studio-h-status-migrate-'))
  try {
    const imagesDir = path.join(root, 'images')
    fs.mkdirSync(path.join(imagesDir, 'illustrious/characters/unknown'), { recursive: true })
    const entries: Record<string, object> = {}
    for (const kind of ['fluid', 'vulva', 'status', 'observation', 'event']) {
      const imagePath = `illustrious/characters/unknown/${kind}.png`
      fs.writeFileSync(path.join(imagesDir, imagePath), png)
      entries[kind] = { talentName: `situation_${kind}__hina__fixture`, imagePath, imageType: 'portrait', promptHash: kind, prompt: 'fixture', createdAt: 1 }
    }
    const collision = path.join(imagesDir, 'illustrious/situation/status/hina/status.png')
    fs.mkdirSync(path.dirname(collision), { recursive: true })
    fs.writeFileSync(collision, 'existing different image')
    fs.writeFileSync(path.join(imagesDir, '.image-cache_H-Status_cache.json'), JSON.stringify({ version: 1, entries }))
    const cache = new CacheStore({ imagesDir, repairConvertedPaths: false }).load()
    for (const kind of ['fluid', 'vulva', 'observation', 'event']) {
      const branch = ['fluid', 'vulva'].includes(kind) ? 'info' : kind
      expect(cache.entries[kind].imagePath).toBe(`illustrious/situation/${branch}/hina/${kind}.png`)
      expect(fs.readFileSync(path.join(imagesDir, cache.entries[kind].imagePath))).toEqual(png)
    }
    expect(cache.entries.status.imagePath).toBe('illustrious/characters/unknown/status.png')
    expect(fs.readFileSync(collision, 'utf8')).toBe('existing different image')
    expect(new CacheStore({ imagesDir, repairConvertedPaths: false }).load().entries.event.imagePath).toBe('illustrious/situation/event/hina/event.png')
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})
