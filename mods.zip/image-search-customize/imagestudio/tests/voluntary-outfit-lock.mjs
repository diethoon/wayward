// 실행: node wml/mods/imagestudio/tests/voluntary-outfit-lock.mjs [--mobile]
// 기본 통합 모드의 격리 게임에서 검사합니다. seed=1138, 실제 세이브·서버·이미지 생성 변경 없음.
import assert from 'node:assert/strict';
import { playStart, playEval, playReload, shutdown } from '../../../../MCP/lib/play.mjs';

const session = 'imagestudio-voluntary-outfit';
const viewport = process.argv.includes('--mobile') ? { width: 390, height: 844 } : { width: 1500, height: 950 };
const stopped = ['security_cover_up', 'desire_dress_bolder', 'afternoon_try_on'];

try {
  const started = await playStart({ id: session, viewport });
  assert.deepEqual(started.failed, []);
  const checked = await playEval({ id: session, timeoutMs: 30000, code: `
    let seed=1138;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
    const d=WML.dev(),b=WW_ImageStudioBridge;
    b.setOutfitLock(false);
    const original=d.store.game(),id=original.primaryCharacterId,wife=original.characters[id];
    const state={...original,phase:'prep',pendingEvent:undefined,activeScene:undefined,slot:120,
      ownedOutfits:['modest','serving_dress'],characters:{...original.characters,[id]:{...wife,
        outfit:'modest',currentTask:'idle',retiredAtSlot:undefined,busyUntilSlot:0,
        traits:{...wife.traits,openness:95,confidence:95},relationship:{...wife.relationship,trust:100},
        stats:{...wife.stats,mood:95,energy:100,arousal:0}}}};
    d.store.update(()=>state);
    const allActions=d.fn('F1')().map(action=>action.id);
    WW_ImageStudio.open();
    const box=document.querySelector('#wwis-lock-wife-outfit');
    const label=box.parentElement.textContent,help=box.parentElement.title;
    box.checked=true;box.dispatchEvent(new Event('change',{bubbles:true}));
    const enabledActions=d.fn('F1')().map(action=>action.id);
    const inputBefore=JSON.stringify(d.store.game());
    const automatic=d.fn('U8')(d.store.game());
    const sourcePreserved=inputBefore===JSON.stringify(d.store.game());
    // 남편의 실제 의상 제안 결과를 게임의 공통 응답 적용 경로로 처리합니다.
    const response=d.fn('playerActionRespond')(d.store.game(),'suggest_outfit_serving_dress');
    const manual=d.fn('E3')(d.store.game(),response);
    d.store.update(()=>manual);
    const manualOutfit=manual.characters[id].outfit,manualAnchor=manual.mods.imagestudio.outfitLock.outfit;
    const nextAutomatic=d.fn('U8')(manual);
    const noCover=d.fn('d6')(manual,'duress');
    const shopping={...manual,activeShoppingSession:{previousOutfit:manualOutfit,purchasedThisSession:false}};
    const tried=d.fn('dCe')(shopping,'modest'),leftShop=d.fn('mCe')(tried);
    const nightResponse=d.fn('playerActionRespond')(manual,'suggest_outfit_nightshift');
    const manualNight=d.fn('E3')(manual,nightResponse);
    const manualNightChoice=d.fn('U8')(manualNight);
    const inBath=d.fn('moveWife')(manual,'bathroom');
    const bath=d.fn('vje')(inBath),afterBath=d.fn('T3')(bath);
    const bathWear=d.fn('outfitById')(bath.characters[id].outfit)?.wear;
    const sleep=d.fn('updateWife')(manual,c=>({...c,outfit:'nightshift',currentTask:'sleeping'}));
    const sleepAnchor=sleep.mods.imagestudio.outfitLock.outfit,wakeOutfit=d.fn('U8')(sleep);
    const manualOther=d.fn('updateCharacter')(manual,id,c=>({...c,outfit:'modest'}));
    const otherId='outfit-other-1138';
    const others={...manualOther,characters:{...manualOther.characters,[otherId]:{...wife,id:otherId,outfit:'modest'}}};
    const changedOther=d.fn('updateCharacter')(others,otherId,c=>({...c,outfit:'serving_dress'}));
    // 의상 변경을 포함하지 않은 거절 응답에 환복을 강제하지 않는지도 확인합니다.
    const refused=d.fn('E3')(manual,{response:'refuse',logText:'test refusal',playerStatDeltas:{},wifeStatDeltas:{},wifeTraitDeltas:{}});
    box.checked=false;box.dispatchEvent(new Event('change',{bubbles:true}));
    const disabledActions=d.fn('F1')().map(action=>action.id);
    const cleared=d.store.game().mods.imagestudio.outfitLock===undefined;
    const offChoice=d.fn('U8')({...sleep,ownedOutfits:['modest']});
    box.checked=true;box.dispatchEvent(new Event('change',{bubbles:true}));
    return {label,help,allActions,enabledActions,automatic,sourcePreserved,responseOutfit:response.outfitChange,
      manualOutfit,manualAnchor,nextAutomatic,coverUnchanged:noCover.state===manual&&noCover.target===null,
      tried:tried.characters[id].outfit,leftShop:leftShop.characters[id].outfit,manualNight:manualNight.characters[id].outfit,manualNightChoice,
      bathWear,afterBath:afterBath.characters[id].outfit,sleepOutfit:sleep.characters[id].outfit,sleepAnchor,wakeOutfit,
      updateCharacterAllowed:manualOther.characters[id].outfit,otherOutfit:changedOther.characters[otherId].outfit,
      otherKeepsAnchor:changedOther.mods.imagestudio.outfitLock.outfit===manualOther.mods.imagestudio.outfitLock.outfit,
      refusedOutfit:refused.characters[id].outfit,disabledActions,cleared,offChoice};
  ` });
  assert.equal(checked.error, undefined, JSON.stringify(checked));
  assert.equal(checked.pageErrorsSoFar, 0);
  const r = checked.result;
  assert.equal(r.label, '아내가 자발적으로 옷을 갈아입지 못하게');
  assert.match(r.help, /남편이 지시/);
  for (const id of stopped) { assert.ok(r.allActions.includes(id)); assert.ok(!r.enabledActions.includes(id)); }
  assert.deepEqual(r.enabledActions, r.allActions.filter(id => !stopped.includes(id)));
  assert.equal(r.automatic, 'modest');
  assert.equal(r.sourcePreserved, true);
  assert.equal(r.responseOutfit, 'serving_dress');
  for (const key of ['manualOutfit', 'manualAnchor', 'nextAutomatic', 'afterBath', 'sleepAnchor', 'wakeOutfit', 'refusedOutfit']) assert.equal(r[key], 'serving_dress', key);
  assert.equal(r.coverUnchanged, true);
  assert.equal(r.tried, 'modest');
  assert.equal(r.leftShop, 'serving_dress');
  assert.equal(r.manualNight, 'nightshift');
  assert.equal(r.manualNightChoice, 'nightshift');
  assert.equal(r.bathWear, 'bath');
  assert.equal(r.sleepOutfit, 'nightshift');
  assert.equal(r.updateCharacterAllowed, 'modest');
  assert.equal(r.otherOutfit, 'serving_dress');
  assert.equal(r.otherKeepsAnchor, true);
  assert.deepEqual(r.disabledActions, r.allActions);
  assert.equal(r.cleared, true);
  assert.equal(r.offChoice, 'modest');
  console.log('PASS voluntary candidates / daily selection / husband instruction / refusal / manual update / bath and sleep / unrelated characters / OFF');
  await playReload({ id: session });
  const reloaded = await playEval({ id: session, code: `WW_ImageStudio.open();return {checked:document.querySelector('#wwis-lock-wife-outfit').checked,actions:WML.dev().fn('F1')().map(action=>action.id),failed:WML.status().failed};` });
  assert.equal(reloaded.pageErrorsSoFar, 0);
  assert.equal(reloaded.result.checked, true);
  assert.deepEqual(reloaded.result.failed, []);
  for (const id of stopped) assert.ok(!reloaded.result.actions.includes(id));
  console.log('PASS stored toggle / reload / integrated mod load');
} finally {
  await shutdown();
  setTimeout(() => process.exit(process.exitCode || 0), 200).unref();
}
