// 원인 분석 전용. 제품 파일은 바꾸지 않고 격리 브라우저에 계측본을 제공합니다.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {registerHooks,createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=fileURLToPath(new URL('../../../../',import.meta.url));
const control=process.argv.includes('--control'),plain=process.argv.includes('--plain');
const fallback=createRequire(path.join(root,'wayward-wml-ko_old/MCP/package.json'));
const files=['imagestudio','imagestudio-compatible-attention-image-prompt'];
const originals=Object.fromEntries(files.map(id=>[id,fs.readFileSync(path.join(root,'wml/mods',id,'mod.js'),'utf8')]));
const targets=['ImageStudio_기본프롬프트수집하기','ImageStudio_편집창열기','ImageStudio_검수창그리기','ImageStudio_특정장면폼만들기','ImageStudio_현재장면읽기','renderSettings','renderCharacterPrompt','renderTagLibrary','ImageStudio_기본축항목읽기','ImageStudio_추가조건목록읽기','ImageStudio_기본축프롬프트기록하기','ImageStudio_기본축설정읽기','ImageStudio_계획프롬프트추가하기','ImageStudio_기본축수정목록읽기','ImageStudio_기본축프롬프트적용하기','refreshImageStudioOutfits'];
const served=Object.fromEntries(files.map(id=>{let s=originals[id];for(const name of plain?[]:targets){const needle='function '+name+'(';if(!s.includes(needle))continue;const label=id+':'+name;s=s.replace(needle,`function ${name}(...args){const t=performance.now();try{return __profile_${name}(...args);}finally{globalThis.__promptPerf?.add(${JSON.stringify(label)},performance.now()-t);}}\nfunction __profile_${name}(`);}return[id,s];}));
const playUrl=new URL('../../../../MCP/lib/play.mjs',import.meta.url);
served.imagestudio=served.imagestudio.replace("panel = api.ui.window({ id: 'prompt-review'", "panel = globalThis.__promptPerf.panel = api.ui.window({ id: 'prompt-review'");
for(const [name,binding] of [['imagePlanner','imagePlanner'],['appendImagePlan','imagePlannerAppend']]){
 const needle=`const ${name} = api.fn('${binding}');`;assert.ok(served.imagestudio.includes(needle));
 served.imagestudio=served.imagestudio.replace(needle,`const __base_${name}=api.fn('${binding}');let __initialized_${name}=false;
 const ${name}=(...args)=>{if(${control}&&${JSON.stringify(name)}==='imagePlanner'&&Array.isArray(args[0]?.kinds)&&args[0].kinds.length===0){if(__initialized_${name})return [];__initialized_${name}=true;}const t=performance.now();try{return __base_${name}(...args);}finally{globalThis.__promptPerf?.add('local.${name}',performance.now()-t);}};`);
}
globalThis.__promptSources=served;
const hook=registerHooks({resolve(s,c,n){try{return n(s,c);}catch(e){if(e.code==='ERR_MODULE_NOT_FOUND')return n(pathToFileURL(fallback.resolve(s)).href,c);throw e;}},load(url,c,next){const r=next(url,c);if(url!==playUrl.href)return r;let s=String(r.source);s=s.replace('  const page = await context.newPage();','  const page = await context.newPage();globalThis.__promptPage=page;');const anchor='    if (isBlocked(u, `http://127.0.0.1:${port}`))';assert.equal(s.split(anchor).length,2);s=s.replace(anchor,"    const fixtureId=new URL(u).pathname.match(/^\\/wml\\/mods\\/([^/]+)\\/mod.js$/)?.[1];\n    if(globalThis.__promptSources[fixtureId])req.respond({status:200,contentType:'text/javascript',body:globalThis.__promptSources[fixtureId]}).catch(()=>{});\n    else if (isBlocked(u, `http://127.0.0.1:${port}`))");return{...r,source:s};}});
const {playStart,playEval,playStatus,shutdown}=await import(playUrl.href);
const report={dateKST:'20261030',control,plain,method:'Fresh isolated PC browser, default mods, new game. Local wrappers measure inclusive durations; nested measurements must not be summed. --plain omits function-declaration wrappers but keeps boundary timers; --control reuses only the first empty planner initialization in browser memory. No product changes/GPU/user saves. These control timings are diagnostic, not validated fixes.',hashes:Object.fromEntries(files.map(id=>[id,createHash('sha256').update(originals[id]).digest('hex')])),runs:[]};
const evaluate=async(code)=>{const r=await playEval({code,timeoutMs:55000});assert.equal(r.pageErrorsSoFar,0,JSON.stringify(r));return r.result;};
try{
 const start=await playStart();assert.deepEqual(start.failed,[]);report.loaded=start.loaded;
 await evaluate(`globalThis.__promptPerf={stats:{},add(name,ms){const r=this.stats[name]||={n:0,ms:0,max:0};r.n++;r.ms+=ms;r.max=Math.max(r.max,ms);}};
 const d=WML.dev();d.fn('settingsStore').getState().set({imageBackendMode:'off',ageAffirmed:true,contentAcknowledged:true});
 d.store.get().newGame();d.fn('store').setState({started:true,selectingArchetype:false,selectingBuilder:false,selectingPicks:false});
 await new Promise(r=>setTimeout(r,120));[...document.querySelectorAll('button')].find(b=>b.textContent==='건너뛰기')?.click();
 await new Promise(r=>setTimeout(r,300));WW_ImageStudio.open();await new Promise(r=>setTimeout(r,500));return true;`);
 await evaluate(`const d=WML.dev();for(const name of ['ert','Xst','dd','mu'])d.hook(name,{priority:-9000000,around(next,...args){const t=performance.now();try{return next(...args);}finally{__promptPerf.add('game.'+name,performance.now()-t);}}});return true;`);
 const cdp=await globalThis.__promptPage.createCDPSession();await cdp.send('Profiler.enable');
 for(const label of ['first','reopen','reopen2']){
  await cdp.send('Profiler.start');
  const data=await evaluate(`__promptPerf.stats={};const b=WW_ImageStudioBridge,base={};
   for(const name of ['collectPromptDefaults','axes','packs']){const original=b[name];b[name]=function(...args){const t=performance.now();try{return original.apply(this,args);}finally{__promptPerf.add('bridge.'+name,performance.now()-t);}};base[name]=original;}
   const editor=b.extensions.editor,render=editor.render;editor.render=(...args)=>{const t=performance.now();try{return render(...args);}finally{__promptPerf.add('editor.render',performance.now()-t);}};
   const t=performance.now();document.querySelector('#wwis-prompt-edit').click();const syncMs=performance.now()-t;
   await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));const untilFrameMs=performance.now()-t;
   const result={syncMs,untilFrameMs,nodes:document.querySelector('[data-wwis-prompt-editor]')?.querySelectorAll('*').length,specificNodes:document.querySelector('.wwis-specific-builder')?.querySelectorAll('*').length,stats:__promptPerf.stats};
   for(const [name,original]of Object.entries(base))b[name]=original;editor.render=render;
   __promptPerf.panel.close();
   return result;`);
  const {profile}=await cdp.send('Profiler.stop');const samples=new Map(),nodes=new Map(profile.nodes.map(n=>[n.id,n]));
  for(let i=0;i<(profile.samples||[]).length;i++){const id=profile.samples[i];samples.set(id,(samples.get(id)||0)+(profile.timeDeltas?.[i]||0));}
  data.cpuTop=[...samples].sort((a,b)=>b[1]-a[1]).slice(0,25).map(([id,us])=>({function:nodes.get(id).callFrame.functionName,ms:us/1000,url:nodes.get(id).callFrame.url?.slice(-90)}));
  report.runs.push({label,...data});console.log(JSON.stringify({label,...data}));
 }
 report.status=await playStatus();report.sourceUnchanged=files.every(id=>fs.readFileSync(path.join(root,'wml/mods',id,'mod.js'),'utf8')===originals[id]);
 const out=path.join(root,'wml/mods/imagestudio/reports/prompt-open-20261030.json');
 const previous=fs.existsSync(out)?JSON.parse(fs.readFileSync(out,'utf8')):{};
 const cases=previous.cases||{};cases[control?'control':plain?'plain':'detail']=report;
 fs.writeFileSync(out,JSON.stringify({dateKST:'20261030',cases},null,2)+'\n');
}finally{await shutdown();hook.deregister();delete globalThis.__promptSources;setTimeout(()=>process.exit(process.exitCode||0),200).unref();}
