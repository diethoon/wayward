// node wml/mods/imagestudio/tests/prompt-open-responsive.mjs [--mobile]
// 이전 ZIP 대비 기본값 동등성, 즉시 열기·프레임 양보·취소/재개·입력 보존을 검사합니다.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {registerHooks,createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=fileURLToPath(new URL('../../../../',import.meta.url)),mod=path.join(root,'wml/mods/imagestudio');
const req=createRequire(path.join(root,'wayward-wml-ko_old/MCP/package.json'));
const archive=path.join(mod,'imagestudio-1.31.14-pre7.1.zip').replaceAll("'","''");
const ps=`Add-Type -AssemblyName System.IO.Compression.FileSystem;$z=[IO.Compression.ZipFile]::OpenRead('${archive}');try{$r=[IO.StreamReader]::new($z.GetEntry('mod.js').Open());try{[Console]::Out.Write($r.ReadToEnd())}finally{$r.Dispose()}}finally{$z.Dispose()}`;
const before=execFileSync('powershell.exe',['-NoProfile','-EncodedCommand',Buffer.from(ps,'utf16le').toString('base64')],{encoding:'utf8',maxBuffer:5e6});
const after=fs.readFileSync(path.join(mod,'mod.js'),'utf8');
let served='';globalThis.__promptReadySource=()=>served;
let editor=fs.readFileSync(path.join(root,'wml/mods/imagestudio-compatible-attention-image-prompt/mod.js'),'utf8');
const mark='host.axes = ImageStudio_추가조건목록읽기;';assert.ok(editor.includes(mark));
globalThis.__promptEditorSource=editor.replace(mark,mark+`\nglobalThis.__promptDefaults=()=>({axes:Object.fromEntries(Object.entries(ImageStudio_기본축기본값).map(([key,map])=>[key,Object.fromEntries([...map].sort())])),variants:Object.fromEntries([...ImageStudio_장면변형기본값].sort())});`);
const playUrl=new URL('../../../../MCP/lib/play.mjs',import.meta.url);
registerHooks({resolve(s,c,n){try{return n(s,c);}catch(e){if(e.code==='ERR_MODULE_NOT_FOUND')return n(pathToFileURL(req.resolve(s)).href,c);throw e;}},load(url,c,next){const r=next(url,c);if(url!==playUrl.href)return r;const anchor='    if (isBlocked(u, `http://127.0.0.1:${port}`))';let s=String(r.source);assert.equal(s.split(anchor).length,2);s=s.replace('  const page = await context.newPage();','  const page = await context.newPage();globalThis.__promptReadyPage=page;');return{...r,source:s.replace(anchor,"    if(new URL(u).pathname==='/wml/mods/imagestudio/mod.js')req.respond({status:200,contentType:'text/javascript',body:globalThis.__promptReadySource()}).catch(()=>{});\n    else if(new URL(u).pathname==='/wml/mods/imagestudio-compatible-attention-image-prompt/mod.js')req.respond({status:200,contentType:'text/javascript',body:globalThis.__promptEditorSource}).catch(()=>{});\n    else if (isBlocked(u, `http://127.0.0.1:${port}`))")};}});
const {playStart,playEval,playStatus,playStop,shutdown}=await import(playUrl.href);
const call=async(fn,args)=>{const r=await playEval({code:'return ('+fn.toString()+')('+JSON.stringify(args??null)+');',timeoutMs:55000});assert.equal(r.pageErrorsSoFar,0,JSON.stringify(r));return r.result;};
const mobile=process.argv.includes('--mobile'),report={dateKST:'20261030',mobile,results:[],hash:createHash('sha256').update(after).digest('hex')};
const instrument=source=>source.replace("panel = api.ui.window({ id: 'prompt-review'", "panel = globalThis.__promptReadyPanel = api.ui.window({ id: 'prompt-review'")
 .replace('ImageStudio_기본프롬프트수집완료 = !work.jobs.length;', '(globalThis.__promptSlices ||= []).push(performance.now()-start);ImageStudio_기본프롬프트수집완료 = !work.jobs.length;');
async function setup(){
 const d=WML.dev();let seed=1138;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 localStorage.setItem('wml.mod.imagestudio-compatible-attention-image-prompt',JSON.stringify({nativeAxisPrompts:{room:{taproom:{positivePrompt:'saved room prompt',negativePrompt:'saved room negative'}},situation:{idle:{variants:{'1':{positivePrompt:'saved variant prompt'}}}}}}));
 d.fn('settingsStore').getState().set({imageBackendMode:'off',ageAffirmed:true,contentAcknowledged:true});d.store.get().newGame();d.fn('store').setState({started:true,selectingArchetype:false,selectingBuilder:false,selectingPicks:false});
 await new Promise(r=>setTimeout(r,120));[...document.querySelectorAll('button')].find(b=>b.textContent==='건너뛰기')?.click();await new Promise(r=>setTimeout(r,250));WW_ImageStudio.open();await WW_ImageStudioBridge.ready();await new Promise(r=>setTimeout(r,500));return true;
}
async function open({isNew,priority}){
 globalThis.__promptChecks={gaps:[],last:performance.now(),initialGame:JSON.stringify(WML.dev().store.game()),initialSettings:localStorage.getItem('wml.mod.imagestudio-compatible-attention-image-prompt')};
 const c=__promptChecks;c.timer=setInterval(()=>{const now=performance.now();c.gaps.push(now-c.last);c.last=now;},10);
 const start=performance.now();document.querySelector('#wwis-prompt-edit').click();c.openMs=performance.now()-start;
 c.initialDone=WW_ImageStudioBridge.promptDefaultsStatus?.().done||0;
 if(priority){[...document.querySelectorAll('[data-wwis-prompt-editor] button')].find(b=>b.textContent===priority)?.click();
  const select=document.querySelector('[data-native-axis-prompt-source]');if(select?.options.length>1){select.selectedIndex=select.options.length-1;select.dispatchEvent(new Event('change',{bubbles:true}));}
 }
 await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));c.frameMs=performance.now()-start;
 return {openMs:c.openMs,frameMs:c.frameMs,initialDone:c.initialDone};
}
async function finish(isNew){
 const sleep=ms=>new Promise(r=>setTimeout(r,ms)),c=__promptChecks;
 if(isNew){const until=performance.now()+20000;while(!WW_ImageStudioBridge.promptDefaultsStatus().complete&&performance.now()<until)await sleep(30);}
 await sleep(80);clearInterval(c.timer);
 return {snapshot:__promptDefaults(),status:WW_ImageStudioBridge.promptDefaultsStatus?.(),maxGap:Math.max(...c.gaps),maxSlice:Math.max(...(globalThis.__promptSlices||[0])),slices:globalThis.__promptSlices?.length||0,ticks:c.gaps.length,gameUnchanged:c.initialGame===JSON.stringify(WML.dev().store.game()),settingsUnchanged:c.initialSettings===localStorage.getItem('wml.mod.imagestudio-compatible-attention-image-prompt')};
}
try{
 let reference;
 for(const [label,source,priority]of [['before',before,null],['after',after,null],['priority',after,'노출 상태 프롬프트'],['priority-room',after,'장소 프롬프트'],['priority-scene',after,'장면/작업 프롬프트']]){
  served=instrument(source);const started=await playStart({viewport:mobile?{width:390,height:844}:{width:1500,height:950}});assert.deepEqual(started.failed,[]);await call(setup);
  const opening=await call(open,{isNew:label!=='before',priority});const result=await call(finish,label!=='before');
  if(label==='before')reference=result.snapshot;else {assert.deepEqual(result.snapshot,reference,'기본 프롬프트 전체 동등성 '+label);assert.equal(result.status.complete,true);assert.equal(result.status.failed,0);assert.ok(opening.openMs<300,'창을 먼저 표시');assert.equal(opening.initialDone,0);assert.ok(result.ticks>20,'분할 사이 타이머 처리');}
  assert.equal(result.gameUnchanged,true);assert.equal(result.settingsUnchanged,true);report.results.push({label,...opening,...result,snapshot:undefined,loaded:started.loaded});console.log(JSON.stringify(report.results.at(-1)));await playStop();
 }
 // 닫기 중단/재개 및 수집 중 입력 보존은 별도 새 세션에서 검증합니다.
 served=instrument(after);await playStart({viewport:mobile?{width:390,height:844}:{width:1500,height:950}});await call(setup);await call(open,{isNew:true});
 const checks=await call(async()=>{
  const b=WW_ImageStudioBridge,sleep=ms=>new Promise(r=>setTimeout(r,ms));
  await sleep(100);__promptReadyPanel.close();await sleep(60);const paused=b.promptDefaultsStatus().done;await sleep(100);const stopped=b.promptDefaultsStatus().done===paused;
  const t=performance.now();document.querySelector('#wwis-prompt-edit').click();const reopenMs=performance.now()-t;
  [...document.querySelectorAll('[data-wwis-prompt-editor] button')].find(b=>b.textContent==='장소 프롬프트').click();
  const input=document.querySelector('[data-native-axis-prompt="room:positive"]');input.focus();input.value='unsaved probe prompt';input.dispatchEvent(new Event('input',{bubbles:true}));
  const until=performance.now()+20000;while(!b.promptDefaultsStatus().complete&&performance.now()<until)await sleep(30);
  const unsavedPreserved=input.isConnected&&input.value==='unsaved probe prompt';
  input.dispatchEvent(new Event('change',{bubbles:true}));await sleep(60);
  const saved=JSON.parse(localStorage.getItem('wml.mod.imagestudio-compatible-attention-image-prompt')).nativeAxisPrompts.room;
  const persisted=Object.values(saved).some(v=>v.positivePrompt==='unsaved probe prompt');
  __promptReadyPanel.close();document.querySelector('#wwis-prompt-edit').click();await sleep(50);
  const warm=!!document.querySelector('[data-wwis-defaults-progress][data-complete="true"]');
  clearInterval(__promptChecks.timer);return {stopped,paused,reopenMs,unsavedPreserved,persisted,warm,status:b.promptDefaultsStatus()};
 });
 for(const k of ['stopped','unsavedPreserved','persisted','warm'])assert.equal(checks[k],true,k);assert.ok(checks.paused>0&&checks.paused<checks.status.total);report.checks=checks;report.status=await playStatus();console.log(JSON.stringify(checks));
 await playStop();
 const appendNeedle="const appendImagePlan = api.fn('imagePlannerAppend');";assert.ok(after.includes(appendNeedle));
 served=instrument(after.replace(appendNeedle,"const actualAppend=api.fn('imagePlannerAppend');const appendImagePlan=(...args)=>{if(globalThis.__promptFailure){globalThis.__promptFailure=false;throw Error('test-only collection failure');}return actualAppend(...args);};"));
 await playStart({viewport:mobile?{width:390,height:844}:{width:1500,height:950}});await call(setup);await call(()=>{globalThis.__promptFailure=true;});await call(open,{isNew:true});
 await call(()=>{WML.dev().fn('Uat')({kinds:[],keysOnly:true,scenes:['__foreign_planner_test__']});});
 const failed=await call(finish,true);assert.equal(failed.status.failed,1);
 await call(()=>{__promptReadyPanel.close();});await call(open,{isNew:true});const retry=await call(finish,true);assert.equal(retry.status.failed,0);assert.equal(retry.status.complete,true);
 assert.deepEqual(retry.snapshot,reference,'다른 플래너 작업/실패 재시도 뒤 기본값 동등성');
 report.retry={failed:failed.status,retried:retry.status,interleavedPlanner:true};
 fs.writeFileSync(path.join(mod,'reports/prompt-open-responsive-20261030'+(mobile?'-mobile':'')+'.json'),JSON.stringify(report,null,2)+'\n');
}finally{await shutdown();setTimeout(()=>process.exit(process.exitCode||0),200).unref();}
