// 실제 계획 함수의 시간 경과 회귀 + 격리 게임 UI/250개 분할 전송. 사용자 서버·GPU에 쓰지 않습니다.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const source=fs.readFileSync(new URL('../source/mod.wml.js',import.meta.url),'utf8');
const planner=source.slice(source.indexOf('  function ImageStudio_랜덤정수뽑기('),source.indexOf('  function ImageStudio_랜덤검사안내읽기('));
function fixture({size=20000n,cost=30,held=[],repeat=0,abortAfter=0}={}){
  let elapsed=0,builds=0,seed=1138;const controller=new AbortController();
  const bridge={identity:key=>key,weight:()=>1,randomSpace:()=>({count:size,build:index=>{
    elapsed+=cost;if(++builds===abortAfter)controller.abort();
    const key='mari-'+(repeat?index%BigInt(repeat):index);return [{talentId:key,prompt:key}];
  }})};
  const sandbox={Math:Object.create(Math),DOMException,performance:{now:()=>elapsed},state:{catalogue:held.map(talentName=>({talentName}))},
    axisDefs:[['character','인물']],valuesOf:(selected,axis)=>[...(selected[axis]||[])],checkPlanningCancelled:signal=>{if(signal?.aborted)throw new DOMException('cancel','AbortError');},
    waitForPlanning:async value=>value,loadCatalogue:async()=>{},bridge:()=>bridge,
    ImageStudio_보유식별자읽기:key=>key,imageIdentity:key=>key,createDuplicateAudit:()=>({}),recordDuplicateAudit:()=>{},
    ImageStudio_계산묶음만들기:()=>()=>null,matchesSelection:()=>true,
    globalThis:{WW_ImageStudioPrompt:{combinationSpace:()=>({count:1n,at:()=>({})})}}};
  sandbox.Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
  const plan=vm.runInNewContext(planner+'\nImageStudio_랜덤생성계획하기;',sandbox);
  return {run:requested=>plan({character:['mari']},null,requested,()=>{},'composition',controller.signal),elapsed:()=>elapsed,builds:()=>builds};
}
const slow=fixture();const filled=await slow.run(5000);
console.log(JSON.stringify({case:'5000 target / 30ms per candidate',queued:filled.queue.length,virtualSeconds:slow.elapsed()/1000,sampling:filled.sampling}));
assert.equal(filled.queue.length,5000,'30초가 지나도 목표 수량까지 확보해야 합니다.');
assert.equal(new Set(filled.queue.map(item=>item.talentId)).size,5000);
assert.equal(filled.sampling.limited,false);
const scarce=await fixture({size:12n,held:['mari-0','mari-1']}).run(5000);
assert.equal(scarce.queue.length,10);assert.equal(scarce.sampling.exhausted,true);assert.equal(scarce.ownedDuplicates,2);
await assert.rejects(fixture({abortAfter:40}).run(5000),{name:'AbortError'});
const duplicateHeavy=await fixture({repeat:10,size:1000000n,cost:0}).run(100);
assert.equal(duplicateHeavy.queue.length,10);assert.equal(duplicateHeavy.sampling.stopReason,'attempts');
console.log('PASS elapsed time / unique keys / exhausted space / owned duplicates / cancellation / duplicate-heavy attempt guard');
if(process.argv.includes('--unit'))process.exit(0);

const {playStart,playEval,playStatus,shutdown}=await import('../../../../MCP/lib/play.mjs');
const id='imagestudio-random-queue',mobile=process.argv.includes('--mobile');
const run=async code=>{const out=await playEval({id,code,timeoutMs:45000});assert.ok(!out.error,out.error);assert.equal(out.pageErrorsSoFar,0);return out.result;};
try{
  const started=await playStart({id,viewport:mobile?{width:390,height:844}:{width:1500,height:950}});assert.deepEqual(started.failed,[]);
  console.log('Loaded '+started.loaded.length+' mods');
  await run(`
    const b=WW_ImageStudioBridge,originalFetch=window.fetch;
    WML.dev().hook('imageServerUrl',{priority:100000,around(next,path){return location.origin+path;}});
    b.list=()=>{throw Error('무작위 생성에서 전체 프롬프트 목록을 계산하면 안 됩니다.');};
    b.connection=()=>({baseUrl:location.origin,comfyui:true});b.ready=async()=>{};
    globalThis.randomQueueTest={requests:[],keys:[],prompts:[],starts:[],clock:performance.now(),ticks:0};
    globalThis.randomQueueTick=setInterval(()=>randomQueueTest.ticks++,10);
    window.fetch=async(input,options={})=>{
      const u=new URL(String(input),location.href);if(!u.pathname.startsWith('/api/'))return originalFetch(input,options);
      let body={};randomQueueTest.requests.push(u.pathname);
      if(u.pathname==='/api/pack')body={packFormat:1,entries:{}};
      if(u.pathname==='/api/batch/status')body={enqueueMode:'append',running:false,total:0,done:0};
      if(u.pathname==='/api/batch/enqueue'){
        const payload=JSON.parse(options.body);randomQueueTest.keys.push(...payload.items.map(i=>i.talentId));randomQueueTest.prompts.push(...payload.items.map(i=>i.prompt));randomQueueTest.starts.push(payload.start);
        body={accepted:payload.items.length,alreadyCached:0,alreadyQueued:0,jobId:payload.jobId};
      }
      return new Response(JSON.stringify(body),{headers:{'Content-Type':'application/json'}});
    };
    WW_ImageStudio.open();await new Promise(resolve=>setTimeout(resolve,100));
    return true;
  `);
  const opened=await run(`
    const rows=[...document.querySelectorAll('#wwis-content .wwis-row')];
    const row=rows.find(row=>row.textContent.includes('마리')&&row.querySelector('button'));
    if(!row)return {found:false,buttons:[...document.querySelectorAll('#wwis-content button')].map(b=>b.textContent).slice(0,15)};
    row.querySelector('button').click();await new Promise(resolve=>setTimeout(resolve,80));
    document.querySelector('#wwis-conditional').click();await new Promise(resolve=>setTimeout(resolve,100));
    document.querySelector('#wwis-random-count').value='5000';
    const selected=Object.fromEntries(['outfit','room','situation'].map(axis=>[axis,[...document.querySelectorAll('input[data-axis="'+axis+'"]:checked')].length]));
    document.querySelector('#wwis-enqueue-random').click();return {found:true,selected};
  `);
  console.log(JSON.stringify({opened}));assert.equal(opened.found,true);
  let result;
  for(let poll=0;poll<90;poll++){
    result=await run(`await new Promise(resolve=>setTimeout(resolve,2000));return {busy:WW_ImageStudio.isBusy(),count:randomQueueTest.keys.length,elapsed:(performance.now()-randomQueueTest.clock)/1000,message:document.querySelector('#wwis-message')?.textContent};`);
    if(!result.busy)break;if(poll%10===0)console.log(JSON.stringify(result));
  }
  assert.equal(result.busy,false,'3분 안에 시험 완료');
  result=await run(`clearInterval(randomQueueTick);return {count:randomQueueTest.keys.length,unique:new Set(randomQueueTest.keys).size,chunks:randomQueueTest.starts.length,starts:randomQueueTest.starts.filter(Boolean).length,ticks:randomQueueTest.ticks,elapsed:(performance.now()-randomQueueTest.clock)/1000,body:document.querySelector('#wwis-content').innerText.slice(-1100)};`);
  console.log(JSON.stringify(result));assert.equal(result.count,5000);assert.equal(result.unique,5000);assert.equal(result.chunks,20);assert.equal(result.starts,1);assert.ok(result.ticks>1);
  const cancelled=await run(`
    document.querySelector('#wwis-enqueue-random').click();document.querySelector('#wwis-plan-cancel').click();
    await new Promise(resolve=>setTimeout(resolve,100));
    return {busy:WW_ImageStudio.isBusy(),count:randomQueueTest.keys.length,cancelled:document.querySelector('#wwis-message').textContent.includes('취소')};
  `);
  assert.deepEqual(cancelled,{busy:false,count:5000,cancelled:true});
  console.log('PASS explicit cancel sends no additional queue items');
  const status=await playStatus({id});assert.deepEqual(status.failed,[]);assert.deepEqual(status.pageErrors,[]);
  console.log('PASS Mari all outfits / rooms / task + scene / 5000 unique / 20 HTTP chunks / responsive UI '+(mobile?'mobile':'pc'));
}finally{
  // 취소 직후 Chromium 종료 응답이 지연돼도 검사 프로세스가 남지 않게 합니다.
  const cleanupDeadline=setTimeout(()=>process.exit(process.exitCode||0),5000);
  await shutdown();clearTimeout(cleanupDeadline);setTimeout(()=>process.exit(process.exitCode||0),200).unref();
}

