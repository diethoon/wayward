// 실행: bun wml/mods/imagestudio/tests/settings-unsaved.ts [--mobile]
// 실제 게임 화면과 가짜 설정 API로 미저장 확인·입력 보존·저장 실패를 시험합니다. 실제 설정은 쓰지 않습니다.
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { resolveConfig } from '../backend/wayward-imagegen/src/config.ts'
import { ComfyClient } from '../backend/wayward-imagegen/src/comfy/client.ts'
import { loadGenerationSettings } from '../backend/wayward-imagegen/src/routes/generationSettings.ts'
import { playStart, playEval, playStop, playScreenshot } from '../../../../MCP/lib/play.mjs'

const mobile = process.argv.includes('--mobile')
const session = 'imagestudio-unsaved-' + (mobile ? 'mobile' : 'desktop')
const config = resolveConfig([], path.join(import.meta.dir, '.unused-settings-fixture'))
const { naiToken, ...defaults } = loadGenerationSettings(config, new ComfyClient('http://127.0.0.1:1'))
const fixture = { ...defaults, imageProvider: 'sdxl', naiTokenConfigured: false }

try {
  await playStart({ id: session, viewport: mobile ? { width: 390, height: 844 } : { width: 1500, height: 950 },
    mods: { 'addon-compat': true, imagestudio: true } })
  const result = await playEval({ id: session, timeoutMs: 30000, code: `
    const expect = (value, message) => { if (!value) throw Error(message); };
    const sleep = () => new Promise(resolve => setTimeout(resolve, 5));
    const waitFor = async selector => {
      for(let i=0;i<100&&!document.querySelector(selector);i++) await sleep();
      expect(document.querySelector(selector), '요소 없음: ' + selector);
    };
    const byId = id => document.getElementById(id);
    const edit = (id, value) => { byId(id).value = value; byId(id).dispatchEvent(new Event('input', {bubbles:true})); };
    const dirty = () => byId('wwis-settings-unsaved').dataset.dirty === 'true';
    const prompt = () => byId('wwis-unsaved-prompt');
    const unloadBlocked = () => { const event = new Event('beforeunload', {cancelable:true}); window.dispatchEvent(event); return event.defaultPrevented; };
    const fixture = ${JSON.stringify(fixture)};
    let persisted = structuredClone(fixture), puts = [], fail = false, hold = false, release = null;
    let holdGet = false, releaseGet = null;
    const originalFetch = fetch;
    const gameBefore = JSON.stringify(WML.dev().store.game());
    WW_ImageStudioBridge.connection = () => ({baseUrl:location.origin,comfyui:true});
    globalThis.fetch = async (input, options = {}) => {
      const url = String(input);
      if(url.endsWith('/api/generation/settings')) {
        if(options.method === 'PUT') {
          const incoming = JSON.parse(options.body); puts.push(incoming);
          if(hold) await new Promise(resolve => { release = resolve; });
          if(fail) return Response.json({error:'모의 저장 실패'},{status:503});
          persisted = {...incoming, naiTokenConfigured:incoming.naiToken ? true : persisted.naiTokenConfigured};
          delete persisted.naiToken;
          return Response.json({settings:persisted,saved:true});
        }
        if(holdGet) await new Promise(resolve => { releaseGet = resolve; });
        return Response.json(persisted);
      }
      if(url.includes('/api/generation/resources')) return Response.json({source:'folder'});
      if(url.includes('/api/generation/prompt-batch-support')) return Response.json({supported:true,reachable:true});
      return originalFetch(input, options);
    };
    const open = async () => {
      WW_ImageStudio.open();
      byId('wwis-generation-settings').click();
      await waitFor('#wwis-settings-unsaved'); await sleep();
      expect(!dirty(), '처음 열 때 미저장 아님');
    };

    // 1. 입력은 자동 전송하지 않습니다. 원래 값으로 되돌리면 경고도 사라집니다.
    await open();
    const original = byId('wwis-sdxl-positive').value;
    edit('wwis-sdxl-positive', 'new prompt');
    expect(dirty() && puts.length===0, '입력 시 미저장 표시, 자동 전송 없음');
    WW_ImageStudio.open();
    expect(byId('wwis-sdxl-positive').value==='new prompt', '다시 열기 호출에도 입력 유지');
    byId('wwis-close').click();
    expect(prompt() && prompt().querySelectorAll('button').length===3, '닫기 시 세 선택지');
    byId('wwis-unsaved-continue').dispatchEvent(new KeyboardEvent('keydown',{key:'Tab',bubbles:true,cancelable:true}));
    expect(document.activeElement===byId('wwis-unsaved-save'), '확인 창에서 Tab 초점 순환');
    byId('wwis-unsaved-continue').click();
    expect(!prompt() && byId('wwis-sdxl-positive').value==='new prompt', '계속 수정은 입력 유지');
    expect(unloadBlocked(), '새로고침/탭 종료 경고 등록');
    edit('wwis-sdxl-positive', original);
    expect(!dirty() && !unloadBlocked(), '원래 값으로 복구하면 변경 없음');

    // 2. 추가·삭제한 동적 캐릭터/LoRA도 감지합니다.
    byId('wwis-add-lora').click(); await sleep(); expect(dirty(), 'LoRA 행 추가 감지');
    byId('wwis-anima-lora-rows').lastElementChild.querySelector('[data-remove]').click(); await sleep();
    expect(!dirty(), '빈 LoRA 행 삭제로 원상 복구');
    byId('wwis-add-character').click(); await sleep(); expect(dirty(), '캐릭터 행 추가 감지');
    byId('wwis-character-rows').lastElementChild.querySelector('[data-remove]').click(); await sleep();
    expect(!dirty(), '캐릭터 행 원상 복구');
    edit('wwis-sdxl-positive', 'discarded'); byId('wwis-settings-back').click();
    expect(prompt(), '인물 선택으로 돌아갈 때 확인');
    byId('wwis-unsaved-discard').click();
    expect(byId('wwis-generation-settings') && puts.length===0, '저장 없이 이동, API 전송 없음');

    // 3. 위/아래 저장 버튼과 저장 후 나가기는 동일 API를 사용합니다.
    await open();
    edit('wwis-sdxl-positive', 'saved at top');
    expect(await byId('wwis-save-generation-top').onclick(), '상단 저장 성공');
    expect(!dirty() && puts.length===1 && !unloadBlocked(), '성공한 저장만 미저장 해제');
    byId('wwis-close').click(); expect(byId('wwis-overlay').hidden && !prompt(), '저장 후에는 바로 닫기');
    await open(); expect(byId('wwis-sdxl-positive').value==='saved at top', '다시 열 때 서버 저장값 표시');
    edit('wwis-sdxl-positive', 'save and return'); byId('wwis-settings-back').click();
    await byId('wwis-unsaved-save').onclick();
    expect(byId('wwis-generation-settings') && puts.length===2, '저장 후 인물 선택 이동');

    // 4. 서버 실패 시 나가지 않고 토큰을 포함한 편집값을 그대로 남깁니다.
    await open(); document.querySelector('[name=wwis-provider][value=nai]').click();
    edit('wwis-nai-token', 'private-unsaved-token');
    fail=true; byId('wwis-close').click(); await byId('wwis-unsaved-save').onclick();
    expect(!byId('wwis-overlay').hidden && dirty(), '저장 실패 시 화면/미저장 유지');
    expect(byId('wwis-nai-token').value==='private-unsaved-token', '실패 시 토큰 입력 유지');
    expect(byId('wwis-settings-status').textContent.includes('모의 저장 실패'), '저장 실패 이유 표시');
    fail=false; await byId('wwis-save-generation').onclick();
    expect(!dirty() && byId('wwis-nai-token').value==='', '정상 저장 시 토큰 입력 정리');

    // 5. 저장 응답 대기 중 닫기/중복 저장을 막고, 응답을 받은 뒤에만 미저장 상태를 해제합니다.
    edit('wwis-nai-positive', 'pending save'); hold=true;
    const countBefore=puts.length, pending=byId('wwis-save-generation').onclick();
    expect(byId('wwis-content').inert && byId('wwis-save-generation-top').disabled, '저장 중 입력 잠금');
    byId('wwis-close').click(); expect(!byId('wwis-overlay').hidden && !prompt(), '저장 중 화면 유지');
    expect(await byId('wwis-save-generation-top').onclick()===false, '중복 저장 방지');
    expect(puts.length===countBefore+1 && dirty(), '저장 전 미저장 표시 유지');
    hold=false; release(); await pending;
    expect(!dirty() && !byId('wwis-content').inert, '완료 후 잠금/미저장 해제');

    // 6. Esc·배경 닫기도 확인합니다. Esc로 확인 창만 닫으면 편집을 이어갑니다.
    edit('wwis-nai-positive', 'escape changes');
    window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true,cancelable:true}));
    expect(prompt(), 'Esc 종료 확인');
    window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true,cancelable:true}));
    expect(!prompt() && dirty(), '확인 창에서 Esc는 계속 수정');
    byId('wwis-overlay').dispatchEvent(new MouseEvent('click',{bubbles:true}));
    expect(prompt(), '배경 클릭 종료 확인');
    byId('wwis-unsaved-discard').click();
    expect(byId('wwis-overlay').hidden && !byId('wwis-nai-token') && !unloadBlocked(), '취소한 입력과 경고 정리');

    // 7. 설정 읽기 응답이 닫기보다 늦게 와도 숨긴 화면에 편집기를 다시 만들지 않습니다.
    WW_ImageStudio.open(); holdGet=true; byId('wwis-generation-settings').click();
    byId('wwis-close').click(); holdGet=false; releaseGet(); await sleep();
    expect(byId('wwis-overlay').hidden && !byId('wwis-settings-unsaved'), '늦은 읽기 응답 무시');
    await open(); edit('wwis-nai-positive', 'screenshot unsaved'); byId('wwis-close').click();
    expect(gameBefore===JSON.stringify(WML.dev().store.game()), '게임 상태 불변');
    return {puts:puts.length,failed:WML.status().failed,dirty:dirty(),prompt:!!prompt()};
  ` })
  assert.ok(!result.error, result.error)
  assert.equal(result.pageErrorsSoFar, 0, JSON.stringify(result))
  assert.deepEqual(result.result.failed, [])
  assert.equal(result.result.dirty, true)
  assert.equal(result.result.prompt, true)
  const screenshot = await playScreenshot({ id: session })
  const screenshotDirectory = path.join(import.meta.dir, '../.maintenance')
  fs.mkdirSync(screenshotDirectory, { recursive: true })
  fs.writeFileSync(path.join(screenshotDirectory, 'settings-unsaved-' + (mobile ? 'mobile' : 'desktop') + '.jpg'), Buffer.from(screenshot, 'base64'))
  console.log('PASS 미저장/값 복구·동적 행·닫기/뒤로/Esc/배경·저장/실패·토큰 보존·중복 저장·늦은 응답·브라우저 종료 경고 (' + (mobile ? 'mobile' : 'desktop') + ')')
} finally {
  await playStop({ id: session })
  setTimeout(() => process.exit(process.exitCode || 0), 200).unref()
}
