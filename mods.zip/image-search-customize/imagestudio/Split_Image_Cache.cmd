@echo off
setlocal
set "IMAGE_STUDIO_GAME_DIR=%~dp0..\..\.."
set "IMAGE_STUDIO_SERVER=%~dp0backend\wayward-imagegen"
pushd "%IMAGE_STUDIO_GAME_DIR%"
if errorlevel 1 exit /b 1
set "IMAGE_STUDIO_CONFIG=%IMAGE_STUDIO_SERVER%\wayward-imagegen.config.json"
if exist "%CD%\wayward-imagegen\wayward-imagegen.config.json" set "IMAGE_STUDIO_CONFIG=%CD%\wayward-imagegen\wayward-imagegen.config.json"
echo Close the image server first. The original cache will be backed up.
bun "%IMAGE_STUDIO_SERVER%\src\splitImageCache.ts" --config "%IMAGE_STUDIO_CONFIG%" --apply %*
popd
pause
endlocal
