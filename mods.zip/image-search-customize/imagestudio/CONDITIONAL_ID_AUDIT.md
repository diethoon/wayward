# 조건부 생성 ‘일상’ ID 연결 조사

확인일: 2026-10-18. 대상: 현재 게임의 한국어 vanilla 코드와 ImageStudio 1.21.1. 사용자 플레이 세션에 접속한 검사는 아닙니다. 작업 폴더의 캐시 JSON을 읽고, 각 ID의 실제 키를 하나씩 사용해 격리 게임에서 화면과 생성 계획을 검사했습니다. 최초 캐시 6개와 승인된 복구 후 정규 캐시 3개를 모두 대조했습니다. 이 조사에서는 이미지를 생성하지 않았습니다. 운영 캐시는 별도로 승인받은 백업·중복 병합만 적용했으며 상세 결과는 `cache-recovery-result.json`입니다.

## 이전 설명 정정

‘작업 목록이 8개라 휴식·수면이 조건부 생성 화면에 없다’는 설명은 잘못됐습니다.

- vanilla 이미지 계획기의 `JLe`(`imageTasks`)는 `idle`, `greeting`, `taking_order`, `serving`, `cleaning`, `cooking`, `passed_out`, `bathing`의 8개입니다. **게임에서 쓰는 작업 전체 목록이 아닙니다.**
- ImageStudio의 `axesWithCatalogue()`는 기본 선택지에 **보유 이미지 키에서 발견한 작업·장면을 추가**합니다. `resting`, `sleeping` 키가 있으면 이전에도 ‘일상’에 표시됩니다.
- 일상 분류는 `dailySituations`에 지정한 17종과 `kind: task`인 추가 항목을 포함합니다. 현재 읽은 캐시에서 지정된 17종을 모두 확인했으며 별도의 추가 작업 ID는 없었습니다.
- 기본 공급 목록과 캐시 추가 목록은 다릅니다. 파일 검사가 성공하면 없는 파일은 카탈로그에서 제외되므로 캐시 추가 항목은 실제 등록 자료·검사 결과에 따라 달라집니다. 현재 선택한 아내의 키만이 아니라 전체 카탈로그에서 추가됩니다.
- 1.21.0의 휴식·수면 보완은 ‘보이지 않던 메뉴 복구’가 아니라 **캐시 없이도 기본 공급하고 직접 조합 생성에서 허용**한 변경입니다.

한글 번역기는 일반 텍스트의 `resting`, `sleeping`도 ‘휴식 중’, ‘수면 중’으로 치환합니다. 그래서 이전의 이름 뒤 `(ID)` 표시까지 한글이 되는 문제가 있었습니다. 1.21.1의 별도 코드 텍스트 ID는 이 재번역을 방지합니다.

## 일상 전체 연결표

‘직접 조합’은 각 항목에 맞는 장소·의상·남성 수로 최소 1개 조합을 만들었을 때 해당 ID가 생성 키에 들어가는지 확인한 결과입니다. 모든 의상·장소 조합이 허용된다는 뜻은 아닙니다. ‘원본 키 복제’는 기존 키를 `fromKey()`에 넣어 같은 작업·장면의 생성 항목을 구성할 수 있는지 확인했습니다. 대기열 전송이나 GPU 생성은 하지 않았습니다.

| 표시명 / 번역명 | 실제 vanilla ID | 이미지 키 필드 | 현재 기본 공급 | 직접 조합 | 원본 키 복제 |
|---|---|---|---|---|---|
| 대기 중 | `idle` | `task-idle` | 있음 | 정상 | 가능 |
| 손님 맞이 | `greeting` | `task-greeting` | 있음 | 정상 | 가능 |
| 주문 받기 | `taking_order` | `task-taking_order` | 있음 | 정상 | 가능 |
| 서빙 | `serving` | `task-serving` | 있음 | 정상 | 가능 |
| 청소 | `cleaning` | `task-cleaning` | 있음 | 정상 | 가능 |
| 요리 | `cooking` | `task-cooking` | 있음 | 정상 | 가능 |
| 의식을 잃음 | `passed_out` | `task-passed_out` | 있음 | 정상 | 가능 |
| 목욕 | `bathing` | `task-bathing` | 있음 | 정상 | 가능 |
| 휴식 / 휴식 중 | `resting` | `task-resting` | 있음, 1.21.0부터 | 정상 | 가능 |
| 수면 / 수면 중 | `sleeping` | `task-sleeping` | 있음, 1.21.0부터 | 정상 | 가능 |
| 혼자 목욕 | `bath_solo` | `scene-bath_solo` | 있음 | 정상 | 가능 |
| 목욕 시중 | `bath_attendant` | `scene-bath_attendant` | 있음 | 정상 | 가능 |
| 손님과 대화 | `patron_chatting` | `scene-patron_chatting` | 있음 | 정상 | 가능 |
| 손님과 추파 | `patron_flirting` | `scene-patron_flirting` | 있음 | 정상 | 가능 |
| 장보는 중 | `at_market` | `task-at_market` | 없음, 캐시에서 추가 | **0건: 허용 목록에서 제외** | 가능 |
| 마음을 추스르는 중 | `composing` | `task-composing` | 없음, 캐시에서 추가 | **0건: 허용 목록에서 제외** | 가능 |
| 외출 중 | `away` | `task-away` | 없음, 캐시에서 추가 | **0건: 허용 목록에서 제외** | 가능 |

합계: 작업 13종 + 장면 4종. **일상 탭이라고 모두 `task`는 아닙니다.** `bath_solo`, `bath_attendant`, `patron_chatting`, `patron_flirting`은 `scene`으로 연결됩니다. `bathing`과 `bath_solo`는 별도 ID입니다.

## 실제 경로와 제약

1. `imageStudioAxes()`가 기본 작업·장면 선택지를 제공합니다.
2. `imageStudio_loadCatalogue()`가 이미지팩과 서버 팩을 모읍니다. 서버가 응답하면 파일 경로를 검증하고 없는 경로를 제외합니다.
3. `axesWithCatalogue()`가 카탈로그 키의 `task-...` 또는 `scene-...`를 선택지에 합칩니다. `situationGroup()`이 일상 등 화면 그룹을 정합니다.
4. 직접 선택한 조건을 조합할 때 `randomSpace()`와 `listStudioImages()`는 별도의 허용 목록 `imageTasks/imageEscalations/imageSexScenes`를 확인합니다. 여기에 없는 항목은 건너뜁니다. 이것이 마지막 3종의 불일치 원인입니다.
5. 원본 구성 복제는 기존 키를 파싱해 native 단일 항목 생성기 `appendImagePlan()`으로 보냅니다. 이 경로에서는 마지막 3종의 작업 ID도 유지됩니다.

vanilla `o8`(`imageDescriptor`)는 일반 작업을 `task: character.currentTask`로 직렬화합니다. `s6e`는 계획기의 `options.task`를 `currentTask`에 전달합니다. 실제 게임에서도 `c0`는 `resting`, `Rue`는 `sleeping`, `Pbe`/`Ybe`는 `composing`, `E1`은 `at_market`, `qc` 등은 `away`를 설정합니다. 따라서 이 ID들이 게임에 없어서 생긴 문제가 아닙니다.

- 수면: vanilla가 이미지 의상을 `nightshift`로 고정합니다. 다른 의상을 고른 수면 조합은 결과 키의 의상이 달라져 선택 조건 필터에서 제외될 수 있습니다. 이번 검사는 `nightshift` + `bedroom`으로 수행했습니다.
- 목욕 3종: 목욕 장소 `bathhouse`와 목욕용 의상이 필요합니다. 검사는 `bath_towel`을 사용했습니다.
- 기본 남성 수: `bath_attendant`, `patron_chatting`, `patron_flirting`은 1명, 나머지 일상 항목은 0명으로 검사했습니다.
- 침실·침대 위: 선택 문자열은 `bedroom (침대 위)`지만 실제 게임 조건은 `room-bedroom` + `abed-1`이므로 `[bedroom, abed=1]`로 표시합니다.

## 이번 변경 범위

모든 선택 박스에 기존 제목 옆 **주황색 `[ID]`**를 추가했습니다. ID는 부연설명과 같은 10.5px이며 긴 ID는 줄바꿈됩니다. 기존 설명의 유무, 제목, 실제 선택값과 생성 허용 목록은 유지합니다. 원래 제목만 있던 다른 작업·장면 그룹에는 설명을 새로 만들지 않았습니다.

기본 항목에는 해당 게임 선택 ID, 모드 추가 조건에는 그 모드의 선택 ID를 표시합니다. `auto`, `none`, `default` 등은 선택기에서 사용하는 자동/없음/기본 값이며 독립적인 vanilla 장면 ID는 아닙니다.

검사: PC·430px 모바일 화면의 339개 선택지에서 ID 원문·색상·크기, 설명 유무, ID 검색, 체크 상태, 반복 갱신 시 중복 표시 방지 및 가로 넘침을 검사했습니다. vanilla 8개 작업만 기본 공급하는 상황을 흉내 내고 다른 아내의 카탈로그 키를 공급했을 때도 ‘휴식 중’, ‘수면 중’이 일상에 추가되는 것을 재현했습니다.

재현 코드: `tests/conditional-id-audit.mjs`, `tests/conditional-id-ui.mjs`. 상세 조사 결과는 `tests/conditional-id-audit.json`에 남겼습니다. 마지막 3종의 직접 조합 허용 여부는 조사 결과로 보고하며 이번 표시 변경에 포함하지 않았습니다.
