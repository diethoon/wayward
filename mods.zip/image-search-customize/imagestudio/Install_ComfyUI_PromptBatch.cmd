@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0comfyui\install.ps1" %*
pause
endlocal
