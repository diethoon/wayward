// ImageStudio의 탐색·추첨과 초상화 표시 코드를 분리한 모드. 원작 ImageStudio: Hina_Lover.
WML.define({
  id: 'image-search-customize',
  name: { ko: '이미지 기준', en: 'Image Search Customize' },
  author: 'Hina_Lover',
  version: '1.0.3',
  game: '2026-11-01',
  tags: ['image','util'],
  loadAfter: ['imagestudio','attention-image-prompt'],
  description: '게임에서 표시할 이미지의 필수 조건, 유사도, 추첨과 표시를 설정합니다.',
  symbols: {
    imageLookup: {raw:{'2026-11-01':'vy'}},
    imageEntryUrl: {raw:{'2026-11-01':'o_'}},
    topFeelings: {raw:{'2026-11-01':'i_'}},
    imageUsagePortraitPanel: {raw:{'2026-11-01':'rv'}},
  },
  setup(api) {
    /* SEARCH_SETUP */
    ImageStudio_이미지매칭연결하기(api);
  },
});
