import fs from 'node:fs';
import vm from 'node:vm';
const read=name=>fs.readFileSync(new URL(name,import.meta.url),'utf8');
const {axes}=JSON.parse(read('vanilla-ids.json'));
const standaloneAxes=Object.fromEntries(Object.entries(axes).map(([id,values])=>[id,values.map(value=>({value,label:value}))]));
const sources=['matching-positions.js','portrait-display.js','image-matching.js'].map(read).join('\n');
const mod=read('mod.wml.js').replace('/* SEARCH_SETUP */',()=> 'const standaloneAxes = '+JSON.stringify(standaloneAxes)+';\n'+sources);
new vm.Script(mod);
fs.writeFileSync(new URL('../mod.js',import.meta.url),mod);
