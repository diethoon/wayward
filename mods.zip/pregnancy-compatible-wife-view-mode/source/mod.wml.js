// 호환성 패치 기준: pregnancy 3.3.1 / wife-view-mode 0.10.1 (개정 기준, 버전 번호에 따른 실행 제한 없음)
WML.define({
  tags: ["content"],
  id: 'pregnancy-compatible-wife-view-mode',
  author: "Hina_Lover",
  name: "임신·출산 - 여성 시점 모드 호환 패치",
  version: "1.3.4",
  game: "2026-11-01",
  requires: ['pregnancy', 'wife-view-mode'],
  description: "약 복용과 임신·출산 반응, 출산 후 아이 처치 제안·남자의 답변·결과를 자동 처리하지 않고 직접 확인합니다.",
  setup(api) {
    const pregnancy = globalThis.__wc2PregnancyBirth265;
    if (typeof pregnancy?.getCycleInfo !== 'function' || typeof pregnancy?.getReactionCatalog !== 'function') {
      throw new Error('임신 모드에 주기 약·반응 기능이 없습니다. Pregnancy 2.9.1 폴더를 함께 설치하세요.');
    }
    function PregnancyCompatibleWifeView_수동사건확인하기(state, event = state?.pendingEvent) {
      return (event?.type === 'wife_conversation' && event.pregnancyMedicineConversation === true)
        || (event?.type === 'alert' && ['wc2_pregnancy_reaction','wc2_child_disposition'].includes(event.alert?.kind));
    }
    function PregnancyCompatibleWifeView_반응표현만들기(state, event) {
      if (event?.type !== 'alert' || !['wc2_pregnancy_reaction','wc2_child_disposition'].includes(event.alert?.kind)) return null;
      const question=event.alert.kind==='wc2_child_disposition'&&event.alert.childDisposition?.phase==='question';
      return { title: event.alert.title, body: event.text, description: question
        ?"그녀의 제안과 속마음을 확인하고 당신의 답변을 직접 선택하세요."
        :'대사와 속마음, 결과를 확인한 뒤 계속하기를 누르세요.' };
    }
    function PregnancyCompatibleWifeView_구형구간확인하기(state) {
      return globalThis.__waywardWifeViewCompatibility?.pregnancy !== true && PregnancyCompatibleWifeView_수동사건확인하기(state);
    }
    globalThis.__waywardPregnancyCompatibleWifeView = {
      ownsConversation: PregnancyCompatibleWifeView_수동사건확인하기,
      getPresentation: PregnancyCompatibleWifeView_반응표현만들기,
      getStatus: () => ({ legacyFallback: globalThis.__waywardWifeViewCompatibility?.pregnancy !== true })
    };
    globalThis.__waywardWifeViewLegacyGuard.register(api.id, api, PregnancyCompatibleWifeView_구형구간확인하기);
  }
});
