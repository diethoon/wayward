<!-- STABLE_PORT -->
## 2026-11-01 정식판 이식

모드 버전 **1.3.4**, 대상 게임 **2026-11-01**, WML **0.9.5**입니다. MCP 0.6.2로 연결을 검사합니다. 새 게임을 기준으로 하며 pre7 및 기존 저장 이전은 지원 범위에 포함하지 않습니다.

배포 파일: `pregnancy-compatible-wife-view-mode-1.3.4-20261101.zip`. 압축의 폴더 이름과 설치 ID는 `pregnancy-compatible-wife-view-mode`이며 `wml/mods/pregnancy-compatible-wife-view-mode/mod.js`로 설치합니다. WML 모드 관리자에서 ZIP 설치도 가능합니다. 아래의 pre7 버전·ZIP 안내는 이전 변경 기록입니다.
<!-- /STABLE_PORT -->

> **호환성 패치 기준:** pregnancy 3.3.1 / wife-view-mode 0.10.1
> 이번 개정의 기준 버전입니다. 버전 번호로 실행을 차단하지 않으며, 필수 모드와 실제 연결 기능은 필요합니다. 최신 구성에 맞춰 유지합니다.

# Pregnancy-compatible-Wife_View_Mode 1.3.3

## [pre7 배포 · 버전 분리]

현재 모드 버전: 1.3.3. 대상 게임: 2026-10-24-pre7. 이전 모드 버전: 1.3.2-pre7.3.
배포 파일: pregnancy-compatible-wife-view-mode-1.3.3-pre7.zip
압축 내부 최상위 폴더와 로딩 ID는 항상 `pregnancy-compatible-wife-view-mode`이며 버전·pre 표기를 붙이지 않습니다. 폴더 복사 설치 경로는 `wml/mods/pregnancy-compatible-wife-view-mode/mod.js`입니다. ZIP 설치는 WML 모드 관리자를 사용하세요. 모드의 version은 숫자 버전, game은 대상 게임 식별자로 분리했습니다. 업데이트 인식을 위해 모드 버전의 마지막 숫자를 올렸으며 게임 동작은 이번 변경에서 수정하지 않았습니다. 이전 ZIP과 과거 변경 기록은 보존합니다.


**임신·출산 3.1.0 + Wife_View_Mode**에서 사용합니다. 약 복용 대화를 직접 선택하고, 임신·출산 반응을 읽은 뒤 계속합니다. 출산 후 아이 처치 상의에서도 아내의 제안을 읽고 남편의 답변을 직접 선택하며, 답변 뒤 결과를 읽기 전까지 자동 진행하지 않습니다. Brothel 종업원의 같은 상의 사건도 포함합니다. 최신 아내 시점에서는 해당 연결 지점을 사용합니다.

연결 기능이 없는 구형 아내 시점에서는 해당 대화·반응을 기본 게임 화면으로 보여 주고, 사건 종료 후 원래 아내 시점 활성 상태를 복원합니다. Delivery 호환 패치와 함께 쓰면 모든 대기가 끝난 뒤 복원합니다. 상대 본체를 수정하거나 공통 로더를 교체하지 않습니다.

임신 본체에 주기 약·반응 기능이 없으면 모드 관리자의 초기화 오류에 필요한 본체를 표시합니다. 기능 없이 성공으로 표시하지 않습니다. 처음부터 아내 시점이 꺼져 있던 경우는 켜지 않습니다. 대화 도중에는 패치를 끄지 말고 대화를 마친 뒤 구성을 변경하세요.

폴더 전체를 zip으로 묶어 설치합니다. 필수 모드인 `pregnancy`, `wife-view-mode`와 임신 모드의 `addon-compat`도 켜야 합니다.

개발: `source/mod.wml.js`, `source/legacy-guard.js`를 수정하고 `node wml/mods/pregnancy-compatible-wife-view-mode/source/build.mjs`로 재생성합니다.

검사: 게임 폴더에서 `node wml/mods/pregnancy/tests/regression.mjs` 또는 `node wml/mods/delivery/tests/portability.mjs`.


## 2026-10-24-pre7 이식

- 배포 버전: `1.3.2-pre7.1` · WML 0.9.4 · 구 게임용 배포와 구분합니다.
- 원제작자·원문 출처 표기는 기존 머리말과 문서에 보존했습니다. 이 배포의 호환 수정: HL 작업본.
- 모드 내부 ID와 폴더 이름을 `pregnancy-compatible-wife-view-mode`로 통일했습니다. 이 폴더만 덮어쓸 수 있는 개별 ZIP을 함께 제공합니다.
- 구 게임의 압축 함수 이름과 탐색 규칙을 pre7에 맞췄습니다. 변경·검증의 전체 범위와 한계는 작업 폴더 `version_up_ready/PORT_RESULT.md`를 참고하세요.


## 1.3.2-pre7.2 · 2026-10-27 배포 정합성 보완

현재 폴더에서 선택한 한국어 모드명·설명을 제작 소스와 배포 ZIP에 반영하고 고정 태그를 선언했습니다. 원제작자·출처와 기존 기능은 보존합니다.

## 1.3.2-pre7.3 — 관계 표현 보완 (2026-10-28)

여성 시점의 약 복용·임신 안내에서 배우자 고정 표현을 정리했습니다. 예약·복용·대화 소유권 및 처리 시점은 유지합니다.
