// 호환성 패치 기준: pregnancy 3.3.1 / wife-view-mode 0.10.1 (개정 기준, 버전 번호에 따른 실행 제한 없음)
// 생성 파일. 수정: source/mod.wml.js, source/legacy-guard.js
// 구형 아내 시점의 자동 처리만 필요한 구간에서 잠시 중지하고, 저장된 활성 상태를 복원합니다.
WML.define({
  tags: ["content"],
  id: 'pregnancy-compatible-wife-view-mode',
  author: "Hina_Lover",
  name: "임신·출산 - 여성 시점 모드 호환 패치",
  version: "1.3.4",
  game: "2026-11-01",
  requires: ['pregnancy', 'wife-view-mode'],
  description: "약 복용과 임신·출산 반응, 출산 후 아이 처치 제안·남자의 답변·결과를 자동 처리하지 않고 직접 확인합니다.",
  setup(api) {
// 호환성 패치 기준: pregnancy 3.3.1 / wife-view-mode 0.10.1 (개정 기준, 버전 번호에 따른 실행 제한 없음)
// 생성 파일. 수정: source/mod.wml.js, source/legacy-guard.js
// 구형 아내 시점의 자동 처리만 필요한 구간에서 잠시 중지하고, 저장된 활성 상태를 복원합니다.
(() => {
  if (globalThis.__waywardWifeViewLegacyGuard) return;
  const rules = new Map();
  let store = null, writing = false, unsubscribe = null;
  function WifeViewLegacyGuard_상태정리하기() {
    if (writing || !store) return;
    const state = store.game();
    if (!state) return;
    const view = state.mods?.['wife-view-mode'] || {};
    const saved = view.portableCompatibility;
    const owners = [...rules].filter(([, rule]) => rule(state)).map(([id]) => id).sort();
    if (!saved && (!owners.length || view.active !== true)) return;
    if (saved && owners.length && view.active === false && JSON.stringify(saved.owners) === JSON.stringify(owners)) return;
    const nextView = owners.length
      ? { ...view, active: false, portableCompatibility: { wasActive: saved?.wasActive ?? view.active, owners } }
      : { ...view, active: saved.wasActive === true };
    if (!owners.length) delete nextView.portableCompatibility;
    writing = true;
    try { store.update(current => ({ ...current, mods: { ...current.mods, 'wife-view-mode': nextView } })); }
    finally { writing = false; }
  }
  function WifeViewLegacyGuard_등록하기(owner, api, rule) {
    rules.set(owner, rule);
    if (!store) { store = api.store; unsubscribe = store.subscribe(WifeViewLegacyGuard_상태정리하기); }
    WifeViewLegacyGuard_상태정리하기();
    return () => { rules.delete(owner); WifeViewLegacyGuard_상태정리하기(); };
  }
  window.addEventListener('pagehide', () => unsubscribe?.(), { once: true });
  globalThis.__waywardWifeViewLegacyGuard = { register: WifeViewLegacyGuard_등록하기,
    reconcile: WifeViewLegacyGuard_상태정리하기 };
})();

// 호환성 패치 기준: pregnancy 3.3.1 / wife-view-mode 0.10.1 (개정 기준, 버전 번호에 따른 실행 제한 없음)

Object.assign(globalThis,{});

    const pregnancy = globalThis.__wc2PregnancyBirth265;
    if (typeof pregnancy?.getCycleInfo !== 'function' || typeof pregnancy?.getReactionCatalog !== 'function') {
      throw new Error('임신 모드에 주기 약·반응 기능이 없습니다. Pregnancy 2.9.1 폴더를 함께 설치하세요.');
    }
    function PregnancyCompatibleWifeView_수동사건확인하기(state, event = state?.pendingEvent) {
      return (event?.type === 'wife_conversation' && event.pregnancyMedicineConversation === true)
        || (event?.type === 'alert' && ['wc2_pregnancy_reaction','wc2_child_disposition'].includes(event.alert?.kind));
    }
    function PregnancyCompatibleWifeView_반응표현만들기(state, event) {
      if (event?.type !== 'alert' || !['wc2_pregnancy_reaction','wc2_child_disposition'].includes(event.alert?.kind)) return null;
      const question=event.alert.kind==='wc2_child_disposition'&&event.alert.childDisposition?.phase==='question';
      return { title: event.alert.title, body: event.text, description: question
        ?"그녀의 제안과 속마음을 확인하고 당신의 답변을 직접 선택하세요."
        :'대사와 속마음, 결과를 확인한 뒤 계속하기를 누르세요.' };
    }
    function PregnancyCompatibleWifeView_구형구간확인하기(state) {
      return globalThis.__waywardWifeViewCompatibility?.pregnancy !== true && PregnancyCompatibleWifeView_수동사건확인하기(state);
    }
    globalThis.__waywardPregnancyCompatibleWifeView = {
      ownsConversation: PregnancyCompatibleWifeView_수동사건확인하기,
      getPresentation: PregnancyCompatibleWifeView_반응표현만들기,
      getStatus: () => ({ legacyFallback: globalThis.__waywardWifeViewCompatibility?.pregnancy !== true })
    };
    globalThis.__waywardWifeViewLegacyGuard.register(api.id, api, PregnancyCompatibleWifeView_구형구간확인하기);
  }
});
