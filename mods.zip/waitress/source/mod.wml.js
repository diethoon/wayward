// 웨이트리스 — WML 포팅판
// 원본: waitress.src.js (md5 e743d816870089bf0f97049098b30c9c), 9-30 한글판 모드 매니저용 애드온.
// 원본에서 고친 곳 7군데: waitress.fixes.json
// 원본 코드는 아래 setup() 안에서 그대로 실행돼요. 게임 함수 연결은 addon-compat 모드가 해 줘요.
// 이 파일은 tools/wrap-addon.mjs 로 만들었어요. 원본을 고치려면 원본을 고친 뒤 다시 만드세요.
WML.define({
  id: "waitress",
  author: "Hina_Lover",
  name: "웨이트리스",
  version: "1.1.2",
  game: "2026-11-01",
  description: "홀 업무를 자동으로 처리하는 종업원을 고용합니다.",
  requires: ["addon-compat"],
  loadAfter: [],
  conflicts: ["arhka-maid"],
  role: ["hall-staff"],

  setup(api) {
    // ---- 원본 애드온 ----
/* Wayward 2026-09-30 - Simple Waitress addon
 * One non-interactive employee: greet, take orders, serve, report shortages,
 * clean, and cook. Install through Install_Addons.cmd.
 */
(()=>{
  'use strict';

  if(globalThis.__WAYWARD_SIMPLE_WAITRESS_LOADED__)return;
  const api=globalThis.__WAYWARD_ADDON_API__;
  if(!api){console.error('[Simple Waitress] Wayward addon API was not found.');return}
  const {ue,waitress:game}=api;
  if(!ue?.getState||!ue?.setState||!ue?.subscribe||!game||typeof api.minuteTick!=='function'){
    console.error('[Simple Waitress] This Wayward build is not compatible.');
    return;
  }
  globalThis.__WAYWARD_SIMPLE_WAITRESS_LOADED__=true;

  const STORAGE_KEY='wayward-simple-waitress-2026-09-30-v1';
  const WAGE=10;
  const TASK_TIME={greet:2,order:2,serve:3,unavailable:2,clean:10,cook:15};
  const DEFAULTS={
    hired:false,
    name:'메이드',
    showLocation:true,
    cleanThreshold:70,
    autoCook:true,
    readyFoodTarget:4,
    lastPaidDay:null,
    lastAttemptDay:null,
    activeDay:null,
    lastSeenDay:null
  };
  const reservationProviders=new Map();
  function externalReservations(state){const row={customers:new Set(),kitchenBusy:false};for(const fn of reservationProviders.values()){const r=fn(state)||{};for(const id of r.customers||[])row.customers.add(id);row.kitchenBusy ||= !!r.kitchenBusy;}return row;}
  const runtime={readyAt:null,lastSlot:null,task:'대기 중',detail:'다음 일을 기다리고 있습니다.',targetId:null};
  let config=loadConfig();
  let ui=null;
  let decorateQueued=false;

  function finite(value,fallback=0){const number=Number(value);return Number.isFinite(number)?number:fallback}
  function clamp(value,min,max){return Math.max(min,Math.min(max,finite(value,min)))}
  function normalName(value){const text=String(value??'').trim().slice(0,32);return text||'메이드'}
  function dayOf(state){return Math.max(0,Math.floor(finite(state?.day,0)))}
  function readRaw(){try{return JSON.parse(localStorage.getItem(STORAGE_KEY)||'null')}catch{return null}}
  function loadConfig(){
    const raw=readRaw()||{};
    return{
      ...DEFAULTS,
      ...raw,
      hired:raw.hired===true,
      name:normalName(raw.name??DEFAULTS.name),
      showLocation:raw.showLocation!==false,
      cleanThreshold:Math.round(clamp(raw.cleanThreshold??70,0,100)),
      autoCook:raw.autoCook!==false,
      readyFoodTarget:Math.round(clamp(raw.readyFoodTarget??DEFAULTS.readyFoodTarget,1,100)),
      lastPaidDay:Number.isInteger(raw.lastPaidDay)?raw.lastPaidDay:null,
      lastAttemptDay:Number.isInteger(raw.lastAttemptDay)?raw.lastAttemptDay:null,
      activeDay:Number.isInteger(raw.activeDay)?raw.activeDay:null,
      lastSeenDay:Number.isInteger(raw.lastSeenDay)?raw.lastSeenDay:null
    };
  }
  function saveConfig(){
    try{localStorage.setItem(STORAGE_KEY,JSON.stringify(config))}catch(error){console.warn('[Simple Waitress] Settings could not be saved.',error)}
    renderStatus();
    scheduleDecorate();
  }
  function addLog(state,text){return{...state,log:[...(state.log??[]),{slot:state.slot,text,wwSimpleWaitress:true}]}}
  function currentRoot(){try{return ue.getState()}catch{return null}}
  function currentState(){return currentRoot()?.state??null}
  function replaceState(next){
    try{ue.setState(root=>({...root,state:next}));return true}catch(error){console.error('[Simple Waitress] Game state update failed.',error);return false}
  }
  function setMessage(text,tone='normal'){
    if(!ui)return;
    ui.message.textContent=text||'';
    ui.message.dataset.tone=tone;
  }
  function isWorking(state=currentState()){return!!state&&config.hired&&config.activeDay!=null}
  function workerStateText(state=currentState()){
    if(!config.hired)return'고용하지 않음';
    if(!state)return'게임 상태 확인 중';
    if(config.activeDay==null)return'오늘 미출근';
    if(!['service','last_call'].includes(state.phase))return'출근 완료 · 영업 대기 중';
    return runtime.detail;
  }

  function resetRuntime(state){
    runtime.readyAt=finite(state?.slot,0);
    runtime.lastSlot=null;
    runtime.task='대기 중';
    runtime.detail='다음 일을 기다리고 있습니다.';
    runtime.targetId=null;
  }
  function begin(state,task,duration,detail,targetId=null){
    runtime.task=task;
    runtime.detail=detail;
    runtime.targetId=targetId;
    runtime.readyAt=finite(state.slot,0)+duration;
  }
  function customerRoom(state,customer){
    for(const [room,data] of Object.entries(state.locations??{})){
      if(data?.occupants?.includes(customer.id))return room;
    }
    return null;
  }
  function reservedCustomers(state){
    const ids=new Set(externalReservations(state).customers);
    try{
      const scene=state.activeScene?.patron;
      if(scene?.customerId)ids.add(scene.customerId);
      for(const id of scene?.crowdPatronIds??[])ids.add(id);
      for(const id of scene?.joinedPatronIds??[])ids.add(id);
    }catch{}
    const wife=state.characters?.[state.primaryCharacterId];
    if(wife?.taskTarget)ids.add(wife.taskTarget);
    return ids;
  }
  function availableCustomers(state){
    const reserved=reservedCustomers(state);
    return(state.customers??[]).filter(customer=>
      customer&&
      !reserved.has(customer.id)&&
      !['gone','leaving'].includes(customer.status)&&
      customerRoom(state,customer)==='taproom'
    );
  }
  const ORDER_LABELS={food:'식사',beer:'에일',wine:'와인',food_and_beer:'식사와 에일',food_and_wine:'식사와 와인'};
  function orderLabel(order){return ORDER_LABELS[order]??String(order??'메뉴')}

  function greet(state,customer){
    const customers=state.customers.map(item=>item.id===customer.id?{...item,status:'greeted'}:item);
    begin(state,'인사',TASK_TIME.greet,`${customer.name}을(를) 맞이하고 있습니다.`,customer.id);
    return addLog({...state,customers},`${config.name}이(가) ${customer.name}에게 인사하고 빈 자리로 안내한다.`);
  }
  function takeOrder(state,customer){
    const order=game.chooseOrder();
    const customers=state.customers.map(item=>item.id===customer.id?{
      ...item,
      status:'ordered',
      order,
      roundsOrdered:finite(item.roundsOrdered,0)+1,
      patience:finite(item.maxPatience,item.patience??0)
    }:item);
    begin(state,'메뉴 질문',TASK_TIME.order,`${customer.name}의 주문을 받고 있습니다.`,customer.id);
    return addLog({...state,customers},`${config.name}이(가) ${customer.name}의 주문을 받는다: ${orderLabel(order)}.`);
  }
  function serve(state,customer){
    if(!customer.order||!game.available(state,customer.order))return state;
    const supplied=game.consume(state,customer.order),price=finite(game.price(customer.order),0);
    const customers=(supplied.customers??[]).map(item=>item.id===customer.id?{
      ...item,
      status:'drinking',
      tab:finite(item.tab,0)+price,
      walletGold:Math.max(0,finite(item.walletGold,0)-price),
      servedBy:'simple_waitress',
      servedQuality:65,
      stayTimer:Math.max(finite(item.stayTimer,0),20+Math.floor(Math.random()*40))
    }:item);
    const serves=supplied.servesToday??{count:0,qualitySum:0,spills:0};
    let next={
      ...supplied,
      customers,
      customersServedToday:finite(supplied.customersServedToday,0)+(finite(customer.roundsOrdered,0)===1?1:0),
      servesToday:{...serves,count:serves.count+1,qualitySum:serves.qualitySum+65}
    };
    next=game.recordWord(next,customer);
    next=game.recordDrink(next,customer.id,customer.order);
    next=game.income(addLog(next,`${config.name}이(가) ${customer.name}에게 ${orderLabel(customer.order)}을(를) 내온다. (+${price}골드)`),'service',price);
    begin(state,'서빙',TASK_TIME.serve,`${customer.name}에게 주문을 서빙하고 있습니다.`,customer.id);
    return next;
  }
  function missingLabel(item){return orderLabel(item)}
  function reportUnavailable(state,customer){
    if(!customer.order)return state;
    let missing=[];
    try{missing=game.missing(state,customer.order)??[]}catch{}
    let alternative=null;
    try{alternative=game.alternative(state,customer.order)}catch{}
    const missingText=missing.length?missing.map(missingLabel).join(' 또는 '):orderLabel(customer.order);
    begin(state,'메뉴 없음 안내',TASK_TIME.unavailable,`${customer.name}에게 품절 메뉴를 안내하고 있습니다.`,customer.id);
    if(alternative){
      const customers=state.customers.map(item=>item.id===customer.id?{
        ...item,
        order:alternative,
        patience:Math.max(1,Math.floor(finite(item.patience,1)*.8))
      }:item);
      return addLog({...state,customers},`${config.name}이(가) ${customer.name}에게 ${missingText} 재고가 없다고 알린다. 손님은 대신 ${orderLabel(alternative)}을(를) 주문한다.`);
    }
    if(customer.isResident){
      const customers=state.customers.map(item=>item.id===customer.id?{...item,status:'drinking',order:null,stayTimer:20+Math.floor(Math.random()*20)}:item);
      return addLog({...state,customers},`${config.name}이(가) ${customer.name}에게 ${missingText} 재고가 없다고 알린다. 묵는 손님은 투덜거리지만 자리를 지킨다.`);
    }
    const customers=state.customers.map(item=>item.id===customer.id?{...item,status:'leaving',mood:'angry'}:item);
    const reputation=state.tavernReputation?{...state.tavernReputation,service:Math.max(0,finite(state.tavernReputation.service,0)-2)}:state.tavernReputation;
    return addLog({
      ...state,
      customers,
      customersLostToday:finite(state.customersLostToday,0)+1,
      ...(reputation?{tavernReputation:reputation}:{})
    },`${config.name}이(가) ${customer.name}에게 ${missingText} 재고가 없다고 사과한다. 손님은 불평하며 주점을 나선다.`);
  }
  function clean(state){
    const cleanliness=Math.min(100,finite(state.tavernCleanliness,100)+5);
    begin(state,'청소',TASK_TIME.clean,'빈 잔을 치우고 탁자와 바닥을 닦고 있습니다.');
    return addLog({...state,tavernCleanliness:cleanliness},`${config.name}이(가) 빈 잔을 치우고 탁자와 바닥을 닦는다. 청결도: ${cleanliness}%.`);
  }
  function cook(state){
    const food=Math.max(0,finite(state.supplies?.food,0));
    const currentReady=Math.max(0,finite(state.readyFood,0));
    const portions=Math.min(2,food,Math.max(0,config.readyFoodTarget-currentReady));
    if(portions<=0)return state;
    const ready=currentReady+portions;
    begin(state,'요리',TASK_TIME.cook,`${portions}인분을 요리하고 있습니다.`);
    return addLog({
      ...state,
      supplies:{...state.supplies,food:food-portions},
      readyFood:ready
    },`${config.name}이(가) 부엌에서 ${portions}인분을 요리한다. (${ready}인분 준비됨)`);
  }

  function processMorningWage(state){
    const day=dayOf(state);
    let dirty=false;
    if(config.lastSeenDay!=null&&day<config.lastSeenDay){
      config.lastPaidDay=null;
      config.lastAttemptDay=null;
      config.activeDay=null;
      resetRuntime(state);
      dirty=true;
    }
    if(config.lastSeenDay!==day){config.lastSeenDay=day;dirty=true}
    if(!config.hired){
      if(config.activeDay!=null){config.activeDay=null;dirty=true}
      if(dirty)saveConfig();
      return state;
    }
    if(config.lastPaidDay===day){
      if(config.activeDay!==day){config.activeDay=day;dirty=true}
      if(dirty)saveConfig();
      return state;
    }
    if(config.lastAttemptDay===day){if(dirty)saveConfig();return state}
    config.lastAttemptDay=day;
    if(finite(state.economy?.gold,0)<WAGE){
      config.activeDay=null;
      saveConfig();
      return addLog(state,`${config.name}의 일당 ${WAGE}골드가 부족해 오늘은 출근하지 않았다.`);
    }
    config.lastPaidDay=day;
    config.activeDay=day;
    resetRuntime(state);
    saveConfig();
    return addLog({...state,economy:{...state.economy,gold:state.economy.gold-WAGE}},`${config.name}이(가) 출근했다. 일당 ${WAGE}골드를 지급했다.`);
  }

  function runWorker(state){
    const slot=finite(state.slot,0);
    if(runtime.lastSlot!=null&&(slot<runtime.lastSlot||slot-runtime.lastSlot>120))resetRuntime(state);
    if(runtime.lastSlot===slot)return state;
    runtime.lastSlot=slot;
    if(state.gameOver||state.pendingEvent||!isWorking(state)||!['service','last_call'].includes(state.phase))return state;
    if(runtime.readyAt!=null&&slot<runtime.readyAt)return state;

    runtime.task='대기 중';
    runtime.detail='홀을 둘러보며 다음 일을 찾고 있습니다.';
    runtime.targetId=null;
    const customers=availableCustomers(state);

    // User-selected strict priority: greet -> ask menu -> serve -> no menu -> clean -> cook.
    const arrived=customers.find(customer=>customer.status==='arrived');
    if(arrived)return greet(state,arrived);
    const waiting=customers.find(customer=>customer.status==='greeted'||customer.status==='wants_more');
    if(waiting)return takeOrder(state,waiting);
    const ordered=customers.filter(customer=>customer.status==='ordered'&&customer.order)
      .sort((left,right)=>finite(left.arrivedAtSlot,0)-finite(right.arrivedAtSlot,0));
    const ready=ordered.find(customer=>game.available(state,customer.order));
    if(ready)return serve(state,ready);
    if(ordered.length)return reportUnavailable(state,ordered[0]);
    if(finite(state.tavernCleanliness,100)<config.cleanThreshold)return clean(state);
    if(!externalReservations(state).kitchenBusy&&state.characters?.[state.primaryCharacterId]?.currentTask!=='cooking'&&config.autoCook&&finite(state.supplies?.food,0)>0&&finite(state.readyFood,0)<config.readyFoodTarget)return cook(state);
    return state;
  }
  function tick(state){
    if(!state)return state;
    return runWorker(state);
  }
  const originalMinuteTick=api.minuteTick;
  api.minuteTick=function(state){return tick(originalMinuteTick(state))};

  function disableForNewGame(){
    config.hired=false;
    config.lastPaidDay=null;
    config.lastAttemptDay=null;
    config.activeDay=null;
    config.lastSeenDay=null;
    resetRuntime(null);
    saveConfig();
  }
  function installNewGameDefaults(){
    const root=currentRoot();
    if(!root)return;
    const replacements={};
    for(const key of ['newGame','startGameWithWifeArchetype','startGameWithPicks']){
      const original=root[key];
      if(typeof original!=='function'||original.__wwSimpleWaitressWrapped)continue;
      const wrapped=function(...args){disableForNewGame();return original.apply(this,args)};
      Object.defineProperty(wrapped,'__wwSimpleWaitressWrapped',{value:true});
      replacements[key]=wrapped;
    }
    if(Object.keys(replacements).length)ue.setState(current=>({...current,...replacements}));
  }

  function hire(){
    const root=currentRoot(),state=root?.state;
    if(!root?.started||!state){setMessage('게임을 시작한 뒤 고용할 수 있습니다.','error');renderForm();return false}
    if(config.hired){renderForm();return true}
    if(finite(state.economy?.gold,0)<WAGE){setMessage(`고용하려면 ${WAGE}골드가 필요합니다.`,'error');renderForm();return false}
    const day=dayOf(state);
    const next=addLog({...state,economy:{...state.economy,gold:state.economy.gold-WAGE}},`${config.name}을(를) 웨이트리스로 고용했다. 오늘 일당 ${WAGE}골드를 지급했다.`);
    if(!replaceState(next)){setMessage('고용 처리 중 오류가 발생했습니다.','error');renderForm();return false}
    config.hired=true;
    config.lastPaidDay=day;
    config.lastAttemptDay=day;
    config.activeDay=day;
    config.lastSeenDay=day;
    resetRuntime(next);
    saveConfig();
    setMessage(`${config.name} 고용 완료 · ${WAGE}골드를 지급했습니다.`,'success');
    renderForm();
    return true;
  }
  function cancelHire(){
    const state=currentState();
    config.hired=false;
    config.activeDay=null;
    resetRuntime(state);
    saveConfig();
    if(state)replaceState(addLog(state,`${config.name}의 고용을 취소했다. 지급한 일당은 반환되지 않는다.`));
    setMessage('고용을 취소했습니다. 다음 날부터 출근하지 않습니다.','normal');
    renderForm();
  }

  function el(tag,className,text){const node=document.createElement(tag);if(className)node.className=className;if(text!=null)node.textContent=text;return node}
  function checkRow(label,description,input){
    const row=el('label','ww1-row ww1-check-row'),copy=el('span','ww1-copy'),title=el('span','ww1-label',label),help=el('span','ww1-help',description);
    copy.append(title,help);row.append(copy,input);return row;
  }
  function renderForm(){
    if(!ui)return;
    ui.hired.checked=config.hired;
    ui.name.value=config.name;
    ui.location.checked=config.showLocation;
    ui.clean.value=String(config.cleanThreshold);
    ui.cook.checked=config.autoCook;
    ui.cookTarget.value=String(config.readyFoodTarget);
    ui.cookTarget.disabled=!config.autoCook;
    renderStatus();
  }
  function renderStatus(){
    if(!ui)return;
    const state=currentState(),gold=state?.economy?.gold;
    const statusText=`상태: ${workerStateText(state)}${Number.isFinite(gold)?` · 보유 골드 ${gold}g`:''}`;
    if(ui.status.textContent!==statusText)ui.status.textContent=statusText;
    document.querySelectorAll('.ww1-header-button').forEach(node=>{
      const active=config.hired?'true':'false',title=`Waitress 모드 · ${workerStateText(state)}`;
      if(node.dataset.active!==active)node.dataset.active=active;
      if(node.title!==title)node.title=title;
      if(node.getAttribute('aria-label')!==title)node.setAttribute('aria-label',title);
    });
  }
  function openSettings(){
    if(!ui)return;
    renderForm();
    ui.modal.hidden=false;
    ui.modal.style.zIndex='2147483647';
  }
  function closeSettings(){if(ui)ui.modal.hidden=true}

  function installStyles(){
    if(document.getElementById('ww1-style'))return;
    const style=el('style');style.id='ww1-style';style.textContent=`
      #ww1-modal[hidden]{display:none!important}
      #ww1-modal{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;padding:18px;background:#000c;font-family:"Malgun Gothic","Apple SD Gothic Neo",sans-serif;color:#e7e5e4}
      #ww1-modal *{box-sizing:border-box}
      #ww1-dialog{width:min(620px,96vw);max-height:92dvh;overflow:auto;border:1px solid #57534e;border-radius:12px;background:#1c1917;box-shadow:0 24px 70px #000;padding:18px}
      .ww1-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:14px}
      .ww1-title{margin:0;color:#fcd34d;font-size:20px;font-weight:700}.ww1-version{margin-top:2px;color:#a16207;font-size:11px}
      .ww1-close{border:0;background:transparent;color:#a8a29e;font-size:20px;cursor:pointer}.ww1-close:hover{color:#fff}
      .ww1-notice{margin-bottom:12px;padding:11px;border:1px solid #44403c;border-left:3px solid #d97706;border-radius:7px;background:#0c0a0999;color:#d6d3d1;font-size:12px;line-height:1.65}
      .ww1-form{overflow:hidden;border:1px solid #44403c;border-radius:8px;background:#0c0a0966}
      .ww1-row{min-height:58px;padding:10px 12px;border-bottom:1px solid #292524}.ww1-row:last-child{border-bottom:0}
      .ww1-check-row{display:flex;align-items:center;justify-content:space-between;gap:15px;cursor:pointer}
      .ww1-copy{display:flex;min-width:0;flex-direction:column}.ww1-label{color:#e7e5e4;font-size:13px;font-weight:600}.ww1-help{margin-top:3px;color:#78716c;font-size:11px;line-height:1.4}
      .ww1-fields{display:grid;grid-template-columns:minmax(0,1fr) minmax(120px,180px);align-items:center;gap:14px}
      #ww1-modal input[type=checkbox]{width:17px;height:17px;accent-color:#d97706}
      #ww1-modal input[type=text],#ww1-modal input[type=number]{width:100%;border:1px solid #57534e;border-radius:5px;background:#0c0a09;color:#f5f5f4;padding:8px;font:inherit;font-size:13px}
      .ww1-status{margin-top:12px;padding:9px 10px;border-radius:6px;background:#29252480;color:#d6d3d1;font-size:12px}.ww1-message{min-height:18px;margin-top:7px;color:#a8a29e;font-size:11px}.ww1-message[data-tone=error]{color:#fda4af}.ww1-message[data-tone=success]{color:#86efac}
      .ww1-done{width:100%;margin-top:12px;border:1px solid #b45309;border-radius:6px;background:#b45309;color:#fff;padding:9px;font-size:13px;font-weight:600;cursor:pointer}.ww1-done:hover{background:#d97706}
      .ww1-header-button[data-active=true]{background:#15803d!important;border-color:#22c55e!important;color:#f0fdf4!important}
      .ww1-header-button[data-active=true]:hover{background:#166534!important}
      .ww1-header-button[data-active=false]{background:#44403c!important;border-color:#57534e!important;color:#e7e5e4!important}
      .ww1-header-button[data-active=false]:hover{background:#57534e!important}
      .ww1-header-desktop{right:10.5rem!important;width:5.25rem!important;font-size:.65rem!important;font-weight:700!important}
      @media(min-width:640px){.ww1-header-topbar{padding-right:16.25rem!important}}
      .ww1-location-row{display:flex;flex-wrap:wrap;gap:4px;margin-top:4px}.ww1-location-chip{padding:1px 5px;border:1px solid #be185d;border-radius:3px;background:#500724;color:#fbcfe8;font-size:10px}
      @media(max-width:700px){#ww1-modal{padding:9px}.ww1-fields{grid-template-columns:1fr}.ww1-row{min-height:52px}.ww1-fields input{margin-top:2px}}
    `;document.head.append(style);
  }
  function installModal(){
    if(ui)return;
    installStyles();
    const modal=el('div');modal.id='ww1-modal';modal.hidden=true;
    const dialog=el('section');dialog.id='ww1-dialog';dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');dialog.setAttribute('aria-labelledby','ww1-title');
    const head=el('header','ww1-head'),heading=el('div'),title=el('h2','ww1-title','웨이트리스');title.id='ww1-title';heading.append(title,el('div','ww1-version','단일 웨이트리스 고용 및 설정'));
    const close=el('button','ww1-close','✕');close.type='button';close.title='닫기';close.addEventListener('click',closeSettings);head.append(heading,close);
    const notice=el('div','ww1-notice','이곳에서 웨이트리스를 고용할 수 있습니다. 웨이트리스는 고용과 동시에 10g, 이후 매일 아침 기상 직후 출근시 10g를 줘야합니다. 웨이트리스는 손님과 상호작용을 안하고, 인사/메뉴질문/서빙/청소/요리를 대신해줍니다. 다음날 출근이 불필요하다면 잠들기 전에 고용 취소를 해주세요.');
    const form=el('div','ww1-form');
    const hired=el('input');hired.type='checkbox';hired.addEventListener('change',()=>{if(hired.checked)hire();else cancelHire()});
    form.append(checkRow('웨이트리스 고용','고용 즉시 10g, 이후 매일 출근 시 10g가 필요합니다.',hired));
    const name=el('input');name.type='text';name.maxLength=32;name.value=config.name;name.addEventListener('change',()=>{config.name=normalName(name.value);saveConfig();renderForm()});
    const nameRow=el('label','ww1-row ww1-fields'),nameCopy=el('span','ww1-copy');nameCopy.append(el('span','ww1-label','웨이트리스 이름'),el('span','ww1-help','기본값: 메이드'));nameRow.append(nameCopy,name);form.append(nameRow);
    const location=el('input');location.type='checkbox';location.addEventListener('change',()=>{config.showLocation=location.checked;saveConfig()});
    form.append(checkRow('웨이트리스 위치 표시 여부','출근한 웨이트리스를 “모두의 현재 위치”의 홀에 표시합니다.',location));
    const clean=el('input');clean.type='number';clean.inputMode='numeric';clean.min='0';clean.max='100';clean.step='1';clean.addEventListener('change',()=>{config.cleanThreshold=Math.round(clamp(clean.value,0,100));saveConfig();renderForm()});
    const cleanRow=el('label','ww1-row ww1-fields'),cleanCopy=el('span','ww1-copy');cleanCopy.append(el('span','ww1-label','웨이트리스 자동 청결 관리 기준'),el('span','ww1-help','청결도가 이 수치보다 낮으면 자동으로 청소합니다. (0~100)'));cleanRow.append(cleanCopy,clean);form.append(cleanRow);
    const cookInput=el('input');cookInput.type='checkbox';cookInput.addEventListener('change',()=>{config.autoCook=cookInput.checked;saveConfig();renderForm()});
    form.append(checkRow('웨이트리스 자동 요리 여부','식재료가 있고 준비된 음식이 부족할 때 자동으로 요리합니다.',cookInput));
    const cookTarget=el('input');cookTarget.type='number';cookTarget.inputMode='numeric';cookTarget.min='1';cookTarget.max='100';cookTarget.step='1';cookTarget.addEventListener('change',()=>{config.readyFoodTarget=Math.round(clamp(cookTarget.value,1,100));saveConfig();renderForm()});
    const cookTargetRow=el('label','ww1-row ww1-fields'),cookTargetCopy=el('span','ww1-copy');cookTargetCopy.append(el('span','ww1-label','자동 요리 목표 수량'),el('span','ww1-help','준비된 음식이 이 수량에 도달할 때까지 자동으로 요리합니다. (1~100, 기본값: 4)'));cookTargetRow.append(cookTargetCopy,cookTarget);form.append(cookTargetRow);
    const status=el('div','ww1-status'),message=el('div','ww1-message');
    const done=el('button','ww1-done','닫기');done.type='button';done.addEventListener('click',closeSettings);
    dialog.append(head,notice,form,status,message,done);modal.append(dialog);document.body.append(modal);
    modal.addEventListener('click',event=>{if(event.target===modal)closeSettings()});
    ui={modal,hired,name,location,clean,cook:cookInput,cookTarget,status,message};
    renderForm();
    document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!modal.hidden)closeSettings()});
  }

  function installHeaderButtons(){
    document.querySelectorAll('.ww1-menu-button').forEach(node=>node.remove());
    const supports=[...document.querySelectorAll('button[title]')].filter(node=>['Wayward 후원하기','Support Wayward'].includes(node.title));
    for(const support of supports){
      const desktop=support.classList.contains('fixed'),id=desktop?'ww1-header-desktop':'ww1-header-mobile';
      if(support.previousElementSibling?.id===id)continue;
      const existing=document.getElementById(id);
      if(existing){support.before(existing);continue}
      const button=el('button',`${support.className.replace(/right-\[[^\]]+\]/g,'')} ww1-header-button ${desktop?'ww1-header-desktop':'ww1-header-mobile'}`,desktop?'웨이트리스':'W');
      button.id=id;button.type='button';button.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();openSettings()});
      support.before(button);
      if(desktop)document.querySelector('#root .sticky.top-0')?.classList.add('ww1-header-topbar');
    }
    renderStatus();
  }
  function decorateLocation(){
    const existing=[...document.querySelectorAll('.ww1-location-row')];
    const state=currentState();
    if(!config.showLocation||!isWorking(state)){existing.forEach(node=>node.remove());return}
    const title=[...document.querySelectorAll('span')].find(node=>['모두의 현재 위치','Where everyone is'].includes(node.textContent.trim()));
    if(!title){existing.forEach(node=>node.remove());return}
    let container=title.parentElement;
    for(let index=0;index<4&&container;index++,container=container.parentElement){
      if(container.querySelectorAll?.('div[class*="rounded"][class*="border"]').length>=2)break;
    }
    if(!container){existing.forEach(node=>node.remove());return}
    const cards=[...container.querySelectorAll('div[class*="rounded"][class*="border"]')];
    const hall=cards.find(card=>['홀','Taproom'].includes(card.firstElementChild?.textContent?.trim()));
    if(!hall){existing.forEach(node=>node.remove());return}
    let row=existing.find(node=>node.parentElement===hall)??null;
    existing.filter(node=>node!==row).forEach(node=>node.remove());
    if(!row){row=el('div','ww1-location-row');hall.append(row)}
    let chip=row.querySelector('.ww1-location-chip');
    if(!chip){chip=el('span','ww1-location-chip');row.append(chip)}
    if(chip.textContent!==config.name)chip.textContent=config.name;
    const titleText=workerStateText(state);if(chip.title!==titleText)chip.title=titleText;
  }
  function decorate(){decorateQueued=false;installHeaderButtons();decorateLocation()}
  function scheduleDecorate(){
    if(!ui||decorateQueued)return;
    decorateQueued=true;
    if(typeof requestAnimationFrame==='function')requestAnimationFrame(decorate);else setTimeout(decorate,0);
  }
  function installUi(){
    installModal();decorate();
    const observer=new MutationObserver(scheduleDecorate);
    observer.observe(document.body,{childList:true,subtree:true});
    setInterval(decorate,1000);
    let observedState=currentState();
    try{ue.subscribe(()=>{
      const state=currentState(),previous=observedState;
      observedState=state;
      const wokeForNewDay=!!state&&!!previous&&state.phase==='prep'&&previous.phase!=='prep';
      if(wokeForNewDay){
        const paid=processMorningWage(state);
        if(paid!==state){observedState=paid;replaceState(paid);return}
      }
      renderStatus();scheduleDecorate();
    })}catch{}
  }

  globalThis.__waywardSimpleWaitressPublic={
    openSettings,
    registerReservations(owner,provider){if(reservationProviders.has(owner))throw Error('Waitress reservation provider already registered');reservationProviders.set(owner,provider);return()=>reservationProviders.delete(owner);},
    getReservations(state){const busy=isWorking(state)&&runtime.readyAt>state.slot;return{customers:busy&&runtime.targetId?[runtime.targetId]:[],kitchenBusy:busy&&runtime.task==='요리'};},
    getConfig:()=>({...config}),
    isWorking:()=>isWorking(),
    getRuntime:()=>({...runtime}),
    tick
  };
  installNewGameDefaults();
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',installUi,{once:true});else installUi();
})();

  },
});
