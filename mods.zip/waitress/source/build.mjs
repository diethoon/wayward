// Local source is authoritative; preserve the original author header.
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('./mod.wml.js',import.meta.url),'utf8');
new vm.Script(source);
fs.writeFileSync(new URL('../mod.js',import.meta.url),'// 생성 파일. 수정: source/mod.wml.js — node source/build.mjs\n'+source);
