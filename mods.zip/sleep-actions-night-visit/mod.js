WML.define({
  id: 'sleep-actions-night-visit',
  name: '수면 중 투숙객 야간 방문',
  author: '민트좋아',
  symbols: {
    "applyEffects": {"raw":{"2026-11-01":"ft"},"doc":"야간 방문 개입 결과의 신뢰·원망·기분 변화를 원본 효과 경로로 적용"},
    "nextSceneVariant": {"raw":{"2026-11-01":"ey"},"doc":"대상이 알아차리고 수용한 야간 방문의 원본 손님 장면 변형 선택"},
    "ClosedDoorActions": {"raw":{"2026-11-01":"M5"},"doc":"야간 방문 중 원본의 일반 노크·문틈 보기·문 열기 묶음을 전용 문 앞 행동으로 대체"},
    "approachClosedDoor": {"raw":{"2026-11-01":"m$"},"doc":"방문 중 깨어난 플레이어를 대상 방의 닫힌 문 바깥 문턱으로 이동"},
    "roomSideForOccupant": {"raw":{"2026-11-01":"nD"},"doc":"방문 중 문 앞 플레이어를 원본 inside/outside/peeking 판정에 outside로 합성"},
    "relationshipInfluence": {"raw":{"2026-11-01":"fC"},"doc":"공용 기상 개입에서 설명을 믿지 않을 때 필요한 개입 권한과 비교하는 원본 최종 관계 영향력(Your say)"}
  },
  version: "1.4.13",
  game: "2026-11-01",
  role: 'sleep-actions-night-visit',
  requires: ['sleep-actions'],
  requiresVersion: { 'sleep-actions': '>=1.12.1 <2' },
  loadAfter: ['badguest', 'her-debt'],
  tags: ['h-scene'],
  description: '투숙객의 야간 방문·발견·개입·복귀 흐름을 수면 중 행동 기반 위에 추가합니다.',

  setup(api) {
    const ID = api.id;
    const OWNER_ID = ID;
    const WAKE_ACTION = `${ID}/wake`;
    const DOOR_KNOCK_ACTION = `${ID}/door-knock`;
    const DOOR_PEEK_ACTION = `${ID}/door-peek`;
    const DOOR_INTERVENE_ACTION = `${ID}/door-intervene`;
    const NATIVE_DOOR_ACTIONS = new Set(['knock_on_door', 'peek_inside', 'open_the_door']);
    const BAD_GUEST_LOCKED_DOOR_EVENT = 'bad_guest_locked_door';
    const BAD_GUEST_BREAK_DOOR_CHOICE = 'bad_guest_break_door';
    const BAD_GUEST_LEAVE_LOCKED_CHOICE = 'bad_guest_leave_locked';
    const DOOR_CHECK_MINUTES = 1;
    const T = (ko, en) => api.t({ ko, en });
    const h = api.ui.h;
    const React = api.fn('React');
    const JSX = api.fn('jsx');
    const ActionButton = api.fn('ActionButton');
    const sleepActions = api.use('sleep-actions');
    const badGuest = (() => {
      try {
        const value = api.use('badguest');
        return value?.apiVersion >= 5 && typeof value.getState === 'function' ? value : null;
      } catch {
        return null;
      }
    })();
    const herDebt = (() => {
      try {
        const value = api.use('her-debt');
        return value?.apiVersion === 1 ? value : null;
      } catch {
        return null;
      }
    })();
    if (!sleepActions || sleepActions.apiVersion < 12) {
      throw new Error('sleep-actions-night-visit requires sleep-actions API 12 or newer');
    }
    if (typeof sleepActions.state?.sleepRoom !== 'function'
      || typeof sleepActions.state?.bedSharing !== 'function'
      || typeof sleepActions.patron?.canStartFlow !== 'function') {
      throw new Error('sleep-actions-night-visit requires the sleep-actions pre7 room and flow API');
    }

    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
    const number = (value, fallback = 0) => Number.isFinite(Number(value))
      ? Number(value) : fallback;
    const whole = (value, fallback = 0) => Math.round(number(value, fallback));

    const DEFAULTS = Object.freeze({
      baseChance: 4,
      relationshipBonus: 16,
      platonicWeight: 0.2,
      romanticWeight: 0.3,
      sexualWeight: 0.5,
      playerNoticeBaseChance: 72,
      playerNoticeWitBonus: 23,
      wifeNoticeBaseChance: 35,
      wifeNoticeWitWeight: 0.35,
      wifeNoticeComposureWeight: 0.15,
      wifeNoticeMinimum: 5,
      wifeNoticeMaximum: 75,
      guestRoomMoveChance: 25,
    });

    function settings() {
      const raw = api.settings.get({}) || {};
      return Object.fromEntries(Object.keys(DEFAULTS).map(key => [
        key, number(raw[key], DEFAULTS[key]),
      ]));
    }

    function normalizeIntrusion(value) {
      if (!value || typeof value !== 'object' || typeof value.customerId !== 'string') return null;
      return {
        customerId: value.customerId,
        customerName: typeof value.customerName === 'string' ? value.customerName : value.customerId,
        room: typeof value.room === 'string' ? value.room : null,
        originRoom: typeof value.originRoom === 'string' ? value.originRoom : null,
        // Older saves could only start a visit while both characters shared a room.
        sharedSleepRoom: value.sharedSleepRoom !== false,
        playerSleepRoom: typeof value.playerSleepRoom === 'string' ? value.playerSleepRoom : null,
        playerOriginRoom: typeof value.playerOriginRoom === 'string' ? value.playerOriginRoom : null,
        playerWasInSleepRoom: value.playerWasInSleepRoom === true,
        noticed: value.noticed === true,
        wifeNoticed: value.wifeNoticed === true,
        targetInvited: value.targetInvited === true,
        locationMode: value.locationMode === 'guest_room' ? 'guest_room' : 'in_place',
        locationModeForced: value.locationModeForced === true,
        awakeConsent: value.awakeConsent === true,
        playerPeeking: value.playerPeeking === true,
        playerAtDoor: value.playerAtDoor === true,
        playerDoorRoom: typeof value.playerDoorRoom === 'string' ? value.playerDoorRoom : null,
        playerWoke: value.playerWoke === true,
        sleepUnderway: value.sleepUnderway !== false,
      };
    }

    const currentNight = state => {
      const night = sleepActions.state.bedSharing(state)?.night;
      return Number.isFinite(Number(night)) ? Number(night) : whole(state?.day, 0);
    };
    const normalizeCustomerIds = value => [...new Set(
      (Array.isArray(value) ? value : []).filter(item => typeof item === 'string' && item.length > 0),
    )];
    const dataOf = state => {
      const source = state?.mods?.[ID] || {};
      const intrusion = normalizeIntrusion(source.intrusion);
      const night = currentNight(state);
      const sourceNight = Number.isFinite(Number(source.visitNight)) ? Number(source.visitNight) : null;
      const migratedIds = whole(source.schemaVersion) < 2 && intrusion ? [intrusion.customerId] : [];
      return {
        schemaVersion: 2,
        intrusion,
        visitNight: night,
        visitedCustomerIds: sourceNight === night
          ? normalizeCustomerIds(source.visitedCustomerIds)
          : normalizeCustomerIds(migratedIds),
      };
    };
    const writeData = (state, patch) => ({
      ...state,
      mods: {
        ...(state?.mods || {}),
        [ID]: { schemaVersion: 2, ...dataOf(state), ...patch },
      },
    });
    const intrusionOf = state => dataOf(state).intrusion;
    const characterOf = state => sleepActions.state.character(state);
    const wifeName = state => characterOf(state)?.name || T('그녀', 'She');
    const heroOf = state => ({
      elena_farmgirl: 'elena', mara_citygirl: 'mara', pippa_waif: 'pippa',
    })[characterOf(state)?.archetypeId] || 'other';
    const stringSeed = value => [...String(value || '')]
      .reduce((total, character) => total + character.codePointAt(0), 0);
    let activeDoorCheck = null;

    // Match Sleep Actions' presentation-only rotation: no judgment roll or save field.
    function sceneLine(state, key, pairs, step = whole(state?.slot)) {
      const start = Math.abs(stringSeed(key) + whole(step) + whole(state?.day)) % pairs.length;
      const recent = (Array.isArray(state?.logs) ? state.logs
        : Array.isArray(state?.log) ? state.log : [])
        .slice(-24).map(entry => typeof entry === 'string' ? entry : String(entry?.text || ''));
      for (let offset = 0; offset < pairs.length; offset += 1) {
        const pair = pairs[(start + offset) % pairs.length];
        const line = T(pair[0], pair[1]);
        if (!recent.some(previous => previous.includes(line))) return line;
      }
      return T(...pairs[start]);
    }

    function voiceLine(state, key, pools) {
      const hero = heroOf(state);
      return sceneLine(state, `${key}:${hero}`, pools[hero] || pools.other);
    }

    function visitChance(context, value = settings()) {
      const relationship = context?.relationship || {};
      const positiveBond = clamp(
        Math.max(0, number(relationship.platonic)) * value.platonicWeight
          + Math.max(0, number(relationship.romantic)) * value.romanticWeight
          + Math.max(0, number(relationship.sexual)) * value.sexualWeight,
        0, 100,
      );
      return clamp(value.baseChance + value.relationshipBonus * (positiveBond / 100), 0, 100) / 100;
    }

    function playerNoticeChance(context, value = settings()) {
      return clamp(value.playerNoticeBaseChance
        + value.playerNoticeWitBonus * (clamp(number(context?.playerWit, 50), 0, 100) / 100), 0, 100) / 100;
    }

    function wifeNoticeChance(context, value = settings()) {
      const minimum = clamp(Math.min(value.wifeNoticeMinimum, value.wifeNoticeMaximum), 0, 100);
      const maximum = clamp(Math.max(value.wifeNoticeMinimum, value.wifeNoticeMaximum), 0, 100);
      return clamp(value.wifeNoticeBaseChance
        + (number(context?.wifeWit, 50) - 50) * value.wifeNoticeWitWeight
        + (number(context?.wifeComposure, 50) - 50) * value.wifeNoticeComposureWeight,
      minimum, maximum) / 100;
    }

    function herDebtFlowConflict(state, customerId, rooms) {
      const flowState = herDebt?.selectors?.flowState;
      if (typeof flowState !== 'function') return false;
      const filters = [
        { customerId },
        ...[...new Set(rooms.filter(room => typeof room === 'string' && room.length > 0))]
          .map(room => ({ room })),
      ];
      return filters.some(filter => {
        try { return flowState(state, filter)?.matchingOccupied === true; }
        catch { return false; }
      });
    }

    function candidates(state) {
      if (!sleepActions.getSettings().patronActionsEnabled || !state || state.pendingEvent
        || state.activeScene?.patron || state.activeScene?.sex || intrusionOf(state)) return [];
      if (state.phase !== 'bedroom' || !sleepActions.patron.canStartFlow(state)) return [];
      const sleepSession = sleepActions.getState(state)?.session;
      if (sleepSession?.kind === 'patron') return [];
      const sleepRoom = sleepActions.state.sleepRoom(state);
      if (!sleepRoom || !Array.isArray(state.locations?.[sleepRoom]?.occupants)) return [];
      const visitedCustomerIds = new Set(dataOf(state).visitedCustomerIds);
      return (state.customers || []).filter(customer => {
        const rentedRoom = sleepActions.patron.rentedRoom(state, customer.id);
        return customer.isResident
          && sleepActions.patron.intentEligible(customer, 'interested')
          && !visitedCustomerIds.has(customer.id)
          && !sleepActions.patron.onCooldown(state, customer.id)
          && customer.status !== 'gone'
          && customer.status !== 'leaving'
          && !api.fn('brothelCustomerBusy')(state, customer.id)
          && !!rentedRoom
          && !herDebtFlowConflict(state, customer.id, [sleepRoom, rentedRoom]);
      });
    }

    function context(state, customerId, options = {}) {
      const customer = candidates(state).find(item => item.id === customerId);
      if (!customer) return null;
      const wife = characterOf(state);
      const attributes = api.fn('getEffectiveAttributes')(wife) || wife?.attributes || {};
      const sleepRoom = sleepActions.state.sleepRoom(state);
      const bedSharing = sleepActions.state.bedSharing(state);
      return Object.freeze({
        customer,
        sleepRoom,
        relationship: sleepActions.patron.relationship(state, customer),
        sharedSleepRoom: bedSharing?.sameBed === true,
        playerSleepRoom: typeof bedSharing?.playerRoom === 'string' ? bedSharing.playerRoom : 'bedroom',
        playerOriginRoom: api.fn('playerLocation')(state),
        playerInSleepRoom: api.fn('playerLocation')(state) === sleepRoom,
        targetInvited: options.targetInvited === true,
        playerWit: clamp(number(state.player?.attributes?.wit, 50), 0, 100),
        wifeWit: number(attributes.wit, 50),
        wifeComposure: number(attributes.composure, 50),
      });
    }

    function chooseVisitor(state, value = settings()) {
      const entries = candidates(state).map(customer => ({ customer, context: context(state, customer.id) }))
        .filter(entry => entry.context)
        .sort((left, right) => visitChance(right.context, value) - visitChance(left.context, value));
      for (const entry of entries) if (Math.random() < visitChance(entry.context, value)) return entry;
      return null;
    }

    function awareLocation(state, customer) {
      const wife = characterOf(state);
      const attributes = api.fn('getEffectiveAttributes')(wife) || wife?.attributes || {};
      const relationship = sleepActions.patron.relationship(state, customer);
      const openlyCurious = sleepActions.state.morningDisposition(state, state.primaryCharacterId) === 'curious';
      const assertive = sleepActions.state.hasLatentTrait(wife, 'latent_dominant')
        && number(attributes.confidence, 50) >= 60;
      const familiar = number(relationship?.sexual) >= 70
        && number(relationship?.sexual) >= number(relationship?.romantic);
      return openlyCurious || assertive || familiar ? 'in_place' : 'guest_room';
    }

    function prepareSleepingTarget(state) {
      if (sleepActions.state.isUnconscious(state)) return state;
      return api.fn('updateWife')(state, wife => ({
        ...wife,
        currentTask: 'sleeping',
        taskTarget: undefined,
        busyUntilSlot: Math.max(whole(wife.busyUntilSlot), whole(state.slot) + 9999),
        retiredAtSlot: wife.retiredAtSlot ?? whole(state.slot),
      }));
    }

    function returnPlayerAfterVisit(state, intrusion) {
      if (!intrusion.playerAtDoor && !intrusion.playerWoke) return state;
      const visitRoom = intrusion.locationMode === 'guest_room' ? intrusion.room : intrusion.originRoom;
      if (!visitRoom || api.fn('playerLocation')(state) !== visitRoom) return state;
      const plannedRoom = intrusion.playerSleepRoom || 'bedroom';
      if (plannedRoom === visitRoom && Array.isArray(state.locations?.[plannedRoom]?.occupants)) {
        return state;
      }
      const destination = Array.isArray(state.locations?.[plannedRoom]?.occupants)
        ? plannedRoom
        : [intrusion.playerOriginRoom]
          .find(room => room && room !== visitRoom && Array.isArray(state.locations?.[room]?.occupants));
      if (!destination) return state;
      let next = api.fn('moveOccupant')(state, 'player', destination);
      next = api.fn('log')(next, sceneLine(next, 'return:player', [
        ['당신은 발걸음을 돌려 잠자리로 돌아갑니다.', 'You turn back and return to your bed.'],
        ['복도로 나온 당신은 그제야 길게 숨을 내쉽니다. 한동안 그 자리에 서 있다가 잠자리로 발길을 돌립니다.', 'Only when you reach the corridor do you let out a long breath. You stand there for a moment before heading back to bed.'],
        ['당신은 문 앞을 한 번 돌아본 뒤 잠자리로 향합니다.', 'You glance back at the door once, then head for your bed.'],
      ]));
      return next;
    }

    function closeVisit(state, options = {}) {
      const intrusion = intrusionOf(state);
      if (!intrusion) return state;
      let next = sleepActions.patron.clearFlow(state, options.participants || participants(state));
      next = returnPlayerAfterVisit(next, intrusion);
      const targetRoom = intrusion.originRoom;
      const visitor = (next.customers || []).find(item => item.id === intrusion.customerId);
      if (targetRoom && Array.isArray(next.locations?.[targetRoom]?.occupants)
        && api.fn('wifeLocation')(next) !== targetRoom) {
        next = api.fn('moveOccupant')(next, next.primaryCharacterId, targetRoom);
        const name = visitor?.name || intrusion.customerName;
        const line = sleepActions.state.isUnconscious(next)
          ? sceneLine(next, 'return:unconscious', [
            [`${name}은(는) ${wifeName(next)}을(를) 원래 방으로 데려와 조심스럽게 눕힙니다. 그녀는 눈을 뜨지 않습니다.`, `${name} carries ${wifeName(next)} back to her room and lays her down carefully. Her eyes stay closed.`],
            [`${name}은(는) ${wifeName(next)}을(를) 안고 돌아옵니다. 그녀를 내려놓고도 한동안 손을 떼지 못합니다.`, `${name} carries ${wifeName(next)} back. After laying her down, he keeps his hands there for a moment.`],
            [`${name}은(는) ${wifeName(next)}을(를) 원래 방에 눕힌 뒤 발소리를 죽이고 나갑니다.`, `${name} lays ${wifeName(next)} down in her room, then slips out quietly.`],
          ])
          : sceneLine(next, 'return:awake', [
            [`${wifeName(next)}은(는) 손님을 뒤로하고 원래 있던 방으로 돌아옵니다.`, `${wifeName(next)} leaves the patron behind and returns to her room.`],
            [`${wifeName(next)}은(는) 문턱에서 한 번 멈췄다가 원래 방으로 돌아옵니다.`, `${wifeName(next)} pauses at the threshold, then returns to her room.`],
            [`${wifeName(next)}은(는) 돌아보지 않고 방을 나섭니다. 원래 있던 곳에 돌아와서야 걸음을 늦춥니다.`, `${wifeName(next)} leaves without looking back. She slows only when she reaches her room.`],
          ]);
        next = api.fn('log')(next, line);
      }
      if (visitor && visitor.status !== 'gone' && visitor.status !== 'leaving'
        && intrusion.room && Array.isArray(next.locations?.[intrusion.room]?.occupants)
        && api.fn('patronControlCustomerLocation')(next, visitor.id) !== intrusion.room) {
        next = api.fn('moveOccupant')(next, visitor.id, intrusion.room);
      }
      next = writeData(next, { intrusion: null });
      if (options.resumeSleep === false) return next;
      return api.fn('reduceGameAction')(next, {
        type: 'sleep', underway: intrusion.sleepUnderway, sleepActionsNightVisitBypass: true,
      });
    }

    function closePlayerIntervention(state, participantMap = {}) {
      const next = sleepActions.state.isUnconscious(state)
        ? sleepActions.wake.character(state) : state;
      return closeVisit(next, { resumeSleep: false, participants: participantMap });
    }

    function rejectAwareVisit(state, customer, decision) {
      const wife = wifeName(state);
      const patron = customer.name;
      const pools = decision.emphatic ? {
        elena: [
          [`${wife}은(는) 몸을 일으켜 ${patron}을(를) 노려봅니다. "지금 나가세요." 그가 손을 거두고 자기 객실로 물러납니다.`, `${wife} sits up and glares at ${patron}. "Leave. Now." He withdraws his hand and retreats to his room.`],
          [`${wife}이(가) 문 쪽을 가리킵니다. "다시는 이렇게 들어오지 마세요." ${patron}은(는) 대꾸하지 못하고 돌아갑니다.`, `${wife} points to the door. "Don't come in like this again." ${patron} leaves without an answer.`],
        ],
        mara: [
          [`${wife}이(가) ${patron}의 손목을 쳐 냅니다. "꺼져. 지금." 그가 자기 객실로 뒷걸음질 칩니다.`, `${wife} knocks ${patron}'s wrist aside. "Get out. Now." He backs toward his room.`],
          [`${wife}은(는) 그가 다가오기 전에 길을 막습니다. "내가 부른 적 없어. 돌아가." ${patron}은(는) 말없이 물러납니다.`, `${wife} blocks him before he can come closer. "I didn't call you. Go back." ${patron} retreats in silence.`],
        ],
        pippa: [
          [`${wife}은(는) 눈을 뜨자마자 ${patron}의 손을 뿌리칩니다. "싫어! 나가!" 그가 놀라 자기 객실로 돌아갑니다.`, `${wife} wakes and bats ${patron}'s hand away. "No! Get out!" Startled, he returns to his room.`],
          [`${wife}이(가) 한 걸음 물러나 문을 가리킵니다. "이건 장난 아니야. 나가." ${patron}은(는) 시선을 피하며 돌아갑니다.`, `${wife} steps back and points to the door. "This isn't a game. Leave." ${patron} looks away and goes.`],
        ],
        other: [
          [`${wife}은(는) 문소리에 눈을 뜨고 ${patron}을(를) 노려봅니다. "당장 나가." 그는 자기 객실로 물러납니다.`, `${wife} opens her eyes and glares at ${patron}. "Get out. Now." He retreats to his room.`],
          [`${wife}이(가) ${patron}의 손을 밀쳐 냅니다. "오지 마." 그는 잠시 멈췄다가 자기 객실로 돌아갑니다.`, `${wife} pushes ${patron}'s hand away. "Stay back." He pauses, then returns to his room.`],
        ],
      } : {
        elena: [
          [`${wife}은(는) 몸을 일으켜 ${patron}을(를) 바라봅니다. "돌아가 주세요." 그가 머뭇거리다 자기 객실로 갑니다.`, `${wife} sits up and looks at ${patron}. "Please go back." He hesitates, then returns to his room.`],
          [`${wife}이(가) 다가온 손을 조용히 막습니다. "오늘은 안 돼요." ${patron}은(는) 손을 내리고 돌아갑니다.`, `${wife} quietly stops his hand. "Not tonight." ${patron} lowers it and goes back.`],
        ],
        mara: [
          [`${wife}은(는) ${patron}을(를) 알아보고 고개를 젓습니다. "오늘은 아니야. 돌아가." 그가 입을 다물고 객실로 물러납니다.`, `${wife} recognizes ${patron} and shakes her head. "Not tonight. Go back." He falls silent and retreats.`],
          [`${wife}이(가) 그의 손을 내려놓습니다. "늦었어. 내일 얘기해." ${patron}은(는) 더 다가오지 않고 자기 객실로 갑니다.`, `${wife} lowers his hand. "It's late. Talk to me tomorrow." ${patron} goes back without coming closer.`],
        ],
        pippa: [
          [`${wife}은(는) 눈을 비비다 ${patron}을(를) 보고 손을 내립니다. "오늘은 싫어. 돌아가." 그가 자기 객실로 물러납니다.`, `${wife} rubs her eyes, sees ${patron}, and lowers her hand. "Not tonight. Go back." He retreats to his room.`],
          [`${wife}이(가) 손바닥을 들어 그를 멈춥니다. "나 지금 졸려. 내일 봐." ${patron}은(는) 더 말하지 않고 돌아갑니다.`, `${wife} raises a palm to stop him. "I'm sleepy. See you tomorrow." ${patron} returns without another word.`],
        ],
        other: [
          [`${wife}은(는) ${patron}을(를) 보고 몸을 일으킵니다. "돌아가요." 그가 자기 객실로 물러납니다.`, `${wife} sits up when she sees ${patron}. "Go back." He retreats to his room.`],
          [`${wife}이(가) 고개를 저으며 그의 손을 막습니다. ${patron}은(는) 한 걸음 물러나 자기 객실로 갑니다.`, `${wife} shakes her head and stops his hand. ${patron} steps back and goes to his room.`],
        ],
      };
      const line = voiceLine(state, `reject:${decision.emphatic ? 'emphatic' : 'quiet'}`, pools);
      let next = api.fn('updateWife')(state, wife => ({
        ...wife, lastResponse: line, lastResponseSlot: whole(state.slot),
        lastResponseType: sleepActions.wake.responseType(decision),
      }));
      next = api.fn('log')(next, line);
      next = sleepActions.patron.startCooldowns(next, [customer.id]);
      return closeVisit(next);
    }

    function setAwakeGropingScene(state, interaction) {
      const nextInteraction = {
        ...api.fn('transitionPatronStage')(
          interaction, 'groping', characterOf(state), { by: ID },
        ),
        sleepActionsStage: undefined,
        lateralAct: undefined,
        watchedHimStroke: undefined,
        ticksAtStage: 0,
      };
      let next = {
        ...state,
        activeScene: { ...(state.activeScene || {}), patron: nextInteraction },
        pendingEvent: undefined,
      };
      return api.fn('updateWife')(next, wife => ({
        ...wife,
        sceneOverride: 'groped_tits',
        sceneVariant: api.fn('nextSceneVariant')(),
        sceneSetAtSlot: whole(state.slot),
      }));
    }

    function startAwareGroping(state, customer, decision) {
      const intrusion = intrusionOf(state);
      const locationMode = intrusion.locationModeForced
        ? intrusion.locationMode : awareLocation(state, customer);
      const destination = locationMode === 'guest_room' ? intrusion.room : intrusion.originRoom;
      if (!destination || !Array.isArray(state.locations?.[destination]?.occupants)) {
        return rejectAwareVisit(state, customer, { ...decision, emphatic: false });
      }
      let next = { ...state, pendingEvent: undefined };
      next = { ...next, customers: next.customers.map(item => item.id === customer.id
        ? { ...item, intent: 'predatory' } : item) };
      next = sleepActions.wake.character(next);
      if (api.fn('wifeLocation')(next) !== destination) {
        next = api.fn('moveOccupant')(next, next.primaryCharacterId, destination);
      }
      if (api.fn('patronControlCustomerLocation')(next, customer.id) !== destination) {
        next = api.fn('moveOccupant')(next, customer.id, destination);
      }
      next = api.fn('startPatronInteraction')(next, customer.id, undefined, '', { abed: true });
      if (next.activeScene?.patron?.customerId !== customer.id) return closeVisit(next);
      next = setAwakeGropingScene(next, next.activeScene.patron);
      next = writeData(next, { intrusion: { ...intrusion, wifeNoticed: true, locationMode, awakeConsent: true } });
      const wife = wifeName(next);
      const patron = customer.name;
      const key = `${intrusion.targetInvited ? 'invited' : 'noticed'}:${locationMode}`;
      const pools = intrusion.targetInvited ? locationMode === 'in_place' ? {
        elena: [
          [`${wife}은(는) ${patron}이(가) 들어오자 손을 내밉니다. "오셨네요." 그녀가 그의 손을 제 쪽으로 당깁니다.`, `${wife} reaches out when ${patron} enters. "You came." She draws his hand toward her.`],
          [`${wife}은(는) ${patron}이(가) 문을 닫을 때까지 기다립니다. "조용히 해 주세요." 그의 손을 잡아 가까이 이끕니다.`, `${wife} waits for ${patron} to close the door. "Please be quiet." She takes his hand and draws him close.`],
        ],
        mara: [
          [`${wife}은(는) ${patron}을(를) 보자 손을 뻗습니다. "늦었네." 그의 손목을 잡아 제 쪽으로 끌어옵니다.`, `${wife} reaches for ${patron}. "You're late." She takes his wrist and draws him closer.`],
          [`${wife}이(가) ${patron}의 손을 잡습니다. 『내가 불렀어. 이제 와서 겁낼 것 없잖아.』 손끝에 힘이 들어갑니다.`, `${wife} takes ${patron}'s hand. 『I called him. No use losing my nerve now.』 Her grip tightens.`],
        ],
        pippa: [
          [`${wife}이(가) ${patron}을(를) 보자 손짓합니다. "왔어? 쉿, 이리 와." 그녀가 그의 손을 잡습니다.`, `${wife} beckons when she sees ${patron}. "You came? Shh, over here." She takes his hand.`],
          [`${wife}은(는) ${patron}이(가) 가까워지자 입가에 손가락을 댑니다. "조용히." 곧 그 손으로 그의 손을 끌어당깁니다.`, `${wife} puts a finger to her lips as ${patron} approaches. "Quiet." Then she uses that hand to draw him closer.`],
        ],
        other: [
          [`${wife}은(는) 자신이 부른 ${patron}의 손을 잡아 제 쪽으로 이끕니다.`, `${wife} takes the hand of ${patron}, whom she invited, and draws him toward her.`],
          [`${wife}이(가) ${patron}을(를) 가까이 부릅니다. 그가 손을 내밀자 그녀가 잡습니다.`, `${wife} beckons ${patron} closer and takes the hand he offers.`],
        ],
      } : {
        elena: [
          [`${wife}은(는) ${patron}을(를) 따라 객실로 갑니다. "문은 조용히 닫아 주세요." 그의 손이 닿아도 물러서지 않습니다.`, `${wife} follows ${patron} to his room. "Please close the door quietly." She does not pull away when he touches her.`],
          [`${wife}은(는) ${patron}의 발소리를 따라 객실로 향합니다. 문턱에서 잠시 멈췄다가 그의 손을 잡습니다.`, `${wife} follows ${patron}'s footsteps to his room. She pauses at the threshold, then takes his hand.`],
        ],
        mara: [
          [`${wife}이(가) ${patron}의 등을 가볍게 밀어 객실로 보냅니다. "네 방으로 가." 그녀도 따라 들어가 그의 손을 잡습니다.`, `${wife} gives ${patron} a light push toward his room. "Your room." She follows him inside and takes his hand.`],
          [`${wife}은(는) ${patron}을(를) 따라 복도를 지납니다. "발소리 좀 죽여." 객실에 들어서자 그의 손을 제 쪽으로 당깁니다.`, `${wife} follows ${patron} down the corridor. "Keep your steps down." Inside his room, she draws his hand toward her.`],
        ],
        pippa: [
          [`${wife}은(는) ${patron}을(를) 따라 객실로 갑니다. "진짜 조용히 가야 해." 문이 닫히자 그의 손을 잡습니다.`, `${wife} follows ${patron} to his room. "We have to be really quiet." Once the door closes, she takes his hand.`],
          [`${wife}이(가) 복도에서 ${patron}의 손을 잠깐 놓습니다. 객실에 들어서자 다시 손을 찾아 잡습니다.`, `${wife} lets go of ${patron}'s hand in the corridor. Inside his room, she reaches for it again.`],
        ],
        other: [
          [`${wife}은(는) 자신이 부른 ${patron}을(를) 따라 객실로 갑니다. 그의 손이 닿아도 물러서지 않습니다.`, `${wife} follows ${patron}, whom she invited, to his room. She does not pull away when he touches her.`],
          [`${wife}이(가) ${patron}을(를) 따라 객실에 들어섭니다. 문이 닫히자 그녀가 먼저 그의 손을 잡습니다.`, `${wife} enters ${patron}'s room behind him. When the door closes, she takes his hand first.`],
        ],
      } : locationMode === 'in_place' ? {
        elena: [
          [`${wife}은(는) 문소리에 눈을 뜹니다. "조용히 해 주세요." ${patron}의 손이 닿아도 밀어내지 않습니다.`, `${wife} opens her eyes at the door. "Please be quiet." She does not push ${patron}'s hand away when it touches her.`],
          [`${wife}은(는) ${patron}의 손을 내려다보다 시선을 돌립니다. 그가 다시 손을 뻗어도 그녀는 막지 않습니다.`, `${wife} looks down at ${patron}'s hand, then away. She does not stop him when he reaches out again.`],
        ],
        mara: [
          [`${wife}은(는) ${patron}을(를) 보고 손을 움켜쥡니다. "문 닫아." 그가 다가오자 주먹을 풀지만 손은 밀어내지 않습니다.`, `${wife} sees ${patron} and clenches her hand. "Close the door." As he comes closer, her fist loosens, but she does not push him away.`],
          [`${wife}이(가) 잠시 ${patron}의 손목을 붙잡습니다. 손끝의 힘을 풀자 그의 손이 다시 그녀에게 닿습니다.`, `${wife} catches ${patron}'s wrist for a moment. When her grip loosens, his hand reaches her again.`],
        ],
        pippa: [
          [`${wife}은(는) 눈을 뜨고 ${patron}을(를) 빤히 봅니다. "지금?" 그의 손이 닿아도 물러서지 않습니다.`, `${wife} opens her eyes and stares at ${patron}. "Now?" She does not draw back when he touches her.`],
          [`${wife}이(가) 입가에 손가락을 댑니다. ${patron}의 손이 다가오자 손가락을 내리지만 그를 막지는 않습니다.`, `${wife} puts a finger to her lips. When ${patron}'s hand approaches, she lowers it without stopping him.`],
        ],
        other: [
          [`${wife}은(는) 문소리에 눈을 뜹니다. ${patron}의 손이 닿아도 밀어내지 않습니다.`, `${wife} opens her eyes at the door. She does not push ${patron}'s hand away.`],
          [`${wife}은(는) ${patron}을(를) 알아보고 잠시 바라봅니다. 그가 손을 뻗자 그녀는 고개만 돌립니다.`, `${wife} recognizes ${patron} and watches him for a moment. When he reaches out, she only turns her head.`],
        ],
      } : {
        elena: [
          [`${wife}은(는) 문소리에 눈을 뜨고 ${patron}을(를) 바라봅니다. 잠시 뒤 그를 따라 객실로 갑니다. 그의 손이 닿아도 물러서지 않습니다.`, `${wife} opens her eyes and looks at ${patron}. After a pause, she follows him to his room and does not pull away when he touches her.`],
          [`${wife}은(는) 방 문턱에서 한 번 멈춥니다. ${patron}을(를) 따라 객실에 들어선 뒤에도 그의 손을 막지는 않습니다.`, `${wife} pauses at the doorway before following ${patron} to his room. Even there, she does not stop his hand.`],
        ],
        mara: [
          [`${wife}은(는) ${patron}을(를) 보고 낮게 말합니다. "여긴 안 돼." 그를 따라 객실로 가지만 다가온 손은 밀어내지 않습니다.`, `${wife} sees ${patron} and speaks quietly. "Not here." She follows him to his room and does not push away his hand.`],
          [`${wife}은(는) 입을 굳게 다문 채 ${patron}을(를) 따라 복도를 지납니다. 객실에서 그가 손을 대도 돌아서지 않습니다.`, `${wife} follows ${patron} down the corridor, her mouth set. In his room, she does not turn away when he touches her.`],
        ],
        pippa: [
          [`${wife}은(는) ${patron}의 얼굴과 열린 문을 번갈아 봅니다. "저쪽으로?" 그를 따라 객실에 들어가며 다가온 손을 밀어내지 않습니다.`, `${wife} looks between ${patron} and the open door. "Over there?" She follows him to his room without pushing his hand away.`],
          [`${wife}은(는) 복도에서 몇 번이나 뒤를 돌아봅니다. 그래도 ${patron}을(를) 따라 객실에 들어가고 그의 손을 막지는 않습니다.`, `${wife} looks back several times in the corridor. Still, she follows ${patron} into his room and does not stop his hand.`],
        ],
        other: [
          [`${wife}은(는) 눈을 뜨고 ${patron}을(를) 바라봅니다. 잠시 뒤 그를 따라 객실로 가고, 다가온 손을 밀어내지 않습니다.`, `${wife} opens her eyes and looks at ${patron}. After a pause, she follows him to his room and does not push his hand away.`],
          [`${wife}은(는) 방을 한번 돌아본 뒤 ${patron}의 객실로 향합니다. 그가 손을 대도 밀어내지 않습니다.`, `${wife} glances back at the room before going to ${patron}'s. She does not push him away when he touches her.`],
        ],
      };
      const line = voiceLine(next, `accept:${key}`, pools);
      next = api.fn('updateWife')(next, wife => ({
        ...wife, lastResponse: line, lastResponseSlot: whole(next.slot),
        lastResponseType: sleepActions.wake.responseType(decision),
      }));
      next = api.fn('log')(next, line);
      next = {
        ...next,
        activeScene: {
          ...next.activeScene,
          patron: { ...next.activeScene.patron, ticksAtStage: -1 },
        },
      };
      return api.fn('processPatronInteractionTick')(next);
    }

    function startUnawareVisit(state, customer) {
      const intrusion = intrusionOf(state);
      const targetConditionKo = sleepActions.state.isPassedOut(state) ? '정신을 잃은' : '잠든';
      const targetConditionEn = sleepActions.state.isPassedOut(state) ? 'unconscious' : 'asleep';
      const destination = intrusion.locationMode === 'guest_room' ? intrusion.room : intrusion.originRoom;
      let next = { ...state, pendingEvent: undefined };
      next = { ...next, customers: next.customers.map(item => item.id === customer.id
        ? { ...item, intent: 'predatory' } : item) };
      next = prepareSleepingTarget(next);
      if (api.fn('wifeLocation')(next) !== destination) {
        next = api.fn('moveOccupant')(next, next.primaryCharacterId, destination);
      }
      if (api.fn('patronControlCustomerLocation')(next, customer.id) !== destination) {
        next = api.fn('moveOccupant')(next, customer.id, destination);
      }
      next = sleepActions.patron.scheduleApproach(next, {
        customerId: customer.id,
        immediate: true,
        style: 'secretive',
        reason: ID,
        ownerId: OWNER_ID,
        minimumIntent: 'interested',
        alreadyPrivate: true,
      });
      const wife = wifeName(next);
      const patron = customer.name;
      const visitLine = intrusion.locationMode === 'in_place'
        ? intrusion.sharedSleepRoom ? sceneLine(next, `approach:shared:${targetConditionKo}`, [
          [`${patron}은(는) 당신 쪽을 한 번 보고 ${targetConditionKo} ${wife}에게 다가갑니다.`, `${patron} glances your way, then approaches ${wife}, still ${targetConditionEn}.`],
          [`${patron}은(는) 당신 곁을 발소리 없이 지납니다. ${targetConditionKo} ${wife} 앞에서 걸음을 멈춥니다.`, `${patron} passes you without a sound and stops beside ${wife}, still ${targetConditionEn}.`],
          [`작은 발소리가 나자 ${patron}은(는) 잠시 멈춥니다. 당신이 움직이지 않자 ${targetConditionKo} ${wife} 쪽으로 몸을 굽힙니다.`, `${patron} pauses at the sound of his own step. When you do not stir, he bends toward ${wife}, still ${targetConditionEn}.`],
        ]) : sceneLine(next, `approach:separate:${targetConditionKo}`, [
          [`${patron}은(는) ${targetConditionKo} ${wife}의 곁으로 다가갑니다.`, `${patron} approaches ${wife}, still ${targetConditionEn}.`],
          [`${patron}은(는) 방 안에 들어와 한동안 ${wife}을(를) 바라봅니다. 그녀는 ${targetConditionKo} 채 눈을 뜨지 않습니다.`, `${patron} enters and watches ${wife} for a moment. She remains ${targetConditionEn}, her eyes closed.`],
          [`${patron}은(는) 발소리를 죽이고 ${wife} 곁에 몸을 낮춥니다. 그녀는 ${targetConditionKo} 채 움직이지 않습니다.`, `${patron} treads softly and crouches beside ${wife}. She remains ${targetConditionEn} and does not move.`],
        ]) : intrusion.sharedSleepRoom ? sceneLine(next, 'carry:shared', [
          [`${patron}은(는) 당신 쪽을 한 번 본 뒤 ${wife}을(를) 안아 들어 자기 객실로 데려갑니다.`, `${patron} glances your way, then carries ${wife} to his room.`],
          [`${patron}은(는) 당신 곁에서 발소리를 죽입니다. ${wife}을(를) 품에 안고 문 밖으로 나가 자기 객실로 향합니다.`, `${patron} treads softly past you. He lifts ${wife} in his arms and carries her to his room.`],
          [`${patron}은(는) 당신 쪽으로 잠시 귀를 기울입니다. 그제야 ${wife}을(를) 안아 들어 자기 객실로 갑니다.`, `${patron} listens toward you for a moment, then lifts ${wife} and carries her to his room.`],
        ]) : sceneLine(next, 'carry:separate', [
          [`${patron}은(는) ${wife}을(를) 안아 들어 자기 객실로 데려갑니다.`, `${patron} lifts ${wife} and carries her to his room.`],
          [`${patron}은(는) ${wife}의 어깨와 다리 밑에 팔을 넣습니다. 그녀를 들어 올려 자기 객실로 향합니다.`, `${patron} slips an arm beneath ${wife}'s shoulders and legs, then carries her to his room.`],
          [`${patron}은(는) ${wife}을(를) 안고 방을 나섭니다. 그녀의 팔은 힘없이 늘어져 있습니다. ${patron}은(는) 그녀를 안고 자기 객실로 들어갑니다.`, `${patron} leaves carrying ${wife}. Her arm hangs limp as he carries her into his room.`],
        ]);
      next = api.fn('log')(next, visitLine);
      next = sleepActions.patron.begin(next);
      return next.activeScene?.patron ? next : closeVisit(next);
    }

    function nightVisitNoticeEvent(state, intrusion) {
      return {
        ...state,
        pendingEvent: {
          type: 'sleep_actions_night_visit_notice',
          customerId: intrusion.customerId,
          customerName: intrusion.customerName,
          text: sceneLine(state, 'notice:door', [
            [`막 잠이 들려는 순간 문고리가 천천히 돌아갑니다. ${intrusion.customerName}이(가) 문틈으로 들어와 ${wifeName(state)} 쪽을 바라봅니다.`, `Just as you drift off, the door handle turns slowly. ${intrusion.customerName} slips in and looks toward ${wifeName(state)}.`],
            [`복도에서 발소리가 멎고 문이 조금 열립니다. ${intrusion.customerName}의 그림자가 ${wifeName(state)}이(가) 누운 곳으로 길게 드리웁니다.`, `Footsteps stop in the corridor, and the door opens a little. ${intrusion.customerName}'s shadow stretches toward where ${wifeName(state)} lies.`],
            [`당신이 눈을 감으려는 순간 문틈이 넓어집니다. ${intrusion.customerName}이(가) 숨을 죽이고 들어와 ${wifeName(state)} 쪽을 봅니다.`, `As you close your eyes, the gap in the door widens. ${intrusion.customerName} slips in quietly and looks toward ${wifeName(state)}.`],
          ]),
          choices: [
            {
              id: 'stop',
              label: T('일어나 막기', 'Get up and stop him'),
              description: T('몸을 일으켜 손님을 돌려보냅니다.', 'Sit up and send him away.'),
            },
            {
              id: 'ignore',
              label: T('모른 척하고 잠들기', 'Ignore him and sleep'),
              description: T('눈을 감고 가만히 있습니다.', 'Close your eyes and lie still.'),
            },
          ],
          sleepActionsNightVisitNotice: true,
        },
      };
    }

    function startVisit(state) {
      const intrusion = intrusionOf(state);
      if (!intrusion) return state;
      const customer = (state.customers || []).find(item => item.id === intrusion.customerId);
      if (!customer) return closeVisit(state);
      if (!intrusion.wifeNoticed) return startUnawareVisit(state, customer);
      if (intrusion.targetInvited) {
        return startAwareGroping(state, customer, {
          accepted: true, emphatic: false, eager: true,
        });
      }
      const wifeRoom = api.fn('wifeLocation')(state);
      const previewState = api.fn('patronControlCustomerLocation')(state, customer.id) === wifeRoom
        ? state : api.fn('moveOccupant')(state, customer.id, wifeRoom);
      const interaction = sleepActions.patron.interactionPreview(previewState, customer);
      if (!interaction) return rejectAwareVisit(state, customer, {
        accepted: false, emphatic: false, eager: false,
      });
      const evaluation = api.fn('evaluateIntimacy')(
        state, 'touch_breasts', sleepActions.patron.intimacyContext(state, customer, interaction),
      );
      const decision = sleepActions.wake.decision(evaluation);
      return decision.accepted
        ? startAwareGroping(state, customer, decision)
        : rejectAwareVisit(state, customer, decision);
    }

    function beginVisit(state, action, options = {}) {
      if (action?.sleepActionsNightVisitBypass === true) return null;
      const targetInvited = options.targetInvited === true;
      const selected = context(state, options.customerId, { targetInvited });
      if (!selected) return null;
      const customer = selected.customer;
      const originRoom = selected.sleepRoom;
      const sharedSleepRoom = selected.sharedSleepRoom;
      const intrusion = {
        customerId: customer.id,
        customerName: customer.name,
        room: sleepActions.patron.rentedRoom(state, customer.id),
        originRoom,
        sharedSleepRoom,
        playerSleepRoom: selected.playerSleepRoom,
        playerOriginRoom: selected.playerOriginRoom,
        playerWasInSleepRoom: selected.playerInSleepRoom,
        noticed: sharedSleepRoom && options.noticed === true,
        wifeNoticed: targetInvited || options.wifeNoticed === true,
        targetInvited,
        locationMode: options.locationMode === 'guest_room' ? 'guest_room' : 'in_place',
        locationModeForced: options.forceLocationMode === true,
        awakeConsent: false,
        playerPeeking: false,
        playerAtDoor: false,
        playerDoorRoom: null,
        playerWoke: false,
        sleepUnderway: action?.underway !== false,
      };
      let next = prepareSleepingTarget(state);
      if (api.fn('wifeLocation')(next) !== originRoom) {
        next = api.fn('moveOccupant')(next, next.primaryCharacterId, originRoom);
      }
      const playerSleepRoom = intrusion.playerSleepRoom || 'bedroom';
      if (Array.isArray(next.locations?.[playerSleepRoom]?.occupants)
        && api.fn('playerLocation')(next) !== playerSleepRoom) {
        next = api.fn('moveOccupant')(next, 'player', playerSleepRoom);
      }
      const data = dataOf(next);
      next = writeData(next, {
        intrusion,
        visitNight: currentNight(next),
        visitedCustomerIds: [...new Set([...data.visitedCustomerIds, customer.id])],
      });
      return intrusion.noticed ? nightVisitNoticeEvent(next, intrusion) : startVisit(next);
    }

    function interceptNightVisit(state, action) {
      if (action?.type !== 'sleep' || action.sleepActionsNightVisitBypass === true || intrusionOf(state)) return null;
      const value = settings();
      const selected = chooseVisitor(state, value);
      if (!selected) return null;
      return beginVisit(state, action, {
        customerId: selected.customer.id,
        noticed: selected.context.sharedSleepRoom
          && Math.random() < playerNoticeChance(selected.context, value),
        wifeNoticed: Math.random() < wifeNoticeChance(selected.context, value),
        locationMode: Math.random() * 100 < value.guestRoomMoveChance ? 'guest_room' : 'in_place',
      });
    }

    function resolveNoticeChoice(state, choiceId) {
      const intrusion = intrusionOf(state);
      if (!intrusion || !state.pendingEvent?.sleepActionsNightVisitNotice) return state;
      const customer = (state.customers || []).find(item => item.id === intrusion.customerId);
      if (choiceId === 'ignore') {
        const next = api.fn('log')({ ...state, pendingEvent: undefined }, sceneLine(state, 'notice:ignore', [
          [`당신은 눈을 감고 가만히 있습니다. ${customer?.name || intrusion.customerName}은(는) 한동안 당신을 보다가 발소리를 죽입니다.`, `You close your eyes and lie still. ${customer?.name || intrusion.customerName} watches you for a moment, then treads softly past.`],
          [`당신은 숨결을 고르게 맞춥니다. 가까이서 ${customer?.name || intrusion.customerName}의 발소리가 잠시 멎었다가 다시 멀어집니다.`, `You keep your breathing steady. ${customer?.name || intrusion.customerName}'s footsteps stop nearby, then move away.`],
          [`당신은 돌아보지 않고 눈을 감습니다. ${customer?.name || intrusion.customerName}은(는) 당신 곁에서 한동안 기다리다 ${wifeName(state)} 쪽으로 향합니다.`, `You close your eyes without turning. ${customer?.name || intrusion.customerName} waits beside you, then moves toward ${wifeName(state)}.`],
        ]));
        return startVisit(next);
      }
      if (choiceId !== 'stop') return state;
      let next = api.fn('log')({ ...state, pendingEvent: undefined }, sceneLine(state, 'notice:stop', [
        [`당신이 몸을 일으키자 ${customer?.name || intrusion.customerName}은(는) 걸음을 멈춥니다. "돌아가요." 그는 자기 객실로 물러납니다.`, `You sit up, and ${customer?.name || intrusion.customerName} stops. "Go back to your room." He retreats.`],
        [`당신은 잠자리에서 일어나 문 쪽을 가리킵니다. "나가요." ${customer?.name || intrusion.customerName}은(는) 시선을 피하고 자기 객실로 돌아갑니다.`, `You rise and point at the door. "Leave." ${customer?.name || intrusion.customerName} looks away and returns to his room.`],
        [`"거기서 멈춰요." 당신의 목소리에 ${customer?.name || intrusion.customerName}은(는) 손을 내립니다. 잠시 뒤 자기 객실로 물러납니다.`, `"Stop there." At your voice, ${customer?.name || intrusion.customerName} lowers his hand, then retreats to his room.`],
      ]));
      next = sleepActions.patron.startCooldowns(next, [intrusion.customerId]);
      return closeVisit(next, { resumeSleep: false });
    }

    function participants(state) {
      const session = sleepActions.getState(state)?.session;
      const result = { ...(session?.patronParticipants || {}) };
      const primaryId = session?.patronPrimaryId || state.activeScene?.patron?.customerId;
      if (primaryId && !result[primaryId]) result[primaryId] = { customerId: primaryId };
      return result;
    }

    function primaryParticipant(state) {
      const intrusion = intrusionOf(state);
      const interaction = state.activeScene?.patron;
      const session = sleepActions.getState(state)?.session;
      const primaryId = session?.patronPrimaryId || interaction?.customerId || intrusion?.customerId;
      if (!primaryId) return null;
      const saved = participants(state)[primaryId] || {};
      return {
        ...saved,
        customerId: primaryId,
        customerName: saved.customerName || interaction?.customerName
          || intrusion?.customerName || primaryId,
        stage: saved.stage || interaction?.sleepActionsStage || interaction?.stage,
        actionId: saved.actionId || interaction?.sleepActionsActionId,
      };
    }

    function currentVisitActionLine(state) {
      const intrusion = intrusionOf(state);
      const participant = primaryParticipant(state);
      const line = participant ? sleepActions.patron.actionLine(state, participant) : '';
      return line || T(
        `${intrusion?.customerName || '손님'}이(가) ${wifeName(state)}의 곁에 몸을 굽힙니다.`,
        `${intrusion?.customerName || 'The patron'} bends over ${wifeName(state)}.`,
      );
    }

    function targetWakeState(state) {
      if (sleepActions.state.isPassedOut(state)) return 'passed_out';
      if (sleepActions.state.isSleeping(state)) return 'sleeping';
      return 'awake';
    }

    function doorRoomLabel(state, room) {
      const intrusion = intrusionOf(state);
      if (room && room === intrusion?.room) return T(
        `${intrusion.customerName}의 객실`,
        `${intrusion.customerName}'s rented room`,
      );
      if (room === 'elena_room') return T(
        `${wifeName(state)}의 방`,
        `${wifeName(state)}'s room`,
      );
      const labels = {
        bedroom: T('침실', 'the bedroom'),
        upstairs_hall: T('1번 객실', 'the rental room'),
        upstairs_room_2: T('2번 객실', 'rental room 2'),
        back_room: T('뒷방', 'the back room'),
        bathroom: T('욕실', 'the bathroom'),
        bathhouse: T('목욕탕', 'the bathhouse'),
      };
      return labels[room] || T('그 방', 'the room');
    }

    function resolveDoorCheck(state, kind) {
      const intrusion = intrusionOf(state);
      if (!intrusion?.playerAtDoor || !state.activeScene?.patron || state.pendingEvent) return state;
      const nextIntrusion = {
        ...intrusion,
        ...(kind === 'peek' ? { playerPeeking: true } : {}),
      };
      let next = writeData(state, { intrusion: nextIntrusion });
      const wakeState = targetWakeState(state);
      if (kind === 'knock') {
        const room = doorRoomLabel(state, intrusion.playerDoorRoom);
        const pools = wakeState === 'awake' ? [
          [`당신은 ${room} 문을 가볍게 두드립니다. 안에서 움직임이 들리지만 대답은 없습니다.`, `You knock softly on the door to ${room}. You hear movement inside, but no answer.`],
          [`${room} 문을 두드리자 안에서 움직임이 멎습니다. 대답은 들리지 않습니다.`, `You knock on the door to ${room}. Movement inside stops, but no one answers.`],
          [`당신의 손마디가 ${room} 문에 닿습니다. 안에서는 희미한 발소리만 들립니다.`, `Your knuckles meet the door to ${room}. You hear only faint footsteps inside.`],
        ] : wakeState === 'passed_out' ? [
          [`당신은 ${room} 문을 가볍게 두드립니다. 안에서는 아무런 반응이 없습니다.`, `You knock softly on the door to ${room}. There is no response from inside.`],
          [`${room} 문을 두 번 두드리고 기다립니다. 안은 잠잠합니다.`, `You knock twice on the door to ${room} and wait. Nothing stirs inside.`],
          [`당신의 손마디가 ${room} 문에 닿습니다. 한참 기다려도 대답은 돌아오지 않습니다.`, `Your knuckles meet the door to ${room}. You wait, but no answer comes.`],
        ] : [
          [`당신은 ${room} 문을 가볍게 두드립니다. 대답이 없습니다.`, `You knock softly on the door to ${room}. No one answers.`],
          [`${room} 문을 두 번 두드리고 귀를 기울입니다. 안에서는 대답이 들리지 않습니다.`, `You knock twice on the door to ${room} and listen. No one answers.`],
          [`당신은 ${room} 문에 손을 댔다가 가볍게 두드립니다. 방 안은 여전히 조용합니다.`, `You rest a hand on the door to ${room}, then knock softly. The room stays quiet.`],
        ];
        return api.fn('log')(next, sceneLine(next, `door:knock:${wakeState}`, pools));
      }
      return next;
    }

    function doorPeekPrefix(state) {
      const intrusion = intrusionOf(state);
      const wakeState = targetWakeState(state);
      const room = doorRoomLabel(state, intrusion.playerDoorRoom);
      const wife = wifeName(state);
      const pools = wakeState === 'awake' ? [
        [`당신은 ${room} 문틈으로 들여다봅니다. ${wife}은(는) 눈을 뜨고 있습니다.`, `You peer through the door to ${room}. ${wife} has her eyes open.`],
        [`${room} 문틈으로 ${wife}의 얼굴이 보입니다. 그녀의 눈은 떠 있습니다.`, `You can see ${wife}'s face through the gap in the door to ${room}. Her eyes are open.`],
        [`당신은 문틈에 얼굴을 가까이 댑니다. ${wife}은(는) 대답하지 않지만 눈은 떠 있습니다.`, `You move closer to the gap. ${wife} does not answer, but her eyes are open.`],
      ] : wakeState === 'passed_out' ? [
        [`당신은 ${room} 문틈으로 들여다봅니다. ${wife}은(는) 미동도 하지 않습니다.`, `You peer through the door to ${room}. ${wife} does not stir.`],
        [`${room} 문틈 너머로 ${wife}이(가) 보입니다. 눈꺼풀은 움직이지 않습니다.`, `You can see ${wife} through the gap in the door to ${room}. Her eyelids do not move.`],
        [`당신은 문틈을 통해 ${wife}을(를) 살핍니다. 그녀에게서는 어떤 움직임도 보이지 않습니다.`, `You watch ${wife} through the gap. She makes no visible movement.`],
      ] : [
        [`당신은 ${room} 문틈으로 들여다봅니다. ${wife}은(는) 잠든 채입니다.`, `You peer through the door to ${room}. ${wife} remains asleep.`],
        [`${room} 문틈으로 ${wife}이(가) 보입니다. 그녀는 눈을 감고 있습니다.`, `You can see ${wife} through the gap in the door to ${room}. Her eyes are closed.`],
        [`당신은 문틈에 얼굴을 가까이 댑니다. ${wife}은(는) 잠에서 깨지 않은 채 누워 있습니다.`, `You move closer to the gap. ${wife} lies there without waking.`],
      ];
      return sceneLine(state, `door:peek:${wakeState}`, pools);
    }

    function performDoorCheck(state, kind) {
      const prepared = resolveDoorCheck(state, kind);
      if (prepared === state) return state;
      const previousDoorCheck = activeDoorCheck;
      const contextValue = {
        kind, customerId: intrusionOf(prepared)?.customerId,
        prefix: kind === 'peek' ? doorPeekPrefix(prepared) : null,
        actionLogged: false,
      };
      activeDoorCheck = contextValue;
      let advanced;
      try { advanced = api.fn('tick')(prepared); }
      finally { activeDoorCheck = previousDoorCheck; }
      if (kind !== 'peek' || contextValue.actionLogged) return advanced;
      return api.fn('log')(advanced, contextValue.prefix);
    }

    function onVisitActionLog(state, { line }) {
      const contextValue = activeDoorCheck;
      if (!contextValue || intrusionOf(state)?.customerId !== contextValue.customerId) return undefined;
      contextValue.actionLogged = true;
      return contextValue.kind === 'knock' ? null : `${contextValue.prefix} ${line}`;
    }

    function nightCallEvent(state, contextValue) {
      const intrusion = intrusionOf(state);
      const wife = wifeName(state);
      const patron = contextValue.customer.name;
      const line = voiceLine(state, 'call:refusal', {
        elena: [
          [`${wife}은(는) 눈을 뜨자마자 ${patron}을(를) 밀어내고 당신을 부릅니다. "여기 좀 와 주세요!"`, `${wife} wakes, pushes ${patron} away, and calls to you. "Please come here!"`],
          [`${wife}은(는) ${patron}의 손을 뿌리치고 숨을 들이켭니다. "도와줘요!"`, `${wife} jerks away from ${patron}'s hand and draws a breath. "Help me!"`],
        ],
        mara: [
          [`${wife}이(가) 눈을 뜨고 ${patron}을(를) 밀쳐 낸 뒤 당신을 부릅니다. "야! 여기 좀 와!"`, `${wife} opens her eyes, shoves ${patron} away, and calls to you. "Hey! Get over here!"`],
          [`${wife}은(는) ${patron}의 손을 쳐 낸 뒤 당신을 부릅니다. "빨리 와!"`, `${wife} knocks ${patron}'s hand away and calls for you. "Get here, quick!"`],
        ],
        pippa: [
          [`${wife}은(는) 눈을 뜨자마자 ${patron}을(를) 밀어냅니다. "도와줘!"`, `${wife} wakes and pushes ${patron} away. "Help me!"`],
          [`${wife}이(가) ${patron}의 손을 뿌리치며 당신을 부릅니다. "일어나, 나 좀 도와줘!"`, `${wife} jerks away from ${patron}'s hand and calls to you. "Wake up and help me!"`],
        ],
        other: [
          [`${wife}은(는) 눈을 뜨자마자 ${patron}을(를) 밀어내고 당신을 부릅니다.`, `${wife} wakes, pushes ${patron} away, and calls for you.`],
          [`${wife}이(가) ${patron}의 손을 뿌리치며 당신에게 도움을 청합니다.`, `${wife} jerks away from ${patron}'s hand and calls to you for help.`],
        ],
      });
      let next = api.fn('updateWife')(state, wife => ({
        ...wife, lastResponse: line, lastResponseSlot: whole(state.slot),
        lastResponseType: sleepActions.wake.responseType(contextValue.decision),
      }));
      next = api.fn('log')(next, line);
      return {
        ...next,
        pendingEvent: {
          type: 'sleep_actions_night_visit_call',
          text: intrusion.locationMode === 'guest_room'
            ? sceneLine(next, 'call:guest_room', [
              [`${wifeName(next)}의 목소리에 잠에서 깹니다. 손님 객실 쪽에서 급한 발소리가 들립니다.`, `${wifeName(next)}'s voice wakes you. Hurried footsteps come from the guest room.`],
              [`${wifeName(next)}이(가) 당신을 부릅니다. 눈을 뜨자 손님 객실 쪽에서 그녀의 거친 숨소리가 들립니다.`, `${wifeName(next)} calls for you. As you wake, you hear her uneven breathing from the guest room.`],
            ])
            : sceneLine(next, 'call:in_place', [
              [`${wifeName(next)}의 목소리에 잠에서 깹니다. 그녀와 ${intrusion.customerName}은(는) 서로 떨어져 서 있습니다.`, `${wifeName(next)}'s voice wakes you. She and ${intrusion.customerName} stand apart.`],
              [`당신이 눈을 뜨자 ${wifeName(next)}은(는) 당신 쪽을 보고 있습니다. ${intrusion.customerName}은(는) 그녀에게서 한 걸음 물러나 있습니다.`, `When you open your eyes, ${wifeName(next)} is looking toward you. ${intrusion.customerName} stands a step away from her.`],
            ]),
          choices: [
            { id: 'expel', label: T('손님을 쫓아내기', 'Expel the patron') },
            { id: 'comfort', label: T('그녀를 위로하고 손님은 남겨 두기', 'Comfort her and let him stay') },
            { id: 'ignore', label: T('무시하기', 'Ignore her') },
          ],
          sleepActionsNightVisitCall: true,
          participantIds: Object.keys(contextValue.participants || {}),
        },
      };
    }

    function ownerWake(state, contextValue) {
      if (!intrusionOf(state)) return null;
      if (!contextValue.decision.accepted) return nightCallEvent(state, contextValue);
      let next = writeData(state, { intrusion: { ...intrusionOf(state), awakeConsent: true } });
      next = sleepActions.wake.applyPatronResponse(
        next, contextValue.customer, contextValue.decision, contextValue.participants,
      );
      next = {
        ...next,
        activeScene: {
          ...next.activeScene,
          patron: {
            ...next.activeScene.patron,
            ...(contextValue.action.actionId === 'watch_him' ? { watchedHimStroke: true } : {}),
            ticksAtStage: -1,
          },
        },
      };
      return api.fn('processPatronInteractionTick')(next);
    }

    function ownerFinish(state, contextValue) {
      const intrusion = intrusionOf(state);
      if (!intrusion) return null;
      let next = sleepActions.patron.clearFlow(state, contextValue.participants);
      next = sleepActions.session.end(next, contextValue.reason);
      return closeVisit(next, {
        resumeSleep: !intrusion.playerAtDoor && !intrusion.playerWoke,
        participants: contextValue.participants,
      });
    }

    sleepActions.patron.registerFlowOwner(OWNER_ID, {
      onWake: ownerWake,
      onFinish: ownerFinish,
      onActionLog: onVisitActionLog,
    });

    function canWake(state) {
      return !!(intrusionOf(state) && state.activeScene?.patron && !state.pendingEvent);
    }

    function ownsActiveSleepPanel(state) {
      return !!(intrusionOf(state) && state.activeScene?.patron && !state.pendingEvent);
    }

    function approachVisitDoor(state) {
      if (!canWake(state)) return state;
      const intrusion = intrusionOf(state);
      const wifeRoom = api.fn('wifeLocation')(state);
      const playerRoom = api.fn('playerLocation')(state);
      if (!wifeRoom || wifeRoom === playerRoom) return openWakeEvent(state);
      const approach = api.fn('approachClosedDoor')(state, wifeRoom);
      if (!approach?.state || approach.caught) return approach?.state || state;
      let next = writeData(approach.state, {
        intrusion: {
          ...intrusion,
          playerAtDoor: true,
          playerDoorRoom: wifeRoom,
        },
      });
      return api.fn('log')(next, sceneLine(next, 'wake:approach_door', [
        [`희미한 소리에 잠이 깹니다. 당신은 ${doorRoomLabel(next, wifeRoom)} 문 앞까지 다가갑니다.`, `A faint sound wakes you. You make your way to the door of ${doorRoomLabel(next, wifeRoom)}.`],
        [`복도 쪽에서 소리가 나자 당신은 몸을 일으킵니다. ${doorRoomLabel(next, wifeRoom)} 문 앞에서 걸음을 멈춥니다.`, `A sound from the corridor makes you rise. You stop at the door of ${doorRoomLabel(next, wifeRoom)}.`],
        [`당신은 잠결에 들린 기척을 따라갑니다. ${doorRoomLabel(next, wifeRoom)} 문에 이르러 귀를 기울입니다.`, `You follow the movement you heard in your sleep. At the door of ${doorRoomLabel(next, wifeRoom)}, you listen.`],
      ]));
    }

    function openWakeEvent(state) {
      if (!canWake(state)) return state;
      const intrusion = intrusionOf(state);
      const wifeRoom = api.fn('wifeLocation')(state);
      const atDoor = intrusion.playerAtDoor && intrusion.playerDoorRoom === wifeRoom;
      const sameRoom = !atDoor && wifeRoom === api.fn('playerLocation')(state);
      if (!sameRoom && !atDoor) return approachVisitDoor(state);
      const actionLine = currentVisitActionLine(state);
      return {
        ...state,
        pendingEvent: {
          type: 'sleep_actions_night_visit_wake',
          text: sameRoom ? sceneLine(state, 'wake:in_place', [
            [`당신은 눈을 가늘게 뜹니다. ${actionLine}`, `You narrow your eyes. ${actionLine}`],
            [`가까운 움직임에 눈이 떠집니다. 당신은 숨을 죽인 채 고개를 돌립니다. ${actionLine}`, `Movement nearby wakes you. Holding your breath, you turn your head. ${actionLine}`],
            [`잠결의 기척이 분명해지자 당신은 눈을 뜹니다. ${actionLine}`, `As the sound beside you grows clear, you open your eyes. ${actionLine}`],
          ]) : sceneLine(state, 'wake:at_door', [
            [`문을 열자 ${actionLine}`, `You open the door. ${actionLine}`],
            [`당신이 문을 밀어 열자 방 안의 움직임이 눈에 들어옵니다. ${actionLine}`, `You push the door open and see movement inside. ${actionLine}`],
            [`문이 열리고 방 안이 보입니다. ${actionLine}`, `The door opens, and the room comes into view. ${actionLine}`],
          ]),
          choices: sameRoom ? [
            { id: 'intervene', label: T('일어나 그에게 손을 떼라고 말하기', 'Tell him to take his hands off her') },
            { id: 'eject', label: T('일어나 그를 주점 밖으로 쫓아내기', 'Throw him out of the tavern') },
            { id: 'peek', label: T('잠든 척 지켜보기', 'Pretend to sleep and watch') },
          ] : [
            { id: 'intervene', label: T('문을 열고 그에게 손을 떼라고 말하기', 'Open the door and tell him to stop') },
            { id: 'eject', label: T('문을 열고 그를 주점 밖으로 쫓아내기', 'Open the door and throw him out') },
            { id: 'back_off', label: T('문을 닫고 물러서기', 'Close the door and step back') },
          ],
          sleepActionsNightVisitWake: true,
        },
      };
    }

    function activeBadGuestDoorLock(room) {
      const lock = badGuest?.getState()?.data?.doorLock;
      return lock?.active && lock.roomId === room ? lock : null;
    }

    function markNightVisitLockedDoor(state) {
      if (state.pendingEvent?.type !== BAD_GUEST_LOCKED_DOOR_EVENT) return state;
      return {
        ...state,
        pendingEvent: {
          ...state.pendingEvent,
          sleepActionsNightVisitDoor: true,
        },
      };
    }

    function openVisitDoor(state) {
      if (state.pendingEvent) return state;
      const intrusion = intrusionOf(state);
      if (!intrusion) return state;
      const room = api.fn('wifeLocation')(state);
      const atDoor = intrusion.playerAtDoor && intrusion.playerDoorRoom === room;
      if (!room || !atDoor) return openWakeEvent(state);
      if (!activeBadGuestDoorLock(room)) return openWakeEvent(state);
      const signaled = api.fn('reduceGameAction')(state, {
        type: 'open_the_door',
        room,
        sleepActionsNightVisitDoorSignal: true,
      });
      if (signaled.pendingEvent?.type === BAD_GUEST_LOCKED_DOOR_EVENT) {
        return markNightVisitLockedDoor(signaled);
      }
      if (signaled.pendingEvent || !intrusionOf(signaled)) return signaled;
      return openWakeEvent(signaled);
    }

    function awakeExplanationBelief(evaluation) {
      const config = sleepActions.getSettings();
      const withoutSleepBonus = {
        ...(evaluation || {}),
        score: number(evaluation?.score, Number.NEGATIVE_INFINITY)
          - number(config.patronExplanationBeliefBonus),
      };
      const shared = sleepActions.intervention.adjustedExplanationBelief(withoutSleepBonus);
      return { ...shared, raw: evaluation };
    }

    function interventionAssessment(state, customer, interaction, participant, wasUnconscious) {
      const action = sleepActions.patron.stageAction(
        participant?.stage || interaction?.sleepActionsStage || interaction?.stage,
        participant?.actionId || interaction?.sleepActionsActionId,
      );
      if (!action) return { action: null, mode: 'neutral', refused: false };
      const currentRaw = api.fn('evaluateIntimacy')(
        state, action.actionId, sleepActions.patron.intimacyContext(state, customer, interaction),
      );
      const current = wasUnconscious
        ? sleepActions.intervention.adjustedWakeAcceptance(currentRaw)
        : { raw: currentRaw, adjusted: currentRaw, decision: sleepActions.wake.decision(currentRaw) };
      const explanationRaw = api.fn('evaluateIntimacy')(
        state, 'interrupt_patron', { kind: 'player_interrupt' },
      );
      const explanation = wasUnconscious
        ? sleepActions.intervention.adjustedExplanationBelief(explanationRaw)
        : awakeExplanationBelief(explanationRaw);
      const config = sleepActions.getSettings();
      const requiredInfluence = clamp(
        (number(explanation.decision.threshold) + number(config.patronInterventionInfluenceMargin)
          - number(explanation.decision.score))
          / Math.max(Number.EPSILON, number(config.patronInterventionInfluenceScale)),
        0, 1,
      );
      const actualInfluence = clamp(number(api.fn('relationshipInfluence')(state), 0), 0, 1);
      if (!current.decision.accepted || explanation.decision.believed) return {
        action, current, explanation, requiredInfluence, actualInfluence,
        mode: explanation.decision.believed ? 'welcomed' : 'neutral', refused: false,
      };
      if (actualInfluence >= requiredInfluence) return {
        action, current, explanation, requiredInfluence, actualInfluence,
        mode: 'reluctant', refused: false,
      };
      return {
        action, current, explanation, requiredInfluence, actualInfluence,
        mode: null, refused: true,
      };
    }

    function directInterventionResultLine(state, customer, currentAccepted, explanationBelieved) {
      const wife = wifeName(state);
      const patron = customer.name;
      const atDoor = intrusionOf(state)?.playerAtDoor;
      if (!currentAccepted && explanationBelieved) return voiceLine(state, 'intervene:refused_believed', {
        elena: [
          [`${wife}은(는) ${patron}의 손을 밀어내고 당신 쪽으로 옵니다. "알겠어요. 저 사람을 내보내 주세요."`, `${wife} pushes ${patron}'s hand away and comes toward you. "I understand. Please get him out."`],
          [`${wife}이(가) ${patron}에게서 물러나 당신의 소매를 잡습니다. "저 사람과 더 있고 싶지 않아요."`, `${wife} steps away from ${patron} and takes your sleeve. "I don't want to stay with him."`],
        ],
        mara: [
          [`${wife}이(가) ${patron}을(를) 밀쳐 내고 당신 곁으로 옵니다. "알았어. 저 자식 내보내."`, `${wife} shoves ${patron} away and comes to your side. "All right. Get that bastard out."`],
          [`${wife}은(는) ${patron}의 손목을 놓고 당신 뒤로 물러섭니다. "자세한 얘기는 나중에. 먼저 쫓아내."`, `${wife} lets go of ${patron}'s wrist and moves behind you. "We can talk details later. Get him out first."`],
        ],
        pippa: [
          [`${wife}은(는) ${patron}의 손을 뿌리치고 당신에게 다가옵니다. "네 말 믿을게. 저 사람 가라고 해."`, `${wife} jerks away from ${patron} and comes toward you. "I believe you. Tell him to go."`],
          [`${wife}은(는) ${patron}에게서 떨어져 당신 손을 잡습니다. "나 여기 있기 싫어. 저 사람 보내 줘."`, `${wife} steps away from ${patron} and takes your hand. "I don't want to stay here. Make him leave."`],
        ],
        other: [
          [`${wife}은(는) ${patron}을(를) 밀어내고 당신 쪽으로 물러섭니다. "알겠어. 저 사람을 내보내 줘."`, `${wife} pushes ${patron} away and steps toward you. "I understand. Get him out of here."`],
          [`${wife}은(는) ${patron}에게서 떨어져 당신 곁에 섭니다. "저 사람과 더 있고 싶지 않아."`, `${wife} steps away from ${patron} and stands beside you. "I don't want to stay with him."`],
        ],
      });
      if (currentAccepted && explanationBelieved) return voiceLine(state, 'intervene:accepted_believed', {
        elena: [
          [`${wife}은(는) ${patron}의 손을 놓고 한 걸음 물러섭니다. "알겠어요. 여기서 멈출게요. 무슨 일이 있었는지 조금 더 말해 주세요."`, `${wife} lets go of ${patron}'s hand and steps back. "I understand. I'll stop here. Please tell me a little more about what happened."`],
          [`${wife}은(는) 두 사람을 번갈아 보다 ${patron}에게서 떨어집니다. "무슨 일이 있었는지 좀 더 듣고 싶어요. 지금은 여기서 그만할게요."`, `${wife} looks between you, then steps away from ${patron}. "I want to hear more about what happened. I'll stop here for now."`],
        ],
        mara: [
          [`${wife}이(가) ${patron}의 손을 놓습니다. "알았어, 여기까지. 대신 무슨 일이 있었는지는 끝까지 들어 봐야겠어."`, `${wife} releases ${patron}'s hand. "All right, that's enough. But I want the whole story."`],
          [`${wife}은(는) ${patron}에게서 떨어져 팔짱을 낍니다. "네 말대로 일단 여기서 멈출게. 나머지는 확인해 볼 거야."`, `${wife} steps away from ${patron} and folds her arms. "I'll stop here for now, like you said. I'll check the rest myself."`],
        ],
        pippa: [
          [`${wife}은(는) ${patron}의 손을 놓고 당신을 봅니다. "알겠어. 네 말이 맞는 것 같아. 여기서 그만할게."`, `${wife} releases ${patron}'s hand and looks at you. "Okay. I think you're right. I'll stop here."`],
          [`${wife}이(가) 두 사람 사이에서 한 걸음 물러섭니다. "잠깐만. 무슨 일이 있었는지 네 얘기를 좀 더 듣고 싶어. 지금은 여기서 멈출게."`, `${wife} takes a step back from both of you. "Wait. I want to hear more about what happened. I'll stop here for now."`],
        ],
        other: [
          [`${wife}은(는) ${patron}의 손을 놓고 한 걸음 물러섭니다. "알겠어. 네 말이 맞는 것 같아. 여기서 그만할게."`, `${wife} lets go of ${patron}'s hand and steps back. "I understand. I think you're right. I'll stop here."`],
          [`${wife}은(는) ${patron}에게서 떨어집니다. "무슨 일이 있었는지 좀 더 듣고 싶어. 일단 여기서 멈출게."`, `${wife} moves away from ${patron}. "I want to hear more about what happened. I'll stop here for now."`],
        ],
      });
      const whyKo = atDoor ? '왜 들어왔는지' : '왜 이렇게 나섰는지';
      const whyEn = atDoor ? 'why you came in' : 'why you stepped in';
      return voiceLine(state, `intervene:unbelieved:${atDoor ? 'door' : 'room'}`, {
        elena: [
          [`${wife}은(는) ${patron}의 손을 밀어내고 당신을 돌아봅니다. "그만해요. ${whyKo}는 나중에 다시 말해 주세요."`, `${wife} pushes ${patron}'s hand away and turns to you. "Stop. Please explain ${whyEn} again later."`],
          [`${wife}은(는) 두 사람에게서 한 걸음씩 물러섭니다. "지금은 어느 쪽 말도 믿기 어려워요."`, `${wife} steps back from both of you. "I can't trust either of you right now."`],
        ],
        mara: [
          [`${wife}이(가) ${patron}의 손을 쳐 내고 당신을 노려봅니다. "그만. ${whyKo}는 나중에 다시 설명해."`, `${wife} knocks ${patron}'s hand away and glares at you. "Enough. Explain ${whyEn} again later."`],
          [`${wife}은(는) 두 사람 사이를 빠져나옵니다. "둘 다 손 치워. 말은 나중에 들어."`, `${wife} slips away from both of you. "Both of you, hands off. I'll hear your stories later."`],
        ],
        pippa: [
          [`${wife}은(는) ${patron}의 손을 뿌리치고 당신을 봅니다. "그만해! 너랑도 나중에 얘기할 거야."`, `${wife} jerks away from ${patron} and looks at you. "Stop! You and I are talking later, too."`],
          [`${wife}은(는) 두 사람에게서 멀어집니다. "지금은 누구 말도 듣기 싫어."`, `${wife} moves away from both of you. "I don't want to hear either of you right now."`],
        ],
        other: [
          [`${wife}은(는) ${patron}의 손을 밀치고 당신을 돌아봅니다. "그만해. ${whyKo}는 나중에 다시 설명해."`, `${wife} pushes ${patron}'s hand away and turns to you. "Stop. Explain ${whyEn} again later."`],
          [`${wife}은(는) 두 사람에게서 거리를 둡니다. "둘 다 멈춰. 지금은 어느 쪽 말도 못 믿겠어."`, `${wife} steps away from both of you. "Both of you stop. I can't trust either of you right now."`],
        ],
      });
    }

    function interventionResultLine(state, customer, assessment, wasUnconscious) {
      const wife = wifeName(state);
      const patron = customer.name;
      if (!assessment.action) return wasUnconscious
        ? sceneLine(state, 'intervene:no_action:unconscious', [
          [`${wife}은(는) 눈을 뜨고, ${patron}은(는) 황급히 물러납니다.`, `${wife} opens her eyes, and ${patron} hurriedly backs away.`],
          [`${wife}의 눈꺼풀이 움직이자 ${patron}은(는) 손을 거두고 뒤로 물러섭니다.`, `As ${wife}'s eyelids stir, ${patron} draws back his hand and steps away.`],
        ])
        : intrusionOf(state)?.playerAtDoor ? sceneLine(state, 'intervene:no_action:door', [
          [`${wife}은(는) 당신이 들어오자 몸을 일으키고, ${patron}은(는) 황급히 물러납니다.`, `${wife} straightens when you enter, and ${patron} hurriedly backs away.`],
          [`문이 열리자 ${patron}은(는) 먼저 물러납니다. ${wife}은(는) 당신을 보고 몸을 일으킵니다.`, `${patron} steps back as the door opens. ${wife} sees you and straightens.`],
        ]) : sceneLine(state, 'intervene:no_action:room', [
          [`당신이 몸을 일으키자 ${patron}은(는) 손을 거둡니다. ${wife}은(는) 눈을 뜨고 두 사람을 봅니다.`, `As you sit up, ${patron} pulls his hand away. ${wife} opens her eyes and looks at both of you.`],
          [`${patron}은(는) 당신을 보고 황급히 물러납니다. ${wife}은(는) 몸을 일으켜 그를 바라봅니다.`, `${patron} sees you and steps back quickly. ${wife} sits up and looks at him.`],
        ]);
      if (assessment.mode === 'reluctant') return voiceLine(state, 'intervene:reluctant', {
        elena: [
          [`${wife}은(는) 입술을 꾹 다문 채 ${patron}에게서 떨어집니다. "믿기 어렵지만 여기서 그만할게요."`, `${wife} steps away from ${patron}, her lips pressed tight. "It's hard to believe, but I'll stop here."`],
          [`${wife}이(가) ${patron}의 손을 떼어 놓습니다. "지금은 멈출게요. 나중에 다시 얘기해요."`, `${wife} removes ${patron}'s hand. "I'll stop for now. We can talk later."`],
        ],
        mara: [
          [`${wife}이(가) ${patron}에게서 떨어집니다. "못 믿겠어. 그래도 여기까지만 해."`, `${wife} steps away from ${patron}. "I don't believe you. But this stops here."`],
          [`${wife}은(는) ${patron}의 손목을 놓고 당신을 봅니다. "네 말이 맞아서가 아니야. 내가 멈추는 거야."`, `${wife} releases ${patron}'s wrist and looks at you. "I'm not saying you're right. I'm choosing to stop."`],
        ],
        pippa: [
          [`${wife}은(는) ${patron}에게서 떨어져 손을 움켜쥡니다. "믿기 어려워. 그래도 그만할래."`, `${wife} steps away from ${patron} and clenches her hand. "It's hard to believe. But I'll stop."`],
          [`${wife}이(가) 두 사람을 번갈아 보다 당신 쪽으로 돌아섭니다. "지금은 그만할게. 나중에 더 얘기해 줘."`, `${wife} looks between you and ${patron}, then turns to you. "I'll stop now. Tell me more later, okay?"`],
        ],
        other: [
          [`${wife}은(는) 입을 굳게 다문 채 ${patron}에게서 떨어집니다. "네 말은 못 믿겠어. 그래도 여기서 그만할게."`, `${wife} steps away from ${patron}, her lips pressed tight. "I don't believe you. But I'll stop here."`],
          [`${wife}은(는) ${patron}의 손을 떼어 놓습니다. "일단 멈출게. 나중에 얘기해."`, `${wife} removes ${patron}'s hand. "I'll stop for now. We'll talk later."`],
        ],
      });
      return directInterventionResultLine(
        state, customer, assessment.current.decision.accepted, assessment.explanation.decision.believed,
      );
    }

    function finishIntervention(state, assessment, customer, participantMap, wasUnconscious, line = null) {
      const resultLine = line || interventionResultLine(
        state, customer, assessment, wasUnconscious,
      );
      const finished = sleepActions.intervention.finishWake(state, assessment.mode, resultLine);
      return closePlayerIntervention(finished, participantMap);
    }

    function ejectVisitor(state, assessment, customer, participantMap = {}, wasUnconscious = false) {
      const intrusion = intrusionOf(state);
      const mode = assessment.refused ? 'forced' : assessment.mode;
      const wife = wifeName(state);
      const patron = customer.name;
      const line = mode === 'forced' ? voiceLine(state, 'eject:forced', {
        elena: [
          [`당신이 ${patron}을(를) 붙잡아 떼어 놓습니다. ${wife}이(가) 당신의 손을 밀어냅니다. "제 일은 제가 정한다고 했잖아요."`, `You grab ${patron} and pull him away. ${wife} pushes your hand aside. "I said I'd decide for myself."`],
          [`당신이 ${patron}을(를) 문 쪽으로 끌고 갑니다. ${wife}이(가) 뒤에서 말합니다. "멈춰요. 제 말을 듣지도 않았잖아요."`, `You drag ${patron} toward the door. ${wife} calls after you. "Stop. You haven't listened to me."`],
        ],
        mara: [
          [`당신이 ${patron}을(를) 붙잡아 떼어 놓습니다. ${wife}이(가) 당신의 팔을 쳐 냅니다. "내가 정한다고 했잖아."`, `You grab ${patron} and pull him away. ${wife} knocks your arm aside. "I told you I decide."`],
          [`당신이 ${patron}을(를) 문 쪽으로 몰자 ${wife}이(가) 주먹을 쥡니다. "손 놔. 내 말은 장식이야?"`, `As you drive ${patron} to the door, ${wife} clenches her fist. "Let go. Do my words mean nothing?"`],
        ],
        pippa: [
          [`당신이 ${patron}을(를) 붙잡아 떼어 놓습니다. ${wife}이(가) 당신의 손을 뿌리칩니다. "내가 고를 거야!"`, `You grab ${patron} and pull him away. ${wife} knocks your hand aside. "I get to choose!"`],
          [`당신이 ${patron}을(를) 문 쪽으로 끌고 가자 ${wife}이(가) 따라옵니다. "내 말 좀 들어!"`, `As you pull ${patron} toward the door, ${wife} follows. "Please listen to me!"`],
        ],
        other: [
          [`당신이 ${patron}을(를) 붙잡아 떼어 놓습니다. ${wife}이(가) 당신의 손을 뿌리칩니다. "내가 정한다고 했잖아."`, `You grab ${patron} and pull him away. ${wife} knocks your hand aside. "I said I decide."`],
          [`당신이 ${patron}을(를) 문 쪽으로 몰자 ${wife}이(가) 말합니다. "내 말부터 들어."`, `As you drive ${patron} toward the door, ${wife} says, "Listen to me first."`],
        ],
      }) : sceneLine(state, 'eject:accepted', [
        [`당신이 두 사람 사이를 막아섭니다. "당장 나가." ${wife}은(는) 당신 뒤로 물러섭니다.`, `You step between ${patron} and ${wife}. "Get out." ${wife} moves behind you.`],
        [`당신이 ${patron}의 팔을 잡고 문 쪽을 가리킵니다. "여기서 끝이야." ${wife}은(는) 한 걸음 물러섭니다.`, `You take ${patron}'s arm and point to the door. "That's enough." ${wife} steps back.`],
        [`당신은 문을 열어 둔 채 ${patron}을(를) 바라봅니다. "나가." ${wife}은(는) 그에게서 떨어져 섭니다.`, `You hold the door open and look at ${patron}. "Leave." ${wife} stands apart from him.`],
      ]);
      let next = sleepActions.intervention.finishWake(state, mode, line);
      next = {
        ...next,
        customers: (next.customers || []).map(item => item.id === intrusion.customerId
          ? { ...item, status: 'leaving', isResident: false } : item),
        tavern: {
          ...(next.tavern || {}),
          ...(next.tavern?.tonightRenter?.customerId === intrusion.customerId ? { tonightRenter: undefined } : {}),
          ...(next.tavern?.tonightRenter2?.customerId === intrusion.customerId ? { tonightRenter2: undefined } : {}),
        },
      };
      if (Array.isArray(next.locations?.taproom?.occupants)) {
        next = api.fn('moveOccupant')(next, intrusion.customerId, 'taproom');
      }
      return closePlayerIntervention(next, participantMap);
    }

    function resolveWakeChoice(state, choiceId) {
      const intrusion = intrusionOf(state);
      if (!intrusion || !state.pendingEvent?.sleepActionsNightVisitWake) return state;
      if (choiceId === 'back_off' && intrusion.playerAtDoor) {
        return api.fn('log')({ ...state, pendingEvent: undefined }, sceneLine(state, 'wake:back_off', [
          ['당신은 문을 다시 닫고 문 앞에서 숨을 고릅니다.', 'You close the door again and steady yourself outside it.'],
          ['문이 닫히자 방 안의 소리가 둔해집니다. 당신은 문에서 한 걸음 물러섭니다.', 'The room grows muffled when the door closes. You take a step back.'],
          ['당신은 문을 닫고 손잡이에서 손을 뗍니다. 잠시 그 자리에 서 있습니다.', 'You close the door and let go of the handle. For a moment you stand there.'],
        ]));
      }
      if (choiceId === 'peek') {
        const sameRoom = !intrusion.playerAtDoor
          && api.fn('wifeLocation')(state) === api.fn('playerLocation')(state);
        let next = writeData({ ...state, pendingEvent: undefined }, {
          intrusion: { ...intrusion, playerPeeking: true },
        });
        return api.fn('log')(next, sameRoom ? sceneLine(next, 'wake:watch_in_place', [
          ['당신은 숨을 죽인 채 눈을 가늘게 뜨고, 잠든 척하며 두 사람을 지켜봅니다.', 'You hold your breath and pretend to sleep while watching them.'],
          ['당신은 눈을 반쯤 감은 채 움직이지 않습니다. 가까이서 두 사람의 숨소리가 들립니다.', 'You keep your eyes half closed and lie still. You can hear both of them breathing nearby.'],
          ['당신은 고개를 들지 않습니다. 눈꺼풀 사이로 두 사람을 지켜봅니다.', 'You keep your head down and watch them through half closed eyes.'],
        ]) : sceneLine(next, 'wake:watch_at_door', [
          ['당신은 문을 더 열지 않은 채 숨을 죽이고, 문틈 너머로 두 사람을 지켜봅니다.', 'You hold your breath without opening the door any farther and watch them through the gap.'],
          ['당신은 문짝 뒤에 몸을 숨깁니다. 좁은 틈으로 방 안의 움직임을 좇습니다.', 'You stay behind the door and follow the movement inside through the narrow gap.'],
          ['손잡이에서 손을 떼고 문틈에 눈을 댑니다. 방 안에서는 두 사람의 낮은 숨소리만 들립니다.', 'You let go of the handle and look through the gap. You hear only their breathing inside.'],
        ]));
      }
      if (!['intervene', 'eject'].includes(choiceId)) return state;
      const all = participants(state);
      const interaction = state.activeScene?.patron;
      const participant = primaryParticipant(state);
      const customer = (state.customers || []).find(item => item.id === (
        participant?.customerId || interaction?.customerId || intrusion.customerId
      ));
      if (!customer) return closeVisit({ ...state, pendingEvent: undefined }, {
        resumeSleep: false, participants: all,
      });
      const wasUnconscious = sleepActions.state.isUnconscious(state);
      let next = writeData({ ...state, pendingEvent: undefined }, {
        intrusion: {
          ...intrusion,
          playerWoke: true,
        },
      });
      const session = sleepActions.getState(next)?.session;
      if (session?.kind === 'patron') {
        next = sleepActions.patron.discardCurrentMorningIncident(next, 'patron', session);
        next = sleepActions.session.end(next, 'player-woke-to-night-visit');
      }
      if (wasUnconscious) next = sleepActions.wake.character(next);
      next = sleepActions.patron.startCooldowns(next, Object.keys(all));
      const assessment = interventionAssessment(
        next, customer, interaction, participant, wasUnconscious,
      );
      const atDoor = intrusion.playerAtDoor;
      const conditionKo = sleepActions.state.isPassedOut(state) ? '정신을 잃은 사이' : '잠든 사이';
      const conditionEn = sleepActions.state.isPassedOut(state) ? 'while you were unconscious' : 'while you were asleep';
      const conditionReasonKo = sleepActions.state.isPassedOut(state)
        ? '정신을 잃고 있어서' : '잠들어 있어서';
      const conditionStateEn = sleepActions.state.isPassedOut(state) ? 'unconscious' : 'asleep';
      const explanation = wasUnconscious ? (atDoor
        ? sceneLine(next, `intervene:explain:${conditionKo}:door`, [
          [`당신은 열린 문을 가리킵니다. "안에서 기척이 나서 문을 열었어. 네가 ${conditionKo} 저 사람이 네 몸에 손을 대고 있더라. 그래서 막으려고 들어온 거야."`, `You point at the open door. "I heard movement inside and opened the door. He was touching you ${conditionEn}, so I came in to stop him."`],
          [`당신은 ${customer.name}을(를) 가리킵니다. "문 안에서 소리가 났어. 들어와 보니 네가 ${conditionKo} 저 사람이 네게 손을 대고 있었어. 보고만 있을 수 없었어."`, `You point at ${customer.name}. "I heard something inside. When I came in, he was touching you ${conditionEn}. I couldn't just watch."`],
          [`${wifeName(next)}이(가) 당신을 볼 때까지 기다린 뒤 말합니다. "네가 ${conditionKo} 방 안에서 이상한 기척이 났어. 문을 열어 보니 ${customer.name}이(가) 네 몸에 손을 대고 있었어."`, `You wait for ${wifeName(next)} to look at you. "I heard something strange in the room while you were ${conditionStateEn}. When I opened the door, ${customer.name} was touching you."`],
        ])
        : sceneLine(next, `intervene:explain:${conditionKo}:room`, [
          [`당신은 ${wifeName(next)}에게 말합니다. "눈을 떠 보니 ${customer.name}이(가) 네 몸에 손을 대고 있었어. 그래서 일어나 말리려던 거야."`, `You tell ${wifeName(next)}, "I woke up and saw ${customer.name} touching you, so I got up to stop him."`],
          [`당신은 ${customer.name}을(를) 가리킵니다. "저 사람이 네 몸에 손을 대고 있었어. 네가 ${conditionReasonKo} 보고만 있을 수 없었어."`, `You point at ${customer.name}. "He was touching you. You were ${conditionStateEn}, and I couldn't just watch."`],
          [`${wifeName(next)}이(가) 당신을 볼 때까지 기다린 뒤 말합니다. "${customer.name}이(가) 네게 손을 대고 있었어. 네가 ${conditionReasonKo} 내가 나선 거야."`, `You wait for ${wifeName(next)} to look at you. "${customer.name} was touching you. You were ${conditionStateEn}, so I stepped in."`],
        ])) : atDoor ? sceneLine(next, 'intervene:explain:awake_door', [
        [`당신이 열린 문을 가리킵니다. "안에서 이상한 소리가 들려서 문을 열었어."`, `You point at the open door. "I heard something strange inside, so I opened the door."`],
        [`당신은 문 쪽으로 손을 뻗습니다. "기척이 나서 문을 열었어. 저 사람이 여기 있었어."`, `You gesture at the door. "I heard movement, opened it, and found him here."`],
      ]) : sceneLine(next, 'intervene:explain:awake_room', [
        [`당신이 ${customer.name}을(를) 가리킵니다. "눈을 뜨니 저 사람이 곁에 있었어."`, `You point at ${customer.name}. "I woke up and found him beside you."`],
        [`당신은 ${wifeName(next)}을(를) 바라봅니다. "옆에서 기척이 나서 눈을 떴어. 저 사람이 네 곁에 있었어."`, `You look at ${wifeName(next)}. "I heard movement beside us and opened my eyes. He was right next to you."`],
      ]);
      next = api.fn('log')(next, explanation);
      if (choiceId === 'eject') {
        return ejectVisitor(next, assessment, customer, all, wasUnconscious);
      }
      if (assessment.refused) {
        return {
          ...next,
          pendingEvent: {
            type: 'sleep_actions_patron_intervention_refused',
            text: voiceLine(next, 'intervene:refused', {
              elena: [
                [`${wifeName(next)}은(는) ${customer.name}의 곁에서 당신을 바라봅니다. "괜찮아요. 제가 결정할게요."`, `${wifeName(next)} looks at you from beside ${customer.name}. "I'm all right. I'll decide for myself."`],
                [`${wifeName(next)}이(가) 당신에게 손바닥을 보입니다. "물러나 주세요. 이건 제 일이에요."`, `${wifeName(next)} raises a palm toward you. "Please step back. This is my decision."`],
              ],
              mara: [
                [`${wifeName(next)}은(는) ${customer.name}의 곁에 남아 당신을 노려봅니다. "내 일은 내가 정해. 나가."`, `${wifeName(next)} stays beside ${customer.name} and glares at you. "I'll decide for myself. Get out."`],
                [`${wifeName(next)}이(가) 당신 앞으로 한 걸음 나섭니다. "손대지 마. 내가 말했잖아."`, `${wifeName(next)} steps toward you. "Hands off. I already told you."`],
              ],
              pippa: [
                [`${wifeName(next)}은(는) ${customer.name}의 곁에서 고개를 젓습니다. "나 괜찮아. 내가 고를게."`, `${wifeName(next)} shakes her head beside ${customer.name}. "I'm okay. Let me choose."`],
                [`${wifeName(next)}이(가) 당신 앞에 손을 뻗어 막습니다. "잠깐! 나한테 먼저 물어봐."`, `${wifeName(next)} raises a hand to stop you. "Wait! Ask me first."`],
              ],
              other: [
                [`${wifeName(next)}은(는) ${customer.name}의 곁에 남아 당신을 바라봅니다. "난 괜찮아. 내 일은 내가 결정할게."`, `${wifeName(next)} stays beside ${customer.name} and looks at you. "I'm fine. I'll decide for myself."`],
                [`${wifeName(next)}이(가) 당신에게 손바닥을 보입니다. "물러나. 내가 정할 거야."`, `${wifeName(next)} raises a palm toward you. "Step back. I'll decide."`],
              ],
            }),
            choices: [
              { id: 'back_off', label: T('두 사람을 두고 나가기', 'Leave them alone') },
              { id: 'force', label: T('억지로 떼어놓기', 'Pull them apart by force') },
            ],
            customerId: customer.id,
            customerName: customer.name,
            currentRawScore: number(assessment.current.raw?.score),
            currentEffectiveScore: assessment.current.decision.score,
            currentThreshold: assessment.current.decision.threshold,
            explanationRawScore: number(assessment.explanation.raw?.score),
            explanationEffectiveScore: assessment.explanation.decision.score,
            explanationThreshold: assessment.explanation.decision.threshold,
            requiredInfluence: assessment.requiredInfluence,
            actualInfluence: assessment.actualInfluence,
            participantIds: Object.keys(all),
            sleepActionsPatronInterventionRefused: true,
            sleepActionsNightVisitInterventionRefused: true,
          },
        };
      }
      return finishIntervention(next, assessment, customer, all, wasUnconscious);
    }

    function resolveRefusalChoice(state, choiceId) {
      const event = state.pendingEvent;
      if (!event?.sleepActionsNightVisitInterventionRefused
        || !event.sleepActionsPatronInterventionRefused
        || !['back_off', 'force'].includes(choiceId)) return state;
      const intrusion = intrusionOf(state);
      const participantMap = Object.fromEntries(
        (event.participantIds || []).map(customerId => [customerId, { customerId }]),
      );
      const resolved = sleepActions.intervention.resolveChoice(state, choiceId);
      if (resolved === state) return state;
      if (choiceId === 'force') return closePlayerIntervention(resolved, participantMap);
      return writeData(resolved, {
        intrusion: { ...intrusion, awakeConsent: true, playerWoke: true },
      });
    }

    function resolveCallChoice(state, choiceId) {
      const intrusion = intrusionOf(state);
      if (!intrusion || !state.pendingEvent?.sleepActionsNightVisitCall) return state;
      const all = Object.fromEntries((state.pendingEvent.participantIds || [])
        .map(customerId => [customerId, { customerId }]));
      let next = sleepActions.patron.clearFlow({ ...state, pendingEvent: undefined }, all);
      if (choiceId === 'expel') {
        const room = sleepActions.patron.rentedRoom(next, intrusion.customerId);
        next = {
          ...next,
          customers: (next.customers || []).map(item => item.id === intrusion.customerId
            ? { ...item, status: 'leaving', isResident: false } : item),
          tavern: {
            ...(next.tavern || {}),
            ...(room === 'upstairs_hall' ? { tonightRenter: undefined } : {}),
            ...(room === 'upstairs_room_2' ? { tonightRenter2: undefined } : {}),
          },
        };
        if (Array.isArray(next.locations?.taproom?.occupants)) {
          next = api.fn('moveOccupant')(next, intrusion.customerId, 'taproom');
        }
        next = api.fn('applyEffects')(next, {
          targetCharacterId: next.primaryCharacterId,
          playerStatDeltas: {}, wifeStatDeltas: { mood: 3 }, wifeTraitDeltas: {},
          trustDelta: 3, resentDelta: -1,
        });
        next = api.fn('log')(next, sceneLine(next, 'call:expel', [
          [`당신은 ${intrusion.customerName}을(를) 주점 밖으로 몰아냅니다. ${wifeName(next)}은(는) 떨리는 숨을 고릅니다.`, `You drive ${intrusion.customerName} out of the tavern. ${wifeName(next)} steadies her breathing.`],
          [`${intrusion.customerName}이(가) 주점 밖으로 나갑니다. ${wifeName(next)}은(는) 그제야 길게 숨을 내쉽니다.`, `${intrusion.customerName} leaves the tavern. Only then does ${wifeName(next)} let out a long breath.`],
          [`"다시는 들어오지 마." 당신이 ${intrusion.customerName}을(를) 내쫓자 ${wifeName(next)}은(는) 손을 내려놓습니다.`, `"Don't come back." You drive ${intrusion.customerName} out, and ${wifeName(next)} lowers her hand.`],
        ]));
      } else if (choiceId === 'comfort') {
        next = api.fn('applyEffects')(next, {
          targetCharacterId: next.primaryCharacterId,
          playerStatDeltas: {}, wifeStatDeltas: { mood: 2 }, wifeTraitDeltas: {}, trustDelta: 2,
        });
        next = api.fn('log')(next, sceneLine(next, 'call:comfort', [
          [`당신이 ${wifeName(next)}에게 대답하자 그녀가 몇 번 숨을 고릅니다. ${intrusion.customerName}은(는) 더 다가오지 않고 자기 객실로 돌아갑니다.`, `You answer ${wifeName(next)}, and she steadies her breathing. ${intrusion.customerName} keeps his distance and returns to his room.`],
          [`당신은 ${wifeName(next)}의 이름을 부르며 괜찮다고 말합니다. 그녀의 숨소리가 조금씩 가라앉고 ${intrusion.customerName}은(는) 객실로 물러납니다.`, `You call ${wifeName(next)} by name and reassure her. Her breathing slows as ${intrusion.customerName} retreats to his room.`],
          [`"여기 있어." 당신의 대답에 ${wifeName(next)}은(는) 잠시 말을 잃습니다. ${intrusion.customerName}은(는) 뒤로 물러나 객실로 돌아갑니다.`, `"I'm here." At your answer, ${wifeName(next)} falls quiet for a moment. ${intrusion.customerName} backs away and returns to his room.`],
        ]));
      } else {
        next = api.fn('applyEffects')(next, {
          targetCharacterId: next.primaryCharacterId,
          playerStatDeltas: {}, wifeStatDeltas: { mood: -6 }, wifeTraitDeltas: {},
          trustDelta: -6, resentDelta: 4,
        });
        next = api.fn('log')(next, sceneLine(next, 'call:ignore', [
          [`당신은 대답하지 않습니다. ${wifeName(next)}은(는) 한동안 기다리다가 더는 부르지 않습니다.`, `You do not answer. ${wifeName(next)} waits a moment, then stops calling.`],
          [`${wifeName(next)}의 부름이 한 번 더 들리지만 당신은 움직이지 않습니다. 잠시 뒤 방 안이 조용해집니다.`, `${wifeName(next)} calls again, but you do not move. After a while the room falls quiet.`],
          [`당신이 침묵하자 ${wifeName(next)}은(는) 말을 잇지 않습니다. 그녀의 발소리만 천천히 멀어집니다.`, `You remain silent, and ${wifeName(next)} says no more. Her footsteps slowly fade away.`],
        ]));
      }
      return choiceId === 'ignore' ? closeVisit(next) : closePlayerIntervention(next);
    }

    function resolveCurrentEventChoice(state, choiceId) {
      if (state?.pendingEvent?.sleepActionsNightVisitNotice) {
        return resolveNoticeChoice(state, choiceId);
      }
      if (state?.pendingEvent?.sleepActionsNightVisitWake) {
        return resolveWakeChoice(state, choiceId);
      }
      if (state?.pendingEvent?.sleepActionsNightVisitInterventionRefused) {
        return resolveRefusalChoice(state, choiceId);
      }
      if (state?.pendingEvent?.sleepActionsNightVisitCall) {
        return resolveCallChoice(state, choiceId);
      }
      return state;
    }

    const START_ACTIONS = Object.freeze(
      ['in_place', 'guest_room'].flatMap(locationMode => (
        [false, true].flatMap(noticed => (
          [
            { state: 'target-unaware', wifeNoticed: false, targetInvited: false },
            { state: 'target-noticed', wifeNoticed: true, targetInvited: false },
            { state: 'target-invited', wifeNoticed: true, targetInvited: true },
          ].map(target => Object.freeze({
            id: `visit:start:${locationMode}:${noticed ? 'player-noticed' : 'player-unaware'}:${target.state}`,
            kind: 'start',
            group: T('방문 시작', 'Start visit'),
            label: T(
              `${locationMode === 'guest_room' ? '손님 객실' : '현재 침실'} · 플레이어 ${noticed ? '발견' : '미발견'} · 대상 ${target.targetInvited ? '직접 초대' : target.wifeNoticed ? '발견' : '미발견'}`,
              `${locationMode === 'guest_room' ? 'Guest room' : 'Current bedroom'} · player ${noticed ? 'notices' : 'unaware'} · target ${target.targetInvited ? 'invited him' : target.wifeNoticed ? 'notices' : 'unaware'}`,
            ),
            locationMode,
            noticed,
            wifeNoticed: target.wifeNoticed,
            targetInvited: target.targetInvited,
          }))
        ))
      )),
    );

    function actionCatalog(state, requestContext = {}) {
      const customerId = requestContext.customerId;
      const starts = START_ACTIONS.map(action => {
        const selected = customerId
          ? context(state, customerId, { targetInvited: action.targetInvited }) : null;
        return Object.freeze({
          ...action,
          customerId: customerId || null,
          eligible: !!selected,
          reason: selected ? undefined : customerId ? 'visitor_ineligible' : 'customer_required',
        });
      });
      const intrusion = intrusionOf(state);
      const wakeEligible = canWake(state);
      const lifecycle = [
        Object.freeze({
          id: 'visit:open-wake-event', kind: 'lifecycle', group: T('방문 진행', 'Visit progress'),
          label: T('개입을 위해 깨우기', 'Wake to intervene'),
          eligible: wakeEligible, reason: wakeEligible ? undefined : 'wake_unavailable',
        }),
        Object.freeze({
          id: 'visit:close', kind: 'lifecycle', group: T('방문 진행', 'Visit progress'),
          label: T('현재 방문 종료', 'Close current visit'),
          eligible: !!intrusion, reason: intrusion ? undefined : 'visit_missing',
        }),
      ];
      const event = state?.pendingEvent;
      const ownedEvent = event && (
        event.sleepActionsNightVisitNotice
        || event.sleepActionsNightVisitWake
        || event.sleepActionsNightVisitInterventionRefused
        || event.sleepActionsNightVisitCall
      );
      const currentChoices = ownedEvent ? (event.choices || []).map(choice => Object.freeze({
        id: `event:${event.type || 'night-visit'}:${choice.id}`,
        kind: 'event-choice',
        group: T('현재 사건', 'Current event'),
        label: choice.label,
        description: choice.description,
        eventType: event.type,
        choiceId: choice.id,
        eligible: choice.disabled !== true,
        reason: choice.disabled === true ? 'choice_disabled' : undefined,
      })) : [];
      return Object.freeze([...starts, ...lifecycle, ...currentChoices]);
    }

    function executeAction(state, request = {}) {
      const action = actionCatalog(state, { customerId: request.customerId })
        .find(entry => entry.id === request.id);
      if (!action) return { state, status: 'invalid', reason: 'action_unknown' };
      if (!action.eligible) {
        return { state, status: 'ineligible', reason: action.reason, actionId: action.id };
      }
      let next = state;
      if (action.kind === 'start') {
        next = beginVisit(state, { type: 'sleep', underway: request.underway !== false }, {
          customerId: request.customerId,
          locationMode: action.locationMode,
          forceLocationMode: true,
          noticed: action.noticed,
          wifeNoticed: action.wifeNoticed,
          targetInvited: action.targetInvited,
        }) || state;
      } else if (action.id === 'visit:open-wake-event') {
        next = openWakeEvent(state);
      } else if (action.id === 'visit:close') {
        next = closeVisit(state, { resumeSleep: request.resumeSleep === true });
      } else if (action.kind === 'event-choice') {
        next = resolveCurrentEventChoice(state, action.choiceId);
      }
      return {
        state: next,
        status: next === state ? 'ineligible' : 'applied',
        reason: next === state ? 'conditions_not_met' : undefined,
        actionId: action.id,
      };
    }

    function runToDecision(state) {
      let next = state;
      for (let guard = 0; guard < 180; guard++) {
        if (next.pendingEvent?.sleepActionsNightVisitCall) return next;
        if (sleepActions.state.isUnconscious(next) && next.activeScene?.patron) {
          next = { ...next, slot: whole(next.slot) + 1 };
          next = sleepActions.patron.advance(next);
          continue;
        }
        if (next.activeScene?.patron && !sleepActions.state.isUnconscious(next)) {
          next = { ...next, slot: whole(next.slot) + 1 };
          next = api.fn('processPatronInteractionTick')(next);
          continue;
        }
        if (!next.activeScene?.patron) return closeVisit(next);
        break;
      }
      return next;
    }

    api.hook('reduceGameAction', {
      around(next, state, action, ...rest) {
        const intrusion = intrusionOf(state);
        if (intrusion && NATIVE_DOOR_ACTIONS.has(action?.type)) {
          if (action.sleepActionsNightVisitDoorSignal === true) {
            return next(state, action, ...rest);
          }
          const visitRoom = api.fn('wifeLocation')(state);
          const targetRoom = action.room || visitRoom;
          if (targetRoom !== visitRoom) return next(state, action, ...rest);
          let doorState = intrusion.playerAtDoor ? state : approachVisitDoor(state);
          if (!intrusionOf(doorState)?.playerAtDoor) return doorState;
          if (action.type === 'knock_on_door') return performDoorCheck(doorState, 'knock');
          if (action.type === 'peek_inside') return performDoorCheck(doorState, 'peek');
          return openVisitDoor(doorState);
        }
        const intercepted = interceptNightVisit(state, action);
        if (intercepted) return intercepted;
        if (action?.type === 'resolve_event') {
          const lockedDoorEvent = state.pendingEvent?.type === BAD_GUEST_LOCKED_DOOR_EVENT
            && state.pendingEvent?.sleepActionsNightVisitDoor === true;
          if (lockedDoorEvent && [BAD_GUEST_BREAK_DOOR_CHOICE, BAD_GUEST_LEAVE_LOCKED_CHOICE]
            .includes(action.choiceId)) {
            const resolved = next(state, action, ...rest);
            return action.choiceId === BAD_GUEST_BREAK_DOOR_CHOICE && intrusionOf(resolved)
              ? openVisitDoor(resolved) : resolved;
          }
          const resolved = resolveCurrentEventChoice(state, action.choiceId);
          if (resolved !== state) return resolved;
        }
        if (action?.type === 'sleep' && intrusionOf(state)) return runToDecision(state);
        return next(state, action, ...rest);
      },
    });

    api.hook('worldTick', {
      after(state) {
        const intrusion = intrusionOf(state);
        if (!intrusion || state.pendingEvent || state.activeScene?.patron) return state;
        return intrusion.awakeConsent
          ? closeVisit(state, { resumeSleep: !intrusion.playerAtDoor && !intrusion.playerWoke }) : state;
      },
    });

    function visitActionControls(state) {
      const intrusion = intrusionOf(state);
      const atRemoteDoor = intrusion?.playerAtDoor === true;
      const buttons = atRemoteDoor ? [
        JSX.jsx(ActionButton, {
          label: T('노크하기', 'Knock'),
          time: DOOR_CHECK_MINUTES,
          description: T('문을 두드리고 대답을 기다립니다.', 'Knock and wait for an answer.'),
          onClick: () => api.store.dispatch({ type: DOOR_KNOCK_ACTION }),
        }, DOOR_KNOCK_ACTION),
        JSX.jsx(ActionButton, {
          label: T('안을 들여다보기', 'Peek inside'),
          time: DOOR_CHECK_MINUTES,
          description: T('문틈으로 방 안을 엿봅니다.', 'Peer through the gap into the room.'),
          onClick: () => api.store.dispatch({ type: DOOR_PEEK_ACTION }),
        }, DOOR_PEEK_ACTION),
        JSX.jsx(ActionButton, {
          label: T('문을 열고 개입하기', 'Open the door and intervene'),
          description: T('문을 열고 들어가 손님을 막습니다.', 'Open the door and stop the patron.'),
          onClick: () => api.store.dispatch({ type: DOOR_INTERVENE_ACTION }),
          primary: true,
        }, DOOR_INTERVENE_ACTION),
      ] : [JSX.jsx(ActionButton, {
        label: T('기척을 확인하러 일어나기', 'Get up to check the movement'),
        description: T('잠자리에서 일어나 소리가 난 곳으로 갑니다.', 'Get up and follow the sound.'),
        onClick: () => api.store.dispatch({ type: WAKE_ACTION }),
        primary: true,
      }, WAKE_ACTION)];
      return JSX.jsx('div', {
        className: 'mt-3 grid grid-cols-1 gap-2',
        'data-sleep-actions-night-visit-controls': atRemoteDoor ? 'door' : 'sleep',
        children: buttons,
      });
    }

    api.hook('ActionPanel', {
      after(original) {
        const state = api.store.game();
        if (!React.isValidElement(original) || !ownsActiveSleepPanel(state)) return original;
        return React.cloneElement(original, {}, [
          ...React.Children.toArray(original.props.children),
          visitActionControls(state),
        ]);
      },
    });

    api.hook('ClosedDoorActions', {
      around(next, props, ...rest) {
        const state = api.store.game();
        const intrusion = intrusionOf(state);
        const visitRoom = state ? api.fn('wifeLocation')(state) : null;
        if (!intrusion || !state.activeScene?.patron || props?.room !== visitRoom) {
          return next(props, ...rest);
        }
        return null;
      },
    });

    api.hook('roomSideForOccupant', {
      around(next, state, room, occupantId, ...rest) {
        const intrusion = intrusionOf(state);
        const isPlayer = occupantId == null || occupantId === 'player';
        if (intrusion?.playerAtDoor && intrusion.playerDoorRoom === room && isPlayer
          && api.fn('playerLocation')(state) === room) return 'outside';
        return next(state, room, occupantId, ...rest);
      },
    });

    api.actions.register(WAKE_ACTION, openWakeEvent, {
      label: T('기척을 확인하러 일어나기', 'Get up to check the movement'),
    });
    api.actions.register(DOOR_KNOCK_ACTION, state => performDoorCheck(state, 'knock'), {
      label: T('노크하기', 'Knock'),
    });
    api.actions.register(DOOR_PEEK_ACTION, state => performDoorCheck(state, 'peek'), {
      label: T('안을 들여다보기', 'Peek inside'),
    });
    api.actions.register(DOOR_INTERVENE_ACTION, openVisitDoor, {
      label: T('문을 열고 개입하기', 'Open the door and intervene'),
    });

    api.ui.settings((body, win) => {
      const value = settings();
      const numberRow = (key, label, step, note = '') => h('label', {
        style: 'display:grid;grid-template-columns:1fr 100px minmax(150px,auto);gap:10px;align-items:center;margin:7px 0',
      }, h('span', {}, label), h('input', {
        type: 'number', step, value: value[key],
        'data-sleep-actions-night-visit-setting': key,
        style: 'width:100px;padding:5px;background:#292524;color:#fafaf9;border:1px solid #78716c;border-radius:5px',
        onchange: event => { api.settings.set({ [key]: Number(event.target.value) }); win.refresh(); },
      }), h('span', { class: 'wml-muted', style: 'font-size:.85em;text-align:right' }, note));
      body.append(h('section', { class: 'wml-section' },
        h('h3', { style: 'margin:0 0 9px' }, T('투숙객 야간 방문 확률', 'Lodger night-visit chances')),
        numberRow('baseChance', T('기본 방문 확률', 'Base visit chance'), 1, '%'),
        numberRow('relationshipBonus', T('관계 최대 추가 확률', 'Maximum relationship bonus'), 1, '%'),
        numberRow('platonicWeight', T('우호 관계 반영 비율', 'Platonic relationship weight'), 0.01),
        numberRow('romanticWeight', T('연애 관계 반영 비율', 'Romantic relationship weight'), 0.01),
        numberRow('sexualWeight', T('성적 관계 반영 비율', 'Sexual relationship weight'), 0.01),
        numberRow('playerNoticeBaseChance', T('플레이어 기본 눈치챔 확률', 'Base player-notice chance'), 1, '%'),
        numberRow('playerNoticeWitBonus', T('재치 최대 추가 확률', 'Maximum wit bonus'), 1, '%'),
        numberRow('wifeNoticeBaseChance', T('대상 기본 눈치챔 확률', 'Base target-notice chance'), 1, '%'),
        numberRow('wifeNoticeWitWeight', T('대상 재치 1점당 보정', 'Modifier per target wit point'), 0.01),
        numberRow('wifeNoticeComposureWeight', T('대상 침착성 1점당 보정', 'Modifier per target composure point'), 0.01),
        numberRow('wifeNoticeMinimum', T('대상 눈치챔 하한', 'Target-notice chance floor'), 1, '%'),
        numberRow('wifeNoticeMaximum', T('대상 눈치챔 상한', 'Target-notice chance ceiling'), 1, '%'),
        numberRow('guestRoomMoveChance', T('자기 객실로 데려갈 확률', 'Chance to move her to his room'), 1, '%'),
      ));
    });

    api.provide(Object.freeze({
      apiVersion: 4,
      defaults: DEFAULTS,
      getSettings: settings,
      updateSettings(patch = {}) { api.settings.set(patch); return settings(); },
      resetSettings() { api.settings.set({ ...DEFAULTS }); return settings(); },
      getState(state = api.store.game()) { return state ? dataOf(state) : null; },
      visitChance,
      playerNoticeChance,
      wifeNoticeChance,
      candidates,
      context,
      chooseVisitor,
      beginVisit,
      interceptNightVisit,
      resolveNoticeChoice,
      resolveCurrentEventChoice,
      canWake,
      openWakeEvent,
      resolveWakeChoice,
      resolveCallChoice,
      closeVisit,
      actions: Object.freeze({
        catalog: actionCatalog,
        execute: executeAction,
        resolveCurrentEventChoice,
      }),
    }));
  },
});
