// 창관 + 임신 연동 — 유지보수 WML판
// 실행 파일 하나만 배포합니다. 임신 모드 3.1.0의 아이 처치 의사결정 엔진을 함께 사용합니다.
WML.define({
  id: 'brothel-pregnancy',
  author: "Hina_Lover",
  name: '창관 + 임신 연동',
  version: "2.2.0",
  game: "2026-11-01",
  lang: 'ko',
  description: '창관 종업원의 임신·출산과 친부 추정, 출산 후 아이 처치 상의·입양 사례금을 임신 모드와 연결합니다.',
  requires: ['addon-compat','brothel','pregnancy'],
  requiresVersion: {brothel:'>=3.15.0',pregnancy:'>=3.6.0'},
  loadAfter: ['brothel','pregnancy'],
  conflicts: [],
  symbols: {
    "BrothelPregnancyReduceGameAction": {"raw":{"2026-11-01":"p5"},"doc":"게임 행동과 경고창 선택을 처리합니다."},
    "BrothelPregnancyDrainAlerts": {"raw":{"2026-11-01":"oi"},"doc":"대기 중인 경고를 현재 사건으로 꺼냅니다."}
  },

  setup(wmlApi) {
    (()=>{
      'use strict';
      if(globalThis.__WAYWARD_BROTHEL_PREGNANCY_LOADED__)return;
      const addonApi=globalThis.__WAYWARD_ADDON_API__;
      const pregnancy=globalThis.__wc2PregnancyBirth265;
      const brothel=globalThis.__waywardBrothelPublic;
      if(!addonApi?.ue?.subscribe||!pregnancy?.planChildDisposition||!brothel){
        console.error('[Brothel Pregnancy] Brothel 3.7.0과 Pregnancy 3.1.0을 먼저 불러와야 합니다.');
        return;
      }
      globalThis.__WAYWARD_BROTHEL_PREGNANCY_LOADED__=true;

      const KEY='waywardBrothelPregnancyV1';
      const MAX_EVENTS=200;
      const MAX_SEEN=120;
      let internalWrite=false;

      function BrothelPregnancy_복사하기(value){
        try{return structuredClone(value)}catch{return JSON.parse(JSON.stringify(value))}
      }
      function BrothelPregnancy_범위값만들기(value,min=0,max=100){
        return Math.max(min,Math.min(max,Number(value)||0));
      }
      function BrothelPregnancy_아이디만들기(prefix){
        try{return `${prefix}:${crypto.randomUUID()}`}catch{return `${prefix}:${Date.now()}:${Math.random().toString(36).slice(2)}`}
      }
      function BrothelPregnancy_날짜읽기(state){return Math.max(1,Number(state?.day)||1)}
      function BrothelPregnancy_주기일읽기(day){
        const length=Number(pregnancy.getOptions().cycleLength)||7;
        return((day-1)%length)+1;
      }
      function BrothelPregnancy_주기이름읽기(day){
        const info=pregnancy.getCycleInfo?.(day,{});
        return info?.label??(BrothelPregnancy_주기일읽기(day)===1?'월경기':'황체기');
      }
      function BrothelPregnancy_옵션읽기(){return pregnancy.getOptions()}
      function BrothelPregnancy_정자량읽기(record){
        return(record?.spermDeposits??[]).reduce((sum,item)=>sum+(Number(item.amount)||0),0);
      }
      function BrothelPregnancy_임신확률읽기(record){
        return typeof pregnancy.getConceptionChance==='function'
          ?pregnancy.getConceptionChance(record)
          :Math.min(100,(Number(BrothelPregnancy_옵션읽기().conceptionChance)||0)+BrothelPregnancy_정자량읽기(record));
      }
      function BrothelPregnancy_새기록만들기(day){
        return{lastMorningDay:day-1,pausedAtDay:null,spermDeposits:[],pregnancy:null,seenServices:[]};
      }
      function BrothelPregnancy_친부추정정규화하기(raw){
        const result={};
        for(const role of ['wife','husband']){
          const candidates=Array.isArray(raw?.[role]?.candidates)?raw[role].candidates.filter(item=>item?.name).map(item=>({
            id:item.id==null?null:String(item.id),name:String(item.name)
          })):[];
          result[role]={candidates:[...new Map(candidates.map(item=>[item.id??item.name,item])).values()]};
        }
        return result;
      }
      function BrothelPregnancy_친부추정만들기(deposits){
        const estimates={};
        for(const role of ['wife','husband']){
          estimates[role]={candidates:[...new Map(deposits.filter(item=>item[`${role}Knows`]===true)
            .map(item=>[item.fatherId??item.fatherName,{id:item.fatherId,name:item.fatherName}])).values()]};
        }
        return BrothelPregnancy_친부추정정규화하기(estimates);
      }
      function BrothelPregnancy_아이처치정규화하기(raw){
        if(!raw||!['pending','parents','adopted'].includes(raw.status))return null;
        return BrothelPregnancy_복사하기(raw);
      }
      function BrothelPregnancy_데이터읽기(state){
        const raw=state?.[KEY],day=BrothelPregnancy_날짜읽기(state);
        const data={version:2,workers:{},events:[]};
        if(raw?.workers&&typeof raw.workers==='object')for(const [id,value] of Object.entries(raw.workers)){
          const record=BrothelPregnancy_새기록만들기(day);
          record.lastMorningDay=Number.isFinite(value?.lastMorningDay)?Number(value.lastMorningDay):record.lastMorningDay;
          record.pausedAtDay=Number.isFinite(value?.pausedAtDay)?Number(value.pausedAtDay):null;
          record.spermDeposits=Array.isArray(value?.spermDeposits)?value.spermDeposits.filter(item=>item&&Number.isFinite(item.day)&&Number.isFinite(item.amount)).map(item=>({
            id:String(item.id||BrothelPregnancy_아이디만들기('brothel-sperm')),day:Number(item.day),amount:Math.max(0,Math.round(Number(item.amount))),
            fatherId:item.fatherId==null?null:String(item.fatherId),fatherName:String(item.fatherName||'손님'),
            wifeKnows:item.wifeKnows!==false,husbandKnows:item.husbandKnows!==false,affection:BrothelPregnancy_범위값만들기(item.affection)
          })).filter(item=>item.amount>0):[];
          if(value?.pregnancy&&Number.isFinite(value.pregnancy.conceptionDay))record.pregnancy={
            childCount:pregnancy.normalizeChildCount(value.pregnancy.childCount),
            birthDeferred:value.pregnancy.birthDeferred===true,
            conceptionDay:Number(value.pregnancy.conceptionDay),fatherId:value.pregnancy.fatherId==null?null:String(value.pregnancy.fatherId),
            fatherName:String(value.pregnancy.fatherName||'손님'),fatherEstimates:BrothelPregnancy_친부추정정규화하기(value.pregnancy.fatherEstimates),
            beliefAffections:value.pregnancy.beliefAffections&&typeof value.pregnancy.beliefAffections==='object'?{...value.pregnancy.beliefAffections}:{}
          };
          record.seenServices=Array.isArray(value?.seenServices)?value.seenServices.map(String).slice(-MAX_SEEN):[];
          data.workers[id]=record;
        }
        data.events=Array.isArray(raw?.events)?raw.events.slice(-MAX_EVENTS).map(entry=>({...entry,
          id:String(entry.id||BrothelPregnancy_아이디만들기('brothel-pregnancy-event')),
          fatherEstimates:BrothelPregnancy_친부추정정규화하기(entry.fatherEstimates),
          childDisposition:BrothelPregnancy_아이처치정규화하기(entry.childDisposition)
        })):[]; 
        return data;
      }
      function BrothelPregnancy_로그추가하기(state,text,workerId){
        return{...state,log:[...(state.log??[]),{slot:Number(state.slot)||0,text,eventCategory:'ww_brothel_pregnancy',important:true,wwWorkerId:workerId}]};
      }
      function BrothelPregnancy_사건추가하기(data,state,worker,type,pregnancyRecord){
        const entry={id:BrothelPregnancy_아이디만들기(`brothel-${type}`),type,workerId:worker.id,motherName:worker.name,
          fatherId:pregnancyRecord.fatherId,fatherName:pregnancyRecord.fatherName,
          fatherEstimates:BrothelPregnancy_친부추정정규화하기(pregnancyRecord.fatherEstimates),day:BrothelPregnancy_날짜읽기(state),childDisposition:null};
        if(type==='birth')entry.children=pregnancy.birthChildren(entry.id,pregnancyRecord.childCount);
        entry.childCount=pregnancy.normalizeChildCount(pregnancyRecord.childCount);
        data.events.push(entry);data.events=data.events.slice(-MAX_EVENTS);
        const verb=type==='birth'?'출산했습니다':'임신했습니다';
        return{state:BrothelPregnancy_로그추가하기(state,`[창관 임신 / 출산] ${worker.name}이(가) ${pregnancyRecord.fatherName}의 아이 ${entry.childCount}명을 ${verb}`,worker.id),entry};
      }
      function BrothelPregnancy_관계호감읽기(state,worker,source){
        if(source.id==='player')return BrothelPregnancy_범위값만들기(brothel.playerRelationship?.(state,worker.id)?.affection);
        return BrothelPregnancy_범위값만들기(source.chemistry??source.charm??worker.tendencies?.intimacy);
      }
      function BrothelPregnancy_정자기록하기(data,state,worker,source,fingerprint){
        const day=BrothelPregnancy_날짜읽기(state),record=data.workers[worker.id]??BrothelPregnancy_새기록만들기(day);
        if(record.seenServices.includes(fingerprint))return false;
        record.seenServices=[...record.seenServices,fingerprint].slice(-MAX_SEEN);
        record.spermDeposits.push({id:BrothelPregnancy_아이디만들기('brothel-sperm'),day,amount:1+Math.floor(Math.random()*50),
          fatherId:String(source.id),fatherName:String(source.name||'손님'),wifeKnows:true,husbandKnows:true,
          affection:BrothelPregnancy_관계호감읽기(state,worker,source)});
        data.workers[worker.id]=record;
        return true;
      }
      function BrothelPregnancy_서비스기록하기(state,worker,customer){
        if(!state||!worker?.enabled||!customer||!BrothelPregnancy_옵션읽기().enabled||!(Number(customer.boldness)>55))return state;
        const data=BrothelPregnancy_데이터읽기(state),fingerprint=`guest:${BrothelPregnancy_날짜읽기(state)}:${Number(state.slot)||0}:${customer.id}`;
        if(!BrothelPregnancy_정자기록하기(data,state,worker,{...customer,id:String(customer.id),name:String(customer.name||'손님')},fingerprint))return state;
        return{...state,[KEY]:data};
      }
      function BrothelPregnancy_남편서비스동기화하기(data,state,active){
        let changed=false;
        for(const history of state.mods?.brothel?.playerHistory??[]){
          if(history?.stage!=='sex_patron'||history.serviceRecorded!==true||!history.id)continue;
          const worker=active.find(item=>item.id===history.workerId);if(!worker)continue;
          changed=BrothelPregnancy_정자기록하기(data,state,worker,{id:'player',name:"당신"},`player:${history.id}`)||changed;
        }
        return changed;
      }
      function BrothelPregnancy_직원삭제하기(state,workerId){
        if(!state?.[KEY])return state;
        const data=BrothelPregnancy_데이터읽기(state);delete data.workers[workerId];data.events=data.events.filter(entry=>entry.workerId!==workerId);
        return{...state,[KEY]:data};
      }
      function BrothelPregnancy_체력배수읽기(workerId){
        if(!BrothelPregnancy_옵션읽기().enabled)return 1;
        return addonApi.ue.getState().state?.[KEY]?.workers?.[workerId]?.pregnancy?1.5:1;
      }
      function BrothelPregnancy_임신의향계산하기(state,worker,pregnancyRecord){
        const candidates=pregnancyRecord.fatherEstimates?.wife?.candidates??[],scores=(candidates.length?candidates:[{id:'player'}]).map(candidate=>{
          const affection=candidate.id==='player'
            ?BrothelPregnancy_범위값만들기(brothel.playerRelationship?.(state,worker.id)?.affection)
            :BrothelPregnancy_범위값만들기(pregnancyRecord.beliefAffections?.[candidate.id??candidate.name]??worker.tendencies?.intimacy);
          const sexualScore=(BrothelPregnancy_범위값만들기(worker.affinities?.vaginal,-2,2)+2)*25;
          return Math.round(affection*.6+sexualScore*.4);
        });
        return Math.round(scores.reduce((sum,value)=>sum+value,0)/scores.length);
      }
      function BrothelPregnancy_알림추가하기(state,alert){
        let next={...state,alertQueue:[...(state.alertQueue??[]),alert]};
        if(!next.pendingEvent&&!next.errandSession)next=wmlApi.fn('BrothelPregnancyDrainAlerts')(next);
        return next;
      }
      function BrothelPregnancy_아이처치로그추가하기(state,worker,disposition,phase){
        const copy=phase==='question'?disposition.consultation:disposition.outcome,lines=[`[창관 아이 처치 상의] ${worker.name}`];
        if(copy?.husbandDialogue)lines.push(`사장님: “${copy.husbandDialogue}”`);
        if(copy?.dialogue)lines.push(`${worker.name}: “${copy.dialogue}”`);
        if(copy?.innerThought)lines.push(`속마음: ${copy.innerThought}`);
        if(phase==='result')lines.push(disposition.status==='adopted'
          ?`아이를 입양 보내고 사례금 ${disposition.adoptionFee}골드를 받았습니다.`:'아이를 부모님께 맡겨 키우기로 했습니다.');
        return BrothelPregnancy_로그추가하기(state,lines.join('\n'),worker.id);
      }
      function BrothelPregnancy_관계영향적용하기(state,worker,outcome){
        if(!outcome?.effect)return state;
        const current=brothel.playerRelationship?.(state,worker.id)??{},changes=outcome.parameterChanges;
        const delta=changes?{affinity:changes.affection,affection:changes.affection,trust:changes.trust}
          :outcome.effect==='positive'?{affinity:3,affection:3,trust:3}:{affinity:-3,affection:-2,trust:-4};
        const relationship={...current};
        for(const key of ['affinity','affection','trust'])relationship[key]=BrothelPregnancy_범위값만들기((Number(current[key])||0)+delta[key]);
        return{...state,mods:{...state.mods,brothel:{...state.mods?.brothel,relationships:{...state.mods?.brothel?.relationships,[worker.id]:relationship}}}};
      }
      function BrothelPregnancy_선택처리하기(next,state,action){
        const alert=state.pendingEvent?.alert,choiceId=action?.choiceId;
        if(action?.type!=='resolve_event'||alert?.kind!=='wc2_child_disposition'||alert.childDisposition?.source!=='brothel-pregnancy'||
          alert.childDisposition?.phase!=='question')return next(state,action);
        if(!['pregnancy_child_parents','pregnancy_child_adoption','pregnancy_child_adoption_profit'].includes(choiceId))return state;
        const choices=state.pendingEvent.choices??alert.choices??[];
        if(!choices.some(choice=>choice.id===choiceId&&!choice.disabled))return state;
        const initial=BrothelPregnancy_데이터읽기(state).events.find(item=>item.id===alert.childDisposition.recordId);
        const worker=brothel.getConfig()?.workers?.find(item=>item.id===alert.childDisposition.workerId);
        if(initial?.childDisposition?.status!=='pending'||!worker)return state;
        const deferredQueue=state.alertQueue??[];
        let result=next({...state,alertQueue:[]},action);const data=BrothelPregnancy_데이터읽기(result);
        const entry=data.events.find(item=>item.id===alert.childDisposition.recordId);
        if(!entry?.childDisposition||entry.childDisposition.status!=='pending'||!worker)return result;
        const choice=choiceId==='pregnancy_child_adoption_profit'?'adoption_profit':choiceId==='pregnancy_child_adoption'?'adoption':'parents';
        const disposition=pregnancy.resolveChildDisposition(entry.childDisposition,choice,result.day);entry.childDisposition=disposition;result={...result,[KEY]:data};
        if(disposition.adoptionFee)result={...result,economy:{...(result.economy??{}),gold:(Number(result.economy?.gold)||0)+disposition.adoptionFee}};
        result=BrothelPregnancy_관계영향적용하기(result,worker,disposition.outcome);
        const moodDelta=Number(disposition.outcome?.parameterChanges?.mood)||0;
        if(moodDelta){
          worker.stats={...worker.stats,mood:BrothelPregnancy_범위값만들기((Number(worker.stats?.mood)||0)+moodDelta)};
          const runtime=brothel.getRuntime().get(worker.id);if(runtime)runtime.stats.mood=worker.stats.mood;brothel.saveConfig();
        }
        result=BrothelPregnancy_아이처치로그추가하기(result,worker,disposition,'result');
        const followup=pregnancy.makeChildDispositionAlert(disposition,entry.id,worker.name,'brothel-pregnancy',worker.id);
        result={...result,alertQueue:[followup,...(result.alertQueue??[]),...deferredQueue]};
        if(!result.pendingEvent&&!result.errandSession)result=wmlApi.fn('BrothelPregnancyDrainAlerts')(result);
        return result;
      }
      function BrothelPregnancy_저장변경처리하기(){
        if(internalWrite)return;
        const root=addonApi.ue.getState(),state=root?.state;if(!root?.started||!state)return;
        const data=BrothelPregnancy_데이터읽기(state),day=BrothelPregnancy_날짜읽기(state),active=brothel.getConfig()?.workers?.filter(worker=>worker.enabled)??[];
        const enabled=BrothelPregnancy_옵션읽기().enabled,externalPause=state.wc2PregnancyBirthMode265?.pausedAtDay;
        let changed=state[KEY]?.version!==2,next=state;const births=[];
        changed=BrothelPregnancy_남편서비스동기화하기(data,state,active)||changed;
        for(const worker of active){
          const record=data.workers[worker.id];if(!record)continue;
          if(!enabled||externalPause!=null){if(record.pausedAtDay==null){record.pausedAtDay=Number.isFinite(externalPause)?externalPause:day;changed=true}continue}
          if(record.pausedAtDay!=null){
            const gap=Math.max(0,day-record.pausedAtDay);record.spermDeposits=record.spermDeposits.map(item=>({...item,day:item.day+gap}));
            if(record.pregnancy)record.pregnancy={...record.pregnancy,conceptionDay:record.pregnancy.conceptionDay+gap};
            record.pausedAtDay=null;record.lastMorningDay=day;changed=true;continue;
          }
          const due=record.pregnancy&&day-record.pregnancy.conceptionDay>=4;
          const deferred=due&&record.pregnancy.birthDeferred;
          if(!deferred&&(state.phase!=='prep'||record.lastMorningDay===day))continue;
          if(due&&brothel.workerHasService(state,worker.id)){
            if(!deferred){record.pregnancy.birthDeferred=true;changed=true;}
            continue;
          }
          if(day<record.lastMorningDay){record.lastMorningDay=day;changed=true;continue}
          record.lastMorningDay=day;record.spermDeposits=record.spermDeposits.filter(item=>day-item.day<=2);changed=true;
          if(record.pregnancy&&day-record.pregnancy.conceptionDay>=4){
            const pregnancyRecord=record.pregnancy,result=BrothelPregnancy_사건추가하기(data,next,worker,'birth',pregnancyRecord);next=result.state;
            const relationship=brothel.playerRelationship?.(state,worker.id),desireScore=BrothelPregnancy_임신의향계산하기(state,worker,pregnancyRecord);
            const disposition=pregnancy.planChildDisposition({fatherEstimates:pregnancyRecord.fatherEstimates,desireScore,profile:worker,
              relationshipTrust:relationship?.trust,motherName:worker.name,day,address:'사장님'});
            result.entry.childDisposition=disposition;
            next=BrothelPregnancy_알림추가하기(next,{id:result.entry.id,kind:'brothel_birth',severity:'critical',pause:true,
              title:worker.name+' · 출산',body:'아이 '+result.entry.childCount+'명이 태어났습니다. 다음 날 아침까지 출산 휴가입니다.',
              slot:state.slot,choices:[{id:'dismiss',label:'계속하기'}]});
            if(disposition.adoptionFee)next={...next,economy:{...(next.economy??{}),gold:(Number(next.economy?.gold)||0)+disposition.adoptionFee}};
            if(disposition.showEvent){
              next=BrothelPregnancy_아이처치로그추가하기(next,worker,disposition,disposition.status==='pending'?'question':'result');
              next=BrothelPregnancy_알림추가하기(next,pregnancy.makeChildDispositionAlert(disposition,result.entry.id,worker.name,'brothel-pregnancy',worker.id));
            }
            record.pregnancy=null;births.push(worker);
            next=brothel.setBirthLeave(next,worker.id);
          }else if(!record.pregnancy&&['배란기','황체기'].includes(BrothelPregnancy_주기이름읽기(day))&&record.spermDeposits.length&&Math.random()*100<BrothelPregnancy_임신확률읽기(record)){
            const possible=[...new Map(record.spermDeposits.map(item=>[item.fatherId??item.fatherName,item])).values()];
            const father=possible[Math.floor(Math.random()*possible.length)];
            record.pregnancy={conceptionDay:day,childCount:pregnancy.rollChildCount(),fatherId:father.fatherId,fatherName:father.fatherName,
              fatherEstimates:BrothelPregnancy_친부추정만들기(record.spermDeposits),
              beliefAffections:Object.fromEntries(possible.map(item=>[item.fatherId??item.fatherName,item.affection]))};
            record.spermDeposits=[];const result=BrothelPregnancy_사건추가하기(data,next,worker,'conception',record.pregnancy);next=result.state;
          }
        }
        if(!changed)return;
        for(const worker of births){worker.stats.energy=10;const runtime=brothel.getRuntime().get(worker.id);if(runtime)runtime.stats.energy=10}
        if(births.length)brothel.saveConfig();
        internalWrite=true;
        try{addonApi.ue.setState(current=>({...current,state:{...next,[KEY]:data}}))}finally{internalWrite=false}
        brothel.refreshSettings();
      }
      function BrothelPregnancy_요소만들기(tag,className,text){
        const node=document.createElement(tag);if(className)node.className=className;if(text!=null)node.textContent=text;return node;
      }
      function BrothelPregnancy_친부표시읽기(record){
        try{return pregnancy.getFatherDisplay(record)}catch{return{wife:'불명',husband:'불명'}}
      }
      function BrothelPregnancy_설정그리기(state,config){
        const section=BrothelPregnancy_요소만들기('section','ww-global ww-pregnancy'),title=BrothelPregnancy_요소만들기('h3','', '매춘부 임신 / 출산');
        section.append(title,BrothelPregnancy_요소만들기('p','ww-help',"임신 모드의 ON/OFF·주기·확률·아이 처치 상의·입양 사례금 설정을 함께 사용합니다. 종업원과 손님의 성관계 및 당신의 유료 성관계를 친부 추정에 반영합니다."));
        const data=BrothelPregnancy_데이터읽기(state),day=BrothelPregnancy_날짜읽기(state),workers=BrothelPregnancy_요소만들기('div','ww-pregnancy-workers');
        for(const worker of config.workers.filter(item=>item.enabled)){
          const record=data.workers[worker.id],display=record?.pregnancy?BrothelPregnancy_친부표시읽기(record.pregnancy):null;
          const status=record?.pregnancy?`${day-record.pregnancy.conceptionDay<=1?'임신 초기':day-record.pregnancy.conceptionDay===2?'임신 중기':'임신 후기'} · 직원 추정 ${display.wife} · 사장 추정 ${display.husband}`
            :`${BrothelPregnancy_주기이름읽기(day)} (${BrothelPregnancy_주기일읽기(day)}/${BrothelPregnancy_옵션읽기().cycleLength}일차)`;
          const amount=BrothelPregnancy_정자량읽기(record),chance=record?.pregnancy?'임신 중':record?.spermDeposits?.length?`${BrothelPregnancy_임신확률읽기(record)}%`:'정자 없음';
          workers.append(BrothelPregnancy_요소만들기('div','ww-pregnancy-worker',`${worker.name} · ${status} · 자궁 내 정자량 ${amount}M · 임신 판정 ${chance}`));
        }
        if(!workers.childElementCount)workers.append(BrothelPregnancy_요소만들기('p','ww-help','고용 중인 매춘부가 없습니다.'));
        section.append(workers,BrothelPregnancy_요소만들기('h4','', '임신 / 출산 Log'));
        const list=BrothelPregnancy_요소만들기('div','ww-pregnancy-log');
        if(!data.events.length)list.append(BrothelPregnancy_요소만들기('p','ww-help','아직 임신·출산 기록이 없습니다.'));
        for(const entry of [...data.events].reverse()){
          const disposition=entry.childDisposition,status=entry.type==='birth'&&disposition
            ?disposition.status==='adopted'?` · 입양 ${disposition.adoptionFee}G`:disposition.status==='pending'?' · 아이 처치 상의 중':' · 부모님께 맡김':'';
          const row=BrothelPregnancy_요소만들기('div','ww-pregnancy-entry',`${entry.day}일차 · ${entry.motherName} · ${entry.fatherName}의 아이 ${pregnancy.normalizeChildCount(entry.childCount)}명 ${entry.type==='birth'?'출산':'임신'}${status}${pregnancy.getChildDispositionHistoryText?.(disposition)??''}`);
          row.style.whiteSpace='pre-line';list.append(row);
        }
        section.append(list);return section;
      }
      const style=BrothelPregnancy_요소만들기('style');
      style.textContent='#ww-settings .ww-pregnancy-workers{display:grid;gap:6px;margin:10px 0}#ww-settings .ww-pregnancy-worker,#ww-settings .ww-pregnancy-entry{padding:7px 9px;border:1px solid #44403c;border-radius:6px;background:#1c1917;font-size:12px;color:#e7e5e4}#ww-settings .ww-pregnancy-log{display:grid;gap:5px;max-height:240px;overflow:auto;margin-top:7px}';
      document.head.append(style);
      wmlApi.hook('BrothelPregnancyReduceGameAction',{priority:-700,around:BrothelPregnancy_선택처리하기});
      globalThis.__waywardBrothelPregnancy={recordService:BrothelPregnancy_서비스기록하기,dismissWorker:BrothelPregnancy_직원삭제하기,
        energyMultiplier:BrothelPregnancy_체력배수읽기,renderSettings:BrothelPregnancy_설정그리기,getData:()=>BrothelPregnancy_데이터읽기(addonApi.ue.getState().state)};
      addonApi.ue.subscribe(BrothelPregnancy_저장변경처리하기);BrothelPregnancy_저장변경처리하기();
    })();
  }
});
