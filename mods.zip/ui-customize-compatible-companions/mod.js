// UI_customize + Companions adapter. Original live monitor: Hina_Lover's Companions,
// files/live.js (itself references the Brothel live monitor). No copied simulation.
WML.define({
  id:'ui-customize-compatible-companions',name:'UI_customize · 동료 실시간 연결',
  author:'Hina_Lover',version:"1.2.2",game:"2026-11-01",lang:'ko',tags:['util'],
  description:'동료 전체 창과 인물별 실시간 카드를 독립적인 고정·Floating 블록으로 연결합니다.',
  requires:['ui-customize','companions'],requiresVersion:{'ui-customize':'>=1.1.1','companions':'>=2.6.0'},loadAfter:['ui-customize','companions'],
  setup(api){
    const layout=WML.use('ui-customize'),people=WML.use('companions'),live=people.live;
    if(!live||!layout?.migrateBlockIds)throw Error('UI_customize 1.1.1과 Companions 2.6.0 이상이 필요합니다.');
    const entries=new Map(),host=document.createElement('div');host.hidden=true;host.dataset.uicCompanionsCards='';document.body.append(host);
    let whole=null,queued=false,stopped=false,migrated=false;
    const style=document.createElement('style');style.textContent=`[data-uic-companions-source]{visibility:hidden!important;pointer-events:none!important}[data-uic-body]>.companions-live{width:100%;height:100%;min-height:0;box-sizing:border-box;padding:6px}[data-uic-body]>.companions-live-card{width:100%;height:100%;min-height:0;box-sizing:border-box}`;document.head.append(style);
    function scan(){
      queued=false;if(stopped)return;
      const state=api.store.game(),list=people.list(state),config=live.getConfig();
      if(!migrated&&list.length){migrated=true;const mapping={};for(let i=0;i<16;i++){const id=config.slots[i]||(!Object.keys(config.slots).length?list[i]?.id:null);mapping['companions:card:'+i]=id?'companions:person:'+id:null;}layout.migrateBlockIds(mapping);}
      const owner=document.querySelector('[data-companions-window="live"]');layout.setBlockAvailable('companions:live',!!owner);
      if(whole&&whole.owner!==owner){whole.unregister();whole.owner.removeAttribute('data-uic-companions-source');whole=null;}
      if(owner&&!whole){const node=owner.querySelector('.companions-live');if(node){const unregister=layout.registerBlock({id:'companions:live',node,title:'동료 실시간 · 전체',source:'companions',dockLabel:'고정',gameFontSize:true,kind:'monitor',onClaim(){owner.setAttribute('data-uic-companions-source','');},onRelease(){owner.removeAttribute('data-uic-companions-source');}});whole={owner,unregister};}}
      const keep=new Set(list.map(p=>p.id));
      for(const [id,entry]of entries)if(!keep.has(id)){layout.restore('companions:person:'+id);entry.unregister();live.destroyCard(entry.card);entries.delete(id);}
      for(const p of list){const key='companions:person:'+p.id,title='동료 · '+p.name;let entry=entries.get(p.id);
        if(!entry){const card=live.createCard(p.id);host.append(card.el);entry={card,title};entries.set(p.id,entry);entry.unregister=layout.registerBlock({id:key,node:card.el,title,source:'companions',dockLabel:'고정',gameFontSize:true,kind:'card',onClaim(){live.updateCard(card);}});}
        if(entry.title!==title){entry.title=title;layout.updateBlock(key,{title});}
        if(layout.isPlaced(key))live.updateCard(entry.card,state);
      }
    }
    function schedule(){if(queued||stopped)return;queued=true;requestAnimationFrame(scan);}
    const unsubscribe=live.subscribe(schedule),unlayout=layout.subscribe(schedule);
    api.ui.settings(root=>{live.renderSettings(root);root.append(api.ui.h('p',{},'UI_customize의 세부 창에서 동료 이름을 선택해 고정하거나 Floating으로 엽니다. 개인 창은 전체 실시간 창과 독립적입니다.'),api.ui.button('UI_customize 열기',()=>layout.openSettings()));});
    if(live.legacyVisibility&&api.settings.get({restoreLive:false}).restoreLive&&layout.isPlaced('companions:live'))live.setVisible(true);
    api.provide({refresh:scan,open(){live.setVisible(true);schedule();},ids:()=>[...(whole?['companions:live']:[]),...[...entries.keys()].map(id=>'companions:person:'+id)]});schedule();
    window.addEventListener('pagehide',()=>{stopped=true;unsubscribe();unlayout();},{once:true});
  }
});
