// 생성 파일. 수정: source/mod.wml.js, source/native-ui.js — 재생성: node wml/mods/editor/source/build.mjs
// 각 모드에 포함되는 설정 UI. 게임 HTML의 메뉴와 DOM만 사용합니다.
WML.define({
  id: "editor",
  author: "Hina_Lover",
  name: "게임 에디터(HL)",
  version: "1.2.3",
  game: "2026-11-01",
  lang: 'ko',
  description: "게임 수치와 손님을 편집하는 도구입니다.",
  requires: ["addon-compat"],
  loadAfter: [],
  conflicts: [],
  role: ["custom-guests"],

  setup(wmlApi) {
// 생성 파일. 수정: source/mod.wml.js, source/native-ui.js — 재생성: node wml/mods/editor/source/build.mjs
// 각 모드에 포함되는 설정 UI. 게임 HTML의 메뉴와 DOM만 사용합니다.
(() => {
  if (globalThis.__waywardPauseSettingsUiFactory?.version === 1) return;
  const entries = new Map(), windows = new Map();
  const legacyButtons = '[data-wc2-preg-menu],[data-wc2-customer-menu],.ww-brothel-menu-button,[data-bad-guest-settings-launch],[data-ww-image-studio-menu]';
  let queued = false, theme = null;
  const cssValues = new Map(), cssProbe = document.createElement('div').style;

  function ModNativeUI_요소만들기(tag, props, ...children) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(props || {})) {
      if (value == null || value === false) continue;
      if (key === 'class') node.className = value;
      else if (key === 'style') node.style.cssText = value;
      else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2).toLowerCase(), value);
      else if (key in node && key !== 'list') node[key] = value;
      else node.setAttribute(key, value === true ? '' : String(value));
    }
    for (const child of children.flat()) if (child != null && child !== false) node.append(child.nodeType ? child : String(child));
    return node;
  }
  // WML 0.9.5 owns pause-menu placement through api.ui.pauseSettings.
  function ModNativeUI_메뉴찾기() { return []; }
  function ModNativeUI_스타일지정하기(node, property, value) {
    const key = property + ':' + value;
    if (!cssValues.has(key)) { cssProbe.setProperty(property, value); cssValues.set(key, cssProbe.getPropertyValue(property)); }
    if (node.style.getPropertyValue(property) !== cssValues.get(key) || node.style.getPropertyPriority(property) !== 'important') node.style.setProperty(property, value, 'important');
  }
  function ModNativeUI_테마읽기(button) {
    const native = getComputedStyle(button || document.getElementById('root') || document.body);
    const channels = (native.backgroundColor.match(/[\d.]+/g) || [28, 25, 23]).slice(0, 3).map(Number);
    const luminance = Math.max(.09, Math.min(.22, (Math.max(...channels) + Math.min(...channels)) / 510));
    return { font: native.fontFamily || 'sans-serif', background: `hsl(32 52% ${Math.round(luminance * 100 + 4)}%)`,
      foreground: 'hsl(40 78% 88%)', border: 'hsl(32 55% 34%)', radius: native.borderRadius || '6px' };
  }
  function ModNativeUI_버튼색칠하기(button, settings) {
    const colors = theme = ModNativeUI_테마읽기(settings);
    for (const [key, value] of Object.entries({ background: colors.background, color: colors.foreground,
      'border-color': colors.border, 'border-width': '1px', 'border-style': 'solid', 'border-radius': colors.radius,
      width: '100%', padding: '8px 16px', 'font-family': colors.font, 'font-size': '14px', cursor: 'pointer' })) ModNativeUI_스타일지정하기(button, key, value);
  }
  function ModNativeUI_앞으로올리기(node) {
    ModNativeUI_스타일지정하기(node, 'z-index', '2147483647');
    if (node.parentElement === document.body && node.nextElementSibling) document.body.append(node);
  }
  function ModNativeUI_정리하기() {
    for (const { list, settings } of ModNativeUI_메뉴찾기()) {
      let anchor = settings;
      for (const [owner, entry] of entries) {
        const official = [...list.querySelectorAll('[data-wml-pause-entry]')].find(node => node.dataset.wmlPauseEntry === owner);
        if (official) {
          for (const old of [...list.children]) if (old !== official &&
            (old.dataset.waywardNativeSettings === owner || entry.legacyButton && old.matches(entry.legacyButton))) old.remove();
          anchor = official;
          continue;
        }
        let button = [...list.children].find(node => node.dataset.waywardNativeSettings === owner);
        if (!button && entry.legacyButton) button = list.querySelector(entry.legacyButton);
        if (!button) {
          button = ModNativeUI_요소만들기('button', { type: 'button', class: settings.className,
            'data-wayward-native-settings': owner, ...entry.attributes,
            class: `${settings.className} ${entry.attributes?.class || ''}`.trim() }, entry.label);
          button.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); entry.onClick?.();
            queueMicrotask(() => entry.windowSelector && document.querySelectorAll(entry.windowSelector).forEach(ModNativeUI_앞으로올리기)); });
          list.append(button);
        }
        button.dataset.waywardNativeSettings = owner;
        // 이 표시는 새 로더의 기존 버튼 정렬과도 같은 순서를 유지하게 합니다.
        // 구형 로더에서는 사용하지 않아도 HTML 메뉴가 직접 처리됩니다.
        button.dataset.wmlModSettings = owner;
        ModNativeUI_버튼색칠하기(button, settings);
        if (button.textContent !== entry.label) button.textContent = entry.label;
        if (anchor.nextElementSibling !== button) anchor.after(button);
        anchor = button;
      }
      const panel = list.parentElement;
      if (panel.style.maxHeight !== 'calc(100dvh - 32px)') panel.style.maxHeight = 'calc(100dvh - 32px)';
      if (panel.style.overflowY !== 'auto') panel.style.overflowY = 'auto';
    }
    for (const entry of entries.values()) if (entry.windowSelector) {
      for (const panel of document.querySelectorAll(entry.windowSelector)) {
        ModNativeUI_스타일지정하기(panel, 'z-index', '2147483647');
      }
    }
  }
  function ModNativeUI_정리예약하기() {
    if (queued) return;
    queued = true;
    queueMicrotask(() => { queued = false; ModNativeUI_정리하기(); });
  }
  function ModNativeUI_버튼만들기(label, onClick, options = {}) {
    return ModNativeUI_요소만들기('button', { type: 'button', class: 'wayward-native-button',
      title: options.title, disabled: options.disabled, onclick: onClick,
      style: options.primary ? 'background:#78350f;color:#fef3c7' : '' }, label);
  }
  function ModNativeUI_창열기(owner, options) {
    const id = `${owner}:${options.id || 'settings'}`;
    if (windows.has(id)) { const prior = windows.get(id); prior.focus(); return prior; }
    const colors = theme || ModNativeUI_테마읽기();
    const width = Math.min(options.width || 520, Math.max(280, innerWidth - 16));
    const height = Math.min(options.height || 440, Math.max(160, innerHeight - 16));
    const title = ModNativeUI_요소만들기('strong', {}, options.title || owner);
    const body = ModNativeUI_요소만들기('div', { class: 'wayward-native-window-body' });
    const node = ModNativeUI_요소만들기('section', { class: 'wayward-native-window', role: 'region',
      'aria-label': options.title || owner, 'data-wml-ui': owner, 'data-wayward-native-window': id,
      style: `left:${Math.max(8, (innerWidth - width) / 2)}px;top:${Math.max(8, (innerHeight - height) / 3)}px;width:${width}px;height:${height}px;font-family:${colors.font}` });
    let removeBack = null;
    function ModNativeUI_창닫기() { node.remove(); windows.delete(id); removeBack?.(); options.onClose?.(); }
    const bar = ModNativeUI_요소만들기('header', { class: 'wayward-native-window-title' }, title,
      ModNativeUI_버튼만들기('✕', ModNativeUI_창닫기, { title: '닫기' }));
    node.append(bar, body);
    const handle = { el: node, body, owner, close: ModNativeUI_창닫기,
      focus: () => {
        ModNativeUI_앞으로올리기(node); windows.delete(id); windows.set(id, handle);
        if (typeof options.onBack === 'function') {
          removeBack?.(); removeBack = options.onBack(() => { handle.close(); return true; });
        }
      }, setTitle: value => { title.textContent = value; },
      refresh: () => { body.replaceChildren(); options.render?.(body, handle); } };
    node.addEventListener('pointerdown', handle.focus);
    bar.addEventListener('pointerdown', event => {
      if (event.button !== 0 || event.target.closest('button')) return;
      event.preventDefault();
      const x = event.clientX - node.offsetLeft, y = event.clientY - node.offsetTop;
      const move = next => { node.style.left = Math.max(0, Math.min(innerWidth - 80, next.clientX - x)) + 'px'; node.style.top = Math.max(0, Math.min(innerHeight - 40, next.clientY - y)) + 'px'; };
      const stop = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', stop); };
      window.addEventListener('pointermove', move); window.addEventListener('pointerup', stop, { once: true });
    });
    windows.set(id, handle); document.body.append(node); handle.focus(); handle.refresh();
    return handle;
  }
  const style = ModNativeUI_요소만들기('style', { 'data-wayward-native-ui': '1' });
  style.textContent = `
    .wayward-native-window{position:fixed;display:flex;flex-direction:column;font-size:14px;max-width:calc(100vw - 16px);max-height:calc(100dvh - 16px);min-width:280px;min-height:160px;resize:both;overflow:hidden;background:#1c1917;color:#e7e5e4;border:1px solid #92400e;border-radius:9px;box-shadow:0 14px 44px #000c}
    .wayward-native-window-title{display:flex;align-items:center;gap:8px;padding:8px 10px;background:#292524;border-bottom:1px solid #44403c;cursor:move;touch-action:none}.wayward-native-window-title strong{flex:1;font-size:14px}.wayward-native-window-body{flex:1;overflow:auto;padding:12px}
    .wayward-native-button{border:1px solid #57534e;border-radius:6px;padding:6px 10px;background:#292524;color:#e7e5e4;cursor:pointer;font:inherit}.wayward-native-button:disabled{opacity:.45;cursor:default}
    .wayward-native-window .wml-muted{color:#a8a29e}.wayward-native-window .wml-note{color:#fde68a}.wayward-native-window .wml-small{font-size:12px}
    @media(max-width:640px){.wayward-native-window{left:8px!important;top:8px!important;width:calc(100vw - 16px)!important;height:calc(100dvh - 16px)!important;resize:none}}
  `;
  document.head.append(style);
  const observer = new MutationObserver(ModNativeUI_정리예약하기);
  observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'hidden', 'class'] });
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape' || !windows.size) return;
    [...windows.values()].at(-1).close(); event.preventDefault(); event.stopImmediatePropagation();
  }, true);
  window.addEventListener('pagehide', () => observer.disconnect(), { once: true });
  function ModNativeUI_연결하기(base, config) {
    const owner = config.id, raw = name => config.bindings?.[base.game]?.[name] || name;
    const resolve = name => {
      const candidate = raw(name);
      if (base.engine && candidate in base.engine) return candidate;
      return base.sym(name);
    };
    const registerMenu = options => { entries.set(owner, options); return base.ui.pauseSettings({ ...options, attributes: { ...options.attributes, 'data-wayward-native-settings': owner }, onClick: () => { options.onClick?.(); queueMicrotask(() => options.windowSelector && document.querySelectorAll(options.windowSelector).forEach(ModNativeUI_앞으로올리기)); } }); };
    const ui = { ...base.ui,
      h: ModNativeUI_요소만들기, button: ModNativeUI_버튼만들기,
      window: options => ModNativeUI_창열기(owner, { ...options, onBack: base.onBack }),
      settings: render => {
        base.ui.settings(render);
        registerMenu({ label: config.label, onClick: () => ModNativeUI_창열기(owner,
          { id: 'settings', title: config.label, render, onBack: base.onBack }) }); ModNativeUI_정리예약하기();
      },
      menuSettings: registerMenu,
    };
    const facade = { ...base, ui,
      fn: name => base.engine?.[resolve(name)], sym: resolve,
      has: name => { try { return !!resolve(name); } catch { return false; } },
      hook: (name, options) => base.hook(resolve(name), options),
      onBack: typeof base.onBack === 'function' ? base.onBack : () => () => {},
    };
    if (config.legacy) ui.menuSettings(config.legacy);
    return facade;
  }
  globalThis.__waywardPauseSettingsUiFactory = { version: 1, connect: ModNativeUI_연결하기 };
})();

// 게임 에디터 — WML 포팅판
// 원본: editor.js (md5 20d54e6313aa3a2fa83451a44403ad4c), 9-30 한글판 모드 매니저용 애드온.
// 원본 코드는 아래 setup() 안에서 그대로 실행돼요. 게임 함수 연결은 addon-compat 모드가 해 줘요.

Object.assign(globalThis,{});

    const api = globalThis.__waywardPauseSettingsUiFactory.connect(wmlApi, {"id":"editor","label":"게임 에디터","bindings":{"2026-10-04":{"store":"ae","settingsStore":"At","React":"Z","jsx":"u","ActionButton":"Ze","ActionPanel":"aO","wife":"_","updateWife":"O","updateCharacter":"nn","log":"N","tick":"Jt","intoxLabel":"In","playerId":"fe","wifeId":"Re","locationOf":"$e","wifeLocation":"_e","playerLocation":"bt","moveOccupant":"Pt","patronScene":"Y","playerSexScene":"Le","setScene":"MV","patronSceneLocation":"tt","isSexualStage":"it","sceneDef":"ls","sceneOutfitState":"bx","garmentWorn":"vr","exposureSummary":"nf","patronWatchChoices":"Xae","patronChoice":"tNe","startPlayerSex":"_p","playerSexEvent":"Fl","ensureHusbandLed":"F8","addJoinedPatron":"nfe","joinSlots":"NH","registerAlert":"nr","queueAlert":"gn","drainAlerts":"gl","imagePrompt":"r8","imageKey":"s8","imageKeyOf":"n8","imageDescriptor":"o8","makeCustomer":"ff","addCustomer":"Ka","carryToBed":"RDe","talkToWife":"EF","actionTimes":"Oo","addFeeling":"we","addIdentityStrainFromPatronAct":"Kf","getCustomerLocation":"Yn","getEffectiveAttributes":"B","heroineConditioningMax":"QX","heroineDriveCalc":"si","moveWife":"pt","outfits":"fh","patronControlCustomerLocation":"ht","wifeById":"ul","wifePreview":"gue","reduceGameAction":"wT","brothelLog":"hs","decisionCategories":"bo","decisionResolve":"G$e","manaMax":"ms","minuteTick":"gp","recordPlayerTone":"Rt","wives":"mh","imageBackend":"Eh","brothelCustomerBusy":"XO","buildPatronMoveCandidates":"Phe","ejectCustomer":"Q5","endPatronInteraction":"jt","finishBackRoomService":"xF","forceAttemptChance":"Ppe","patronControlAcquaintanceStop":"_Ie","patronControlAttemptRoll":"Iy","patronControlBackRoomOpen":"Tr","patronControlBareForPushIn":"O5","patronControlChooseMove":"Yhe","patronControlCoercionEscape":"cpe","patronControlFavorTable":"h3","patronControlHerBackRoomProposal":"ipe","patronControlIntentEvolve":"z$","patronControlJoinerComfort":"wh","patronControlJoinerPushIn":"jIe","patronControlLineUp":"Gce","patronControlLungePlan":"Vre","patronControlMortifyingCheck":"b$","patronControlMoveCustomer":"Yt","patronControlNaturalEnd":"hI","patronControlPatronBackRoomProposal":"ape","patronControlPatronDrift":"Kbe","patronControlPlayerAway":"Tt","patronControlPositionWeights":"Fhe","patronControlPrivateSession":"wpe","patronControlPrivateSessionInfo":"a0","patronControlPushIn":"qce","patronControlPushInAnalReaction":"p6","patronControlPushInReaction":"R6","patronControlRelentChance":"Bpe","patronControlRequestTable":"E2e","patronControlSelfEscalationRoll":"Qre","patronControlShameStop":"dpe","patronControlSlotFree":"kS","patronControlSmallRequest":"R2e","patronControlStageLabel":"hG","patronControlStrengthContest":"Za","patronControlTacticTable":"lIe","patronControlUndressAttempt":"AIe","patronControlVerbalAsk":"$5e","patronControlWitnessesFor":"Ks","patronControlYieldRoll":"pB","playerActionPublicRefusal":"Rs","processPatronGroupJoin":"BS","processPatronGroupParticipants":"WS","processPatronInteractionTick":"R7","recordPatronMistreatment":"yl","recordPatronReach":"K5e","resolvePatronEscalation":"ub","resolvePatronForce":"gB","rotatePatronGroupAfterPrimary":"Gie","selectPatronTactic":"gIe","startPatronInteraction":"Go","transitionPatronStage":"Dn","evaluateIntimacy":"Pe","getMaritalDrift":"E4","getPatronAttachment":"Uo","nudgeRelationship":"Mo","recordAffection":"Iw","recordIntimateHistory":"Wd","recordPatronBoundary":"Qi","brothelRoomLabels":"bO","imageRoom":"lue","waitressAlternative":"u$","waitressAvailable":"Bd","waitressChooseOrder":"Jle","waitressConsume":"_w","waitressIncome":"Qt","waitressMissing":"CP","waitressPrice":"d$","waitressRecordDrink":"vw","waitressRecordWord":"VB","playerActionRespond":"P1e","playerActionTopicFatigue":"GY","playerActionTouchedOut":"er","promptJoin":"J6","promptRoomFilter":"$de","promptGenParams":"q6","outfitById":"Ot","saveSlotInfo":"Mb","listDayStarts":"ZI","saveDayStart":"UDe","wifePortraits":"z6e","resentment":"Ue","marriageBond":"VT","wakeUp":"FI","gameOverScreen":"HLe","allureScore":"Ir","normalVisitRoll":"nhe","lodgingChance":"IB","worldTick":"Dp","hotkeyAction":"sG","confirmAction":"N4e","busyTask":"X0","imageManifest":"Wb","imageServerUrl":"Cs","imageGenerate":"LPe","imageQueue":"g6e","imageBackendProbe":"JU","imageBackendForget":"UD","imagePackReset":"qD","imageAutoProbeAllowed":"KU"}, "2026-11-01": {"store":"ae","settingsStore":"at","React":"J","jsx":"u","ActionButton":"ht","ActionPanel":"SB","wife":"_","updateWife":"C","updateCharacter":"rn","log":"j","tick":"Jt","intoxLabel":"Sn","playerId":"ge","wifeId":"Ee","locationOf":"Ae","wifeLocation":"we","playerLocation":"vt","moveOccupant":"Ht","patronScene":"U","playerSexScene":"Be","setScene":"dK","patronSceneLocation":"Je","isSexualStage":"ct","sceneDef":"Sr","sceneOutfitState":"KMe","garmentWorn":"Zr","exposureSummary":"_g","patronWatchChoices":"Dbe","patronChoice":"uZ","startPlayerSex":"uh","playerSexEvent":"Kl","ensureHusbandLed":"ihe","addJoinedPatron":"C3e","joinSlots":"eU","registerAlert":"ar","queueAlert":"_n","drainAlerts":"oi","imagePrompt":"DR","imageKey":"zz","imageKeyOf":"CR","imageDescriptor":"RR","makeCustomer":"Ag","addCustomer":"Fi","carryToBed":"r5e","talkToWife":"gee","actionTimes":"tn","addFeeling":"Se","addIdentityStrainFromPatronAct":"Qf","getCustomerLocation":"Jn","getEffectiveAttributes":"B","heroineConditioningMax":"eue","heroineDriveCalc":"il","moveWife":"Nt","outfits":"Oi","patronControlCustomerLocation":"et","wifeById":"$m","wifePreview":"WL","reduceGameAction":"p5","brothelLog":"ds","decisionCategories":"Ho","decisionResolve":"DFe","manaMax":"Ys","minuteTick":"ry","recordPlayerTone":"qn","wives":"kr","imageBackend":"yh","brothelCustomerBusy":"z5","buildPatronMoveCandidates":"Zve","ejectCustomer":"HR","endPatronInteraction":"Rt","finishBackRoomService":"IV","forceAttemptChance":"iIe","patronControlAcquaintanceStop":"OUe","patronControlAttemptRoll":"g0","patronControlBackRoomOpen":"xS","patronControlBareForPushIn":"Q2","patronControlChooseMove":"sxe","patronControlCoercionEscape":"YOe","patronControlFavorTable":"wY","patronControlHerBackRoomProposal":"dGe","patronControlIntentEvolve":"AC","patronControlJoinerComfort":"ch","patronControlJoinerPushIn":"KUe","patronControlLineUp":"ADe","patronControlLungePlan":"s8e","patronControlMortifyingCheck":"b_","patronControlMoveCustomer":"lo","patronControlNaturalEnd":"GC","patronControlPatronBackRoomProposal":"cGe","patronControlPatronDrift":"NHe","patronControlPlayerAway":"yt","patronControlPositionWeights":"rxe","patronControlPrivateSession":"ZJ","patronControlPrivateSessionInfo":"Nh","patronControlPushIn":"jDe","patronControlPushInAnalReaction":"N9","patronControlPushInReaction":"wz","patronControlRelentChance":"mIe","patronControlRequestTable":"JGe","patronControlSelfEscalationRoll":"l8e","patronControlShameStop":"WOe","patronControlSlotFree":"G$","patronControlSmallRequest":"QGe","patronControlStageLabel":"Ote","patronControlStrengthContest":"el","patronControlTacticTable":"$Ue","patronControlUndressAttempt":"zUe","patronControlVerbalAsk":"A7e","patronControlWitnessesFor":"hs","patronControlYieldRoll":"Xq","playerActionPublicRefusal":"ir","processPatronGroupJoin":"gN","processPatronGroupParticipants":"XS","processPatronInteractionTick":"cZ","recordPatronMistreatment":"yl","recordPatronReach":"bPe","resolvePatronEscalation":"_b","resolvePatronForce":"Zq","rotatePatronGroupAfterPrimary":"jle","selectPatronTactic":"MUe","startPatronInteraction":"Xo","transitionPatronStage":"js","evaluateIntimacy":"We","getMaritalDrift":"i4","getPatronAttachment":"Uo","nudgeRelationship":"ko","recordAffection":"Iw","recordIntimateHistory":"Om","recordPatronBoundary":"tl","brothelRoomLabels":"LB","imageRoom":"ER","waitressAlternative":"JA","waitressAvailable":"zr","waitressChooseOrder":"uTe","waitressConsume":"v_","waitressIncome":"vo","waitressMissing":"K7","waitressPrice":"zv","waitressRecordDrink":"ox","waitressRecordWord":"vK","playerActionRespond":"IWe","playerActionTopicFatigue":"sX","playerActionTouchedOut":"er","promptJoin":"Yz","promptRoomFilter":"uMe","promptGenParams":"Dz","outfitById":"Ot","saveSlotInfo":"Bk","listDayStarts":"h$","saveDayStart":"y5e","wifePortraits":"Uit","resentment":"qe","marriageBond":"dA","wakeUp":"vD","gameOverScreen":"kat","allureScore":"aa","normalVisitRoll":"wTe","lodgingChance":"mK","worldTick":"py","hotkeyAction":"KG","confirmAction":"NYe","busyTask":"sv","imageManifest":"bh","imageServerUrl":"es","imageGenerate":"xst","imageQueue":"eit","imageBackendProbe":"FD","imageBackendForget":"iM","imagePackReset":"t_","imageAutoProbeAllowed":"eoe"}}});
    api.ui.menuSettings({label:"게임 에디터",legacyButton:"[data-wc2-customer-menu]",windowSelector:"#wc2-customer-editor",attributes:{"data-wc2-customer-menu":"1"},onClick:()=>globalThis.__waywardEditor?.openSettings?.()});
    try { api.ui.pauseSettings?.({label:{ko:'게임 에디터',en:'Editor settings'},attributes:{'data-wc2-customer-menu':'1'},onClick:()=>globalThis.__waywardEditor?.openSettings?.()}); } catch (error) { console.warn("[editor] 공통 설정 메뉴 등록 실패: 기존 직접 삽입 방식으로 계속합니다.", error); }

    // ---- 현재 게임에 맞춘 보정 ----
    // What the 9-30 mod manager changed in the game's customer flow for the editor ("방문 · 뒷방 · 숙박 설정"),
    // redone as WML hooks. The editor writes its options into __WAYWARD_ADDON_API__.customerFlow.options.
    const LG = globalThis.__WML_LEGACY__;
    const raw = LG.name, G = LG.get;
    function wwCustomerOption(key, fallback) {
      const v = globalThis.__WAYWARD_ADDON_API__?.customerFlow?.options?.[key];
      return v ?? fallback;
    }
    function wwCustomerCount(state) { return state.customers.filter(customer => customer.status !== 'gone').length; }
    function wwCustomerHasSpace(state, size) { return wwCustomerCount(state) + size <= wwCustomerOption('maxCustomers', 8); }
    function wwCustomerArrivalAllowed(state) { return state.slot % wwCustomerOption('arrivalInterval', 1) === 0 && wwCustomerHasSpace(state, 1); }
    const liveState = () => { try { return G('re').getState().state; } catch { return null; } };
    
    // ordinary arrivals: the editor's cap, interval and arrival multiplier (the game caps at 8)
    api.hook(raw('nae'), {
      around(next, slot, service, count, renown = 50, scale = 1) {
        const state = liveState();
        if (state && !wwCustomerArrivalAllowed(state)) return false;
        const n = Math.max(Number(count) || 0, state ? wwCustomerCount(state) : 0);
        if (n >= wwCustomerOption('maxCustomers', 8)) return false;
        // Keep the editor's cap above, and let the shared arrival chain apply
        // construction capacity, festival multipliers and native probability once.
        return next(slot, service, 0, renown, scale * wwCustomerOption('arrivalMultiplier', 1));
      },
    });
    // men who come because of a bill or a hail: same gate and multiplier
    api.hook(raw('vpe'), {
      around(next, state, chance) {
        if (!wwCustomerArrivalAllowed(state)) return null;
        return next(state, chance * wwCustomerOption('arrivalMultiplier', 1));
      },
    });
    
    // custom patrons from the editor ("사용자 손님") and per-name overrides
    function wwCustomerApplyProfile(generated, state, usedNames, reason) {
      const roster = state?.editorCustomers;
      if (!roster || !generated) return generated;
      const ordinaryNewArrival = reason == null && Object.hasOwn(generated, 'drawnBy') &&
        !(state.patronRecords ?? []).some(record => record.name === generated.name);
      const custom = ordinaryNewArrival && Array.isArray(roster?.customs) ? roster.customs.filter(profile =>
        profile && typeof profile.name === 'string' && !usedNames.includes(profile.name) &&
        !(state.patronRecords ?? []).some(record => record.name === profile.name && record.turnedOut?.count > 0) &&
        Number(profile.weight) > 0) : [];
      let profile = null;
      if (custom.length && Math.random() * 100 < Math.max(0, Math.min(100, Number(roster.share) || 0))) {
        const total = custom.reduce((sum, entry) => sum + Math.max(0, Number(entry.weight) || 0), 0);
        let roll = Math.random() * total;
        for (const entry of custom) { roll -= Math.max(0, Number(entry.weight) || 0); if (roll < 0) { profile = entry; break; } }
        profile ??= custom[custom.length - 1];
      }
      if (!profile && roster?.overrides && Object.hasOwn(roster.overrides, generated.name)) profile = roster.overrides[generated.name];
      if (!profile) return generated;
      const min = Math.max(0, Math.min(500, Math.round(Number(profile.walletMin) || 0)));
      const max = Math.max(min, Math.min(500, Math.round(Number(profile.walletMax) || min)));
      return { ...generated, name: profile.name || generated.name,
        patronType: profile.patronType || generated.patronType,
        intent: profile.intent || generated.intent,
        tacticStyle: profile.tacticStyle || generated.tacticStyle,
        boldness: Number.isFinite(profile.boldness) ? profile.boldness : generated.boldness,
        charm: Number.isFinite(profile.charm) ? profile.charm : generated.charm,
        chemistry: Number.isFinite(profile.chemistry) ? profile.chemistry : generated.chemistry,
        walletGold: min + Math.floor(Math.random() * (max - min + 1)),
        attributes: { ...generated.attributes, ...profile.attributes },
        personaTags: Array.isArray(profile.personaTags) ? [...profile.personaTags] : generated.personaTags };
    }
    api.hook(raw('Pm'), {
      after(generated, [slot, usedNames = [], records, reputation, state, reason]) {
        return state ? wwCustomerApplyProfile(generated, state, usedNames, reason) : generated;
      },
    });
    
    // lodgers: room-booking chance x the editor's multiplier, and only when there is room for one more
    api.hook(raw('L6'), {
      after(chance) {
        const state = liveState();
        if (state && !wwCustomerHasSpace(state, 1)) return 0;
        return Math.min(1, chance * wwCustomerOption('lodgingMultiplier', 1));
      },
    });
    
    // back-room parties and long stays: weight x multiplier, and the whole party must fit
    const wwCustomerPartySizes = { town_meeting: 4, merchants_visit: 5, soldiers_billet: 6, noble_visit: 4, smuggler_negotiation: 4, quiet_pair: 2 };
    for (const scenario of G('MY') || []) {
      const size = wwCustomerPartySizes[scenario.id];
      const lodging = scenario.id === 'long_term_renter';
      if (!size && !lodging) continue;
      const weight = scenario.weight;
      const eligible = scenario.eligible;
      Object.defineProperty(scenario, 'weight', { configurable: true, get: () => weight * wwCustomerOption(lodging ? 'lodgingMultiplier' : 'backroomMultiplier', 1) });
      scenario.eligible = function (state) { return wwCustomerHasSpace(state, size || 1) && eligible.call(this, state); };
    }
    api.hook(raw('LIe'), {
      around(next, state, choice) {
        const match = /^scenario_(town_meeting|merchants_visit|soldiers_billet|noble_visit|smuggler_negotiation|quiet_pair)_(agree|charge|welcome|take)$/.exec(choice);
        const size = match ? wwCustomerPartySizes[match[1]] : choice === 'scenario_long_term_renter_accept' ? 1 : 0;
        if (size && !wwCustomerHasSpace(state, size)) return G('j')(state, '손님 정원이 부족합니다. 방문 설정의 한도를 늘리거나 이용 요청을 거절해 주세요.');
        return next(state, choice);
      },
    });
    // ---- 원본 애드온 ----
/* Wayward 2026-09-30 - Game Editor Addon
 * Install with Install_Addons.cmd. The installer creates a separate Addons HTML.
 */
(()=>{
  'use strict';
  if(globalThis.__WAYWARD_EDITOR_ADDON_LOADED__)return;

  const OPTIONS_KEY='wayward-customer-edit-options-v1';
  const FLOW_FIELDS={
    arrivalInterval:{label:'방문 판정 간격 (게임 내 분)',hint:'일반 손님 방문을 몇 분마다 판정할지 정합니다',min:1,max:120,step:1,value:1},
    arrivalMultiplier:{label:'일반 손님 방문 확률 배율',hint:'기본 방문 확률에 곱합니다. 0은 신규 일반 방문 중지',min:0,max:20,step:.1,value:1},
    maxCustomers:{label:'최대 동시 방문 손님 수',hint:'새 손님과 단체가 들어올 때 적용하는 수용 인원',min:1,max:100,step:1,value:8},
    backroomMultiplier:{label:'뒷방 단체 이용 빈도 배율',hint:'새 단체 이용 요청의 발생 빈도에 곱합니다',min:0,max:20,step:.1,value:1},
    lodgingMultiplier:{label:'숙박 예약 확률 배율',hint:'빈 객실 예약과 장기 숙박 제안 빈도에 곱합니다',min:0,max:20,step:.1,value:1}
  };
  const DEFAULT_OPTIONS={walletMultiplier:1,infiniteMana:false,...Object.fromEntries(Object.entries(FLOW_FIELDS).map(([key,field])=>[key,field.value]))};
  const PATRON_TYPES={
    regular:'일반 손님',
    charmer:'매력적인 말재주꾼',
    drunk_bold:'술 취한 호걸',
    rogue:'건달',
    nobleman:'귀족',
    wealthy_pervert:'부유한 호색가'
  };
  const INTENTS={
    drink_only:'음주 위주',
    talk_only:'대화 위주',
    flirt_curious:'가벼운 유혹',
    interested:'적극적 관심',
    predatory:'강압적 접근'
  };
  const TACTICS={
    warm_builder:'친밀감 쌓기',
    drink_pusher:'술 권하기',
    smooth_charmer:'능숙한 유혹',
    lap_grabber:'신체 접촉',
    transactional:'거래 제안'
  };
  const PERSONA_TAGS={
    local_farmer:'지역 농부',
    journeyman_artisan:'숙련 장인',
    young_bachelor:'젊은 독신자',
    recently_widowed:'최근 사별함',
    married_man_alone:'혼자 온 기혼자',
    town_drunk:'마을의 술꾼',
    ex_soldier:'전직 군인',
    traveling_merchant:'여행 상인',
    noble_slumming:'신분을 숨긴 귀족',
    traveling_bard:'여행 음유시인',
    clergy_off_duty:'비번 성직자'
  };
  const ATTRIBUTES={
    strength:'힘',
    deftness:'손재주',
    vigor:'활력',
    wit:'재치',
    composure:'침착성',
    charm:'매력',
    honesty:'정직성',
    loyalty:'충실성',
    openness:'개방성',
    confidence:'자신감'
  };
  const PERSONALITY={dominance:'지배성',charisma:'카리스마',cunning:'교활함'};
  const AFFINITIES={romantic:'로맨스',oral:'구강',vaginal:'성관계',anal:'항문',exhibition:'노출',submission:'복종',domination:'지배',prostitution:'금전 관계',drinking:'음주',taboo:'금기'};
  const WIFE_TRAITS={
    true_prude:'극도로 보수적',self_protective:'자기보호적',latent_dominant:'지배 성향',romance_starved:'애정에 굶주림',likes_cheating:'외도 성향',cold_pragmatist:'냉정한 실리주의자',breaks_under_pressure:'압박에 약함',guilt_eroticizer:'죄책감에서 흥분',latent_exhibitionist:'노출 성향',public_thrill_seeker:'공개 스릴 추구',latent_submissive:'복종 성향',easily_intoxicated:'술에 쉽게 취함',enjoys_making_him_jealous:'질투 유발을 즐김',wants_to_be_corrupted:'타락 욕구',latent_masochist:'피학 성향',latent_voyeur:'관음 성향',curious_about_women:'여성에게 호기심',jealousy_kindled:'질투로 자극받음',wary_of_drinks:'술을 경계함',latent_self_pleasure:'숨겨진 자기쾌락 성향'
  };
  const HUSBAND_FEELINGS={devotion:'헌신',tenderness:'다정함',longing:'갈망',desire:'욕망',pushed_away:'마음을 닫음',contempt:'경멸·원망',anger:'분노',disgust:'혐오',shame:'수치심',guilt:'죄책감',regret:'후회',sadness:'슬픔',humiliation:'굴욕감'};
  const SPELL_LABELS={assay_purse:'주머니 감정',strengthen:'강화',weaken:'약화',sway_affinity:'마음 흔들기',kindle_quell:'감정 불붙이기/가라앉히기',heartsight:'마음 읽기'};
  const ALCHEMY_EFFECTS={
    nettle:['restore_energy','sap_charm','clear_fatigue','mend'],wild_garlic:['sober','nausea','fortify_vigor','quell'],willow_bark:['ease','mend','clear_fatigue','sap_deftness'],comfrey:['mend','ease','restore_energy','weary'],
    dandelion:['sober','restore_energy','nausea','fortify_wit'],plantain:['mend','ease','sober','drain_energy'],yarrow:['mend','sober','fortify_composure','weary'],clover:['restore_energy','kindle','nausea','fortify_charm'],
    hawthorn:['fortify_vigor','quell','mend','weary'],elderberry:['restore_energy','befuddle','fortify_charm','nausea'],mint:['sober','clear_fatigue','quell','ease'],thyme:['fortify_composure','restore_energy','sober','sap_charm'],
    honey:['restore_energy','fortify_charm','drowse','kindle'],bitterroot:['sober','nausea','restore_mana','fortify_wit'],chamomile:['drowse','ease','quell','sap_deftness'],mugwort:['drowse','restore_mana','nausea','fortify_wit'],
    valerian:['drowse','quell','ease','sap_wit'],heartsease:['embolden','fortify_charm','kindle','weary'],honeycap:['kindle','fortify_charm','befuddle','fortify_vigor'],foxglove:['fortify_vigor','nausea','drowse','sap_composure'],
    fly_agaric:['befuddle','restore_mana','nausea','sap_composure'],oak_gall:['fortify_composure','sap_charm','mend','sober'],birch_sap:['restore_energy','clear_fatigue','fortify_deftness','befuddle'],pine_resin:['mend','fortify_strength','weary','sap_deftness'],
    harts_tongue:['restore_mana','fortify_wit','clear_fatigue','candor'],marsh_mallow:['ease','mend','drowse','restore_energy'],sundew:['fortify_deftness','kindle','drain_energy','sober'],bog_myrtle:['sober','quell','clear_fatigue','sap_wit'],
    moonpetal:['open','restore_mana','kindle','drowse'],wolfsbane:['sap_vigor','fortify_strength','drain_energy','cow'],nightshade:['drowse','befuddle','cow','sap_vigor'],bloodcap:['embolden','fortify_strength','drain_energy','open'],
    ghost_orchid:['candor','quell','restore_mana','weary'],tallow:['mend','fortify_vigor','weary','drain_energy'],sinew:['fortify_strength','fortify_deftness','weary','sap_charm'],antler:['fortify_vigor','fortify_strength','fortify_composure','drain_energy'],
    tusk:['fortify_strength','fortify_composure','sap_charm','kindle'],musk:['kindle','fortify_charm','befuddle','fortify_vigor'],marrow:['restore_energy','mend','fortify_vigor','weary'],wine:['befuddle','kindle','restore_energy','drowse']
  };
  const EDITOR_TABS={tavern:"술집/당신",wife:"그녀",staff:'동료/직원',customers:'손님',magic:'마법/채취/조제'};
  const ATTRIBUTE_HINTS={strength:'힘을 쓰는 행동 판정',deftness:'손놀림과 정교한 작업',vigor:'체력과 버티는 힘',wit:'판단력과 눈치',composure:'압박에 대한 침착함',charm:'대인 매력',honesty:'정직함과 비밀 관련 성향',openness:'새 경험에 대한 개방성',confidence:'자기주장과 자신감'};
  const PARAM_HINTS={
    'economy.gold':'현재 사용할 수 있는 돈','economy.debt':'갚아야 할 채무','economy.weeklyRent':'매주 납부할 임대료',
    'supplies.food':'요리에 쓰는 식재료 재고','supplies.beer':'판매할 맥주 재고','supplies.wine':'판매할 와인 재고',
    readyFood:'즉시 판매할 수 있는 음식','tavernCleanliness':'술집의 현재 청결도','tavern.quality':'시설의 품질 수치',
    'tavernReputation.service':'접객 서비스 평가','tavernReputation.renown':'술집의 일반적인 명성','tavernReputation.notoriety':'추문과 악명',
    'player.personality.dominance':"당신의 지배적인 태도",'player.personality.charisma':"당신의 설득력과 카리스마",'player.personality.cunning':"당신의 계략과 속임수 성향",
    'player.fatigue':"당신에게 쌓인 피로",'player.magic.understanding':'마법 이론의 이해도','player.magic.attunement':'마법과의 동조율. 최대 마나를 높입니다','player.magic.mana.current':'지금 사용할 수 있는 마나',
    'player.skills.cooking':'요리의 품질과 음식을 태울 확률에 쓰이는 숙련도','player.skills.hunting':'사냥감 발견과 포획 판정에 쓰이는 숙련도','player.skills.foraging':'채취 성공률과 알아볼 수 있는 식물 종류를 정하는 숙련도','player.skills.brewing':'조제 성공률과 물약 품질에 쓰이는 숙련도',
    libido:"그녀의 성욕 강도",volatility:"그녀의 감정 변동성",'relationship.trust':"그녀가 당신을 신뢰하는 정도",
    'selfConcept.openness':"그녀가 스스로 인식하는 개방성",'selfConcept.confidence':"그녀가 스스로 인식하는 자신감"
  };
  const CUSTOMER_HINTS={walletGold:'현재 손님에게 남은 소지금',walletMin:'다음 방문 때 생성되는 지갑의 최소 금액',walletMax:'다음 방문 때 생성되는 지갑의 최대 금액',weight:'사용자 손님끼리 뽑힐 때의 상대 가중치',boldness:'적극적인 접근 성향',charm:'처음 만났을 때의 매력 수치',chemistry:"그녀와의 초기 궁합",platonic:"그녀와 손님의 친근감",romantic:"그녀와 손님의 연애 감정",sexual:"그녀와 손님의 성적 끌림"};
  const TRAIT_HINTS={true_prude:'노출과 대담한 행동에 강한 저항',self_protective:'위험한 상황에서 자신을 보호함',latent_dominant:'주도권을 잡는 행동 선호',romance_starved:'정서적 친밀감에 크게 반응',likes_cheating:'배우자 밖 관계에 끌림',cold_pragmatist:'감정보다 현실적 이득 중시',breaks_under_pressure:'지속적인 압박에 흔들림',guilt_eroticizer:'죄책감과 수치심에 자극받음',latent_exhibitionist:'남의 시선과 노출에 반응',public_thrill_seeker:'들킬 위험의 스릴을 선호',latent_submissive:'상대에게 주도권을 넘기기 쉬움',easily_intoxicated:'술에 따른 반응 변화가 큼',enjoys_making_him_jealous:"당신의 질투를 유도하는 상황 선호",wants_to_be_corrupted:'선을 넘고 변하는 과정에 끌림',latent_masochist:'거친 자극과 굴욕에 반응',latent_voyeur:'지켜보는 상황에 반응',curious_about_women:'여성과의 관계에 호기심',jealousy_kindled:'질투와 경쟁에서 자극받음',wary_of_drinks:'술 권유를 더 경계',latent_self_pleasure:'혼자 욕구를 해소하는 상황에 반응'};
  const TYPE_KEYS=new Set(Object.keys(PATRON_TYPES));
  const INTENT_KEYS=new Set(Object.keys(INTENTS));
  const TACTIC_KEYS=new Set(Object.keys(TACTICS));
  const TAG_KEYS=new Set(Object.keys(PERSONA_TAGS));

  let api=null;
  let unsubscribe=null;
  let uiFrame=0;
  let selectedKey='';
  let filterMode='all';
  let searchText='';
  let activeTab='tavern';
  let lastBackup=null;
  let editorDraft=null;
  let internalWrite=false;
  let dispatching=false;
  let options=loadOptions();
  function clampNumber(value,min,max,fallback){
    const number=Number(value);
    return Number.isFinite(number)?Math.max(min,Math.min(max,number)):fallback;
  }

  function clampInteger(value,min=0,max=100,fallback=0){
    return Math.round(clampNumber(value,min,max,fallback));
  }

  function normalizeMultiplier(value){
    return Math.round(clampNumber(value,.1,10,1)*10)/10;
  }

  function loadOptions(){
    try{
      const raw=JSON.parse(localStorage.getItem(OPTIONS_KEY)||'{}');
      return normalizeOptions(raw);
    }catch(_){return{...DEFAULT_OPTIONS}}
  }

  function normalizeOptions(raw){
    const next={walletMultiplier:normalizeMultiplier(raw?.walletMultiplier),infiniteMana:raw?.infiniteMana===true};
    for(const[key,field]of Object.entries(FLOW_FIELDS)){
      const value=raw?.[key];
      next[key]=value==null||value===''?field.value:Math.round(clampNumber(value,field.min,field.max,field.value)/field.step)*field.step;
      next[key]=Number(next[key].toFixed(1));
    }
    return next;
  }

  function syncFlowOptions(){
    if(api?.customerFlow?.version!==1)return false;
    api.customerFlow.options={...options};
    return true;
  }

  function setFlowOptions(patch){
    if(api?.customerFlow?.version!==1){
      showToast('설치기를 다시 실행한 뒤 새 Addons HTML을 열어 주세요.');
      return false;
    }
    options=normalizeOptions({...options,...patch,walletMultiplier:options.walletMultiplier});
    syncFlowOptions();
    saveOptions();
    renderFlowSettings();
    showToast('방문·뒷방·숙박 설정을 적용했습니다.');
    return{...options};
  }

  function saveOptions(){
    try{localStorage.setItem(OPTIONS_KEY,JSON.stringify(options))}catch(_){}
  }

  function currentState(){
    try{return api?.ue?.getState?.().state??null}catch(_){return null}
  }

  function visibleState(){return editorDraft?.state??currentState()}
  function visibleOptions(){return editorDraft?.options??options}
  function staffApis(){let companions=null;try{companions=globalThis.WML?.use?.('companions')??null}catch{}return{companions,brothel:globalThis.__waywardBrothelPublic??null}}
  function readStaffDraft(state){const apis=staffApis();return{companions:apis.companions?.editorRead?.(state)??null,brothel:apis.brothel?.editorRead?.()??null,brothelPatches:[]}}
  function newEditorDraft(){const state=currentState();return{state,options:{...options},customerPatches:new Map(),staff:readStaffDraft(state),stale:false}}
  function beginEditSession(){editorDraft=newEditorDraft();return !!editorDraft.state}
  function stageCustomerPatch(key,patch){
    if(!editorDraft||!findEntry(key,editorDraft.state))return false;
    editorDraft.customerPatches.set(key,patch);return true;
  }

  function commitState(next,remember=true){
    if(!next||!api?.ue?.setState)return false;
    if(remember)lastBackup={state:currentState(),options:{...options}};
    internalWrite=true;
    try{api.ue.setState(root=>({...root,state:next}))}
    finally{internalWrite=false}
    return true;
  }

  function undoEditorChange(){
    if(!lastBackup)return false;
    const previous=lastBackup;
    if(previous.brothel){const restored=previous.brothel.api?.editorRestore?.(previous.brothel.snapshot,previous.brothel.afterRevision);if(!restored){showToast('창관 직원 자료가 적용 뒤 바뀌어 되돌릴 수 없습니다.');return false}}
    lastBackup=null;
    options={...previous.options};
    saveOptions();
    syncFlowOptions();
    internalWrite=true;
    try{api.ue.setState(root=>({...root,state:previous.state}))}
    finally{internalWrite=false}
    if(editorDraft){
      const editor=document.querySelector('#wc2-customer-editor [data-wce-detail]');
      if(editor)editor.dataset.customerDirty='0';
      editorDraft=newEditorDraft();
      invalidateRenderedPages();
      if(document.getElementById('wc2-customer-editor')?.querySelector('[data-wce-multiplier-number]')){renderSettings();renderFlowSettings()}
    }
    renderActiveTab();
    showToast('직전 게임 상태 수정을 되돌렸습니다.');
    return true;
  }

  function scaleNewCustomers(root,previous){
    if(!dispatching||internalWrite||options.walletMultiplier===1)return;
    const state=root?.state;
    const before=previous?.state;
    if(!Array.isArray(state?.customers)||!Array.isArray(before?.customers))return;
    const oldIds=new Set(before.customers.map(customer=>customer.id));
    let changed=false;
    const customers=state.customers.map(customer=>{
      if(oldIds.has(customer.id)||!Number.isFinite(Number(customer.walletGold)))return customer;
      changed=true;
      return{...customer,walletGold:clampInteger(Number(customer.walletGold)*options.walletMultiplier,0,999999,0)};
    });
    if(changed)commitState({...state,customers},false);
  }

  function installCustomerArrivalHook(){
    const store=api.ue;
    const baseDispatch=store.getState().dispatch;
    if(typeof baseDispatch!=='function'||baseDispatch.__wc2CustomerEditHook)return;
    const wrapped=function(...args){
      dispatching=true;
      try{return baseDispatch.apply(this,args)}
      finally{dispatching=false}
    };
    Object.defineProperty(wrapped,'__wc2CustomerEditHook',{value:true});
    store.setState({dispatch:wrapped});
    store.subscribe(scaleNewCustomers);
  }

  function setWalletMultiplier(value){
    const nextMultiplier=normalizeMultiplier(value);
    const previousOptions={...options},previousMultiplier=options.walletMultiplier;
    options={...options,walletMultiplier:nextMultiplier};
    saveOptions();

    const state=currentState();
    if(state&&previousMultiplier!==nextMultiplier&&Array.isArray(state.customers)){
      const ratio=nextMultiplier/previousMultiplier;
      const customers=state.customers.map(customer=>{
        if(!Number.isFinite(Number(customer.walletGold)))return customer;
        return{...customer,walletGold:clampInteger(Number(customer.walletGold)*ratio,0,999999,0)};
      });
      commitState({...state,customers});
      lastBackup.options=previousOptions;
    }
    renderSettings();
    showToast(`손님 소지금 배율: ${nextMultiplier.toFixed(1)}배`);
    return nextMultiplier;
  }

  function getEntries(state=visibleState()){
    if(!state)return[];
    const customers=Array.isArray(state.customers)?state.customers:[];
    const records=Array.isArray(state.patronRecords)?state.patronRecords:[];
    const currentNames=new Set(customers.map(customer=>String(customer.name||'')));
    const entries=customers.map(customer=>({
      key:`current:${customer.id}`,
      kind:'current',
      item:customer,
      record:records.find(record=>record.name===customer.name)||null
    }));
    records.forEach((record,index)=>{
      if(!currentNames.has(String(record.name||''))){
        entries.push({key:`history:${index}`,kind:'history',item:record,record});
      }
    });
    (state.editorCustomers?.customs??[]).forEach((profile,index)=>{
      entries.push({key:`custom:${index}`,kind:'custom',item:profile,record:null});
    });
    return entries;
  }

  function editorRoster(state=visibleState()){
    const raw=state?.editorCustomers??{};
    return{...raw,share:clampInteger(raw.share,0,100,20),customs:Array.isArray(raw.customs)?raw.customs:[],overrides:raw.overrides??{},baselines:raw.baselines??{}};
  }

  function stateWithNewCustomCustomer(state){
    if(!state)return null;
    const roster=editorRoster(state);
    if(roster.customs.length>=50){showToast('사용자 손님은 최대 50명입니다.');return null}
    const used=new Set([...state.customers??[],...state.patronRecords??[],...roster.customs].map(item=>String(item.name||'').toLocaleLowerCase('ko-KR')));
    let name='새 손님',number=2;
    while(used.has(name.toLocaleLowerCase('ko-KR')))name=`새 손님 ${number++}`;
    const profile={name,patronType:'regular',intent:'talk_only',tacticStyle:'warm_builder',boldness:50,charm:50,chemistry:50,personaTags:[],attributes:Object.fromEntries(Object.keys(ATTRIBUTES).map(key=>[key,50])),walletMin:20,walletMax:50,weight:1};
    return{...state,editorCustomers:{...roster,customs:[...roster.customs,profile]}};
  }

  function addCustomCustomer(){
    const state=currentState(),next=stateWithNewCustomCustomer(state);if(!next)return false;
    const index=next.editorCustomers.customs.length-1;
    commitState(next);
    selectedKey=`custom:${index}`;filterMode='custom';renderSettings();
    showToast('사용자 손님을 추가했습니다. 정보를 저장하면 다음 방문부터 등장합니다.');
    return true;
  }

  function stageAddCustomCustomer(){
    if(!editorDraft)return false;
    rememberCustomerEditor();
    const next=stateWithNewCustomCustomer(editorDraft.state);if(!next)return false;
    editorDraft.state=next;
    selectedKey=`custom:${next.editorCustomers.customs.length-1}`;filterMode='custom';
    renderSettings();showToast('사용자 손님을 추가했습니다. 모든 변경 적용을 누르면 저장됩니다.');return true;
  }

  function removeCustomCustomer(index){
    const state=currentState(),roster=editorRoster(state);
    if(!Number.isInteger(index)||index<0||index>=roster.customs.length)return false;
    commitState({...state,editorCustomers:{...roster,customs:roster.customs.filter((_,i)=>i!==index)}});
    selectedKey='';renderSettings();showToast('사용자 손님을 삭제했습니다. 기존 방문 기록은 유지됩니다.');return true;
  }

  function stageRemoveCustomCustomer(index){
    if(!editorDraft)return false;
    rememberCustomerEditor();
    const state=editorDraft.state,roster=editorRoster(state);
    if(!Number.isInteger(index)||index<0||index>=roster.customs.length)return false;
    editorDraft.state={...state,editorCustomers:{...roster,customs:roster.customs.filter((_,i)=>i!==index)}};
    const patches=new Map();
    for(const[key,patch]of editorDraft.customerPatches){
      const match=/^custom:(\d+)$/.exec(key);
      if(!match){patches.set(key,patch);continue}
      const oldIndex=Number(match[1]);
      if(oldIndex!==index)patches.set(`custom:${oldIndex>index?oldIndex-1:oldIndex}`,patch);
    }
    editorDraft.customerPatches=patches;
    const editor=document.querySelector('#wc2-customer-editor [data-wce-detail]');
    if(editor)editor.dataset.customerKey='';
    selectedKey='';renderSettings();showToast('사용자 손님 삭제를 기록했습니다. 모든 변경 적용을 누르면 저장됩니다.');return true;
  }

  function setCustomShare(value){
    const state=currentState();if(!state)return false;
    const share=clampInteger(value,0,100,20),roster=editorRoster(state);
    commitState({...state,editorCustomers:{...roster,share}});
    renderSettings();showToast(`사용자 손님 등장 비중: ${share}%`);return share;
  }

  function findEntry(key,state=visibleState()){
    return getEntries(state).find(entry=>entry.key===key)||null;
  }

  function sanitizePatch(raw,allowWallet,current){
    const patch={};
    patch.patronType=TYPE_KEYS.has(raw?.patronType)?raw.patronType:(TYPE_KEYS.has(current?.patronType)?current.patronType:'regular');
    patch.intent=INTENT_KEYS.has(raw?.intent)?raw.intent:(INTENT_KEYS.has(current?.intent)?current.intent:'talk_only');
    patch.tacticStyle=TACTIC_KEYS.has(raw?.tacticStyle)?raw.tacticStyle:(TACTIC_KEYS.has(current?.tacticStyle)?current.tacticStyle:'warm_builder');
    patch.boldness=clampInteger(raw?.boldness,0,100,current?.boldness??0);
    patch.charm=clampInteger(raw?.charm,0,100,current?.charm??0);
    patch.chemistry=clampInteger(raw?.chemistry,0,100,current?.chemistry??0);
    patch.personaTags=Array.isArray(raw?.personaTags)?[...new Set(raw.personaTags.filter(tag=>TAG_KEYS.has(tag)))]:[...(current?.personaTags??[])].filter(tag=>TAG_KEYS.has(tag));
    patch.attributes={};
    for(const key of Object.keys(ATTRIBUTES)){
      patch.attributes[key]=clampInteger(raw?.attributes?.[key],0,100,current?.attributes?.[key]??50);
    }
    if(allowWallet)patch.walletGold=clampInteger(raw?.walletGold,0,999999,current?.walletGold??0);
    return patch;
  }

  function applyPatch(item,patch,allowWallet){
    const next={
      ...item,
      patronType:patch.patronType,
      intent:patch.intent,
      tacticStyle:patch.tacticStyle,
      boldness:patch.boldness,
      charm:patch.charm,
      chemistry:patch.chemistry,
      personaTags:[...patch.personaTags],
      attributes:{...(item.attributes??{}),...patch.attributes}
    };
    if(allowWallet)next.walletGold=patch.walletGold;
    return next;
  }

  function customerStateWithPatch(state,key,rawPatch){
    const entry=findEntry(key,state);
    if(!state||!entry)return null;
    const current=entry.kind==='current';
    const patch=sanitizePatch(rawPatch,current,entry.item);
    if(current&&rawPatch.__walletGoldTouched===false)patch.walletGold=entry.item.walletGold;
    if(entry.kind==='custom'){
      const index=Number(key.slice('custom:'.length)),roster=editorRoster(state),name=String(rawPatch.name??'').trim();
      const existing=[...state.customers??[],...state.patronRecords??[],...roster.customs.filter((_,i)=>i!==index)].some(item=>
        String(item.name||'').toLocaleLowerCase('ko-KR')===name.toLocaleLowerCase('ko-KR') && name!==entry.item.name);
      if(!name||name.length>24||/[\x00-\x1f\x7f]/.test(name)||existing){showToast('이름은 중복 없이 1~24자로 입력해 주세요.');return null}
      const walletMin=clampInteger(rawPatch.walletMin,0,500,entry.item.walletMin??20),walletMax=clampInteger(rawPatch.walletMax,0,500,entry.item.walletMax??50);
      if(walletMin>walletMax){showToast('초기 지갑 최소값이 최대값보다 큽니다.');return null}
      const profile={...applyPatch(entry.item,patch,false),name,walletMin,walletMax,weight:clampInteger(rawPatch.weight,0,10,entry.item.weight??1)};
      return{...state,editorCustomers:{...roster,customs:roster.customs.map((item,i)=>i===index?profile:item)}};
    }
    const relation={};
    for(const field of ['platonic','romantic','sexual'])if(rawPatch[field]!=null)relation[field]=clampInteger(rawPatch[field],-100,100,entry.record?.[field]??0);
    let customers=state.customers??[];
    let patronRecords=state.patronRecords??[];

    if(current){
      customers=customers.map(customer=>customer.id===entry.item.id?applyPatch(customer,patch,true):customer);
      patronRecords=patronRecords.map(record=>record.name===entry.item.name?{...applyPatch(record,patch,false),...relation}:record);
    }else{
      const recordIndex=Number(key.slice('history:'.length));
      patronRecords=patronRecords.map((record,index)=>index===recordIndex?{...applyPatch(record,patch,false),...relation}:record);
    }
    const roster=editorRoster(state);
    const walletMin=clampInteger(rawPatch.walletMin,0,500,roster.overrides[entry.item.name]?.walletMin??20);
    const walletMax=clampInteger(rawPatch.walletMax,0,500,roster.overrides[entry.item.name]?.walletMax??50);
    if(walletMin>walletMax){showToast('초기 지갑 최소값이 최대값보다 큽니다.');return null}
    const override={...patch,name:entry.item.name,walletMin,walletMax};
    const baseline=entry.record??null;
    const baselines=baseline&&!Object.hasOwn(roster.baselines,entry.item.name)?{...roster.baselines,[entry.item.name]:baseline}:roster.baselines;
    return{...state,customers,patronRecords,editorCustomers:{...roster,overrides:{...roster.overrides,[entry.item.name]:override},baselines}};
  }

  function saveCustomer(key,rawPatch){
    const state=currentState(),next=customerStateWithPatch(state,key,rawPatch);
    if(!next)return false;
    commitState(next);
    const entry=findEntry(key,next);
    showToast(`${entry.item.name||'손님'}의 설정을 저장했습니다.`);
    renderSettings();
    return true;
  }

  function customerStateWithoutOverride(state,key){
    const entry=findEntry(key,state);
    if(!state||!entry||entry.kind==='custom')return null;
    const roster=editorRoster(state),name=entry.item.name;
    const overrides={...roster.overrides};delete overrides[name];
    const baseline=roster.baselines[name],baselines={...roster.baselines};delete baselines[name];
    const patronRecords=baseline?(state.patronRecords??[]).map(record=>record.name===name?baseline:record):state.patronRecords;
    return{...state,patronRecords,editorCustomers:{...roster,overrides,baselines}};
  }

  function resetCustomerOverride(key){
    const state=currentState(),next=customerStateWithoutOverride(state,key);
    if(!next)return false;
    commitState(next);
    const name=findEntry(key,state).item.name;
    renderSettings();showToast(`${name}의 다음 방문 편집값을 초기화했습니다. 현재 손님은 유지됩니다.`);return true;
  }

  function stageResetCustomerOverride(key){
    if(!editorDraft)return false;
    rememberCustomerEditor();
    const next=customerStateWithoutOverride(editorDraft.state,key);
    if(!next)return false;
    editorDraft.state=next;
    editorDraft.customerPatches.delete(key);
    const editor=document.querySelector('#wc2-customer-editor [data-wce-detail]');
    if(editor)editor.dataset.customerKey='';
    renderSettings();showToast('손님 편집값 초기화를 기록했습니다. 모든 변경 적용을 누르면 저장됩니다.');return true;
  }

  function showToast(message){
    if(typeof document==='undefined')return;
    let node=document.getElementById('wc2-customer-toast');
    if(!node){
      node=document.createElement('div');
      node.id='wc2-customer-toast';
      node.setAttribute('role','status');
      document.body.appendChild(node);
    }
    node.textContent=message;
    node.classList.add('show');
    clearTimeout(node._wc2Timer);
    node._wc2Timer=setTimeout(()=>node.classList.remove('show'),2800);
  }

  function injectPauseButton(){
    const pauseTitle=[...document.querySelectorAll('h2')].find(node=>['일시 정지','Paused'].includes((node.textContent||'').trim()));
    const pauseRoot=pauseTitle?.closest('.fixed');
    if(!pauseRoot)return;
    const settingsButton=[...pauseRoot.querySelectorAll('button')].find(node=>['설정','Settings'].includes((node.textContent||'').trim()));
    if(!settingsButton||pauseRoot.querySelector('[data-wc2-customer-menu]'))return;
    const button=document.createElement('button');
    button.type='button';
    button.dataset.wc2CustomerMenu='1';
    button.className=settingsButton.className;
    button.textContent='게임 에디터';
    button.addEventListener('click',event=>{
      event.preventDefault();
      event.stopPropagation();
      openSettings();
    });
    settingsButton.insertAdjacentElement('afterend',button);
  }

  function scheduleUI(){
    if(uiFrame||typeof requestAnimationFrame!=='function')return;
    uiFrame=requestAnimationFrame(()=>{
      uiFrame=0;
      injectPauseButton();
    });
  }

  function ensureStyles(){
    if(document.getElementById('wc2-customer-style'))return;
    const style=document.createElement('style');
    style.id='wc2-customer-style';
    style.textContent=`
      #wc2-customer-toast{position:fixed;left:50%;bottom:76px;z-index:2147483647;max-width:min(560px,calc(100vw - 32px));transform:translate(-50%,16px);opacity:0;pointer-events:none;background:#1c1917;color:#fde68a;border:1px solid #b45309;border-radius:8px;padding:9px 13px;box-shadow:0 12px 34px rgba(0,0,0,.55);font:700 12px/1.45 "Malgun Gothic","Apple SD Gothic Neo",sans-serif;transition:opacity .18s ease,transform .18s ease;text-align:center}
      #wc2-customer-toast.show{opacity:1;transform:translate(-50%,0)}
      #wc2-customer-editor{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;padding:14px;background:rgba(0,0,0,.8);font-family:"Malgun Gothic","Apple SD Gothic Neo","Noto Sans KR",sans-serif;color:#e7e5e4}
      #wc2-customer-editor *{box-sizing:border-box;letter-spacing:0}
      #wc2-customer-editor .wce-card{display:flex;flex-direction:column;width:min(980px,100%);height:min(760px,92dvh);overflow:hidden;background:#1c1917;border:1px solid #57534e;border-radius:8px;box-shadow:0 22px 70px rgba(0,0,0,.68)}
      #wc2-customer-editor .wce-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:15px 18px;border-bottom:1px solid #44403c}#wc2-customer-editor h2{margin:0;color:#fcd34d;font-size:19px;font-weight:800}#wc2-customer-editor .wce-subtitle{margin-top:2px;color:#78716c;font-size:10px}#wc2-customer-editor .wce-close{flex:0 0 34px;width:34px;height:34px;padding:0;background:transparent;color:#a8a29e;border:0;border-radius:6px;font-size:20px}#wc2-customer-editor .wce-close:hover{background:#292524;color:#fff}
      #wc2-customer-editor .wce-wallet{display:grid;grid-template-columns:minmax(180px,1fr) minmax(220px,360px) auto;align-items:center;gap:14px;padding:12px 18px;background:#0c0a09;border-bottom:1px solid #44403c}#wc2-customer-editor .wce-wallet-label{color:#f5f5f4;font-size:12px;font-weight:800}#wc2-customer-editor .wce-wallet-label small{display:block;margin-top:2px;color:#78716c;font-size:10px;font-weight:400}#wc2-customer-editor .wce-multiplier{display:grid;grid-template-columns:1fr 68px;align-items:center;gap:10px}#wc2-customer-editor input[type=range]{width:100%;accent-color:#d97706}#wc2-customer-editor input[type=number],#wc2-customer-editor input[type=search],#wc2-customer-editor select{min-width:0;background:#292524;color:#fafaf9;border:1px solid #57534e;border-radius:6px;padding:7px 8px;font-size:12px}#wc2-customer-editor input[type=number]{width:68px;text-align:right}#wc2-customer-editor .wce-apply,#wc2-customer-editor .wce-save{border:0;border-radius:6px;background:#b45309;color:#fff;padding:8px 13px;font-size:12px;font-weight:800}#wc2-customer-editor .wce-apply:hover,#wc2-customer-editor .wce-save:hover{background:#d97706}
      #wc2-customer-editor .wce-main{display:grid;grid-template-columns:280px minmax(0,1fr);min-height:0;flex:1}#wc2-customer-editor .wce-sidebar{display:flex;flex-direction:column;min-height:0;border-right:1px solid #44403c;background:#141210}#wc2-customer-editor .wce-tools{padding:12px;border-bottom:1px solid #292524}#wc2-customer-editor input[type=search]{width:100%;margin-bottom:8px}#wc2-customer-editor .wce-tabs{display:grid;grid-template-columns:repeat(4,1fr);gap:4px}#wc2-customer-editor .wce-tab{padding:6px 4px;border:1px solid #44403c;border-radius:6px;background:#1c1917;color:#a8a29e;font-size:10px;font-weight:700}#wc2-customer-editor .wce-tab.active{background:#78350f;border-color:#b45309;color:#fef3c7}
      #wc2-customer-editor .wce-nav{display:grid;grid-template-columns:repeat(5,1fr);gap:7px;padding:9px 14px;background:#0c0a09;border-bottom:1px solid #44403c;flex-shrink:0}
      #wc2-customer-editor .wce-nav button{padding:9px 4px;background:#292524;border:1px solid #57534e;border-radius:6px;color:#d6d3d1;font-size:12px;font-weight:700}
      #wc2-customer-editor .wce-nav button.active{background:#92400e;border-color:#f59e0b;color:#fff}
      #wc2-customer-editor .wce-page{display:none;flex:1;min-height:0;flex-direction:column;overflow:auto}
      #wc2-customer-editor .wce-page.active{display:flex}
      #wc2-customer-editor .wce-form{overflow:auto;padding:16px 18px}
      #wc2-customer-editor .wce-form{flex:1;min-height:0}
      #wc2-customer-editor .wce-form-section{margin:0 0 16px;padding:14px;background:#141210;border:1px solid #44403c;border-radius:8px}
      #wc2-customer-editor .wce-form-section h3{margin:0 0 10px;color:#fcd34d;font-size:14px}
      #wc2-customer-editor .wce-form-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
      #wc2-customer-editor .wce-form-grid label{display:flex;flex-direction:column;gap:4px;color:#a8a29e;font-size:11px}
      #wc2-customer-editor .wce-form-grid input{width:100%}
      #wc2-customer-editor .wce-form-grid select{width:100%;min-width:0}
      #wc2-customer-editor .wce-form-grid input[type=number]{width:100%;text-align:left}
      #wc2-customer-editor .wce-form-actions{display:flex;justify-content:flex-end;gap:8px;padding:10px 18px;border-top:1px solid #44403c;background:#141210}
      #wc2-customer-editor .wce-form-note{margin:0 0 10px;color:#a8a29e;font-size:11px;line-height:1.5}
      #wc2-customer-editor .wce-trait-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}
      #wc2-customer-editor .wce-trait{display:grid;grid-template-columns:minmax(0,1fr) 45px 45px;align-items:center;gap:5px;font-size:11px;background:#292524;padding:6px;border-radius:5px}
      #wc2-customer-editor .wce-trait label{text-align:center;font-size:10px}
      #wc2-customer-editor .wce-switch{display:flex;align-items:center;gap:8px;margin:8px 0;color:#e7e5e4;font-size:12px}
      #wc2-customer-editor .wce-custom-bar{display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:9px 12px;border-bottom:1px solid #292524;font-size:10px;color:#a8a29e}
      #wc2-customer-editor .wce-custom-bar input{width:65px}
      #wc2-customer-editor .wce-head,#wc2-customer-editor .wce-wallet{flex-shrink:0}
      #wc2-customer-editor .wce-flow{flex-shrink:0;border-bottom:1px solid #44403c;background:#141210}
      #wc2-customer-editor .wce-flow summary{padding:10px 18px;cursor:pointer;color:#fcd34d;font-size:12px;font-weight:800}
      #wc2-customer-editor .wce-flow-body{max-height:29dvh;overflow:auto;padding:0 18px 12px}
      #wc2-customer-editor .wce-flow-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px 18px}
      #wc2-customer-editor .wce-flow-field{display:flex;align-items:center;justify-content:space-between;gap:8px;color:#d6d3d1;font-size:11px}
      #wc2-customer-editor .wce-flow-field input{flex:0 0 76px;width:76px}
      #wc2-customer-editor .wce-flow-note{color:#a8a29e;font-size:10px;line-height:1.6;margin:10px 0}
      #wc2-customer-editor .wce-flow-actions{display:flex;justify-content:flex-end;gap:8px}
      #wc2-customer-editor .wce-flow-reset{border:1px solid #57534e;border-radius:6px;background:#292524;color:#d6d3d1;padding:7px 12px;font-size:12px}
      #wc2-customer-editor .wce-flow button:disabled,#wc2-customer-editor .wce-flow input:disabled{opacity:.45;cursor:not-allowed}
      @media(max-width:760px){#wc2-customer-editor .wce-flow-grid{grid-template-columns:1fr}}
      #wc2-customer-editor .wce-list{min-height:0;overflow:auto;padding:7px}#wc2-customer-editor .wce-person{display:block;width:100%;padding:9px 10px;margin-bottom:5px;text-align:left;background:#1c1917;border:1px solid #292524;border-radius:6px;color:#d6d3d1}#wc2-customer-editor .wce-person:hover{border-color:#78716c}#wc2-customer-editor .wce-person.active{background:#292524;border-color:#d97706}#wc2-customer-editor .wce-person-top{display:flex;align-items:center;justify-content:space-between;gap:8px}#wc2-customer-editor .wce-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#fafaf9;font-size:12px;font-weight:800}#wc2-customer-editor .wce-badge{flex:0 0 auto;padding:2px 5px;border-radius:5px;background:#44403c;color:#a8a29e;font-size:9px}#wc2-customer-editor .wce-badge.current{background:#14532d;color:#bbf7d0}#wc2-customer-editor .wce-person-meta{margin-top:4px;color:#78716c;font-size:10px}#wc2-customer-editor .wce-empty{padding:24px 10px;color:#57534e;font-size:11px;text-align:center}
      #wc2-customer-editor .wce-editor{min-width:0;overflow:auto;padding:16px 18px}#wc2-customer-editor .wce-placeholder{display:flex;align-items:center;justify-content:center;height:100%;color:#57534e;font-size:12px}#wc2-customer-editor .wce-person-title{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:14px}#wc2-customer-editor .wce-person-title h3{margin:0;color:#fff;font-size:17px}#wc2-customer-editor .wce-person-title small{display:block;margin-top:3px;color:#78716c;font-size:10px}#wc2-customer-editor .wce-section{margin-bottom:16px;padding-bottom:15px;border-bottom:1px solid #292524}#wc2-customer-editor .wce-section:last-of-type{border-bottom:0}#wc2-customer-editor .wce-section h4{margin:0 0 10px;color:#fcd34d;font-size:12px}#wc2-customer-editor .wce-select-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}#wc2-customer-editor .wce-field label{display:block;margin-bottom:4px;color:#a8a29e;font-size:10px}#wc2-customer-editor .wce-field select,#wc2-customer-editor .wce-field input{width:100%}
      #wc2-customer-editor .wce-stat-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px 18px}#wc2-customer-editor .wce-stat{display:grid;grid-template-columns:72px minmax(70px,1fr) 58px;align-items:center;gap:8px}#wc2-customer-editor .wce-stat label{color:#a8a29e;font-size:10px}#wc2-customer-editor .wce-stat input[type=number]{width:58px;padding:5px 6px}#wc2-customer-editor .wce-tags{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px}#wc2-customer-editor .wce-tag{display:flex;align-items:center;gap:6px;min-width:0;padding:7px 8px;background:#292524;border:1px solid #44403c;border-radius:6px;color:#d6d3d1;font-size:10px}#wc2-customer-editor .wce-tag input{accent-color:#d97706}#wc2-customer-editor .wce-actions{display:flex;justify-content:flex-end;padding-top:2px}#wc2-customer-editor .wce-save{min-width:150px}
      @media(max-width:760px){#wc2-customer-editor{padding:6px}#wc2-customer-editor .wce-card{height:96dvh}#wc2-customer-editor .wce-wallet{grid-template-columns:1fr auto}#wc2-customer-editor .wce-wallet-label{grid-column:1/-1}#wc2-customer-editor .wce-main{grid-template-columns:1fr;grid-template-rows:190px minmax(0,1fr)}#wc2-customer-editor .wce-sidebar{border-right:0;border-bottom:1px solid #44403c}#wc2-customer-editor .wce-select-grid{grid-template-columns:1fr}#wc2-customer-editor .wce-stat-grid{grid-template-columns:1fr}#wc2-customer-editor .wce-tags{grid-template-columns:repeat(2,minmax(0,1fr))}}
      @media(max-width:760px){#wc2-customer-editor .wce-main{grid-template-rows:minmax(70px,32%) minmax(0,1fr)}}
      @media(max-width:760px){#wc2-customer-editor .wce-form-grid,#wc2-customer-editor .wce-trait-grid{grid-template-columns:repeat(2,minmax(0,1fr))}#wc2-customer-editor .wce-trait{grid-template-columns:minmax(0,1fr) 34px 34px}}
      @media(max-height:560px){#wc2-customer-editor .wce-card{overflow:auto}#wc2-customer-editor .wce-main{flex-shrink:0;min-height:280px}}
      #wc2-customer-editor .wce-wallet{grid-template-columns:minmax(180px,1fr) minmax(220px,360px)}
      #wc2-customer-editor .wce-param-hint,#wc2-customer-editor .wce-wallet-label .wce-param-hint{display:block;margin-top:3px;color:#facc15;font-size:10px;line-height:1.4;font-weight:400}
      #wc2-customer-editor .wce-global-actions{display:flex;align-items:center;justify-content:flex-end;gap:8px;padding:10px 18px;border-top:1px solid #44403c;background:#141210;flex-shrink:0}
      #wc2-customer-editor .wce-global-actions span{margin-right:auto;color:#a8a29e;font-size:10px}
      #wc2-customer-editor .wce-flow-field{display:flex;flex-direction:column;align-items:stretch;gap:3px}
      #wc2-customer-editor .wce-flow-row{display:flex;align-items:center;justify-content:space-between;gap:8px}
      #wc2-customer-editor .wce-stat{row-gap:3px}
      #wc2-customer-editor .wce-stat .wce-param-hint{grid-column:1/-1;margin:0}
      #wc2-customer-editor .wce-trait .wce-param-hint{grid-column:1/-1}
      #wc2-customer-editor .wce-tag{align-items:flex-start}
      #wc2-customer-editor .wce-global-actions button:disabled{opacity:.45;cursor:not-allowed}
      #wc2-customer-editor .wce-staff-group{margin:0 0 16px}#wc2-customer-editor .wce-staff-group>h3{margin:0 0 8px;color:#fcd34d;font-size:15px}#wc2-customer-editor .wce-staff-card{margin:0 0 9px;border:1px solid #44403c;border-radius:8px;background:#141210}#wc2-customer-editor .wce-staff-card>summary{cursor:pointer;padding:10px 12px;color:#f5f5f4;font-size:12px;font-weight:800}#wc2-customer-editor .wce-staff-body{padding:0 12px 12px}#wc2-customer-editor .wce-staff-meta{margin:0 0 9px;color:#a8a29e;font-size:10px}#wc2-customer-editor .wce-staff-fields{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px}#wc2-customer-editor .wce-staff-field{display:flex;flex-direction:column;gap:3px;color:#a8a29e;font-size:10px}#wc2-customer-editor .wce-staff-field input,#wc2-customer-editor .wce-staff-field select{width:100%!important;text-align:left!important}#wc2-customer-editor .wce-staff-traits{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:5px}#wc2-customer-editor .wce-staff-traits label{display:flex;gap:5px;align-items:flex-start;padding:5px;border:1px solid #292524;border-radius:5px;color:#d6d3d1;font-size:10px}#wc2-customer-editor .wce-staff-heading{margin:11px 0 6px;color:#fbbf24;font-size:11px}
      @media(max-width:760px){#wc2-customer-editor .wce-wallet{grid-template-columns:1fr}#wc2-customer-editor .wce-global-actions{flex-wrap:wrap}#wc2-customer-editor .wce-global-actions span{flex-basis:100%}}
      @media(max-width:760px){#wc2-customer-editor .wce-nav{grid-template-columns:repeat(3,1fr)}#wc2-customer-editor .wce-staff-fields,#wc2-customer-editor .wce-staff-traits{grid-template-columns:repeat(2,minmax(0,1fr))}}
    `;
    document.head.appendChild(style);
  }

  function makeOption(select,value,label){
    const option=document.createElement('option');
    option.value=value;
    option.textContent=label;
    select.appendChild(option);
  }

  function createFlowSettings(){
    const section=document.createElement('details');
    section.className='wce-flow';
    section.open=true;
    section.innerHTML=`<summary>방문 · 뒷방 · 숙박 설정</summary><div class="wce-flow-body"><div class="wce-flow-grid"></div><p class="wce-flow-note">기존 시설·시간·평판·사건 대기일 조건은 유지됩니다. 수금원 등 이야기용 인물과 다른 애드온이 직접 만드는 손님은 별도입니다. 설정값은 이 브라우저에 저장됩니다.</p><p class="wce-flow-note" data-wce-flow-status></p><div class="wce-flow-actions"><button type="button" class="wce-flow-reset">방문 설정 기본값 입력</button></div></div>`;
    const grid=section.querySelector('.wce-flow-grid');
    for(const[key,field]of Object.entries(FLOW_FIELDS)){
      const label=document.createElement('label');
      label.className='wce-flow-field';
      const text=document.createElement('span');text.textContent=field.label;
      const input=document.createElement('input');
      input.type='number';input.min=String(field.min);input.max=String(field.max);input.step=String(field.step);
      input.required=true;
      input.dataset.wceFlow=key;
      const row=document.createElement('span');row.className='wce-flow-row';row.append(text,input);
      const hint=document.createElement('small');hint.className='wce-param-hint';hint.textContent=`${field.hint} · 범위 ${field.min}~${field.max}${key==='arrivalInterval'?'분':key==='maxCustomers'?'명':'배'}`;
      label.append(row,hint);grid.appendChild(label);
    }
    section.querySelector('.wce-flow-reset').addEventListener('click',()=>{
      for(const input of section.querySelectorAll('[data-wce-flow]'))input.value=String(DEFAULT_OPTIONS[input.dataset.wceFlow]);
      showToast('방문 설정 기본값을 입력했습니다. 모든 변경 적용을 눌러 저장하세요.');
    });
    return section;
  }

  function renderFlowSettings(){
    if(typeof document==='undefined')return;
    const section=document.querySelector('#wc2-customer-editor .wce-flow');
    if(!section)return;
    const ready=api?.customerFlow?.version===1;
    section.querySelectorAll('[data-wce-flow]').forEach(input=>{input.value=String(visibleOptions()[input.dataset.wceFlow]);input.disabled=!ready});
    section.querySelectorAll('button').forEach(button=>{button.disabled=!ready});
    section.querySelector('[data-wce-flow-status]').textContent=ready?'':'이 기능을 사용하려면 Install_Addons.cmd를 다시 실행하고 새 Addons HTML을 열어 주세요. (2026-09-30 버전 지원)';
  }

  function makeSelectField(label,field,choices,value){
    const wrapper=document.createElement('div');
    wrapper.className='wce-field';
    const title=document.createElement('label');
    title.textContent=label;
    const select=document.createElement('select');
    select.dataset.field=field;
    for(const[key,text]of Object.entries(choices))makeOption(select,key,text);
    select.value=Object.hasOwn(choices,value)?value:Object.keys(choices)[0];
    const hint=document.createElement('small');hint.className='wce-param-hint';
    hint.textContent={patronType:'손님의 기본 행동 유형을 고릅니다',intent:'방문할 때 추구하는 목적을 고릅니다',tacticStyle:'접근할 때 주로 쓰는 방식을 고릅니다'}[field]??'목록에서 선택합니다';
    wrapper.append(title,select,hint);
    return wrapper;
  }

  function makeNumberField(label,field,value,max=100){
    const row=document.createElement('div');
    row.className='wce-stat';
    const title=document.createElement('label');
    title.textContent=label;
    const range=document.createElement('input');
    range.type='range';range.min='0';range.max=String(max);range.step='1';range.value=String(clampInteger(value,0,max,0));
    const number=document.createElement('input');
    number.type='number';number.min='0';number.max=String(max);number.step='1';number.value=range.value;number.dataset.field=field;number.dataset.original=number.value;
    range.addEventListener('input',()=>{number.value=range.value});
    number.addEventListener('input',()=>{range.value=String(clampInteger(number.value,0,max,0))});
    const hint=document.createElement('small');hint.className='wce-param-hint';
    hint.textContent=`${CUSTOMER_HINTS[field]??ATTRIBUTE_HINTS[field.slice('attribute:'.length)]??'손님의 기본 능력치'} · 범위 0~${max}`;
    row.append(title,range,number,hint);
    return row;
  }

  function renderCustomerList(entries){
    const modal=document.getElementById('wc2-customer-editor');
    const list=modal?.querySelector('[data-wce-list]');
    if(!list)return;
    const query=searchText.trim().toLocaleLowerCase('ko-KR');
    const filtered=entries.filter(entry=>{
      if(filterMode!=='all'&&entry.kind!==filterMode)return false;
      if(!query)return true;
      const text=`${entry.item.name||''} ${PATRON_TYPES[entry.item.patronType]||entry.item.patronType||''} ${(entry.item.personaTags||[]).map(tag=>PERSONA_TAGS[tag]||tag).join(' ')}`.toLocaleLowerCase('ko-KR');
      return text.includes(query);
    });
    list.replaceChildren();
    if(filtered.length===0){
      const empty=document.createElement('div');
      empty.className='wce-empty';
      empty.textContent=entries.length?'검색 결과가 없습니다.':'아직 방문한 손님이 없습니다.';
      list.appendChild(empty);
      return;
    }
    for(const entry of filtered){
      const button=document.createElement('button');
      button.type='button';
      button.className=`wce-person${entry.key===selectedKey?' active':''}`;
      button.dataset.customerKey=entry.key;
      const top=document.createElement('span');top.className='wce-person-top';
      const name=document.createElement('span');name.className='wce-name';name.textContent=entry.item.name||'이름 없는 손님';
      const badge=document.createElement('span');badge.className=`wce-badge ${entry.kind}`;badge.textContent=entry.kind==='current'?'현재':entry.kind==='custom'?'사용자':'기록';
      const meta=document.createElement('span');meta.className='wce-person-meta';
      const detail=entry.kind==='current'?`소지금 ${Number(entry.item.walletGold)||0}G`:`방문 ${Number(entry.item.visitCount)||0}회`;
      meta.textContent=`${PATRON_TYPES[entry.item.patronType]||entry.item.patronType||'일반 손님'} · ${entry.kind==='custom'?`가중치 ${entry.item.weight??1}`:detail}`;
      top.append(name,badge);button.append(top,meta);list.appendChild(button);
    }
  }

  function renderCustomerEditor(entry){
    const modal=document.getElementById('wc2-customer-editor');
    const editor=modal?.querySelector('[data-wce-detail]');
    if(!editor)return;
    editor.replaceChildren();
    editor.dataset.customerKey=entry?.key??'';
    editor.dataset.customerDirty='0';
    if(!entry){
      const placeholder=document.createElement('div');
      placeholder.className='wce-placeholder';
      placeholder.textContent='편집할 손님을 선택하세요.';
      editor.appendChild(placeholder);
      return;
    }
    const item=entry.item;
    const title=document.createElement('div');title.className='wce-person-title';
    const titleText=document.createElement('div');
    const heading=document.createElement('h3');heading.textContent=item.name||'이름 없는 손님';
    const sub=document.createElement('small');sub.textContent=entry.kind==='current'?'현재 가게에 있는 손님':entry.kind==='custom'?'사용자 생성 손님 · 다음 방문부터 등장':'과거 방문 기록';
    titleText.append(heading,sub);title.appendChild(titleText);
    if(entry.kind==='custom'){
      const nameField=document.createElement('label');nameField.className='wce-field';nameField.textContent='이름';
      const nameInput=document.createElement('input');nameInput.type='text';nameInput.maxLength=24;nameInput.value=item.name??'';nameInput.dataset.field='name';
      const nameHint=document.createElement('small');nameHint.className='wce-param-hint';nameHint.textContent='방문 시 표시할 고유 이름 · 1~24자';
      nameField.append(nameInput,nameHint);editor.appendChild(nameField);
    }

    const tendency=document.createElement('section');tendency.className='wce-section';
    const tendencyTitle=document.createElement('h4');tendencyTitle.textContent='직업과 행동 성향';
    const selectGrid=document.createElement('div');selectGrid.className='wce-select-grid';
    selectGrid.append(
      makeSelectField('직업 유형','patronType',PATRON_TYPES,item.patronType),
      makeSelectField('방문 의도','intent',INTENTS,item.intent),
      makeSelectField('접근 방식','tacticStyle',TACTICS,item.tacticStyle)
    );
    tendency.append(tendencyTitle,selectGrid);

    const basics=document.createElement('section');basics.className='wce-section';
    const basicsTitle=document.createElement('h4');basicsTitle.textContent='기본 수치';
    const basicGrid=document.createElement('div');basicGrid.className='wce-stat-grid';
    if(entry.kind==='current')basicGrid.appendChild(makeNumberField('소지금','walletGold',item.walletGold,999999));
    if(entry.kind==='custom')basicGrid.append(
      makeNumberField('초기 지갑 최소','walletMin',item.walletMin??20,500),
      makeNumberField('초기 지갑 최대','walletMax',item.walletMax??50,500),
      makeNumberField('등장 가중치','weight',item.weight??1,10)
    );
    if(entry.kind!=='custom'){
      const future=editorRoster().overrides[item.name]??{};
      basicGrid.append(
        makeNumberField('다음 방문 지갑 최소','walletMin',future.walletMin??20,500),
        makeNumberField('다음 방문 지갑 최대','walletMax',future.walletMax??50,500)
      );
    }
    basicGrid.append(
      makeNumberField('대담함','boldness',item.boldness),
      makeNumberField('초기 매력','charm',item.charm),
      makeNumberField('궁합','chemistry',item.chemistry)
    );
    basics.append(basicsTitle,basicGrid);

    const stats=document.createElement('section');stats.className='wce-section';
    const statsTitle=document.createElement('h4');statsTitle.textContent='능력치';
    const statGrid=document.createElement('div');statGrid.className='wce-stat-grid';
    for(const[key,label]of Object.entries(ATTRIBUTES))statGrid.appendChild(makeNumberField(label,`attribute:${key}`,item.attributes?.[key]));
    stats.append(statsTitle,statGrid);

    const backgrounds=document.createElement('section');backgrounds.className='wce-section';
    const backgroundsTitle=document.createElement('h4');backgroundsTitle.textContent='직업과 배경 태그';
    const tags=document.createElement('div');tags.className='wce-tags';
    const activeTags=new Set(item.personaTags??[]);
    for(const[key,label]of Object.entries(PERSONA_TAGS)){
      const tag=document.createElement('label');tag.className='wce-tag';
      const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.value=key;checkbox.dataset.personaTag='1';checkbox.checked=activeTags.has(key);
      const text=document.createElement('span');text.textContent=label;
      const hint=document.createElement('small');hint.className='wce-param-hint';hint.textContent='이 배경 태그의 적용 여부 · 선택/해제';text.appendChild(hint);
      tag.append(checkbox,text);tags.appendChild(tag);
    }
    backgrounds.append(backgroundsTitle,tags);

    let relation=null;
    if(entry.record){
      relation=document.createElement('section');relation.className='wce-section';
      const relationTitle=document.createElement('h4');relationTitle.textContent="그녀와 이 손님의 관계";
      const grid=document.createElement('div');grid.className='wce-stat-grid';
      for(const[key,label]of [['platonic','호감 / 친근감'],['romantic','연애 감정'],['sexual','성적 끌림']]){
        const row=document.createElement('label');row.className='wce-field';row.textContent=label;
        const input=document.createElement('input');input.type='number';input.min='-100';input.max='100';input.step='1';input.value=String(entry.record[key]??0);input.dataset.field=key;
        const hint=document.createElement('small');hint.className='wce-param-hint';hint.textContent=`${CUSTOMER_HINTS[key]} · 범위 -100~100`;
        row.append(input,hint);grid.appendChild(row);
      }
      relation.append(relationTitle,grid);
    }

    const actions=document.createElement('div');actions.className='wce-actions';
    const pendingNote=document.createElement('small');pendingNote.className='wce-param-hint';pendingNote.textContent='이 손님의 수정도 아래의 모든 변경 적용 버튼으로 함께 저장됩니다.';
    actions.appendChild(pendingNote);
    if(entry.kind==='custom'){
      const remove=document.createElement('button');remove.type='button';remove.className='wce-flow-reset';remove.dataset.removeCustom=entry.key.slice('custom:'.length);remove.textContent='사용자 손님 삭제';actions.prepend(remove);
    }else if(editorRoster().overrides[item.name]){
      const reset=document.createElement('button');reset.type='button';reset.className='wce-flow-reset';reset.dataset.resetCustomer=entry.key;reset.textContent='원본 동작으로 되돌리기';actions.prepend(reset);
    }
    editor.prepend(title);
    editor.append(tendency,basics,stats,backgrounds);
    if(relation)editor.appendChild(relation);
    editor.appendChild(actions);
    const pending=editorDraft?.customerPatches.get(entry.key);
    if(pending){
      for(const input of editor.querySelectorAll('[data-field]')){
        const key=input.dataset.field;
        const value=key.startsWith('attribute:')?pending.attributes?.[key.slice(10)]:pending[key];
        if(value!=null){
          input.value=String(value);
          const range=input.closest('.wce-stat')?.querySelector('input[type=range]');
          if(range)range.value=String(value);
        }
      }
      for(const input of editor.querySelectorAll('[data-persona-tag]'))input.checked=pending.personaTags?.includes(input.value)??false;
      editor.dataset.customerDirty='1';
    }
  }

  function readEditorPatch(editor){
    const read=field=>editor.querySelector(`[data-field="${field}"]`)?.value;
    const attributes={};
    for(const key of Object.keys(ATTRIBUTES))attributes[key]=read(`attribute:${key}`);
    return{
      patronType:read('patronType'),
      intent:read('intent'),
      tacticStyle:read('tacticStyle'),
      walletGold:read('walletGold'),
      __walletGoldTouched:(()=>{const input=editor.querySelector('[data-field="walletGold"]');return input?input.value!==input.dataset.original:undefined})(),
      boldness:read('boldness'),
      charm:read('charm'),
      chemistry:read('chemistry'),
      attributes,
      personaTags:[...editor.querySelectorAll('[data-persona-tag]:checked')].map(input=>input.value),
      name:read('name'),walletMin:read('walletMin'),walletMax:read('walletMax'),weight:read('weight'),
      platonic:read('platonic'),romantic:read('romantic'),sexual:read('sexual')
    };
  }

  function rememberCustomerEditor(){
    if(!editorDraft||typeof document==='undefined')return;
    const editor=document.querySelector('#wc2-customer-editor [data-wce-detail]');
    const key=editor?.dataset.customerKey;
    if(key&&editor.dataset.customerDirty==='1')editorDraft.customerPatches.set(key,readEditorPatch(editor));
  }

  function validateCustomerPatch(key,patch){
    const bounds={walletGold:[0,999999],walletMin:[0,500],walletMax:[0,500],weight:[0,10],boldness:[0,100],charm:[0,100],chemistry:[0,100],platonic:[-100,100],romantic:[-100,100],sexual:[-100,100]};
    for(const [field,[min,max]] of Object.entries(bounds)){
      const value=patch[field];if(value==null)continue;
      if(value===''||!Number.isInteger(Number(value))||Number(value)<min||Number(value)>max){showToast(`${key}: ${field} 값은 ${min}~${max} 정수여야 합니다.`);return false}
    }
    for(const [field,value] of Object.entries(patch.attributes??{})){
      if(value===''||!Number.isInteger(Number(value))||Number(value)<0||Number(value)>100){showToast(`${key}: ${field} 능력치는 0~100 정수여야 합니다.`);return false}
    }
    return true;
  }

  function renderSettings(){
    if(typeof document==='undefined')return;
    const modal=document.getElementById('wc2-customer-editor');
    if(!modal)return;
    rememberCustomerEditor();
    const entries=getEntries();
    if(selectedKey&&!entries.some(entry=>entry.key===selectedKey))selectedKey='';
    if(!selectedKey&&entries.length)selectedKey=entries[0].key;
    const multiplier=modal.querySelector('[data-wce-multiplier-number]');
    const range=modal.querySelector('[data-wce-multiplier-range]');
    if(modal.dataset.wceCustomersRendered!=='1'){
      multiplier.value=visibleOptions().walletMultiplier.toFixed(1);
      range.value=String(visibleOptions().walletMultiplier);
      modal.querySelector('[data-wce-custom-share]').value=String(editorRoster().share);
      modal.dataset.wceCustomersRendered='1';
    }
    modal.querySelectorAll('[data-wce-filter]').forEach(button=>button.classList.toggle('active',button.dataset.wceFilter===filterMode));
    const search=modal.querySelector('[data-wce-search]');
    if(document.activeElement!==search&&search.value!==searchText)search.value=searchText;
    renderCustomerList(entries);
    renderCustomerEditor(findEntry(selectedKey));
  }

  function readPath(object,path){return path.reduce((value,key)=>value?.[key],object)}

  function writePath(object,path,value){
    const [key,...rest]=path;
    const next=Array.isArray(object)?[...object]:{...(object??{})};
    next[key]=rest.length?writePath(object?.[key],rest,value):value;
    return next;
  }

  function maxMana(attunement){return Math.round(30+70*clampNumber(attunement,0,100,0)/100)}

  function numericHint(path){
    const joined=path.join('.'),tail=path.slice(-2).join('.'),key=path.at(-1);
    if(key==='raising')return'-1 개방적 / +1 보수적 · 기존 특성·능력치를 다시 생성하지 않음';
    if(path.includes('latitude'))return{encouragement:'행동을 권유한 정도',restriction:'행동을 제한한 정도',encouragementClarity:'권유를 분명하게 이해한 정도',restrictionClarity:'제한을 분명하게 이해한 정도'}[key]??'관계 방침';
    if(key==='loyalty')return'관계를 지키려는 기본 성향';
    if(PARAM_HINTS[joined])return PARAM_HINTS[joined];
    if(PARAM_HINTS[tail])return PARAM_HINTS[tail];
    if(path.includes('attributes'))return ATTRIBUTE_HINTS[key]??'기본 능력치';
    if(path.includes('affinities'))return `${AFFINITIES[key]??key} 행동에 대한 선호도`;
    if(path.includes('stats'))return{energy:'행동에 쓰는 기력',mood:'현재 기분',arousal:'현재 흥분도'}[key]??'현재 상태';
    if(key==='proficiency')return'이 주문을 시전할 때 쓰는 숙련도';
    return'현재 게임 상태의 저장 수치';
  }

  function addNumberGroup(parent,title,fields,state){
    const section=document.createElement('section');section.className='wce-form-section';
    const heading=document.createElement('h3');heading.textContent=title;
    const grid=document.createElement('div');grid.className='wce-form-grid';
    for(const field of fields){
      const stored=readPath(state,field.path);
      const value=typeof stored==='number'&&Number.isFinite(stored)?stored:field.fallback;
      if(typeof value!=='number'||!Number.isFinite(value))continue;
      const label=document.createElement('label');label.textContent=field.label;
      const input=document.createElement('input');input.type='number';input.required=true;
      input.min=String(field.min??0);input.max=String(field.max??100);input.step=String(field.step??1);
      input.value=String(value);input.dataset.editPath=JSON.stringify(field.path);input.dataset.original=String(value);
      const hint=document.createElement('small');hint.className='wce-param-hint';hint.textContent=`${numericHint(field.path)} · 범위 ${field.min??0}~${field.max??100}`;
      label.append(input,hint);grid.appendChild(label);
    }
    if(grid.childElementCount){section.append(heading,grid);parent.appendChild(section)}
  }

  function numericFields(base,labels,min=0,max=100,step=1){
    return Object.entries(labels).map(([key,label])=>({path:[...base,key],label,min,max,step}));
  }

  function renderTavernEditor(page,state){
    addNumberGroup(page,'술집 경제',[
      {path:['economy','gold'],label:'보유 골드',min:0,max:999999999},
      {path:['economy','debt'],label:'빚',min:0,max:999999999},
      {path:['economy','weeklyRent'],label:'주당 임대료',min:0,max:999999999}
    ],state);
    addNumberGroup(page,'재고와 시설',[
      ...numericFields(['supplies'],{food:'식재료',beer:'맥주',wine:'와인'},0,999999999),
      {path:['readyFood'],label:'완성된 음식',min:0,max:999999999},
      {path:['tavernCleanliness'],label:'청결',min:0,max:100},
      {path:['tavern','quality'],label:'술집 품질',min:0,max:100}
    ],state);
    addNumberGroup(page,'평판',numericFields(['tavernReputation'],{service:'서비스 평판',renown:'명성',notoriety:'악명'},0,100,.01),state);
    addNumberGroup(page,"당신 능력치",numericFields(['player','attributes'],ATTRIBUTES),state);
    addNumberGroup(page,"당신 성격",numericFields(['player','personality'],PERSONALITY),state);
    addNumberGroup(page,"당신 생활 기술",[
      {path:['player','skills','cooking'],label:'요리 숙련도',min:0,max:100,step:.01,fallback:10},
      {path:['player','skills','hunting'],label:'사냥 숙련도',min:0,max:100,step:.01,fallback:0}
    ],state);
    addNumberGroup(page,"당신 현재 상태",[
      ...numericFields(['player','stats'],{energy:'기력',mood:'기분',arousal:'흥분'},0,100,.01),
      {path:['player','fatigue'],label:'피로',min:0,max:100,step:.01}
    ],state);
  }

  function husbandFeeling(wife,id){
    return (wife?.feelings??[]).filter(feeling=>feeling?.emotion===id&&feeling?.target?.kind==='husband').reduce((value,feeling)=>Math.max(value,Number(feeling.intensity)||0),0);
  }


  const PRE7_POLICIES={"sex_vaginal":"일반 관계","sex_rough":"거친 관계","sex_anal":"항문 관계","oral_giving":"구강 행위 제공","oral_receiving":"구강 행위 받기","genital_rubbing":"몸 비비기","cum_in_mouth":"입 안 사정","cum_swallow":"정액 삼키기","manual_giving":"손으로 해 주기","manual_receiving":"손으로 받기","watch_him":"상대 관찰","touch_over_clothes":"옷 위 접촉","touch_breasts":"가슴 접촉","touch_under_skirt":"치마 안 접촉","visual_thigh":"허벅지 노출","visual_undergarments":"속옷 노출","visual_explicit":"은밀한 부위 노출","visual_topless":"상체 노출","visual_bottomless":"하체 노출","visual_full_nude":"전신 노출","kiss_real":"입맞춤"};
  Object.assign(PRE7_POLICIES,{touch_affection:'애정 표현',visual_modest:'단정한 모습',visual_payment:'대가를 받는 노출',kiss_chaste:'가벼운 입맞춤',cum_on_skin:'피부 위 마무리',cum_on_face:'얼굴 위 마무리',sex_public:'공개적인 관계',verbal_proposition:'말로 제안하기',social_assertion:'의견 표현',interrupt_patron:'손님과의 교류 중단',step_away_private:'별도 공간으로 이동'});
  const PRE7_RELATIONS={'':'별도 바탕 없음',step_sibling:'의붓동생',childhood_friend:'오랜 친구',employee:'고용인·종업원'};
  const PRE7_ROMANCE={'':'연애 관계 없음',spouse:'배우자',courting:'교제 중',lover:'연인',betrothed:'약혼자'};
  const PRE7_TIP_SHARES={none:'없음',quarter:'4분의 1 (기본)',half:'절반',all:'전부'};
  function mainRelation(state){return(state.relationships??[]).find(row=>row.refs?.some(ref=>ref.kind==='player')&&row.refs?.some(ref=>ref.kind==='character'&&ref.id===state.primaryCharacterId));}
  function addPre7Select(parent,label,key,value,choices){
    const row=document.createElement('label');row.className='wce-form-note';row.textContent=label;
    const select=document.createElement('select');select.dataset.pre7=key;select.dataset.original=value;
    for(const [id,name]of Object.entries(choices)){const option=document.createElement('option');option.value=id;option.textContent=name;select.append(option);}
    if(!Object.hasOwn(choices,value)){const option=document.createElement('option');option.value=value;option.textContent='기존 값 유지: '+value;select.append(option);}
    select.value=value;row.append(select);parent.append(row);
  }
  function renderPre7Editor(page,state){
    const id=state.primaryCharacterId,wife=state.characters[id],base=['characters',id],pair=mainRelation(state);
    const section=document.createElement('section');section.className='wce-form-section';
    const title=document.createElement('h3');title.textContent='관계와 오늘 밤 취침';section.append(title);
    const grid=document.createElement('div');grid.className='wce-form-grid';section.append(grid);
    if(pair){
      addPre7Select(grid,'관계 바탕','relation',pair.kinship??pair.tags?.find(tag=>['childhood_friend','employee'].includes(tag))??'',PRE7_RELATIONS);
      addPre7Select(grid,'연애 관계','romance',pair.romantic??'',PRE7_ROMANCE);
    }
    const rooms={'':'자동 · 관계에 따른 기본 방'};
    for(const [room,label]of Object.entries({bedroom:'침실',elena_room:'그녀의 방'}))if(state.locations?.[room])rooms[room]=label;
    addPre7Select(grid,'그녀의 오늘 밤 취침방','wifeBed',wife.bedTonight??'',rooms);
    addPre7Select(grid,'당신의 오늘 밤 취침방','playerBed',state.player.bedTonight??'',rooms);
    addPre7Select(grid,'그녀가 챙기는 팁 비율','tipShare',state.herTipShare??'quarter',PRE7_TIP_SHARES);
    const note=document.createElement('p');note.className='wce-form-note';note.textContent='관계 바탕과 연애 상태는 별개입니다. 배우자에서 친구·고용인으로 바꾸려면 연애 관계도 “없음”으로 바꾸세요. 감정·신뢰·방침·개인 배경은 유지됩니다. 취침방 변경은 현재 위치·행동을 옮기지 않습니다.';section.append(note);page.append(section);
    addNumberGroup(page,'성장 배경과 생활 기술',[
      {path:[...base,'raising'],label:'성장 배경',min:-1,max:1,step:.01,fallback:0},
      ...numericFields([...base,'skills'],{cooking:'요리 숙련도',serving:'응대 숙련도'},0,100,.01).map(field=>({...field,fallback:0}))
    ],state);
    addNumberGroup(page,'개인 금전과 미지급 임금',[
      {path:[...base,'purse'],label:'개인 지갑 (골드)',min:0,max:999999999,step:1,fallback:0},
      {path:[...base,'wagesOwed'],label:'밀린 임금 (골드)',min:0,max:999999999,step:1,fallback:0}
    ],state);
    const wagesNote=document.createElement('p');wagesNote.className='wce-form-note';wagesNote.textContent='지갑·밀린 임금은 장부 수치만 변경합니다. 금고에서 자동으로 송금하지 않습니다. 고용 관계의 주급과 다음 임금 정산·퇴사 판정은 본편 규칙을 따릅니다.';page.append(wagesNote);
    const policies=document.createElement('details'),summary=document.createElement('summary');summary.textContent='관계 방침 · 권유와 제한';policies.append(summary);page.append(policies);
    for(const category of Object.keys(wmlApi.fn('decisionCategories'))){
      addNumberGroup(policies,PRE7_POLICIES[category]||category,numericFields([...base,'latitude','byCategory',category],{encouragement:'권유 강도',restriction:'제한 강도',encouragementClarity:'권유의 명확도',restrictionClarity:'제한의 명확도'},0,100,.01).map(field=>({...field,fallback:0})),state);
    }
  }
  function applyPre7Selections(state,page){
    let next=state,relationEdited=false;
    for(const input of page.querySelectorAll('[data-pre7]')){
      if(input.value===input.dataset.original)continue;
      const key=input.dataset.pre7,value=input.value;
      if(key==='relation'||key==='romance'){
        relationEdited=true;
        if(!Object.hasOwn(key==='relation'?PRE7_RELATIONS:PRE7_ROMANCE,value))return null;
        const pair=mainRelation(next);if(!pair)return null;
        const replacement={...pair};
        if(key==='romance'){
          if(value)replacement.romantic=value;else delete replacement.romantic;
        }else{
          replacement.tags=(pair.tags??[]).filter(t=>!['childhood_friend','employee'].includes(t));
          delete replacement.kinship;
          if(value==='step_sibling')replacement.kinship=value;
          else if(value)replacement.tags=[value,...replacement.tags];
        }
        next={...next,relationships:next.relationships.map(r=>r===pair?replacement:r)};
      }else if(key==='tipShare'){
        if(!Object.hasOwn(PRE7_TIP_SHARES,value))return null;
        next={...next,herTipShare:value};
      }else{
        if(value&&!['bedroom','elena_room'].includes(value))return null;
        if(value&&!next.locations?.[value])return null;
        const path=key==='wifeBed'?['characters',next.primaryCharacterId]:['player'];
        const actor={...readPath(next,path)};if(value)actor.bedTonight=value;else delete actor.bedTonight;
        next=writePath(next,path,actor);
      }
    }
    const pair=mainRelation(next);
    if(relationEdited&&pair&&!pair.romantic&&!pair.kinship&&!pair.tags?.length){showToast('관계 바탕 또는 연애 관계를 하나 이상 선택해 주세요.');return null;}
    return next;
  }

  function renderWifeEditor(page,state){
    const id=state.primaryCharacterId,wife=state.characters?.[id];
    if(!wife){page.textContent="그녀 상태를 찾지 못했습니다.";return}
    const base=['characters',id];
    renderPre7Editor(page,state);
    addNumberGroup(page,`${wife.name??"그녀"}의 능력치`,numericFields([...base,'attributes'],ATTRIBUTES),state);
    addNumberGroup(page,'현재 상태',[
      ...numericFields([...base,'stats'],{energy:'기력',mood:'기분',arousal:'흥분'},0,100,.01),
      {path:[...base,'attributes','libido'],label:'성욕',min:0,max:100},
      {path:[...base,'volatility'],label:'감정 변동성',min:.1,max:.85,step:.01}
    ],state);
    addNumberGroup(page,"내면과 당신과의 관계",[
      ...numericFields([...base,'selfConcept'],{openness:'내면 개방성',confidence:'내면 자신감'},0,100,.01),
      {path:[...base,'relationship','trust'],label:"당신에 대한 신뢰",min:0,max:100}
    ],state);
    addNumberGroup(page,'행동 선호',numericFields([...base,'affinities'],AFFINITIES,-2,2,.01),state);

    const traitSection=document.createElement('section');traitSection.className='wce-form-section';
    const title=document.createElement('h3');title.textContent='숨은 특성 · 발견된 특성';
    const note=document.createElement('p');note.className='wce-form-note';note.textContent='보유는 실제 판정에, 발견은 상태 화면 표시에 사용됩니다. 알 수 없는 기존 특성은 보존합니다.';
    const grid=document.createElement('div');grid.className='wce-trait-grid';
    for(const[key,label]of Object.entries(WIFE_TRAITS)){
      const row=document.createElement('div');row.className='wce-trait';
      const text=document.createElement('span');text.textContent=label;
      const own=document.createElement('input');own.type='checkbox';own.dataset.traitOwn=key;own.checked=(wife.latentTraits??[]).includes(key);own.dataset.original=String(own.checked);
      const seen=document.createElement('input');seen.type='checkbox';seen.dataset.traitSeen=key;seen.checked=(wife.noticedLatentTraits??[]).includes(key);seen.dataset.original=String(seen.checked);
      own.addEventListener('change',()=>{if(!own.checked)seen.checked=false});
      seen.addEventListener('change',()=>{if(seen.checked)own.checked=true});
      const ownLabel=document.createElement('label');ownLabel.textContent='보유';ownLabel.appendChild(own);
      const seenLabel=document.createElement('label');seenLabel.textContent='발견';seenLabel.appendChild(seen);
      const hint=document.createElement('small');hint.className='wce-param-hint';hint.textContent=`${TRAIT_HINTS[key]} · 보유/발견 각각 선택·해제`;
      row.append(text,ownLabel,seenLabel,hint);grid.appendChild(row);
    }
    traitSection.append(title,note,grid);page.appendChild(traitSection);

    const feelingSection=document.createElement('section');feelingSection.className='wce-form-section';
    const feelingTitle=document.createElement('h3');feelingTitle.textContent="당신에 대한 지속 감정";
    const feelingGrid=document.createElement('div');feelingGrid.className='wce-form-grid';
    for(const[key,label]of Object.entries(HUSBAND_FEELINGS)){
      const input=document.createElement('input');input.type='number';input.min='0';input.max='100';input.step='1';input.required=true;
      input.dataset.husbandFeeling=key;input.value=String(husbandFeeling(wife,key));input.dataset.original=input.value;
      const row=document.createElement('label');row.textContent=label;
      const hint=document.createElement('small');hint.className='wce-param-hint';hint.textContent=`당신에게 느끼는 ${label}의 지속 강도 · 범위 0~100`;
      row.append(input,hint);feelingGrid.appendChild(row);
    }
    feelingSection.append(feelingTitle,feelingGrid);page.appendChild(feelingSection);
  }

  function renderMagicEditor(page,state){
    const magic=state.player?.magic??{grimoireFound:false,understanding:0,attunement:0,mana:{current:30},spells:{}};
    const section=document.createElement('section');section.className='wce-form-section';
    const heading=document.createElement('h3');heading.textContent='마법 해금';section.appendChild(heading);
    for(const[key,label,checked,description]of [
      ['magicBook','마도서 발견 / 비술 기능',!!magic.grimoireFound,'강화·약화 등 비술 메뉴를 열어 줍니다 · 켜짐/꺼짐'],
      ['magicAssay','주머니 감정 주문 습득',!!magic.spells?.assay_purse,'주머니 감정 주문을 보유합니다 · 켜짐/꺼짐'],
      ['infiniteMana','무한 마나',visibleOptions().infiniteMana,'소비된 마나를 현재 최대치로 즉시 채웁니다 · 켜짐/꺼짐']
    ]){
      const row=document.createElement('label');row.className='wce-switch';
      const input=document.createElement('input');input.type='checkbox';input.dataset[key]='1';input.checked=checked;input.dataset.original=String(checked);
      const copy=document.createElement('span');copy.textContent=label;
      const hint=document.createElement('small');hint.className='wce-param-hint';hint.textContent=description;copy.appendChild(hint);
      row.append(input,copy);section.appendChild(row);
    }
    const book=section.querySelector('[data-magic-book]'),assay=section.querySelector('[data-magic-assay]');
    book.addEventListener('change',()=>{if(!book.checked)assay.checked=false});
    assay.addEventListener('change',()=>{if(assay.checked)book.checked=true});
    page.appendChild(section);
    addNumberGroup(page,'마법 수치',[
      {path:['player','magic','understanding'],label:'이해도',min:0,max:100,step:.01,fallback:magic.understanding??0},
      {path:['player','magic','attunement'],label:'동조율',min:0,max:100,step:.01,fallback:magic.attunement??0},
      {path:['player','magic','mana','current'],label:`현재 마나 (현재 최대 ${maxMana(magic.attunement)})`,min:0,max:100,step:.01,fallback:magic.mana?.current??30}
    ],state);
    addNumberGroup(page,'주문 숙련도',Object.entries(magic.spells??{}).filter(([,spell])=>typeof spell?.proficiency==='number').map(([id])=>({path:['player','magic','spells',id,'proficiency'],label:SPELL_LABELS[id]??id,min:0,max:100,step:.01})),state);
    const lore=Number.isFinite(state.stillroom?.lore)?state.stillroom.lore:0;
    addNumberGroup(page,'채취·조제 숙련도',[
      {path:['player','skills','foraging'],label:'채취 숙련도',min:0,max:100,step:.01,fallback:lore},
      {path:['player','skills','brewing'],label:'조제 숙련도',min:0,max:100,step:.01,fallback:lore}
    ],state);
    const known=state.stillroom?.known??{};
    const totalEffects=Object.values(ALCHEMY_EFFECTS).reduce((sum,effects)=>sum+effects.length,0);
    const knownEffects=Object.entries(ALCHEMY_EFFECTS).reduce((sum,[id,effects])=>sum+effects.filter(effect=>(known[id]??[]).includes(effect)).length,0);
    const allKnown=knownEffects===totalEffects;
    const knowledge=document.createElement('section');knowledge.className='wce-form-section';
    const knowledgeTitle=document.createElement('h3');knowledgeTitle.textContent='채취·조제 발견';
    const knowledgeRow=document.createElement('label');knowledgeRow.className='wce-switch';
    const knowledgeInput=document.createElement('input');knowledgeInput.type='checkbox';knowledgeInput.dataset.alchemyKnown='1';knowledgeInput.checked=allKnown;knowledgeInput.dataset.original=String(allKnown);
    const knowledgeCopy=document.createElement('span');knowledgeCopy.textContent='모든 조제 재료 효과와 조합법 발견';
    const knowledgeHint=document.createElement('small');knowledgeHint.className='wce-param-hint';knowledgeHint.textContent=`현재 발견한 효과 ${knownEffects}/${totalEffects} · 켜면 약초·사냥 재료·와인의 모든 효과가 밝혀져 가능한 조합 추천도 해금됩니다. 끄면 기본 재료 효과 지식을 지웁니다.`;
    knowledgeCopy.appendChild(knowledgeHint);knowledgeRow.append(knowledgeInput,knowledgeCopy);knowledge.append(knowledgeTitle,knowledgeRow);page.appendChild(knowledge);
    const note=document.createElement('p');note.className='wce-form-note';note.textContent='현재 마나의 상한은 동조율에 따라 30~100입니다. 시전 횟수와 진행 중인 마법 효과는 편집하지 않습니다.';page.appendChild(note);
  }

  function stateWithAlchemyKnowledge(state,enabled){
    const current=state.stillroom??{ingredients:{},cups:[],known:{},brewsToday:0,dosesToday:{}};
    const known={...(current.known??{})};
    for(const[id,effects]of Object.entries(ALCHEMY_EFFECTS)){
      const existing=Array.isArray(known[id])?known[id]:[];
      const next=enabled?[...new Set([...existing,...effects])]:existing.filter(effect=>!effects.includes(effect));
      if(next.length)known[id]=next;else delete known[id];
    }
    return{...state,stillroom:{...current,known}};
  }

  function staffNumberFields(body,kind,id,group,defs,values,min,max){
    const title=document.createElement('h4');title.className='wce-staff-heading';title.textContent={stats:'현재 상태',attributes:'능력치',tendencies:'행동 성향',affinities:'행동 선호도'}[group]??group;body.appendChild(title);
    const grid=document.createElement('div');grid.className='wce-staff-fields';
    for(const def of defs||[]){const key=def[0],label=def[1],row=document.createElement('label'),input=document.createElement('input');row.className='wce-staff-field';row.append(document.createTextNode(label));input.type='number';input.min=String(min);input.max=String(max);input.step=group==='affinities'?'.1':'1';input.required=true;input.value=String(values?.[key]??0);input.dataset.original=input.value;input.dataset.staffKind=kind;input.dataset.staffId=id;input.dataset.staffGroup=group;input.dataset.staffKey=key;row.appendChild(input);grid.appendChild(row)}
    body.appendChild(grid);
  }
  function staffTraitFields(body,kind,id,group,defs,values){
    const title=document.createElement('h4');title.className='wce-staff-heading';title.textContent=group==='traits'?'기본 성격 특성':'숨은 특성';body.appendChild(title);
    const grid=document.createElement('div');grid.className='wce-staff-traits';const selected=new Set(Array.isArray(values)?values:[]);
    for(const def of defs||[]){const key=def[0],label=def[1],row=document.createElement('label'),input=document.createElement('input');input.type='checkbox';input.checked=Array.isArray(values)?selected.has(key):!!values?.[key];input.dataset.original=String(input.checked);input.dataset.staffKind=kind;input.dataset.staffId=id;input.dataset.staffGroup=group;input.dataset.staffKey=key;row.append(input,document.createTextNode(label));grid.appendChild(row)}body.appendChild(grid);
  }
  function staffCard(kind,item,schema,index){
    const card=document.createElement('details');card.className='wce-staff-card';card.open=false;const summary=document.createElement('summary');summary.textContent=`${item.name} · ${kind==='companions'?'Companions':'Brothel'}`;const body=document.createElement('div');body.className='wce-staff-body';
    const meta=document.createElement('p');meta.className='wce-staff-meta';meta.textContent=kind==='companions'?`${item.gender==='male'?'남성':'여성'} · ID ${item.id}`:`등급 ${item.hireTier??'미기록'} · 오늘 서비스 급료 ${item.wageLedger?.serviceWages??0}g · 미지급 ${item.wageLedger?.unpaid??0}g`;body.appendChild(meta);
    const identity=document.createElement('div');identity.className='wce-staff-fields';const personality=document.createElement('label'),select=document.createElement('select');personality.className='wce-staff-field';personality.append(document.createTextNode('성격'));for(const[id,label]of schema.personalities||[]){const option=document.createElement('option');option.value=id;option.textContent=label;option.selected=id===item.personality;select.appendChild(option)}select.dataset.original=select.value;select.dataset.staffKind=kind;select.dataset.staffId=item.id;select.dataset.staffGroup='root';select.dataset.staffKey='personality';personality.appendChild(select);identity.appendChild(personality);
    if(kind==='companions'){const skillLabel=document.createElement('label'),skill=document.createElement('input');skillLabel.className='wce-staff-field';skillLabel.append(document.createTextNode('일솜씨'));skill.type='number';skill.min='0';skill.max='100';skill.step='.1';skill.required=true;skill.value=String(item.skill??0);skill.dataset.original=skill.value;skill.dataset.staffKind=kind;skill.dataset.staffId=item.id;skill.dataset.staffGroup='root';skill.dataset.staffKey='skill';skillLabel.appendChild(skill);identity.appendChild(skillLabel)}body.appendChild(identity);
    if(kind==='companions'){staffNumberFields(body,kind,item.id,'stats',schema.stats,item.stats,0,100);staffNumberFields(body,kind,item.id,'attributes',schema.attributes,item.attributes,0,100);staffNumberFields(body,kind,item.id,'affinities',schema.affinities,item.affinities,-2,2);staffTraitFields(body,kind,item.id,'latentTraits',schema.traits,item.latentTraits)}
    else{for(const[group,defs]of Object.entries(schema.numeric||{}))staffNumberFields(body,kind,item.id,group,defs,item[group],0,100);staffNumberFields(body,kind,item.id,'affinities',schema.affinities,item.affinities,-2,2);staffTraitFields(body,kind,item.id,'traits',schema.traits,item.traits);staffTraitFields(body,kind,item.id,'latentTraits',schema.latentTraits,item.latentTraits)}
    card.append(summary,body);return card;
  }
  function renderStaffEditor(page){
    const staff=editorDraft?.staff;page.replaceChildren();const note=document.createElement('p');note.className='wce-form-note';note.textContent='기존 관계·기억·접객·임신·수입 기록은 보존하고 수치와 체크형 특성만 바꿉니다. 고용 등급과 급료 장부는 편집하지 않습니다.';page.appendChild(note);
    let count=0;for(const[kind,title,data]of [['companions','Companions 동료',staff?.companions],['brothel','Brothel 직원',staff?.brothel]]){const roster=kind==='companions'?data?.people:data?.workers;if(!roster?.length)continue;const section=document.createElement('section');section.className='wce-staff-group';const heading=document.createElement('h3');heading.textContent=title;section.appendChild(heading);roster.forEach((item,index)=>section.appendChild(staffCard(kind,item,data.schema,index)));page.appendChild(section);count+=roster.length}
    if(!count){const empty=document.createElement('p');empty.className='wce-placeholder';empty.textContent='현재 편집할 Companions 동료나 Brothel 직원이 없습니다.';page.appendChild(empty)}
  }
  function applyStaffPage(state,page){
    const patches=new Map();for(const input of page.querySelectorAll('[data-staff-kind]')){const changed=input.type==='checkbox'?String(input.checked)!==input.dataset.original:input.value!==input.dataset.original;if(!changed)continue;if(input.type!=='checkbox'&&(input.value===''||!input.checkValidity()||!Number.isFinite(Number(input.value))&&input.tagName!=='SELECT')){input.reportValidity();input.focus();return null}
      const mapKey=`${input.dataset.staffKind}:${input.dataset.staffId}`,entry=patches.get(mapKey)??{kind:input.dataset.staffKind,id:input.dataset.staffId,patch:{}},group=input.dataset.staffGroup,key=input.dataset.staffKey,value=input.type==='checkbox'?input.checked:input.tagName==='SELECT'?input.value:Number(input.value);if(group==='root')entry.patch[key]=value;else(entry.patch[group]??={})[key]=value;patches.set(mapKey,entry)}
    let next=state,changed=false;const apis=staffApis(),brothel=[];
    for(const entry of patches.values()){if(entry.kind==='companions'){if(!apis.companions?.editorApply)throw Error('Companions 편집 연결을 찾지 못했습니다.');next=apis.companions.editorApply(next,entry.id,entry.patch);changed=true}else{brothel.push({id:entry.id,patch:entry.patch});changed=true}}
    if(editorDraft){editorDraft.state=next;editorDraft.staff.brothelPatches=brothel}return{state:next,changed};
  }

  function renderActiveTab(){
    if(typeof document==='undefined')return;
    const modal=document.getElementById('wc2-customer-editor');if(!modal)return;
    modal.querySelectorAll('[data-wce-tab]').forEach(button=>button.classList.toggle('active',button.dataset.wceTab===activeTab));
    modal.querySelectorAll('[data-wce-page]').forEach(page=>page.classList.toggle('active',page.dataset.wcePage===activeTab));
    modal.querySelectorAll('[data-wce-undo]').forEach(button=>{button.disabled=!lastBackup});
    if(activeTab==='customers'){
      if(modal.dataset.wceCustomersRendered!=='1'){renderSettings();renderFlowSettings()}
      return;
    }
    const page=modal.querySelector(`[data-wce-form="${activeTab}"]`),state=visibleState();
    if(!page||!state)return;
    if(page.dataset?.wceRendered==='1')return;
    page.replaceChildren();
    if(activeTab==='tavern')renderTavernEditor(page,state);
    else if(activeTab==='wife')renderWifeEditor(page,state);
    else if(activeTab==='magic')renderMagicEditor(page,state);
    else if(activeTab==='staff')renderStaffEditor(page,state);
    if(page.dataset)page.dataset.wceRendered='1';
  }

  function invalidateRenderedPages(){
    const modal=typeof document==='undefined'?null:document.getElementById('wc2-customer-editor');
    if(!modal)return;
    modal.querySelectorAll('[data-wce-form]').forEach(page=>{if(page.dataset)delete page.dataset.wceRendered});
    if(modal.dataset)delete modal.dataset.wceCustomersRendered;
  }

  function selectTab(tab){
    if(!Object.hasOwn(EDITOR_TABS,tab))return false;
    activeTab=tab;renderActiveTab();return true;
  }

  function applyEditorPage(tab){
    if(!['tavern','wife','staff','magic'].includes(tab))return false;
    const state=visibleState(),modal=document.getElementById('wc2-customer-editor'),page=modal?.querySelector(`[data-wce-form="${tab}"]`);
    if(!state||!page)return false;
    if(tab==='staff'){try{const result=applyStaffPage(state,page);return result===null?null:result.changed}catch(error){showToast(error?.message||'직원 편집값을 적용할 수 없습니다.');return null}}
    let next=state,changed=false,magicTouched=false;
    const skillTouched=[];
    const previousOptions={...options};
    const nextOptions={...visibleOptions()};
    for(const input of page.querySelectorAll('[data-edit-path]')){
      if(input.value===input.dataset.original)continue;
      if(input.value===''||!input.checkValidity()||!Number.isFinite(Number(input.value))){input.reportValidity();input.focus();return null}
      const path=JSON.parse(input.dataset.editPath),value=Number(input.value);
      if(readPath(next,path)!==value){next=writePath(next,path,value);changed=true}
      if(path[0]==='characters'&&path[2]==='latitude'&&path[3]==='byCategory'){
        const side=path.at(-1).startsWith('encouragement')?'encouragement':'restriction';
        const entryPath=path.slice(0,-1),row=readPath(next,entryPath),day=state.day??1;
        const entry={encouragement:0,restriction:0,encouragementClarity:0,restrictionClarity:0,encouragementLastDay:day,restrictionLastDay:day,...row};
        entry[side+'LastDay']=day;entry.sources={...row.sources,[side]:[...new Set([...(Array.isArray(row.sources?.[side])?row.sources[side]:[]),'editor'])]};
        next=writePath(next,entryPath,entry);
      }
      if(path[0]==='player'&&path[1]==='magic')magicTouched=true;
      if(path[0]==='player'&&path[1]==='skills'&&path.length===3)skillTouched.push(path[2]);
    }
    if(skillTouched.length){
      const practice={...(next.player?.skillPractice??{})};
      for(const skill of skillTouched)practice[skill]=state.slot??0;
      next=writePath(next,['player','skillPractice'],practice);
    }
    if(tab==='wife'){
      const selected=applyPre7Selections(next,page);if(!selected)return null;if(selected!==next){next=selected;changed=true;}
      const id=state.primaryCharacterId,wife=next.characters?.[id];if(!wife)return false;
      const ownInputs=[...page.querySelectorAll('[data-trait-own]')],seenInputs=[...page.querySelectorAll('[data-trait-seen]')];
      if([...ownInputs,...seenInputs].some(input=>String(input.checked)!==input.dataset.original)){
        const known=new Set(Object.keys(WIFE_TRAITS));
        const oldOwn=(wife.latentTraits??[]).filter(key=>!known.has(key)),oldSeen=(wife.noticedLatentTraits??[]).filter(key=>!known.has(key));
        const own=[...new Set([...oldOwn,...ownInputs.filter(input=>input.checked).map(input=>input.dataset.traitOwn)])];
        const seen=[...new Set([...oldSeen,...seenInputs.filter(input=>input.checked&&own.includes(input.dataset.traitSeen)).map(input=>input.dataset.traitSeen)])];
        next=writePath(next,['characters',id,'latentTraits'],own);
        next=writePath(next,['characters',id,'noticedLatentTraits'],seen);
        changed=true;
      }
      for(const input of page.querySelectorAll('[data-husband-feeling]')){
        if(input.value===input.dataset.original)continue;
        if(input.value===''||!input.checkValidity()){input.reportValidity();input.focus();return null}
        const value=Number(input.value),key=input.dataset.husbandFeeling;
        const feelings=(readPath(next,['characters',id,'feelings'])??[]).filter(item=>!(item?.emotion===key&&item?.target?.kind==='husband'));
        if(value>0)feelings.push({emotion:key,intensity:value,source:'addon_editor:husband_feeling',triggeredAtSlot:state.slot??0,expiresAtSlot:(state.slot??0)+10000,target:{kind:'husband'},class:'persistent'});
        next=writePath(next,['characters',id,'feelings'],feelings);changed=true;
      }
    }
    if(tab==='magic'){
      const book=page.querySelector('[data-magic-book]'),assay=page.querySelector('[data-magic-assay]'),infinite=page.querySelector('[data-infinite-mana]'),knowledge=page.querySelector('[data-alchemy-known]');
      if(book&&assay&&(String(book.checked)!==book.dataset.original||String(assay.checked)!==assay.dataset.original)){
        let magic=next.player?.magic??{grimoireFound:false,understanding:0,attunement:0,mana:{current:30},spells:{}};
        const spells={...magic.spells};
        if(assay.checked&&!spells.assay_purse)spells.assay_purse={proficiency:8,casts:0};
        if(!assay.checked)delete spells.assay_purse;
        magic={...magic,grimoireFound:book.checked||assay.checked,spells};
        next=writePath(next,['player','magic'],magic);changed=true;
      }
      if(infinite&&infinite.checked!==nextOptions.infiniteMana){nextOptions.infiniteMana=infinite.checked;changed=true}
      if(knowledge&&String(knowledge.checked)!==knowledge.dataset.original){next=stateWithAlchemyKnowledge(next,knowledge.checked);changed=true}
      if(magicTouched||nextOptions.infiniteMana){
        const magic=next.player?.magic;if(magic){
          const limit=maxMana(magic.attunement);
          const current=nextOptions.infiniteMana?limit:clampNumber(magic.mana?.current,0,limit,0);
          if(magic.mana?.current!==current){next=writePath(next,['player','magic','mana','current'],current);changed=true}
        }
      }
    }
    if(editorDraft){editorDraft.state=next;editorDraft.options=nextOptions;return changed}
    if(!changed){showToast('변경된 항목이 없습니다.');return false}
    options=nextOptions;saveOptions();syncFlowOptions();
    if(next!==state){commitState(next);lastBackup.options=previousOptions}
    else lastBackup={state,options:previousOptions};
    invalidateRenderedPages();renderActiveTab();showToast(`${EDITOR_TABS[tab]} 설정을 적용했습니다.`);return true;
  }

  function applyAllChanges(){
    const modal=document.getElementById('wc2-customer-editor');
    if(!modal||!editorDraft)return false;
    if(editorDraft.stale){showToast('게임 상태가 편집 중 바뀌었습니다. 창을 닫고 다시 열어 주세요.');return false}
    rememberCustomerEditor();
    for(const tab of ['tavern','wife','staff','magic']){
      const page=modal.querySelector(`[data-wce-form="${tab}"]`);
      if(page?.dataset.wceRendered!=='1')continue;
      if(applyEditorPage(tab)===null){selectTab(tab);return false}
    }
    let next=editorDraft.state;
    let nextOptions={...editorDraft.options};
    const customerPage=modal.querySelector('[data-wce-page="customers"]');
    if(customerPage){
      const wallet=customerPage.querySelector('[data-wce-multiplier-number]');
      const share=customerPage.querySelector('[data-wce-custom-share]');
      for(const input of [wallet,share,...customerPage.querySelectorAll('[data-wce-flow]')]){
        if(!input||input.disabled)continue;
        if(input.value===''||!input.checkValidity()){selectTab('customers');input.reportValidity();input.focus();return false}
      }
      if(wallet){
        const multiplier=normalizeMultiplier(wallet.value),ratio=multiplier/options.walletMultiplier;
        if(multiplier!==options.walletMultiplier){
          next={...next,customers:(next.customers??[]).map(customer=>Number.isFinite(Number(customer.walletGold))?{...customer,walletGold:clampInteger(Number(customer.walletGold)*ratio,0,999999,0)}:customer)};
          nextOptions.walletMultiplier=multiplier;
        }
      }
      if(share){
        const roster=editorRoster(next),value=clampInteger(share.value,0,100,roster.share);
        if(value!==roster.share)next={...next,editorCustomers:{...roster,share:value}};
      }
      if(api?.customerFlow?.version===1){
        const flow={};
        customerPage.querySelectorAll('[data-wce-flow]').forEach(input=>{flow[input.dataset.wceFlow]=input.value});
        nextOptions=normalizeOptions({...nextOptions,...flow});
      }
    }
    for(const[key,patch]of editorDraft.customerPatches){
      if(!validateCustomerPatch(key,patch)){selectTab('customers');selectedKey=key;renderSettings();return false}
      const updated=customerStateWithPatch(next,key,patch);
      if(!updated){selectTab('customers');selectedKey=key;renderSettings();return false}
      next=updated;
    }
    const beforeState=currentState(),beforeOptions={...options};
    const optionsChanged=Object.keys(nextOptions).some(key=>nextOptions[key]!==options[key]);
    const brothelPatches=editorDraft.staff?.brothelPatches??[],brothelApi=staffApis().brothel;
    if(next===beforeState&&!optionsChanged&&!brothelPatches.length){showToast('변경된 항목이 없습니다.');return false}
    let brothelBackup=null;
    if(brothelPatches.length){try{const result=brothelApi?.editorApply?.(brothelPatches,editorDraft.staff?.brothel?.revision);if(!result)throw Error('Brothel 편집 연결을 찾지 못했습니다.');brothelBackup={api:brothelApi,snapshot:result.snapshot,afterRevision:result.afterRevision}}
      catch(error){selectTab('staff');showToast(error?.message||'창관 직원 자료를 적용할 수 없습니다.');return false}}
    if(next!==beforeState){commitState(next);lastBackup.options=beforeOptions}
    else lastBackup={state:beforeState,options:beforeOptions};
    if(brothelBackup)lastBackup.brothel=brothelBackup;
    options=nextOptions;saveOptions();syncFlowOptions();
    const customerEditor=modal.querySelector('[data-wce-detail]');
    if(customerEditor)customerEditor.dataset.customerDirty='0';
    editorDraft=newEditorDraft();
    invalidateRenderedPages();
    if(modal.querySelector('[data-wce-multiplier-number]')){renderSettings();renderFlowSettings()}
    renderActiveTab();
    showToast('모든 변경을 한 번에 적용했습니다.');
    return true;
  }

  function maintainInfiniteMana(root){
    if(internalWrite||!options.infiniteMana)return;
    const state=currentState(),magic=state?.player?.magic;
    if(!magic||magic.mana?.current===maxMana(magic.attunement))return;
    commitState(writePath(state,['player','magic','mana','current'],maxMana(magic.attunement)),false);
  }

  function openSettings(){
    ensureStyles();
    let modal=document.getElementById('wc2-customer-editor');
    if(!modal){
      modal=document.createElement('div');
      modal.id='wc2-customer-editor';
      modal.innerHTML=`<div class="wce-card" role="dialog" aria-modal="true" aria-labelledby="wce-title">
        <div class="wce-head"><div><h2 id="wce-title">게임 에디터</h2><div class="wce-subtitle">Wayward 2026-11-01 · Editor 1.2.3</div></div><button type="button" class="wce-close" aria-label="닫기">×</button></div>
        <nav class="wce-nav" aria-label="게임 에디터 항목">${Object.entries(EDITOR_TABS).map(([key,label])=>`<button type="button" data-wce-tab="${key}">${label}</button>`).join('')}</nav>
        ${['tavern','wife','staff','magic'].map(key=>`<section class="wce-page" data-wce-page="${key}"><div class="wce-form" data-wce-form="${key}"></div></section>`).join('')}
        <section class="wce-page" data-wce-page="customers">
          <section class="wce-wallet"><div class="wce-wallet-label">손님 소지금 배율<small class="wce-param-hint">새 손님의 지갑과 현재 손님의 남은 소지금에 곱합니다 · 범위 0.1~10배</small></div><div class="wce-multiplier"><input data-wce-multiplier-range type="range" min="0.1" max="10" step="0.1"><input data-wce-multiplier-number type="number" min="0.1" max="10" step="0.1" inputmode="decimal" required></div></section>
          <div class="wce-custom-bar"><button type="button" class="wce-flow-reset" data-wce-add-custom>사용자 손님 추가</button><label>신규 일반 방문 중 사용자 손님 비중 <input data-wce-custom-share type="number" min="0" max="100" step="1" required> %<small class="wce-param-hint">새 일반 손님이 사용자 프로필에서 뽑힐 확률 · 범위 0~100%</small></label></div>
          <div class="wce-main"><aside class="wce-sidebar"><div class="wce-tools"><input data-wce-search type="search" placeholder="이름, 직업, 배경 검색" autocomplete="off"><div class="wce-tabs"><button type="button" class="wce-tab" data-wce-filter="all">전체</button><button type="button" class="wce-tab" data-wce-filter="current">현재</button><button type="button" class="wce-tab" data-wce-filter="history">기록</button><button type="button" class="wce-tab" data-wce-filter="custom">사용자</button></div></div><div class="wce-list" data-wce-list></div></aside><main class="wce-editor" data-wce-detail></main></div>
        </section><div class="wce-global-actions"><span>탭을 옮겨도 입력이 유지됩니다. 마지막에 한 번 적용하세요.</span><button type="button" class="wce-flow-reset" data-wce-undo>직전 적용 되돌리기</button><button type="button" class="wce-save" data-wce-apply-all>모든 변경 적용</button></div></div>`;
      modal.addEventListener('click',event=>{
        if(event.target===modal){closeSettings();return}
        const tabButton=event.target.closest?.('[data-wce-tab]');
        if(tabButton){selectTab(tabButton.dataset.wceTab);return}
        if(event.target.closest?.('[data-wce-apply-all]')){applyAllChanges();return}
        if(event.target.closest?.('[data-wce-undo]')){undoEditorChange();return}
        if(event.target.closest?.('[data-wce-add-custom]')){stageAddCustomCustomer();return}
        const removeCustom=event.target.closest?.('[data-remove-custom]');
        if(removeCustom){stageRemoveCustomCustomer(Number(removeCustom.dataset.removeCustom));return}
        const resetCustomer=event.target.closest?.('[data-reset-customer]');
        if(resetCustomer){stageResetCustomerOverride(resetCustomer.dataset.resetCustomer);return}
        const customerButton=event.target.closest?.('[data-customer-key]');
        if(customerButton){selectedKey=customerButton.dataset.customerKey;renderSettings();return}
        const filterButton=event.target.closest?.('[data-wce-filter]');
        if(filterButton){filterMode=filterButton.dataset.wceFilter;renderSettings();return}
      });
      const markCustomerDirty=event=>{
        const editor=event.target.closest?.('[data-wce-detail]');
        if(editor&&event.target.matches?.('[data-field], [data-persona-tag]'))editor.dataset.customerDirty='1';
      };
      modal.addEventListener('input',markCustomerDirty);
      modal.addEventListener('change',markCustomerDirty);
      modal.querySelector('.wce-close').addEventListener('click',closeSettings);
      modal.querySelector('.wce-wallet').insertAdjacentElement('afterend',createFlowSettings());
      const range=modal.querySelector('[data-wce-multiplier-range]');
      const number=modal.querySelector('[data-wce-multiplier-number]');
      range.addEventListener('input',()=>{number.value=Number(range.value).toFixed(1)});
      number.addEventListener('input',()=>{range.value=String(normalizeMultiplier(number.value))});
      modal.querySelector('[data-wce-search]').addEventListener('input',event=>{searchText=event.target.value;renderSettings()});
      document.body.appendChild(modal);
      beginEditSession();
      renderSettings();
      renderFlowSettings();
    }
    renderActiveTab();
  }

  function closeSettings(){document.getElementById('wc2-customer-editor')?.remove();editorDraft=null}

  function onStoreChange(root,previous){
    if(internalWrite)return;
    if(previous?.state!==root?.state){
      lastBackup=null;
      if(editorDraft&&!editorDraft.stale){editorDraft.stale=true;showToast('게임 상태가 바뀌었습니다. 편집 창을 다시 열어 주세요.')}
    }
    maintainInfiniteMana(root);
    if(document.getElementById('wc2-customer-editor'))renderActiveTab();
    scheduleUI();
  }

  function init(){
    if(api||!globalThis.__WAYWARD_ADDON_API__)return false;
    const bridge=globalThis.__WAYWARD_ADDON_API__;
    if(!bridge.ue?.getState||!bridge.ue?.setState||!bridge.ue?.subscribe||typeof bridge.ue.getState().dispatch!=='function')return false;
    api=bridge;
    syncFlowOptions();
    globalThis.__WAYWARD_EDITOR_ADDON_LOADED__=true;
    installCustomerArrivalHook();
    if(typeof document!=='undefined'){
      ensureStyles();
      unsubscribe=api.ue.subscribe(onStoreChange);
      const observer=new MutationObserver(scheduleUI);
      observer.observe(document.body,{childList:true,subtree:true});
      document.addEventListener('keydown',event=>{
        if(event.key==='Escape'&&document.getElementById('wc2-customer-editor')){
          event.preventDefault();
          event.stopImmediatePropagation();
          closeSettings();
        }
      },true);
      scheduleUI();
    }
    globalThis.__waywardEditor=globalThis.__waywardCustomerEdit={
      openSettings,
      getOptions:()=>({...options}),
      getCustomers:()=>getEntries().map(entry=>({key:entry.key,kind:entry.kind,name:entry.item.name})),
      setWalletMultiplier,
      setFlowOptions,
      saveCustomer,
      resetCustomerOverride,
      addCustomCustomer,
      removeCustomCustomer,
      setCustomShare,
      applyEditorPage,
      applyAllChanges,
      beginEditSession,
      stageCustomerPatch,
      undoEditorChange,
      selectTab,
    };
    return true;
  }

  if(!init()){
    let attempts=0;
    const timer=setInterval(()=>{
      attempts++;
      if(init()||attempts>240)clearInterval(timer);
    },250);
  }
})();

  },
});
