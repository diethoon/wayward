// Local vanilla module comparison; never executes a game or edits reference inputs.
import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';
import {parseModule,topLevel,inlinePackedData,MODULE_TAG} from '../../../../MCP/lib/vendor/lib.mjs';
const keys=n=>n?.properties?.map(p=>p.key?.name??p.key?.value).filter(Boolean)??[];
function walk(n,visit){if(!n||typeof n!=='object')return;visit(n);for(const v of Object.values(n))if(Array.isArray(v))v.forEach(x=>walk(x,visit));else if(v&&typeof v==='object')walk(v,visit);}
function read(file,names){
 const data=fs.readFileSync(file),html=data.toString(),at=html.indexOf(MODULE_TAG)+MODULE_TAG.length,source=inlinePackedData(html.slice(at,html.indexOf('</script>',at))),ast=parseModule(source),decls=topLevel(ast),out={file,sha256:crypto.createHash('sha256').update(data).digest('hex')};
 for(const [label,name]of Object.entries(names)){const d=decls.find(d=>d.name===name);assert.ok(d,name);let fields;if(label==='character'){walk(d.node,n=>{if(n.type==='ReturnStatement'&&n.argument?.type==='ObjectExpression')fields=keys(n.argument);});}else if(d.init?.type==='ObjectExpression')fields=keys(d.init);else if(d.init?.type==='ArrayExpression')fields=d.init.elements.map(n=>{const props=Object.fromEntries((n.properties??[]).map(p=>[p.key?.name??p.key?.value,p.value]));return{id:props.id?.value,released:props.released?.type==='UnaryExpression'?props.released.argument.value===0:props.released?.value};});out[label]={declaration:name,fields};}
 const propertyNames=new Set();walk(ast,n=>{if(n.type==='Property'&&!n.computed){const key=n.key.name??n.key.value;if(typeof key==='string'&&/^[a-zA-Z][a-zA-Z0-9]{3,}$/.test(key))propertyNames.add(key);}});return{out,propertyNames};
}
const old=read('wayward-wml-ko_old/Wayward_WML_ko.html',{character:'q3e',decisionCategories:'bo',policyDefaults:'p4',traits:'_h',actions:'Oo'});
const current=read('Wayward_WML_ko.html',{character:'BQe',decisionCategories:'Lo',policyDefaults:'s_',traits:'Cd',actions:'on',startRelations:'E$',tipShares:'K$'});
const diff={};for(const key of ['character','decisionCategories','policyDefaults','traits','actions']){const a=old.out[key].fields,b=current.out[key].fields;diff[key]={added:b.filter(k=>!a.includes(k)),removed:a.filter(k=>!b.includes(k))};}
assert.deepEqual(diff.character.added,['raising']);assert.deepEqual(diff.decisionCategories.added,['touch_breasts','touch_under_skirt']);assert.equal(current.out.decisionCategories.fields.length,31);
const result={old:old.out,current:current.out,diff,newPropertyNames:[...current.propertyNames].filter(k=>!old.propertyNames.has(k)).sort(),note:'Property-name differences include UI/text metadata, not just save fields. Reviewed persistent editor fields and exclusions are documented in README.md. Packed base module only; no mod execution.'};
fs.writeFileSync(new URL('./pre7-audit.json',import.meta.url),JSON.stringify(result,null,2));console.log(JSON.stringify(diff));
