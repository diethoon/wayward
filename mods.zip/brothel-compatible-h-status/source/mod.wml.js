// 호환성 패치 기준: brothel 3.10.0 / h-status 1.7.6 (개정 기준, 버전 번호에 따른 실행 제한 없음)
WML.define({
  tags: ["content","h-scene"],
  id: 'brothel-compatible-h-status',
  author: "Hina_Lover",
  name: '창관 + H_Status 기록',
  version: "1.1.2",
  game: "2026-11-01",
  lang: 'ko',
  description: '직원별 H_Status 신체 상태·평가·이미지와 서비스 기록을 각 상세보기에 표시합니다.',
  requires: ['brothel', 'h-status'],
  /* requiresVersion: { brothel: '>=3.10.0', 'h-status': '>=1.6.0' }, */
  loadAfter: ['brothel', 'h-status'],
  conflicts: [],
  symbols: {
    "brothelHStatusStoreSelector": {"raw":{"2026-11-01":"Rre"}},
    "brothelHStatusReactDOM": {"raw":{"2026-11-01":"Are"}},
    "brothelHStatusCharacter": {"raw":{"2026-11-01":"RZe"}}
  },
  setup(api) {
    const brothel = globalThis.__waywardBrothelPublic;
    const hStatus = globalThis.__waywardSituationEventMod;
    if (!brothel?.getConfig || !hStatus?.getStats) throw Error('창관과 H_Status를 먼저 불러와야 합니다.');
    const stages = ['groping', 'intimate', 'handjob_patron', 'blowjob_patron', 'titfuck_patron', 'sex_patron'];
    const labels = { groping: '접촉', intimate: '친밀 서비스', handjob_patron: '손 서비스', blowjob_patron: '구강 서비스', titfuck_patron: '가슴 서비스', sex_patron: '성관계' };
    const fields = { handjob_patron: 'manualGiven', blowjob_patron: 'oralGiven', titfuck_patron: 'otherSex', sex_patron: 'vaginalSex' };
    const eventKeys = ['manualGiven', 'manualReceived', 'oralGiven', 'oralReceived', 'vaginalSex', 'analSex', 'otherSex', 'patronMolestation'];
    let writing = false, scheduled = false;
    const roots = new Map(), openWorkers = new Set();
    const React = api.fn('React'), ReactDOM = api.fn('brothelHStatusReactDOM');
    const Scope = React.createContext(null), jsx = api.fn('jsx').jsx;
    const copy = value => value == null ? value : structuredClone(value);
    const employeeKey = worker => worker.relationshipId || `legacy:${worker.id}`;
    function BrothelHStatus_공백상태(day) {
      return { version: hStatus.getStats()?.version, totalSexActCount: 0, eventCounts: Object.fromEntries(eventKeys.map(key => [key, 0])),
        fluidState: {}, jewelryState: {}, completedActIds: [], dailyInternalEjaculationCount: 0, dailyCountDay: day,
        hypnosis: 0, crest: 0 };
    }
    function BrothelHStatus_인물읽기(state, worker) {
      const saved = state.mods?.[api.id]?.workers?.[worker.id];
      const related = brothel.patronRelationships?.(state, worker.id);
      const profiles = api.fn('wives');
      const selectedProfile = profiles.find(item => item.shortname === worker.portrait);
      const profile = selectedProfile || profiles[0];
      const base = saved?.employeeKey === employeeKey(worker) && saved.character || related?.character ||
        api.fn('brothelHStatusCharacter')(profile, { id: worker.id, name: worker.name, day: state.day, commitment: 0 });
      return { ...base, id: worker.id, name: worker.name, gender: 'female', age: Math.max(18, Number(base.age) || 25),
        archetypeId: selectedProfile?.id || `brothel_${worker.portrait}`,
        generatedArchetype: { ...base.generatedArchetype, shortname: worker.portrait, id: selectedProfile?.id || `brothel_${worker.portrait}` },
        stats: { ...base.stats, ...worker.stats }, attributes: { ...base.attributes, ...worker.attributes, libido: worker.tendencies?.libido ?? 50 },
        affinities: { ...base.affinities, ...worker.affinities },
        latentTraits: Object.keys(worker.latentTraits || {}).filter(key => worker.latentTraits[key]),
        relationship: { ...base.relationship, trust: brothel.playerRelationship?.(state, worker.id)?.trust ?? 30 },
        situationStats: base.situationStats || BrothelHStatus_공백상태(state.day),
        intimateHistory: base.intimateHistory || [] };
    }
    function BrothelHStatus_완료기록(state, workerId, stage, partner, options = {}) {
      if (!fields[stage]) return state;
      const worker = brothel.getConfig()?.workers.find(item => item.id === workerId && item.enabled);
      if (!worker || options.employeeKey && options.employeeKey !== employeeKey(worker)) return state;
      const character = BrothelHStatus_인물읽기(state, worker), stats = character.situationStats;
      const marker = options.marker || `${state.day}:${state.slot}:${stage}:${partner?.id || partner?.name || 'player'}`;
      if ((stats.completedActIds || []).includes(marker)) return state;
      const actId = { handjob_patron: 'handjob', blowjob_patron: 'blowjob', titfuck_patron: 'titfuck', sex_patron: 'sex' }[stage];
      const player = options.player === true;
      const dimensions = player ? hStatus.playerPenis?.() : hStatus.patronPenis?.(partner || {});
      const history = { actId, partnerType: player ? 'player' : 'patron', partner: player ? 'player' : partner?.name || '손님',
        partnerId: partner?.id, day: state.day, slot: state.slot, reception: 'paid',
        ...(Number.isFinite(options.pleasure) ? { herPleasure: options.pleasure } : {}),
        ...(dimensions && stage === 'sex_patron' ? { penisLengthCm: dimensions.lengthCm, penisGirthCm: dimensions.girthCm } : {}) };
      const projected = { ...state, primaryCharacterId: worker.id, characters: { [worker.id]: character }, relationships: [],
        patronRecords: brothel.patronRelationships?.(state, worker.id)?.records || [] };
      const recorded = api.fn('recordIntimateHistory')(projected, history).characters[worker.id];
      const nextCharacter = { ...recorded, situationStats: { ...stats,
        totalSexActCount: (stats.totalSexActCount || 0) + 1,
        eventCounts: { ...stats.eventCounts, [fields[stage]]: (stats.eventCounts?.[fields[stage]] || 0) + 1 },
        completedActIds: [...(stats.completedActIds || []), marker].slice(-512) } };
      const old = state.mods?.[api.id] || {};
      const previous = old.workers?.[worker.id] || {};
      return { ...state, mods: { ...state.mods, [api.id]: { ...old, workers: { ...old.workers,
        [worker.id]: { ...previous, employeeKey: employeeKey(worker), trackedSince: previous.trackedSince || state.day, character: nextCharacter } } } } };
    }
    // Record each paid stage only after its real task deadline and transition. The snapshot is
    // local to this call, so simulations/undo/load cannot leak deferred events into another state.
    function BrothelHStatus_진행기록(invoke, state, ...args) {
      const snapshots = [];
      for (const worker of brothel.getConfig()?.workers || []) {
        if (!brothel.getConfig().enabled || state.gameOver || !['service', 'last_call'].includes(state.phase)) break;
        const runtime = brothel.getRuntime().get(worker.id), scene = runtime?.interaction;
        const customer = state.customers?.find(item => item.id === scene?.customerId);
        if (!worker.enabled || !fields[scene?.stage] || runtime.externalOwner || state.mods?.brothel?.assignments?.[worker.id]
          || !customer || ['gone', 'leaving'].includes(customer.status)) continue;
        snapshots.push({ workerId: worker.id, employeeKey: employeeKey(worker), stage: scene.stage,
          due: runtime.busyUntil, index: scene.index, partner: copy(customer),
          marker: ['natural', worker.id, employeeKey(worker), scene.customerId, scene.stage, runtime.busyUntil].join(':') });
      }
      let result = invoke(state, ...args);
      for (const old of snapshots) {
        const runtime = brothel.getRuntime().get(old.workerId), scene = runtime?.interaction;
        const customer = result.customers?.find(item => item.id === old.partner.id);
        if (result.slot < old.due || result.slot - old.due > 60 || state.pendingEvent ||
          !customer || ['gone', 'leaving'].includes(customer.status) ||
          scene?.customerId === old.partner.id && scene.stage === old.stage && scene.index === old.index) continue;
        result = BrothelHStatus_완료기록(result, old.workerId, old.stage, old.partner, old);
      }
      return result;
    }
    for (const symbol of ['minuteTick', 'worldTick']) api.hook(symbol, { priority: -1000000, around: BrothelHStatus_진행기록 });
    const naturalTick = brothel.tick;
    brothel.tick = (state, ...args) => BrothelHStatus_진행기록(naturalTick, state, ...args);
    // WML custom actions bypass reduceGameAction. Read the real session's recorded flag during
    // store synchronization, including the final history entry when a session ends in the same call.
    api.actions.observe(({ owner }) => { if (owner === 'brothel') BrothelHStatus_저장변경처리하기(); });
    function BrothelHStatus_출장완료(state, id, cancel = false) {
      const data = state.mods?.[api.id], run = data?.external?.[id];
      if (!run) return state;
      let next = !cancel && state.mods?.brothel?.assignments?.[id]?.owner === run.owner && Number.isFinite(run.until) && state.slot >= run.until
        ? BrothelHStatus_완료기록(state, id, run.stage, run.partner, { employeeKey: run.employeeKey, marker: run.marker }) : state;
      const external = { ...next.mods?.[api.id]?.external }; delete external[id];
      return { ...next, mods: { ...next.mods, [api.id]: { ...next.mods?.[api.id], external } } };
    }
    const service = brothel.service, activity = brothel.externalActivity, endActivity = brothel.endExternalActivity;
    brothel.service = function(state, id, partner, stage, options) {
      const assignment = state.mods?.brothel?.assignments?.[id];
      if (assignment?.owner === options?.owner) state = BrothelHStatus_출장완료(state, id);
      const worker = brothel.getConfig()?.workers.find(item => item.id === id), before = Number(worker?.sexualExperience?.[stage]) || 0;
      let next = service.call(this, state, id, partner, stage, options);
      if (fields[stage] && (Number(worker?.sexualExperience?.[stage]) || 0) > before) {
        const data = next.mods?.[api.id] || {};
        next = { ...next, mods: { ...next.mods, [api.id]: { ...data, external: { ...data.external, [id]: { stage,
          partner: copy(partner), owner: options?.owner, employeeKey: employeeKey(worker), marker: `external:${id}:${next.day}:${next.slot}:${stage}:${before + 1}` } } } } };
      }
      return next;
    };
    brothel.externalActivity = function(state, id, partner, stage, options) {
      let next = activity.call(this, state, id, partner, stage, options), data = next.mods?.[api.id];
      if (data?.external?.[id]?.stage === stage && next.mods?.brothel?.assignments?.[id]?.owner === options?.owner) next = { ...next, mods: { ...next.mods, [api.id]: { ...data,
        external: { ...data.external, [id]: { ...data.external[id], until: options?.untilSlot } } } } };
      return next;
    };
    brothel.endExternalActivity = function(state, id, options) {
      const valid = state.mods?.brothel?.assignments?.[id]?.owner === options?.owner;
      return endActivity.call(this, valid ? BrothelHStatus_출장완료(state, id) : state, id, options);
    };
    const release = brothel.release;
    brothel.release = function(state, owner) {
      for (const [id, run] of Object.entries(state.mods?.[api.id]?.external || {})) if (run.owner === owner) state = BrothelHStatus_출장완료(state, id);
      return release.call(this, state, owner);
    };
    function BrothelHStatus_읽기문맥(root, workerId) {
      const state = root.state, record = state?.mods?.[api.id]?.workers?.[workerId];
      if (!record?.character) return root;
      return { ...root, state: { ...state, primaryCharacterId: workerId,
        characters: { [workerId]: record.character }, relationships: [],
        patronRecords: brothel.patronRelationships?.(state, workerId)?.records || [] } };
    }
    api.hook('brothelHStatusStoreSelector', { around(next, store, selector) {
      const scope = React.useContext(Scope);
      if (!scope || store.getState !== api.fn('store').getState) return next(store, selector);
      return next(store, root => (selector || (value => value))(scope(root)));
    } });
    function BrothelHStatus_전체화면({ workerId }) {
      const project = React.useMemo(() => {
        const cache = new WeakMap();
        return root => { if (!cache.has(root)) cache.set(root, BrothelHStatus_읽기문맥(root, workerId)); return cache.get(root); };
      }, [workerId]);
      return jsx(Scope.Provider, { value: project, children: jsx(hStatus.SecretPanel, {}) });
    }
    function BrothelHStatus_정수읽기(value) { return Math.max(0, Math.floor(Number(value) || 0)); }
    function BrothelHStatus_직원기록만들기(state, worker) {
      const serviceCounts = Object.fromEntries(stages.map(stage => [stage, BrothelHStatus_정수읽기(worker.sexualExperience?.[stage])]));
      const eventCounts = Object.fromEntries(eventKeys.map(key => [key, 0]));
      for (const [stage, field] of Object.entries(fields)) eventCounts[field] += serviceCounts[stage];
      const history = (worker.sexualHistory || []).slice(-80).map(record => ({
        day: BrothelHStatus_정수읽기(record.day), slot: BrothelHStatus_정수읽기(record.slot),
        stage: String(record.stage || ''), partner: String(record.partner || ''),
        room: String(record.room || ''), fee: BrothelHStatus_정수읽기(record.fee)
      }));
      const previous = state.mods?.[api.id]?.workers?.[worker.id];
      const character = BrothelHStatus_인물읽기(state, worker);
      const pregnancy = state.waywardBrothelPregnancyV1?.workers?.[worker.id];
      const day = Number(pregnancy?.pausedAtDay ?? state.day);
      const deposits = (pregnancy?.spermDeposits || []).filter(item => day >= item.day && day - item.day <= 2);
      if (pregnancy) character.situationStats = { ...character.situationStats,
        fluidState: { ...character.situationStats.fluidState, uterus: deposits.length },
        dailyInternalEjaculationCount: deposits.filter(item => item.day === state.day).length, dailyCountDay: state.day };
      return {
        employeeKey: worker.relationshipId || `legacy:${worker.id}`, name: worker.name,
        serviceCounts, history, character,
        trackedSince: previous?.employeeKey === employeeKey(worker) && previous.trackedSince || state.day,
        situationStats: {
          version: hStatus.getStats()?.version,
          totalSexActCount: Object.values(eventCounts).reduce((sum, count) => sum + count, 0), eventCounts,
          contactServiceCount: serviceCounts.groping + serviceCounts.intimate,
          unavailableFields: ['manualReceived', 'oralReceived', 'analSex', 'patronMolestation', 'dailyInternalEjaculationCount', 'fluidState', 'orgasms', 'reception']
        }
      };
    }
    function BrothelHStatus_동기화하기(state) {
      if (!state) return state;
      const session = state.mods?.brothel?.playerSession;
      if (session?.serviceRecorded) state = BrothelHStatus_완료기록(state, session.workerId, session.stage, null,
        { player: true, marker: `player:${session.id}` });
      const config = brothel.getConfig();
      if (!config) return state;
      const workers = Object.fromEntries(config.workers.filter(worker => worker.enabled).map(worker => [worker.id, BrothelHStatus_직원기록만들기(state, worker)]));
      const data = { ...state.mods?.[api.id], version: 2, workers };
      if (JSON.stringify(state.mods?.[api.id]) === JSON.stringify(data)) return state;
      return { ...state, mods: { ...state.mods, [api.id]: data } };
    }
    function BrothelHStatus_기록읽기(state, workerId) {
      const worker = brothel.getConfig()?.workers?.find(item => item.id === workerId && item.enabled);
      const record = state?.mods?.[api.id]?.workers?.[workerId];
      if (!worker || record?.employeeKey !== (worker.relationshipId || `legacy:${worker.id}`)) return null;
      return structuredClone(record);
    }
    function BrothelHStatus_요소만들기(tag, text) {
      const element = document.createElement(tag);
      if (text != null) element.textContent = text;
      return element;
    }
    function BrothelHStatus_전체화면표시(host) {
      const open = host.closest('details.ww-editor-card')?.open;
      if (!open) { const root = roots.get(host); if (root) { root.unmount(); roots.delete(host); } return; }
      if (roots.has(host)) return;
      const full = host.querySelector('[data-brothel-secret]');
      const root = ReactDOM.createRoot(full); roots.set(host, root);
      root.render(jsx(BrothelHStatus_전체화면, { workerId: host.dataset.brothelHStatus }));
    }
    function BrothelHStatus_내용그리기(host, record) {
      const stamp = JSON.stringify({ name: record.name, serviceCounts: record.serviceCounts, history: record.history, trackedSince: record.trackedSince });
      if (host.dataset.record === stamp) { BrothelHStatus_전체화면표시(host); return; }
      host.dataset.record = stamp;
      const mounted = roots.get(host); if (mounted) { mounted.unmount(); roots.delete(host); }
      host.replaceChildren();
      host.append(BrothelHStatus_요소만들기('h4', `${record.name} · H_Status 기록`));
      host.append(BrothelHStatus_요소만들기('p', `신체 상태·평가는 ${record.trackedSince}일차부터 기록합니다. 이전 서비스 누계는 아래에 별도 표시하며, 과거의 미기록 상태를 무경험으로 판정하지 않습니다. 평가는 실제 기록된 유료 서비스·관계·접객 반응에 H_Status의 기준을 적용합니다.`));
      const full = BrothelHStatus_요소만들기('div'); full.dataset.brothelSecret = host.dataset.brothelHStatus;
      host.append(full);
      BrothelHStatus_전체화면표시(host);
      const grid = BrothelHStatus_요소만들기('dl');
      const values = [['기록된 행위 서비스 합계', record.situationStats.totalSexActCount], ['접촉·친밀 서비스', record.situationStats.contactServiceCount], ...stages.slice(2).map(stage => [labels[stage], record.serviceCounts[stage]])];
      for (const [label, count] of values) grid.append(BrothelHStatus_요소만들기('dt', label), BrothelHStatus_요소만들기('dd', `${count}회`));
      host.append(grid, BrothelHStatus_요소만들기('p', '창관의 서비스 기록 시점 기준입니다. 아내의 기록과 합산하지 않습니다. 사정 위치·절정·받은 행위 등 미제공 항목은 추정하지 않습니다. 신체 치수는 H_Status의 외형 기반 산출값이며, 미기록 잔류물·장신구·최면 상태의 기본 표시를 과거 이력으로 해석하지 않습니다.'));
      const history = BrothelHStatus_요소만들기('details');
      history.append(BrothelHStatus_요소만들기('summary', `최근 서비스 기록 (${record.history.length}/80)`));
      if (!record.history.length) history.append(BrothelHStatus_요소만들기('p', '아직 기록이 없습니다.'));
      for (const entry of [...record.history].reverse()) history.append(BrothelHStatus_요소만들기('div', `${entry.day}일차 · ${Math.floor(entry.slot % 1440 / 60)}:${String(entry.slot % 60).padStart(2, '0')} · ${entry.partner} · ${labels[entry.stage] || entry.stage} · ${entry.fee}G`));
      host.append(history);
    }
    function BrothelHStatus_화면갱신하기() {
      scheduled = false;
      for (const [host, root] of roots) if (!host.isConnected) { root.unmount(); roots.delete(host); }
      const settings = document.querySelector('#ww-settings');
      if (!settings || settings.hidden) return;
      const state = BrothelHStatus_저장반영하기();
      for (const select of settings.querySelectorAll('[data-brothel-portrait]')) {
        const workerId = select.dataset.brothelPortrait, content = select.closest('.ww-editor-content');
        if (!content) continue;
        const record = BrothelHStatus_기록읽기(state, workerId);
        const card = content.closest('details.ww-editor-card');
        if (card && !card.dataset.brothelSecretToggle) {
          card.dataset.brothelSecretToggle = 'true';
          if (openWorkers.has(workerId)) card.open = true;
          card.addEventListener('toggle', () => {
            if (!card.isConnected) return;
            card.open ? openWorkers.add(workerId) : openWorkers.delete(workerId);
            BrothelHStatus_갱신예약하기();
          });
        }
        let host = content.querySelector('[data-brothel-h-status]');
        if (!record) { host?.remove(); continue; }
        if (!host) { host = BrothelHStatus_요소만들기('section'); host.dataset.brothelHStatus = workerId; content.append(host); }
        BrothelHStatus_내용그리기(host, record);
      }
    }
    function BrothelHStatus_갱신예약하기() {
      if (!scheduled) { scheduled = true; queueMicrotask(BrothelHStatus_화면갱신하기); }
    }
    function BrothelHStatus_저장반영하기() {
      if (writing || !api.store.get()?.started) return api.store.game();
      const state = api.store.game(), next = BrothelHStatus_동기화하기(state);
      if (next !== state) {
        writing = true;
        try { api.store.update(current => current === state ? next : current); } finally { writing = false; }
      }
      return api.store.game();
    }
    function BrothelHStatus_저장변경처리하기() {
      if (writing || !api.store.get()?.started) return;
      BrothelHStatus_저장반영하기();
      BrothelHStatus_갱신예약하기();
    }
    const style = BrothelHStatus_요소만들기('style');
    style.textContent = '[data-brothel-h-status]{border:1px solid #57534e;border-radius:7px;padding:10px;margin-top:10px;min-width:0}[data-brothel-h-status]>dl{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:5px}[data-brothel-h-status]>dl>dd{margin:0}[data-brothel-h-status]>p,[data-brothel-h-status]>details{font-size:12px;overflow-wrap:anywhere}[data-brothel-h-status]>details{max-height:260px;overflow:auto}';
    document.head.append(style);
    const observer = new MutationObserver(BrothelHStatus_갱신예약하기);
    observer.observe(document.body, { childList: true, subtree: true });
    window.addEventListener('pagehide', () => { observer.disconnect(); for (const root of roots.values()) root.unmount(); roots.clear(); }, { once: true });
    api.store.subscribe(BrothelHStatus_저장변경처리하기);
    hStatus.getBrothelStats = workerId => BrothelHStatus_기록읽기(api.store.game(), workerId)?.situationStats || null;
    globalThis.__waywardBrothelHStatus = { sync: BrothelHStatus_동기화하기, getRecord: BrothelHStatus_기록읽기, refresh: BrothelHStatus_저장변경처리하기,
      project: BrothelHStatus_읽기문맥 };
    BrothelHStatus_저장변경처리하기();
  }
});
