// 실행: node wml/mods/brothel-compatible-h-status/source/build.mjs
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
const source = path.dirname(fileURLToPath(import.meta.url));
const output = fs.readFileSync(new URL('mod.wml.js', import.meta.url), 'utf8').split(/\r?\n/)[0] + '\n' + '// 생성 파일. source/mod.wml.js를 수정한 뒤 source/build.mjs로 재생성합니다.\n' + fs.readFileSync(path.join(source, 'mod.wml.js'), 'utf8');
new vm.Script(output);
fs.writeFileSync(path.join(source, '../mod.js'), output);
console.log('Generated ' + path.join(source, '../mod.js'));
