<!-- STABLE_PORT -->
## 2026-11-01 정식판 이식

모드 버전 **1.1.2**, 대상 게임 **2026-11-01**, WML **0.9.5**입니다. MCP 0.6.2로 연결을 검사합니다. 새 게임을 기준으로 하며 pre7 및 기존 저장 이전은 지원 범위에 포함하지 않습니다.

배포 파일: `brothel-compatible-h-status-1.1.2-20261101.zip`. 압축의 폴더 이름과 설치 ID는 `brothel-compatible-h-status`이며 `wml/mods/brothel-compatible-h-status/mod.js`로 설치합니다. WML 모드 관리자에서 ZIP 설치도 가능합니다. 아래의 pre7 버전·ZIP 안내는 이전 변경 기록입니다.
<!-- /STABLE_PORT -->

> **호환성 패치 기준:** brothel 3.10.0 / h-status 1.7.6
> 이번 개정의 기준 버전입니다. 버전 번호로 실행을 차단하지 않으며, 필수 모드와 실제 연결 기능은 필요합니다. 최신 구성에 맞춰 유지합니다.

# 창관 + H_Status 기록 1.1.1

## [pre7 배포 · 버전 분리]

현재 모드 버전: 1.1.1. 대상 게임: 2026-10-24-pre7. 이전 모드 버전: 1.1.0-pre7.1.
배포 파일: brothel-compatible-h-status-1.1.1-pre7.zip
압축 내부 최상위 폴더와 로딩 ID는 항상 `brothel-compatible-h-status`이며 버전·pre 표기를 붙이지 않습니다. 폴더 복사 설치 경로는 `wml/mods/brothel-compatible-h-status/mod.js`입니다. ZIP 설치는 WML 모드 관리자를 사용하세요. 모드의 version은 숫자 버전, game은 대상 게임 식별자로 분리했습니다. 업데이트 인식을 위해 모드 버전의 마지막 숫자를 올렸으며 게임 동작은 이번 변경에서 수정하지 않았습니다. 이전 ZIP과 과거 변경 기록은 보존합니다.


## 1.1.0-pre7.1 · 직원별 비밀 화면 (2026-10-29)

각 직원 상세보기 안에 H_Status 원본 비밀 화면을 그 직원 전용 읽기 문맥으로 표시합니다. 신체 상태·외형 기반 치수·행위 이력·평가·선택한 외형의 기존 이미지팩을 사용하며 실제 메인 인물 ID/슬롯·아내 기록은 바꾸지 않습니다. 접은 상세보기는 전체 화면 렌더링을 보류하고 새로 그릴 때 펼침 상태를 유지합니다.

기존 서비스 누계/최근 80건과 신규 완료 기록을 구분합니다. 기존 API의 situationStats는 서비스 누계 형식을 유지하고, getRecord(...).character의 situationStats·intimateHistory에는 이 버전부터 실제 일반 접객 단계 완료·출장 단계 완료·플레이어 서비스 기록을 넣습니다. 중도 취소·반복 동기화는 완료 기록을 중복 생성하지 않습니다. 직원 교체는 relationshipId로 구분합니다. 직원 전용 상세 기록은 세이브에 포함합니다.

원본 H_Status의 유료 서비스·행위·관계 기준으로 평가하며 절정·알 수 없는 사정 위치·제공하지 않는 받은 행위를 만들어 넣지 않습니다. 신체 치수는 원본의 외형 기반 산출값입니다. 과거의 미기록 상태는 복원하지 않으며 초기 기본 표시를 과거 무경험으로 해석하지 않습니다. 자궁 잔류 정보는 기존 직원 Pregnancy 자료가 있으면 그 자료를 읽습니다. 실제 이미지 파일이 없으면 원본의 준비 중 표시를 사용합니다. 표시만으로 이미지를 자동 생성하지 않습니다.

배포: brothel-compatible-h-status-1.1.0-pre7.1.zip. 이 모드만 교체하고 새로고침합니다. H_Status 본체·Brothel 원본 수정은 필요 없습니다. 아래 1.0.x 설명 중 요약 전용 제한은 이전 버전의 범위입니다.

현행 통합 검사: node --import ./wml/mods/companions/tests/runtime.mjs wml/mods/secert-club-compatible-companions/tests/integration.mjs (--mobile / --zip). 결과와 한계는 해당 호환 README 및 tests/result-*.json 참조.


필수: `brothel` 3.10.0 이상, `h-status` 1.6.0 이상 및 각 모드의 필수 의존성. 원본 모드 파일은 수정하지 않습니다.

창관 설정의 고용 직원 상세보기에 **H_Status 기록**을 추가합니다. 창관의 누적 서비스 횟수와 최근 80건을 직원별로 읽고, H_Status의 `totalSexActCount`·`eventCounts` 형식으로 `state.mods['brothel-compatible-h-status'].workers`에 분리 저장합니다. 아내의 `situationStats`, 직원 간 기록, 같은 외모의 직원 간 기록을 합치지 않습니다. 기존 기록도 처음 켤 때 반영하며 반복 동기화로 중복 가산하지 않습니다. 고용 인물의 `relationshipId`를 사용하므로 교체 고용에 이전 직원의 기록을 복사하지 않습니다.

손·구강·가슴·성관계 서비스만 행위 합계로 계산하고 접촉·친밀 서비스는 따로 표시합니다. 창관은 서비스 진입/기록 시점에 횟수를 올리므로 H_Status 원본의 완료 판정과 완전히 같은 의미가 아닙니다. 받는 행위·항문·사정 위치·절정·신체 치수·평가 등 창관이 제공하지 않는 정보는 추정하지 않습니다. `unavailableFields`로 미제공 항목을 명시합니다. H_Status 사건·외출·포커·이미지 생성 기능을 직원에게 복제하지 않습니다.

누적 횟수의 원본은 Brothel의 기존 브라우저 설정입니다. 호환 자료는 세이브에 포함하지만, 과거 슬롯을 불러와도 Brothel 자체가 되돌리지 않는 전역 직원 기록은 이 모드도 임의로 되돌리지 않습니다. 세이브를 불러온 뒤에는 현재 Brothel 기록으로 갱신합니다. H_Status 추가 사건 OFF 상태에서도 기록은 유지합니다.

공개 API: `__waywardBrothelHStatus.getRecord(state, workerId)`, `.sync(state)`, `__waywardSituationEventMod.getBrothelStats(workerId)`. 미고용/교체된 직원은 `null`입니다. 아내용 기존 `getStats()`는 변경하지 않습니다.

배포 ZIP을 WML 모드 관리자에 설치하고 필수 모드와 함께 켠 뒤 새로고침합니다. 폴더 설치는 `wml/mods/brothel-compatible-h-status/`에 풀고 모드 관리자에서 폴더를 등록합니다. 공통 `mods.js`는 수정하지 않습니다.

수정 원본: `source/mod.wml.js`. 생성: `node wml/mods/brothel-compatible-h-status/source/build.mjs`. 배포: `powershell -NoProfile -ExecutionPolicy Bypass -File wml/mods/brothel-compatible-h-status/source/package.ps1`.

통합 검증: `node --import ./wml/mods/brothel-compatible-h-status/tests/mcp-runtime.mjs wml/mods/brothel-compatible-h-status/tests/regression.mjs` (`--zip`, `--mobile` 지원). 두 호환 모드와 필수 모드를 함께 켠 격리 브라우저에서 초기 기록, 동일 외모 직원 분리, 자동·남편·출장 서비스, 중복 방지, 아내 기록 보존, 임신 이미지 로딩, OFF·저장·새로고침·해고·재고용을 확인합니다. 사용자 저장과 공통 모드 목록을 수정하지 않습니다.

각 호환 모드를 따로 켜는 검증: `node --import ./wml/mods/brothel-compatible-h-status/tests/mcp-runtime.mjs wml/mods/brothel-compatible-h-status/tests/independent.mjs`.


## 2026-10-24-pre7 이식

- 배포 버전: `1.0.2-pre7.1` · WML 0.9.4 · 구 게임용 배포와 구분합니다.
- 원제작자·원문 출처 표기는 기존 머리말과 문서에 보존했습니다. 이 배포의 호환 수정: HL 작업본.
- 모드 내부 ID와 폴더 이름을 `brothel-compatible-h-status`로 통일했습니다. 이 폴더만 덮어쓸 수 있는 개별 ZIP을 함께 제공합니다.
- 구 게임의 압축 함수 이름과 탐색 규칙을 pre7에 맞췄습니다. 변경·검증의 전체 범위와 한계는 작업 폴더 `version_up_ready/PORT_RESULT.md`를 참고하세요.


## 1.0.2-pre7.2 · 2026-10-27 MCP 후속 보완

- MCP 0.6.1 기준의 고정 태그를 모드 자체에 선언했습니다. 제작자/원문 출처 및 기존 pack은 보존합니다.
