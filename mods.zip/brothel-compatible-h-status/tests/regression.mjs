// 실행: node --import ./wml/mods/brothel-compatible-h-status/tests/mcp-runtime.mjs wml/mods/brothel-compatible-h-status/tests/regression.mjs [--mobile] [--zip]
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { checkMod } from '../../../../MCP/lib/check.mjs';
import { playStart, playEval, playReload, playStatus, playScreenshot, shutdown } from '../../../../MCP/lib/play.mjs';

const mobile = process.argv.includes('--mobile');
const ids = ['addon-compat', 'brothel', 'h-status', 'pregnancy', 'brothel-pregnancy', 'brothel-compatible-h-status', 'brothel-compatible-pregnancy'];
const disabled = Object.fromEntries(fs.readdirSync('wml/mods', { withFileTypes: true }).filter(entry => entry.isDirectory()).map(entry => [entry.name, false]));
async function BrothelCompatTest_평가하기(code) {
  const response = await playEval({ code });
  if (response.error) throw Error(response.error);
  return response.result;
}
try {
  for (const id of ids.slice(-2)) {
    const checked = checkMod(id); assert.ok(checked.ok, JSON.stringify(checked.errors));
  }
  await playStart({ mods: { ...disabled, ...Object.fromEntries(ids.map(id => [id, true])) }, ...(mobile ? { viewport: { width: 390, height: 844 } } : {}) });
  await BrothelCompatTest_평가하기(`localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify(ids)}));return true;`);
  if (process.argv.includes('--zip')) {
    const installed = await BrothelCompatTest_평가하기(`
      const ids=${JSON.stringify(ids.slice(-2))},append=document.head.appendChild;
      document.head.appendChild=function(node){
        if(node.tagName==='SCRIPT'&&ids.some(id=>node.src.endsWith('/wml/mods/'+id+'/mod.js'))){queueMicrotask(()=>node.dispatchEvent(new Event('error')));return node}
        return append.call(this,node);
      };
      try{return await WML.install(await Promise.all(ids.map(async id=>({path:id+'-1.0.0.zip',blob:await(await fetch('wml/mods/'+id+'/'+id+'-1.0.0.zip')).blob()}))))}
      finally{document.head.appendChild=append}
    `);
    assert.deepEqual(installed.map(item => item.id).sort(), ids.slice(-2).sort());
    assert.ok(installed.every(item => item.version === '1.0.0'));
    assert.ok(installed.every(item => item.mode === 'browser'));
  }
  const loaded = await playReload({}); assert.deepEqual(loaded.failed, []);
  for (const id of ids) assert.ok(loaded.loaded.includes(id), id);
  await BrothelCompatTest_평가하기(`
    for(let step=0;step<30;step++){
      if(document.querySelector('button[title="메뉴"]'))break;
      const buttons=[...document.querySelectorAll('button')].filter(button=>button.offsetParent);
      const button=buttons.find(item=>!item.disabled&&/^(예$|이해하고 동의합니다$|새 게임$|계속하기 —|시작 —|시작하기$|건너뛰기$)/.test(item.innerText.trim()))||buttons.find(item=>item.innerText.trim().startsWith('마라'));
      if(!button)throw Error('새 게임 버튼 없음');button.click();await new Promise(resolve=>setTimeout(resolve,80));
    }
    let seed=1138;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
    const api=WML.dev(),b=__waywardBrothelPublic,h=__waywardSituationEventMod;
    h.setSettings({enabled:false,pokerEnabled:false,outingEnabled:false});
    api.store.update(state=>({...state,day:10,slot:9*1440+1020,phase:'service',pendingEvent:undefined,alertQueue:[],brothelAddonCampaignVersion:1,economy:{...state.economy,gold:5000}}));
    const config=b.getConfig();config.enabled=false;config.allowTaproomSex=true;
    config.workers.forEach((worker,index)=>{worker.enabled=index<2;worker.relationshipId='compat-employee-'+index;worker.name='시험 직원 '+(index+1);worker.stats.energy=100;worker.lastFullRestDay=10;worker.portrait='elena';worker.sexualExperience={groping:0,intimate:0,handjob_patron:0,blowjob_patron:0,titfuck_patron:0,sex_patron:0};worker.sexualHistory=[]});
    config.workers[0].sexualExperience.handjob_patron=3;config.workers[1].sexualExperience.blowjob_patron=2;
    b.saveConfig();__waywardBrothelHStatus.refresh();b.openSettings();
    globalThis.BrothelCompatTest_wife=structuredClone(api.store.game().characters[api.store.game().primaryCharacterId]);
    return true;
  `);
  const initial = await BrothelCompatTest_평가하기(`
    const api=WML.dev(),h=__waywardBrothelHStatus,s=api.store.game();
    const before=JSON.stringify(s.mods['brothel-compatible-h-status']);h.refresh();h.refresh();
    return{first:h.getRecord(s,'brothel_worker_1'),second:h.getRecord(s,'brothel_worker_2'),same:before===JSON.stringify(api.store.game().mods['brothel-compatible-h-status']),wifeUnchanged:JSON.stringify(BrothelCompatTest_wife)===JSON.stringify(api.store.game().characters[s.primaryCharacterId]),shown:document.querySelectorAll('[data-brothel-h-status]').length,missing:h.getRecord(s,'brothel_worker_3')};
  `);
  assert.equal(initial.first.situationStats.eventCounts.manualGiven, 3);
  assert.equal(initial.second.situationStats.eventCounts.oralGiven, 2);
  assert.equal(initial.first.situationStats.eventCounts.oralGiven, 0);
  assert.equal(initial.first.situationStats.totalSexActCount, 3);
  assert.equal(initial.same, true); assert.equal(initial.wifeUnchanged, true);
  assert.equal(initial.shown, 2); assert.equal(initial.missing, null);
  console.log('PASS separate employee H_Status records, existing counters, same appearance, idempotence, wife unchanged and disabled events');

  const natural = await BrothelCompatTest_평가하기(`
    const api=WML.dev(),b=__waywardBrothelPublic,h=__waywardBrothelHStatus;
    const guest={id:'compat-guest',name:'시험 손님',boldness:30,charm:50,patronType:'regular',walletGold:1000,attributes:{strength:50,deftness:50,wit:50},status:'drinking'};
    let state=api.store.game();state=b.assign(state,['brothel_worker_1'],{owner:'compat-test',location:'taproom',task:'시험',situation:'시험 중'});
    state=b.service(state,'brothel_worker_1',guest,'blowjob_patron',{owner:'compat-test'});state=b.release(state,'compat-test');api.store.update(()=>state);
    const first=h.getRecord(api.store.game(),'brothel_worker_1');h.refresh();
    return{first,second:h.getRecord(api.store.game(),'brothel_worker_2'),stats:__waywardSituationEventMod.getBrothelStats('brothel_worker_1'),wifeUnchanged:JSON.stringify(BrothelCompatTest_wife)===JSON.stringify(api.store.game().characters[state.primaryCharacterId])};
  `);
  assert.equal(natural.first.situationStats.eventCounts.oralGiven, 1);
  assert.equal(natural.first.situationStats.totalSexActCount, 4);
  assert.equal(natural.first.history.at(-1).partner, '시험 손님');
  assert.equal(natural.second.situationStats.totalSexActCount, 2);
  assert.equal(natural.stats.totalSexActCount, 4); assert.equal(natural.wifeUnchanged, true);
  console.log('PASS actual external service records once, independent coworkers and H_Status public adapter');

  const gameplay = await BrothelCompatTest_평가하기(`
    const api=WML.dev(),b=__waywardBrothelPublic,c=b.getConfig(),worker=c.workers[0];
    const guest={id:'automatic-guest',name:'자동 접객 손님',boldness:30,charm:50,patronType:'regular',walletGold:1000,attributes:{strength:50,deftness:50,wit:50},status:'drinking',stayTimer:200,intent:'interested',tacticStyle:'warm_builder'};
    let state=api.fn('moveOccupant')({...api.store.game(),slot:api.store.game().slot+1,customers:[guest]},'player','taproom');
    c.enabled=true;
    b.getRuntime().set(worker.id,{id:worker.id,task:'interaction',location:'taproom',busyUntil:state.slot,stats:{...worker.stats},interaction:{customerId:guest.id,customerName:guest.name,customerSnapshot:guest,stages:['groping','handjob_patron'],index:0,stage:'groping',comfort:80}});
    const coworker=b.getRuntime().get(c.workers[1].id);coworker.task='rest';coworker.busyUntil=state.slot+100;
    state=b.tick(state);c.enabled=false;api.store.update(()=>state);
    const auto=__waywardSituationEventMod.getBrothelStats(worker.id).totalSexActCount;
    Object.assign(b.getRuntime().get(worker.id),{task:'idle',interaction:null,busyUntil:state.slot});
    api.store.update(current=>({...current,customers:[],pendingEvent:undefined,alertQueue:[],activeScene:{}}));
    api.store.dispatch({type:'brothel/player-service',workerId:worker.id,stage:'handjob_patron'});
    const started=!!api.store.game().mods.brothel.playerSession;
    for(let turn=0;turn<16&&api.store.game().mods.brothel.playerSession;turn++){
      if(api.store.game().pendingEvent)api.store.update(current=>({...current,pendingEvent:undefined,alertQueue:[]}));
      const session=api.store.game().mods.brothel.playerSession;
      if(session.waitingUntil!=null){api.store.dispatch({type:'brothel/player-continue',sessionId:session.id,turn:session.turn});continue}
      const choice=b.playerChoices(api.store.game())[0];if(!choice)throw Error('직원 대화 선택지 없음');
      api.store.dispatch({type:'brothel/player-choice',sessionId:session.id,turn:session.turn,choiceId:choice.id});
    }
    const stats=__waywardSituationEventMod.getBrothelStats(worker.id),record=__waywardBrothelHStatus.getRecord(api.store.game(),worker.id);
    __waywardBrothelHStatus.refresh();
    return{auto,started,stats,last:record.history.at(-1),second:__waywardSituationEventMod.getBrothelStats(c.workers[1].id).totalSexActCount,session:api.store.game().mods.brothel.playerSession,log:api.store.game().log.slice(-3),
      wifeUnchanged:JSON.stringify(BrothelCompatTest_wife.situationStats)===JSON.stringify(api.store.game().characters[state.primaryCharacterId].situationStats)};
  `);
  assert.equal(gameplay.auto, 5); assert.equal(gameplay.started, true, JSON.stringify(gameplay.log));
  assert.equal(gameplay.stats.totalSexActCount, 6, JSON.stringify(gameplay)); assert.equal(gameplay.stats.eventCounts.manualGiven, 5);
  assert.equal(gameplay.second, 2); assert.equal(gameplay.last.partner, '남편');
  assert.equal(gameplay.session, null); assert.equal(gameplay.wifeUnchanged, true);
  console.log('PASS automatic worker service and actual player dialogue service, one record per service and wife H_Status unchanged');

  const visuals = await BrothelCompatTest_평가하기(`
    const api=WML.dev(),v=__waywardBrothelPregnancyVisual,p=__wc2PregnancyBirth265,b=__waywardBrothelPublic;
    p.setEnabled(true);p.setCycleLength(7);
    let state=api.store.game();
    const wifeBefore=JSON.stringify(state.wc2PregnancyBirthMode265);
    const records={brothel_worker_1:{lastMorningDay:10,pausedAtDay:null,spermDeposits:[{id:'sample1',day:10,amount:80,fatherId:'known',fatherName:'기록된 손님',wifeKnows:true,husbandKnows:true}],pregnancy:null,seenServices:[]},brothel_worker_2:{lastMorningDay:10,pausedAtDay:null,spermDeposits:[],pregnancy:{conceptionDay:10,fatherId:'private',fatherName:'비공개 친부'},seenServices:[]}};
    state={...state,waywardBrothelPregnancyV1:{version:2,workers:records,events:[]}};api.store.update(()=>state);b.refreshSettings();
    const first=v.getVisualState(state,'brothel_worker_1'),second=v.getVisualState(state,'brothel_worker_2');
    const stages=[0,1,2,3,4].map(age=>v.getVisualState({...state,day:10+age},'brothel_worker_2'));
    const expired=v.getVisualState({...state,day:13},'brothel_worker_1');
    const paused=v.getVisualState({...state,day:40,waywardBrothelPregnancyV1:{...state.waywardBrothelPregnancyV1,workers:{...records,brothel_worker_2:{...records.brothel_worker_2,pausedAtDay:11}}}},'brothel_worker_2');
    return{first,second,stages,expired,paused,privateLeaked:JSON.stringify(second).includes('비공개 친부'),wifeUnchanged:wifeBefore===JSON.stringify(api.store.game().wc2PregnancyBirthMode265),figures:document.querySelectorAll('[data-brothel-pregnancy-visual]').length};
  `);
  assert.equal(visuals.first.ovumOwner, '시험 직원 1'); assert.equal(visuals.first.amount, 80); assert.equal(visuals.first.tier, 2);
  assert.deepEqual(visuals.first.spermOwners, ['기록된 손님']); assert.equal(visuals.second.amount, 0);
  assert.equal(visuals.second.file, 'two-cell-with-sperm-field-000.png');
  assert.deepEqual(visuals.stages.map(item => item.stage), ['fertilization', 'early', 'middle', 'late', 'birth']);
  assert.equal(visuals.expired.amount, 0); assert.equal(visuals.paused.stage, 'early');
  assert.equal(visuals.privateLeaked, false); assert.equal(visuals.wifeUnchanged, true);
  assert.equal(visuals.figures, 2);
  const images = await BrothelCompatTest_평가하기(`
    const images=[...document.querySelectorAll('[data-brothel-pregnancy-visual] img')];
    await Promise.all(images.map(image=>image.complete?Promise.resolve():new Promise(resolve=>{image.addEventListener('load',resolve,{once:true});image.addEventListener('error',resolve,{once:true})})));
    return images.map(image=>({src:image.src,loaded:image.naturalWidth>0}));
  `);
  assert.ok(images.every(image => image.loaded));
  assert.equal(images.length, 4);
  if (process.argv.includes('--zip')) assert.ok(images.every(image => /^(blob:|data:)/.test(image.src)), JSON.stringify(images.map(image=>image.src.slice(0,100))));
  console.log('PASS employee-specific cycle, dose, owner, all gestation images, pause, expiry, privacy and actual packaged images');

  await BrothelCompatTest_평가하기(`
    const p=__wc2PregnancyBirth265;p.setEnabled(false);__waywardBrothelPublic.refreshSettings();return true;
  `);
  const off = await BrothelCompatTest_평가하기(`return{visual:__waywardBrothelPregnancyVisual.getVisualState(WML.dev().store.game(),'brothel_worker_1'),images:document.querySelectorAll('[data-brothel-pregnancy-visual]').length,record:WML.dev().store.game().waywardBrothelPregnancyV1.workers.brothel_worker_1.spermDeposits.length};`);
  assert.equal(off.visual, null); assert.equal(off.images, 0); assert.equal(off.record, 1);
  await BrothelCompatTest_평가하기(`__wc2PregnancyBirth265.setEnabled(true);__waywardBrothelPublic.refreshSettings();WML.dev().store.get().saveToSlot(0);return true;`);
  assert.deepEqual((await playReload({})).failed, []);
  const persisted = await BrothelCompatTest_평가하기(`
    const api=WML.dev(),b=__waywardBrothelPublic;api.store.get().loadFromSlot(0);b.openSettings();
    const first=__waywardBrothelHStatus.getRecord(api.store.game(),'brothel_worker_1'),visual=__waywardBrothelPregnancyVisual.getVisualState(api.store.game(),'brothel_worker_2');
    const worker=b.getConfig().workers[0];globalThis.confirm=()=>true;
    document.querySelector('[data-brothel-portrait="'+worker.id+'"]').closest('.ww-editor-card').querySelector('.ww-dismiss').click();
    const invalidBefore=__waywardBrothelHStatus.getRecord(api.store.game(),worker.id),pregnancyAfterDismiss=__waywardBrothelPregnancyVisual.getVisualState(api.store.game(),worker.id);
    document.querySelector('.ww-hire-offer').click();
    return{first,visual,invalidBefore,pregnancyAfterDismiss,replacement:__waywardBrothelHStatus.getRecord(api.store.game(),worker.id),second:__waywardBrothelHStatus.getRecord(api.store.game(),'brothel_worker_2'),replacementPregnancy:api.store.game().waywardBrothelPregnancyV1.workers[worker.id]?.pregnancy||null};
  `);
  assert.equal(persisted.first.situationStats.totalSexActCount, 6); assert.equal(persisted.visual.ovumOwner, '시험 직원 2');
  assert.equal(persisted.invalidBefore, null); assert.equal(persisted.replacement.situationStats.totalSexActCount, 0);
  assert.equal(persisted.pregnancyAfterDismiss, null); assert.equal(persisted.replacementPregnancy, null);
  assert.equal(persisted.replacement.history.length, 0); assert.equal(persisted.second.situationStats.totalSexActCount, 2);
  console.log('PASS OFF preserves data, slot/reload persistence and replacement employee isolation');
  await BrothelCompatTest_평가하기(`
    const card=document.querySelector('[data-brothel-h-status]').closest('.ww-editor-card');card.open=true;card.querySelector('[data-brothel-h-status]').scrollIntoView({block:'start'});return true;
  `);
  fs.writeFileSync(`wml/mods/brothel-compatible-h-status/tests/${mobile ? 'mobile' : 'desktop'}-records.jpg`, Buffer.from(await playScreenshot({}), 'base64'));
  const status = await playStatus({}); assert.deepEqual(status.pageErrors, []);
  console.log('PASS ' + (mobile ? 'mobile' : 'desktop') + (process.argv.includes('--zip') ? ' ZIP' : ' source') + ', no browser errors');
} finally { await shutdown(); }
