// 실행: node --import ./wml/mods/brothel-compatible-h-status/tests/mcp-runtime.mjs wml/mods/brothel-compatible-h-status/tests/independent.mjs
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { playStart, playEval, playReload, playStatus, shutdown } from '../../../../MCP/lib/play.mjs';

const disabled = Object.fromEntries(fs.readdirSync('wml/mods', { withFileTypes: true }).filter(entry => entry.isDirectory()).map(entry => [entry.name, false]));
const variants = [
  ['brothel-compatible-h-status', ['addon-compat', 'brothel', 'h-status', 'brothel-compatible-h-status']],
  ['brothel-compatible-pregnancy', ['addon-compat', 'brothel', 'pregnancy', 'brothel-pregnancy', 'brothel-compatible-pregnancy']]
];
try {
  for (const [id, ids] of variants) {
    await playStart({ id, mods: { ...disabled, ...Object.fromEntries(ids.map(name => [name, true])) } });
    await playEval({ id, code: `localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify(ids)}));return true;` });
    const loaded = await playReload({ id });
    assert.deepEqual(loaded.failed, []);
    for (const name of ids) assert.ok(loaded.loaded.includes(name), name);
    const result = (await playEval({ id, code: `
      for(let step=0;step<30;step++){
        if(document.querySelector('button[title="메뉴"]'))break;
        const buttons=[...document.querySelectorAll('button')].filter(button=>button.offsetParent);
        const button=buttons.find(item=>!item.disabled&&/^(예$|이해하고 동의합니다$|새 게임$|계속하기 —|시작 —|시작하기$|건너뛰기$)/.test(item.innerText.trim()))||buttons.find(item=>item.innerText.trim().startsWith('마라'));
        if(!button)throw Error('새 게임 버튼 없음');button.click();await new Promise(resolve=>setTimeout(resolve,80));
      }
      const api=WML.dev(),b=__waywardBrothelPublic,worker=b.getConfig().workers[0];
      worker.enabled=true;worker.relationshipId='independent-employee';worker.sexualExperience.handjob_patron=7;b.saveConfig();
      api.store.update(state=>({...state,day:3,phase:'service',brothelAddonCampaignVersion:1}));
      if(globalThis.__wc2PregnancyBirth265)__wc2PregnancyBirth265.setEnabled(true);
      b.openSettings();await new Promise(resolve=>setTimeout(resolve,50));
      const nameInput=document.querySelector('.ww-identity input[type="text"]');nameInput.value=worker.name+' 이름수정';nameInput.dispatchEvent(new Event('input',{bubbles:true}));await new Promise(resolve=>setTimeout(resolve,50));
      return{records:globalThis.__waywardBrothelHStatus?.getRecord(api.store.game(),worker.id)?.situationStats.totalSexActCount,
        recordName:globalThis.__waywardBrothelHStatus?.getRecord(api.store.game(),worker.id)?.name,
        visual:globalThis.__waywardBrothelPregnancyVisual?.getVisualState(api.store.game(),worker.id)?.ovumOwner,
        name:worker.name,hasRecords:!!document.querySelector('[data-brothel-h-status]'),hasImage:!!document.querySelector('[data-brothel-pregnancy-visual]')};
    ` })).result;
    if (id === 'brothel-compatible-h-status') {
      assert.equal(result.records, 7); assert.equal(result.hasRecords, true); assert.equal(result.hasImage, false);
      assert.equal(result.recordName, result.name);
      assert.ok(!loaded.loaded.includes('pregnancy'));
    } else {
      assert.equal(result.visual, result.name); assert.equal(result.hasImage, true); assert.equal(result.hasRecords, false);
      assert.ok(!loaded.loaded.includes('h-status'));
    }
    const status = await playStatus({ id }); assert.deepEqual(status.pageErrors, []);
    console.log('PASS independent dependency set: ' + id);
  }
} finally { await shutdown(); }
