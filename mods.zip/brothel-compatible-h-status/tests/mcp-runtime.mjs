// 복사된 pnpm 의존성의 누락 링크를 시험 중에만 해결합니다. MCP 폴더는 수정하지 않습니다.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { registerHooks } from 'node:module';
const store = fileURLToPath(new URL('../../../../MCP/node_modules/.pnpm/', import.meta.url));
const roots = fs.existsSync(store) ? fs.readdirSync(store).map(name => path.join(store, name)) : [];
registerHooks({
  resolve(specifier, context, next) {
    try { return next(specifier, context); }
    catch (error) {
      if (error.code !== 'ERR_MODULE_NOT_FOUND' || specifier.startsWith('.') || specifier.includes(':')) throw error;
      const name = specifier.startsWith('@') ? specifier.split('/').slice(0, 2).join('/') : specifier.split('/')[0];
      for (const root of roots) {
        if (fs.existsSync(path.join(root, 'node_modules', name, 'package.json'))) {
          return next(specifier, { ...context, parentURL: pathToFileURL(path.join(root, '__test__.mjs')).href });
        }
      }
      throw error;
    }
  }
});
