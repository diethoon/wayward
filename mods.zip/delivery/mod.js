// 생성 파일. 수정: source/mod.wml.js, source/native-ui.js — 재생성: node wml/mods/delivery/source/build.mjs
// 각 모드에 포함되는 설정 UI. 게임 HTML의 메뉴와 DOM만 사용합니다.
WML.define({
  tags: ["content"],
  id: 'delivery',
  author: "Hina_Lover",
  name: "배달의 민족 (Delivery)",
  // mod symbols (tools/mod-symbols.mjs / MCP symbol_add keep this block; data only)
  symbols: {
    "DeliveryLocations": {"raw":{"2026-11-01":"Za"}},
    "DeliveryLocationNames": {"raw":{"2026-11-01":"YZ"}},
    "DeliveryLocationCardNames": {"raw":{"2026-11-01":"LB"}},
    "DeliveryErrandLocations": {"raw":{"2026-11-01":"BZ"}},
    "DeliveryServiceScenarios": {"raw":{"2026-11-01":"NV"}},
    "DeliveryServiceWindow": {"raw":{"2026-11-01":"mW"}},
    "DeliveryPartyCustomers": {"raw":{"2026-11-01":"H$e"}},
    "DeliveryBackRoomApproach": {"raw":{"2026-11-01":"oNe"}},
    "DeliveryPatronOpportunity": {"raw":{"2026-11-01":"ADe"}},
    "DeliveryPatronRubbingOpportunity": {"raw":{"2026-11-01":"jDe"}},
    "DeliveryGameShell": {"raw":{"2026-11-01":"Iit"}},
    "DeliveryLocationPanel": {"raw":{"2026-11-01":"hat"}},
    "DeliveryEventModal": {"raw":{"2026-11-01":"Eat"}},
    "DeliveryPartyDefinition": {"raw":{"2026-11-01":"ca"}},
    "DeliveryActStage": {"raw":{"2026-11-01":"Ka"}},
    "DeliveryPatronTactic": {"raw":{"2026-11-01":"MUe"}},
    "DeliveryPatronAmbientContact": {"raw":{"2026-11-01":"QGe"}},
    "DeliveryDayEnd": {"raw":{"2026-11-01":"xm"},"doc":"Defers tavern closing while delegated delivery service is unfinished."},
    "DeliveryBackRoomWifeAvailable": {"raw":{"2026-11-01":"Dx"},"doc":"Native back-room order eligibility; ordinary service busyUntilSlot does not block delegation."},
    "DeliveryBackRoomWifeUnavailableReason": {"raw":{"2026-11-01":"J$e"},"doc":"Native explanation when the wife cannot be sent to serve a private-room order."}
  },
  version: "5.3.5",
  game: "2026-11-01",
  lang: 'ko',
  description: "다양한 목적지로 직접 배달하거나 여성캐릭터를 보냅니다. 독립된 배달장소에서 응대하며, 주문 발생과 배달장소 성적 행위 가중치를 0~10배로 조절합니다.",
  requires: [],
  loadAfter: [],
  setup(wmlApi) {
// 생성 파일. 수정: source/mod.wml.js, source/native-ui.js — 재생성: node wml/mods/delivery/source/build.mjs
// 각 모드에 포함되는 설정 UI. 게임 HTML의 메뉴와 DOM만 사용합니다.
(() => {
  if (globalThis.__waywardPauseSettingsUiFactory?.version === 1) return;
  const entries = new Map(), windows = new Map();
  const legacyButtons = '[data-wc2-preg-menu],[data-wc2-customer-menu],.ww-brothel-menu-button,[data-bad-guest-settings-launch],[data-ww-image-studio-menu]';
  let queued = false, theme = null;
  const cssValues = new Map(), cssProbe = document.createElement('div').style;

  function ModNativeUI_요소만들기(tag, props, ...children) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(props || {})) {
      if (value == null || value === false) continue;
      if (key === 'class') node.className = value;
      else if (key === 'style') node.style.cssText = value;
      else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2).toLowerCase(), value);
      else if (key in node && key !== 'list') node[key] = value;
      else node.setAttribute(key, value === true ? '' : String(value));
    }
    for (const child of children.flat()) if (child != null && child !== false) node.append(child.nodeType ? child : String(child));
    return node;
  }
  // WML 0.9.5 owns pause-menu placement through api.ui.pauseSettings.
  function ModNativeUI_메뉴찾기() { return []; }
  function ModNativeUI_스타일지정하기(node, property, value) {
    const key = property + ':' + value;
    if (!cssValues.has(key)) { cssProbe.setProperty(property, value); cssValues.set(key, cssProbe.getPropertyValue(property)); }
    if (node.style.getPropertyValue(property) !== cssValues.get(key) || node.style.getPropertyPriority(property) !== 'important') node.style.setProperty(property, value, 'important');
  }
  function ModNativeUI_테마읽기(button) {
    const native = getComputedStyle(button || document.getElementById('root') || document.body);
    const channels = (native.backgroundColor.match(/[\d.]+/g) || [28, 25, 23]).slice(0, 3).map(Number);
    const luminance = Math.max(.09, Math.min(.22, (Math.max(...channels) + Math.min(...channels)) / 510));
    return { font: native.fontFamily || 'sans-serif', background: `hsl(32 52% ${Math.round(luminance * 100 + 4)}%)`,
      foreground: 'hsl(40 78% 88%)', border: 'hsl(32 55% 34%)', radius: native.borderRadius || '6px' };
  }
  function ModNativeUI_버튼색칠하기(button, settings) {
    const colors = theme = ModNativeUI_테마읽기(settings);
    for (const [key, value] of Object.entries({ background: colors.background, color: colors.foreground,
      'border-color': colors.border, 'border-width': '1px', 'border-style': 'solid', 'border-radius': colors.radius,
      width: '100%', padding: '8px 16px', 'font-family': colors.font, 'font-size': '14px', cursor: 'pointer' })) ModNativeUI_스타일지정하기(button, key, value);
  }
  function ModNativeUI_앞으로올리기(node) {
    ModNativeUI_스타일지정하기(node, 'z-index', '2147483647');
    if (node.parentElement === document.body && node.nextElementSibling) document.body.append(node);
  }
  function ModNativeUI_정리하기() {
    for (const { list, settings } of ModNativeUI_메뉴찾기()) {
      let anchor = settings;
      for (const [owner, entry] of entries) {
        const official = [...list.querySelectorAll('[data-wml-pause-entry]')].find(node => node.dataset.wmlPauseEntry === owner);
        if (official) {
          for (const old of [...list.children]) if (old !== official &&
            (old.dataset.waywardNativeSettings === owner || entry.legacyButton && old.matches(entry.legacyButton))) old.remove();
          anchor = official;
          continue;
        }
        let button = [...list.children].find(node => node.dataset.waywardNativeSettings === owner);
        if (!button && entry.legacyButton) button = list.querySelector(entry.legacyButton);
        if (!button) {
          button = ModNativeUI_요소만들기('button', { type: 'button', class: settings.className,
            'data-wayward-native-settings': owner, ...entry.attributes,
            class: `${settings.className} ${entry.attributes?.class || ''}`.trim() }, entry.label);
          button.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); entry.onClick?.();
            queueMicrotask(() => entry.windowSelector && document.querySelectorAll(entry.windowSelector).forEach(ModNativeUI_앞으로올리기)); });
          list.append(button);
        }
        button.dataset.waywardNativeSettings = owner;
        // 이 표시는 새 로더의 기존 버튼 정렬과도 같은 순서를 유지하게 합니다.
        // 구형 로더에서는 사용하지 않아도 HTML 메뉴가 직접 처리됩니다.
        button.dataset.wmlModSettings = owner;
        ModNativeUI_버튼색칠하기(button, settings);
        if (button.textContent !== entry.label) button.textContent = entry.label;
        if (anchor.nextElementSibling !== button) anchor.after(button);
        anchor = button;
      }
      const panel = list.parentElement;
      if (panel.style.maxHeight !== 'calc(100dvh - 32px)') panel.style.maxHeight = 'calc(100dvh - 32px)';
      if (panel.style.overflowY !== 'auto') panel.style.overflowY = 'auto';
    }
    for (const entry of entries.values()) if (entry.windowSelector) {
      for (const panel of document.querySelectorAll(entry.windowSelector)) {
        ModNativeUI_스타일지정하기(panel, 'z-index', '2147483647');
      }
    }
  }
  function ModNativeUI_정리예약하기() {
    if (queued) return;
    queued = true;
    queueMicrotask(() => { queued = false; ModNativeUI_정리하기(); });
  }
  function ModNativeUI_버튼만들기(label, onClick, options = {}) {
    return ModNativeUI_요소만들기('button', { type: 'button', class: 'wayward-native-button',
      title: options.title, disabled: options.disabled, onclick: onClick,
      style: options.primary ? 'background:#78350f;color:#fef3c7' : '' }, label);
  }
  function ModNativeUI_창열기(owner, options) {
    const id = `${owner}:${options.id || 'settings'}`;
    if (windows.has(id)) { const prior = windows.get(id); prior.focus(); return prior; }
    const colors = theme || ModNativeUI_테마읽기();
    const width = Math.min(options.width || 520, Math.max(280, innerWidth - 16));
    const height = Math.min(options.height || 440, Math.max(160, innerHeight - 16));
    const title = ModNativeUI_요소만들기('strong', {}, options.title || owner);
    const body = ModNativeUI_요소만들기('div', { class: 'wayward-native-window-body' });
    const node = ModNativeUI_요소만들기('section', { class: 'wayward-native-window', role: 'region',
      'aria-label': options.title || owner, 'data-wml-ui': owner, 'data-wayward-native-window': id,
      style: `left:${Math.max(8, (innerWidth - width) / 2)}px;top:${Math.max(8, (innerHeight - height) / 3)}px;width:${width}px;height:${height}px;font-family:${colors.font}` });
    let removeBack = null;
    function ModNativeUI_창닫기() { node.remove(); windows.delete(id); removeBack?.(); options.onClose?.(); }
    const bar = ModNativeUI_요소만들기('header', { class: 'wayward-native-window-title' }, title,
      ModNativeUI_버튼만들기('✕', ModNativeUI_창닫기, { title: '닫기' }));
    node.append(bar, body);
    const handle = { el: node, body, owner, close: ModNativeUI_창닫기,
      focus: () => {
        ModNativeUI_앞으로올리기(node); windows.delete(id); windows.set(id, handle);
        if (typeof options.onBack === 'function') {
          removeBack?.(); removeBack = options.onBack(() => { handle.close(); return true; });
        }
      }, setTitle: value => { title.textContent = value; },
      refresh: () => { body.replaceChildren(); options.render?.(body, handle); } };
    node.addEventListener('pointerdown', handle.focus);
    bar.addEventListener('pointerdown', event => {
      if (event.button !== 0 || event.target.closest('button')) return;
      event.preventDefault();
      const x = event.clientX - node.offsetLeft, y = event.clientY - node.offsetTop;
      const move = next => { node.style.left = Math.max(0, Math.min(innerWidth - 80, next.clientX - x)) + 'px'; node.style.top = Math.max(0, Math.min(innerHeight - 40, next.clientY - y)) + 'px'; };
      const stop = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', stop); };
      window.addEventListener('pointermove', move); window.addEventListener('pointerup', stop, { once: true });
    });
    windows.set(id, handle); document.body.append(node); handle.focus(); handle.refresh();
    return handle;
  }
  const style = ModNativeUI_요소만들기('style', { 'data-wayward-native-ui': '1' });
  style.textContent = `
    .wayward-native-window{position:fixed;display:flex;flex-direction:column;font-size:14px;max-width:calc(100vw - 16px);max-height:calc(100dvh - 16px);min-width:280px;min-height:160px;resize:both;overflow:hidden;background:#1c1917;color:#e7e5e4;border:1px solid #92400e;border-radius:9px;box-shadow:0 14px 44px #000c}
    .wayward-native-window-title{display:flex;align-items:center;gap:8px;padding:8px 10px;background:#292524;border-bottom:1px solid #44403c;cursor:move;touch-action:none}.wayward-native-window-title strong{flex:1;font-size:14px}.wayward-native-window-body{flex:1;overflow:auto;padding:12px}
    .wayward-native-button{border:1px solid #57534e;border-radius:6px;padding:6px 10px;background:#292524;color:#e7e5e4;cursor:pointer;font:inherit}.wayward-native-button:disabled{opacity:.45;cursor:default}
    .wayward-native-window .wml-muted{color:#a8a29e}.wayward-native-window .wml-note{color:#fde68a}.wayward-native-window .wml-small{font-size:12px}
    @media(max-width:640px){.wayward-native-window{left:8px!important;top:8px!important;width:calc(100vw - 16px)!important;height:calc(100dvh - 16px)!important;resize:none}}
  `;
  document.head.append(style);
  const observer = new MutationObserver(ModNativeUI_정리예약하기);
  observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'hidden', 'class'] });
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape' || !windows.size) return;
    [...windows.values()].at(-1).close(); event.preventDefault(); event.stopImmediatePropagation();
  }, true);
  window.addEventListener('pagehide', () => observer.disconnect(), { once: true });
  function ModNativeUI_연결하기(base, config) {
    const owner = config.id, raw = name => config.bindings?.[base.game]?.[name] || name;
    const resolve = name => {
      const candidate = raw(name);
      if (base.engine && candidate in base.engine) return candidate;
      return base.sym(name);
    };
    const registerMenu = options => { entries.set(owner, options); return base.ui.pauseSettings({ ...options, attributes: { ...options.attributes, 'data-wayward-native-settings': owner }, onClick: () => { options.onClick?.(); queueMicrotask(() => options.windowSelector && document.querySelectorAll(options.windowSelector).forEach(ModNativeUI_앞으로올리기)); } }); };
    const ui = { ...base.ui,
      h: ModNativeUI_요소만들기, button: ModNativeUI_버튼만들기,
      window: options => ModNativeUI_창열기(owner, { ...options, onBack: base.onBack }),
      settings: render => {
        base.ui.settings(render);
        registerMenu({ label: config.label, onClick: () => ModNativeUI_창열기(owner,
          { id: 'settings', title: config.label, render, onBack: base.onBack }) }); ModNativeUI_정리예약하기();
      },
      menuSettings: registerMenu,
    };
    const facade = { ...base, ui,
      fn: name => base.engine?.[resolve(name)], sym: resolve,
      has: name => { try { return !!resolve(name); } catch { return false; } },
      hook: (name, options) => base.hook(resolve(name), options),
      onBack: typeof base.onBack === 'function' ? base.onBack : () => () => {},
    };
    if (config.legacy) ui.menuSettings(config.legacy);
    return facade;
  }
  globalThis.__waywardPauseSettingsUiFactory = { version: 1, connect: ModNativeUI_연결하기 };
})();

// Delivery 5: 다양한 주문 목적지와 독립된 배달장소에서 뒷방 서빙 규칙을 사용합니다.

Object.assign(globalThis,{});

    const api = globalThis.__waywardPauseSettingsUiFactory.connect(wmlApi, {"id":"delivery","label":"배달 모드 설정","bindings":{"2026-10-04":{"store":"ae","settingsStore":"At","React":"Z","jsx":"u","ActionButton":"Ze","ActionPanel":"aO","wife":"_","updateWife":"O","updateCharacter":"nn","log":"N","tick":"Jt","intoxLabel":"In","playerId":"fe","wifeId":"Re","locationOf":"$e","wifeLocation":"_e","playerLocation":"bt","moveOccupant":"Pt","patronScene":"Y","playerSexScene":"Le","setScene":"MV","patronSceneLocation":"tt","isSexualStage":"it","sceneDef":"ls","sceneOutfitState":"bx","garmentWorn":"vr","exposureSummary":"nf","patronWatchChoices":"Xae","patronChoice":"tNe","startPlayerSex":"_p","playerSexEvent":"Fl","ensureHusbandLed":"F8","addJoinedPatron":"nfe","joinSlots":"NH","registerAlert":"nr","queueAlert":"gn","drainAlerts":"gl","imagePrompt":"r8","imageKey":"s8","imageKeyOf":"n8","imageDescriptor":"o8","makeCustomer":"ff","addCustomer":"Ka","carryToBed":"RDe","talkToWife":"EF","actionTimes":"Oo","addFeeling":"we","addIdentityStrainFromPatronAct":"Kf","getCustomerLocation":"Yn","getEffectiveAttributes":"B","heroineConditioningMax":"QX","heroineDriveCalc":"si","moveWife":"pt","outfits":"fh","patronControlCustomerLocation":"ht","wifeById":"ul","wifePreview":"gue","reduceGameAction":"wT","brothelLog":"hs","decisionCategories":"bo","decisionResolve":"G$e","manaMax":"ms","minuteTick":"gp","recordPlayerTone":"Rt","wives":"mh","imageBackend":"Eh","brothelCustomerBusy":"XO","buildPatronMoveCandidates":"Phe","ejectCustomer":"Q5","endPatronInteraction":"jt","finishBackRoomService":"xF","forceAttemptChance":"Ppe","patronControlAcquaintanceStop":"_Ie","patronControlAttemptRoll":"Iy","patronControlBackRoomOpen":"Tr","patronControlBareForPushIn":"O5","patronControlChooseMove":"Yhe","patronControlCoercionEscape":"cpe","patronControlFavorTable":"h3","patronControlHerBackRoomProposal":"ipe","patronControlIntentEvolve":"z$","patronControlJoinerComfort":"wh","patronControlJoinerPushIn":"jIe","patronControlLineUp":"Gce","patronControlLungePlan":"Vre","patronControlMortifyingCheck":"b$","patronControlMoveCustomer":"Yt","patronControlNaturalEnd":"hI","patronControlPatronBackRoomProposal":"ape","patronControlPatronDrift":"Kbe","patronControlPlayerAway":"Tt","patronControlPositionWeights":"Fhe","patronControlPrivateSession":"wpe","patronControlPrivateSessionInfo":"a0","patronControlPushIn":"qce","patronControlPushInAnalReaction":"p6","patronControlPushInReaction":"R6","patronControlRelentChance":"Bpe","patronControlRequestTable":"E2e","patronControlSelfEscalationRoll":"Qre","patronControlShameStop":"dpe","patronControlSlotFree":"kS","patronControlSmallRequest":"R2e","patronControlStageLabel":"hG","patronControlStrengthContest":"Za","patronControlTacticTable":"lIe","patronControlUndressAttempt":"AIe","patronControlVerbalAsk":"$5e","patronControlWitnessesFor":"Ks","patronControlYieldRoll":"pB","playerActionPublicRefusal":"Rs","processPatronGroupJoin":"BS","processPatronGroupParticipants":"WS","processPatronInteractionTick":"R7","recordPatronMistreatment":"yl","recordPatronReach":"K5e","resolvePatronEscalation":"ub","resolvePatronForce":"gB","rotatePatronGroupAfterPrimary":"Gie","selectPatronTactic":"gIe","startPatronInteraction":"Go","transitionPatronStage":"Dn","evaluateIntimacy":"Pe","getMaritalDrift":"E4","getPatronAttachment":"Uo","nudgeRelationship":"Mo","recordAffection":"Iw","recordIntimateHistory":"Wd","recordPatronBoundary":"Qi","brothelRoomLabels":"bO","imageRoom":"lue","waitressAlternative":"u$","waitressAvailable":"Bd","waitressChooseOrder":"Jle","waitressConsume":"_w","waitressIncome":"Qt","waitressMissing":"CP","waitressPrice":"d$","waitressRecordDrink":"vw","waitressRecordWord":"VB","playerActionRespond":"P1e","playerActionTopicFatigue":"GY","playerActionTouchedOut":"er","promptJoin":"J6","promptRoomFilter":"$de","promptGenParams":"q6","outfitById":"Ot","saveSlotInfo":"Mb","listDayStarts":"ZI","saveDayStart":"UDe","wifePortraits":"z6e","resentment":"Ue","marriageBond":"VT","wakeUp":"FI","gameOverScreen":"HLe","allureScore":"Ir","normalVisitRoll":"nhe","lodgingChance":"IB","worldTick":"Dp","hotkeyAction":"sG","confirmAction":"N4e","busyTask":"X0","imageManifest":"Wb","imageServerUrl":"Cs","imageGenerate":"LPe","imageQueue":"g6e","imageBackendProbe":"JU","imageBackendForget":"UD","imagePackReset":"qD","imageAutoProbeAllowed":"KU","DeliveryLocations":"hl","DeliveryLocationNames":"K7","DeliveryLocationCardNames":"bO","DeliveryErrandLocations":"Q7","DeliveryServiceScenarios":"$F","DeliveryServiceWindow":"LAe","DeliveryPartyCustomers":"Bje","DeliveryBackRoomApproach":"nAe","DeliveryPatronOpportunity":"Gce","DeliveryPatronRubbingOpportunity":"qce","DeliveryGameShell":"L6e","DeliveryLocationPanel":"ILe","DeliveryEventModal":"zLe","DeliveryPartyDefinition":"Ar","DeliveryActStage":"my","DeliveryPatronTactic":"gIe","DeliveryPatronAmbientContact":"R2e","DeliveryDayEnd":"Cd","DeliveryBackRoomWifeAvailable":"V0","DeliveryBackRoomWifeUnavailableReason":"Qje"}, "2026-11-01": {"store":"ae","settingsStore":"at","React":"J","jsx":"u","ActionButton":"ht","ActionPanel":"SB","wife":"_","updateWife":"C","updateCharacter":"rn","log":"j","tick":"Jt","intoxLabel":"Sn","playerId":"ge","wifeId":"Ee","locationOf":"Ae","wifeLocation":"we","playerLocation":"vt","moveOccupant":"Ht","patronScene":"U","playerSexScene":"Be","setScene":"dK","patronSceneLocation":"Je","isSexualStage":"ct","sceneDef":"Sr","sceneOutfitState":"KMe","garmentWorn":"Zr","exposureSummary":"_g","patronWatchChoices":"Dbe","patronChoice":"uZ","startPlayerSex":"uh","playerSexEvent":"Kl","ensureHusbandLed":"ihe","addJoinedPatron":"C3e","joinSlots":"eU","registerAlert":"ar","queueAlert":"_n","drainAlerts":"oi","imagePrompt":"DR","imageKey":"zz","imageKeyOf":"CR","imageDescriptor":"RR","makeCustomer":"Ag","addCustomer":"Fi","carryToBed":"r5e","talkToWife":"gee","actionTimes":"tn","addFeeling":"Se","addIdentityStrainFromPatronAct":"Qf","getCustomerLocation":"Jn","getEffectiveAttributes":"B","heroineConditioningMax":"eue","heroineDriveCalc":"il","moveWife":"Nt","outfits":"Oi","patronControlCustomerLocation":"et","wifeById":"$m","wifePreview":"WL","reduceGameAction":"p5","brothelLog":"ds","decisionCategories":"Ho","decisionResolve":"DFe","manaMax":"Ys","minuteTick":"ry","recordPlayerTone":"qn","wives":"kr","imageBackend":"yh","brothelCustomerBusy":"z5","buildPatronMoveCandidates":"Zve","ejectCustomer":"HR","endPatronInteraction":"Rt","finishBackRoomService":"IV","forceAttemptChance":"iIe","patronControlAcquaintanceStop":"OUe","patronControlAttemptRoll":"g0","patronControlBackRoomOpen":"xS","patronControlBareForPushIn":"Q2","patronControlChooseMove":"sxe","patronControlCoercionEscape":"YOe","patronControlFavorTable":"wY","patronControlHerBackRoomProposal":"dGe","patronControlIntentEvolve":"AC","patronControlJoinerComfort":"ch","patronControlJoinerPushIn":"KUe","patronControlLineUp":"ADe","patronControlLungePlan":"s8e","patronControlMortifyingCheck":"b_","patronControlMoveCustomer":"lo","patronControlNaturalEnd":"GC","patronControlPatronBackRoomProposal":"cGe","patronControlPatronDrift":"NHe","patronControlPlayerAway":"yt","patronControlPositionWeights":"rxe","patronControlPrivateSession":"ZJ","patronControlPrivateSessionInfo":"Nh","patronControlPushIn":"jDe","patronControlPushInAnalReaction":"N9","patronControlPushInReaction":"wz","patronControlRelentChance":"mIe","patronControlRequestTable":"JGe","patronControlSelfEscalationRoll":"l8e","patronControlShameStop":"WOe","patronControlSlotFree":"G$","patronControlSmallRequest":"QGe","patronControlStageLabel":"Ote","patronControlStrengthContest":"el","patronControlTacticTable":"$Ue","patronControlUndressAttempt":"zUe","patronControlVerbalAsk":"A7e","patronControlWitnessesFor":"hs","patronControlYieldRoll":"Xq","playerActionPublicRefusal":"ir","processPatronGroupJoin":"gN","processPatronGroupParticipants":"XS","processPatronInteractionTick":"cZ","recordPatronMistreatment":"yl","recordPatronReach":"bPe","resolvePatronEscalation":"_b","resolvePatronForce":"Zq","rotatePatronGroupAfterPrimary":"jle","selectPatronTactic":"MUe","startPatronInteraction":"Xo","transitionPatronStage":"js","evaluateIntimacy":"We","getMaritalDrift":"i4","getPatronAttachment":"Uo","nudgeRelationship":"ko","recordAffection":"Iw","recordIntimateHistory":"Om","recordPatronBoundary":"tl","brothelRoomLabels":"LB","imageRoom":"ER","waitressAlternative":"JA","waitressAvailable":"zr","waitressChooseOrder":"uTe","waitressConsume":"v_","waitressIncome":"vo","waitressMissing":"K7","waitressPrice":"zv","waitressRecordDrink":"ox","waitressRecordWord":"vK","playerActionRespond":"IWe","playerActionTopicFatigue":"sX","playerActionTouchedOut":"er","promptJoin":"Yz","promptRoomFilter":"uMe","promptGenParams":"Dz","outfitById":"Ot","saveSlotInfo":"Bk","listDayStarts":"h$","saveDayStart":"y5e","wifePortraits":"Uit","resentment":"qe","marriageBond":"dA","wakeUp":"vD","gameOverScreen":"kat","allureScore":"aa","normalVisitRoll":"wTe","lodgingChance":"mK","worldTick":"py","hotkeyAction":"KG","confirmAction":"NYe","busyTask":"sv","imageManifest":"bh","imageServerUrl":"es","imageGenerate":"xst","imageQueue":"eit","imageBackendProbe":"FD","imageBackendForget":"iM","imagePackReset":"t_","imageAutoProbeAllowed":"eoe","DeliveryLocations":"Za","DeliveryLocationNames":"YZ","DeliveryLocationCardNames":"LB","DeliveryErrandLocations":"BZ","DeliveryServiceScenarios":"NV","DeliveryServiceWindow":"mW","DeliveryPartyCustomers":"H$e","DeliveryBackRoomApproach":"oNe","DeliveryPatronOpportunity":"ADe","DeliveryPatronRubbingOpportunity":"jDe","DeliveryGameShell":"Iit","DeliveryLocationPanel":"hat","DeliveryEventModal":"Eat","DeliveryPartyDefinition":"ca","DeliveryActStage":"Ka","DeliveryPatronTactic":"MUe","DeliveryPatronAmbientContact":"QGe","DeliveryDayEnd":"xm","DeliveryBackRoomWifeAvailable":"Dx","DeliveryBackRoomWifeUnavailableReason":"J$e"}}});
    const DELIVERY_SITE = 'delivery_site', DURATION = 30, MIN_DAY = 2;
    const WIFE_DURATION_NOTE = '최소 30분이 소요되나, 손님과 더 시간을 보낼수도 있습니다';
    const WIFE_BASE_TIP_MULTIPLIER = 1, WIFE_INTERACTION_TIP_PER_MINUTE = 1;
    const DEFAULTS = { eventWeight: 1, hotelSexWeight: 2 };
    
    const ITEM_PRICE = { food: 5, beer: 3, wine: 6 };
    const ITEM_LABEL = { food: '음식', beer: '맥주', wine: '와인' };
    const TIERS = [
    {fee:20, requester:'인근 공방의 견습공들', destination:'가죽공방 뒤편 작업장', minUnits:1,maxUnits:3,renown:1,refuseRenown:-1,weight:28,
      request:'해가 지기 전부터 일감을 붙들고 있던 견습공들이 저녁을 거른 모양입니다.'},
    {fee:30, requester:'야간 경비 초소의 경비병들', destination:'서문 야간 경비 초소', minUnits:2,maxUnits:5,renown:1,refuseRenown:-1,weight:24,
      request:'교대할 사람이 없어 자리를 비울 수 없는 경비병들이 따뜻한 음식과 술을 찾습니다.'},
    {fee:40, requester:'상인 조합 창고의 인부들', destination:'강변 상인 조합 창고', minUnits:3,maxUnits:7,renown:2,refuseRenown:-2,weight:18,
      request:'밤늦게 들어온 짐을 내리느라 묶인 창고 인부들이 한꺼번에 먹을 것을 주문했습니다.'},
    {fee:60, requester:'여행 상단의 행수', destination:'북문 밖 상단 숙영지', minUnits:5,maxUnits:9,renown:3,refuseRenown:-2,weight:14,
      request:'내일 새벽 출발할 상단이 장부를 마무리하며 일행이 먹을 야식을 부탁합니다.'},
    {fee:80, requester:'귀족 저택의 청지기', destination:'언덕 위 귀족 저택', minUnits:7,maxUnits:12,renown:4,refuseRenown:-3,refuseNotoriety:1,weight:10,
      request:'예고 없이 손님을 맞은 청지기가 체면을 세울 음식과 술을 급히 구하고 있습니다.'},
    {fee:100,requester:'성주의 사냥 연회를 맡은 집사', destination:'성채 안뜰의 사냥 연회장', minUnits:10,maxUnits:16,renown:5,refuseRenown:-4,refuseNotoriety:2,weight:6,
      request:'늦게 돌아온 사냥 일행 때문에 성채 주방만으로는 연회상이 모자라다고 합니다.'}
  ];
    const React = api.fn('React'), jsx = api.fn('jsx');
    let projectionDepth = 0;
    const orderKind = api.events.onAlert('order', (state, choice) => {
      const cleared = { ...state, pendingEvent: undefined };
      if (choice === 'decline') return Delivery_주문거절하기(cleared);
      const started = Delivery_배달시작하기(cleared, choice === 'wife' ? 'wife' : 'player');
      return started === cleared ? state : started;
    });

    function Delivery_숫자제한하기(value, min, max, fallback = min) {
      const number = Number(value);
      return Math.max(min, Math.min(max, Number.isFinite(number) ? number : fallback));
    }
    function Delivery_설정읽기() {
      const saved = api.settings.get(DEFAULTS);
      return {
        eventWeight: Delivery_숫자제한하기(saved.eventWeight, 0, 10, 1),
        hotelSexWeight: Delivery_숫자제한하기(saved.hotelSexWeight, 0, 10, 2)
      };
    }
    function Delivery_설정저장하기(patch) {
      const settings = { ...Delivery_설정읽기(), ...patch };
      api.settings.set({
        eventWeight: Delivery_숫자제한하기(settings.eventWeight, 0, 10, 1),
        hotelSexWeight: Delivery_숫자제한하기(settings.hotelSexWeight, 0, 10, 2)
      });
      return Delivery_설정읽기();
    }
    function Delivery_자료읽기(state) { return state?.deliveryAddon || {}; }
    function Delivery_자료쓰기(state, patch) {
      return { ...state, deliveryAddon: { ...Delivery_자료읽기(state), version: 5, ...patch } };
    }
    function Delivery_기록하기(state, text) { return api.fn('log')(state, text); }
    function Delivery_장소등록하기() {
      // 주문의 실제 목적지는 offer.destination에 보관하고, 응대 장소는 독립 ID로 등록합니다.
      const rooms = api.fn('DeliveryLocations');
      if (!rooms.includes(DELIVERY_SITE)) rooms.push(DELIVERY_SITE);
      api.fn('DeliveryLocationNames')[DELIVERY_SITE] = '배달장소';
      api.fn('DeliveryLocationCardNames')[DELIVERY_SITE] = '배달장소';
      api.fn('DeliveryErrandLocations').delivery = DELIVERY_SITE;
    }
    function Delivery_장소준비하기(state) {
      if (!state || state.locations?.[DELIVERY_SITE]) return state;
      return { ...state, locations: { ...state.locations, [DELIVERY_SITE]: { occupants: [] } } };
    }
    function Delivery_재고읽기(state) {
      return {
        food: Math.max(0, Math.floor(Number(state.readyFood) || 0)),
        beer: Math.max(0, Math.floor(Number(state.supplies?.beer) || 0)),
        wine: Math.max(0, Math.floor(Number(state.supplies?.wine) || 0))
      };
    }
    function Delivery_재고충족확인하기(state, offer) {
      const stock = Delivery_재고읽기(state);
      return !!offer && Object.entries(offer.order).every(([key, count]) => stock[key] >= count);
    }
    function Delivery_평판변경하기(state, renown, notoriety = 0) {
      const current = state.tavernReputation || {};
      return { ...state, tavernReputation: { ...current,
        renown: Delivery_숫자제한하기((current.renown || 0) + renown, 0, 100),
        notoriety: Delivery_숫자제한하기((current.notoriety || 0) + notoriety, 0, 100) } };
    }
    function Delivery_주문표시하기(order) {
      return Object.entries(order).filter(([, count]) => count > 0)
        .map(([key, count]) => `${ITEM_LABEL[key]} ${count}개`).join(' · ');
    }
    function Delivery_주문복원하기(offer) {
      if (!offer || !['러브호텔', '러브 호텔'].includes(offer.destination)) return offer;
      const destination = offer.originalDestination || TIERS.find(tier => tier.fee === offer.fee)?.destination;
      return destination ? { ...offer, destination } : offer;
    }
    function Delivery_대금표시하기(offer) {
      return `음식값 ${offer.itemPrice}골드 + 배달료 ${offer.fee}골드 = 총 ${offer.totalPrice}골드`;
    }
    function Delivery_아내기본팁계산하기(offer) {
      return Math.round(offer.fee * WIFE_BASE_TIP_MULTIPLIER);
    }
    function Delivery_담당자이름(state=api.store.game()) {return state?api.fn('wife')(state)?.name||'그녀':'그녀';}
    function Delivery_아내보너스예상표시하기(offer) {
      const base = Delivery_아내기본팁계산하기(offer);
      return `응대 보너스 예상: +${base}~${base + DURATION * WIFE_INTERACTION_TIP_PER_MINUTE}골드 (상호작용 0~${DURATION}분 기준). 실제 응대 1분마다 +${WIFE_INTERACTION_TIP_PER_MINUTE}골드이며, 더 오래 응대하면 예상보다 늘어납니다.`;
    }
    function Delivery_아내보너스읽기(session) {
      const saved = session.wifeBonus;
      return saved || { baseTip: Delivery_아내기본팁계산하기(session.offer), perMinute: WIFE_INTERACTION_TIP_PER_MINUTE,
        interactionMinutes: 0, lastCountedSlot: session.startSlot };
    }
    function Delivery_아내보너스계산하기(session) {
      if (session.who !== 'wife') return { baseTip: 0, interactionMinutes: 0, interactionTip: 0, total: 0 };
      const bonus = Delivery_아내보너스읽기(session);
      const interactionTip = bonus.interactionMinutes * bonus.perMinute;
      return { baseTip: bonus.baseTip, interactionMinutes: bonus.interactionMinutes, interactionTip,
        total: bonus.baseTip + interactionTip };
    }
    function Delivery_거절결과표시하기(offer) {
      return `명성 ${offer.refuseRenown} · 악명 +${offer.refuseNotoriety || 0}`;
    }
    function Delivery_주문만들기(state, fee) {
      const available = Delivery_재고읽기(state);
      const total = Object.values(available).reduce((sum, number) => sum + number, 0);
      const tiers = TIERS.filter(tier => tier.minUnits <= total && (fee == null || tier.fee === fee));
      if (!tiers.length) return null;
      let roll = Math.random() * tiers.reduce((sum, tier) => sum + tier.weight, 0);
      const tier = tiers.find(candidate => (roll -= candidate.weight) < 0) || tiers.at(-1);
      let remaining = tier.minUnits + Math.floor(Math.random() * (Math.min(tier.maxUnits, total) - tier.minUnits + 1));
      const order = { food: 0, beer: 0, wine: 0 };
      while (remaining-- > 0) {
        const keys = Object.keys(order).filter(key => order[key] < available[key]);
        order[keys[Math.floor(Math.random() * keys.length)]]++;
      }
      const itemPrice = Object.entries(order).reduce((sum, [key, count]) => sum + ITEM_PRICE[key] * count, 0);
      return { ...tier, id: `delivery:${state.day}:${state.slot}:${Math.random().toString(36).slice(2, 9)}`,
        createdDay: state.day, createdSlot: state.slot, order, itemPrice, totalPrice: itemPrice + tier.fee };
    }
    function Delivery_아내불가이유읽기(state) {
      if (!state || !api.fn('wife')(state)) return "그녀의 상태를 확인할 수 없습니다.";
      if (Delivery_자료읽기(state).activeDelivery || state.errandSession) return '진행 중인 배달이나 외출을 먼저 마무리해야 합니다.';
      // 뒷방 주문과 같은 기준을 사용합니다. 인사·주문 받기·서빙 등
      // 일반 홀 응대의 busyUntilSlot은 배달을 맡기는 데 장애가 되지 않습니다.
      if (!api.fn('DeliveryBackRoomWifeAvailable')(state)) return api.fn('DeliveryBackRoomWifeUnavailableReason')(state);
      if (api.fn('playerSexScene')(state) || state.activeScene?.situation || state.activeScene?.table)
        return '진행 중인 특별한 장면을 먼저 마무리해야 합니다.';
      return '';
    }
    function Delivery_아내가능확인하기(state) { return !Delivery_아내불가이유읽기(state); }
    
    
    
    function Delivery_담당아내확인하기(state) {
      const session = Delivery_아내세션읽기(state);
      return !!session && session.characterId === state.primaryCharacterId;
    }
    function Delivery_주문소유확인하기(state) {
      return !!Delivery_자료읽기(state).pendingOffer && state?.pendingEvent?.alert?.kind === orderKind;
    }
    function Delivery_발생확률읽기() {
      // 뒷방 이용 요청(상인 방문)과 같은 weight / service-window 추첨 기준.
      const base = api.fn('DeliveryServiceScenarios').find(event => event.id === 'merchants_visit');
      return Math.min(1, (base?.weight ?? 0.1) / api.fn('DeliveryServiceWindow') * Delivery_설정읽기().eventWeight);
    }
    function Delivery_발생가능확인하기(state) {
      const meta = Delivery_자료읽기(state);
      return !!state && !state.gameOver && state.phase === 'service' && state.day >= MIN_DAY
        && !meta.pendingOffer && !meta.activeDelivery && !meta.activeDeliveryId
        && !state.pendingEvent && !state.errandSession && !api.fn('patronScene')(state)
        && !api.fn('playerSexScene')(state) && !state.activeScene?.situation && !state.activeScene?.table
        && api.fn('playerLocation')(state) === 'taproom'
        && api.fn('wife')(state).currentTask !== 'passed_out'
        && Object.values(Delivery_재고읽기(state)).some(number => number > 0);
    }
    function Delivery_주문추첨하기(state, force = false, fee) {
      const meta = Delivery_자료읽기(state);
      if (!Delivery_발생가능확인하기(state) || (!force && meta.lastRollSlot === state.slot)) return state;
      const chance = Delivery_발생확률읽기();
      if (!force && chance <= 0) return state;
      let next = Delivery_자료쓰기(state, { lastRollSlot: state.slot });
      if (!force && Math.random() >= chance) return next;
      const offer = Delivery_주문만들기(next, fee);
      if (!offer) return next;
      next = Delivery_자료쓰기(next, { pendingOffer: offer, lastOfferDay: state.day });
      const body = `${offer.requester}이(가) ${offer.destination}으로 ${Delivery_주문표시하기(offer.order)}을(를) 주문했습니다. ${Delivery_대금표시하기(offer)}. 완료하면 명성 +${offer.renown}. 거절하면 ${Delivery_거절결과표시하기(offer)}. 그녀 배달은 ${WIFE_DURATION_NOTE}. ${Delivery_아내보너스예상표시하기(offer)}`;
      next = Delivery_기록하기({ ...next, eventsTonight: (next.eventsTonight || 0) + 1 }, `[배달] ${body}`);
      return api.events.alert(next, { kind: orderKind, title: '배달 주문', body,
        choices: [{ id: 'player', label: '직접 가기' }, { id: 'wife', label: Delivery_담당자이름(next)+'에게 배달 부탁하기' }, { id: 'decline', label: '거절하기' }] });
    }
    function Delivery_재고차감하기(state, order) {
      return { ...state, readyFood: state.readyFood - order.food,
        supplies: { ...state.supplies, beer: state.supplies.beer - order.beer, wine: state.supplies.wine - order.wine } };
    }
    function Delivery_배달시작하기(state, who) {
      const offer = Delivery_주문복원하기(Delivery_자료읽기(state).pendingOffer);
      if (!offer || Delivery_자료읽기(state).activeDelivery || state.errandSession
        || (state.pendingEvent && state.pendingEvent.alert?.kind !== orderKind)
        || !Delivery_재고충족확인하기(state, offer)) return state;
      if (who === 'wife' && !Delivery_아내가능확인하기(state)) return state;
      if (who !== 'wife' && api.fn('playerLocation')(state) !== 'taproom') return state;
      if (state.pendingEvent?.alert?.kind === orderKind) state = { ...state, pendingEvent: undefined };
      // 기본 뒷방으로 보낼 때처럼 홀 손님 응대는 넘깁니다. 이전 손님
      // 장면이 배달장소까지 따라가거나 배달 손님 응대를 막지 않도록 정리합니다.
      if (who === 'wife' && api.fn('patronScene')(state)) state = { ...state,
        activeScene: { ...state.activeScene, patron: undefined } };
      const characterId = who === 'wife' ? state.primaryCharacterId : api.fn('playerId');
      const session = { id: offer.id, who, characterId, offer, startSlot: state.slot,
        returnAtSlot: state.slot + DURATION, originalLocation: 'taproom', location: DELIVERY_SITE, customerIds: [] };
      let next = Delivery_재고차감하기(Delivery_장소준비하기(state), offer.order);
      if (who === 'wife') {
        session.minimumReturnAtSlot = session.returnAtSlot;
        session.wifeBonus = Delivery_아내보너스읽기(session);
        const type = offer.fee >= 80 ? 'nobles' : offer.fee === 30 ? 'town_watch' : 'merchants';
        const guests = api.fn('DeliveryPartyCustomers')(next, type, Math.min(4, Math.max(2, Math.ceil(offer.fee / 30))));
        const customers = guests.map((guest, index) => ({ ...guest, id: `${session.id}:guest:${index}`, deliveryCustomer: true }));
        session.customerIds = customers.map(customer => customer.id);
        session.party = { occupiedBy: type, startedAtSlot: next.slot, endSlot: session.returnAtSlot,
          mood: 34, drinksServed: Object.values(offer.order).reduce((sum, count) => sum + count, 0) };
        next = { ...next, customers: [...next.customers, ...customers], locations: { ...next.locations,
          [DELIVERY_SITE]: { ...next.locations[DELIVERY_SITE], occupants: [...next.locations[DELIVERY_SITE].occupants, ...session.customerIds] } } };
        next = api.fn('moveOccupant')(next, characterId, DELIVERY_SITE);
        next = api.fn('updateCharacter')(next, characterId, character => ({ ...character,
          currentTask: 'serving', taskTarget: 'delivery', busyUntilSlot: session.returnAtSlot,
          locationUntilSlot: session.returnAtSlot }));
      } else {
        next = { ...next, errandSession: { reason: 'delivery', startSlot: state.slot,
          returnAtSlot: session.returnAtSlot, deliveryId: offer.id, deliveryOffer: offer }, awayEvents: [] };
        next = api.fn('moveOccupant')(next, characterId, DELIVERY_SITE);
      }
      next = Delivery_자료쓰기(next, { pendingOffer: undefined, activeDelivery: session, activeDeliveryId: session.id });
      return Delivery_기록하기(next, who === 'wife'
        ? `[배달] ${state.characters[characterId].name}을(를) ${offer.destination}으로 보냈습니다. ${WIFE_DURATION_NOTE}. ${Delivery_대금표시하기(offer)} · 완료 시 명성 +${offer.renown}. ${Delivery_아내보너스예상표시하기(offer)}`
        : `[배달] 당신이 ${offer.destination}으로 직접 배달을 떠납니다. 30분 동안 그녀가 주점을 맡습니다. ${Delivery_대금표시하기(offer)} · 완료 시 명성 +${offer.renown}.`);
    }
    function Delivery_주문거절하기(state) {
      const offer = Delivery_자료읽기(state).pendingOffer;
      if (!offer) return state;
      if (state.pendingEvent?.alert?.kind === orderKind) state = { ...state, pendingEvent: undefined };
      const next = Delivery_평판변경하기(Delivery_자료쓰기(state, { pendingOffer: undefined }), offer.refuseRenown, offer.refuseNotoriety || 0);
      return Delivery_기록하기(next, `[배달] ${offer.requester}의 주문을 거절했습니다. (${Delivery_거절결과표시하기(offer)})`);
    }
    function Delivery_아내세션읽기(state) {
      const session = Delivery_자료읽기(state).activeDelivery;
      return session?.who === 'wife' ? session : null;
    }
    function Delivery_최소귀환시각읽기(session) {
      // 4.0 세이브의 returnAtSlot도 최소 체류 시각으로 해석합니다.
      return session.minimumReturnAtSlot ?? session.returnAtSlot ?? session.startSlot + DURATION;
    }
    function Delivery_아내귀환가능확인하기(state) {
      const session = Delivery_아내세션읽기(state);
      if (!session || state.slot < Delivery_최소귀환시각읽기(session)) return false;
      const scene = api.fn('patronScene')(state);
      const servingScene = scene && (scene.characterId || state.primaryCharacterId) === session.characterId
        && api.fn('patronSceneLocation')(state) === DELIVERY_SITE;
      // 기본 뒷방 Jje와 같은 기준: 모든 단계의 손님 장면·선택 사건·부부 장면이 끝나야 복귀합니다.
      return !servingScene && !state.pendingEvent && !api.fn('playerSexScene')(state);
    }
    function Delivery_세션유지하기(state) {
      const session = Delivery_아내세션읽기(state);
      if (!session || !state.characters?.[session.characterId]) return state;
      let next = Delivery_장소준비하기(state);
      // 다음 기본 게임 틱에서도 자동 작업/장소 타이머가 먼저 만료되지 않도록 유지합니다.
      const holdUntil = Math.max(Delivery_최소귀환시각읽기(session), state.slot + 2);
      next = Delivery_자료쓰기(next, { activeDelivery: { ...session,
        wifeBonus: Delivery_아내보너스읽기(session),
        minimumReturnAtSlot: Delivery_최소귀환시각읽기(session), party: { ...session.party, endSlot: holdUntil } } });
      next = Delivery_입실자배치하기(next, session);
      return api.fn('updateCharacter')(next, session.characterId, character => ({ ...character,
        currentTask: 'serving', taskTarget: 'delivery', busyUntilSlot: holdUntil, locationUntilSlot: holdUntil }));
    }
    function Delivery_입실자배치하기(state, session) {
      const ids = [session.characterId, ...session.customerIds];
      const locations = {};
      for (const [room, value] of Object.entries(state.locations)) {
        locations[room] = { ...value, occupants: (value.occupants || []).filter(id => !ids.includes(id)) };
      }
      locations[DELIVERY_SITE] = { ...locations[DELIVERY_SITE], occupants: [...new Set([...locations[DELIVERY_SITE].occupants, ...ids])] };
      return { ...state, locations };
    }
    function Delivery_뒷방처리하기(state, callback, finishing = false) {
      const session = Delivery_아내세션읽기(state);
      if (!session) return callback(state);
      const realBackRoom = state.locations.back_room;
      const site = state.locations[DELIVERY_SITE];
      const projected = { ...state, primaryCharacterId: session.characterId,
        locations: { ...state.locations, [DELIVERY_SITE]: { ...site, occupants: [] },
          back_room: { occupants: [...site.occupants], meta: { party: session.party } } } };
      projectionDepth++;
      let processed;
      try { processed = callback(projected); } finally { projectionDepth--; }
      const party = processed.locations.back_room.meta?.party || session.party;
      const locations = { ...processed.locations, back_room: realBackRoom, [DELIVERY_SITE]: site };
      let next = { ...processed, primaryCharacterId: state.primaryCharacterId, locations };
      next = Delivery_자료쓰기(next, { activeDelivery: { ...session, party } });
      return finishing ? next : Delivery_세션유지하기(next);
    }
    function Delivery_원격장면확인하기(state, scene = api.fn('patronScene')(state)) {
      const session = Delivery_아내세션읽기(state);
      return !!session && !!scene && (scene.characterId || state.primaryCharacterId) === session.characterId
        && session.customerIds.includes(scene.customerId);
    }
    function Delivery_성적선택확인하기(move) {
      return move.kind === 'anal' || move.kind === 'lateral'
        || api.fn('isSexualStage')(move.target || move.wanted || '');
    }
    function Delivery_성적가중치적용하기(candidates, state, scene) {
      if (!Delivery_원격장면확인하기(state, scene)) return candidates;
      const weight = Delivery_설정읽기().hotelSexWeight;
      return candidates.map(candidate => Delivery_성적선택확인하기(candidate.move)
        ? { ...candidate, weight: candidate.weight * weight } : candidate).filter(candidate => candidate.weight > 0);
    }
    function Delivery_첫추첨가중하기(callback, weight) {
      const random = Math.random;
      let first = true;
      Math.random = function Delivery_가중난수만들기() {
        const roll = random();
        if (!first) return roll;
        first = false;
        return roll / weight;
      };
      try { return callback(); } finally { Math.random = random; }
    }
    function Delivery_성적결과확인하기(result) {
      const act = result?.actDone || result?.recordEncounter?.actId;
      return !!act && api.fn('isSexualStage')(api.fn('DeliveryActStage')(act) || '')
        || result?.setPatronExposed || result?.patronFinished;
    }
    function Delivery_배달정산하기(state, session, completed = true) {
      if (Delivery_자료읽기(state).lastSettledDeliveryId === session.id) return state;
      const offer = session.offer;
      const bonus = completed ? Delivery_아내보너스계산하기(session) : null;
      let next = Delivery_자료쓰기(state, { activeDelivery: undefined, activeDeliveryId: undefined,
        lastSettledDeliveryId: session.id, lastRollSlot: state.slot,
        lastReceipt: { id: session.id, who: session.who, destination: offer.destination, completed,
          basePayment: completed ? offer.totalPrice : 0, bonus, totalPayment: completed ? offer.totalPrice + bonus.total : 0 } });
      if (!completed) return Delivery_기록하기(Delivery_평판변경하기(next, offer.refuseRenown, offer.refuseNotoriety || 0),
        '[배달] 배달을 마치기 전에 돌아왔습니다. 주문 대금은 받지 못했습니다.');
      next = api.fn('waitressIncome')(next, 'service', offer.itemPrice);
      next = api.fn('waitressIncome')(next, 'errands', offer.fee + bonus.total);
      const bonusText = session.who === 'wife'
        ? ` + 응대 보너스 ${bonus.total}골드 (추가 팁 ${bonus.baseTip}골드 + 상호작용 ${bonus.interactionMinutes}분 ${bonus.interactionTip}골드) = 최종 ${offer.totalPrice + bonus.total}골드`
        : '';
      return Delivery_기록하기(Delivery_평판변경하기(next, offer.renown),
        `[배달] ${offer.destination} 배달을 마쳤습니다. ${Delivery_대금표시하기(offer)}${bonusText}를 받았습니다. (명성 +${offer.renown})`);
    }
    function Delivery_아내귀환하기(state) {
      const session = Delivery_아내세션읽기(state);
      if (!session || !Delivery_아내귀환가능확인하기(state)) return state;
      let next = Delivery_뒷방처리하기(state, projected => api.fn('finishBackRoomService')(projected), true);
      const locations = {};
      for (const [room, value] of Object.entries(next.locations)) {
        locations[room] = { ...value, occupants: value.occupants.filter(id => !session.customerIds.includes(id) && id !== session.characterId) };
      }
      next = { ...next, locations, customers: next.customers.filter(customer => !session.customerIds.includes(customer.id)) };
      next = api.fn('moveOccupant')(next, session.characterId, ['closed', 'bedroom'].includes(next.phase) ? 'bedroom' : 'taproom');
      next = api.fn('updateCharacter')(next, session.characterId, character => ({ ...character,
        currentTask: 'idle', taskTarget: undefined, busyUntilSlot: 0, locationUntilSlot: undefined,
        sceneOverride: undefined, onPatronLap: false }));
      return Delivery_배달정산하기(next, session);
    }
    function Delivery_분진행처리하기(state, previous) {
      if (!state || state.slot <= previous.slot) return state;
      let next = state;
      const session = Delivery_자료읽기(next).activeDelivery;
      if (session?.who === 'wife') {
        next = Delivery_세션유지하기(next);
        if (Delivery_아내귀환가능확인하기(next)) return Delivery_아내귀환하기(next);
        const active = Delivery_아내세션읽기(next);
        const definition = api.fn('DeliveryPartyDefinition')(session.party.occupiedBy);
        next = Delivery_자료쓰기(next, { activeDelivery: { ...active,
          party: { ...active.party, mood: Math.min(100, active.party.mood + definition.moodDriftPerTick) } } });
        if (next.slot < Delivery_최소귀환시각읽기(active)
          && !next.pendingEvent && !api.fn('patronScene')(next) && !api.fn('playerSexScene')(next) && !next.activeScene?.situation) {
          next = Delivery_뒷방처리하기(next, projected => api.fn('DeliveryBackRoomApproach')(projected));
        }
        return next;
      }
      if (session?.who === 'player') {
        if (!next.errandSession || next.slot >= session.returnAtSlot) {
          next = { ...next, errandSession: next.errandSession?.deliveryId === session.id ? undefined : next.errandSession };
          next = api.fn('moveOccupant')(next, api.fn('playerId'), 'taproom');
          return Delivery_배달정산하기(next, session, next.slot >= session.returnAtSlot);
        }
        return next;
      }
      return Delivery_주문추첨하기(next);
    }
    function Delivery_상태정리하기(state) {
      if (!state) return state;
      let next = Delivery_장소준비하기(state);
      const meta = Delivery_자료읽기(next);
      const pendingOffer = Delivery_주문복원하기(meta.pendingOffer);
      if (pendingOffer !== meta.pendingOffer) next = Delivery_자료쓰기(next, { pendingOffer });
      // v3 세이브의 진행 중 남편 배달도 한 번만 정산합니다.
      if (!meta.activeDelivery && next.errandSession?.reason === 'delivery' && next.errandSession.deliveryOffer) {
        const old = next.errandSession;
        next = Delivery_자료쓰기(next, { activeDelivery: { id: old.deliveryId, who: 'player', characterId: api.fn('playerId'),
          offer: old.deliveryOffer, startSlot: old.startSlot, returnAtSlot: old.returnAtSlot, customerIds: [] } });
      }
      const session = Delivery_자료읽기(next).activeDelivery;
      if (session) {
        const offer = Delivery_주문복원하기(session.offer);
        if (session.location !== DELIVERY_SITE || offer !== session.offer) {
          next = Delivery_자료쓰기(next, { activeDelivery: { ...session, offer, location: DELIVERY_SITE } });
          // 4.x가 공유하던 러브호텔에서 배달 담당자만 이동합니다. H_Status의 다른 입실자는 보존합니다.
          // 기본 moveOccupant는 현재 등록되지 않은 방을 버리므로, 저장에 있던 방까지 보존합니다.
          next = Delivery_입실자배치하기(next, session);
        }
        if (next.errandSession?.deliveryId === session.id && next.errandSession.deliveryOffer !== offer) {
          next = { ...next, errandSession: { ...next.errandSession, deliveryOffer: offer } };
        }
      }
      if (!Delivery_자료읽기(next).activeDelivery && meta.activeDeliveryId && !next.errandSession) {
        next = Delivery_자료쓰기(next, { activeDeliveryId: undefined });
      }
      return Delivery_세션유지하기(next);
    }

    Delivery_장소등록하기();
    api.actions.register('delivery/go-yourself', state => Delivery_배달시작하기(state, 'player'), { label: '직접 가기' });
    api.actions.register('delivery/send-wife', state => Delivery_배달시작하기(state, 'wife'), { label: "그녀를 보내기" });
    api.actions.register('delivery/decline', Delivery_주문거절하기, { label: '배달 거절' });
    api.hook('worldTick', {
      around(next, state, ...rest) {
        const prepared = Delivery_상태정리하기(state);
        const processed = next(prepared, ...rest);
        return Delivery_분진행처리하기(processed, prepared);
      }
    });
    api.hook('DeliveryDayEnd', { around(next, state, ...rest) {
      // 기본 뒷방처럼 외부 서빙도 마감 정산이 장면을 강제로 끊지 않게 합니다.
      return Delivery_아내세션읽기(state) ? state : next(state, ...rest);
    } });
    api.hook('reduceGameAction', { around(next, state, action, ...rest) {
      const prepared = Delivery_상태정리하기(state);
      const processed = next(prepared, action, ...rest);
      const session = Delivery_자료읽기(prepared).activeDelivery;
      if (session?.who === 'player' && !processed.errandSession && Delivery_자료읽기(processed).activeDelivery) {
        return Delivery_배달정산하기(processed, session, processed.slot >= session.returnAtSlot);
      }
      return processed;
    } });
    api.hook('processPatronInteractionTick', {
      around(next, state, ...rest) {
        if (projectionDepth || !Delivery_원격장면확인하기(state)) return next(state, ...rest);
        const session = Delivery_아내세션읽기(state);
        if (session.lastInteractionSlot === state.slot) return state;
        let progressed = false;
        const processed = Delivery_뒷방처리하기(state, projected => {
          const result = next(projected, ...rest);
          progressed = result !== projected;
          return result;
        });
        const scene = api.fn('patronScene')(state), bonus = Delivery_아내보너스읽기(session);
        // 실제로 진행된 배달 손님 장면만 집계하며, 같은 게임 분·선택 대기는 중복 지급하지 않습니다.
        const counted = progressed && !state.pendingEvent && !scene.playerEngaged
          && !['solo', 'husband_led'].includes(scene.kind)
          && state.customers.some(customer => customer.id === scene.customerId)
          && state.slot > bonus.lastCountedSlot;
        return Delivery_자료쓰기(processed, { activeDelivery: { ...Delivery_아내세션읽기(processed),
          lastInteractionSlot: state.slot, wifeBonus: counted ? { ...bonus,
            interactionMinutes: bonus.interactionMinutes + 1, lastCountedSlot: state.slot } : bonus } });
      }
    });
    api.hook('buildPatronMoveCandidates', { after: (candidates, [state, scene]) => Delivery_성적가중치적용하기(candidates, state, scene) });
    api.hook('transitionPatronStage', {
      before([scene, stage]) {
        if (projectionDepth && Delivery_설정읽기().hotelSexWeight === 0 && api.fn('isSexualStage')(stage)) {
          return { cancel: true, value: scene };
        }
      }
    });
    for (const name of ['DeliveryPatronOpportunity', 'DeliveryPatronRubbingOpportunity']) {
      api.hook(name, { around(next, state, ...args) {
        if (!Delivery_원격장면확인하기(state)) return next(state, ...args);
        const weight = Delivery_설정읽기().hotelSexWeight;
        return weight === 0 ? null : Delivery_첫추첨가중하기(() => next(state, ...args), weight);
      } });
    }
    api.hook('DeliveryPatronTactic', { after(result, [state]) {
      if (Delivery_원격장면확인하기(state) && Delivery_설정읽기().hotelSexWeight === 0 && Delivery_성적결과확인하기(result?.result)) return null;
    } });
    api.hook('DeliveryPatronAmbientContact', { after(result, [state]) {
      if (Delivery_원격장면확인하기(state) && Delivery_설정읽기().hotelSexWeight === 0 && Delivery_성적결과확인하기(result)) return null;
    } });
    api.hook('imageRoom', { before: ([room]) => room === DELIVERY_SITE ? ['upstairs_hall'] : undefined });
    for (const name of ['imageDescriptor', 'imagePrompt']) {
      api.hook(name, { before(args) {
        return args[1] === DELIVERY_SITE ? [args[0], api.fn('imageRoom')('upstairs_hall'), ...args.slice(2)] : undefined;
      } });
    }

    function Delivery_설정그리기(body, win) {
      const settings = Delivery_설정읽기();
      const fields = {};
      const feedback = api.ui.h('p', { role: 'status', 'aria-live': 'polite', class: 'wml-note', style: 'min-height:18px;margin:8px 0 0' });
      const form = api.ui.h('form', { 'data-delivery-settings-form': true,
        onsubmit(event) {
          event.preventDefault();
          if (!form.reportValidity()) return;
          Delivery_설정저장하기(Object.fromEntries(Object.entries(fields).map(([key, input]) => [key, Number(input.value)])));
          feedback.textContent = '저장했습니다.';
        }
      });
      form.append(api.ui.h('section', { 'data-delivery-settings-help': true,
        style: 'padding:12px;border:1px solid #44403c;border-radius:8px;background:#0c0a09;color:#d6d3d1;line-height:1.65' },
        api.ui.h('strong', { style: 'display:block;margin-bottom:6px;color:#fde68a' }, '부연설명'),
        api.ui.h('p', { style: 'margin:0 0 8px' }, api.ui.h('b', {}, "당신이 배달할 때 — 직접 가기"),
          api.ui.h('br'), '공방·경비 초소·창고·상단 숙영지·귀족 저택·성채 연회장 등 주문한 곳으로 직접 배달합니다. 왕복 30분 후 돌아오며, 주문에 표시된 음식값·배달료·명성을 받습니다.'),
        api.ui.h('p', { style: 'margin:0 0 8px' }, api.ui.h('b', {}, "그녀가 배달할 때 — 그녀를 보내기"),
          api.ui.h('br'), "같은 주문 목적지로 그녀가 배달합니다. ", WIFE_DURATION_NOTE, ". 독립된 배달장소에서 뒷방 서빙과 같은 방식으로 손님을 응대하며, 대화나 가벼운 접촉을 포함한 모든 상호작용이 끝나야 돌아옵니다. 귀환 시 주문 대금과 명성을 받으며, 기본 성적 행위 가중치는 2배입니다. 그녀 배달은 배달료만큼의 추가 팁을 받으며, 대화·접촉·후처리 등 실제 손님 장면이 진행된 1분마다 1골드의 보너스가 더해집니다. 이동·단순 대기·선택 대기는 집계하지 않습니다. 보너스는 귀환할 때 한 번 정산합니다."),
        api.ui.h('p', { class: 'wml-muted', style: 'margin:0;font-size:12px' },
          '날짜 쿨타임 없이 2일차부터 영업 중 매분 추첨합니다. 기본 확률과 시간 조건은 상인의 뒷방 이용 요청과 같습니다. 주문 대기·배달 중에는 추첨하지 않습니다.')));
      for (const [key, label, help] of [
        ['eventWeight', '배달 이벤트 발생 가중치', '0배: 주문 발생 중지 · 기본 1배'],
        ['hotelSexWeight', '배달장소 성적 행위 가중치', '0배: 성적 행위 진행 중지 · 기본 2배']
      ]) {
        const input = api.ui.h('input', { type: 'number', min: 0, max: 10, step: 'any', required: true, inputMode: 'decimal', value: settings[key],
          'data-delivery-setting': key, 'aria-label': label,
          style: 'width:76px;min-width:0;padding:7px 8px;border:1px solid #57534e;border-radius:6px;background:#292524;color:#fff;text-align:right;font:inherit',
          oninput() { feedback.textContent = '저장을 눌러 적용하세요.'; } });
        fields[key] = input;
        form.append(api.ui.h('label', { style: 'display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:12px;padding:14px 0;border-bottom:1px solid #292524' },
          api.ui.h('span', {}, api.ui.h('span', { style: 'display:block' }, label),
            api.ui.h('small', { class: 'wml-muted', style: 'display:block;margin-top:4px' }, help)),
          api.ui.h('span', { style: 'display:flex;align-items:center;gap:5px' }, input, '배')));
      }
      const restore = api.ui.button('기본값 복원', () => {
        for (const [key, input] of Object.entries(fields)) input.value = DEFAULTS[key];
        feedback.textContent = '기본값을 불러왔습니다. 저장을 눌러 적용하세요.';
      });
      restore.dataset.deliverySettingsRestore = 'true';
      const save = api.ui.button('저장', () => form.requestSubmit(), { primary: true });
      save.dataset.deliverySettingsSave = 'true';
      form.append(feedback, api.ui.h('div', { style: 'display:flex;justify-content:flex-end;gap:8px;padding-top:8px' }, restore, save));
      body.append(form);
    }
    function Delivery_설정열기() {
      return api.ui.window({ id: 'settings', title: '배달 모드 설정', width: 520, height: 660, settings: true, render: Delivery_설정그리기 });
    }
    // 기본 설정 등록만 사용해 일시정지 메뉴의 자동·구형 버튼 등록을 피합니다.
    wmlApi.ui.settings(Delivery_설정그리기);
    api.ui.addButton({ label: '배달', title: '배달 모드 설정', onClick: Delivery_설정열기 });

    function Delivery_주문창(props) {
      const state = api.fn('store')(root => root.state);
      const offer = Delivery_주문복원하기(Delivery_자료읽기(state).pendingOffer);
      if (!offer) return null;
      const stocked = Delivery_재고충족확인하기(state, offer);
      return jsx.jsx('div', { className: 'fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75',
        'data-delivery-offer': offer.id, children: jsx.jsxs('section', {
          role: 'dialog', 'aria-modal': true, 'aria-labelledby': 'delivery-offer-title',
          className: 'w-full max-w-lg max-h-[90vh] overflow-auto p-5 rounded-xl border border-amber-700 bg-stone-900 text-stone-200',
          children: [jsx.jsx('h2', { id: 'delivery-offer-title', className: 'text-lg font-bold text-amber-300', children: '배달 주문' }),
            jsx.jsx('p', { className: 'my-3 text-sm', children: `${offer.requester} · ${offer.request}` }),
            jsx.jsxs('div', { className: 'my-3 p-3 rounded border border-stone-700 bg-stone-950 text-sm space-y-1',
              'data-delivery-order-details': true, children: [
                jsx.jsx('div', { children: Delivery_주문표시하기(offer.order) }),
                jsx.jsx('div', { 'data-delivery-destination': true, children: `배달지: ${offer.destination}` }),
                jsx.jsx('div', { 'data-delivery-price': true, children: Delivery_대금표시하기(offer) }),
                jsx.jsx('div', { className: 'text-amber-200', 'data-delivery-reward': true,
                  children: `배달 완료: 명성 +${offer.renown}` })] }),
            jsx.jsx('p', { className: 'my-3 text-sm text-amber-200', 'data-delivery-wife-duration': true,
              children: `그녀 배달: ${WIFE_DURATION_NOTE}` }),
            ...[['delivery/go-yourself', '직접 가기', stocked, `왕복 30분 동안 그녀가 주점을 맡습니다. 완료하면 ${offer.totalPrice}골드 · 명성 +${offer.renown}.`],
              ['delivery/send-wife', Delivery_담당자이름(state)+'에게 배달 부탁하기', stocked && Delivery_아내가능확인하기(state), `배달장소에서 손님 응대 후 귀환합니다. 기본 대금 ${offer.totalPrice}골드에 보너스를 더해 받으며, 명성 +${offer.renown}.`],
              ['delivery/decline', '거절하기', true, `심부름꾼을 기다리게 둡니다. ${Delivery_거절결과표시하기(offer)}.`]]
              .map(([type, label, allowed, help]) => jsx.jsxs('button', {
                type: 'button', 'aria-label': label, disabled: !allowed, onClick: () => api.store.dispatch({ type }),
                className: 'w-full mt-2 p-3 rounded border border-stone-600 bg-stone-800 disabled:opacity-40',
                children: [jsx.jsx('span', { className: 'block', children: label }),
                  type === 'delivery/send-wife' && jsx.jsx('small', { className: 'block mt-1 text-xs text-amber-200',
                    'data-delivery-wife-bonus': true, children: Delivery_아내보너스예상표시하기(offer) }),
                  jsx.jsx('small', { className: 'block mt-1 text-xs text-stone-400', children: help })] }, type)),
            !stocked && jsx.jsx('p', { className: 'mt-2 text-xs', children: '주문을 보낼 재고가 부족합니다.' }),
            stocked && !Delivery_아내가능확인하기(state) && jsx.jsx('p', { className: 'mt-2 text-xs', children: Delivery_아내불가이유읽기(state) })]
        }) });
    }
    api.hook('DeliveryGameShell', { around(next, ...args) {
      const original = next(...args);
      return jsx.jsxs(React.Fragment, { children: [original, jsx.jsx(Delivery_주문창, {})] });
    } });
    api.hook('DeliveryEventModal', { around(next, props, ...rest) {
      const original = next(props, ...rest);
      return props.pendingEvent?.alert?.kind === orderKind ? null : original;
    } });
    function Delivery_장소카드만들기(state) {
      const session = Delivery_자료읽기(state).activeDelivery;
      const remaining = session && Math.max(0, (session.who === 'wife' ? Delivery_최소귀환시각읽기(session) : session.returnAtSlot) - state.slot);
      const progress = session?.who === 'wife'
        ? remaining > 0 ? `그녀 배달 중 · 최소 체류 ${remaining}분 남음` : "그녀 배달 중 · 손님 응대 마무리 후 귀환"
        : `배달 중 · 귀환까지 ${remaining}분`;
      const occupants = state.locations?.[DELIVERY_SITE]?.occupants || [];
      const names = occupants.map(id => id === api.fn('playerId') ? '당신'
        : state.characters?.[id]?.name || state.customers.find(customer => customer.id === id)?.name).filter(Boolean);
      return jsx.jsxs('div', { className: 'mt-1.5 p-2 rounded border border-stone-700 text-xs', 'data-delivery-site': true,
        children: [jsx.jsx('div', { className: 'text-stone-400', children: '배달장소' }),
          session && jsx.jsx('div', { className: 'text-stone-300 mt-1', children: `배달지: ${Delivery_주문복원하기(session.offer).destination}` }),
          jsx.jsx('div', { children: names.join(' · ') || '비어 있음' }),
          session && jsx.jsx('div', { className: 'text-amber-300 mt-1', children: progress }),
          session?.who === 'wife' && jsx.jsx('div', { className: 'text-amber-200 mt-1', 'data-delivery-bonus-progress': true,
            children: `응대 보너스 누적: +${Delivery_아내보너스계산하기(session).total}골드 · 상호작용 ${Delivery_아내보너스읽기(session).interactionMinutes}분` })] });
    }
    api.hook('DeliveryLocationPanel', { around(next, ...args) {
      const original = next(...args);
      return React.cloneElement(original, original.props, ...React.Children.toArray(original.props.children), Delivery_장소카드만들기(api.store.game()));
    } });
    globalThis.__waywardDeliveryAddon = {
      config: { minDay: MIN_DAY, durationMinutes: DURATION, deliveryLocation: DELIVERY_SITE, hotelLocation: DELIVERY_SITE },
      getSettings: Delivery_설정읽기, setSettings: Delivery_설정저장하기, openSettings: Delivery_설정열기,
      getOffer: () => Delivery_주문복원하기(Delivery_자료읽기(api.store.game()).pendingOffer) || null,
      getSession: () => Delivery_자료읽기(api.store.game()).activeDelivery || null,
      getBonus: () => { const session = Delivery_아내세션읽기(api.store.game()); return session ? Delivery_아내보너스계산하기(session) : null; },
      getReceipt: () => Delivery_자료읽기(api.store.game()).lastReceipt || null,
      accept: (who = 'player') => { const state = api.store.game(), next = Delivery_배달시작하기(state, who); if (next === state) return false; api.store.update(() => next); return true; },
      ignore: () => api.store.update(Delivery_주문거절하기),
      forceOffer: fee => { const state = api.store.game(), next = Delivery_주문추첨하기(state, true, fee); api.store.update(() => next); return !!next.deliveryAddon?.pendingOffer; },
      deliveryCard: Delivery_장소카드만들기, hotelCard: Delivery_장소카드만들기, prepare: Delivery_상태정리하기,
      ownsScene: Delivery_원격장면확인하기,
      ownsOrder: Delivery_주문소유확인하기,
      canSendWife: Delivery_아내가능확인하기, probability: Delivery_발생확률읽기,
      projectService: Delivery_뒷방처리하기, weightMoves: Delivery_성적가중치적용하기,
      orderText: Delivery_주문표시하기
    };
    // 아내 시점 병용 기능은 별도 delivery-compatible-wife-view-mode가 제공합니다.
    
    
    function Delivery_저장복원하기() {
      const state = api.store.game(), meta = Delivery_자료읽기(state);
      if (!state) return;
      if (meta.activeDelivery && meta.activeDelivery.location !== DELIVERY_SITE
        || Delivery_주문복원하기(meta.pendingOffer) !== meta.pendingOffer
        || !meta.activeDelivery && state.errandSession?.reason === 'delivery' && state.errandSession.deliveryOffer) {
        api.store.update(Delivery_상태정리하기);
      }
    }
    api.store.subscribe(Delivery_저장복원하기);
    Delivery_저장복원하기();
  }
});
