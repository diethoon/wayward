// 실행: node wml/mods/delivery/tests/portability.mjs
// seed 1138. 로더는 디스크에서 수정하지 않고 HTTP 응답에서만 구형 API 조건을 재현합니다.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import puppeteer from '../../../../MCP/node_modules/puppeteer-core/lib/puppeteer/puppeteer-core.js';
import * as acorn from '../../../../MCP/node_modules/acorn/dist/acorn.mjs';
import * as walk from '../../../../MCP/node_modules/acorn-walk/dist/walk.mjs';
import { findBrowser } from '../../../../MCP/lib/play.mjs';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../..');
const all = fs.readdirSync(path.join(root, 'wml/mods')).filter(id => fs.existsSync(path.join(root, 'wml/mods', id, 'mod.js')));
const uiMods = ['wife-view-mode','delivery','pregnancy','imagestudio','editor','brothel','badguest','anal-excuse'];
const replacements = new Map();
const packs = new Map();
function PortableTest_ZIP만들기(id) {
  const home=path.join(root,'wml/mods',id),locals=[],centrals=[];
  let offset=0;
  for(const relative of fs.readdirSync(home,{recursive:true}).filter(file=>fs.statSync(path.join(home,file)).isFile())){
    const name=Buffer.from(relative.replaceAll('\\','/')),data=fs.readFileSync(path.join(home,relative));
    let crc=0xffffffff;for(const byte of data){crc^=byte;for(let bit=0;bit<8;bit++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}crc=(crc^0xffffffff)>>>0;
    const local=Buffer.alloc(30);local.writeUInt32LE(0x04034b50);local.writeUInt16LE(20,4);local.writeUInt16LE(0x800,6);local.writeUInt32LE(crc,14);local.writeUInt32LE(data.length,18);local.writeUInt32LE(data.length,22);local.writeUInt16LE(name.length,26);
    const central=Buffer.alloc(46);central.writeUInt32LE(0x02014b50);central.writeUInt16LE(20,4);central.writeUInt16LE(20,6);central.writeUInt16LE(0x800,8);central.writeUInt32LE(crc,16);central.writeUInt32LE(data.length,20);central.writeUInt32LE(data.length,24);central.writeUInt16LE(name.length,28);central.writeUInt32LE(offset,42);
    locals.push(local,name,data);centrals.push(central,name);offset+=local.length+name.length+data.length;
  }
  const count=centrals.length/2,end=Buffer.alloc(22),directory=Buffer.concat(centrals);
  end.writeUInt32LE(0x06054b50);end.writeUInt16LE(count,8);end.writeUInt16LE(count,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);
  return Buffer.concat([...locals,directory,end]);
}
function PortableTest_구형API만들기() {
  let source=fs.readFileSync(path.join(root,'wml/runtime/wml-core.js'),'utf8');
  const edits=[];
  walk.ancestor(acorn.parse(source,{ecmaVersion:'latest'}),{Property(node,ancestors){
    if(!['pauseSettings','settings','window','h','button'].includes(node.key.name))return;
    if(!ancestors.some(parent=>parent.type==='Property'&&parent.key.name==='ui'))return;
    edits.push([node.value.start,node.value.end,'undefined']);
  }});
  for(const [start,end,value] of edits.sort((a,b)=>b[0]-a[0]))source=source.slice(0,start)+value+source.slice(end);
  source=source.replace('    Wml_메뉴설정설치하기();','    // 구형 조건: 공통 설정 메뉴 없음')
    .replace('symFailed = resolveModSymbols(state.order)','symFailed = new Set()')
    .replace(/^\[data-wml-(?:settings-window|mod-settings)\].*$/gm,'');
  return source;
}
const legacyCore=PortableTest_구형API만들기();
let mode='current';
const mime={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.webp':'image/webp','.png':'image/png','.ogg':'audio/ogg'};
const server=http.createServer((req,res)=>{
  const relative=decodeURIComponent(new URL(req.url,'http://localhost').pathname).slice(1);
  if(packs.has(relative)){res.writeHead(200,{'Content-Type':'application/zip'});res.end(packs.get(relative));return;}
  if(mode==='zip'&&relative==='wml/mods/mods.js'){res.writeHead(200,{'Content-Type':'text/javascript'});res.end('WML.enable([]);');return;}
  if(mode==='zip'&&relative.startsWith('wml/mods/')){res.writeHead(404);res.end();return;}
  const file=path.resolve(root,relative);
  if(!file.startsWith(root+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404);res.end();return;}
  res.writeHead(200,{'Content-Type':(mime[path.extname(file)]||'application/octet-stream')+'; charset=utf-8','Cache-Control':'no-store'});
  if(relative==='wml/runtime/wml-core.js'&&['legacy','zip'].includes(mode))res.end(legacyCore);
  else if(replacements.has(relative))res.end(replacements.get(relative));
  else fs.createReadStream(file).pipe(res);
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const origin=`http://127.0.0.1:${server.address().port}`;
const browser=await puppeteer.launch({executablePath:findBrowser(),headless:true,args:['--no-first-run','--no-default-browser-check','--disable-extensions']});
async function PortableTest_세션만들기(ids,{start=true,expectedFailed=[]}={}) {
  const context=await browser.createBrowserContext(),page=await context.newPage(),errors=[];
  await page.setViewport({width:1440,height:1000});
  await page.setRequestInterception(true);
  page.on('request',request=>{const url=request.url();if((!url.startsWith(origin+'/')&&!url.startsWith('data:')&&!url.startsWith('blob:'))||url.startsWith(origin+'/api/'))request.abort().catch(()=>{});else request.continue().catch(()=>{});});
  page.on('pageerror',error=>errors.push(error.stack || error.message));
  page.on('dialog',dialog=>dialog.dismiss());
  await page.evaluateOnNewDocument(({all,ids})=>{
    localStorage.setItem('wml.dev','true');localStorage.setItem('wml.folders',JSON.stringify(all));
    localStorage.setItem('wml.toggles',JSON.stringify(Object.fromEntries(all.map(id=>[id,ids.includes(id)]))));
    let seed=1138;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
  },{all,ids});
  await page.goto(origin+'/Wayward_WML_ko.html',{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>WML.status().booted);
  const failed=await page.evaluate(()=>WML.status().failed);
  assert.deepEqual(failed.map(row=>row.id),expectedFailed);
  if(!start)return {context,page,errors,failed};
  await page.evaluate(async()=>{
    for(let i=0;i<25;i++){
      if(document.querySelector('button[title="메뉴"]'))break;
      const buttons=[...document.querySelectorAll('button')].filter(button=>button.offsetParent&&!button.disabled);
      const button=buttons.find(button=>/^(예$|이해하고 동의합니다$|새 게임$|계속하기 —|시작 —|시작하기$|건너뛰기$)/.test(button.innerText.trim()))||buttons.find(button=>button.innerText.trim().startsWith('마라'));
      if(!button)throw Error('게임 시작 버튼 없음');button.click();await new Promise(resolve=>setTimeout(resolve,80));
    }
    if(!WML.dev().store.game())throw Error('새 게임 시작 실패');
  });
  return {context,page,errors};
}
try {
  for(mode of ['current','legacy']){
    const {context,page,errors}=await PortableTest_세션만들기(['addon-compat',...uiMods]);
    try{
      const result=await page.evaluate(async()=>{
        document.querySelector('button[title="메뉴"]').click();await new Promise(resolve=>setTimeout(resolve,100));
        const buttons=[...document.querySelectorAll('[data-wayward-native-settings]')];
        const list=buttons[0].parentElement,children=[...list.children].filter(node=>node.tagName==='BUTTON');
        const first=children.indexOf(buttons[0]);
        const rows=[];
        for(const button of buttons){button.click();await new Promise(resolve=>setTimeout(resolve,70));
          const id=button.dataset.waywardNativeSettings;
          const legacy={editor:'#wc2-customer-editor',brothel:'#ww-settings',pregnancy:'#wc2-pregnancy-settings-265',imagestudio:'#wwis-overlay'};
          const panel=legacy[id]?document.querySelector(legacy[id]):document.querySelector(`[data-wayward-native-window^="${id}:"]`);
          if(!panel)throw Error('설정 창 없음: '+id);
          const input=panel.querySelector('input,button')||panel,rect=input.getBoundingClientRect();
          rows.push({id,color:getComputedStyle(button).backgroundColor,front:panel.contains(document.elementFromPoint(rect.x+Math.min(rect.width/2,15),rect.y+Math.min(rect.height/2,8)))});
          if(id==='editor')panel.querySelector('.wce-close').click();
          else if(id==='brothel')panel.hidden=true;
          else if(id==='pregnancy')panel.querySelector('button').click();
          else if(id==='imagestudio')document.querySelector('#wwis-close').click();
          else panel.querySelector('.wayward-native-window-title button').click();
        }
        return {rows,first,grouped:buttons.every((button,i)=>children[first+i]===button),pauseVisible:list.isConnected};
      });
      assert.equal(result.rows.length,8);assert.equal(result.first,4);assert.equal(result.grouped,true);assert.equal(result.pauseVisible,true);
      assert.ok(result.rows.every(row=>row.front),JSON.stringify(result));
      assert.equal(new Set(result.rows.map(row=>row.color)).size,1);assert.deepEqual(errors,[]);
      console.log('PASS '+mode+' core: 8 HTML menu buttons, shared distinct color, foreground settings');
    }finally{await context.close();}
  }
  mode='legacy';
  const legacyWife=fs.readFileSync(path.join(root,'wml/mods/wife-view-mode/mod_v0.9.0.backup'),'utf8');
  replacements.set('wml/mods/wife-view-mode/mod.js',legacyWife);
  // 구형 상대 모드는 자체 의미 이름 기능을 사용하므로 이 조합은 해당 기능만 유지합니다.
  const normalSymbols=fs.readFileSync(path.join(root,'wml/runtime/wml-core.js'),'utf8').replace(/pauseSettings: opts =>[^\n]+/, 'pauseSettings: undefined,').replace('    Wml_메뉴설정설치하기();','');
  replacements.set('wml/runtime/wml-core.js',normalSymbols);
  mode='patched-legacy';
  const {context,page,errors}=await PortableTest_세션만들기(['addon-compat','delivery','wife-view-mode','pregnancy','delivery-compatible-wife-view-mode','pregnancy-compatible-wife-view-mode']);
  try{
    const results=await page.evaluate(async()=>{
      const api=WML.dev(),base=structuredClone(api.store.game());
      function PortableTest_상태복원하기(){const state=structuredClone(base);state.mods={...state.mods,'wife-view-mode':{...state.mods?.['wife-view-mode'],active:true}};state.day=3;state.slot=2*1440+1020;state.phase='service';state.readyFood=100;state.supplies={...state.supplies,beer:100,wine:100};state.pendingEvent=undefined;state.alertQueue=[];state.activeScene={};state.customers=[];state.errandSession=undefined;state.deliveryAddon={};for(const room of Object.values(state.locations))room.occupants=[];state.locations.taproom.occupants=['player',state.primaryCharacterId];Object.assign(state.characters[state.primaryCharacterId],{currentTask:'idle',busyUntilSlot:0,locationUntilSlot:undefined});api.store.update(()=>state);__waywardDeliveryAddon.setSettings({eventWeight:0});}
      PortableTest_상태복원하기();__waywardDeliveryAddon.forceOffer(20);await new Promise(resolve=>setTimeout(resolve,80));
      const order={present:!!api.store.game().deliveryAddon.pendingOffer,paused:api.store.game().mods['wife-view-mode'].active===false};
      const accepted=__waywardDeliveryAddon.accept('wife');const session=api.store.game().deliveryAddon.activeDelivery;
      const delegated={accepted,paused:api.store.game().mods['wife-view-mode'].active===false,owns:__waywardDeliveryCompatibleWifeView.ownsWife(api.store.game())};
      const mod=__waywardDeliveryAddon,random=Math.random;Math.random=()=>.999999;
      let state=api.store.game();state={...state,slot:session.minimumReturnAtSlot-1,pendingEvent:undefined,alertQueue:[]};
      state=mod.projectService(state,projected=>api.fn('startPatronInteraction')(projected,session.customerIds[0]));
      state={...state,activeScene:{...state.activeScene,patron:{...api.fn('patronScene')(state),stage:'chatting',ticksElapsed:0,ticksAtStage:0,stalled:0,elenaComfort:60,patronBoldness:0,patronPleasure:0,playerEngaged:false}}};
      state=api.fn('tick')(state);api.store.update(()=>state);
      const extended=!!mod.getSession()&&api.store.game().mods['wife-view-mode'].active===false;
      state=mod.projectService(api.store.game(),projected=>api.fn('endPatronInteraction')(projected,'patron_satisfied_chat',{suppressEndText:true}));
      state=api.fn('tick')({...state,pendingEvent:undefined,alertQueue:[]});api.store.update(()=>state);Math.random=random;
      const nativeReturned=!mod.getSession()&&api.fn('wifeLocation')(api.store.game())==='taproom';
      const restored=api.store.game().mods['wife-view-mode'].active===true;
      PortableTest_상태복원하기();api.store.dispatch({type:'talk_to_wife'});api.store.dispatch({type:'wife_topic',topicId:'pregnancy_ask_cycle_medicine'});await new Promise(resolve=>setTimeout(resolve,80));
      const medicine={type:api.store.game().pendingEvent?.type,paused:api.store.game().mods['wife-view-mode'].active===false,choices:api.store.game().pendingEvent?.choices?.length};
      api.store.dispatch({type:'wife_topic',topicId:'pregnancy_medicine_follicular'});api.store.update(state=>({...state,pendingEvent:undefined}));
      const medicineRestored=api.store.game().mods['wife-view-mode'].active===true;
      PortableTest_상태복원하기();api.store.update(state=>({...state,pendingEvent:{type:'alert',customerName:'임신 반응',text:'반응 테스트',choices:[{id:'dismiss',label:'계속하기'}],alert:{id:'test',kind:'wc2_pregnancy_reaction',title:'임신 반응',body:'반응 테스트',choices:[{id:'dismiss',label:'계속하기'}]}}}));
      await new Promise(resolve=>setTimeout(resolve,100));const reactionKept=api.store.game().pendingEvent?.alert?.kind==='wc2_pregnancy_reaction';
      const reaction=structuredClone(api.store.game().pendingEvent);
      PortableTest_상태복원하기();mod.forceOffer(20);mod.accept('wife');
      api.store.update(state=>({...state,pendingEvent:reaction}));
      const owners=api.store.game().mods['wife-view-mode'].portableCompatibility?.owners;
      api.store.update(state=>JSON.parse(JSON.stringify(state)));
      const saveKept=api.store.game().mods['wife-view-mode'].active===false&&api.store.game().mods['wife-view-mode'].portableCompatibility?.wasActive===true;
      api.store.update(state=>({...state,deliveryAddon:{}}));
      const waitingForReaction=api.store.game().mods['wife-view-mode'].active===false;
      api.store.update(state=>({...state,deliveryAddon:{},pendingEvent:undefined}));
      const finalRestored=api.store.game().mods['wife-view-mode'].active===true;
      PortableTest_상태복원하기();api.store.update(state=>({...state,mods:{...state.mods,'wife-view-mode':{...state.mods['wife-view-mode'],active:false}}}));
      mod.forceOffer(20);const originallyOff=!api.store.game().mods['wife-view-mode'].portableCompatibility;
      api.store.dispatch({type:'resolve_event',choiceId:'decline'});const staysOff=api.store.game().mods['wife-view-mode'].active===false;
      return {order,delegated,extended,nativeReturned,restored,medicine,medicineRestored,reactionKept,owners,saveKept,waitingForReaction,finalRestored,originallyOff,staysOff};
    });
    assert.ok(results.order.present&&results.order.paused&&results.delegated.accepted&&results.delegated.paused&&results.delegated.owns&&results.extended&&results.nativeReturned&&results.restored&&results.originallyOff&&results.staysOff,JSON.stringify(results));
    assert.equal(results.medicine.type,'wife_conversation');assert.ok(results.medicine.paused&&results.medicine.choices>=3&&results.medicineRestored&&results.reactionKept&&results.finalRestored,JSON.stringify(results));
    assert.deepEqual(results.owners,['delivery-compatible-wife-view-mode','pregnancy-compatible-wife-view-mode']);assert.ok(results.saveKept&&results.waitingForReaction,JSON.stringify(results));
    assert.deepEqual(errors,[]);console.log('PASS legacy Wife_View_Mode 0.9.0: independent Delivery and pregnancy guards, manual choices and restoration');
  }finally{await context.close();}
  replacements.clear();mode='current';
  replacements.set('wml/mods/pregnancy/mod.js',fs.readFileSync(path.join(root,'wml/mods/pregnancy/mod.js'),'utf8').replace('getReactionCatalog:', 'missingReactionCatalog:'));
  const capability=await PortableTest_세션만들기(['addon-compat','pregnancy','wife-view-mode','pregnancy-compatible-wife-view-mode'],{start:false,expectedFailed:['pregnancy-compatible-wife-view-mode']});
  assert.match(capability.failed[0].error,/주기 약·반응 기능이 없습니다/);await capability.context.close();
  console.log('PASS missing pregnancy capability: descriptive installation error');
  replacements.clear();mode='zip';
  const installed=['addon-compat',...uiMods,'delivery-compatible-wife-view-mode','pregnancy-compatible-wife-view-mode'];
  for(const id of installed)packs.set('__portable-pack/'+id+'.zip',PortableTest_ZIP만들기(id));
  const zipped=await PortableTest_세션만들기(installed,{start:false});
  try{
    const installResults=await zipped.page.evaluate(async ids=>{
      const files=await Promise.all(ids.map(async id=>({path:id+'.zip',blob:new File([await(await fetch('/__portable-pack/'+id+'.zip')).blob()],id+'.zip')})));
      return WML.install(files);
    },installed);
    assert.ok(installResults.every(row=>row.mode==='browser'));assert.equal(installResults.length,installed.length);
    await zipped.page.reload({waitUntil:'domcontentloaded'});await zipped.page.waitForFunction(()=>WML.status().booted);
    const loaded=await zipped.page.evaluate(()=>WML.status());assert.deepEqual(loaded.failed,[]);assert.deepEqual([...loaded.loaded].sort(),[...installed].sort());
    await zipped.page.evaluate(async()=>{
      for(let i=0;i<25;i++){
        if(document.querySelector('button[title="메뉴"]'))break;
        const buttons=[...document.querySelectorAll('button')].filter(button=>button.offsetParent&&!button.disabled);
        const button=buttons.find(button=>/^(예$|이해하고 동의합니다$|새 게임$|계속하기 —|시작 —|시작하기$|건너뛰기$)/.test(button.innerText.trim()))||buttons.find(button=>button.innerText.trim().startsWith('마라'));
        if(!button)throw Error('ZIP 설치 후 게임 시작 버튼 없음');button.click();await new Promise(resolve=>setTimeout(resolve,80));
      }
      document.querySelector('button[title="메뉴"]').click();await new Promise(resolve=>setTimeout(resolve,80));
    });
    assert.equal(await zipped.page.$$eval('[data-wayward-native-settings]',nodes=>nodes.length),8);assert.deepEqual(zipped.errors,[]);
    console.log('PASS folder-only ZIP: 11 independently packaged mods installed from ZIP, disk copies absent, old UI API absent');
  }finally{await zipped.context.close();}
}finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
