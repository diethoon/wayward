// 실행: 게임 폴더에서 node wml/mods/delivery/tests/regression.mjs
// seed 1138, MCP의 독립 브라우저에서 단독/호환/아내 시점 조합을 검증합니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { playStart, playEval, playStatus, playStop, playScreenshot, playReload } from '../../../../MCP/lib/play.mjs';
import { checkMod } from '../../../../MCP/lib/check.mjs';
import { readModsJs } from '../../../../MCP/lib/mods.mjs';

const screenshot = process.argv.includes('--screenshot');
const combinations = process.argv.includes('--standalone') ? ['standalone']
  : process.argv.includes('--wife-view-only') || process.argv.includes('--wife-view') ? ['wife-view-only']
  : ['standalone', 'wife-view-only'];
async function DeliveryTest_평가하기(code) { return (await playEval({ code })).result; }
const listed = readModsJs().entries;
const isolatedMods = Object.fromEntries(listed.map(entry => [entry.id, false]));
for (const id of ['delivery', 'wife-view-mode', 'delivery-compatible-wife-view-mode']) {
  const check = checkMod(id);
  assert.ok(check.ok, JSON.stringify(check));
}
for (const combination of combinations) {
  const wifeViewOn = combination === 'wife-view-only';
  try {
    let started = await playStart({ mods: {
      ...isolatedMods,
      delivery: true, 'h-status': false, 'wife-view-mode': wifeViewOn,
      'delivery-compatible-wife-view-mode': wifeViewOn,
      'addon-compat': false, imagestudio: false
    }, ...(process.argv.includes('--mobile') ? {viewport:{width:390,height:844}} : {}) });
    if(wifeViewOn){
      await DeliveryTest_평가하기("localStorage.setItem('wml.folders',JSON.stringify(['delivery-compatible-wife-view-mode']))");
      started=await playReload({});
    }
    assert.deepEqual(started.failed, []);
    assert.ok(started.loaded.includes('delivery'));
    assert.equal(started.loaded.includes('delivery-compatible-wife-view-mode'),wifeViewOn);
    console.log(`START ${combination}: ${started.loaded.join(', ')}`);
    await DeliveryTest_평가하기(`
      for (let step = 0; step < 25; step++) {
        const buttons = [...document.querySelectorAll('button')].filter(button => button.offsetParent);
        if (document.querySelector('button[title="메뉴"]')) break;
        const button = buttons.find(item => !item.disabled && /^(예$|이해하고 동의합니다$|새 게임$|계속하기 —|시작 —|시작하기$|건너뛰기$)/.test(item.innerText.trim()))
          || buttons.find(item => item.innerText.trim().startsWith('마라'));
        if (!button) throw Error('새 게임 시작 버튼 없음: ' + buttons.map(item => item.innerText).join(' / '));
        button.click(); await new Promise(resolve => setTimeout(resolve, 150));
      }
      const api = WML.dev();
      if (!api.store.game()) throw Error('새 게임 없음');
      globalThis.deliveryTestSeed = 1138;
      Math.random = function DeliveryTest_난수만들기() {
        globalThis.deliveryTestSeed = (Math.imul(globalThis.deliveryTestSeed, 1664525) + 1013904223) >>> 0;
        return globalThis.deliveryTestSeed / 4294967296;
      };
      globalThis.deliveryTestBase = structuredClone(api.store.game());
      if (WML.status().loaded.includes('wife-view-mode')) {
        globalThis.deliveryTestBase.mods = {...globalThis.deliveryTestBase.mods,
          'wife-view-mode': {...globalThis.deliveryTestBase.mods?.['wife-view-mode'],active:true,wifeIntent:'self'}};
      }
      globalThis.DeliveryTest_초기화하기 = function() {
        const state = structuredClone(globalThis.deliveryTestBase);
        state.slot = 2 * 1440 + 1020; state.day = 3; state.phase = 'service';
        state.readyFood = 100; state.supplies = { ...state.supplies, beer: 100, wine: 100 };
        state.pendingEvent = undefined; state.alertQueue = []; state.activeScene = {};
        state.customers = []; state.errandSession = undefined; state.deliveryAddon = {};
        state.economy.gold = 100; state.economy.debt = 0; state.pendingCollectorVisit = false;
        state.tavern.backRoomReady = true;
        for (const value of Object.values(state.locations)) value.occupants = [];
        state.locations.taproom.occupants = ['player', state.primaryCharacterId];
        const wife = state.characters[state.primaryCharacterId];
        Object.assign(wife, { currentTask: 'idle', busyUntilSlot: 0, taskTarget: undefined, locationUntilSlot: undefined });
        if (state.situationEventMod) for (const key of ['hotelSession', 'intrusion', 'observation', 'cardFunding', 'suspiciousPatron', 'crestAutonomy']) state.situationEventMod[key] = null;
        api.store.update(() => state);
        globalThis.__waywardDeliveryAddon.setSettings({ eventWeight: 0, hotelSexWeight: 2 });
        return state;
      };
      return DeliveryTest_초기화하기().slot;
    `);
    assert.deepEqual(await DeliveryTest_평가하기('__waywardDeliveryAddon.getSettings()'), { eventWeight: 0, hotelSexWeight: 2 });
    const probability = await DeliveryTest_평가하기(`
      const mod = __waywardDeliveryAddon;
      mod.setSettings({ eventWeight: 1 }); const base = mod.probability();
      mod.setSettings({ eventWeight: 10 }); const ten = mod.probability();
      mod.setSettings({ eventWeight: 0 }); return { base, ten, zero: mod.probability() };
    `);
    assert.equal(probability.base, 0.1 / 360);
    assert.equal(probability.ten, probability.base * 10);
    assert.equal(probability.zero, 0);

    const destinations = ['가죽공방 뒤편 작업장', '서문 야간 경비 초소', '강변 상인 조합 창고',
      '북문 밖 상단 숙영지', '언덕 위 귀족 저택', '성채 안뜰의 사냥 연회장'];
    const detailedOrders = await DeliveryTest_평가하기(`
      const mod=__waywardDeliveryAddon,results=[];
      for(const fee of [20,30,40,60,80,100]) {
        DeliveryTest_초기화하기();mod.forceOffer(fee);
        await new Promise(resolve=>setTimeout(resolve,100));
        const offer=mod.getOffer(),api=WML.dev(),text=document.querySelector('[data-delivery-offer]').textContent;
        results.push({destination:offer.destination,fee:offer.fee,renown:offer.renown,
          priceCorrect:offer.itemPrice===offer.order.food*5+offer.order.beer*3+offer.order.wine*6,
          totalCorrect:offer.totalPrice===offer.itemPrice+offer.fee,
          stockUnchanged:api.store.game().readyFood===100&&api.store.game().supplies.beer===100&&api.store.game().supplies.wine===100,
          detailCorrect: text.includes('배달지: '+offer.destination)&&text.includes(mod.orderText(offer.order))
            &&text.includes('음식값 '+offer.itemPrice+'골드 + 배달료 '+fee+'골드 = 총 '+offer.totalPrice+'골드')
            &&text.includes('배달 완료: 명성 +'+offer.renown)
            &&text.includes('명성 '+offer.refuseRenown+' · 악명 +'+(offer.refuseNotoriety||0)),
          bonusBelowWife:document.querySelector('[data-delivery-wife-bonus]')?.previousElementSibling?.textContent===api.fn('wife')(api.store.game()).name+'에게 배달 부탁하기',
          bonusForecast:document.querySelector('[data-delivery-wife-bonus]')?.textContent.includes('+'+fee+'~'+(fee+30)+'골드')
            &&text.includes('상호작용 0~30분 기준')&&text.includes('실제 응대 1분마다 +1골드'),
          logCorrect:api.store.game().pendingEvent.alert.body.includes(offer.destination)
            &&api.store.game().pendingEvent.alert.body.includes('완료하면 명성 +'+offer.renown)});
      }
      DeliveryTest_초기화하기();return results;
    `);
    assert.deepEqual(detailedOrders.map(offer=>offer.destination),destinations);
    assert.deepEqual(detailedOrders.map(offer=>offer.renown),[1,1,2,3,4,5]);
    assert.ok(detailedOrders.every(offer=>offer.priceCorrect&&offer.totalCorrect&&offer.stockUnchanged&&offer.detailCorrect&&offer.logCorrect&&offer.bonusBelowWife&&offer.bonusForecast),JSON.stringify(detailedOrders));
    console.log(`PASS ${combination}: all six original destinations, quantities, price breakdown, renown and refusal consequences`);

    const guards = await DeliveryTest_평가하기(`
      const api=WML.dev(),mod=__waywardDeliveryAddon;
      DeliveryTest_초기화하기();mod.forceOffer(20);
      api.store.update(state=>({...state,readyFood:0,supplies:{...state.supplies,beer:0,wine:0}}));
      const empty=api.store.game(),failedPlayer=mod.accept('player'),failedWife=mod.accept('wife');
      const kept=api.store.game()===empty && mod.ownsOrder(api.store.game());
      DeliveryTest_초기화하기();mod.forceOffer(20);
      api.store.update(state=>api.fn('updateWife')(state,wife=>({...wife,currentTask:'sleeping',busyUntilSlot:state.slot+5})));
      const busy=api.store.game(),busyFailed=mod.accept('wife'),busyKept=api.store.game()===busy;
      DeliveryTest_초기화하기();
      return {failedPlayer,failedWife,kept,busyFailed,busyKept};
    `);
    assert.deepEqual(guards,{failedPlayer:false,failedWife:false,kept:true,busyFailed:false,busyKept:true});

    const ordinaryService = await DeliveryTest_평가하기(`
      const api=WML.dev(),mod=__waywardDeliveryAddon,symbols=WML.status().modSymbols.delivery,results=[];
      for(const task of ['greeting','taking_order','serving','cleaning','cooking']) {
        DeliveryTest_초기화하기();
        api.store.update(state=>api.fn('updateWife')(state,wife=>({...wife,currentTask:task,taskTarget:'hall-service',busyUntilSlot:state.slot+5})));
        if(!mod.forceOffer(20))throw Error('일반 응대 중 주문 생성 실패');
        await new Promise(resolve=>setTimeout(resolve,80));
        const before=api.store.game(),offer=mod.getOffer(),button=[...document.querySelectorAll('[data-delivery-offer] button')].find(button=>button.getAttribute('aria-label')===api.fn('wife')(api.store.game()).name+'에게 배달 부탁하기');
        const nativeAllowed=api.fn(symbols.DeliveryBackRoomWifeAvailable)(before);
        const enabled=!button.disabled;button.click();
        const after=api.store.game();
        results.push({task,nativeAllowed,enabled,who:mod.getSession()?.who,room:api.fn('wifeLocation')(after),
          retargeted:api.fn('wife')(after).taskTarget==='delivery',
          stockOnce:before.readyFood-after.readyFood===offer.order.food&&before.supplies.beer-after.supplies.beer===offer.order.beer&&before.supplies.wine-after.supplies.wine===offer.order.wine});
      }
      DeliveryTest_초기화하기();return results;
    `);
    assert.ok(ordinaryService.every(result=>result.nativeAllowed&&result.enabled&&result.who==='wife'&&result.room==='delivery_site'&&result.retargeted&&result.stockOnce),JSON.stringify(ordinaryService));
    const hallHandoff = await DeliveryTest_평가하기(`
      const api=WML.dev(),mod=__waywardDeliveryAddon,symbols=WML.status().modSymbols.delivery;
      DeliveryTest_초기화하기();
      api.store.update(state=>{
        const guest=api.fn(symbols.DeliveryPartyCustomers)(state,'merchants',2)[0];
        return {...state,customers:[guest],locations:{...state.locations,taproom:{...state.locations.taproom,occupants:[...state.locations.taproom.occupants,guest.id]}}};
      });
      if(!mod.forceOffer(20))throw Error('홀 응대 테스트 주문 없음');
      api.store.update(state=>api.fn('startPatronInteraction')(state,state.customers[0].id));
      const before=api.store.game(),hadScene=!!api.fn('patronScene')(before),guest=structuredClone(before.customers[0]);
      const nativeAllowed=api.fn(symbols.DeliveryBackRoomWifeAvailable)(before),sent=mod.accept('wife'),after=api.store.game();
      const result={hadScene,nativeAllowed,sent,cleared:!api.fn('patronScene')(after),room:api.fn('wifeLocation')(after),
        guestKept:JSON.stringify(guest)===JSON.stringify(after.customers.find(customer=>customer.id===guest.id))&&after.locations.taproom.occupants.includes(guest.id)};
      DeliveryTest_초기화하기();return result;
    `);
    assert.deepEqual(hallHandoff,{hadScene:true,nativeAllowed:true,sent:true,cleared:true,room:'delivery_site',guestKept:true});
    const protectedService = await DeliveryTest_평가하기(`
      const api=WML.dev(),mod=__waywardDeliveryAddon,results=[];
      for(const condition of ['sleeping','passed_out','retired','reserved','other-room','special-scene','table','errand']) {
        DeliveryTest_초기화하기();mod.forceOffer(20);
        api.store.update(state=>{
          if(condition==='other-room')return api.fn('moveOccupant')(state,state.primaryCharacterId,'back_room');
          if(condition==='special-scene')return {...state,activeScene:{...state.activeScene,situation:{kind:'reserved'}}};
          if(condition==='table')return {...state,activeScene:{...state.activeScene,table:{kind:'reserved'}}};
          if(condition==='errand')return {...state,errandSession:{reason:'market',returnAtSlot:state.slot+10}};
          return api.fn('updateWife')(state,wife=>({...wife,...(condition==='retired'?{retiredAtSlot:state.slot}:condition==='reserved'?{locationUntilSlot:state.slot+10}:{currentTask:condition})}));
        });
        const before=api.store.game();results.push({condition,allowed:mod.canSendWife(before),sent:mod.accept('wife'),same:before===api.store.game()});
      }
      DeliveryTest_초기화하기();return results;
    `);
    assert.ok(protectedService.every(result=>!result.allowed&&!result.sent&&result.same),JSON.stringify(protectedService));
    console.log(`PASS ${combination}: greeting/menu/order/serving can be delegated; native hall handoff and protected situations preserved`);

    const rolled = await DeliveryTest_평가하기(`
      const api=WML.dev(),mod=__waywardDeliveryAddon,random=Math.random;
      DeliveryTest_초기화하기();mod.setSettings({eventWeight:10});let rollCount=0;
      Math.random=function DeliveryTest_주문추첨난수() {
        if(new Error().stack.includes('Delivery_주문추첨하기')) {rollCount++;return 0;}
        return random();
      };
      try {
        let state=api.store.game();
        for(let index=0;index<10&&!state.deliveryAddon.pendingOffer;index++) {
          state={...state,pendingEvent:undefined,alertQueue:[]};state=api.fn('tick')(state);
        }
        api.store.update(()=>state);
        const natural=mod.ownsOrder(state),beforeRoll=rollCount;
        if(!mod.accept('wife'))throw Error('추첨된 주문의 아내 배달 실패');
        state=api.fn('tick')(api.store.game());api.store.update(()=>state);
        const paused=rollCount===beforeRoll;
        DeliveryTest_초기화하기();mod.setSettings({eventWeight:10});
        state={...api.store.game(),phase:'prep',slot:2*1440+600};state=api.fn('tick')(state);api.store.update(()=>state);
        const offHours=rollCount===beforeRoll;
        DeliveryTest_초기화하기();return {natural,paused,offHours,rollCount};
      } finally {Math.random=random;}
    `);
    assert.equal(rolled.natural,true);assert.equal(rolled.paused,true);assert.equal(rolled.offHours,true);assert.ok(rolled.rollCount>0);
    console.log(`PASS ${combination}: per-minute order roll, service hours, paused rolls and rejected stale choices`);

    const order = await DeliveryTest_평가하기(`
      const api = WML.dev(), mod = __waywardDeliveryAddon;
      if (!mod.forceOffer(40)) throw Error('주문 생성 실패');
      await new Promise(resolve => setTimeout(resolve, 200));
      return { name:api.fn('wife')(api.store.game()).name, labels: [...document.querySelectorAll('[data-delivery-offer] button')].map(button => button.getAttribute('aria-label')),
        wifeDuration: document.querySelector('[data-delivery-wife-duration]')?.textContent,
        pendingType: api.store.game().pendingEvent?.type, wifeEnabled: ![...document.querySelectorAll('[data-delivery-offer] button')].find(button => button.getAttribute('aria-label') === api.fn('wife')(api.store.game()).name+'에게 배달 부탁하기').disabled,
        overflow: document.documentElement.scrollWidth > window.innerWidth };
    `);
    assert.deepEqual(order.labels, ['직접 가기', order.name+'에게 배달 부탁하기', '거절하기']);
    assert.equal(order.wifeDuration,'그녀 배달: 최소 30분이 소요되나, 손님과 더 시간을 보낼수도 있습니다');
    assert.equal(order.pendingType, 'alert');
    assert.equal(order.wifeEnabled, true);
    assert.equal(order.overflow, false);
    if (screenshot && combination === 'standalone') fs.writeFileSync(new URL('./delivery-offer.jpg', import.meta.url), Buffer.from(await playScreenshot({}), 'base64'));
    const sent = await DeliveryTest_평가하기(`
      const api = WML.dev(), mod = __waywardDeliveryAddon;
      const before = api.store.game(), offer = mod.getOffer();
      document.querySelectorAll('[data-delivery-offer] button')[1].click();
      await new Promise(resolve => setTimeout(resolve, 150));
      const state = api.store.game(), session = mod.getSession();
      if (!session) throw Error('아내 배달 시작 실패: ' + JSON.stringify(state.pendingEvent));
      globalThis.deliveryTestOrder = offer;
      return { who: session.who, room: api.fn('wifeLocation')(state), playerRoom: api.fn('playerLocation')(state),
        spent: { food: before.readyFood - state.readyFood, beer: before.supplies.beer - state.supplies.beer, wine: before.supplies.wine - state.supplies.wine },
        order: offer.order, ids: session.customerIds.length, duplicate: Object.values(state.locations).filter(room => room.occupants.includes(session.characterId)).length,
        doubleOrder: mod.forceOffer() };
    `);
    assert.equal(sent.who, 'wife'); assert.equal(sent.room, 'delivery_site'); assert.equal(sent.playerRoom, 'taproom');
    assert.deepEqual(sent.spent, sent.order); assert.ok(sent.ids >= 2); assert.equal(sent.duplicate, 1); assert.equal(sent.doubleOrder, false);
    console.log(`PASS ${combination}: native order UI, wife route, single stock deduction, exclusive location`);
    const weighted = await DeliveryTest_평가하기(`
      const api = WML.dev(), mod = __waywardDeliveryAddon, state = api.store.game(), session = mod.getSession();
      const scene = { characterId: session.characterId, customerId: session.customerIds[0] };
      const candidates = [{move:{kind:'rung',target:'flirting'},weight:3},{move:{kind:'rung',target:'sex_patron'},weight:5}];
      mod.setSettings({hotelSexWeight:2}); const two = mod.weightMoves(candidates,state,scene);
      mod.setSettings({hotelSexWeight:0}); const zero = mod.weightMoves(candidates,state,scene);
      mod.setSettings({hotelSexWeight:10}); const ten = mod.weightMoves(candidates,state,scene);
      mod.setSettings({hotelSexWeight:0}); return {two,zero,ten};
    `);
    assert.deepEqual(weighted.two.map(candidate => candidate.weight), [3, 10]);
    assert.equal(weighted.zero.length, 1); assert.deepEqual(weighted.ten.map(candidate => candidate.weight), [3, 50]);

    const ticked = await DeliveryTest_평가하기(`
      const api = WML.dev(), mod = __waywardDeliveryAddon;
      api.store.update(state => ({...state, locations:{...state.locations, back_room:{occupants:[], meta:{testSentinel:'keep-real-back-room'}}}}));
      let state = api.store.game();
      const beforeStock = {food:state.readyFood,beer:state.supplies.beer,wine:state.supplies.wine};
      state = api.fn('tick')(state);
      api.store.update(() => state);
      return { room: api.fn('wifeLocation')(state), task: api.fn('wife')(state).currentTask,
        realRoom: state.locations.back_room.meta.testSentinel, elapsed: state.slot - mod.getSession().startSlot,
        lastRollSlot: state.deliveryAddon.lastRollSlot, beforeStock,
        afterStock:{food:state.readyFood,beer:state.supplies.beer,wine:state.supplies.wine},
        imageRoom: api.fn('imageRoom')('delivery_site'), image: api.fn('imageDescriptor')(api.fn('wife')(state),'delivery_site').room };
    `);
    assert.equal(ticked.room, 'delivery_site'); assert.equal(ticked.task, 'serving'); assert.equal(ticked.realRoom, 'keep-real-back-room');
    assert.equal(ticked.elapsed, 1); assert.deepEqual(ticked.beforeStock, ticked.afterStock);
    assert.equal(ticked.imageRoom, 'bedroom'); assert.equal(ticked.image, 'bedroom');
    await DeliveryTest_평가하기(`
      const api=WML.dev();api.store.update(state=>JSON.parse(JSON.stringify(state)));
      if(__waywardDeliveryAddon.getSession().who!=='wife')throw Error('배달 세션 저장 복원 실패');
    `);

    const nativeMoves = await DeliveryTest_평가하기(`
      const api=WML.dev(),mod=__waywardDeliveryAddon;let state=api.store.game();const session=mod.getSession();
      state=mod.projectService(state, projected=>api.fn('startPatronInteraction')(projected,session.customerIds[0]));
      const scene={...api.fn('patronScene')(state),stage:'intimate',ticksAtStage:20,elenaComfort:90,patronBoldness:90,playerEngaged:false};
      state={...state,activeScene:{...state.activeScene,patron:scene},
        characters:{...state.characters,[session.characterId]:{...state.characters[session.characterId],stats:{...state.characters[session.characterId].stats,arousal:90}}}};
      const customer=state.customers.find(item=>item.id===scene.customerId),character=state.characters[session.characterId];
      mod.setSettings({hotelSexWeight:1});const one=api.fn('buildPatronMoveCandidates')(state,scene,customer,character);
      mod.setSettings({hotelSexWeight:2});const two=api.fn('buildPatronMoveCandidates')(state,scene,customer,character);
      mod.setSettings({hotelSexWeight:0});const zero=api.fn('buildPatronMoveCandidates')(state,scene,customer,character);
      const sexual=item=>item.move.kind==='lateral'||item.move.kind==='anal'||api.fn('isSexualStage')(item.move.target||item.move.wanted||'');
      api.store.update(()=>state);
      return {one:one.filter(sexual).map(item=>item.weight),two:two.filter(sexual).map(item=>item.weight),zero:zero.filter(sexual).length,
        controlled:api.store.game().activeScene.patron.playerEngaged};
    `);
    assert.ok(nativeMoves.one.length > 0);assert.deepEqual(nativeMoves.two,nativeMoves.one.map(weight=>weight*2));
    assert.equal(nativeMoves.zero,0);assert.equal(nativeMoves.controlled,false);

    const returned = await DeliveryTest_평가하기(`
      const api=WML.dev(), mod=__waywardDeliveryAddon;
      let state=api.store.game(); const end=mod.getSession().returnAtSlot;
      let guard=0,forbidden=false,interactionTicks=0,early=false;
      while (state.deliveryAddon.activeDelivery && guard++ < 240) {
        state={...state,pendingEvent:undefined,alertQueue:[]};
        state=api.fn('tick')(state);
        const scene=api.fn('patronScene')(state);
        forbidden ||= api.fn('isSexualStage')(scene?.stage||'');
        interactionTicks=Math.max(interactionTicks,scene?.ticksElapsed||0);
        early ||= !state.deliveryAddon.activeDelivery && state.slot<end;
      }
      api.store.update(()=>state);
      return {slot:state.slot,end,session:mod.getSession(),wifeRoom:api.fn('wifeLocation')(state),
        income:state.log.filter(entry=>entry.text.startsWith('[배달] ') && entry.text.includes(' 배달을 마쳤습니다.')).length,
        remoteCustomers:state.customers.filter(customer=>customer.deliveryCustomer).length,
        realRoom:state.locations.back_room.meta.testSentinel,
        badStage:api.fn('isSexualStage')(api.fn('patronScene')(state)?.stage||''),
        task:api.fn('wife')(state).currentTask,forbidden,interactionTicks,early,bonus:mod.getReceipt()?.bonus};
    `);
    assert.ok(returned.slot>=returned.end); assert.equal(returned.session, null); assert.equal(returned.wifeRoom, 'taproom');
    assert.equal(returned.income, 1); assert.equal(returned.remoteCustomers, 0); assert.equal(returned.realRoom, 'keep-real-back-room');
    assert.equal(returned.badStage, false); assert.equal(returned.task, 'idle');
    assert.equal(returned.forbidden,false);assert.ok(returned.interactionTicks > 0);assert.equal(returned.early,false);
    assert.ok(returned.bonus.interactionMinutes>0);assert.equal(returned.bonus.interactionTip,returned.bonus.interactionMinutes);
    console.log(`PASS ${combination}: minimum 30-minute native service, images, no real back-room/stock pollution, once-only return`);

    const extended = await DeliveryTest_평가하기(`
      const api=WML.dev(),mod=__waywardDeliveryAddon,random=Math.random,results=[];
      Math.random=()=>0.999999;
      try {
        for(const stage of ['chatting','flirting','light_touch','sex_patron']) {
          DeliveryTest_초기화하기();mod.setSettings({hotelSexWeight:stage==='sex_patron'?1:0});
          mod.forceOffer(20);mod.accept('wife');
          let state=api.store.game(),session=mod.getSession();const minimum=session.minimumReturnAtSlot;
          state={...state,slot:minimum-1,pendingEvent:undefined,alertQueue:[]};
          state=mod.projectService(state,projected=>api.fn('startPatronInteraction')(projected,session.customerIds[0]));
          const scene={...api.fn('patronScene')(state),stage,ticksElapsed:0,ticksAtStage:0,stalled:0,
            elenaComfort:60,patronBoldness:0,patronPleasure:0,playerEngaged:false,lateralAct:undefined};
          state={...state,activeScene:{...state.activeScene,patron:scene}};
          state=api.fn('tick')(state);api.store.update(()=>state);
          const atMinimum={active:!!mod.getSession(),scene:!!api.fn('patronScene')(state),room:api.fn('wifeLocation')(state),
            paid:state.log.some(entry=>entry.text.startsWith('[배달] ') && entry.text.includes(' 배달을 마쳤습니다.'))};
          state=JSON.parse(JSON.stringify(state));delete state.deliveryAddon.activeDelivery.minimumReturnAtSlot;
          state=api.fn('tick')(state);api.store.update(()=>state);
          const restored={active:!!mod.getSession(),scene:!!api.fn('patronScene')(state),room:api.fn('wifeLocation')(state),
            timer:state.characters[session.characterId].locationUntilSlot>state.slot,
            party:state.deliveryAddon.activeDelivery?.party.endSlot>state.slot};
          await new Promise(resolve=>setTimeout(resolve,100));
          const statusText=[...document.querySelectorAll('[data-delivery-site]')].some(item=>item.textContent.includes('손님 응대 마무리 후 귀환'));
          state=mod.projectService(state,projected=>api.fn('endPatronInteraction')(projected,
            stage==='sex_patron'?'elena_refused':'patron_satisfied_chat',{suppressEndText:true}));
          state={...state,pendingEvent:undefined,alertQueue:[]};
          state=api.fn('tick')(state);api.store.update(()=>state);
          results.push({stage,atMinimum,restored,statusText,returned:mod.getSession()===null,
            slot:state.slot,minimum,room:api.fn('wifeLocation')(state),guests:state.customers.filter(c=>c.deliveryCustomer).length,
            payments:state.log.filter(entry=>entry.text.startsWith('[배달] ') && entry.text.includes(' 배달을 마쳤습니다.')).length,
            bonus:mod.getReceipt()?.bonus});
        }
        return results;
      }finally {Math.random=random;}
    `);
    for(const result of extended) {
      assert.deepEqual(result.atMinimum,{active:true,scene:true,room:'delivery_site',paid:false},result.stage);
      assert.deepEqual(result.restored,{active:true,scene:true,room:'delivery_site',timer:true,party:true},result.stage);
      assert.equal(result.statusText,true,result.stage);assert.equal(result.returned,true,result.stage);
      assert.ok(result.slot>result.minimum);assert.equal(result.room,'taproom');assert.equal(result.guests,0);assert.equal(result.payments,1);
      assert.equal(result.bonus.interactionMinutes,2,result.stage);assert.equal(result.bonus.total,22,result.stage);
    }
    const minimumOnly = await DeliveryTest_평가하기(`
      DeliveryTest_초기화하기();const api=WML.dev(),mod=__waywardDeliveryAddon,random=Math.random;
      Math.random=()=>0.999999;
      try {
        mod.forceOffer(20);mod.accept('wife');let state=api.store.game();const minimum=mod.getSession().minimumReturnAtSlot;
        state={...state,slot:minimum-2};state=api.fn('tick')(state);const before=!!state.deliveryAddon.activeDelivery;
        state=api.fn('tick')(state);api.store.update(()=>state);
        return {before,atMinimum:state.slot===minimum,returned:mod.getSession()===null};
      }finally {Math.random=random;}
    `);
    assert.deepEqual(minimumOnly,{before:true,atMinimum:true,returned:true});
    console.log(`PASS ${combination}: chat/flirt/light touch/sex all extend after 30 minutes; return only after native scene end, including v4 save restore`);

    const closing = await DeliveryTest_평가하기(`
      DeliveryTest_초기화하기();const api=WML.dev(),mod=__waywardDeliveryAddon,random=Math.random;
      Math.random=()=>0.999999;
      try {
        mod.forceOffer(20);mod.accept('wife');let state=api.store.game();const session=mod.getSession();
        state={...state,slot:3*1440+119,phase:'last_call',pendingEvent:undefined,alertQueue:[]};
        state=api.fn('updateCharacter')(state,session.characterId,character=>({...character,stats:{...character.stats,energy:100}}));
        state=mod.projectService(state,projected=>api.fn('startPatronInteraction')(projected,session.customerIds[0]));
        state={...state,activeScene:{...state.activeScene,patron:{...api.fn('patronScene')(state),
          stage:'chatting',ticksElapsed:0,ticksAtStage:0,stalled:0,playerEngaged:false}}};
        state=api.fn('tick')(state);api.store.update(()=>state);
        const during={active:!!mod.getSession(),scene:!!api.fn('patronScene')(state),phase:state.phase,room:api.fn('wifeLocation')(state)};
        state=mod.projectService(state,projected=>api.fn('endPatronInteraction')(projected,'patron_satisfied_chat',{suppressEndText:true}));
        state={...state,pendingEvent:undefined,alertQueue:[]};state=api.fn('tick')(state);api.store.update(()=>state);
        const after={returned:mod.getSession()===null,room:api.fn('wifeLocation')(state),
          payments:state.log.filter(entry=>entry.text.startsWith('[배달] ') && entry.text.includes(' 배달을 마쳤습니다.')).length};
        state=api.fn('tick')({...state,pendingEvent:undefined,alertQueue:[]});api.store.update(()=>state);
        return {during,after,closingResumed:state.phase!=='closed'};
      }finally{Math.random=random;}
    `);
    assert.deepEqual(closing.during,{active:true,scene:true,phase:'closed',room:'delivery_site'});
    assert.deepEqual(closing.after,{returned:true,room:'bedroom',payments:1});assert.equal(closing.closingResumed,true);
    console.log(`PASS ${combination}: closing waits for hotel interaction; wife returns and normal day settlement resumes`);

    const self = await DeliveryTest_평가하기(`
      DeliveryTest_초기화하기();const api=WML.dev(),mod=__waywardDeliveryAddon;
      if(!mod.forceOffer(20)||!mod.accept('player'))throw Error('직접 배달 실패');
      let state=api.store.game();const end=mod.getSession().returnAtSlot;
      const room=api.fn('playerLocation')(state);const before=state.economy.gold;
      while(state.slot<end){state={...state,pendingEvent:undefined,alertQueue:[]};state=api.fn('tick')(state)}
      api.store.update(()=>state);
      return {room,returnRoom:api.fn('playerLocation')(state),session:mod.getSession(),paid:state.economy.gold-before,
        total:deliveryTestOrder.totalPrice,offer:state.deliveryAddon.pendingOffer||null,canOrderAgain:mod.forceOffer(20)};
    `);
    assert.equal(self.room, 'delivery_site'); assert.equal(self.returnRoom, 'taproom'); assert.equal(self.session, null); assert.ok(self.paid >= 20);
    assert.equal(self.canOrderAgain, true);
    await DeliveryTest_평가하기('__waywardDeliveryAddon.ignore()');
    console.log(`PASS ${combination}: direct delivery, settlement and same-day repeat without cooldown`);

    const cancelled = await DeliveryTest_평가하기(`
      DeliveryTest_초기화하기();const api=WML.dev(),mod=__waywardDeliveryAddon;
      mod.forceOffer(20);mod.accept('player');const before=api.store.game();
      api.store.dispatch({type:'errand_return_now'});const state=api.store.game();
      return {session:mod.getSession(),errand:!!state.errandSession,room:api.fn('playerLocation')(state),
        paid:state.economy.gold-before.economy.gold,completed:state.log.some(entry=>entry.text.startsWith('[배달] ') && entry.text.includes(' 배달을 마쳤습니다.')),
        cancelled:state.log.some(entry=>entry.text.includes('[배달] 배달을 마치기 전에 돌아왔습니다.'))};
    `);
    assert.deepEqual(cancelled,{session:null,errand:false,room:'taproom',paid:0,completed:false,cancelled:true});
    console.log(`PASS ${combination}: native early-return action clears delivery without paying the order`);

    const migrated = await DeliveryTest_평가하기(`
      DeliveryTest_초기화하기();const api=WML.dev(),mod=__waywardDeliveryAddon;
      mod.forceOffer(20);mod.accept('player');
      let state=api.store.game();const end=mod.getSession().returnAtSlot,total=mod.getSession().offer.totalPrice;
      state=JSON.parse(JSON.stringify({...state,deliveryAddon:{...state.deliveryAddon,version:3,activeDelivery:undefined,
        lastRollDay:state.day,lastDeliveryDay:state.day,nextEligibleDay:state.day+4}}));
      const before=state.economy.gold;state=api.fn('tick')(state);const converted=state.deliveryAddon.activeDelivery?.who;
      while(state.slot<end){state={...state,pendingEvent:undefined,alertQueue:[]};state=api.fn('tick')(state);}
      // 후속 홀 사건을 제거해, 주문을 막는 날짜 쿨타임이 없다는 조건만 검사합니다.
      api.store.update(()=>({...state,pendingEvent:undefined,alertQueue:[],activeScene:{}}));
      return {converted,settled:state.deliveryAddon.activeDelivery==null,paid:state.economy.gold-before,total,
        settlements:state.log.filter(entry=>entry.text.startsWith('[배달] ') && entry.text.includes(' 배달을 마쳤습니다.')).length,reordered:mod.forceOffer(20)};
    `);
    assert.equal(migrated.converted,'player');assert.equal(migrated.settled,true);assert.ok(migrated.paid>=migrated.total);
    assert.equal(migrated.settlements,1);assert.equal(migrated.reordered,true);
    await DeliveryTest_평가하기('__waywardDeliveryAddon.ignore()');
    console.log(`PASS ${combination}: v3 delivery-save migration without duplicate payment or old cooldown`);

    const oldHotelSaves = await DeliveryTest_평가하기(`
      const api=WML.dev(),mod=__waywardDeliveryAddon,results=[];
      for(const who of ['wife','player']) {
        DeliveryTest_초기화하기();mod.forceOffer(60);mod.accept(who);
        let state=structuredClone(api.store.game()),session=state.deliveryAddon.activeDelivery;
        const ids=[session.characterId,...session.customerIds],destination=session.offer.destination;
        const offer={...session.offer,destination:'러브호텔',originalDestination:destination};
        delete session.location;session.offer=offer;state.deliveryAddon.version=4;
        delete state.locations.delivery_site;
        state.locations.love_hotel={occupants:['unrelated-hotel-guest',...ids],meta:{sentinel:'H_Status room'}};
        if(state.errandSession)state.errandSession.deliveryOffer=offer;
        const legacyState=state,before=JSON.stringify(state),gold=state.economy.gold,stock=state.readyFood;
        state=mod.prepare(state);
        results.push({who,room:api.fn(who==='wife'?'wifeLocation':'playerLocation')(state),
          allMoved:ids.every(id=>state.locations.delivery_site.occupants.includes(id)),
          hotelOccupants:state.locations.love_hotel.occupants,
          hotelMeta:state.locations.love_hotel.meta.sentinel,
          destination:state.deliveryAddon.activeDelivery.offer.destination,
          timerKept:state.deliveryAddon.activeDelivery.returnAtSlot===session.returnAtSlot,
          unpaid:state.economy.gold===gold,stockKept:state.readyFood===stock,
          originalUnchanged:before===JSON.stringify(legacyState),
          errandDestination:state.errandSession?.deliveryOffer.destination||null});
        api.store.update(()=>state);
        await new Promise(resolve=>setTimeout(resolve,100));
        if(!document.querySelector('[data-delivery-site]').textContent.includes(destination))throw Error('Old-save destination card missing');
      }
      DeliveryTest_초기화하기();mod.forceOffer(80);
      api.store.update(state=>({...state,deliveryAddon:{...state.deliveryAddon,version:4,
        pendingOffer:{...state.deliveryAddon.pendingOffer,destination:'러브호텔'}}}));
      const pending=mod.getOffer().destination;
      const gold=api.store.game().economy.gold;mod.ignore();
      const refused={renown:api.store.game().tavernReputation.renown,notoriety:api.store.game().tavernReputation.notoriety,
        unpaid:api.store.game().economy.gold===gold};
      DeliveryTest_초기화하기();return {results,pending,refused};
    `);
    for(const save of oldHotelSaves.results) {
      assert.equal(save.room,'delivery_site');assert.equal(save.allMoved,true);
      assert.deepEqual(save.hotelOccupants,['unrelated-hotel-guest']);assert.equal(save.hotelMeta,'H_Status room');
      assert.equal(save.destination,destinations[3]);assert.equal(save.timerKept,true);
      assert.equal(save.unpaid,true);assert.equal(save.stockKept,true);assert.equal(save.originalUnchanged,true);
      assert.equal(save.errandDestination,save.who==='player'?destinations[3]:null);
    }
    assert.equal(oldHotelSaves.pending,destinations[4]);assert.equal(oldHotelSaves.refused.unpaid,true);
    console.log(`PASS ${combination}: v4 wife/player location and pending-order migration preserves H_Status occupants, timers, stock and payment`);

    const preciseRewards = await DeliveryTest_평가하기(`
      const api=WML.dev(),mod=__waywardDeliveryAddon,random=Math.random,results=[];
      Math.random=()=>0.999999;
      try {
        for(const who of ['wife','player']) {
          DeliveryTest_초기화하기();mod.forceOffer(100);const offer=mod.getOffer();mod.accept(who);
          const before=api.store.game();let state={...before,slot:mod.getSession().returnAtSlot-1};
          state=api.fn('tick')(state);api.store.update(()=>state);
          const gold=state.economy.gold,renown=state.tavernReputation.renown;
          state=api.fn('tick')({...state,pendingEvent:undefined,alertQueue:[]});
          results.push({who,paid:gold-before.economy.gold,expected:offer.totalPrice+(who==='wife'?offer.fee:0),
            receipt:mod.getReceipt(),
            renown:renown-before.tavernReputation.renown,expectedRenown:offer.renown,
            settled:state.deliveryAddon.activeDelivery==null,
            once:state.economy.gold===gold&&state.tavernReputation.renown===renown,
            logCorrect:state.log.some(entry=>entry.text.includes(offer.destination+' 배달을 마쳤습니다.')
              &&entry.text.includes('총 '+offer.totalPrice+'골드')&&entry.text.includes('명성 +'+offer.renown))});
        }
        DeliveryTest_초기화하기();return results;
      }finally{Math.random=random;}
    `);
    assert.ok(preciseRewards.every(result=>result.paid===result.expected&&result.renown===result.expectedRenown&&result.settled&&result.once&&result.logCorrect),JSON.stringify(preciseRewards));
    for(const result of preciseRewards){
      assert.equal(result.receipt.totalPayment,result.expected);
      assert.equal(result.receipt.bonus.total,result.who==='wife'?100:0);
      assert.equal(result.receipt.bonus.interactionMinutes,0);
    }
    console.log(`PASS ${combination}: both routes pay the displayed amount and renown exactly once`);

    const interactionBonus = await DeliveryTest_평가하기(`
      const api=WML.dev(),mod=__waywardDeliveryAddon,random=Math.random,results=[];
      Math.random=()=>0.999999;
      try {
        for(const minutes of [1,5,35]) {
          DeliveryTest_초기화하기();mod.forceOffer(20);const offer=mod.getOffer();mod.accept('wife');
          let state=api.store.game(),session=mod.getSession();
          for(let i=0;i<3;i++)state=api.fn('tick')(state);
          const idleMinutes=state.deliveryAddon.activeDelivery.wifeBonus.interactionMinutes;
          state=mod.projectService(state,projected=>api.fn('startPatronInteraction')(projected,session.customerIds[0]));
          // 후처리의 기본 게임 분 진행을 사용해 무작위 종료 없이 정해진 시간만큼 실제 응대합니다.
          state={...state,activeScene:{...state.activeScene,patron:{...api.fn('patronScene')(state),
            playerEngaged:false,ticksElapsed:0,ticksAtStage:0,afterglow:{untilSlot:state.slot+90}}}};
          api.store.update(()=>state);
          // 실제 게임의 대기 액션도 같은 분 진행 경로로 보너스를 적립해야 합니다.
          api.store.dispatch({type:'wait',minutes:1});state=api.store.game();
          for(let i=1;i<minutes;i++)state=api.fn('tick')(state);
          const earned=state.deliveryAddon.activeDelivery.wifeBonus.interactionMinutes;
          const duplicate=api.fn('processPatronInteractionTick')(state);
          const sameSlot=duplicate.deliveryAddon.activeDelivery.wifeBonus.interactionMinutes===earned;
          state=JSON.parse(JSON.stringify(duplicate));state=mod.prepare(state);
          const restored=state.deliveryAddon.activeDelivery.wifeBonus.interactionMinutes;
          const duplicateAfterLoad=api.fn('processPatronInteractionTick')(state).deliveryAddon.activeDelivery.wifeBonus.interactionMinutes===earned;
          const paused=api.fn('tick')({...state,pendingEvent:{type:'alert',alert:{kind:'bonus-wait'}}});
          const choiceWait=paused.slot===state.slot&&paused.deliveryAddon.activeDelivery.wifeBonus.interactionMinutes===earned;
          const engaged=api.fn('processPatronInteractionTick')({...state,slot:state.slot+1,
            activeScene:{...state.activeScene,patron:{...api.fn('patronScene')(state),playerEngaged:true}}});
          const noPlayerSceneBonus=engaged.deliveryAddon.activeDelivery.wifeBonus.interactionMinutes===earned;
          const foreign=api.fn('processPatronInteractionTick')({...state,slot:state.slot+1,
            activeScene:{...state.activeScene,patron:{...api.fn('patronScene')(state),customerId:'unrelated-customer'}}});
          const noForeignBonus=foreign.deliveryAddon.activeDelivery.wifeBonus.interactionMinutes===earned;
          const old=structuredClone(state);delete old.deliveryAddon.activeDelivery.wifeBonus;
          const oldPrepared=mod.prepare(old),oldRestored=oldPrepared.deliveryAddon.activeDelivery.wifeBonus.interactionMinutes;
          const oldNewMinute=api.fn('tick')(oldPrepared).deliveryAddon.activeDelivery.wifeBonus.interactionMinutes;
          api.store.update(()=>state);await new Promise(resolve=>setTimeout(resolve,80));
          const progressShown=document.querySelector('[data-delivery-bonus-progress]')?.textContent.includes('+'+(20+minutes)+'골드 · 상호작용 '+minutes+'분');
          state=mod.projectService(state,projected=>api.fn('endPatronInteraction')(projected,'patron_satisfied_chat',{suppressEndText:true}));
          state={...state,slot:Math.max(state.slot,session.minimumReturnAtSlot-1),pendingEvent:undefined,alertQueue:[]};
          const before=state.incomeBreakdownToday?.errands||0;
          state=api.fn('tick')(state);api.store.update(()=>state);
          const receipt=mod.getReceipt(),paid=(state.incomeBreakdownToday?.errands||0)-before;
          const log=state.log.find(entry=>entry.text.includes(offer.destination+' 배달을 마쳤습니다.'))?.text;
          const after=api.fn('tick')({...state,pendingEvent:undefined,alertQueue:[]});
          const once=after.deliveryAddon.lastReceipt.id===receipt.id
            &&(after.incomeBreakdownToday?.errands||0)===(state.incomeBreakdownToday?.errands||0);
          results.push({minutes,idleMinutes,earned,sameSlot,restored,duplicateAfterLoad,choiceWait,
            noPlayerSceneBonus,noForeignBonus,oldRestored,oldNewMinute,progressShown,receipt,paid,once,
            logCorrect:log.includes('추가 팁 20골드 + 상호작용 '+minutes+'분 '+minutes+'골드')
              &&log.includes('최종 '+(offer.totalPrice+20+minutes)+'골드'),basePrice:offer.totalPrice});
        }
        DeliveryTest_초기화하기();return results;
      }finally{Math.random=random;}
    `);
    for(const result of interactionBonus){
      assert.equal(result.idleMinutes,0,JSON.stringify(result));assert.equal(result.earned,result.minutes,JSON.stringify(result));
      assert.equal(result.restored,result.minutes);assert.equal(result.oldRestored,0);assert.equal(result.oldNewMinute,1);
      for(const key of ['sameSlot','duplicateAfterLoad','choiceWait','noPlayerSceneBonus','noForeignBonus','progressShown','once','logCorrect'])assert.equal(result[key],true,key+': '+JSON.stringify(result));
      assert.deepEqual(result.receipt.bonus,{baseTip:20,interactionMinutes:result.minutes,interactionTip:result.minutes,total:20+result.minutes});
      assert.equal(result.receipt.totalPayment,result.basePrice+20+result.minutes);
      assert.equal(result.paid,40+result.minutes);
    }
    console.log(`PASS ${combination}: proportional wife tips for 1/5/35 interaction minutes, native action/aftercare, idle/choice exclusions, save restore and once-only settlement`);

    // Legacy pause-menu DOM grouping was intentionally removed before the stable port.
    const settings=await DeliveryTest_평가하기(`const mod=__waywardDeliveryAddon;document.querySelector('button[title^="메뉴"]').click();await new Promise(r=>setTimeout(r,100));mod.openSettings();const input=document.querySelector('[data-delivery-setting="eventWeight"]');input.value='7.4';document.querySelector('[data-delivery-settings-save]').click();return {saved:mod.getSettings().eventWeight,visible:input.getBoundingClientRect().width>0};`);
    assert.equal(settings.saved,7.4);assert.equal(settings.visible,true);
    const restore = await DeliveryTest_평가하기(`
      const mod=__waywardDeliveryAddon,input=document.querySelector('[data-delivery-setting="eventWeight"]');
      input.value='11';document.querySelector('[data-delivery-settings-save]').click();const rejected=mod.getSettings().eventWeight===7.4;
      document.querySelector('[data-delivery-settings-restore]').click();
      const values=[...document.querySelectorAll('[data-delivery-setting]')].map(item=>Number(item.value));
      const pending=mod.getSettings().eventWeight===7.4;
      document.querySelector('[data-delivery-settings-save]').click();const defaults=mod.getSettings();
      input.value='7.4';document.querySelector('[data-delivery-settings-save]').click();
      if(WML.status().loaded.includes('wife-view-mode')) {
        document.querySelector('[data-wml-pause-entry="wife-view-mode"]').click();await new Promise(resolve=>setTimeout(resolve,120));
        const wife=document.querySelector('[data-wayward-native-window^="wife-view-mode:"]');
        const box=wife.querySelector('.wayward-native-window-title').getBoundingClientRect();
        if(!wife.contains(document.elementFromPoint(box.x+box.width/2,box.y+box.height/2)))throw Error('Wife settings not foremost');
        mod.openSettings();
        const box2=input.getBoundingClientRect();if(!input.closest('.wayward-native-window').contains(document.elementFromPoint(box2.x+box2.width/2,box2.y+box2.height/2)))throw Error('Existing settings did not regain focus');
        if(!WML.back()||input.isConnected)throw Error('Back did not close the focused settings window');
        wife.querySelector('.wayward-native-window-title button').click();
      } else input.closest('.wayward-native-window').querySelector('.wayward-native-window-title button').click();
      return {rejected,values,pending,defaults};
    `);
    assert.equal(restore.rejected,true);assert.equal(restore.pending,true);assert.deepEqual(restore.values,[1,2]);
    assert.deepEqual(restore.defaults,{eventWeight:1,hotelSexWeight:2});
    if(screenshot) {
      await DeliveryTest_평가하기('__waywardDeliveryAddon.openSettings();await new Promise(resolve=>setTimeout(resolve,120))');
      fs.writeFileSync(new URL('./delivery-settings.jpg',import.meta.url),Buffer.from(await playScreenshot({}),'base64'));
    }
    await playReload({});assert.equal((await DeliveryTest_평가하기('__waywardDeliveryAddon.getSettings()')).eventWeight,7.4);
    const status=await playStatus({});
    assert.deepEqual(status.failed,[]);
    assert.deepEqual(status.pageErrors,[]);
    console.log(`PASS ${combination}: settings UI, persistence and no runtime errors`);
  } finally { await playStop(); }
}
