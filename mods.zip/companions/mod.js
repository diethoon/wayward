// 동료 모드 · Companions 2.7.2-pre7.1 — servant의 차기 독립 버전.
// 고용인 · Companions 1.2.1
// 구 메이드관(maid/mod.js)과 arhka의 Addon_arhka_Maid.js 코드를 참고했습니다.
// NPC Simulator 연동 기반: urkta의 작품(npc-simulator, town-expansion, our-town)을 참고합니다.
// 초상화 선택 흐름: urkta의 패배 히로인들의 삶(town-residents)·NPC Simulator를 참고했습니다.
WML.define({
  tags: ["content"],
  id: 'companions',
  author: "Hina_Lover", name: {ko:'동료 모드',en:'Companions'}, version: "2.9.4", game: "2026-11-01", lang: 'ko',
  description: '남녀 동료의 관계·고용·자율 생활·연애와 원본 대사·행동을 연결합니다.',
  backup: {indexedDB:['wml.mod.companions.portraits']},
  loadAfter: ['waitress', 'imagestudio','construction-tool','brothel-house'],
  conflicts: ['servant', 'maid', 'arhka-maid'], role: 'hall-staff',
  symbols: {
    "companionsBedRoom": {"raw":{"2026-11-01":"ho"}},
    "companionsStoreSelector": {"raw":{"2026-11-01":"Rre"},"doc":"저장소를 바꾸지 않고 해당 UI 렌더의 선택자에만 인물 문맥 전달"},
    "companionsRoomChips": {"raw":{"2026-11-01":"YB"}},
    "companionsVisualState": {"raw":{"2026-11-01":"Wg"}},
    "companionsVisualCharacter": {"raw":{"2026-11-01":"FK"}},
    "companionsVisualMood": {"raw":{"2026-11-01":"Gz"}},
    "companionsVisualContext": {"raw":{"2026-11-01":"GK"}},
    "companionsPatronDescription": {"raw":{"2026-11-01":"Uoe"},"doc":"본편 접객 단계의 현재 상황 설명"},
    "companionsReservedPatrons": {"raw":{"2026-11-01":"rd"},"doc":"접객 중 손님의 중복 이동·욕실 안내·다른 장면 참여 방지"},
    "companionsPatronRecord": {"raw":{"2026-11-01":"Sde"},"doc":"원본 손님 관계 기록의 중립 초기값"},
    "companionsEventHotkeys": {"raw":{"2026-11-01":"hnt"}},
    "companionsEventDigit": {"raw":{"2026-11-01":"Hp"}},
    "companionsMainTaskTick": {"raw":{"2026-11-01":"nQe"}},
    "companionsMainMoodTick": {"raw":{"2026-11-01":"sQe"}},
    "companionsMainPatronTick": {"raw":{"2026-11-01":"aQe"}},
    "companionsMainAgencyTick": {"raw":{"2026-11-01":"hW"}},
    "companionsMainEventTick": {"raw":{"2026-11-01":"iQe"}},
    "companionsNativeMenu": {"raw":{"2026-11-01":"Su"}},
    "companionsNativeChoice": {"raw":{"2026-11-01":"qKe"}},
    "companionsSceneChoice": {"raw":{"2026-11-01":"SOe"}},
    "companionsSceneMenu": {"raw":{"2026-11-01":"Kl"}},
    "companionsSceneAdvance": {"raw":{"2026-11-01":"AOe"}},
    "companionsAssignRelation": {"raw":{"2026-11-01":"fk"}},
    "companionsRelationType": {"raw":{"2026-11-01":"id"}},
    "companionsFeelings": {"raw":{"2026-11-01":"Lie"}},
    "companionsAlcohol": {"raw":{"2026-11-01":"dpe"}},
    "companionsExposure": {"raw":{"2026-11-01":"yxe"}},
    "companionsThoughts": {"raw":{"2026-11-01":"o9"}},
    "companionsCharacter": {"raw":{"2026-11-01":"RZe"},"doc":"아내와 같은 능력치 틀로 독립 인물을 생성"},
    "companionsPeoplePanel": {"raw":{"2026-11-01":"qoe"},"doc":"가게 인물 목록"},
    "companionsLocationPanel": {"raw":{"2026-11-01":"hat"},"doc":"모두의 현재 위치 패널"},
    "companionsSharedBedroom": {"raw":{"2026-11-01":"hd"},"doc":"본편 그녀의 방 카드 숨김 조건"},
    "companionsLocationLabels": {"raw":{"2026-11-01":"YZ"},"doc":"현재 게임 장소 이름"},
    "companionsPortraitPanel": {"raw":{"2026-11-01":"rv"},"doc":"아내 초상화와 이미지 표시"},
    "companionsHallActions": {"raw":{"2026-11-01":"Int"},"doc":"홀의 기본 행동과 아내 대화 자리"},
    "companionsBedroomActions": {"raw":{"2026-11-01":"$nt"}},
    "companionsBathhouseActions": {"raw":{"2026-11-01":"Nnt"}},
    "companionsBathroomActions": {"raw":{"2026-11-01":"Ant"}},
    "companionsBackRoomActions": {"raw":{"2026-11-01":"jnt"}},
    "companionsKitchenActions": {"raw":{"2026-11-01":"Lnt"}},
    "companionsGuestRoomActions": {"raw":{"2026-11-01":"Ynt"}},
    "companionsPrivateRoomActions": {"raw":{"2026-11-01":"Wnt"}},
    "companionsImageLookup": {"raw":{"2026-11-01":"vy"},"doc":"그림 키로 기존 이미지 검색"},
    "companionsImageUrl": {"raw":{"2026-11-01":"o_"},"doc":"이미지 자료의 표시 주소"}
  },
  async setup(api) {
    await api.loadScript('files/people.js');
    const people = globalThis.Companions_인물모델(api);
    await api.loadScript('files/housing.js');
    globalThis.Companions_거주연결(api,people);
    await api.loadScript('files/work.js');
    globalThis.Companions_업무연결(api, people);
    await api.loadScript('files/panels.js');
    await api.loadScript('files/portrait.js');
    await api.loadScript('files/native.js');
    globalThis.Companions_원본연결(api, people);
    await api.loadScript('files/life.js');
    globalThis.Companions_자율생활(api, people);
    await api.loadScript('files/ui.js');
    const open = globalThis.Companions_화면연결(api, people);
    await api.loadScript('files/live.js');
    globalThis.Companions_실시간연결(api,people,open);
    api.provide({...people, open, windowMarkerVersion:1});
  }
});
