// MCP dependencies are local to this mod's tests; game/MCP sources stay unchanged.
import {pathToFileURL} from 'node:url';
import {createRequire,registerHooks} from 'node:module';
const require=createRequire(new URL('./.runtime/package.json',import.meta.url));
registerHooks({resolve(specifier,context,next){
  try{return next(specifier,context);}catch(error){
    if(error.code!=='ERR_MODULE_NOT_FOUND'||specifier.startsWith('.')||specifier.includes(':'))throw error;
    return next(pathToFileURL(require.resolve(specifier)).href,context);
  }
}});
