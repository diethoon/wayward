// 건물별 방·거주 배정은 동료 자료에만 저장합니다. 바닐라 방·아내 명부는 복제하지 않습니다.
globalThis.Companions_거주연결=function(api,people){
  'use strict';
  const ct=()=>globalThis.WML.use('construction-tool'),estate=()=>globalThis.WML.use('real-estate');
  const origin=()=>globalThis.__waywardWOW?.roleOf('home')||'home';
  const floors=['ground','upper','basement'];
  const baseRooms=new Set(Object.keys(people.roomNames));
  const roomCache=new WeakMap();
  function built(s){if(!roomCache.has(s))roomCache.set(s,(ct()?.getRooms?.(s)||[]).filter(r=>r.built!==false&&!r.stored));return roomCache.get(s);}
  const propertySite=id=>'estate:'+id;
  function sites(s){
    const list=[{id:origin(),name:'본점',entrance:'taproom'}],e=estate();
    for(const lot of e?.lots||[])if(e.read(s).lots[lot.id]?.building&&e.project(s,lot.id).complete)
      list.push({id:propertySite(lot.id),name:lot.label+' · '+(e.getBuildingTypes?.().find(b=>b.id===e.read(s).lots[lot.id].building)?.label||'건물'),
        entrance:e.entryArea(lot.id),lot:lot.id});
    return list;
  }
  function siteForRoom(s,id){
    const row=built(s).find(r=>r.id===id),e=estate();
    for(const lot of e?.lots||[])if(id===e.entryArea(lot.id)||floors.some(f=>row?.floor==='estate_'+lot.id+'_'+f))return propertySite(lot.id);
    if(baseRooms.has(id)||row&&!String(row.floor).startsWith('estate_'))return origin();
    return null;
  }
  function context(s){
    const wow=globalThis.__waywardWOW,all=sites(s),current=s.mods?.wow?.home||origin();
    const travel=!!s.mods?.wow?.trip||!!(wow&&wow.where(s).region!==wow.roleOf('home','region'));
    const player=siteForRoom(s,api.fn('playerLocation')(s)),wife=siteForRoom(s,api.fn('wifeLocation')(s));
    const active=player||current;
    const awayBySite=Object.fromEntries(all.map(site=>[site.id,travel||player!==site.id&&wife!==site.id]));
    return {origin:origin(),active,sites:all,awayBySite,ownerAway:awayBySite[active]??true};
  }
  function rooms(s,site=context(s).active){
    const all=built(s),names=api.fn('companionsLocationLabels'),list=[];
    for(const room of all)if(siteForRoom(s,room.id)===site)list.push({id:room.id,name:room.label,...room});
    if(site===origin())for(const id of baseRooms)if(s.locations?.[id]&&!all.some(r=>r.id===id)&&
      !(id==='bathhouse'&&!s.tavern?.hasBathhouse||id==='upstairs_hall'&&!s.tavern?.hasRoom||id==='upstairs_room_2'&&!s.tavern?.hasRoom2))
      list.push({id,name:names[id]||people.roomNames[id],label:names[id]||people.roomNames[id],native:true});
    const numbers={};
    for(const room of list)if(room.staffRole){
      const number=numbers[room.staffRole]=(numbers[room.staffRole]||0)+1;
      const floor=String(room.floor||'').split('_').at(-1),label={ground:'1층',upper:'2층',basement:'지하'}[floor]||ct()?.getPlots().find(p=>p.id===room.floor)?.label||room.floor;
      room.name=room.label+' '+number+(label?' · '+label:'');
    }
    return list;
  }
  function emptyNative(s){
    if(!s.locations?.elena_room)return false;
    if((s.locations.elena_room.occupants||[]).some(id=>id==='player'||id==='wife'||s.characters?.[id]||s.customers?.some(c=>c.id===id)))return false;
    return !Object.keys(s.characters||{}).some(id=>api.fn('companionsBedRoom')({...s,primaryCharacterId:id})==='elena_room');
  }
  function nativeAllowed(s){
    const recorded=people.read(s).nativeServantRoomAvailable;
    if(recorded===false)return false;
    if(recorded==null)return emptyNative(s);
    return !Object.keys(s.characters||{}).some(id=>api.fn('companionsBedRoom')({...s,primaryCharacterId:id})==='elena_room');
  }
  function bedrooms(s,site=context(s).active){
    const list=rooms(s,site).filter(r=>r.staffRole==='servant');
    if(site===origin()&&nativeAllowed(s)){
      const native=rooms(s,site).find(r=>r.id==='elena_room');if(native)list.unshift({...native,staffRole:'servant',borrowed:true});
    }
    return list;
  }
  const occupant=(s,site,id,except)=>people.list(s).find(p=>p.id!==except&&p.site===site&&p.housingRoom===id);
  function info(s,site=context(s).active){
    const beds=bedrooms(s,site),peopleHere=people.list(s).filter(p=>p.site===site),offices=rooms(s,site).filter(r=>r.staffRole==='manager');
    return {site,rooms:beds.map(r=>({...r,person:occupant(s,site,r.id)})),offices,capacity:beds.length,
      employed:peopleHere.filter(p=>p.employed).length,free:beds.filter(r=>!occupant(s,site,r.id)).length};
  }
  function valid(s,p){return !!p?.housingRoom&&bedrooms(s,p.site).some(r=>r.id===p.housingRoom)&&!occupant(s,p.site,p.housingRoom,p.id);}
  function reserve(s,p,preferred){
    if(!sites(s).some(site=>site.id===p.site))return {reason:'먼저 해당 건물을 완공해 주세요.'};
    const list=bedrooms(s,p.site),room=list.find(r=>r.id===preferred&&!occupant(s,p.site,r.id,p.id))||
      (!preferred?list.find(r=>!occupant(s,p.site,r.id,p.id)):null);
    return room?{room:room.id}:{reason:preferred?'해당 방을 사용할 수 없거나 다른 동료가 배정되어 있습니다.':'이 건물에 빈 고용인의 방이 없습니다. 한 방에 한 명씩 고용할 수 있습니다.'};
  }
  function contractReason(s,p){
    const capacity=bedrooms(s,p.site).length,count=people.list(s).filter(row=>row.employed&&row.site===p.site&&row.id!==p.id).length;
    return count>=capacity?'이 건물의 고용 정원이 찼습니다. 고용인의 방 한 개당 한 명을 고용할 수 있습니다.':null;
  }
  function managerRoom(s,site){
    const offices=info(s,site).offices,id=people.read(s).managerRooms?.[site];
    return offices.find(r=>r.id===id)||offices[0]||null;
  }
  function prepare(s){
    if(!s||s.pmCore)return s;
    let data=people.read(s),next=s;
    if(data.nativeServantRoomAvailable==null){next=people.write(s,{...data,nativeServantRoomAvailable:emptyNative(s),housingVersion:1});data=people.read(next);}
    for(const p of people.list(next))if(p.employed&&!p.housingManual&&!valid(next,p)){
      const available=reserve(next,p);if(available.room)next=people.save(next,{...p,housingRoom:available.room,homeRoom:available.room});
    }
    return next;
  }
  function assign(s,a){
    const denied=people.blocked(s);if(denied)return people.log(s,denied);
    s=prepare(s);const site=a.site||context(s).active;
    if(!bedrooms(s,site).some(r=>r.id===a.roomId))return people.log(s,'사용할 수 있는 고용인의 방을 선택해 주세요.');
    const old=occupant(s,site,a.roomId),person=a.personId&&people.get(s,a.personId);
    if(a.personId&&!person)return people.log(s,'배정할 동료를 선택해 주세요.');
    if(person?.employed&&person.site!==site){const denied=contractReason(s,{...person,site});if(denied)return people.log(s,denied,person.id);}
    for(const p of [old,person])if(p&&(p.readyAt>s.slot||p.nativeSession||p.interaction||p.life?.pending))return people.log(s,'진행 중인 업무·이동·대화를 마친 뒤 방을 바꿔 주세요.',p.id);
    let next=s;
    if(old&&old.id!==person?.id)next=people.save(next,{...old,housingRoom:null,housingManual:true,homeRoom:sites(s).find(r=>r.id===site)?.entrance||'taproom'});
    if(person){
      const data=people.read(next),managers={...data.managers},managerRooms={...data.managerRooms};
      if(person.site!==site&&managers[person.site]===person.id){delete managers[person.site];delete managerRooms[person.site];}
      next=people.write(next,{...data,managers,managerRooms});
      next=people.save(next,{...person,site,housingRoom:a.roomId,housingManual:true,homeRoom:a.roomId,
        ...(person.site!==site?{room:a.roomId,task:'idle',targetId:null,life:{...person.life,pending:null}}:{})});
    }
    return people.log(next,person?person.name+'의 거주실을 배정했습니다.':'방 배정을 해제했습니다. 거주실 없는 고용인은 근무를 보류합니다.',person?.id);
  }
  // 거주 배정·관리 위임은 실제 인물이 다른 방에서 일하더라도 철거 전에 해제해야 합니다.
  ct()?.registerOccupancyProvider?.({id:'companions:housing',isOccupied:(s,id)=>people.list(s).some(p=>p.housingRoom===id||p.room===id)||
    Object.entries(people.read(s).managers).some(([site,idPerson])=>people.get(s,idPerson)?.employed&&managerRoom(s,site)?.id===id)});
  let normalizing=false;
  api.store.subscribe(()=>{const root=api.store.get();if(normalizing||!root.started||root.selectingArchetype||root.selectingBuilder||root.selectingPicks)return;
    const s=root.state,next=prepare(s);if(next!==s){normalizing=true;try{api.store.update(current=>current===s?next:current);}finally{normalizing=false;}}});
  api.actions.register('companions/room-assign',assign);
  const housing={context,rooms,sites,siteForRoom,bedrooms,info,valid,reserve,contractReason,managerRoom,prepare};
  people.installHousing(housing);
  Object.assign(people,{housing,siteForRoom,buildingRooms:rooms});
};
