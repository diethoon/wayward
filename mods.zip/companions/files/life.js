// 관계·직업·연애는 별도입니다. NPC Simulator의 저장·실행기·판정을 호출하지 않습니다.
globalThis.Companions_자율생활=function(api,people){
  'use strict';
  const clamp=people.clamp,romantic=new Set(['flirt','hand','hug','kiss','confess','private']);
  const tasks={...people.tasks,walking:'이동',social:'대화',leisure:'여가',private:'사적인 시간'};
  function remember(s,id,type,text,partner){const p=people.actor(s,id);if(!p)return s;
    return people.saveActor(s,{...people.remember({...p,memories:p.memories||[]},s,type,text,partner),
      ...(p.main?{character:p.character}:{})});}
  function adjust(s,id,other,delta){const old=people.bond(s,id,other),row={...old,known:true,lastSlot:s.slot,interactions:old.interactions+1};
    for(const [key,value]of Object.entries(delta))row[key]=key==='status'?value:clamp((old[key]||0)+value);
    return people.setBond(s,id,other,row);}
  function free(s,p){
    if(!p||p.active===false||p.socialEnabled===false||p.room==='town:transit'||p.readyAt>s.slot||p.life?.pending||p.interaction||p.nativeSession||p.task==='sleeping')return false;
    if(p.main)return !s.pendingEvent&&!Object.values(s.activeScene||{}).some(Boolean)&&
      !['sleeping','bathing','cooking','cleaning'].includes(p.character.currentTask)&&
      (p.character.busyUntilSlot||0)<=s.slot;
    return true;
  }
  function score(s,a,b,kind){
    const ba=people.bond(s,b.id,a.id),attrs=api.fn('getEffectiveAttributes')(b.character);
    return 32+(b.mood-50)*.35+ba.trust*.35+ba.like*.35+ba.heart*.2-ba.resentment*.7+
      ((attrs.openness??50)-50)*.1+(['flirt','kiss','private'].includes(kind)?(b.character.affinities?.romantic||0)*6:12);
  }
  function socialize(s,aId,bId,kind='talk',options={}){
    let a=people.actor(s,aId),b=people.actor(s,bId);if(!a||!b||aId===bId)return s;
    if(!free(s,a)||!free(s,b)||a.site!==b.site||a.room!==b.room)return s;
    if(romantic.has(kind)&&(!a.allowRomance||!b.allowRomance))return s;
    const prior=people.bond(s,bId,aId);
    if((prior.nextSlot||0)>s.slot)return s;
    const denied=kind==='confess'?people.loverReason(s,aId,bId):null;
    const accepted=!denied&&score(s,a,b,kind)+(options.roll??Math.random()*20)>=
      (kind==='confess'?83:kind==='private'?85:romantic.has(kind)?62:40);
    let next=s;
    // Reuse actual vanilla chat/touch responses and effects when the receiver has a compatible model.
    const receiver=b.gender==='female'?b:a.gender==='female'?a:null,sender=receiver?.id===bId?a:b;
    const nativeKey={talk:'ask_about_her_day',praise:'thank_her',joke:'share_private_joke',flirt:'flirt',hand:'hold_hand',hug:'hug',kiss:'kiss',private:'ask_fuck'}[kind];
    let nativeAccepted=accepted;
    if(receiver&&nativeKey&&accepted&&(kind!=='private'||sender.gender==='male')){
      const category=kind==='private'?'sex':['hand','hug','kiss'].includes(kind)?'touch':'chat';
      next=people.nativeChoose(next,receiver.id,'cat_'+category,sender.id,{autonomous:true});
      // Category navigation has no time cost and must not reserve the following action.
      let p=people.actor(next,receiver.id);next=people.saveActor(next,{...p,readyAt:s.slot});
      const offered=people.nativeEvent(next,receiver.id,sender.id).choices.some(c=>c.id===nativeKey&&!c.disabled);
      if(offered)next=people.nativeChoose(next,receiver.id,nativeKey,sender.id,{autonomous:true});
      p=people.actor(next,receiver.id);nativeAccepted=offered&&!['refuse','angry','offended'].includes(p.character.lastResponseType);
      if(!Object.values(p.nativeSession?.scenes||{}).some(Boolean))next=people.saveActor(next,{...p,nativeSession:null,interaction:null});
    }
    const ok=accepted&&nativeAccepted;
    const changes=ok?(romantic.has(kind)?{trust:.8,like:1,heart:1.5}:{trust:1.5,like:2}):{like:-.5,resentment:.5};
    next=adjust(next,aId,bId,changes);next=adjust(next,bId,aId,changes);
    if(kind==='confess'&&ok){next=adjust(next,aId,bId,{status:'lover'});next=adjust(next,bId,aId,{status:'lover'});}
    const names={talk:'일상 이야기를',praise:'감사의 말을',joke:'농담을',flirt:'호감을',hand:'손잡기를',hug:'포옹을',kiss:'입맞춤을',confess:'교제를',private:'사적인 만남을'};
    const text=a.name+'와(과) '+b.name+'이(가) '+(names[kind]||'이야기를')+' '+
      (denied?'나눴지만 새 연인 관계는 맺지 않았습니다.':kind==='confess'&&ok?'통해 연인이 되었습니다.':ok?'나눴습니다.':'제안했지만 상대가 거절했습니다.');
    for(const [id,other]of [[aId,bId],[bId,aId]]){
      next=people.setBond(next,id,other,{...people.bond(next,id,other),nextSlot:s.slot+45});
      next=remember(next,id,'social:'+kind,text,other);
      const p=people.actor(next,id);next=people.saveActor(next,{...p,
        ...(p.main?{}:{task:'social'}),readyAt:s.slot+5,mood:clamp(p.mood+(ok?1:-1)),
        character:{...p.character,stats:{...p.character.stats,mood:clamp(p.mood+(ok?1:-1))}}});
    }
    if(receiver&&people.actor(next,receiver.id).nativeSession?.scenes?.sex){
      const partner=people.actor(next,sender.id);next=people.saveActor(next,{...partner,interaction:'autonomous',
        life:{...partner.life,sceneWith:receiver.id}});
    }
    return people.log(next,text,aId);
  }
  function playerInteract(s,a){
    let p=people.get(s,a.id);if(!p)return s;
    if(a.kind==='confess'){
      const denied=people.loverReason(s,p.id,'player');if(denied)return people.log(s,denied,p.id);
      const row=people.bond(s,p.id,'player'),accepted=p.allowRomance&&row.trust+row.like+row.heart>=65&&p.mood>=30;
      let next=accepted?people.setBond(s,p.id,'player',{...row,status:'lover',heart:row.heart+2}):s;
      next=people.save(next,people.remember({...people.get(next,p.id),cooldowns:{...p.cooldowns,confess:s.slot+60}},s,'confess',accepted?'연인 관계를 맺었습니다.':'교제 제안을 거절했습니다.'));
      return people.log(next,p.name+(accepted?'와(과) 연인이 되었습니다.':'이(가) 아직은 교제할 마음이 없다고 답합니다.'),p.id);
    }
    if(a.kind==='gift'){
      if(s.economy.gold<10)return people.log(s,'선물을 살 금화가 부족합니다.',p.id);
      const row=people.bond(s,p.id,'player');let next=people.setBond({...s,economy:{...s.economy,gold:s.economy.gold-10}},p.id,'player',
        {...row,trust:clamp(row.trust+2),like:clamp(row.like+2)});
      return people.log(people.save(next,people.remember({...people.get(next,p.id),cooldowns:{...p.cooldowns,gift:s.slot+60}},s,'gift','작은 선물을 받았습니다.')),p.name+'에게 작은 선물을 건넸습니다.',p.id);
    }
    const key={talk:'ask_about_her_day',praise:'thank_her',hand:'hold_hand',hug:'hug'}[a.kind];
    if(!key)return null;
    let next=people.nativeChoose(s,p.id,'cat_'+(['hand','hug'].includes(a.kind)?'touch':'chat'));
    return people.nativeChoose(next,p.id,key);
  }
  function move(s,p,target,pending){
    if(p.room===target){const next=people.save(s,{...p,task:pending.plan?.type||'leisure',targetId:pending.plan?.targetId||null,readyAt:s.slot+(pending.plan?.duration||0),life:{...p.life,lastReason:null,pending:pending.plan?{...pending,phase:'work',due:s.slot+(pending.plan?.duration||0)}:null}});return pending.plan?people.beginWork(next,people.get(next,p.id),pending.plan):next;}
    const town=globalThis.WML.use('town-expansion')||globalThis.WML.use('real-estate')?.navigation;let route=null;
    if(town?.getActorRoute){try{route=town.getActorRoute(s,{actorId:p.id,from:p.room,target});}catch{}}
    const internal=people.rooms(s,p.site).some(r=>r.id===target)&&people.rooms(s,p.site).some(r=>r.id===p.room);
    if(route?.reason||route?.minutes==null&&!internal)return people.save(s,{...p,readyAt:s.slot+10,life:{...p.life,pending:null,lastReason:route?.reason||'이동 경로 없음'}});
    const minutes=route?.minutes??2;
    return people.save(s,{...p,room:'town:transit',task:'walking',targetId:pending.plan?.targetId||null,readyAt:s.slot+minutes,
      life:{...p.life,lastReason:null,pending:{...pending,phase:'walk',from:p.room,target,due:s.slot+minutes}}});
  }
  function tick(s,p){
    if(people.inProjection())return s;
    s=people.nativePatronTick?.(s,p.id)||s;p=people.get(s,p.id);
    p=people.nativePassive(s,p);s=people.save(s,p);
    if(p.nativeSession?.partner==='player'&&p.room!==api.fn('playerLocation')(s)&&!people.nativeHasPatron(p))return people.nativeClose(s,p.id);
    if(p.nativeSession||p.interaction)return s;
    if(p.character?.birthLeaveDay===s.day){
      s=people.cancelWork(s,p,p.life?.pending?.plan);
      p=people.get(s,p.id);
      return people.save(s,{...p,task:'rest',targetId:null,readyAt:s.slot,
        room:p.room==='town:transit'?p.life?.pending?.from||p.homeRoom:p.room,
        life:{...p.life,pending:null,lastReason:'출산 휴가 중 · 다음 날 아침 복귀'}});
    }
    if(p.employed&&!people.housing.valid(s,p)){s=people.cancelWork(s,p,p.life?.pending?.plan);p=people.get(s,p.id);return people.save(s,{...p,task:'rest',readyAt:s.slot,
      room:p.room==='town:transit'?p.life?.pending?.from||p.homeRoom:p.room,
      life:{...p.life,pending:null,lastReason:'고용인의 방 배정 필요'}});}
    const hour=(s.slot%1440)/60,run=p.life?.pending;
    const lateService=p.employed&&p.enabled&&p.paidDay===s.day&&['service','last_call'].includes(s.phase);
    if(run){
      if(run.plan&&(!p.employed||!p.enabled||p.paidDay!==s.day||!people.workValid(s,p,run.plan))){
        s=people.cancelWork(s,p,run.plan);p=people.get(s,p.id);
        return people.save(s,{...p,room:p.room==='town:transit'?run.from||p.homeRoom:p.room,task:'idle',targetId:null,readyAt:s.slot,life:{...p.life,pending:null,lastReason:'업무 조건 변경 · 다시 배정 대기'}});}
      if(s.slot<run.due)return s;
      if(run.phase==='walk'){
        p={...p,room:run.target,task:run.plan?.type||'leisure',readyAt:s.slot+(run.plan?.duration||10),
          life:{...p.life,pending:run.plan?{...run,phase:'work',due:s.slot+run.plan.duration}:null}};
        const next=people.save(s,p);return run.plan?people.beginWork(next,p,run.plan):next;
      }
      const stepped=people.stepWork(s,p,run.plan);if(stepped)return stepped;
      const cleared=people.save(s,{...p,task:'idle',readyAt:s.slot,life:{...p.life,pending:null}});
      const next=people.completeWork(cleared,people.get(cleared,p.id),run.plan);
      const latest=people.get(next,p.id);return people.save(next,{...latest,energy:clamp(latest.energy-(run.plan?.energyCost??1.5)),readyAt:s.slot,task:'idle',targetId:null});
    }
    if(p.readyAt>s.slot)return s;
    if(!lateService&&(hour<7||hour>=23)||p.energy<20||p.task==='rest'&&p.energy<65){
      if(p.room!==p.homeRoom)return move(s,p,p.homeRoom,{plan:null});
      return people.save(s,{...p,task:!lateService&&(hour<7||hour>=23)?'sleeping':'rest',energy:clamp(p.energy+1.5),readyAt:s.slot,life:{...p.life,lastReason:null}});
    }
    if(people.managerStatus(s,p).acting){
      const office=people.housing.managerRoom(s,p.site);
      if(p.room!==office.id)return move(s,p,office.id,{plan:null});
      return people.save(s,{...p,task:'managing',energy:clamp(p.energy+.1),readyAt:s.slot});
    }
    if(p.employed&&p.enabled&&p.paidDay===s.day&&['prep','service','last_call'].includes(s.phase)){
      const plan=people.planWork(s,p);
      if(plan?.wait)return people.save(s,{...p,task:'idle',readyAt:s.slot});
      if(plan&&!resourceBusy(s,p.site,plan.room,plan.resourceId,p.id))return move(s,p,plan.room,{plan});
      const base=people.dutyHome(s,p);if(p.room!==base&&people.rooms(s,p.site).some(r=>r.id===base))return move(s,p,base,{plan:null});
    }
    // Free companions can use available rooms even when no employment contract exists.
    if(!p.employed&&p.socialEnabled&&s.slot%60===p.hiredDay%60){
      const rooms=people.rooms(s,p.site).filter(r=>!['bedroom','bathroom'].includes(r.id)&&
        (!['servant','manager'].includes(r.staffRole)||r.id===p.homeRoom));
      if(rooms.length){const target=rooms[Math.floor(Math.random()*rooms.length)].id;if(target!==p.room)return move(s,p,target,{plan:null});}
    }
    return people.save(s,{...p,task:'idle',targetId:null,energy:clamp(p.energy+.3),life:{...p.life,lastReason:['closed','bedroom'].includes(s.phase)?'영업 종료 · 휴식':p.site!==people.context(s).origin?'이 사업장에 연결된 술집 업무 없음':'대기 · 처리할 업무 또는 사용 가능한 자원 없음'}});
  }
  function resourceBusy(s,site,room,resource,exceptId){return (site===people.context(s).origin&&resource==='stove'&&(people.externalReservations(s).kitchenBusy||api.fn('wife')(s)?.currentTask==='cooking'))||people.list(s).some(p=>p.id!==exceptId&&p.site===site&&
    p.life?.pending?.plan?.room===room&&p.life.pending.plan.resourceId===resource);}
  people.installAIAdapter({controls:(_s,p)=>p?.active!==false,tick,interact:playerInteract,resourceBusy,
    reservedCustomers:s=>people.list(s).map(p=>p.life?.pending?.plan?.targetId).filter(Boolean),
    canEdit:(_s,p,patch)=>p.life?.pending&&['site','homeRoom','job','duty','enabled','employed'].some(k=>patch[k]!=null&&patch[k]!==p[k])?'이동·업무가 끝난 뒤 배치를 바꿔 주세요.':null,
    canDismiss:(_s,p)=>p.life?.pending?'이동·업무가 끝난 뒤 고용을 종료해 주세요.':null});
  api.hook('minuteTick',{priority:-2000,after(s){
    if(people.inProjection()||!s||people.blocked(s))return s;
    let next=s;
    // A subcharacter scene progresses on its own; it never waits for a remote player choice.
    for(const initial of [...people.list(next),people.actor(next,people.mainId(next))]){
      const p=people.actor(next,initial.id),session=p.nativeSession;
      if(!session||people.nativeHasPatron(p)||session.partner==='player'||p.readyAt>next.slot)continue;
      const partner=people.actor(next,session.partner);
      if(!partner||partner.room!==p.room||next.slot-session.startedAt>=45){next=people.nativeClose(next,p.id);continue;}
      const menu=people.nativeEvent(next,p.id,session.partner),choices=menu.choices.filter(c=>!c.disabled);
      const choice=choices.find(c=>c.id==='continue')||choices.find(c=>c.id==='keep_going')||
        choices.find(c=>!['stop','back','pull_away'].includes(c.id)&&!c.id.startsWith('invite_join:')&&!c.id.startsWith('throw_out:'));
      if(choice)next=people.nativeChoose(next,p.id,choice.id,session.partner,{autonomous:true});
      else next=people.nativeClose(next,p.id);
    }
    const data=people.read(next),cell=Math.floor(next.slot/30);if(data.socialCell===cell)return next;
    next=people.write(next,{...data,socialCell:cell});
    const candidates=[...people.list(next).filter(p=>p.site===people.context(next).active),people.actor(next,people.mainId(next))];
    const used=new Set();let count=0;
    for(const source of candidates){if(count>=8)break;const a=people.actor(next,source.id);if(used.has(a.id)||!free(next,a))continue;
      const choices=candidates.map(p=>people.actor(next,p.id)).filter(b=>b.id!==a.id&&!used.has(b.id)&&free(next,b)&&a.site===b.site&&a.room===b.room&&(!a.main||!b.main));
      if(!choices.length)continue;
      choices.sort((x,y)=>people.bond(next,a.id,y.id).like-people.bond(next,a.id,x.id).like);
      const b=choices[Math.floor(Math.random()*Math.min(3,choices.length))],row=people.bond(next,b.id,a.id);
      let kind=['talk','joke','praise'][Math.floor(Math.random()*3)];
      if(a.allowRomance&&b.allowRomance){
        if(row.like>=30&&row.heart>=10&&a.gender!==b.gender&&Math.random()<.15)kind='private';
        else if(row.like>=20&&row.heart>=10&&Math.random()<.25)kind=row.status==='lover'?'kiss':'confess';
        else if(row.like>=8&&Math.random()<.35)kind='flirt';
      }
      next=socialize(next,a.id,b.id,kind);used.add(a.id);used.add(b.id);count++;
    }
    return next;
  }});
  Object.assign(people,{tasks:{...tasks,managing:'건물 관리'},socialize,freeForSocial:free});
};
