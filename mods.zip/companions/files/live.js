// 창관(Brothel)의 인물 실시간 창 구성을 참고한 동료 전용 모니터.
// 화면 설정만 저장합니다. 인물·진행·시간을 별도로 복제하거나 실행하지 않습니다.
globalThis.Companions_실시간연결=function(api,people,openProfile){
  'use strict';
  const h=api.ui.h,key='wml.mod.companions.live',cards=new Map(),personalWindows=new Map(),listeners=new Set(),settings=new Set(),views=new Set();
  let win=null,grid=null,viewport=null,queued=false,legacyVisibility=false;
  const positive=value=>Number.isSafeInteger(value)&&value>=1;
  let config={columns:1,rows:1,slots:{},visible:false,imageHeights:{},showDialogue:false,showThought:false};
  try{const value=JSON.parse(localStorage.getItem(key));if(value){legacyVisibility=!('visible' in value);config={columns:positive(value.columns)?value.columns:1,rows:positive(value.rows)?value.rows:1,
    slots:value.slots&&typeof value.slots==='object'?Object.fromEntries(Object.entries(value.slots).filter(([index,id])=>/^\d+$/.test(index)&&Number.isSafeInteger(Number(index))&&typeof id==='string')):{},visible:value.visible===true,
    imageHeights:value.imageHeights&&typeof value.imageHeights==='object'?Object.fromEntries(Object.entries(value.imageHeights).filter(([,height])=>Number.isFinite(height)&&height>=70&&height<=1080)):{},
    showDialogue:value.showDialogue===true,showThought:value.showThought===true};}}catch{}
  if(!Number.isSafeInteger(config.columns*config.rows))config.rows=1;
  function save(){try{localStorage.setItem(key,JSON.stringify(config));}catch(error){api.warn('실시간 창 설정 저장 실패: '+error.message);}}
  function notify(){for(const fn of listeners)fn();for(const entry of [...settings]){if(!entry.root.isConnected){settings.delete(entry);continue;}entry.check.checked=config.visible;for(const [name,input]of entry.inputs)if(document.activeElement!==input)input.value=config[name];for(const [name,input]of entry.textOptions)input.checked=config[name];}}
  const imageHeight=id=>config.imageHeights[id]??180;
  const stageLabels={chatting:'대화',flirting:'추파와 농담',light_touch:'가벼운 접촉',bold_touch:'대담한 접촉',groping:'짙은 스킨십',intimate:'은밀한 애무',handjob_patron:'손 서비스',blowjob_patron:'구강 서비스',titfuck_patron:'가슴 서비스',sex_patron:'성관계'};
  const sexLabels={sex:'성관계',sex_rough:'성관계',anal:'항문 성관계',blowjob:'구강 서비스',deepthroat:'구강 서비스',handjob:'손 서비스',titfuck:'가슴 서비스',riding:'기승위',doggy_style:'후배위',standing_sex:'서서 성관계',rubbing:'애무',cunnilingus:'구강 애무',kiss:'입맞춤'};
  const taskLabels={...people.tasks,walking:'이동 중',leisure:'자율 생활',social:'교류',patron:'접객',managing:'매니저 업무',bathing:'목욕',away:'외출',at_market:'장보기',passed_out:'의식 없음'};
  const taskNotes={greeting:'손님을 맞이하고 있습니다.',taking_order:'주문을 받고 있습니다.',serving:'음식·술을 서빙하고 있습니다.',unavailable:'품절 메뉴를 안내하고 있습니다.',cleaning:'탁자와 바닥을 청소하고 있습니다.',cooking:'음식을 준비하고 있습니다.',laundry:'빨래를 하고 있습니다.',beds:'침대를 정리하고 있습니다.',rest:'휴식하며 기력을 회복하고 있습니다.',sleeping:'잠을 자고 있습니다.',bathing:'목욕하고 있습니다.',managing:'사업장을 관리하고 있습니다.'};
  function placeName(state,id){return globalThis.WML.use('construction-tool')?.getRooms?.(state)?.find(r=>r.id===id)?.label||people.roomNames[id]||api.fn('companionsLocationLabels')[id]||id||'위치 미상';}
  function currentView(state,p){
    const run=p.life?.pending,plan=run?.plan,session=p.nativeSession,scenes=session?.scenes||{},patron=scenes.patron,sex=scenes.sex;
    const outfitId=p.character?.outfit,outfit=api.fn('outfits').find(row=>row.id===outfitId);
    const view={task:taskLabels[p.task]||p.task||'대기',outfit:outfit?.label||outfit?.name||outfitId||'복장 미상',description:''};
    if(sex){view.task=sexLabels[sex.type]||String(sex.type||'장면 진행').replaceAll('_',' ');const partner=patron?.customerName||(session.partner==='player'?'당신':people.get(state,session.partner)?.name);view.description=[partner?partner+' · '+view.task:view.task,Number.isFinite(sex.ticksElapsed)?sex.ticksElapsed+'분 경과':''].filter(Boolean).join(' · ');}
    else if(patron){view.task=stageLabels[patron.stage]||String(patron.stage||'접객').replaceAll('_',' ');view.description=[patron.customerName,api.fn('companionsPatronDescription')(patron.stage,patron.primarySlot)].filter(Boolean).join(' · ');}
    else if(session){view.task='대화';view.description='대화·개인 만남 중';}
    else if(run?.phase==='walk'){view.task='이동 중';view.description=placeName(state,run.target)+'으로 이동 중 · '+Math.max(0,Math.ceil(run.due-state.slot))+'분 남음';}
    else if(plan){view.task=plan.label||taskLabels[plan.type]||plan.type;const target=state.customers?.find(c=>c.id===plan.targetId)?.name;view.description=[target,taskNotes[plan.type]||plan.label||view.task,Math.max(0,Math.ceil(run.due-state.slot))+'분 남음'].filter(Boolean).join(' · ');}
    else view.description=taskNotes[p.task]||people.workStatus(state,p);
    return view;
  }
  function paintHeight(card){const id=card.resolve(),height=imageHeight(id);card.el.style.setProperty('--companions-image-height',height+'px');card.resize.setAttribute('aria-valuenow',String(height));}
  function setImageHeight(id,height){config.imageHeights[id]=Math.round(Math.max(70,Math.min(1080,height)));for(const card of views)if(card.resolve()===id)paintHeight(card);}
  function installResize(card){
    const handle=card.resize;
    handle.onpointerdown=event=>{
      if(event.button!==0||!people.get(api.store.game(),card.resolve()))return;
      event.preventDefault();event.stopPropagation();card.cancelResize?.();
      const id=card.resolve(),start=imageHeight(id),startY=event.clientY,pointer=event.pointerId;
      card.resizingId=id;try{handle.setPointerCapture(pointer);}catch{}
      const finish=commit=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',up);window.removeEventListener('pointercancel',cancel);try{handle.releasePointerCapture(pointer);}catch{}delete card.cancelResize;delete card.resizingId;handle.classList.remove('dragging');if(commit)save();else setImageHeight(id,start);};
      const move=next=>{if(next.pointerId!==pointer)return;if(card.resolve()!==id||!people.get(api.store.game(),id)||!card.el.isConnected){finish(false);return;}setImageHeight(id,start+next.clientY-startY);};
      const up=next=>{if(next.pointerId===pointer)finish(true);},cancel=next=>{if(next.pointerId===pointer)finish(false);};
      card.cancelResize=()=>finish(false);handle.classList.add('dragging');window.addEventListener('pointermove',move);window.addEventListener('pointerup',up);window.addEventListener('pointercancel',cancel);
    };
    handle.onkeydown=event=>{const id=card.resolve();if(!people.get(api.store.game(),id)||!['ArrowUp','ArrowDown','Home','End'].includes(event.key))return;event.preventDefault();event.stopPropagation();setImageHeight(id,event.key==='Home'?70:event.key==='End'?1080:imageHeight(id)+(event.key==='ArrowUp'?-10:10));save();};
  }
  function createCard(id,index){
    const image=h('img',{alt:'',loading:'lazy'}),message=h('p',{class:'companions-live-message'}),name=h('strong'),place=h('span',{class:'companions-live-place'}),task=h('span',{class:'companions-live-task','data-companions-live-task':''}),outfit=h('span',{class:'companions-live-outfit','data-companions-live-outfit':''}),description=h('p',{class:'companions-live-description','data-companions-live-description':''}),stats=h('p'),story=h('p');
    const dialogue=h('p',{'data-companions-live-dialogue':''}),thought=h('p',{'data-companions-live-thought':''});
    dialogue.hidden=thought.hidden=true;
    const resolve=()=>typeof id==='function'?id():id;
    const profile=api.ui.button('개인 화면',()=>{const p=people.get(api.store.game(),resolve());if(p)openProfile(p.id);});
    const el=h('section',{class:'companions-live-card'},h('div',{class:'companions-live-image'},image,message),h('div',{class:'companions-live-info'},h('div',{class:'companions-live-name'},name,task,outfit,place),description,stats,story,profile));
    const resize=h('div',{class:'companions-image-resizer',role:'separator','aria-orientation':'horizontal','aria-label':'초상화 높이 조절','aria-valuemin':70,'aria-valuemax':1080,tabindex:0,title:'위아래로 끌어 초상화 높이 조절'});el.querySelector('.companions-live-image').after(resize);
    if(index===undefined)story.replaceWith(dialogue,thought);
    const card={el,image,message,name,place,task,outfit,description,stats,story,dialogue,thought,profile,resolve,resize,ticket:0,stamp:'',options:''};views.add(card);installResize(card);paintHeight(card);
    if(index!==undefined){const select=h('select',{'aria-label':'실시간 동료 '+(index+1),'data-companions-live-select':index});card.select=select;el.dataset.companionsLiveCell=index;el.prepend(select);
      select.onchange=()=>{card.cancelResize?.();config.slots[index]=select.value;card.stamp='';save();update();notify();};}
    image.onerror=()=>{image.hidden=true;message.textContent='이미지 경로를 확인해 주세요.';message.hidden=false;};return card;
  }
  function destroyCard(card){card.cancelResize?.();views.delete(card);card.ticket++;card.el.remove();}
  function openPersonal(id){
    const person=people.get(api.store.game(),id);
    if(!person)return;
    const existing=personalWindows.get(id);
    if(existing){existing.focus();return;}
    const card=createCard(id);
    const handle=api.ui.window({id:'companions-live-person-'+id,title:person.name+' · 실시간',width:330,height:390,
      render(body,windowHandle){
        windowHandle.el.dataset.companionsWindow='personal-live';
        body.style.display='flex';card.el.style.flex='1';body.append(card.el);updateCard(card);
      },
      onClose(){destroyCard(card);personalWindows.delete(id);}});
    personalWindows.set(id,handle);
    updateCard(card);
  }
  function updateCard(card,state=api.store.game()){
    if(!state)return;const list=people.list(state),p=list.find(p=>p.id===card.resolve());
    if(card.select){const signature=JSON.stringify(list.map(p=>[p.id,p.name]));if(card.options!==signature){card.options=signature;card.select.replaceChildren(h('option',{value:''},'동료 선택'));for(const p of list)card.select.append(h('option',{value:p.id},p.name));}card.select.value=card.resolve()||'';}
    if(card.resizingId&&card.resizingId!==p?.id)card.cancelResize?.();paintHeight(card);card.resize.hidden=!p;card.resize.tabIndex=p?0:-1;card.profile.disabled=!p;
    for(const [node,show,value,label] of [[card.dialogue,config.showDialogue,p?.character?.lastResponse,'대사'],[card.thought,config.showThought,p?.character?.innerThought,'속마음']]){
      node.hidden=!show||!value;
      node.textContent=node.hidden?'':label+' · '+value;
    }
    if(!p){card.ticket++;card.stamp='';card.image.removeAttribute('src');card.image.hidden=true;delete card.el.dataset.companionsLiveId;
      card.message.hidden=false;card.message.textContent='표시할 동료를 선택하세요.';for(const node of [card.name,card.place,card.task,card.outfit,card.description,card.stats,card.story]){node.textContent='';node.removeAttribute('title');}return;}
    card.el.dataset.companionsLiveId=p.id;card.name.textContent=p.name;
    const view=currentView(state,p);card.place.textContent=placeName(state,p.room);card.place.title=card.place.textContent;
    card.task.textContent=view.task;card.task.title=view.task;card.outfit.textContent=view.outfit;card.outfit.title='복장: '+view.outfit;card.description.textContent=view.description;
    card.stats.textContent='기력 '+Math.round(p.energy)+' · 기분 '+Math.round(p.mood)+' · 신뢰 '+Math.round(p.relationship.trust);card.story.textContent=p.memories?.at(-1)?.text||'아직 개인 기록이 없습니다.';
    const request=p.gender==='female'?people.imageRequest(p,state):null,stamp=p.id+'|'+p.portrait+'|'+(request?.key||'fixed')+'|'+(p.gender==='female'?state.slot:'');
    if(stamp===card.stamp)return;card.stamp=stamp;const ticket=++card.ticket;card.message.hidden=false;card.message.textContent='이미지를 불러옵니다…';
    people.imageSource(p,state).then(result=>{if(!card.el.isConnected||ticket!==card.ticket)return;card.image.hidden=!result.url;if(result.url){card.image.alt=p.name;card.image.src=result.url;}else card.image.removeAttribute('src');card.message.hidden=!result.message;card.message.textContent=result.message;})
      .catch(error=>{if(ticket===card.ticket&&card.el.isConnected){card.image.hidden=true;card.message.hidden=false;card.message.textContent='이미지 조회 실패: '+error.message;}});
  }
  // Materialize viewport cells only, instead of allocating columns*rows cards.
  function layout(){
    if(!grid||!viewport)return;
    const width=Math.max(145,(viewport.clientWidth-8*(config.columns-1))/config.columns),height=Math.max(240,(viewport.clientHeight-8*(config.rows-1))/config.rows);
    grid.style.width=(width+8)*config.columns-8+'px';grid.style.height=(height+8)*config.rows-8+'px';grid.dataset.layout=config.columns+'x'+config.rows;
    const firstCol=Math.min(config.columns-1,Math.max(0,Math.floor(viewport.scrollLeft/(width+8)))),firstRow=Math.min(config.rows-1,Math.max(0,Math.floor(viewport.scrollTop/(height+8))));
    const keep=new Set(),lastCol=Math.min(config.columns-1,firstCol+Math.ceil(viewport.clientWidth/(width+8))+1),lastRow=Math.min(config.rows-1,firstRow+Math.ceil(viewport.clientHeight/(height+8))+1);
    for(let row=firstRow;row<=lastRow;row++)for(let col=firstCol;col<=lastCol;col++){
      const index=row*config.columns+col;keep.add(index);let card=cards.get(index);if(!card){card=createCard(()=>config.slots[index],index);cards.set(index,card);grid.append(card.el);}
      Object.assign(card.el.style,{position:'absolute',left:col*(width+8)+'px',top:row*(height+8)+'px',width:width+'px',height:height+'px'});
    }
    for(const [index,card]of cards)if(!keep.has(index)){destroyCard(card);cards.delete(index);}update();
  }
  function update(){const state=api.store.game();for(const card of views)updateCard(card,state);}
  function setVisible(value){
    config.visible=!!value;save();
    if(!value){win?.close();notify();return;}
    if(win){win.focus();notify();return;}
    if(!Object.keys(config.slots).length){config.slots=Object.fromEntries(people.list(api.store.game()).map((p,index)=>[index,p.id]));save();}
    win=api.ui.window({id:'companions-live',title:'동료 실시간',width:Math.min(1100,300*config.columns),height:Math.min(900,360*config.rows+100),render(body,handle){
      handle.el.setAttribute('data-companions-window','live');handle.el.style.setProperty('z-index','2147483647','important');body.classList.add('companions-live');
      viewport=h('div',{class:'companions-live-viewport'});grid=h('div',{class:'companions-live-grid','data-companions-live-grid':''});viewport.append(grid);body.append(viewport);viewport.onscroll=layout;
      const observer=new ResizeObserver(layout);observer.observe(viewport);handle.el.addEventListener('companions-live-dispose',()=>observer.disconnect(),{once:true});
    },onClose(){const old=win;win=null;old?.el.dispatchEvent(new Event('companions-live-dispose'));for(const card of cards.values())destroyCard(card);cards.clear();grid=null;viewport=null;config.visible=false;save();notify();}});
    layout();notify();
  }
  function renderSettings(root){
    const check=h('input',{type:'checkbox','aria-label':'실시간 인물 창'});check.checked=config.visible;check.onchange=()=>setVisible(check.checked);
    const controls=h('div',{class:'companions-live-settings'}),row=h('div',{class:'companions-live-controls'}),inputs=[];
    for(const [name,label]of [['columns','가로 칸'],['rows','세로 칸']]){const input=h('input',{type:'number',min:1,step:1,value:config[name],'aria-label':label});inputs.push([name,input]);input.onchange=()=>{const value=Number(input.value);if(!input.value.trim()||!positive(value)||!Number.isSafeInteger(value*(name==='columns'?config.rows:config.columns))){input.value=config[name];return;}config[name]=value;save();if(viewport){viewport.scrollTop=0;viewport.scrollLeft=0;}layout();notify();};if(inputs.length===2)row.append(' × ');row.append(h('label',{},label+' ',input));}
    const textOptions=[];
    const textRow=h('div',{class:'companions-live-controls'});
    for(const [name,label] of [['showDialogue','개인 창 대사 표시'],['showThought','개인 창 속마음 표시']]){
      const input=h('input',{type:'checkbox','aria-label':label});
      input.checked=config[name];
      input.onchange=()=>{config[name]=input.checked;save();for(const card of views)updateCard(card);notify();};
      textOptions.push([name,input]);
      textRow.append(h('label',{},input,' '+label));
    }
    controls.append(h('label',{},check,' 실시간 인물 창'),row,textRow);root.append(controls);settings.add({root:controls,check,inputs,textOptions});
  }
  api.store.subscribe(()=>{if(queued)return;queued=true;queueMicrotask(()=>{queued=false;update();notify();});});
  document.head.append(h('style',{},`.companions-live{display:flex;flex-direction:column;min-height:0;overflow:hidden}.companions-live-controls{display:flex;align-items:center;flex-wrap:wrap;gap:8px;margin:8px 0}.companions-live-settings input[type=number]{width:76px;background:#292524;color:#f5f5f4;border:1px solid #78716c;border-radius:4px;padding:4px}.companions-live-card select{background:#292524;color:#f5f5f4;border:1px solid #78716c;border-radius:4px;padding:4px;max-width:100%}.companions-live-viewport{flex:1;min-height:0;overflow:auto}.companions-live-grid{position:relative;min-height:0}.companions-live-card{font-size:1rem;box-sizing:border-box;min-width:0;overflow:auto;display:flex;flex-direction:column;border:1px solid #57534e;border-radius:7px;background:#1c1917}.companions-live-card>select{margin:6px}.companions-live-image{height:var(--companions-image-height,180px);flex:0 0 var(--companions-image-height,180px);position:relative;background:#0c0a09}.companions-live-image img{width:100%;height:100%;object-fit:contain}.companions-live-message{position:absolute;bottom:0;margin:0;background:#1c1917d9;color:#a8a29e;padding:5px;font-size:.6875rem}.companions-live-info{padding:7px;font-size:.75rem}.companions-live-name{display:flex;gap:6px;justify-content:space-between;flex-wrap:wrap}.companions-live-name strong{color:#ddd6fe}.companions-live-name span{font-size:.6875rem;color:#a8a29e}.companions-live-info p{margin:5px 0;overflow-wrap:anywhere}.companions-live-card [hidden]{display:none!important}`));
  document.head.append(h('style',{},`[data-companions-window="live"] .wml-win-title b{font-size:.8125rem}[data-companions-window="live"] .wml-win-close{font-size:1.0625rem}.companions-live-card button,.companions-live-card select{font:inherit;font-size:.75rem}.companions-image-resizer{height:1px;flex:0 0 1px;cursor:ns-resize;touch-action:none;background:#44403c;position:relative}.companions-image-resizer::before{content:'';position:absolute;left:0;right:0;top:-4px;height:9px;background:transparent}.companions-image-resizer:hover::before,.companions-image-resizer.dragging::before,.companions-image-resizer:focus-visible::before{background:#78716c44}`));
  people.openLive=()=>setVisible(true);people.renderLiveSettings=renderSettings;
  document.head.append(h('style',{},`.companions-live-name{justify-content:flex-start;align-items:center;gap:4px 7px;min-width:0}.companions-live-name strong{overflow-wrap:anywhere}.companions-live-name .companions-live-task{color:#c4b5fd;font-size:.6875rem}.companions-live-name .companions-live-outfit{color:#d6d3d1;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border:1px solid #57534e;border-radius:999px;padding:1px 5px;font-size:.625rem}.companions-live-name .companions-live-place{margin-left:auto;text-align:right;overflow-wrap:anywhere}.companions-live-description{color:#d6d3d1;line-height:1.5;white-space:pre-wrap}`));
  people.live={legacyVisibility,getConfig:()=>structuredClone(config),setVisible,renderSettings,openPersonal,createCard,updateCard,destroyCard,subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn);}};
  if(config.visible)queueMicrotask(()=>setVisible(true));
};
