// 웨이트리스의 인사→주문→서빙→품절 안내 순서와 구 메이드관의 생활 업무를 참고했습니다.
globalThis.Companions_업무연결 = function Companions_업무연결(api, people) {
  'use strict';
  const game = Object.fromEntries(['ChooseOrder','Available','Consume','Missing','Alternative','Price','Income','RecordDrink','RecordWord']
    .map(name => [name, api.fn('waitress'+name)]));
  const tasks = {idle:'대기', greeting:'손님 맞이', taking_order:'주문 받기', serving:'서빙',
    unavailable:'품절 안내', cleaning:'청소', cooking:'요리', laundry:'빨래', beds:'침대 정리',
    rest:'휴식', sleeping:'수면', conversation:'대화', patron_chat:'손님과 대화'};
  const reservationProviders=new Map();
  const workProviders=new Map();
  function externalReservations(state){const result={customers:new Set(),kitchenBusy:false};for(const provider of reservationProviders.values()){
    const row=provider(state)||{};for(const id of row.customers||[])result.customers.add(id);result.kitchenBusy ||= !!row.kitchenBusy;
  }return result;}
  function workStatus(state,p){const run=p.life?.pending,plan=run?.plan;
    if(p.character?.birthLeaveDay===state.day)return '출산 휴가 중 · 다음 날 아침 복귀';
    if(plan){const target=state.customers?.find(c=>c.id===plan.targetId)?.name;return `${run.phase==='walk'?'이동 → ':''}${plan.label||tasks[plan.type]||plan.type}${target?' · '+target:''} · ${Math.max(0,Math.ceil(run.due-state.slot))}분 남음`;}
    const patron=p.nativeSession?.scenes?.patron;
    if(patron)return `${patron.customerName||'손님'} · 접객 중`;
    if(p.nativeSession||p.interaction)return '대화·개인 만남 중';
    if(p.task==='walking')return '이동 중';
    if(p.employed&&!people.housing.valid(state,p))return '근무 보류 · 고용인의 방 미배정';
    if(!p.employed)return '자율 생활 · 고용 계약 없음';
    if(!p.enabled)return '근무 중지';
    if(p.paidDay!==state.day)return '근무 보류 · 오늘 급여 미지급';
    if(p.task==='rest'||p.task==='sleeping')return tasks[p.task]+' · '+(p.energy<65?'기력 회복 중':'영업 외 시간');
    return p.life?.lastReason||tasks[p.task]||p.task;
  }
  function Companions_업무시작(state, person, task, duration, room, text, targetId = null) {
    const minutes = Math.max(1, Math.round(duration*(1.3-person.skill/200)));
    const updated = {...person, task, room, targetId, readyAt:state.slot+minutes,
      energy:people.clamp(person.energy-1.5), skill:Math.min(100, person.skill+0.02)};
    return people.log(people.save(state, updated), person.name+' '+text, person.id);
  }
  function Companions_예약손님(state) {
    const reserved = new Set(people.list(state).filter(person => person.readyAt > state.slot).map(person => person.targetId).filter(Boolean));
    for (const id of people.getAIAdapter()?.reservedCustomers?.(state) || []) reserved.add(id);
    for(const id of externalReservations(state).customers)reserved.add(id);
    for(const p of people.list(state))for(const id of people.nativeCustomerIds?.(p)||[])reserved.add(id);
    const scene = state.activeScene?.patron;
    for (const id of [scene?.customerId, ...(scene?.joinedPatronIds || []), ...(scene?.crowdPatronIds || []),
      api.fn('wife')(state)?.taskTarget]) if (id) reserved.add(id);
    return reserved;
  }
  function Companions_응대손님(state) {
    const reserved = Companions_예약손님(state);
    return (state.customers || []).filter(customer => !reserved.has(customer.id) &&
      !['gone','leaving'].includes(customer.status) && state.locations?.taproom?.occupants.includes(customer.id) &&
      !api.fn('brothelCustomerBusy')(state, customer.id));
  }
  function Companions_서빙(state, person, customer) {
    const order = customer.order, price = game.Price(order);
    if (!game.Available(state, order)) return state;
    let next = game.Consume(state, order);
    next = {...next, customers:next.customers.map(item => item.id !== customer.id ? item : {...item,
      status:'drinking', tab:(item.tab || 0)+price, walletGold:Math.max(0, (item.walletGold || 0)-price),
      servedBy:person.id, servedQuality:Math.round(person.skill), stayTimer:Math.max(item.stayTimer || 0, 30)}),
      customersServedToday:(next.customersServedToday || 0)+(customer.roundsOrdered === 1 ? 1 : 0),
      servesToday:{count:(next.servesToday?.count || 0)+1,
        qualitySum:(next.servesToday?.qualitySum || 0)+person.skill, spills:next.servesToday?.spills || 0}};
    next = game.RecordWord(next, customer);
    next = game.RecordDrink(next, customer.id, order);
    next = game.Income(next, 'service', price);
    return Companions_업무시작(next, person, 'serving', 3, 'taproom', '이(가) '+customer.name+'에게 주문을 내옵니다. (+'+price+'g)', customer.id);
  }
  function Companions_생활업무(state, person) {
    const auto = person.job === 'auto';
    const settings=people.workSettings(state);
    if ((auto || person.job === 'clean') && state.tavernCleanliness < settings.cleanThreshold)
      return Companions_업무시작({...state, tavernCleanliness:Math.min(100, state.tavernCleanliness+5)},
        person, 'cleaning', 10, 'taproom', '이(가) 탁자와 바닥을 청소합니다.');
    if ((auto || person.job === 'cook') && settings.autoCook && state.supplies.food > 0 && state.readyFood < settings.readyFoodTarget &&
        !people.getAIAdapter()?.resourceBusy?.(state,person.site,'kitchen','stove',person.id)) {
      const portions = Math.min(2, state.supplies.food, settings.readyFoodTarget-state.readyFood);
      return Companions_업무시작({...state, supplies:{...state.supplies, food:state.supplies.food-portions},
        readyFood:state.readyFood+portions}, person, 'cooking', 15, 'kitchen', '이(가) '+portions+'인분을 요리합니다.');
    }
    const data = people.read(state), chores = data.chores || {}, site = person.site;
    // 빨래·침대 정리는 사업장별 하루 한 번입니다. 여러 명을 고용해도 보너스를 중복 지급하지 않습니다.
    for (const [task, job, room] of [['laundry','laundry','kitchen'], ['beds','beds',state.tavern.hasRoom ? 'upstairs_hall' : null]]) {
      const key = site+':'+task;
      if (!(auto || person.job === job) || !room || chores[key] === state.day) continue;
      const next = people.write(state, {...data, chores:{...chores, [key]:state.day}});
      return Companions_업무시작(next, person, task, task === 'beds' ? 8 : 12, room,
        task === 'beds' ? '이(가) 객실 침대를 정리합니다.' : '이(가) 수건과 작업복을 세탁합니다.');
    }
    return state;
  }
  function Companions_손님교류(state, person, customers) {
    if (person.gender !== 'female') return state;
    const customer = customers.find(item => item.status === 'drinking' &&
      (person.patrons['patron:'+item.name]?.nextSlot || 0) <= state.slot);
    if (!customer) return state;
    const key = 'patron:'+customer.name, prior = person.patrons[key] || {name:customer.name, talks:0, trust:0, affection:0};
    const flirt = person.allowRomance && prior.trust >= 12 && person.mood >= 50 && ['allure','devil','cute','girlish'].includes(person.personality);
    const record = {...prior, talks:prior.talks+1, trust:people.clamp(prior.trust+2),
      affection:people.clamp(prior.affection+(flirt ? 1 : 0)), lastDay:state.day, nextSlot:state.slot+90};
    let updated = {...person, patrons:{...person.patrons, [key]:record}};
    const text = person.name+'이(가) '+customer.name+(flirt ? '와(과) 다정한 농담을 나눕니다.' : '의 이야기를 듣고 자신의 생각을 들려줍니다.');
    updated = people.remember(updated, state, flirt ? 'patron_flirt' : 'patron_chat', text, key);
    return Companions_업무시작(state, updated, 'patron_chat', 4, 'taproom',
      customer.name+'와(과) '+(flirt ? '다정한 농담을 나눕니다.' : '이야기를 나눕니다.'), customer.id);
  }
  function Companions_개별업무(state, person) {
    if (person.readyAt > state.slot || person.interaction) return state;
    const customers = Companions_응대손님(state), hall = ['auto','hall'].includes(person.job);
    if (hall && ['service','last_call'].includes(state.phase)) {
      const arrived = customers.find(customer => customer.status === 'arrived');
      if (arrived) return Companions_업무시작({...state,
        customers:state.customers.map(customer => customer.id !== arrived.id ? customer : {...customer, status:'greeted'})},
        person, 'greeting', 2, 'taproom', '이(가) '+arrived.name+'을(를) 빈자리로 안내합니다.', arrived.id);
      const waiting = customers.find(customer => ['greeted','wants_more'].includes(customer.status));
      if (waiting) {
        const order = game.ChooseOrder();
        return Companions_업무시작({...state, customers:state.customers.map(customer => customer.id !== waiting.id ? customer :
          {...customer, status:'ordered', order, roundsOrdered:(customer.roundsOrdered || 0)+1,
            patience:customer.maxPatience ?? customer.patience})}, person, 'taking_order', 2, 'taproom',
          '이(가) '+waiting.name+'의 주문을 받습니다.', waiting.id);
      }
      const ordered = customers.filter(customer => customer.status === 'ordered' && customer.order);
      const ready = ordered.find(customer => game.Available(state, customer.order));
      if (ready) return Companions_서빙(state, person, ready);
      if (ordered.length) {
        const customer = ordered[0], alternative = game.Alternative(state, customer.order);
        const next = {...state, customers:state.customers.map(item => item.id !== customer.id ? item : alternative ?
          {...item, order:alternative, patience:Math.max(1, (item.patience || 1)-1)} : item.isResident ?
          {...item, status:'drinking', order:null, stayTimer:30} : {...item, status:'leaving', mood:'angry'}),
          customersLostToday:(state.customersLostToday || 0)+(!alternative && !customer.isResident ? 1 : 0)};
        return Companions_업무시작(next, person, 'unavailable', 2, 'taproom', '이(가) 품절 메뉴와 대체 메뉴를 안내합니다.', customer.id);
      }
    }
    const worked = Companions_생활업무(state, person);
    if (worked !== state) return worked;
    const social = ['auto','hall'].includes(person.job) ? Companions_손님교류(state, person, customers) : state;
    if (social !== state) return social;
    return people.save(state, {...person, room:person.homeRoom, task:'idle', targetId:null, energy:people.clamp(person.energy+0.5)});
  }
  function Companions_분진행(state, options = {}) {
    if (!state || state.gameOver || state.pmCore) return state;
    let next = people.wages(state);
    if (next.pendingEvent) return next;
    const siteId = options.siteId;
    const hour = Math.floor(next.slot/60)%24;
    for (const record of people.list(next)) {
      if (siteId&&record.site !== siteId || record.lastSlot === next.slot) continue;
      let person = {...record, lastSlot:next.slot};
      const ai = people.getAIAdapter();
      if (!ai && person.npcAI?.enabled) {
        person={...person,task:'idle',targetId:null,readyAt:next.slot,
          room:person.room==='town:transit'?(person.npcAI.pending?.lastPassed||person.npcAI.lastPassed||person.homeRoom):person.room,
          npcAI:{...person.npcAI,enabled:false,pending:null,lastReason:'개인 AI 연결이 꺼져 진행 중 작업을 취소했습니다.'}};
        next=people.save(next,person);
        continue;
      }
      if (ai?.controls(next, person)) {
        next = ai.tick(people.save(next, person), person, options);
        continue;
      }
      if (hour < 7 || person.energy < 15 || person.task === 'rest' && person.energy < 65 ||
          !person.enabled || person.paidDay !== next.day || ['closed','bedroom'].includes(next.phase)) {
        person = {...person, task:hour < 7 ? 'sleeping' : 'rest', room:person.homeRoom,
          targetId:null, energy:people.clamp(person.energy+1.5), readyAt:Math.max(person.readyAt, next.slot)};
        next = people.save(next, person);
      } else {
        next = people.save(next, person);
        next = Companions_개별업무(next, person);
      }
      const latest = people.get(next, person.id);
      if (latest.character) next = people.save(next, {...latest, character:{...latest.character,
        currentTask:latest.task === 'rest' ? 'idle' : latest.task,
        stats:{...latest.character.stats, energy:latest.energy, mood:latest.mood},
        relationship:{...latest.character.relationship, trust:latest.relationship.trust}}});
    }
    return next;
  }
  api.hook('minuteTick', {priority:-1000, after:state => Companions_분진행(state)});
  api.hook('brothelCustomerBusy', {after(value, [state, id]) {
    return value || people.list(state).some(person => person.id!==people.projectionActor?.()&&
      (person.targetId === id && person.readyAt > state.slot||(people.nativeCustomerIds?.(person)||[]).includes(id)));
  }});
  api.hook('companionsReservedPatrons',{after(value,[state]){
    const reserved=new Set(value);
    for(const p of people.list(state))if(p.id!==people.projectionActor?.())
      for(const id of people.nativeCustomerIds?.(p)||[])reserved.add(id);
    return reserved;
  }});
  // 계획은 자원을 바꾸지 않으며, 완료 때 실제 상태를 다시 확인합니다. 외부 AI 연결용입니다.
  function basePlanWork(state, person) {
    if(person.site!==people.context(state).origin)return null;
    const settings=people.workSettings(state);
    const make=(type,duration,room,extra={})=>({type,duration:Math.max(1,Math.round(duration*(1.3-person.skill/200))),
      site:person.site,room,resourceId:extra.targetId || type,...extra});
    const customers=Companions_응대손님(state),hall=['auto','hall'].includes(person.job),auto=person.job==='auto';
    if (hall && ['service','last_call'].includes(state.phase)) {
      const arrived=customers.find(c=>c.status==='arrived');
      if(arrived)return make('greeting',2,'taproom',{targetId:arrived.id,status:arrived.status});
      const waiting=customers.find(c=>['greeted','wants_more'].includes(c.status));
      if(waiting)return make('taking_order',2,'taproom',{targetId:waiting.id,status:waiting.status});
      const ordered=customers.filter(c=>c.status==='ordered'&&c.order);
      const ready=ordered.find(c=>game.Available(state,c.order));
      if(ready)return make('serving',3,'taproom',{targetId:ready.id,status:ready.status,order:ready.order});
      if(ordered.length)return make('unavailable',2,'taproom',{targetId:ordered[0].id,status:'ordered',order:ordered[0].order});
    }
    if((auto||person.job==='clean')&&state.tavernCleanliness<settings.cleanThreshold)return make('cleaning',10,'taproom');
    if((auto||person.job==='cook')&&settings.autoCook&&state.supplies.food>0&&state.readyFood<settings.readyFoodTarget&&
      !people.getAIAdapter()?.resourceBusy?.(state,person.site,'kitchen','stove',person.id))
      return make('cooking',15,'kitchen',{resourceId:'stove'});
    const chores=people.read(state).chores || {};
    for(const [type,job,room]of [['laundry','laundry','kitchen'],['beds','beds',state.tavern.hasRoom?'upstairs_hall':null]])
      if((auto||person.job===job)&&room&&chores[person.site+':'+type]!==state.day)
        return make(type,type==='beds'?8:12,room);
    return null;
  }
  function primaryWork(state,person){
    const duty=people.dutyOf(person);
    for(const [owner,provider]of workProviders)if(provider.duty===duty){const plan=provider.plan?.(state,person);if(plan)return {...plan,provider:owner};}
    if(duty==='hall')return basePlanWork(state,{...person,job:'hall'});
    if(duty==='rooms')return basePlanWork(state,{...person,job:'beds'})||basePlanWork(state,{...person,job:'laundry'});
    return null;
  }
  function planWork(state,person){return primaryWork(state,person)||basePlanWork(state,person);}
  function dutyHome(state,person){
    const supplied=people.dutyDefinition(people.dutyOf(person))?.home?.(state,person);
    if(supplied)return supplied;
    return people.dutyOf(person)==='rooms'?(people.rooms(state,person.site).find(r=>r.type==='guest_room'||r.id==='upstairs_hall')?.id||'taproom'):'taproom';
  }
  function workValid(state, person, plan) {
    if(!plan||person.site!==plan.site)return false;
    if(plan.provider)return workProviders.get(plan.provider)?.valid?.(state,person,plan)===true;
    if(!['prep','service','last_call'].includes(state.phase))return false;
    if(person.site!==people.context(state).origin||person.employed&&!people.housing.valid(state,person))return false;
    if(plan.targetId){
      const c=state.customers.find(c=>c.id===plan.targetId);
      if(!['service','last_call'].includes(state.phase)||!c||c.status!==plan.status||
        !state.locations?.taproom?.occupants.includes(c.id)||api.fn('wife')(state)?.taskTarget===c.id||externalReservations(state).customers.has(c.id))return false;
      if(plan.order&&c.order!==plan.order)return false;
      if(plan.type==='serving')return game.Available(state,c.order);
      if(plan.type==='unavailable')return !game.Available(state,c.order);
      return true;
    }
    const settings=people.workSettings(state);
    if(plan.type==='cooking')return settings.autoCook&&state.supplies.food>0&&state.readyFood<settings.readyFoodTarget&&api.fn('wife')(state)?.currentTask!=='cooking'&&!externalReservations(state).kitchenBusy;
    if(plan.type==='cleaning')return state.tavernCleanliness<settings.cleanThreshold;
    return (people.read(state).chores || {})[person.site+':'+plan.type]!==state.day;
  }
  function completeWork(state, person, plan) {
    if(!workValid(state,person,plan))return state;
    if(plan.provider)return workProviders.get(plan.provider).complete?.(state,person,plan)||state;
    if(plan.type==='serving')return Companions_서빙(state,person,state.customers.find(c=>c.id===plan.targetId));
    let next=state;
    if(plan.type==='greeting'||plan.type==='taking_order'||plan.type==='unavailable'){
      next={...state,customers:state.customers.map(c=>{
        if(c.id!==plan.targetId)return c;
        if(plan.type==='greeting')return {...c,status:'greeted'};
        if(plan.type==='taking_order')return {...c,status:'ordered',order:game.ChooseOrder(),roundsOrdered:(c.roundsOrdered||0)+1,patience:c.maxPatience??c.patience};
        const alternative=game.Alternative(state,c.order);
        return alternative?{...c,order:alternative,patience:Math.max(1,(c.patience||1)-1)}:
          {...c,status:c.isResident?'drinking':'leaving',order:null,...(c.isResident?{stayTimer:30}:{mood:'angry'})};
      })};
      if(plan.type==='unavailable'&&next.customers.find(c=>c.id===plan.targetId)?.status==='leaving')
        next={...next,customersLostToday:(next.customersLostToday||0)+1};
    }else if(plan.type==='cleaning')next={...next,tavernCleanliness:Math.min(100,next.tavernCleanliness+5)};
    else if(plan.type==='cooking'){
      const portions=Math.min(2,next.supplies.food,people.workSettings(next).readyFoodTarget-next.readyFood);
      next={...next,supplies:{...next.supplies,food:next.supplies.food-portions},readyFood:next.readyFood+portions};
    }else{
      const data=people.read(next);
      next=people.write(next,{...data,chores:{...data.chores,[person.site+':'+plan.type]:next.day}});
    }
    return people.log(next,person.name+'이(가) '+tasks[plan.type]+'을(를) 마쳤습니다.',person.id);
  }
  Object.assign(people, {tick:Companions_분진행, tasks,workStatus,externalReservations,
    registerWorkReservations(owner,provider){if(reservationProviders.has(owner))throw Error('업무 예약 연결 중복');reservationProviders.set(owner,provider);return()=>reservationProviders.delete(owner);},
    workReservations(state){const plans=people.list(state).map(p=>p.life?.pending?.plan).filter(Boolean);return{customers:plans.map(p=>p.targetId).filter(Boolean),kitchenBusy:plans.some(p=>p.type==='cooking')};},
    reservedCustomers:Companions_예약손님,planWork,primaryWork,workValid,completeWork,dutyHome,
    registerWorkProvider(owner,provider){if(workProviders.has(owner))throw Error('업무 실행 연결 중복');workProviders.set(owner,provider);return()=>workProviders.delete(owner);},
    beginWork:(s,p,plan)=>workProviders.get(plan?.provider)?.begin?.(s,p,plan)||s,
    stepWork:(s,p,plan)=>workProviders.get(plan?.provider)?.step?.(s,p,plan),
    cancelWork:(s,p,plan)=>workProviders.get(plan?.provider)?.cancel?.(s,p,plan)||s,
    patronChat:Companions_손님교류,hallCustomers:Companions_응대손님});
};
