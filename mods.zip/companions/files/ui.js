globalThis.Companions_화면연결 = function Companions_화면연결(api, people) {
  'use strict';
  const h = api.ui.h, cache = new Map(), portraitUrls = new Map(), pendingUploads = new Set();
  let portraitDatabase = null;
  let win = null, selected = null, refreshQueued = false, information = null, hireWin = null, hireView = null;
  const info=globalThis.Companions_정보화면(api,people);
  const profileSections=new Map();people.registerProfileSection=(owner,render)=>{if(profileSections.has(owner))throw Error('개인 화면 연결 중복');profileSections.set(owner,render);return()=>profileSections.delete(owner);};
  const newDraft=()=>({name:'',gender:'female',personality:'shy',tier:'basic',archetypeId:'elena_farmgirl',relationType:'employee',employed:true,maleImage:null,site:null,mode:'random',template:null,templateKey:'',attributes:{},latentTraits:[]});
  const draft=newDraft();
  const relationOptions=[['step_sibling','의붓동생'],['childhood_friend','친구'],['employee','고용인·종업원']];
  const relationLabel=id=>relationOptions.find(row=>row[0]===id)?.[1]||id;
  const labels = {talk:'일상 이야기', praise:'수고를 칭찬한다', gift:'작은 선물 · 10g',
    hand:'손잡기를 청한다', hug:'포옹을 청한다', confess:'마음을 전한다'};
  function Companions_선택창(value, options, label) {
    const select = h('select', {'aria-label':label});
    for (const [id, text] of options) select.append(h('option', {value:id}, text));
    select.value = value;
    return select;
  }
  function Companions_입력줄(parent, label, input) {
    parent.append(h('label', {class:'companions-field'}, h('span', null, label), input));
    return input;
  }
  function Companions_행동(type, args) { api.store.dispatch({type:'companions/'+type, ...args}); }
  function renderWorkSettings(body){
    const state=api.store.game();if(!state)return;
    const settings=people.workSettings(state),section=h('section',{class:'companions-section','data-companions-work-settings':''});
    section.append(h('h3',null,'자동 청소·요리 기준'));
    for(const [key,label,min,max,help]of [
      ['cleanThreshold','자동 청소 기준',0,100,'청결도가 이 값보다 낮으면 청소합니다. 0이면 자동 청소를 하지 않습니다. 기본값: 70.'],
      ['readyFoodTarget','자동 요리 목표 수량',1,100,'준비된 음식이 이 수량보다 적으면 한 번에 최대 2인분씩 보충합니다. 기본값: 4.']]){
      const input=h('input',{type:'number',inputmode:'numeric',min,max,step:1,value:settings[key],'aria-label':'동료 '+label});
      input.onchange=()=>{const value=Number(input.value);if(!input.value.trim()||!Number.isInteger(value)||value<min||value>max){input.value=people.workSettings(api.store.game())[key];return;}Companions_행동('work-policy',{[key]:value});input.value=people.workSettings(api.store.game())[key];};
      Companions_입력줄(section,label+' ('+min+'~'+max+')',input);section.append(h('p',{class:'wml-note'},help));
    }
    const cook=h('input',{type:'checkbox','aria-label':'동료 자동 요리'});cook.checked=settings.autoCook;
    cook.onchange=()=>Companions_행동('work-policy',{autoCook:cook.checked});
    section.append(h('label',null,cook,' 자동 요리'),h('p',{class:'wml-note'},'남녀 종업원 공통 설정 · 변경 즉시 적용되며 게임 저장에 보관됩니다. 주요 업무를 먼저 처리하고 보조 업무 선호와 재료·조리대·근무 조건에 따라 작업합니다.'));
    body.append(section);
  }
  function Companions_고용원형초기화(){draft.template=null;draft.templateKey='';draft.attributes={};draft.latentTraits=[];}
  function Companions_고용원형확인(state){
    const key=[draft.gender,draft.archetypeId,draft.personality].join('|');
    if(draft.template&&draft.templateKey===key)return draft.template;
    draft.template=people.hireTemplate(state,{gender:draft.gender,archetypeId:draft.archetypeId,personality:draft.personality,name:draft.name});
    draft.templateKey=key;draft.attributes={...draft.template.baseAttributes};draft.latentTraits=[...draft.template.baseTraits];return draft.template;
  }
  function Companions_그림저장소() {
    if(portraitDatabase)return portraitDatabase;
    portraitDatabase=new Promise((resolve,reject)=>{
      const request=indexedDB.open('wml.mod.companions.portraits',1);
      request.onupgradeneeded=()=>request.result.createObjectStore('portraits');
      request.onsuccess=()=>{
        request.result.onversionchange=()=>{request.result.close();portraitDatabase=null;};
        resolve(request.result);
      };
      request.onerror=()=>{portraitDatabase=null;reject(request.error);};
    });
    return portraitDatabase;
  }
  async function Companions_스탠딩저장(person, file) {
    // WML 백업은 JSON 자료만 보존합니다. File/Blob 대신 문자열을 별도 그림 저장소에 둡니다.
    const dataUrl=await new Promise((resolve,reject)=>{
      const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(reader.error);
      reader.readAsDataURL(file);
    });
    const database=await Companions_그림저장소();
    const key='companions-portrait:'+person.id+':'+crypto.randomUUID();
    await new Promise((resolve,reject)=>{
      const transaction=database.transaction('portraits','readwrite');
      transaction.objectStore('portraits').put({name:file.name,type:file.type,dataUrl},key);
      transaction.oncomplete=resolve;transaction.onerror=()=>reject(transaction.error);
    });
    Companions_행동('edit',{id:person.id,patch:{portrait:key}});
  }
  function Companions_이미지첨부(file){
    if(!file)return false;
    if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>1000000){
      api.log('그림은 PNG/JPEG/WebP, 1MB 이하로 선택해 주세요.');return false;
    }
    return true;
  }
  function Companions_첨부저장(person,file){
    const saving=Companions_스탠딩저장(person,file);pendingUploads.add(saving);
    saving.catch(error=>api.warn('스탠딩 저장 실패: '+error.message)).finally(()=>pendingUploads.delete(saving));
    return saving;
  }
  async function Companions_스탠딩주소(key) {
    if(portraitUrls.has(key))return portraitUrls.get(key);
    const database=await Companions_그림저장소();
    const record=await new Promise((resolve,reject)=>{
      const request=database.transaction('portraits').objectStore('portraits').get(key);
      request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);
    });
    if(!record?.dataUrl)throw Error('저장된 스탠딩이 없습니다. WML 백업을 복원하거나 그림을 다시 등록해 주세요.');
    const url=record.dataUrl;portraitUrls.set(key,url);
    if(portraitUrls.size>64)portraitUrls.delete(portraitUrls.keys().next().value);
    return url;
  }
  function Companions_그림설명(person, state=api.store.game()) {
    if (person.gender !== 'female' || !person.character) return null;
    const projected=people.nativeView(state,person.id,person.nativeSession?.partner||'player');
    const task={laundry:'cleaning',beds:'cleaning',rest:'idle',conversation:'idle',social:'idle',
      patron_chat:'idle',unavailable:'taking_order',walking:'idle',leisure:'idle'}[person.task]||person.task;
    const native=api.fn('companionsVisualState')(projected);
    const character=api.fn('companionsVisualCharacter')({...projected.characters[projected.primaryCharacterId],
      currentTask:task,stats:{...person.character.stats,energy:person.energy,mood:person.mood}},native);
    // 원본 키·장면·기분·인원·진행 상태를 그대로 사용해 기존 이미지팩을 재사용합니다.
    const room=people.buildingRooms(state,person.site).find(r=>r.id===person.room);
    return api.fn('imagePrompt')(character,api.fn('imageRoom')(room?.template||person.room),
      api.fn('companionsVisualMood')(projected),api.fn('playerSexScene')(projected)?.ticksElapsed,
      api.fn('patronScene')(projected),api.fn('companionsVisualContext')(projected));
  }
  function Companions_기본초상(person) {
    if(person.gender!=='female'||!person.character)return null;
    const profile=api.fn('wifeById')(person.character.archetypeId);
    return api.fn('wifePortraits')[profile?.shortname || person.character.archetypeId.split('_')[0]];
  }
  async function Companions_고정그림(person){
    if(!person.portrait)return '';
    if(person.portrait.startsWith('companions-portrait:'))return Companions_스탠딩주소(person.portrait);
    return person.portrait.startsWith('portraits/')?api.fileUrl(person.portrait):person.portrait;
  }
  async function Companions_그림읽기(person,state=api.store.game()){
    if(person.gender==='male')return {url:await Companions_고정그림(person),message:person.portrait?'':'고정 이미지 한 장을 등록해 주세요.'};
    const request=Companions_그림설명(person,state);
    const found=await api.fn('companionsImageLookup')(request.key);
    if(found)return {url:api.fn('companionsImageUrl')(found),message:'',key:request.key};
    if(cache.has(request.key))return {url:cache.get(request.key),message:'',key:request.key};
    return {url:await Companions_고정그림(person)||Companions_기본초상(person)||'',
      message:'현재 모습의 이미지가 없어 기본 초상화를 표시합니다.',key:request.key};
  }
  async function Companions_그림표시(img,message,person){
    const result=await Companions_그림읽기(person);
    if(!img.isConnected)return;
    if(result.url)img.src=result.url;
    message.textContent=result.message;
  }
  function Companions_상세화면(body, state, person) {
    const section = h('section', {class:'companions-section', 'data-companions-profile':person.id});
    if(people.nativeHasPatron(person))section.append(api.ui.button('접객 중단',()=>Companions_행동('native-stop',{id:person.id})));
    const manager = people.managerStatus(state, person);
    section.append(h('h3', null, person.name+' · '+(person.gender === 'male' ? '남성 동료' : '여성 동료')+
      (manager.acting ? ' · 매니저 대행 중' : manager.appointed ? ' · 매니저 대행 지정' : '')));
    const grid = h('div', {class:'companions-profile-grid'}), visual = h('div');
    const image = h('img', {alt:person.name, class:'companions-portrait'}), message=h('p',{class:'wml-note'});
    image.onerror=()=>{
      const fallback=Companions_기본초상(person);
      if(fallback&&image.getAttribute('src')!==fallback){image.src=fallback;message.textContent='기본 초상화를 표시합니다.';return;}
      image.style.display='none';message.textContent='그림 경로를 확인해 주세요.';
    };
    visual.append(image,message); grid.append(visual);
    Companions_그림표시(image,message,person).catch(error=>{message.textContent='그림 조회 실패: '+error.message;});
    if (person.gender === 'female') visual.append(api.ui.button('현재 모습 불러오기 · 생성', async ()=>{
      message.textContent='현재 모습의 그림을 준비합니다…';
      try {
        const request=Companions_그림설명(people.get(api.store.game(),person.id));
        const result=await api.fn('imageGenerate')({imageKey:request.key,prompt:request.prompt,
          negativePrompt:request.negativePrompt,...request.genParams,debug:{imageMatching:request.imageMatching},width:832,height:1216});
        if(result?.url){cache.set(request.key,result.url);image.src=result.url;message.textContent='';}
        else message.textContent='게임의 이미지 서버 연결과 생성 설정을 확인해 주세요.';
      } catch(error) {message.textContent='그림 준비 실패: '+error.message;}
    }));
    const detail=h('div');
    detail.append(h('p',null,people.workStatus(state,person)+' · '+
      (people.rooms(state,person.site).find(room=>room.id===person.room)?.name || people.roomNames[person.room] || person.room)),
      h('p',null,'기력 '+Math.round(person.energy)+' · 일솜씨 '+Math.round(person.skill)+' · 일당 '+person.wage+'g'));
    {
      detail.append(h('p',null,people.personalities.find(item=>item.id===person.personality).label+
        ' · 기분 '+Math.round(person.mood)+' · 신뢰 '+Math.round(person.relationship.trust*10)/10+
        ' · 애정 '+Math.round(person.relationship.affection*10)/10));
      const memories=h('details',null,h('summary',null,'개인 기억 '+person.memories.length+'개 · 알고 지내는 손님 '+Object.keys(person.patrons).length+'명'));
      for(const memory of person.memories.slice(-12).reverse())memories.append(h('p',null,memory.day+'일 · '+memory.text));
      for(const record of Object.values(person.patrons))memories.append(h('p',null,record.name+' · 대화 '+record.talks+'회 · 신뢰 '+record.trust));
      detail.append(memories);
    }
    const informationButtons=h('div',{class:'companions-actions','data-companions-information':''});
    for(const[tab,label]of Object.entries({details:'세부 스테이터스 확인',relationships:'인간 관계 확인',status:'상태',secrets:'비밀'}))
      informationButtons.append(api.ui.button(label,()=>{information=tab;win?.refresh();},{primary:information===tab}));
    informationButtons.append(api.ui.button('이 직원이 있는 방으로 이동',()=>{
        Companions_행동('visit',{id:person.id});
        const current=api.store.game(),latest=people.get(current,person.id);
        if(latest?.site===people.context(current).active&&api.fn('playerLocation')(current)===latest.room)win?.close();
      }));
    detail.append(informationButtons,h('p',{class:'wml-note'},'직원이 있는 방으로 이동한 뒤, 행동 칸의 “'+person.name+'”를 선택합니다.'));
    if(information)info.render(detail,state,person,information);
    detail.append(api.ui.button('개인 실시간 창',()=>people.live.openPersonal(person.id)));
    for(const render of profileSections.values())render(detail,state,person);
    people.getAIAdapter()?.render?.(detail,state,person);
    grid.append(detail);section.append(grid);
    if(person.active!==false){
      const form=h('div',{class:'companions-form'});
      const name=Companions_입력줄(form,'이름',h('input',{type:'text',value:person.name,maxlength:32,'aria-label':'직원 이름'}));
      const duty=Companions_입력줄(form,'주요 업무',Companions_선택창(people.dutyOf(person),people.dutyOptions(state,person).map(row=>[row.id,row.label]),'주요 업무'));
      const job=Companions_입력줄(form,'보조 업무 선호',Companions_선택창(person.job,Object.entries(people.jobs),'담당 업무'));
      const wage=Companions_입력줄(form,'일당',h('input',{type:'number',min:0,max:500,value:person.wage,'aria-label':'직원 일당'}));
      const sites=people.context(state).sites;
      const site=Companions_입력줄(form,'근무 사업장',Companions_선택창(person.site,sites.map(item=>[item.id,item.name]),'근무 사업장'));
      const home=Companions_입력줄(form,'고용인의 방',Companions_선택창(person.housingRoom||'',[],'생활 장소'));
      const updateHomes=()=>{
        home.replaceChildren();
        home.append(h('option',{value:''},'자동 배정 / 현재 배정 유지'));
        for(const room of people.housing.info(api.store.game(),site.value).rooms)
          if(!room.person||room.person.id===person.id)home.append(h('option',{value:room.id},room.name));
        home.value=site.value===person.site?person.housingRoom||'':'';
      };
      site.onchange=updateHomes;updateHomes();
      if(person.employed&&!people.housing.valid(state,person))form.append(h('p',{class:'wml-note'},'고용인의 방 미배정: 근무·급여가 보류됩니다. 아래 건물별 방 배정에서 선택하세요.'));
      const uploaded=person.portrait.startsWith('data:')||person.portrait.startsWith('companions-portrait:');
      const portrait=Companions_입력줄(form,'스탠딩·고정 초상 경로',h('input',{type:'text',value:uploaded?'':person.portrait,
        placeholder:'images/companions/name.webp 또는 portraits/name.webp','aria-label':'초상 경로'}));
      const upload=h('input',{type:'file',accept:'image/png,image/jpeg,image/webp','aria-label':'스탠딩 이미지 선택'});
      upload.onchange=()=>{
        const file=upload.files[0];if(!file)return;
        if(!Companions_이미지첨부(file)){upload.value='';return;}
        Companions_첨부저장(person,file);
      };
      Companions_입력줄(form,person.gender==='male'?'고정 이미지 한 장 첨부':'그림 파일 등록',upload);
      if(person.gender==='male')form.append(h('p',{class:'wml-note'},'첨부한 한 장을 모든 상태에서 사용합니다. 다른 이미지로 바꾸려면 새 파일 한 장을 선택하세요.'));
      const relation=Companions_입력줄(form,'기본 관계',Companions_선택창(person.relationType,relationOptions,'기본 관계'));
      const employed=h('input',{type:'checkbox','aria-label':'고용 계약'});employed.checked=person.employed;Companions_입력줄(form,'고용 계약',employed);
      const social=h('input',{type:'checkbox','aria-label':'자율 소통'});social.checked=person.socialEnabled!==false;Companions_입력줄(form,'자율 소통',social);
      const romance=h('input',{type:'checkbox','aria-label':'자율 로맨스'});romance.checked=person.allowRomance;Companions_입력줄(form,'자율 로맨스',romance);
      let outfit=null;
      if(person.gender==='female'){
        outfit=Companions_입력줄(form,'복장',Companions_선택창(person.character.outfit,
          api.fn('outfits').map(item=>[item.id,item.label || item.name || item.id]),'직원 복장'));
      }
      const enabled=h('input',{type:'checkbox','aria-label':'근무 허용'});enabled.checked=person.enabled;
      Companions_입력줄(form,'근무 허용',enabled);
      section.append(form,api.ui.button('직원 설정 저장',()=>{
        const patch={name:name.value,job:job.value,duty:duty.value,wage:Number(wage.value),site:site.value,enabled:enabled.checked,relationType:relation.value,employed:employed.checked,socialEnabled:social.checked,allowRomance:romance.checked};
        if(home.value&&home.value!==person.housingRoom)patch.homeRoom=home.value;
        if(portrait.value || !uploaded)patch.portrait=portrait.value.trim();
        if(outfit)patch.outfit=outfit.value;
        Companions_행동('edit',{id:person.id,patch});
      },{primary:true}),api.ui.button(people.read(state).managers[person.site]===person.id?'매니저 지정 해제':'매니저 대행 지정',()=>Companions_행동('manager',{id:person.id})),
      api.ui.button('퇴직 확인',()=>{
        api.ui.window({id:'companions-retire',title:'퇴직 확인',width:360,height:180,render(box,confirm){
          confirm.el.setAttribute('data-companions-window','retire');confirm.el.style.setProperty('z-index','2147483647','important');
          box.append(h('p',null,person.name+'의 고용 계약을 종료합니다. 동료·관계·기억은 유지됩니다.'),
            api.ui.button('퇴직 처리',()=>{Companions_행동('dismiss',{id:person.id});confirm.close();}),api.ui.button('취소',()=>confirm.close()));
        }});
      }));
    }
    body.append(section);
  }
  let housingSite=null;
  function renderHousing(body,state){
    const sites=people.housing.sites(state);
    if(!sites.some(s=>s.id===housingSite))housingSite=people.context(state).active;
    if(!sites.some(s=>s.id===housingSite))housingSite=sites[0].id;
    const data=people.housing.info(state,housingSite),section=h('details',{'data-companions-housing':'',open:true},h('summary',null,'건물별 방 배정'));
    const site=Companions_입력줄(section,'건물',Companions_선택창(housingSite,sites.map(s=>[s.id,s.name]),'방 배정 건물'));
    site.onchange=()=>{housingSite=site.value;win?.refresh();};
    section.append(h('p',null,'고용인의 방 '+data.capacity+'개 · 빈 방 '+data.free+'개 · 고용 계약 '+data.employed+'명 · 매니저실 '+data.offices.length+'개'),
      h('p',{class:'wml-note'},'고용인의 방 한 개당 한 명을 배정합니다. 시작 시 비어 있던 그녀의 방도 사용할 수 있습니다. 매니저실은 이 건물의 관리 위임에 필요합니다.'));
    if(!data.rooms.length)section.append(h('p',null,'사용 가능한 고용인의 방이 없습니다. 건축 모드에서 고용인의 방(300g)을 지어 주세요.'));
    for(const room of data.rooms){
      const row=h('div',{class:'companions-actions','data-companions-room':room.id});
      row.append(h('b',null,room.name+(room.borrowed?' · 기존 빈 방':'')));
      const select=Companions_선택창(room.person?.id||'',[['','비워 두기'],...people.list(state).map(p=>[p.id,p.name+(p.site!==housingSite?' · 다른 건물':'')])],room.name+' 동료 배정');
      row.append(select,api.ui.button('배정 저장',()=>Companions_행동('room-assign',{site:housingSite,roomId:room.id,personId:select.value||null})));section.append(row);
    }
    for(const p of people.list(state).filter(p=>p.site===housingSite&&p.employed&&!people.housing.valid(state,p)))
      section.append(h('p',{class:'wml-note'},p.name+' · 고용인의 방 미배정 / 근무·급여 보류'));
    const manager=people.get(state,people.read(state).managers[housingSite]);
    for(const room of data.offices){
      const assigned=manager&&people.managerStatus(state,manager).office===room.id?manager:null;
      const row=h('div',{class:'companions-actions','data-companions-office':room.id},h('b',null,room.name+' · '+(assigned?.name||'관리자 미배정')));
      const select=Companions_선택창(assigned?.id||'',[['','관리자 없음'],...people.list(state).filter(p=>p.site===housingSite&&p.employed).map(p=>[p.id,p.name])],room.name+' 관리자 배정');
      row.append(select,api.ui.button('관리자 배정 저장',()=>{
        if(!select.value&&!assigned)return;
        Companions_행동('office-assign',{site:housingSite,roomId:room.id,personId:select.value||null});
      }));section.append(row);
    }
    body.append(section);
  }
  function Companions_화면그리기(body, handle) {
    // 호환 패치가 고용인 소유 창만 구분하도록 표시합니다. 다른 WML 창의 순서는 변경하지 않습니다.
    handle.el.setAttribute('data-companions-window','main');
    handle.el.style.setProperty('z-index','2147483647','important');
    const state=api.store.game();body.classList.add('companions-panel');
    if(!state){body.append(h('p',null,'게임을 시작한 뒤 고용할 수 있습니다.'));return;}
    const context=people.context(state),list=people.list(state),data=people.read(state);
    body.append(h('p',null,'동료 '+list.length+'/'+data.policy.maxEmployees+'명 · 보유 '+Math.floor(state.economy.gold)+'g · '+state.day+'일째'),
      h('p',{class:'wml-note'},"매니저는 두 사람을 대신하는 직책입니다. 사업장당 한 명을 지정하며, 두 사람이 자리를 비우면 대행합니다."));
    const cards=h('div',{class:'companions-cards'});
    for(const person of list){
      const manager=people.managerStatus(state,person),site=context.sites.find(item=>item.id===person.site);
      cards.append(h('section',{class:'companions-card','data-companions-id':person.id},h('b',null,person.name+' · '+(person.gender==='male'?'남':'여')),
        h('p',null,(site?.name || person.site)+' · '+(people.tasks[person.task] || person.task)),
        h('p',null,manager.acting?'매니저 대행 중':manager.appointed?'대행 담당자':relationLabel(person.relationType)+(person.employed?' · 근무 계약':' · 비고용')),
        api.ui.button('개인 화면',()=>{selected=person.id;information=null;win?.refresh();})));
    }
    const person=selected&&people.get(state,selected);
    if(person)Companions_상세화면(body,state,person);
    const roster=h('details',{open:!person},h('summary',null,'전체 동료 · '+list.length+'명'));
    roster.append(cards);body.append(roster);
    renderHousing(body,state);
    body.append(api.ui.button('새 동료 추가',Companions_추가창열기));
    const settings=h('details',null,h('summary',null,'운영 설정'));
    const max=h('input',{type:'number',min:1,max:64,value:data.policy.maxEmployees,'aria-label':'최대 고용 인원'});
    const exclusive=h('input',{type:'checkbox','aria-label':'기존 연인이 있는 경우 새 연인 관계는 금지'});exclusive.checked=!!data.policy.forbidNewLoversWhenPartnered;
    settings.append(h('label',null,'최대 동료 인원 ',max),h('label',null,exclusive,' 기존 연인이 있는 경우 새 연인 관계는 금지'),h('p',{class:'wml-note'},'교제 성립만 제한합니다. 호감 표현·친밀 행동·바람 행동은 상대의 성향과 반응을 따릅니다. NPC Simulator 연동은 사용하지 않습니다.'),api.ui.button('설정 저장',()=>Companions_행동('policy',{maxEmployees:Number(max.value),forbidNewLoversWhenPartnered:exclusive.checked})));
    body.append(settings);renderWorkSettings(body);people.renderLiveSettings(body);
  }

  function Companions_추가창열기(){
    if(hireWin){document.body.append(hireWin.el);hireWin.focus();return;}
    if(!draft.site)draft.site=people.context(api.store.game()).active;
    hireWin=api.ui.window({id:'companions-hire',title:'새 동료 추가',width:880,height:720,render:Companions_추가화면,
      onClose(){hireWin=null;hireView=null;}});
  }
  function Companions_추가화면(body,handle){
    handle.el.setAttribute('data-companions-window','hire');handle.el.style.setProperty('z-index','2147483647','important');body.classList.add('companions-panel');
    body.append(h('p',{class:'wml-note'},'취소하거나 닫아도 작성 중인 내용은 유지됩니다. 생성할 때 비용을 지불합니다.'));
    const form=h('div',{class:'companions-form','data-companions-hire':''});
    const selectField=(label,value,rows,aria=label)=>Companions_입력줄(form,label,Companions_선택창(value,rows,aria));
    const site=selectField('합류 건물',draft.site,[]),housingNote=h('p',{class:'wml-note'});
    const gender=selectField('성별',draft.gender,[['female','여성 동료'],['male','남성 동료']],'채용 성별');
    const name=Companions_입력줄(form,'이름',h('input',{type:'text',value:draft.name,maxlength:32,'aria-label':'채용 이름'}));
    const relation=selectField('시작 관계',draft.relationType,relationOptions);
    const contract=h('input',{type:'checkbox','aria-label':'합류 시 고용 계약'});contract.checked=draft.employed;Companions_입력줄(form,'고용 계약',contract);
    const tier=selectField('경력·소개비',draft.tier,people.tiers.map(t=>[t.id,t.label+' · '+t.cost+'g']),'채용 경력');
    const appearance=h('div',{class:'companions-field','data-companions-hire-appearance':''});form.append(appearance);
    const personality=selectField('성격',draft.personality,people.personalities.map(t=>[t.id,t.label]),'채용 성격');
    const cost=h('p',{class:'wml-note','data-companions-hire-cost':''}),message=h('p',{class:'wml-note','data-companions-hire-message':'',role:'status'});
    const modes=h('div',{class:'companions-actions','aria-label':'고용 방식'}),allocation=h('div',{'data-companions-hire-allocation':''});
    const random=api.ui.button('아무나 고용',()=>setMode('random')),specified=api.ui.button('지정 고용',()=>setMode('specified'));
    random.dataset.companionsHireMode='random';specified.dataset.companionsHireMode='specified';modes.append(random,specified);
    const create=api.ui.button('생성',generate,{primary:true}),cancel=api.ui.button('취소',()=>handle.close());create.dataset.companionsCreate='';cancel.dataset.companionsCancel='';
    const footer=h('div',{class:'companions-hire-footer'},message,h('div',{class:'companions-actions'},create,cancel));
    body.append(form,housingNote,cost,h('h4',null,'고용 방식'),modes,allocation,footer);
    let budgetNote=null,allocationStatus=null,busy=false,siteStamp='';
    function note(text,error=false){message.textContent=text;message.style.color=error?'#fca5a5':'';}
    function values(){const state=api.store.game(),template=Companions_고용원형확인(state),chosen=people.tiers.find(t=>t.id===draft.tier)||people.tiers[0];
      const base=people.hireAttributes.reduce((sum,[key])=>sum+Number(template.baseAttributes[key]||0),0),budget=Math.min(people.hireAttributes.length*100,Math.round(base*chosen.budgetMultiplier));
      const total=people.hireAttributes.reduce((sum,[key])=>sum+Number(draft.attributes[key]||0),0),baseline=new Set(template.baseTraits),selectedTraits=new Set(draft.latentTraits);
      const changes=people.latentTraitDefs.filter(([key])=>baseline.has(key)!==selectedTraits.has(key)).length;
      const invalid=people.hireAttributes.some(([key])=>String(draft.attributes[key]??'').trim()===''||!Number.isInteger(Number(draft.attributes[key]))||Number(draft.attributes[key])<0||Number(draft.attributes[key])>100);
      return {state,template,chosen,base,budget,total,changes,invalid};
    }
    function update(){
      const {state,chosen,base,budget,total,changes,invalid}=values(),sites=people.context(state).sites;
      const stamp=JSON.stringify(sites.map(s=>[s.id,s.name]));if(stamp!==siteStamp){siteStamp=stamp;site.replaceChildren();for(const s of sites)site.append(h('option',{value:s.id},s.name));if(!sites.some(s=>s.id===draft.site))site.append(h('option',{value:draft.site},'사용할 수 없는 건물 (선택 유지)'));site.value=draft.site;}
      const available=sites.some(s=>s.id===draft.site)?people.housing.info(state,draft.site):{free:0};
      housingNote.textContent='이 건물의 빈 고용인의 방: '+available.free+'개. 고용 계약을 맺을 때 한 명당 한 방이 필요합니다.';
      cost.textContent='소개비 '+chosen.cost+'g'+(draft.employed?' + 오늘 일당 '+chosen.wage+'g':'')+' · 생성 비용 '+(chosen.cost+(draft.employed?chosen.wage:0))+'g · 보유 '+Math.floor(state.economy.gold)+'g';
      if(budgetNote)budgetNote.textContent='개별 상한 100 · 기본 총점 '+base+' · 이 등급의 총 배분 예산 '+budget+' · 체크형 특성 변경 '+chosen.traitEdits+'개';
      const excess=total>budget||changes>chosen.traitEdits||invalid;
      if(allocationStatus){allocationStatus.textContent='현재 총점 '+total+' · 남은 배분 '+(budget-total)+' · 특성 변경 '+changes+'/'+chosen.traitEdits+(invalid?' · 능력치는 0~100 정수로 입력하세요.':'');allocationStatus.style.color=excess?'#fca5a5':'';}
      create.disabled=busy||(draft.mode==='specified'&&excess);random.setAttribute('aria-pressed',String(draft.mode==='random'));specified.setAttribute('aria-pressed',String(draft.mode==='specified'));
    }
    function buildAllocation(){
      allocation.replaceChildren();budgetNote=null;allocationStatus=null;
      if(draft.mode==='specified'){
        const section=h('section',{class:'companions-section companions-allocation'},h('h4',null,'지정 고용 능력치'));budgetNote=h('p',{class:'wml-note'});allocationStatus=h('p',{class:'wml-note','data-companions-allocation-status':''});
        const stats=h('div',{class:'companions-allocation-grid'}),traits=h('div',{class:'companions-trait-grid'});
        for(const [key,label]of people.hireAttributes){const input=h('input',{type:'number',min:0,max:100,step:1,value:draft.attributes[key]??'','aria-label':'지정 능력치 '+label});input.oninput=()=>{draft.attributes[key]=input.value;update();};stats.append(h('label',{class:'companions-field'},h('span',null,label),input));}
        for(const [key,label]of people.latentTraitDefs){const input=h('input',{type:'checkbox','aria-label':'지정 특성 '+label});input.checked=draft.latentTraits.includes(key);input.onchange=()=>{const selected=new Set(draft.latentTraits);input.checked?selected.add(key):selected.delete(key);draft.latentTraits=[...selected];update();};traits.append(h('label',null,input,' ',label));}
        section.append(budgetNote,stats,allocationStatus,h('h4',null,'체크형 숨은 특성'),traits);allocation.append(section);
      }
      update();
    }
    function resetTemplate(){Companions_고용원형초기화();Companions_고용원형확인(api.store.game());buildAllocation();note('외형·성격에 맞춰 기본 능력치와 특성을 갱신했습니다.');}
    function setMode(mode){draft.mode=mode;buildAllocation();note('');}
    function buildAppearance(){
      appearance.replaceChildren();
      if(draft.gender==='female'){
        const profile=Companions_선택창(draft.archetypeId,api.fn('wives').map(p=>[p.id,p.name]),'채용 외형');appearance.append(h('span',null,'외형'),profile);profile.onchange=()=>{draft.archetypeId=profile.value;resetTemplate();};
      }else{
        const upload=h('input',{type:'file',accept:'image/png,image/jpeg,image/webp','aria-label':'남성 동료 고정 이미지'}),fileNote=h('span',{class:'wml-note'});
        const updateFile=()=>{fileNote.textContent=(draft.maleImage?draft.maleImage.name+' · ':'')+'PNG/JPEG/WebP, 1MB 이하. 선택한 한 장을 사용합니다.';};updateFile();
        upload.onchange=()=>{const file=upload.files[0];if(!file)return;if(!Companions_이미지첨부(file)){upload.value='';note('그림은 PNG/JPEG/WebP, 1MB 이하로 선택해 주세요.',true);return;}draft.maleImage=file;updateFile();note('');};appearance.append(h('span',null,'고정 이미지 한 장 첨부'),upload,fileNote);
      }
    }
    function generate(){
      if(busy||hireWin?.el!==handle.el)return;note('');
      const {state,template}=values(),before=people.read(state).nextId;
      const options={name:draft.name,gender:draft.gender,personality:draft.personality,tier:draft.tier,archetypeId:draft.archetypeId,relationType:draft.relationType,employed:draft.employed,site:draft.site,mode:draft.mode,template,attributes:{...draft.attributes},latentTraits:[...draft.latentTraits]};
      busy=true;update();
      try{Companions_행동('hire',{options});}catch(error){busy=false;update();note('생성하지 못했습니다: '+error.message,true);return;}
      const after=api.store.game(),created=people.get(after,'companions_'+before);
      if(people.read(after).nextId!==before+1||!created){busy=false;update();note(after.log?.at(-1)?.text||'현재 조건으로 동료를 생성하지 못했습니다.',true);return;}
      if(options.gender==='male'&&draft.maleImage)Companions_첨부저장(created,draft.maleImage);
      Object.assign(draft,newDraft());selected=created.id;information=null;handle.close();win?.refresh();
    }
    site.onchange=()=>{draft.site=site.value;update();};gender.onchange=()=>{draft.gender=gender.value;buildAppearance();resetTemplate();};
    name.oninput=()=>{draft.name=name.value;};relation.onchange=()=>{draft.relationType=relation.value;draft.employed=relation.value==='employee';contract.checked=draft.employed;update();};
    contract.onchange=()=>{draft.employed=contract.checked;update();};tier.onchange=()=>{draft.tier=tier.value;update();};personality.onchange=()=>{draft.personality=personality.value;resetTemplate();};
    buildAppearance();buildAllocation();hireView={update};
  }
  function Companions_창열기(id) {
    if(id&&id!==selected){selected=id;information=null;}
    if(win){win.refresh();win.focus();document.body.append(win.el);return;}
    win=api.ui.window({id:'companions-main',title:'동료 모드',width:880,height:700,render:Companions_화면그리기,
      onClose(){win=null;}});
    // 이동 후 창을 닫은 직후 로더의 지연된 크기 저장이 0을 기록한 경우 이 창만 복구합니다.
    if(parseFloat(win.el.style.width)<280||parseFloat(win.el.style.height)<160){
      const width=Math.min(880,innerWidth-16),height=Math.min(700,innerHeight-16);
      Object.assign(win.el.style,{width:width+'px',height:height+'px',left:Math.max(8,(innerWidth-width)/2)+'px',
        top:Math.max(8,(innerHeight-height)/3)+'px'});
    }
  }
  const style=h('style',null,`.companions-panel{max-width:100%;overflow-wrap:anywhere}.companions-cards,.companions-form{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,220px),1fr));gap:10px;margin:12px 0}.companions-card,.companions-section{border:1px solid #57534e;border-radius:8px;padding:12px;margin:8px 0}.companions-field{display:flex;flex-direction:column;gap:4px;min-width:0}.companions-field input,.companions-field select{width:100%;min-width:0;box-sizing:border-box;background:#292524;color:#f5f5f4;border:1px solid #78716c;border-radius:4px;padding:5px}.companions-field input[type=checkbox]{width:auto;align-self:flex-start}.companions-actions{display:flex;flex-wrap:wrap;gap:5px}.companions-profile-grid{display:grid;grid-template-columns:minmax(140px,240px) minmax(0,1fr);gap:14px}.companions-portrait{display:block;width:100%;max-height:310px;object-fit:contain}.companions-portrait:not([src]){min-height:100px;background:#292524}.companions-panel details{margin:12px 0}.companions-panel button{margin:3px;max-width:100%;white-space:normal}.companions-allocation-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:7px}.companions-trait-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:5px;font-size:12px}.companions-trait-grid label{border:1px solid #44403c;border-radius:5px;padding:6px}.companions-trait-grid input{accent-color:#d97706}@media(max-width:540px){.companions-profile-grid{grid-template-columns:1fr}.companions-portrait{max-height:220px}.companions-trait-grid{grid-template-columns:1fr}}`);
  document.head.append(style);
  document.head.append(h('style',null,'.companions-actions select{max-width:100%;min-width:0;background:#292524;color:#f5f5f4;border:1px solid #78716c;border-radius:4px;padding:5px}'));
  document.head.append(h('style',null,'[data-companions-window]{z-index:2147483647!important}'));
  document.head.append(h('style',null,`.companions-stat-table{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:5px 12px;margin:10px 0}.companions-stat-table dd{margin:0;overflow-wrap:anywhere}.companions-stat-table dt{color:#b8aaa0}.companions-meter{margin:8px 0}.companions-meter meter{width:100%;height:12px}.companions-location-groups{display:flex;flex-wrap:wrap;gap:6px}.companions-location-group{border:1px solid #57534e;border-radius:5px;padding:6px;min-width:0}.companions-location-group button{display:block;text-align:left;max-width:100%;white-space:normal}.companions-talk-buttons{display:grid;gap:6px}.companions-talk-feedback{white-space:pre-wrap;border-left:2px solid #a78bfa;padding:8px;margin:8px 0}`));
  document.head.append(h('style',null,'.companions-hire-footer{position:sticky;bottom:0;padding:8px 0;background:#1c1917;border-top:1px solid #57534e}.companions-panel [aria-pressed=true]{outline:1px solid #c4b5fd}.companions-panel [data-companions-hire-message]{white-space:pre-wrap;margin:0 0 6px}.companions-panel [data-companions-hire-message]:empty{display:none}'));
  api.ui.addButton({label:'동료',title:'고용·개인 관계·매니저',onClick:()=>Companions_창열기()});
  api.ui.settings(body=>{body.append(api.ui.button('동료 관리창 열기',()=>Companions_창열기()));renderWorkSettings(body);people.renderLiveSettings(body);});
  api.backup.beforeExport(()=>Promise.all([...pendingUploads]));
  api.ui.pauseSettings?.({label:{ko:'동료 모드',en:'Companions'},onClick:()=>Companions_창열기()});
  api.store.subscribe(()=>{
    hireView?.update();
    if(!win||refreshQueued||win.el.contains(document.activeElement)&&['INPUT','SELECT'].includes(document.activeElement.tagName))return;
    refreshQueued=true;queueMicrotask(()=>{refreshQueued=false;win?.refresh();});
  });
  const jsx=api.fn('jsx').jsx,React=api.fn('React'),listeners=new Set();
  let dialogueTarget=null;
  const target=()=>dialogueTarget,subscribe=fn=>{listeners.add(fn);return()=>listeners.delete(fn);};
  function selectTarget(id){dialogueTarget=id;for(const fn of listeners)fn();}
  function closeDialogue(id=dialogueTarget){
    const person=people.get(api.store.game(),id);
    if(person?.gender!=='male'&&person?.nativeSession)Companions_행동('native-close',{id});
    selectTarget(null);
  }
  function openDialogue(id){const s=api.store.game(),p=people.get(s,id);
    if(!p||p.site!==people.context(s).active||p.room!==api.fn('playerLocation')(s)||people.blocked(s))return;
    if(p.gender!=='male'&&people.dialogueReason(s,p))return;
    win?.close();if(p.gender!=='male')Companions_행동('native-open',{id});selectTarget(id);
  }
  function TalkCards(){
    const state=api.fn('store')(root=>root.state);
    if(!state||people.blocked(state))return null;
    const present=people.list(state).filter(p=>p.site===people.context(state).active&&p.room===api.fn('playerLocation')(state)&&p.room!=='town:transit');
    return present.length?jsx('div',{'data-companions-talk-slot':api.fn('playerLocation')(state),children:present.map(person=>{
      const reason=person.gender==='male'?null:people.dialogueReason(state,person);
      return jsx('div',{'data-companions-talk-to':person.id,children:jsx(api.fn('ActionButton'),{label:person.name,
        description:person.gender==='male'?'종업원과 대화합니다.':'말을 걸거나 입맞추거나 만집니다.',disabled:!!reason,
        onClick:()=>openDialogue(person.id)})},person.id);
    })}):null;
  }
  function insertCards(tree,fallback=false){
    const state=api.store.game();if(!state||people.blocked(state))return tree;
    const wife=api.fn('wife')(state),ActionButton=api.fn('ActionButton');let found=false;
    function walk(node){
      if(!React.isValidElement(node))return node;
      if(node.type===ActionButton&&node.props.label===wife.name){found=true;return jsx(React.Fragment,{children:[node,jsx(TalkCards,{})]},node.key||'companions-talk-anchor');}
      if(!node.props.children)return node;
      return React.cloneElement(node,{},React.Children.map(node.props.children,walk));
    }
    const result=walk(tree);
    return !found&&fallback?jsx(React.Fragment,{children:[result,jsx(TalkCards,{})]}):result;
  }
  for(const symbol of ['companionsHallActions','companionsBedroomActions','companionsBathhouseActions','companionsBathroomActions',
    'companionsBackRoomActions','companionsKitchenActions','companionsGuestRoomActions','companionsPrivateRoomActions'])
    api.hook(symbol,{after:tree=>insertCards(tree,true)});
  function NativeAction({render,args,project}){
    if(!project)return insertCards(render(...args),!Object.hasOwn(people.roomNames,api.fn('playerLocation')(api.store.game())));
    return people.withDisplay(project,()=>render(...args));
  }
  function ActionHost({render,args}){
    const state=api.fn('store')(root=>root.state),id=React.useSyncExternalStore(subscribe,target,target),p=people.get(state,id);
    const present=p&&(p.gender==='male'||p.nativeSession?.partner==='player')&&p.site===people.context(state).active&&p.room===api.fn('playerLocation')(state)&&p.room!=='town:transit';
    React.useEffect(()=>{if(id&&!present)closeDialogue(id);},[id,!!present]);
    const shown=present&&!people.blocked(state);
    const project=React.useMemo(()=>people.displayRoot(root=>{
      const person=people.get(root.state,id);if(!person)return {};
      const projected=people.nativeView(root.state,id);
      return {state:{...projected,pendingEvent:people.nativeEvent(root.state,id)},dispatch:action=>{
        if(action.type==='resolve_event'&&action.choiceId==='cancel')closeDialogue(id);
        else if(['wife_topic','scene_action','resolve_event'].includes(action.type))Companions_행동('native-choice',{
          id,key:action.topicId||action.actionId||action.choiceId,targetCustomerId:action.targetCustomerId});
        else if(['set_demeanor','set_dare_reason'].includes(action.type))api.store.dispatch(action);
      }};
    }),[id]);
    if(!shown)return jsx(NativeAction,{render,args},'main');
    if(p.gender==='male')return jsx('div',{'data-companions-dialogue':id,'data-companions-dialogue-placeholder':'',children:[
      jsx('p',{className:'text-sm text-stone-200 mb-3',children:'현재 구현중입니다.'}),
      jsx('div',{'data-companions-dialogue-close':'',children:jsx(api.fn('ActionButton'),{label:'대화 닫기',onClick:()=>closeDialogue(id)})})]});
    return jsx('div',{'data-companions-dialogue':id,'data-companions-native-dialogue':'',children:[
      jsx(NativeAction,{render,args,project},id),
      jsx('div',{'data-companions-dialogue-close':'',children:jsx(api.fn('ActionButton'),{label:'대화 닫기',
        description:"대화 화면을 닫습니다. 그녀와 손님의 진행 중인 행동은 유지됩니다.",onClick:()=>closeDialogue(id)})})]});
  }
  api.hook('ActionPanel',{priority:-4000000,around(render,...args){return jsx(ActionHost,{render,args});}});
  // 키보드 선택도 대상 동료의 원본 이벤트에 전달합니다. 실제 메인 이벤트가 생기면 그 이벤트를 우선합니다.
  window.addEventListener('keydown',event=>{
    const s=api.store.game(),p=people.get(s,dialogueTarget);
    if(!p||people.blocked(s)||event.ctrlKey||event.altKey||event.metaKey||event.target.closest?.('input,textarea,select,[contenteditable=true]'))return;
    let action;
    if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();closeDialogue();return;}
    if(p.gender==='male')return;
    const menu=people.nativeEvent(s,p.id),rows=api.fn('companionsEventHotkeys')(menu);
    if(/^[1-9]$/.test(event.key))action=rows.find(row=>!row.disabled&&String(api.fn('companionsEventDigit')(menu,row.part,row.index))===event.key)?.action;
    if(action){event.preventDefault();event.stopImmediatePropagation();if(action.type==='resolve_event'&&action.choiceId==='cancel')closeDialogue();
      else Companions_행동('native-choice',{id:p.id,key:action.topicId||action.actionId||action.choiceId,targetCustomerId:action.targetCustomerId});}
  },true);
  // 위치 패널의 읽기 투영에만 비충돌 표식을 넣어 빈 방도 원본의 인물 칩 자리를 그리게 합니다.
  const locationProject=people.displayRoot(root=>{
    const s=root.state;if(!s||s.pmCore||s.mods?.wow?.trip)return {};
    const locations={...s.locations};
    for(const p of people.list(s).filter(p=>p.site===people.context(s).active)){
      const room=locations[p.room]||{occupants:[]};locations[p.room]={...room,occupants:[...(room.occupants||[]),'person:companions:'+p.id]};
    }
    return {state:{...s,locations}};
  });
  function addAssignedRoom(tree){
    const s=api.store.game();if(!s||s.pmCore||s.mods?.wow?.trip||!s.locations?.elena_room||!api.fn('companionsSharedBedroom')(s))return tree;
    const list=people.list(s).filter(p=>p.site===people.context(s).active);
    if(!list.some(p=>p.room==='elena_room'||p.housingRoom==='elena_room'||p.homeRoom==='elena_room'))return tree;
    const chips=api.fn('companionsRoomChips'),present=list.some(p=>p.room==='elena_room'),occupied=(s.locations.elena_room.occupants||[]).length>0;
    const card=jsx('div',{'data-companions-native-room':'elena_room',className:'flex-1 min-w-[5.5rem]',children:jsx('div',{
      className:'p-1.5 rounded border border-stone-800 bg-stone-900/40 text-xs leading-tight min-w-0',children:[
        jsx('div',{className:'text-[0.65rem] uppercase tracking-wider text-stone-500 mb-0.5',children:api.fn('companionsLocationLabels').elena_room||'그녀의 방'}),
        jsx('div',{className:'flex flex-wrap gap-1',children:[jsx(chips,{room:'elena_room'}),!present&&!occupied?jsx('span',{className:'text-stone-600 italic',children:'비어 있음'}):null]})]})});
    function insert(node){
      if(!React.isValidElement(node))return node;
      if(node.props.className==='flex flex-wrap gap-1.5'&&Array.isArray(node.props.children)&&node.props.children.length===5){
        const children=[...node.props.children];children[1]=card;
        return React.cloneElement(node,{children});
      }
      return node.props.children?React.cloneElement(node,{},React.Children.map(node.props.children,insert)):node;
    }
    return insert(tree);
  }
  api.hook('companionsLocationPanel',{priority:-4000000,around(next,...args){return addAssignedRoom(people.withDisplay(locationProject,()=>next(...args)));}});
  api.hook('companionsRoomChips',{after(tree,[{room}]){
    const s=api.store.game();if(!s||s.pmCore||s.mods?.wow?.trip)return tree;
    const list=people.list(s).filter(p=>p.site===people.context(s).active&&p.room===room);
    return jsx(React.Fragment,{children:[tree,...list.map(p=>jsx('button',{type:'button',
      className:'px-1 py-0 rounded border border-violet-700 text-violet-200 text-[0.65rem]',
      'data-companions-location-id':p.id,'data-companions-location-room':room,
      onClick:e=>{e.stopPropagation();Companions_창열기(p.id);},children:p.name},p.id))]});
  }});
  Object.assign(people,{imageRequest:Companions_그림설명,imageSource:Companions_그림읽기,
    fixedImage:Companions_고정그림,dialogueTarget:target,subscribeDialogue:subscribe,openDialogue,closeDialogue});
  globalThis.Companions_초상화연결(api,people,{roomName:info.roomName,
    standingUrl:Companions_스탠딩주소,basePortrait:Companions_기본초상,
    cached:key=>cache.get(key),cache:(key,url)=>cache.set(key,url)});
  return Companions_창열기;
};
