// 직원의 실제 자료를 읽습니다. 아내 슬롯이나 전역 H_Status 자료를 바꾸지 않습니다.
globalThis.Companions_정보화면 = function Companions_정보화면(api, people) {
  'use strict';
  const h=api.ui.h, finite=value=>typeof value==='number'&&Number.isFinite(value);
  const names={energy:'기력',mood:'기분',arousal:'흥분도',trust:'신뢰',affection:'애정',resentment:'원망',
    confidence:'자신감',openness:'개방성',composure:'침착함',allure:'매력',wit:'재치',willpower:'의지',
    stamina:'체력',strength:'힘',cooking:'요리',service:'응대',cleaning:'청소',like:'호감',heart:'연심',lust:'욕망',
    loyalty:'충성심',obedience:'순응',charisma:'카리스마',intelligence:'지성',charm:'매력',
    manualGiven:'손 서비스',manualReceived:'손 접촉 경험',oralGiven:'구강 서비스',oralReceived:'구강 접촉 경험',
    vaginalSex:'성관계',analSex:'후방 성관계',otherSex:'기타 친밀 경험',patronMolestation:'원치 않은 접촉'};
  function number(value){return finite(value)?String(Math.round(value*10)/10):'미기록';}
  function table(parent,entries){
    const dl=h('dl',{class:'companions-stat-table'});
    for(const[label,value]of entries)dl.append(h('dt',null,label),h('dd',null,String(value??'미기록')));
    parent.append(dl);
  }
  function bars(parent,entries){
    for(const[label,value]of entries){
      if(!finite(value))continue;
      parent.append(h('div',{class:'companions-meter'},h('div',null,label+' · '+number(value)),
        h('meter',{min:0,max:100,value:Math.max(0,Math.min(100,value)),'aria-label':label})));
    }
  }
  function record(parent,title,value){
    const entries=Object.entries(value||{}).filter(([,v])=>finite(v)||typeof v==='boolean');
    if(!entries.length)return;
    parent.append(h('h4',null,title));table(parent,entries.map(([key,v])=>[names[key]||key,typeof v==='boolean'?(v?'예':'아니오'):number(v)]));
  }
  function memories(parent,person){
    const entries=person.memories||[];
    if(!entries.length)parent.append(h('p',null,'아직 개인 기억이 없습니다.'));
    for(const memory of entries.slice(-60).reverse())parent.append(h('p',null,memory.day+'일 · '+memory.text));
  }
  function detail(parent,state,person){
    const context=people.context(state),manager=people.managerStatus(state,person);
    table(parent,[['이름',person.name],['고용인 ID',person.id],['성별',person.gender==='male'?'남성':'여성'],['나이',person.age],
      ['근무 사업장',context.sites.find(row=>row.id===person.site)?.name||person.site],['현재 장소',roomName(state,person.room)],
      ['담당 업무',people.jobs[person.job]||person.job],['현재 행동',people.workStatus(state,person)],
      ['기본 관계',({step_sibling:'의붓동생',childhood_friend:'친구',employee:'고용인·종업원'})[person.relationType]],['고용 계약',person.employed?'있음':'없음'],['합류일',person.hiredDay+'일'],['일당',person.wage+'g'],['오늘 급여',person.paidDay===state.day?'지급 완료':'미지급'],
      ['일솜씨',number(person.skill)],['근무 허용',person.enabled?'허용':'중지'],
      ['매니저',manager.acting?'대행 중':manager.appointed?'지정됨':'미지정']]);
    record(parent,'개인 수치',person.character?.stats);
    record(parent,'능력치',person.character?.attributes);
  }
  function relationships(parent,state,person){
    parent.append(h('h4',null,(state.player?.name||"당신")+'와의 관계'));
    bars(parent,[['신뢰',person.relationship?.trust],['애정',person.relationship?.affection]]);
    record(parent,'개인 감정',person.character?.playerFeelings);
    const bonds=Object.entries(person.bonds||{}).filter(([id])=>id!=='player');
    parent.append(h('h4',null,'동료·메인 캐릭터와의 관계'));
    for(const [id,row] of bonds){const other=people.actor(state,id);table(parent,[['상대',other?.name||id],['관계',row.status==='lover'?'연인':'알고 지내는 사이'],['신뢰',number(row.trust)],['호감',number(row.like)],['연심',number(row.heart)]]);}
    const patrons=Object.values(person.patrons||{});
    parent.append(h('h4',null,'알고 지내는 손님 · '+patrons.length+'명'));
    if(!patrons.length)parent.append(h('p',null,'아직 기록된 손님 관계가 없습니다.'));
    for(const p of patrons)table(parent,[['이름',p.name],['대화',p.talks+'회'],['신뢰',number(p.trust)],
      ['애정',number(p.affection)],['마지막 만남',p.lastDay==null?'미기록':p.lastDay+'일']]);
  }
  function status(parent,state,person){
    const tabs=[['current','상태'],['personality','성격'],['attributes','능력치'],['reputation','평판'],['memories','개인 기억']];
    const tabbar=h('div',{class:'companions-actions',role:'tablist','aria-label':person.name+' 상태 분류'}),content=h('div');
    function render(key){
      content.replaceChildren();
      for(const b of tabbar.children)b.setAttribute('aria-selected',String(b.dataset.companionsStatusTab===key));
      if(key==='current'){
        bars(content,[['기력',person.energy],['기분',person.mood],['흥분도',person.character?.stats?.arousal],
          ['신뢰',person.relationship?.trust],...(person.gender==='female'?[['애정',person.relationship?.affection]]:[])]);
        const outfit=api.fn('outfits').find(row=>row.id===person.character?.outfit);
        table(content,[['현재 행동',people.workStatus(state,person)],['현재 장소',roomName(state,person.room)],
          ['복장',outfit?.label||outfit?.name||person.character?.outfit||'고정 스탠딩'],
          ['취기',number(person.character?.intoxication?.level)]]);
      }else if(key==='personality'){
        content.append(h('p',null,people.personalities.find(row=>row.id===person.personality)?.label||person.personality));
        record(content,'성향',person.character?.affinities);
        content.append(h('p',null,'자율 로맨스 · '+(person.allowRomance?'허용':'꺼짐')));
      }else if(key==='attributes'){
        table(content,[['일솜씨',number(person.skill)]]);record(content,'능력치',person.character?.attributes);
      }else if(key==='reputation'){
        const value=person.character?.reputation;
        if(value&&Object.keys(value).length)record(content,'개인 평판',value);
        else content.append(h('p',null,'개인 평판 기록이 없습니다.'));
      }else memories(content,person);
    }
    for(const[key,label]of tabs){const b=api.ui.button(label,()=>render(key));b.dataset.companionsStatusTab=key;b.setAttribute('role','tab');tabbar.append(b);}
    parent.append(tabbar,content);render('current');
  }
  function secrets(parent,state,person){
    if(person.gender!=='female'){parent.append(h('p',null,'남성 고용인은 스탠딩과 기본 업무 기록을 사용합니다. 별도의 비밀 기록은 없습니다.'));return;}
    const character=person.character||{},stats=character.situationStats;
    parent.append(h('p',{class:'wml-note'},'이 직원에게 저장된 개인 기록입니다. 기록되지 않은 항목은 미기록으로 표시합니다.'));
    if(!stats)parent.append(h('p',null,'아직 이 직원에게 저장된 H_Status 누적 기록이 없습니다.'));
    table(parent,[['누적 경험',number(stats?.totalSexActCount)],['최면도',number(stats?.hypnosis)],['문양 상태',number(stats?.crest)]]);
    record(parent,'누적 기록',stats?.eventCounts);
    record(parent,'신체 측정',stats?.bodyMeasurements);
    record(parent,'잔류 상태',stats?.fluidState);
    const history=character.intimateHistory||[];
    parent.append(h('h4',null,'개인 만남 기록 · '+history.length+'건'));
    if(!history.length)parent.append(h('p',null,'아직 기록된 친밀한 만남이 없습니다.'));
    for(const row of history.slice(-60).reverse())table(parent,[['날짜',row.day==null?'미기록':row.day+'일'],
      ['상대',row.partnerName||row.customerName||row.partner?.name||'미기록'],['기록 분류',row.kind||row.type||'미기록']]);
  }
  function roomName(state,id){
    return globalThis.WML.use('construction-tool')?.getRooms?.(state).find(row=>row.id===id)?.label||
      globalThis.WML.use('town-expansion')?.getArea?.(state,id)?.label||people.roomNames[id]||api.fn('companionsLocationLabels')[id]||id;
  }
  return {roomName,render(parent,state,person,tab){
    const labels={details:'세부 스테이터스 확인',relationships:'인간 관계 확인',status:'상태',secrets:'비밀'};
    const section=h('section',{class:'companions-section','data-companions-info':tab,'data-companions-info-id':person.id},h('h3',null,person.name+' · '+labels[tab]));
    ({details:detail,relationships,status,secrets}[tab]||detail)(section,state,person);parent.append(section);
  }};
};
