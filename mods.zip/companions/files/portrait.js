// 패배 히로인들의 삶(urkta)이 사용하는 초상화 선택 흐름을 참고한 고용인 표시 연결.
// 동료 대화 중에만 해당 인물을 표시합니다. NPC Simulator 제공자·아내 슬롯·원본 그림 키는 변경하지 않습니다.
globalThis.Companions_초상화연결=function(api,people,images){
  'use strict';
  const React=api.fn('React'),jsx=api.fn('jsx').jsx;
  const blocked=state=>!!people.blocked(state);
  function available(state){
    if(blocked(state))return [];
    const here=api.fn('playerLocation')(state),site=people.context(state).active;
    return people.list(state).filter(person=>person.site===site&&person.room===here&&person.room!=='town:transit');
  }
  const source=(person,state)=>people.imageSource(person,state);
  function Image({person,state}){
    const [picture,setPicture]=React.useState({url:'',message:'이미지를 불러옵니다…'});
    const [generating,setGenerating]=React.useState(false),generation=React.useRef(null),loading=React.useRef(0);
    const request=person.gender==='female'?people.imageRequest(person,state):null;
    const stamp=person.id+'|'+person.portrait+'|'+(request?.key||'standing')+'|'+(person.gender==='female'?state.slot:'');
    React.useEffect(()=>{let cancelled=false;const ticket=++loading.current;
      generation.current=null;setGenerating(false);
      setPicture({url:'',message:'이미지를 불러옵니다…'});
      source(person,state).then(value=>{if(!cancelled&&loading.current===ticket)setPicture(value);}).catch(error=>{if(!cancelled&&loading.current===ticket)setPicture({url:'',message:'이미지 조회 실패: '+error.message});});
      return()=>{cancelled=true;};
    },[stamp]);
    React.useEffect(()=>()=>{generation.current=null;},[]);
    async function generate(){
      const state=api.store.game(),latest=people.get(state,person.id);
      if(latest?.gender!=='female'||!available(state).some(row=>row.id===person.id))return;
      const pending=people.imageRequest(latest,state);loading.current++;generation.current=pending.key;setGenerating(true);
      try{
        const result=await api.fn('imageGenerate')({imageKey:pending.key,prompt:pending.prompt,negativePrompt:pending.negativePrompt,...pending.genParams,debug:{imageMatching:pending.imageMatching},width:832,height:1216});
        if(result?.url)images.cache(pending.key,result.url);
        if(generation.current===pending.key)setPicture(result?.url?{url:result.url,message:''}:{url:images.basePortrait(latest)||'',message:'게임의 이미지 서버 설정을 확인해 주세요.'});
      }catch(error){if(generation.current===pending.key)setPicture({url:'',message:'이미지 준비 실패: '+error.message});}
      finally{if(generation.current===pending.key)setGenerating(false);}
    }
    return jsx('section',{'data-companions-portrait':person.id,'data-companions-portrait-gender':person.gender,className:'min-w-0',children:[
      jsx('div',{className:'text-sm text-amber-200 mb-2',children:person.name+' · '+images.roomName(api.store.game(),person.room)+' · '+(people.tasks[person.task]||person.task)}),
      picture.url?jsx('img',{src:picture.url,alt:person.name,'data-companions-portrait-image':'',
        style:{display:'block',width:'100%',maxHeight:'65vh',objectFit:'contain'},onError:()=>{
          const fallback=person.gender==='female'?images.basePortrait(person):null;
          setPicture({url:fallback&&fallback!==picture.url?fallback:'',message:'등록한 이미지 경로를 확인해 주세요.'});
        }}):null,
      picture.message&&jsx('p',{className:'text-xs text-stone-400 mt-2',children:picture.message}),
      person.gender==='female'&&jsx('button',{type:'button',className:'wml-btn mt-2',disabled:generating,
        'data-companions-portrait-generate':'',onClick:generate,children:generating?'이미지 준비 중…':'현재 모습 불러오기 · 생성'})]});
  }
  function DialoguePortrait({original}){
    const state=api.fn('store')(root=>root.state),list=available(state);
    const talk=React.useSyncExternalStore(people.subscribeDialogue,people.dialogueTarget,people.dialogueTarget);
    const person=list.find(row=>row.id===talk);
    return person?jsx(Image,{person,state},person.id):original;
  }
  api.hook('companionsPortraitPanel',{priority:-30000,after(original){return jsx(DialoguePortrait,{original});}});
};
