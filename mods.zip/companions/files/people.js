// 구 메이드관과 Addon_arhka_Maid의 성격·독립 관계·소개소 구조를 참고했습니다.
globalThis.Companions_인물모델 = function Companions_인물모델(api) {
  'use strict';
  const ID = api.id;
  const clamp = value => Math.max(0, Math.min(100, value));
  const personalities = [
    ['shy','수줍음','조금 긴장했지만, 이야기를 들어 주셔서 기뻐요.'],
    ['pure','순수','오늘도 새로운 일을 배웠어요. 다음에도 함께 이야기해요.'],
    ['cute','애교','오늘 제 일솜씨는 어땠어요? 다음에는 더 잘할게요.'],
    ['girlish','낭만적','가끔은 일 말고, 서로의 이야기도 나누고 싶어요.'],
    ['tsun','츤데레','딱히 기다린 건 아니에요. 그래도 와 주셔서… 고마워요.'],
    ['yan','일편단심','약속을 기억해 주셨네요. 저도 잊지 않고 있었어요.'],
    ['devil','장난기','그렇게 진지하게 들으시면, 오히려 제가 부끄러워지잖아요.'],
    ['allure','여유로움','바쁜 하루였죠? 잠깐 쉬면서 이야기해요.'],
    ['noble','몰락 영애','맡은 일에는 최선을 다하겠어요. 제 의견도 들어 주셨으면 해요.'],
    ['holy','신앙심','서로를 배려하며 일할 수 있다는 게 참 감사해요.'],
    ['queen','당당함','일을 맡기셨으면 믿어 주세요. 필요한 건 분명하게 말씀드릴게요.'],
    ['maso','인내심','괜찮다고만 하지 말고, 제가 힘들어 보이면 알려 주세요.'],
    ['cool','쿨데레','…이야기, 잘 들었어요. 다음에도 들려주세요.'],
    ['sporty','활발함','함께 움직이니까 시간이 금방 가네요!'],
    ['secretary','비서형','장부는 정리해 두었어요. 이제 제 이야기도 조금 들어 주시겠어요?']
  ].map(([id, label, line]) => ({id, label, line}));
  const personalityAdjustments = {
    shy:{attributes:{confidence:25,openness:35},traits:['self_protective']},
    pure:{attributes:{honesty:80,loyalty:75,openness:35},traits:['true_prude']},
    cute:{attributes:{charm:68,confidence:55},traits:['romance_starved']},
    girlish:{attributes:{openness:65,charm:60},traits:['romance_starved']},
    tsun:{attributes:{confidence:65,honesty:45,composure:65},traits:['self_protective']},
    yan:{attributes:{loyalty:85,confidence:60},traits:['jealousy_kindled']},
    devil:{attributes:{wit:70,openness:72,confidence:68},traits:['guilt_eroticizer']},
    allure:{attributes:{charm:78,composure:70,confidence:70},traits:['latent_exhibitionist']},
    noble:{attributes:{composure:78,honesty:68,charm:65},traits:['cold_pragmatist']},
    holy:{attributes:{honesty:88,loyalty:80,openness:32},traits:['true_prude']},
    queen:{attributes:{confidence:85,composure:78},traits:['latent_dominant']},
    maso:{attributes:{vigor:68,composure:62},traits:['latent_masochist']},
    cool:{attributes:{composure:82,confidence:62,openness:42},traits:['self_protective']},
    sporty:{attributes:{strength:68,vigor:78,deftness:62},traits:[]},
    secretary:{attributes:{wit:80,composure:78,honesty:72},traits:['cold_pragmatist']}
  };
  const tiers = [
    {id:'basic', label:'일반 합류', cost:0, wage:10, skill:60, budgetMultiplier:1, traitEdits:0},
    {id:'trainee', label:'숙련 합류', cost:300, wage:12, skill:70, budgetMultiplier:1.3, traitEdits:1},
    {id:'skilled', label:'전문 합류', cost:600, wage:15, skill:82, budgetMultiplier:1.6, traitEdits:3},
    {id:'noblehouse', label:'최상급 합류', cost:1000, wage:20, skill:95, budgetMultiplier:2, traitEdits:6}
  ];
  const hireAttributes = [
    ['strength','힘'],['deftness','손재주'],['vigor','활력'],['wit','재치'],['composure','침착함'],['charm','매력'],
    ['honesty','정직성'],['libido','성욕'],['loyalty','충실성'],['caution','신중함'],['openness','개방성'],['confidence','자신감']
  ];
  const latentTraitDefs = [
    ['true_prude','극도로 보수적'],['self_protective','자기보호적'],['latent_dominant','지배 성향'],['romance_starved','애정에 굶주림'],
    ['likes_cheating','외도 성향'],['cold_pragmatist','냉정한 실리주의자'],['breaks_under_pressure','압박에 약함'],['guilt_eroticizer','죄책감에서 흥분'],
    ['latent_exhibitionist','노출 성향'],['public_thrill_seeker','공개 스릴 추구'],['latent_submissive','복종 성향'],['easily_intoxicated','술에 쉽게 취함'],
    ['enjoys_making_him_jealous','질투 유발을 즐김'],['wants_to_be_corrupted','타락 욕구'],['latent_masochist','피학 성향'],['latent_voyeur','관음 성향'],
    ['curious_about_women','여성에게 호기심'],['jealousy_kindled','질투로 자극받음'],['wary_of_drinks','술을 경계함'],['latent_self_pleasure','숨겨진 자기쾌락 성향']
  ];
  const affinityDefs = [
    ['romantic','로맨스'],['oral','구강'],['vaginal','성관계'],['anal','항문'],['breast','가슴'],['exhibition','노출'],
    ['dominance','지배'],['submission','복종'],['prostitution','금전 관계'],['drinking','음주'],['taboo','금기']
  ];
  const jobs = {auto:'자동 업무', hall:'홀 응대', cook:'요리', clean:'청소', laundry:'빨래', beds:'침대 정리'};
  const dutyDefinitions=new Map([['hall',{id:'hall',label:'홀 서빙'}],['rooms',{id:'rooms',label:'객실 담당'}]]);
  const dutyOf=p=>dutyDefinitions.has(p?.duty)?p.duty:'hall';
  const roomNames = {taproom:'홀', kitchen:'부엌', bedroom:'침실', back_room:'뒷방', bathroom:'욕실',
    bathhouse:'목욕탕', upstairs_hall:'객실', upstairs_room_2:'객실 2', elena_room:'그녀의 방'};
  let adapter = null, aiAdapter = null, housing = null;
  // npc-simulator의 구 동행 저장도 mods.companions를 사용하므로 독립된 roster 아래에 둡니다.
  const read = state => state?.mods?.[ID]?.roster || {schema:2, nextId:1, people:{}, managers:{}, policy:{maxEmployees:12,forbidNewLoversWhenPartnered:false}};
  const write = (state, data) => ({...state, mods:{...state.mods, [ID]:{...state.mods?.[ID],roster:data}}});
  const workSettings = state => {
    const policy=read(state).policy||{};
    return {cleanThreshold:Number.isInteger(policy.cleanThreshold)&&policy.cleanThreshold>=0&&policy.cleanThreshold<=100?policy.cleanThreshold:70,
      readyFoodTarget:Number.isInteger(policy.readyFoodTarget)&&policy.readyFoodTarget>=1&&policy.readyFoodTarget<=100?policy.readyFoodTarget:4,
      autoCook:policy.autoCook!==false};
  };
  const list = state => Object.values(read(state).people).filter(person => person.active !== false);
  const get = (state, id) => read(state).people[id];
  const log = (state, text, id) => ({...state, log:[...(state.log || []),
    {slot:state.slot, text:'[동료] '+text, companionsId:id, eventCategory:'companions'}]});
  function Companions_인물저장(state, person) {
    const data = read(state);
    return write(state, {...data, people:{...data.people, [person.id]:person}});
  }
  function Companions_사업장상황(state) {
    if(housing)return housing.context(state);
    if (adapter) return adapter.context(state);
    const wow = globalThis.__waywardWOW;
    const origin = wow?.roleOf('home') || 'home';
    const active = state.mods?.wow?.home || origin;
    const inside = location => Object.hasOwn(roomNames, location) || String(location).startsWith('ct_');
    const travelling = !!state.mods?.wow?.trip || (wow && wow.where(state).region !== wow.roleOf('home','region'));
    const husbandHere = !travelling && inside(api.fn('playerLocation')(state));
    const wifeHere = !(travelling && state.mods?.wow?.with) && inside(api.fn('wifeLocation')(state));
    return {origin, active, sites:[{id:origin, name:'본점'}],
      ownerAway:!husbandHere && !wifeHere};
  }
  function Companions_방목록(state, site) {
    if(housing)return housing.rooms(state,site);
    const names = {...roomNames};
    if (adapter?.rooms) Object.assign(names, adapter.rooms(state));
    return Object.entries(state.locations || {}).filter(([id]) => names[id]).filter(([id]) =>
      id !== 'bathhouse' || state.tavern?.hasBathhouse).filter(([id]) =>
      id !== 'upstairs_hall' || state.tavern?.hasRoom).filter(([id]) =>
      id !== 'upstairs_room_2' || state.tavern?.hasRoom2).map(([id]) => ({id, name:names[id]}));
  }
  function Companions_행동차단(state) {
    if (!state || state.gameOver) return '진행 중인 게임이 필요합니다.';
    if (state.pmCore) return '다른 임시 플레이 세계에서는 본점 직원을 조작할 수 없습니다.';
    const scenes=state.activeScene||{};
    if (state.pendingEvent || Object.entries(scenes).some(([kind,scene])=>scene&&(kind!=='patron'||scene.playerEngaged||scene.kind==='husband_led')) || state.mods?.wow?.trip ||
        state.activeShoppingSession || state.errandSession || state.mods?.['village-navigation']?.travel ||
        state.mods?.['village-navigation']?.returnJourney)
      return '진행 중인 사건·장면·여행을 먼저 마쳐 주세요.';
    return null;
  }
  function Companions_만남차단(state, person, kind) {
    const reason = Companions_행동차단(state);
    if (reason) return reason;
    if (!person || person.active === false) return '고용 중인 직원을 선택해 주세요.';
    if (person.site !== Companions_사업장상황(state).active || api.fn('playerLocation')(state) !== person.room || person.room === 'town:transit')
      return person.name+'이(가) 있는 장소로 찾아가 주세요.';
    if (person.readyAt > state.slot || person.interaction || person.npcAI?.pending || person.task === 'sleeping')
      return '진행 중인 업무·이동·수면이 끝나면 대화할 수 있습니다.';
    if (kind && (person.cooldowns[kind] || 0) > state.slot) return '조금 시간을 두고 다시 이야기해 주세요.';
    return null;
  }
  const clone = value => { try { return structuredClone(value); } catch { return JSON.parse(JSON.stringify(value)); } };
  const hireAttributeKeys = hireAttributes.map(([key]) => key);
  const knownLatentTraits = new Set(latentTraitDefs.map(([key]) => key));
  function Companions_성격반영(character, personalityId) {
    const preset = personalityAdjustments[personalityId] || personalityAdjustments.shy;
    const attributes = {...character.attributes};
    for (const [key,value] of Object.entries(preset.attributes || {})) attributes[key] = clamp(value);
    const latentTraits = [...new Set([...(character.latentTraits || []), ...(preset.traits || [])])];
    return {...character, attributes, latentTraits,
      selfConcept:{...character.selfConcept,openness:attributes.openness,confidence:attributes.confidence},
      traitsAtGeneration:{...character.traitsAtGeneration,openness:attributes.openness,confidence:attributes.confidence}};
  }
  function Companions_고용원형(state, options = {}) {
    const gender = options.gender === 'male' ? 'male' : 'female';
    const personality = personalities.find(item => item.id === (options.personality || 'shy')) || personalities[0];
    const profiles = api.fn('wives');
    const archetypeId = gender === 'male' ? 'elena_farmgirl' : (options.archetypeId || 'elena_farmgirl');
    const profile = profiles.find(item => item.id === archetypeId);
    if (!profile) throw Error('선택한 기반 캐릭터의 외형 자료를 찾지 못했습니다.');
    let character = api.fn('companionsCharacter')(profile, {id:'companions_hire_preview',name:String(options.name || '새 동료'),day:state.day,commitment:0});
    if (gender === 'male') character = {...character, latentTraits:[], noticedLatentTraits:[],
      attributes:{...character.attributes,...Object.fromEntries(hireAttributeKeys.map(key => [key,50]))}};
    character = Companions_성격반영({...character,role:'companion',gender,age:25,
      stats:{...character.stats,energy:100,mood:65,arousal:clamp(character.stats?.arousal ?? 0)},
      relationship:{trust:10,patronInteractionsEncouraged:0}},personality.id);
    const baseAttributes = Object.fromEntries(hireAttributeKeys.map(key => [key,clamp(character.attributes?.[key] ?? 50)]));
    const baseTraits = [...new Set(character.latentTraits || [])];
    return {gender,personality:personality.id,archetypeId:gender === 'male' ? null : profile.id,character,baseAttributes,baseTraits};
  }
  function Companions_무작위배분(base, budget) {
    const values = {...base};
    let remaining = Math.max(0, budget-Math.round(hireAttributeKeys.reduce((sum,key)=>sum+values[key],0)));
    const open = hireAttributeKeys.filter(key=>values[key]<100);
    while (remaining>0 && open.length) {
      const index = Math.floor(Math.random()*open.length),key=open[index],gain=Math.min(remaining,100-values[key],1+Math.floor(Math.random()*8));
      values[key]+=gain;remaining-=gain;if(values[key]>=100)open.splice(index,1);
    }
    return values;
  }
  function Companions_고용자료준비(state, options, tier) {
    let template = options.template;
    if (!template || template.gender !== options.gender || template.personality !== options.personality ||
        (options.gender === 'female' && template.archetypeId !== (options.archetypeId || 'elena_farmgirl')))
      template = Companions_고용원형(state,options);
    else template = clone(template);
    const baseAttributes = Object.fromEntries(hireAttributeKeys.map(key=>[key,clamp(template.baseAttributes?.[key] ?? template.character?.attributes?.[key] ?? 50)]));
    const baseTotal = Math.round(hireAttributeKeys.reduce((sum,key)=>sum+baseAttributes[key],0));
    const budget = Math.min(hireAttributeKeys.length*100,Math.round(baseTotal*tier.budgetMultiplier));
    let attributes;
    if(options.mode === 'specified'){
      attributes={};
      for(const key of hireAttributeKeys){const value=Number(options.attributes?.[key]);if(!Number.isFinite(value)||value<0||value>100)throw Error('지정 고용 능력치는 각각 0~100이어야 합니다.');attributes[key]=Math.round(value)}
      if(hireAttributeKeys.reduce((sum,key)=>sum+attributes[key],0)>budget)throw Error('지정 고용 능력치 총점이 등급별 배분 예산을 넘었습니다.');
    }else attributes=Companions_무작위배분(baseAttributes,budget);
    const baseKnown = new Set((template.baseTraits || []).filter(key=>knownLatentTraits.has(key)));
    const selected = options.mode === 'specified' ? new Set((options.latentTraits || []).filter(key=>knownLatentTraits.has(key))) : baseKnown;
    const traitChanges = [...knownLatentTraits].filter(key=>baseKnown.has(key)!==selected.has(key)).length;
    if(traitChanges>tier.traitEdits)throw Error('이 등급에서 바꿀 수 있는 체크형 특성 수를 넘었습니다.');
    const unknown = (template.baseTraits || []).filter(key=>!knownLatentTraits.has(key));
    const character = {...template.character,attributes:{...template.character.attributes,...attributes},latentTraits:[...new Set([...unknown,...selected])],
      selfConcept:{...template.character.selfConcept,openness:attributes.openness,confidence:attributes.confidence},
      traitsAtGeneration:{...template.character.traitsAtGeneration,openness:attributes.openness,confidence:attributes.confidence}};
    return {character,baseAttributes,baseTraits:[...(template.baseTraits || [])],budget,baseTotal,traitChanges};
  }
  function Companions_고용하기(state, action) {
    if(housing)state=housing.prepare(state);
    const reason = Companions_행동차단(state);
    if (reason) return log(state, reason);
    const data = read(state), opts = action.options || action;
    const name = String(opts.name || '').trim();
    const tier = tiers.find(item => item.id === (opts.tier || (opts.gender === 'male' ? 'basic' : 'trainee')));
    const personality = personalities.find(item => item.id === (opts.personality || 'shy'));
    const relationType = opts.relationType || 'employee';
    if (!['step_sibling','childhood_friend','employee'].includes(relationType)) return log(state,'시작 관계를 확인해 주세요.');
    const employed = opts.employed ?? relationType === 'employee';
    if(typeof employed!=='boolean')return log(state,'고용 계약 여부를 확인해 주세요.');
    const wage = tier?.wage;
    if (!['male','female'].includes(opts.gender) || !name || name.length > 32 ||
        !tier || !personality || !Number.isInteger(wage))
      return log(state, '성별·이름(1~32자)·고용 등급·성격을 확인해 주세요.');
    if (list(state).length >= data.policy.maxEmployees) return log(state, '설정한 고용 정원에 도달했습니다.');
    const due=tier.cost+(employed?wage:0);
    if (state.economy.gold < due) return log(state, employed?'소개비와 오늘 일당이 부족합니다.':'소개비가 부족합니다.');
    const site = opts.site || Companions_사업장상황(state).active;
    if(!Companions_사업장상황(state).sites.some(s=>s.id===site))return log(state,'사용할 수 있는 건물을 선택해 주세요.');
    const id = 'companions_'+data.nextId;
    if(employed&&housing){const denied=housing.contractReason(state,{id,site});if(denied)return log(state,denied);}
    const bed=employed&&housing?housing.reserve(state,{id,site},opts.homeRoom):null;
    if(bed?.reason)return log(state,bed.reason);
    let prepared;
    try{prepared=Companions_고용자료준비(state,{...opts,gender:opts.gender,personality:personality.id},tier)}
    catch(error){return log(state,error?.message||'고용 능력치와 특성 설정을 확인해 주세요.');}
    const character={...prepared.character,id,name,gender:opts.gender,role:'companion',age:25};
    const person = {id, name, gender:opts.gender, age:25, active:true, employed, relationType, hiredDay:state.day,
      site, homeRoom:bed?.room||'taproom', housingRoom:bed?.room||null,
      room:site===Companions_사업장상황(state).active?api.fn('playerLocation')(state):bed?.room||'taproom', job:'auto', duty:'hall', tier:tier.id, skill:tier.skill,
      wage, paidDay:employed?state.day:null, enabled:employed, task:'idle', readyAt:state.slot, lastSlot:null,
      energy:100, mood:65, personality:personality.id, character, portrait:'',
      hireAllocation:{mode:opts.mode==='specified'?'specified':'random',baseTotal:prepared.baseTotal,budget:prepared.budget,baseAttributes:prepared.baseAttributes,baseTraits:prepared.baseTraits,traitChanges:prepared.traitChanges},
      relationship:{trust:10, affection:0}, patrons:{}, memories:[], cooldowns:{},
      allowRomance:true, socialEnabled:true, bonds:{}, targetId:null, interaction:null};
    const next = write({...state, economy:{...state.economy, gold:state.economy.gold-due}},
      {...data, nextId:data.nextId+1, people:{...data.people, [id]:person}});
    return log(next, name+'이(가) 동료로 합류했습니다. 소개비 '+tier.cost+'g. '+(employed ? '오늘 일당 '+wage+'g을 지급했습니다.' : '고용 계약은 없으며 일당은 지급하지 않습니다.'), id);
  }
  function Companions_설정하기(state, action) {
    if(housing)state=housing.prepare(state);
    const data = read(state), person = get(state, action.id), patch = action.patch || {};
    if (!person || person.active===false) return log(state, '동료를 선택해 주세요.');
    const reason = Companions_행동차단(state);
    if (reason) return log(state, reason);
    if (person.readyAt > state.slot && (patch.site != null || patch.job != null || patch.duty != null || patch.homeRoom != null))
      return log(state, '진행 중인 업무·대화를 마친 뒤 배치해 주세요.', person.id);
    const allowed = new Set(['name','job','duty','homeRoom','enabled','wage','portrait','allowRomance','site','outfit','relationType','employed','socialEnabled']);
    if (Object.keys(patch).some(key => !allowed.has(key))) return log(state, '지원하지 않는 직원 설정입니다.');
    if (patch.name != null && (typeof patch.name !== 'string' || !patch.name.trim() || patch.name.length > 32) ||
        patch.job != null && !Object.hasOwn(jobs, patch.job) ||
        patch.duty != null && (!dutyDefinitions.has(patch.duty)||dutyDefinitions.get(patch.duty).eligible?.(state,person)===false) ||
        patch.wage != null && (!Number.isInteger(patch.wage) || patch.wage < 0 || patch.wage > 500) ||
        patch.enabled != null && typeof patch.enabled !== 'boolean' ||
        patch.allowRomance != null && typeof patch.allowRomance !== 'boolean' ||
        patch.portrait != null && (typeof patch.portrait !== 'string' || patch.portrait.length > 1500000))
      return log(state, '직원 설정 값이 올바르지 않습니다.');
    const context = Companions_사업장상황(state);
    const aiReason = aiAdapter?.canEdit?.(state, person, patch);
    if (aiReason) return log(state, aiReason, person.id);
    if (patch.site != null && !context.sites.some(site => site.id === patch.site))
      return log(state, '계약한 사업장만 배치할 수 있습니다.');
    if (patch.homeRoom != null &&
        !Companions_방목록(state,patch.site||person.site).some(room => room.id === patch.homeRoom))
      return log(state, '해당 사업장에서 실제로 사용할 수 있는 방을 선택해 주세요.');
    if (patch.relationType != null && !['step_sibling','childhood_friend','employee'].includes(patch.relationType) ||
        patch.employed != null && typeof patch.employed !== 'boolean' ||
        patch.socialEnabled != null && typeof patch.socialEnabled !== 'boolean') return log(state,'관계·고용 설정을 확인해 주세요.');
    if (patch.outfit != null && (
        !api.fn('outfits').some(outfit => outfit.id === patch.outfit))) return log(state, '복장을 확인해 주세요.');
    let nextPerson = {...person, ...patch};
    if (!nextPerson.employed) nextPerson={...nextPerson,enabled:false};
    if (patch.employed === true && !person.employed) nextPerson={...nextPerson,enabled:true,paidDay:null,hiredDay:state.day};
    if (patch.name != null) nextPerson.name = patch.name.trim();
    if (patch.site != null && patch.site !== person.site)
      nextPerson = {...nextPerson, room:'taproom', homeRoom:'taproom', task:'idle', targetId:null};
    const changedHome=patch.homeRoom!=null&&patch.homeRoom!==person.homeRoom;
    const changedSite=nextPerson.site!==person.site;
    if(housing&&nextPerson.employed&&(!person.employed||changedSite)){
      const denied=housing.contractReason(state,nextPerson);if(denied)return log(state,denied,person.id);
    }
    if(housing&&(nextPerson.employed&&!person.employed||changedHome||changedSite&&nextPerson.employed)){
      const preferred=patch.homeRoom??(nextPerson.site===person.site?person.housingRoom:null);
      const bed=housing.reserve(state,nextPerson,preferred);
      if(bed.reason)return log(state,bed.reason,person.id);
      nextPerson={...nextPerson,housingRoom:bed.room,homeRoom:bed.room,housingManual:true,
        ...(nextPerson.site!==person.site?{room:bed.room}:{})};
    }
    if (person.character) nextPerson.character = {...person.character, name:nextPerson.name,
      outfit:patch.outfit || person.character.outfit};
    const managers = {...data.managers},managerRooms={...data.managerRooms};
    if (changedSite && managers[person.site] === person.id){delete managers[person.site];delete managerRooms[person.site];}
    if(changedSite&&!nextPerson.employed&&!changedHome)nextPerson={...nextPerson,housingRoom:null,
      homeRoom:context.sites.find(s=>s.id===nextPerson.site)?.entrance||'taproom',room:context.sites.find(s=>s.id===nextPerson.site)?.entrance||'taproom'};
    return write(state, {...data, managers,managerRooms, people:{...data.people, [person.id]:nextPerson}});
  }
  function Companions_관리자지정(state, action) {
    if(housing)state=housing.prepare(state);
    const reason = Companions_행동차단(state);
    if (reason) return log(state, reason);
    const data = read(state), person = get(state, action.personId||action.id);
    const site=action.site||person?.site;
    const managers = {...data.managers};
    const managerRooms={...data.managerRooms};
    const explicit=action.type==='companions/office-assign';
    if(explicit&&!Companions_사업장상황(state).sites.some(s=>s.id===site))return log(state,'건물을 선택해 주세요.');
    if(explicit&&!action.personId||!explicit&&person&&managers[person.site]===person.id){
      delete managers[site];delete managerRooms[site];
      return log(write(state,{...data,managers,managerRooms}),'매니저 지정을 해제했습니다.');
    }
    if (!person?.employed || !person.enabled || person.site!==site) return log(state, '이 건물에서 근무가 켜진 직원을 선택해 주세요.');
    if(housing&&!housing.valid(state,person))return log(state,'먼저 이 직원에게 고용인의 방을 배정해 주세요.',person.id);
    const room=action.roomId?housing?.info(state,site).offices.find(r=>r.id===action.roomId):housing?.managerRoom(state,person.site);
    if(housing&&!room)return log(state,'이 건물에 매니저실이 있어야 관리를 맡길 수 있습니다.',person.id);
    managers[person.site] = person.id;if(room)managerRooms[person.site]=room.id;
    return log(write(state, {...data, managers,managerRooms}), person.name+'의 매니저 대행 지정을 변경했습니다.', person.id);
  }
  function Companions_매니저상태(state, person) {
    const office=housing?.managerRoom(state,person.site);
    const appointed = read(state).managers[person.site] === person.id&&(!housing||!!office&&housing.valid(state,person));
    const context = Companions_사업장상황(state);
    const away = context.awayBySite?.[person.site] ?? (person.site !== context.active || context.ownerAway);
    return {appointed,office:office?.id||null, acting:appointed && away && person.employed && person.enabled && person.paidDay === state.day};
  }
  function Companions_퇴직하기(state, action) {
    const person = get(state, action.id);
    if (!person?.employed) return state;
    const reason = Companions_행동차단(state);
    if (reason) return log(state, reason);
    const aiReason=aiAdapter?.canDismiss?.(state,person);
    if(aiReason)return log(state,aiReason,person.id);
    if (person.readyAt > state.slot) return log(state, '진행 중인 업무·대화를 먼저 마쳐 주세요.');
    let next = Companions_인물저장(state, {...person, employed:false, enabled:false, retiredDay:state.day, task:'idle'});
    const data = read(next), managers = {...data.managers};
    if (managers[person.site] === person.id) delete managers[person.site];
    return log(write(next, {...data, managers}), person.name+'이(가) 퇴직했습니다. 개인 기록은 남습니다.', person.id);
  }
  function Companions_일당정산(state) {
    let next = state;
    for (const person of list(next)) {
      if (!person.employed || !person.enabled || person.paidDay === state.day) continue;
      if(housing&&!housing.valid(next,person))continue;
      if (next.economy.gold < person.wage) {
        if (person.unpaidDay !== state.day) next = log(Companions_인물저장(next, {...person, unpaidDay:state.day}),
          person.name+'의 일당이 부족해 근무를 보류합니다.', person.id);
        continue;
      }
      next = Companions_인물저장({...next, economy:{...next.economy, gold:next.economy.gold-person.wage}},
        {...person, paidDay:state.day, unpaidDay:null});
      next = log(next, person.name+'에게 일당 '+person.wage+'g를 지급했습니다.', person.id);
    }
    return next;
  }
  function Companions_기억추가(person, state, type, text, partner = 'player') {
    return {...person, memories:[...person.memories, {day:state.day, slot:state.slot, type, partner, text}].slice(-60)};
  }
  function Companions_상호작용(state, action) {
    const person = get(state, action.id), reason = Companions_만남차단(state, person, action.kind);
    if (reason) return log(state, reason, person?.id);
    if (aiAdapter?.controls(state, get(state, action.id))) {
      const result = aiAdapter.interact?.(state, action);
      if (result != null) return result;
    }
    const options = {
      talk:{minutes:3, trust:2, love:1}, praise:{minutes:2, trust:3, love:1},
      gift:{minutes:2, trust:2, love:2, gold:10}, hand:{minutes:2, trust:1, love:2, threshold:25},
      hug:{minutes:3, trust:1, love:3, threshold:40}, confess:{minutes:5, trust:1, love:5, threshold:65}
    };
    const choice = options[action.kind];
    if (!choice) return log(state, '지원하지 않는 대화입니다.');
    if ((choice.gold || 0) > state.economy.gold) return log(state, '선물을 살 금화가 부족합니다.');
    const romance = choice.threshold != null;
    const score = person.relationship.trust+person.relationship.affection;
    const shyPenalty = ['shy','cool','noble'].includes(person.personality) ? 8 : 0;
    const accepted = !romance || person.allowRomance && score >= choice.threshold+shyPenalty && person.mood >= 30;
    const personality = personalities.find(item => item.id === person.personality);
    const reply = person.gender === 'male' ? {talk:'오늘 맡은 일은 잘 진행하고 있습니다.',
      praise:'알아주셔서 감사합니다. 맡은 일에 힘쓰겠습니다.',gift:'선물 감사합니다. 잘 쓰겠습니다.'}[action.kind]
      : accepted ? personality.line : '아직은 그런 관계로 다가가기 어려워요. 천천히 알아가고 싶어요.';
    let updated = {...person, task:'conversation', readyAt:state.slot+choice.minutes,
      interaction:'player', targetId:null, cooldowns:{...person.cooldowns, [action.kind]:state.slot+60},
      relationship:{trust:clamp(person.relationship.trust+(accepted ? choice.trust : -1)),
        affection:clamp(person.relationship.affection+(accepted && person.gender === 'female' ? choice.love : 0))},
      mood:clamp(person.mood+(accepted ? 2 : -2))};
    updated = Companions_기억추가(updated, state, action.kind, reply);
    let next = Companions_인물저장({...state, economy:{...state.economy, gold:state.economy.gold-(choice.gold || 0)}}, updated);
    next = log(next, person.name+': “'+reply+'”', person.id);
    // 세계 시계를 사용해 같은 시간 동안 본편과 다른 직원도 진행합니다. 사건이 생기면 즉시 멈춥니다.
    for (let minute = 0; minute < choice.minutes && !next.pendingEvent && !next.gameOver; minute++)
      next = api.fn('worldTick')(next, {playerPresent:true});
    const latest = get(next, person.id);
    return Companions_인물저장(next, {...latest, interaction:null, readyAt:next.slot, task:'idle'});
  }
  function Companions_방문하기(state, action) {
    const person = get(state, action.id), reason = Companions_행동차단(state);
    if (reason) return log(state, reason);
    if (!person || person.active === false || person.site !== Companions_사업장상황(state).active)
      return log(state, '먼저 직원이 있는 사업장에 방문해 주세요.');
    if (api.fn('playerLocation')(state) === person.room) return state;
    const aiVisit = aiAdapter?.visit?.(state, person);
    if (aiVisit != null) return aiVisit;
    const construction = globalThis.WML.use('construction-tool');
    const built = construction?.getRooms?.(state) || [], current = api.fn('playerLocation')(state);
    const actions = {taproom:'return_to_taproom', kitchen:'go_to_kitchen', back_room:'go_to_back_room',
      bedroom:'go_to_bedroom', upstairs_hall:'go_upstairs', upstairs_room_2:'go_upstairs',
      bathhouse:'enter_bathhouse', bathroom:'enter_bathroom', elena_room:'knock_on_door'};
    const inside = Object.hasOwn(roomNames,current) || built.some(room=>room.id===current&&!room.external);
    if (inside && actions[person.room]) return api.fn('reduceGameAction')(state, {type:actions[person.room],room:person.room});
    if (built.some(room => room.id === person.room && room.built !== false && !room.stored && !room.external && !room.native))
      return api.fn('reduceGameAction')(state, {type:'construction-tool/move',roomId:person.room});
    if (adapter?.visit) return adapter.visit(state, person.room);
    if (!actions[person.room]) return log(state, '마을·건축 지도에서 해당 방으로 이동해 주세요.');
    return api.fn('reduceGameAction')(state, {type:actions[person.room], room:person.room});
  }
  function Companions_편집자료(state) {
    return {version:1,
      schema:{stats:[['energy','기력'],['mood','기분'],['arousal','흥분도']],attributes:hireAttributes,affinities:affinityDefs,traits:latentTraitDefs,personalities:personalities.map(({id,label})=>[id,label])},
      people:list(state).map(person=>({id:person.id,name:person.name,gender:person.gender,personality:person.personality,skill:person.skill,
        stats:{energy:person.energy,mood:person.mood,arousal:person.character?.stats?.arousal??0},attributes:{...person.character?.attributes},
        affinities:{...person.character?.affinities},latentTraits:[...(person.character?.latentTraits||[])]}))};
  }
  function Companions_편집적용(state,id,patch={}) {
    const person=get(state,id);if(!person||person.active===false)throw Error('편집할 동료를 찾지 못했습니다.');
    const numberGroup=(raw,defs,min,max,current)=>{
      if(raw==null)return{...current};const out={...current};
      for(const[key]of defs){if(raw[key]==null)continue;const value=Number(raw[key]);if(!Number.isFinite(value)||value<min||value>max)throw Error(`${key} 값이 ${min}~${max} 범위를 벗어났습니다.`);out[key]=Math.round(value*10)/10}
      return out;
    };
    const stats=numberGroup(patch.stats,[['energy'],['mood'],['arousal']],0,100,{...person.character?.stats,energy:person.energy,mood:person.mood});
    const attributes=numberGroup(patch.attributes,hireAttributes,0,100,person.character?.attributes||{});
    const affinities=numberGroup(patch.affinities,affinityDefs,-2,2,person.character?.affinities||{});
    let latentTraits=[...(person.character?.latentTraits||[])];
    if(patch.latentTraits!=null){if(!Array.isArray(patch.latentTraits))throw Error('숨은 특성 형식이 올바르지 않습니다.');const selected=new Set(patch.latentTraits.filter(key=>knownLatentTraits.has(key))),unknown=latentTraits.filter(key=>!knownLatentTraits.has(key));latentTraits=[...new Set([...unknown,...selected])]}
    const personality=patch.personality==null?person.personality:String(patch.personality);
    if(!personalities.some(item=>item.id===personality))throw Error('성격 선택을 확인해 주세요.');
    const skill=patch.skill==null?person.skill:Number(patch.skill);if(!Number.isFinite(skill)||skill<0||skill>100)throw Error('일솜씨는 0~100이어야 합니다.');
    const updated={...person,personality,skill:Math.round(skill*10)/10,energy:stats.energy,mood:stats.mood,
      character:{...person.character,stats,attributes,affinities,latentTraits,
        selfConcept:{...person.character?.selfConcept,openness:attributes.openness,confidence:attributes.confidence}}};
    return Companions_인물저장(state,updated);
  }
  for (const [type, handler] of Object.entries({hire:Companions_고용하기, edit:Companions_설정하기,
    manager:Companions_관리자지정, 'office-assign':Companions_관리자지정, dismiss:Companions_퇴직하기, interact:Companions_상호작용, visit:Companions_방문하기}))
    api.actions.register(ID+'/'+type, handler);
  api.actions.register(ID+'/policy', (state, action) => {
    if (!Number.isInteger(action.maxEmployees) || action.maxEmployees < 1 || action.maxEmployees > 64)
      return log(state, '고용 정원은 1~64명입니다.');
    if (action.forbidNewLoversWhenPartnered != null && typeof action.forbidNewLoversWhenPartnered !== 'boolean') return log(state,'연애 설정을 확인해 주세요.');
    return write(state, {...read(state), policy:{...read(state).policy, maxEmployees:action.maxEmployees,
      ...(action.forbidNewLoversWhenPartnered == null ? {} : {forbidNewLoversWhenPartnered:action.forbidNewLoversWhenPartnered})}});
  });
  api.hook('wakeUp', {after:Companions_일당정산});
  api.actions.register(ID+'/work-policy',(state,action)=>{
    const patch={};
    for(const [key,min,max]of [['cleanThreshold',0,100],['readyFoodTarget',1,100]])if(Object.hasOwn(action,key)){
      if(!Number.isInteger(action[key])||action[key]<min||action[key]>max)return log(state,'청소·조리 기준은 지정 범위의 정수로 입력해 주세요.');
      patch[key]=action[key];
    }
    if(Object.hasOwn(action,'autoCook')){if(typeof action.autoCook!=='boolean')return log(state,'자동 요리 설정을 확인해 주세요.');patch.autoCook=action.autoCook;}
    return write(state,{...read(state),policy:{...read(state).policy,...patch}});
  });
  return {version:3, read, write, list, get, log, save:Companions_인물저장, clamp, personalities, tiers, jobs, roomNames,workSettings,
    dutyOf,dutyOptions:(s,p)=>[...dutyDefinitions.values()].filter(row=>row.eligible?.(s,p)!==false),
    registerDuty(id,spec){if(dutyDefinitions.has(id)&&!['hall','rooms'].includes(id))throw Error('주요 업무 연결 중복');const row={...dutyDefinitions.get(id),...spec,id};dutyDefinitions.set(id,row);return()=>dutyDefinitions.delete(id);},
    dutyDefinition:id=>dutyDefinitions.get(id),
    hireAttributes,latentTraitDefs,affinityDefs,hireTemplate:Companions_고용원형,editorRead:Companions_편집자료,editorApply:Companions_편집적용,
    aiAdapterVersion:1, getAIAdapter:()=>aiAdapter,
    installAIAdapter(value) {
      if (aiAdapter || typeof value?.controls !== 'function' || typeof value?.tick !== 'function')
        throw Error('고용인 AI 연결은 controls·tick을 제공하고 한 번만 등록해야 합니다.');
      aiAdapter=value;
    },
    context:Companions_사업장상황, rooms:Companions_방목록, blocked:Companions_행동차단, meetingReason:Companions_만남차단,
    managerStatus:Companions_매니저상태, wages:Companions_일당정산, remember:Companions_기억추가,
    installSiteAdapter(value) { if (adapter) throw Error('companions 사업장 연결이 중복되었습니다.'); adapter=value; },
    installHousing(value){housing=value;}};
};
