// 원본 대사·판정·행동은 게임의 순수 함수로 실행합니다. 임시 주인공은 실제 저장에 넣지 않습니다.
// 구 메이드관/arhka 및 urkta의 NPC Simulator 투영 구조를 참고하되 실행 의존성은 없습니다.
globalThis.Companions_원본연결=function(api,people){
  'use strict';
  const copy=value=>value==null?value:JSON.parse(JSON.stringify(value));
  let frame=null;
  const resultObservers=new Map();
  const projectionProviders=new Map();
  people.registerNativeProjection=(owner,handler)=>{if(projectionProviders.has(owner))throw Error('원본 문맥 연결 중복');projectionProviders.set(owner,handler);return()=>projectionProviders.delete(owner);};
  people.registerNativeResult=(owner,handler)=>{if(resultObservers.has(owner))throw Error('원본 결과 연결 중복');resultObservers.set(owner,handler);return()=>resultObservers.delete(owner);};
  // Zustand의 상수 store와 실제 getState는 교체하지 않습니다. 원본 UI가 구독을 만드는 동안만
  // 선택자를 감싸고, 이후의 구독 갱신도 같은 읽기 전용 투영을 사용합니다.
  let display=null;
  const React=api.fn('React'),DisplayContext=React.createContext(null),jsx=api.fn('jsx').jsx;
  function displayRoot(project){const roots=new WeakMap();return root=>{
    if(!roots.has(root))roots.set(root,{...root,...project(root)});
    return roots.get(root);
  };}
  function withDisplay(project,render){const previous=display;display=project;
    try{return jsx(DisplayContext.Provider,{value:project,children:render()});}finally{display=previous;}}
  api.hook('companionsStoreSelector',{around(next,store,selector){
    const inherited=React.useContext(DisplayContext),scope=display||inherited;
    if(!scope||store.getState!==api.fn('store').getState)return next(store,selector);
    return next(store,root=>(selector||((value)=>value))(scope(root)));
  }});
  const mainId=s=>'main:'+s.primaryCharacterId;
  const hasPatron=p=>!!(p?.nativeSession?.scenes?.patron||p?.nativeSession?.pendingForcedPatron);
  const customerIds=p=>{const session=p?.nativeSession,scene=session?.scenes?.patron;return [...new Set([scene?.customerId,...scene?.joinedPatronIds||[],...scene?.crowdPatronIds||[],session?.pendingForcedPatron?.customerId].filter(Boolean))];};
  function customerBusy(s,customerId,except){
    const scene=s.activeScene?.patron;
    return [scene?.customerId,...scene?.joinedPatronIds||[],...scene?.crowdPatronIds||[]].includes(customerId)||
      people.list(s).some(p=>p.id!==except&&(customerIds(p).includes(customerId)||p.life?.pending?.plan?.targetId===customerId));
  }
  api.hook('startPatronInteraction',{before([s,customerId]){
    if(people.list(s).some(p=>p.id!==frame?.personId&&(customerIds(p).includes(customerId)||p.life?.pending?.plan?.targetId===customerId)))return {cancel:true,value:s};
  }});
  function actor(s,id){
    if(id===mainId(s)){const character=api.fn('wife')(s);return {id,name:character.name,gender:character.gender||'female',
      age:character.age||25,character,room:api.fn('wifeLocation')(s),site:people.siteForRoom(s,api.fn('wifeLocation')(s))||people.context(s).origin,
      energy:character.stats.energy,mood:character.stats.mood,allowRomance:true,socialEnabled:true,
      bonds:people.read(s).mainBonds||{},memories:people.read(s).mainMemories||[],
      nativeSession:people.read(s).mainSession||null,interaction:people.read(s).mainInteraction||null,
      life:people.read(s).mainLife||{},readyAt:people.read(s).mainReadyAt||0,main:true};}
    return people.get(s,id);
  }
  function saveActor(s,p){
    if(!p.main)return people.save(s,p);
    const data=people.read(s),next=people.write(s,{...data,mainBonds:p.bonds||{},mainSession:p.nativeSession||null,
      mainReadyAt:p.readyAt||0,mainMemories:p.memories||[],mainInteraction:p.interaction||null,mainLife:p.life||{}});
    return {...next,characters:{...next.characters,[s.primaryCharacterId]:p.character}};
  }
  function relation(s,id,other='player'){
    const p=actor(s,id),stored=p?.bonds?.[other];
    return {trust:other==='player'?(p?.relationship?.trust??p?.character?.relationship?.trust??20):20,
      like:other==='player'?(p?.relationship?.affection??p?.character?.playerFeelings?.like??0):0,
      heart:0,resentment:0,status:null,interactions:0,...stored};
  }
  function setRelation(s,id,other,patch){
    const p=actor(s,id);if(!p)return s;
    const row={...relation(s,id,other),...patch};
    let updated={...p,bonds:{...p.bonds,[other]:row}};
    if(other==='player'&&!p.main)updated={...updated,relationship:{trust:row.trust,affection:row.like}};
    return saveActor(s,updated);
  }
  function partnered(s,id,except){
    if(id==='player')return ['spouse','lover','courting','betrothed'].includes(api.fn('companionsRelationType')(s))||
      people.list(s).some(p=>p.id!==except&&relation(s,p.id,'player').status==='lover');
    const p=actor(s,id);if(!p)return false;
    if(p.main&&except!=='player'&&['spouse','lover','courting','betrothed'].includes(api.fn('companionsRelationType')(s)))return true;
    return Object.entries(p.bonds||{}).some(([other,row])=>other!==except&&['lover','spouse'].includes(row.status));
  }
  function loverReason(s,a,b){
    if(relation(s,a,b).status==='lover')return null;
    return people.read(s).policy.forbidNewLoversWhenPartnered&&(partnered(s,a,b)||partnered(s,b,a))?
      '설정에 따라 기존 연인이 있는 인물과 새 연인 관계를 맺을 수 없습니다.':null;
  }
  function view(s,id,other='player'){
    const p=actor(s,id),nativeId=p.main?s.primaryCharacterId:p.id,row=relation(s,id,other);
    const counterpart=other==='player'?null:actor(s,other);
    const character={...copy(p.character),id:nativeId,name:p.name,
      stats:{...p.character.stats,energy:p.energy,mood:p.mood},
      relationship:{...p.character.relationship,trust:row.trust,resentment:row.resentment},
      playerFeelings:{...p.character.playerFeelings,like:row.like,heart:row.heart}};
    const locations=Object.fromEntries(Object.entries(s.locations).map(([room,value])=>[room,{...value,
      occupants:(value.occupants||[]).filter(key=>!['wife','player',s.primaryCharacterId,p.id,counterpart?.id].includes(key))}]));
    locations[p.room]={...locations[p.room],occupants:[...(locations[p.room]?.occupants||[]),'wife','player']};
    let projected={...s,primaryCharacterId:nativeId,characters:{...s.characters,[nativeId]:character},locations,
      pendingEvent:copy(p.nativeSession?.event),activeScene:copy(p.nativeSession?.scenes)||{},pendingForcedPatron:copy(p.nativeSession?.pendingForcedPatron),
      alertQueue:[],errandSession:undefined,activeShoppingSession:undefined,
      player:counterpart?{...copy(s.player),attributes:copy(counterpart.character.attributes),
        stats:{...s.player.stats,...counterpart.character.stats},climaxSlots:copy(counterpart.character.climaxSlots||[]),name:counterpart.name}:copy(s.player)};
    // Native patron affection belongs to this woman, independently of the main heroine.
    if(!p.main){const records=copy(p.nativePatronRecords||[]),known=new Set(records.map(row=>row.name));
      for(const customer of s.customers||[])if(!known.has(customer.name)){records.push(api.fn('companionsPatronRecord')(customer,s.day));known.add(customer.name);}
      projected={...projected,patronRecords:records};}
    // 실제 배우자 관계를 다른 사람에게 전용하지 않고, 이 두 사람의 관계만 투영합니다.
    const type=row.status==='lover'?'lover':other==='player'?(p.main?api.fn('companionsRelationType')(s):p.relationType):'neighbor';
    const assign=api.fn('companionsAssignRelation');
    // Filtering the projected pair also removes a previous romantic tag after a base-relation edit.
    projected={...projected,relationships:[]};
    projected=assign(projected,{kind:'player'},{kind:'character',id:nativeId},type||'employee');
    for(const handler of projectionProviders.values())projected=handler(projected,{state:s,person:p,other})||projected;
    return projected;
  }
  function run(fn,personId){const previous=frame,current={minutes:0,personId};frame=current;
    try{return {state:fn(),minutes:current.minutes};}finally{frame=previous;}}
  api.hook('worldTick',{priority:100000,before(args){if(frame){frame.minutes++;return {cancel:true,value:args[0]};}}});
  api.hook('companionsSceneAdvance',{priority:100000,before(args){if(frame){frame.minutes++;return {cancel:true,value:args[0]};}}});
  for(const symbol of ['companionsMainTaskTick','companionsMainMoodTick','companionsMainPatronTick','companionsMainAgencyTick','companionsMainEventTick'])
    api.hook(symbol,{priority:100000,before(args){const s=args[0],data=people.read(s);
      if(!frame&&(data.mainInteraction||data.mainSession||data.mainReadyAt>s.slot))return {cancel:true,value:s};
    }});
  api.hook('reduceGameAction',{priority:100000,before(args){const [s,a]=args,data=people.read(s);
    if(!frame&&(data.mainInteraction||data.mainSession)&&['talk_to_wife','wife_topic','scene_action'].includes(a?.type))
      return {cancel:true,value:people.log(s,'메인 캐릭터가 동료와의 만남을 마친 뒤 이야기해 주세요.')};
  }});
  const neutralText=(text,p)=>p.gender==='male'&&typeof text==='string'?text.replaceAll('그녀',p.name):text;
  function eventView(s,id,other='player'){
    const p=actor(s,id),projected=view(s,id,other);
    const event=p.nativeSession?.event||api.fn('companionsNativeMenu')(projected);
    const maleAllowed=new Set(['cat_chat','cat_touch','back','how_was_night','ask_about_her_day','thank_her',
      'share_private_joke','compliment','flirt','tease_her','sit_with_her','hug','hold_hand','brush_hair','rub_shoulders','kiss']);
    return {...event,text:neutralText(event.text,p),choices:(event.choices||[])
      .filter(c=>!['companions_invite','companions_end'].includes(c.id))
      .filter(c=>!c.targetCustomerId||!customerBusy(s,c.targetCustomerId,id))
      .filter(c=>p.gender!=='male'||maleAllowed.has(c.id))
      .map(c=>({...c,label:neutralText(c.label,p),description:neutralText(c.description,p)}))};
  }
  function commit(s,id,other,projected,result){
    const p=actor(s,id),changed=result.characters[projected.primaryCharacterId],before=projected.characters[projected.primaryCharacterId];
    if(!changed)throw Error('원본 행동 결과의 대상 인물이 없습니다.');
    const old=relation(s,id,other),row={...old,trust:changed.relationship?.trust??old.trust,
      like:changed.playerFeelings?.like??old.like,heart:changed.playerFeelings?.heart??old.heart,
      resentment:changed.relationship?.resentment??old.resentment,interactions:old.interactions+1,lastSlot:s.slot};
    // Main-character player feelings and another partner's feelings are separate records.
    const character={...copy(changed),id:p.character.id,
      ...(other!=='player'?{relationship:copy(p.character.relationship),playerFeelings:copy(p.character.playerFeelings)}:{})};
    const scenes=copy(result.activeScene)||{},hasScene=Object.values(scenes).some(Boolean);
    const event=copy(result.pendingEvent),forced=copy(result.pendingForcedPatron),session=hasScene||forced||other==='player'&&(event||p.nativeSession?.resume)?{...p.nativeSession,scenes,event,pendingForcedPatron:forced,partner:other,
      startedAt:p.nativeSession?.startedAt??s.slot}:null;
    const patron=scenes.patron;
    const encountered=new Set([...customerIds(p),patron?.customerId,forced?.customerId].filter(Boolean).map(key=>s.customers.find(c=>c.id===key)?.name));
    let next=saveActor(s,{...p,character,energy:character.stats.energy,mood:character.stats.mood,
      ...(!p.main?{nativePatronRecords:copy(result.patronRecords).map(row=>encountered.has(row.name)?{...row,visitCount:Math.max(1,row.visitCount||0),lastVisitDay:s.day}:row)}:{}),
      nativeSession:session,interaction:hasScene||forced?'native':null,
      ...(patron||forced?{task:'patron',targetId:patron?.customerId||forced.customerId}: {})});
    if(other!=='player'&&!hasScene){const partner=actor(next,other);
      if(partner?.life?.sceneWith===id)next=saveActor(next,{...partner,interaction:null,readyAt:s.slot,life:{...partner.life,sceneWith:null}});
    }
    next=setRelation(next,id,other,row);
    if(api.fn('companionsRelationType')(result)==='lover'&&api.fn('companionsRelationType')(projected)!=='lover'){
      next=setRelation(next,id,other,{...relation(next,id,other),status:'lover'});
      if(other!=='player')next=setRelation(next,other,id,{...relation(next,other,id),status:'lover'});
    }
    const appended=(result.log||[]).slice(projected.log.length).map(entry=>({...copy(entry),
      text:other==='player'?neutralText(entry.text,p):p.name+' · '+actor(s,other).name+': '+neutralText(entry.text,p).replaceAll('당신',actor(s,other).name),
      companionsId:id,eventCategory:'companions'}));
    next={...next,log:[...s.log,...appended]};
    // Only effects owned by this action are committed; projected IDs/locations/mods/clock never escape.
    for(const field of ['supplies','readyFood','ownedOutfits','tavernCleanliness'])
      if(JSON.stringify(result[field])!==JSON.stringify(projected[field]))next={...next,[field]:copy(result[field])};
    const gold=(result.economy?.gold??projected.economy.gold)-projected.economy.gold;
    if(gold)next={...next,economy:{...next.economy,gold:Math.max(0,next.economy.gold+gold)}};
    if(JSON.stringify(result.customers)!==JSON.stringify(projected.customers))next={...next,customers:copy(result.customers)};
    if(other==='player')next={...next,player:copy(result.player)};
    else{const sender=actor(next,other);if(sender){const c={...sender.character,climaxSlots:copy(result.player.climaxSlots||[]),stats:{...sender.character.stats,
      arousal:result.player.stats?.arousal??sender.character.stats.arousal}};next=saveActor(next,{...sender,character:c});}}
    // Scene movement belongs to this subcharacter only.
    const room=api.fn('wifeLocation')(result);
    if(room&&room!==p.room&&!p.main&&people.rooms(s,p.site).some(r=>r.id===room))next=people.save(next,{...people.get(next,id),room});
    // Only the patrons owned by this activity may follow the subcharacter's movement.
    for(const customerId of new Set([...customerIds(p),...customerIds(actor(next,id))])){
      const destination=api.fn('getCustomerLocation')(result,customerId),prior=api.fn('getCustomerLocation')(projected,customerId);
      if(destination&&destination!==prior)next=api.fn('moveOccupant')(next,customerId,destination);
    }
    for(const handler of resultObservers.values())next=handler(next,{id,other,before:projected,after:result,sourceState:s})||next;
    return next;
  }
  function spend(s,minutes){let next=s;
    for(let n=0;n<Math.min(60,minutes)&&!next.pendingEvent&&!next.gameOver;n++){
      const slot=next.slot;next=api.fn('worldTick')(next,{playerPresent:true});if(next.slot<=slot)break;
    }return next;
  }
  function choose(s,id,key,other='player',options={}){
    const p=actor(s,id);if(!p?.character)return s;
    if(!options.autonomous){const denied=people.blocked(s);if(denied)return people.log(s,denied,id);
      if(p.site!==people.context(s).active||p.room!==api.fn('playerLocation')(s))return people.log(s,'같은 장소에서 이야기해 주세요.',id);
      if(p.readyAt>s.slot||p.life?.pending||p.task==='sleeping')return people.log(s,'업무·이동·수면을 마친 뒤 이야기해 주세요.',id);}
    if(key==='ask_be_lovers'){const denied=loverReason(s,id,other);if(denied)return people.log(s,denied,id);}
    const menu=eventView(s,id,other),choice=menu.choices.find(c=>c.id===key&&!c.disabled&&
      (options.targetCustomerId==null||c.targetCustomerId===options.targetCustomerId));
    if(!choice)return people.log(s,'현재 선택할 수 없는 원본 행동입니다.',id);
    const projected=view(s,id,other);projected.pendingEvent=copy(p.nativeSession?.event||menu);
    const result=run(()=>menu.type==='wife_conversation'?api.fn('companionsNativeChoice')(projected,key,choice.targetCustomerId):
      menu.type==='sex_scene'?api.fn('companionsSceneChoice')(projected,key):
      api.fn('reduceGameAction')(projected,{type:'resolve_event',choiceId:key}),id);
    if(menu.type==='wife_conversation'&&(key.startsWith('cat_')||key==='back'||key.startsWith('umbrella_')))
      return saveActor(s,{...p,nativeSession:{...p.nativeSession,event:copy(result.state.pendingEvent),scenes:copy(result.state.activeScene)||{},partner:other,startedAt:p.nativeSession?.startedAt??s.slot}});
    let next=commit(s,id,other,projected,result.state);
    const latest=actor(next,id),minutes=result.minutes;
    if(options.autonomous)return saveActor(next,{...latest,readyAt:s.slot+Math.max(2,minutes)});
    next=saveActor(next,{...latest,interaction:'native-action'});
    next=spend(next,minutes);
    const current=actor(next,id);return saveActor(next,{...current,interaction:current.nativeSession&&Object.values(current.nativeSession.scenes||{}).some(Boolean)?'native':null});
  }
  function dialogueReason(s,p){
    const denied=people.blocked(s);if(denied)return denied;
    if(!p||p.active===false)return '대화할 동료를 선택해 주세요.';
    if(p.site!==people.context(s).active||p.room!==api.fn('playerLocation')(s)||p.room==='town:transit')return '같은 장소에서 이야기해 주세요.';
    if(p.task==='sleeping')return '수면을 마친 뒤 이야기해 주세요.';
    if(hasPatron(p)&&p.nativeSession?.detached)return '손님과의 접객을 마친 뒤 이야기해 주세요.';
    if(p.nativeSession?.partner&&p.nativeSession.partner!=='player'||p.interaction&&!p.nativeSession)
      return '다른 만남을 마친 뒤 이야기해 주세요.';
    return null;
  }
  function open(s,id){const p=actor(s,id),denied=dialogueReason(s,p);
    if(denied)return people.log(s,denied,id);
    if(p.gender==='male')return s;
    if(p.nativeSession)return s;
    const resume={pending:copy(p.life?.pending),remaining:Math.max(0,(p.readyAt||0)-s.slot),task:p.task,pausedAt:s.slot};
    return saveActor(s,{...p,task:'conversation',readyAt:s.slot,life:{...p.life,pending:null},nativeSession:{
      event:api.fn('companionsNativeMenu')(view(s,id)),scenes:{},partner:'player',startedAt:s.slot,resume}});
  }
  function close(s,id,options={}){let p=actor(s,id);if(!p)return s;const partner=p.nativeSession?.partner,resume=p.nativeSession?.resume;
    const patron=p.nativeSession?.scenes?.patron;
    if(hasPatron(p)&&!options.stop&&!p.nativeSession.scenes?.sex&&!patron?.playerEngaged&&patron?.kind!=='husband_led')
      return saveActor(s,{...p,nativeSession:{...p.nativeSession,event:null,detached:true},task:'patron',interaction:'native'});
    if(p.nativeSession?.scenes?.sex){const projected=view(s,id,p.nativeSession.partner),key=p.nativeSession.scenes.sex.finish?'pull_away':'stop';
      const result=run(()=>api.fn('companionsSceneChoice')(projected,key),id);s=commit(s,id,p.nativeSession.partner,projected,result.state);p=actor(s,id);}
    if(hasPatron(p)&&!options.stop)return stopPatron(s,id);
    let next=saveActor(s,{...p,nativeSession:null,interaction:null});
    if(resume&&!p.main){
      const pending=resume.pending,valid=pending?.plan&&p.employed&&p.enabled&&p.paidDay===next.day&&people.workValid(next,p,pending.plan);
      const restored=valid?{...pending,due:next.slot+Math.max(0,pending.due-resume.pausedAt)}:null;
      next=saveActor(next,{...actor(next,id),task:restored?resume.task:'idle',readyAt:restored?restored.due:next.slot,
        life:{...p.life,pending:restored}});
    }
    const other=partner&&partner!=='player'?actor(next,partner):null;
    if(other?.life?.sceneWith===id)next=saveActor(next,{...other,interaction:null,readyAt:next.slot,life:{...other.life,sceneWith:null}});
    return next;
  }
  function stopPatron(s,id){
    const p=actor(s,id);if(!p||!hasPatron(p))return s;
    if(!p.nativeSession.scenes?.patron)return close(saveActor(s,{...p,nativeSession:{...p.nativeSession,pendingForcedPatron:null}}),id,{stop:true});
    const projected=view(s,id),result=run(()=>api.fn('endPatronInteraction')(projected,'elena_refused'),id);
    return close(commit(s,id,'player',projected,result.state),id,{stop:true});
  }
  function patronTick(s,id){
    let p=actor(s,id);if(frame||!p||!hasPatron(p)||s.gameOver||s.pmCore||s.pendingEvent||p.nativeSession.lastPatronSlot===s.slot)return s;
    if(p.nativeSession.scenes?.patron?.playerEngaged||p.nativeSession.scenes?.patron?.kind==='husband_led')return s;
    const ids=customerIds(p),customers=ids.map(key=>s.customers.find(c=>c.id===key));
    if(!customers[0]||['gone','leaving'].includes(customers[0].status)||api.fn('getCustomerLocation')(s,ids[0])!==p.room)return stopPatron(s,id);
    const projected=view(s,id),playerRoom=api.fn('playerLocation')(s);
    projected.pendingEvent=undefined;
    for(const row of Object.values(projected.locations))row.occupants=row.occupants.filter(key=>key!=='player');
    if(projected.locations[playerRoom])projected.locations[playerRoom].occupants.push('player');
    const result=run(()=>{
      let next=projected,forced=next.pendingForcedPatron;
      if(forced&&!next.activeScene?.patron&&s.slot>forced.setAtSlot){next=api.fn('startPatronInteraction')(next,forced.customerId,undefined,forced.openText);next={...next,pendingForcedPatron:undefined};}
      if(next.activeScene?.patron)next=api.fn('processPatronInteractionTick')(next);
      const selfDecision=next.pendingEvent?.choices?.find(choice=>!choice.disabled&&choice.id.endsWith('_she_decides'));
      if(selfDecision)next=api.fn('reduceGameAction')(next,{type:'resolve_event',choiceId:selfDecision.id});
      return next;
    },id);
    let next=commit(s,id,'player',projected,result.state);p=actor(next,id);
    if(!hasPatron(p))return close(next,id,{stop:true});
    return saveActor(next,{...p,nativeSession:{...p.nativeSession,lastPatronSlot:s.slot},readyAt:s.slot,task:'patron',interaction:'native'});
  }
  function passive(s,p){
    if(frame||!p.character)return p;
    let projected=view(s,p.id);for(const name of ['companionsFeelings','companionsAlcohol','companionsThoughts',
      ...(p.gender==='female'?['companionsExposure']:[])])projected=api.fn(name)(projected);
    const character={...projected.characters[p.id],relationship:p.character.relationship,playerFeelings:p.character.playerFeelings};
    return {...p,character,nativePatronRecords:copy(projected.patronRecords),energy:character.stats.energy,mood:character.stats.mood};
  }
  api.actions.register('companions/native-open',(s,a)=>open(s,a.id));
  api.actions.register('companions/native-choice',(s,a)=>choose(s,a.id,a.key,'player',{targetCustomerId:a.targetCustomerId}));
  api.actions.register('companions/native-close',(s,a)=>close(s,a.id));
  api.actions.register('companions/native-stop',(s,a)=>people.blocked(s)?s:stopPatron(s,a.id));
  Object.assign(people,{actor,saveActor,mainId,bond:relation,setBond:setRelation,partnered,loverReason,
    nativeView:view,nativeEvent:eventView,nativeChoose:choose,nativeOpen:open,nativeClose:close,nativePassive:passive,dialogueReason,
    nativeHasPatron:hasPatron,nativeCustomerIds:customerIds,nativePatronTick:patronTick,runNative:run,
    projectionActor:()=>frame?.personId,inProjection:()=>!!frame,displayRoot,withDisplay});
};
