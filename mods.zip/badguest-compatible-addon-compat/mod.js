// BadGuest 원제작자: 민트좋아 / 원글: https://kone.gg/s/somisoft/brKPSnhPt5SpL5XMALc6eb
// addon-compat 원제작자: WML 제작자. 원본 두 모드는 복사하거나 덮어쓰지 않습니다.
WML.define({
  id: 'badguest-compatible-addon-compat',
  name: {ko:'나쁜 손님 · 애드온 호환 패치',en:'BadGuest / Addon compatibility'},
  author: 'Hina_Lover',
  version: "1.0.2",
  game: "2026-11-01",
  lang: 'ko',
  tags: ['content','util'],
  description: '구 공용 API의 방·세션 인자와 나쁜 손님의 손님 기록 인자를 pre7에 연결합니다.',
  requires: ['addon-compat'],
  // 기준: addon-compat 2.3.0 / BadGuest 1.3.7-pre7.1. API/게임으로 확인합니다.
  loadAfter: ['h-status','wife-view-mode'],
  loadBefore: ['badguest'],
  symbols: {
    "compatPrivateRoomOpen": {"raw":{"2026-11-01":"xS"},"doc":"방 ID를 받는 비공개 방 입장 판정"},
    "compatPrivateInfo": {"raw":{"2026-11-01":"Nh"},"doc":"방 메타데이터의 privatePatron 조회"},
    "compatPrivateTick": {"raw":{"2026-11-01":"ZJ"},"doc":"state, room, session으로 개인실 시간 경과 처리"},
    "compatLegacyJi": {"raw":{"2026-11-01":"Ni"},"doc":"레거시 wc/Ji 연결의 현재 바인딩"},
    "compatMistreatment": {"raw":{"2026-11-01":"sl"},"doc":"손님 이름을 받아 부당 대우 기록을 갱신"}
  },
  setup(api) {
    // It must precede BadGuest: its private bridge captures this dispatcher.
    if (!WML.status().order.includes('badguest')) return;
    const bridge=globalThis.__WAYWARD_ADDON_API__,pc=bridge?.patronControl;
    if (!pc) throw Error('addon-compat 공용 연결이 없습니다.');
    let normalized=0;
    api.hook('compatMistreatment',{before([state,patron,...rest]){
      if (patron&&typeof patron==='object'&&typeof patron.name==='string') {
        normalized++;return [state,patron.name,...rest];
      }
    }});
    const sessionOf=(state,room='back_room')=>api.fn('compatPrivateInfo')(state,room)??null;
    pc.backRoomOpen=state=>api.fn('compatPrivateRoomOpen')(state,'back_room');
    pc.bareForPushIn=exposure=>!!(exposure?.skirtUp||exposure?.skirtRemoved)&&!!(exposure?.pantiesRemoved||exposure?.pantiesAside);
    pc.privateSessionInfo=state=>sessionOf(state);
    const frames=[];
    let release=null;
    const legacyTick=state=>{
      const active=frames.at(-1);
      if(active)return active.next(state,active.room,active.session);
      const session=sessionOf(state);return session?api.fn('compatPrivateTick')(state,'back_room',session):state;
    };
    Object.defineProperty(pc,'privateSession',{
      configurable:true,enumerable:true,get:()=>legacyTick,
      set(replacement){
        if(typeof replacement!=='function')return;
        release?.();release=null;
        if(replacement===legacyTick)return;
        release=api.hook('compatPrivateTick',{around(next,state,room,session){
          if(room!=='back_room')return next(state,room,session);
          frames.push({next,room,session});
          try{return replacement(state)}finally{frames.pop()}
        }});
      },
    });
    Object.defineProperty(bridge,'Ji',{configurable:true,enumerable:true,get:()=>api.fn('compatLegacyJi')});
    api.provide({version:1,normalizations:()=>normalized});
    api.report?.('pre7 공용 연결을 보정했습니다.',{bridge:'addon-compat',recordArgument:'patron name'});
  },
});
