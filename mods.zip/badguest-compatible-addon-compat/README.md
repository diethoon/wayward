<!-- STABLE_PORT -->
## 2026-11-01 정식판 이식

모드 버전 **1.0.2**, 대상 게임 **2026-11-01**, WML **0.9.5**입니다. MCP 0.6.2로 연결을 검사합니다. 새 게임을 기준으로 하며 pre7 및 기존 저장 이전은 지원 범위에 포함하지 않습니다.

배포 파일: `badguest-compatible-addon-compat-1.0.2-20261101.zip`. 압축의 폴더 이름과 설치 ID는 `badguest-compatible-addon-compat`이며 `wml/mods/badguest-compatible-addon-compat/mod.js`로 설치합니다. WML 모드 관리자에서 ZIP 설치도 가능합니다. 아래의 pre7 버전·ZIP 안내는 이전 변경 기록입니다.
<!-- /STABLE_PORT -->

# 나쁜 손님 · 애드온 호환 패치 1.0.1

## [pre7 배포 · 버전 분리]

현재 모드 버전: 1.0.1. 대상 게임: 2026-10-24-pre7. 이전 모드 버전: 1.0.0.
배포 파일: badguest-compatible-addon-compat-1.0.1-pre7.zip
압축 내부 최상위 폴더와 로딩 ID는 항상 `badguest-compatible-addon-compat`이며 버전·pre 표기를 붙이지 않습니다. 폴더 복사 설치 경로는 `wml/mods/badguest-compatible-addon-compat/mod.js`입니다. ZIP 설치는 WML 모드 관리자를 사용하세요. 모드의 version은 숫자 버전, game은 대상 게임 식별자로 분리했습니다. 업데이트 인식을 위해 모드 버전의 마지막 숫자를 올렸으며 게임 동작은 이번 변경에서 수정하지 않았습니다. 이전 ZIP과 과거 변경 기록은 보존합니다.


BadGuest 원제작자: 민트좋아 — [원글](https://kone.gg/s/somisoft/brKPSnhPt5SpL5XMALc6eb). addon-compat 원본은 WML 제작자 배포본입니다. 호환 보완: Hina_Lover.

기준 게임: 2026-10-24-pre7 / WML 0.9.4. 확인 기준: addon-compat 2.3.0, badguest 1.3.7-pre7.1. 버전 번호로 다른 호환 조합을 임의 차단하지 않으며 실제 게임 바인딩과 공용 API를 사용합니다.

- addon-compat 다음, badguest 준비 이전에 로드해야 합니다. BadGuest가 준비할 때 손님 기록 함수 참조를 보관하므로 뒤에서 켜면 늦습니다.
- BadGuest의 손님 객체 인자를 pre7의 이름 인자로 변환해 부당 대우 기록이 누락되지 않게 합니다. 기본 게임이 이미 이름을 넘기는 호출은 그대로 유지합니다.
- 공용 backRoomOpen, bareForPushIn, privateSession, privateSessionInfo, Ji 연결을 보완합니다. 개인실 처리에는 방 ID/세션을 넘기고, 세션이 없으면 상태를 그대로 돌려줍니다. 다른 방의 개인실 진행은 변경하지 않습니다.
- badguest가 꺼져 있으면 준비 작업을 건너뜁니다. addon-compat 원본·게임/로더·기존 저장 키를 수정하지 않습니다.

이 폴더의 ZIP을 설치하거나 `wml/mods/badguest-compatible-addon-compat`에 이 폴더를 넣고 등록합니다. addon-compat, 이 패치, badguest를 함께 켜고 새로고침하세요. 모드 관리자에 별도 설정은 없습니다.

설정/코어 기능을 바꾸는 패치가 아닙니다. 실제 GPU/사용자 저장·실기 모바일 앱 검증과 격리 Chromium 검사는 구분합니다. 전체 구현·검사 결과는 작업 폴더 version_up_ready2의 후속 결과 문서를 참고하세요.
