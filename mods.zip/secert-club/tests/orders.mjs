// 실행: node --import ./wml/mods/brothel/tests/mcp-runtime.mjs wml/mods/secert-club/tests/orders.mjs [--zip] [--brothel]
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { checkMod } from '../../../../MCP/lib/check.mjs';
import { modSymbolsCheck } from '../../../../MCP/lib/modsym.mjs';
import { playStart, playEval, playReload, playStatus, shutdown } from '../../../../MCP/lib/play.mjs';

const packaged = process.argv.includes('--zip'), brothel = process.argv.includes('--brothel');
const id = 'secert-club-orders';
const mods = Object.fromEntries(fs.readdirSync(new URL('../../', import.meta.url), { withFileTypes: true }).filter(entry => entry.isDirectory()).map(entry => [entry.name, false]));
Object.assign(mods, { 'addon-compat': true, waitress: true, 'secert-club': true, brothel, 'secert-club-compatible-brothel': brothel });
const evaluate = async code => (await playEval({ id, code, timeoutMs: 45000 })).result;

try {
  const check = checkMod('secert-club');
  assert.ok(check.ok, JSON.stringify(check.errors));
  assert.ok(!modSymbolsCheck('secert-club').includes('✗'));
  await playStart({ id, mods });
  await evaluate(`
    localStorage.setItem('wml.folders',JSON.stringify(['secert-club','secert-club-compatible-brothel']));
    const day=WML.dev().store.game().day;
    localStorage.setItem('wayward-simple-waitress-2026-09-30-v1',JSON.stringify({hired:true,name:'주문 시험 메이드',activeDay:day,lastPaidDay:day,lastAttemptDay:day,lastSeenDay:day,autoCook:false,cleanThreshold:0}));
    return true;
  `);
  if (packaged) await evaluate(`return WML.install([{path:'secert-club-1.2.0.zip',blob:await(await fetch('wml/mods/secert-club/secert-club-1.2.0.zip')).blob()}]);`);
  const loaded = await playReload({ id });
  assert.deepEqual(loaded.failed, []);
  assert.ok(loaded.loaded.includes('secert-club'));
  assert.ok(loaded.loaded.includes('waitress'));
  if (brothel) assert.ok(loaded.loaded.includes('secert-club-compatible-brothel'));
  await evaluate(`
    globalThis.clubTest={api:WML.dev(),symbols:WML.status().modSymbols['secert-club'],roll:1,calls:0};
    const test=clubTest;
    test.fn=name=>test.api.fn(test.symbols[name]||name);
    test.originalChance=test.fn('clubReorderChance')({servedQuality:65});
    test.api.hook(test.symbols.clubReorderChance,{around(){test.calls++;return test.roll;}});
    test.guest=(patch={})=>({id:'club-order-1138',name:'시험 단골',status:'drinking',intent:'interested',stayTimer:1,
      roundsOrdered:1,maxRounds:99,walletGold:100,patience:999,maxPatience:999,boldness:1,charm:50,
      mood:'pleased',patronType:'regular',servedQuality:65,arrivedAtSlot:1020,tab:0,secertClubOrderVersion:1,...patch});
    test.fixture=(room='taproom',patch={})=>{
      const state=structuredClone(test.api.store.game()),customer=test.guest(patch);
      state.slot=1020;state.phase='service';state.pendingEvent=null;state.gameOver=false;
      state.tavern={...state.tavern,backRoomReady:true,hasRoom:true,hasRoom2:true,hasBathhouse:true,tonightRenter:null,tonightRenter2:null};
      state.supplies={beer:100,wine:100,food:100};state.readyFood=100;state.tavernCleanliness=100;
      state.customers=[customer];state.log=[];state.activeScene={};
      state.mods={...state.mods,'secert-club':{active:{day:state.day,venue:room,participants:'wife',guestIds:[customer.id],ejected:[],openedAtSlot:1020,notorietyCeiling:state.tavernReputation.notoriety||0}}};
      for(const location of Object.values(state.locations))location.occupants=[];
      state.locations[room].occupants=[customer.id];
      state.locations.taproom.occupants.push(test.api.fn('playerId'),test.api.fn('wifeId'));
      const wife=state.characters[state.primaryCharacterId];
      Object.assign(wife,{currentTask:'idle',taskTarget:undefined,busyUntilSlot:0,locationUntilSlot:undefined,retiredAtSlot:undefined});
      return state;
    };
    test.advance=state=>test.fn('clubCustomerTick')({...state,slot:state.slot+1});
    test.customer=state=>state.customers.find(customer=>customer.id==='club-order-1138');
    return {chance:test.originalChance,working:__waywardSimpleWaitressPublic.getConfig()};
  `);
  const clock = await evaluate(`
    const test=clubTest;test.roll=1;test.calls=0;
    const low=test.advance(test.fixture('taproom',{stayTimer:119}));
    const requested=test.advance(test.fixture());
    const waiting=test.advance({...requested,customers:requested.customers.map(customer=>({...customer,patience:80}))});
    const ordered=test.advance(test.fixture('taproom',{status:'ordered',order:'wine',patience:80,stayTimer:0}));
    test.roll=0;test.calls=0;let retry=test.advance(test.fixture());const initial=test.customer(retry).stayTimer;
    for(let minute=0;minute<119;minute++)retry=test.advance(retry);
    const before={timer:test.customer(retry).stayTimer,calls:test.calls};
    test.roll=1;retry=test.advance(retry);
    const unregistered=test.fixture('taproom',{stayTimer:999});delete unregistered.customers[0].secertClubOrderVersion;
    const migrated=test.advance(unregistered);
    return {chance:test.originalChance,low:test.customer(low).stayTimer,request:test.customer(requested).status,
      waiting:test.customer(waiting),ordered:test.customer(ordered),initial,before,after:test.customer(retry),calls:test.calls,
      migrated:test.customer(migrated).stayTimer};
  `);
  assert.equal(clock.chance, 0.75);
  assert.equal(clock.low, 118);
  assert.equal(clock.request, 'wants_more');
  assert.equal(clock.waiting.status, 'wants_more');
  assert.equal(clock.waiting.patience, 79);
  assert.equal(clock.ordered.status, 'ordered');
  assert.equal(clock.ordered.order, 'wine');
  assert.equal(clock.initial, 120);
  assert.deepEqual(clock.before, { timer: 1, calls: 1 });
  assert.equal(clock.after.status, 'wants_more');
  assert.equal(clock.calls, 2);
  assert.ok(clock.migrated >= 19 && clock.migrated <= 58);
  console.log('PASS normal countdown, unchanged 75% chance, pending orders, exact 120-minute retry and old-save migration');

  const departures = await evaluate(`
    const test=clubTest;test.roll=1;
    const gone=test.advance(test.fixture('taproom',{status:'gone'}));
    const leaving=test.advance(test.fixture('taproom',{status:'leaving'}));
    const broke=test.advance(test.fixture('taproom',{walletGold:2}));
    let ejected=test.fixture();ejected.mods['secert-club'].active.ejected=['club-order-1138'];
    ejected.customers[0].status='leaving';ejected=test.advance(ejected);
    let empty=test.fixture('taproom',{intent:'drink_only'});empty.supplies={beer:0,wine:0,food:0};empty.readyFood=0;empty=test.advance(empty);
    const waitingLost=test.advance(test.fixture('taproom',{status:'wants_more',patience:1,stayTimer:0}));
    const closed=test.fixture();closed.mods['secert-club'].active=null;closed.customers[0].stayTimer=119;
    const normal=test.advance(closed);
    const interrupted=test.fixture();interrupted.activeScene={bathhouse:{customerId:'club-order-1138'}};
    const busy=test.advance(interrupted);
    const away=test.fn('clubAwayCustomerTick')(test.fixture());
    const kicked=test.api.fn('ejectCustomer')(test.fixture(),'club-order-1138');
    const kickedLater=test.advance(kicked);
    test.roll=0;const drinkOnly=test.advance(test.fixture('taproom',{intent:'drink_only'}));
    return {gone:test.customer(gone)?.status||'removed',leaving:test.customer(leaving)?.status||'removed',
      broke:test.customer(broke)?.status,ejected:test.customer(ejected)?.status||'removed',empty:test.customer(empty)?.status||'removed',
      waitingLost:test.customer(waitingLost)?.status||'removed',normal:test.customer(normal).stayTimer,
      busy:test.customer(busy).stayTimer,away:test.customer(away)?.status,
      kicked:test.customer(kickedLater)?.status||'removed',drinkOnly:test.customer(drinkOnly).stayTimer};
  `);
  assert.ok(['removed', 'gone'].includes(departures.gone));
  assert.ok(['removed', 'gone'].includes(departures.leaving));
  assert.equal(departures.broke, 'leaving');
  assert.ok(['removed', 'gone'].includes(departures.ejected));
  assert.ok(['removed', 'gone', 'leaving'].includes(departures.empty));
  assert.ok(['removed', 'gone', 'leaving'].includes(departures.waitingLost));
  assert.equal(departures.normal, 118);
  assert.equal(departures.busy, 1);
  assert.equal(departures.away, 'wants_more');
  assert.ok(['removed', 'gone', 'leaving'].includes(departures.kicked));
  assert.equal(departures.drinkOnly, 120);
  console.log('PASS no resurrection after ejection, departure, insufficient funds or ignored order; paused scenes and away-player ordering');

  const rooms = await evaluate(`
    const test=clubTest,rows=[];test.roll=1;
    for(const room of ['taproom','back_room','upstairs_hall','upstairs_room_2','bathhouse']){
      let state=test.advance(test.fixture(room));
      const player=test.api.fn('playerId');state=test.api.fn('moveOccupant')(state,player,room);
      state=test.fn('clubPlayerOrder')(state,'club-order-1138');
      const ordered=test.customer(state).status,order=test.customer(state).order;
      const before=state.supplies.beer+state.supplies.wine+state.readyFood;
      const originalRandom=Math.random;Math.random=()=>0.999;
      try{state=test.fn('clubPlayerServe')(state,'club-order-1138');}finally{Math.random=originalRandom;}
      rows.push({room,ordered,order,status:test.customer(state).status,servedBy:test.customer(state).servedBy,
        customerRoom:test.api.fn('getCustomerLocation')(state,'club-order-1138'),
        playerRoom:test.api.fn('locationOf')(state,player),consumed:before-(state.supplies.beer+state.supplies.wine+state.readyFood)});
    }
    return rows;
  `);
  for (const room of rooms) {
    assert.equal(room.ordered, 'ordered', JSON.stringify(room));
    assert.equal(room.status, 'drinking', JSON.stringify(room));
    assert.equal(room.servedBy, 'player');
    assert.equal(room.customerRoom, room.room);
    assert.equal(room.playerRoom, room.room);
    assert.ok(room.consumed > 0);
  }
  console.log('PASS player orders and serving in all five venues with real inventory use and stable locations');

  const wife = await evaluate(`
    const test=clubTest,rows=[];
    for(const room of ['taproom','back_room','upstairs_hall','upstairs_room_2','bathhouse']){
      let state=test.fixture(room,{status:'wants_more',stayTimer:0});
      state=test.api.fn('moveOccupant')(state,test.api.fn('wifeId'),room);
      state=test.fn('clubWifeChooseTask')(state);
      const ordered=test.customer(state).status;
      state={...state,slot:state.slot+10};
      const originalRandom=Math.random;Math.random=()=>0.999;
      try{state=test.fn('clubWifeChooseTask')(state);}finally{Math.random=originalRandom;}
      const served=test.customer(state).status;
      state={...state,slot:state.slot+10};
      state=test.fn('clubWifeChooseTask')(state);
      rows.push({room,ordered,served,servedBy:test.customer(state).servedBy,
        wifeRoom:test.api.fn('wifeLocation')(state),customerRoom:test.api.fn('getCustomerLocation')(state,'club-order-1138')});
    }
    return rows;
  `);
  for (const room of wife) {
    assert.equal(room.ordered, 'ordered', JSON.stringify(room));
    assert.equal(room.served, 'drinking', JSON.stringify(room));
    assert.equal(room.servedBy, 'wife');
    assert.equal(room.wifeRoom, room.room);
    assert.equal(room.customerRoom, room.room);
  }
  console.log('PASS wife orders, serves and waits in every club venue without returning to the hall between rounds');

  const limits = await evaluate(`
    const test=clubTest;
    let remote=test.fixture('back_room',{status:'wants_more',stayTimer:0});
    remote=test.fn('clubPlayerOrder')(remote,'club-order-1138');
    let closed=test.fixture('back_room',{status:'wants_more',stayTimer:0});
    closed=test.api.fn('moveOccupant')(closed,test.api.fn('playerId'),'back_room');closed.mods['secert-club'].active=null;
    closed=test.fn('clubPlayerOrder')(closed,'club-order-1138');
    let outsider=test.fixture('back_room',{status:'wants_more',stayTimer:0});
    outsider=test.api.fn('moveOccupant')(outsider,test.api.fn('playerId'),'back_room');outsider.mods['secert-club'].active.guestIds=[];
    outsider=test.fn('clubPlayerOrder')(outsider,'club-order-1138');
    const original=test.fixture('taproom',{status:'wants_more',stayTimer:0});original.mods['secert-club'].active=null;
    const hall=test.fn('clubPlayerOrder')(original,'club-order-1138');
    return {remote:test.customer(remote).status,closed:test.customer(closed).status,outsider:test.customer(outsider).status,hall:test.customer(hall).status};
  `);
  assert.deepEqual(limits, { remote: 'wants_more', closed: 'wants_more', outsider: 'wants_more', hall: 'ordered' });
  console.log('PASS same-room player requirement and ordinary-service restrictions outside an active club');

  const waitress = await evaluate(`
    const test=clubTest,rows=[];test.roll=1;
    let slot=1100;
    for(const room of ['back_room','upstairs_hall','upstairs_room_2','bathhouse']){
      let state=test.fixture(room,{status:'wants_more',stayTimer:0});state.slot=slot;state.activeScene={};
      const originalLocations=Object.fromEntries(['club-order-1138',test.api.fn('playerId'),test.api.fn('wifeId')].map(id=>[id,test.api.fn('locationOf')(state,id)]));
      state=test.api.fn('minuteTick')(state);
      const ordered=test.customer(state).status;
      for(let minute=0;minute<4;minute++)state=test.api.fn('minuteTick')(state);
      rows.push({room,ordered,status:test.customer(state).status,servedBy:test.customer(state).servedBy,
        quality:test.customer(state).servedQuality,stableLocations:Object.entries(originalLocations).every(([id,room])=>test.api.fn('locationOf')(state,id)===room),
        rounds:test.customer(state).roundsOrdered,runtime:__waywardSimpleWaitressPublic.getRuntime()});
      slot+=20;
    }
    let closed=test.fixture('back_room',{status:'wants_more',stayTimer:0});closed.slot=slot;closed.mods['secert-club'].active=null;
    closed=test.api.fn('minuteTick')(closed);
    let outsider=test.fixture('back_room',{status:'wants_more',stayTimer:0});outsider.slot=slot+20;outsider.mods['secert-club'].active.guestIds=[];
    outsider=test.api.fn('minuteTick')(outsider);
    return {rows,closed:test.customer(closed).status,outsider:test.customer(outsider).status};
  `);
  for (const room of waitress.rows) {
    assert.equal(room.ordered, 'ordered', JSON.stringify(room));
    assert.equal(room.status, 'drinking', JSON.stringify(room));
    assert.equal(room.servedBy, 'simple_waitress');
    assert.equal(room.quality, 65);
    assert.equal(room.stableLocations, true, JSON.stringify(room));
    assert.equal(room.rounds, 2);
  }
  assert.equal(waitress.closed, 'wants_more');
  assert.equal(waitress.outsider, 'wants_more');
  console.log('PASS shared waitress job clock, all four remote venues, club-only access and no fake location persistence');

  const opening = await evaluate(`
    const test=clubTest,club=test.api.use('secert-club');test.roll=1;
    let state=test.fixture('back_room');state.customers=[];
    state.patronRecords=[{name:'신규 초대 손님',intent:'interested',boldness:1,charm:50,attributes:{openness:50}}];
    state.mods['secert-club']={active:null,prepared:{day:state.day,venue:'back_room',participants:'wife',approved:[{name:'신규 초대 손님'}]}};
    state=club.openClub(state);const guestId=state.customers[0].id;
    const initial={status:state.customers[0].status,rounds:state.customers[0].roundsOrdered,timer:state.customers[0].stayTimer,tab:state.customers[0].tab};
    state=test.fn('clubWifeChooseTask')(state);const firstOrder=state.customers[0].roundsOrdered;
    state={...state,slot:state.slot+10};const originalRandom=Math.random;Math.random=()=>0.999;
    try{state=test.fn('clubWifeChooseTask')(state);}finally{Math.random=originalRandom;}
    const firstTab=state.customers[0].tab;
    state={...state,slot:state.slot+10};state=test.fn('clubWifeChooseTask')(state);
    state={...state,customers:state.customers.map(customer=>({...customer,stayTimer:1}))};
    state=test.advance(state);state=test.fn('clubWifeChooseTask')(state);
    const secondOrder=state.customers.find(customer=>customer.id===guestId).roundsOrdered;
    const beforeTick=state.slot;let seed=1138;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
    try{for(let step=0;step<12;step++)state=test.api.fn('worldTick')(state,{playerPresent:true});}finally{Math.random=originalRandom;}
    return {initial,firstOrder,firstTab,secondOrder,venue:club.readData(state).active?.venue,worldMinutes:state.slot-beforeTick};
  `);
  assert.equal(opening.initial.status, 'greeted');
  assert.equal(opening.initial.rounds, 0);
  assert.equal(opening.initial.tab, 0);
  assert.ok(opening.initial.timer >= 20 && opening.initial.timer <= 59);
  assert.equal(opening.firstOrder, 1);
  assert.ok(opening.firstTab > 0);
  assert.equal(opening.secondOrder, 2, JSON.stringify(opening));
  assert.equal(opening.venue, 'back_room');
  assert.ok(opening.worldMinutes > 0, JSON.stringify(opening));
  console.log('PASS real club opening, first paid order, a second order and full world ticks in the chosen remote venue');
  const status = await playStatus({ id });
  assert.deepEqual(status.pageErrors, []);
  console.log(JSON.stringify({ packaged, brothel, clock: { retry: clock.initial, chance: clock.chance }, departures, rooms: rooms.length, wifeRooms: wife.length, waitressRooms: waitress.rows.length }));
} finally { await shutdown(); }
