// 실행: node --import ./wml/mods/brothel/tests/mcp-runtime.mjs ./wml/mods/secert-club/tests/settings-ui.mjs
// MCP의 격리 브라우저에서 요청된 네 모드를 함께 확인합니다. 사용자 저장과 공통 파일은 수정하지 않습니다.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { playStart, playEval, playReload, playStatus, playStop, playScreenshot } from '../../../../MCP/lib/play.mjs';
import { checkMod } from '../../../../MCP/lib/check.mjs';
const ids = ['secert-club', 'secert-club-compatible-brothel', 'endings', 'kknd-hotkeys'];
const evaluate = async code => (await playEval({ code })).result;
const openSettings = `globalThis.openTestSettings = id => {
  WML.openManager();
  const names = {'secert-club':'Secert Club · 비밀 클럽', endings:'엔딩 설정', 'kknd-hotkeys':'단축키 (MOD판)'};
  const row = [...document.querySelectorAll('tr')].find(r => r.textContent.includes(names[id]));
  [...row.querySelectorAll('button')].find(b => b.textContent === '⚙').click();
  const win = [...document.querySelectorAll('.wml-win')].find(w => w.getAttribute('aria-label') === names[id]+' 설정');
  if (!win) throw Error('설정창 없음: '+id);
  return win;
}; return true;`;
async function start(compatibility) {
  await playStart({ mods: { imagestudio: false, 'sound-mod': false, 'secert-club': true, 'secert-club-compatible-brothel': compatibility } });
  await evaluate(`localStorage.setItem('wml.folders',JSON.stringify(['secert-club','secert-club-compatible-brothel'])); return true;`);
  const status = await playReload({});
  assert.deepEqual(status.failed, []);
  assert.ok(status.loaded.includes('secert-club'));
  await evaluate(`
    for(let step=0;step<35;step++){
      if(document.querySelector('button[title="메뉴"]'))return true;
      const buttons=[...document.querySelectorAll('button')].filter(b=>b.offsetParent&&!b.disabled);
      const button=buttons.find(b=>/^(예$|이해하고 동의합니다$|새 게임$|계속하기 —|시작 —|시작하기$|건너뛰기$)/.test(b.innerText.trim()))||buttons.find(b=>b.innerText.trim().startsWith('마라'));
      if(!button)throw Error('새 게임 진행 버튼 없음: '+buttons.map(b=>b.innerText).join('|'));
      button.click();await new Promise(r=>setTimeout(r,150));
    }throw Error('새 게임 시작 시간 초과');
  `);
  await evaluate(openSettings);
}
try {
  for (const id of ids) {
    const check = checkMod(id);
    console.log('CHECK', id, JSON.stringify({ok:check.ok,errors:check.errors,warnings:check.warnings}));
    assert.ok(check.ok, id);
  }
  await start(false);
  const inactive = await evaluate(`
    const win=openTestSettings('secert-club'), section=win.querySelector('[data-secert-club-brothel-settings]');
    return {disabled:section.disabled, blocked:section.querySelector('input').matches(':disabled'), entries:WML.status().pauseMenu.entries};
  `);
  assert.equal(inactive.disabled, true);
  assert.equal(inactive.blocked, true);
  assert.ok(!inactive.entries.includes('secert-club-compatible-brothel'));
  console.log('PASS compatibility settings disabled when adapter is off');
  await playStop();

  await start(true);
  const active = await evaluate(`
    document.querySelector('button[title="메뉴"]').click(); await new Promise(r=>setTimeout(r,200));
    const entry=[...document.querySelectorAll('.wml-dock button')].find(button=>button.textContent==='비밀 클럽');
    if(!entry)throw Error('WML 비밀 클럽 버튼 없음'); entry.click();
    const win=document.querySelector('.wml-win[data-secert-club-settings]'), section=win.querySelector('[data-secert-club-brothel-settings]');
    const input=section.querySelector('input'); input.scrollIntoView({block:'center'}); input.value='3.5'; input.dispatchEvent(new Event('change',{bubbles:true}));
    const rect=input.getBoundingClientRect(), top=document.elementFromPoint(rect.x+rect.width/2,rect.y+rect.height/2);
    return {disabled:section.disabled, saved:JSON.parse(localStorage.getItem('wml.mod.secert-club-compatible-brothel')).serviceFeeMultiplier,
      top:win.contains(top), z:getComputedStyle(win).zIndex, entries:WML.status().pauseMenu.entries};
  `);
  assert.equal(active.disabled, false);
  assert.equal(active.saved, 3.5);
  assert.equal(active.top, true, JSON.stringify(active));
  assert.ok(!active.entries.includes('secert-club-compatible-brothel'));
  assert.ok(active.entries.includes('endings'));
  console.log('PASS integrated compatibility settings, persistence, and hit testing above pause menu');
  fs.writeFileSync(new URL('./club-settings.jpg', import.meta.url), Buffer.from(await playScreenshot({}), 'base64'));

  const toggles = await evaluate(`
    document.querySelector('.wml-win[data-secert-club-settings] .wml-win-close').click();
    const win=openTestSettings('endings');
    document.querySelector('button[title="엔딩 조건"]').click();
    const keys=['rich','ntr','collector','notoriety'];
    const results=[];
    for(const key of keys){
      const buttons=[...document.querySelectorAll('[data-wml-ending-toggle="'+key+'"]')];
      buttons[0].click();
      results.push({key,off:buttons.every(b=>b.textContent==='Off'&&b.getAttribute('aria-checked')==='false'),saved:JSON.parse(localStorage.getItem('wml.mod.endings'))[key]});
    }
    return results;
  `);
  assert.equal(toggles.length, 4);
  for (const result of toggles) { assert.equal(result.off, true); assert.equal(result.saved, false); }
  console.log('PASS all four ending switches save Off and synchronize between settings and status');
  const fixture = `
    globalThis.testEndingConditions = () => {
      const d=WML.dev(), symbols=WML.status().modSymbols.endings||{};
      const fn=name=>d.fn(symbols[name]||name);
      const after=name=>[...d.hooks.values()].flatMap(h=>h.after).find(e=>e.owner==='endings'&&e.where==='after:'+name).fn;
      const fresh=()=>structuredClone(d.store.game());
      let rich=fresh();
      rich.economy={...rich.economy,gold:1000000,debt:0};
      rich.tavern={...rich.tavern,backRoomReady:true,hasRoom:true,hasRoom2:true,hasBathhouse:true,
        qualityUpgrades:fn('qualityUpgrades').map(x=>x.id)};
      rich.stillroom={...rich.stillroom,storage:fn('storageUpgrades').map(x=>x.id)};
      rich=fn('updateWife')(rich,w=>({...w,feelings:[],leavingState:undefined,relationship:{...w.relationship,trust:100}}));
      let ntr=fresh();
      ntr.mods={...ntr.mods,endings:{destination:'테스트 손님'}};
      ntr=fn('updateWife')(ntr,w=>({...w,leavingState:{leavingOnDay:ntr.day,startedDay:ntr.day-3},relationship:{...w.relationship,trust:0}}));
      const collector=fresh();collector.economy.collectorStallStreak=8;
      const notoriety=fresh();notoriety.tavernReputation={...notoriety.tavernReputation,notoriety:100};
      const results={rich:after('wakeUp')(rich)||rich,ntr:after('wakeUp')(ntr)||ntr,
        collector:after('collectorStallUp')(collector)||collector,
        notoriety:after('reduceGameAction')(notoriety,[notoriety,{type:'test'}])||notoriety};
      return Object.fromEntries(Object.entries(results).map(([key,state])=>[key,{gameOver:!!state.gameOver,reached:state.mods?.endings?.reached}]));
    };return testEndingConditions();
  `;
  const offResults = await evaluate(fixture);
  for (const result of Object.values(offResults)) assert.equal(result.gameOver, false);
  console.log('PASS disabled endings do not end the game when their conditions are met');
  fs.writeFileSync(new URL('./ending-settings.jpg', import.meta.url), Buffer.from(await playScreenshot({}), 'base64'));

  const hotkeys = await evaluate(`
    for(const win of document.querySelectorAll('.wml-win[data-wml-endings-window]'))win.querySelector('.wml-win-close').click();
    const win=openTestSettings('kknd-hotkeys');
    return [...win.querySelectorAll('input[type=text]')].map(input=>{const c=getComputedStyle(input);return {background:c.backgroundColor,color:c.color}});
  `);
  assert.ok(hotkeys.length > 10);
  for (const colors of hotkeys) { assert.equal(colors.background, 'rgb(22, 18, 15)'); assert.equal(colors.color, 'rgb(245, 245, 244)'); }
  assert.equal(await evaluate(`const win=document.querySelector('[data-wml-hotkeys-window]'), input=win.querySelector('input[type=text]'),r=input.getBoundingClientRect(); return win.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2));`), true);
  console.log('PASS dark key boxes and light text');
  fs.writeFileSync(new URL('./hotkey-settings.jpg', import.meta.url), Buffer.from(await playScreenshot({}), 'base64'));

  await playReload({});
  await evaluate(openSettings);
  const persisted = await evaluate(`
    const win=openTestSettings('endings');
    return [...win.querySelectorAll('[data-wml-ending-toggle]')].map(b=>b.getAttribute('aria-checked'));
  `);
  assert.deepEqual(persisted, ['false', 'false', 'false', 'false']);
  const enabled = await evaluate(`
    return [...document.querySelectorAll('[data-wml-ending-toggle]')].map(b=>{b.click();return b.textContent});
  `);
  assert.deepEqual(enabled, ['On', 'On', 'On', 'On']);
  const onResults = await evaluate(fixture);
  for (const [key, result] of Object.entries(onResults)) {
    assert.equal(result.gameOver, true, key+': '+JSON.stringify(result));
    assert.equal(result.reached, key);
  }
  console.log('PASS all four enabled endings fire when their conditions are met');
  assert.equal(await evaluate(`openTestSettings('secert-club');return document.querySelector('[data-secert-club-brothel-settings] input').value`), '3.5');
  console.log('PASS values survive reload and all four endings can be reenabled');
  const final = await playStatus();
  assert.deepEqual(final.failed, []);
  assert.deepEqual(final.pageErrors, []);
  console.log('PASS no runtime errors with all enabled game mods');
} finally {
  await playStop();
}
