// 실행: node --import ./wml/mods/brothel/tests/mcp-runtime.mjs wml/mods/secert-club/tests/privacy.mjs [--zip]
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { playStart, playEval, playReload, playStatus, shutdown } from '../../../../MCP/lib/play.mjs';
import { checkMod } from '../../../../MCP/lib/check.mjs';
import { modSymbolsCheck } from '../../../../MCP/lib/modsym.mjs';
const id = 'secert-club-privacy';
const ids = ['addon-compat', 'brothel', 'secert-club', 'secert-club-compatible-brothel'];
const evaluate = async code => (await playEval({ id, code, timeoutMs: 45000 })).result;
try {
  for (const mod of ids.slice(2)) assert.ok(checkMod(mod).ok, JSON.stringify(checkMod(mod)));
  assert.ok(!modSymbolsCheck('secert-club').includes('✗'));
  const mods = Object.fromEntries(fs.readdirSync(new URL('../../', import.meta.url), { withFileTypes: true }).filter(e => e.isDirectory()).map(e => [e.name, ids.includes(e.name)]));
  await playStart({ id, mods });
  await evaluate(`localStorage.setItem('wml.folders',JSON.stringify(${JSON.stringify(ids)}));return true;`);
  if (process.argv.includes('--zip')) {
    const installed = await evaluate(`
      const append=Node.prototype.appendChild;
      Node.prototype.appendChild=function(node){
        if(node.tagName==='SCRIPT'&&/\\/wml\\/mods\\/(secert-club|secert-club-compatible-brothel)\\/mod\\.js(?:[?#]|$)/.test(node.src)){
          queueMicrotask(()=>node.dispatchEvent(new Event('error')));return node;
        }
        return append.call(this,node);
      };
      try{return await WML.install(await Promise.all(['secert-club','secert-club-compatible-brothel'].map(async mod=>({path:mod+'-1.2.0.zip',blob:await(await fetch('wml/mods/'+mod+'/'+mod+'-1.2.0.zip')).blob()}))));}
      finally{Node.prototype.appendChild=append;}
    `);
    assert.ok(installed.every(mod => mod.mode === 'browser'), JSON.stringify(installed));
  }
  const loaded = await playReload({ id });
  assert.deepEqual(loaded.failed, []);
  for (const mod of ids) assert.ok(loaded.loaded.includes(mod), mod);
  await evaluate(`
    const api=WML.dev(),symbols=WML.status().modSymbols['secert-club'];
    globalThis.privacyTest={api,fn:name=>api.fn(symbols[name]||name),club:__waywardSecertClubPublic};
    const t=privacyTest;
    t.fixture=(room='taproom')=>{
      const s=structuredClone(api.store.game());s.day=10;s.slot=9*1440+1020;s.phase='service';s.gameOver=false;
      s.pendingEvent=undefined;s.activeScene={};s.alertQueue=[];s.customers=[{id:'approved-1138',name:'초대 손님',status:'drinking',stayTimer:80,
        maxPatience:999,patience:999,roundsOrdered:1,maxRounds:99,intent:'interested',walletGold:100,boldness:80,charm:70,secertClubOrderVersion:1}];
      s.mods={...s.mods,'secert-club':{active:{day:10,venue:room,participants:'wife',guestIds:['approved-1138'],ejected:[],openedAtSlot:s.slot,notorietyCeiling:0}}};
      s.tavern={...s.tavern,backRoomReady:true,hasRoom:true,hasRoom2:true,hasBathhouse:true,tonightRenter:null,tonightRenter2:null};
      s.supplies={beer:100,wine:100,food:100};s.readyFood=100;s.tavernCleanliness=100;
      for(const loc of Object.values(s.locations))loc.occupants=[];
      s.locations[room].occupants=[api.fn('wifeId'),api.fn('playerId'),'approved-1138'];
      Object.assign(s.characters[s.primaryCharacterId],{currentTask:'idle',busyUntilSlot:0,retiredAtSlot:undefined,locationUntilSlot:undefined});
      return s;
    };return true;
  `);
  const gating = await evaluate(`
    const t=privacyTest,s=t.fixture();t.api.store.update(()=>s);
    const original=Math.random;let calls=0;Math.random=()=>{calls++;return 0;};
    try{
      const names=['clubFirstRenterArrival','clubSecondRenterArrival','clubRelativesArrival','clubServiceScenarioRoll',
        'clubCreatePrivateParty','clubInsertPrivateParty','clubWifeRenterVisit','clubCustomerFollowWife','clubPartyRoundRequest','clubPartyRoundAuto'];
      const same=names.every(name=>t.fn(name)(s,'merchants',60,[])===s);
      const proposals=['patronControlHerBackRoomProposal','patronControlPatronBackRoomProposal'].every(name=>{const r=t.fn(name)(s);return r.state===s&&!r.event;});
      const ordinary=t.fn('normalVisitRoll')(s.slot,true,0,0),outreach=t.fn('clubOutreachRoll')(s,1),back=t.fn('clubPrivateRoomOpen')(s,'back_room');
      return {same,proposals,ordinary,outreach,back,calls};
    }finally{Math.random=original;}
  `);
  assert.deepEqual(gating, { same: true, proposals: true, ordinary: false, outreach: null, back: false, calls: 0 });
  console.log('PASS entrance, lodging, outreach, external parties and private-room proposals stop before RNG');
  const venues = await evaluate(`
    const t=privacyTest,rooms=['taproom','back_room','upstairs_hall','upstairs_room_2','bathhouse'],out=[];
    for(const room of rooms){
      const s=t.fixture(room);t.api.store.update(()=>s);
      const tags=[...t.fn('clubRoomFeatures')(room)],witness=t.fn('clubWitnessContext')(s,{activeCustomerId:'approved-1138'});
      const explicit=t.fn('clubWitnessContext')(s,{otherWitnesses:3});
      const outsider={...s.customers[0],id:'outsider-1138',name:'일반 손님'};
      const denied=t.fn('addCustomer')(s,outsider,room)===s;
      const candidate={...s,customers:[...s.customers,outsider],locations:structuredClone(s.locations)};
      candidate.locations.village.occupants.push(outsider.id);
      const blocked=t.fn('moveOccupant')(candidate,outsider.id,room)===candidate;
      const closed=t.club.closeClub(s),accepted=t.fn('addCustomer')(closed,outsider,room).customers.some(c=>c.id===outsider.id);
      t.api.store.update(()=>closed);const restored=[...t.fn('clubRoomFeatures')(room)];
      out.push({room,tags,restored,witness,explicit,denied,blocked,accepted});
    }return out;
  `);
  for (const row of venues) {
    assert.ok(!row.tags.includes('public_floor'), row.room);
    assert.ok(row.tags.includes('shut_door') && row.tags.includes('tables'));
    assert.equal(row.witness.otherWitnesses, 0);
    assert.equal(row.explicit.otherWitnesses, 3);
    assert.ok(row.denied && row.blocked && row.accepted);
    if (['taproom','bathhouse'].includes(row.room)) assert.ok(row.restored.includes('public_floor'));
  }
  console.log('PASS all five venues: temporary privacy, approved audience, outsider rejection and restoration after closing');
  const migration = await evaluate(`
    const t=privacyTest,s=t.fixture();
    s.pendingEvent={type:'patron_offer',choices:[{id:'back_room_private_encourage'}]};
    t.api.store.update(()=>s);await new Promise(resolve=>setTimeout(resolve,0));
    const cleared=!t.api.store.game().pendingEvent;
    const critical={...s,pendingEvent:{type:'critical_test',choices:[{id:'continue'}]}};
    t.api.store.update(()=>critical);await new Promise(resolve=>setTimeout(resolve,0));
    const retained=t.api.store.game().pendingEvent?.type==='critical_test';
    const resolved=t.fn('clubResolveBackRoomProposal')(s,'back_room_private_encourage');
    const normal=t.fixture();normal.mods['secert-club'].active=null;
    const original=Math.random;let calls=0;Math.random=()=>{calls++;return 1;};
    try{t.api.store.update(()=>normal);t.fn('clubOutreachRoll')(normal,1);t.fn('normalVisitRoll')(normal.slot,true,0,0);}finally{Math.random=original;}
    return {cleared,retained,place:t.api.fn('wifeLocation')(resolved),calls};
  `);
  assert.ok(migration.cleared && migration.retained);
  assert.equal(migration.place, 'taproom');assert.ok(migration.calls > 0);
  console.log('PASS stale saved offers cleared without losing unrelated events; closed-club RNG resumes');
  const wifeMigration = await evaluate(`
    const t=privacyTest;let s=t.fixture('bathhouse');
    const scene={customerId:'approved-1138',customerName:'초대 손님',stage:'groping',elenaComfort:57,ticksAtStage:4,ticksElapsed:12};
    s.activeScene={patron:scene};s=t.api.fn('moveOccupant')(s,t.api.fn('wifeId'),'back_room');
    s=t.api.fn('moveOccupant')(s,'approved-1138','back_room');
    s.locations.back_room.meta={...s.locations.back_room.meta,privatePatron:{customerId:'approved-1138',returnAtSlot:s.slot+20}};
    const stats=JSON.stringify(t.api.fn('wife')(s).stats);
    t.api.store.update(()=>s);await new Promise(resolve=>setTimeout(resolve,0));s=t.api.store.game();
    return {wife:t.api.fn('wifeLocation')(s),guest:t.api.fn('getCustomerLocation')(s,'approved-1138'),
      sameScene:JSON.stringify(s.activeScene.patron)===JSON.stringify(scene),sameStats:JSON.stringify(t.api.fn('wife')(s).stats)===stats,
      cleared:!s.locations.back_room.meta.privatePatron,upstairs:t.fn('clubUpstairsPrivateOpen')(s)};
  `);
  assert.deepEqual(wifeMigration,{wife:'bathhouse',guest:'bathhouse',sameScene:true,sameStats:true,cleared:true,upstairs:false});
  console.log('PASS old wife handoff returns to the chosen venue without scene or personality changes');
  const status = await playStatus({ id });assert.deepEqual(status.pageErrors, []);
  console.log(JSON.stringify({ packaged: process.argv.includes('--zip'), venues: venues.length, gating, migration }));
} finally { await shutdown(); }
