WML.define({
  tags: ["content","h-scene"],
  id: 'secert-club',
  author: "Hina_Lover",
  name: { ko: 'Secert Club · 비밀 클럽', en: 'Secert Club' },
  // mod symbols (tools/mod-symbols.mjs / MCP symbol_add keep this block; data only)
  symbols: {
    "clubPrivateRoomOpen": {"raw":{"2026-11-01":"xS"},"doc":"등록된 비공개 장소의 실제 입장 가능 판정"},
    "clubCustomerTick": {"raw":{"2026-11-01":"RV"},"doc":"일반 손님의 음주 타이머와 주문 상태 진행"},
    "clubAwayCustomerTick": {"raw":{"2026-11-01":"RV"},"doc":"플레이어 부재 중 손님 상태 진행"},
    "clubReorderChance": {"raw":{"2026-11-01":"kce"},"doc":"서빙 품질에 따른 원본 추가 주문 확률"},
    "clubReservedCustomers": {"raw":{"2026-11-01":"rd"},"doc":"진행 중인 장면에서 응대할 수 없는 손님"},
    "clubPlayerGreet": {"raw":{"2026-11-01":"zZe"},"doc":"플레이어 손님 인사"},
    "clubPlayerOrder": {"raw":{"2026-11-01":"JZe"},"doc":"플레이어 주문 받기"},
    "clubPlayerServe": {"raw":{"2026-11-01":"QZe"},"doc":"플레이어 주문 서빙"},
    "clubPlayerUnavailable": {"raw":{"2026-11-01":"XZe"},"doc":"플레이어 품절 안내"},
    "clubPlayerInHall": {"raw":{"2026-11-01":"my"},"doc":"기본 플레이어 홀 응대 위치 검사"},
    "clubCustomerServiceable": {"raw":{"2026-11-01":"$r"},"doc":"기본 손님 홀 응대 가능 여부"},
    "clubWifeChooseTask": {"raw":{"2026-11-01":"Kje"},"doc":"아내의 주문·서빙·대기 업무 선택"},
    "clubRoomFeatures": {"raw":{"2026-11-01":"JG"},"doc":"비밀 클럽의 일시적 장소·초대 전용 영업 판정"},
    "clubWitnessContext": {"raw":{"2026-11-01":"Yn"},"doc":"비밀 클럽의 일시적 장소·초대 전용 영업 판정"},
    "clubOutreachRoll": {"raw":{"2026-11-01":"qIe"},"doc":"비밀 클럽의 일시적 장소·초대 전용 영업 판정"},
    "clubFirstRenterArrival": {"raw":{"2026-11-01":"pK"},"doc":"비밀 클럽의 일시적 장소·초대 전용 영업 판정"},
    "clubSecondRenterArrival": {"raw":{"2026-11-01":"xee"},"doc":"비밀 클럽의 일시적 장소·초대 전용 영업 판정"},
    "clubRelativesArrival": {"raw":{"2026-11-01":"XCe"},"doc":"비밀 클럽의 일시적 장소·초대 전용 영업 판정"},
    "clubServiceScenarioRoll": {"raw":{"2026-11-01":"mNe"},"doc":"비밀 클럽의 일시적 장소·초대 전용 영업 판정"},
    "clubCreatePrivateParty": {"raw":{"2026-11-01":"Or"},"doc":"비밀 클럽의 일시적 장소·초대 전용 영업 판정"},
    "clubInsertPrivateParty": {"raw":{"2026-11-01":"Yqe"},"doc":"비밀 클럽의 일시적 장소·초대 전용 영업 판정"},
    "clubResolveBackRoomProposal": {"raw":{"2026-11-01":"Gg"},"doc":"비밀 클럽의 일시적 장소·초대 전용 영업 판정"},
    "clubWifeRenterVisit": {"raw":{"2026-11-01":"MAe"},"doc":"비밀 클럽의 일시적 장소·초대 전용 영업 판정"},
    "clubCustomerFollowWife": {"raw":{"2026-11-01":"NHe"},"doc":"비밀 클럽의 일시적 장소·초대 전용 영업 판정"},
    "clubPartyRoundRequest": {"raw":{"2026-11-01":"Q$e"},"doc":"비밀 클럽의 일시적 장소·초대 전용 영업 판정"},
    "clubPartyRoundAuto": {"raw":{"2026-11-01":"Z$e"},"doc":"비밀 클럽의 일시적 장소·초대 전용 영업 판정"},
    "clubUrgentHallService": {"raw":{"2026-11-01":"pV"},"doc":"비밀 클럽의 일시적 장소·초대 전용 영업 판정"},
    "clubUpstairsPrivateOpen": {"raw":{"2026-11-01":"xS"},"doc":"위층 개별 접객 가능 판정"},
    "clubStartPaidInteraction": {"raw":{"2026-11-01":"Xt"},"doc":"유료 제안 수락 후 같은 장소에서 상호작용 시작"}
  },
  version: "1.3.1",
  game: "2026-11-01",
  lang: 'ko',
  loadAfter: ['waitress'],
  description: {
    ko: '방문 했던 손님을 초대하는 문란한 비밀 클럽을 개장합니다. 입장료·서비스 요금·비공개 평판 규칙을 적용합니다.',
    en: 'Runs an invitation-only secret club with admission fees, paid intimate services, and no notoriety gain.',
  },
  async setup(api) {
    await api.loadScript('files/privacy.js');
    const MOD_ID = 'secert-club';
    const OPEN_ACTION = `${MOD_ID}/open`;
    const PREPARE_ACTION = `${MOD_ID}/prepare`;
    const PAID_STAGES = new Set(['groping', 'intimate', 'handjob_patron', 'blowjob_patron', 'titfuck_patron', 'rubbing_patron', 'sex_patron']);
    const STAGE_FEES = { groping: 1, intimate: 2, handjob_patron: 3, titfuck_patron: 3, rubbing_patron: 4, blowjob_patron: 4, sex_patron: 6 };
    const STAGE_LABELS = { groping: '짙은 스킨십', intimate: '은밀한 애무', handjob_patron: '손 서비스', titfuck_patron: '가슴 서비스', rubbing_patron: '성기 마찰', blowjob_patron: '구강 서비스', sex_patron: '성관계' };
    const INTENT_LABELS = { drink_only: '음주 위주', talk_only: '대화 위주', flirt_curious: '가벼운 유혹', interested: '적극적 관심', predatory: '강압적 접근' };
    const TYPE_LABELS = { regular: '단골', local: '마을 주민', traveler: '여행자', merchant: '상인', laborer: '노동자', soldier: '군인', noble: '귀족' };
    const SCORE_LABELS = {
      permission: '그녀가 느끼는 허용 정도', coldPragmatist: '냉정한 실리주의자', openness: '개방성', confidence: '자신감',
      libido: '성적 욕망', arousal: '흥분도', taboo: '금기 선호도', likesCheating: '외도 성향', publicThrill: '공개 스릴 추구',
      corruption: '타락 욕구', jealousy: '질투 유발을 즐김', voyeur: '관음 성향', truePrude: '극도로 보수적',
    };
    const SCORE_MAX = {
      permission: 80, coldPragmatist: 20, openness: 20, confidence: 10, libido: 10, arousal: 10, taboo: 10,
      likesCheating: 5, publicThrill: 10, corruption: 10, jealousy: 5, voyeur: 10, truePrude: -20,
    };
    const VISIT_LABELS = { intent: '방문 의도', openness: '개방성', boldness: '대담함', approach: '접근 방식', relationship: "그녀/참여자와의 관계" };
    const VISIT_BASE = { intent: 0.4, openness: 0.1, boldness: 0.1, approach: 0.1, relationship: 0.3 };
    const DEFAULT_SETTINGS = {
      proposalEnabled: true,
      admissionFee: 10,
      proposalThreshold: 100,
      proposalOffset: -100,
      femaleAcceptanceRelaxation: 50,
      sexualBoost: 2,
      scoreWeights: Object.fromEntries(Object.keys(SCORE_MAX).map(key => [key, 1])),
      visitWeights: Object.fromEntries(Object.keys(VISIT_BASE).map(key => [key, 1])),
    };
    let compatibility = null;
    let preparationDraft = null;
    let setupRequestQueued = false;
    let servingCustomerId = null;
    const REORDER_RETRY_TIME = 120;
    const privacy = globalThis.SecertClub_비공개영업규칙등록하기(api, state => SecertClub_자료읽기(state).active);

    function SecertClub_수치제한하기(value, min, max) {
      const number = Number(value);
      return Math.max(min, Math.min(max, Number.isFinite(number) ? number : min));
    }

    function SecertClub_정수읽기(value, fallback = 0) {
      const number = Number(value);
      return Number.isFinite(number) ? Math.round(number) : fallback;
    }

    function SecertClub_설정읽기() {
      const saved = api.settings.get(DEFAULT_SETTINGS);
      return {
        ...DEFAULT_SETTINGS,
        ...saved,
        scoreWeights: { ...DEFAULT_SETTINGS.scoreWeights, ...(saved.scoreWeights || {}) },
        visitWeights: { ...DEFAULT_SETTINGS.visitWeights, ...(saved.visitWeights || {}) },
      };
    }

    function SecertClub_허용기준배수읽기() {
      return 1 - SecertClub_수치제한하기(SecertClub_설정읽기().femaleAcceptanceRelaxation, 0, 100) / 100;
    }

    function SecertClub_허용판정완화하기(result) {
      if (!result || !Number.isFinite(result.score) || !Number.isFinite(result.threshold)) return result;
      const factor = SecertClub_허용기준배수읽기();
      if (factor >= 1) return result;
      const threshold = result.threshold * factor;
      if (result.outcome === 'eager' || result.outcome === 'hesitant' || result.score < threshold) return { ...result, threshold };
      const { refusalFlavor, insultDepth, becauseOfHim, ...accepted } = result;
      return { ...accepted, outcome: result.score >= threshold + 15 ? 'eager' : 'hesitant', threshold };
    }

    function SecertClub_자료기본값읽기() {
      return {
        version: 1,
        unlocked: false,
        proposalSeen: false,
        lastMorningRollDay: 0,
        lastNightCheckDay: 0,
        openSetupRequested: false,
        prepared: null,
        active: null,
        history: [],
      };
    }

    function SecertClub_자료읽기(state) {
      return { ...SecertClub_자료기본값읽기(), ...(state?.mods?.[MOD_ID] || {}) };
    }

    function SecertClub_자료쓰기(state, patch) {
      return {
        ...state,
        mods: {
          ...(state.mods || {}),
          [MOD_ID]: { ...SecertClub_자료읽기(state), ...patch },
        },
      };
    }

    function SecertClub_문자해시읽기(value) {
      let hash = 2166136261;
      for (const character of String(value)) {
        hash ^= character.charCodeAt(0);
        hash = Math.imul(hash, 16777619);
      }
      return hash >>> 0;
    }

    function SecertClub_고정난수읽기(value) {
      return (SecertClub_문자해시읽기(value) % 100000) / 1000;
    }

    function SecertClub_특성목록읽기(wife) {
      return new Set([...(wife?.latentTraits || []), ...(wife?.noticedLatentTraits || [])]);
    }

    function SecertClub_허용도읽기(wife) {
      const rows = Object.values(wife?.latitude?.byCategory || {});
      if (!rows.length) return 0;
      const total = rows.reduce((sum, row) => sum + SecertClub_수치제한하기(50 + (row?.encouragement || 0) - (row?.restriction || 0), 0, 100), 0);
      return total / rows.length;
    }

    function SecertClub_아내점수읽기(state) {
      const wife = api.fn('wife')(state);
      const attributes = wife?.attributes || {};
      const traits = SecertClub_특성목록읽기(wife);
      const settings = SecertClub_설정읽기();
      const taboo = SecertClub_수치제한하기((((wife?.affinities?.taboo ?? 0) + 2) / 4) * 100, 0, 100);
      const normalized = {
        permission: SecertClub_허용도읽기(wife),
        coldPragmatist: traits.has('cold_pragmatist') ? 100 : 0,
        openness: SecertClub_수치제한하기(attributes.openness ?? 0, 0, 100),
        confidence: SecertClub_수치제한하기(attributes.confidence ?? 0, 0, 100),
        libido: SecertClub_수치제한하기(attributes.libido ?? 0, 0, 100),
        arousal: SecertClub_수치제한하기(wife?.stats?.arousal ?? 0, 0, 100),
        taboo,
        likesCheating: traits.has('likes_cheating') ? 100 : 0,
        publicThrill: traits.has('public_thrill_seeker') || traits.has('latent_exhibitionist') ? 100 : 0,
        corruption: traits.has('wants_to_be_corrupted') ? 100 : 0,
        jealousy: traits.has('enjoys_making_him_jealous') || traits.has('jealousy_kindled') ? 100 : 0,
        voyeur: traits.has('latent_voyeur') ? 100 : 0,
        truePrude: traits.has('true_prude') ? 100 : 0,
      };
      const parts = {};
      let total = 0;
      for (const key of Object.keys(SCORE_MAX)) {
        const points = SCORE_MAX[key] * normalized[key] / 100 * SecertClub_수치제한하기(settings.scoreWeights[key], 0, 2);
        parts[key] = Math.round(points * 10) / 10;
        total += points;
      }
      return { total: Math.round(total * 10) / 10, normalized, parts };
    }

    function SecertClub_남편감정점수읽기(state) {
      const wife = api.fn('wife')(state);
      const positive = new Set(['tenderness', 'devotion', 'pride', 'elation', 'ecstasy', 'contentment', 'longing', 'desire', 'arousal_buzz']);
      const negative = new Set(['resentment', 'anger', 'contempt', 'disgust', 'pushed_away']);
      let feeling = 0;
      for (const item of wife?.feelings || []) {
        const amount = SecertClub_수치제한하기(item?.intensity ?? 0, 0, 100);
        if (positive.has(item?.emotion)) feeling += amount * 0.25;
        if (negative.has(item?.emotion)) feeling -= amount * 0.2;
      }
      let resentment = 0;
      try { resentment = Number(api.fn('resentment')(wife)) || 0; } catch { resentment = Number(wife?.relationship?.resentment) || 0; }
      return Math.round(SecertClub_수치제한하기((wife?.relationship?.trust ?? 0) * 0.5 + feeling - resentment * 0.5, 0, 100) * 10) / 10;
    }

    function SecertClub_기본조건충족여부(state) {
      return SecertClub_아내점수읽기(state).total >= SecertClub_설정읽기().proposalThreshold;
    }

    function SecertClub_호환조건충족여부(state) {
      try { return !!compatibility?.eligible?.(state); } catch (error) { api.warn(`Brothel 호환 조건 확인 실패: ${error.message}`); return false; }
    }

    function SecertClub_개점가능여부(state) {
      if (!state || state.gameOver) return false;
      const data = SecertClub_자료읽기(state);
      if (SecertClub_호환조건충족여부(state)) return true;
      if (data.unlocked) return true;
      return !SecertClub_설정읽기().proposalEnabled && SecertClub_기본조건충족여부(state);
    }

    function SecertClub_관계점수읽기(record) {
      const values = [record?.platonic, record?.romantic, record?.sexual].filter(Number.isFinite);
      if (!values.length) return SecertClub_수치제한하기(20 + (record?.visitCount || 0) * 5 + (record?.kindnessCount || 0) * 3, 0, 100);
      return SecertClub_수치제한하기(values.reduce((sum, value) => sum + value, 0) / values.length, 0, 100);
    }

    function SecertClub_의도점수읽기(intent) {
      return ({ drink_only: 20, talk_only: 25, flirt_curious: 60, interested: 85, predatory: 95 })[intent] ?? 50;
    }

    function SecertClub_접근점수읽기(style) {
      const id = String(style || '').toLowerCase();
      if (/tender|charm|patient|polite|romantic/.test(id)) return 85;
      if (/direct|bold|confident|command/.test(id)) return 75;
      if (/opportun|cunning|pressure|force|rough/.test(id)) return 45;
      if (/awkward|shy|passive/.test(id)) return 35;
      return 60;
    }

    function SecertClub_손님기본점수읽기(record) {
      const settings = SecertClub_설정읽기();
      const attributes = record?.attributes || {};
      const components = {
        intent: SecertClub_의도점수읽기(record?.intent),
        openness: SecertClub_수치제한하기(attributes.openness ?? 50, 0, 100),
        boldness: SecertClub_수치제한하기(record?.boldness ?? attributes.boldness ?? attributes.confidence ?? 50, 0, 100),
        approach: SecertClub_접근점수읽기(record?.tacticStyle),
        relationship: SecertClub_관계점수읽기(record),
      };
      let weighted = 0;
      let divisor = 0;
      for (const key of Object.keys(VISIT_BASE)) {
        const weight = VISIT_BASE[key] * SecertClub_수치제한하기(settings.visitWeights[key], 0, 2);
        weighted += components[key] * weight;
        divisor += weight;
      }
      return { score: divisor > 0 ? weighted / divisor : 0, components, hostName: api.fn('wife')(api.store.game() || {})?.name || "그녀" };
    }

    function SecertClub_손님점수읽기(state, record, participants) {
      const wifeScore = SecertClub_손님기본점수읽기(record);
      if (!compatibility?.guestScore) return wifeScore;
      try { return compatibility.guestScore(state, record, participants, wifeScore) || wifeScore; }
      catch (error) { api.warn(`Brothel 호환 손님 점수 계산 실패: ${error.message}`); return wifeScore; }
    }

    function SecertClub_장소목록읽기(state) {
      const tavern = state?.tavern || {};
      return [
        { id: 'taproom', label: '홀', enabled: true },
        { id: 'back_room', label: '뒷방', enabled: tavern.backRoomReady === true },
        { id: 'upstairs_hall', label: '객실 1', enabled: !!tavern.hasRoom && !tavern.tonightRenter },
        { id: 'upstairs_room_2', label: '객실 2', enabled: !!tavern.hasRoom2 && !tavern.tonightRenter2 },
        { id: 'bathhouse', label: '목욕탕', enabled: !!tavern.hasBathhouse },
      ];
    }

    function SecertClub_아내선택목록읽기(state, participants) {
      const records = [...(state.patronRecords || [])];
      records.sort((left, right) => {
        const leftScore = SecertClub_손님점수읽기(state, left, participants).score + SecertClub_관계점수읽기(left) * 0.35;
        const rightScore = SecertClub_손님점수읽기(state, right, participants).score + SecertClub_관계점수읽기(right) * 0.35;
        return rightScore - leftScore || String(left.name).localeCompare(String(right.name), 'ko');
      });
      const count = Math.min(6, Math.max(1, Math.ceil(records.length / 2)));
      return records.slice(0, count).map(record => record.name);
    }

    function SecertClub_승인결과읽기(state, names, participants) {
      const known = new Map((state.patronRecords || []).map(record => [record.name, record]));
      const approved = [];
      const rejected = [];
      for (const name of [...new Set(names)]) {
        const record = known.get(name);
        if (!record) continue;
        const result = SecertClub_손님점수읽기(state, record, participants);
        const chance = SecertClub_수치제한하기(result.score, 0, 100);
        const roll = SecertClub_고정난수읽기(`${state.day}|${name}|${participants}|${result.hostName || ''}`);
        const row = { name, chance: Math.round(chance * 10) / 10, roll: Math.round(roll * 10) / 10, hostName: result.hostName || api.fn('wife')(state).name };
        (roll < chance ? approved : rejected).push(row);
      }
      return { approved, rejected };
    }

    function SecertClub_손님만들기(state, record, admissionFee) {
      const hash = SecertClub_문자해시읽기(`${state.day}:${record.name}`).toString(36);
      const boldness = SecertClub_수치제한하기(record.boldness ?? record.attributes?.boldness ?? record.attributes?.confidence ?? 50, 1, 100);
      const charm = SecertClub_수치제한하기(record.charm ?? record.attributes?.charm ?? 50, 1, 100);
      return {
        id: `secert-club-${state.day}-${hash}`,
        name: record.name,
        status: 'greeted',
        mood: 'pleased',
        order: null,
        patience: 999,
        maxPatience: 999,
        stayTimer: 20 + Math.floor(Math.random() * 40),
        roundsOrdered: 0,
        maxRounds: 99,
        tab: 0,
        arrivedAtSlot: state.slot,
        boldness,
        charm,
        patronType: record.patronType || 'regular',
        intent: record.intent || 'interested',
        walletGold: Math.max(admissionFee + 60, Number(record.walletGold) || 0),
        personaTags: [...(record.personaTags || [])],
        tacticStyle: record.tacticStyle,
        chemistry: record.chemistry ?? 50,
        kindnessTonight: 0,
        attributes: { ...(record.attributes || {}), openness: record.attributes?.openness ?? 50 },
        drawnBy: 'secert_club',
        secertClubOrderVersion: 1,
      };
    }

    function SecertClub_클럽열기(state) {
      const data = SecertClub_자료읽기(state);
      const prepared = data.prepared;
      if (!prepared || prepared.day !== state.day || !prepared.approved?.length || data.active) return state;
      const settings = SecertClub_설정읽기();
      const known = new Map((state.patronRecords || []).map(record => [record.name, record]));
      let next = state;
      const guestIds = [];
      let admissionTotal = 0;
      for (const approval of prepared.approved) {
        const record = known.get(approval.name);
        if (!record) continue;
        let customer = next.customers.find(item => item.name === record.name && item.status !== 'gone');
        if (!customer) {
          customer = SecertClub_손님만들기(next, record, settings.admissionFee);
          next = api.fn('addCustomer')(next, customer, prepared.venue);
        }
        const fee = Math.max(0, SecertClub_정수읽기(settings.admissionFee, 10));
        next = {
          ...next,
          customers: next.customers.map(item => item.id === customer.id ? {
            ...item,
            status: item.status === 'leaving' ? 'greeted' : item.status,
            stayTimer: item.stayTimer >= 120 || !Number.isFinite(item.stayTimer) ? 20 + Math.floor(Math.random() * 40) : item.stayTimer,
            maxRounds: Math.max(99, item.maxRounds || 0),
            walletGold: Math.max(0, Math.max(fee, Number(item.walletGold) || 0) - fee),
            secertClubGuest: true,
            secertClubOrderVersion: 1,
          } : item),
          economy: { ...next.economy, gold: (next.economy?.gold || 0) + fee },
          goldEarnedToday: (next.goldEarnedToday || 0) + fee,
          incomeBreakdownToday: { ...(next.incomeBreakdownToday || {}), secretClubAdmission: ((next.incomeBreakdownToday || {}).secretClubAdmission || 0) + fee },
        };
        next = api.fn('moveOccupant')(next, customer.id, prepared.venue);
        guestIds.push(customer.id);
        admissionTotal += fee;
      }
      if (!guestIds.length) return api.fn('log')(next, '[비밀 클럽] 입장할 수 있는 승인 손님이 없어 개장하지 못했습니다.');
      const participants = prepared.participants || 'wife';
      if (participants !== 'workers_only') next = api.fn('moveOccupant')(next, api.fn('wifeId'), prepared.venue);
      let active = {
        day: next.day,
        venue: prepared.venue,
        participants,
        guestIds,
        openedAtSlot: next.slot,
        notorietyCeiling: next.tavernReputation?.notoriety ?? 0,
        lastSceneMarker: null,
        ejected: [],
        extensionData: null,
      };
      next = SecertClub_자료쓰기(next, { active });
      if (compatibility?.beforeOpen) {
        try {
          const result = compatibility.beforeOpen(next, prepared, active) || {};
          next = result.state || next;
          active = { ...SecertClub_자료읽기(next).active, extensionData: result.extensionData || null };
          next = SecertClub_자료쓰기(next, { active });
        } catch (error) { api.warn(`Brothel 호환 개장 처리 실패: ${error.message}`); }
      }
      const venueLabel = SecertClub_장소목록읽기(next).find(room => room.id === prepared.venue)?.label || prepared.venue;
      next = privacy.normalize(next);
      return api.fn('log')(next, `[비밀 클럽] ${venueLabel}에 승인 손님 ${guestIds.length}명이 입장했습니다. 입장료 ${admissionTotal}골드를 받았습니다.`);
    }

    function SecertClub_클럽닫기(state, reason = '영업이 끝났습니다.') {
      const data = SecertClub_자료읽기(state);
      if (!data.active) return state;
      let next = state;
      if (compatibility?.afterClose) {
        try { next = compatibility.afterClose(next, data.active) || next; }
        catch (error) { api.warn(`Brothel 호환 종료 처리 실패: ${error.message}`); }
      }
      const guestIds = new Set(data.active.guestIds || []);
      next = {
        ...next,
        customers: (next.customers || []).map(customer => guestIds.has(customer.id) && customer.status !== 'gone' ? { ...customer, status: 'leaving' } : customer),
      };
      const history = [...(data.history || []), { day: data.active.day, venue: data.active.venue, guests: guestIds.size, closedAtSlot: next.slot }].slice(-20);
      next = SecertClub_자료쓰기(next, { active: null, prepared: data.prepared?.day === next.day ? data.prepared : null, history });
      return api.fn('log')(next, `[비밀 클럽] ${reason}`);
    }

    function SecertClub_영업중인가(state) {
      const active = SecertClub_자료읽기(state).active;
      return !state.pmCore && !state.gameOver && active?.day === state.day && ['service', 'last_call', 'closed'].includes(state.phase);
    }

    function SecertClub_주문대상인가(state, customer) {
      const active = SecertClub_자료읽기(state).active;
      return !!customer && SecertClub_영업중인가(state) && (active.guestIds || []).includes(customer.id)
        && !(active.ejected || []).includes(customer.id) && !['leaving', 'gone'].includes(customer.status);
    }

    function SecertClub_응대중손님읽기(state) {
      const reserved = new Set(api.fn('clubReservedCustomers')(state));
      const wife = api.fn('wife')(state);
      if (wife?.taskTarget && ['greeting', 'taking_order', 'serving'].includes(wife.currentTask)) reserved.add(wife.taskTarget);
      for (const customer of state.customers || []) {
        if (api.has('brothelCustomerBusy') && api.fn('brothelCustomerBusy')(state, customer.id)) reserved.add(customer.id);
      }
      return reserved;
    }

    function SecertClub_손님음주진행하기(next, state, ...args) {
      if (!SecertClub_영업중인가(state)) return next(state, ...args);
      state = SecertClub_손님잔류처리하기(state);
      const drinking = new Map(state.customers.filter(customer => SecertClub_주문대상인가(state, customer) && customer.status === 'drinking').map(customer => [customer.id, customer]));
      if (!drinking.size) return next(state, ...args);
      const reserved = SecertClub_응대중손님읽기(state);
      let result = next({ ...state, customers: state.customers.map(customer => drinking.has(customer.id) ? { ...customer, isResident: true } : customer) }, ...args);
      const messages = [];
      const customers = result.customers.map(customer => {
        const original = drinking.get(customer.id);
        if (!original) return customer;
        const { isResident, ...restored } = customer;
        let updated = Object.hasOwn(original, 'isResident') ? { ...restored, isResident: original.isResident } : restored;
        if (!SecertClub_주문대상인가(result, updated) || reserved.has(updated.id)) return updated;
        updated = { ...updated, stayTimer: Math.max(0, (Number(updated.stayTimer) || 0) - 1) };
        if (updated.stayTimer > 0) return updated;
        if ((Number(updated.walletGold) || 0) < 3) {
          messages.push(`[비밀 클럽] ${updated.name}은(는) 추가 주문할 돈이 부족해 자리를 떠납니다.`);
          return { ...updated, status: 'leaving' };
        }
        if (updated.roundsOrdered < updated.maxRounds && Math.random() < api.fn('clubReorderChance')(updated)) {
          messages.push(`[비밀 클럽] ${updated.name}이(가) 잔을 비우고 추가 주문을 요청합니다.`);
          return { ...updated, status: 'wants_more', patience: updated.maxPatience };
        }
        messages.push(`[비밀 클럽] ${updated.name}은(는) 잠시 쉬며 클럽에 머뭅니다. ${REORDER_RETRY_TIME}분 뒤 추가 주문을 다시 생각합니다.`);
        return { ...updated, stayTimer: REORDER_RETRY_TIME };
      });
      result = { ...result, customers };
      for (const message of messages) result = api.fn('log')(result, message);
      return result;
    }

    function SecertClub_플레이어응대가능한가(state, customerId) {
      const customer = state.customers.find(item => item.id === customerId);
      if (!SecertClub_주문대상인가(state, customer) || SecertClub_응대중손님읽기(state).has(customerId)) return false;
      const room = api.fn('getCustomerLocation')(state, customerId);
      return SecertClub_장소목록읽기(state).some(venue => venue.id === room && venue.enabled)
        && api.fn('locationOf')(state, api.fn('playerId')) === room;
    }

    function SecertClub_웨이트리스호환진행하기(state) {
      if (!SecertClub_영업중인가(state) || state.pendingEvent || !['service', 'last_call'].includes(state.phase)) return state;
      const worker = globalThis.__waywardSimpleWaitressPublic;
      const config = worker?.getConfig?.();
      if (!worker?.tick || !config?.hired || config.activeDay !== state.day) return state;
      const reserved = SecertClub_응대중손님읽기(state);
      const ids = new Set(state.customers.filter(customer => SecertClub_주문대상인가(state, customer)
        && !reserved.has(customer.id) && ['arrived', 'greeted', 'wants_more', 'ordered'].includes(customer.status)
        && api.fn('getCustomerLocation')(state, customer.id) !== 'taproom'
        && SecertClub_장소목록읽기(state).some(venue => venue.enabled && venue.id === api.fn('getCustomerLocation')(state, customer.id))).map(customer => customer.id));
      if (!ids.size) return state;
      const locations = Object.fromEntries(Object.entries(state.locations).map(([room, location]) => [room, {
        ...location, occupants: (location.occupants || []).filter(id => !ids.has(id)),
      }]));
      locations.taproom = { ...locations.taproom, occupants: [...(locations.taproom?.occupants || []), ...ids] };
      const result = worker.tick({ ...state, slot: state.slot + 1, locations });
      return { ...result, slot: state.slot, locations: state.locations };
    }

    function SecertClub_아내주문대기하기(next, state, ...args) {
      const active = SecertClub_자료읽기(state).active;
      const wife = api.fn('wife')(state);
      if (!SecertClub_영업중인가(state) || active.participants === 'workers_only' || active.venue === 'taproom'
        || api.fn('wifeLocation')(state) !== active.venue || wife.retiredAtSlot != null
        || !['idle', 'greeting', 'taking_order', 'serving'].includes(wife.currentTask)
        || state.activeScene?.patron || api.fn('playerSexScene')(state) || state.activeScene?.bathhouse
        || state.slot < wife.busyUntilSlot || (wife.locationUntilSlot != null && state.slot < wife.locationUntilSlot)) return next(state, ...args);
      const waiting = state.customers.some(customer => ['arrived', 'greeted', 'wants_more', 'ordered'].includes(customer.status)
        && api.fn('getCustomerLocation')(state, customer.id) === active.venue);
      if (waiting || state.tavernCleanliness < 55 || (state.readyFood < 3 && state.supplies.food > 0)) return next(state, ...args);
      return api.fn('updateWife')(state, current => ({ ...current, currentTask: 'idle', taskTarget: undefined, busyUntilSlot: state.slot + 1 }));
    }

    function SecertClub_손님잔류처리하기(state) {
      const data = SecertClub_자료읽기(state);
      if (!data.active) return state;
      const ids = new Set(data.active.guestIds || []);
      const ejected = new Set(data.active.ejected || []);
      const suppliesLeft = (state.supplies?.beer || 0) + (state.supplies?.wine || 0) + (state.supplies?.food || 0) + (state.readyFood || 0);
      let changed = false;
      const customers = (state.customers || []).map(customer => {
        if (!ids.has(customer.id) || ejected.has(customer.id) || ['leaving', 'gone'].includes(customer.status)) return customer;
        if (customer.intent === 'drink_only' && suppliesLeft <= 0) {
          if (customer.status === 'leaving' || customer.status === 'gone') return customer;
          changed = true;
          return { ...customer, status: 'leaving' };
        }
        if (customer.secertClubOrderVersion !== 1) {
          changed = true;
          return { ...customer, secertClubOrderVersion: 1,
            stayTimer: customer.status === 'drinking' && ((customer.stayTimer || 0) >= 120 || !Number.isFinite(customer.stayTimer))
              ? 20 + Math.floor(Math.random() * 40) : customer.stayTimer };
        }
        return customer;
      });
      return changed ? { ...state, customers } : state;
    }

    function SecertClub_서비스요금처리하기(state) {
      const data = SecertClub_자료읽기(state);
      const active = data.active;
      if (!active || active.participants === 'workers_only') return state;
      const scene = state.activeScene?.patron;
      if (!scene || !(active.guestIds || []).includes(scene.customerId)) {
        if (active.lastSceneMarker == null) return state;
        return SecertClub_자료쓰기(state, { active: { ...active, lastSceneMarker: null } });
      }
      const marker = `${scene.customerId}:${scene.startedAtSlot || active.openedAtSlot}:${scene.stage}`;
      if (active.lastSceneMarker === marker) return state;
      let next = SecertClub_자료쓰기(state, { active: { ...active, lastSceneMarker: marker } });
      if (!PAID_STAGES.has(scene.stage)) return next;
      const customer = next.customers.find(item => item.id === scene.customerId);
      if (!customer) return next;
      let multiplier = 1;
      try { multiplier = compatibility?.feeMultiplier ? compatibility.feeMultiplier(next, active) : 1; } catch { multiplier = 1; }
      const fee = Math.max(1, Math.round((STAGE_FEES[scene.stage] || 1) * SecertClub_수치제한하기(multiplier, 1, 10)));
      next = {
        ...next,
        customers: next.customers.map(item => item.id === customer.id ? { ...item, walletGold: Math.max(0, (Number(item.walletGold) || fee) - fee) } : item),
        economy: { ...next.economy, gold: (next.economy?.gold || 0) + fee },
        goldEarnedToday: (next.goldEarnedToday || 0) + fee,
        incomeBreakdownToday: { ...(next.incomeBreakdownToday || {}), secretClubService: ((next.incomeBreakdownToday || {}).secretClubService || 0) + fee },
      };
      return api.fn('log')(next, `[비밀 클럽] ${customer.name}이(가) ${STAGE_LABELS[scene.stage] || '서비스'} 요금 ${fee}골드를 지불했습니다.`);
    }

    function SecertClub_호환진행처리하기(state) {
      const active = SecertClub_자료읽기(state).active;
      if (!active || !compatibility?.onTick) return state;
      try {
        const result = compatibility.onTick(state, active) || {};
        let next = result.state || state;
        if (result.extensionData !== undefined) {
          const latest = SecertClub_자료읽기(next).active;
          if (latest) next = SecertClub_자료쓰기(next, { active: { ...latest, extensionData: result.extensionData } });
        }
        return next;
      } catch (error) {
        api.warn(`Brothel 호환 진행 처리 실패: ${error.message}`);
        return state;
      }
    }

    function SecertClub_악명증가막기(state) {
      const active = SecertClub_자료읽기(state).active;
      const current = state.tavernReputation?.notoriety;
      if (!active || !Number.isFinite(current) || current <= active.notorietyCeiling) return state;
      return { ...state, tavernReputation: { ...state.tavernReputation, notoriety: active.notorietyCeiling } };
    }

    function SecertClub_활성상태진행하기(state) {
      const data = SecertClub_자료읽기(state);
      if (!data.active) return state;
      if (state.day !== data.active.day || state.phase === 'bedroom') return SecertClub_클럽닫기(state, '밤의 비밀 영업을 마쳤습니다.');
      let next = SecertClub_손님잔류처리하기(privacy.normalize(state));
      next = SecertClub_호환진행처리하기(next);
      next = SecertClub_서비스요금처리하기(next);
      return SecertClub_악명증가막기(next);
    }

    function SecertClub_제안넣기(state, source) {
      const data = SecertClub_자료읽기(state);
      if (data.proposalSeen || data.unlocked || SecertClub_호환조건충족여부(state)) return state;
      const wife = api.fn('wife')(state);
      let next = SecertClub_자료쓰기(state, { proposalSeen: true, unlocked: true });
      next = api.events.alert(next, {
        kind: proposalKind,
        title: '비밀 클럽 제안',
        body: source === 'morning'
          ? `${wife.name}이(가) 눈을 뜨자마자 조심스럽게 단골들만 받는 비밀 클럽을 열어 보자고 제안합니다.`
          : `${wife.name}이(가) 새벽의 침실에서, 서로 믿을 수 있는 손님만 초대해 비밀 클럽을 열어 보자고 말합니다.`,
        choices: [
          { id: 'prepare', label: '개점 준비를 시작한다' },
          { id: 'later', label: '다음에 준비한다' },
        ],
      });
      return next;
    }

    function SecertClub_자동제안처리하기(state) {
      if (!state || !SecertClub_설정읽기().proposalEnabled || !SecertClub_기본조건충족여부(state)) return state;
      const data = SecertClub_자료읽기(state);
      if (data.proposalSeen || data.unlocked || SecertClub_호환조건충족여부(state)) return state;
      const minute = ((state.slot % 1440) + 1440) % 1440;
      if ((state.phase === 'bedroom' || state.phase === 'closed') && minute >= 120 && minute < 360 && data.lastNightCheckDay !== state.day) {
        const checked = SecertClub_자료쓰기(state, { lastNightCheckDay: state.day });
        return SecertClub_제안넣기(checked, 'bedroom');
      }
      return state;
    }

    function SecertClub_준비창요청처리하기() {
      const state = api.store.game();
      if (!state || !SecertClub_자료읽기(state).openSetupRequested || setupRequestQueued) return;
      setupRequestQueued = true;
      setTimeout(() => {
        setupRequestQueued = false;
        const latest = api.store.game();
        if (!latest) return;
        api.store.update(current => SecertClub_자료쓰기(current, { openSetupRequested: false }));
        SecertClub_준비창열기();
      }, 0);
    }

    function SecertClub_요소만들기(tag, props, ...children) {
      return api.ui.h(tag, props || {}, ...children);
    }

    function SecertClub_버튼만들기(label, onClick, options = {}) {
      return api.ui.button(label, onClick, options);
    }

    function SecertClub_준비초안읽기(state) {
      const venues = SecertClub_장소목록읽기(state);
      const existing = SecertClub_자료읽기(state).prepared;
      const participantChoices = compatibility?.participantChoices?.(state) || [{ id: 'wife', label: "그녀 참여", description: '' }];
      const participantIds = new Set(participantChoices.map(choice => choice.id));
      return {
        day: state.day,
        venue: venues.some(room => room.enabled && room.id === existing?.venue) ? existing.venue : venues.find(room => room.enabled)?.id || 'taproom',
        method: existing?.method || 'direct',
        selected: new Set(existing?.invited || []),
        participants: participantIds.has(existing?.participants) ? existing.participants : participantChoices[0].id,
        resultsVisible: !!existing,
      };
    }

    function SecertClub_준비창열기() {
      const state = api.store.game();
      if (!state) return;
      if (!SecertClub_개점가능여부(state)) {
        api.log('[비밀 클럽] 아직 개점 조건을 충족하지 못했습니다.');
        return;
      }
      if (!preparationDraft || preparationDraft.day !== state.day) preparationDraft = SecertClub_준비초안읽기(state);
      const handle = api.ui.window({
        id: 'secert-club-preparation',
        title: '비밀 클럽 · 개점 준비',
        width: 760,
        height: 720,
        render(body, win) {
          const current = api.store.game();
          if (!current) return;
          if (!preparationDraft || preparationDraft.day !== current.day) preparationDraft = SecertClub_준비초안읽기(current);
          const draft = preparationDraft;
          const records = current.patronRecords || [];
          const data = SecertClub_자료읽기(current);
          body.textContent = '';
          body.dataset.wmlUi = 'true';
          body.style.cssText = 'display:flex;flex-direction:column;gap:12px;color:#eee;';

          const score = SecertClub_아내점수읽기(current);
          body.append(SecertClub_요소만들기('p', { class: 'wml-note' }, `그녀 점수 ${score.total}점 · 기준 ${SecertClub_설정읽기().proposalThreshold}점 · 알고 있는 손님 ${records.length}명`));

          const venueSection = SecertClub_요소만들기('section', { class: 'wml-section' });
          venueSection.append(SecertClub_요소만들기('h3', {}, '클럽 장소 선정'));
          const venueGrid = SecertClub_요소만들기('div', { style: 'display:flex;flex-wrap:wrap;gap:8px;' });
          for (const room of SecertClub_장소목록읽기(current)) {
            const label = SecertClub_요소만들기('label', { style: `display:flex;gap:5px;align-items:center;opacity:${room.enabled ? 1 : 0.45};` });
            const radio = SecertClub_요소만들기('input', { type: 'radio', name: 'secert-club-venue', value: room.id, checked: draft.venue === room.id, disabled: !room.enabled });
            radio.addEventListener('change', () => { draft.venue = room.id; });
            label.append(radio, document.createTextNode(room.label + (room.enabled ? '' : ' · 시설 필요')));
            venueGrid.append(label);
          }
          venueSection.append(venueGrid);
          body.append(venueSection);

          const guestSection = SecertClub_요소만들기('section', { class: 'wml-section' });
          guestSection.append(SecertClub_요소만들기('h3', {}, '초대 손님 고르기'));
          const methodRow = SecertClub_요소만들기('div', { style: 'display:flex;gap:8px;flex-wrap:wrap;' });
          methodRow.append(
            SecertClub_버튼만들기('직접 고르기', () => { draft.method = 'direct'; draft.resultsVisible = false; win.refresh(); }, { primary: draft.method === 'direct' }),
            SecertClub_버튼만들기("그녀가 손님 고르기", () => {
              draft.method = 'wife';
              draft.selected = new Set(SecertClub_아내선택목록읽기(current, draft.participants));
              draft.resultsVisible = false;
              win.refresh();
            }, { primary: draft.method === 'wife' }),
          );
          guestSection.append(methodRow);
          const selectRow = SecertClub_요소만들기('div', { style: 'display:flex;gap:8px;margin-top:8px;' });
          selectRow.append(
            SecertClub_버튼만들기('모두 선택', () => { draft.selected = new Set(records.map(record => record.name)); draft.resultsVisible = false; win.refresh(); }),
            SecertClub_버튼만들기('모두 해제', () => { draft.selected.clear(); draft.resultsVisible = false; win.refresh(); }),
          );
          guestSection.append(selectRow);
          const guestList = SecertClub_요소만들기('div', { style: 'display:flex;flex-direction:column;gap:6px;max-height:250px;overflow:auto;margin-top:8px;padding-right:4px;' });
          if (!records.length) guestList.append(SecertClub_요소만들기('p', { class: 'wml-note' }, "아직 두 사람이 알고 지내는 손님이 없습니다. 영업 중 손님을 만나 기록을 쌓은 뒤 초대할 수 있습니다."));
          for (const record of records) {
            const row = SecertClub_요소만들기('label', { style: 'display:grid;grid-template-columns:auto 1fr;gap:8px;padding:7px;border:1px solid #66533b;border-radius:6px;background:#1d1915;' });
            const checkbox = SecertClub_요소만들기('input', { type: 'checkbox', checked: draft.selected.has(record.name), disabled: draft.method === 'wife' });
            checkbox.addEventListener('change', () => { checkbox.checked ? draft.selected.add(record.name) : draft.selected.delete(record.name); draft.resultsVisible = false; });
            const info = SecertClub_요소만들기('span', {});
            const scoreRow = SecertClub_손님점수읽기(current, record, draft.participants);
            info.append(
              SecertClub_요소만들기('strong', {}, record.name),
              SecertClub_요소만들기('br'),
              SecertClub_요소만들기('small', { class: 'wml-muted' }, `${TYPE_LABELS[record.patronType] || record.patronType || '직업 미상'} · ${INTENT_LABELS[record.intent] || record.intent || '의도 미상'} · 관계 ${Math.round(SecertClub_관계점수읽기(record))} · 참여 가능성 ${Math.round(scoreRow.score)}%${scoreRow.hostName ? ` · 초대자 ${scoreRow.hostName}` : ''}`),
            );
            row.append(checkbox, info);
            guestList.append(row);
          }
          guestSection.append(guestList);
          body.append(guestSection);

          const participantChoices = compatibility?.participantChoices?.(current) || [];
          if (participantChoices.length) {
            const participantSection = SecertClub_요소만들기('section', { class: 'wml-section' });
            participantSection.append(SecertClub_요소만들기('h3', {}, '참여자 지정'));
            for (const choice of participantChoices) {
              const label = SecertClub_요소만들기('label', { style: 'display:flex;align-items:flex-start;gap:6px;margin:6px 0;' });
              const radio = SecertClub_요소만들기('input', { type: 'radio', name: 'secert-club-participants', value: choice.id, checked: draft.participants === choice.id });
              radio.addEventListener('change', () => { draft.participants = choice.id; draft.resultsVisible = false; if (draft.method === 'wife') draft.selected = new Set(SecertClub_아내선택목록읽기(current, draft.participants)); win.refresh(); });
              label.append(radio, SecertClub_요소만들기('span', {}, choice.label, choice.description ? SecertClub_요소만들기('small', { class: 'wml-muted', style: 'display:block;' }, choice.description) : ''));
              participantSection.append(label);
            }
            body.append(participantSection);
          }

          if (draft.resultsVisible && data.prepared?.day === current.day) {
            const resultSection = SecertClub_요소만들기('section', { class: 'wml-section' });
            resultSection.append(SecertClub_요소만들기('h3', {}, '손님 승인 리스트'));
            const approved = data.prepared.approved || [];
            const rejected = data.prepared.rejected || [];
            resultSection.append(SecertClub_요소만들기('p', {}, approved.length ? `참여 승인: ${approved.map(item => `${item.name} (${item.chance}%, ${item.hostName})`).join(', ')}` : '참여를 승인한 손님이 없습니다.'));
            if (rejected.length) resultSection.append(SecertClub_요소만들기('p', { class: 'wml-muted' }, `거절: ${rejected.map(item => `${item.name} (${item.chance}%)`).join(', ')}`));
            body.append(resultSection);
          }

          const actions = SecertClub_요소만들기('div', { style: 'display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap;' });
          actions.append(
            SecertClub_버튼만들기('개점 안하기', () => { preparationDraft = null; win.close(); }),
            SecertClub_버튼만들기(draft.resultsVisible ? '승인 리스트 확인' : '개점하기', () => {
              if (draft.resultsVisible) { win.close(); return; }
              const names = draft.method === 'wife' ? SecertClub_아내선택목록읽기(current, draft.participants) : [...draft.selected];
              if (!names.length) { api.log('[비밀 클럽] 초대할 손님을 한 명 이상 골라야 합니다.'); return; }
              api.store.dispatch({ type: PREPARE_ACTION, venue: draft.venue, method: draft.method, invited: names, participants: draft.participants });
              draft.resultsVisible = true;
              win.refresh();
            }, { primary: true }),
          );
          body.append(actions);
        },
        onClose() { preparationDraft = null; },
      });
      setTimeout(() => handle?.focus?.(), 0);
    }

    function SecertClub_설정숫자행만들기(label, value, min, max, step, onChange, help = '') {
      const row = SecertClub_요소만들기('label', { style: 'display:grid;grid-template-columns:minmax(190px,1fr) 110px;gap:10px;align-items:center;margin:7px 0;' });
      const title = SecertClub_요소만들기('span', {}, label);
      if (help) title.append(SecertClub_요소만들기('small', { class: 'wml-muted', style: 'display:block;' }, help));
      const input = SecertClub_요소만들기('input', { type: 'number', min, max, step, value, style: 'width:100%;background:#16120f;color:#fff;border:1px solid #6c573d;border-radius:4px;padding:5px;' });
      input.addEventListener('change', () => { const next = SecertClub_수치제한하기(input.value, min, max); input.value = String(next); onChange(next); });
      row.append(title, input);
      return row;
    }

    function SecertClub_설정창그리기(body, win) {
      const settings = SecertClub_설정읽기();
      body.textContent = '';
      body.dataset.wmlUi = 'true';
      body.style.cssText = 'display:flex;flex-direction:column;gap:10px;color:#eee;';
      // 다른 모드가 게임 메뉴를 최상위로 올려도 설정창을 조작할 수 있게 합니다.
      win.el.dataset.secertClubSettings = 'true';
      body.append(SecertClub_요소만들기('style', {}, '.wml-win[data-secert-club-settings]{z-index:2147483647!important}'));
      const proposal = SecertClub_요소만들기('label', { style: 'display:flex;gap:8px;align-items:center;' });
      const proposalInput = SecertClub_요소만들기('input', { type: 'checkbox', checked: settings.proposalEnabled });
      proposalInput.addEventListener('change', () => api.settings.set({ proposalEnabled: proposalInput.checked }));
      proposal.append(proposalInput, document.createTextNode("그녀의 비밀 클럽 개점 제안 여부"));
      body.append(proposal, SecertClub_설정숫자행만들기('입장료', settings.admissionFee, 0, 999, 1, value => api.settings.set({ admissionFee: value }), '승인된 손님 한 명당 받는 골드'));

      const brothelSettings = SecertClub_요소만들기('fieldset', { class: 'wml-section', 'data-secert-club-brothel-settings': '', style: 'min-width:0;' });
      const brothelActive = compatibility?.id === 'secert-club-compatible-brothel' && typeof compatibility.renderSettings === 'function';
      brothelSettings.disabled = !brothelActive;
      body.append(SecertClub_요소만들기('h3', {}, '창관 호환 설정'), brothelSettings);
      if (brothelActive) compatibility.renderSettings(brothelSettings);
      else {
        brothelSettings.style.opacity = '0.55';
        brothelSettings.append(SecertClub_설정숫자행만들기('서비스 요금 배수', 2, 1, 10, 0.1, () => {}));
        body.append(SecertClub_요소만들기('p', { class: 'wml-note' }, '비밀 클럽 · 창관 호환 모드가 실행 중일 때만 설정할 수 있습니다. 창관과 호환 모드를 켠 뒤 새로고침하세요.'));
      }

      const scoreSection = SecertClub_요소만들기('section', { class: 'wml-section' });
      scoreSection.append(SecertClub_요소만들기('h3', {}, '점수 계산식 조정'));
      scoreSection.append(
        SecertClub_설정숫자행만들기('이벤트 시작 기준 점수', settings.proposalThreshold, 0, 300, 1, value => api.settings.set({ proposalThreshold: value })),
        SecertClub_설정숫자행만들기("그녀 개점 제안 점수", settings.proposalOffset, -300, 300, 1, value => api.settings.set({ proposalOffset: value }), "그녀 점수 + 당신 감정 점수에 더합니다."),
      );
      for (const key of Object.keys(SCORE_MAX)) {
        scoreSection.append(SecertClub_설정숫자행만들기(`${SCORE_LABELS[key]} (${SCORE_MAX[key] >= 0 ? '+' : ''}${SCORE_MAX[key]}점)`, settings.scoreWeights[key], 0, 2, 0.1, value => api.settings.set({ scoreWeights: { ...SecertClub_설정읽기().scoreWeights, [key]: value } }), '가중치 0~2배'));
      }
      body.append(scoreSection);

      const visitSection = SecertClub_요소만들기('section', { class: 'wml-section' });
      visitSection.append(SecertClub_요소만들기('h3', {}, '손님 방문 계산 파라미터'));
      for (const key of Object.keys(VISIT_BASE)) {
        visitSection.append(SecertClub_설정숫자행만들기(`${VISIT_LABELS[key]} (${Math.round(VISIT_BASE[key] * 100)}%)`, settings.visitWeights[key], 0, 2, 0.1, value => api.settings.set({ visitWeights: { ...SecertClub_설정읽기().visitWeights, [key]: value } }), '가중치 0~2배'));
      }
      const relaxationRow = SecertClub_설정숫자행만들기('여성 허용 기준 완화율', settings.femaleAcceptanceRelaxation, 0, 100, 1, value => api.settings.set({ femaleAcceptanceRelaxation: value }), '개장 중 각 성적 행위의 요구 기준에 (100%-완화율)을 곱합니다. 기본 50%.');
      relaxationRow.dataset.secertClubAcceptanceRelaxation = '';
      body.append(visitSection, relaxationRow, SecertClub_설정숫자행만들기('성적 행위 부스트', settings.sexualBoost, 1, 10, 0.5, value => api.settings.set({ sexualBoost: value }), "손님과 그녀의 성적 행동 시도·주도성 1~10배"));
    }

    const proposalKind = api.events.onAlert('proposal', (state, choice) => {
      let next = SecertClub_자료쓰기(state, { unlocked: true, openSetupRequested: choice === 'prepare' });
      return api.fn('log')(next, choice === 'prepare' ? '[비밀 클럽] 개점 준비 창을 엽니다.' : '[비밀 클럽] 제안은 받아들였습니다. 준비 시간에 개장 버튼을 누르면 됩니다.');
    });

    api.actions.register(PREPARE_ACTION, (state, action) => {
      if (!SecertClub_개점가능여부(state) || state.phase !== 'prep') return api.fn('log')(state, '[비밀 클럽] 영업 준비 시간에만 개점 준비를 할 수 있습니다.');
      const venue = SecertClub_장소목록읽기(state).find(room => room.id === action.venue && room.enabled);
      if (!venue) return api.fn('log')(state, '[비밀 클럽] 사용할 수 없는 장소입니다. 시설 상태를 확인하세요.');
      const invited = [...new Set((action.invited || []).filter(name => state.patronRecords.some(record => record.name === name)))];
      const result = SecertClub_승인결과읽기(state, invited, action.participants || 'wife');
      const prepared = { day: state.day, venue: venue.id, method: action.method === 'wife' ? 'wife' : 'direct', invited, participants: action.participants || 'wife', ...result };
      const next = SecertClub_자료쓰기(state, { prepared });
      return api.fn('log')(next, result.approved.length ? `[비밀 클럽] ${result.approved.map(item => item.name).join(', ')}이(가) 초대를 받아들였습니다.` : '[비밀 클럽] 이번 초대를 받아들인 손님이 없습니다.');
    }, { label: '비밀 클럽 개점 준비' });

    api.actions.register(OPEN_ACTION, state => {
      if (SecertClub_자료읽기(state).active) return state;
      return SecertClub_클럽열기(state);
    }, { label: '비밀 클럽 개장하기' });

    api.hook('ActionButton', {
      priority: -100,
      around(next, props, ...rest) {
        const original = next(props, ...rest);
        if (!props || props.__secertClubButton) return original;
        const state = api.store.game();
        if (!state || state.phase !== 'prep' || props.label !== '일찍 문 열기' || props.time !== api.fn('actionTimes').open_tavern || !SecertClub_개점가능여부(state)) return original;
        const prepared = SecertClub_자료읽기(state).prepared;
        const ready = prepared?.day === state.day && prepared.approved?.length > 0;
        const jsx = api.fn('jsx');
        const ownProps = {
          ...props,
          __secertClubButton: true,
          label: ready ? '비밀 클럽 개장하기' : '비밀 클럽 개장',
          description: ready ? `승인 손님 ${prepared.approved.length}명을 즉시 입장시키고 비밀 영업을 시작합니다.` : '장소와 초대 손님을 정해 비밀 클럽 개점을 준비합니다.',
          secondary: !ready,
          primary: !!ready,
          onClick: ready ? () => { props.onClick?.(); api.store.dispatch({ type: OPEN_ACTION }); } : () => SecertClub_준비창열기(),
        };
        const own = jsx.jsx(api.fn('ActionButton'), ownProps, ready ? 'secert-club-open' : 'secert-club-prepare');
        return ready ? own : jsx.jsxs(jsx.Fragment, { children: [original, own] });
      },
    });

    api.hook('patronControlAttemptRoll', {
      priority: -100,
      around(next, ...args) {
        let result = next(...args);
        const state = api.store.game();
        const active = state && SecertClub_자료읽기(state).active;
        if (result || !active || !(active.guestIds || []).includes(args[0]?.customerId)) return result;
        const boost = SecertClub_설정읽기().sexualBoost;
        for (let trial = 1; trial < Math.floor(boost) && !result; trial += 1) result = next(...args);
        if (!result && Math.random() < boost % 1) result = next(...args);
        return result;
      },
    });

    api.hook('evaluateIntimacy', {
      priority: -100,
      after(result, args) {
        const [state, , context] = args;
        const active = state && SecertClub_자료읽기(state).active;
        const customerId = context?.activeCustomerId;
        const characterId = context?.characterId ?? state?.primaryCharacterId;
        if (!active || active.participants === 'workers_only' || context?.kind !== 'patron_request'
          || !(active.guestIds || []).includes(customerId) || characterId !== state.primaryCharacterId) return result;
        const wife = api.fn('wife')(state);
        if (wife?.allowRomance === false) return result;
        return SecertClub_허용판정완화하기(result);
      },
    });

    api.hook('patronControlSelfEscalationRoll', {
      priority: -100,
      around(next, ...args) {
        let result = next(...args);
        const state = api.store.game();
        const active = state && SecertClub_자료읽기(state).active;
        if (result || !active || active.participants === 'workers_only' || !(active.guestIds || []).includes(args[0]?.customerId)) return result;
        const boost = SecertClub_설정읽기().sexualBoost;
        for (let trial = 1; trial < Math.floor(boost) && !result; trial += 1) result = next(...args);
        if (!result && Math.random() < boost % 1) result = next(...args);
        return result;
      },
    });

    api.hook('buildPatronMoveCandidates', {
      priority: -100,
      after(result, args) {
        const state = api.store.game();
        const active = state && SecertClub_자료읽기(state).active;
        if (!active || !(active.guestIds || []).includes(args[1]?.customerId) || !Array.isArray(result)) return result;
        const boost = SecertClub_설정읽기().sexualBoost;
        return result.map(candidate => candidate?.move?.kind === 'hold' ? candidate : { ...candidate, weight: (candidate.weight || 0) * boost });
      },
    });

    api.hook('ejectCustomer', {
      priority: -100,
      after(result, args) {
        const id = args[1];
        const active = SecertClub_자료읽기(result).active;
        if (!active || !(active.guestIds || []).includes(id) || !result.customers.some(customer => customer.id === id && customer.status === 'gone')) return result;
        return SecertClub_자료쓰기(result, { active: { ...active, ejected: [...new Set([...(active.ejected || []), id])] } });
      },
    });

    api.hook('clubCustomerTick', { around: SecertClub_손님음주진행하기 });
    // Stable merges present/away customer processing in clubCustomerTick; wrap it once.
    api.hook('clubWifeChooseTask', { around: SecertClub_아내주문대기하기 });
    api.hook('minuteTick', { before: ([state]) => [SecertClub_웨이트리스호환진행하기(state)] });
    for (const name of ['clubPlayerGreet', 'clubPlayerOrder', 'clubPlayerServe', 'clubPlayerUnavailable']) {
      api.hook(name, { around(next, state, customerId, ...args) {
        const previous = servingCustomerId;
        servingCustomerId = SecertClub_플레이어응대가능한가(state, customerId) ? customerId : null;
        try { return next(state, customerId, ...args); } finally { servingCustomerId = previous; }
      } });
    }
    api.hook('clubPlayerInHall', { after(result, [state]) {
      return servingCustomerId !== null && SecertClub_플레이어응대가능한가(state, servingCustomerId) ? true : result;
    } });
    api.hook('clubCustomerServiceable', { after(result, [state, customer]) {
      return customer?.id === servingCustomerId && SecertClub_플레이어응대가능한가(state, customer.id) ? true : result;
    } });

    api.hook('worldTick', {
      priority: -300,
      after(result) {
        let next = SecertClub_자동제안처리하기(result);
        const data = SecertClub_자료읽기(next);
        if (!data.active && data.prepared?.day === next.day && data.prepared.approved?.length && ['service', 'last_call'].includes(next.phase)) next = SecertClub_클럽열기(next);
        return SecertClub_활성상태진행하기(next);
      },
    });

    api.hook('reduceGameAction', {
      priority: -900,
      after(result) {
        return SecertClub_활성상태진행하기(result);
      },
    });

    api.hook('wakeUp', {
      priority: -800,
      after(result) {
        let next = SecertClub_활성상태진행하기(result);
        const settings = SecertClub_설정읽기();
        let data = SecertClub_자료읽기(next);
        if (!settings.proposalEnabled || data.proposalSeen || data.unlocked || data.lastMorningRollDay === next.day || !SecertClub_기본조건충족여부(next) || SecertClub_호환조건충족여부(next)) return next;
        next = SecertClub_자료쓰기(next, { lastMorningRollDay: next.day });
        data = SecertClub_자료읽기(next);
        const wifeScore = SecertClub_아내점수읽기(next).total;
        const husbandScore = SecertClub_남편감정점수읽기(next);
        const chance = SecertClub_수치제한하기(wifeScore + husbandScore + settings.proposalOffset, 0, 100);
        const roll = SecertClub_고정난수읽기(`morning:${next.day}:${api.fn('wife')(next).name}:${wifeScore}:${husbandScore}`);
        return roll < chance ? SecertClub_제안넣기(next, 'morning') : next;
      },
    });

    api.store.subscribe(SecertClub_준비창요청처리하기);
    api.ui.settings((body, win) => SecertClub_설정창그리기(body, win));
    // 관리자 ⚙와 같은 창 ID와 렌더러를 사용해 설정창이 중복되지 않게 합니다.
    api.ui.addButton({
      label: '비밀 클럽',
      title: '비밀 클럽 설정',
      onClick: () => api.ui.window({ id: 'settings', title: 'Secert Club · 비밀 클럽 설정',
        width: 460, height: 420, render: SecertClub_설정창그리기 }),
    });

    const publicApi = {
      registerCompatibility(adapter) {
        if (!adapter || typeof adapter !== 'object') throw new Error('호환 어댑터가 필요합니다.');
        if (compatibility && compatibility.id !== adapter.id) throw new Error(`이미 ${compatibility.id} 호환 모드가 연결되어 있습니다.`);
        compatibility = adapter;
        return true;
      },
      readData: SecertClub_자료읽기,
      writeData: SecertClub_자료쓰기,
      wifeScore: SecertClub_아내점수읽기,
      husbandFeelingScore: SecertClub_남편감정점수읽기,
      guestBaseScore: SecertClub_손님기본점수읽기,
      openPreparation: SecertClub_준비창열기,
      openClub: SecertClub_클럽열기,
      closeClub: SecertClub_클럽닫기,
      settings: SecertClub_설정읽기,
      acceptanceFactor: SecertClub_허용기준배수읽기,
      relaxedThreshold: value => Number(value) * SecertClub_허용기준배수읽기(),
      relaxIntimacyResult: SecertClub_허용판정완화하기,
    };
    api.provide(publicApi);
    globalThis.__waywardSecertClubPublic = publicApi;
  },
});
