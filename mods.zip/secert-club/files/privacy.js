// Open-club room semantics are temporary; never mutate the game's shared room tags.
globalThis.SecertClub_비공개영업규칙등록하기 = function SecertClub_비공개영업규칙등록하기(api, readActive) {
  let context = null;
  function SecertClub_개장상태읽기(state) {
    const active = state && readActive(state);
    return active && active.day === state.day && !state.pmCore && !state.gameOver && state.phase !== 'bedroom' ? active : null;
  }
  function SecertClub_맥락실행하기(next, state, ...args) {
    const previous = context;
    context = state;
    try { return next(state, ...args); } finally { context = previous; }
  }
  function SecertClub_이동제안인가(event) {
    return event?.choices?.some(choice => /^(back_room_private_|upstairs_(take_him_up|she_decides|refuse)|back_round_|scenario_)/.test(choice.id || ''));
  }
  function SecertClub_영업정리하기(state) {
    const active = SecertClub_개장상태읽기(state);
    if (!active) return state;
    let next = SecertClub_이동제안인가(state.pendingEvent) ? { ...state, pendingEvent: undefined } : state;
    // Undo only a recognizable old club handoff, not sleep, rest or manual travel.
    const scene = next.activeScene?.patron;
    for (const [room, location] of Object.entries(next.locations || {})) {
      const privatePatron = location.meta?.privatePatron;
      if (!privatePatron || !(active.guestIds || []).includes(privatePatron.customerId)) continue;
      if (scene?.customerId === privatePatron.customerId && active.participants !== 'workers_only'
        && api.fn('wifeLocation')(next) === room && room !== active.venue) {
        for (const id of [api.fn('wifeId'), scene.customerId, ...(scene.joinedPatronIds || [])]) {
          if (id === api.fn('wifeId') || (active.guestIds || []).includes(id)) next = api.fn('moveOccupant')(next, id, active.venue);
        }
        next = api.fn('updateWife')(next, wife => ({ ...wife, locationUntilSlot: undefined }));
      }
      const current = next.locations[room];
      next = { ...next, locations: { ...next.locations, [room]: { ...current, meta: { ...current.meta, privatePatron: undefined } } } };
    }
    // Remove existing ordinary diners only from the reserved venue, not from other rooms.
    const outsiders = (next.customers || []).filter(customer => !(active.guestIds || []).includes(customer.id)
      && api.fn('getCustomerLocation')(next, customer.id) === active.venue);
    for (const customer of outsiders) next = api.fn('moveOccupant')(next, customer.id, 'village');
    if (outsiders.length) {
      const ids = new Set(outsiders.filter(customer => !customer.isResident).map(customer => customer.id));
      next = { ...next, customers: next.customers.map(customer => ids.has(customer.id) && customer.status !== 'gone'
        ? { ...customer, status: 'leaving' } : customer) };
    }
    return next;
  }
  // Use the actual simulation state, including direct ticks against a cloned state.
  for (const name of ['worldTick', 'minuteTick', 'reduceGameAction', 'processPatronInteractionTick',
    'buildPatronMoveCandidates', 'clubWifeChooseTask', 'clubWitnessContext']) {
    api.hook(name, { priority: -2000, around: SecertClub_맥락실행하기 });
  }
  api.hook('clubRoomFeatures', { after(result, [room]) {
    const active = SecertClub_개장상태읽기(context || api.store.game());
    if (!active || room !== active.venue) return result;
    const features = new Set(result);
    features.delete('public_floor');
    for (const tag of ['shut_door', 'seating', 'tables']) features.add(tag);
    return features;
  } });
  api.hook('clubWitnessContext', { after(result, [state, options = {}]) {
    const active = SecertClub_개장상태읽기(state);
    if (!active || active.participants === 'workers_only' || api.fn('wifeLocation')(state) !== active.venue) return result;
    const occupants = state.locations?.[active.venue]?.occupants || [];
    const allowed = new Set([api.fn('playerId'), api.fn('wifeId'), ...(active.guestIds || []), ...(active.extensionData?.workerIds || [])]);
    if (options.otherWitnesses != null || occupants.some(id => !allowed.has(id))) return result;
    return { ...result, otherWitnesses: 0, totalWitnesses: result.husbandPresent ? 1 : 0 };
  } });
  // Cancel before the original lottery: no RNG, cooldown, contract or fee is consumed.
  api.hook('normalVisitRoll', { priority: 2000, before() {
    if (SecertClub_개장상태읽기(context || api.store.game())) return { cancel: true, value: false };
  } });
  api.hook('clubOutreachRoll', { priority: 2000, before([state]) {
    if (SecertClub_개장상태읽기(state)) return { cancel: true, value: null };
  } });
  for (const name of ['clubFirstRenterArrival', 'clubSecondRenterArrival', 'clubRelativesArrival',
    'clubServiceScenarioRoll', 'clubCreatePrivateParty', 'clubInsertPrivateParty', 'clubWifeRenterVisit',
    'clubCustomerFollowWife', 'clubPartyRoundRequest', 'clubPartyRoundAuto']) {
    api.hook(name, { priority: 2000, before([state]) {
      if (SecertClub_개장상태읽기(state)) return { cancel: true, value: state };
    } });
  }
  for (const name of ['clubPrivateRoomOpen']) {
    api.hook(name, { priority: 2000, before([state]) {
      if (SecertClub_개장상태읽기(state)) return { cancel: true, value: false };
    } });
  }
  api.hook('clubStartPaidInteraction', { before([state, id, stage, options]) {
    const active = SecertClub_개장상태읽기(state);
    if (active && active.guestIds.includes(id) && options?.scene === 'patron_sex') {
      return [state, id, stage, { ...options, openText: '[비밀 클럽] 초대 손님과 지정된 클럽 공간에서 접객을 이어갑니다.' }];
    }
  } });
  for (const name of ['patronControlHerBackRoomProposal', 'patronControlPatronBackRoomProposal']) {
    api.hook(name, { priority: 2000, before([state]) {
      if (SecertClub_개장상태읽기(state)) return { cancel: true, value: { state } };
    } });
  }
  api.hook('clubResolveBackRoomProposal', { priority: 2000, before([state]) {
    if (SecertClub_개장상태읽기(state)) return { cancel: true, value: SecertClub_영업정리하기(state) };
  } });
  api.hook('clubUrgentHallService', { after(result, [state]) {
    const active = SecertClub_개장상태읽기(state);
    return active && api.fn('wifeLocation')(state) === active.venue && state.activeScene?.patron ? false : result;
  } });
  api.hook('addCustomer', { priority: 2000, before([state, customer]) {
    const active = SecertClub_개장상태읽기(state);
    if (active && !(active.guestIds || []).includes(customer?.id)) return { cancel: true, value: state };
  } });
  api.hook('moveOccupant', { priority: 2000, before([state, id, room]) {
    const active = SecertClub_개장상태읽기(state);
    if (active && room === active.venue && !(active.guestIds || []).includes(id)
      && state.customers?.some(customer => customer.id === id)) return { cancel: true, value: state };
  } });
  // A saved pending offer pauses the game clock, so clear obsolete offers even before a tick.
  let queued = false;
  function SecertClub_저장상태정리예약하기() {
    if (queued) return;
    queued = true;
    queueMicrotask(() => {
      queued = false;
      const state = api.store.game();
      if (!state) return;
      const normalized = SecertClub_영업정리하기(state);
      if (normalized !== state) api.store.update(() => normalized);
    });
  }
  api.store.subscribe(SecertClub_저장상태정리예약하기);
  SecertClub_저장상태정리예약하기();
  return { normalize: SecertClub_영업정리하기 };
};
