// H Status + 임신 연동 — WML 포팅판
// 원본: H_Status-compatible-Pregnancy.js (md5 a9af5a96178481505252c369ac13e6ab), 9-30 한글판 모드 매니저용 애드온.
// 원본 코드는 아래 setup() 안에서 그대로 실행돼요. 게임 함수 연결은 addon-compat 모드가 해 줘요.
// 이 파일은 tools/wrap-addon.mjs 로 만들었어요. 원본을 고치려면 원본을 고친 뒤 다시 만드세요.
WML.define({
  id: "h-status-pregnancy",
  name: "H Status + 임신 연동",
  version: "1.6.4",
  game: "2026-11-01",
  description: "H Status의 질내사정 기록을 임신 모드에 전달합니다.",
  requires: ["addon-compat","h-status","pregnancy"],
  loadAfter: [],
  conflicts: [],

  setup(api) {
    // ---- 원본 애드온 ----
/* Optional bridge for Wayward Situation v1.6.1 and the unmodified pregnancy addon. */
(() => {
  "use strict";
  if (globalThis.__WAYWARD_SITUATION_COMPAT_LOADED__) return;
  globalThis.__WAYWARD_SITUATION_COMPAT_LOADED__ = true;

  const STATE_KEY = "wc2PregnancyBirthMode265";
  const OPTIONS_KEY = "wc2-pregnancy-birth-options-v1";
  const MAX_SEEN = 120;
  let api = null;
  let writing = false;

  function pregnancyEnabled() {
    try { return JSON.parse(localStorage.getItem(OPTIONS_KEY) || "{}").enabled !== false; }
    catch { return true; }
  }

  function eligible(event) {
    return event?.eventCategory === "hotel_affair" && event?.act === "sex" &&
      event?.condomUsed === false && event?.ejaculation === "inside" &&
      typeof event?.completionId === "string" && event.completionId.length > 0;
  }

  function normalize(raw, day) {
    const source = raw && typeof raw === "object" ? raw : {};
    return {
      ...source,
      version: Math.max(2, Number(source.version) || 0),
      lastMorningDay: Number.isFinite(source.lastMorningDay) ? source.lastMorningDay : Math.max(0, (Number(day) || 1) - 1),
      pausedAtDay: Number.isFinite(source.pausedAtDay) ? source.pausedAtDay : null,
      spermDeposits: Array.isArray(source.spermDeposits) ? source.spermDeposits : [],
      pregnancy: source.pregnancy || null,
      birthLog: Array.isArray(source.birthLog) ? source.birthLog : [],
      seenFinishes: Array.isArray(source.seenFinishes) ? source.seenFinishes.map(String).slice(-MAX_SEEN) : []
    };
  }

  function sync() {
    if (writing || !pregnancyEnabled()) return;
    const root = api?.ue?.getState?.();
    const state = root?.state;
    if (!state) return;
    const events = (state.awayEvents || []).filter(eligible);
    if (!events.length) return;
    const data = normalize(state[STATE_KEY], state.day);
    let changed = false;
    for (const event of events) {
      const fingerprint = `situation:${event.completionId}`;
      if (data.seenFinishes.includes(fingerprint)) continue;
      data.seenFinishes = [...data.seenFinishes, fingerprint].slice(-MAX_SEEN);
      data.spermDeposits = [...data.spermDeposits, {
        id: `sperm:${fingerprint}`,
        day: Number(state.day) || 1,
        slot: Number(event.slot ?? state.slot) || 0,
        amount: 1 + Math.floor(Math.random() * 50),
        sourceId: String(event.patronId || event.patronName || "patron"),
        sourceName: String(event.patronName || event.patronId || "손님")
      }];
      changed = true;
    }
    if (!changed) return;
    writing = true;
    try {
      api.ue.setState(current => current?.state === state
        ? { ...current, state: { ...state, [STATE_KEY]: data } }
        : current);
    } finally { writing = false; }
  }

  function init() {
    if (api || !globalThis.__WAYWARD_PREGNANCY_ADDON_LOADED__ || !globalThis.__WAYWARD_ADDON_API__ || !globalThis.__waywardSituationEventMod) return false;
    api = globalThis.__WAYWARD_ADDON_API__;
    if (!api.ue?.getState || !api.ue?.subscribe || !api.ue?.setState) return false;
    api.ue.subscribe(sync);
    sync();
    globalThis.__waywardSituationCompatibility = Object.freeze({ version: "1.8", syncPregnancy: sync });
    return true;
  }

  if (!init()) {
    let attempts = 0;
    const timer = setInterval(() => { if (init() || ++attempts > 240) clearInterval(timer); }, 250);
  }
})();

  },
});
