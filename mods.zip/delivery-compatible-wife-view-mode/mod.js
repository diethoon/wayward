// 호환성 패치 기준: delivery 5.3.2 / wife-view-mode 0.10.1 (개정 기준, 버전 번호에 따른 실행 제한 없음)
// 생성 파일. 수정: source/mod.wml.js, source/legacy-guard.js
// 구형 아내 시점의 자동 처리만 필요한 구간에서 잠시 중지하고, 저장된 활성 상태를 복원합니다.
WML.define({
  tags: ["content"],
  id: 'delivery-compatible-wife-view-mode',
  author: "Hina_Lover",
  name: "배달의 민족 - 아내 시점 호환 패치",
  version: "1.0.4",
  game: "2026-11-01",
  requires: ['delivery', 'wife-view-mode'],
  description: "배달 담당자는 직접 선택하고, 아내 배달은 뒷방처럼 자동 진행합니다. 구형 아내 시점도 배달 후 복원합니다.",
  setup(api) {
// 호환성 패치 기준: delivery 5.3.2 / wife-view-mode 0.10.1 (개정 기준, 버전 번호에 따른 실행 제한 없음)
// 생성 파일. 수정: source/mod.wml.js, source/legacy-guard.js
// 구형 아내 시점의 자동 처리만 필요한 구간에서 잠시 중지하고, 저장된 활성 상태를 복원합니다.
(() => {
  if (globalThis.__waywardWifeViewLegacyGuard) return;
  const rules = new Map();
  let store = null, writing = false, unsubscribe = null;
  function WifeViewLegacyGuard_상태정리하기() {
    if (writing || !store) return;
    const state = store.game();
    if (!state) return;
    const view = state.mods?.['wife-view-mode'] || {};
    const saved = view.portableCompatibility;
    const owners = [...rules].filter(([, rule]) => rule(state)).map(([id]) => id).sort();
    if (!saved && (!owners.length || view.active !== true)) return;
    if (saved && owners.length && view.active === false && JSON.stringify(saved.owners) === JSON.stringify(owners)) return;
    const nextView = owners.length
      ? { ...view, active: false, portableCompatibility: { wasActive: saved?.wasActive ?? view.active, owners } }
      : { ...view, active: saved.wasActive === true };
    if (!owners.length) delete nextView.portableCompatibility;
    writing = true;
    try { store.update(current => ({ ...current, mods: { ...current.mods, 'wife-view-mode': nextView } })); }
    finally { writing = false; }
  }
  function WifeViewLegacyGuard_등록하기(owner, api, rule) {
    rules.set(owner, rule);
    if (!store) { store = api.store; unsubscribe = store.subscribe(WifeViewLegacyGuard_상태정리하기); }
    WifeViewLegacyGuard_상태정리하기();
    return () => { rules.delete(owner); WifeViewLegacyGuard_상태정리하기(); };
  }
  window.addEventListener('pagehide', () => unsubscribe?.(), { once: true });
  globalThis.__waywardWifeViewLegacyGuard = { register: WifeViewLegacyGuard_등록하기,
    reconcile: WifeViewLegacyGuard_상태정리하기 };
})();

// 호환성 패치 기준: delivery 5.3.2 / wife-view-mode 0.10.1 (개정 기준, 버전 번호에 따른 실행 제한 없음)

Object.assign(globalThis,{});

    const delivery = globalThis.__waywardDeliveryAddon;
    for (const key of ['ownsScene', 'ownsOrder', 'getSession', 'accept']) {
      if (typeof delivery?.[key] !== 'function') throw new Error('Delivery의 배달 연결 기능이 없습니다. Delivery 5.2.0 폴더를 함께 설치하세요.');
    }
    function DeliveryCompatibleWifeView_아내소유확인하기(state) {
      const session = state?.deliveryAddon?.activeDelivery;
      return session?.who === 'wife' && session.characterId === state.primaryCharacterId;
    }
    function DeliveryCompatibleWifeView_구형구간확인하기(state) {
      if (globalThis.__waywardWifeViewCompatibility?.delivery === true) return false;
      return DeliveryCompatibleWifeView_아내소유확인하기(state) || delivery.ownsOrder(state);
    }
    globalThis.__waywardDeliveryCompatibleWifeView = {
      ownsWife: DeliveryCompatibleWifeView_아내소유확인하기,
      ownsScene: state => delivery.ownsScene(state),
      ownsOrder: state => delivery.ownsOrder(state),
      getStatus: () => ({ legacyFallback: globalThis.__waywardWifeViewCompatibility?.delivery !== true })
    };
    globalThis.__waywardWifeViewLegacyGuard.register(api.id, api, DeliveryCompatibleWifeView_구형구간확인하기);
  }
});
