// 구형 아내 시점의 자동 처리만 필요한 구간에서 잠시 중지하고, 저장된 활성 상태를 복원합니다.
(() => {
  if (globalThis.__waywardWifeViewLegacyGuard) return;
  const rules = new Map();
  let store = null, writing = false, unsubscribe = null;
  function WifeViewLegacyGuard_상태정리하기() {
    if (writing || !store) return;
    const state = store.game();
    if (!state) return;
    const view = state.mods?.['wife-view-mode'] || {};
    const saved = view.portableCompatibility;
    const owners = [...rules].filter(([, rule]) => rule(state)).map(([id]) => id).sort();
    if (!saved && (!owners.length || view.active !== true)) return;
    if (saved && owners.length && view.active === false && JSON.stringify(saved.owners) === JSON.stringify(owners)) return;
    const nextView = owners.length
      ? { ...view, active: false, portableCompatibility: { wasActive: saved?.wasActive ?? view.active, owners } }
      : { ...view, active: saved.wasActive === true };
    if (!owners.length) delete nextView.portableCompatibility;
    writing = true;
    try { store.update(current => ({ ...current, mods: { ...current.mods, 'wife-view-mode': nextView } })); }
    finally { writing = false; }
  }
  function WifeViewLegacyGuard_등록하기(owner, api, rule) {
    rules.set(owner, rule);
    if (!store) { store = api.store; unsubscribe = store.subscribe(WifeViewLegacyGuard_상태정리하기); }
    WifeViewLegacyGuard_상태정리하기();
    return () => { rules.delete(owner); WifeViewLegacyGuard_상태정리하기(); };
  }
  window.addEventListener('pagehide', () => unsubscribe?.(), { once: true });
  globalThis.__waywardWifeViewLegacyGuard = { register: WifeViewLegacyGuard_등록하기,
    reconcile: WifeViewLegacyGuard_상태정리하기 };
})();
