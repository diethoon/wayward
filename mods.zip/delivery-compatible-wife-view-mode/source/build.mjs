// 실행: node wml/mods/<호환 모드>/source/build.mjs
import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import {fileURLToPath} from 'node:url';
const dir=path.dirname(fileURLToPath(import.meta.url));
const code=fs.readFileSync(new URL('mod.wml.js', import.meta.url), 'utf8').split(/\r?\n/)[0] + '\n' + '// 생성 파일. 수정: source/mod.wml.js, source/legacy-guard.js\n'+fs.readFileSync(path.join(dir,'legacy-guard.js'),'utf8')+'\n'+fs.readFileSync(path.join(dir,'mod.wml.js'),'utf8');
new vm.Script(code);fs.writeFileSync(path.join(dir,'../mod.js'),Pre7_lazySetup(code));console.log('Generated '+path.join(dir,'../mod.js'));

// pre7: loading a disabled mod must not initialize globals or change settings.
function Pre7_lazySetup(source){
  const at=source.indexOf('WML.define({');if(at<0)throw Error('WML definition missing');
  const prefix=source.slice(0,at);if(!prefix.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*/g,'').trim())return source;
  const header=prefix.match(/^(?:\s|\/\*[\s\S]*?\*\/|\/\/[^\n]*(?:\n|$))*/)[0];
  let found=false;
  const result=header+source.slice(at).replace(/((?:async\s+)?setup\([^)]*\)\s*\{)/,match=>{found=true;return match+'\n'+prefix+'\nObject.assign(globalThis,{});\n';});
  if(!found)throw Error('setup declaration missing');return result;
}
