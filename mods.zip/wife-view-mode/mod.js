// 생성 파일. 수정: source/mod.wml.js, source/native-ui.js — 재생성: node wml/mods/wife-view-mode/source/build.mjs
// 각 모드에 포함되는 설정 UI. 게임 HTML의 메뉴와 DOM만 사용합니다.
WML.define({
  tags: ["content"],
  id: 'wife-view-mode',
  author: "Hina_Lover",
  name: "여성 시점 모드",
  version: "0.10.4",
  description: "여성 시점 플레이, 관계·성향 기반 주인공 반응, 개장 전 물품·시설 관리를 추가합니다.",
  game: "2026-11-01",
  lang: 'ko',
  loadAfter: ['waitress'],
  // mod symbols (tools/mod-symbols.mjs / MCP symbol_add keep this block; data only)
  symbols: {
    "WifeViewModeRelationshipContext": {"raw":{"2026-11-01":"ld"},"doc":"현재 두 주인공 사이의 관계 호칭 정보"},
    "WifeViewModeGameShell": {"raw":{"2026-11-01":"Iit"},"doc":"Main game shell component."},
    "WifeViewModeQualityUpgrades": {"raw":{"2026-11-01":"U7"},"doc":"Facility quality upgrade definitions."},
    "WifeViewModeLocationOverview": {"raw":{"2026-11-01":"hat"},"doc":"Current-location overview and room movement cards."},
    "WifeViewModeWifeAI": {"raw":{"2026-11-01":"Kje"},"doc":"Wife autonomous tavern-service decision step."},
    "WifeViewModeWifeGreet": {"raw":{"2026-11-01":"Xje"},"doc":"Wife greets a patron using the native service mechanic."},
    "WifeViewModeWifeTakeOrder": {"raw":{"2026-11-01":"Zje"},"doc":"Wife takes a patron order using the native service mechanic."},
    "WifeViewModeWifeServe": {"raw":{"2026-11-01":"tEe"},"doc":"Wife serves a patron using the native service mechanic."},
    "WifeViewModeOutOfStock": {"raw":{"2026-11-01":"$K"},"doc":"Native out-of-stock response shared by player and wife service."},
    "WifeViewModeDaresAvailable": {"raw":{"2026-11-01":"aC"},"doc":"Filters the native wife dare list for the current state."},
    "WifeViewModeDareTargets": {"raw":{"2026-11-01":"Vb"},"doc":"Lists valid patrons for a native wife dare."},
    "WifeViewModeMoveCustomer": {"raw":{"2026-11-01":"lo"},"doc":"Moves a patron through the native location registry."},
    "WifeViewModeStartPatronInteraction": {"raw":{"2026-11-01":"Xo"},"doc":"Starts the native wife-patron interaction scene."},
    "WifeViewModeResolveCardHand": {"raw":{"2026-11-01":"Zqe"},"doc":"Resolves one native card-table hand."},
    "WifeViewModeCardScore": {"raw":{"2026-11-01":"l$"},"doc":"Calculates a participant score for a native card hand."},
    "WifeViewModeWaitControls": {"raw":{"2026-11-01":"Ui"},"doc":"Native wait controls with 1, 5, 15 minutes and until-customer actions."},
    "WifeViewModeConversationMenu": {"raw":{"2026-11-01":"Su"},"doc":"Builds the native wife conversation menu, including clothing choices."},
    "WifeViewModeApplyOutcome": {"raw":{"2026-11-01":"ft"},"doc":"Applies native wife conversation stat, trait, relationship and effect deltas."},
    "WifeViewModeApplySceneOutcome": {"raw":{"2026-11-01":"L0"},"doc":"Applies native outfit, exposure and scene changes from a wife conversation outcome."},
    "WifeViewModeJoinCandidates": {"raw":{"2026-11-01":"MR"},"doc":"Lists native eligible patrons who can join the current patron scene."},
    "WifeViewModeJoinWilling": {"raw":{"2026-11-01":"tye"},"doc":"Runs the native willingness check for a patron invited into a group scene."},
    "WifeViewModePatronFinishChoice": {"raw":{"2026-11-01":"Ix"},"doc":"Selects the native patron climax result for the current sexual stage."},
    "WifeViewModeEndPatronInteraction": {"raw":{"2026-11-01":"Rt"},"doc":"Ends a native patron interaction and applies its normal aftermath and cleanup."},
    "WifeViewModeOpposedCheck": {"raw":{"2026-11-01":"el"},"doc":"Runs the native opposed attribute check used for a wife's breakaway attempt."},
    "WifeViewModeApplyPlayerTavernAction": {"raw":{"2026-11-01":"uet"},"doc":"Applies one native player tavern-service action without advancing time."},
    "WifeViewModeHusbandNextTavernAction": {"raw":{"2026-11-01":"RW"},"doc":"Selects the next native player tavern-service action for husband automation."},
    "WifeViewModeScenePresentation": {"raw":{"2026-11-01":"Wg"},"doc":"Scoped wife-view scene presentation and private room transition boundaries."},
    "WifeViewModePrivateBackRoomStart": {"raw":{"2026-11-01":"Qa"},"doc":"Scoped wife-view scene presentation and private room transition boundaries."},
    "WifeViewModeRenterUpstairsStart": {"raw":{"2026-11-01":"cK"},"doc":"Scoped wife-view scene presentation and private room transition boundaries."},
    "WifeViewModePrivateBathroomStart": {"raw":{"2026-11-01":"NJ"},"doc":"Scoped wife-view scene presentation and private room transition boundaries."},
    "WifeViewModeRestStart": {"raw":{"2026-11-01":"iy"},"doc":"Wife-view manual autonomy and off-hours interaction boundaries."},
    "WifeViewModeAgencyTick": {"raw":{"2026-11-01":"hW"},"doc":"Wife-view manual autonomy and off-hours interaction boundaries."},
    "WifeViewModeOffHoursPatronTick": {"raw":{"2026-11-01":"uQe"},"doc":"Wife-view manual autonomy and off-hours interaction boundaries."},
    "WifeViewModeImageKey": {"raw":{"2026-11-01":"bee"},"doc":"Effective image request key derived from the current scene and wife room."},
    "WifeViewModePortrait": {"raw":{"2026-11-01":"rv"},"doc":"Wife-view portrait refresh at scene and room boundaries."},
    "WifeViewModeFocusColumn": {"raw":{"2026-11-01":"Yrt"},"doc":"Wife-view portrait refresh at scene and room boundaries."},
    "WifeViewModeLayout": {"raw":{"2026-11-01":"gat"},"doc":"Wife-view portrait refresh at scene and room boundaries."},
    "WifeViewModeEventOverlay": {"raw":{"2026-11-01":"Sat"},"doc":"Wife-view portrait refresh at scene and room boundaries."},
    "WifeViewModeShopCustomer": {"raw":{"2026-11-01":"PB"},"doc":"Wife-view shop service routing, offline image fallback, safe night completion and scene diagnostics."},
    "WifeViewModeServiceButton": {"raw":{"2026-11-01":"O5"},"doc":"Wife-view shop service routing, offline image fallback, safe night completion and scene diagnostics."},
    "WifeViewModeServeControl": {"raw":{"2026-11-01":"ist"},"doc":"Wife-view shop service routing, offline image fallback, safe night completion and scene diagnostics."},
    "WifeViewModeImageLookup": {"raw":{"2026-11-01":"vy"},"doc":"Wife-view shop service routing, offline image fallback, safe night completion and scene diagnostics."},
    "WifeViewModeImageUrl": {"raw":{"2026-11-01":"o_"},"doc":"Wife-view shop service routing, offline image fallback, safe night completion and scene diagnostics."},
    "WifeViewModeMinuteOfDay": {"raw":{"2026-11-01":"dn"},"doc":"Wife-view shop service routing, offline image fallback, safe night completion and scene diagnostics."},
    "WifeViewModeNightCloseSlot": {"raw":{"2026-11-01":"Mc"},"doc":"Wife-view shop service routing, offline image fallback, safe night completion and scene diagnostics."},
    "WifeViewModeMinutesPerDay": {"raw":{"2026-11-01":"h_"},"doc":"Wife-view shop service routing, offline image fallback, safe night completion and scene diagnostics."},
    "WifeViewModeTavernDay": {"raw":{"2026-11-01":"pt"},"doc":"Wife-view shop service routing, offline image fallback, safe night completion and scene diagnostics."},
    "WifeViewModeEndDay": {"raw":{"2026-11-01":"xm"},"doc":"Wife-view shop service routing, offline image fallback, safe night completion and scene diagnostics."},
    "WifeViewModeSleep": {"raw":{"2026-11-01":"yet"},"doc":"Wife-view shop service routing, offline image fallback, safe night completion and scene diagnostics."},
    "WifeViewModeBreakForService": {"raw":{"2026-11-01":"UC"},"doc":"Wife-view shop service routing, offline image fallback, safe night completion and scene diagnostics."},
    "WifeViewModeSatiety": {"raw":{"2026-11-01":"ud"},"doc":"Wife-view shop service routing, offline image fallback, safe night completion and scene diagnostics."},
    "WifeViewModeRetire": {"raw":{"2026-11-01":"cm"},"doc":"Wife-view shop service routing, offline image fallback, safe night completion and scene diagnostics."},
    "WifeViewModeBackRoomOrder": {"raw":{"2026-11-01":"Q$e"},"doc":"Wife-view service order choices with native stock, payment and toilet visit mechanics."},
    "WifeViewModeBackRoomOutcome": {"raw":{"2026-11-01":"xV"},"doc":"Wife-view service order choices with native stock, payment and toilet visit mechanics."},
    "WifeViewModeBackRoomEnter": {"raw":{"2026-11-01":"TV"},"doc":"Wife-view service order choices with native stock, payment and toilet visit mechanics."},
    "WifeViewModeBackRoomAutoOrder": {"raw":{"2026-11-01":"Z$e"},"doc":"Wife-view service order choices with native stock, payment and toilet visit mechanics."},
    "WifeViewModeBackRoomWifeAvailable": {"raw":{"2026-11-01":"Dx"},"doc":"Wife-view service order choices with native stock, payment and toilet visit mechanics."},
    "WifeViewModeServiceEventResolve": {"raw":{"2026-11-01":"DXe"},"doc":"Wife-view service order choices with native stock, payment and toilet visit mechanics."},
    "WifeViewModeToiletRequest": {"raw":{"2026-11-01":"bPe"},"doc":"Wife-view service order choices with native stock, payment and toilet visit mechanics."},
    "WifeViewModeToiletAddressee": {"raw":{"2026-11-01":"pPe"},"doc":"Wife-view service order choices with native stock, payment and toilet visit mechanics."},
    "WifeViewModeToiletKnown": {"raw":{"2026-11-01":"fPe"},"doc":"Wife-view service order choices with native stock, payment and toilet visit mechanics."},
    "WifeViewModeToiletResolve": {"raw":{"2026-11-01":"n6"},"doc":"Wife-view service order choices with native stock, payment and toilet visit mechanics."},
    "WifeViewModeToiletVisit": {"raw":{"2026-11-01":"jp"},"doc":"Wife-view service order choices with native stock, payment and toilet visit mechanics."},
    "WifeViewModeHusbandInTavern": {"raw":{"2026-11-01":"yt"},"doc":"Native in-tavern availability check for husband service requests."}
  },

  setup(wmlApi) {
// 생성 파일. 수정: source/mod.wml.js, source/native-ui.js — 재생성: node wml/mods/wife-view-mode/source/build.mjs
// 각 모드에 포함되는 설정 UI. 게임 HTML의 메뉴와 DOM만 사용합니다.
(() => {
  if (globalThis.__waywardPauseSettingsUiFactory?.version === 1) return;
  const entries = new Map(), windows = new Map();
  const legacyButtons = '[data-wc2-preg-menu],[data-wc2-customer-menu],.ww-brothel-menu-button,[data-bad-guest-settings-launch],[data-ww-image-studio-menu]';
  let queued = false, theme = null;
  const cssValues = new Map(), cssProbe = document.createElement('div').style;

  function ModNativeUI_요소만들기(tag, props, ...children) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(props || {})) {
      if (value == null || value === false) continue;
      if (key === 'class') node.className = value;
      else if (key === 'style') node.style.cssText = value;
      else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2).toLowerCase(), value);
      else if (key in node && key !== 'list') node[key] = value;
      else node.setAttribute(key, value === true ? '' : String(value));
    }
    for (const child of children.flat()) if (child != null && child !== false) node.append(child.nodeType ? child : String(child));
    return node;
  }
  // WML 0.9.5 owns pause-menu placement through api.ui.pauseSettings.
  function ModNativeUI_메뉴찾기() { return []; }
  function ModNativeUI_스타일지정하기(node, property, value) {
    const key = property + ':' + value;
    if (!cssValues.has(key)) { cssProbe.setProperty(property, value); cssValues.set(key, cssProbe.getPropertyValue(property)); }
    if (node.style.getPropertyValue(property) !== cssValues.get(key) || node.style.getPropertyPriority(property) !== 'important') node.style.setProperty(property, value, 'important');
  }
  function ModNativeUI_테마읽기(button) {
    const native = getComputedStyle(button || document.getElementById('root') || document.body);
    const channels = (native.backgroundColor.match(/[\d.]+/g) || [28, 25, 23]).slice(0, 3).map(Number);
    const luminance = Math.max(.09, Math.min(.22, (Math.max(...channels) + Math.min(...channels)) / 510));
    return { font: native.fontFamily || 'sans-serif', background: `hsl(32 52% ${Math.round(luminance * 100 + 4)}%)`,
      foreground: 'hsl(40 78% 88%)', border: 'hsl(32 55% 34%)', radius: native.borderRadius || '6px' };
  }
  function ModNativeUI_버튼색칠하기(button, settings) {
    const colors = theme = ModNativeUI_테마읽기(settings);
    for (const [key, value] of Object.entries({ background: colors.background, color: colors.foreground,
      'border-color': colors.border, 'border-width': '1px', 'border-style': 'solid', 'border-radius': colors.radius,
      width: '100%', padding: '8px 16px', 'font-family': colors.font, 'font-size': '14px', cursor: 'pointer' })) ModNativeUI_스타일지정하기(button, key, value);
  }
  function ModNativeUI_앞으로올리기(node) {
    ModNativeUI_스타일지정하기(node, 'z-index', '2147483647');
    if (node.parentElement === document.body && node.nextElementSibling) document.body.append(node);
  }
  function ModNativeUI_정리하기() {
    for (const { list, settings } of ModNativeUI_메뉴찾기()) {
      let anchor = settings;
      for (const [owner, entry] of entries) {
        const official = [...list.querySelectorAll('[data-wml-pause-entry]')].find(node => node.dataset.wmlPauseEntry === owner);
        if (official) {
          for (const old of [...list.children]) if (old !== official &&
            (old.dataset.waywardNativeSettings === owner || entry.legacyButton && old.matches(entry.legacyButton))) old.remove();
          anchor = official;
          continue;
        }
        let button = [...list.children].find(node => node.dataset.waywardNativeSettings === owner);
        if (!button && entry.legacyButton) button = list.querySelector(entry.legacyButton);
        if (!button) {
          button = ModNativeUI_요소만들기('button', { type: 'button', class: settings.className,
            'data-wayward-native-settings': owner, ...entry.attributes,
            class: `${settings.className} ${entry.attributes?.class || ''}`.trim() }, entry.label);
          button.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); entry.onClick?.();
            queueMicrotask(() => entry.windowSelector && document.querySelectorAll(entry.windowSelector).forEach(ModNativeUI_앞으로올리기)); });
          list.append(button);
        }
        button.dataset.waywardNativeSettings = owner;
        // 이 표시는 새 로더의 기존 버튼 정렬과도 같은 순서를 유지하게 합니다.
        // 구형 로더에서는 사용하지 않아도 HTML 메뉴가 직접 처리됩니다.
        button.dataset.wmlModSettings = owner;
        ModNativeUI_버튼색칠하기(button, settings);
        if (button.textContent !== entry.label) button.textContent = entry.label;
        if (anchor.nextElementSibling !== button) anchor.after(button);
        anchor = button;
      }
      const panel = list.parentElement;
      if (panel.style.maxHeight !== 'calc(100dvh - 32px)') panel.style.maxHeight = 'calc(100dvh - 32px)';
      if (panel.style.overflowY !== 'auto') panel.style.overflowY = 'auto';
    }
    for (const entry of entries.values()) if (entry.windowSelector) {
      for (const panel of document.querySelectorAll(entry.windowSelector)) {
        ModNativeUI_스타일지정하기(panel, 'z-index', '2147483647');
      }
    }
  }
  function ModNativeUI_정리예약하기() {
    if (queued) return;
    queued = true;
    queueMicrotask(() => { queued = false; ModNativeUI_정리하기(); });
  }
  function ModNativeUI_버튼만들기(label, onClick, options = {}) {
    return ModNativeUI_요소만들기('button', { type: 'button', class: 'wayward-native-button',
      title: options.title, disabled: options.disabled, onclick: onClick,
      style: options.primary ? 'background:#78350f;color:#fef3c7' : '' }, label);
  }
  function ModNativeUI_창열기(owner, options) {
    const id = `${owner}:${options.id || 'settings'}`;
    if (windows.has(id)) { const prior = windows.get(id); prior.focus(); return prior; }
    const colors = theme || ModNativeUI_테마읽기();
    const width = Math.min(options.width || 520, Math.max(280, innerWidth - 16));
    const height = Math.min(options.height || 440, Math.max(160, innerHeight - 16));
    const title = ModNativeUI_요소만들기('strong', {}, options.title || owner);
    const body = ModNativeUI_요소만들기('div', { class: 'wayward-native-window-body' });
    const node = ModNativeUI_요소만들기('section', { class: 'wayward-native-window', role: 'region',
      'aria-label': options.title || owner, 'data-wml-ui': owner, 'data-wayward-native-window': id,
      style: `left:${Math.max(8, (innerWidth - width) / 2)}px;top:${Math.max(8, (innerHeight - height) / 3)}px;width:${width}px;height:${height}px;font-family:${colors.font}` });
    let removeBack = null;
    function ModNativeUI_창닫기() { node.remove(); windows.delete(id); removeBack?.(); options.onClose?.(); }
    const bar = ModNativeUI_요소만들기('header', { class: 'wayward-native-window-title' }, title,
      ModNativeUI_버튼만들기('✕', ModNativeUI_창닫기, { title: '닫기' }));
    node.append(bar, body);
    const handle = { el: node, body, owner, close: ModNativeUI_창닫기,
      focus: () => {
        ModNativeUI_앞으로올리기(node); windows.delete(id); windows.set(id, handle);
        if (typeof options.onBack === 'function') {
          removeBack?.(); removeBack = options.onBack(() => { handle.close(); return true; });
        }
      }, setTitle: value => { title.textContent = value; },
      refresh: () => { body.replaceChildren(); options.render?.(body, handle); } };
    node.addEventListener('pointerdown', handle.focus);
    bar.addEventListener('pointerdown', event => {
      if (event.button !== 0 || event.target.closest('button')) return;
      event.preventDefault();
      const x = event.clientX - node.offsetLeft, y = event.clientY - node.offsetTop;
      const move = next => { node.style.left = Math.max(0, Math.min(innerWidth - 80, next.clientX - x)) + 'px'; node.style.top = Math.max(0, Math.min(innerHeight - 40, next.clientY - y)) + 'px'; };
      const stop = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', stop); };
      window.addEventListener('pointermove', move); window.addEventListener('pointerup', stop, { once: true });
    });
    windows.set(id, handle); document.body.append(node); handle.focus(); handle.refresh();
    return handle;
  }
  const style = ModNativeUI_요소만들기('style', { 'data-wayward-native-ui': '1' });
  style.textContent = `
    .wayward-native-window{position:fixed;display:flex;flex-direction:column;font-size:14px;max-width:calc(100vw - 16px);max-height:calc(100dvh - 16px);min-width:280px;min-height:160px;resize:both;overflow:hidden;background:#1c1917;color:#e7e5e4;border:1px solid #92400e;border-radius:9px;box-shadow:0 14px 44px #000c}
    .wayward-native-window-title{display:flex;align-items:center;gap:8px;padding:8px 10px;background:#292524;border-bottom:1px solid #44403c;cursor:move;touch-action:none}.wayward-native-window-title strong{flex:1;font-size:14px}.wayward-native-window-body{flex:1;overflow:auto;padding:12px}
    .wayward-native-button{border:1px solid #57534e;border-radius:6px;padding:6px 10px;background:#292524;color:#e7e5e4;cursor:pointer;font:inherit}.wayward-native-button:disabled{opacity:.45;cursor:default}
    .wayward-native-window .wml-muted{color:#a8a29e}.wayward-native-window .wml-note{color:#fde68a}.wayward-native-window .wml-small{font-size:12px}
    @media(max-width:640px){.wayward-native-window{left:8px!important;top:8px!important;width:calc(100vw - 16px)!important;height:calc(100dvh - 16px)!important;resize:none}}
  `;
  document.head.append(style);
  const observer = new MutationObserver(ModNativeUI_정리예약하기);
  observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'hidden', 'class'] });
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape' || !windows.size) return;
    [...windows.values()].at(-1).close(); event.preventDefault(); event.stopImmediatePropagation();
  }, true);
  window.addEventListener('pagehide', () => observer.disconnect(), { once: true });
  function ModNativeUI_연결하기(base, config) {
    const owner = config.id, raw = name => config.bindings?.[base.game]?.[name] || name;
    const resolve = name => {
      const candidate = raw(name);
      if (base.engine && candidate in base.engine) return candidate;
      return base.sym(name);
    };
    const registerMenu = options => { entries.set(owner, options); return base.ui.pauseSettings({ ...options, attributes: { ...options.attributes, 'data-wayward-native-settings': owner }, onClick: () => { options.onClick?.(); queueMicrotask(() => options.windowSelector && document.querySelectorAll(options.windowSelector).forEach(ModNativeUI_앞으로올리기)); } }); };
    const ui = { ...base.ui,
      h: ModNativeUI_요소만들기, button: ModNativeUI_버튼만들기,
      window: options => ModNativeUI_창열기(owner, { ...options, onBack: base.onBack }),
      settings: render => {
        base.ui.settings(render);
        registerMenu({ label: config.label, onClick: () => ModNativeUI_창열기(owner,
          { id: 'settings', title: config.label, render, onBack: base.onBack }) }); ModNativeUI_정리예약하기();
      },
      menuSettings: registerMenu,
    };
    const facade = { ...base, ui,
      fn: name => base.engine?.[resolve(name)], sym: resolve,
      has: name => { try { return !!resolve(name); } catch { return false; } },
      hook: (name, options) => base.hook(resolve(name), options),
      onBack: typeof base.onBack === 'function' ? base.onBack : () => () => {},
    };
    if (config.legacy) ui.menuSettings(config.legacy);
    return facade;
  }
  globalThis.__waywardPauseSettingsUiFactory = { version: 1, connect: ModNativeUI_연결하기 };
})();


Object.assign(globalThis,{});

    const api = globalThis.__waywardPauseSettingsUiFactory.connect(wmlApi, {"id":"wife-view-mode","label":"여성 시점 모드 설정","bindings":{"2026-10-04":{"store":"ae","settingsStore":"At","React":"Z","jsx":"u","ActionButton":"Ze","ActionPanel":"aO","wife":"_","updateWife":"O","updateCharacter":"nn","log":"N","tick":"Jt","intoxLabel":"In","playerId":"fe","wifeId":"Re","locationOf":"$e","wifeLocation":"_e","playerLocation":"bt","moveOccupant":"Pt","patronScene":"Y","playerSexScene":"Le","setScene":"MV","patronSceneLocation":"tt","isSexualStage":"it","sceneDef":"ls","sceneOutfitState":"bx","garmentWorn":"vr","exposureSummary":"nf","patronWatchChoices":"Xae","patronChoice":"tNe","startPlayerSex":"_p","playerSexEvent":"Fl","ensureHusbandLed":"F8","addJoinedPatron":"nfe","joinSlots":"NH","registerAlert":"nr","queueAlert":"gn","drainAlerts":"gl","imagePrompt":"r8","imageKey":"s8","imageKeyOf":"n8","imageDescriptor":"o8","makeCustomer":"ff","addCustomer":"Ka","carryToBed":"RDe","talkToWife":"EF","actionTimes":"Oo","addFeeling":"we","addIdentityStrainFromPatronAct":"Kf","getCustomerLocation":"Yn","getEffectiveAttributes":"B","heroineConditioningMax":"QX","heroineDriveCalc":"si","moveWife":"pt","outfits":"fh","patronControlCustomerLocation":"ht","wifeById":"ul","wifePreview":"gue","reduceGameAction":"wT","brothelLog":"hs","decisionCategories":"bo","decisionResolve":"G$e","manaMax":"ms","minuteTick":"gp","recordPlayerTone":"Rt","wives":"mh","imageBackend":"Eh","brothelCustomerBusy":"XO","buildPatronMoveCandidates":"Phe","ejectCustomer":"Q5","endPatronInteraction":"jt","finishBackRoomService":"xF","forceAttemptChance":"Ppe","patronControlAcquaintanceStop":"_Ie","patronControlAttemptRoll":"Iy","patronControlBackRoomOpen":"Tr","patronControlBareForPushIn":"O5","patronControlChooseMove":"Yhe","patronControlCoercionEscape":"cpe","patronControlFavorTable":"h3","patronControlHerBackRoomProposal":"ipe","patronControlIntentEvolve":"z$","patronControlJoinerComfort":"wh","patronControlJoinerPushIn":"jIe","patronControlLineUp":"Gce","patronControlLungePlan":"Vre","patronControlMortifyingCheck":"b$","patronControlMoveCustomer":"Yt","patronControlNaturalEnd":"hI","patronControlPatronBackRoomProposal":"ape","patronControlPatronDrift":"Kbe","patronControlPlayerAway":"Tt","patronControlPositionWeights":"Fhe","patronControlPrivateSession":"wpe","patronControlPrivateSessionInfo":"a0","patronControlPushIn":"qce","patronControlPushInAnalReaction":"p6","patronControlPushInReaction":"R6","patronControlRelentChance":"Bpe","patronControlRequestTable":"E2e","patronControlSelfEscalationRoll":"Qre","patronControlShameStop":"dpe","patronControlSlotFree":"kS","patronControlSmallRequest":"R2e","patronControlStageLabel":"hG","patronControlStrengthContest":"Za","patronControlTacticTable":"lIe","patronControlUndressAttempt":"AIe","patronControlVerbalAsk":"$5e","patronControlWitnessesFor":"Ks","patronControlYieldRoll":"pB","playerActionPublicRefusal":"Rs","processPatronGroupJoin":"BS","processPatronGroupParticipants":"WS","processPatronInteractionTick":"R7","recordPatronMistreatment":"yl","recordPatronReach":"K5e","resolvePatronEscalation":"ub","resolvePatronForce":"gB","rotatePatronGroupAfterPrimary":"Gie","selectPatronTactic":"gIe","startPatronInteraction":"Go","transitionPatronStage":"Dn","evaluateIntimacy":"Pe","getMaritalDrift":"E4","getPatronAttachment":"Uo","nudgeRelationship":"Mo","recordAffection":"Iw","recordIntimateHistory":"Wd","recordPatronBoundary":"Qi","brothelRoomLabels":"bO","imageRoom":"lue","waitressAlternative":"u$","waitressAvailable":"Bd","waitressChooseOrder":"Jle","waitressConsume":"_w","waitressIncome":"Qt","waitressMissing":"CP","waitressPrice":"d$","waitressRecordDrink":"vw","waitressRecordWord":"VB","playerActionRespond":"P1e","playerActionTopicFatigue":"GY","playerActionTouchedOut":"er","promptJoin":"J6","promptRoomFilter":"$de","promptGenParams":"q6","outfitById":"Ot","saveSlotInfo":"Mb","listDayStarts":"ZI","saveDayStart":"UDe","wifePortraits":"z6e","resentment":"Ue","marriageBond":"VT","wakeUp":"FI","gameOverScreen":"HLe","allureScore":"Ir","normalVisitRoll":"nhe","lodgingChance":"IB","worldTick":"Dp","hotkeyAction":"sG","confirmAction":"N4e","busyTask":"X0","imageManifest":"Wb","imageServerUrl":"Cs","imageGenerate":"LPe","imageQueue":"g6e","imageBackendProbe":"JU","imageBackendForget":"UD","imagePackReset":"qD","imageAutoProbeAllowed":"KU","WifeViewModeGameShell":"L6e","WifeViewModeQualityUpgrades":"AP","WifeViewModeLocationOverview":"ILe","WifeViewModeWifeAI":"Hye","WifeViewModeWifeGreet":"Yye","WifeViewModeWifeTakeOrder":"Fye","WifeViewModeWifeServe":"Gye","WifeViewModeOutOfStock":"sW","WifeViewModeDaresAvailable":"H2","WifeViewModeDareTargets":"K_","WifeViewModeMoveCustomer":"Yt","WifeViewModeStartPatronInteraction":"Go","WifeViewModeResolveCardHand":"jje","WifeViewModeCardScore":"qx","WifeViewModeWaitControls":"dl","WifeViewModeConversationMenu":"Vc","WifeViewModeApplyOutcome":"st","WifeViewModeApplySceneOutcome":"Tb","WifeViewModeJoinCandidates":"K5","WifeViewModeJoinWilling":"Gne","WifeViewModePatronFinishChoice":"lp","WifeViewModeEndPatronInteraction":"jt","WifeViewModeOpposedCheck":"Za","WifeViewModeApplyPlayerTavernAction":"vDe","WifeViewModeHusbandNextTavernAction":"ID","WifeViewModeScenePresentation":"wf","WifeViewModePrivateBackRoomStart":"bd","WifeViewModePrivateUpstairsStart":"S1","WifeViewModeRenterUpstairsStart":"RB","WifeViewModePrivateBathroomStart":"yB","WifeViewModeRestStart":"c0","WifeViewModeAgencyTick":"iD","WifeViewModeOffHoursPatronTick":"PMe","WifeViewModeImageKey":"DF","WifeViewModePortrait":"yN","WifeViewModeFocusColumn":"sLe","WifeViewModeLayout":"MLe","WifeViewModeEventOverlay":"WLe","WifeViewModeShopCustomer":"_O","WifeViewModeServiceButton":"ST","WifeViewModeServeControl":"vPe","WifeViewModeImageLookup":"Hp","WifeViewModeImageUrl":"ak","WifeViewModeMinuteOfDay":"cs","WifeViewModeNightCloseSlot":"Jm","WifeViewModeMinutesPerDay":"ho","WifeViewModeTavernDay":"Mt","WifeViewModeEndDay":"Cd","WifeViewModeSleep":"NDe","WifeViewModeBreakForService":"cI","WifeViewModeSatiety":"Oh","WifeViewModeRetire":"vd","WifeViewModeBackRoomOrder":"Xje","WifeViewModeBackRoomOutcome":"bF","WifeViewModeBackRoomEnter":"vF","WifeViewModeBackRoomAutoOrder":"eAe","WifeViewModeBackRoomWifeAvailable":"V0","WifeViewModeServiceEventResolve":"E3e","WifeViewModeToiletRequest":"lge","WifeViewModeToiletAddressee":"nge","WifeViewModeToiletKnown":"oge","WifeViewModeToiletResolve":"AC","WifeViewModeToiletVisit":"vm","WifeViewModeHusbandInTavern":"Wo"}, "2026-11-01": {"store":"ae","settingsStore":"at","React":"J","jsx":"u","ActionButton":"ht","ActionPanel":"SB","wife":"_","updateWife":"C","updateCharacter":"rn","log":"j","tick":"Jt","intoxLabel":"Sn","playerId":"ge","wifeId":"Ee","locationOf":"Ae","wifeLocation":"we","playerLocation":"vt","moveOccupant":"Ht","patronScene":"U","playerSexScene":"Be","setScene":"dK","patronSceneLocation":"Je","isSexualStage":"ct","sceneDef":"Sr","sceneOutfitState":"KMe","garmentWorn":"Zr","exposureSummary":"_g","patronWatchChoices":"Dbe","patronChoice":"uZ","startPlayerSex":"uh","playerSexEvent":"Kl","ensureHusbandLed":"ihe","addJoinedPatron":"C3e","joinSlots":"eU","registerAlert":"ar","queueAlert":"_n","drainAlerts":"oi","imagePrompt":"DR","imageKey":"zz","imageKeyOf":"CR","imageDescriptor":"RR","makeCustomer":"Ag","addCustomer":"Fi","carryToBed":"r5e","talkToWife":"gee","actionTimes":"tn","addFeeling":"Se","addIdentityStrainFromPatronAct":"Qf","getCustomerLocation":"Jn","getEffectiveAttributes":"B","heroineConditioningMax":"eue","heroineDriveCalc":"il","moveWife":"Nt","outfits":"Oi","patronControlCustomerLocation":"et","wifeById":"$m","wifePreview":"WL","reduceGameAction":"p5","brothelLog":"ds","decisionCategories":"Ho","decisionResolve":"DFe","manaMax":"Ys","minuteTick":"ry","recordPlayerTone":"qn","wives":"kr","imageBackend":"yh","brothelCustomerBusy":"z5","buildPatronMoveCandidates":"Zve","ejectCustomer":"HR","endPatronInteraction":"Rt","finishBackRoomService":"IV","forceAttemptChance":"iIe","patronControlAcquaintanceStop":"OUe","patronControlAttemptRoll":"g0","patronControlBackRoomOpen":"xS","patronControlBareForPushIn":"Q2","patronControlChooseMove":"sxe","patronControlCoercionEscape":"YOe","patronControlFavorTable":"wY","patronControlHerBackRoomProposal":"dGe","patronControlIntentEvolve":"AC","patronControlJoinerComfort":"ch","patronControlJoinerPushIn":"KUe","patronControlLineUp":"ADe","patronControlLungePlan":"s8e","patronControlMortifyingCheck":"b_","patronControlMoveCustomer":"lo","patronControlNaturalEnd":"GC","patronControlPatronBackRoomProposal":"cGe","patronControlPatronDrift":"NHe","patronControlPlayerAway":"yt","patronControlPositionWeights":"rxe","patronControlPrivateSession":"ZJ","patronControlPrivateSessionInfo":"Nh","patronControlPushIn":"jDe","patronControlPushInAnalReaction":"N9","patronControlPushInReaction":"wz","patronControlRelentChance":"mIe","patronControlRequestTable":"JGe","patronControlSelfEscalationRoll":"l8e","patronControlShameStop":"WOe","patronControlSlotFree":"G$","patronControlSmallRequest":"QGe","patronControlStageLabel":"Ote","patronControlStrengthContest":"el","patronControlTacticTable":"$Ue","patronControlUndressAttempt":"zUe","patronControlVerbalAsk":"A7e","patronControlWitnessesFor":"hs","patronControlYieldRoll":"Xq","playerActionPublicRefusal":"ir","processPatronGroupJoin":"gN","processPatronGroupParticipants":"XS","processPatronInteractionTick":"cZ","recordPatronMistreatment":"yl","recordPatronReach":"bPe","resolvePatronEscalation":"_b","resolvePatronForce":"Zq","rotatePatronGroupAfterPrimary":"jle","selectPatronTactic":"MUe","startPatronInteraction":"Xo","transitionPatronStage":"js","evaluateIntimacy":"We","getMaritalDrift":"i4","getPatronAttachment":"Uo","nudgeRelationship":"ko","recordAffection":"Iw","recordIntimateHistory":"Om","recordPatronBoundary":"tl","brothelRoomLabels":"LB","imageRoom":"ER","waitressAlternative":"JA","waitressAvailable":"zr","waitressChooseOrder":"uTe","waitressConsume":"v_","waitressIncome":"vo","waitressMissing":"K7","waitressPrice":"zv","waitressRecordDrink":"ox","waitressRecordWord":"vK","playerActionRespond":"IWe","playerActionTopicFatigue":"sX","playerActionTouchedOut":"er","promptJoin":"Yz","promptRoomFilter":"uMe","promptGenParams":"Dz","outfitById":"Ot","saveSlotInfo":"Bk","listDayStarts":"h$","saveDayStart":"y5e","wifePortraits":"Uit","resentment":"qe","marriageBond":"dA","wakeUp":"vD","gameOverScreen":"kat","allureScore":"aa","normalVisitRoll":"wTe","lodgingChance":"mK","worldTick":"py","hotkeyAction":"KG","confirmAction":"NYe","busyTask":"sv","imageManifest":"bh","imageServerUrl":"es","imageGenerate":"xst","imageQueue":"eit","imageBackendProbe":"FD","imageBackendForget":"iM","imagePackReset":"t_","imageAutoProbeAllowed":"eoe","WifeViewModeGameShell":"Iit","WifeViewModeQualityUpgrades":"U7","WifeViewModeLocationOverview":"hat","WifeViewModeWifeAI":"Kje","WifeViewModeWifeGreet":"Xje","WifeViewModeWifeTakeOrder":"Zje","WifeViewModeWifeServe":"tEe","WifeViewModeOutOfStock":"$K","WifeViewModeDaresAvailable":"aC","WifeViewModeDareTargets":"Vb","WifeViewModeMoveCustomer":"lo","WifeViewModeStartPatronInteraction":"Xo","WifeViewModeResolveCardHand":"Zqe","WifeViewModeCardScore":"l$","WifeViewModeWaitControls":"Ui","WifeViewModeConversationMenu":"Su","WifeViewModeApplyOutcome":"ft","WifeViewModeApplySceneOutcome":"L0","WifeViewModeJoinCandidates":"MR","WifeViewModeJoinWilling":"tye","WifeViewModePatronFinishChoice":"Ix","WifeViewModeEndPatronInteraction":"Rt","WifeViewModeOpposedCheck":"el","WifeViewModeApplyPlayerTavernAction":"uet","WifeViewModeHusbandNextTavernAction":"RW","WifeViewModeScenePresentation":"Wg","WifeViewModePrivateBackRoomStart":"Qa","WifeViewModePrivateUpstairsStart":"Qa","WifeViewModeRenterUpstairsStart":"cK","WifeViewModePrivateBathroomStart":"NJ","WifeViewModeRestStart":"iy","WifeViewModeAgencyTick":"hW","WifeViewModeOffHoursPatronTick":"uQe","WifeViewModeImageKey":"bee","WifeViewModePortrait":"rv","WifeViewModeFocusColumn":"Yrt","WifeViewModeLayout":"gat","WifeViewModeEventOverlay":"Sat","WifeViewModeShopCustomer":"PB","WifeViewModeServiceButton":"O5","WifeViewModeServeControl":"ist","WifeViewModeImageLookup":"vy","WifeViewModeImageUrl":"o_","WifeViewModeMinuteOfDay":"dn","WifeViewModeNightCloseSlot":"Mc","WifeViewModeMinutesPerDay":"h_","WifeViewModeTavernDay":"pt","WifeViewModeEndDay":"xm","WifeViewModeSleep":"yet","WifeViewModeBreakForService":"UC","WifeViewModeSatiety":"ud","WifeViewModeRetire":"cm","WifeViewModeBackRoomOrder":"Q$e","WifeViewModeBackRoomOutcome":"xV","WifeViewModeBackRoomEnter":"TV","WifeViewModeBackRoomAutoOrder":"Z$e","WifeViewModeBackRoomWifeAvailable":"Dx","WifeViewModeServiceEventResolve":"DXe","WifeViewModeToiletRequest":"bPe","WifeViewModeToiletAddressee":"pPe","WifeViewModeToiletKnown":"fPe","WifeViewModeToiletResolve":"n6","WifeViewModeToiletVisit":"jp","WifeViewModeHusbandInTavern":"yt"}}});
    const React = api.fn('React');
    const JSX = api.fn('jsx');
    const WifeViewMode_게임스토어 = api.fn('store');
    function WifeViewMode_관계문구(text,state=api.store.game()) {
      if(typeof text!=='string')return text;
      const person=state?api.fn('wife')(state):null;
      const relation=state?api.fn('WifeViewModeRelationshipContext')(state):null;
      const names={Her:person?.name||'그녀',His:relation?.playerRoleNoun||'상대'};
      return text.replace(/\{rt(Her|His)\}(은\(는\)|이\(가\)|을\(를\)|과\(와\)|으로\(로\)|은|는|이|가|을|를|과|와|으로|로)?/g,(_all,who,particle)=>{
        const name=names[who];if(!particle)return name;
        const last=name.charCodeAt(name.length-1),final=last>=0xac00&&last<=0xd7a3?(last-0xac00)%28:null;
        const pair=/은|는/.test(particle)?['은','는']:/이|가/.test(particle)?['이','가']:/을|를/.test(particle)?['을','를']:/과|와/.test(particle)?['과','와']:['으로','로'];
        return name+(final==null?pair[0]+'('+pair[1]+')':pair[0]==='으로'?final&&final!==8?pair[0]:pair[1]:final?pair[0]:pair[1]);
      });
    }
    const WifeViewMode_기본설정 = Object.freeze({
      active: false,
      stance: 'companion',
      wifeIntent: 'self',
      wifeServiceMode: 'auto',
      husbandServiceMode: 'auto',
      husbandProfile: null,
    });
    const WifeViewMode_스탠스목록 = Object.freeze([
      {
        id: 'companion',
        label: '동반자형',
        description: "그녀의 의사를 우선하며, 위험 신호가 있을 때만 중단 의견을 말합니다. 행동을 강제하지 않습니다.",
      },
      {
        id: 'protector',
        label: '보호자형',
        description: "위험하거나 과격한 상황에서 일찍 중단 의견을 말합니다. 최종 행동은 그녀가 결정합니다.",
      },
      {
        id: 'money',
        label: '돈벌레형',
        description: "수익과 영업상 이득이 있으면 권유하는 말을 자주 합니다. 그녀의 결정 자체는 바꾸지 않습니다.",
      },
      {
        id: 'observer',
        label: '관망자형',
        description: "그녀가 스스로 처리하도록 두고 자신의 의견만 짧게 밝힙니다.",
      },
      {
        id: 'netorase',
        label: '네토라세형',
        description: "손님과의 친밀한 교류를 적극 권유하지만, 그녀가 원하지 않는 행동을 강제로 선택하지는 않습니다.",
      },
    ]);
    const WifeViewMode_의향목록 = Object.freeze([
      {
        id: 'refuse',
        label: '단호히 거절',
        description: '손님과의 친밀한 진행을 거절합니다. 이미 위험한 상황이라면 원래 게임의 더 강한 반응은 유지됩니다.',
      },
      {
        id: 'cautious',
        label: '신중하게 대응',
        description: "적극적인 수락을 망설이는 수준으로 낮추고, 그녀가 먼저 관계를 진전시키는 행동은 막습니다.",
      },
      {
        id: 'self',
        label: '스스로 판단',
        description: "그녀의 성향·감정·관계 수치에 따른 원래 게임 판정을 그대로 사용합니다.",
      },
      {
        id: 'allow',
        label: '적극적으로 응함',
        description: "그녀가 먼저 관계를 진전시킬 수 있게 둡니다. 원래 게임의 경계·상태 판정을 강제로 통과시키지는 않습니다.",
      },
    ]);
    const WifeViewMode_남편행동선호목록 = Object.freeze([
      { id: 'romantic', label: '로맨스', description: "남성 주인공이 캐릭터에게 손님과 정서적·낭만적으로 가까워지는 행동을 요구하는 정도입니다." },
      { id: 'oral', label: '구강', description: "남성 주인공이 캐릭터에게 구강성교를 요구하거나 권하는 정도입니다." },
      { id: 'vaginal', label: '성관계', description: "남성 주인공이 캐릭터에게 손님과 성관계를 갖도록 요구하거나 권하는 정도입니다." },
      { id: 'anal', label: '항문', description: "남성 주인공이 캐릭터에게 항문성교를 요구하거나 권하는 정도입니다." },
      { id: 'exhibition', label: '노출', description: "남성 주인공이 캐릭터에게 손님 앞에서 몸을 드러내도록 요구하거나 권하는 정도입니다." },
      { id: 'submission', label: '복종', description: "남성 주인공이 캐릭터에게 손님의 주도에 따르도록 요구하거나 권하는 정도입니다." },
      { id: 'domination', label: '지배', description: "남성 주인공이 캐릭터에게 손님을 주도하도록 요구하거나 권하는 정도입니다." },
      { id: 'prostitution', label: '금전 관계', description: "남성 주인공이 캐릭터에게 대가를 받고 손님을 상대하도록 요구하거나 권하는 정도입니다." },
      { id: 'drinking', label: '음주', description: "남성 주인공이 캐릭터에게 손님과 술을 마시도록 요구하거나 권하는 정도입니다." },
      { id: 'taboo', label: '금기', description: "남성 주인공이 캐릭터에게 평소의 경계를 넘는 행동을 요구하거나 권하는 정도입니다." },
    ]);
    const WifeViewMode_남편특성목록 = Object.freeze([
      { id: 'true_prude', label: '극도로 보수적', description: "그녀의 노출이나 대담한 행동을 강하게 꺼립니다." },
      { id: 'self_protective', label: '자기보호적', description: '위험한 상황과 관계 손상을 피하려는 반응이 강합니다.' },
      { id: 'latent_dominant', label: '지배 성향', description: "그녀에게 조건과 선을 분명하게 제시하려는 경향이 있습니다." },
      { id: 'romance_starved', label: '애정에 굶주림', description: "그녀와의 정서적 거리와 애정 부족에 민감하게 반응합니다." },
      { id: 'likes_cheating', label: '외도 성향', description: '배우자 밖의 관계와 성적 자유에 비교적 관대합니다.' },
      { id: 'cold_pragmatist', label: '냉정한 실리주의자', description: '감정보다 수익과 현실적인 이익을 우선합니다.' },
      { id: 'breaks_under_pressure', label: '압박에 약함', description: '긴장과 압박이 커지면 처음 입장을 유지하기 어려워집니다.' },
      { id: 'latent_exhibitionist', label: '노출 성향', description: "그녀가 다른 사람의 시선을 받는 상황에 긍정적으로 반응합니다." },
      { id: 'public_thrill_seeker', label: '공개 스릴 추구', description: '들킬 수 있는 공개적인 상황의 긴장감을 선호합니다.' },
      { id: 'latent_submissive', label: '복종 성향', description: "그녀가 주도권을 잡았을 때 자신의 판단을 뒤로 미루기 쉽습니다." },
      { id: 'easily_intoxicated', label: '술에 쉽게 취함', description: '술이 관련된 사건에서 입장이 더 쉽게 흔들립니다.' },
      { id: 'wants_to_be_corrupted', label: '타락 욕구', description: "두 사람이 함께 기존의 경계를 넘어가는 변화에 끌립니다." },
      { id: 'latent_masochist', label: '피학 성향', description: '굴욕감이나 관계의 긴장을 감정적으로 강하게 받아들입니다.' },
      { id: 'latent_voyeur', label: '관음 성향', description: "그녀와 다른 사람의 친밀한 행동을 지켜보는 상황을 선호합니다." },
      { id: 'jealousy_kindled', label: '질투로 자극받음', description: '질투와 경쟁심이 생기면 욕망과 반응이 강해집니다.' },
      { id: 'wary_of_drinks', label: '술을 경계함', description: "그녀가 손님과 술을 마시는 상황을 더 위험하게 판단합니다." },
    ]);
    const WifeViewMode_남편감정목록 = Object.freeze([
      { id: 'devotion', label: '헌신' },
      { id: 'tenderness', label: '다정함' },
      { id: 'longing', label: '갈망' },
      { id: 'desire', label: '욕망' },
      { id: 'pushed_away', label: '마음을 닫음' },
      { id: 'contempt', label: '경멸·원망' },
      { id: 'anger', label: '분노' },
      { id: 'disgust', label: '혐오' },
      { id: 'shame', label: '수치심' },
      { id: 'guilt', label: '죄책감' },
      { id: 'regret', label: '후회' },
      { id: 'sadness', label: '슬픔' },
      { id: 'humiliation', label: '굴욕감' },
    ]);
    const WifeViewMode_선택경로 = Object.freeze({
      accept: 'direct', agree: 'direct', allow: 'direct', encourage: 'direct', direct: 'direct',
      nod: 'direct', watch: 'direct', play_them_off: 'direct', buy_drink: 'direct', yes: 'direct',
      route_upstairs: 'direct', route_back_room: 'direct', route_back_room_line: 'direct',
      back_room_private_encourage: 'direct', stay_back: 'delegate',
      let_handle: 'delegate', let_her_handle_it: 'delegate', she_decides: 'delegate',
      back_room_private_she_decides: 'delegate', wait: 'delegate', ignore: 'delegate',
      back_off: 'delegate', leave: 'delegate', her_call: 'delegate', tell_me: 'delegate',
      redirect: 'restrict', redirect_other: 'restrict', send_errand: 'restrict', send_one_away: 'restrict',
      minimize: 'restrict', warn: 'restrict', limit: 'restrict',
      refuse: 'reject', reject: 'reject', no: 'reject', stop: 'reject', pull_away: 'reject',
      step_in: 'reject', intervene: 'reject', protective_intervene: 'reject',
      force_intervene: 'reject', throw_out: 'reject', back_room_private_refuse: 'reject',
      charge: 'profit', cash_first: 'profit', negotiate: 'profit', take_payment: 'profit',
      scenario_town_meeting_charge: 'profit',
      comfort: 'direct', wounded: 'restrict', angry: 'reject', sanction: 'delegate', repair: 'direct',
      back: 'delegate', cancel: 'delegate',
    });
    const WifeViewMode_확인선택 = new Set(['dismiss', 'continue', 'continue_after_climax', 'ok']);
    const WifeViewMode_처리시도 = new WeakSet();
    const WifeViewMode_실패선택목록 = new Map();
    const WifeViewMode_강제중단사건목록 = new Set();
    const WifeViewMode_자동처리연속제한 = 12;
    let WifeViewMode_자동처리연속상태 = { day: null, slot: null, count: 0, lastAt: 0 };
    let WifeViewMode_설정창 = null;
    let WifeViewMode_카드강제패배중 = false;
    let WifeViewMode_카드점수사용됨 = false;
    let WifeViewMode_비활성상태정리중 = false;
    let WifeViewMode_남편응대처리중 = false;
    let WifeViewMode_장면자료복구중 = false;
    let WifeViewMode_조작자료동기화중 = false;
    let WifeViewMode_승인된이동깊이 = 0;
    const WifeViewMode_세계진행목록 = [];

    function WifeViewMode_승인된이동실행하기(callback) {
      WifeViewMode_승인된이동깊이 += 1;
      try { return callback(); } finally { WifeViewMode_승인된이동깊이 -= 1; }
    }

    function WifeViewMode_자율행동차단여부(state) {
      if (!WifeViewMode_활성여부(state)) return false;
      const wife = api.fn('wife')(state);
      return WifeViewMode_자료읽기(state).wifeServiceMode === 'manual'
        || WifeViewMode_손님장면조작가능여부(state) || !!wife?.wifeViewHoldPosition;
    }

    function WifeViewMode_자동이동차단여부(state, destination) {
      // 플레이어가 승인한 Delivery 외출의 진행·귀환은 기본 서빙 규칙을 사용합니다.
      if (globalThis.__waywardDeliveryCompatibleWifeView?.ownsWife(state)) return false;
      if (WifeViewMode_승인된이동깊이 || !WifeViewMode_세계진행목록.length
        || !WifeViewMode_자율행동차단여부(state)) return false;
      const frame = WifeViewMode_세계진행목록.at(-1);
      const wife = api.fn('wife')(state);
      // Existing trips, unconsciousness, sleep and day transitions retain native recovery.
      if (state.phase !== frame.phase || state.day !== frame.day
        || ['away', 'sleeping', 'passed_out'].includes(wife?.currentTask)
        || wife?.passedOutAtSlot != null || (wife?.stats?.energy ?? 1) <= 0) return false;
      return destination !== api.fn('wifeLocation')(state);
    }

    function WifeViewMode_함께이동하기(state, customer, room) {
      const scene = state.activeScene?.patron;
      const ids = [customer.id, ...(scene?.joinedPatronIds || [])];
      let next = WifeViewMode_손님복귀장소기록하기(state, ids);
      next = api.fn('updateWife')(next, wife => ({ ...wife, currentTask: 'idle',
        busyUntilSlot: next.slot, locationUntilSlot: undefined, wifeViewHoldPosition: false }));
      return WifeViewMode_승인된이동실행하기(() => {
        next = api.fn('moveWife')(next, room, undefined, { skipModestyCheck: false });
        for (const id of ids) next = api.fn('WifeViewModeMoveCustomer')(next, id, room);
        return next;
      });
    }

    function WifeViewMode_손님장면조작가능여부(state) {
      const scene = state?.activeScene?.patron;
      if (globalThis.__waywardDeliveryCompatibleWifeView?.ownsScene(state)) return false;
      return WifeViewMode_활성여부(state) && !!scene
        && (scene.characterId || state.primaryCharacterId) === state.primaryCharacterId
        && !['solo', 'husband_led'].includes(scene.kind);
    }

    function WifeViewMode_손님장면인계하기(state) {
      if (!WifeViewMode_손님장면조작가능여부(state)) return state;
      const scene = state.activeScene.patron;
      if (scene.wifeViewControlled) return state;
      const next = WifeViewMode_손님장면제어표시하기(state, scene.customerId);
      return {
        ...next,
        customers: next.customers.map(customer => customer.id === scene.customerId
          ? { ...customer, wifeViewGreeted: true } : customer),
        activeScene: { ...next.activeScene, patron: {
          ...next.activeScene.patron, wifeViewPatronInitiated: true,
        } },
      };
    }

    function WifeViewMode_손님복귀장소기록하기(state, ids) {
      const moved = new Set(ids);
      return { ...state, customers: state.customers.map(customer => moved.has(customer.id)
        ? { ...customer, wifeViewReturnRoom: customer.wifeViewReturnRoom
          || WifeViewMode_인물장소찾기(state, customer.id) || 'taproom' }
        : customer) };
    }

    function WifeViewMode_남은손님복귀시키기(state) {
      if (!WifeViewMode_활성여부(state)) return state;
      const involved = new Set([
        state.activeScene?.patron?.customerId, ...(state.activeScene?.patron?.joinedPatronIds || []),
        state.activeScene?.bathhouse?.customerId,
      ]);
      let next = state;
      for (const customer of state.customers || []) {
        const room = WifeViewMode_인물장소찾기(next, customer.id);
        const roomMeta = next.locations?.[room]?.meta;
        const registered = [next.tavern?.tonightRenter, next.tavern?.tonightRenter2]
          .some(renter => renter?.customerId === customer.id);
        if (involved.has(customer.id) || customer.isResident || registered
          || roomMeta?.privatePatron?.customerId === customer.id || roomMeta?.party
          || customer.bathReturnSlot != null || customer.privyAtSlot != null) continue;
        const expired = ['back_room', 'upstairs_hall', 'upstairs_room_2', 'bedroom', 'elena_room'].includes(room)
          && customer.status === 'drinking' && (customer.stayTimer ?? 1) <= 0;
        if (!customer.wifeViewReturnRoom && !expired) continue;
        const destination = next.locations?.[customer.wifeViewReturnRoom] ? customer.wifeViewReturnRoom : 'taproom';
        next = api.fn('WifeViewModeMoveCustomer')(next, customer.id, destination);
        next = { ...next, customers: next.customers.map(item => {
          if (item.id !== customer.id) return item;
          const { wifeViewReturnRoom, ...rest } = item;
          return rest;
        }) };
      }
      return next;
    }

    function WifeViewMode_장소이동제안만들기(state, room, customerId) {
      if (state.pendingEvent || !WifeViewMode_장소사용가능여부(state, room)) return state;
      const scene = state.activeScene?.patron;
      if (scene?.wifeViewDeclinedMoveRoom === room) return state;
      const customer = state.customers?.find(item => item.id === (customerId || scene?.customerId));
      const label = api.fn('brothelRoomLabels')?.[room] || room;
      return { ...state, pendingEvent: {
        type: 'wife_view_move', customerId: customer?.id, room,
        text: WifeViewMode_관계문구(`${customer?.name || '상대'}이(가) ${label}(으)로 함께 이동하자고 제안합니다. {rtHer}가 직접 결정합니다.`, state),
        choices: [
          { id: 'approve_move', label: '이동을 승인하기', description: '지금의 상호작용을 유지하며 함께 이동합니다.' },
          { id: 'decline_move', label: '여기에 머무르기', description: '장소 이동을 거절하고 현재 장소에 머무릅니다.' },
        ],
      } };
    }

    function WifeViewMode_조작자료동기화하기() {
      const state = api.store.game();
      if (!state || !WifeViewMode_활성여부(state) || WifeViewMode_조작자료동기화중) return;
      let next = WifeViewMode_멈춘장면정리하기(WifeViewMode_손님장면인계하기(state));
      next = WifeViewMode_남은손님복귀시키기(next);
      if (next === state) return;
      WifeViewMode_조작자료동기화중 = true;
      try { api.store.update(current => current === state ? next : current); }
      finally { WifeViewMode_조작자료동기화중 = false; }
    }
    const WifeViewMode_손님장면단계 = Object.freeze({
      talk: { stage: 'chatting', scene: 'patron_chatting', comfortBoost: 20, boldnessBoost: 0 },
      flirt: { stage: 'flirting', scene: 'patron_flirting', comfortBoost: 25, boldnessBoost: 8 },
      light_touch: { stage: 'light_touch', scene: 'patron_touching', comfortBoost: 30, boldnessBoost: 12 },
      expose_penis: { stage: 'groping', scene: 'patron_groping', comfortBoost: 34, boldnessBoost: 20, exposed: true },
      touch_penis: { stage: 'handjob_patron', scene: 'patron_handjob', comfortBoost: 40, boldnessBoost: 22, exposed: true },
      mouth_penis: { stage: 'blowjob_patron', scene: 'patron_blowjob', comfortBoost: 44, boldnessBoost: 28, exposed: true },
      breasts_penis: { stage: 'intimate', scene: 'patron_titfuck', comfortBoost: 42, boldnessBoost: 27, exposed: true, variant: 'breasts' },
      thigh_rub: { stage: 'rubbing_patron', scene: 'patron_rubbing', comfortBoost: 42, boldnessBoost: 26, exposed: true, variant: 'thigh' },
      genital_rub: { stage: 'rubbing_patron', scene: 'patron_rubbing', comfortBoost: 45, boldnessBoost: 30, exposed: true, variant: 'genitals' },
      ride_vaginal: { stage: 'sex_patron', scene: 'patron_riding', comfortBoost: 48, boldnessBoost: 34, exposed: true, primarySlot: 'astride' },
      anal_from_behind: { stage: 'sex_patron', scene: 'patron_anal', comfortBoost: 45, boldnessBoost: 36, exposed: true, primarySlot: 'inside_anal', variant: 'anal' },
    });
    const WifeViewMode_손님장면순서 = Object.freeze([
      'chatting', 'flirting', 'light_touch', 'bold_touch', 'groping',
      'intimate', 'handjob_patron', 'blowjob_patron', 'rubbing_patron', 'sex_patron',
    ]);
    const WifeViewMode_손님장면화면 = Object.freeze({
      chatting: 'patron_chatting',
      flirting: 'patron_flirting',
      light_touch: 'patron_touching',
      bold_touch: 'patron_bold',
      groping: 'patron_groping',
      intimate: 'patron_intimate',
      handjob_patron: 'patron_handjob',
      blowjob_patron: 'patron_blowjob',
      rubbing_patron: 'patron_rubbing',
      sex_patron: 'patron_sex',
    });
    const WifeViewMode_일반손님장면그림 = new Set([
      ...Object.values(WifeViewMode_손님장면화면),
      ...Object.values(WifeViewMode_손님장면단계).map(config => config.scene),
    ]);

    function WifeViewMode_그림변형번호정규화하기(value) {
      // Native image prompts index an array with this value. Action names belong
      // in wifeViewActVariant, never in the native numeric sceneVariant field.
      return Number.isInteger(value) && value >= 0 ? value : 0;
    }

    function WifeViewMode_손님장면그림찾기(scene, current) {
      // Native finish, afterglow and lateral-action frames take precedence over
      // the last action selected in this mod.
      if (scene.afterglow || scene.lateralAct
        || current.sceneOverride && !WifeViewMode_일반손님장면그림.has(current.sceneOverride)) {
        return current.sceneOverride;
      }
      const config = WifeViewMode_손님장면단계[scene.wifeViewAction];
      if (config?.stage === scene.stage
        && (!config.primarySlot || config.primarySlot === scene.primarySlot)) return config.scene;
      if (scene.stage === 'sex_patron') {
        return scene.primarySlot === 'inside_anal' ? 'patron_anal'
          : scene.primarySlot === 'astride' ? 'patron_riding' : 'patron_sex';
      }
      return WifeViewMode_손님장면화면[scene.stage] || current.sceneOverride;
    }

    function WifeViewMode_기존장면자료복구하기() {
      const state = api.store.game();
      if (!state || WifeViewMode_장면자료복구중) return;
      const wife = api.fn('wife')(state);
      const invalidVariant = wife?.sceneVariant != null
        && WifeViewMode_그림변형번호정규화하기(wife.sceneVariant) !== wife.sceneVariant;
      const ownedVariant = ['breasts', 'thigh', 'genitals', 'anal'].includes(wife?.sceneVariant)
        || state.activeScene?.patron?.wifeViewControlled;
      if (!invalidVariant || !ownedVariant) return;
      WifeViewMode_장면자료복구중 = true;
      try {
        api.store.update(current => api.fn('updateWife')(current, character => ({
          ...character,
          sceneVariant: WifeViewMode_그림변형번호정규화하기(character.sceneVariant),
        })));
      } finally {
        WifeViewMode_장면자료복구중 = false;
      }
    }
    const WifeViewMode_대화대사 = Object.freeze([
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}의 곁에 다가가 미소 짓습니다. “안녕하세요. 잠깐 이야기 나눠도 될까요?”`,
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name} 옆의 빈자리를 가리킵니다. “옆에 좀 앉을게요.” 그녀가 자연스럽게 자리를 잡습니다.`,
      ({ wife, customer, returning }) => returning
        ? `${wife.name}이(가) ${customer.name}을(를) 알아보고 반갑게 웃습니다. “또 오셨네요. 오늘은 어떻게 지내셨어요?”`
        : `${wife.name}이(가) 처음 보는 ${customer.name}에게 먼저 인사를 건넵니다. “처음 오셨네요. 편하게 계세요.”`,
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}의 잔을 바라보다가 말을 겁니다. “술은 입에 맞으세요? 잠깐 말벗이 되어 드릴게요.”`,
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}과(와) 눈을 맞추며 의자를 당겨 앉습니다. “혼자 계시네요. 무슨 이야기든 들려주세요.”`,
    ]);
    const WifeViewMode_추파대사 = Object.freeze([
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}을(를) 천천히 훑어보고 웃습니다. “가까이서 보니 무척 잘생기셨네요.”`,
      ({ wife, customer }) => `${wife.name}이(가) 잔을 든 ${customer.name}의 손을 바라봅니다. “술 마시는 모습이 꽤 멋지네요.”`,
      ({ wife, customer }) => `${wife.name}이(가) 목소리를 낮춥니다. “오늘 여기서 가장 눈에 띄는 분이 누군지 아세요?”`,
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}의 옷깃을 손끝으로 가리키며 말합니다. “그 차림, 정말 잘 어울려요.”`,
      ({ wife, customer }) => `${wife.name}이(가) 장난스러운 눈빛으로 ${customer.name}을(를) 봅니다. “그렇게 계속 쳐다보시면 제가 오해할지도 몰라요.”`,
      ({ wife, customer }) => `${wife.name}이(가) 한 걸음 더 가까이 섭니다. “오늘은 평소보다 더 멋져 보이시네요.”`,
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}의 미소를 보고 따라 웃습니다. “웃을 때 분위기가 참 좋아요.”`,
      ({ wife, customer }) => `${wife.name}이(가) 머리카락을 귀 뒤로 넘기며 묻습니다. “저와 조금 더 오래 이야기하고 싶지 않으세요?”`,
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}에게만 들릴 만큼 작게 말합니다. “당신 옆에 있으니 오늘 밤이 덜 지루하네요.”`,
      ({ wife, customer }) => `${wife.name}이(가) 시선을 피하지 않은 채 미소 짓습니다. “멋진 분과 한잔하면 술맛도 달라지겠죠?”`,
    ]);
    const WifeViewMode_가벼운접촉대사 = Object.freeze([
      ({ wife, customer }) => `${wife.name}이(가) 이야기 도중 ${customer.name}의 팔을 손끝으로 가볍게 스치고 반응을 살핍니다.`,
      ({ wife, customer }) => `${wife.name}이(가) 웃으며 ${customer.name}의 어깨에 잠시 손을 얹었다가 천천히 거둡니다.`,
      ({ wife, customer }) => `${wife.name}이(가) 잔을 건네며 ${customer.name}의 손등에 손가락을 살짝 겹칩니다.`,
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name} 옆에 바짝 앉아 그의 팔에 자신의 팔을 가볍게 맞댑니다.`,
      ({ wife, customer }) => `${wife.name}이(가) 옷깃의 먼지를 털어 주는 척하며 ${customer.name}의 어깨와 가슴께를 부드럽게 쓸어 내립니다.`,
    ]);
    const WifeViewMode_손자극대사 = Object.freeze([
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}의 손을 잡아 자신의 허리 가까이 이끕니다. “제가 손으로 해드려도 될까요?”`,
      ({ wife, customer }) => `${wife.name}이(가) 그의 귓가에 낮게 묻습니다. “제 손길이 필요한 것 같은데… 제가 해드릴까요?”`,
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}의 허벅지에 손을 얹고 눈을 맞춥니다. “조금 더 편하게 해드리고 싶어요.”`,
      ({ wife, customer }) => `${wife.name}이(가) 손끝을 천천히 아래로 내리며 속삭입니다. “가만히 계세요. 제가 직접 해볼게요.”`,
    ]);
    const WifeViewMode_성행동대사 = Object.freeze({
      expose_penis: [
        ({ wife, customer }) => `${wife.name}이(가) ${customer.name}의 눈을 바라보며 손을 허리춤으로 가져가 그의 성기를 직접 꺼냅니다.`,
        ({ wife, customer }) => `${wife.name}이(가) ${customer.name}에게 몸을 가까이 붙이고 옷자락 아래로 손을 넣어 그의 성기를 드러냅니다.`,
      ],
      touch_penis: WifeViewMode_손자극대사,
      mouth_penis: [
        ({ wife, customer }) => `${wife.name}이(가) ${customer.name} 앞에 무릎을 굽히고 그의 성기를 입에 물어 천천히 자극하기 시작합니다.`,
        ({ wife, customer }) => `${wife.name}이(가) ${customer.name}과(와) 눈을 맞춘 뒤 입술로 그의 성기를 감쌉니다.`,
      ],
      breasts_penis: [
        ({ wife, customer }) => `${wife.name}이(가) 가슴 사이에 ${customer.name}의 성기를 끼우고 몸을 움직여 자극합니다.`,
        ({ wife, customer }) => `${wife.name}이(가) ${customer.name}에게 더 가까이 다가가 가슴으로 그의 성기를 감싸 비빕니다.`,
      ],
      thigh_rub: [
        ({ wife, customer }) => `${wife.name}이(가) ${customer.name}의 성기를 허벅지 사이에 끼우고 천천히 비비기 시작합니다.`,
        ({ wife, customer }) => `${wife.name}이(가) 다리를 모아 ${customer.name}의 성기를 허벅지로 감싸 자극합니다.`,
      ],
      genital_rub: [
        ({ wife, customer }) => `${wife.name}이(가) ${customer.name}에게 몸을 밀착하고 서로의 성기가 맞닿도록 천천히 비빕니다.`,
        ({ wife, customer }) => `${wife.name}이(가) 삽입하지 않은 채 ${customer.name}의 성기에 자신의 몸을 맞대어 자극합니다.`,
      ],
      ride_vaginal: [
        ({ wife, customer }) => `${wife.name}이(가) ${customer.name}의 위에 올라타 자세를 잡고 스스로 그의 성기를 몸 안에 받아들입니다.`,
        ({ wife, customer }) => `${wife.name}이(가) ${customer.name}의 허리를 붙잡고 그 위에 올라타 천천히 삽입합니다.`,
      ],
      anal_from_behind: [
        ({ wife, customer }) => `${wife.name}이(가) ${customer.name}에게 등을 돌려 엉덩이를 내밀고 그의 성기를 항문에 받아들입니다.`,
        ({ wife, customer }) => `${wife.name}이(가) 뒤로 돌아 자세를 낮춘 뒤 ${customer.name}이(가) 뒤에서 항문에 삽입하도록 이끕니다.`,
      ],
    });
    const WifeViewMode_직접성행동목록 = Object.freeze([
      { id: 'expose_penis', label: '손님의 성기를 꺼내기', description: '손님에게 다가가 그의 성기를 직접 꺼냅니다. 이후 원하는 성행위를 선택할 수 있습니다.' },
      { id: 'touch_penis', label: '만지기', description: '꺼낸 손님의 성기를 손으로 만지고 자극합니다.', requiresExposed: true },
      { id: 'mouth_penis', label: '입에 물기', description: '손님의 성기를 입에 물고 구강으로 자극합니다.', requiresExposed: true },
      { id: 'breasts_penis', label: '가슴에 끼우기', description: '손님의 성기를 가슴 사이에 끼워 비비며 자극합니다.', requiresExposed: true },
      { id: 'thigh_rub', label: '허벅지에 비비기', description: '손님의 성기를 허벅지 사이에 끼워 비빕니다.', requiresExposed: true },
      { id: 'genital_rub', label: '성기끼리 비비기', description: '삽입하지 않고 서로의 성기를 맞대어 비빕니다.', requiresExposed: true },
      { id: 'ride_vaginal', label: '올라타서 삽입하기', description: "그녀가 손님 위에 올라타 스스로 질에 삽입합니다.", requiresExposed: true },
      { id: 'anal_from_behind', label: '뒤로 돌아 엉덩이에 넣기', description: '손님에게 등을 돌리고 뒤에서 항문에 삽입하도록 이끕니다.', requiresExposed: true },
    ]);
    const WifeViewMode_이동권하기행동 = new Set([
      'dare_back_room_give_them_what_they_want',
      'dare_back_room_let_them_handle',
      'dare_back_room_work_them',
      'dare_take_him_upstairs',
    ]);
    const WifeViewMode_합류대사 = Object.freeze([
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}에게 손짓합니다. “보고만 계실 건가요? 이쪽으로 오세요.”`,
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}과(와) 눈을 맞추며 자리를 내줍니다. “함께하고 싶다면 가까이 와도 돼요.”`,
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}의 손을 잡아 이끕니다. “혼자 두지 말고 같이 즐겨요.”`,
      ({ wife, customer }) => `${wife.name}이(가) 장난스럽게 미소 짓습니다. “당신도 끼고 싶은 표정인데, 제가 틀렸나요?”`,
    ]);
    const WifeViewMode_안에대사 = Object.freeze([
      ({ wife, customer, oral }) => oral
        ? `${wife.name}이(가) ${customer.name}을(를) 올려다보며 입 안에 받아도 좋다는 뜻을 전합니다.`
        : `${wife.name}이(가) ${customer.name}을(를) 끌어안고 낮게 속삭입니다. “밖으로 빼지 말고, 안에 해주세요.”`,
      ({ wife, customer, oral }) => oral
        ? `${wife.name}이(가) 그의 허리를 붙잡고 마지막까지 입 안에 해달라고 부탁합니다.`
        : `${wife.name}이(가) 움직임을 맞추며 ${customer.name}에게 안에 사정해 달라고 부탁합니다.`,
      ({ wife, customer, oral }) => oral
        ? `${wife.name}이(가) 눈을 맞춘 채 물러나지 않고, 그대로 입 안에 끝내 달라는 뜻을 보입니다.`
        : `${wife.name}이(가) ${customer.name}의 귓가에 “그대로 안에 해도 돼요.”라고 말합니다.`,
      ({ wife, customer, oral }) => oral
        ? `${wife.name}이(가) ${customer.name}의 손을 잡고, 마지막은 입 안에 받고 싶다고 조용히 말합니다.`
        : `${wife.name}이(가) 다리로 그를 감싸며 이번에는 안에 남겨 달라고 청합니다.`,
    ]);
    const WifeViewMode_밖에대사 = Object.freeze([
      ({ wife, customer, oral }) => oral
        ? `${wife.name}이(가) 잠시 입을 떼고 ${customer.name}에게 밖에 마무리해 달라고 부탁합니다.`
        : `${wife.name}이(가) ${customer.name}에게 마지막에는 반드시 밖으로 빼 달라고 말합니다.`,
      ({ wife, customer, oral }) => oral
        ? `${wife.name}이(가) 그의 손을 잡으며 얼굴 쪽에 끝내 달라고 조용히 청합니다.`
        : `${wife.name}이(가) 숨을 고르며 “안에는 안 돼요. 밖에 해주세요.”라고 분명히 말합니다.`,
      ({ wife, customer, oral }) => oral
        ? `${wife.name}이(가) ${customer.name}을(를) 올려다보며 입 밖에 사정해 달라는 뜻을 전합니다.`
        : `${wife.name}이(가) 그의 어깨를 붙잡고 때가 되면 밖으로 물러나 달라고 부탁합니다.`,
      ({ wife, customer, oral }) => oral
        ? `${wife.name}이(가) 마지막 순간에는 입을 떼겠다고 말하며 밖에 끝내 달라고 합니다.`
        : `${wife.name}이(가) ${customer.name}과(와) 눈을 맞추고 밖에 마무리해 달라고 다시 확인합니다.`,
    ]);
    const WifeViewMode_거절대사 = Object.freeze([
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}의 손을 붙잡아 떼어 내며 단호하게 말합니다. “여기까지예요. 더는 안 돼요.”`,
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}에게서 한 걸음 물러납니다. “제가 허락한 건 거기까지예요.”`,
      ({ wife, customer }) => `${wife.name}이(가) 손목을 빼내고 ${customer.name}을(를) 똑바로 바라봅니다. “멈춰 주세요.”`,
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}의 손을 밀어 내며 고개를 젓습니다. “그 이상은 원하지 않아요.”`,
    ]);
    const WifeViewMode_뿌리치기성공대사 = Object.freeze([
      ({ wife, customer }) => `${wife.name}이(가) 붙잡힌 팔에 힘을 주어 ${customer.name}의 손을 거세게 뿌리칩니다. 그가 균형을 잃은 사이 그녀는 즉시 거리를 벌리고 장면에서 빠져나옵니다.`,
      ({ wife, customer }) => `${wife.name}이(가) 중심을 낮추고 팔을 힘껏 비틀어 ${customer.name}의 손아귀에서 벗어납니다. 그녀는 다시 붙잡히기 전에 자리를 떠납니다.`,
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}을(를) 강하게 밀어 내고 붙잡힌 손을 빼냅니다. 그의 손이 떨어지자 그녀는 곧바로 안전한 거리를 확보합니다.`,
      ({ wife, customer }) => `${wife.name}이(가) 온힘을 다해 팔을 당겨 ${customer.name}의 손을 떼어 냅니다. 이번에는 그가 버티지 못했고, 그녀는 상호작용을 끝내고 나옵니다.`,
    ]);
    const WifeViewMode_뿌리치기실패대사 = Object.freeze([
      ({ wife, customer }) => `${wife.name}이(가) 팔을 뿌리치려 하지만 ${customer.name}의 힘에 밀려 손아귀를 떼어 내지 못합니다. 그녀가 빠져나오지 못한 채 지금 상황이 계속됩니다.`,
      ({ wife, customer }) => `${wife.name}이(가) 몸을 빼며 ${customer.name}의 손을 밀어 내지만 그가 더 세게 버팁니다. 그녀는 거리를 만들지 못하고 같은 상황에 붙들려 있습니다.`,
      ({ wife, customer }) => `${wife.name}이(가) 힘껏 팔을 당겼지만 ${customer.name}의 손은 떨어지지 않습니다. 짧은 몸싸움 뒤에도 장면은 끝나지 않습니다.`,
      ({ wife, customer }) => `${wife.name}이(가) ${customer.name}을(를) 떼어 내려 애쓰지만 힘이 모자랍니다. 그는 물러서지 않고, 그녀는 아직 이 상황에서 벗어나지 못합니다.`,
    ]);
    const WifeViewMode_권하기행동표현 = Object.freeze({
      dare_drink_with_him: {
        label: '함께 술 한잔하기',
        description: '그에게 술을 권하며 같이 마십니다.',
      },
      dare_flash_tits: {
        label: '가슴 보여주기',
        description: '그의 앞에 다가가서 가슴을 보여줍니다.',
      },
      dare_bend_over_serving: {
        label: '그 사람 앞에서 허리를 깊게 숙이기',
        description: '그의 눈 앞에서 허리를 깊게 숙여서 엉덩이가 잘 보이게 합니다.',
      },
      dare_back_room_give_them_what_they_want: {
        label: '뒷방에서 원하는 것을 해주기',
        description: '그와 뒷방으로 가서 그가 원하던 친밀한 행동을 직접 해줍니다.',
      },
      dare_back_room_let_them_handle: {
        label: '뒷방에서 그의 손길 받아들이기',
        description: '그와 뒷방으로 이동해 그가 자신의 몸을 만지도록 허용합니다.',
      },
      dare_back_room_work_them: {
        label: '뒷방에서 손님 상대하기',
        description: '그를 뒷방으로 데려가 직접 상대하고 대가를 받습니다.',
      },
      dare_dance_for_table: {
        label: '탁자 앞에서 춤추기',
        description: '그의 탁자 앞으로 가서 몸을 보여 주며 춤을 춥니다.',
      },
      dare_dirty_whisper: {
        label: '음탕한 귓속말 하기',
        description: '그의 귀 가까이 다가가 은밀하고 음탕한 말을 속삭입니다.',
      },
      dare_hand_to_tit: {
        label: '그의 손을 가슴에 올리기',
        description: '그의 손을 직접 잡아 자신의 가슴 위에 올립니다.',
      },
      dare_kiss_patron: {
        label: '그에게 입맞추기',
        description: '그에게 먼저 다가가 입술에 키스합니다.',
      },
      dare_let_him_touch: {
        label: '그의 손길 받아들이기',
        description: '그가 자신의 몸을 만지도록 허용하고 반응을 살핍니다.',
      },
      dare_play_cards: {
        label: '함께 카드 한 판 하기',
        description: '그의 자리에 앉아 함께 카드 게임을 시작합니다.',
      },
      dare_sit_lap: {
        label: '그의 무릎에 앉기',
        description: '그에게 다가가 직접 무릎 위에 앉습니다.',
      },
      dare_take_him_upstairs: {
        label: '단둘이 있는 곳으로 데려가기',
        description: '그에게 조용히 따라오라고 말하고 단둘이 있을 수 있는 장소로 데려갑니다.',
      },
      dare_whisper_wet: {
        label: '젖었다고 귓속말하기',
        description: '그의 귓가에 다가가 자신이 얼마나 흥분했는지 직접 속삭입니다.',
      },
    });

    function WifeViewMode_남편프로필기본값만들기() {
      return {
        libido: 50,
        volatility: 0.45,
        selfConcept: { openness: 50, confidence: 50 },
        relationship: { trust: 60 },
        affinities: Object.fromEntries(WifeViewMode_남편행동선호목록.map(item => [item.id, 0])),
        latentTraits: [],
        noticedLatentTraits: [],
        feelings: Object.fromEntries(WifeViewMode_남편감정목록.map(item => [item.id,
          item.id === 'devotion' ? 60 : item.id === 'tenderness' ? 55 : item.id === 'desire' ? 40 : 0])),
      };
    }

    function WifeViewMode_남편프로필정규화하기(value) {
      const defaults = WifeViewMode_남편프로필기본값만들기();
      const number = (input, fallback, min, max) => Number.isFinite(Number(input))
        ? Math.max(min, Math.min(max, Number(input)))
        : fallback;
      const affinities = Object.fromEntries(WifeViewMode_남편행동선호목록.map(item => [
        item.id,
        number(value?.affinities?.[item.id], defaults.affinities[item.id], -2, 2),
      ]));
      const feelings = Object.fromEntries(WifeViewMode_남편감정목록.map(item => [
        item.id,
        number(value?.feelings?.[item.id], defaults.feelings[item.id], 0, 100),
      ]));
      const allowedTraits = new Set(WifeViewMode_남편특성목록.map(item => item.id));
      const latentTraits = [...new Set((value?.latentTraits || []).filter(item => allowedTraits.has(item)))];
      const ownedTraits = new Set(latentTraits);
      return {
        libido: number(value?.libido, defaults.libido, 8, 95),
        volatility: number(value?.volatility, defaults.volatility, 0.1, 0.85),
        selfConcept: {
          openness: number(value?.selfConcept?.openness, defaults.selfConcept.openness, 0, 100),
          confidence: number(value?.selfConcept?.confidence, defaults.selfConcept.confidence, 0, 100),
        },
        relationship: {
          trust: number(value?.relationship?.trust, defaults.relationship.trust, 0, 100),
        },
        affinities,
        latentTraits,
        noticedLatentTraits: [...new Set((value?.noticedLatentTraits || [])
          .filter(item => allowedTraits.has(item) && ownedTraits.has(item)))],
        feelings,
      };
    }

    function WifeViewMode_브라우저설정읽기() {
      return api.settings.get({ defaultStance: WifeViewMode_기본설정.stance });
    }

    function WifeViewMode_자료읽기(state = api.store.game()) {
      const saved = state?.mods?.['wife-view-mode'] ?? api.data.get() ?? {};
      const browser = WifeViewMode_브라우저설정읽기();
      const stance = WifeViewMode_스탠스목록.some(item => item.id === saved.stance)
        ? saved.stance
        : browser.defaultStance;
      const wifeIntent = WifeViewMode_의향목록.some(item => item.id === saved.wifeIntent)
        ? saved.wifeIntent
        : WifeViewMode_기본설정.wifeIntent;
      const wifeServiceMode = ['auto', 'manual'].includes(saved.wifeServiceMode)
        ? saved.wifeServiceMode
        : WifeViewMode_기본설정.wifeServiceMode;
      const husbandServiceMode = ['auto', 'manual'].includes(saved.husbandServiceMode)
        ? saved.husbandServiceMode
        : WifeViewMode_기본설정.husbandServiceMode;
      const husbandProfile = WifeViewMode_남편프로필정규화하기(saved.husbandProfile);
      return {
        ...WifeViewMode_기본설정, ...saved, stance, wifeIntent,
        wifeServiceMode, husbandServiceMode, husbandProfile,
      };
    }

    function WifeViewMode_활성여부(state = api.store.game()) {
      return WifeViewMode_자료읽기(state).active === true;
    }

    function WifeViewMode_자료합치기(state, patch) {
      const current = state?.mods?.['wife-view-mode'] ?? {};
      return {
        ...state,
        mods: {
          ...(state.mods || {}),
          'wife-view-mode': { ...WifeViewMode_기본설정, ...current, ...patch },
        },
      };
    }

    function WifeViewMode_자동처리기록초기화하기() {
      WifeViewMode_실패선택목록.clear();
      WifeViewMode_강제중단사건목록.clear();
      WifeViewMode_자동처리연속상태 = { day: null, slot: null, count: 0, lastAt: 0 };
    }

    function WifeViewMode_남편시점복귀상태정리하기(state) {
      let next = state;
      const patronScene = next.activeScene?.patron;
      const wifeViewSceneKeys = [
        'wifeViewControlled', 'wifeViewAction', 'wifeViewAcceptedStage', 'wifeViewEscalatedFromStage',
        'wifeViewPatronEscalated', 'wifeViewPersistentPressure', 'wifeViewRejectionCount',
        'wifeViewBreakawayFailures', 'wifeViewFinishPreference', 'wifeViewPatronExposed',
        'wifeViewActVariant',
        'wifeViewPatronInitiated', 'wifeViewDeclinedMoveRoom',
      ];
      const wifeViewPatronScene = !!patronScene
        && wifeViewSceneKeys.some(key => Object.prototype.hasOwnProperty.call(patronScene, key));

      if (wifeViewPatronScene) {
        if (next.pendingEvent?.type === 'patron_interaction') next = { ...next, pendingEvent: undefined };
        try {
          next = api.fn('WifeViewModeEndPatronInteraction')(
            next,
            'elena_broke_for_service',
            { suppressEndText: true, suppressReactionWindow: true },
          ) || next;
        } catch (error) {
          api.warn(WifeViewMode_관계문구(`Wife_View_Mode: {rtHis} 시점 복귀 중 손님 장면 원본 종료가 실패해 안전 정리를 적용했습니다. ${error?.message || error}`, state));
          next = {
            ...next,
            activeScene: { ...(next.activeScene || {}), patron: undefined },
          };
          next = api.fn('updateWife')(next, wife => ({
            ...wife,
            currentTask: 'idle',
            taskTarget: undefined,
            busyUntilSlot: next.slot,
            sceneOverride: undefined,
            sceneVariant: undefined,
          }));
        }
      }

      if (next.pendingEvent?.type === 'wife_view_move' || next.pendingEvent?.type === 'wife_conversation'
        || wifeViewPatronScene && next.pendingEvent?.type === 'patron_interaction') {
        next = { ...next, pendingEvent: undefined };
      }

      if (next.activeScene?.table?.wifeViewLoseNext !== undefined) {
        const { wifeViewLoseNext, ...table } = next.activeScene.table;
        next = { ...next, activeScene: { ...next.activeScene, table } };
      }

      if (api.fn('wife')(next)?.wifeViewHoldPosition !== undefined) {
        next = api.fn('updateWife')(next, wife => {
          const { wifeViewHoldPosition, ...cleaned } = wife;
          return cleaned;
        });
      }
      for (const customer of next.customers || []) {
        if (customer.wifeViewReturnRoom && !customer.isResident && customer.status !== 'gone') {
          const room = next.locations?.[customer.wifeViewReturnRoom] ? customer.wifeViewReturnRoom : 'taproom';
          next = api.fn('WifeViewModeMoveCustomer')(next, customer.id, room);
        }
      }
      if (Array.isArray(next.customers) && next.customers.some(customer => customer.wifeViewGreeted !== undefined || customer.wifeViewReturnRoom !== undefined)) {
        next = {
          ...next,
          customers: next.customers.map(customer => {
            if (customer.wifeViewGreeted === undefined && customer.wifeViewReturnRoom === undefined) return customer;
            const { wifeViewGreeted, wifeViewReturnRoom, ...cleaned } = customer;
            return cleaned;
          }),
        };
      }

      if (wifeViewPatronScene) {
        const wife = api.fn('wife')(next);
        next = api.fn('log')(
          next,
          WifeViewMode_관계문구(`${wife?.name || WifeViewMode_관계문구("{rtHer}", state)}은(는) 진행하던 손님 응대를 정리합니다. {rtHis}이 다시 가게의 결정을 맡습니다.`, state),
        );
      }
      return next;
    }

    function WifeViewMode_모드전환하기() {
      const state = api.store.game();
      if (!state) {
        api.warn(WifeViewMode_관계문구("게임을 시작한 뒤 {rtHer} 시점으로 전환할 수 있습니다."));
        return;
      }
      WifeViewMode_자동처리기록초기화하기();
      api.store.update(oldState => {
        const browser = WifeViewMode_브라우저설정읽기();
        const saved = oldState?.mods?.['wife-view-mode'] || {};
        const current = { ...WifeViewMode_기본설정, stance: browser.defaultStance, ...saved };
        const base = current.active
          ? WifeViewMode_남편시점복귀상태정리하기(oldState)
          : oldState;
        return WifeViewMode_자료합치기(base, {
          ...current,
          active: !current.active,
          husbandProfile: WifeViewMode_남편프로필정규화하기(current.husbandProfile),
        });
      });
    }

    function WifeViewMode_비활성잔여상태정리하기() {
      const state = api.store.game();
      if (!state || WifeViewMode_활성여부(state) || WifeViewMode_비활성상태정리중) return;
      const patron = state.activeScene?.patron;
      const hasPatronMarker = !!patron && [
        'wifeViewControlled', 'wifeViewAction', 'wifeViewAcceptedStage', 'wifeViewEscalatedFromStage',
        'wifeViewPatronEscalated', 'wifeViewPersistentPressure', 'wifeViewRejectionCount',
        'wifeViewBreakawayFailures', 'wifeViewFinishPreference', 'wifeViewPatronExposed',
        'wifeViewActVariant',
        'wifeViewPatronInitiated', 'wifeViewDeclinedMoveRoom',
      ].some(key => Object.prototype.hasOwnProperty.call(patron, key));
      const hasTableMarker = state.activeScene?.table?.wifeViewLoseNext !== undefined;
      const hasCustomerMarker = state.customers?.some(customer => customer.wifeViewGreeted !== undefined || customer.wifeViewReturnRoom !== undefined);
      const hasHoldMarker = api.fn('wife')(state)?.wifeViewHoldPosition !== undefined;
      const hasMoveEvent = state.pendingEvent?.type === 'wife_view_move';
      if (!hasPatronMarker && !hasTableMarker && !hasCustomerMarker && !hasHoldMarker && !hasMoveEvent) return;
      WifeViewMode_비활성상태정리중 = true;
      try {
        api.store.update(current => WifeViewMode_활성여부(current)
          ? current
          : WifeViewMode_남편시점복귀상태정리하기(current));
      } finally {
        WifeViewMode_비활성상태정리중 = false;
      }
    }

    function WifeViewMode_스탠스바꾸기(stance) {
      if (!WifeViewMode_스탠스목록.some(item => item.id === stance)) return;
      api.settings.set({ defaultStance: stance });
      if (api.store.game()) api.data.set(old => ({ ...WifeViewMode_기본설정, ...(old || {}), stance }));
    }

    function WifeViewMode_응대방식바꾸기(wifeServiceMode) {
      if (!['auto', 'manual'].includes(wifeServiceMode) || !api.store.game()) return;
      api.store.update(state => {
        const next = WifeViewMode_자료합치기(state, { wifeServiceMode });
        return wifeServiceMode === 'auto'
          ? api.fn('updateWife')(next, wife => ({ ...wife, wifeViewHoldPosition: false })) : next;
      });
    }

    function WifeViewMode_남편응대방식바꾸기(husbandServiceMode) {
      if (!['auto', 'manual'].includes(husbandServiceMode) || !api.store.game()) return;
      api.data.set(old => ({ ...WifeViewMode_기본설정, ...(old || {}), husbandServiceMode }));
    }

    function WifeViewMode_남편프로필바꾸기(updater) {
      if (typeof updater !== 'function' || !api.store.game()) return;
      api.data.set(old => {
        const current = { ...WifeViewMode_기본설정, ...(old || {}) };
        const husbandProfile = WifeViewMode_남편프로필정규화하기(
          updater(WifeViewMode_남편프로필정규화하기(current.husbandProfile)),
        );
        return { ...current, husbandProfile };
      });
    }

    function WifeViewMode_사건지문만들기(state, event) {
      const choices = (event?.choices || []).map(choice => `${choice.id}:${choice.disabled ? 1 : 0}`).join('|');
      return [state?.day, state?.slot, event?.type, event?.category, event?.customerId,
        event?.situationId, event?.situationStepId, event?.alert?.kind, choices].join('::');
    }

    function WifeViewMode_사건진행서명만들기(state) {
      const patron = state?.activeScene?.patron;
      const sex = state?.activeScene?.sex;
      const wife = state ? api.fn('wife')(state) : null;
      const lastLog = state?.log?.[state.log.length - 1];
      return [
        state?.day, state?.slot, state?.phase, state?.log?.length, lastLog?.slot, lastLog?.text,
        patron?.customerId, patron?.stage, patron?.ticksElapsed, patron?.ticksAtStage,
        patron?.playerEncouragements, patron?.lastBuyDrinkSlot,
        sex?.stage, sex?.ticksElapsed, sex?.ticksAtStage,
        wife?.lastResponseSlot, wife?.lastResponse, wife?.lastResponseType,
      ].join('::');
    }

    function WifeViewMode_선택경로찾기(choiceId) {
      if (typeof choiceId !== 'string' || !choiceId) return null;
      const permission = choiceId.match(/::(accept|redirect|refuse)$/);
      if (permission) return { accept: 'direct', redirect: 'restrict', refuse: 'reject' }[permission[1]];
      if (choiceId.startsWith('bath_verb:')) return 'direct';
      const tail = choiceId.includes(':') ? choiceId.slice(choiceId.lastIndexOf(':') + 1) : choiceId;
      return WifeViewMode_선택경로[choiceId] || WifeViewMode_선택경로[tail] || null;
    }

    function WifeViewMode_사건맥락찾기(event) {
      const ids = [
        event?.type, event?.category, event?.customerId, event?.situationId,
        event?.situationStepId, event?.alert?.kind,
        ...(event?.choices || []).map(choice => choice.id),
      ].filter(Boolean).join('_').toLowerCase();
      const affinity = /anal/.test(ids) ? 'anal'
        : /blowjob|oral|mouth|swallow/.test(ids) ? 'oral'
          : /sex|vaginal|inside|penetrat/.test(ids) ? 'vaginal'
            : /flash|breast|tit|nude|strip|expos|outfit/.test(ids) ? 'exhibition'
              : /handjob|touch|grope|intimate|lap|wet/.test(ids) ? 'taboo'
              : /submit|obey|yield/.test(ids) ? 'submission'
                : /dominat|command|take_control/.test(ids) ? 'domination'
                  : /charge|payment|paid|gold|offer|transaction/.test(ids) ? 'prostitution'
                    : /drink|beer|wine|ale|intoxic/.test(ids) ? 'drinking'
                      : /public|taboo|dare|rough|humiliat/.test(ids) ? 'taboo'
                        : 'romantic';
      const intimate = ['patron_interaction', 'sex_scene'].includes(event?.type)
        || /patron|guest|flirt|kiss|touch|grope|intimate|handjob|blowjob|sex|anal|expos|dare/.test(ids);
      return { affinity, intimate };
    }

    function WifeViewMode_아내결정욕구계산하기(state, event) {
      const wife = api.fn('wife')(state);
      const attributes = api.fn('getEffectiveAttributes')(wife);
      const context = WifeViewMode_사건맥락찾기(event);
      const traits = new Set(wife?.latentTraits || []);
      let desire = (wife?.affinities?.[context.affinity] ?? 0) * 25
        + ((attributes?.openness ?? 50) - 50) * 0.28
        + ((attributes?.confidence ?? 50) - 50) * 0.1
        + ((wife?.stats?.arousal ?? 0) - 25) * 0.12;
      if (traits.has('true_prude')) desire -= 28;
      if (traits.has('self_protective')) desire -= 12;
      if (traits.has('latent_dominant')) desire += 8;
      if (traits.has('likes_cheating')) desire += 18;
      if (traits.has('cold_pragmatist') && context.affinity === 'prostitution') desire += 22;
      if (traits.has('latent_exhibitionist') && context.affinity === 'exhibition') desire += 24;
      if (traits.has('latent_voyeur')) desire += 6;
      if (traits.has('public_thrill_seeker') && context.affinity === 'taboo') desire += 18;
      if (traits.has('wants_to_be_corrupted')) desire += 12;
      if (traits.has('wary_of_drinks') && context.affinity === 'drinking') desire -= 24;
      return { ...context, desire };
    }

    function WifeViewMode_아내선택점수계산하기(state, event, route, index, allUnknown) {
      const data = WifeViewMode_자료읽기(state);
      const wife = api.fn('wife')(state);
      const attributes = api.fn('getEffectiveAttributes')(wife);
      const context = WifeViewMode_아내결정욕구계산하기(state, event);
      if (context.intimate) {
        const intentWeights = {
          refuse: { direct: -120, profit: -100, delegate: 20, restrict: 90, reject: 120, unknown: -80 },
          cautious: { direct: -25, profit: -20, delegate: 45, restrict: 70, reject: 55, unknown: -15 },
          allow: { direct: 105, profit: 75, delegate: 25, restrict: -20, reject: -80, unknown: 30 },
        }[data.wifeIntent];
        if (intentWeights) return (intentWeights[route || 'unknown'] ?? -100) - index * 0.01;
      }
      if (!route && allUnknown) return context.desire >= 0 ? 30 - index : index;
      const confidence = attributes?.confidence ?? 50;
      const trust = wife?.relationship?.trust ?? 50;
      const scores = {
        direct: context.desire + (event?.type === 'elena_ask' ? 28 : 0),
        profit: context.desire + (wife?.affinities?.prostitution ?? 0) * 22,
        delegate: 18 - Math.abs(context.desire) * 0.18 + (50 - confidence) * 0.15,
        restrict: -context.desire * 0.62 + (55 - trust) * 0.08,
        reject: -context.desire + (50 - confidence) * 0.08,
        unknown: -35,
      };
      return (scores[route || 'unknown'] ?? -100) - index * 0.01;
    }

    function WifeViewMode_남편반응판단하기(state, event, fingerprint) {
      const data = WifeViewMode_자료읽기(state);
      const profile = data.husbandProfile;
      const context = WifeViewMode_사건맥락찾기(event);
      const feelings = profile.feelings;
      const traits = new Set(profile.latentTraits);
      const husband = state.player || {};
      const hasProfitChoice = (event?.choices || []).some(choice => WifeViewMode_선택경로찾기(choice.id) === 'profit');
      let score = ({ companion: 7, protector: -40, money: hasProfitChoice ? 30 : 3, observer: 0, netorase: 38 }[data.stance] ?? 0)
        + (profile.affinities[context.affinity] ?? 0) * 28
        + (profile.relationship.trust - 50) * 0.18
        + (profile.libido - 50) * 0.14
        + (profile.selfConcept.openness - 50) * 0.18
        + (profile.selfConcept.confidence - 50) * 0.04
        + ((husband.stats?.arousal ?? 25) - 25) * 0.08
        + (feelings.desire ?? 0) * 0.1
        + (feelings.longing ?? 0) * 0.06
        + (feelings.devotion ?? 0) * 0.04
        + (feelings.tenderness ?? 0) * 0.04
        - (feelings.anger ?? 0) * 0.12
        - (feelings.contempt ?? 0) * 0.15
        - (feelings.disgust ?? 0) * 0.16
        - (feelings.shame ?? 0) * 0.08
        - (feelings.guilt ?? 0) * 0.07
        - (feelings.regret ?? 0) * 0.09
        - (feelings.sadness ?? 0) * 0.06
        - (feelings.humiliation ?? 0) * 0.12
        - (feelings.pushed_away ?? 0) * 0.1;
      if (traits.has('true_prude')) score -= 30;
      if (traits.has('self_protective')) score -= 16;
      if (traits.has('latent_dominant')) score += 6;
      if (traits.has('romance_starved') && context.affinity === 'romantic') score += 16;
      if (traits.has('likes_cheating')) score += 12;
      if (traits.has('cold_pragmatist') && (context.affinity === 'prostitution' || hasProfitChoice)) score += 24;
      if (traits.has('breaks_under_pressure')) score += score < 0 ? 8 : -3;
      if (traits.has('latent_exhibitionist') && context.affinity === 'exhibition') score += 24;
      if (traits.has('public_thrill_seeker') && context.affinity === 'taboo') score += 18;
      if (traits.has('latent_submissive')) score += 6;
      if (traits.has('easily_intoxicated') && context.affinity === 'drinking') score += 10;
      if (traits.has('wants_to_be_corrupted')) score += 15;
      if (traits.has('latent_masochist') && ['submission', 'taboo'].includes(context.affinity)) score += 12;
      if (traits.has('latent_voyeur')) score += 25;
      if (traits.has('jealousy_kindled')) score += 8;
      if (traits.has('wary_of_drinks') && context.affinity === 'drinking') score -= 28;
      score *= 0.8 + profile.volatility * 0.45;
      const id = score >= 36 ? 'encourage' : score >= 9 ? 'allow' : score > -23 ? 'partial' : 'stop';
      const label = { encourage: '권유', allow: '방임', partial: '부분 허용', stop: '중단' }[id];
      const lines = {
        encourage: [
          WifeViewMode_관계문구("“네가 원한다면 해봐. 어디까지 갈지는 네가 직접 정해.” {rtHis}은 {rtHer}의 결정을 재촉하지 않고 지지한다는 뜻을 분명히 합니다.", state),
          WifeViewMode_관계문구("“하고 싶은 마음이 있다면 숨기지 않아도 돼. 선택은 당신이 해.” {rtHis}은 한 걸음 물러나 {rtHer}에게 주도권을 넘깁니다.", state),
          WifeViewMode_관계문구("“당신이 직접 정해서 해봐. 나는 그 선택을 존중할게.” {rtHis}은 {rtHer}가 스스로 행동하기를 권합니다.", state),
        ],
        allow: [
          WifeViewMode_관계문구("“내 허락을 기다릴 필요는 없어. 당신 판단대로 해.” {rtHis}은 개입하지 않고 결정을 {rtHer}에게 맡깁니다.", state),
          WifeViewMode_관계문구("“당신이 괜찮다면 내가 정할 일은 아니야.” {rtHis}은 상황을 지켜보되 행동을 지시하지 않습니다.", state),
          WifeViewMode_관계문구("“나는 끼어들지 않을게. 하고 싶은지 아닌지는 당신이 정해.” {rtHis}은 {rtHer}의 선택을 기다립니다.", state),
        ],
        partial: [
          WifeViewMode_관계문구("“나는 여기까지라면 괜찮다고 생각해. 그 이상은 신중했으면 해.” {rtHis}은 자신의 선을 말하지만 최종 결정은 {rtHer}에게 남깁니다.", state),
          WifeViewMode_관계문구("“무리하지 말고, 싫어지는 순간에는 멈춰.” {rtHis}은 제한적인 허용 의사를 밝힌 뒤 {rtHer}의 판단을 기다립니다.", state),
          WifeViewMode_관계문구("“완전히 반대하지는 않지만 선은 지켜 줬으면 해.” {rtHis}은 조건을 말할 뿐 {rtHer}의 행동을 대신 결정하지 않습니다.", state),
        ],
        stop: [
          WifeViewMode_관계문구("“나는 이건 그만뒀으면 해. 그래도 억지로 막지는 않을게.” {rtHis}은 반대 의사를 밝히고 마지막 결정을 {rtHer}에게 넘깁니다.", state),
          WifeViewMode_관계문구("“내 생각은 중단이야. 하지만 실제로 어떻게 할지는 당신이 정해.” {rtHis}의 목소리는 단호하지만 직접 개입하지는 않습니다.", state),
          WifeViewMode_관계문구("“더 진행하지 않았으면 좋겠어.” {rtHis}은 불편함을 숨기지 않으면서도 {rtHer}가 스스로 답하기를 기다립니다.", state),
        ],
      }[id];
      let hash = 0;
      for (let index = 0; index < fingerprint.length; index += 1) hash = (hash * 31 + fingerprint.charCodeAt(index)) | 0;
      return { id, label, score, line: lines[Math.abs(hash) % lines.length], affinity: context.affinity };
    }

    function WifeViewMode_주어만들기(name) {
      const last = name?.charCodeAt(name.length - 1);
      if (last >= 0xac00 && last <= 0xd7a3) return `${name}${(last - 0xac00) % 28 ? '은' : '는'}`;
      return `${name || WifeViewMode_관계문구("{rtHer}")}은(는)`;
    }

    function WifeViewMode_아내결정묘사만들기(state, route, reaction) {
      const name = api.fn('wife')(state)?.name || WifeViewMode_관계문구("{rtHer}", state);
      const subject = WifeViewMode_주어만들기(name);
      const conflict = reaction?.id === 'stop' && ['direct', 'profit'].includes(route);
      if (conflict) return WifeViewMode_관계문구(`${subject} {rtHis}의 반대 의사를 들었지만 시선을 피하지 않습니다. “당신 뜻은 알겠어. 그래도 이번에는 내가 결정할게.” 그녀가 자신의 선택대로 행동하자 두 사람 사이에 불편한 침묵이 남습니다.`, state);
      return {
        direct: WifeViewMode_관계문구(`${subject} {rtHis}의 반응을 들은 뒤, 자신의 의사로 행동을 받아들이고 계속하기로 결정합니다.`, state),
        profit: `${subject} 조건과 대가를 직접 따져 본 뒤, 자신의 판단으로 행동하기로 결정합니다.`,
        delegate: `${subject} 지금 당장 결론을 서두르지 않고 상황을 더 지켜보기로 결정합니다.`,
        restrict: `${subject} 자신이 받아들일 수 있는 선을 정하고 그 범위까지만 허용하기로 결정합니다.`,
        reject: WifeViewMode_관계문구(`${subject} {rtHis}의 입장과 별개로 자신이 원하지 않는다고 판단해 거절하기로 결정합니다.`, state),
      }[route] || WifeViewMode_관계문구(`${subject} {rtHis}의 말을 들은 뒤에도 행동의 결론은 스스로 내립니다.`, state);
    }

    function WifeViewMode_남편갈등적용하기(state) {
      const profile = WifeViewMode_자료읽기(state).husbandProfile;
      return WifeViewMode_자료합치기(state, {
        husbandProfile: {
          ...profile,
          relationship: { ...profile.relationship, trust: Math.max(0, profile.relationship.trust - 5) },
          feelings: {
            ...profile.feelings,
            anger: Math.min(100, profile.feelings.anger + 6),
            pushed_away: Math.min(100, profile.feelings.pushed_away + 5),
            sadness: Math.min(100, profile.feelings.sadness + 3),
          },
        },
      });
    }

    function WifeViewMode_행동선호키찾기(actionId) {
      if (/anal/.test(actionId)) return 'anal';
      if (/blowjob|oral|mouth/.test(actionId)) return 'oral';
      if (/sex|vaginal|inside/.test(actionId)) return 'vaginal';
      if (/flash|tit|breast|bend|dance|expos/.test(actionId)) return 'exhibition';
      if (/drink|beer|wine/.test(actionId)) return 'drinking';
      if (/work_them|payment|paid|gold/.test(actionId)) return 'prostitution';
      if (/kiss|flirt|talk|cards/.test(actionId)) return 'romantic';
      return 'taboo';
    }

    function WifeViewMode_아내행동남편반응적용하기(state, actionId, customer) {
      if (!WifeViewMode_활성여부(state) || !actionId || actionId === 'talk') return state;
      const affinity = WifeViewMode_행동선호키찾기(actionId);
      const event = {
        type: 'wife_view_action',
        category: `${affinity}_${actionId}`,
        customerId: customer?.id,
        choices: [{ id: 'direct' }],
      };
      const fingerprint = WifeViewMode_사건지문만들기(state, event);
      const reaction = WifeViewMode_남편반응판단하기(state, event, fingerprint);
      let next = api.fn('log')(state, reaction.line);
      next = api.fn('log')(next, WifeViewMode_아내결정묘사만들기(next, 'direct', reaction));
      return reaction.id === 'stop' ? WifeViewMode_남편갈등적용하기(next) : next;
    }

    function WifeViewMode_재정사건여부(state, event) {
      if (!event) return false;
      const choiceIds = (event.choices || []).map(choice => String(choice.id || ''));
      const customer = event.customerId
        ? state.customers?.find(item => item.id === event.customerId)
        : null;
      return customer?.isCollector === true
        || ['collector_briefing', 'collector_negotiation', 'rent_notice'].includes(event.type)
        || choiceIds.some(id => id === 'pay_rent_now'
          || id === 'defer_rent'
          || id.startsWith('collector_')
          || id.startsWith('collector_brief:')
          || id.startsWith('neg:')
          || id.startsWith('scenario_lenders_man_'));
    }

    function WifeViewMode_응대사건종류찾기(event) {
      const ids = (event?.choices || []).map(choice => choice.id);
      if (ids.includes('back_round_send_wife')) return 'back-room';
      if (ids.includes('privy_let_her') || ids.includes('privy_point')) return 'toilet';
      if (event?.category === 'bathhouse_service') return 'bathhouse';
      return null;
    }

    function WifeViewMode_응대인물차단사유찾기(state, actor) {
      if (state.gameOver) return '게임이 종료되었습니다.';
      if (state.activeScene?.patron || state.activeScene?.sex || state.activeScene?.table
        || state.activeScene?.bathhouse) return '진행 중인 장면을 먼저 끝내야 합니다.';
      if (actor === 'husband') {
        if (state.errandSession || state.activeShoppingSession
          || !api.fn('WifeViewModeHusbandInTavern')(state)) return WifeViewMode_관계문구("{rtHis}이 가게로 돌아와야 합니다.", state);
        if ((state.player?.stats?.energy ?? 1) <= 0) return WifeViewMode_관계문구("{rtHis}이 휴식해야 합니다.", state);
        return null;
      }
      const wife = api.fn('wife')(state);
      if (!wife || wife.passedOutAtSlot != null || wife.retiredAtSlot != null
        || ['away', 'sleeping', 'passed_out'].includes(wife.currentTask)
        || (wife.stats?.energy ?? 0) <= 0) return WifeViewMode_관계문구("{rtHer}가 현재 응대할 수 없는 상태입니다.", state);
      if (api.fn('wifeLocation')(state) !== 'taproom') return WifeViewMode_관계문구("{rtHer}가 홀에 있어야 합니다.", state);
      if ((wife.busyUntilSlot ?? 0) > state.slot || wife.locationUntilSlot != null) return '현재 작업을 먼저 마쳐야 합니다.';
      return null;
    }

    function WifeViewMode_응대사건표현바꾸기(state, event) {
      if (!WifeViewMode_활성여부(state)) return event;
      const kind = WifeViewMode_응대사건종류찾기(event);
      if (!kind) return event;
      const choices = (event.choices || []).map(choice => {
        let label, description, blocked;
        if (kind === 'back-room') {
          if (choice.id === 'back_round_send_wife') {
            label = '직접 들고가기';
            description = '쟁반을 들고 뒷방 손님에게 직접 서빙합니다. 원래 응대 시간 동안 뒷방에 머무릅니다.';
            blocked = WifeViewMode_응대인물차단사유찾기(state, 'wife');
            if (!blocked && !api.fn('WifeViewModeBackRoomWifeAvailable')(state)) blocked = choice.disabledReason || '현재 직접 서빙할 수 없습니다.';
          } else if (choice.id === 'back_round_go_yourself') {
            label = WifeViewMode_관계문구("{rtHis}에게 들고가달라 하기", state);
            description = WifeViewMode_관계문구("{rtHis}에게 뒷방 서빙을 부탁하고, {rtHer}는 현재 장소에 남습니다.", state);
            blocked = WifeViewMode_응대인물차단사유찾기(state, 'husband');
          }
        } else if (kind === 'toilet') {
          const wording = {
            privy_let_her: ['직접 안내하기', '손님을 화장실 문까지 직접 안내합니다.'],
            privy_line: ['안내하고 바로 돌아오기', '화장실 문까지 위치를 알려준 뒤 홀에 남아 응대를 이어갑니다.'],
            privy_point: ['위치 알려주기', WifeViewMode_관계문구("계단 옆 화장실 위치를 손으로 가리켜 알려줍니다. {rtHer}는 현재 장소에 남습니다.", state)],
          }[choice.id];
          if (wording) {
            [label, description] = wording;
            blocked = WifeViewMode_응대인물차단사유찾기(state, 'wife');
            if (!state.customers.some(customer => customer.id === event.customerId)) blocked = '손님이 이미 자리를 떠났습니다.';
          }
        } else if (kind === 'bathhouse' && choice.id.startsWith('bathhouse_service:')) {
          // Change only the ordinary service perspective; retain native request, consent and payment rules.
          if (choice.id.split(':')[2] === 'accept') {
            label = '요청에 직접 응하기';
            description = '손님의 요청에 응합니다. 가능 여부와 비용은 원래 게임의 판정을 따릅니다.';
          } else if (choice.id.split(':')[2] === 'refuse') {
            label = '요청 거절하고 응대 마치기';
            description = choice.description;
          }
        }
        return label ? { ...choice, label, description: blocked || description,
          disabled: !!choice.disabled || !!blocked, disabledReason: blocked || choice.disabledReason } : choice;
      });
      return { ...event, choices, ...(kind === 'toilet'
        ? { text: `${event.customerName || '손님'}이(가) 화장실 위치를 묻습니다. 어떻게 안내할지 직접 선택합니다.` } : {}) };
    }

    function WifeViewMode_사건판단하기(state, event) {
      const enabled = (WifeViewMode_응대사건표현바꾸기(state, event)?.choices || []).filter(choice => !choice.disabled);
      const fingerprint = WifeViewMode_사건지문만들기(state, event);
      if (globalThis.__waywardPregnancyCompatibleWifeView?.ownsConversation(state, event)) {
        return { owner: 'wife-manual', available: enabled, fingerprint,
          reason: '약 복용 대화와 임신·출산 반응 이벤트는 직접 확인합니다' };
      }
      if (globalThis.__waywardDeliveryCompatibleWifeView?.ownsOrder(state)) {
        return { owner: 'wife-manual', available: enabled, fingerprint,
          reason: '배달 담당자는 배달 주문 창에서 직접 선택합니다' };
      }
      if (WifeViewMode_강제중단사건목록.has(fingerprint)) {
        return {
          owner: 'blocked',
          reason: '같은 시간대에 사건 처리가 반복되어 자동 진행을 안전하게 중단했습니다',
          fingerprint,
        };
      }
      const failedChoices = WifeViewMode_실패선택목록.get(fingerprint) || new Set();
      const available = enabled.filter(choice => !failedChoices.has(choice.id));
      if (!available.length) return { owner: 'blocked', reason: '적용 가능한 원본 사건 분기가 남아 있지 않습니다', fingerprint };
      if (WifeViewMode_재정사건여부(state, event)) {
        return {
          owner: 'wife-manual', available,
          reason: WifeViewMode_관계문구("빚쟁이·집주인·월세 사건은 자동으로 넘기지 않고 {rtHer}가 원본 선택지에서 직접 결정합니다", state),
          fingerprint,
        };
      }
      if (event.type === 'wife_view_move' || event.type === 'sex_scene'
        || ['patron_offer', 'elena_ask', 'elena_initiative'].includes(event.type)
        || available.some(choice => /back_room_private_|upstairs_take|step_away|leave_for|outing/.test(choice.id))) {
        return { owner: 'wife-manual', available, fingerprint,
          reason: WifeViewMode_관계문구("{rtHer}의 접촉·이동·함께하는 행동은 플레이어가 직접 결정합니다", state) };
      }
      if (available.length === 1 && WifeViewMode_확인선택.has(available[0].id)) {
        return { owner: 'system', choice: available[0], reason: '분기 없는 확인 알림', fingerprint };
      }
      if (event.type === 'wife_conversation') {
        return {
          owner: 'system', choice: { id: 'close_wife_conversation', label: '대화를 마침', wifeViewSynthetic: 'close-wife-conversation' }, route: 'delegate',
          reason: WifeViewMode_관계문구("{rtHer} 시점 전환 전에 열려 있던 {rtHis} 대화 메뉴를 종료", state), fingerprint,
        };
      }
      if (event.type === 'elena_ask' && event.customerId === 'ask_not_him') {
        const safeChoice = available.find(choice => choice.id === 'ask_not_him::redirect')
          || available.find(choice => choice.id === 'ask_not_him::refuse');
        if (safeChoice) {
          const reaction = WifeViewMode_남편반응판단하기(state, event, fingerprint);
          return {
            owner: 'wife', choice: safeChoice, route: 'reject', reaction,
            wifeLine: WifeViewMode_아내결정묘사만들기(state, 'reject', reaction),
            reason: WifeViewMode_관계문구("{rtHer}가 이미 밝힌 명시적 거절을 자신의 결정으로 유지", state), fingerprint,
          };
        }
      }
      const classified = available.map((choice, index) => ({
        choice,
        index,
        route: WifeViewMode_선택경로찾기(choice.id),
      }));
      const allUnknown = classified.every(item => !item.route);
      const ranked = classified
        .map(item => ({
          ...item,
          score: WifeViewMode_아내선택점수계산하기(state, event, item.route, item.index, allUnknown),
        }))
        .sort((left, right) => right.score - left.score || left.index - right.index);
      const selected = ranked[0];
      const route = selected.route || 'unknown';
      const reaction = WifeViewMode_남편반응판단하기(state, event, fingerprint);
      return {
        owner: 'wife', choice: selected.choice, route, reaction,
        wifeLine: WifeViewMode_아내결정묘사만들기(state, route, reaction),
        reason: selected.route
          ? WifeViewMode_관계문구(`{rtHer}의 성향·감정·행동 선호를 반영한 ${route} 분기`, state)
          : WifeViewMode_관계문구(`새 선택지의 원본 순서를 {rtHer}의 현재 욕구와 함께 적용한 호환 분기`, state),
        fingerprint,
      };
    }

    function WifeViewMode_사건선택보내기(event, choice) {
      if (!event || !choice) return;
      if (event.type === 'wife_view_move') {
        api.store.dispatch({ type: 'wife-view-mode/resolve-move', choiceId: choice.id });
        return;
      }
      return WifeViewMode_승인된이동실행하기(() => {
      if (choice.wifeViewSynthetic === 'close-wife-conversation') {
        api.store.dispatch({ type: 'wife-view-mode/close-wife-conversation' });
      } else if (event.type === 'wife_conversation') {
        api.store.dispatch({
          type: 'wife_topic',
          topicId: choice.id,
          ...(choice.targetCustomerId ? { targetCustomerId: choice.targetCustomerId } : {}),
        });
      } else if (event.type === 'sex_scene') {
        api.store.dispatch({ type: 'scene_action', actionId: choice.id });
      } else if (event.type === 'patron_interaction') {
        api.store.dispatch({ type: 'patron_interaction_choice', choiceId: choice.id });
      } else {
        api.store.dispatch({ type: 'resolve_event', choiceId: choice.id });
      }
      });
    }

    function WifeViewMode_남편판단예약하기() {
      const state = api.store.game();
      const event = state?.pendingEvent;
      if (!state || !event || typeof event !== 'object' || !WifeViewMode_활성여부(state)) return;
      if (event.type === 'patron_interaction' && state.activeScene?.patron?.wifeViewControlled) return;
      if (WifeViewMode_처리시도.has(event)) return;
      const plan = WifeViewMode_사건판단하기(state, event);
      if (!plan.choice || ['blocked', 'wife-manual'].includes(plan.owner)) return;
      const now = Date.now();
      const rapidContinuation = WifeViewMode_자동처리연속상태.day === state.day
        && WifeViewMode_자동처리연속상태.slot === state.slot
        && now - WifeViewMode_자동처리연속상태.lastAt < 1000;
      WifeViewMode_자동처리연속상태 = {
        day: state.day,
        slot: state.slot,
        count: rapidContinuation ? WifeViewMode_자동처리연속상태.count + 1 : 1,
        lastAt: now,
      };
      if (WifeViewMode_자동처리연속상태.count > WifeViewMode_자동처리연속제한) {
        WifeViewMode_강제중단사건목록.add(plan.fingerprint);
        api.warn('Wife_View_Mode: 같은 시간대의 사건 자동 처리가 반복되어 화면 멈춤을 막기 위해 중단했습니다.');
        api.store.update(currentState => ({ ...currentState }));
        return;
      }
      WifeViewMode_처리시도.add(event);
      queueMicrotask(() => {
        const current = api.store.game();
        if (!current || !WifeViewMode_활성여부(current)) return;
        if (current.pendingEvent !== event) return;
        if (WifeViewMode_사건지문만들기(current, event) !== plan.fingerprint) return;
        const stillEnabled = plan.choice.wifeViewSynthetic
          ? plan.choice
          : (event.choices || []).find(choice => choice.id === plan.choice.id && !choice.disabled);
        if (!stillEnabled) return;
        const priorFailures = WifeViewMode_실패선택목록.get(plan.fingerprint)?.size ?? 0;
        if (plan.owner === 'wife' && priorFailures === 0) {
          api.store.dispatch({
            type: 'wife-view-mode/husband-comment',
            fingerprint: plan.fingerprint,
            line: plan.reaction?.line,
          });
        }
        const beforeChoice = api.store.game();
        const beforeProgress = WifeViewMode_사건진행서명만들기(beforeChoice);
        const beforePendingEvent = beforeChoice?.pendingEvent;
        WifeViewMode_사건선택보내기(event, stillEnabled);
        queueMicrotask(() => {
          const after = api.store.game();
          const progressed = after?.pendingEvent !== beforePendingEvent
            || WifeViewMode_사건진행서명만들기(after) !== beforeProgress;
          const ignored = !progressed;
          if (ignored) {
            const failed = WifeViewMode_실패선택목록.get(plan.fingerprint) || new Set();
            failed.add(plan.choice.id);
            WifeViewMode_실패선택목록.set(plan.fingerprint, failed);
            WifeViewMode_처리시도.delete(event);
            api.warn(WifeViewMode_관계문구(`Wife_View_Mode: {rtHer}가 고른 원본 분기(${plan.choice.id})가 진행되지 않아 다음 호환 분기를 시도합니다.`));
            const enabledCount = (event.choices || []).filter(choice => !choice.disabled).length;
            if (failed.size >= enabledCount) {
              api.store.update(currentState => ({ ...currentState }));
              return;
            }
            queueMicrotask(WifeViewMode_남편판단예약하기);
            return;
          }
          WifeViewMode_실패선택목록.delete(plan.fingerprint);
          if (plan.owner === 'wife') {
            api.store.dispatch({
              type: 'wife-view-mode/wife-decision-result',
              line: plan.wifeLine,
              route: plan.route,
              husbandReaction: plan.reaction?.id,
            });
          }
        });
      });
    }

    function WifeViewMode_설정본문그리기(body, win) {
      body.style.cssText += ';font-size:14px;color:#e7e5e4;min-width:min(680px,calc(100vw - 48px));';
      const data = WifeViewMode_자료읽기();
      const section = (title, description, ...children) => api.ui.h(
        'section',
        { class: 'wml-section', style: 'margin:0 0 14px;padding:12px;border:1px solid #44403c;border-radius:8px;background:#1c1917' },
        api.ui.h('div', { style: 'font-weight:700;color:#fcd34d;margin-bottom:4px' }, title),
        api.ui.h('div', { class: 'wml-small wml-muted', style: 'margin-bottom:9px;line-height:1.45' }, description),
        ...children,
      );
      const card = (item, selected, onClick) => api.ui.h(
        'button',
        {
          type: 'button',
          onclick: onClick,
          style: `display:block;width:100%;text-align:left;padding:9px 10px;margin:6px 0;border-radius:7px;border:1px solid ${selected ? '#d97706' : '#57534e'};background:${selected ? '#78350f' : '#292524'};color:#fafaf9;cursor:pointer`,
        },
        api.ui.h('div', { style: 'font-weight:700;margin-bottom:2px' }, `${selected ? '● ' : '○ '}${item.label}`),
        api.ui.h('div', { class: 'wml-small', style: 'color:#a8a29e;line-height:1.45' }, item.description),
      );
      const numberControl = (label, value, min, max, step, description, onChange) => api.ui.h(
        'label',
        { style: 'display:block;padding:8px;margin:6px 0;border:1px solid #44403c;border-radius:7px;background:#292524' },
        api.ui.h('div', { style: 'font-weight:700;margin-bottom:5px' }, label),
        api.ui.h('input', {
          type: 'number', min: String(min), max: String(max), step: String(step), value: String(value),
          onchange: event => {
            const next = Number(event.target.value);
            if (!Number.isFinite(next)) return;
            onChange(Math.max(min, Math.min(max, next)));
            win.refresh();
          },
          style: 'width:100%;padding:6px 8px;border:1px solid #57534e;border-radius:5px;background:#1c1917;color:#fafaf9',
        }),
        api.ui.h('div', { class: 'wml-small', style: 'color:#a8a29e;margin-top:5px;line-height:1.4' }, description),
      );
      const profileNumber = (group, key, value, min, max, step, label, description) => numberControl(
        label, value, min, max, step, description,
        next => WifeViewMode_남편프로필바꾸기(profile => ({
          ...profile,
          [group]: { ...profile[group], [key]: next },
        })),
      );
      const activeButton = api.ui.button(
        data.active ? WifeViewMode_관계문구("{rtHis} 시점으로 복귀") : WifeViewMode_관계문구("{rtHer} 시점으로 전환"),
        () => { WifeViewMode_모드전환하기(); win.refresh(); },
        { primary: !data.active },
      );
      body.append(
        section(
          '모드 상태',
          WifeViewMode_관계문구("전환 상태와 {rtHis}의 관계·특성·행동 선호는 현재 세이브에 저장됩니다. {rtHis} 시점으로 돌아가도 설정값은 유지됩니다."),
          activeButton,
        ),
        section(
          WifeViewMode_관계문구("{rtHis} 스탠스"),
          WifeViewMode_관계문구("{rtHis}이 사건에서 권유·방임·부분 허용·중단 중 어떤 입장을 말할지 정하는 기본 태도입니다. 실제 행동은 {rtHer}가 자신의 수치로 결정합니다."),
          ...WifeViewMode_스탠스목록.map(item => card(item, data.stance === item.id, () => {
            WifeViewMode_스탠스바꾸기(item.id);
            win.refresh();
          })),
        ),
        section(
          WifeViewMode_관계문구("{rtHis}의 내면"),
          WifeViewMode_관계문구("{rtHer} 에디터의 현재 상태·내면 항목 가운데 기존 {rtHis} 데이터에 없던 수치입니다. {rtHis}이 {rtHer}의 행동에 어떤 입장을 말할지 판정할 때 사용합니다."),
          numberControl(
            '성욕', data.husbandProfile.libido, 8, 95, 1,
            WifeViewMode_관계문구("{rtHis}의 성적 관심 강도입니다. 높을수록 친밀한 행동을 권유하는 쪽으로 기울 수 있습니다."),
            next => WifeViewMode_남편프로필바꾸기(profile => ({ ...profile, libido: next })),
          ),
          numberControl(
            '감정 변동성', data.husbandProfile.volatility, 0.1, 0.85, 0.01,
            WifeViewMode_관계문구("{rtHis}의 감정과 입장이 사건에 반응하는 폭입니다. 높을수록 현재 감정과 성향의 영향이 커집니다."),
            next => WifeViewMode_남편프로필바꾸기(profile => ({ ...profile, volatility: next })),
          ),
          profileNumber(
            'selfConcept', 'openness', data.husbandProfile.selfConcept.openness, 0, 100, 0.01,
            '내면 개방성', WifeViewMode_관계문구("{rtHis}이 스스로 새로운 경험을 받아들인다고 여기는 정도입니다."),
          ),
          profileNumber(
            'selfConcept', 'confidence', data.husbandProfile.selfConcept.confidence, 0, 100, 0.01,
            '내면 자신감', WifeViewMode_관계문구("{rtHis}이 자신의 판단과 경계를 얼마나 확신하는지 나타냅니다."),
          ),
        ),
        section(
          WifeViewMode_관계문구("{rtHis}과 {rtHer}의 관계"),
          WifeViewMode_관계문구("{rtHer} 에디터의 관계·지속 감정에 대응하는 {rtHis} 쪽 수치입니다. 모든 감정은 {rtHis}이 {rtHer}에게 느끼는 강도입니다."),
          profileNumber(
            'relationship', 'trust', data.husbandProfile.relationship.trust, 0, 100, 1,
            WifeViewMode_관계문구("{rtHer}에 대한 신뢰"), WifeViewMode_관계문구("{rtHis}이 {rtHer}의 판단과 약속을 신뢰하는 정도입니다. 범위 0~100."),
          ),
          ...WifeViewMode_남편감정목록.map(item => profileNumber(
            'feelings', item.id, data.husbandProfile.feelings[item.id], 0, 100, 1,
            WifeViewMode_관계문구(`{rtHer}에 대한 ${item.label}`), WifeViewMode_관계문구(`{rtHis}이 {rtHer}에게 느끼는 ${item.label}의 지속 강도입니다. 범위 0~100.`),
          )),
        ),
        section(
          WifeViewMode_관계문구("{rtHis}의 행동 선호"),
          WifeViewMode_관계문구("값이 높을수록 {rtHis}이 {rtHer}에게 해당 행동을 요구하거나 권하려 합니다. -2는 강한 반대, 0은 중립, 2는 강한 요구입니다."),
          ...WifeViewMode_남편행동선호목록.map(item => profileNumber(
            'affinities', item.id, data.husbandProfile.affinities[item.id], -2, 2, 0.01,
            item.label, item.description,
          )),
        ),
        section(
          WifeViewMode_관계문구("{rtHis}의 특성"),
          WifeViewMode_관계문구("에디터처럼 한 줄에서 실제 보유와 {rtHer}가 발견한 상태를 설정합니다. 보유 특성만 {rtHis}의 입장 판정에 사용됩니다."),
          api.ui.h(
            'div',
            { style: 'display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px' },
            ...WifeViewMode_남편특성목록.map(item => {
              const owned = data.husbandProfile.latentTraits.includes(item.id);
              const noticed = data.husbandProfile.noticedLatentTraits.includes(item.id);
              const toggleOwned = () => {
                WifeViewMode_남편프로필바꾸기(profile => {
                  const nextOwned = !profile.latentTraits.includes(item.id);
                  return {
                    ...profile,
                    latentTraits: nextOwned
                      ? [...profile.latentTraits, item.id]
                      : profile.latentTraits.filter(id => id !== item.id),
                    noticedLatentTraits: nextOwned
                      ? profile.noticedLatentTraits
                      : profile.noticedLatentTraits.filter(id => id !== item.id),
                  };
                });
                win.refresh();
              };
              const toggleNoticed = () => {
                WifeViewMode_남편프로필바꾸기(profile => {
                  const nextNoticed = !profile.noticedLatentTraits.includes(item.id);
                  return {
                    ...profile,
                    latentTraits: nextNoticed && !profile.latentTraits.includes(item.id)
                      ? [...profile.latentTraits, item.id]
                      : profile.latentTraits,
                    noticedLatentTraits: nextNoticed
                      ? [...profile.noticedLatentTraits, item.id]
                      : profile.noticedLatentTraits.filter(id => id !== item.id),
                  };
                });
                win.refresh();
              };
              return api.ui.h(
                'div',
                { title: item.description, style: 'display:grid;grid-template-columns:minmax(0,1fr) auto auto;gap:8px;align-items:center;padding:6px 8px;border:1px solid #44403c;border-radius:6px;background:#292524' },
                api.ui.h('span', { style: 'font-weight:650;color:#e7e5e4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis' }, item.label),
                api.ui.h('label', { class: 'wml-small', style: 'display:flex;align-items:center;gap:3px;color:#d6d3d1;cursor:pointer' },
                  api.ui.h('input', { type: 'checkbox', checked: owned, onchange: toggleOwned }), '보유'),
                api.ui.h('label', { class: 'wml-small', style: 'display:flex;align-items:center;gap:3px;color:#a8a29e;cursor:pointer' },
                  api.ui.h('input', { type: 'checkbox', checked: noticed, onchange: toggleNoticed }), '발견'),
              );
            }),
          ),
        ),
        section(
          WifeViewMode_관계문구("{rtHis}의 손님 응대 AI"),
          WifeViewMode_관계문구("{rtHer} 시점에서 AI {rtHis}이 인사·주문받기·서빙·품절 안내·청소·조리를 자동으로 처리할지 정합니다."),
          ...[
            {
              id: 'auto', label: '자동',
              description: WifeViewMode_관계문구("{rtHis}이 비어 있는 손님 응대와 주점 일을 원래 플레이어 메커니즘으로 자동 처리합니다."),
            },
            {
              id: 'manual', label: WifeViewMode_관계문구("수동 — {rtHis} 손님 응대 AI 중지"),
              description: WifeViewMode_관계문구("{rtHis}의 자율 응대·요리·청소를 중지합니다. {rtHer}가 직접 하는 행동에는 영향을 주지 않습니다."),
            },
          ].map(item => card(item, data.husbandServiceMode === item.id, () => {
            WifeViewMode_남편응대방식바꾸기(item.id);
            win.refresh();
          })),
        ),
        section(
          WifeViewMode_관계문구("{rtHer}의 손님 응대 AI"),
          WifeViewMode_관계문구("수동에서는 응대뿐 아니라 자율 휴식·외출·장소 이동도 멈춥니다. 손님 장면 중에는 자동 설정이어도 {rtHer}가 조작합니다. 수면·의식불명·이미 시작한 외출의 복귀는 유지됩니다."),
          ...[
            {
              id: 'auto', label: '자동',
              description: WifeViewMode_관계문구("원래 게임의 {rtHer} AI가 손님 응대와 선술집 일을 자동으로 처리합니다. 선택하면 장면 종료 후 현재 위치 대기를 해제합니다."),
            },
            {
              id: 'manual', label: WifeViewMode_관계문구("수동 — 인사, 메뉴 묻기 등 {rtHer} AI 중지"),
              description: WifeViewMode_관계문구("{rtHer}의 자율 영업·생활 이동을 멈추고 행동 패널과 위치 카드로 직접 조작합니다."),
            },
          ].map(item => card(item, data.wifeServiceMode === item.id, () => {
            WifeViewMode_응대방식바꾸기(item.id);
            win.refresh();
          })),
        ),
        section(
          WifeViewMode_관계문구("{rtHer}의 기본 의향"),
          WifeViewMode_관계문구("손님과의 관계 진행에서 {rtHer}의 판정 상한과 자발적 진행 여부를 정합니다. 게임의 강한 경계나 위험 판정은 강제로 해제하지 않습니다."),
          ...WifeViewMode_의향목록.map(item => card(item, data.wifeIntent === item.id, () => {
            if (api.store.game()) api.store.dispatch({ type: 'wife-view-mode/set-intent', intent: item.id });
            win.refresh();
          })),
        ),
        api.ui.h(
          'div',
          { class: 'wml-note', style: 'line-height:1.5' },
          WifeViewMode_관계문구("사건에서 {rtHis}은 자신의 입장을 말로만 밝힙니다. 원본 선택지는 {rtHer}의 성향·감정·행동 선호로 자동 선택하며, 새 선택지는 멈추지 않고 {rtHer}의 현재 욕구와 원본 순서를 이용한 호환 분기로 처리합니다."),
        ),
      );
    }

    function WifeViewMode_설정창열기() {
      if (WifeViewMode_설정창?.el?.isConnected) {
        WifeViewMode_설정창.focus?.();
        WifeViewMode_설정창.refresh?.();
        return;
      }
      WifeViewMode_설정창 = api.ui.window({
        id: 'wife-view-mode-settings',
        title: WifeViewMode_관계문구("{rtHer} 시점 모드 설정"),
        width: 820,
        height: 820,
        settings: true,
        render: WifeViewMode_설정본문그리기,
        onClose() { WifeViewMode_설정창 = null; },
      });
    }

    function WifeViewMode_버튼그리기({ label, description, onClick, disabled = false, tone = 'stone' }) {
      const color = tone === 'amber'
        ? 'border-amber-700 bg-amber-900/50 hover:bg-amber-800/60 text-amber-100'
        : tone === 'rose'
          ? 'border-rose-800 bg-rose-950/40 hover:bg-rose-900/50 text-rose-100'
          : 'border-stone-700 bg-stone-800 hover:bg-stone-700 text-stone-100';
      return JSX.jsxs('button', {
        type: 'button',
        disabled,
        onClick,
        className: `w-full text-left p-3 rounded-lg border transition-colors ${color} disabled:opacity-40 disabled:cursor-not-allowed`,
        children: [
          JSX.jsx('div', { className: 'font-medium text-sm', children: label }),
          JSX.jsx('div', { className: 'text-xs text-stone-400 mt-0.5 leading-relaxed', children: description }),
        ],
      });
    }

    function WifeViewMode_복장차단사유찾기(state, wife) {
      if (state.pendingEvent) return '먼저 현재 사건을 처리해야 복장을 바꿀 수 있습니다.';
      if (state.activeScene?.patron || state.activeScene?.sex || state.activeScene?.table) return '진행 중인 장면이나 게임을 끝낸 뒤 복장을 바꿀 수 있습니다.';
      if (!wife) return WifeViewMode_관계문구("{rtHer} 캐릭터 정보를 찾을 수 없습니다.", state);
      if (wife.passedOutAtSlot != null || ['away', 'sleeping', 'passed_out'].includes(wife.currentTask)) return WifeViewMode_관계문구("현재 {rtHer} 상태에서는 복장을 바꿀 수 없습니다.", state);
      return null;
    }

    function WifeViewMode_복장생각만들기(wife, choice) {
      const special = {
        suggest_naked: '속마음: 아무것도 걸치지 않는 것은 시선이 부담스럽지만, 지금 자신의 마음이 허락하는지 가늠해 봅니다.',
        suggest_no_underwear: '속마음: 겉으로 드러나지 않는 대담함에 긴장하면서도 묘한 자극을 느낍니다.',
        ask_open_bodice: '속마음: 앞섶을 느슨하게 하면 시선이 쏠릴 것을 알기에 조심스럽게 생각합니다.',
        ask_topless: '속마음: 상의를 벗는 노출을 감당할 수 있을지 자신의 용기와 기분을 살핍니다.',
        ask_just_panties: '속마음: 속옷만 남기는 차림이 지나치지 않을지 망설이며 주변 시선을 의식합니다.',
        ask_no_bottom: '속마음: 하의를 벗은 채 움직이는 모습을 떠올리며 긴장과 호기심 사이에서 고민합니다.',
      };
      if (special[choice.id]) return special[choice.id];
      if (choice.id.startsWith('suggest_outfit_')) {
        const outfitId = choice.id.slice(15);
        const outfit = api.fn('outfitById')(outfitId);
        const boldness = outfit?.boldnessScore ?? 0;
        const confidence = wife?.attributes?.confidence ?? 50;
        const openness = wife?.attributes?.openness ?? 50;
        const feeling = boldness >= 60 && confidence + openness < 110
          ? '노출이 큰 복장이라 사람들의 시선이 신경 쓰이고 조금 망설여집니다.'
          : boldness >= 30
            ? '평소보다 대담하지만 지금의 자신에게 어울릴지 거울 앞에서 생각해 봅니다.'
            : '익숙하고 편안한 쪽에 가까워 부담 없이 입을 수 있다고 생각합니다.';
        return `속마음: ${feeling}`;
      }
      return `속마음: ${choice.description || '지금 이 차림이 자신의 기분에 맞는지 생각합니다.'}`;
    }

    function WifeViewMode_복장선택이름만들기(choice) {
      const label = String(choice?.label || choice?.id || '복장 바꾸기');
      return label
        .replace(/\s*(?:을\(를\)|을|를)?\s*입으라고\s*(?:말)?하기\s*$/, ' 입기')
        .replace(/\s+/g, ' ')
        .trim();
    }

    function WifeViewMode_복장변경그리기({ state, wife }) {
      const [open, setOpen] = React.useState(false);
      const blocked = WifeViewMode_복장차단사유찾기(state, wife);
      let choices = [];
      try {
        choices = (api.fn('WifeViewModeConversationMenu')(state, 'clothing')?.choices || [])
          .filter(choice => choice.id !== 'back');
      } catch (error) {
        api.warn(`Wife_View_Mode: 원래 복장 목록을 읽지 못했습니다. ${error?.message || error}`);
      }
      return JSX.jsxs('div', {
        className: 'mt-3 pt-3 border-t border-amber-900/60',
        children: [
          WifeViewMode_버튼그리기({
            label: open ? '복장 변경 닫기' : '복장 변경',
            description: blocked || WifeViewMode_관계문구("원래 {rtHis} 시점의 복장 선택지를 그대로 열고, 각 복장에 대한 {rtHer}의 속마음을 확인합니다."),
            disabled: !!blocked,
            onClick: () => setOpen(value => !value),
            tone: 'amber',
          }),
          open && !blocked ? JSX.jsx('div', {
            className: 'grid grid-cols-1 gap-2 mt-2',
            children: choices.length ? choices.map(choice => JSX.jsx(WifeViewMode_버튼그리기, {
              label: WifeViewMode_복장선택이름만들기(choice),
              description: WifeViewMode_복장생각만들기(wife, choice),
              onClick: () => api.store.dispatch({ type: 'wife-view-mode/change-outfit', topicId: choice.id }),
            }, choice.id)) : JSX.jsx('p', {
              className: 'text-xs text-stone-500',
              children: '현재 상태에서 선택할 수 있는 다른 복장이 없습니다.',
            }),
          }) : null,
        ],
      });
    }

    function WifeViewMode_사건그리기(state, event) {
      const plan = WifeViewMode_사건판단하기(state, event);
      const presented = WifeViewMode_응대사건표현바꾸기(state, event);
      const pregnancyPresentation = globalThis.__waywardPregnancyCompatibleWifeView?.getPresentation?.(state, event);
      return JSX.jsxs('section', {
        className: 'mb-4 p-3 rounded-lg border-2 border-amber-700 bg-stone-900/80',
        children: [
          JSX.jsx('h3', {
            className: 'text-sm font-bold text-amber-300 mb-1',
            children: pregnancyPresentation?.title || (plan.owner === 'wife-manual'
              ? WifeViewMode_관계문구("{rtHer}가 직접 결정할 사건", state)
              : plan.owner === 'system'
              ? '시스템 알림 처리 중'
              : plan.owner === 'blocked'
                ? WifeViewMode_관계문구("{rtHer}의 결정을 적용하지 못함", state)
                : WifeViewMode_관계문구(`{rtHer}가 결정 중 · {rtHis}의 입장: ${plan.reaction?.label || '방임'}`, state)),
          }),
          JSX.jsx('p', { className: 'text-sm text-stone-200 leading-relaxed mb-2',
            style: pregnancyPresentation ? { whiteSpace: 'pre-line' } : undefined,
            children: pregnancyPresentation?.body || presented.text || event.question || '처리할 사건이 있습니다.' }),
          plan.reaction?.line ? JSX.jsx('p', {
            className: 'text-sm text-amber-100 leading-relaxed mb-2 p-2 rounded border border-amber-900/60 bg-amber-950/20',
            children: plan.reaction.line,
          }) : null,
          JSX.jsx('p', {
            className: 'text-xs text-stone-500 mb-3',
            children: pregnancyPresentation?.description || (plan.owner === 'wife-manual'
              ? `${plan.reason}. 선택 결과와 비용·기한·게임오버 조건은 원래 게임 규칙을 그대로 따릅니다.`
              : WifeViewMode_관계문구(`${plan.reason}. {rtHis}의 발언은 행동을 강제하지 않으며, 실행 직전에 같은 사건인지 다시 확인합니다.`, state)),
          }),
          plan.owner !== 'wife-manual' ? JSX.jsx('div', {
            className: 'text-xs text-amber-300/80 animate-pulse',
            children: plan.choice
              ? WifeViewMode_관계문구(`{rtHer}의 선택 예정: ${plan.choice.label || plan.choice.id}`, state)
              : '원본 사건 처리기가 진행 가능한 분기를 제공하지 않았습니다.',
          }) : JSX.jsx('div', {
            className: 'grid grid-cols-1 gap-2',
            children: (WifeViewMode_응대사건종류찾기(event) ? presented.choices : plan.available || []).map(choice => WifeViewMode_버튼그리기({
              label: choice.label || choice.id,
              description: choice.description || WifeViewMode_관계문구("{rtHer}가 이 원본 사건 선택지를 직접 고릅니다.", state),
              disabled: !!choice.disabled,
              onClick: () => {
                const current = api.store.game();
                if (!current?.pendingEvent
                  || WifeViewMode_사건지문만들기(current, current.pendingEvent) !== plan.fingerprint) return;
                WifeViewMode_사건선택보내기(current.pendingEvent, choice);
              },
              tone: choice.id === 'defer_rent' ? 'rose' : 'amber',
            })),
          }),
          plan.owner === 'blocked' ? JSX.jsx('div', {
            className: 'mt-3',
            children: WifeViewMode_버튼그리기({
              label: '멈춘 사건 정리하고 계속하기',
              description: WifeViewMode_관계문구("원본 선택지를 다시 표시하지 않고, 처리할 수 없는 사건 상태만 안전하게 정리해 {rtHer}의 행동 화면으로 돌아갑니다.", state),
              onClick: () => api.store.dispatch({
                type: 'wife-view-mode/recover-blocked-event', fingerprint: plan.fingerprint,
              }),
              tone: 'rose',
            }),
          }) : null,
        ],
      });
    }

    function WifeViewMode_준비관리그리기(state) {
      if (state.phase !== 'prep') return null;
      const targets = state.supplyTargets || { food: 12, beer: 12, wine: 5 };
      const labels = { food: '식재료', beer: '맥주', wine: '와인' };
      const tavern = state.tavern || {};
      const owned = new Set(tavern.qualityUpgrades || []);
      const qualityUpgrades = (api.fn('WifeViewModeQualityUpgrades') || []).filter(item => !owned.has(item.id));
      const facilities = [
        ...qualityUpgrades.map(item => ({
          id: item.id,
          label: item.label,
          description: `${item.cost}골드 · 품질 +${item.qualityBoost} · ${item.description}`,
          action: { type: 'buy_quality_upgrade', upgradeId: item.id },
          disabled: state.economy.gold < item.cost,
        })),
        ...tavern.backRoomReady === false ? [{
          id: 'back-room', label: '뒷방 치우기',
          description: '원래 게임의 비용·시간·해금 조건을 그대로 적용해 휴게실을 준비합니다.',
          action: { type: 'clean_back_room' },
        }] : [],
        ...!tavern.hasRoom ? [{
          id: 'room-1', label: '위층 객실 꾸미기',
          description: '창고를 대여 가능한 객실로 바꿉니다. 원래 게임의 비용과 30분 작업 시간을 적용합니다.',
          action: { type: 'buy_room_upgrade' },
        }] : [],
        ...tavern.hasRoom && !tavern.hasRoom2 ? [{
          id: 'room-2', label: '두 번째 객실 만들기',
          description: '투숙객 수용량을 늘립니다. 원래 게임의 비용과 조건을 적용합니다.',
          action: { type: 'buy_room2_upgrade' },
        }] : [],
        ...!tavern.hasBathhouse ? [{
          id: 'bathhouse', label: '목욕탕 짓기',
          description: '목욕료 수입과 숙박료 상한을 높입니다. 원래 게임의 비용과 조건을 적용합니다.',
          action: { type: 'buy_bathhouse' },
        }] : [],
      ];
      return JSX.jsxs('section', {
        className: 'mb-4 p-3 rounded-lg border border-emerald-900/70 bg-emerald-950/20',
        children: [
          JSX.jsx('h3', { className: 'text-sm font-bold text-emerald-300 mb-1', children: '개장 전 물품·시설 관리' }),
          JSX.jsx('p', {
            className: 'text-xs text-stone-400 mb-3',
            children: WifeViewMode_관계문구("{rtHer} 플레이어가 목표 구매 수량을 직접 지정합니다. 실제 구매와 시설 공사는 원래 게임 액션이 비용·시간·조건을 검증합니다.", state),
          }),
          JSX.jsx('div', {
            className: 'rounded border border-stone-700 divide-y divide-stone-700 mb-2',
            children: ['food', 'beer', 'wine'].map(item => JSX.jsxs('label', {
              className: 'flex items-center gap-3 px-3 py-2 text-sm',
              children: [
                JSX.jsx('span', { className: 'w-16 text-stone-300', children: labels[item] }),
                JSX.jsx('span', { className: 'text-xs text-stone-500', children: `현재 ${state.supplies?.[item] ?? 0}` }),
                JSX.jsx('input', {
                  type: 'number', min: 0, max: 99, value: targets[item] ?? 0,
                  onChange: event => api.store.dispatch({
                    type: 'set_supply_target', item, value: Math.max(0, Math.min(99, Number(event.target.value) || 0)),
                  }),
                  className: 'ml-auto w-16 px-2 py-1 rounded bg-stone-900 border border-stone-600 text-right text-stone-100',
                  title: `${labels[item]} 개장 전 목표 구매 수량`,
                }),
              ],
            }, item)),
          }),
          WifeViewMode_버튼그리기({
            label: '목표 수량까지 물품 구매',
            description: '지정한 수량과 현재 보유량의 차이만 구매합니다. 가격·보유 골드·구매 시간은 원래 게임 규칙을 따릅니다.',
            onClick: () => api.store.dispatch({ type: 'stock_up', skip: [] }),
            tone: 'amber',
          }),
          JSX.jsx('div', { className: 'mt-3 mb-1 text-xs font-bold uppercase tracking-wider text-stone-500', children: '시설 업그레이드' }),
          facilities.length ? JSX.jsx('div', {
            className: 'grid grid-cols-1 gap-2',
            children: facilities.map(item => JSX.jsx(WifeViewMode_버튼그리기, {
              label: item.label,
              description: item.description,
              disabled: !!item.disabled,
              onClick: () => api.store.dispatch(item.action),
            }, item.id)),
          }) : JSX.jsx('p', { className: 'text-xs text-stone-500', children: '현재 표시할 시설 업그레이드가 없습니다.' }),
        ],
      });
    }

    function WifeViewMode_인물장소찾기(state, id) {
      return Object.entries(state.locations || {}).find(([, location]) => location?.occupants?.includes(id))?.[0] || null;
    }

    function WifeViewMode_수동응대차단사유찾기(state, wife, customer, { allowControlled = false } = {}) {
      const controlled = !!(state.activeScene?.patron?.wifeViewControlled
        && state.activeScene.patron.customerId === customer?.id);
      if (state.gameOver) return '게임이 종료되었습니다.';
      if (state.pendingEvent && !(allowControlled && controlled && state.pendingEvent.type === 'patron_interaction')) return '먼저 현재 사건을 처리해야 합니다.';
      if ((state.activeScene?.patron && !(allowControlled && controlled)) || state.activeScene?.sex || state.activeScene?.table) return '진행 중인 장면이나 게임을 먼저 끝내야 합니다.';
      if (!wife || !customer) return '응대할 인물을 찾을 수 없습니다.';
      if (wife.passedOutAtSlot != null || ['away', 'sleeping', 'passed_out'].includes(wife.currentTask)) return WifeViewMode_관계문구("현재 {rtHer} 상태에서는 응대할 수 없습니다.", state);
      if (!controlled && (wife.busyUntilSlot ?? 0) > state.slot) return `현재 작업이 ${Math.max(1, wife.busyUntilSlot - state.slot)}분 뒤 끝납니다.`;
      if (WifeViewMode_인물장소찾기(state, customer.id) !== api.fn('wifeLocation')(state)) return '같은 장소에 있는 손님만 응대할 수 있습니다.';
      return null;
    }

    function WifeViewMode_가게응대차단사유찾기(state, wife, customer) {
      const blocked = WifeViewMode_수동응대차단사유찾기(state, wife, customer);
      if (blocked) return blocked;
      if (!['service', 'last_call'].includes(state.phase)) return '영업 중에만 가게 응대를 할 수 있습니다.';
      if (api.fn('wifeLocation')(state) !== 'taproom') return WifeViewMode_관계문구("{rtHer}를 홀로 이동한 뒤 응대할 수 있습니다.", state);
      if (wife.retiredAtSlot != null || (wife.stats?.energy ?? 0) <= 0) return WifeViewMode_관계문구("{rtHer}가 휴식 중입니다.", state);
      return null;
    }

    function WifeViewMode_가게손님버튼보강하기(result, args) {
      const state = api.store.game();
      if (!WifeViewMode_활성여부(state)) return result;
      const customer = args[0]?.customer;
      if (!customer) return result;
      const blocked = WifeViewMode_가게응대차단사유찾기(state, api.fn('wife')(state), customer);
      const dispatch = kind => api.store.dispatch({
        type: 'wife-view-mode/wife-service', kind, customerId: customer.id, fromShop: true,
      });
      return WifeViewMode_요소찾아바꾸기(result,
        node => node.type === api.fn('WifeViewModeServiceButton') || node.type === api.fn('WifeViewModeServeControl'),
        node => {
          if (node.type === api.fn('WifeViewModeServeControl') && !blocked) {
            return React.cloneElement(node, { onServe: () => dispatch('serve'), onApologize: () => dispatch('out-of-stock') });
          }
          const kind = customer.status === 'arrived' ? 'greet'
            : ['greeted', 'wants_more'].includes(customer.status) ? 'order' : 'serve';
          const label = node.props.label || (api.fn('waitressAvailable')(state, customer.order) ? '서빙' : '품절 안내');
          return JSX.jsx('button', {
            className: 'bg-amber-700 hover:bg-amber-600 disabled:opacity-40 disabled:cursor-not-allowed rounded px-1.5 py-0.5 text-[0.7rem] whitespace-nowrap',
            'data-wvm-shop-service': kind, title: blocked || `${api.fn('wife')(state).name}가 직접 응대합니다.`,
            disabled: !!blocked, onClick: event => { event.stopPropagation(); dispatch(kind); }, children: label,
          }, node.key);
        });
    }

    function WifeViewMode_심야마무리가능여부(state) {
      if (!WifeViewMode_활성여부(state) || state.gameOver || state.pendingEvent
        || state.activeScene?.patron || state.activeScene?.sex || state.activeScene?.table || state.activeScene?.bathhouse
        || !['service', 'last_call', 'closed', 'bedroom'].includes(state.phase)) return false;
      const room = api.fn('wifeLocation')(state);
      if (!['bedroom', 'elena_room'].includes(room)) return false;
      const minute = api.fn('WifeViewModeMinuteOfDay')(state.slot);
      return state.phase === 'bedroom' || state.phase === 'closed' || minute >= 22 * 60 || minute < 2 * 60;
    }

    function WifeViewMode_멈춘장면정리하기(state) {
      const scene = state.activeScene?.patron;
      if (!WifeViewMode_활성여부(state) || !scene?.wifeViewControlled
        || state.pendingEvent && state.pendingEvent.type !== 'patron_interaction') return state;
      const wife = api.fn('wife')(state);
      const room = api.fn('wifeLocation')(state);
      const customer = state.customers.find(item => item.id === scene.customerId);
      const unavailable = !wife || !customer || ['gone', 'leaving'].includes(customer.status)
        || wife.passedOutAtSlot != null || ['away', 'sleeping', 'passed_out'].includes(wife.currentTask)
        || (wife.stats?.energy ?? 0) <= 0 || WifeViewMode_인물장소찾기(state, scene.customerId) !== room;
      if (!unavailable) return state;
      let next = api.fn('WifeViewModeEndPatronInteraction')(state, 'patron_gave_up');
      if (wife) {
        next = api.fn('updateWife')(next, current => ({ ...current,
          currentTask: wife.currentTask, taskTarget: undefined, busyUntilSlot: wife.busyUntilSlot,
          retiredAtSlot: wife.retiredAtSlot, wakeSlot: wife.wakeSlot, passedOutAtSlot: wife.passedOutAtSlot,
        }));
        if (api.fn('wifeLocation')(next) !== room) next = WifeViewMode_승인된이동실행하기(() => api.fn('moveWife')(next, room));
      }
      return api.fn('log')(next, '상대와 떨어졌거나 현재 상태로 진행할 수 없어 장면을 정리했습니다. 시간 보내기 또는 휴식으로 이어갈 수 있습니다.');
    }

    function WifeViewMode_손님이동장소목록(state, customer) {
      const current = WifeViewMode_인물장소찾기(state, customer.id);
      const rooms = ['taproom'];
      const backRoom = state.locations?.back_room;
      if (WifeViewMode_장소사용가능여부(state, 'back_room')
        && !backRoom?.meta?.privatePatron && !backRoom?.meta?.party) rooms.push('back_room');
      if (WifeViewMode_장소사용가능여부(state, 'bathhouse')) rooms.push('bathhouse');
      if (WifeViewMode_장소사용가능여부(state, 'bedroom')) rooms.push('bedroom');
      for (const room of ['upstairs_hall', 'upstairs_room_2']) {
        const renter = room === 'upstairs_hall' ? state.tavern?.tonightRenter : state.tavern?.tonightRenter2;
        if (WifeViewMode_장소사용가능여부(state, room)
          && (!renter?.customerId || renter.customerId === customer.id)) rooms.push(room);
      }
      return [...new Set(rooms)].filter(room => room !== current);
    }

    function WifeViewMode_대사고르기(state, customer, lines, salt, extra = {}) {
      const key = `${state.day || 0}:${state.slot || 0}:${customer?.id || ''}:${salt}`;
      let hash = 0;
      for (let index = 0; index < key.length; index += 1) hash = (hash * 31 + key.charCodeAt(index)) | 0;
      const line = lines[Math.abs(hash) % lines.length];
      const returning = (state.patronRecords || []).some(record => record.name === customer?.name && (record.visitCount ?? 0) > 1);
      return line({ state, wife: api.fn('wife')(state), customer, returning, ...extra });
    }

    function WifeViewMode_손님장면단계이름(stage) {
      return {
        chatting: '옆에 앉아 대화하는 중',
        flirting: '추파를 던지며 대화하는 중',
        light_touch: '가벼운 스킨십 중',
        bold_touch: '대담한 스킨십 중',
        groping: '짙은 스킨십 중',
        intimate: '은밀한 접촉 중',
        handjob_patron: '손으로 자극하는 중',
        blowjob_patron: '구강성교 중',
        rubbing_patron: '몸을 맞대고 자극하는 중',
        sex_patron: '성관계 중',
      }[stage] || stage;
    }

    function WifeViewMode_손님장면단계번호(stage) {
      return WifeViewMode_손님장면순서.indexOf(stage);
    }

    function WifeViewMode_인사후행동목록만들기(state, customer, scene = null) {
      let dares = [];
      try {
        dares = (api.fn('WifeViewModeDaresAvailable')(state, 'with_someone') || []).filter(dare =>
          (api.fn('WifeViewModeDareTargets')(state, dare) || []).some(target => target.id === customer.id));
      } catch (error) {
        api.warn(`Wife_View_Mode: 원래 권하기 행동을 읽지 못했습니다. ${error?.message || error}`);
      }
      const exposed = !!(scene?.wifeViewPatronExposed
        || ['handjob_patron', 'blowjob_patron', 'rubbing_patron', 'sex_patron'].includes(scene?.stage));
      const directActions = WifeViewMode_직접성행동목록
        .filter(item => exposed ? item.id !== 'expose_penis' : !item.requiresExposed)
        .map(item => ({ ...item, kind: 'activity' }));
      const baseActions = [
        {
          id: 'talk', kind: 'activity', label: '옆에 앉아 대화하기',
          description: '손님의 옆에 앉아서 먼저 말을 걸고 대화를 시작합니다.',
        },
        {
          id: 'flirt', kind: 'activity', label: '추파 던지기',
          description: WifeViewMode_관계문구("손님의 외모와 분위기를 칭찬하며 {rtHer}가 먼저 추파를 던집니다.", state),
        },
        {
          id: 'light_touch', kind: 'activity', label: '가벼운 스킨십',
          description: '손님의 팔이나 어깨를 스치듯 가볍게 만지고 그의 반응을 살핍니다.',
        },
      ];
      const dareActions = dares
        .filter(dare => !['dare_say_hello', 'dare_sit_with_him', 'dare_handjob_patron'].includes(dare.id)
          && !WifeViewMode_이동권하기행동.has(dare.id))
        .map(dare => ({
          id: dare.id,
          kind: 'dare',
          label: WifeViewMode_권하기행동표현[dare.id]?.label || dare.label,
          description: WifeViewMode_권하기행동표현[dare.id]?.description
            || WifeViewMode_관계문구(`{rtHer}가 자신의 판단으로 ${dare.label || dare.id} 행동을 시작합니다.`, state),
        }));
      return [...baseActions, ...dareActions, ...directActions];
    }

    function WifeViewMode_손님행동버튼그리기(items, customer, blocked) {
      return items.map(item => JSX.jsx(WifeViewMode_버튼그리기, {
        label: item.label,
        description: blocked || item.description,
        disabled: !!blocked,
        onClick: () => api.store.dispatch(item.kind === 'activity'
          ? { type: 'wife-view-mode/start-patron-activity', activity: item.id, customerId: customer.id }
          : { type: 'wife-view-mode/patron-action', dareId: item.id, customerId: customer.id }),
        tone: WifeViewMode_직접성행동목록.some(action => action.id === item.id) ? 'rose' : 'stone',
      }, item.id));
    }

    function WifeViewMode_손님장면그리기({ state, wife, customer, scene }) {
      const [moveOpen, setMoveOpen] = React.useState(false);
      const [otherOpen, setOtherOpen] = React.useState(false);
      const blocked = WifeViewMode_수동응대차단사유찾기(state, wife, customer, { allowControlled: true });
      const moveRooms = WifeViewMode_손님이동장소목록(state, customer);
      const otherActions = WifeViewMode_인사후행동목록만들기(state, customer, scene);
      const roomLabels = api.fn('brothelRoomLabels') || {};
      let joinCandidates = [];
      try {
        joinCandidates = (api.fn('WifeViewModeJoinCandidates')(state) || [])
          .filter(candidate => candidate.id !== scene.customerId);
      } catch (error) {
        api.warn(`Wife_View_Mode: 합류 가능한 손님을 읽지 못했습니다. ${error?.message || error}`);
      }
      let joinSlots = [];
      try {
        joinSlots = api.fn('joinSlots')(scene, scene.stage, scene.joinedPatronSlots || {}, false) || [];
      } catch {
        joinSlots = [];
      }
      const canInvite = joinSlots.length > 0;
      const canChooseFinish = ['blowjob_patron', 'sex_patron'].includes(scene.stage);
      const patronEscalated = !!(scene.wifeViewPatronEscalated || scene.wifeViewPersistentPressure);
      const persistentPressure = !!scene.wifeViewPersistentPressure;
      const currentLine = wife?.lastResponseSlot != null ? wife.lastResponse : null;
      return JSX.jsxs('div', {
        className: 'mt-3',
        children: [
          JSX.jsx('div', { className: 'text-xs font-bold uppercase tracking-wider text-violet-300 mb-1', children: `${customer.name} · ${WifeViewMode_손님장면단계이름(scene.stage)}` }),
          currentLine ? JSX.jsx('p', { className: 'text-xs text-stone-300 leading-relaxed mb-2 p-2 rounded border border-stone-800 bg-stone-950/50', children: currentLine }) : null,
          JSX.jsx('div', {
            className: 'grid grid-cols-1 gap-2',
            children: [
              WifeViewMode_버튼그리기({
                label: '계속하기',
                description: blocked || '손님과 하던 것을 계속하고, 1분 동안 손님의 반응을 봅니다.',
                disabled: !!blocked,
                onClick: () => api.store.dispatch({ type: 'wife-view-mode/continue-patron' }),
                tone: 'amber',
              }),
              WifeViewMode_버튼그리기({
                label: patronEscalated ? '거절하기' : scene.wifeViewPatronInitiated ? '중단 요청하기' : '그만두기',
                description: patronEscalated
                  ? `${customer.name}이(가) 먼저 높인 접촉 수위를 거절하고 직전 단계로 물러납니다.`
                  : '현재 손님과의 장면을 안전하게 끝내고 일반 행동으로 돌아갑니다.',
                disabled: !!blocked,
                onClick: () => api.store.dispatch({ type: patronEscalated
                  ? 'wife-view-mode/reject-patron-escalation'
                  : 'wife-view-mode/stop-patron' }),
                tone: patronEscalated ? 'rose' : undefined,
              }),
              patronEscalated ? WifeViewMode_버튼그리기({
                label: '중단 요청하기',
                description: '상대에게 현재 상호작용 전체를 중단하겠다는 의사를 밝힙니다.',
                disabled: !!blocked,
                onClick: () => api.store.dispatch({ type: 'wife-view-mode/stop-patron' }),
              }) : null,
              persistentPressure ? WifeViewMode_버튼그리기({
                label: '뿌리치기',
                description: '손님의 손을 뿌리치고 나옵니다. 힘 수치에 따라서 결과가 달라집니다.',
                disabled: !!blocked,
                onClick: () => api.store.dispatch({ type: 'wife-view-mode/break-away' }),
                tone: 'rose',
              }) : null,
              !scene.afterglow ? WifeViewMode_버튼그리기({
                label: otherOpen ? '다른 행동 닫기' : '다른 행동하기',
                description: '인사 후 행동 목록을 다시 열어 지금의 대화나 접촉에서 다른 행동으로 전환합니다.',
                disabled: !!blocked,
                onClick: () => setOtherOpen(value => !value),
              }) : null,
            ],
          }),
          otherOpen && !scene.afterglow ? JSX.jsxs('div', {
            className: 'mt-3',
            children: [
              JSX.jsx('div', { className: 'text-xs font-bold uppercase tracking-wider text-stone-500 mb-1', children: '다른 행동 선택' }),
              JSX.jsx('div', {
                className: 'grid grid-cols-1 gap-2',
                children: WifeViewMode_손님행동버튼그리기(otherActions, customer, blocked),
              }),
            ],
          }) : null,
          !scene.afterglow && canInvite && joinCandidates.length ? JSX.jsxs('div', {
            className: 'mt-3',
            children: [
              JSX.jsx('div', { className: 'text-xs font-bold uppercase tracking-wider text-stone-500 mb-1', children: '합류 제안' }),
              JSX.jsx('div', {
                className: 'grid grid-cols-1 gap-2',
                children: joinCandidates.map(candidate => WifeViewMode_버튼그리기({
                  label: `${candidate.name}에게 합류를 제안하기`,
                  description: WifeViewMode_관계문구("특정 손님에게 지금 하는 행위에 동참하도록 {rtHer}가 직접 권유합니다. 수락 여부와 가능한 자리는 원래 게임 판정을 따릅니다."),
                  disabled: !!blocked,
                  onClick: () => api.store.dispatch({ type: 'wife-view-mode/invite-join', customerId: candidate.id }),
                })),
              }),
            ],
          }) : null,
          !scene.afterglow && canChooseFinish ? JSX.jsxs('div', {
            className: 'mt-3',
            children: [
              JSX.jsx('div', { className: 'text-xs font-bold uppercase tracking-wider text-stone-500 mb-1', children: '마지막 부탁' }),
              JSX.jsx('div', {
                className: 'grid grid-cols-1 gap-2',
                children: [
                  WifeViewMode_버튼그리기({
                    label: scene.wifeViewFinishPreference === 'inside' ? '안에 싸도록 부탁 · 선택됨' : '안에 싸도록 부탁',
                    description: scene.stage === 'blowjob_patron' ? '손님에게 입 안에 사정해 달라고 부탁합니다.' : '손님에게 몸 안에 사정해 달라고 부탁합니다.',
                    disabled: !!blocked,
                    onClick: () => api.store.dispatch({ type: 'wife-view-mode/set-finish-preference', preference: 'inside' }),
                    tone: 'rose',
                  }),
                  WifeViewMode_버튼그리기({
                    label: scene.wifeViewFinishPreference === 'outside' ? '밖에 싸도록 부탁 · 선택됨' : '밖에 싸도록 부탁',
                    description: '손님에게 몸 밖에 사정해 달라고 부탁합니다.',
                    disabled: !!blocked,
                    onClick: () => api.store.dispatch({ type: 'wife-view-mode/set-finish-preference', preference: 'outside' }),
                  }),
                ],
              }),
            ],
          }) : null,
          moveRooms.length ? JSX.jsxs('div', {
            className: 'mt-3',
            children: [
              WifeViewMode_버튼그리기({
                label: moveOpen ? '장소 선택 닫기' : '장소옮기기 제안하기',
                description: `${customer.name}에게 함께 다른 장소로 옮기자고 제안합니다. 버튼을 누르면 이동 가능한 장소가 표시됩니다.`,
                disabled: !!blocked,
                onClick: () => setMoveOpen(value => !value),
              }),
              moveOpen ? JSX.jsx('div', {
                className: 'grid grid-cols-1 gap-2 mt-2',
                children: moveRooms.map(room => WifeViewMode_버튼그리기({
                  label: `${roomLabels[room] || room}(으)로 함께 이동`,
                  description: WifeViewMode_관계문구("현재 상호작용을 유지한 채 {rtHer}와 손님이 함께 이동합니다."),
                  disabled: !!blocked,
                  onClick: () => api.store.dispatch({ type: 'wife-view-mode/propose-move', customerId: customer.id, room }),
                })),
              }) : null,
            ],
          }) : null,
        ],
      });
    }

    function WifeViewMode_손님행동그리기({ state, wife }) {
      const location = api.fn('wifeLocation')(state);
      const controlledScene = state.activeScene?.patron?.wifeViewControlled ? state.activeScene.patron : null;
      const customers = (state.customers || []).filter(customer =>
        !['gone', 'leaving'].includes(customer.status)
        && WifeViewMode_인물장소찾기(state, customer.id) === location);
      const [selectedId, setSelectedId] = React.useState(controlledScene?.customerId || customers[0]?.id || '');
      const [moveOpen, setMoveOpen] = React.useState(false);
      const customer = controlledScene
        ? state.customers?.find(item => item.id === controlledScene.customerId)
        : customers.find(item => item.id === selectedId) || customers[0];
      const data = WifeViewMode_자료읽기(state);
      if (!customer) return JSX.jsxs('section', {
        className: 'mb-4 p-3 rounded-lg border border-stone-800 bg-stone-900/40',
        children: [
          JSX.jsx('h3', { className: 'text-sm font-bold text-cyan-300', children: '같은 장소의 손님 행동' }),
          JSX.jsx('p', { className: 'text-xs text-stone-500 mt-1', children: WifeViewMode_관계문구("현재 {rtHer}와 같은 장소에 행동 가능한 손님이 없습니다.") }),
        ],
      });
      let dares = [];
      try {
        dares = (api.fn('WifeViewModeDaresAvailable')(state, 'with_someone') || []).filter(dare =>
          (api.fn('WifeViewModeDareTargets')(state, dare) || []).some(target => target.id === customer.id));
      } catch (error) {
        api.warn(`Wife_View_Mode: 원래 권하기 행동을 읽지 못했습니다. ${error?.message || error}`);
      }
      const serviceBlocked = WifeViewMode_수동응대차단사유찾기(state, wife, customer);
      const moveRooms = WifeViewMode_손님이동장소목록(state, customer);
      const roomLabels = api.fn('brothelRoomLabels') || {};
      const greeted = customer.wifeViewGreeted === true;
      const greetDare = dares.find(dare => dare.id === 'dare_say_hello');
      const afterGreetingActions = WifeViewMode_인사후행동목록만들기(state, customer);
      const serviceAction = customer.status === 'arrived'
        ? { kind: 'greet', label: '인사하고 자리 안내', description: WifeViewMode_관계문구("원래 {rtHer}의 손님 맞이 처리를 직접 실행합니다.") }
        : customer.status === 'greeted' || customer.status === 'wants_more'
          ? { kind: 'order', label: '메뉴 묻기·주문받기', description: WifeViewMode_관계문구("원래 {rtHer}의 주문 생성과 인내심 초기화를 그대로 사용합니다.") }
          : customer.status === 'ordered' && customer.order
            ? api.fn('waitressAvailable')(state, customer.order)
              ? { kind: 'serve', label: `${customer.order.replace(/_/g, ' ')} 서빙`, description: WifeViewMode_관계문구("재고·가격·수입·서빙 기록을 원래 {rtHer} 메커니즘으로 처리합니다.") }
              : { kind: 'out-of-stock', label: '품절 안내', description: '원래 게임의 대체 주문 또는 손님 이탈 판정을 사용합니다.' }
            : null;
      return JSX.jsxs('section', {
        className: 'mb-4 p-3 rounded-lg border border-cyan-900/70 bg-cyan-950/15',
        children: [
          JSX.jsx('h3', { className: 'text-sm font-bold text-cyan-300 mb-1', children: '같은 장소의 손님 행동' }),
          JSX.jsxs('p', {
            className: 'text-xs text-stone-500 mb-2',
            children: [WifeViewMode_관계문구("{rtHer} 응대 AI: "), data.wifeServiceMode === 'manual' ? '수동' : '자동', ' · 현재 위치: ', roomLabels[location] || location],
          }),
          JSX.jsx('select', {
            value: customer.id,
            disabled: !!controlledScene,
            onChange: event => {
              setSelectedId(event.target.value);
              setMoveOpen(false);
            },
            className: 'w-full mb-2 px-2 py-2 rounded bg-stone-900 border border-stone-700 text-sm text-stone-100',
            children: customers.map(item => JSX.jsx('option', {
              value: item.id,
              children: `${item.name} · ${item.status}`,
            }, item.id)),
          }),
          data.wifeServiceMode === 'manual' && !controlledScene ? JSX.jsxs('div', {
            className: 'mb-3',
            children: [
              JSX.jsx('div', { className: 'text-xs font-bold uppercase tracking-wider text-stone-500 mb-1', children: '수동 응대' }),
              serviceAction ? WifeViewMode_버튼그리기({
                label: serviceAction.label,
                description: serviceBlocked || serviceAction.description,
                disabled: !!serviceBlocked,
                onClick: () => api.store.dispatch({
                  type: 'wife-view-mode/wife-service', kind: serviceAction.kind, customerId: customer.id,
                }),
                tone: 'amber',
              }) : JSX.jsx('p', { className: 'text-xs text-stone-500', children: '현재 손님 상태에는 필요한 기본 응대가 없습니다.' }),
            ],
          }) : null,
          controlledScene ? JSX.jsx(WifeViewMode_손님장면그리기, { state, wife, customer, scene: controlledScene }) : null,
          !controlledScene && !greeted ? JSX.jsxs('div', {
            children: [
              JSX.jsx('div', { className: 'text-xs font-bold uppercase tracking-wider text-stone-500 mb-1', children: '손님에게 다가가서 인사를 합니다' }),
              WifeViewMode_버튼그리기({
                label: '인사하기',
                description: serviceBlocked || '손님의 이름을 부르며 먼저 반갑게 인사합니다. 인사한 뒤 대화와 행동 선택지가 열립니다.',
                disabled: !!serviceBlocked,
                onClick: () => api.store.dispatch({ type: 'wife-view-mode/greet-patron', customerId: customer.id }),
                tone: 'amber',
              }),
            ],
          }) : null,
          !controlledScene && greeted ? JSX.jsxs('div', {
            children: [
              JSX.jsx('div', { className: 'text-xs font-bold uppercase tracking-wider text-stone-500 mb-1', children: '인사 후 행동' }),
              JSX.jsx('div', {
                className: 'grid grid-cols-1 gap-2',
                children: WifeViewMode_손님행동버튼그리기(afterGreetingActions, customer, serviceBlocked),
              }),
            ],
          }) : null,
          !controlledScene && greeted && moveRooms.length ? JSX.jsxs('div', {
            className: 'mt-3',
            children: [
              WifeViewMode_버튼그리기({
                label: moveOpen ? '장소 선택 닫기' : '장소옮기기 제안하기',
                description: `${customer.name}에게 장소를 옮기자고 제안합니다. 버튼을 누르면 이동 가능한 장소가 표시됩니다.`,
                disabled: !!serviceBlocked,
                onClick: () => setMoveOpen(value => !value),
              }),
              moveOpen ? JSX.jsx('div', {
                className: 'grid grid-cols-1 gap-2',
                children: moveRooms.map(room => JSX.jsx(WifeViewMode_버튼그리기, {
                  label: `${roomLabels[room] || room}(으)로 함께 이동`,
                  description: WifeViewMode_관계문구(`${customer.name}에게 제안해 함께 이동하고 {rtHer}가 먼저 대화를 시작합니다.`),
                  disabled: !!serviceBlocked,
                  onClick: () => api.store.dispatch({
                    type: 'wife-view-mode/propose-move', customerId: customer.id, room,
                  }),
                }, room)),
              }) : null,
            ],
          }) : null,
        ],
      });
    }

    function WifeViewMode_남편상호작용차단사유(state, wife) {
      if (state.pendingEvent || state.activeScene?.patron || state.activeScene?.sex || state.activeScene?.table) return '진행 중인 사건이나 장면을 먼저 끝내야 합니다.';
      if (wife?.passedOutAtSlot != null || ['away', 'sleeping', 'passed_out'].includes(wife?.currentTask)) return '지금은 직접 대화할 수 없는 상태입니다.';
      if (api.fn('wifeLocation')(state) !== api.fn('playerLocation')(state)) return WifeViewMode_관계문구("{rtHis}과 같은 장소에 있어야 합니다.", state);
      if (state.errandSession || state.activeShoppingSession) return WifeViewMode_관계문구("{rtHis}이 외출에서 돌아와야 합니다.", state);
      return null;
    }

    function WifeViewMode_남편기본행동목록(state) {
      return ['touch', 'sex'].flatMap(category =>
        (api.fn('WifeViewModeConversationMenu')(state, category)?.choices || [])
          .filter(choice => choice.id !== 'back' && !choice.id.startsWith('cat_')));
    }

    function WifeViewMode_남편상호작용그리기({ state, wife }) {
      const [open, setOpen] = React.useState(false);
      const blocked = WifeViewMode_남편상호작용차단사유(state, wife);
      const choices = open && !blocked ? WifeViewMode_남편기본행동목록(state) : [];
      return JSX.jsxs('section', {
        className: 'mb-4 p-3 rounded-lg border border-amber-900/70 bg-amber-950/15',
        children: [
          JSX.jsx('h3', { className: 'text-sm font-bold text-amber-300 mb-2', children: WifeViewMode_관계문구("{rtHis}과 상호작용") }),
          blocked ? JSX.jsx('p', { className: 'text-xs text-stone-500 mb-2', children: blocked }) : null,
          WifeViewMode_버튼그리기({ label: WifeViewMode_관계문구("{rtHis}과 대화하기"), description: WifeViewMode_관계문구("{rtHis}과 이야기를 나누고 서로의 마음을 확인합니다."), disabled: !!blocked,
            onClick: () => api.store.dispatch({ type: 'wife-view-mode/husband-interaction', topicId: 'talk' }) }),
          WifeViewMode_버튼그리기({ label: open ? WifeViewMode_관계문구("함께하는 행동 닫기") : WifeViewMode_관계문구("함께하는 행동 선택"), description: WifeViewMode_관계문구("기본 게임의 접촉·장면 선택지를 엽니다. {rtHis}의 관계·성향과 원래 게임의 상태 판정을 함께 적용합니다."), disabled: !!blocked,
            onClick: () => setOpen(value => !value) }),
          ...choices.map(choice => WifeViewMode_버튼그리기({
            label: choice.label.replaceAll('그녀에게', WifeViewMode_관계문구("{rtHis}에게")).replaceAll('그녀와', WifeViewMode_관계문구("{rtHis}과")).replaceAll('그녀를', WifeViewMode_관계문구("{rtHis}을")).replaceAll('그녀의', WifeViewMode_관계문구("{rtHis}의")),
            description: WifeViewMode_관계문구("{rtHer}가 함께할 행동을 선택합니다. {rtHis}이 응하면 기본 게임의 장면·효과로 진행합니다."),
            onClick: () => api.store.dispatch({ type: 'wife-view-mode/husband-interaction', topicId: choice.id }),
          })),
        ],
      });
    }

    function WifeViewMode_게임행동그리기(state) {
      const table = state.activeScene?.table;
      if (!table) return null;
      const queued = table.wifeViewLoseNext === true;
      return JSX.jsx('section', {
        className: 'mb-4 p-3 rounded-lg border border-violet-900/70 bg-violet-950/20',
        children: WifeViewMode_버튼그리기({
          label: queued ? '다음 판은 일부러 지기로 함' : '다음 판 일부러 지기',
          description: queued
            ? WifeViewMode_관계문구("다음 카드 판에서 {rtHer}의 점수만 최하점으로 처리합니다. 한 판이 끝나면 자동 해제됩니다.", state)
            : '현재 카드 게임의 다음 한 판만 고의로 패배합니다. 판돈과 후속 사건은 원래 게임 규칙을 따릅니다.',
          disabled: queued,
          onClick: () => api.store.dispatch({ type: 'wife-view-mode/lose-next-game' }),
          tone: 'rose',
        }),
      });
    }

    function WifeViewMode_시간행동그리기(state) {
      if (state.activeScene?.patron) return null;
      return JSX.jsxs('section', {
        className: 'mb-4',
        children: [
          JSX.jsx('h3', { className: 'text-sm font-bold text-amber-400 mb-2', children: '시간·영업 행동' }),
          JSX.jsx(api.fn('WifeViewModeWaitControls'), {
            dispatch: action => api.store.dispatch(action),
            description: '원래 게임과 같은 시간 보내기입니다. 도중에 사건이 발생하면 원래 규칙대로 멈춥니다.',
            showUntilCustomer: ['service', 'last_call'].includes(state.phase),
          }),
          state.phase === 'prep' ? JSX.jsx('div', { className: 'mt-2', children: WifeViewMode_버튼그리기({
            label: '영업 시작',
            description: '개장 준비를 마치고 선술집 문을 엽니다. 원래 게임의 개장 처리와 시간을 그대로 사용합니다.',
            onClick: () => api.store.dispatch({ type: 'open_tavern' }),
            tone: 'amber',
          }) }) : null,
          state.phase === 'closed' ? JSX.jsx('div', { className: 'mt-2', children: WifeViewMode_버튼그리기({
            label: '영업 마감',
            description: '남은 손님을 정리하고 원래 게임의 일일 정산을 실행합니다.',
            onClick: () => api.store.dispatch({ type: 'end_day' }),
            tone: 'amber',
          }) }) : null,
          state.phase === 'bedroom' ? JSX.jsx('div', { className: 'mt-2', children: WifeViewMode_버튼그리기({
            label: '잠자기',
            description: '밤을 마치고 다음 날로 넘어갑니다. 원래 게임의 수면·회복·하루 시작 처리를 사용합니다.',
            onClick: () => api.store.dispatch({ type: 'sleep', underway: false }),
            tone: 'amber',
          }) }) : null,
          state.phase !== 'bedroom' && WifeViewMode_심야마무리가능여부(state) ? JSX.jsxs('div', {
            className: 'mt-2 grid grid-cols-1 gap-2', children: [
              WifeViewMode_버튼그리기({ label: '잠자기',
                description: '새벽 2시까지 진행하고 정상 정산·수면으로 다음 날을 시작합니다. 선택이 필요한 사건이 생기면 멈춥니다.',
                onClick: () => api.store.dispatch({ type: 'wife-view-mode/finish-night', sleep: true }), tone: 'amber' }),
              WifeViewMode_버튼그리기({ label: '하루 마무리하기',
                description: '새벽 2시까지 진행하고 영업을 정산합니다. 빚·월세 등 선택이 필요한 사건은 직접 처리합니다.',
                onClick: () => api.store.dispatch({ type: 'wife-view-mode/finish-night', sleep: false }), tone: 'amber' }),
            ],
          }) : null,
        ],
      });
    }

    function WifeViewMode_행동패널그리기({ state }) {
      const wife = api.fn('wife')(state);
      const data = WifeViewMode_자료읽기(state);
      const stance = WifeViewMode_스탠스목록.find(item => item.id === data.stance);
      const location = api.fn('wifeLocation')(state);
      const controlledPatronEvent = !!(state.activeScene?.patron?.wifeViewControlled
        && (!state.pendingEvent || state.pendingEvent.type === 'patron_interaction'));
      const blockingEvent = !!state.pendingEvent && !controlledPatronEvent;
      const lastEnd = data.lastSceneEnd;
      return JSX.jsxs('div', {
        'data-wml-ui': 'wife-view-mode',
        className: 'space-y-1',
        children: [
          JSX.jsxs('div', {
            className: 'mb-3 p-3 rounded-lg border border-amber-800/70 bg-amber-950/20',
            children: [
              JSX.jsx('h2', { className: 'text-base font-bold text-amber-300', children: `${wife?.name || WifeViewMode_관계문구("{rtHer}")} 시점` }),
              JSX.jsx('p', {
                className: 'text-xs text-stone-400 mt-1',
                children: WifeViewMode_관계문구(`위치: ${location || '알 수 없음'} · 현재 작업: ${wife?.currentTask || '대기'} · {rtHis}: ${stance?.label || '동반자형'} · {rtHer}에 대한 신뢰: ${Math.round(data.husbandProfile.relationship.trust)}`),
              }),
              JSX.jsx('p', { className: 'text-xs text-stone-500 mt-1', children: stance?.description }),
              lastEnd && state.slot - lastEnd.slot <= 5 && !state.activeScene?.patron ? JSX.jsx('p', {
                className: 'text-xs text-amber-300 mt-2', children: lastEnd.message,
              }) : null,
              JSX.jsx(WifeViewMode_복장변경그리기, { state, wife }),
            ],
          }),
          blockingEvent ? WifeViewMode_사건그리기(state, state.pendingEvent) : null,
          !blockingEvent ? WifeViewMode_준비관리그리기(state) : null,
          !blockingEvent
            ? JSX.jsx(WifeViewMode_손님행동그리기, { state, wife }) : null,
          !blockingEvent ? JSX.jsx(WifeViewMode_남편상호작용그리기, { state, wife }) : null,
          !blockingEvent ? WifeViewMode_게임행동그리기(state) : null,
          !blockingEvent ? WifeViewMode_시간행동그리기(state) : null,
        ],
      });
    }

    function WifeViewMode_손님장면시작하기(state, customer, activity, line) {
      const config = WifeViewMode_손님장면단계[activity];
      if (!config || state.activeScene?.patron) return state;
      let next = api.fn('WifeViewModeStartPatronInteraction')(state, customer.id, undefined, line);
      const scene = next.activeScene?.patron;
      if (!scene || scene.customerId !== customer.id) return state;
      const transitioned = api.fn('transitionPatronStage')(scene, config.stage, api.fn('wife')(next), {
        by: 'self', bySelf: true, slot: config.primarySlot,
      });
      const hadPatronEvent = next.pendingEvent?.type === 'patron_interaction';
      next = {
        ...next,
        ...(hadPatronEvent ? { pendingEvent: undefined } : {}),
        activeScene: {
          ...next.activeScene,
          patron: {
            ...transitioned,
            stage: config.stage,
            activity: 'conversation',
            ticksAtStage: 0,
            elenaComfort: Math.min(100, (scene.elenaComfort ?? 0) + config.comfortBoost),
            patronBoldness: Math.min(100, (scene.patronBoldness ?? customer.boldness ?? 0) + config.boldnessBoost),
            elenaInitiated: true,
            playerEngaged: false,
            wifeViewControlled: true,
            wifeViewPatronInitiated: false,
            wifeViewAction: activity,
            wifeViewAcceptedStage: config.stage,
            wifeViewEscalatedFromStage: undefined,
            wifeViewPatronEscalated: false,
            wifeViewPersistentPressure: false,
            wifeViewRejectionCount: 0,
            wifeViewBreakawayFailures: 0,
            wifeViewPatronExposed: !!config.exposed,
            patronExposed: !!(scene.patronExposed || config.exposed),
            wifeViewActVariant: config.variant,
          },
        },
      };
      const lastLog = next.log?.[next.log.length - 1]?.text;
      if (lastLog !== line) next = api.fn('log')(next, line);
      return api.fn('updateWife')(next, current => ({
        ...current,
        currentTask: 'idle',
        taskTarget: customer.id,
        busyUntilSlot: next.slot,
        sceneOverride: config.scene,
        sceneSetAtSlot: next.slot,
        sceneVariant: WifeViewMode_그림변형번호정규화하기(current.sceneVariant),
        lastResponse: line,
        lastResponseType: 'neutral',
        lastResponseSlot: next.slot,
      }));
    }

    function WifeViewMode_손님장면행동바꾸기(state, customer, activity, line) {
      const config = WifeViewMode_손님장면단계[activity];
      const scene = state.activeScene?.patron;
      const wife = api.fn('wife')(state);
      if (!config || !scene?.wifeViewControlled || scene.customerId !== customer.id || !wife || scene.afterglow) return state;
      let changed = scene;
      if (scene.stage !== config.stage || config.primarySlot && scene.primarySlot !== config.primarySlot) {
        changed = api.fn('transitionPatronStage')(scene, config.stage, wife, {
          by: 'self', bySelf: true, slot: config.primarySlot,
        });
      }
      let next = {
        ...state,
        ...(state.pendingEvent?.type === 'patron_interaction' ? { pendingEvent: undefined } : {}),
        activeScene: {
          ...state.activeScene,
          patron: {
            ...changed,
            stage: config.stage,
            activity: 'conversation',
            ticksAtStage: 0,
            elenaComfort: Math.min(100, (changed.elenaComfort ?? 0) + Math.ceil(config.comfortBoost / 2)),
            patronBoldness: Math.min(100, (changed.patronBoldness ?? customer.boldness ?? 0) + Math.ceil(config.boldnessBoost / 2)),
            playerEngaged: false,
            wifeViewControlled: true,
            wifeViewAction: activity,
            wifeViewAcceptedStage: config.stage,
            wifeViewEscalatedFromStage: undefined,
            wifeViewPatronEscalated: false,
            wifeViewPersistentPressure: false,
            wifeViewPatronExposed: !!(scene.wifeViewPatronExposed || config.exposed),
            patronExposed: !!(scene.patronExposed || config.exposed),
            wifeViewActVariant: config.variant,
            ...(config.primarySlot ? { primarySlot: config.primarySlot } : config.stage === 'sex_patron' ? {} : { primarySlot: undefined }),
          },
        },
      };
      next = api.fn('log')(next, line);
      return api.fn('updateWife')(next, current => ({
        ...current,
        currentTask: 'idle',
        taskTarget: customer.id,
        busyUntilSlot: next.slot,
        sceneOverride: config.scene,
        sceneSetAtSlot: next.slot,
        sceneVariant: WifeViewMode_그림변형번호정규화하기(current.sceneVariant),
        sceneSetAtSlot: next.slot,
        lastResponse: line,
        lastResponseType: 'neutral',
        lastResponseSlot: next.slot,
      }));
    }

    function WifeViewMode_손님장면제어표시하기(state, customerId, fallbackActivity = 'talk') {
      const scene = state.activeScene?.patron;
      if (!scene || scene.customerId !== customerId) return state;
      const activity = scene.wifeViewAction || fallbackActivity;
      let next = {
        ...state,
        ...(state.pendingEvent?.type === 'patron_interaction' ? { pendingEvent: undefined } : {}),
        activeScene: {
          ...state.activeScene,
          patron: {
            ...scene,
            playerEngaged: false,
            wifeViewControlled: true,
            wifeViewAction: activity,
            wifeViewAcceptedStage: scene.wifeViewAcceptedStage || scene.stage,
            wifeViewPatronEscalated: scene.wifeViewPatronEscalated ?? false,
            wifeViewPersistentPressure: scene.wifeViewPersistentPressure ?? false,
            wifeViewRejectionCount: scene.wifeViewRejectionCount ?? 0,
            wifeViewBreakawayFailures: scene.wifeViewBreakawayFailures ?? 0,
            wifeViewPatronExposed: !!(scene.wifeViewPatronExposed || scene.patronExposed
              || ['handjob_patron', 'blowjob_patron', 'rubbing_patron', 'sex_patron'].includes(scene.stage)),
          },
        },
      };
      next = api.fn('updateWife')(next, current => ({
        ...current,
        sceneOverride: WifeViewMode_손님장면그림찾기(next.activeScene.patron, current),
        sceneVariant: WifeViewMode_그림변형번호정규화하기(current.sceneVariant),
      }));
      return next;
    }

    function WifeViewMode_요소찾아바꾸기(node, predicate, transform) {
      if (!React.isValidElement(node)) return node;
      if (predicate(node)) return transform(node);
      const children = React.Children.toArray(node.props?.children);
      if (!children.length) return node;
      let changed = false;
      const nextChildren = children.map(child => {
        const next = WifeViewMode_요소찾아바꾸기(child, predicate, transform);
        if (next !== child) changed = true;
        return next;
      });
      return changed ? React.cloneElement(node, undefined, ...nextChildren) : node;
    }

    function WifeViewMode_이동차단사유찾기(state, wife = api.fn('wife')(state)) {
      if (globalThis.__waywardDeliveryCompatibleWifeView?.ownsWife(state)) return '배달이 끝난 뒤 이동할 수 있습니다.';
      if (state.pendingEvent) return '먼저 현재 사건을 처리해야 이동할 수 있습니다.';
      if (state.activeScene?.patron || state.activeScene?.sex || state.activeScene?.table) return '진행 중인 장면을 끝내야 이동할 수 있습니다.';
      if (!wife) return WifeViewMode_관계문구("{rtHer} 캐릭터 정보를 찾을 수 없어 이동할 수 없습니다.", state);
      if (wife.currentTask === 'away') return WifeViewMode_관계문구("{rtHer}의 외출이 끝난 뒤 이동할 수 있습니다.", state);
      if (wife.passedOutAtSlot != null) return '의식을 잃은 상태에서는 직접 이동할 수 없습니다.';
      return null;
    }

    function WifeViewMode_장소사용가능여부(state, room) {
      if (!state.locations?.[room]) return false;
      if (room === 'bathhouse' && !state.tavern?.hasBathhouse) return false;
      if (room === 'back_room' && state.tavern?.backRoomReady === false) return false;
      if (room === 'upstairs_hall' && !state.tavern?.hasRoom) return false;
      if (room === 'upstairs_room_2' && !state.tavern?.hasRoom2) return false;
      return true;
    }

    function WifeViewMode_요소문자열읽기(node) {
      if (typeof node === 'string' || typeof node === 'number') return String(node);
      if (Array.isArray(node)) return node.map(WifeViewMode_요소문자열읽기).join('');
      if (!React.isValidElement(node)) return '';
      return React.Children.toArray(node.props?.children).map(WifeViewMode_요소문자열읽기).join('');
    }

    function WifeViewMode_카드장소찾기(node) {
      const roomLabels = api.fn('brothelRoomLabels') || {};
      const heading = React.Children.toArray(node.props?.children)[0];
      const headingText = WifeViewMode_요소문자열읽기(heading).trim();
      return Object.entries(roomLabels)
        .filter(([room]) => room !== 'upstairs_hall' || headingText !== `${roomLabels.upstairs_hall} 2`)
        .sort((left, right) => String(right[1]).length - String(left[1]).length)
        .find(([, label]) => headingText.startsWith(String(label)))?.[0] || null;
    }

    function WifeViewMode_장소패널보강하기(result) {
      const state = api.store.game();
      if (!state || !WifeViewMode_활성여부(state) || !React.isValidElement(result)) return result;
      const wife = api.fn('wife')(state);
      const wifeLocation = api.fn('wifeLocation')(state);
      const blockedReason = WifeViewMode_이동차단사유찾기(state, wife);
      const relabeled = WifeViewMode_요소찾아바꾸기(
        result,
        node => {
          const className = node.props?.className;
          const text = WifeViewMode_요소문자열읽기(node);
          return typeof className === 'string'
            && className.includes('bg-blue-900/60') && text === '당신';
        },
        node => React.cloneElement(node, undefined, WifeViewMode_관계문구("{rtHis}")),
      );
      return WifeViewMode_요소찾아바꾸기(
        relabeled,
        node => typeof node.props?.className === 'string'
          && node.props.className.includes('p-1.5 rounded border')
          && !!WifeViewMode_카드장소찾기(node),
        node => {
          const room = WifeViewMode_카드장소찾기(node);
          const available = WifeViewMode_장소사용가능여부(state, room);
          const here = room === wifeLocation;
          const canMove = available && !here && !blockedReason;
          const baseClass = node.props.className.split(/\s+/).filter(token => ![
            'cursor-pointer', 'hover:brightness-125', 'hover:ring-1', 'hover:ring-amber-700/70', 'transition',
          ].includes(token)).join(' ');
          const title = here ? WifeViewMode_관계문구("{rtHer}의 현재 위치")
            : !available ? '현재 이용할 수 없는 장소입니다.'
              : blockedReason || WifeViewMode_관계문구("{rtHer}를 이곳으로 이동");
          return React.cloneElement(node, {
            ...node.props,
            'data-wvm-room': room,
            className: `${baseClass}${canMove ? ' cursor-pointer hover:brightness-125 hover:ring-1 hover:ring-pink-700/70 transition' : ''}`,
            onClick: canMove ? () => api.store.dispatch({ type: 'wife-view-mode/move-wife', room }) : undefined,
            onKeyDown: canMove ? event => {
              if (event.key !== 'Enter' && event.key !== ' ') return;
              event.preventDefault();
              api.store.dispatch({ type: 'wife-view-mode/move-wife', room });
            } : undefined,
            role: canMove ? 'button' : undefined,
            tabIndex: canMove ? 0 : -1,
            title,
            'aria-disabled': canMove ? undefined : true,
          });
        },
      );
    }

    function WifeViewMode_헤더버튼그리기({ mobile = false }) {
      const state = WifeViewMode_게임스토어(store => store.state);
      const active = WifeViewMode_활성여부(state);
      return JSX.jsx('button', {
        type: 'button',
        'data-wvm-header': mobile ? 'mobile-toggle' : 'desktop-toggle',
        'data-wml-ui': 'wife-view-mode',
        onClick: WifeViewMode_모드전환하기,
        title: active ? WifeViewMode_관계문구("{rtHis} 시점으로 복귀") : WifeViewMode_관계문구("{rtHer} 시점으로 전환"),
        'aria-label': active ? WifeViewMode_관계문구("{rtHis} 시점으로 복귀") : WifeViewMode_관계문구("{rtHer} 시점으로 전환"),
        'aria-pressed': active,
        className: mobile
          ? `w-8 border-l border-stone-700 hover:bg-stone-700 text-base leading-none ${active ? 'bg-pink-900 text-pink-100' : 'text-amber-300'}`
          : `wvm-header-toggle hidden desk:flex fixed top-2 z-30 h-9 items-center justify-center border rounded leading-none ${active ? 'bg-pink-900/90 hover:bg-pink-800 border-pink-600 text-pink-100' : 'bg-stone-800/90 hover:bg-stone-700 border-stone-700 text-amber-200'}`,
        style: mobile ? undefined : { right: '8rem', width: '8rem', fontSize: '0.68rem', whiteSpace: 'nowrap' },
        children: mobile ? active ? '♂' : '♀' : active ? WifeViewMode_관계문구("{rtHis} 시점으로 복귀") : WifeViewMode_관계문구("{rtHer} 시점으로 전환"),
      });
    }

    function WifeViewMode_게임화면보강하기(result) {
      if (!React.isValidElement(result) || !api.store.game()) return result;
      let mobileInserted = false;
      const withMobile = WifeViewMode_요소찾아바꾸기(
        result,
        node => !mobileInserted && typeof node.props?.className === 'string'
          && node.props.className.includes('desk:hidden flex items-stretch shrink-0'),
        node => {
          mobileInserted = true;
          const children = React.Children.toArray(node.props.children);
          if (children.some(child => child?.props?.['data-wvm-mobile-node'])) return node;
          const button = JSX.jsx(WifeViewMode_헤더버튼그리기, {
            mobile: true,
            'data-wvm-mobile-node': true,
          }, 'wife-view-mode-mobile-toggle');
          children.splice(Math.max(0, children.length - 2), 0, button);
          return React.cloneElement(node, undefined, ...children);
        },
      );
      const children = React.Children.toArray(withMobile.props?.children);
      if (!children.length || children.some(child => child?.props?.['data-wvm-desktop-node'])) return withMobile;
      const desktopButton = JSX.jsx(WifeViewMode_헤더버튼그리기, {
        mobile: false,
        'data-wvm-desktop-node': true,
      }, 'wife-view-mode-desktop-toggle');
      return React.cloneElement(withMobile, undefined, ...children, desktopButton);
    }

    function WifeViewMode_스타일설치하기() {
      const install = () => {
        document.body?.classList.add('wvm-installed');
        if (document.getElementById('wife-view-mode-style')) return;
        const style = document.createElement('style');
        style.id = 'wife-view-mode-style';
        style.textContent = `
          @media (min-width: 640px) {
            .wvm-installed button[class*="right-[8rem]"]:not(.wvm-header-toggle) { right: 16.5rem !important; }
            .wvm-installed .ww1-header-desktop { right: 19.25rem !important; }
            .wvm-installed .ww1-header-topbar,
            .wvm-installed div[class*="desk:pr-[11rem]"] { padding-right: 25rem !important; }
          }
        `;
        document.head.appendChild(style);
      };
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', install, { once: true });
      else install();
    }

    api.actions.register('wife-view-mode/close-wife-conversation', (state) => {
      if (!WifeViewMode_활성여부(state) || state.pendingEvent?.type !== 'wife_conversation') return state;
      const wife = api.fn('wife')(state);
      return api.fn('log')(
        { ...state, pendingEvent: undefined },
        WifeViewMode_관계문구(`${wife?.name || WifeViewMode_관계문구("{rtHer}", state)}은(는) {rtHis}이 열어 둔 대화 흐름을 정리하고 자신의 행동으로 돌아갑니다.`, state),
      );
    });

    api.actions.register('wife-view-mode/recover-blocked-event', (state, action) => {
      const event = state.pendingEvent;
      if (!WifeViewMode_활성여부(state) || !event
        || WifeViewMode_사건지문만들기(state, event) !== action.fingerprint) return state;
      const plan = WifeViewMode_사건판단하기(state, event);
      if (plan.owner !== 'blocked') return state;
      let next = { ...state, pendingEvent: undefined };
      if (next.activeScene?.patron) {
        next = api.fn('WifeViewModeEndPatronInteraction')(next, 'patron_satisfied', { suppressEndText: true });
      } else if (next.activeScene?.sex) {
        next = {
          ...next,
          activeScene: { ...next.activeScene, sex: undefined },
        };
        next = api.fn('updateWife')(next, wife => ({
          ...wife,
          currentTask: 'idle',
          busyUntilSlot: next.slot,
          sceneOverride: undefined,
          sceneVariant: undefined,
        }));
      }
      WifeViewMode_실패선택목록.delete(action.fingerprint);
      WifeViewMode_강제중단사건목록.delete(action.fingerprint);
      WifeViewMode_자동처리연속상태 = { day: null, slot: null, count: 0, lastAt: 0 };
      return api.fn('log')(next, WifeViewMode_관계문구("{rtHer}는 더 진행되지 않는 대화와 장면을 정리하고 자신의 행동으로 돌아갑니다.", state));
    });

    api.actions.register('wife-view-mode/set-intent', (state, action) => {
      if (!WifeViewMode_의향목록.some(item => item.id === action.intent)) return state;
      return WifeViewMode_자료합치기(state, { wifeIntent: action.intent });
    });

    api.actions.register('wife-view-mode/husband-comment', (state, action) => {
      if (!WifeViewMode_활성여부(state) || !state.pendingEvent || !action.line) return state;
      if (WifeViewMode_사건지문만들기(state, state.pendingEvent) !== action.fingerprint) return state;
      return api.fn('log')(state, action.line);
    });

    api.actions.register('wife-view-mode/wife-decision-result', (state, action) => {
      if (!WifeViewMode_활성여부(state) || !action.line) return state;
      let next = api.fn('log')(state, action.line);
      if (action.husbandReaction === 'stop' && ['direct', 'profit'].includes(action.route)) {
        next = WifeViewMode_남편갈등적용하기(next);
      }
      return next;
    });

    api.actions.register('wife-view-mode/move-wife', (state, action) => {
      if (!WifeViewMode_활성여부(state)) return state;
      const wife = api.fn('wife')(state);
      if (WifeViewMode_이동차단사유찾기(state, wife)) return state;
      if (!WifeViewMode_장소사용가능여부(state, action.room)) return state;
      if (api.fn('wifeLocation')(state) === action.room) return state;
      const wasSleeping = wife.currentTask === 'sleeping';
      let next = api.fn('updateWife')(state, current => ({
        ...current,
        currentTask: 'idle',
        taskTarget: undefined,
        busyUntilSlot: state.slot,
        locationUntilSlot: undefined,
        wifeViewHoldPosition: false,
        ...(wasSleeping ? { retiredAtSlot: undefined, wakeSlot: undefined, sleepsApart: undefined,bedTonight:undefined } : {}),
      }));
      next = WifeViewMode_승인된이동실행하기(() => api.fn('moveWife')(next, action.room, undefined, { skipModestyCheck: false }));
      const roomLabel = api.fn('brothelRoomLabels')?.[action.room] || action.room;
      return api.fn('log')(next, `${wife.name}은(는) ${roomLabel}(으)로 이동합니다.`);
    });

    api.actions.register('wife-view-mode/change-outfit', (state, action) => {
      if (!WifeViewMode_활성여부(state)) return state;
      const wife = api.fn('wife')(state);
      if (WifeViewMode_복장차단사유찾기(state, wife)) return state;
      let choice;
      try {
        choice = (api.fn('WifeViewModeConversationMenu')(state, 'clothing')?.choices || [])
          .find(item => item.id === action.topicId && item.id !== 'back');
      } catch (error) {
        api.warn(`Wife_View_Mode: 복장 선택을 안전하게 중단했습니다. ${error?.message || error}`);
        return state;
      }
      if (!choice) return state;
      const outcome = api.fn('playerActionRespond')(state, choice.id);
      const accepted = !!(outcome?.outfitChange || outcome?.exposureChange);
      const responseText = accepted
        ? outcome.response === 'hesitant'
          ? `${wife.name}은(는) 조금 망설인 끝에 “${choice.label}”을(를) 택해 직접 옷매무새를 바꿉니다.`
          : `${wife.name}은(는) 자신의 마음에 따라 “${choice.label}”을(를) 택하고 직접 복장을 바꿉니다.`
        : outcome?.response === 'angry'
          ? `${wife.name}은(는) 이 복장을 떠올려 본 뒤 지금 자신에게 강요하고 싶지 않다고 단호히 생각합니다.`
          : `${wife.name}은(는) 거울을 잠시 바라보다가 지금은 이 복장을 입고 싶지 않다고 결정합니다.`;
      let next = api.fn('log')(state, responseText);
      next = api.fn('WifeViewModeApplyOutcome')(next, outcome);
      next = api.fn('WifeViewModeApplySceneOutcome')(next, outcome);
      next = api.fn('updateWife')(next, current => ({
        ...current,
        lastResponse: responseText,
        lastResponseType: outcome?.response || 'neutral',
        lastResponseSlot: next.slot,
      }));
      for (let index = 0; index < 2; index += 1) next = api.fn('tick')(next);
      return next;
    });

    api.actions.register('wife-view-mode/greet-patron', (state, action) => {
      if (!WifeViewMode_활성여부(state)) return state;
      const wife = api.fn('wife')(state);
      const customer = state.customers?.find(item => item.id === action.customerId);
      if (WifeViewMode_수동응대차단사유찾기(state, wife, customer) || customer?.wifeViewGreeted) return state;
      try {
        const dare = (api.fn('WifeViewModeDaresAvailable')(state, 'with_someone') || [])
          .find(item => item.id === 'dare_say_hello');
        const validDare = dare && (api.fn('WifeViewModeDareTargets')(state, dare) || []).some(target => target.id === customer.id);
        const consequence = validDare && (dare.consequenceEager || dare.consequenceReluctant);
        let next = typeof consequence === 'function' ? consequence(state, customer) || state : state;
        const rawText = validDare && typeof dare.text?.eager === 'string'
          ? dare.text.eager
          : `${wife.name}이(가) ${customer.name}에게 반갑게 인사합니다.`;
        const text = rawText
          .replaceAll('{w}', wife.name)
          .replaceAll('{target}', customer.name)
          .replaceAll('%w', wife.name)
          .replaceAll('%p', customer.name);
        next = api.fn('log')(next, text);
        return {
          ...next,
          customers: next.customers.map(item => item.id === customer.id
            ? { ...item, wifeViewGreeted: true }
            : item),
        };
      } catch (error) {
        api.warn(`Wife_View_Mode: 손님 인사를 안전하게 중단했습니다. ${error?.message || error}`);
        return state;
      }
    });

    api.actions.register('wife-view-mode/start-patron-activity', (state, action) => {
      if (!WifeViewMode_활성여부(state) || !WifeViewMode_손님장면단계[action.activity]) return state;
      const wife = api.fn('wife')(state);
      const customer = state.customers?.find(item => item.id === action.customerId);
      const controlled = !!(state.activeScene?.patron?.wifeViewControlled
        && state.activeScene.patron.customerId === customer?.id);
      if (!customer?.wifeViewGreeted
        || WifeViewMode_수동응대차단사유찾기(state, wife, customer, { allowControlled: controlled })) return state;
      const requested = WifeViewMode_직접성행동목록.find(item => item.id === action.activity);
      const scene = state.activeScene?.patron;
      if (scene?.afterglow) return state;
      if (requested?.requiresExposed && !(scene?.wifeViewPatronExposed || scene?.patronExposed
        || ['handjob_patron', 'blowjob_patron', 'rubbing_patron', 'sex_patron'].includes(scene?.stage))) return state;
      const lines = WifeViewMode_성행동대사[action.activity] || {
        talk: WifeViewMode_대화대사,
        flirt: WifeViewMode_추파대사,
        light_touch: WifeViewMode_가벼운접촉대사,
      }[action.activity];
      const line = WifeViewMode_대사고르기(state, customer, lines, action.activity);
      const next = WifeViewMode_아내행동남편반응적용하기(state, action.activity, customer);
      return controlled
        ? WifeViewMode_손님장면행동바꾸기(next, customer, action.activity, line)
        : WifeViewMode_손님장면시작하기(next, customer, action.activity, line);
    });

    api.actions.register('wife-view-mode/continue-patron', (state) => {
      if (!WifeViewMode_활성여부(state)) return state;
      const scene = state.activeScene?.patron;
      const customer = state.customers?.find(item => item.id === scene?.customerId);
      const wife = api.fn('wife')(state);
      if (!scene?.wifeViewControlled
        || WifeViewMode_수동응대차단사유찾기(state, wife, customer, { allowControlled: true })) return state;
      const acceptedBeforeTick = scene.wifeViewPatronEscalated
        ? scene.stage
        : scene.wifeViewAcceptedStage || scene.stage;
      const beforeStageNumber = WifeViewMode_손님장면단계번호(scene.stage);
      let next = state.pendingEvent?.type === 'patron_interaction' ? { ...state, pendingEvent: undefined } : state;
      next = api.fn('tick')(next);
      if (next.activeScene?.patron?.customerId === scene.customerId) {
        next = WifeViewMode_손님장면제어표시하기(next, scene.customerId, scene.wifeViewAction || 'talk');
        const advanced = next.activeScene.patron;
        const afterStageNumber = WifeViewMode_손님장면단계번호(advanced.stage);
        const patronAdvanced = afterStageNumber > beforeStageNumber && advanced.stageBy !== 'self';
        const wifeAdvanced = afterStageNumber > beforeStageNumber && advanced.stageBy === 'self';
        const rejectedBefore = (scene.wifeViewRejectionCount ?? 0) > 0;
        const resistedAgain = rejectedBefore && (
          (advanced.stalled ?? 0) > (scene.stalled ?? 0)
          || (!!advanced.hasBeenRefused && !scene.hasBeenRefused)
          || ((advanced.lastPressureTacticSlot ?? -1) > (scene.lastPressureTacticSlot ?? -1))
        );
        const pressureRoseAgain = rejectedBefore
          && (advanced.pressureLevel ?? 0) >= 12
          && (advanced.pressureLevel ?? 0) > (scene.pressureLevel ?? 0);
        const forcedNow = (patronAdvanced && advanced.stageBy === 'override')
          || (advanced.coercedSinceSlot != null && advanced.coercedSinceSlot !== scene.coercedSinceSlot);
        const persistentPressure = !!(scene.wifeViewPersistentPressure
          || forcedNow
          || (rejectedBefore && patronAdvanced)
          || resistedAgain
          || pressureRoseAgain);
        next = {
          ...next,
          activeScene: {
            ...next.activeScene,
            patron: {
              ...advanced,
              wifeViewAcceptedStage: wifeAdvanced ? advanced.stage : acceptedBeforeTick,
              wifeViewEscalatedFromStage: patronAdvanced ? scene.stage : advanced.wifeViewEscalatedFromStage,
              wifeViewPatronEscalated: patronAdvanced || persistentPressure,
              wifeViewPersistentPressure: persistentPressure,
            },
          },
        };
      }
      return next;
    });

    api.actions.register('wife-view-mode/reject-patron-escalation', (state) => {
      if (!WifeViewMode_활성여부(state)) return state;
      const scene = state.activeScene?.patron;
      const customer = state.customers?.find(item => item.id === scene?.customerId);
      const wife = api.fn('wife')(state);
      if (!scene?.wifeViewControlled || !customer
        || !(scene.wifeViewPatronEscalated || scene.wifeViewPersistentPressure)
        || WifeViewMode_수동응대차단사유찾기(state, wife, customer, { allowControlled: true })) return state;
      const previousStage = scene.wifeViewEscalatedFromStage || scene.wifeViewAcceptedStage || scene.stageFrom;
      const canStepBack = WifeViewMode_손님장면단계번호(previousStage) >= 0
        && WifeViewMode_손님장면단계번호(previousStage) < WifeViewMode_손님장면단계번호(scene.stage);
      const restoredStage = canStepBack ? previousStage : scene.stage;
      const rejectionCount = (scene.wifeViewRejectionCount ?? 0) + 1;
      const forcedPressure = scene.wifeViewPersistentPressure
        || scene.stageBy === 'override'
        || scene.coercedSinceSlot != null;
      const line = WifeViewMode_대사고르기(state, customer, WifeViewMode_거절대사, `reject:${rejectionCount}:${scene.stage}`);
      let next = {
        ...state,
        ...(state.pendingEvent?.type === 'patron_interaction' ? { pendingEvent: undefined } : {}),
        activeScene: {
          ...state.activeScene,
          patron: {
            ...scene,
            stage: restoredStage,
            stageFrom: scene.stage,
            stageBy: 'wife_view_refusal',
            ...(restoredStage === 'sex_patron' ? {} : { primarySlot: undefined }),
            ticksAtStage: 0,
            stalled: (scene.stalled ?? 0) + 1,
            hasBeenRefused: true,
            wifeViewAcceptedStage: restoredStage,
            wifeViewEscalatedFromStage: undefined,
            wifeViewPatronEscalated: forcedPressure,
            wifeViewPersistentPressure: forcedPressure,
            wifeViewRejectionCount: rejectionCount,
          },
        },
      };
      next = api.fn('log')(next, line);
      return api.fn('updateWife')(next, current => ({
        ...current,
        sceneOverride: WifeViewMode_손님장면화면[restoredStage] || current.sceneOverride,
        lastResponse: line,
        lastResponseType: 'neutral',
        lastResponseSlot: next.slot,
      }));
    });

    api.actions.register('wife-view-mode/break-away', (state) => {
      if (!WifeViewMode_활성여부(state)) return state;
      const scene = state.activeScene?.patron;
      const customer = state.customers?.find(item => item.id === scene?.customerId);
      const wife = api.fn('wife')(state);
      if (!scene?.wifeViewControlled || !scene.wifeViewPersistentPressure || !customer || !wife
        || WifeViewMode_수동응대차단사유찾기(state, wife, customer, { allowControlled: true })) return state;
      const wifeStrength = Number(api.fn('getEffectiveAttributes')(wife)?.strength) || 0;
      const customerStrength = Number(api.fn('getEffectiveAttributes')(customer)?.strength) || 0;
      const result = api.fn('WifeViewModeOpposedCheck')(wifeStrength, customerStrength, { spread: 22 });
      const attempts = scene.wifeViewBreakawayFailures ?? 0;
      const lines = result.attackerWins ? WifeViewMode_뿌리치기성공대사 : WifeViewMode_뿌리치기실패대사;
      const line = WifeViewMode_대사고르기(state, customer, lines, `break-away:${attempts}:${result.attackerWins ? 'success' : 'failure'}`);
      let next = state.pendingEvent?.type === 'patron_interaction' ? { ...state, pendingEvent: undefined } : state;
      next = api.fn('log')(next, line);
      if (result.attackerWins) {
        next = api.fn('WifeViewModeEndPatronInteraction')(next, 'elena_refused', { suppressEndText: true });
      } else {
        next = {
          ...next,
          activeScene: {
            ...next.activeScene,
            patron: {
              ...next.activeScene.patron,
              hasBeenRefused: true,
              stalled: (next.activeScene.patron.stalled ?? 0) + 1,
              wifeViewPatronEscalated: true,
              wifeViewPersistentPressure: true,
              wifeViewBreakawayFailures: attempts + 1,
            },
          },
        };
      }
      return api.fn('updateWife')(next, current => ({
        ...current,
        lastResponse: line,
        lastResponseType: result.attackerWins ? 'neutral' : 'hesitant',
        lastResponseSlot: next.slot,
      }));
    });

    api.actions.register('wife-view-mode/invite-join', (state, action) => {
      if (!WifeViewMode_활성여부(state)) return state;
      const scene = state.activeScene?.patron;
      const primary = state.customers?.find(item => item.id === scene?.customerId);
      const candidate = state.customers?.find(item => item.id === action.customerId);
      const wife = api.fn('wife')(state);
      if (!scene?.wifeViewControlled || !primary || !candidate
        || WifeViewMode_수동응대차단사유찾기(state, wife, primary, { allowControlled: true })) return state;
      let candidates;
      try {
        candidates = (api.fn('WifeViewModeJoinCandidates')(state) || [])
          .filter(item => item.id !== scene.customerId);
      } catch {
        return state;
      }
      if (!candidates.some(item => item.id === candidate.id)) return state;
      const invitation = WifeViewMode_대사고르기(state, candidate, WifeViewMode_합류대사, `join:${scene.stage}`);
      let next = api.fn('log')(state, invitation);
      const willingness = api.fn('WifeViewModeJoinWilling')(next, candidate);
      if (!willingness?.willing) {
        return api.fn('log')(next, WifeViewMode_관계문구(`${candidate.name}은(는) 잠시 {rtHer}와 두 사람을 바라보다가 고개를 저으며 이번에는 물러납니다.`, state));
      }
      const slots = api.fn('joinSlots')(scene, scene.stage, scene.joinedPatronSlots || {}, false) || [];
      const slot = slots[0];
      if (!slot) return api.fn('log')(next, `${candidate.name}이(가) 다가오지만 지금 장면에는 자연스럽게 합류할 자리가 없습니다.`);
      next = api.fn('addJoinedPatron')(next, next.activeScene.patron, candidate.id, slot);
      return WifeViewMode_손님장면제어표시하기(next, scene.customerId, scene.wifeViewAction || 'talk');
    });

    api.actions.register('wife-view-mode/set-finish-preference', (state, action) => {
      if (!WifeViewMode_활성여부(state) || !['inside', 'outside'].includes(action.preference)) return state;
      const scene = state.activeScene?.patron;
      if (!scene?.wifeViewControlled || !['blowjob_patron', 'sex_patron'].includes(scene.stage)) return state;
      const customer = state.customers?.find(item => item.id === scene.customerId);
      if (!customer) return state;
      const wife = api.fn('wife')(state);
      if (WifeViewMode_수동응대차단사유찾기(state, wife, customer, { allowControlled: true })) return state;
      const lines = action.preference === 'inside' ? WifeViewMode_안에대사 : WifeViewMode_밖에대사;
      const line = WifeViewMode_대사고르기(state, customer, lines, `${action.preference}:${scene.stage}`, {
        oral: scene.stage === 'blowjob_patron',
      });
      let next = {
        ...state,
        activeScene: {
          ...state.activeScene,
          patron: { ...scene, wifeViewFinishPreference: action.preference },
        },
      };
      next = api.fn('log')(next, line);
      return api.fn('updateWife')(next, current => ({
        ...current,
        lastResponse: line,
        lastResponseType: 'eager',
        lastResponseSlot: next.slot,
      }));
    });

    api.actions.register('wife-view-mode/stop-patron', (state) => {
      const scene = state.activeScene?.patron;
      if (!WifeViewMode_손님장면조작가능여부(state)) return state;
      if (state.pendingEvent && state.pendingEvent.type !== 'patron_interaction') return state;
      let next = { ...state, pendingEvent: undefined };
      const customer = state.customers.find(item => item.id === scene.customerId);
      if (customer && (scene.wifeViewPersistentPressure || scene.stageBy === 'override' || scene.coercedSinceSlot != null)) {
        const chance = api.fn('patronControlRelentChance')(customer, scene.wifeViewRejectionCount || 0, api.fn('wife')(state), false);
        if (Math.random() >= chance) {
          next = { ...next, activeScene: { ...next.activeScene, patron: {
            ...scene, hasBeenRefused: true, wifeViewPatronEscalated: true, wifeViewPersistentPressure: true,
            wifeViewRejectionCount: (scene.wifeViewRejectionCount || 0) + 1,
          } } };
          return api.fn('log')(next, '중단을 요청했지만 손님이 물러나지 않습니다. 다시 거절하거나 뿌리치기를 시도할 수 있습니다.');
        }
      }
      const reason = scene.wifeViewPatronInitiated || scene.wifeViewPatronEscalated
        || scene.wifeViewPersistentPressure ? 'elena_refused' : 'patron_satisfied';
      return api.fn('WifeViewModeEndPatronInteraction')(next, reason, { suppressEndText: false });
    });

    api.actions.register('wife-view-mode/husband-interaction', (state, action) => {
      if (!WifeViewMode_활성여부(state) || WifeViewMode_남편상호작용차단사유(state, api.fn('wife')(state))) return state;
      const profile = WifeViewMode_자료읽기(state).husbandProfile;
      if (action.topicId === 'talk') {
        const feelings = { ...profile.feelings, tenderness: Math.min(100, profile.feelings.tenderness + 1) };
        let next = WifeViewMode_자료합치기(state, { husbandProfile: { ...profile, feelings } });
        next = api.fn('log')(next, WifeViewMode_관계문구(`${api.fn('wife')(state).name}이(가) {rtHis}에게 먼저 말을 겁니다. 두 사람은 서로의 생각을 나눕니다.`, state));
        return api.fn('tick')(next);
      }
      const choice = WifeViewMode_남편기본행동목록(state).find(item => item.id === action.topicId);
      if (!choice) return state;
      const outcome = api.fn('playerActionRespond')(state, choice.id);
      const intimate = !!outcome?.startScene;
      const receptiveness = profile.relationship.trust + profile.feelings.tenderness + profile.feelings.desire
        - profile.feelings.anger - profile.feelings.disgust;
      if (receptiveness < (intimate ? 45 : 15)) return api.fn('log')(state, WifeViewMode_관계문구("{rtHis}은 지금은 그 행동을 원하지 않는다고 말합니다. 두 사람은 현재 위치에 머무릅니다.", state));
      let next = api.fn('log')(state, WifeViewMode_관계문구(`${api.fn('wife')(state).name}이(가) {rtHis}에게 먼저 다가갑니다.`, state));
      next = api.fn('WifeViewModeApplyOutcome')(next, outcome);
      next = WifeViewMode_승인된이동실행하기(() => api.fn('WifeViewModeApplySceneOutcome')(next, outcome));
      if (!next.activeScene?.sex) {
        next = api.fn('log')(next, ['refuse', 'angry'].includes(outcome.response)
          ? WifeViewMode_관계문구("지금의 상태에서는 이 함께하는 행동을 이어가지 않습니다.", state) : '두 사람은 현재 위치에서 함께 시간을 보냅니다.');
        for (let index = 0; index < 2 && !next.pendingEvent; index += 1) next = api.fn('tick')(next);
      }
      return next;
    });

    api.actions.register('wife-view-mode/resolve-move', (state, action) => {
      if (!WifeViewMode_활성여부(state) || state.pendingEvent?.type !== 'wife_view_move') return state;
      const event = state.pendingEvent;
      if (!['approve_move', 'decline_move'].includes(action.choiceId)) return state;
      let next = { ...state, pendingEvent: undefined };
      if (action.choiceId === 'decline_move') {
        if (next.activeScene?.patron) next = { ...next, activeScene: { ...next.activeScene, patron: {
          ...next.activeScene.patron, wifeViewDeclinedMoveRoom: event.room,
        } } };
        return api.fn('log')(next, WifeViewMode_관계문구("{rtHer}는 장소 이동을 거절하고 지금 있는 곳에 머무릅니다.", state));
      }
      const customer = next.customers.find(item => item.id === event.customerId);
      if (!customer || WifeViewMode_인물장소찾기(next, customer.id) !== api.fn('wifeLocation')(next)
        || !WifeViewMode_손님이동장소목록(next, customer).includes(event.room)) return next;
      next = WifeViewMode_함께이동하기(next, customer, event.room);
      next = api.fn('log')(next, WifeViewMode_관계문구("{rtHer}가 장소 이동을 승인하고 상대와 함께 자리를 옮깁니다.", state));
      return WifeViewMode_손님장면인계하기(next);
    });

    api.actions.register('wife-view-mode/wife-service', (state, action) => {
      if (!WifeViewMode_활성여부(state)
        || !action.fromShop && WifeViewMode_자료읽기(state).wifeServiceMode !== 'manual') return state;
      const wife = api.fn('wife')(state);
      const customer = state.customers?.find(item => item.id === action.customerId);
      const blocked = action.fromShop ? WifeViewMode_가게응대차단사유찾기(state, wife, customer)
        : WifeViewMode_수동응대차단사유찾기(state, wife, customer);
      if (blocked) return state;
      let next = state;
      if (action.kind === 'greet' && customer.status === 'arrived') {
        next = api.fn('WifeViewModeWifeGreet')(state, customer);
        next = { ...next, customers: next.customers.map(item => item.id === customer.id ? { ...item, wifeViewGreeted: true } : item) };
      }
      if (action.kind === 'order' && ['greeted', 'wants_more'].includes(customer.status)) {
        next = api.fn('WifeViewModeWifeTakeOrder')(state, customer);
      }
      if (action.kind === 'serve' && customer.status === 'ordered' && customer.order
        && api.fn('waitressAvailable')(state, customer.order)) {
        next = api.fn('WifeViewModeWifeServe')(state, customer);
      }
      if (action.kind === 'out-of-stock' && customer.status === 'ordered' && customer.order
        && !api.fn('waitressAvailable')(state, customer.order)) {
        const missing = api.fn('waitressMissing')(state, customer.order).join(' or ');
        const alternative = api.fn('waitressAlternative')(state, customer.order);
        next = api.fn('WifeViewModeOutOfStock')(state, customer, missing, alternative, 'wife');
      }
      if (!action.fromShop || next === state) return next;
      const finishSlot = Math.min(state.slot + 10, Math.max(state.slot + 1, api.fn('wife')(next).busyUntilSlot ?? state.slot));
      // The native wife action applies inventory/payment once. Only its work time is advanced here.
      for (let count = 0; next.slot < finishSlot && count < 10; count += 1) {
        if (next.gameOver || next.pendingEvent || next.activeScene?.patron || next.activeScene?.sex || next.phase !== state.phase) break;
        const before = next.slot;
        next = api.fn('tick')(next);
        if (next.slot <= before) break;
      }
      return next;
    });

    api.actions.register('wife-view-mode/finish-night', (state, action) => {
      if (!WifeViewMode_심야마무리가능여부(state)) return state;
      const closingSlot = (api.fn('WifeViewModeTavernDay')(state.slot) - 1)
        * api.fn('WifeViewModeMinutesPerDay') + api.fn('WifeViewModeNightCloseSlot');
      let next = state;
      for (let count = 0; next.slot < closingSlot && count < 600; count += 1) {
        if (next.gameOver || next.pendingEvent || next.activeScene?.patron || next.activeScene?.sex
          || next.activeScene?.table || next.activeScene?.bathhouse || next.phase === 'prep') return next;
        const before = next.slot;
        next = api.fn('tick')(next);
        if (next.slot <= before) return next;
      }
      // Never clear events to fast-forward. The ordinary reducer owns collection/rent and settlement.
      if (next.gameOver || next.pendingEvent || next.activeScene?.patron || next.activeScene?.sex || next.slot < closingSlot) return next;
      if (next.phase === 'closed') next = api.fn('WifeViewModeEndDay')(next);
      if (action.sleep && !next.gameOver && !next.pendingEvent && next.phase === 'bedroom') next = api.fn('WifeViewModeSleep')(next, false);
      return next;
    });

    function WifeViewMode_남편표현으로바꾸기(text,state=api.store.game()) {
      if (typeof text !== 'string' || !text.includes('당신')) return text;
      return text
        .replaceAll('당신은', WifeViewMode_관계문구("{rtHis}은",state))
        .replaceAll('당신이', WifeViewMode_관계문구("{rtHis}이",state))
        .replaceAll('당신을', WifeViewMode_관계문구("{rtHis}을",state))
        .replaceAll('당신의', WifeViewMode_관계문구("{rtHis}의",state))
        .replaceAll('당신에게', WifeViewMode_관계문구("{rtHis}에게",state))
        .replaceAll('당신과', WifeViewMode_관계문구("{rtHis}과",state))
        .replaceAll('당신', WifeViewMode_관계문구("{rtHis}",state));
    }

    function WifeViewMode_남편응대로그바꾸기(state, originalLogLength) {
      if (!Array.isArray(state?.log) || state.log.length <= originalLogLength) return state;
      return {
        ...state,
        log: state.log.map((entry, index) => index < originalLogLength || typeof entry?.text !== 'string'
          ? entry
          : { ...entry, text: WifeViewMode_남편표현으로바꾸기(entry.text,state) }),
      };
    }

    api.actions.register('wife-view-mode/patron-action', (state, action) => {
      if (!WifeViewMode_활성여부(state)) return state;
      const wife = api.fn('wife')(state);
      const customer = state.customers?.find(item => item.id === action.customerId);
      const controlled = !!(state.activeScene?.patron?.wifeViewControlled
        && state.activeScene.patron.customerId === customer?.id);
      if (!customer?.wifeViewGreeted
        || WifeViewMode_수동응대차단사유찾기(state, wife, customer, { allowControlled: controlled })) return state;
      let dare;
      try {
        dare = (api.fn('WifeViewModeDaresAvailable')(state, 'with_someone') || [])
          .find(item => item.id === action.dareId);
        if (!dare || !(api.fn('WifeViewModeDareTargets')(state, dare) || []).some(target => target.id === customer.id)) return state;
        const consequence = dare.consequenceEager || dare.consequenceReluctant;
        if (typeof consequence !== 'function') return state;
        const prepared = WifeViewMode_아내행동남편반응적용하기(state, action.dareId, customer);
        const beforeLogLength = prepared.log?.length ?? 0;
        let next = consequence(prepared, customer) || prepared;
        if ((next.log?.length ?? 0) === beforeLogLength) {
          const rawText = typeof dare.text?.eager === 'string' ? dare.text.eager : `${wife.name}이(가) ${customer.name}에게 먼저 다가갑니다.`;
          const text = rawText
            .replaceAll('{w}', wife.name)
            .replaceAll('{target}', customer.name)
            .replaceAll('%w', wife.name)
            .replaceAll('%p', customer.name);
          next = api.fn('log')(next, text);
        }
        return WifeViewMode_손님장면제어표시하기(next, customer.id, state.activeScene?.patron?.wifeViewAction || 'talk');
      } catch (error) {
        api.warn(`Wife_View_Mode: 손님 접근 행동(${action.dareId})을 안전하게 중단했습니다. ${error?.message || error}`);
        return state;
      }
    });

    api.actions.register('wife-view-mode/propose-move', (state, action) => {
      if (!WifeViewMode_활성여부(state)) return state;
      const wife = api.fn('wife')(state);
      const customer = state.customers?.find(item => item.id === action.customerId);
      const controlled = !!(state.activeScene?.patron?.wifeViewControlled
        && state.activeScene.patron.customerId === customer?.id);
      if (!customer?.wifeViewGreeted
        || WifeViewMode_수동응대차단사유찾기(state, wife, customer, { allowControlled: controlled })) return state;
      if (!WifeViewMode_손님이동장소목록(state, customer).includes(action.room)) return state;
      const roomLabel = api.fn('brothelRoomLabels')?.[action.room] || action.room;
      let next = WifeViewMode_함께이동하기(state, customer, action.room);
      const joinedIds = controlled ? state.activeScene.patron.joinedPatronIds || [] : [];
      const line = `${wife.name}이(가) ${customer.name}에게 ${roomLabel}(으)로 자리를 옮기자고 제안합니다. 그가 함께 따라갑니다.${joinedIds.length ? ' 함께하던 손님들도 두 사람을 따라 자리를 옮깁니다.' : ''}`;
      if (!controlled) {
        const movedCustomer = next.customers?.find(item => item.id === customer.id) || customer;
        return WifeViewMode_손님장면시작하기(next, movedCustomer, 'talk', line);
      }
      next = api.fn('log')(next, line);
      next = api.fn('updateWife')(next, current => ({
        ...current,
        lastResponse: line,
        lastResponseType: 'neutral',
        lastResponseSlot: next.slot,
      }));
      return WifeViewMode_손님장면제어표시하기(next, customer.id, state.activeScene.patron.wifeViewAction || 'talk');
    });

    api.actions.register('wife-view-mode/lose-next-game', (state) => {
      if (!WifeViewMode_활성여부(state) || !state.activeScene?.table || state.activeScene.table.wifeViewLoseNext) return state;
      return {
        ...state,
        activeScene: {
          ...state.activeScene,
          table: { ...state.activeScene.table, wifeViewLoseNext: true },
        },
      };
    });

    const WifeViewMode_뒷방응대문맥 = [];
    api.hook('WifeViewModeServiceEventResolve', {
      around(next, state, choiceId, ...args) {
        const kind = WifeViewMode_응대사건종류찾기(state.pendingEvent);
        if (!WifeViewMode_활성여부(state) || !kind) return next(state, choiceId, ...args);
        // Revalidate at dispatch time too: native party resolution otherwise silently substitutes the husband.
        const choice = WifeViewMode_응대사건표현바꾸기(state, state.pendingEvent).choices.find(item => item.id === choiceId);
        if (!choice || choice.disabled) return state;
        if (kind !== 'back-room') return WifeViewMode_승인된이동실행하기(() => next(state, choiceId, ...args));
        const context = { delivered: false };
        WifeViewMode_뒷방응대문맥.push(context);
        try { return WifeViewMode_승인된이동실행하기(() => next(state, choiceId, ...args)); }
        finally { WifeViewMode_뒷방응대문맥.pop(); }
      },
    });
    api.hook('WifeViewModeBackRoomOutcome', {
      after(result, [state, choiceId]) {
        if (!WifeViewMode_활성여부(state) || !result?.outcome) return result;
        const delivered = (result.outcome.goldChange ?? 0) > 0;
        const context = WifeViewMode_뒷방응대문맥.at(-1);
        if (context) context.delivered = delivered;
        if (choiceId === 'back_round_ignore') return result;
        const count = ['beer', 'wine'].reduce((sum, key) => sum + Math.max(0,
          (state.supplies[key] ?? 0) - (result.state.supplies[key] ?? 0)), 0);
        const text = delivered
          ? choiceId === 'back_round_send_wife'
            ? `${api.fn('wife')(state).name}이(가) 직접 쟁반을 들고 뒷방으로 들어가 술 ${count}잔을 서빙합니다.`
            : WifeViewMode_관계문구(`{rtHis}에게 서빙을 부탁합니다. {rtHis}이 뒷방 손님에게 술 ${count}잔을 가져다주는 동안 {rtHer}는 현재 장소에 남습니다.`)
          : '맥주와 와인이 부족해 뒷방 주문을 서빙할 수 없습니다.';
        return { ...result, outcome: { ...result.outcome, logText: text } };
      },
    });
    api.hook('WifeViewModeBackRoomEnter', {
      around(next, state, ...args) {
        if (WifeViewMode_활성여부(state) && WifeViewMode_뒷방응대문맥.at(-1)?.delivered === false) return state;
        return next(state, ...args);
      },
    });
    api.hook('WifeViewModeBackRoomAutoOrder', {
      around(next, state, ...args) {
        if (!WifeViewMode_활성여부(state)) return next(state, ...args);
        // A husband off-screen is not authority to send the controlled wife away automatically.
        if (state.pendingEvent) return state;
        return api.fn('WifeViewModeBackRoomOrder')(state);
      },
    });
    api.hook('WifeViewModeToiletRequest', {
      around(next, state, customer, ...args) {
        if (!WifeViewMode_활성여부(state) || state.pendingEvent
          || WifeViewMode_응대인물차단사유찾기(state, 'wife')
          || api.fn('WifeViewModeToiletKnown')(state, customer)
          || api.fn('WifeViewModeToiletAddressee')(state, customer) !== 'her') return next(state, customer, ...args);
        const candidate = next(state, customer, ...args);
        if (candidate === state) return state; // Keep native occupancy and request-eligibility guards.
        if (candidate.pendingEvent && !['toilet'].includes(WifeViewMode_응대사건종류찾기(candidate.pendingEvent))
          && candidate.pendingEvent.type !== 'wife_view_move') return candidate;
        // Native pointing/escort branches may immediately act when the husband is absent. Offer a choice instead.
        return { ...state, pendingEvent: { type: 'patron_offer', customerId: customer.id, customerName: customer.name,
          text: `${customer.name}이(가) 화장실 위치를 묻습니다. 어떻게 안내할지 직접 선택합니다.`,
          choices: [{ id: 'privy_let_her', label: '직접 안내하기' },
            { id: 'privy_line', label: '안내하고 바로 돌아오기' },
            { id: 'privy_point', label: '위치 알려주기' }] } };
      },
    });
    api.hook('WifeViewModeToiletResolve', {
      around(next, state, choiceId, ...args) {
        if (!WifeViewMode_활성여부(state) || WifeViewMode_응대사건종류찾기(state.pendingEvent) !== 'toilet') return next(state, choiceId, ...args);
        const customer = state.customers.find(item => item.id === state.pendingEvent.customerId);
        if (!customer || WifeViewMode_응대인물차단사유찾기(state, 'wife')) return state;
        let result = { ...state, pendingEvent: undefined };
        const text = choiceId === 'privy_point' ? WifeViewMode_관계문구(`화장실은 계단 옆이라고 ${customer.name}에게 알려줍니다. {rtHer}는 현재 장소에 남습니다.`, state)
          : choiceId === 'privy_line' ? `${customer.name}을(를) 화장실 문까지 안내하고 바로 홀로 돌아옵니다.`
          : `${customer.name}을(를) 화장실 문까지 직접 안내합니다.`;
        if (choiceId === 'privy_let_her') {
          result = WifeViewMode_승인된이동실행하기(() => api.fn('moveWife')(result, 'bathroom', result.slot + 2));
          result = api.fn('updateWife')(result, wife => ({ ...wife, currentTask: 'serving',
            taskTarget: undefined, busyUntilSlot: result.slot + 2 }));
        }
        // A wife's own direction/return decision is not a husband's restriction or permission memory.
        result = api.fn('log')(result, text);
        return api.fn('WifeViewModeToiletVisit')(result, customer);
      },
    });
    api.hook('WifeViewModeEventOverlay', {
      before(args) {
        const state = api.store.game(), event = state?.pendingEvent, props = args[0];
        if (!WifeViewMode_활성여부(state) || !WifeViewMode_응대사건종류찾기(event)
          || !props?.choices?.some(choice => event.choices.some(item => item.id === choice.id))) return;
        const presented = WifeViewMode_응대사건표현바꾸기(state, event);
        return [{ ...props, body: presented.text || props.body, choices: props.choices.map(choice => ({ ...choice,
          ...presented.choices.find(item => item.id === choice.id) })), onChoice: id => {
          const current = api.store.game();
          if (current?.pendingEvent !== event) return;
          const choice = WifeViewMode_응대사건표현바꾸기(current, event).choices.find(item => item.id === id);
          if (choice && !choice.disabled) props.onChoice(id);
        } }, ...args.slice(1)];
      },
      after(result, [props]) {
        const state = api.store.game();
        if (!WifeViewMode_활성여부(state) || !WifeViewMode_응대사건종류찾기(state.pendingEvent)) return result;
        return WifeViewMode_요소찾아바꾸기(result,
          node => node.type === 'button' && props.choices.some(choice => node.key?.endsWith(choice.id)),
          node => {
            const choice = props.choices.find(item => node.key?.endsWith(item.id));
            return React.cloneElement(node, { disabled: !!choice.disabled, 'data-wvm-service-choice': choice.id });
          });
      },
    });

    api.hook('WifeViewModeWifeAI', {
      around(next, state) {
        if (!state || !WifeViewMode_자율행동차단여부(state)) return next(state);
        const wife = api.fn('wife')(state);
        if (!wife || state.pendingEvent || state.activeScene?.patron || state.activeScene?.sex || state.activeScene?.table
          || wife.retiredAtSlot != null || wife.passedOutAtSlot != null
          || ['away', 'sleeping', 'passed_out', 'bathing', 'resting', 'composing'].includes(wife.currentTask)
          || (wife.busyUntilSlot ?? 0) > state.slot
          || wife.locationUntilSlot != null && wife.locationUntilSlot > state.slot) return state;
        return api.fn('updateWife')(state, current => ({
          ...current,
          currentTask: 'idle',
          taskTarget: undefined,
          busyUntilSlot: state.slot,
        }));
      },
    });

    api.hook('WifeViewModeCardScore', {
      after(result) {
        if (!WifeViewMode_카드강제패배중 || WifeViewMode_카드점수사용됨) return result;
        WifeViewMode_카드점수사용됨 = true;
        return -1000000000;
      },
    });

    api.hook('WifeViewModeResolveCardHand', {
      around(next, ...args) {
        const state = args[0];
        if (!state?.activeScene?.table?.wifeViewLoseNext || !WifeViewMode_활성여부(state)) return next(...args);
        WifeViewMode_카드강제패배중 = true;
        WifeViewMode_카드점수사용됨 = false;
        let result;
        try {
          result = next(...args);
        } finally {
          WifeViewMode_카드강제패배중 = false;
          WifeViewMode_카드점수사용됨 = false;
        }
        if (result?.activeScene?.table) {
          result = {
            ...result,
            activeScene: {
              ...result.activeScene,
              table: { ...result.activeScene.table, wifeViewLoseNext: undefined },
            },
          };
        }
        return api.fn('log')(result, `${api.fn('wife')(state).name}은(는) 이번 판에서 일부러 허술한 패를 내 승리를 양보했습니다.`);
      },
    });

    api.hook('WifeViewModePatronFinishChoice', {
      after(result, args) {
        const scene = args?.[0];
        if (!WifeViewMode_활성여부() || !scene?.wifeViewControlled || !scene.wifeViewFinishPreference) return result;
        if (scene.stage === 'blowjob_patron') {
          return scene.wifeViewFinishPreference === 'inside' ? 'patron_blowjob_swallow' : 'patron_facial';
        }
        if (scene.stage === 'sex_patron') {
          const anal=scene.primarySlot==='inside_anal';
          return scene.wifeViewFinishPreference === 'inside' ? anal?'patron_anal_finish':'patron_sex_finish' : anal?'patron_anal_finish_pullout':'patron_sex_finish_pullout';
        }
        return result;
      },
    });

    api.hook('minuteTick', {
      after(result) {
        if (!result || WifeViewMode_남편응대처리중 || !WifeViewMode_활성여부(result)) return result;
        const data = WifeViewMode_자료읽기(result);
        if (data.husbandServiceMode !== 'auto'
          || !['service', 'last_call'].includes(result.phase)
          || result.gameOver
          || result.pendingEvent
          || result.activeScene?.sex
          || result.errandSession
          || result.activeShoppingSession
          || (result.player?.stats?.energy ?? 1) <= 0) return result;
        const location = api.fn('playerLocation')(result);
        if (!['taproom', 'kitchen'].includes(location)) return result;
        const sameDay = data.husbandServiceDay === result.day;
        const readySlot = sameDay && Number.isFinite(Number(data.husbandServiceReadySlot))
          ? Number(data.husbandServiceReadySlot)
          : result.slot;
        if (result.slot < readySlot) return result;
        let action;
        try {
          action = api.fn('WifeViewModeHusbandNextTavernAction')(result);
          if (location === 'kitchen' && ['greet', 'take_order', 'serve', 'apologize_out_of_stock', 'clean'].includes(action?.type)) {
            action = { type: 'return_to_taproom' };
          }
        } catch (error) {
          api.warn(WifeViewMode_관계문구(`Wife_View_Mode: {rtHis} 응대 행동 선택을 중단했습니다. ${error?.message || error}`));
          return WifeViewMode_자료합치기(result, {
            husbandServiceDay: result.day,
            husbandServiceReadySlot: result.slot + 1,
          });
        }
        if (!action || action.type === 'wait') {
          return WifeViewMode_자료합치기(result, {
            husbandServiceDay: result.day,
            husbandServiceReadySlot: result.slot + 1,
          });
        }
        const originalLogLength = result.log?.length ?? 0;
        WifeViewMode_남편응대처리중 = true;
        try {
          let next = api.fn('WifeViewModeApplyPlayerTavernAction')(result, action) || result;
          next = WifeViewMode_남편응대로그바꾸기(next, originalLogLength);
          const duration = Math.max(1, Number(api.fn('actionTimes')?.[action.type]) || 1);
          return WifeViewMode_자료합치기(next, {
            husbandServiceDay: result.day,
            husbandServiceReadySlot: result.slot + duration,
          });
        } catch (error) {
          api.warn(WifeViewMode_관계문구(`Wife_View_Mode: {rtHis} 응대 행동(${action.type})을 안전하게 중단했습니다. ${error?.message || error}`));
          return WifeViewMode_자료합치기(result, {
            husbandServiceDay: result.day,
            husbandServiceReadySlot: result.slot + 1,
          });
        } finally {
          WifeViewMode_남편응대처리중 = false;
        }
      },
    });

    api.hook('decisionResolve', {
      after(result, args) {
        const [state, , context] = args;
        if (globalThis.__waywardDeliveryCompatibleWifeView?.ownsScene(state)) return result;
        if (!result || !state || !WifeViewMode_활성여부(state) || !api.fn('patronScene')(state)) return result;
        if (['player_intimate', 'player_service'].includes(context?.kind) || context?.kind === 'dare' && context?.targetPatron) return result;
        const intent = WifeViewMode_자료읽기(state).wifeIntent;
        if (intent === 'refuse' && (result.outcome === 'eager' || result.outcome === 'hesitant')) {
          return { ...result, outcome: 'refuse', score: Math.min(result.score, result.threshold - 1) };
        }
        if (intent === 'cautious' && result.outcome === 'eager') return { ...result, outcome: 'hesitant' };
        return result;
      },
    });

    api.hook('patronControlSelfEscalationRoll', {
      after(result, args) {
        const state = args?.[3];
        if (globalThis.__waywardDeliveryCompatibleWifeView?.ownsScene(state)) return result;
        if (!state || !WifeViewMode_활성여부(state)) return result;
        return 0;
      },
    });

    api.hook('patronControlHerBackRoomProposal', {
      around(next, state, ...args) {
        return WifeViewMode_활성여부(state) && !globalThis.__waywardDeliveryCompatibleWifeView?.ownsScene(state)
          ? { state } : next(state, ...args);
      },
    });

    api.hook('moveWife', {
      around(next, state, room, ...args) {
        return WifeViewMode_자동이동차단여부(state, room) ? state : next(state, room, ...args);
      },
    });
    api.hook('moveOccupant', {
      around(next, state, id, room, ...args) {
        return id === state.primaryCharacterId && WifeViewMode_자동이동차단여부(state, room)
          ? state : next(state, id, room, ...args);
      },
    });
    api.hook('worldTick', {
      around(next, state, ...args) {
        if (!WifeViewMode_활성여부(state)) return next(state, ...args);
        WifeViewMode_세계진행목록.push({ phase: state.phase, day: state.day });
        try { return WifeViewMode_남은손님복귀시키기(WifeViewMode_멈춘장면정리하기(WifeViewMode_손님장면인계하기(next(state, ...args)))); }
        finally { WifeViewMode_세계진행목록.pop(); }
      },
    });
    api.hook('WifeViewModeRetire', {
      around(next, state, ...args) {
        // Native health/night retirement is not an optional service-AI movement.
        return WifeViewMode_활성여부(state)
          ? WifeViewMode_승인된이동실행하기(() => next(state, ...args)) : next(state, ...args);
      },
    });
    api.hook('WifeViewModeEndDay', {
      around(next, state, ...args) {
        // Automatic closing must not erase a newly raised collection/rent/other choice.
        return WifeViewMode_활성여부(state) && state.pendingEvent ? state : next(state, ...args);
      },
    });
    api.hook('WifeViewModeBreakForService', {
      around(next, state, ...args) {
        return WifeViewMode_손님장면조작가능여부(state) ? null : next(state, ...args);
      },
    });
    api.hook('WifeViewModeRestStart', {
      around(next, state, ...args) {
        return !WifeViewMode_승인된이동깊이 && WifeViewMode_자율행동차단여부(state)
          ? state : next(state, ...args);
      },
    });
    api.hook('WifeViewModeAgencyTick', {
      around(next, state, ...args) {
        return WifeViewMode_자율행동차단여부(state) ? state : next(state, ...args);
      },
    });
    api.hook('WifeViewModeOffHoursPatronTick', {
      around(next, state, ...args) {
        if (WifeViewMode_손님장면조작가능여부(state) && !['service', 'last_call', 'closed'].includes(state.phase)) {
          return api.fn('processPatronInteractionTick')(state);
        }
        return next(state, ...args);
      },
    });
    api.hook('WifeViewModeStartPatronInteraction', {
      after(result) { return WifeViewMode_손님장면인계하기(result); },
    });
    api.hook('processPatronInteractionTick', {
      after(result, args) {
        if (!WifeViewMode_손님장면조작가능여부(result)) return result;
        const before = args[0].activeScene?.patron;
        let next = WifeViewMode_손님장면인계하기(result);
        const scene = next.activeScene.patron;
        const advanced = before?.customerId === scene.customerId
          && WifeViewMode_손님장면단계번호(scene.stage) > WifeViewMode_손님장면단계번호(before.stage)
          && scene.stageBy !== 'self';
        const forced = scene.stageBy === 'override' || scene.coercedSinceSlot != null;
        next = { ...next, activeScene: { ...next.activeScene, patron: {
          ...scene, wifeViewPatronEscalated: !!(scene.wifeViewPatronEscalated || advanced || forced),
          wifeViewPersistentPressure: !!(scene.wifeViewPersistentPressure || forced),
          ...(advanced ? { wifeViewEscalatedFromStage: before.stage } : {}),
        } } };
        return WifeViewMode_손님장면제어표시하기(next, scene.customerId);
      },
    });
    api.hook('WifeViewModeEndPatronInteraction', {
      around(next, state, ...args) {
        if (!WifeViewMode_손님장면조작가능여부(state)) return next(state, ...args);
        const room = api.fn('wifeLocation')(state);
        let result = next(state, ...args);
        const wife = api.fn('wife')(result);
        if (wife && wife.passedOutAtSlot == null && (wife.stats?.energy ?? 1) > 0
          && !['away', 'sleeping', 'passed_out'].includes(wife.currentTask)
          && result.phase === state.phase) {
          if (api.fn('wifeLocation')(result) !== room) result = WifeViewMode_승인된이동실행하기(() => api.fn('moveWife')(result, room));
          result = api.fn('updateWife')(result, current => ({ ...current, wifeViewHoldPosition: true,
            currentTask: 'idle', taskTarget: undefined, busyUntilSlot: result.slot, locationUntilSlot: undefined }));
        }
        const reasons = api.fn('WifeViewModeSatiety')(api.fn('wife')(state), state.slot).reasons
          .filter(reason => reason.value >= 0.15).map(reason => reason.label);
        const labels = { patron_climax: '상대의 반응이 마무리되어 장면이 종료되었습니다.',
          patron_satisfied: '상대가 상호작용을 마무리했습니다.', chat_complete: '대화가 마무리되었습니다.',
          elena_refused: '거절 또는 원래 상태 판정에 따라 장면이 종료되었습니다.',
          elena_broke_for_service: '응대 작업으로 장면이 종료되었습니다.', patron_gave_up: '상대와의 장면이 종료되었습니다.' };
        result = WifeViewMode_자료합치기(result, { lastSceneEnd: { slot: result.slot, reason: args[0],
          message: `${labels[args[0]] || '원래 게임의 종료 판정에 따라 장면이 끝났습니다.'}${reasons.length ? ` 현재 부담: ${reasons.join(', ')}.` : ''}` } });
        return WifeViewMode_남은손님복귀시키기(result);
      },
    });
    for (const name of ['WifeViewModePrivateBackRoomStart',
      'WifeViewModeRenterUpstairsStart', 'WifeViewModePrivateBathroomStart']) {
      api.hook(name, {
        around(next, state, ...args) {
          if (!WifeViewMode_활성여부(state) || WifeViewMode_승인된이동깊이) return next(state, ...args);
          // Run the native eligibility check, but commit no movement/effects before consent.
          const candidate = WifeViewMode_승인된이동실행하기(() => next(state, ...args));
          const room = api.fn('wifeLocation')(candidate);
          if (room === api.fn('wifeLocation')(state)) return state;
          const customerId = candidate.activeScene?.patron?.customerId || args[0]?.customerId || args[0]?.id;
          return WifeViewMode_장소이동제안만들기(state, room, customerId);
        },
      });
    }
    api.hook('patronControlPatronBackRoomProposal', {
      around(next, state, ...args) {
        if (globalThis.__waywardDeliveryCompatibleWifeView?.ownsScene(state)) return next(state, ...args);
        if (!WifeViewMode_활성여부(state)) return next(state, ...args);
        const result = next(state, ...args);
        const scene = result.state?.activeScene?.patron;
        if (result.event || result.state?.pendingEvent?.type === 'wife_view_move'
          || scene?.backRoomProposedThisInteraction && !state.activeScene?.patron?.backRoomProposedThisInteraction) {
          const marked = { ...state, activeScene: { ...state.activeScene, patron: {
            ...state.activeScene.patron, backRoomProposedThisInteraction: true,
          } } };
          return { state: WifeViewMode_장소이동제안만들기(marked, 'back_room', scene?.customerId) };
        }
        return result;
      },
    });
    api.hook('WifeViewModeScenePresentation', {
      after(result, args) {
        const state = args[0];
        if (!WifeViewMode_손님장면조작가능여부(state) || state.activeScene?.sex || state.activeScene?.bathhouse) return result;
        const scene = state.activeScene.patron;
        // Preserve native group/finish images. For a solo custom action use the actual stage and slot.
        if ((scene.joinedPatronIds || []).length) return result;
        const wife = api.fn('wife')(state);
        return { ...result, scene: WifeViewMode_손님장면그림찾기(scene, wife),
          sceneVariant: WifeViewMode_그림변형번호정규화하기(wife.sceneVariant) };
      },
    });

    function WifeViewMode_초상화전환보강하기(result) {
      const state = api.store.game();
      if (!WifeViewMode_활성여부(state)) return result;
      const presentation = api.fn('WifeViewModeScenePresentation')(state);
      const key = `wife-view:${state.primaryCharacterId}:${api.fn('wifeLocation')(state)}:${presentation.scene || 'idle'}`;
      return WifeViewMode_요소찾아바꾸기(result,
        node => node.type === api.fn('WifeViewModePortrait'),
        node => React.cloneElement(node, { key }));
    }
    for (const name of ['WifeViewModeFocusColumn', 'WifeViewModeLayout', 'WifeViewModeEventOverlay']) {
      api.hook(name, { after: WifeViewMode_초상화전환보강하기 });
    }

    api.hook('imageGenerate', {
      around(next, request, ...args) {
        const state = api.store.game();
        if (!WifeViewMode_활성여부(state) || !globalThis.__WW_STUDIO_OFFLINE_ONLY__ || request?.bypassCache
          || request?.imageKey?.split('__')[0] !== api.fn('WifeViewModeImageKey')(state).split('__')[0]) return next(request, ...args);
        // Offline Studio blocks generation but does not disable the native online-mode exact-key requirement.
        // Explicitly reuse the native nearest-pack lookup. No generated assets or server settings are changed.
        return api.fn('WifeViewModeImageLookup')(request.imageKey, { nearest: true })
          .then(entry => entry ? { url: api.fn('WifeViewModeImageUrl')(entry), fresh: false } : null);
      },
    });
    api.hook('WifeViewModeShopCustomer', { after: WifeViewMode_가게손님버튼보강하기 });

    api.hook('ActionPanel', {
      after(result) {
        const state = api.store.game();
        if (!state || !WifeViewMode_활성여부(state)) return result;
        return JSX.jsx(WifeViewMode_행동패널그리기, { state });
      },
    });

    api.hook('WifeViewModeLocationOverview', {
      after: WifeViewMode_장소패널보강하기,
    });

    api.hook('WifeViewModeGameShell', {
      after: WifeViewMode_게임화면보강하기,
    });

    globalThis.__waywardWifeViewCompatibility = { version: '0.10.1', delivery: true, pregnancy: true,relationText:WifeViewMode_관계문구 };
    api.ui.settings(WifeViewMode_설정본문그리기);
    try { api.ui.pauseSettings?.({label:{ko:"여성 시점 모드 설정",en:'Wife view settings'},attributes:{'data-wvm-pause':'settings'},onClick:WifeViewMode_설정창열기}); } catch (error) { console.warn("[wife-view-mode] 공통 설정 메뉴 등록 실패: 기존 직접 삽입 방식으로 계속합니다.", error); }
    api.ui.menuSettings({ label: "여성 시점 모드 설정", onClick: WifeViewMode_설정창열기,
      attributes: { 'data-wvm-pause': 'settings', 'data-wml-ui': 'wife-view-mode' } });
    WifeViewMode_스타일설치하기();
    api.store.subscribe(() => {
      WifeViewMode_기존장면자료복구하기();
      WifeViewMode_조작자료동기화하기();
      WifeViewMode_비활성잔여상태정리하기();
      WifeViewMode_남편판단예약하기();
    });
    WifeViewMode_기존장면자료복구하기();
    WifeViewMode_조작자료동기화하기();
    WifeViewMode_비활성잔여상태정리하기();
    WifeViewMode_남편판단예약하기();
  },
});
