// Run: node wml/mods/wife-view-mode/tests/service-perspective-regression.mjs --wml .
import assert from 'node:assert/strict';
import { playStart, playEval, playStatus, playStop } from '../../../../MCP/lib/play.mjs';

const session = 'wife-service-perspective-regression';
try {
  console.log(JSON.stringify(await playStart({ id: session, fresh: true, mods: { 'wife-view-mode': true } })));
  console.log(JSON.stringify(await playEval({ id: session, code: `
    const dev = WML.dev();
    let seed = 1138; Math.random = () => { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; return (seed >>> 0) / 4294967296; };
    dev.fn('settingsStore').getState().set({ageAffirmed:true,contentAcknowledged:true});
    let state=structuredClone(dev.store.game());
    state={...state,day:1,slot:1100,phase:'service',pendingEvent:undefined,activeScene:{},customers:[],errandSession:undefined,
      economy:{...state.economy,gold:10000,debt:0},supplies:{...state.supplies,beer:100,wine:100,food:100},readyFood:8,
      mods:{...state.mods,'wife-view-mode':{active:true,wifeServiceMode:'manual',husbandServiceMode:'manual'}}};
    state.locations=Object.fromEntries(Object.entries(state.locations).map(([room,value])=>[room,{...value,occupants:[],meta:{}}]));
    state.locations.taproom.occupants.push(state.primaryCharacterId);state.locations.kitchen.occupants.push('player');
    state=dev.fn('updateWife')(state,wife=>({...wife,currentTask:'idle',busyUntilSlot:state.slot,locationUntilSlot:undefined,
      retiredAtSlot:undefined,passedOutAtSlot:undefined,stats:{...wife.stats,energy:100}}));
    for(let index=0;index<3;index++) {
      const customer={...dev.fn('makeCustomer')(state.slot,[],state.patronRecords,state.tavernReputation,state),id:'customer-service-'+index,
        status:'drinking',servedBy:'wife',privyAtSlot:undefined,patience:500,maxPatience:500,stayTimer:500,boldness:1,charm:1,intent:'drink_only'};
      state=dev.fn('addCustomer')(state,customer,index<2?'back_room':'taproom');
    }
    state.locations.back_room.meta.party={occupiedBy:'town_watch',startedAtSlot:1090,lastBeatSlot:1090,endAtSlot:1300,mood:50,drinks:0};
    dev.store.set(outer=>({...outer,state,started:true,selectingArchetype:false,selectingBuilder:false,selectingPicks:false}));
    window.WifeViewMode_serviceBase=structuredClone(dev.store.game());
    window.WifeViewMode_resetService=()=>{Math.random=()=>.99999;dev.store.update(()=>structuredClone(window.WifeViewMode_serviceBase));};
    window.WifeViewMode_guestRoom=(state,id)=>Object.entries(state.locations).find(([,value])=>value.occupants.includes(id))?.[0];
    // These raw names are isolated test probes for the mod-private symbols, unavailable on WML.dev().fn.
    window.WifeViewMode_partyOrder=()=>dev.store.update(state=>dev.fn('wEe')(state));
    window.WifeViewMode_privyOrder=()=>dev.store.update(state=>dev.fn('eye')(state,state.customers.find(c=>c.id==='customer-service-2')));
    await new Promise(resolve=>setTimeout(resolve,100));
    [...document.querySelectorAll('button')].find(b=>b.innerText.trim()==='건너뛰기')?.click();
    return {setup:true};
  ` })));
  async function check(name, code) {
    const result=await playEval({id:session,code});
    console.log(JSON.stringify({test:name,...result}));
    assert.equal(result.pageErrorsSoFar,0,name);
    assert.ok(result.result && Object.values(result.result).every(value=>value===true),name+': '+JSON.stringify(result.result));
  }
  await check('party self-service button uses wife and native single payment', `
    const dev=WML.dev();window.WifeViewMode_resetService();window.WifeViewMode_partyOrder();
    const before=dev.store.game();await new Promise(resolve=>setTimeout(resolve,100));
    const button=[...document.querySelectorAll('button')].find(b=>b.innerText.startsWith('직접 들고가기'));button?.click();
    await new Promise(resolve=>setTimeout(resolve,100));const after=dev.store.game();
    dev.store.dispatch({type:'resolve_event',choiceId:'back_round_send_wife'});
    return {button:!!button&&!button.disabled,wifeMoved:dev.fn('wifeLocation')(after)==='back_room',husbandStayed:dev.fn('playerLocation')(after)==='kitchen',
      stockOnce:after.supplies.beer===before.supplies.beer-1,paidOnce:after.economy.gold===before.economy.gold+2,
      retryNoDoublePay:dev.store.game().economy.gold===after.economy.gold,eventCleared:!after.pendingEvent,
      selfLog:after.log.some(l=>l.text.includes('직접 쟁반'))};
  `);
  await check('party asking husband keeps wife in hall and correct log', `
    const dev=WML.dev();window.WifeViewMode_resetService();window.WifeViewMode_partyOrder();
    const before=dev.store.game();await new Promise(resolve=>setTimeout(resolve,100));
    const button=[...document.querySelectorAll('button')].find(b=>b.innerText.startsWith('남편에게 들고가달라 하기'));button?.click();
    await new Promise(resolve=>setTimeout(resolve,100));const after=dev.store.game();
    return {button:!!button&&!button.disabled,wifeStayed:dev.fn('wifeLocation')(after)==='taproom',stockOnce:after.supplies.beer===before.supplies.beer-1,
      paidOnce:after.economy.gold===before.economy.gold+2,correctLog:after.log.some(l=>l.text.includes('남편에게 서빙을 부탁'))};
  `);
  await check('absent husband cannot be asked through UI or stale dispatch', `
    const dev=WML.dev();window.WifeViewMode_resetService();
    dev.store.update(state=>dev.fn('moveOccupant')(state,'player','market'));window.WifeViewMode_partyOrder();
    await new Promise(resolve=>setTimeout(resolve,100));const before=dev.store.game();
    const button=[...document.querySelectorAll('button')].find(b=>b.innerText.startsWith('남편에게 들고가달라 하기'));button?.click();
    dev.store.dispatch({type:'resolve_event',choiceId:'back_round_go_yourself'});
    return {buttonDisabled:!!button?.disabled,noServe:dev.store.game().supplies.beer===before.supplies.beer,eventKept:!!dev.store.game().pendingEvent};
  `);
  await check('unavailable wife does not silently substitute husband', `
    const dev=WML.dev();window.WifeViewMode_resetService();window.WifeViewMode_partyOrder();
    dev.store.update(state=>dev.fn('moveOccupant')(state,state.primaryCharacterId,'bedroom'));
    const before=dev.store.game();dev.store.dispatch({type:'resolve_event',choiceId:'back_round_send_wife'});
    return {noServe:dev.store.game().supplies.beer===before.supplies.beer,eventKept:!!dev.store.game().pendingEvent,wifeStayed:dev.fn('wifeLocation')(dev.store.game())==='bedroom'};
  `);
  await check('stock-out does not send wife to empty-handed service', `
    const dev=WML.dev();window.WifeViewMode_resetService();dev.store.update(state=>({...state,supplies:{...state.supplies,beer:0,wine:0}}));
    window.WifeViewMode_partyOrder();const before=dev.store.game();dev.store.dispatch({type:'resolve_event',choiceId:'back_round_send_wife'});
    const after=dev.store.game();return {wifeStayed:dev.fn('wifeLocation')(after)==='taproom',noPayment:after.economy.gold===before.economy.gold,
      noNegativeStock:after.supplies.beer===0&&after.supplies.wine===0,reason:after.log.some(l=>l.text.includes('부족해 뒷방 주문'))};
  `);
  await check('off-screen husband party orders become wife choices, not forced moves', `
    const dev=WML.dev();window.WifeViewMode_resetService();const before=dev.store.game();const after=dev.fn('LAe')(before);
    return {event:after.pendingEvent?.choices.some(c=>c.id==='back_round_send_wife'),stockUntouched:before.supplies.beer===after.supplies.beer,
      wifeStayed:dev.fn('wifeLocation')(after)==='taproom'};
  `);
  await check('toilet request asks wife even when native pointing would be immediate', `
    const dev=WML.dev();window.WifeViewMode_resetService();window.WifeViewMode_privyOrder();
    await new Promise(resolve=>setTimeout(resolve,100));const state=dev.store.game();
    return {event:state.pendingEvent?.choices.some(c=>c.id==='privy_point'),guestStayed:window.WifeViewMode_guestRoom(state,'customer-service-2')==='taproom',
      wifeChoices:document.body.innerText.includes('안내하고 바로 돌아오기'),noHusbandInstruction:!document.body.innerText.includes('돌아오라고 하기')};
  `);
  for(const [id,room] of [['privy_point','taproom'],['privy_line','taproom'],['privy_let_her','bathroom']]) {
    await check('toilet '+id+' respects wife decision without husband boundary writes', `
      const dev=WML.dev();window.WifeViewMode_resetService();window.WifeViewMode_privyOrder();const before=dev.store.game();
      dev.store.dispatch({type:'resolve_event',choiceId:${JSON.stringify(id)}});const after=dev.store.game();
      return {guestMoved:window.WifeViewMode_guestRoom(after,'customer-service-2')==='bathroom',wifeRoom:dev.fn('wifeLocation')(after)===${JSON.stringify(room)},
        noBoundaryWrite:JSON.stringify(dev.fn('wife')(after).latitude)===JSON.stringify(dev.fn('wife')(before).latitude),
        noForcedScene:!after.activeScene?.patron,eventCleared:!after.pendingEvent,timeAdvanced:after.slot>before.slot};
    `);
  }
  await check('known toilet visitors keep native self-directed behavior', `
    const dev=WML.dev();window.WifeViewMode_resetService();dev.store.update(state=>({...state,customers:state.customers.map(c=>c.id==='customer-service-2'?{...c,privyAtSlot:1090}:c)}));
    window.WifeViewMode_privyOrder();return {noUnnecessaryChoice:!dev.store.game().pendingEvent,guestMoved:window.WifeViewMode_guestRoom(dev.store.game(),'customer-service-2')==='bathroom'};
  `);
  await check('event overlay relabels and disables choices without skipping native render', `
    const dev=WML.dev();window.WifeViewMode_resetService();
    dev.store.update(state=>dev.fn('moveOccupant')(state,'player','market'));window.WifeViewMode_partyOrder();
    const event=dev.store.game().pendingEvent;let renders=0,calls=0;
    const unhook=dev.hook('WBe',{around(next,...args){renders++;return next(...args);}});
    const tree=dev.fn('WBe')({title:'주문',body:event.text,choices:event.choices,onChoice:()=>calls++});unhook();
    const elements=[];const walk=node=>{if(!node||typeof node!=='object')return;elements.push(node);const children=node.props?.children;
      for(const child of (Array.isArray(children)?children:[children]))walk(child);};walk(tree);
    const husband=elements.find(node=>node.props?.['data-wvm-service-choice']==='back_round_go_yourself');husband?.props.onClick();
    return {originalOnce:renders===1,disabled:husband?.props.disabled===true,noDispatch:calls===0,
      noOriginalWifeInstruction:!JSON.stringify(tree).includes('에게 술을 들고 들어가게 하기')};
  `);
  await check('bathhouse ordinary service labels use wife perspective', `
    const dev=WML.dev();window.WifeViewMode_resetService();
    dev.store.update(state=>({...state,pendingEvent:{type:'patron_offer',category:'bathhouse_service',customerId:'customer-service-2',
      text:'손님이 평범한 시중을 요청합니다.',choices:[{id:'bathhouse_service:fixture:accept',label:'아내를 시중들러 보내기'},
        {id:'bathhouse_service:fixture:refuse',label:'그녀를 다시 불러들이기',description:'부탁받은 일은 끝났습니다.'}]}}));
    await new Promise(resolve=>setTimeout(resolve,100));const text=document.body.innerText;
    return {wifeAction:text.includes('요청에 직접 응하기'),wifeRefusal:text.includes('요청 거절하고 응대 마치기'),
      noWifeCommand:!text.includes('아내를 시중들러 보내기')&&!text.includes('그녀를 다시 불러들이기')};
  `);
  await check('husband view retains original labels and native toilet memories', `
    const dev=WML.dev();window.WifeViewMode_resetService();
    dev.store.update(state=>dev.fn('moveOccupant')({...state,mods:{...state.mods,'wife-view-mode':{...state.mods['wife-view-mode'],active:false}}},'player','taproom'));
    window.WifeViewMode_partyOrder();await new Promise(resolve=>setTimeout(resolve,100));
    const partyNative=document.body.innerText.includes('에게 술을 들고 들어가게 하기')&&!document.body.innerText.includes('남편에게 들고가달라 하기');
    dev.store.update(state=>({...state,pendingEvent:undefined}));Math.random=()=>0;window.WifeViewMode_privyOrder();
    await new Promise(resolve=>setTimeout(resolve,100));
    const toiletNative=dev.store.game().pendingEvent?.choices.some(c=>c.label==='안내하고 곧장 돌아오라고 하기');
    const before=dev.fn('wife')(dev.store.game()).latitude;dev.store.dispatch({type:'resolve_event',choiceId:'privy_point'});
    return {partyNative,toiletNative,nativeMemoryKept:JSON.stringify(before)!==JSON.stringify(dev.fn('wife')(dev.store.game()).latitude)};
  `);
  const status=await playStatus({id:session});
  assert.deepEqual(status.failed,[]);assert.deepEqual(status.pageErrors,[]);assert.deepEqual(status.warnings,[]);
  console.log(JSON.stringify({ok:true,servicePerspective:true}));
} finally { await playStop({id:session}); }
