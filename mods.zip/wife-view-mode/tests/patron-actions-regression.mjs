// Run: node wml/mods/wife-view-mode/tests/patron-actions-regression.mjs --wml .
import { playStart, playEval, playStatus, playStop } from '../../../../MCP/lib/play.mjs';
import assert from 'node:assert/strict';

const session = 'wife-patron-regression';
const activities = [
  'expose_penis', 'touch_penis', 'mouth_penis', 'breasts_penis',
  'thigh_rub', 'genital_rub', 'ride_vaginal', 'anal_from_behind',
];

try {
  console.log(JSON.stringify(await playStart({
    id: session, fresh: true, mods: { 'wife-view-mode': true },
  })));
  const fixture = await playEval({ id: session, code: `
    const dev = WML.dev();
    let seed = 1138;
    Math.random = () => {
      seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5;
      return (seed >>> 0) / 4294967296;
    };
    dev.fn('settingsStore').getState().set({ ageAffirmed: true, contentAcknowledged: true });
    let state = structuredClone(dev.store.game());
    state = { ...state, day: 1, slot: 1020, phase: 'service', pendingEvent: undefined,
      activeScene: undefined, errandSession: undefined, rngState: 1138,
      mods: { ...(state.mods || {}), 'wife-view-mode': {
        active: true, wifeServiceMode: 'manual', husbandServiceMode: 'manual', wifeIntent: 'self',
      } },
    };
    state.locations = Object.fromEntries(Object.entries(state.locations).map(([room, value]) => [room, {
      ...value, occupants: value.occupants.filter(id => id !== 'player' && id !== state.primaryCharacterId),
    }]));
    state.locations.taproom.occupants.push('player', state.primaryCharacterId);
    state = dev.fn('updateWife')(state, wife => ({
      ...wife, currentTask: 'idle', busyUntilSlot: state.slot, sceneOverride: undefined,
      sceneVariant: undefined, stats: { ...wife.stats, energy: 100, arousal: 70 },
    }));
    const customer = {
      ...dev.fn('makeCustomer')(state.slot, [], state.patronRecords, state.tavernReputation, state),
      status: 'drinking', patience: 500, maxPatience: 500, stayTimer: 500,
      boldness: 45, charm: 50, roundsOrdered: 1,
    };
    state = dev.fn('addCustomer')(state, customer, 'taproom');
    dev.store.set(outer => ({ ...outer, state, started: true,
      selectingArchetype: false, selectingBuilder: false, selectingPicks: false,
    }));
    dev.store.dispatch({ type: 'wife-view-mode/greet-patron', customerId: customer.id });
    window.wifeRegressionBase = structuredClone(dev.store.game());
    window.wifeRegressionCustomerId = customer.id;
    window.WifeViewMode_resetFixture = (room = 'taproom') => {
      seed = 1138;
      let next = structuredClone(window.wifeRegressionBase);
      next = dev.fn('moveOccupant')(next, next.primaryCharacterId, room);
      next = dev.fn('moveOccupant')(next, customer.id, room);
      dev.store.update(() => next);
    };
    window.WifeViewMode_validateImages = state => {
      const wife = dev.fn('wife')(state);
      if (wife.sceneVariant != null && !Number.isInteger(wife.sceneVariant)) throw new Error('Invalid native sceneVariant');
      for (const room of ['taproom', 'back_room', 'bathhouse', 'upstairs_hall']) {
        dev.fn('imagePrompt')(wife, room, undefined, 0, state.activeScene?.patron);
        const descriptor = dev.fn('imageDescriptor')(wife, room, undefined, 0, state.activeScene?.patron);
        if (!Number.isFinite(descriptor.variant)) throw new Error('Invalid image descriptor in ' + room);
      }
    };
    await new Promise(resolve => setTimeout(resolve, 100));
    const skip = [...document.querySelectorAll('button')].find(button => button.innerText.trim() === '건너뛰기');
    if (skip) skip.click();
    await new Promise(resolve => setTimeout(resolve, 100));
    return { fixture: true, greeted: dev.store.game().customers[0].wifeViewGreeted,
      slot: dev.store.game().slot, visible: !!document.querySelector('[data-wvm-header]'),
      started: dev.store.get().started, body: document.body.innerText.slice(0,150) };
  ` });
  assert.equal(fixture.result.greeted, true);
  assert.equal(fixture.result.visible, true);
  const results = [];
  for (const room of ['taproom', 'back_room']) for (const activity of activities) {
    const check = await playEval({ id: session, code: `
      const activity = ${JSON.stringify(activity)};
      const dev = WML.dev();
      window.WifeViewMode_resetFixture(${JSON.stringify(room)});
      const customerId = window.wifeRegressionCustomerId;
      const result = { activity, room: ${JSON.stringify(room)}, entered: false, ticks: 0, errors: [] };
      try {
        if (activity !== 'expose_penis') dev.store.dispatch({
          type: 'wife-view-mode/start-patron-activity', activity: 'expose_penis', customerId,
        });
        dev.store.dispatch({ type: 'wife-view-mode/start-patron-activity', activity, customerId });
        let state = dev.store.game();
        result.entered = state.activeScene?.patron?.wifeViewAction === activity;
        result.stage = state.activeScene?.patron?.stage;
        result.slot = state.activeScene?.patron?.primarySlot;
        result.sceneVariant = dev.fn('wife')(state).sceneVariant;
        window.WifeViewMode_validateImages(state);
        await new Promise(resolve => setTimeout(resolve, 60));
        result.uiAlive = !!document.querySelector('[data-wvm-header]');
        for (let i = 0; i < 25 && dev.store.game().activeScene?.patron; i += 1) {
          const before = dev.store.game().slot;
          dev.store.dispatch({ type: 'wife-view-mode/continue-patron' });
          await new Promise(resolve => setTimeout(resolve, 0));
          state = dev.store.game();
          window.WifeViewMode_validateImages(state);
          if (state.slot === before) { result.blocked = state.pendingEvent?.type || 'no-progress'; break; }
          result.ticks += 1;
        }
      } catch (error) { result.errors.push({ message: error.message, stack: error.stack }); }
      await new Promise(resolve => setTimeout(resolve, 50));
      const wife = dev.fn('wife')(dev.store.game());
      result.variantValid = wife.sceneVariant == null || Number.isFinite(wife.sceneVariant);
      result.pending = dev.store.game().pendingEvent?.type;
      result.ended = !dev.store.game().activeScene?.patron;
      return result;
    ` });
    results.push(check.result);
    console.log(JSON.stringify(check));
    assert.deepEqual(check.result.errors, [], activity + ' at ' + room);
    assert.equal(check.result.entered, true);
    assert.equal(check.result.uiAlive, true);
    assert.equal(check.result.variantValid, true);
    assert.ok(check.result.ticks > 0);
    assert.equal(check.result.blocked, undefined, 'Unexpected blocked progression');
    assert.equal(check.result.ended, true, 'Native scene did not end');
    assert.equal(check.pageErrorsSoFar, 0);
  }
  const transitions = await playEval({ id: session, code: `
    const dev = WML.dev();
    window.WifeViewMode_resetFixture('back_room');
    const customerId = window.wifeRegressionCustomerId;
    const dispatch = activity => {
      dev.store.dispatch({ type: 'wife-view-mode/start-patron-activity', customerId, activity });
      window.WifeViewMode_validateImages(dev.store.game());
      return dev.store.game().activeScene.patron;
    };
    dispatch('expose_penis');
    dispatch('ride_vaginal');
    const anal = dispatch('anal_from_behind');
    const ride = dispatch('ride_vaginal');
    for (const activity of ${JSON.stringify(activities.slice(1))}) dispatch(activity);
    dispatch('talk');
    const returnedToTalk = dev.store.game().activeScene.patron.stage;
    dispatch('anal_from_behind');
    dev.store.dispatch({ type: 'wife-view-mode/set-finish-preference', preference: 'outside' });
    dev.store.dispatch({ type: 'wife-view-mode/stop-patron' });
    await new Promise(resolve => setTimeout(resolve, 60));
    return { analSlot: anal.primarySlot, rideSlot: ride.primarySlot,
      recordedRide: anal.actsHad.some(act => act.stage === 'sex_patron' && act.slot === 'astride'),
      recordedAnal: ride.actsHad.some(act => act.stage === 'sex_patron' && act.slot === 'inside_anal'),
      returnedToTalk, stopped: !dev.store.game().activeScene?.patron,
      uiAlive: !!document.querySelector('[data-wvm-header]') };
  ` });
  console.log(JSON.stringify(transitions));
  assert.deepEqual(transitions.result, {
    analSlot: 'inside_anal', rideSlot: 'astride', recordedRide: true, recordedAnal: true,
    returnedToTalk: 'chatting', stopped: true, uiAlive: true,
  });
  const recovery = await playEval({ id: session, code: `
    const dev = WML.dev();
    const variants = [];
    for (const invalid of ['breasts', 'thigh', 'genitals', 'anal']) {
      window.WifeViewMode_resetFixture('back_room');
      dev.store.dispatch({ type: 'wife-view-mode/start-patron-activity',
        activity: 'expose_penis', customerId: window.wifeRegressionCustomerId });
      dev.store.dispatch({ type: 'wife-view-mode/start-patron-activity',
        activity: 'anal_from_behind', customerId: window.wifeRegressionCustomerId });
      const corrupted = dev.fn('updateWife')(structuredClone(dev.store.game()), wife => ({
        ...wife, sceneVariant: invalid,
      }));
      dev.store.update(() => corrupted);
      window.WifeViewMode_validateImages(dev.store.game());
      variants.push(dev.fn('wife')(dev.store.game()).sceneVariant);
    }
    dev.store.update(state => ({ ...state, activeScene: { ...state.activeScene, patron: {
      ...state.activeScene.patron, afterglow: { sinceSlot: state.slot, untilSlot: state.slot + 2,
        his: 'tender', her: 'sated', connection: 1, witnessed: false },
      finishedParticipantIds: [window.wifeRegressionCustomerId],
    } } }));
    dev.store.update(state => dev.fn('updateWife')(state, wife => ({ ...wife, sceneOverride: 'patron_cum_inside' })));
    const before = dev.store.game();
    dev.store.dispatch({ type: 'wife-view-mode/start-patron-activity',
      activity: 'mouth_penis', customerId: window.wifeRegressionCustomerId });
    const actionBlocked = dev.store.game() === before;
    dev.store.dispatch({ type: 'wife-view-mode/continue-patron' });
    const finishPreserved = dev.fn('wife')(dev.store.game()).sceneOverride === 'patron_cum_inside';
    dev.store.dispatch({ type: 'wife-view-mode/continue-patron' });
    await new Promise(resolve => setTimeout(resolve, 60));
    return { variants, actionBlocked, finishPreserved,
      ended: !dev.store.game().activeScene?.patron,
      uiAlive: !!document.querySelector('[data-wvm-header]') };
  ` });
  console.log(JSON.stringify(recovery));
  assert.deepEqual(recovery.result, {
    variants: [0, 0, 0, 0], actionBlocked: true, finishPreserved: true, ended: true, uiAlive: true,
  });
  const clicks = await playEval({ id: session, code: `
    const dev = WML.dev();
    window.WifeViewMode_resetFixture('back_room');
    const click = async label => {
      await new Promise(resolve => setTimeout(resolve, 60));
      const button = [...document.querySelectorAll('button')].find(item =>
        item.offsetParent && !item.disabled && item.innerText.trim().split('\\n')[0] === label);
      if (!button) throw new Error('Missing enabled UI button: ' + label);
      button.click();
      await new Promise(resolve => setTimeout(resolve, 60));
      window.WifeViewMode_validateImages(dev.store.game());
    };
    await click('손님의 성기를 꺼내기');
    await new Promise(resolve => setTimeout(resolve, 60));
    if (![...document.querySelectorAll('button')].some(button =>
      button.offsetParent && button.innerText.trim().split('\\n')[0] === '뒤로 돌아 엉덩이에 넣기')) {
      await click('다른 행동하기');
    }
    await click('뒤로 돌아 엉덩이에 넣기');
    const entered = dev.store.game().activeScene?.patron?.primarySlot === 'inside_anal';
    const before = dev.store.game().slot;
    await click('계속하기');
    return { entered, advanced: dev.store.game().slot === before + 1,
      uiAlive: !!document.querySelector('[data-wvm-header]') };
  ` });
  console.log(JSON.stringify(clicks));
  assert.deepEqual(clicks.result, { entered: true, advanced: true, uiAlive: true });
  const status = await playStatus({ id: session });
  console.log(JSON.stringify(status));
  assert.deepEqual(status.failed, []);
  assert.deepEqual(status.pageErrors, []);
  console.log(JSON.stringify({ ok: true, actionCases: results.length,
    promptRoomsPerState: 4, transitions: true, saveRecovery: true, uiClicks: true }));
} finally {
  await playStop({ id: session });
}
