// Run: node wml/mods/wife-view-mode/tests/control-regression.mjs --wml .
import { playStart, playEval, playStatus, playStop } from '../../../../MCP/lib/play.mjs';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const session = 'wife-control-regression';
const savePath = process.env.WIFE_VIEW_TEST_SAVE || 'C:/Users/user/Downloads/tavern-save-___-day3-2026-10-09T14-48-20.json';
const save = fs.existsSync(savePath) ? JSON.parse(fs.readFileSync(savePath, 'utf8')).state : null;

try {
  console.log(JSON.stringify(await playStart({ id: session, fresh: true, mods: { 'wife-view-mode': true } })));
  const setup = await playEval({ id: session, code: `
    const dev = WML.dev();
    window.WifeViewMode_testSeed = () => {
      let seed = 1138;
      Math.random = () => { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; return (seed >>> 0) / 4294967296; };
    };
    window.WifeViewMode_testSeed();
    dev.fn('settingsStore').getState().set({ ageAffirmed: true, contentAcknowledged: true });
    let state = structuredClone(dev.store.game());
    state = { ...state, day: 1, slot: 1000, phase: 'service', pendingEvent: undefined, activeScene: {},
      errandSession: undefined, rngState: 1138, customers: [],
      tavern: { ...state.tavern, hasRoom: true, hasRoom2: true, hasBathhouse: true, backRoomReady: true },
      mods: { ...state.mods, 'wife-view-mode': { active: true, wifeServiceMode: 'manual', husbandServiceMode: 'manual' } },
    };
    state.locations = Object.fromEntries(Object.entries(state.locations).map(([room, value]) => [room, { ...value, occupants: [], meta: {} }]));
    state.locations.taproom.occupants.push('player', state.primaryCharacterId);
    state = dev.fn('updateWife')(state, wife => ({ ...wife, currentTask: 'idle', busyUntilSlot: state.slot,
      locationUntilSlot: undefined, retiredAtSlot: undefined, passedOutAtSlot: undefined, sceneOverride: undefined,
      sceneVariant: undefined, stats: { ...wife.stats, energy: 100, mood: 100, arousal: 65 } }));
    const customer = { ...dev.fn('makeCustomer')(state.slot, [], state.patronRecords, state.tavernReputation, state),
      status: 'drinking', patience: 500, maxPatience: 500, stayTimer: 500, boldness: 40, charm: 50, roundsOrdered: 1,
    };
    state = dev.fn('addCustomer')(state, customer, 'taproom');
    dev.store.set(outer => ({ ...outer, state, started: true, selectingArchetype: false, selectingBuilder: false, selectingPicks: false }));
    window.WifeViewMode_testBase = structuredClone(dev.store.game());
    window.WifeViewMode_testId = customer.id;
    window.WifeViewMode_resetControl = (room = 'taproom', phase = 'service') => {
      window.WifeViewMode_testSeed();
      let next = structuredClone(window.WifeViewMode_testBase);
      next.phase = phase;
      next = dev.fn('moveOccupant')(next, next.primaryCharacterId, room);
      next = dev.fn('moveOccupant')(next, customer.id, room);
      dev.store.update(() => next);
    };
    await new Promise(resolve => setTimeout(resolve, 100));
    const skip = [...document.querySelectorAll('button')].find(button => button.innerText.trim() === '건너뛰기');
    if (skip) skip.click();
    return { id: customer.id };
  ` });
  assert.ok(setup.result.id);
  async function check(name, code) {
    const output = await playEval({ id: session, code });
    console.log(JSON.stringify({ test: name, ...output }));
    if(output.pageErrorsSoFar)console.log('PAGE_ERRORS',JSON.stringify((await playStatus({id:session})).pageErrors));
    assert.equal(output.pageErrorsSoFar, 0, name);
    assert.ok(output.result && Object.values(output.result).every(value => value === true), name + ': ' + JSON.stringify(output.result));
  }
  await check('native approach adoption, change, stop', `
    const dev = WML.dev(); window.WifeViewMode_resetControl('back_room');
    const id = window.WifeViewMode_testId;
    dev.store.update(state => dev.fn('startPatronInteraction')(state, id));
    const adopted = dev.store.game().activeScene?.patron?.wifeViewControlled;
    const guestInitiated = dev.store.game().activeScene?.patron?.wifeViewPatronInitiated;
    dev.store.dispatch({ type: 'wife-view-mode/start-patron-activity', customerId: id, activity: 'flirt' });
    const changed = dev.store.game().activeScene?.patron?.stage === 'flirting';
    dev.store.dispatch({ type: 'wife-view-mode/stop-patron' });
    return { adopted, guestInitiated, changed, stopped: !dev.store.game().activeScene?.patron,
      stayed: dev.fn('wifeLocation')(dev.store.game()) === 'back_room' };
  `);
  await check('private move approval and refusal', `
    const dev = WML.dev(); window.WifeViewMode_resetControl();
    const id = window.WifeViewMode_testId;
    dev.store.update(state => dev.fn('startPatronInteraction')(state, id));
    dev.store.update(state => dev.fn(WML.status().modSymbols['wife-view-mode'].WifeViewModePrivateBackRoomStart)(state,'back_room')); // 현재 빌드의 모드 전용 심볼을 사용합니다.
    const offered = dev.store.game().pendingEvent?.type === 'wife_view_move';
    const notMoved = dev.fn('wifeLocation')(dev.store.game()) === 'taproom';
    await new Promise(resolve => setTimeout(resolve, 300));
    const waitedForUser = dev.store.game().pendingEvent?.type === 'wife_view_move';
    dev.store.dispatch({ type: 'wife-view-mode/resolve-move', choiceId: 'decline_move' });
    const refused = dev.fn('wifeLocation')(dev.store.game()) === 'taproom' && !dev.store.game().pendingEvent;
    window.WifeViewMode_resetControl();
    dev.store.update(state => dev.fn('startPatronInteraction')(state, id));
    dev.store.update(state => dev.fn(WML.status().modSymbols['wife-view-mode'].WifeViewModePrivateBackRoomStart)(state,'back_room'));
    dev.store.dispatch({ type: 'wife-view-mode/resolve-move', choiceId: 'approve_move' });
    const state = dev.store.game();
    return { offered, notMoved, waitedForUser, refused,
      approved: dev.fn('wifeLocation')(state) === 'back_room' && dev.fn('patronControlCustomerLocation')(state, id) === 'back_room',
      preserved: !!state.activeScene?.patron?.wifeViewControlled };
  `);
  await check('guest proposal while husband is elsewhere', `
    const dev = WML.dev(); window.WifeViewMode_resetControl();
    const id = window.WifeViewMode_testId;
    dev.store.update(state => dev.fn('moveOccupant')(dev.fn('startPatronInteraction')(state, id), 'player', 'kitchen'));
    dev.store.update(state => ({ ...state, activeScene: { ...state.activeScene, patron: {
      ...state.activeScene.patron, stage: 'groping',
    } } }));
    Math.random = () => 0;
    dev.store.update(state => dev.fn('patronControlPatronBackRoomProposal')(state).state);
    const offered = dev.store.game().pendingEvent?.type === 'wife_view_move';
    const stayed = dev.fn('wifeLocation')(dev.store.game()) === 'taproom';
    await new Promise(resolve => setTimeout(resolve, 100));
    const button = [...document.querySelectorAll('button')].find(button => button.innerText.startsWith('여기에 머무르기'));
    button?.click();
    window.WifeViewMode_testSeed();
    return { offered, stayed, clicked: !!button, resolved: !dev.store.game().pendingEvent };
  `);
  await check('manual movement and post-scene position', `
    const dev = WML.dev(); window.WifeViewMode_resetControl('back_room');
    let state = dev.store.game();
    for (let i = 0; i < 30; i++) {
      state = { ...state, pendingEvent: undefined };
      state = dev.fn('worldTick')(state, { playerPresent: true });
    }
    const idleStayed = dev.fn('wifeLocation')(state) === 'back_room';
    window.WifeViewMode_resetControl('back_room');
    const id = window.WifeViewMode_testId;
    dev.store.update(state => dev.fn('startPatronInteraction')(state, id));
    dev.store.update(state => dev.fn('endPatronInteraction')(state, 'patron_satisfied'));
    state = dev.store.game();
    state = { ...state, pendingEvent: undefined, mods: { ...state.mods, 'wife-view-mode': { ...state.mods['wife-view-mode'], wifeServiceMode: 'auto' } } };
    state = dev.fn('worldTick')(state, { playerPresent: true });
    return { idleStayed, endedStayed: dev.fn('wifeLocation')(state) === 'back_room', hold: !!dev.fn('wife')(state).wifeViewHoldPosition };
  `);
  await check('pre-opening room interaction and image keys', `
    const dev = WML.dev(); window.WifeViewMode_resetControl('upstairs_hall', 'prep');
    const id = window.WifeViewMode_testId;
    dev.store.dispatch({ type: 'wife-view-mode/greet-patron', customerId: id });
    const greeted = !!dev.store.game().customers.find(customer => customer.id === id).wifeViewGreeted;
    dev.store.dispatch({ type: 'wife-view-mode/start-patron-activity', customerId: id, activity: 'talk' });
    const started = !!dev.store.game().activeScene?.patron;
    const before = dev.store.game().slot;
    dev.store.dispatch({ type: 'wife-view-mode/continue-patron' });
    const advanced = dev.store.game().slot > before && (dev.store.game().activeScene?.patron?.ticksElapsed ?? 0) > 0;
    window.WifeViewMode_resetControl();
    dev.store.dispatch({ type: 'wife-view-mode/greet-patron', customerId: id });
    dev.store.dispatch({ type: 'wife-view-mode/start-patron-activity', customerId: id, activity: 'expose_penis' });
    const exposedKey = dev.fn(WML.status().modSymbols['wife-view-mode'].WifeViewModeImageKey)(dev.store.game());
    dev.store.dispatch({ type: 'wife-view-mode/start-patron-activity', customerId: id, activity: 'ride_vaginal' });
    const insertedKey = dev.fn(WML.status().modSymbols['wife-view-mode'].WifeViewModeImageKey)(dev.store.game());
    if(dev.store.game().pendingEvent?.type==='alert')dev.store.dispatch({type:'resolve_event',choiceId:'dismiss'});
    dev.store.dispatch({ type: 'wife-view-mode/propose-move', customerId: id, room: 'bedroom' });
    const movedKey = dev.fn(WML.status().modSymbols['wife-view-mode'].WifeViewModeImageKey)(dev.store.game());
    return { greeted, started, advanced, insertionChanged: exposedKey !== insertedKey,
      roomChanged: insertedKey !== movedKey, moved: dev.fn('wifeLocation')(dev.store.game()) === 'bedroom' };
  `);
  await check('escalated stop request and strength escape fallback', `
    const dev = WML.dev(); window.WifeViewMode_resetControl();
    const id = window.WifeViewMode_testId;
    dev.store.update(state => dev.fn('startPatronInteraction')(state, id));
    dev.store.update(state => ({ ...state, activeScene: { ...state.activeScene, patron: {
      ...state.activeScene.patron, wifeViewPatronEscalated: true, wifeViewPersistentPressure: true, stageBy: 'override',
    } } }));
    Math.random = () => 0.999;
    dev.store.dispatch({ type: 'wife-view-mode/stop-patron' });
    const failedRequest = !!dev.store.game().activeScene?.patron?.wifeViewPersistentPressure
      && dev.store.game().activeScene.patron.wifeViewRejectionCount > 0;
    await new Promise(resolve => setTimeout(resolve, 100));
    const escapeShown = [...document.querySelectorAll('button')].some(button => button.innerText.includes('뿌리치기'));
    Math.random = () => 0;
    dev.store.dispatch({ type: 'wife-view-mode/stop-patron' });
    window.WifeViewMode_testSeed();
    return { failedRequest, escapeShown, successfulRequest: !dev.store.game().activeScene?.patron };
  `);
  await check('guest return after manual escort', `
    const dev = WML.dev(); window.WifeViewMode_resetControl();
    const id = window.WifeViewMode_testId;
    dev.store.dispatch({ type: 'wife-view-mode/greet-patron', customerId: id });
    dev.store.dispatch({ type: 'wife-view-mode/propose-move', customerId: id, room: 'back_room' });
    const tracked = dev.store.game().customers.find(customer => customer.id === id).wifeViewReturnRoom === 'taproom';
    dev.store.dispatch({ type: 'wife-view-mode/stop-patron' });
    return { tracked, returned: dev.fn('patronControlCustomerLocation')(dev.store.game(), id) === 'taproom',
      wifeStayed: dev.fn('wifeLocation')(dev.store.game()) === 'back_room' };
  `);
  await check('portrait refresh with missing destination asset', `
    const dev = WML.dev(); window.WifeViewMode_resetControl();
    dev.fn('settingsStore').getState().set({ sfwMode: false });
    let missing = false;
    const unhook = dev.hook('imageGenerate', { priority:-3000000,around: (next, request) => Promise.resolve(missing ? null : {
      key:request.imageKey,url: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j1ZkAAAAASUVORK5CYII=#' + encodeURIComponent(request.imageKey),
    }) });
    const id = window.WifeViewMode_testId;
    dev.store.dispatch({ type: 'wife-view-mode/greet-patron', customerId: id });
    dev.store.dispatch({ type: 'wife-view-mode/start-patron-activity', customerId: id, activity: 'expose_penis' });
    await new Promise(resolve => setTimeout(resolve, 150));
    const image = () => [...document.querySelectorAll('img')].find(node => node.alt.startsWith(dev.fn('wife')(dev.store.game()).name + ' -'))?.src;
    const before = image();
    dev.store.dispatch({ type: 'wife-view-mode/start-patron-activity', customerId: id, activity: 'ride_vaginal' });
    await new Promise(resolve => setTimeout(resolve, 150));
    const inserted = image();
    missing = true;
    if(dev.store.game().pendingEvent?.type==='alert')dev.store.dispatch({type:'resolve_event',choiceId:'dismiss'});
    dev.store.dispatch({ type: 'wife-view-mode/propose-move', customerId: id, room: 'bedroom' });
    await new Promise(resolve => setTimeout(resolve, 150));
    const cleared = !image();
    unhook();
    return { firstImage: !!before, insertionChanged: !!inserted && before !== inserted, staleCleared: cleared };
  `);
  await check('husband interaction and native viewpoint isolation', `
    const dev = WML.dev(); window.WifeViewMode_resetControl();
    dev.store.dispatch({ type: 'wife-view-mode/husband-interaction', topicId: 'talk' });
    const talked = dev.store.game().log.some(line => line.text.includes('서로의 생각을 나눕니다'));
    await new Promise(resolve => setTimeout(resolve, 100));
    const shown = document.body.innerText.includes('남편과 상호작용');
    const menuButton = [...document.querySelectorAll('button')].find(button => button.innerText.startsWith('부부 행동 선택'));
    menuButton?.click();
    await new Promise(resolve => setTimeout(resolve, 50));
    const menuAlive = !!document.querySelector('[data-wvm-header]');
    window.WifeViewMode_resetControl();
    dev.store.update(state => ({ ...state, mods: { ...state.mods, 'wife-view-mode': { ...state.mods['wife-view-mode'], active: false } } }));
    await new Promise(resolve => setTimeout(resolve, 100));
    const isolated = !document.body.innerText.includes('남편과 상호작용');
    const state = dev.store.game();
    const ai = dev.fn(WML.status().modSymbols['wife-view-mode'].WifeViewModeWifeAI)(state);
    return { talked, shown, menuAlive, isolated, nativeAI: ai !== state };
  `);
  await check('native couple scene start and player choice', `
    const dev = WML.dev(); window.WifeViewMode_resetControl('bedroom', 'bedroom');
    dev.store.update(state => dev.fn('updateWife')(dev.fn('moveOccupant')(state, 'player', 'bedroom'), wife => ({
      ...wife, libido: 90, attributes: { ...wife.attributes, openness: 95, confidence: 95, composure: 90 },
      selfConcept: { ...wife.selfConcept, openness: 95, confidence: 95 },
      relationship: { ...wife.relationship, trust: 100 }, stats: { ...wife.stats, arousal: 90 },
    })));
    const state = dev.store.game();
    const choices = dev.fn(WML.status().modSymbols['wife-view-mode'].WifeViewModeConversationMenu)(state, 'sex').choices.filter(choice => choice.id !== 'back' && !choice.id.startsWith('cat_'));
    const choice = choices.find(item => dev.fn('playerActionRespond')(state, item.id)?.startScene);
    if (!choice) throw new Error('No eligible native couple scene: ' + JSON.stringify(choices.map(item => ({ id: item.id, response: dev.fn('playerActionRespond')(state, item.id)?.response }))));
    dev.store.dispatch({ type: 'wife-view-mode/husband-interaction', topicId: choice.id });
    const started = !!dev.store.game().activeScene?.sex;
    const manualChoice = dev.store.game().pendingEvent?.type === 'sex_scene';
    const event = dev.store.game().pendingEvent;
    const action = event?.choices.find(item => item.id === 'continue') || event?.choices[0];
    await new Promise(resolve => setTimeout(resolve, 100));
    const button = [...document.querySelectorAll('button')].find(node => node.innerText.startsWith(action?.label));
    const beforeChoice = dev.store.game();
    button?.click();
    await new Promise(resolve => setTimeout(resolve, 100));
    return { started, manualChoice, buttonWorks: !!button && dev.store.game() !== beforeChoice,
      uiAlive: !!document.querySelector('[data-wvm-header]') };
  `);
  await check('move event and escort cleanup on husband viewpoint switch', `
    const dev = WML.dev(); window.WifeViewMode_resetControl();
    const id = window.WifeViewMode_testId;
    dev.store.dispatch({ type: 'wife-view-mode/greet-patron', customerId: id });
    dev.store.dispatch({ type: 'wife-view-mode/propose-move', customerId: id, room: 'back_room' });
    dev.store.update(state => ({ ...state, pendingEvent: { type: 'wife_view_move', room: 'bedroom', customerId: id,
      choices: [{ id: 'approve_move', label: '이동을 승인하기' }] } }));
    dev.store.update(state => ({ ...state, mods: { ...state.mods, 'wife-view-mode': { ...state.mods['wife-view-mode'], active: false } } }));
    await new Promise(resolve => setTimeout(resolve, 100));
    const state = dev.store.game();
    return { eventCleared: !state.pendingEvent, ended: !state.activeScene?.patron,
      holdCleared: dev.fn('wife')(state).wifeViewHoldPosition === undefined,
      guestReturned: dev.fn('patronControlCustomerLocation')(state, id) === 'taproom',
      markerCleared: state.customers.find(customer => customer.id === id).wifeViewReturnRoom === undefined };
  `);
  if (save) await check('attached save stranded visitor repair', `
    const dev = WML.dev(); const save = ${JSON.stringify(save)};
    dev.store.update(() => structuredClone(save));
    await new Promise(resolve => setTimeout(resolve, 100));
    const state = dev.store.game();
    return { strandedReturned: dev.fn('patronControlCustomerLocation')(state, 'customer-38') === 'taproom',
      residentStayed: dev.fn('patronControlCustomerLocation')(state, 'customer-37') === 'upstairs_room_2',
      existingOutingPreserved: dev.fn('wife')(state).currentTask === 'away' };
  `);
  const status = await playStatus({ id: session });
  assert.deepEqual(status.failed, []);
  assert.deepEqual(status.pageErrors, []);
  console.log(JSON.stringify({ ok: true, controls: true, manualAI: true, imageKeys: true, attachedSave: !!save }));
} finally { await playStop({ id: session }); }
