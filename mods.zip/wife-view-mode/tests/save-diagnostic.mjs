// Run: node wml/mods/wife-view-mode/tests/save-diagnostic.mjs --wml .
import fs from 'node:fs';
import vm from 'node:vm';
import { playStart, playEval, playStatus, playStop } from '../../../../MCP/lib/play.mjs';

const session = 'wife-save-diagnostic';
const save = JSON.parse(fs.readFileSync('C:/Users/user/Downloads/tavern-save-___-day5-2026-10-09T15-45-47.json', 'utf8')).state;
const packs = { window: {} };
for (const file of ['images-elena-1.js', 'images-elena-2.js']) vm.runInNewContext(fs.readFileSync(file, 'utf8'), packs);
const entries = packs.window.__WAYWARD_IMAGE_PACKS__.flatMap(pack => Object.values(pack.entries));
for (const scene of ['patron_groping', 'patron_handjob', 'patron_blowjob', 'patron_riding', 'patron_anal', 'patron_titfuck']) {
  const found = entries.filter(entry => entry.talentName?.startsWith(`elena__scene-${scene}__`));
  console.log(JSON.stringify({ scene, entries: found.length, existingFiles: found.filter(entry => fs.existsSync('images/' + entry.imagePath)).length }));
}
try {
  console.log(JSON.stringify(await playStart({ id: session, fresh: true, mods: { 'wife-view-mode': true } })));
  console.log(JSON.stringify(await playEval({ id: session, code: `
    const dev = WML.dev();
    let seed = 1138; Math.random = () => { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; return (seed >>> 0) / 4294967296; };
    dev.fn('settingsStore').getState().set({ ageAffirmed: true, contentAcknowledged: true });
    dev.store.set(outer => ({ ...outer, state: ${JSON.stringify(save)}, started: true, selectingArchetype: false, selectingBuilder: false, selectingPicks: false }));
    await new Promise(resolve => setTimeout(resolve, 100));
    [...document.querySelectorAll('button')].find(button => button.innerText.trim() === '건너뛰기')?.click();
    await new Promise(resolve => setTimeout(resolve, 150));
    const before = dev.store.game().slot;
    dev.store.dispatch({ type: 'wait', minutes: 1 });
    const waited = dev.store.game().slot > before;
    const burden = dev.fn('Oh')(dev.fn('wife')(dev.store.game()),dev.store.game().slot);
    const results = [];
    for (const activity of ['talk', 'touch_penis', 'mouth_penis', 'ride_vaginal', 'anal_from_behind']) {
      dev.store.update(() => structuredClone(${JSON.stringify(save)}));
      if (activity !== 'talk') dev.store.dispatch({ type: 'wife-view-mode/start-patron-activity', activity: 'expose_penis', customerId: 'customer-73' });
      dev.store.dispatch({ type: 'wife-view-mode/start-patron-activity', activity, customerId: 'customer-73' });
      const begun = dev.store.game(); const key = dev.fn('u7')(begun); // Mod-private image-key symbol.
      const image = await dev.fn('Yp')(key, { nearest: true }); // Native pack lookup; no generation.
      let ticks = 0;
      while (dev.store.game().activeScene?.patron && ticks++ < 12 && !dev.store.game().pendingEvent) {
        dev.store.dispatch({ type: 'wife-view-mode/continue-patron' });
      }
      const end = dev.store.game(); const wife = dev.fn('wife')(end);
      results.push({ activity, began: !!begun.activeScene?.patron, key, selectedKey: image?.key ?? image?.talentName,
        slot: end.slot, elapsed: end.slot - begun.slot, energy: wife.stats.energy,
        task: wife.currentTask, scene: end.activeScene?.patron?.stage, event: end.pendingEvent?.type });
    }
    return { waited, burden, results };
  ` })));
  console.log(JSON.stringify(await playStatus({ id: session })));
} finally { console.log(JSON.stringify(await playStop({ id: session }))); }
