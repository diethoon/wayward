// Run: node wml/mods/wife-view-mode/tests/service-night-regression.mjs --wml .
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { playStart, playEval, playStatus, playStop } from '../../../../MCP/lib/play.mjs';

const session = 'wife-service-night-regression';
const path = 'C:/Users/user/Downloads/tavern-save-___-day5-2026-10-09T15-45-47.json';
const save = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, 'utf8')).state : null;
try {
  console.log(JSON.stringify(await playStart({ id: session, fresh: true, mods: { 'wife-view-mode': true } })));
  console.log(JSON.stringify(await playEval({ id: session, code: `
    const dev = WML.dev();
    window.WifeViewMode_seedTest = () => {
      let seed = 1138; Math.random = () => { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; return (seed >>> 0) / 4294967296; };
    };
    window.WifeViewMode_seedTest();
    dev.fn('settingsStore').getState().set({ ageAffirmed: true, contentAcknowledged: true });
    let state = structuredClone(dev.store.game());
    state = { ...state, day: 1, slot: 1100, phase: 'service', pendingEvent: undefined, activeScene: {},
      errandSession: undefined, rngState: 1138, customers: [],
      economy: { ...state.economy, gold: 10000, debt: 0 }, readyFood: 8,
      supplies: { ...state.supplies, beer: 100, wine: 100, food: 100 },
      mods: { ...state.mods, 'wife-view-mode': { active: true, wifeServiceMode: 'manual', husbandServiceMode: 'manual' } } };
    state.locations = Object.fromEntries(Object.entries(state.locations).map(([room,value]) => [room,{ ...value,occupants: [],meta: {} }]));
    state.locations.taproom.occupants.push(state.primaryCharacterId);
    state.locations.kitchen.occupants.push('player');
    state = dev.fn('updateWife')(state, wife => ({ ...wife, currentTask: 'idle', busyUntilSlot: state.slot,
      locationUntilSlot: undefined, retiredAtSlot: undefined, passedOutAtSlot: undefined, stats: { ...wife.stats, energy: 100 } }));
    const customer = { ...dev.fn('makeCustomer')(state.slot, [], state.patronRecords, state.tavernReputation, state),
      status: 'arrived', patience: 500, maxPatience: 500, stayTimer: 500, boldness: 1, charm: 1, intent: 'drink_only' };
    state = dev.fn('addCustomer')(state, customer, 'taproom');
    dev.store.set(outer => ({ ...outer, state, started: true, selectingArchetype: false, selectingBuilder: false, selectingPicks: false }));
    window.WifeViewMode_baseTest = structuredClone(dev.store.game()); window.WifeViewMode_customerTest = customer.id;
    window.WifeViewMode_resetTest = () => { window.WifeViewMode_seedTest(); dev.store.update(() => structuredClone(window.WifeViewMode_baseTest)); };
    window.WifeViewMode_nightTest = () => {
      window.WifeViewMode_resetTest();
      dev.store.update(state => dev.fn('updateWife')(dev.fn('moveOccupant')({ ...state, slot: 1515, phase: 'last_call', customers: [],
        locations: Object.fromEntries(Object.entries(state.locations).map(([room,value])=>[room,{ ...value,occupants: value.occupants.filter(id => !id.startsWith('customer-')) }])) }, state.primaryCharacterId, 'bedroom'),
        wife => ({ ...wife, currentTask: 'sleeping', retiredAtSlot: 1510, busyUntilSlot: 1515, stats: { ...wife.stats, energy: 5 } })));
      Math.random = () => .99999;
    };
    await new Promise(resolve => setTimeout(resolve, 100));
    [...document.querySelectorAll('button')].find(button => button.innerText.trim() === '건너뛰기')?.click();
    return { setup: true };
  ` })));
  async function check(name, code) {
    const result = await playEval({ id: session, code });
    console.log(JSON.stringify({ test: name, ...result }));
    assert.equal(result.pageErrorsSoFar, 0, name);
    assert.ok(result.result && Object.values(result.result).every(value => value === true), name + ': ' + JSON.stringify(result.result));
  }
  await check('shop greeting and order use wife with husband in kitchen', `
    const dev = WML.dev(); window.WifeViewMode_resetTest();
    const id = window.WifeViewMode_customerTest;
    await new Promise(resolve => setTimeout(resolve, 100));
    const greet = document.querySelector('[data-wvm-shop-service="greet"]'); const before = dev.store.game().slot;
    greet?.click(); await new Promise(resolve => setTimeout(resolve, 100));
    const greeted = dev.store.game().customers.find(c=>c.id===id)?.status === 'greeted';
    const advanced = dev.store.game().slot > before;
    const order = document.querySelector('[data-wvm-shop-service="order"]'); order?.click();
    await new Promise(resolve => setTimeout(resolve, 100));
    return { greetButton: !!greet && !greet.disabled, greeted, advanced, orderButton: !!order && !order.disabled,
      ordered: dev.store.game().customers.find(c=>c.id===id)?.status === 'ordered',
      husbandStayed: dev.fn('playerLocation')(dev.store.game()) === 'kitchen',
      manualPanelKept: document.body.innerText.includes('수동 응대'),
      noWrongActor: !dev.store.game().log.some(line=>line.text === '당신은 홀에 없습니다.') };
  `);
  await check('shop serving stock and payment applied once', `
    const dev = WML.dev(); window.WifeViewMode_resetTest(); const id = window.WifeViewMode_customerTest;
    dev.store.update(state=>({ ...state, customers: state.customers.map(c=>({ ...c,status:'ordered',order:'beer',roundsOrdered:1,tab:0,walletGold:100 })) }));
    const before = dev.store.game();
    await new Promise(resolve => setTimeout(resolve, 100));
    const serve = [...document.querySelectorAll('button')].find(b=>b.innerText==='서빙'); serve?.click();
    await new Promise(resolve => setTimeout(resolve, 100));
    const after = dev.store.game(); const customer = after.customers.find(c=>c.id===id);
    dev.store.dispatch({type:'wife-view-mode/wife-service',fromShop:true,kind:'serve',customerId:id});
    return { button: !!serve, served: customer?.status==='drinking' && customer.servedBy==='wife',
      stockOnce: after.supplies.beer === before.supplies.beer - 1, paid: after.economy.gold > before.economy.gold,
      retryNoDoublePay: dev.store.game().economy.gold === after.economy.gold,
      husbandStayed: dev.fn('playerLocation')(after)==='kitchen' };
  `);
  await check('wrong room disables shop buttons', `
    const dev = WML.dev(); window.WifeViewMode_resetTest();
    dev.store.update(state=>dev.fn('moveOccupant')(state,state.primaryCharacterId,'bedroom'));
    await new Promise(resolve => setTimeout(resolve, 100));
    const button = document.querySelector('[data-wvm-shop-service="greet"]'); const before=dev.store.game();
    button?.click(); dev.store.dispatch({type:'wife-view-mode/wife-service',fromShop:true,kind:'greet',customerId:window.WifeViewMode_customerTest});
    return { disabled: !!button?.disabled, unchanged: before === dev.store.game() };
  `);
  await check('shop action works in auto mode and out-of-stock path', `
    const dev=WML.dev(); window.WifeViewMode_resetTest(); const id=window.WifeViewMode_customerTest;
    dev.store.update(state=>({ ...state,mods:{...state.mods,'wife-view-mode':{...state.mods['wife-view-mode'],wifeServiceMode:'auto'}},
      customers:state.customers.map(c=>({...c,status:'ordered',order:'beer'})),supplies:{...state.supplies,beer:0,wine:0,food:0},readyFood:0 }));
    await new Promise(resolve=>setTimeout(resolve,100));
    const button=[...document.querySelectorAll('button')].find(b=>b.title.includes('없음 — 사과')); button?.click();
    await new Promise(resolve=>setTimeout(resolve,100));
    const state=dev.store.game();
    return { button:!!button, processed:state.customersLostToday>window.WifeViewMode_baseTest.customersLostToday,
      noStockUnderflow:state.supplies.beer===0, noWrongActor:!state.log.some(l=>l.text==='당신은 홀에 없습니다.') };
  `);
  await check('husband-view buttons still dispatch native actions', `
    const dev=WML.dev(); window.WifeViewMode_resetTest();
    dev.store.update(state=>dev.fn('moveOccupant')({...state,mods:{...state.mods,'wife-view-mode':{...state.mods['wife-view-mode'],active:false}}},'player','taproom'));
    await new Promise(resolve=>setTimeout(resolve,100));
    const isolated=!document.querySelector('[data-wvm-shop-service]');
    const button=[...document.querySelectorAll('button')].find(b=>b.innerText==='인사하기'); button?.click();
    await new Promise(resolve=>setTimeout(resolve,100));
    return { isolated, greeted:['greeted','ordered','drinking'].includes(dev.store.game().customers.find(c=>c.id===window.WifeViewMode_customerTest)?.status) };
  `);
  await check('native exhaustion retirement moves wife in manual mode', `
    const dev=WML.dev(); window.WifeViewMode_resetTest();
    dev.store.update(state=>dev.fn('updateWife')({...state,slot:1515,phase:'last_call'},wife=>({...wife,stats:{...wife.stats,energy:5}})));
    dev.store.dispatch({type:'wait',minutes:1});
    await new Promise(resolve=>setTimeout(resolve,100));
    return { retired:dev.fn('wife')(dev.store.game()).retiredAtSlot!=null,
      moved:['bedroom','elena_room'].includes(dev.fn('wifeLocation')(dev.store.game())),
      finishShown:[...document.querySelectorAll('button')].some(b=>b.innerText.startsWith('하루 마무리하기')) };
  `);
  await check('late sleep completes native settlement and next morning', `
    const dev=WML.dev(); window.WifeViewMode_nightTest();
    await new Promise(resolve=>setTimeout(resolve,100));
    const button=[...document.querySelectorAll('button')].find(b=>b.innerText.startsWith('잠자기')); button?.click();
    await new Promise(resolve=>setTimeout(resolve,100));
    const state=dev.store.game();
    return { button:!!button && !button.disabled, morning:state.phase==='prep', advanced:state.day>=2,
      restored:dev.fn('wife')(state).stats.energy>5, notGameOver:!state.gameOver };
  `);
  await check('finish night reaches 2 AM without skipping a collection event', `
    const dev=WML.dev(); window.WifeViewMode_nightTest();
    dev.store.dispatch({type:'wife-view-mode/finish-night',sleep:false});
    const closed=dev.store.game(); const reaches2=closed.slot>=1560 && closed.phase==='bedroom';
    window.WifeViewMode_nightTest();
    const unhook=dev.hook('minuteTick',{after:result=>({...result,pendingEvent:{type:'alert',text:'수금 확인',choices:[{id:'pay',label:'지불하기'}]}})});
    dev.store.dispatch({type:'wife-view-mode/finish-night',sleep:true}); unhook();
    const paused=dev.store.game(); window.WifeViewMode_seedTest();
    return { reaches2, paused:paused.slot===1516 && paused.pendingEvent?.text==='수금 확인' && paused.phase!=='prep' };
  `);
  await check('event raised on the closing minute survives automatic settlement', `
    const dev=WML.dev(); window.WifeViewMode_nightTest();
    dev.store.update(state=>({...state,slot:1559}));
    const unhook=dev.hook('minuteTick',{after:result=>({...result,pendingEvent:{type:'alert',text:'월세 확인',choices:[{id:'pay',label:'지불하기'}]}})});
    dev.store.dispatch({type:'wife-view-mode/finish-night',sleep:true}); unhook();
    const state=dev.store.game(); window.WifeViewMode_seedTest();
    return { atClosing:state.slot===1560, eventKept:state.pendingEvent?.text==='월세 확인', notSlept:state.phase==='closed' };
  `);
  await check('husband service AI returns from kitchen before serving', `
    const dev=WML.dev(); window.WifeViewMode_resetTest();
    dev.store.update(state=>({...state,mods:{...state.mods,'wife-view-mode':{...state.mods['wife-view-mode'],husbandServiceMode:'auto'}}}));
    dev.store.dispatch({type:'wait',minutes:1});
    return { returned:dev.fn('playerLocation')(dev.store.game())==='taproom',
      noWrongRoomLog:!dev.store.game().log.some(l=>l.text==='당신은 홀에 없습니다.') };
  `);
  await check('offline pack fallback reuses an image without generation', `
    const dev=WML.dev(); window.WifeViewMode_resetTest(); globalThis.__WW_STUDIO_OFFLINE_ONLY__=true;
    const key=dev.fn('u7')(dev.store.game()).replace(/__v-\\d+$/,'__v-999');
    const expected=await dev.fn('Yp')(key,{nearest:true});
    const result=await dev.fn('imageGenerate')({imageKey:key,prompt:''});
    return { available:!!expected, cached:result?.fresh===false, matched:result?.url===dev.fn('ck')(expected) };
  `);
  await check('sleeping or zero-energy scene cannot strand all controls', `
    const dev=WML.dev(); window.WifeViewMode_resetTest(); const id=window.WifeViewMode_customerTest;
    dev.store.update(state=>({...state,customers:state.customers.map(c=>({...c,status:'drinking'}))}));
    dev.store.update(state=>dev.fn('startPatronInteraction')(state,id));
    dev.store.update(state=>dev.fn('updateWife')(state,wife=>({...wife,currentTask:'sleeping',stats:{...wife.stats,energy:0}})));
    await new Promise(resolve=>setTimeout(resolve,100));
    const state=dev.store.game();
    return { sceneCleared:!state.activeScene?.patron, energyNotCheated:dev.fn('wife')(state).stats.energy===0,
      recoveryControls:!!document.querySelector('[data-wvm-header]'), cleaned:!state.pendingEvent,
      reasonShown:state.log.some(l=>l.text.includes('현재 상태로 진행할 수 없어')) };
  `);
  if (save) await check('attached day-5 save still advances without runtime errors', `
    const dev=WML.dev(); dev.store.update(()=>structuredClone(${JSON.stringify(save)}));
    const before=dev.store.game().slot; dev.store.dispatch({type:'wait',minutes:1});
    return { advanced:dev.store.game().slot>before, notGameOver:!dev.store.game().gameOver };
  `);
  const status=await playStatus({id:session});
  assert.deepEqual(status.failed,[]); assert.deepEqual(status.pageErrors,[]); assert.deepEqual(status.warnings,[]);
  console.log(JSON.stringify({ok:true,shop:true,night:true,recovery:true}));
} finally { await playStop({id:session}); }
