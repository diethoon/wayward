// 호환성 패치 기준: brothel 3.10.0 / pregnancy 3.3.1 / brothel-pregnancy 2.1.0 (개정 기준, 버전 번호에 따른 실행 제한 없음)
WML.define({
  tags: ["content"],
  id: 'brothel-compatible-pregnancy',
  author: "Hina_Lover",
  name: '창관 + Pregnancy 자궁 상태',
  version: "1.1.2",
  game: "2026-11-01",
  lang: 'ko',
  description: '직원별 임신 정보·Pregnancy 자궁 상태 이미지를 각 직원 상세보기 안에 표시합니다.',
  requires: ['brothel', 'pregnancy', 'brothel-pregnancy'],
  /* requiresVersion: { brothel: '>=3.10.0', pregnancy: '>=3.2.0', 'brothel-pregnancy': '>=2.1.0' }, */
  loadAfter: ['brothel', 'pregnancy', 'brothel-pregnancy'],
  conflicts: [],
  setup(api) {
    const brothel = globalThis.__waywardBrothelPublic;
    const pregnancy = globalThis.__wc2PregnancyBirth265;
    const bridge = globalThis.__waywardBrothelPregnancy;
    if (!brothel || !pregnancy?.getPregnancyStage || !bridge?.renderSettings) throw Error('창관·Pregnancy·기존 창관 임신 연동을 먼저 불러와야 합니다.');
    function BrothelPregnancyVisual_상태읽기(state, workerId) {
      const worker = brothel.getConfig()?.workers?.find(item => item.id === workerId && item.enabled);
      if (!worker || !state || !pregnancy.getOptions().enabled) return null;
      const record = state.waywardBrothelPregnancyV1?.workers?.[workerId] || {};
      const day = Number(record.pausedAtDay ?? state.day) || 1;
      const deposits = (record.spermDeposits || []).filter(item => day >= item.day && day - item.day <= 2);
      const amount = deposits.reduce((sum, item) => sum + Math.max(0, Number(item.amount) || 0), 0);
      const tier = amount <= 0 ? 0 : Math.min(5, Math.ceil(amount / 75));
      const field = ['000', '075', '150', '225', '300', '300'][tier];
      const owners = new Map();
      for (const item of deposits) {
        const key = item.fatherId ?? item.fatherName;
        owners.set(key, { name: item.fatherName || '불명', amount: (owners.get(key)?.amount || 0) + Math.max(0, Number(item.amount) || 0) });
      }
      const common = { workerId, ovumOwner: worker.name, amount, tier, spermOwners: [...owners.values()].sort((first, second) => second.amount - first.amount).map(item => item.name) };
      const stage = pregnancy.getPregnancyStage(day, record);
      if (stage) {
        const files = { fertilization: `two-cell-with-sperm-field-${field}.png`, early: `thirty-cell-with-sperm-field-${field}.png`, middle: 'development-4-embryo-uterine-lining.png', late: 'development-5-fetus-uterine-lining.png', birth: 'development-5-fetus-uterine-lining.png' };
        return { ...common, kind: 'pregnancy', stage: stage.id, label: stage.label, file: files[stage.id], detail: `수정 후 ${stage.age}일 · 단계 ${stage.dayInStage}/${stage.duration}일` };
      }
      const cycle = pregnancy.getCycleInfo(day, record);
      return { ...common, kind: 'cycle', stage: cycle.id, label: cycle.label,
        file: cycle.id === 'ovulation' ? tier ? `ovum-surrounded-level-${tier}.png` : 'ovum-unfertilized-count-000.png' : `sperm-only-level-${Math.min(5, tier + 1)}-count-${field}.png`,
        detail: `주기 ${cycle.cycleDay}/${cycle.length}일차 · 정자량 ${amount}백만 마리 · ${tier}/5단계` };
    }
    function BrothelPregnancyVisual_요소만들기(tag, text) {
      const element = document.createElement(tag);
      if (text != null) element.textContent = text;
      return element;
    }
    function BrothelPregnancyVisual_그림그리기(host, visual) {
      const figure = BrothelPregnancyVisual_요소만들기('figure');
      figure.dataset.brothelPregnancyVisual = visual.workerId;
      const owner = BrothelPregnancyVisual_요소만들기('strong', visual.ovumOwner);
      const image = BrothelPregnancyVisual_요소만들기('img');
      image.width = 400; image.height = 400; image.alt = `${visual.ovumOwner} · ${visual.label}`;
      image.addEventListener('error', () => { image.hidden = true; figure.append(BrothelPregnancyVisual_요소만들기('p', '자궁 상태 이미지를 불러오지 못했습니다. 호환 모드의 assets 폴더를 확인하세요.')); }, { once: true });
      image.src = api.fileUrl(`assets/${visual.file}`);
      const caption = BrothelPregnancyVisual_요소만들기('figcaption');
      caption.append(BrothelPregnancyVisual_요소만들기('strong', visual.label), BrothelPregnancyVisual_요소만들기('span', visual.detail));
      if (visual.spermOwners.length) caption.append(BrothelPregnancyVisual_요소만들기('span', `기록된 잔류 성분의 출처: ${visual.spermOwners.join(', ')}`));
      figure.append(owner, image, caption); host.append(figure);
    }
    function BrothelPregnancyVisual_직원그리기(host, state, workerId) {
      const visual = BrothelPregnancyVisual_상태읽기(state, workerId);
      if (!visual) { host.append(BrothelPregnancyVisual_요소만들기('p', '임신 모드가 꺼져 있습니다. 기존 임신 자료는 유지합니다.')); return; }
      BrothelPregnancyVisual_그림그리기(host, visual);
    }
    const originalRender = bridge.renderSettings;
    function BrothelPregnancyVisual_직원안내읽기(state, config) {
      const original = originalRender.call(bridge, state, config);
      const rows = [...(original.querySelector('.ww-pregnancy-workers')?.children || [])];
      const workers = config.workers.filter(item => item.enabled);
      return new Map(workers.map((worker, index) => [worker.id, rows[index]?.textContent || '아직 임신 기록이 없습니다.']));
    }
    bridge.renderSettings = function(state, config) {
      const section = originalRender.call(this, state, config);
      section.querySelector('.ww-pregnancy-workers')?.remove();
      const hint = BrothelPregnancyVisual_요소만들기('p', '직원별 임신 정보와 자궁 상태 이미지는 각 직원의 상세보기에서 확인합니다. 아래는 전체 임신·출산 기록입니다.');
      hint.className = 'ww-help'; section.querySelector('h3')?.after(hint);
      return section;
    };
    let scheduled = false;
    function BrothelPregnancyVisual_화면갱신하기() {
      scheduled = false;
      const settings = document.querySelector('#ww-settings');
      if (!settings || settings.hidden) return;
      const state = api.store.game();
      const texts = BrothelPregnancyVisual_직원안내읽기(state, brothel.getConfig());
      for (const select of settings.querySelectorAll('[data-brothel-portrait]')) {
        const content = select.closest('.ww-editor-content'), workerId = select.dataset.brothelPortrait;
        if (!content) continue;
        const stamp = JSON.stringify([BrothelPregnancyVisual_상태읽기(state, workerId), texts.get(workerId)]);
        let host = content.querySelector('[data-brothel-pregnancy-status]');
        if (!host) { host = BrothelPregnancyVisual_요소만들기('section'); host.dataset.brothelPregnancyStatus = workerId; content.append(host); }
        if (host.dataset.state === stamp) continue;
        host.dataset.state = stamp; host.replaceChildren();
        host.append(BrothelPregnancyVisual_요소만들기('h4', 'Pregnancy · 자궁 상태'));
        const information = BrothelPregnancyVisual_요소만들기('p', texts.get(workerId));
        information.dataset.brothelPregnancyInformation = workerId; host.append(information);
        BrothelPregnancyVisual_직원그리기(host, state, workerId);
      }
    }
    function BrothelPregnancyVisual_갱신예약하기() {
      if (!scheduled) { scheduled = true; queueMicrotask(BrothelPregnancyVisual_화면갱신하기); }
    }
    const style = BrothelPregnancyVisual_요소만들기('style');
    style.textContent = '.brothel-pregnancy-visual-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(230px,100%),1fr));gap:10px}[data-brothel-pregnancy-visual]{margin:8px 0;border:1px solid #57534e;border-radius:8px;padding:8px;min-width:0;overflow-wrap:anywhere}[data-brothel-pregnancy-visual]>strong{display:block}[data-brothel-pregnancy-visual] img{display:block;width:100%;max-width:400px;height:auto;object-fit:contain;margin:auto}[data-brothel-pregnancy-visual] figcaption>*{display:block;font-size:12px;margin-top:4px}';
    document.head.append(style);
    const observer = new MutationObserver(BrothelPregnancyVisual_갱신예약하기);
    observer.observe(document.body, { childList: true, subtree: true });
    window.addEventListener('pagehide', () => observer.disconnect(), { once: true });
    api.store.subscribe(BrothelPregnancyVisual_갱신예약하기);
    globalThis.__waywardBrothelPregnancyVisual = { getVisualState: BrothelPregnancyVisual_상태읽기 };
    brothel.refreshSettings(); BrothelPregnancyVisual_갱신예약하기();
  }
});
