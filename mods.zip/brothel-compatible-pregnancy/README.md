<!-- STABLE_PORT -->
## 2026-11-01 정식판 이식

모드 버전 **1.1.2**, 대상 게임 **2026-11-01**, WML **0.9.5**입니다. MCP 0.6.2로 연결을 검사합니다. 새 게임을 기준으로 하며 pre7 및 기존 저장 이전은 지원 범위에 포함하지 않습니다.

배포 파일: `brothel-compatible-pregnancy-1.1.2-20261101.zip`. 압축의 폴더 이름과 설치 ID는 `brothel-compatible-pregnancy`이며 `wml/mods/brothel-compatible-pregnancy/mod.js`로 설치합니다. WML 모드 관리자에서 ZIP 설치도 가능합니다. 아래의 pre7 버전·ZIP 안내는 이전 변경 기록입니다.
<!-- /STABLE_PORT -->

> **호환성 패치 기준:** brothel 3.10.0 / pregnancy 3.3.1 / brothel-pregnancy 2.1.0
> 이번 개정의 기준 버전입니다. 버전 번호로 실행을 차단하지 않으며, 필수 모드와 실제 연결 기능은 필요합니다. 최신 구성에 맞춰 유지합니다.

# 창관 + Pregnancy 자궁 상태 1.1.1

## [pre7 배포 · 버전 분리]

현재 모드 버전: 1.1.1. 대상 게임: 2026-10-24-pre7. 이전 모드 버전: 1.1.0-pre7.1.
배포 파일: brothel-compatible-pregnancy-1.1.1-pre7.zip
압축 내부 최상위 폴더와 로딩 ID는 항상 `brothel-compatible-pregnancy`이며 버전·pre 표기를 붙이지 않습니다. 폴더 복사 설치 경로는 `wml/mods/brothel-compatible-pregnancy/mod.js`입니다. ZIP 설치는 WML 모드 관리자를 사용하세요. 모드의 version은 숫자 버전, game은 대상 게임 식별자로 분리했습니다. 업데이트 인식을 위해 모드 버전의 마지막 숫자를 올렸으며 게임 동작은 이번 변경에서 수정하지 않았습니다. 이전 ZIP과 과거 변경 기록은 보존합니다.


## 1.1.0-pre7.1 · 직원별 상세보기로 이동 (2026-10-29)

위쪽 매춘부 임신 / 출산에 모였던 **직원별 상태 문구·직원별 이미지**를 각 직원 상세보기 → Pregnancy · 자궁 상태로 모았습니다. 전체 설정 안내와 전체 임신·출산 Log는 위쪽에 유지합니다. 같은 직원의 그림을 위·아래에 중복 표시하지 않습니다.

직원별 상태 문구는 기존 brothel-pregnancy의 원래 렌더 결과에서 가져오며, 계산·설정·주기·수정·출산·친부 추정·기록은 바꾸지 않습니다. 기존 이미지 자산과 API를 그대로 사용하고 OFF에서는 그림을 숨기고 원래 자료를 보존합니다. H_Status 호환을 끈 구성에서도 사용할 수 있습니다.

배포: brothel-compatible-pregnancy-1.1.0-pre7.1.zip. 이 모드만 교체하고 새로고침합니다. 아래 1.0.x의 위·아래 동시 이미지 설명은 이전 버전의 배치입니다.

현행 통합 검사: node --import ./wml/mods/companions/tests/runtime.mjs wml/mods/secert-club-compatible-companions/tests/integration.mjs (--mobile / --zip). 실제 사용자 저장·실기 모바일·장기 플레이는 이번 검증 범위에 포함하지 않습니다.


필수: `brothel` 3.10.0 이상, `pregnancy` 3.2.0 이상, **기존 `brothel-pregnancy` 2.1.0 이상** 및 각 모드의 필수 의존성. 이 모드는 기존 창관 임신 연동을 대체하지 않는 시각화 확장입니다. 기존 연동도 켜 두세요. 원본 모드 파일과 공통 `mods.js`는 수정하지 않습니다.

창관 설정의 **매춘부 임신 / 출산**과 **직원 상세보기 → Pregnancy · 자궁 상태**에 직원별 이미지를 추가합니다. Pregnancy의 기존 임상 도식 자산을 이 폴더의 `assets/`에 포함하므로 이 모드 폴더만 배포하면 됩니다. 이미지 생성 서버가 필요 없고 이미지를 자동 생성하지 않습니다. WML ZIP 설치와 폴더 설치를 모두 지원합니다.

기존 `state.waywardBrothelPregnancyV1.workers[workerId]`의 주기·정자량·수정일·정지일과 실제 직원 이름을 사용합니다. Pregnancy의 주기/임신 단계 API와 이미지 선택 규칙을 적용합니다. 정자량은 75백만 단위로 시각화하며 난자·2세포·착상·배아·태아 그림을 전환합니다. 실제 친부나 아내의 데이터를 직원에게 복사하지 않습니다. 잔류 성분의 출처는 해당 직원의 기존 업무 기록에서만 표시합니다.

OFF일 때 그림을 숨기고 자료는 보존합니다. 임신·출산 판정과 기간·체력 소모·친부 추정·출산 후 사건은 **기존 brothel-pregnancy**가 담당하며 이 모드는 해당 계산을 바꾸지 않습니다. 따라서 기존 연동의 출산 일정이 Pregnancy 본체의 새 기간 설정과 다를 수 있으며, 이를 이번 시각화 작업에서 변경하지 않습니다.

공개 API: `__waywardBrothelPregnancyVisual.getVisualState(state, workerId)`. 고용되지 않은 직원 또는 Pregnancy OFF일 때 `null`입니다. 실제 친부 정보는 반환하지 않습니다.

배포 ZIP을 WML 모드 관리자에 설치하고 필수 모드와 함께 켠 뒤 새로고침합니다. 폴더 설치는 `wml/mods/brothel-compatible-pregnancy/`에 풉니다.

수정 원본: `source/mod.wml.js`. 생성: `node wml/mods/brothel-compatible-pregnancy/source/build.mjs`. 배포: `powershell -NoProfile -ExecutionPolicy Bypass -File wml/mods/brothel-compatible-pregnancy/source/package.ps1`.

통합 검증은 함께 배포하는 `brothel-compatible-h-status/tests/regression.mjs`에서 수행합니다. 단계별 그림·주기·정자량·정지일·출처·친부 비공개, 실제 이미지 로딩과 ZIP 내부 이미지, OFF 자료 보존, 저장·새로고침·해고·재고용을 검사합니다. `--mobile --zip`으로 모바일 ZIP 설치도 확인합니다.


## 2026-10-24-pre7 이식

- 배포 버전: `1.0.2-pre7.1` · WML 0.9.4 · 구 게임용 배포와 구분합니다.
- 원제작자·원문 출처 표기는 기존 머리말과 문서에 보존했습니다. 이 배포의 호환 수정: HL 작업본.
- 모드 내부 ID와 폴더 이름을 `brothel-compatible-pregnancy`로 통일했습니다. 이 폴더만 덮어쓸 수 있는 개별 ZIP을 함께 제공합니다.
- 구 게임의 압축 함수 이름과 탐색 규칙을 pre7에 맞췄습니다. 변경·검증의 전체 범위와 한계는 작업 폴더 `version_up_ready/PORT_RESULT.md`를 참고하세요.


## 1.0.2-pre7.2 · 2026-10-27 MCP 후속 보완

- MCP 0.6.1 기준의 고정 태그를 모드 자체에 선언했습니다. 제작자/원문 출처 및 기존 pack은 보존합니다.
