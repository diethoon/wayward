// Companions + Pregnancy compatibility by Hina_Lover.
// Uses Pregnancy's original engine and the biological provider by 냥메이드 / galdcup (HL edition).
WML.define({
  id:'companions-compatible-pregnancy',name:'동료 + Pregnancy·생물학적 고증',author:'Hina_Lover',
  version:"1.1.0",game:"2026-11-01",lang:'ko',tags:['content'],
  description:'동료별 주기·임신·출산·상태 그림·경비병과 성장의 비약을 연결합니다.',
  requires:['companions','pregnancy'],requiresVersion:{companions:'>=2.9.0',pregnancy:'>=3.6.0'},
  loadAfter:['pregnancy_biological_realism','secert-club-compatible-companions'],
  setup(api){
    const ID=api.id,people=api.use('companions'),parent=globalThis.__wc2PregnancyBirth265,engine=parent?.actorApi;
    if(engine?.version!==1||!people.registerNativeResult)throw Error('Companions와 Pregnancy를 최신 버전으로 갱신해 주세요.');
    const KEY=engine.stateKey,copy=x=>x==null?x:structuredClone(x),same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
    const read=s=>s?.mods?.[ID]||{records:{}},record=(s,id)=>read(s).records?.[id]||{};
    const bio=()=>globalThis.__pregnancyBiologicalRealism?.actorApi;
    if(globalThis.__pregnancyBiologicalRealism&&!bio())throw Error('생물학적 고증을 1.2.0 이상으로 갱신해 주세요.');
    const eligible=p=>p&&p.active!==false&&p.gender==='female'&&!p.clubGuest;
    let writing=false,previous=null;
    function saveRecord(s,id,row){if(same(record(s,id),row))return s;const data=read(s);return{...s,mods:{...s.mods,[ID]:{...data,records:{...data.records,[id]:row}}}};}
    function raw(s,p){return p.main?s[KEY]:record(s,p.id).data;}
    people.registerNativeProjection(ID,(projected,{state,person})=>eligible(person)?{...projected,[KEY]:raw(state,person)}:projected);
    function view(s,p){
      const v=people.nativeView(s,p.id),locations=Object.fromEntries(Object.entries(s.locations).map(([id,r])=>[id,{...r,occupants:(r.occupants||[]).filter(id=>id!=='wife')}])) ;
      locations[p.room]={...locations[p.room],occupants:[...(locations[p.room]?.occupants||[]),'wife']};
      const records=[...(s.patronRecords||[])];for(const [id,bond]of Object.entries(p.bonds||{}))if(id!=='player'){
        const partner=people.actor(s,id);if(partner)records.push({id,name:partner.name,romantic:bond.heart||0});
      }
      return{...v,locations,patronRecords:records,[KEY]:raw(s,p),pendingEvent:s.pendingEvent,alertQueue:s.alertQueue||[],activeScene:s.activeScene,
        errandSession:s.errandSession,activeShoppingSession:s.activeShoppingSession,
        mods:{...s.mods,...(bio()?{[bio().modId]:record(s,p.id).bio||{}}:{})}};
    }
    function targetAlert(alert,p){
      const result={...copy(alert),companionsMotherId:p.id};
      if(result.childDisposition){result.kind='companions_pregnancy_child';result.childDisposition={...result.childDisposition,source:ID,workerId:p.id};}
      if(result.kind===bio()?.modId+':guard-visit')result.kind='companions_pregnancy_guard';
      return result;
    }
    function queue(s,alerts,p){const known=new Set([s.pendingEvent?.alert?.id,...(s.alertQueue||[]).map(a=>a.id)]);const added=[];
      for(const alert of alerts||[])if(!known.has(alert.id)){known.add(alert.id);added.push(targetAlert(alert,p));}
      return added.length?{...s,alertQueue:[...(s.alertQueue||[]),...added]}:s;
    }
    function apply(s,p,out,scoped){
      let next=s;
      if(p.main){if(!same(next[KEY],out.data))next={...next,[KEY]:out.data};}
      else next=saveRecord(next,p.id,{...record(next,p.id),data:out.data});
      const before=scoped.characters[scoped.primaryCharacterId],changed=out.character;
      if(changed&&!same(before,changed)){
        const latest=people.actor(next,p.id),character={...latest.character};
        for(const key of Object.keys(changed))if(!same(before[key],changed[key]))character[key]=copy(changed[key]);
        next=people.saveActor(next,{...latest,character,energy:character.stats.energy,mood:character.stats.mood,
          ...(!p.main?{relationship:{...latest.relationship,trust:character.relationship?.trust??latest.relationship.trust}}:{})});
        if(!p.main&&before.relationship?.trust!==changed.relationship?.trust)next=people.setBond(next,p.id,'player',{...people.bond(next,p.id,'player'),trust:character.relationship.trust,resentment:character.relationship.resentment});
      }
      if(out.gold)next={...next,economy:{...next.economy,gold:next.economy.gold+out.gold}};
      if(out.log?.length)next={...next,log:[...next.log,...out.log.map(row=>({...row,companionsId:p.id}))]};
      return queue(next,out.alerts,p);
    }
    function applyBio(s,p,scoped,result){
      if(result===scoped)return s;
      let next=saveRecord(s,p.id,{...record(s,p.id),data:result[KEY],bio:result.mods?.[bio().modId]||{}});
      const gold=(result.economy?.gold||0)-(scoped.economy?.gold||0);if(gold)next={...next,economy:{...next.economy,gold:next.economy.gold+gold}};
      const log=result.log?.slice(scoped.log.length)||[];if(log.length)next={...next,log:[...next.log,...log.map(row=>({...row,companionsId:p.id}))]};
      const known=new Set((scoped.alertQueue||[]).map(a=>a.id));
      const alerts=(result.alertQueue||[]).filter(a=>!known.has(a.id));
      if(result.pendingEvent?.alert&&result.pendingEvent.alert.id!==scoped.pendingEvent?.alert?.id)alerts.push(result.pendingEvent.alert);
      return queue(next,alerts,p);
    }
    people.registerNativeResult(ID,(s,event)=>{
      const p=people.actor(s,event.id);if(!eligible(p))return s;
      const partner=event.other==='player'?null:people.actor(s,event.other);
      if(partner&&partner.gender!=='male')return s;
      const prior=raw(s,p),context={partnerId:event.other,partnerName:partner?.name||'당신',
        motherKnows:engine.isAware(event.before),
        playerKnows:event.other==='player'||api.fn('playerLocation')(event.sourceState)===p.room};
      // A cycle-medicine action may have already returned an explicitly updated actor record.
      const data=!same(event.before[KEY],event.after[KEY])?event.after[KEY]:prior;
      const out=engine.capture(event.before,event.after,data,context);
      return apply(s,p,out,event.after);
    });
    function process(s,prior=previous){
      if(!s||s.gameOver||s.pmCore)return s;
      let next=s;
      // A removed actor's unfinished purchase is refunded once; retained histories are never deleted.
      for(const [id,row]of Object.entries(read(next).records||{}))if(row.bio?.trip&&!eligible(people.get(next,id))){
        next={...next,economy:{...next.economy,gold:next.economy.gold+row.bio.trip.cost}};next=saveRecord(next,id,{...row,bio:{...row.bio,trip:null}});
      }
      for(const initial of people.list(next).filter(eligible)){
        let p=people.get(next,initial.id),scoped=view(next,p),priorActor=prior&&people.get(prior,p.id),oldView=eligible(priorActor)?view(prior,priorActor):null;
        const personalScenes={...p.nativeSession?.scenes};
        next=apply(next,p,engine.advance({...scoped,activeScene:personalScenes},record(next,p.id).data,oldView),scoped);
        if(bio()){
          p=people.get(next,p.id);scoped=view(next,p);
          // Existing personal scenes prevent a new guard event, but pending purchases can still finish/refund.
          const result=p.nativeSession||p.interaction?bio().finish(scoped):bio().process(scoped);
          next=applyBio(next,p,scoped,result);
        }
      }
      if(!next.pendingEvent&&!next.errandSession&&!next.activeShoppingSession&&!Object.values(next.activeScene||{}).some(Boolean)&&next.alertQueue?.length)next=api.fn('drainAlerts')(next);
      return next;
    }
    function refresh(){if(writing||!api.store.get()?.started)return;const s=api.store.game();writing=true;
      try{const next=process(s,previous);if(next!==s)api.store.update(current=>current===s?next:current);}finally{previous=api.store.game();writing=false;}}
    api.store.subscribe(refresh);engine.subscribeOptions(refresh);
    function treatmentReason(s,p){return !eligible(p)?'대상 여성 동료가 없습니다.':people.blocked(s)||
      (p.site!==people.context(s).active||p.room!==api.fn('playerLocation')(s)?'같은 장소에서 선택해 주세요.':
        p.life?.pending||p.nativeSession||p.interaction?'진행 중인 업무·만남이 끝난 뒤 선택해 주세요.':'');}
    api.actions.register(ID+'/medicine',(s,a)=>{const p=people.get(s,a.id),reason=treatmentReason(s,p);if(reason)return people.log(s,reason,a.id);
      const data=engine.medicine(record(s,p.id).data,s,a.phase);return data?people.log(saveRecord(s,p.id,{...record(s,p.id),data}),p.name+'에게 주기 변경 약을 주었습니다. 다음 날 적용됩니다.',p.id):s;});
    api.actions.register(ID+'/elixir',(s,a)=>{const p=people.get(s,a.id),reason=treatmentReason(s,p);if(reason||!bio())return people.log(s,reason||'생물학적 고증을 켜 주세요.',a.id);
      if(s.mods?.[bio().modId]?.trip||Object.values(read(s).records||{}).some(r=>r.bio?.trip))return people.log(s,'이미 비약 구매가 진행 중입니다.',a.id);
      const scoped=view(s,p);return applyBio(s,p,scoped,bio().begin(scoped));});
    function buyElixir(id){api.store.dispatch({type:ID+'/elixir',id});const trip=record(api.store.game(),id).bio?.trip;if(!trip)return false;
      api.store.dispatch({type:'wait',minutes:Math.max(0,trip.endSlot-api.store.game().slot)});
      api.store.update(s=>{const p=people.get(s,id);if(!p||!bio())return s;const scoped=view(s,p);return applyBio(s,p,scoped,bio().finish(scoped,true));});return true;}
    api.hook('reduceGameAction',{priority:120000,around(next,s,action){
      const alert=s.pendingEvent?.alert,id=alert?.companionsMotherId;
      if(action?.type!=='resolve_event'||!id||!['companions_pregnancy_guard','companions_pregnancy_child'].includes(alert.kind))return next(s,action);
      const choice=(s.pendingEvent.choices||alert.choices||[]).find(c=>c.id===action.choiceId&&!c.disabled);if(!choice)return s;
      const p=people.get(s,id),base=next(s,action);if(!eligible(p))return base;
      const scoped=view(s,p);
      if(alert.kind==='companions_pregnancy_guard')return bio()?applyBio(base,p,scoped,bio().resolveGuard(scoped,action.choiceId)):base;
      if(alert.childDisposition?.phase!=='question')return base;
      const out=engine.resolveChild(scoped,record(s,id).data,alert.childDisposition.recordId,action.choiceId);return out?apply(base,p,out,scoped):base;
    }});
    function render(host,s,p){if(!eligible(p))return;const section=document.createElement('section');section.className='companions-pregnancy';section.dataset.companionsPregnancy=p.id;
      const title=document.createElement('h4');title.textContent='Pregnancy · 신체 상태';section.append(title);
      if(!parent.getOptions().enabled){const note=document.createElement('p');note.textContent='Pregnancy OFF · 기록을 보존하고 진행을 멈춥니다.';section.append(note);host.append(section);return;}
      const scoped=view(s,p),data=engine.normalize(record(s,p.id).data,s.day,scoped),visual=engine.visual(scoped,data);engine.renderVisual(section,visual,'companion');
      const note=document.createElement('p');note.textContent=`질/항문 사정 누계 ${data.ejaculationCounts.vaginal}/${data.ejaculationCounts.anal}회`;
      if(data.pregnancy){const father=parent.getFatherDisplay(data.pregnancy);note.textContent+=` · 아이 ${data.pregnancy.childCount}명 · 친부 추정 — 본인: ${father.wife} / 당신: ${father.husband}${father.actual?' · 실제 친부: '+father.actual:''}`;}
      if(data.pendingCycleMedicine)note.textContent+=` · 주기 약 예약 ${data.pendingCycleMedicine.startDay}일차`;section.append(note);
      const reason=treatmentReason(s,p);for(const [phase,label]of [['follicular','난포기'],['ovulation','배란기'],['luteal','황체기']]){const b=document.createElement('button');b.type='button';b.textContent=label+' 약';b.disabled=!!reason||!!data.pregnancy;b.title=reason;b.onclick=()=>api.store.dispatch({type:ID+'/medicine',id:p.id,phase});section.append(b);}
      if(bio()){const button=document.createElement('button');button.type='button';button.textContent='성장의 비약 사용';button.dataset.companionsElixir=p.id;const blocked=reason||bio().canBuy(scoped);button.disabled=!!blocked;button.title=blocked;button.onclick=()=>buyElixir(p.id);section.append(button);const help=document.createElement('p');help.textContent=blocked||`비약 ${engine.ruleOptions().elixirCost}g · ${engine.ruleOptions().elixirMinutes}분`;section.append(help);}
      const log=document.createElement('details'),summary=document.createElement('summary');summary.textContent='임신·출산 기록 '+data.birthLog.length+'건';log.append(summary);
      for(const entry of [...data.birthLog].reverse()){const row=document.createElement('p'),father=parent.getFatherDisplay(entry);row.textContent=`${entry.day}일 · 출산 ${entry.children.length}명 · 본인 추정 ${father.wife} / 당신 추정 ${father.husband}${father.actual?' · 실제 친부 '+father.actual:''}${parent.getChildDispositionHistoryText(entry.childDisposition)}`;log.append(row);}section.append(log);host.append(section);
    }
    const style=document.createElement('style');style.textContent='.companions-pregnancy{border:1px solid #57534e;border-radius:8px;padding:10px;margin-top:12px}.companions-pregnancy .wc2pb-visual{margin:0}.companions-pregnancy .wc2pb-visual-image{position:relative;width:100%;max-width:300px;aspect-ratio:1}.companions-pregnancy .wc2pb-visual-image img{position:absolute;inset:0;width:100%;height:100%;object-fit:contain}.companions-pregnancy button{margin:4px;padding:4px 8px}.companions-pregnancy p{white-space:pre-line;overflow-wrap:anywhere}.companions-pregnancy details{max-height:250px;overflow:auto}';document.head.append(style);
    people.registerProfileSection(ID,render);
    api.provide({read,record,process,view,buyElixir,render});refresh();
  }
});
