const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const React = require("react");
const ReactDOM = require("react-dom");
const ReactDOMClient = require("react-dom/client");
const { JSDOM } = require("jsdom");
const { act } = require("react-dom/test-utils");

const modPath = path.join(__dirname, "..", "mobile-ui-migration", "mod.js");
const modSource = fs.readFileSync(modPath, "utf8");

const dom = new JSDOM(
  "<!doctype html><html><head></head><body><div id='root'></div></body></html>",
  { url: "https://wayward.test/", pretendToBeVisual: true }
);

global.window = dom.window;
global.document = dom.window.document;
global.MutationObserver = dom.window.MutationObserver;
global.HTMLElement = dom.window.HTMLElement;
global.Event = dom.window.Event;
Object.defineProperty(global, "navigator", {
  configurable: true,
  value: dom.window.navigator
});
window.matchMedia = (query) => ({
  media: query,
  matches: query.includes("orientation: portrait") && query.includes("1023px"),
  addEventListener() {},
  removeEventListener() {},
  addListener() {},
  removeListener() {}
});

let definition;
global.WML = {
  define(value) {
    definition = value;
  }
};
vm.runInThisContext(modSource, { filename: modPath });
assert.ok(definition, "WML.define should receive the module definition");

const hooks = new Map();
const dispatched = [];
const api = {
  game: "2026-11-01",
  host: { platform: "mobile" },
  fn(name) {
    if (name === "React") return React;
    if (name === "ReactDOM") return ReactDOM;
    throw new Error(`Unexpected api.fn(${name})`);
  },
  hook(name, definition) {
    hooks.set(name, definition);
    return () => {};
  },
  has() {
    return true;
  }
};

definition.setup(api);
assert.ok(hooks.has("layout"), "layout hook registered");
assert.ok(hooks.has("prepPanel"), "prep-panel hook registered");
assert.ok(hooks.has("facilityAccordion"), "facility accordion hook registered");

function renderFacilityAccordion(props) {
  return React.createElement(
    "div",
    { className: "mb-3 rounded-lg border border-stone-700 bg-stone-800/50" },
    React.createElement("button", { type: "button" }, props.title),
    React.createElement(
      "div",
      { className: "px-3 pb-3" },
      props.children
    )
  );
}
function yst(props) {
  return hooks.get("facilityAccordion").around(renderFacilityAccordion, props);
}

function renderPrepPanel() {
  const [skippedSupplies] = React.useState(["wine"]);
  const dispatch = (action) => dispatched.push(action);
  return React.createElement(
    "div",
    null,
    React.createElement("h2", null, "오후 영업 준비"),
    React.createElement(
      "div",
      {
        className:
          "p-3 bg-rose-950/25 rounded-lg border border-rose-800/60 mb-4"
      },
      React.createElement("h3", null, "대출 — 80골드 남음"),
      React.createElement(
        "button",
        { onClick: () => dispatch({ type: "pay_debt", amount: 30 }) },
        "상환: 30골드"
      )
    ),
    React.createElement(
      "div",
      { className: "mb-4" },
      React.createElement(
        "button",
        {
          onClick: () => dispatch({ type: "stock_up", skip: skippedSupplies })
        },
        "물자 채우기"
      ),
      React.createElement(
        "div",
        { className: "mt-2 rounded-lg border border-stone-700" },
        React.createElement(
          "button",
          {
            onClick: () => dispatch({ type: "set_supply_target", item: "food", value: 5 })
          },
          "목표 수량"
        ),
        React.createElement("input", {
          onChange: () => dispatch({ type: "set_supply_price_limit", item: "food", value: 4 })
        })
      )
    ),
    React.createElement(
      "div",
      { className: "mb-4 px-1" },
      React.createElement("button", null, "엘레나에게 목욕하라고 말하기"),
      React.createElement("button", null, "팁 배분")
    ),
    React.createElement(
      yst,
      { title: "시설 업그레이드", open: true },
      React.createElement(
        "button",
        {
          onClick: () =>
            dispatch({ type: "buy_quality_upgrade", upgradeId: "bathroom" })
        },
        "목욕탕 업그레이드"
      )
    )
  );
}
function wst(props) {
  return hooks.get("prepPanel").around(renderPrepPanel, props);
}
function SB() {
  return React.createElement("button", null, "기본 행동 선택지");
}

// Same wst element is intentionally reused in both responsive story trees,
// matching gat()'s desktop hidden pane + mobile story tab structure.
const storyBody = React.createElement(
  "div",
  { className: "min-w-0" },
  React.createElement(wst, null),
  React.createElement("p", { className: "narration-only" }, "원본 이야기 나레이션")
);
const rawLayout = React.createElement(
  React.Fragment,
  null,
  React.createElement("div", { className: "hidden lg:flex desktop-story-pane" }, storyBody),
  React.createElement(
    "div",
    { className: "lg:hidden flex-1 min-h-0 mobile-layout" },
    React.createElement(
      "div",
      { className: "flex-1 min-h-0 overflow-y-auto p-2 text-[0.78rem] mobile-story-pane" },
      storyBody
    ),
    React.createElement(
      "div",
      { className: "w-[37%] max-w-[13rem] flex flex-col min-h-0" },
      React.createElement(
        "div",
        { className: "flex-1 min-h-0 overflow-y-auto py-1 text-[0.72rem]" },
        React.createElement(SB, null)
      ),
      React.createElement("button", {
        title: "행동 버튼을 반대쪽으로 이동",
        "aria-label": "행동 버튼을 반대쪽으로 이동"
      }, "⇤")
    )
  )
);

const hookedLayout = hooks.get("layout").after(rawLayout);
const root = document.getElementById("root");
const reactRoot = ReactDOMClient.createRoot(root);
act(() => reactRoot.render(hookedLayout));

const prepPanels = root.querySelectorAll(".m36-ui-migration-prep-panel");
assert.equal(prepPanels.length, 1, "prep component must be mounted exactly once");
assert.equal(
  prepPanels[0].querySelectorAll("button").length,
  5,
  "only debt, stock, supply-setting and facility controls should remain"
);
assert.equal(
  root.querySelectorAll(".m36-ui-migration-facility-upgrade").length,
  1,
  "facility accordion should receive its mobile class exactly once"
);
assert.equal(
  root.querySelectorAll(".m36-ui-migration-action-scroll .m36-ui-migration-prep-panel").length,
  1,
  "prep controls should be inside the actual action-choice scroll area"
);
assert.equal(
  root.querySelectorAll(".desktop-story-pane .m36-ui-migration-prep-panel, .mobile-story-pane .m36-ui-migration-prep-panel").length,
  0,
  "story panes must not contain the preparation panel"
);
for (const storyPane of root.querySelectorAll(".desktop-story-pane, .mobile-story-pane")) {
  assert.match(storyPane.textContent, /원본 이야기 나레이션/);
  assert.doesNotMatch(storyPane.textContent, /물자 채우기|시설 업그레이드|상환|목욕하라고/);
}
assert.equal(root.querySelectorAll(".m36-ui-migration-prep-panel button").length, 5);
assert.equal(root.querySelectorAll(".m36-ui-migration-prep-panel input").length, 1);

const stockButton = [...prepPanels[0].querySelectorAll("button")]
  .find((button) => button.textContent.includes("물자 채우기"));
const repayButton = [...prepPanels[0].querySelectorAll("button")]
  .find((button) => button.textContent.includes("상환"));
const upgradeButton = [...prepPanels[0].querySelectorAll("button")]
  .find((button) => button.textContent.includes("목욕탕 업그레이드"));
assert.ok(stockButton && repayButton && upgradeButton);
act(() => stockButton.click());
act(() => repayButton.click());
act(() => upgradeButton.click());
assert.deepEqual(dispatched, [
  { type: "stock_up", skip: ["wine"] },
  { type: "pay_debt", amount: 30 },
  { type: "buy_quality_upgrade", upgradeId: "bathroom" }
], "native handlers and payloads must be preserved verbatim");

const status = window.__M36_MOBILE_UI_MIGRATION__?.getStatus?.();
assert.equal(status?.version, "1.3.14");
assert.equal(status?.prepActionPanel, true);
assert.equal(status?.prepFacilityUpgrade, true);

act(() => window.__M36_MOBILE_UI_MIGRATION__?.stop?.());
act(() => reactRoot.unmount());
dom.window.close();
console.log("PASS: one prep panel moved to action choices; story tabs contain narration only; original dispatch payloads preserved.");
