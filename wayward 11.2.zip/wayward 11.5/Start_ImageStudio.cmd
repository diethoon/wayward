@echo off
setlocal
rem ImageStudio 1.31.20 - game 2026-11-01 - shared server 0.8.4. Only this mod owns the server implementation.
if exist "%~dp0backend\wayward-imagegen\src\cli.ts" (
  set "IMAGE_STUDIO_GAME_DIR=%~dp0..\..\.."
  set "IMAGE_STUDIO_SERVER=%~dp0backend\wayward-imagegen"
) else (
  set "IMAGE_STUDIO_GAME_DIR=%~dp0"
  set "IMAGE_STUDIO_SERVER=%~dp0wml\mods\imagestudio\backend\wayward-imagegen"
)
pushd "%IMAGE_STUDIO_GAME_DIR%"
if errorlevel 1 exit /b 1
rem Also find a standard Bun install before the user has reopened a PATH-updated terminal.
set "IMAGE_STUDIO_BUN="
where bun.exe >nul 2>nul
if not errorlevel 1 set "IMAGE_STUDIO_BUN=bun.exe"
if not defined IMAGE_STUDIO_BUN if exist "%USERPROFILE%\.bun\bin\bun.exe" set "IMAGE_STUDIO_BUN=%USERPROFILE%\.bun\bin\bun.exe"
if not defined IMAGE_STUDIO_BUN if exist "%LOCALAPPDATA%\bun\bin\bun.exe" set "IMAGE_STUDIO_BUN=%LOCALAPPDATA%\bun\bin\bun.exe"
if not defined IMAGE_STUDIO_BUN (
  echo Bun is required. See README.md in the Image Studio mod folder.
  pause
  popd
  exit /b 1
)
set "IMAGE_STUDIO_CONFIG=%IMAGE_STUDIO_SERVER%\wayward-imagegen.config.json"
if exist "%CD%\wayward-imagegen\wayward-imagegen.config.json" set "IMAGE_STUDIO_CONFIG=%CD%\wayward-imagegen\wayward-imagegen.config.json"
"%IMAGE_STUDIO_BUN%" "%IMAGE_STUDIO_SERVER%\src\checkWebp.ts" >nul 2>nul
if errorlevel 1 (
  echo Installing WebP support in the ImageStudio mod folder...
  "%IMAGE_STUDIO_BUN%" install --cwd "%IMAGE_STUDIO_SERVER%" --production --cache-dir "%IMAGE_STUDIO_SERVER%\.bun-cache"
  if errorlevel 1 goto image_studio_failed
  "%IMAGE_STUDIO_BUN%" "%IMAGE_STUDIO_SERVER%\src\checkWebp.ts"
  if errorlevel 1 goto image_studio_failed
)
echo ImageStudio 1.31.20 - game 2026-11-01 - shared server 0.8.4
echo Server: "%IMAGE_STUDIO_SERVER%\src\cli.ts"
echo Config: "%IMAGE_STUDIO_CONFIG%"
"%IMAGE_STUDIO_BUN%" "%IMAGE_STUDIO_SERVER%\src\cli.ts" --config "%IMAGE_STUDIO_CONFIG%" --webp --require-webp %*
popd
pause
endlocal
exit /b

:image_studio_failed
echo WebP setup failed. The image server was not started.
popd
pause
endlocal
exit /b 1
