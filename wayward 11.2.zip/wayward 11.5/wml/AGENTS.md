# AGENTS.md — WML 폴더에서 일하는 AI 에이전트용 안내

이 폴더는 Wayward 게임의 모드 로더(WML)예요. 사용자는 **한국어(해요체)** 설명을 원해요.

## 개발·배포·플레이 위치 (2026-11-01 정식판 기준)
- 정식판 개발 원본: `E:/newwinder/wayward/stable/wayward-game/wml/` (게임 2026-11-01, WML 0.9.5, MCP 0.6.2, 플레이어 1.0.0).
- 배포: `E:/newwinder/wayward/stable/배포_WML0.9.5_stable/` (작업산출물·패키지). `release-paths.json`(개발 전용, 배포 안 함)이 이 자리를 가리켜요.
- pre7 개발 원본: `E:/newwinder/wayward/vanilla/1_작업중/pre-1024/en-wayward-game/`. 정식판 작업 때문에 수정하지 않아요.
- 사용자가 플레이하는 곳: `E:/newwinder/wayward/working`. 파일·설정·실행 중인 프로그램을 건드리지 않고 개발 변경을 자동 동기화하지 않아요.
- 이번 정식판은 `pack-release.mjs --no-mods`로 묶어요. 두 언어 모두 모드 목록은 비우고 기존 모드는 수정·재생성·재배포하지 않아요. pre7 모드 호환 검증과 별개예요.
- 이미지 생성기는 정식판 공식 원본 그대로예요. 사용 중인 이미지 서버의 설정·키·캐시나 실행 상태에는 손대지 않아요.
- APK는 `--player-keys "E:/newwinder/wayward/vanilla/1_작업중/pre-1024/en-wayward-game/player-keys"`로 기존 서명 키를 전달해요. 새 키를 만들지 않아요.
- 포팅 원본(옮기지 않아요, `port/regen.json`이 읽어요): `vanilla/3_모드통째_플레이·시험/옛통합본`, `vanilla/4_받은모드/받은원본`, `vanilla/4_받은모드/옛포팅원본/_extracted`
- pre7에 안 쓰는 옛것(10-04·pre-1018 개발본, 옛 배포물, 옛 플레이·시험 폴더, 옛 모드 모음)은 `E:\newwinder\wayward\old`에 원래 구조 그대로 있어요.
- vanilla 안의 과거 배치: `vanilla/폴더_안내.txt`. 이전 개발 기록의 경로와 현재 stable 개발 위치를 구분해요.

## 먼저 읽을 것
- 모드 만들기: `docs/SDK.md`
- 도구 서버(MCP): `docs/MCP.md`
- 빌드·번역·옛 모드 옮기기: `README.md`

## MCP 도구가 연결돼 있으면
`wml` 서버 도구를 쓰세요. `wml_status` → `docs_read`(작업 순서) 순서로 시작해요.

모드를 만들 때의 흐름:
1. 게임 함수 찾기: `game_find` → `game_source` → `symbols_list` / `symbol_add { mod }` (모드 전용 의미 이름)
2. 모드 작성: `mod_create` → `mod_write_file`
3. 정적 검사: `mod_check`
4. 실제 게임에서 시험: `play_start` → `play_eval` · `play_auto` → `play_stop`

## MCP 없이 일할 때
- 모드는 `mods/<id>/mod.js` 하나, 그리고 `mods/mods.js` 목록에 한 줄을 넣어요.
- 모드만 고쳤으면 빌드할 필요가 없어요. 게임을 새로고침하면 바로 반영돼요.
- 아래를 고쳤을 때만 `node tools/build.mjs --lang ko`로 빌드해요.
  - 번역: `i18n/ko/custom.json`
  - 심볼 표: `symbols/`
- 정적 검사와 브라우저 시험은 MCP 서버로 해요.
  - 따로 받는 배포 파일(`wml-mcp`): `node selftest.mjs --wml <게임 폴더>`
  - 개발 폴더: `npm run mcp:test`

## 지킬 것
- 아래 파일은 손으로 고치지 않아요. 바꾸려면 원본을 고친 뒤 도구로 다시 만들어요.
  - 게임 원본 `../wayward-*.html`
  - 빌드 결과 `../Wayward_WML*.html`
  - 생성 파일: `i18n/ko/display.js`, `symbols/*.js`
- 도구로 포팅한 모드(머리말에 "이 파일은 tools/….mjs 로 만들었어요"라고 적힌 파일)는 손으로 고치지 않고 다시 만들어요.
  - 바꿀 곳은 `port/<id>.fixes.json` / `.prelude.js` / `.post.js`에 두고 `node tools/port-regen.mjs <id>`로 다시 만들어요.
  - 만드는 명령은 `port/regen.json`에 있어요. `node tools/port-regen.mjs --check`는 모든 모드가 기록대로 나오는지 확인해요.
- 게임 상태는 새 객체로 바꿔요(`api.store.update`).
- `mod.js` 맨 바깥(setup 밖)에서는 `WML.define`만 해요. 0.9.1부터 꺼진 모드의 파일은 시작 때 읽지 않고 모드 관리자를 열 때 읽어서, 맨 바깥 코드가 언제 돌지 정해져 있지 않아요. 설정 옮기기 같은 일은 setup 안에서 하고, 다른 모드의 맨 바깥 코드가 만든 전역 값에 기대지 않아요.
- 이미 있는 모드와 같은 일을 하는 모드면 `role`을 적어요(예: `'hotkeys'`). 막지는 않고, 둘 다 켜지면 모드 관리자가 알려 줘요. 이름은 `docs/SDK.md`의 역할 표를 보세요.
- 모드에 `author`(만든 사람)와 `tags`(고정 목록에서만 — MCP `tags_list`)를 적어요. 대표 태그(util·content·h-scene·image)는 하나 이상, 해당하면 표시 태그도. 같이 배포하는 묶음이면 `pack`도 (0.9.0).
- 오래 열어 두는 패널에는 `role="dialog"`를 쓰지 마세요. WAYWORKS가 막는 창으로 보고 모든 단축키를 막아요.
- Esc 로 창을 닫는다면 setup 때 `window.addEventListener('keydown', fn, true)`로 받아요. `document`에 걸면 WAYWORKS가 Esc를 먼저 가져가요(dialog 가 아닌 창일 때).
- IndexedDB에 세이브·설정처럼 백업에 꼭 있어야 하는 자료를 두면 `WML.define`에 `backup: { indexedDB: ['<이름>'] }`을 적어요(안 적으면 WML 백업에서 빠져요). 쓰기를 미루는 모드면 `api.backup.beforeExport`로 마무리해요. 캐시·Blob·파일 핸들은 선언하지 않아요.
- 저장된 글자 그대로가 필요하면 `WML.rawGetItem(key)`. 로더의 `getItem`은 압축 세이브를 풀어서 돌려줘요.
- 세이브 키(`tavern-game`, `tavern-slot-N`, `tavern-auto-dN`)를 위해 `Storage.prototype`을 덮어쓰지 않아요. 저장 공간은 WML의 "세이브 저장 위치"(IndexedDB, 0.9.0부터 기본으로 켜짐)가 맡아요. 켜져 있으면 이 키들의 `WML.rawGetItem`은 표식을 돌려주니, 세이브 글자는 `localStorage.getItem`으로 읽어요.
- 화면 글이 한국어뿐인 모드는 `lang: 'ko'`를 적어요(영문판에서 기본 꺼짐, 켜는 건 허용). 모드 관리자에 보일 `name`·`description`은 `{ ko, en }`도 돼요.
- 다른 제작자가 만든 모드는 함부로 고치지 않아요. 문제를 찾으면 재현 방법·영향·고치는 법을 정리해서 제작자에게 알려요. 로더가 알고 있는 문제는 `compat/compat.js`(호환 자료)의 `notices`에 있고 `mod_check`가 보여 줘요.
- 다른 모드가 꼭 있어야 하면 `requires`, 그 모드의 특정 버전이 필요하면 `requiresVersion: { '<id>': '>=1.2.0' }`도 같이 적어요(0.8.0).
- `mod_check`의 경고는 정적 검사예요. 실제로 깨지는지는 `play_*`로 확인한 뒤에 "고장"이라고 말해요.
- 화면 구석에 버튼을 직접 붙이지 마세요. `api.ui.addButton`으로 WML 버튼 줄에 한 개만 넣고, 나머지는 그 버튼으로 여는 창이나 ⚙ 설정에 둬요.
- 게임 일시 정지 메뉴에 설정 버튼을 넣을 때는 메뉴를 직접 찾지 말고 `api.ui.pauseSettings?.({ label: { ko, en }, onClick })`를 써요(0.8.0). 모든 모드 항목이 게임 '설정' 바로 아래에 로드 순서대로 모여요. `onClick`을 빼면 그 모드의 ⚙ 설정이 열려요.
  (이미 만든 요소는 `api.ui.adopt(el)`로 그 줄에 태울 수 있어요. 줄은 한 줄에 5개씩 차고 넘치면 윗줄이 생겨요.)
- 키보드 단축키만 있는 모드처럼 폰에서 쓸모없는 모드면 `platform: 'pc'`를 적어요. 폰 앱(WML 플레이어)도 생각해서: 파일 저장은 `api.saveFile`, 열어 둔 패널은 `api.onBack`으로 뒤로 가기에 닫히게, 폴더 고르기 대신 파일 여러 개 고르기를 써요.
- `location.protocol === 'file:'`로 기기를 가리지 마세요. 폰 앱에서는 게임이 https 주소로 열려요. `api.host`를 써요.
- 게임 글자로 비교하지 않아요. 한글판에서는 게임 코드 안의 문장도 한글이에요.
- 압축 이름(`r8`, `_`) 대신 의미 이름(`imagePrompt`, `wife`)을 써요.
- 과거 문서의 `release/` 경로를 현재 플레이 폴더로 추정하지 않아요. 위의 `working`은 보호 대상이며 별도 요청 없이 동기화하지 않아요.
