// Pack the mods as a separate download that is copied over a WML game folder.
//   node tools/pack-mods.mjs [--out <folder>] [--version 1.0.0] [--exclude id,id] [--mods <folder>] [--name basic|full]
//                            [--presets <presets.js>] [--mods-only]
// --presets: presets made for these mods, put in as wml/presets/presets.js (the full pack's own presets)
// --mods-only: leave the loader out (wml/runtime, wml/compat, wml/symbols) — the release ships it as its own wml-<loader>.zip
// --exclude: mod folders left out of the pack (their mods.js lines too), e.g. mods you keep for yourself
// --mods: where the mod folders and mods.js come from (default: wml/mods) — the full pack keeps its own folder
// --name: a label in the file name (wml-mods-<name>-<version>) and in the readmes: basic = mods WML made,
//         full = every mod of the last all-mods test
// Default out: release-paths.json staging/mods-release, or <game folder>/묶기작업/mods-release without that config.
// Output: <out>/wml-mods-<version>/ (wml/mods, wml/symbols for this game version, README_ko.txt, README_en.txt)
//         and <out>/wml-mods-<version>.zip; with --mods-only just wml/mods (+ wml/presets) and the readmes
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import * as acorn from 'acorn';
import * as walk from 'acorn-walk';
import { args } from './lib.mjs';
import { releaseOutput } from './release-paths.mjs';
import { zipDir, checkZip } from './zip.mjs';

const WML = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const a = args();
const version = a.version || '1.0.0';
const OUT = releaseOutput(WML, { out: a.out, subdir: 'mods-release' });
const LABEL = typeof a.name === 'string' && /^[a-z]+$/.test(a.name) ? a.name : '';
const NAME = `wml-mods-${LABEL ? `${LABEL}-` : ''}${version}`;
const MODS = path.resolve(a.mods || path.join(WML, 'mods'));
const PKG = path.join(OUT, NAME);
const MODS_ONLY = !!a['mods-only'];
const symbolsFile = fs.readdirSync(path.join(WML, 'symbols')).filter(f => /^\d{4}-\d{2}-\d{2}(?:-[a-z][a-z0-9.]*)?\.json$/.test(f)).sort().pop();
const game = symbolsFile.replace('.json', '');
const core = (fs.readFileSync(path.join(WML, 'runtime', 'wml-core.js'), 'utf8').match(/const VERSION = '([^']+)'/) || [])[1];

// ---- mod list (order and default on/off from mods.js, fields from each WML.define)
const EXCLUDE = new Set(String(a.exclude || '').split(',').map(x => x.trim()).filter(Boolean));
const dropExcluded = text => text.split(/\r?\n/).filter(line => { const m = line.match(/^\s*"([^":]+)(:off)?"/); return !(m && EXCLUDE.has(m[1])); }).join('\n');
const modsJs = dropExcluded(fs.readFileSync(path.join(MODS, 'mods.js'), 'utf8'));
const listed = [...modsJs.matchAll(/^\s*"([^":]+)(:off)?"/gm)].map(m => ({ id: m[1], on: !m[2] }));
const lit = n => (!n ? undefined : n.type === 'Literal' ? n.value : n.type === 'ArrayExpression' ? n.elements.map(lit) : undefined);
function meta(id) {
  const src = fs.readFileSync(path.join(MODS, id, 'mod.js'), 'utf8');
  let def = null;
  walk.simple(acorn.parse(src, { ecmaVersion: 'latest', sourceType: 'script' }), {
    CallExpression(n) { if (!def && n.callee.type === 'MemberExpression' && n.callee.object.name === 'WML' && n.callee.property.name === 'define') def = n.arguments[0]; },
  });
  const m = {};
  for (const p of def.properties) if (p.type === 'Property' && p.key.name !== 'setup') m[p.key.name] = lit(p.value);
  return m;
}
const mods = listed.map(l => ({ ...l, ...meta(l.id) }));
// languages the loader's compat data gives mods that do not state theirs (its argument is plain JSON)
const compatLangs = (() => {
  try {
    const src = fs.readFileSync(path.join(WML, 'compat', 'compat.js'), 'utf8');
    const at = src.search(/^WML\.compat\(/m);
    const data = JSON.parse(src.slice(at + 'WML.compat('.length, src.lastIndexOf(')')));
    return Object.fromEntries(Object.entries(data.mods || {}).filter(([, c]) => c.lang).map(([id, c]) => [id, [].concat(c.lang)]));
  } catch { return {}; }
})();
const langsOf = m => [].concat(m.lang || m.langs || compatLangs[m.id] || []);
const koOnly = m => { const l = langsOf(m); return l.length > 0 && !l.includes('en'); };
const nameOf = id => (mods.find(m => m.id === id) || {}).name || id;

// English one-liners for README_en (the mods' own text is Korean)
const EN = {
  'addon-compat': 'Compatibility layer the ported add-ons need. Keep it on.',
  'join-in': 'While a patron is with your wife, "join in" turns it into a scene with you in it.',
  'leave-her-there': 'When your wife passes out during service, adds "leave her there".',
  delivery: 'A delivery side job.',
  waitress: 'Hire one waitress (button at the top).',
  pregnancy: 'Pregnancy and birth.',
  'newwife-hina': 'New wife: Hina.',
  'newwife-miyabi': 'New wife: Miyabi.',
  outfit: 'Adds maid dress, bunny girl, reverse bunny, succubus and cat costumes to the shop.',
  imagestudio: 'Image generation studio (button at the bottom right).',
  brothel: 'Run a brothel (cellar rooms, break room).',
  'brothel-pregnancy': 'Brothel + pregnancy link.',
  maid: 'Maid house: hire 1-6 maids, give them work, build a relationship. With the waitress mod on, maids do not serve the hall.',
  slave: 'Slave house. Overlaps with the brothel - only one of the two can be on.',
  editor: 'Game editor.',
  'customer-edit': 'Patron editor. Clashes with the game editor - only one can be on.',
  'cheat-ledger': 'Cheat ledger (button at the top right). Used cheats are recorded.',
  'h-status': 'H Status (situation events, secret tab, sound hooks).',
  'situation-pregnancy': 'H Status + pregnancy link.',
  'character-prompts': 'Fixed appearance tags for Elena, Mara and Pippa (per person in its settings).',
  'image-look': 'Separate pictures while pregnant or when piercings / body fluids are visible.',
  'patron-control': 'Choose which patron approaches, what he does next and how she answers.',
  'debug-decision': 'Force or inspect acceptance checks (for testing).',
  'heroine-debug': "Edit your wife's hidden values (for testing).",
  'prompt-manager': 'Fix the prompt of a bad picture with its thumbs-down button and save the rule.',
  'prompt-autocomplete': 'Tag autocompletion for the prompt manager.',
  hooker: 'Edits the final request sent to the image server (CONFIG at the top of its mod.js).',
  wayworks: 'WAYWORKS: window layout, shortcuts, statistics, achievements, cheats.',
  'layer-fix': 'Stops the brothel / slave-house window frames from covering game popups, lines up top-right mod buttons and moves the WML buttons clear of the WAYWORKS window button.',
  'ww_imagepromptenhancedmod': 'Rewrites the image prompts (outfit, exposure, underwear, see-through, scene tags, bath service…) — Mod v2.65 by its own author. Cannot run next to the prompt manager, and does the same job as the Mod v2.30 mods split out in pack 1.1.0.',
  'ww_imagepromptenhancedmod_savecompressaddon': 'Save compression that comes with the mod above. Same job and same format as the bundled save-compress — keep only one on.',
  'outfitqueue': 'Image workshop: queue and review picture generation per outfit and scene. Open it from its ⚙ settings in the mod manager. Needs an image server.',
  'llm-core': 'Adds short lines written by an LLM after the game\'s own ones (your wife\'s mood, feelings and the patron are described to it). Needs an OpenAI-style endpoint of your own — a local llama.cpp / LM Studio / Ollama, or a cloud key. Without one it does nothing.',
  'llm-night-talk': 'Night talk in the bedroom, written by the LLM (needs llm-core). Also the example for writing your own child mod.',
  'extra-screens': 'Puts the story log in a window of its own, for a second monitor. With WAYWORKS on it becomes a WAYWORKS panel (dock, split, ↗ detach); without it, a plain browser window. PC only.',
  'touch-bar': 'Touch action buttons for phones (wait 1/5/15 min, till a patron, clean, kitchen, work, side job, nap) — the same rules as the game\'s hotkeys. Phones only unless switched on for PC.',
  'guidance-timeout': 'Fixes a game bug: an unanswered "what do you think about him?" talk blocked all later ones; after 30 minutes it counts as "Whatever feels right to you."',
  'ko-log-colors': 'Korean build: story lines get their colours back (they all came out white there). Does nothing in English.',
  'i18n-check': 'Untranslated-text collector for translated builds (does nothing in English).',
  'hello-wml': 'Example mod for mod makers.',
  'debug-bridge': 'The game link the debug tools (decision debug, patron control, heroine values, acceptance inspector, card table) need. Changes nothing by itself.',
  'log-colors': 'Easier-to-read story log: colours per kind of line, a colour dot per patron, emphasis for speech and thoughts, font size and line spacing, [action] badges, themes. Built for the Korean build.',
  femdom: 'Wife-led femdom choice events: chastity (three stages), prostate training, pegging. Korean text.',
  'anal-excuse': 'Anal with patrons happens more often, with her excuses for it. Korean text.',
  rival_tavern: 'A rival tavern across the street (parent and children in one mod). Korean text.',
  'extra-lines': 'Adds Korean lines to the story log during quiet minutes of scenes and everyday moments. Does not change numbers or checks.',
  'attention-image-prompt': 'Manages image prompts by state, dialogue, position, wife and outfit, and custom wives. Korean screens.',
  'image-pack-common-optimizer': 'Image packs: rotates the images of a scene across all characters, avoids the last 75 shown, uses outfit stand-ins up to 20% when there are candidates.',
  'layout-grid': 'Splits the four game panels into blocks you can move, resize, layer and open in windows of their own. Korean screens.',
  'crystal-ball': 'Records patron scenes minute by minute for the last 3 days and replays them read-only. Korean screens.',
  'large-save-storage': 'Moves manual slots and day-start saves into the browser database (IndexedDB). Off by default: WML backups do not carry those slots yet (see its notices in the mod manager).',
  'save-compress': 'Compresses save slots and day-start restore points to save space; when storage is full, removes the oldest restore points first. Saves still load with it off (loader 0.5.0+).',
  'acceptance-inspector': 'Shows what she accepts or refuses and why (for testing). Korean screens.',
  'card-table': 'Card table debugger: odds, next winner, stakes (for testing). Korean screens.',
};

// ---- copy
if (fs.existsSync(PKG)) fs.rmSync(PKG, { recursive: true, force: true });
const copyDir = (from, to, top = false) => {
  fs.mkdirSync(to, { recursive: true });
  for (const d of fs.readdirSync(from, { withFileTypes: true })) {
    if (/\.(bak|orig)$/i.test(d.name)) continue;
    if (top && EXCLUDE.has(d.name.replace(/\.zip$/i, ''))) continue;
    const s = path.join(from, d.name), t = path.join(to, d.name);
    if (d.isDirectory()) copyDir(s, t); else fs.copyFileSync(s, t);
  }
};
copyDir(MODS, path.join(PKG, 'wml', 'mods'), true);
if (EXCLUDE.size || a.mods) fs.writeFileSync(path.join(PKG, 'wml', 'mods', 'mods.js'), modsJs);
if (!MODS_ONLY) {
  fs.mkdirSync(path.join(PKG, 'wml', 'symbols'), { recursive: true });
  for (const ext of ['json', 'js']) fs.copyFileSync(path.join(WML, 'symbols', `${game}.${ext}`), path.join(PKG, 'wml', 'symbols', `${game}.${ext}`));
  // the loader too: newer loaders add features (0.3.0: install mods by dropping them on the game) and stay compatible
  fs.mkdirSync(path.join(PKG, 'wml', 'runtime'), { recursive: true });
  fs.copyFileSync(path.join(WML, 'runtime', 'wml-core.js'), path.join(PKG, 'wml', 'runtime', 'wml-core.js'));
  // and its compatibility data (0.8.0: languages and roles mods do not state, known problems per mod version)
  if (fs.existsSync(path.join(WML, 'compat', 'compat.js'))) {
    fs.mkdirSync(path.join(PKG, 'wml', 'compat'), { recursive: true });
    fs.copyFileSync(path.join(WML, 'compat', 'compat.js'), path.join(PKG, 'wml', 'compat', 'compat.js'));
  }
}
// presets made for this set of mods (--presets <presets.js>): they show in the manager as "came with the game"
const PRESETS = typeof a.presets === 'string' ? path.resolve(a.presets) : null;
if (PRESETS) {
  if (!fs.existsSync(PRESETS)) throw new Error(`프리셋 파일이 없어요: ${PRESETS}`);
  fs.mkdirSync(path.join(PKG, 'wml', 'presets'), { recursive: true });
  fs.copyFileSync(PRESETS, path.join(PKG, 'wml', 'presets', 'presets.js'));
}

// ---- readmes
const pad = (s, n) => s + ' '.repeat(Math.max(1, n - [...s].length));
const rel = (m, ko) => [
  m.requires && m.requires.length ? `${ko ? '필요' : 'needs'}: ${m.requires.map(r => (ko ? nameOf(r) : r)).join(', ')}` : '',
  m.conflicts && m.conflicts.length ? `${ko ? '같이 못 켬' : 'cannot run with'}: ${m.conflicts.map(r => (ko ? nameOf(r) : r)).join(', ')}` : '',
].filter(Boolean).join(' / ');
const kb = id => { let n = 0; const w = d => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) w(p); else n += fs.statSync(p).size; } }; w(path.join(PKG, 'wml', 'mods', id)); return n; };
const size = n => (n >= 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)}MB` : `${Math.max(1, Math.round(n / 1024))}KB`);
const total = mods.reduce((s, m) => s + kb(m.id), 0);

const KIND_KO = {
  basic: `기본팩이에요: WML이 만든 모드만 들어 있어요 (WML 자체 모드, MOD v3.44·Mod v2.30 기능을 떼어 포팅한 모드).
다른 제작자분들의 모드는 각 제작자 글에서 최신 버전을 받거나, 한 번에 받으려면 통팩(wml-mods-full)을 받으세요.
`,
  full: `통팩이에요: 모드를 전부 같이 켜서 시험한 구성 그대로예요 (다른 제작자분들의 모드는 묶은 날 기준 최신 버전).
원래 모드팩에 있던 모드는 예전 기본값 그대로이고, 새로 들어온 모드는 꺼져 있어요 — 모드 관리자에서 골라 켜세요.
각 모드의 다음 버전은 제작자 글에서 받아 그 모드 폴더만 바꾸면 돼요.
${PRESETS ? `모드 관리자의 "프리셋" 탭에 이 통팩용 예시 프리셋이 들어 있어요(wml\\presets\\presets.js). 고쳐서 내보내기로 나눠 주세요.
` : ''}`,
};
const KIND_EN = {
  basic: `This is the basic pack: only the mods WML made (WML's own, and features split out of MOD v3.44 / Mod v2.30).
Other authors' mods: get their latest from the authors' posts, or the full pack (wml-mods-full) to have them all.
`,
  full: `This is the full pack: every mod as it was run together in the last all-mods test (other authors' mods at their
latest on the day it was packed). Mods from the earlier pack keep their defaults; newly added ones start off.
${PRESETS ? `Example presets for this pack are in the mod manager's "Presets" tab (wml\\presets\\presets.js); change them and share them with Export.
` : ''}`,
};
const hasMod = id => mods.some(m => m.id === id);

const ko = `Wayward WML 모드팩${LABEL === 'basic' ? ' (기본)' : LABEL === 'full' ? ' (통팩)' : ''} ${version} (게임 ${game} 용)
==========================================

WML(Wayward Mod Loader)에서 돌아가는 모드 ${mods.length}개를 따로 모은 파일이에요.
${KIND_KO[LABEL] || `9-30 한글판용으로 나왔던 모드들을 WML에서 돌도록 옮기고 고친 것과, WML용으로 새로 만든 모드가 들어 있어요.
`}게임 파일 없이 모드만 들어 있어서, 이미 WML 게임(한글판·영문판)을 받은 사람이 모드만 새로 바꿀 때 써요.
${MODS_ONLY ? `모드 로더는 들어 있지 않아요. 로더는 게임 zip 이나 따로 받는 WML 로더(wml-${core}.zip)에 있어요.
` : ''}

■ 필요한 것
------------------------------------------

  - WML 게임 폴더 (게임 ${game} 기준, 모드 로더 v${core}${MODS_ONLY ? ' 이상' : ''})
    Wayward_WML_ko.html(한글판) 또는 Wayward_WML.html(영문판)과 wml 폴더가 있는 폴더예요.
${MODS_ONLY ? `  - 이 모드팩은 로더 v${core}에서 시험했어요. 쓰던 로더가 그보다 옛것이면 WML 로더(wml-${core}.zip)의
    wml 폴더도 게임 폴더에 같이 덮어쓰세요.
` : ''}  - 처음이라면 게임 배포본(한글판/영문판)을 먼저 받으세요. 한글판에는 모드가 없어서 이 모드팩을 같이 받아요
    (영문판에는 기본팩 모드가 들어 있어요).


■ 설치
------------------------------------------

  ▶ 방법 1 — 덮어쓰기 (권장: 폴더로 관리해요. 모드 폴더를 지우면 그 모드가 사라져요)
  1. 게임을 닫아요.
  2. 이 압축 안의 wml 폴더를 게임 폴더에 그대로 덮어써요.
       (게임 폴더)\\wml\\mods\\...        ← 모드 (폴더 하나가 모드 하나)
${MODS_ONLY ? '' : `       (게임 폴더)\\wml\\symbols\\...     ← 게임 함수 이름표 (몇몇 모드가 써요)
       (게임 폴더)\\wml\\runtime\\...     ← 모드 로더 v${core} (끌어다 놓기·폴더 등록·삭제 버튼 포함)
       (게임 폴더)\\wml\\compat\\...      ← 로더의 호환 자료 (모드별 언어·알려진 문제 안내)
`}${PRESETS ? `       (게임 폴더)\\wml\\presets\\...     ← 이 통팩용 예시 프리셋
` : ''}  3. 게임을 다시 열어요. 왼쪽 아래 WML 버튼 → 모드 관리자에서 켜고 꺼요.
  ▶ 모드 지우기: wml\\mods 에서 그 모드 폴더를 지우면 끝이에요. (모드 관리자의 "삭제" 버튼은 남은 설정을 지워 줘요)

  ▶ 방법 2 — 끌어다 놓기 (폴더 없이 브라우저에 보관)
    이 zip 파일을 압축 그대로 게임 화면에 끌어다 놓고 새로고침하세요.
    모드가 한 번에 브라우저에 들어가고, 기본으로 꺼 둘 모드는 꺼진 채로, 순서도 그대로 들어가요.
    ※ 세이브처럼 그 브라우저 안에만 있어요. 지울 때는 모드 관리자의 "삭제" 버튼을 쓰세요.

  ※ 덮어쓰기 전에 wml 폴더를 한 번 백업해 두면 마음이 편해요.
  ※ 모드 관리자에서 바꾼 켜기/끄기·순서는 브라우저에 저장돼 있어서 덮어써도 그대로예요.
  ※ wml\\mods\\mods.js(기본 목록)도 바뀌어요. 직접 추가한 모드가 있었다면 덮어쓴 뒤
     wml\\mods\\모드목록_자동갱신.cmd 를 더블클릭하세요. 폴더에 있는 모드가 다시 목록에 들어가요.
  ※ 앞으로 모드 폴더를 넣거나 뺄 때도 모드목록_자동갱신.cmd 를 더블클릭하면 목록이 맞춰져요.
  ※ 세이브는 브라우저에 저장돼 있어서 손대지 않아요. 그래도 게임 안 설정 → 내보내기로 백업해 두세요.


■ 들어 있는 모드 (${mods.length}개, 합계 ${size(total)})
------------------------------------------

  기본 = 처음부터 켜져 있음 / 끔 = 목록에는 있지만 기본으로 꺼져 있음
  순서는 기본 로드 순서예요 (모드 관리자에서 바꿀 수 있어요).

${mods.map((m, i) => `  ${String(i + 1).padStart(2)}. ${pad(m.name || m.id, 22)} [${m.on ? '기본' : '끔'}] v${m.version || '?'}  (${m.id}, ${size(kb(m.id))})
      ${m.description || ''}${rel(m, true) ? `\n      ${rel(m, true)}` : ''}`).join('\n')}


■ 꼭 알아둘 것
------------------------------------------

  - 애드온 호환층(addon-compat)은 포팅한 모드 대부분이 필요로 해요. 끄지 마세요.
${hasMod('slave') || hasMod('customer-edit') ? `  - 같이 켤 수 없는 조합(노예관 ↔ 창관, 손님 편집 ↔ 게임 에디터)은 둘 다 켜면 한쪽이 실행되지 않고
    모드 관리자에 이유가 빨갛게 나와요.
` : ''}  - 필요한 모드가 꺼져 있어도 그 이유가 모드 관리자에 나와요.
  - 메이드관·노예관 같은 큰 모드는 새 게임에서 시작하는 걸 권해요.
  - 포팅한 모드의 창·문구는 원작 그대로 한국어예요.


■ 원작
------------------------------------------

  포팅한 모드들은 원작 모드 제작자분들의 작품이에요. 내용은 원작 그대로 두고,
  지금 게임에서 돌도록 연결하고 오류만 고쳤어요. (각 mod.js 맨 위에 원본 파일 이름이 적혀 있어요)


■ 문제가 생기면
------------------------------------------

  - 화면이 까맣거나 이상해요 → WML 버튼에서 의심 가는 모드를 끄고 새로고침해 보세요.
  - 모드 관리자에 "오류"가 떠요 → 그 줄에 이유가 적혀 있어요 (필요한 모드, 같이 못 켜는 모드 등).
  - 원래대로 돌리고 싶어요 → 백업해 둔 wml 폴더로 되돌리거나, 게임 배포본의 wml 폴더를 다시 덮어써요.


■ 모드를 직접 만들거나 고치고 싶으면
------------------------------------------

  - 게임 폴더의 wml\\docs\\SDK.md (모드 SDK 설명서)
  - AI와 같이 만들기: MCP 서버(wml-mcp)
  - 모드 하나 = wml\\mods\\<이름>\\mod.js 파일 하나 + mods.js 에 한 줄


이 게임은 성인용(18세 이상) 콘텐츠이며 NTR 소재를 다룹니다.
`;

const en = `Wayward WML mod pack${LABEL ? ` (${LABEL})` : ''} ${version} (for game ${game})
==========================================

${mods.length} mods for the Wayward Mod Loader (WML), packed on their own: add-ons from the Korean community,
ported to run on WML, plus mods made for WML. There is no game file in here - use it to update the mods of a
WML game folder you already have.
${MODS_ONLY ? `The mod loader is not in here: it comes with the game package and as its own download (wml-${core}.zip).
` : ''}${KIND_EN[LABEL] || ''}
NOTE: most of these mods come from Korean add-ons. Their windows, buttons and messages are in Korean.


* Requirements
------------------------------------------

  - A WML game folder (game ${game}, mod loader v${core}${MODS_ONLY ? ' or newer' : ''}): the folder with Wayward_WML.html and the wml folder.
${MODS_ONLY ? `  - This pack was tested with loader v${core}. If yours is older, copy the wml folder of the WML loader
    (wml-${core}.zip) over the game folder too.
` : ''}  - New here? Get the game package first (the English one already holds the basic pack's mods).


* Installation
------------------------------------------

  > Way 1 - copy over (recommended: managed as folders - delete a mod's folder and the mod is gone)
  1. Close the game.
  2. Copy the wml folder from this archive over the game folder:
       (game folder)\\wml\\mods\\...      <- the mods (one folder = one mod)
${MODS_ONLY ? '' : `       (game folder)\\wml\\symbols\\...   <- game function name table (some mods use it)
       (game folder)\\wml\\runtime\\...   <- mod loader v${core} (drag and drop, folder registration, delete button)
       (game folder)\\wml\\compat\\...    <- the loader's compatibility data (languages, known problems per mod)
`}${PRESETS ? `       (game folder)\\wml\\presets\\...   <- example presets for this pack
` : ''}  3. Open the game again. Use the WML button at the bottom left (mod manager) to switch mods on and off.
  > Removing a mod: delete its folder in wml\\mods. (The "삭제" / delete button in the mod manager clears its leftovers.)

  > Way 2 - drag and drop (kept in the browser, no folders)
    Drag this zip file, still zipped, onto the game window and reload.
    All mods go into the browser at once, off-by-default mods stay off, and the order is kept.
    * Like saves, they live in that browser only. Remove them with the "삭제" / delete button in the mod manager.

  * Back up the wml folder first if you like.
  * On/off choices and load order made in the mod manager are stored in the browser and survive the copy.
  * wml\\mods\\mods.js (the default list) is replaced too. If you added mods of your own, double-click
    wml\\mods\\update-mod-list.cmd afterwards - every mod folder goes back on the list.
  * Whenever you add or remove a mod folder later, double-click update-mod-list.cmd to update the list.
  * Saves live in the browser and are not touched. Still, back up with Settings -> Export in the game.


* Mods (${mods.length}, ${size(total)} in total)
------------------------------------------

  on = on by default / off = listed but off by default. Listed in the default load order.

${mods.map((m, i) => `  ${String(i + 1).padStart(2)}. ${pad(m.id, 22)} [${m.on ? 'on' : 'off'}] v${m.version || '?'}  ${size(kb(m.id))}
      ${EN[m.id] || ''}${koOnly(m) ? `${EN[m.id] ? ' ' : ''}[Korean only: starts off in the English game]` : ''}${rel(m, false) ? `\n      ${rel(m, false)}` : ''}`).join('\n')}


* Good to know
------------------------------------------

  - addon-compat is needed by most ported mods. Keep it on.
  - Pairs that cannot run together (slave <-> brothel, customer-edit <-> editor): with both on, one does not run
    and the mod manager shows why in red. Missing required mods are reported the same way.
  - Start a new game for big mods such as maid and slave.


* Credits
------------------------------------------

  The ported mods are the work of their original authors. Their content is unchanged; they were only connected
  to the current game and fixed where they broke. (The original file name is noted at the top of each mod.js.)


* Making or changing mods
------------------------------------------

  - wml\\docs\\SDK.md in the game folder (mod SDK guide)
  - With an AI agent: the MCP package (wml-mcp)
  - One mod = one wml\\mods\\<name>\\mod.js file + one line in mods.js


This game contains adult (18+) content and explores NTR / cuckold themes.
`;
fs.writeFileSync(path.join(PKG, 'README_ko.txt'), ko.replace(/\n/g, '\r\n'));
fs.writeFileSync(path.join(PKG, 'README_en.txt'), en.replace(/\n/g, '\r\n'));

// ---- zip
const zip = path.join(OUT, `${NAME}.zip`);
zipDir(PKG, zip, { top: NAME });
checkZip(zip);                           // "/" paths and UTF-8 names, or it does not open on Linux/macOS/Android
console.log(JSON.stringify({ version, game, loader: core, mods: mods.length, on: mods.filter(m => m.on).length, size: size(total), folder: PKG, zip, zipMB: +(fs.statSync(zip).size / 1024 / 1024).toFixed(1) }, null, 1));
