// Optional development-only output settings. Paths in release-paths.json are relative to wml/.
// Distributed tools keep their original defaults when that file is absent; --out always wins.
import fs from 'node:fs';
import path from 'node:path';

export function releaseOutput(wmlDir, { out, subdir = '', fallback } = {}) {
  if (out) return path.resolve(out);
  const configFile = path.join(wmlDir, 'release-paths.json');
  if (fs.existsSync(configFile)) {
    const config = JSON.parse(fs.readFileSync(configFile, 'utf8'));
    if (!config || typeof config.staging !== 'string' || !config.staging.trim()) {
      throw new Error(`${configFile}: staging must be a non-empty path`);
    }
    return path.resolve(wmlDir, config.staging, subdir);
  }
  return path.resolve(fallback || path.join(wmlDir, '..', '묶기작업', subdir));
}

/** where finished release files go: release-paths.json "dist" (relative to wml/), or null to keep the tool's default */
export function releaseDist(wmlDir) {
  const configFile = path.join(wmlDir, 'release-paths.json');
  if (!fs.existsSync(configFile)) return null;
  const config = JSON.parse(fs.readFileSync(configFile, 'utf8'));
  return config && typeof config.dist === 'string' && config.dist.trim() ? path.resolve(wmlDir, config.dist) : null;
}
