// Carry place-keyed translations to a new game build.
//   node tools/i18n-port-places.mjs --from ../wayward-OLD.html --to ../wayward-NEW.html [--lang ko] [--write] [--verbose]
//
// Most of the pack is keyed by English text and follows a new build on its own. Two parts are keyed by place:
// "extra" (an id-looking word translated at one exact string literal) and "contexts" (one text translated
// differently at one place). A place id carries its top-level declaration's shape hash, so when the minifier renames
// things or the code around it changes, the id no longer exists in the new build and the place goes back to English
// (outfit names, act names, role nouns, slider ends …).
// This tool matches each old declaration that held such places to the new declaration that shares the most string
// literals, finds the same literal there by its neighbours, and writes the translation under the new place id.
// Old ids stay, so builds of the old version are not affected. Without --write it only reports.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { readGame, parseModule, args } from './lib.mjs';
import { units, stringPlaces, collectTexts, STRICT_CODE_PROPS } from './i18n-lib.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const wmlDir = path.resolve(here, '..');
const a = args();
if (!a.from || !a.to) { console.error('usage: node tools/i18n-port-places.mjs --from <old game html> --to <new game html> [--lang ko] [--write]'); process.exit(1); }
const langDir = path.join(wmlDir, 'i18n', a.lang || 'ko');
const packFile = path.join(langDir, 'strings.json');
const pack = JSON.parse(fs.readFileSync(packFile, 'utf8'));
const customFile = path.join(langDir, 'custom.json');
const custom = fs.existsSync(customFile) ? JSON.parse(fs.readFileSync(customFile, 'utf8')) : {};
const extra = { ...(pack.extra || {}), ...(custom.extra || {}) };
const contexts = { ...(pack.contexts || {}), ...(custom.contexts || {}) };
const has = (o, k) => Object.prototype.hasOwnProperty.call(o, k);

function load(file) {
  const g = readGame(path.resolve(file));
  const ast = parseModule(g.module);
  const u = units(ast, g.module);
  const starts = u.list.map(x => x.start);
  const unitAt = pos => {   // same rule as i18n-lib's place ids
    let lo = 0, hi = starts.length - 1, r = -1;
    while (lo <= hi) { const m = (lo + hi) >> 1; if (starts[m] <= pos) { r = m; lo = m + 1; } else hi = m - 1; }
    return r >= 0 && pos < u.list[r].end ? r : -1;
  };
  const byUnit = new Map();
  const slot = ui => { if (!byUnit.has(ui)) byUnit.set(ui, { strings: [], texts: [] }); return byUnit.get(ui); };
  const sp = stringPlaces(ast, u);
  for (const p of sp) { p.ui = unitAt(p.start); const s = slot(p.ui); p.i = s.strings.length; s.strings.push(p); }
  const tx = collectTexts(ast, g.module, u);
  for (const t of tx) { t.ui = unitAt(t.start); const s = slot(t.ui); t.i = s.texts.length; s.texts.push(t); }
  return { version: g.version, u, sp, tx, byUnit };
}

const o = load(a.from), n = load(a.to);
const newLids = new Set(n.sp.map(p => p.lid)), newCtx = new Set(n.tx.map(t => t.ctx));
const lost = new Map();   // old unit -> { strings: [place], texts: [item] }
const lostOf = ui => { if (!lost.has(ui)) lost.set(ui, { strings: [], texts: [] }); return lost.get(ui); };
for (const p of o.sp) if (has(extra, p.lid) && !newLids.has(p.lid)) lostOf(p.ui).strings.push(p);
for (const t of o.tx) if (has(contexts, t.ctx) && !newCtx.has(t.ctx)) lostOf(t.ui).texts.push(t);

// candidate new declarations: those whose shape is not in the old build (unchanged ones keep their ids)
const oldHashes = new Set(o.u.list.map(x => x.hash));
const valuesOf = (b, ui) => { const s = b.byUnit.get(ui); return s ? [...s.strings.map(p => p.value), ...s.texts.map(t => t.key)] : []; };
const index = new Map();   // value -> new units holding it
const newSize = new Map();
for (const [ui] of n.byUnit) {
  if (ui >= 0 && oldHashes.has(n.u.list[ui].hash)) continue;
  const vals = new Set(valuesOf(n, ui).filter(v => v.length >= 2));
  newSize.set(ui, vals.size);
  for (const v of vals) { if (!index.has(v)) index.set(v, []); index.get(v).push(ui); }
}
function candidates(oldUi) {
  const vals = new Set(valuesOf(o, oldUi).filter(v => v.length >= 2));
  const shared = new Map();
  for (const v of vals) {
    const list = index.get(v);
    if (!list || list.length > 40) continue;   // words found everywhere say nothing about which declaration this is
    for (const ui of list) shared.set(ui, (shared.get(ui) || 0) + 1);
  }
  return [...shared].map(([ui, s]) => ({ ui, score: s / (vals.size + newSize.get(ui) - s) }))
    .filter(c => c.score >= 0.2).sort((x, y) => y.score - x.score).slice(0, 4);
}
// the same literal in the new declaration, picked by its neighbours (and its property name)
function pick(oldList, oldItem, newList, valueOf, taken) {
  const v = valueOf(oldItem);
  const near = list => i => new Set([-3, -2, -1, 1, 2, 3].map(d => list[i + d]).filter(Boolean).map(valueOf));
  const mine = near(oldList)(oldItem.i);
  let best = null, bestScore = -1;
  for (const c of newList) {
    if (valueOf(c) !== v || taken.has(c)) continue;
    const ns = near(newList)(c.i);
    let s = 0;
    for (const x of mine) if (ns.has(x)) s++;
    if (c.prop === oldItem.prop) s += 0.5;
    s -= Math.abs(c.i / newList.length - oldItem.i / oldList.length) * 0.1;   // keep the order when nothing else decides
    if (s > bestScore) { best = c; bestScore = s; }
  }
  const count = newList.filter(c => valueOf(c) === v).length;
  return best && (count === 1 || bestScore >= 1) ? best : null;   // several candidates: need some neighbour to agree
}

const outExtra = {}, outCtx = {}, missed = [], dumped = [];
const takenS = new Set(), takenT = new Set();
for (const [oldUi, l] of lost) {
  const cands = candidates(oldUi);
  const name = oldUi >= 0 ? o.u.list[oldUi].name : '(top)';
  for (const p of l.strings) {
    let hit = null;
    for (const c of cands) { const s = n.byUnit.get(c.ui); if (s && (hit = pick(o.byUnit.get(oldUi).strings, p, s.strings, x => x.value, takenS))) break; }
    if (!hit) { missed.push({ kind: 'extra', unit: name, value: p.value, tr: extra[p.lid] }); continue; }
    if (STRICT_CODE_PROPS.has(hit.prop) || has(extra, hit.lid)) continue;
    takenS.add(hit); outExtra[hit.lid] = extra[p.lid];
    if (a.dump) dumped.push({ kind: 'extra', unit: name, prop: hit.prop, value: hit.value, tr: extra[p.lid] });
  }
  for (const t of l.texts) {
    let hit = null;
    for (const c of cands) { const s = n.byUnit.get(c.ui); if (s && (hit = pick(o.byUnit.get(oldUi).texts, t, s.texts, x => x.key, takenT))) break; }
    if (!hit) { missed.push({ kind: 'contexts', unit: name, value: t.key, tr: contexts[t.ctx] }); continue; }
    if (has(contexts, hit.ctx)) continue;
    takenT.add(hit); outCtx[hit.ctx] = contexts[t.ctx];
    if (a.dump) dumped.push({ kind: 'contexts', unit: name, prop: hit.prop, value: hit.key, tr: contexts[t.ctx] });
  }
}

const lostCount = [...lost.values()].reduce((s, l) => s + l.strings.length + l.texts.length, 0);
const report = { from: o.version, to: n.version, lostPlaces: lostCount, portedExtra: Object.keys(outExtra).length, portedContexts: Object.keys(outCtx).length, notFound: missed.length };
console.log(JSON.stringify(report, null, 1));
if (a.dump) fs.writeFileSync(path.resolve(a.dump), JSON.stringify(dumped, null, 1));
if (a.verbose) for (const m of missed) console.log(`  not found  ${m.kind}  ${m.unit}  ${JSON.stringify(m.value).slice(0, 80)} -> ${JSON.stringify(m.tr)}`);
if (a.write) {
  pack.extra = { ...(pack.extra || {}), ...outExtra };
  pack.contexts = { ...(pack.contexts || {}), ...outCtx };
  pack.updates = [...(pack.updates || []), { date: new Date().toISOString().slice(0, 10), from: `${o.version} -> ${n.version}`, placesPorted: report.portedExtra + report.portedContexts, note: 'place-keyed translations carried to the new build (tools/i18n-port-places.mjs)' }];
  fs.writeFileSync(packFile, JSON.stringify(pack, null, 1));
  console.log(`wrote ${path.relative(wmlDir, packFile)}`);
}
