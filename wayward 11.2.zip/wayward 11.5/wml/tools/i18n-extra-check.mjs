// Place-keyed translations ("extra") that may break a comparison in the translated build.
//   node tools/i18n-extra-check.mjs --game ../wayward-<ver>.html [--lang ko]
// An extra replaces one string literal and bypasses the compared-value guard. That is only a problem when the literal's
// value leaves its place as data — returned, stored in a variable, assigned, or put in an object property other than a
// display one (children, label, title …) — while the same English value is compared somewhere (===, case, includes, has).
// Lists those places with the code around them; read each one: a value that only ends up in a sentence is fine, a value
// that reaches a comparison needs the extra set back to English (custom.json "extra") and a display swap instead.
// Run it after tools/i18n-port-places.mjs on every new game version.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as walk from 'acorn-walk';
import { readGame, parseModule, args } from './lib.mjs';
import { units, stringPlaces } from './i18n-lib.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const a = args();
if (!a.game) { console.error('usage: node tools/i18n-extra-check.mjs --game <game html> [--lang ko]'); process.exit(2); }
const langDir = path.join(here, '..', 'i18n', a.lang || 'ko');
const pack = JSON.parse(fs.readFileSync(path.join(langDir, 'strings.json'), 'utf8'));
const customFile = path.join(langDir, 'custom.json');
const custom = fs.existsSync(customFile) ? JSON.parse(fs.readFileSync(customFile, 'utf8')) : {};
const extra = { ...(pack.extra || {}), ...(custom.extra || {}) };

const g = readGame(path.resolve(a.game));
const ast = parseModule(g.module);
const places = stringPlaces(ast, units(ast, g.module)).filter(p => Object.prototype.hasOwnProperty.call(extra, p.lid) && extra[p.lid] !== p.value);
const wanted = new Set(places.map(p => p.start));

// how the literal's value leaves its place (through ?:, && / || and parentheses)
const PASS = new Set(['ConditionalExpression', 'LogicalExpression', 'SequenceExpression', 'ParenthesizedExpression']);
const DISPLAY = /^(children|className|label|title|placeholder|description|text|aria-label|alt|name)$/;
const how = new Map();
walk.ancestor(ast, {
  Literal(node, anc) {
    if (!wanted.has(node.start)) return;
    let child = node;
    for (let i = anc.length - 2; i >= 0; i--) {
      const p = anc[i];
      if (PASS.has(p.type) && !(p.type === 'ConditionalExpression' && p.test === child)) { child = p; continue; }
      if (p.type === 'ReturnStatement') how.set(node.start, 'return');
      else if (p.type === 'ArrowFunctionExpression' && p.body === child) how.set(node.start, 'arrow');
      else if (p.type === 'VariableDeclarator' && p.init === child) how.set(node.start, 'var');
      else if (p.type === 'AssignmentExpression' && p.right === child) how.set(node.start, 'assign');
      else if (p.type === 'Property' && p.value === child) {
        const key = p.key && (p.key.name || p.key.value);
        if (!DISPLAY.test(key)) how.set(node.start, `prop:${key}`);
      }
      break;
    }
  },
});

const mod = g.module;
const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const around = (at, before, after) => mod.slice(Math.max(0, at - before), at + after).replace(/\s+/g, ' ');
const compared = v => {
  const q = esc(JSON.stringify(v));
  const re = new RegExp(`(?:===|!==|==|!=)\\s*${q}|${q}\\s*(?:===|!==|==|!=)|case\\s*${q}\\s*:|\\.includes\\(${q}\\)|\\.has\\(${q}\\)`, 'g');
  const out = [];
  let m;
  while ((m = re.exec(mod)) && out.length < 2) out.push(around(m.index, 80, 50));
  return out;
};
let flagged = 0;
for (const p of places) {
  const h = how.get(p.start);
  if (!h) continue;
  const hits = compared(p.value);
  if (!hits.length) continue;
  flagged++;
  console.log(`## ${JSON.stringify(p.value)} -> ${JSON.stringify(extra[p.lid])}  (${h})  [${p.lid}]`);
  console.log(`   at:  ${around(p.start, 130, 50)}`);
  for (const x of hits) console.log(`   cmp: ${x}`);
}
console.error(JSON.stringify({ game: g.version, translatedExtras: places.length, flagged }));
