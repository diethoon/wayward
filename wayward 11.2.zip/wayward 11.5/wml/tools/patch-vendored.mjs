// Vendored mods: mods their authors maintain, kept here as the received original + the changes we make to it.
// Our changes live in their own file, so a new original can be taken in and our changes put back on top of it,
// and a check finds a mod.js that was edited by hand or rebuilt without them.
//
//   node tools/patch-vendored.mjs <id …> | --all
//        rebuild wml/mods/<id> from the original and our changes (stops before writing if anything does not fit)
//   node tools/patch-vendored.mjs --check [<id …>]
//        rebuild into memory and compare with wml/mods/<id>: "=" same, "≠" different (nothing is written)
//   node tools/patch-vendored.mjs --register <id> --src <folder> --version <v> [--origin "…"]
//        take in a received original: records the folder and a SHA-256 for every file in it.
//        A ported mod of the same id moves out of "mods" (its command is kept under "was")
//   node tools/patch-vendored.mjs --derive <id>
//        write port/<id>.vendor-fixes.json from the difference between the original and the current wml/mods/<id>
//        (to adopt changes that were made by hand); the result is checked to rebuild the current files exactly
//
// port/regen.json → "vendored": { "<id>": { origin, version, src, files: { "<path>": "<sha256>" }, fixes?, was? } }
//   src   — folder with the received mod folder's files, relative to wml/ (development only; it is not shipped)
//   files — SHA-256 of every file in src; a rebuild stops when the original no longer matches what was recorded
//   fixes — port/<id>.vendor-fixes.json:
//     [ { "file": "mod.js", "find": "…", "replace": "…", "count": 1, "why": "…" }
//     | { "file": "files/x.js", "copy": "port/vendor-files/<id>/files/x.js", "why": "…" } ]
//     every find must occur exactly `count` (default 1) times in the file as it is at that point; otherwise nothing
//     is written. A new original therefore stops at the first change that no longer fits — look at it again then.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { args } from './lib.mjs';

const WML = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const REGEN = path.join(WML, 'port', 'regen.json');
const MODS = path.join(WML, 'mods');
const sha = buf => crypto.createHash('sha256').update(buf).digest('hex');
const posix = p => p.split(path.sep).join('/');

function readRegen() { return JSON.parse(fs.readFileSync(REGEN, 'utf8')); }
function writeRegen(r) { fs.writeFileSync(REGEN, JSON.stringify(r, null, 2) + '\n'); }

function listFiles(dir) {
  const out = [];
  const walk = d => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) walk(p); else out.push(posix(path.relative(dir, p)));
    }
  };
  if (fs.existsSync(dir)) walk(dir);
  return out.sort();
}

function entryOf(r, id) {
  const e = r.vendored && r.vendored[id];
  if (!e) throw new Error(`${id}: port/regen.json 의 vendored 에 없어요`);
  if (!e.src) throw new Error(`${id}: 받은 원본(src)이 기록돼 있지 않아요 — --register 로 먼저 기록하세요`);
  return e;
}

/** original files, verified against the recorded hashes */
function original(id, e) {
  const src = path.resolve(WML, e.src);
  if (!fs.existsSync(src)) throw new Error(`${id}: 원본 폴더가 없어요: ${e.src}`);
  const have = listFiles(src), want = Object.keys(e.files || {}).sort();
  const missing = want.filter(f => !have.includes(f)), extra = have.filter(f => !want.includes(f));
  if (missing.length || extra.length) throw new Error(`${id}: 원본 폴더의 파일 구성이 기록과 달라요 (없음: ${missing.join(', ') || '-'} / 더 있음: ${extra.join(', ') || '-'})`);
  const files = new Map();
  for (const f of want) {
    const buf = fs.readFileSync(path.join(src, f));
    if (sha(buf) !== e.files[f]) throw new Error(`${id}: 원본 ${f} 가 기록한 SHA-256 과 달라요 — 원본이 바뀌었으면 --register 로 다시 기록하세요`);
    files.set(f, buf);
  }
  return files;
}

function loadFixes(e) {
  if (!e.fixes) return [];
  const list = JSON.parse(fs.readFileSync(path.join(WML, e.fixes), 'utf8'));
  return list.map(x => (Array.isArray(x) ? { file: 'mod.js', find: x[0], replace: x[1] } : { file: 'mod.js', ...x }));
}

/** original + our changes → Map(path → Buffer). Throws (writes nothing) when a change does not fit. */
function build(id, r = readRegen()) {
  const e = entryOf(r, id);
  const files = original(id, e);
  const fixes = loadFixes(e);
  fixes.forEach((fx, i) => {
    const where = `${id}: 수정 ${i + 1}번 (${fx.file})${fx.why ? ` — ${fx.why}` : ''}`;
    if (fx.copy) {
      const from = path.join(WML, fx.copy);
      if (!fs.existsSync(from)) throw new Error(`${where}: 넣을 파일이 없어요: ${fx.copy}`);
      files.set(fx.file, fs.readFileSync(from));
      return;
    }
    if (!files.has(fx.file)) throw new Error(`${where}: 원본에 이 파일이 없어요`);
    const text = files.get(fx.file).toString('utf8');
    const want = fx.count ?? 1;
    let n = 0, at = -1;
    while ((at = text.indexOf(fx.find, at + 1)) !== -1) { n++; if (!fx.find.length) break; }
    if (n !== want) throw new Error(`${where}: 찾을 글이 ${want}번이어야 하는데 ${n}번 나와요 — 원본이 바뀌었으면 이 수정을 다시 봐야 해요`);
    files.set(fx.file, Buffer.from(text.split(fx.find).join(fx.replace), 'utf8'));
  });
  return files;
}

function compare(id, built) {
  const dir = path.join(MODS, id);
  const have = listFiles(dir);
  const diffs = [];
  for (const [f, buf] of built) {
    const p = path.join(dir, f);
    if (!fs.existsSync(p)) diffs.push(`없음 ${f}`);
    else if (!fs.readFileSync(p).equals(buf)) diffs.push(`다름 ${f}`);
  }
  for (const f of have) if (!built.has(f)) diffs.push(`기록에 없는 파일 ${f}`);
  return diffs;
}

/** replace wml/mods/<id> with the built files; the old folder is kept until the new one is in place */
function write(id, built) {
  const dir = path.join(MODS, id), tmp = path.join(MODS, `.${id}.building`), old = path.join(MODS, `.${id}.old`);
  fs.rmSync(tmp, { recursive: true, force: true });
  for (const [f, buf] of built) {
    const p = path.join(tmp, f);
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, buf);
  }
  fs.rmSync(old, { recursive: true, force: true });
  if (fs.existsSync(dir)) fs.renameSync(dir, old);
  try { fs.renameSync(tmp, dir); }
  catch (err) { if (fs.existsSync(old)) fs.renameSync(old, dir); throw err; }
  fs.rmSync(old, { recursive: true, force: true });
}

// ---------------------------------------------------------------- derive (hand edits → change list)
function lineDiff(a, b) {
  // patience-style: lines unique in both are anchors, the longest increasing run of them is kept,
  // and what lies between two anchors is compared as a block
  const count = arr => { const m = new Map(); arr.forEach((l, i) => { const c = m.get(l); m.set(l, c ? { n: c.n + 1, i } : { n: 1, i }); }); return m; };
  const ca = count(a), cb = count(b);
  const pairs = [];
  for (const [line, x] of ca) { const y = cb.get(line); if (x.n === 1 && y && y.n === 1) pairs.push([x.i, y.i]); }
  pairs.sort((p, q) => p[0] - q[0]);
  // longest increasing subsequence on b-index
  const tails = [], prev = new Array(pairs.length);
  pairs.forEach((p, i) => {
    let lo = 0, hi = tails.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (pairs[tails[mid]][1] < p[1]) lo = mid + 1; else hi = mid; }
    prev[i] = lo ? tails[lo - 1] : -1;
    tails[lo] = i;
  });
  const anchors = [];
  for (let k = tails.length ? tails[tails.length - 1] : -1; k >= 0; k = prev[k]) anchors.unshift(pairs[k]);
  anchors.push([a.length, b.length]);
  const hunks = [];
  let ia = 0, ib = 0;
  for (const [xa, xb] of anchors) {
    // trim equal lines at both ends of the gap
    let s = 0;
    while (ia + s < xa && ib + s < xb && a[ia + s] === b[ib + s]) s++;
    let t = 0;
    while (xa - t - 1 >= ia + s && xb - t - 1 >= ib + s && a[xa - t - 1] === b[xb - t - 1]) t++;
    if (ia + s < xa - t || ib + s < xb - t) hunks.push({ a0: ia + s, a1: xa - t, b0: ib + s, b1: xb - t });
    ia = xa + 1; ib = xb + 1;
  }
  return hunks;
}

function derive(id) {
  const r = readRegen();
  const e = entryOf(r, id);
  const orig = original(id, e);
  const dir = path.join(MODS, id);
  const fixes = [];
  const store = path.join(WML, 'port', 'vendor-files', id);
  for (const f of listFiles(dir)) {
    const cur = fs.readFileSync(path.join(dir, f));
    if (orig.has(f) && orig.get(f).equals(cur)) continue;
    const isText = /\.(js|json|txt|md|css|html)$/i.test(f) && orig.has(f);
    if (isText) {
      const A = orig.get(f).toString('utf8'), B = cur.toString('utf8');
      const a = A.split('\n'), b = B.split('\n');
      const local = [];
      for (const h of lineDiff(a, b)) {
        // grow context until the text to find is unique in the original
        for (let ctx = 1; ctx < 60; ctx++) {
          const s = Math.max(0, h.a0 - ctx), eA = Math.min(a.length, h.a1 + ctx);
          const before = a.slice(s, h.a0), after = a.slice(h.a1, eA);
          const find = [...before, ...a.slice(h.a0, h.a1), ...after].join('\n');
          const replace = [...before, ...b.slice(h.b0, h.b1), ...after].join('\n');
          if (find && A.indexOf(find) === A.lastIndexOf(find)) { local.push({ file: f, find, replace }); break; }
        }
      }
      // the changes must rebuild the current file exactly; otherwise take the whole file
      let t = A, ok = true;
      for (const fx of local) { if (t.split(fx.find).length !== 2) { ok = false; break; } t = t.split(fx.find).join(fx.replace); }
      if (ok && t === B) { fixes.push(...local); continue; }
    }
    const p = path.join(store, f);
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, cur);
    fixes.push({ file: f, copy: posix(path.relative(WML, p)), why: '파일 통째로 (줄 단위 수정으로 옮기지 못함)' });
  }
  for (const f of orig.keys()) if (!fs.existsSync(path.join(dir, f))) throw new Error(`${id}: 지금 폴더에서 원본 파일 ${f} 가 빠졌어요 — 빼는 수정은 지원하지 않아요`);
  const out = path.join(WML, 'port', `${id}.vendor-fixes.json`);
  fs.writeFileSync(out, JSON.stringify(fixes, null, 2) + '\n');
  e.fixes = posix(path.relative(WML, out));
  writeRegen(r);
  const diffs = compare(id, build(id));
  if (diffs.length) throw new Error(`${id}: 뽑은 수정으로 다시 만들면 지금 파일과 달라요: ${diffs.join(', ')}`);
  console.log(`✓ ${id}: 수정 ${fixes.length}개 → ${e.fixes}`);
}

// ---------------------------------------------------------------- register
function register(id, src, version, origin) {
  if (!src || !version) throw new Error('--register <id> --src <폴더> --version <버전> [--origin "…"]');
  const abs = path.resolve(src);
  if (!fs.existsSync(path.join(abs, 'mod.js'))) throw new Error(`${src} 에 mod.js 가 없어요 (받은 모드 폴더의 내용을 가리켜야 해요)`);
  const r = readRegen();
  r.vendored = r.vendored || {};
  const files = {};
  for (const f of listFiles(abs)) files[f] = sha(fs.readFileSync(path.join(abs, f)));
  const prev = r.vendored[id] || {};
  const was = prev.was || (r.mods && r.mods[id]) || undefined;
  if (r.mods && r.mods[id]) delete r.mods[id];
  r.vendored[id] = {
    ...(was ? { was } : {}),
    origin: origin || prev.origin || '',
    version,
    src: posix(path.relative(WML, abs)),
    files,
    ...(prev.fixes ? { fixes: prev.fixes } : {}),
  };
  writeRegen(r);
  console.log(`✓ ${id} ${version}: 원본 ${Object.keys(files).length}개 파일 기록 (${r.vendored[id].src})${prev.fixes ? ` · 기존 수정 ${prev.fixes} 유지` : ''}`);
}

// ---------------------------------------------------------------- main
const a = args();
try {
  if (a.register) { register(String(a.register), a.src, a.version, a.origin); }
  else if (a.derive) { derive(String(a.derive)); }
  else {
    const r = readRegen();
    const managed = Object.keys(r.vendored || {}).filter(id => r.vendored[id].src);
    const named = [...(typeof a.check === 'string' ? [a.check] : []), ...a._];
    const ids = a.all || (a.check && !named.length) ? managed : named;
    if (!ids.length) { console.error('usage: <id …> | --all | --check [<id …>] | --register <id> --src … --version … | --derive <id>'); process.exit(2); }
    let bad = 0;
    for (const id of ids) {
      try {
        const built = build(id, r);
        if (a.check) {
          const diffs = compare(id, built);
          if (diffs.length) bad++;
          console.log(`${diffs.length ? '≠' : '='} ${id} (vendored ${r.vendored[id].version})${diffs.length ? `: ${diffs.join(', ')}` : ''}`);
        } else {
          const before = compare(id, built);
          if (before.length) write(id, built);
          console.log(`✓ ${id} (vendored ${r.vendored[id].version})${before.length ? ' rebuilt' : ' unchanged'}`);
        }
      } catch (err) { bad++; console.log(`✗ ${err.message}`); }
    }
    if (bad) process.exitCode = 1;
  }
} catch (err) { console.error(`✗ ${err.message}`); process.exitCode = 1; }
