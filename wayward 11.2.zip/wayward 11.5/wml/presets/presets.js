// No bundled mod presets in this release.
WML.presets([]);
