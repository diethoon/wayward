// Helpers for the other ported mods (their preludes use the 9-30 Korean names through __WML_LEGACY__).
(() => {
  // 9-30 Korean name -> current name, per game build (made with tools/port-names.mjs, wml/compat/bridge-map.json)
  const MAPS = {
    '2026-10-04': {"re":"ae","g":"_","Y":"Y","Ce":"$e","vt":"bt","Qt":"Qt","Bt":"Pt","Rt":"At","C9":"wV","be":"_e","Ft":"Yt","bt":"pt","Qhe":"eme","_L":"n8","gL":"o8","dp":"Hp","v0":"ak","wc":"Bc","Xi":"hl","f2e":"mje","mY":"rF","nY":"K7","hhe":"lue","o3":"bO","Va":"hs","C3":"XO","Vr":"Xr","Jre":"Jle","_d":"Bd","Pb":"_w","iO":"CP","gT":"u$","pT":"d$","Yb":"vw","r8":"VB","Lf":"gp","Ob":"gw","MMe":"HOe","CMe":"POe","qMe":"JOe","Is":"Cs","I3e":"HPe","gPe":"w6e","dd":"Md","Zl":"mh","tl":"ul","cPe":"f6e","nae":"nhe","aH":"VL","f$":"T5","aae":"ahe","iae":"ihe","vpe":"pye","rae":"rhe","Pm":"ff","L6":"IB","MY":"$F","LIe":"PAe","j":"N","fc":"Dc","cb":"Wb","ph":"Eh","i9":"Kq","uPe":"g6e","iPe":"d6e","d3":"jO","tPe":"r6e","ND":"qD","mc":"Mc","w4e":"$He","Z":"Z","u":"u","gh":"Rh","bL":"r8","yL":"s8","Ile":"$de","dL":"J6","E$":"W5","iy":"Ly","iL":"q6","es":"ls","Av":"bx","Bo":"Oo"},
    '2026-10-18-pre': {"re":"ie","g":"_","Y":"B","Ce":"Pe","vt":"kt","Qt":"mo","Bt":"Ht","Rt":"Nt","C9":"P6","be":"_e","Ft":"fo","bt":"$t","Qhe":"lpe","_L":"sj","gL":"nj","dp":"u_","v0":"nx","wc":"Nd","Xi":"Hl","f2e":"iLe","mY":"Mz","nY":"Tz","hhe":"kG","o3":"t6","Va":"Ss","C3":"F6","Vr":"ma","Jre":"Owe","_d":"Gu","Pb":"h0","iO":"QW","gT":"_N","pT":"gN","Yb":"p0","r8":"LU","Lf":"Mg","Ob":"l0","MMe":"mqe","CMe":"uqe","qMe":"Wqe","Is":"is","I3e":"AVe","gPe":"tR","dd":"xi","Zl":"dr","tl":"Ll","cPe":"eJe","nae":"Fwe","aH":"y7","f$":"F2","aae":"qwe","iae":"Vwe","vpe":"GTe","rae":"Uwe","Pm":"Ap","L6":"IU","MY":"iK","LIe":"oYe","j":"j","fc":"Td","cb":"Mu","ph":"gc","i9":"see","uPe":"hJe","iPe":"PE","d3":"ax","tPe":"ZKe","ND":"jk","mc":"Sd","w4e":"xze","Z":"X","u":"u","gh":"yc","bL":"rj","yL":"IG","Ile":"R0e","dL":"wG","E$":"oj","iy":"xb","iL":"fG","es":"xs","Av":"v1","Bo":"rn"},
    '2026-10-18-pre2': {"re":"le","g":"_","Y":"U","Ce":"He","vt":"vt","Qt":"uo","Bt":"Ht","Rt":"yt","C9":"OY","be":"ge","Ft":"mo","bt":"Nt","Qhe":"Age","_L":"Qj","gL":"Jj","dp":"M_","v0":"Rx","wc":"mi","Xi":"Jl","f2e":"S6e","mY":"OK","nY":"IK","hhe":"bU","o3":"eY","Va":"Ns","C3":"BY","Vr":"xa","Jre":"Jbe","_d":"im","Pb":"C0","iO":"Q8","gT":"aN","pT":"rN","Yb":"L0","r8":"Hq","Lf":"s_","Ob":"R0","MMe":"eVe","CMe":"Z9e","qMe":"NVe","Is":"ds","I3e":"bKe","gPe":"JR","dd":"Di","Zl":"fr","tl":"Xl","cPe":"UQe","nae":"nke","aH":"_G","f$":"Oj","aae":"ake","iae":"ike","vpe":"s$e","rae":"rke","Pm":"zp","L6":"Tq","MY":"lJ","LIe":"wWe","j":"j","fc":"Bd","cb":"Zu","ph":"Ec","i9":"Ite","uPe":"eXe","iPe":"RR","d3":"Mx","tPe":"GQe","ND":"Zk","mc":"Wd","w4e":"mJe","Z":"X","u":"u","gh":"Cc","bL":"Xj","yL":"TU","Ile":"qve","dL":"yU","E$":"Kj","iy":"zb","iL":"mU","es":"$s","Av":"J1","Bo":"en"},
    '2026-10-24-pre7': {"re":"ie","g":"_","Y":"U","Ce":"Ee","vt":"vt","Qt":"mo","Bt":"Wt","Rt":"at","C9":"e8","be":"ye","Ft":"bo","bt":"jt","Qhe":"Hke","_L":"PE","gL":"OE","dp":"_y","v0":"JS","wc":"$i","Xi":"ch","f2e":"tGe","mY":"WX","nY":"EX","hhe":"Yq","o3":"wB","Va":"ds","C3":"a8","Vr":"Oa","Jre":"Fxe","_d":"Ya","Pb":"c_","iO":"ZF","gT":"DA","pT":"Ev","Yb":"Lv","r8":"kz","Lf":"B_","Ob":"jv","MMe":"iet","CMe":"aet","qMe":"Pet","Is":"es","I3e":"jot","gPe":"VD","dd":"Ui","Zl":"br","tl":"Nm","nae":"Jxe","aH":"R9","f$":"vE","aae":"Zxe","iae":"eSe","vpe":"zAe","rae":"Xxe","Pm":"$g","L6":"az","MY":"mZ","LIe":"KUe","j":"j","fc":"mu","cb":"tc","ph":"mh","i9":"Bse","uPe":"hrt","iPe":"jD","d3":"ZS","tPe":"ert","ND":"Zg","mc":"uu","w4e":"xnt","Z":"J","u":"u","gh":"fh","bL":"HE","yL":"zq","Ile":"fIe","dL":"Hq","E$":"ME","iy":"Dk","iL":"Rq","es":"xr","Av":"JIe","Bo":"on"},
  };
  const map = MAPS[api.game];
  if (!map) throw new Error(`게임 ${api.game}용 이름 표가 없어요 (tools/port-names.mjs로 만들어 주세요)`);
  const cur = old => { const n = map[old]; if (!n) throw new Error(`이름 표에 ${old}가 없어요`); return n; };
  const L = old => __E[cur(old)];
  const setL = (old, v) => { __E[cur(old)] = v; };

  // new wives (old "wife addon" files push definitions into globalThis.__WAYWARD_WIFE_ADDONS__):
  // the same merge the mod manager patched into the game — a copy of the base wife with the changes on top
  const registerWife = def => {
    const presets = L('Zl'), names = L('dd'), ids = map.cPe ? L('cPe') : null;   // the id table is gone since 2026-10-18-pre (the game looks wives up by shortname)
    if (!def || typeof def.id !== 'string' || presets.some(w => w.id === def.id)) return false;
    const base = presets.find(w => w.id === def.basedOn);
    if (!base) { api.warn(`새 아내 ${def.name || def.id}: 바탕 아내 ${def.basedOn}을(를) 찾지 못했어요`); return false; }
    const { basedOn, ...changes } = def;
    presets.push({ ...base, ...changes, attributeBias: { ...base.attributeBias, ...changes.attributeBias }, backstoryPins: changes.backstoryPins || {} });
    if (def.shortname && !names.includes(def.shortname)) names.push(def.shortname);
    if (def.shortname && ids) ids[def.shortname] = def.id;
    return true;
  };
  const registerWives = () => { for (const w of globalThis.__WAYWARD_WIFE_ADDONS__ || []) registerWife(w); };
  registerWives();
  // image packs: also look for images-<wife>-custom.js (made by the image studio)
  api.hook(cur('MMe'), { after: (files, [who]) => (Array.isArray(files) && !files.includes(`images-${who}-custom.js`) ? [...files, `images-${who}-custom.js`] : files) });

  globalThis.__WML_LEGACY__ = Object.freeze({ game: api.game, name: cur, get: L, set: setL, map: { ...map }, registerWife, registerWives });
})();

// The shared bridge (__WAYWARD_ADDON_API__) is filled in by many mods, and some put read-only views of game values
// on it: a getter with no setter (this bridge's waitress.price, debug-bridge's manifest text …). A mod that merges
// its own copy of the same value in — Object.assign(api, { ue: store }), as rival_tavern does — then threw and lost
// its whole setup. After every mod's setup such views get a setter: the same value again is fine; another value is
// not taken (the view keeps showing the game's) and the manager says so, but the mod goes on.
(() => {
  const warned = new Set();
  const plain = v => v !== null && typeof v === 'object' && [Object.prototype, null].includes(Object.getPrototypeOf(v));
  const tolerate = (o, path, seen, depth) => {
    if (seen.has(o) || depth > 4 || Object.isFrozen(o)) return;
    seen.add(o);
    for (const k of Object.getOwnPropertyNames(o)) {
      const d = Object.getOwnPropertyDescriptor(o, k), at = path + k;
      if (d.get && !d.set) {
        if (!d.configurable) continue;
        const get = d.get;
        Object.defineProperty(o, k, {
          get, enumerable: d.enumerable, configurable: true,
          set(v) {
            let now;
            try { now = get.call(this); } catch { now = undefined; }
            if (Object.is(v, now) || warned.has(at)) return;
            warned.add(at);
            api.warn(`다른 모드가 공용 연결(__WAYWARD_ADDON_API__)의 ${at}을(를) 바꾸려 했어요. 게임 값을 그대로 보여 주는 읽기 전용 자리라 바꾸지 않고 넘어갔어요.`);
          },
        });
      } else if ('value' in d && plain(d.value)) tolerate(d.value, at + '.', seen, depth + 1);
    }
  };
  const tidy = () => { const bridge = globalThis.__WAYWARD_ADDON_API__; if (plain(bridge)) tolerate(bridge, '', new Set(), 0); };
  tidy();
  if (typeof api.afterEachSetup === 'function') api.afterEachSetup(tidy);
})();
