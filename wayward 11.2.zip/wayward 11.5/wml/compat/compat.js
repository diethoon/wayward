// WML compatibility data — kept with the loader. Mods are never changed for this file.
//
//  mods     What a mod does not say about itself. A mod's own WML.define({ lang, role }) always wins.
//           lang: the game languages the mod is made for. Elsewhere it starts switched off (players can still switch
//                 it on; the manager says "Korean only"). Mods that need such a mod follow it.
//                 Rule used: the mod's screens or the text it adds to the game are in that language only.
//                 A mod whose only Korean is its name/description/log lines is not listed (it works in any language).
//           role: a job it shares with other mods (the manager says when two of them are on; both still run).
//           author / tags / pack (0.9.0): who made it, tags from the loader's fixed list (MOD_TAGS in runtime/wml-core.js),
//                 the bundle it ships in (folded together in the manager). Filled in here for mods that do not say it.
//           Take an entry out once the mod declares it itself or supports more languages.
//  notices  Known problems of a mod version, for players (the manager shows them; "high" also at start) and for
//           the mod's author (MCP mod_check shows them): when it happens, what it does, what WML does about it,
//           how to fix it. cause: "mod" = the mod has to change, "loader" = it comes from WML but WML cannot take it
//           in safely. versions: the versions it is known for ("*" = all).
//
// The argument of the call below is plain JSON (the MCP server reads it as JSON).
WML.compat({
  "format": "wml-compat",
  "version": 2,
  "mods": {
    "ko-log-colors": {
      "lang": [
        "ko"
      ],
      "author": "kknd · WML port",
      "tags": [
        "util"
      ]
    },
    "log-colors": {
      "lang": [
        "ko"
      ],
      "author": "testingreport101",
      "tags": [
        "util"
      ]
    },
    "delivery": {
      "lang": [
        "ko"
      ],
      "author": "Hina_Lover",
      "tags": [
        "content"
      ]
    },
    "waitress": {
      "lang": [
        "ko"
      ],
      "author": "Hina_Lover",
      "tags": [
        "content"
      ]
    },
    "pregnancy": {
      "lang": [
        "ko"
      ],
      "author": "Hina_Lover",
      "tags": [
        "content"
      ]
    },
    "newwife-hina": {
      "lang": [
        "ko"
      ],
      "author": "Hina_Lover",
      "tags": [
        "content",
        "needs-new-game"
      ]
    },
    "newwife-miyabi": {
      "lang": [
        "ko"
      ],
      "author": "arhka",
      "tags": [
        "content",
        "needs-new-game"
      ]
    },
    "outfit": {
      "lang": [
        "ko"
      ],
      "author": "ㅅㅅㅍㅍ",
      "tags": [
        "content"
      ]
    },
    "imagestudio": {
      "lang": [
        "ko"
      ],
      "author": "Hina_Lover",
      "tags": [
        "prompt",
        "image",
        "needs-image-server"
      ]
    },
    "brothel": {
      "lang": [
        "ko"
      ],
      "author": "Hina_Lover",
      "tags": [
        "content",
        "h-scene"
      ]
    },
    "brothel-pregnancy": {
      "lang": [
        "ko"
      ],
      "author": "Hina_Lover",
      "tags": [
        "content"
      ]
    },
    "maid": {
      "lang": [
        "ko"
      ],
      "author": "arhka",
      "tags": [
        "content"
      ]
    },
    "slave": {
      "lang": [
        "ko"
      ],
      "author": "arhka",
      "tags": [
        "content",
        "h-scene"
      ]
    },
    "editor": {
      "lang": [
        "ko"
      ],
      "author": "Hina_Lover",
      "tags": [
        "util"
      ]
    },
    "customer-edit": {
      "lang": [
        "ko"
      ],
      "author": "arhka",
      "tags": [
        "util"
      ]
    },
    "cheat-ledger": {
      "lang": [
        "ko"
      ],
      "author": "Sanguine",
      "tags": [
        "util"
      ]
    },
    "h-status": {
      "lang": [
        "ko"
      ],
      "author": "ilil1ilil1ilil",
      "tags": [
        "content",
        "h-scene"
      ]
    },
    "situation-pregnancy": {
      "lang": [
        "ko"
      ],
      "role": [
        "pregnancy-link"
      ],
      "author": "ilil1ilil1ilil",
      "tags": [
        "content"
      ]
    },
    "femdom": {
      "lang": [
        "ko"
      ],
      "author": "allrounder",
      "tags": [
        "content",
        "h-scene"
      ]
    },
    "anal-excuse": {
      "lang": [
        "ko"
      ],
      "author": "allrounder",
      "tags": [
        "content",
        "h-scene"
      ]
    },
    "rival_tavern": {
      "lang": [
        "ko"
      ],
      "author": "Cc88",
      "tags": [
        "content"
      ]
    },
    "patron-control": {
      "lang": [
        "ko"
      ],
      "author": "testingreport101",
      "tags": [
        "util"
      ]
    },
    "debug-decision": {
      "lang": [
        "ko"
      ],
      "author": "testingreport101",
      "tags": [
        "util"
      ]
    },
    "heroine-debug": {
      "lang": [
        "ko"
      ],
      "author": "testingreport101",
      "tags": [
        "util"
      ]
    },
    "acceptance-inspector": {
      "lang": [
        "ko"
      ],
      "author": "testingreport101",
      "tags": [
        "util"
      ]
    },
    "card-table": {
      "lang": [
        "ko"
      ],
      "author": "testingreport101",
      "tags": [
        "util"
      ]
    },
    "extra-lines": {
      "lang": [
        "ko"
      ],
      "author": "testingreport101",
      "tags": [
        "content",
        "h-scene"
      ]
    },
    "prompt-manager": {
      "lang": [
        "ko"
      ],
      "author": "fdhz4238",
      "tags": [
        "prompt"
      ]
    },
    "attention-image-prompt": {
      "lang": [
        "ko"
      ],
      "author": "aaajjaaaadsfa",
      "tags": [
        "prompt"
      ]
    },
    "ww_imagepromptenhancedmod": {
      "lang": [
        "ko"
      ],
      "author": "dhffkvmrkwhgdk",
      "tags": [
        "prompt"
      ]
    },
    "ww_imagepromptenhancedmod_savecompressaddon": {
      "lang": [
        "ko"
      ],
      "author": "dhffkvmrkwhgdk",
      "tags": [
        "util"
      ]
    },
    "outfitqueue": {
      "lang": [
        "ko"
      ],
      "author": "그린애플",
      "tags": [
        "image"
      ]
    },
    "wayworks": {
      "lang": [
        "ko"
      ],
      "author": "backdoorlover99",
      "tags": [
        "util"
      ]
    },
    "crystal-ball": {
      "lang": [
        "ko"
      ],
      "author": "민트좋아",
      "tags": [
        "util"
      ]
    },
    "i18n-check": {
      "lang": [
        "ko"
      ],
      "author": "키모이맨 (WML)",
      "tags": [
        "util"
      ]
    },
    "layout-grid": {
      "lang": [
        "ko"
      ],
      "role": [
        "layout"
      ],
      "author": "민트좋아",
      "tags": [
        "util"
      ]
    },
    "badguest": {
      "lang": [
        "ko"
      ],
      "author": "민트좋아",
      "tags": [
        "content",
        "h-scene"
      ]
    },
    "best-girl-add-mod": {
      "lang": [
        "ko"
      ],
      "author": "konekoneko",
      "tags": [
        "content",
        "image",
        "needs-new-game"
      ]
    },
    "bond-defense": {
      "lang": [
        "ko"
      ],
      "author": "비비비비빅",
      "tags": [
        "content"
      ]
    },
    "quest-board": {
      "lang": [
        "ko"
      ],
      "author": "urkta",
      "tags": [
        "content"
      ]
    },
    "sound-mod": {
      "lang": [
        "ko"
      ],
      "author": "아즈칼",
      "tags": [
        "content"
      ]
    },
    "peeking-mode": {
      "lang": [
        "ko"
      ],
      "author": "민트좋아",
      "tags": [
        "content",
        "h-scene"
      ]
    },
    "peeking-mode-badguest": {
      "lang": [
        "ko"
      ],
      "author": "민트좋아",
      "tags": [
        "content"
      ]
    },
    "newwife-mika": {
      "lang": [
        "ko"
      ],
      "author": "Hina_Lover",
      "tags": [
        "content",
        "needs-new-game"
      ]
    },
    "wayward-repertoire-pack": {
      "lang": [
        "ko"
      ],
      "author": "2lerw23",
      "tags": [
        "content",
        "h-scene"
      ]
    },
    "wife-view-mode": {
      "lang": [
        "ko"
      ],
      "author": "Hina_Lover",
      "tags": [
        "content"
      ]
    },
    "guard-hire": {
      "lang": [
        "ko"
      ],
      "author": "bangkong",
      "tags": [
        "content"
      ]
    },
    "tavern-expansion": {
      "lang": [
        "ko"
      ],
      "author": "urkta",
      "tags": [
        "content"
      ]
    },
    "h-status-pregnancy": {
      "role": [
        "pregnancy-link"
      ],
      "author": "Hina_Lover",
      "tags": [
        "content"
      ]
    },
    "guidance-timeout": {
      "role": [
        "guidance-fix"
      ],
      "author": "키모이맨 (WML)",
      "tags": [
        "util"
      ]
    },
    "patron-guidance-fix": {
      "role": [
        "guidance-fix"
      ],
      "author": "biolab2",
      "tags": [
        "util"
      ]
    },
    "addon-compat": {
      "author": "키모이맨 (WML)",
      "tags": [
        "util"
      ]
    },
    "extra-screens": {
      "author": "키모이맨 (WML)",
      "tags": [
        "util"
      ]
    },
    "touch-bar": {
      "author": "키모이맨 (WML)",
      "tags": [
        "util"
      ]
    },
    "layer-fix": {
      "author": "키모이맨 (WML)",
      "tags": [
        "util"
      ]
    },
    "hello-wml": {
      "author": "키모이맨 (WML)",
      "tags": [
        "util"
      ]
    },
    "llm-core": {
      "author": "키모이맨 (WML)",
      "tags": [
        "content",
        "needs-llm",
        "experimental"
      ]
    },
    "llm-night-talk": {
      "author": "키모이맨 (WML)",
      "tags": [
        "content",
        "needs-llm",
        "experimental"
      ]
    },
    "join-in": {
      "author": "키모이맨 (WML)",
      "tags": [
        "h-scene"
      ]
    },
    "leave-her-there": {
      "author": "키모이맨 (WML)",
      "tags": [
        "content"
      ]
    },
    "image-look": {
      "author": "키모이맨 (WML)",
      "tags": [
        "prompt"
      ]
    },
    "staff-grandma": {
      "author": "kknd · WML port",
      "tags": [
        "content"
      ]
    },
    "staff-goblin": {
      "author": "kknd · WML port",
      "tags": [
        "content"
      ]
    },
    "staff-hunter": {
      "author": "kknd · WML port",
      "tags": [
        "content"
      ]
    },
    "dare-relax": {
      "author": "kknd · WML port",
      "tags": [
        "content"
      ]
    },
    "clothing-choice": {
      "author": "kknd · WML port",
      "tags": [
        "content"
      ]
    },
    "guest-templates": {
      "author": "kknd · WML port",
      "tags": [
        "content"
      ]
    },
    "endings": {
      "author": "kknd · WML port",
      "tags": [
        "content"
      ]
    },
    "guild-shop": {
      "author": "kknd · WML port",
      "tags": [
        "content"
      ]
    },
    "auto-position": {
      "author": "kknd · WML port",
      "tags": [
        "h-scene",
        "util"
      ]
    },
    "scene-continuations": {
      "author": "kknd · WML port",
      "tags": [
        "h-scene"
      ]
    },
    "wife-autonomy": {
      "author": "kknd · WML port",
      "tags": [
        "content",
        "h-scene"
      ]
    },
    "kknd-cheat": {
      "author": "kknd · WML port",
      "tags": [
        "util"
      ]
    },
    "balance": {
      "author": "kknd · WML port",
      "tags": [
        "util"
      ]
    },
    "music-player": {
      "author": "kknd · WML port",
      "tags": [
        "util"
      ]
    },
    "themes": {
      "author": "kknd · WML port",
      "tags": [
        "util"
      ]
    },
    "log-ui": {
      "author": "kknd · WML port",
      "tags": [
        "util"
      ]
    },
    "kknd-hotkeys": {
      "author": "kknd · WML port",
      "tags": [
        "util"
      ]
    },
    "kknd-stats": {
      "author": "kknd · WML port",
      "tags": [
        "util"
      ]
    },
    "image-ext": {
      "author": "kknd · WML port",
      "tags": [
        "image"
      ]
    },
    "scene-prompt-override": {
      "author": "kknd · WML port",
      "tags": [
        "prompt"
      ]
    },
    "aftermath-look": {
      "author": "dhffkvmrkwhgdk · WML port",
      "tags": [
        "prompt",
        "h-scene"
      ]
    },
    "bath-scenes": {
      "author": "dhffkvmrkwhgdk · WML port",
      "tags": [
        "prompt",
        "h-scene"
      ]
    },
    "group-prompt": {
      "author": "dhffkvmrkwhgdk · WML port",
      "tags": [
        "prompt",
        "h-scene"
      ]
    },
    "finish-scenes": {
      "author": "dhffkvmrkwhgdk · WML port",
      "tags": [
        "prompt",
        "image",
        "h-scene",
        "needs-image-server"
      ]
    },
    "drunk-look": {
      "author": "dhffkvmrkwhgdk · WML port",
      "tags": [
        "prompt"
      ]
    },
    "patron-look": {
      "author": "dhffkvmrkwhgdk · WML port",
      "tags": [
        "prompt"
      ]
    },
    "prompt-cleanup": {
      "author": "dhffkvmrkwhgdk · WML port",
      "tags": [
        "prompt"
      ]
    },
    "prompt-tags": {
      "author": "dhffkvmrkwhgdk · WML port",
      "tags": [
        "prompt"
      ]
    },
    "wife-look-garu": {
      "author": "dhffkvmrkwhgdk · WML port",
      "tags": [
        "prompt"
      ]
    },
    "save-compress": {
      "author": "dhffkvmrkwhgdk · WML port",
      "tags": [
        "util"
      ]
    },
    "delivery-compatible-wife-view-mode": {
      "author": "Hina_Lover",
      "tags": [
        "content"
      ]
    },
    "pregnancy-compatible-wife-view-mode": {
      "author": "Hina_Lover",
      "tags": [
        "content"
      ]
    },
    "festival": {
      "author": "Hina_Lover",
      "tags": [
        "content"
      ]
    },
    "brothel-compatible-festival": {
      "author": "Hina_Lover",
      "tags": [
        "content"
      ]
    },
    "delivery-compatible-brothel": {
      "author": "Hina_Lover",
      "tags": [
        "content"
      ]
    },
    "imagestudio-multiwoman_images": {
      "author": "Hina_Lover",
      "tags": [
        "image",
        "needs-image-server"
      ]
    },
    "brothel-multiwoman_images": {
      "author": "Hina_Lover",
      "tags": [
        "content",
        "image",
        "needs-image-server"
      ]
    },
    "character-prompts": {
      "author": "ilil1ilil1ilil",
      "tags": [
        "prompt"
      ]
    },
    "debug-bridge": {
      "author": "testingreport101",
      "tags": [
        "util"
      ]
    },
    "act-expansion": {
      "author": "testingreport101",
      "tags": [
        "content",
        "h-scene"
      ]
    },
    "husband-life": {
      "author": "testingreport101",
      "tags": [
        "content",
        "h-scene"
      ]
    },
    "erostat-plus": {
      "author": "testingreport101",
      "tags": [
        "content",
        "h-scene"
      ]
    },
    "prompt-autocomplete": {
      "author": "fdhz4238",
      "tags": [
        "prompt",
        "util"
      ]
    },
    "hooker": {
      "author": "ㅅㅅㅍㅍ",
      "tags": [
        "prompt",
        "image"
      ]
    },
    "easygen": {
      "author": "gamon",
      "tags": [
        "image",
        "needs-image-server"
      ]
    },
    "character-atelier": {
      "author": "그린애플",
      "tags": [
        "content",
        "needs-new-game"
      ]
    },
    "large-save-storage": {
      "author": "민트좋아",
      "tags": [
        "util"
      ]
    },
    "image-pack-common-optimizer": {
      "author": "2lerw23",
      "tags": [
        "image"
      ]
    },
    "bath-fix": {
      "author": "2lerw23",
      "tags": [
        "util"
      ]
    },
    "bad-patron-choice-preserver": {
      "author": "2lerw23",
      "tags": [
        "util"
      ]
    },
    "patron-event-repeat-guard": {
      "author": "2lerw23",
      "tags": [
        "util"
      ]
    },
    "temporary-closure": {
      "author": "urkta",
      "tags": [
        "content"
      ]
    },
    "potion-inventory": {
      "author": "urkta",
      "tags": [
        "util"
      ]
    },
    "customer-trade-display": {
      "author": "urkta",
      "tags": [
        "util"
      ]
    },
    "exterior-image-location": {
      "author": "urkta",
      "tags": [
        "prompt"
      ]
    },
    "beast-potions": {
      "author": "ehfmfldrkehfmfldrk",
      "tags": [
        "content"
      ]
    },
    "chastity-belt": {
      "author": "ㄹㅇ이가;",
      "tags": [
        "content",
        "h-scene"
      ]
    },
    "wayward-harmony": {
      "author": "sichverstarken",
      "tags": [
        "util"
      ]
    },
    "wayward-image-prompt-editor": {
      "author": "sichverstarken",
      "tags": [
        "prompt"
      ]
    },
    "wayward-maomao": {
      "author": "sichverstarken",
      "tags": [
        "content",
        "image"
      ]
    },
    "wayward-api": {
      "pack": "sister-mods"
    },
    "relation-unlock": {
      "pack": "sister-mods"
    },
    "wa-accusation": {
      "pack": "sister-mods"
    },
    "wa-allure-tweak": {
      "pack": "sister-mods"
    },
    "wa-bare-secret": {
      "pack": "sister-mods"
    },
    "wa-bath-curtain": {
      "pack": "sister-mods"
    },
    "wa-blacklist": {
      "pack": "sister-mods"
    },
    "wa-boundary-talk": {
      "pack": "sister-mods"
    },
    "wa-burden": {
      "pack": "sister-mods"
    },
    "wa-chain-ask": {
      "pack": "sister-mods"
    },
    "wa-chaste-devotee": {
      "pack": "sister-mods"
    },
    "wa-climax-amends": {
      "pack": "sister-mods"
    },
    "wa-comfort-touch": {
      "pack": "sister-mods"
    },
    "wa-compliance": {
      "pack": "sister-mods"
    },
    "wa-consent-integrity": {
      "pack": "sister-mods"
    },
    "wa-core": {
      "pack": "sister-mods"
    },
    "wa-cosleep": {
      "pack": "sister-mods"
    },
    "wa-customer-edit": {
      "pack": "sister-mods"
    },
    "wa-dare-followup": {
      "pack": "sister-mods"
    },
    "wa-date": {
      "pack": "sister-mods"
    },
    "wa-desire-hold": {
      "pack": "sister-mods"
    },
    "wa-devotion-rescue": {
      "pack": "sister-mods"
    },
    "wa-diary": {
      "pack": "sister-mods"
    },
    "wa-door-rescue": {
      "pack": "sister-mods"
    },
    "wa-editor": {
      "pack": "sister-mods"
    },
    "wa-ending": {
      "pack": "sister-mods"
    },
    "wa-exhibition-thrill": {
      "pack": "sister-mods"
    },
    "wa-fear-pressure": {
      "pack": "sister-mods"
    },
    "wa-feeling-label": {
      "pack": "sister-mods"
    },
    "wa-flirt-followup": {
      "pack": "sister-mods"
    },
    "wa-force-tuning": {
      "pack": "sister-mods"
    },
    "wa-guard-core": {
      "pack": "sister-mods"
    },
    "wa-guard-data": {
      "pack": "sister-mods"
    },
    "wa-guard-patrol": {
      "pack": "sister-mods"
    },
    "wa-guard-watch": {
      "pack": "sister-mods"
    },
    "wa-inner-voice": {
      "pack": "sister-mods"
    },
    "wa-kitchen-call": {
      "pack": "sister-mods"
    },
    "wa-layout": {
      "pack": "sister-mods"
    },
    "wa-outrage": {
      "pack": "sister-mods"
    },
    "wa-patron-arousal": {
      "pack": "sister-mods"
    },
    "wa-patron-blackmail": {
      "pack": "sister-mods"
    },
    "wa-patron-flash": {
      "pack": "sister-mods"
    },
    "wa-patron-grope": {
      "pack": "sister-mods"
    },
    "wa-patron-sex-variants": {
      "pack": "sister-mods"
    },
    "wa-payday": {
      "pack": "sister-mods"
    },
    "wa-private-norm": {
      "pack": "sister-mods"
    },
    "wa-rescue-return": {
      "pack": "sister-mods"
    },
    "wa-scene-walkin": {
      "pack": "sister-mods"
    },
    "wa-shake-off": {
      "pack": "sister-mods"
    },
    "wa-short-nap": {
      "pack": "sister-mods"
    },
    "wa-sibling-calm": {
      "pack": "sister-mods"
    },
    "wa-sister-voice": {
      "pack": "sister-mods"
    },
    "wa-sister-voice-data": {
      "pack": "sister-mods"
    },
    "wa-step-down": {
      "pack": "sister-mods"
    },
    "wa-stepin-respect": {
      "pack": "sister-mods"
    },
    "wa-stepsister": {
      "pack": "sister-mods"
    },
    "wa-submission": {
      "pack": "sister-mods"
    },
    "wa-touting": {
      "pack": "sister-mods"
    },
    "wa-trait-ebb": {
      "pack": "sister-mods"
    },
    "wa-wife-initiative": {
      "pack": "sister-mods"
    },
    "wa-yield-habit": {
      "pack": "sister-mods"
    }
  },
  "notices": [
    {
      "id": "large-save-storage/backup-missing",
      "mod": "large-save-storage",
      "versions": [
        "1.0.0"
      ],
      "cause": "mod",
      "severity": "high",
      "minWml": "0.8.0",
      "since": "0.8.0",
      "title": {
        "ko": "백업 파일에 저장 칸 세이브가 빠져요",
        "en": "Backups miss the save slots"
      },
      "condition": {
        "ko": "켜 둔 채 세이브·설정을 내보낼 때",
        "en": "Exporting saves & settings while it is on"
      },
      "impact": {
        "ko": "수동 저장 칸·날짜 복원본이 백업 파일에 안 들어가요. 이어하기는 들어가요.",
        "en": "Manual slots and day-start saves are not in the backup file. The current game is."
      },
      "support": {
        "ko": "내보낼 때 \"빠진 저장소\"로 표시해요.",
        "en": "The export lists it as a missing database."
      },
      "fix": {
        "ko": "WML.define에 backup: { indexedDB: ['wayward-wml-saves-v1'] } 추가, api.backup.beforeExport로 저장 마무리.",
        "en": "Add backup: { indexedDB: ['wayward-wml-saves-v1'] } to WML.define; finish pending writes in api.backup.beforeExport."
      },
      "code": "backup: { indexedDB: ['wayward-wml-saves-v1'] },\n// in setup:\nif (api.backup && typeof api.backup.beforeExport === 'function') api.backup.beforeExport(async () => { await flush(); if (failures.size) throw new Error(`${failures.size} save(s) not written yet`); });"
    },
    {
      "id": "large-save-storage/restore-compare",
      "mod": "large-save-storage",
      "versions": [
        "1.0.0"
      ],
      "cause": "loader",
      "severity": "medium",
      "minWml": "0.7.0",
      "since": "0.8.0",
      "title": {
        "ko": "'localStorage로 되돌리기' 가 압축된 새 세이브를 실패로 셈",
        "en": "'Restore to localStorage' counts compressed new saves as failed"
      },
      "condition": {
        "ko": "save-compress와 같이 켠 채 저장한 칸을 되돌릴 때",
        "en": "Restoring a slot saved while save-compress was on"
      },
      "impact": {
        "ko": "\"N개 남음\"이라고 나오지만 실제로는 저장됐어요. 세이브 손실 없음.",
        "en": "It says 'N remain', but they were written. No save is lost."
      },
      "support": {
        "ko": "로더가 대신 고칠 수 없어요.",
        "en": "WML cannot fix this for the mod."
      },
      "fix": {
        "ko": "되돌린 뒤 확인하는 비교를 WML.rawGetItem(key) 로 바꿔요 (WML 0.7.0 이상).",
        "en": "Compare with WML.rawGetItem(key) when checking the restored value (WML 0.7.0 or later)."
      },
      "code": "if ((globalThis.WML && typeof WML.rawGetItem === 'function' ? WML.rawGetItem(key) : previous.getItem.call(localStorage, key)) !== value) throw new Error('localStorage verification failed');"
    },
    {
      "id": "large-save-storage/day-starts-kept",
      "mod": "large-save-storage",
      "versions": [
        "1.0.0"
      ],
      "cause": "mod",
      "severity": "low",
      "since": "0.8.0",
      "title": {
        "ko": "날짜 시작 복원본은 최근 5개만 남아요",
        "en": "Only the last 5 day-start saves are kept"
      },
      "condition": {
        "ko": "켜 두는 동안",
        "en": "While it is on"
      },
      "impact": {
        "ko": "더 오래된 날짜 복원본은 지워져요. 수동 저장 칸은 그대로예요.",
        "en": "Older day-start saves are deleted. Manual slots are kept."
      },
      "support": {
        "ko": "오래된 날짜가 필요하면 수동 저장 칸에 저장해 주세요.",
        "en": "To keep an older day, save it to a manual slot."
      }
    },
    {
      "id": "addon-compat/2.1.0-wrong-names",
      "mod": "addon-compat",
      "versions": [
        "2.1.0"
      ],
      "cause": "mod",
      "severity": "medium",
      "since": "0.8.0",
      "title": {
        "ko": "함수 이름 두 개가 틀려요 (게임 2026-10-04)",
        "en": "Two wrong function names (game 2026-10-04)"
      },
      "condition": {
        "ko": "옛 애드온(badguest 등)이 옷 착용·쫓겨난 밤 판정을 쓸 때",
        "en": "When old add-ons (badguest and others) check worn clothes or the turned-out night"
      },
      "impact": {
        "ko": "옷 착용·쫓겨난 밤 판정이 틀려요 (오류는 안 나요).",
        "en": "Those checks come out wrong, without errors."
      },
      "support": {
        "ko": "WML 모드팩의 addon-compat 2.0.1을 써 주세요.",
        "en": "Use addon-compat 2.0.1 from the WML mod pack."
      },
      "fix": {
        "ko": "__E.Ir(her.outfit, her.exposure, p) → __E.vr(…), __E.no(e.slot) → __E.co(e.slot) (게임 2026-10-04).",
        "en": "__E.Ir(her.outfit, her.exposure, p) → __E.vr(…), __E.no(e.slot) → __E.co(e.slot) (game 2026-10-04)."
      }
    }
  ]
});
