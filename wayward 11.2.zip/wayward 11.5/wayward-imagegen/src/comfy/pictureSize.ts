/**
 * What a render request asks ComfyUI for beyond its prompt: the generation
 * overrides and the picture's size.
 *
 * One function for both doors work comes in by — a picture the player is
 * waiting on (`/api/image/generate`) and an overnight batch item — so a queued
 * render of a key is the same picture as the live one. The batch door used to
 * drop the size, and every overnight picture came out square.
 */

import type { GenOverrides } from './workflows/index.ts'

/**
 * ComfyUI's dimension presets are matched by exact string, so these cannot be
 * generated from the numbers. The presets are landscape and the workflow
 * turns every requested one upright (`invert`), so a portrait asked for either
 * way round, 1216x832 or 832x1216, is drawn 832 wide and 1216 tall.
 */
const KNOWN_DIMS: Record<string, string> = {
  '512x512': '512 x 512 (1:1)',
  '768x512': '768 x 512 (1.5:1)',
  '960x512': '960 x 512 (1.875:1)',
  '1024x512': '1024 x 512 (2:1)',
  '1024x576': '1024 x 576 (1.778:1)',
  '1536x640': '1536 x 640 (2.4:1)',
  '1344x768': '1344 x 768 (1.75:1)',
  '1216x832': '1216 x 832 (1.46:1)',
  '832x1216': '1216 x 832 (1.46:1)',
  '1152x896': '1152 x 896 (1.286:1)',
  '1024x1024': '1024 x 1024 (1:1)',
}

/** The game's picture of her: 832 wide, 1216 tall. A request with no size, or
 *  a size with no preset, is drawn at it rather than at the workflow's square. */
export const GAME_PICTURE_DIMENSIONS = KNOWN_DIMS['1216x832']

export interface SizeAsked {
  width?: number
  height?: number
  /** A preset string, passed straight through. */
  dimensions?: string
}

export function resolveDimensions(asked: SizeAsked): string {
  if (asked.dimensions) return asked.dimensions
  if (!asked.width || !asked.height) return GAME_PICTURE_DIMENSIONS
  return KNOWN_DIMS[`${asked.width}x${asked.height}`] ?? GAME_PICTURE_DIMENSIONS
}

export interface RenderAsked extends SizeAsked {
  steps?: number
  cfg?: number
  loraStrength?: number
  checkpoint?: string
}

export function renderOverrides(asked: RenderAsked): GenOverrides {
  return {
    steps: asked.steps,
    cfg: asked.cfg,
    loraStrength: asked.loraStrength,
    checkpoint: asked.checkpoint,
    dimensions: resolveDimensions(asked),
  }
}
