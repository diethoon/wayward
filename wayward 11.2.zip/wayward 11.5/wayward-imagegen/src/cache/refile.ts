/**
 * Moving renders out of `characters/unknown/` once their key names a folder.
 *
 * Before the key decided the folder, every wife built in the game had her
 * pictures filed under `unknown`, all of them together. A wife's folder is her
 * art, so on startup each such file goes where its key says it belongs. Run
 * once per start; a library with nothing in `unknown` costs one pass over the
 * index.
 */

import * as fs from 'node:fs'
import * as path from 'node:path'
import type { CacheStore } from './cacheStore.ts'
import type { HitStore } from './hitStore.ts'
import { extractCharacterName } from '../naming.ts'
import { safeJoin } from './paths.ts'

const IN_UNKNOWN = /^([^/]+)\/characters\/unknown\/([^/]+)$/

/** Returns how many entries now point at their own character's folder. */
export function refileUnknown(cache: CacheStore, hits: HitStore, characters: readonly string[]): number {
  let moved = 0
  for (const [key, entry] of Object.entries(cache.entries)) {
    const m = IN_UNKNOWN.exec(entry.imagePath)
    if (!m) continue
    const who = extractCharacterName(entry.talentName, characters)
    if (!who || who === 'unknown') continue

    const [, workflow, file] = m
    const to = `${workflow}/characters/${who}/${file}`
    let fromAbs: string
    let toAbs: string
    try {
      fromAbs = safeJoin(cache.imagesDir, entry.imagePath)
      toAbs = safeJoin(cache.imagesDir, to)
    } catch {
      continue
    }
    try {
      if (fs.existsSync(fromAbs) && !fs.existsSync(toAbs)) {
        fs.mkdirSync(path.dirname(toAbs), { recursive: true })
        fs.renameSync(fromAbs, toAbs)
      }
      // Two entries can share one file; the second finds it already moved.
      if (!fs.existsSync(toAbs)) continue
    } catch (err) {
      console.warn(`[cache] could not refile ${entry.imagePath}:`, (err as Error).message)
      continue
    }
    hits.rename(entry.imagePath, to)
    cache.repoint(key, to)
    moved++
  }
  if (moved > 0) {
    cache.save()
    hits.flush()
    console.log(`[cache] refiled ${moved} picture${moved === 1 ? '' : 's'} out of characters/unknown`)
  }
  return moved
}
