/**
 * The image generation routes — the ones the game actually calls.
 *
 * Wire-compatible with what the game already sends, with one deliberate change:
 * responses carry a URL (`imageUrl`) rather than a base64 data URL. The old
 * shape meant 1-3 MB of JSON per image, no browser caching, and an image the
 * client could not address or re-find after a reload. `?inline=1` restores the
 * old behaviour for callers that genuinely want bytes.
 */

import * as fs from 'node:fs'
import * as path from 'node:path'
import type { Config, WorkflowType } from '../config.ts'
import type { CacheStore, CacheEntry } from '../cache/cacheStore.ts'
import type { JobRunner, GenerationJob } from '../comfy/jobRunner.ts'
import { derivePromptHash, jobKey, lookFingerprint } from '../naming.ts'
import { Router, sendJson, HttpError } from '../http/router.ts'
import { readJson, JSON_BODY_LIMIT } from '../http/body.ts'
import { mimeFor } from '../http/static.ts'
import { renderOverrides } from '../comfy/pictureSize.ts'

const WORKFLOWS: readonly WorkflowType[] = ['illustrious', 'z-image']

export interface GenerateBody {
  talentId?: string
  talentName?: string
  imageType?: string
  prompt?: string
  negativePrompt?: string
  workflow?: string
  promptHash?: string
  seed?: number
  steps?: number
  cfg?: number
  loraStrength?: number
  checkpoint?: string
  width?: number
  height?: number
  dimensions?: string
  bulk?: boolean
  bypassCache?: boolean
  /** The wife's look fingerprint; see `lookFingerprint`. */
  look?: string
  debug?: Record<string, unknown>
}

export interface ImageRouteDeps {
  config: Config
  cache: CacheStore
  jobs: JobRunner
  /** Append a line to the cache-miss log. Injected so tests need no disk. */
  logMiss?: (line: Record<string, unknown>) => void
}

/**
 * The URL the client loads a render from, relative to the server root.
 *
 * Each segment is encoded separately so a filename containing a space or a
 * `#` survives, without turning the path separators into `%2F`.
 */
export function imageUrlFor(relativePath: string): string {
  return `/images/${relativePath.split('/').map(encodeURIComponent).join('/')}`
}

function sizeOf(cache: CacheStore, entry: CacheEntry): number {
  const full = cache.absolutePathOf(entry)
  if (!full) return 0
  try {
    return fs.statSync(full).size
  } catch {
    return 0
  }
}

function readAsDataUrl(cache: CacheStore, entry: CacheEntry): string | null {
  const full = cache.absolutePathOf(entry)
  if (!full) return null
  try {
    return `data:${mimeFor(full)};base64,${fs.readFileSync(full).toString('base64')}`
  } catch {
    return null
  }
}

/**
 * The identity of a render.
 *
 * The client normally sends its own `promptHash` so both sides agree. When it
 * does not, generation params are folded in — two requests with the same text
 * but different steps/cfg are different pictures and must not share a cell.
 */
export function resolvePromptHash(body: GenerateBody): string {
  if (body.promptHash) return body.promptHash
  return derivePromptHash(body.prompt ?? '', body.negativePrompt ?? '', body)
}

function jobResponse(job: GenerationJob, imagesDir: string, inline: boolean) {
  const base: Record<string, unknown> = {
    promptId: job.promptId,
    status: job.status,
    workflow: job.workflow,
  }
  if (job.error) base.error = job.error
  if (job.media) {
    base.imagePath = job.media.relativePath
    base.imageUrl = imageUrlFor(job.media.relativePath)
    base.bytes = job.media.bytes
    if (inline) {
      try {
        const buf = fs.readFileSync(path.join(imagesDir, job.media.relativePath))
        base.imageData = `data:${job.media.mime};base64,${buf.toString('base64')}`
      } catch { /* the URL is still usable */ }
    }
  }
  return base
}

export function registerImageRoutes(router: Router, deps: ImageRouteDeps): void {
  const { config, cache, jobs } = deps

  router.post('/api/image/generate', async ctx => {
    const body = await readJson<GenerateBody>(ctx.req, JSON_BODY_LIMIT)

    const talentName = body.talentName ?? body.talentId
    if (!talentName) throw new HttpError(400, 'talentId is required')
    const prompt = body.prompt
    if (typeof prompt !== 'string' || prompt.length === 0) {
      throw new HttpError(400, 'prompt is required')
    }

    const workflow = (body.workflow ?? 'illustrious') as WorkflowType
    if (!WORKFLOWS.includes(workflow)) {
      throw new HttpError(400, `unknown workflow: ${workflow}. available: ${WORKFLOWS.join(', ')}`)
    }

    const imageType = body.imageType ?? 'portrait'
    const negativePrompt = body.negativePrompt ?? ''
    const promptHash = resolvePromptHash(body)
    const bulk = body.bulk === true
    const bypassCache = body.bypassCache === true
    const inline = ctx.query.get('inline') === '1'

    // The refresh button: the player said this image is bad. Drop EVERY entry
    // for this talentName, not just the matching hash — prompts drift between
    // sessions, so one state routinely has several hashes, and leaving the
    // others alive means the bad image reappears on the next remount.
    if (bypassCache) {
      let dropped = 0
      for (const [key, entry] of Object.entries(cache.entries)) {
        if (entry.talentName !== talentName) continue
        const full = cache.absolutePathOf(entry)
        if (full && fs.existsSync(full)) {
          try { fs.unlinkSync(full) } catch { /* the entry still goes */ }
        }
        cache.remove(key)
        dropped++
      }
      if (dropped > 0) console.log(`[generate] bypass dropped ${dropped} entr(y/ies) for ${talentName}`)
    }

    const cached = bypassCache ? null : cache.get(talentName, imageType, promptHash, workflow)
    if (cached) {
      const response: Record<string, unknown> = {
        promptId: `cached_${promptHash}`,
        status: 'completed',
        workflow,
        cached: true,
        imagePath: cached.imagePath,
        imageUrl: imageUrlFor(cached.imagePath),
        // Reported so a caller does not have to fetch the bytes just to size
        // them — the bulk runner tallies this per image.
        bytes: sizeOf(cache, cached),
      }
      if (inline) {
        const data = readAsDataUrl(cache, cached)
        if (data) response.imageData = data
      }
      sendJson(ctx.res, 200, response)
      return
    }

    // Only genuine runtime misses are logged: not batch work, not an explicit
    // regen. That keeps the log answering one question — the game asked for
    // something new, was it a truly new state or the same state under a drifted
    // prompt? See `gin images cache-audit`.
    if (!bulk && !bypassCache && deps.logMiss) {
      let priorVariants = 0
      for (const [k, e] of Object.entries(cache.entries)) {
        if (e.talentName === talentName && e.imageType === imageType && k.startsWith(workflow + '_')) {
          priorVariants++
        }
      }
      deps.logMiss({
        at: new Date().toISOString(),
        kind: priorVariants > 0 ? 'drift' : 'new',
        priorVariants,
        talentName,
        imageType,
        workflow,
        promptHash,
        prompt: prompt.slice(0, 300),
      })
    }

    // Bound the damage a runaway or hostile caller can do.
    //
    // The rate ceilings apply to INTERACTIVE work only. Batch work is the
    // operator's own overnight run — it has its own queue and paces itself, and
    // throttling it at a few hundred an hour would quietly stall the
    // pre-generation this server exists to do.
    if (!bulk) {
      if (jobs.queuedCount() >= config.maxQueued) {
        throw new HttpError(429, `too many queued requests (${config.maxQueued})`)
      }
      if (config.maxImagesPerHour > 0 && jobs.completionsThisHour() >= config.maxImagesPerHour) {
        throw new HttpError(429, `hourly image limit reached (${config.maxImagesPerHour})`)
      }
    }
    // The disk ceiling DOES apply to everything: filling the drive is just as
    // bad whoever asked for it.
    if (config.maxDiskGb > 0) {
      const usedGb = cache.diskUsageBytes() / 1024 ** 3
      if (usedGb >= config.maxDiskGb) {
        throw new HttpError(507, `art library is at the ${config.maxDiskGb} GB ceiling`)
      }
    }

    const job = await jobs.submit({
      talentId: body.talentId ?? talentName,
      talentName,
      imageType,
      prompt,
      negativePrompt,
      workflow,
      promptHash,
      seed: body.seed,
      overrides: renderOverrides(body),
      bulk,
      look: lookFingerprint(body.look),
      debug: body.debug,
    })

    sendJson(ctx.res, 200, jobResponse(job, config.imagesDir, inline))
  })

  router.get('/api/image/status/:promptId', ctx => {
    const { promptId } = ctx.params
    const job = jobs.get(promptId)
    if (!job) {
      // A completed job is reaped after its TTL. 404 is honest: we no longer
      // know. The client falls back to the catalogue, which by then has it.
      throw new HttpError(404, 'unknown promptId')
    }
    const inline = ctx.query.get('inline') === '1'
    const body = jobResponse(job, config.imagesDir, inline)
    // 202 while pending keeps a polling client from treating "not yet" as done.
    sendJson(ctx.res, job.status === 'queued' || job.status === 'processing' ? 202 : 200, body)
  })

  router.post('/api/image/cancel', async ctx => {
    const body = await readJson<{ promptId?: string }>(ctx.req)
    if (!body.promptId) throw new HttpError(400, 'promptId is required')
    const result = await jobs.cancel(body.promptId)
    sendJson(ctx.res, 200, { status: 'ok', ...result })
  })

  router.get('/api/image/check', ctx => {
    const name = ctx.query.get('name')
    const hash = ctx.query.get('hash')
    if (!name || !hash) throw new HttpError(400, 'name and hash are required')
    const imageType = ctx.query.get('type') ?? 'portrait'
    const workflow = (ctx.query.get('workflow') ?? 'illustrious') as WorkflowType

    const entry = cache.get(name, imageType, hash, workflow)
    if (!entry) {
      sendJson(ctx.res, 200, { exists: false })
      return
    }
    const response: Record<string, unknown> = {
      exists: true,
      cached: true,
      imagePath: entry.imagePath,
      imageUrl: imageUrlFor(entry.imagePath),
    }
    if (ctx.query.get('inline') === '1') {
      const data = readAsDataUrl(cache, entry)
      if (data) response.imageData = data
    }
    sendJson(ctx.res, 200, response)
  })

  // Deleting art is off unless the operator asks for it. Nothing in the game
  // needs it; it exists for the review UI, on a machine whose owner opted in.
  router.delete('/api/image/delete', ctx => {
    if (!config.allowDelete) {
      throw new HttpError(403, 'deletion is disabled; start with --allow-delete to enable it')
    }
    const name = ctx.query.get('name')
    if (!name) throw new HttpError(400, 'name is required')
    const imageType = ctx.query.get('type') ?? 'portrait'
    const workflow = ctx.query.get('workflow') ?? 'illustrious'

    let deleted = 0
    for (const [key, entry] of Object.entries(cache.entries)) {
      if (entry.talentName !== name) continue
      if (entry.imageType !== imageType) continue
      if (!key.startsWith(workflow + '_')) continue
      const full = cache.absolutePathOf(entry)
      if (full && fs.existsSync(full)) {
        try { fs.unlinkSync(full) } catch { /* the entry still goes */ }
      }
      // Removing the entry as well as the file — the dev server deleted files
      // but left the index pointing at them, which produced phantom entries
      // that every later consumer had to filter out.
      cache.remove(key)
      deleted++
    }
    sendJson(ctx.res, 200, { deleted })
  })
}

/** Exposed for the health route's queue summary. */
export function describeJobs(jobs: JobRunner): Record<string, unknown> {
  const active = jobs.activeJobs()
  return {
    active: active.length,
    queued: jobs.queuedCount(),
    completedThisHour: jobs.completionsThisHour(),
    keys: active.slice(0, 20).map(j => jobKey(j.talentName, j.imageType, j.promptHash, j.workflow)),
  }
}
