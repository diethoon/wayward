/**
 * Built wives: the game registers one when she is saved, and asks how her
 * pictures stand. See `wives/builtWives.ts`.
 *
 * Like every route here, any local page can call these. What is bounded is the
 * damage: an id must be a plain folder name that is not a starter's or shared
 * art's, the record is capped at `MAX_RECORD_BYTES`, and the only file written
 * is that wife's own `pack.json`.
 */

import { once } from 'node:events'
import { Router, sendJson, HttpError } from '../http/router.ts'
import { readJson } from '../http/body.ts'
import { MAX_RECORD_BYTES, type BuiltWives } from '../wives/builtWives.ts'
import { ZipTooLargeError } from '../wives/storeZip.ts'

export function registerWifeRoutes(router: Router, wives: BuiltWives): void {
  router.post('/api/wives/:id', async ctx => {
    const body = await readJson<Record<string, unknown>>(ctx.req, MAX_RECORD_BYTES)
    const record = wives.parseRecord(ctx.params.id, body)
    if (typeof record === 'string') throw new HttpError(400, record)
    sendJson(ctx.res, 200, wives.register(record))
  })

  /** Her pack as a download: what "Share her" in the game links to. */
  router.get('/api/wives/:id/pack.zip', async ctx => {
    if (!wives.isBuiltWifeId(ctx.params.id)) throw new HttpError(400, 'not a built wife id')
    let plan
    try {
      plan = wives.sharePlan(ctx.params.id)
    } catch (err) {
      if (err instanceof ZipTooLargeError) throw new HttpError(413, `her pack is too large for one zip (${err.message})`)
      throw err
    }
    if (!plan) throw new HttpError(404, 'no such wife registered')
    ctx.res.writeHead(200, {
      'Content-Type': 'application/zip',
      'Content-Length': plan.bytes,
      'Content-Disposition': `attachment; filename="${shareFileName(plan.wife.name, plan.wife.id)}"`,
      'Cache-Control': 'no-store',
    })
    await wives.writeShare(plan, async chunk => {
      if (!ctx.res.write(chunk)) await once(ctx.res, 'drain')
    })
    ctx.res.end()
  })

  router.get('/api/wives/:id', ctx => {
    if (!wives.isBuiltWifeId(ctx.params.id)) throw new HttpError(400, 'not a built wife id')
    sendJson(ctx.res, 200, wives.pictures(ctx.params.id))
  })
}

/** `wayward-wife-rosalind-2026-10-07.zip`, dated in the player's own day; the id
 *  stands in for a name with no letters. */
export function shareFileName(name: string, id: string, now = new Date()): string {
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || id
  const day = [now.getFullYear(), now.getMonth() + 1, now.getDate()].map(n => String(n).padStart(2, '0')).join('-')
  return `wayward-wife-${slug}-${day}.zip`
}
