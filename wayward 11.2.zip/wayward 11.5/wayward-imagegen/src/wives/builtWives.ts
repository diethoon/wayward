/**
 * Wives built in the game, as this server knows them.
 *
 * A built wife's folder (`<workflow>/characters/<id>/`) holds her pictures. The
 * game registers her here when she is saved; from then on `pack.json` sits in
 * that folder beside them, naming her and listing one picture per image key,
 * so the folder IS her image pack: zip it and another player can install it.
 *
 * Her record is the game's to interpret (`inputs` is opaque here). What this
 * server adds is the list of pictures, and which of them were drawn from her
 * current look: each render records the look fingerprint the game sent
 * (`CacheEntry.look`), and a picture with a different one is from before she
 * changed. A picture with none predates the fingerprint and counts as current.
 */

import * as fs from 'node:fs'
import * as path from 'node:path'
import type { CacheEntry, CacheStore } from '../cache/cacheStore.ts'
import { lookFingerprint } from '../naming.ts'
import { safeJoin } from '../cache/paths.ts'
import { StoreZip, ZipTooLargeError } from './storeZip.ts'

/** The shape of `pack.json`. Bumped only on a breaking change. */
export const WIFE_PACK_FORMAT = 2
/** The image-key vocabulary the entries are written in; the game owns its meaning. */
export const KEY_VERSION = 1
export const PACK_FILE = 'pack.json'
const WORKFLOW = 'illustrious'
const WIFE_ID = /^[a-z0-9_]{1,64}$/
/** A build is a date, with an optional prerelease suffix (2026-10-24-pre7); the pack keeps the date. */
const BUILD_DATE = /^(\d{4}-\d{2}-\d{2})(?:-[a-z0-9.]{1,32})?$/i
/** A record bigger than this is not a wife; the builder's inputs are a few KB. */
export const MAX_RECORD_BYTES = 64 * 1024
const WRITE_DEBOUNCE_MS = 5_000

export interface BuiltWifeRecord {
  id: string
  name: string
  /** When the player last saved her, in the game's clock. */
  updatedAt: number
  /** Her look fingerprint now. */
  look: string
  /** The game build that registered her (YYYY-MM-DD). */
  madeFor: string
  /** The builder's inputs. The game derives her from these. */
  inputs: unknown
}

export interface WifePack {
  packFormat: number
  keyVersion: number
  madeFor: string
  id: string
  name: string
  /** The folder the pack unzips to; the same as `id`. */
  folder: string
  wife: BuiltWifeRecord
  entryCount: number
  /** Image key → picture file, relative to this folder. */
  entries: Record<string, string>
}

export interface WifePictures {
  registered: boolean
  /** Image keys with a picture from her current look. */
  current: number
  /** Image keys whose only pictures are from an earlier look. */
  oldLook: string[]
}

export interface ShareFile { name: string; path: string }

export interface SharePlan {
  wife: BuiltWifeRecord
  files: ShareFile[]
  /** The zip's exact size. */
  bytes: number
}

/** Does a verdict say this picture is wrong? Supplied by the review store. */
export type RejectedFn = (cacheKey: string) => boolean

export class BuiltWives {
  private readonly pending = new Map<string, ReturnType<typeof setTimeout>>()

  constructor(
    private readonly cache: CacheStore,
    /** Folder names that are not built wives: the starters and shared art. */
    private readonly reserved: readonly string[],
    private readonly rejected: RejectedFn = () => false,
    private readonly debounceMs = WRITE_DEBOUNCE_MS,
  ) {}

  isBuiltWifeId(id: string): boolean {
    return WIFE_ID.test(id) && !this.reserved.includes(id)
  }

  /** Check a record from the wire; returns it normalised, or a reason it is not one. */
  parseRecord(id: string, body: Record<string, unknown>): BuiltWifeRecord | string {
    if (!this.isBuiltWifeId(id)) return 'not a built wife id'
    const look = lookFingerprint(body.look)
    if (!look) return 'look is required'
    if (typeof body.name !== 'string' || body.name.length > 200) return 'name is required'
    if (typeof body.updatedAt !== 'number' || !Number.isFinite(body.updatedAt)) return 'updatedAt is required'
    const built = typeof body.madeFor === 'string' ? BUILD_DATE.exec(body.madeFor) : null
    if (!built) return 'madeFor must be YYYY-MM-DD, with an optional -suffix'
    if (body.inputs === undefined) return 'inputs are required'
    return { id, name: body.name, updatedAt: body.updatedAt, look, madeFor: built[1], inputs: body.inputs }
  }

  /** Remember her (or her new look) and write her pack now. */
  register(record: BuiltWifeRecord): WifePictures {
    const known = this.record(record.id)
    if (!known || JSON.stringify(known) !== JSON.stringify(record)) this.write(record)
    return this.pictures(record.id)
  }

  /** Her record, if she has been registered. */
  record(id: string): BuiltWifeRecord | null {
    if (!this.isBuiltWifeId(id)) return null
    try {
      const pack = JSON.parse(fs.readFileSync(this.packPath(id), 'utf-8')) as Partial<WifePack>
      return pack.wife && pack.wife.id === id ? pack.wife : null
    } catch {
      return null
    }
  }

  pictures(id: string): WifePictures {
    const wife = this.record(id)
    if (!wife) return { registered: false, current: 0, oldLook: [] }
    const byKey = this.entriesOf(id)
    let current = 0
    const oldLook: string[] = []
    for (const [talentName, renders] of byKey) {
      if (renders.some(r => isCurrent(r.entry, wife))) current++
      // Only game keys can be redrawn; a builder preview is not one.
      else if (talentName.includes('__')) oldLook.push(talentName)
    }
    return { registered: true, current, oldLook: oldLook.sort() }
  }

  /** A render landed. If it is a registered wife's, rewrite her pack soon. */
  touched(entry: CacheEntry): void {
    const m = /^[^/]+\/characters\/([^/]+)\//.exec(entry.imagePath)
    const id = m?.[1]
    if (!id || !this.isBuiltWifeId(id) || this.pending.has(id)) return
    this.pending.set(id, setTimeout(() => {
      this.pending.delete(id)
      const wife = this.record(id)
      if (wife) this.write(wife)
    }, this.debounceMs))
  }

  /** Write anything still waiting. For shutdown and tests. */
  flush(): void {
    for (const [id, timer] of this.pending) {
      clearTimeout(timer)
      this.pending.delete(id)
      const wife = this.record(id)
      if (wife) this.write(wife)
    }
  }

  /** Her pack as it would be written now. */
  buildPack(wife: BuiltWifeRecord): WifePack {
    const prefix = `${WORKFLOW}/characters/${wife.id}/`
    const onDisk = this.cache.existingImagePaths()
    const entries: Record<string, string> = {}
    for (const [talentName, candidates] of this.entriesOf(wife.id)) {
      const best = candidates
        .filter(r => isCurrent(r.entry, wife) && onDisk.has(r.entry.imagePath) && !this.rejected(r.key))
        .sort((a, b) => b.entry.createdAt - a.entry.createdAt)[0]
      if (best) entries[talentName] = best.entry.imagePath.slice(prefix.length)
    }
    return {
      packFormat: WIFE_PACK_FORMAT,
      keyVersion: KEY_VERSION,
      madeFor: wife.madeFor,
      id: wife.id,
      name: wife.name,
      folder: wife.id,
      wife,
      entryCount: Object.keys(entries).length,
      entries,
    }
  }

  /**
   * Her pack as one zip: `<folder>/pack.json` and every picture it lists, under
   * the folder it unzips to. Writes `pack.json` first so the zip and the folder
   * agree. Returns null when she is not registered.
   */
  sharePlan(id: string): SharePlan | null {
    const wife = this.record(id)
    if (!wife) return null
    this.write(wife)
    const pack = this.buildPack(wife)
    const files: ShareFile[] = [{ name: `${pack.folder}/${PACK_FILE}`, path: this.packPath(id) }]
    for (const file of new Set(Object.values(pack.entries))) {
      files.push({ name: `${pack.folder}/${file}`, path: safeJoin(this.cache.imagesDir, `${WORKFLOW}/characters/${id}/${file}`) })
    }
    let bytes = 22
    for (const f of files) {
      const name = Buffer.byteLength(f.name)
      bytes += 30 + name + fs.statSync(f.path).size + 46 + name
    }
    if (bytes > 0xffffffff || files.length > 0xffff) throw new ZipTooLargeError(`${files.length} files, ${bytes} bytes`)
    return { wife, files, bytes }
  }

  /** Stream a share plan's zip to `sink`. */
  async writeShare(plan: SharePlan, sink: (chunk: Buffer) => Promise<void>): Promise<void> {
    const zip = new StoreZip(sink)
    for (const f of plan.files) await zip.add(f.name, await fs.promises.readFile(f.path))
    await zip.finish()
  }

  private write(wife: BuiltWifeRecord): void {
    const file = this.packPath(wife.id)
    try {
      fs.mkdirSync(path.dirname(file), { recursive: true })
      const tmp = `${file}.tmp`
      fs.writeFileSync(tmp, JSON.stringify(this.buildPack(wife), null, 1))
      fs.renameSync(tmp, file)
    } catch (err) {
      console.error(`[wives] could not write ${wife.id}/${PACK_FILE}:`, (err as Error).message)
    }
  }

  /** Her renders with their cache keys, grouped by image key. */
  private entriesOf(id: string): Map<string, { key: string; entry: CacheEntry }[]> {
    const prefix = `${WORKFLOW}/characters/${id}/`
    const byKey = new Map<string, { key: string; entry: CacheEntry }[]>()
    for (const [key, entry] of Object.entries(this.cache.entries)) {
      if (!entry.imagePath.startsWith(prefix)) continue
      const list = byKey.get(entry.talentName)
      if (list) list.push({ key, entry })
      else byKey.set(entry.talentName, [{ key, entry }])
    }
    return byKey
  }

  private packPath(id: string): string {
    return safeJoin(this.cache.imagesDir, `${WORKFLOW}/characters/${id}/${PACK_FILE}`)
  }
}

function isCurrent(entry: CacheEntry, wife: BuiltWifeRecord): boolean {
  return entry.look === undefined || entry.look === wife.look
}
