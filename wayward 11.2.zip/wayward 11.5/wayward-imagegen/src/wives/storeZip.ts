/**
 * Writing a zip with no compression, a file at a time, to any sink.
 *
 * A wife's pack is WebP pictures, which deflate cannot shrink, so "store" is
 * the whole job; this server spawns no programs, so it cannot hand the work to
 * `tar` the way the release scripts do. Plain zip, not zip64: a sink that would
 * pass 4 GB or 65,535 files is refused before anything is written past it.
 */

const LOCAL_HEADER = 0x04034b50
const CENTRAL_HEADER = 0x02014b50
const END_OF_CENTRAL = 0x06054b50
/** Bit 11: the names are UTF-8. */
const UTF8_NAMES = 0x0800
const ZIP_LIMIT = 0xffffffff
const MAX_FILES = 0xffff

const CRC_TABLE = (() => {
  const table = new Uint32Array(256)
  for (let n = 0; n < 256; n++) {
    let c = n
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    table[n] = c >>> 0
  }
  return table
})()

export function crc32(data: Uint8Array): number {
  let c = 0xffffffff
  for (let i = 0; i < data.length; i++) c = CRC_TABLE[(c ^ data[i]) & 0xff] ^ (c >>> 8)
  return (c ^ 0xffffffff) >>> 0
}

export class ZipTooLargeError extends Error {}

interface Written { name: Buffer; crc: number; size: number; offset: number }

export class StoreZip {
  private readonly files: Written[] = []
  private offset = 0
  private readonly time: number
  private readonly date: number

  constructor(private readonly sink: (chunk: Buffer) => Promise<void>, now = new Date()) {
    this.time = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1)
    this.date = ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate()
  }

  /** Bytes written so far. */
  get size(): number { return this.offset }

  async add(name: string, data: Buffer): Promise<void> {
    const nameBytes = Buffer.from(name, 'utf-8')
    const headerSize = 30 + nameBytes.length
    if (this.files.length >= MAX_FILES || this.offset + headerSize + data.length > ZIP_LIMIT) {
      throw new ZipTooLargeError('too large for one zip')
    }
    const crc = crc32(data)
    const header = Buffer.alloc(headerSize)
    header.writeUInt32LE(LOCAL_HEADER, 0)
    header.writeUInt16LE(20, 4)
    header.writeUInt16LE(UTF8_NAMES, 6)
    header.writeUInt16LE(0, 8)
    header.writeUInt16LE(this.time, 10)
    header.writeUInt16LE(this.date, 12)
    header.writeUInt32LE(crc, 14)
    header.writeUInt32LE(data.length, 18)
    header.writeUInt32LE(data.length, 22)
    header.writeUInt16LE(nameBytes.length, 26)
    header.writeUInt16LE(0, 28)
    nameBytes.copy(header, 30)
    this.files.push({ name: nameBytes, crc, size: data.length, offset: this.offset })
    await this.sink(header)
    await this.sink(data)
    this.offset += headerSize + data.length
  }

  async finish(): Promise<void> {
    const start = this.offset
    for (const f of this.files) {
      const entry = Buffer.alloc(46 + f.name.length)
      entry.writeUInt32LE(CENTRAL_HEADER, 0)
      entry.writeUInt16LE(20, 4)
      entry.writeUInt16LE(20, 6)
      entry.writeUInt16LE(UTF8_NAMES, 8)
      entry.writeUInt16LE(0, 10)
      entry.writeUInt16LE(this.time, 12)
      entry.writeUInt16LE(this.date, 14)
      entry.writeUInt32LE(f.crc, 16)
      entry.writeUInt32LE(f.size, 20)
      entry.writeUInt32LE(f.size, 24)
      entry.writeUInt16LE(f.name.length, 28)
      entry.writeUInt32LE(f.offset, 42)
      f.name.copy(entry, 46)
      await this.sink(entry)
      this.offset += entry.length
    }
    const end = Buffer.alloc(22)
    end.writeUInt32LE(END_OF_CENTRAL, 0)
    end.writeUInt16LE(this.files.length, 8)
    end.writeUInt16LE(this.files.length, 10)
    end.writeUInt32LE(this.offset - start, 12)
    end.writeUInt32LE(start, 16)
    await this.sink(end)
    this.offset += end.length
  }
}
