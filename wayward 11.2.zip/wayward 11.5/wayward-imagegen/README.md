# wayward-imagegen

Draw Wayward's pictures on your own computer.

The game ships with a library of images. This program lets you add to it: it
watches for pictures the game wants but does not have, renders them through your
own [ComfyUI](https://github.com/comfyanonymous/ComfyUI), and serves them back.
You can also leave it running overnight to fill in the pictures your playthrough
is likely to ask for before you get there.

It is a small HTTP server and nothing else. It does not modify the game, it does
not phone anywhere, and it never runs another program.

---

## Custom characters

A character you build in the game (New Game → **Build a character**) has no shipped
pictures; this program is what draws her. What you can do with one:

| | Where | Needs this server |
|---|---|---|
| Build her: looks, face anchor and its strength, story, a set personality | New Game → **Build a character** | Only for the preview |
| Play her | the character picker | No |
| Draw the pictures the other wives have, ahead of time | **Pictures** next to her on the character picker | Yes ([Making pictures ahead of time](#making-pictures-ahead-of-time)) |
| Redraw her pictures after you change how she looks | the character picker says how many; **Pictures** | Yes |
| Give her to another player, pictures included | **Share** next to her on the character picker, or under Settings → Image generation in a game | Yes ([Sharing a character you built](#sharing-a-character-you-built)) |
| Add a character someone gave you | title screen → **Image packs** | No |

Her pictures live in her own folder, `images/illustrious/characters/<her id>/`,
with a `pack.json` that says who she is.

---

## What you need

- **[Bun](https://bun.sh)** — one download, no configuration.
- **ComfyUI**, running, with a checkpoint installed. The shipped art was made
  with `waiIllustriousSDXL_v170` plus the `sdxl_lightning_8step` LoRA; anything
  else will work but will not look quite like the pictures you already have.
- A GPU with enough memory for that model. A render takes roughly five to
  fifteen seconds.
- **Three ComfyUI custom node packs**, installed through ComfyUI Manager. The
  shipped graph uses nodes from each, and without them ComfyUI will refuse it:
  - **ComfyUI Impact Pack** *(ltdrdata)*
  - **ComfyUI Inspire Pack** *(ltdrdata)*
  - **KJ Nodes for ComfyUI** *(kijai)*

Run `bun src/cli.ts doctor` to check all of this at once — see below.

## Running it

```
bun src/cli.ts
```

Then open the game and go to **Settings → Image generation**. On *Automatic* it
finds the server by itself and the status turns to "connected".

That is the whole setup. The game will now draw anything it does not already
have, while you play.

### If ComfyUI is somewhere else

```
bun src/cli.ts --comfy-url http://192.168.1.50:8188
```

### If port 8189 is taken

```
bun src/cli.ts --port 9000
```

Then set **Specific address** in the game's settings to `http://127.0.0.1:9000`.
The server will not quietly move to another port — a server the game cannot find
looks exactly like a broken one.

### Playing from your phone

```
bun src/cli.ts --host 0.0.0.0
```

Serve the game from the same machine (or open it on the phone from a file) and
the game finds the server at that machine's address on its own. Pages on your
own network are allowed to call it when it is bound this way — a page anywhere
else still is not. Use plain `http://` on the phone: a page loaded over
`https://` is not allowed to fetch from an `http://` server.

If nothing connects, the machine's firewall is the usual reason: allow `bun`
on private networks.

`bun src/cli.ts --help` lists every option.

## When pictures do not appear

```
bun src/cli.ts doctor
```

It answers, in order, the questions you cannot answer by looking: is ComfyUI
reachable, are the three node packs installed, can ComfyUI see the checkpoint
and LoRA under the exact filenames configured, and — the only proof that
counts — does one test render actually come back. Each failure names what to
change.

The commonest cause is a **checkpoint or LoRA filename that does not match**.
ComfyUI does not reject the whole job for that: it drops the part of the graph
that saves the picture, keeps the rest, and reports success about two
milliseconds later having rendered nothing. `doctor` catches it before you
spend an evening on it.

Pictures are stored as WebP when the `sharp` package loads, and as PNG
otherwise; both work. On Linux, run `bun install` once in this folder to get
WebP: without it Bun fetches a build of `sharp` that would hang the server, so
the server refuses it and says so at startup.

If it all passes and the game still shows no picture, check **Settings →
Image generation** in the game — it needs to be on *Automatic*, or *Specific
address* pointing here.

---

## Making pictures ahead of time

In the game: **Settings → Image generation → Make pictures ahead of time**.

Pick who, which pictures, how many, and start it. **What the other wives have**
makes her match the pictures the other wives already have, which is the
usual choice for a wife you built yourself. You can also press **Pictures** next
to her on the character picker. If you change how she looks, the picker says how many
of her pictures are from her old look, and **Redo the pictures from her old
look** draws them again. It works through the list most-likely-first,
so stopping early still leaves you with the pictures you were actually going to
see. You can keep playing while it runs — anything you look at is drawn first.

The whole space is tens of thousands of images, which is days of GPU time. The
panel tells you how long it thinks it will take. Leaving it overnight is the
intended use.

Progress survives a restart. If the machine reboots, it picks up where it left
off, paused, waiting for you to say continue.

---

## Reviewing what it made

Open <http://127.0.0.1:8189/> while the server is running.

One picture at a time: **Keep** (J) or **Redo** (K). Redo can carry a note about
what is wrong with it. Your verdict outranks anything automatic — if you say a
picture is wrong, it is wrong.

---

## Sharing a character you built

On the character picker, or in the character list under Settings → Image
generation (in a game too), **Share** next to her downloads her as one zip
(`wayward-wife-<name>-<date>.zip`): her description and every picture of her
current look, in a folder named after her. A picture is about 80 KB, so 3,000
pictures make a zip of about 240 MB, and a full set matching the other wives
about 1.2 GB.

To install one you were given, in the game: title screen → **Image packs**.
Unzip the zip into a folder named `packs` next to the game's html file, so you
have `packs/<her folder>/pack.json`, then press **Add a pack** and pick that
`pack.json`. She is then on the character picker. You do not need this server to
play her; it is only needed to draw more pictures of her.

To let players on the web version have her, unzip the zip somewhere that serves
files to other sites, such as a GitHub Pages site, and give them the address of
her `pack.json`. They paste it into **Image packs** in the game. A zip cannot be
added by its address, and some file-sharing sites do not let the game read the
file.

---

## Sending pictures back

If you make images you think belong in the game, you can offer them:

```
curl -X POST http://127.0.0.1:8189/api/contrib/export \
  -H 'Content-Type: application/json' \
  -d '{"onlyKept": true, "contributor": "your name"}'
```

That writes a folder under `<state-dir>/contributions/`. **Look through it
before you send it** — it contains your own images, including anything you
generated for yourself.

A bundle carries the pictures, the prompt each one answers, your verdicts, and
which model settings were used. That last part matters: an image made with a
different checkpoint is a different look, not a better or worse render.

Sending a bundle is you offering the images for use in the game.

---

## Where things go

```
<images-dir>/                       default ./images
  .image-cache.json                 which picture answers which request
  illustrious/characters/<who>/     the pictures, one folder per wife (a wife you
                                    built has her own, named by her id)
    pack.json                       in a built wife's folder: who she is and which
                                    picture answers each request, so the folder is
                                    her image pack
  videos/                           if you enabled video
<state-dir>/                        default <images-dir>/.state
  image-hits.json                   how often each picture has been shown
  review-progress.json              your verdicts
  batch/                            overnight queues, so they survive a restart
  contributions/                    export bundles
  cache-misses.jsonl                what the game asked for and did not have
```

Nothing is written outside these.

---

## Video

Off unless you turn it on, because it needs a workflow and models this does not
ship:

```
bun src/cli.ts --wan-workflow ./my-wan-i2v-workflow.json
```

Export an image-to-video workflow from ComfyUI in **API format**. The bundled
node ids are expected; a differently-built workflow will need its ids remapped,
and the server says which node it could not find rather than failing obscurely.

The game shows its video button (on the portrait, desktop width) only when the
server was started this way. After turning video on, press Check again in the
game's image server settings.

---

## Safety

It listens on `127.0.0.1` only — nothing outside your machine can reach it —
unless you pass `--host 0.0.0.0`, which opens it to every device on your
network. It runs no other programs, and writes nowhere but the folders above.

It does **not** ask who is calling. Any page open in your browser can reach a
server on your own machine; that is true of every local server and no header
check can distinguish one local page from another. What is bounded instead is
the damage: there are caps on how many images an hour it will draw, how deep the
queue can get, and optionally how large the library may grow
(`--max-disk-gb`). Deleting images is off unless you pass `--allow-delete`.

If you would rather it not be reachable at all while you are not using it, stop
it.

---

## Modifying it

It is plain TypeScript with no build step — edit a file, restart, done.

```
src/cli.ts             arguments and startup
src/config.ts          every setting, and where it comes from
src/server.ts          wiring
src/routes/            the HTTP endpoints
src/comfy/workflows/   the ComfyUI graphs — change these to render differently
src/cache/             the picture index
src/batch/             the overnight queue
ui/index.html          the review page
```

`src/comfy/workflows/index.ts` is the interesting one: it builds the node graph
sent to ComfyUI. Changing the sampler, adding a LoRA, or swapping the model
happens there or through the matching command-line options.

Run the tests with `bun test` from the repository root, or
`npx vitest run packages/wayward-imagegen/test/`.

The prompts themselves are **not** here — the game builds those and sends them
over. This program decides how a prompt becomes a picture, not what the picture
should be of.
