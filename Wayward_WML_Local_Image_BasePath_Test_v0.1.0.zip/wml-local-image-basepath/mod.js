// WML diagnostic/fix mod: resolve local art images relative to the HTML file.
// This intentionally leaves the game's image catalogue and imagePath values untouched.
WML.define({
  id: 'local-image-basepath',
  name: {
    ko: '로컬 이미지 기준 경로 보정',
    en: 'Local image base-path correction'
  },
  version: '0.1.0',
  game: '>=2026-10-04',
  description: {
    ko: 'art.sintention.com/images/... 요청을 HTML 파일 위치 기준 images/...로 연결합니다. 하위 폴더에 게임을 둔 모바일 서버 환경을 지원합니다.',
    en: 'Resolves art.sintention.com image URLs against the game HTML folder, including nested mobile-server folders.'
  },
  setup(api) {
    'use strict';

    const FLAG = '__WML_LOCAL_IMAGE_BASEPATH__';
    if (window[FLAG]?.installed) return;

    const state = window[FLAG] = {
      installed: true,
      rewrites: 0,
      loaded: 0,
      failed: 0,
      lastOriginal: '',
      lastLocal: '',
      lastFailed: '',
      pageUrl: location.href,
      documentBaseURI: document.baseURI,
      expectedImagesFolder: new URL('images/', document.baseURI).href
    };

    const watched = new WeakSet();
    const imgDescriptor = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'src');
    const originalSetAttribute = Element.prototype.setAttribute;

    function rewrite(value) {
      if (typeof value !== 'string' || value.length === 0) return value;

      let parsed;
      try {
        parsed = new URL(value, document.baseURI);
      } catch {
        return value;
      }

      const current = new URL(document.baseURI);
      const isArtHost = parsed.hostname.toLowerCase() === 'art.sintention.com';
      const isSameOrigin = parsed.origin === current.origin;
      if (!isArtHost && !isSameOrigin) return value;
      if (!parsed.pathname.startsWith('/images/')) return value;

      // Keep the 'images/' segment relative to the HTML directory.
      // Do NOT use location.origin + '/images/': that loses a parent folder such as
      // /HL_wayward_20261018/ when the web server root is one directory higher.
      const relativePath = parsed.pathname.replace(/^\/+/, '');
      let localUrl;
      try {
        localUrl = new URL(relativePath + parsed.search + parsed.hash, document.baseURI).href;
      } catch {
        return value;
      }

      if (localUrl !== value) {
        state.rewrites++;
        state.lastOriginal = value;
        state.lastLocal = localUrl;
        if (state.rewrites <= 8 || state.rewrites % 100 === 0) {
          console.info('[WML local-image-basepath] redirected', value, '=>', localUrl);
        }
      }
      return localUrl;
    }

    function watchImage(image) {
      if (watched.has(image)) return;
      watched.add(image);
      image.addEventListener('load', () => { state.loaded++; }, { passive: true });
      image.addEventListener('error', () => {
        state.failed++;
        state.lastFailed = image.currentSrc || image.src || image.getAttribute('src') || '';
        if (state.failed <= 8 || state.failed % 100 === 0) {
          console.warn('[WML local-image-basepath] image load failed', state.lastFailed);
        }
      }, { passive: true });
    }

    if (imgDescriptor?.get && imgDescriptor?.set && imgDescriptor.configurable) {
      Object.defineProperty(HTMLImageElement.prototype, 'src', {
        configurable: true,
        enumerable: imgDescriptor.enumerable,
        get() {
          return imgDescriptor.get.call(this);
        },
        set(value) {
          watchImage(this);
          return imgDescriptor.set.call(this, rewrite(String(value)));
        }
      });
    } else {
      console.warn('[WML local-image-basepath] HTMLImageElement.src could not be wrapped in this browser.');
    }

    Element.prototype.setAttribute = function(name, value) {
      if (this instanceof HTMLImageElement && String(name).toLowerCase() === 'src') {
        watchImage(this);
        return originalSetAttribute.call(this, name, rewrite(String(value)));
      }
      return originalSetAttribute.call(this, name, value);
    };

    // Catch images already present before the mod initialized.
    function rewriteExistingImages(root = document) {
      if (!root?.querySelectorAll) return;
      for (const image of root.querySelectorAll('img[src]')) {
        watchImage(image);
        const before = image.getAttribute('src');
        const after = rewrite(before);
        if (after !== before) originalSetAttribute.call(image, 'src', after);
      }
    }

    rewriteExistingImages();

    const observer = new MutationObserver(records => {
      for (const record of records) {
        if (record.type === 'attributes' && record.attributeName === 'src') {
          const image = record.target;
          if (!(image instanceof HTMLImageElement)) continue;
          watchImage(image);
          const before = image.getAttribute('src');
          const after = rewrite(before);
          if (after !== before) originalSetAttribute.call(image, 'src', after);
        }
        for (const node of record.addedNodes || []) {
          if (node instanceof HTMLImageElement) {
            watchImage(node);
            const before = node.getAttribute('src');
            const after = rewrite(before);
            if (after && after !== before) originalSetAttribute.call(node, 'src', after);
          } else if (node?.querySelectorAll) {
            rewriteExistingImages(node);
          }
        }
      }
    });

    if (document.documentElement) {
      observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['src']
      });
    }

    state.getStatus = () => ({
      installed: state.installed,
      rewrites: state.rewrites,
      loaded: state.loaded,
      failed: state.failed,
      lastOriginal: state.lastOriginal,
      lastLocal: state.lastLocal,
      lastFailed: state.lastFailed,
      pageUrl: location.href,
      documentBaseURI: document.baseURI,
      expectedImagesFolder: new URL('images/', document.baseURI).href,
      note: 'If rewrites increase but images fail, inspect the reported local URL and whether the server returns that exact file.'
    });

    console.info('[WML local-image-basepath] installed', {
      pageUrl: location.href,
      documentBaseURI: document.baseURI,
      expectedImagesFolder: state.expectedImagesFolder
    });

    try {
      api?.log?.('로컬 이미지 경로 보정 활성화: HTML 파일 위치 기준 images/ 경로를 사용합니다.');
    } catch { /* logging is optional */ }
  }
});
