로컬 이미지 기준 경로 보정 모드 0.1.0

목적
- art.sintention.com/images/...로 향하는 이미지 요청을 현재 HTML 파일의 폴더를 기준으로 images/...에 연결합니다.
- 특히 다음 구조처럼 게임 폴더가 웹서버 루트 아래 한 단계 들어간 경우를 처리합니다.

  HL_wayward_20261018/
    Wayward_WML_ko.html
    images/
      illustrious/
        characters/
    images-mari-1.js
    images-hina-1.js
    wml/

중요
- location.origin + '/images/...'를 사용하지 않습니다.
- document.baseURI를 기준으로 URL을 계산하므로 /HL_wayward_20261018/ 경로가 보존됩니다.
- 게임의 이미지 목록, imagePath 값, 세이브 데이터, 게임 로직은 수정하지 않습니다.
- 이미지 파일을 다운로드하거나 이동하지 않습니다.

설치 및 확인
1. ZIP 안의 wml-local-image-basepath 폴더를 WML 모드에 등록합니다.
2. 모드를 활성화하고 게임을 새로고침합니다.
3. 브라우저 콘솔에서 다음을 실행합니다.

   window.__WML_LOCAL_IMAGE_BASEPATH__?.getStatus()

4. rewrites 값이 증가하는지 확인합니다.
   lastLocal이 다음과 같은 형태여야 합니다.

   http://서버주소/HL_wayward_20261018/images/illustrious/characters/파일명

판정
- rewrites가 0이면 해당 HTML이 art.sintention.com/images/... 또는 동일 출처의 /images/... 경로를 사용하지 않는 것입니다. 이 경우 4.38MB HTML 자체의 경로 함수를 별도 확인해야 합니다.
- rewrites가 증가하고 loaded도 증가하면 로컬 이미지가 정상 로딩되는 것입니다.
- rewrites가 증가하지만 failed가 증가하면 lastFailed의 URL에 해당하는 실제 파일이 있는지, Android 서버가 그 하위 경로를 제공하는지 확인해야 합니다.

이 모드는 진단 겸 경로 보정 모드입니다. 실제 Android 서버와 4.38MB HTML에서 검증된 결과로 간주하지 마세요.
